﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.Windows.Forms;

    public class RepTankerLog : Form
    {
        private WBTable tbl_info;
        private string fName = "";
        public string chckSQL;
        public int refCount = 0;
        public int rowCount = 0;
        private IContainer components = null;
        public Label label3;
        public Label labelProses2;
        public CheckBox checkDate;
        public TextBox textTanker;
        public GroupBox groupBox1;
        public DateTimePicker monthCalendar1;
        public Label label5;
        public Label label6;
        public DateTimePicker monthCalendar2;
        public Label labelProses1;
        public Button button2;
        public Label labelcommodity;
        public Button button1;
        public Button buttonTanker;

        public RepTankerLog()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                WBTable vTransLog = new WBTable();
                vTransLog = this.initTable(this.checkDate.Checked, this.monthCalendar1.Value, this.monthCalendar2.Value, this.textTanker.Text);
                if (vTransLog.DT.Rows.Count <= 0)
                {
                    MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    HTML html = new HTML();
                    html = this.generateRep(vTransLog, this.monthCalendar1.Value);
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + html.File) }
                    };
                    report.ShowDialog();
                    this.labelProses1.Text = "";
                    this.labelProses1.Refresh();
                    this.labelProses2.Text = "";
                    this.labelProses2.Refresh();
                    html.Dispose();
                    report.Dispose();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonTanker_Click(object sender, EventArgs e)
        {
            FormTanker tanker = new FormTanker {
                pMode = "CHOOSE"
            };
            tanker.ShowDialog();
            if (tanker.ReturnRow != null)
            {
                this.textTanker.Text = tanker.ReturnRow["Tanker_No"].ToString();
                this.textTanker.Focus();
            }
            tanker.Dispose();
        }

        private void checkDate_CheckedChanged(object sender, EventArgs e)
        {
            this.textTanker.Enabled = !this.checkDate.Checked;
            this.monthCalendar1.Enabled = this.checkDate.Checked;
            this.monthCalendar2.Enabled = this.checkDate.Checked;
            this.textTanker.Text = "";
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public HTML generateRep(WBTable vTransLog, DateTime dt)
        {
            WBTable table = new WBTable();
            this.tbl_info = new WBTable();
            string sqltext = "Select ORDINAL_POSITION as NO, COLUMN_NAME as FIELD, DATA_TYPE as TYPE, CHARACTER_MAXIMUM_LENGTH as LENGTH, IS_NULLABLE as ISNULL from INFORMATION_SCHEMA.COLUMNS WHERE table_name ='wb_tanker_log'";
            this.tbl_info.OpenTable("wb_info", sqltext, WBData.conn);
            int count = 0;
            count = this.tbl_info.DT.Rows.Count;
            this.labelProses1.Text = "0/" + vTransLog.DT.Rows.Count;
            HTML html = new HTML();
            string path = html.File + @"\TankerLogReport";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            html.File = html.File + @"\TankerLogReport\TANKERLOG_" + dt.ToString("ddMMyyyy") + ".htm";
            html.Title = "List of Tanker Log";
            html.Open();
            html.Write(html.Style());
            html.Write("<br><font size=5><b>LIST OF APPROVED OVER CAPACITY TANKER</b></font><br>");
            string[] textArray1 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
            html.Write(string.Concat(textArray1));
            string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
            html.Write(string.Concat(textArray2));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            html.Write("<br><br>");
            html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
            if (this.textTanker.Text.Trim() != "")
            {
                html.Write("<tr class=bd>");
                html.Write("<td>Tanker No</td>");
                html.Write("<td>: <b>" + this.textTanker.Text + "</b></td>");
                html.Write("</tr>");
            }
            if (this.checkDate.Checked)
            {
                html.Write("<tr class=bd>");
                html.Write("<td>Selected Date</td>");
                string[] textArray3 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                html.Write(string.Concat(textArray3));
                html.Write("</tr>");
            }
            html.Write("<tr class=bd>");
            html.Write("<td>Report Date</td>");
            DateTime now = DateTime.Now;
            html.Write("<td>: <b>" + now.ToShortDateString() + "</b></td>");
            html.Write("</tr>");
            html.Write("</table>");
            html.Write("<br/><br/><br/>");
            table.OpenTable("wb_tanker_Log", this.chckSQL, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                html.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                html.Write("<tr class='bd'> ");
                html.Write("<th nowrap>Date</th>");
                html.Write("<th nowrap>Reference No</th>");
                html.Write("<th nowrap>Tanker No</th>");
                html.Write("<th>Maximum Capacity</th>");
                html.Write("<th nowrap>Net</th>");
                html.Write("<th nowrap>Released By</th>");
                html.Write("<th nowrap>Remark</th>");
                html.Write("</tr> ");
                this.fName = "";
                this.rowCount = 0;
                foreach (DataRow row in vTransLog.DT.Rows)
                {
                    this.labelProses1.Text = this.rowCount.ToString();
                    this.labelProses1.Refresh();
                    html.Write("<tr class='bd'>");
                    now = Convert.ToDateTime(row["DateTime"].ToString());
                    html.Write("<td>" + html.strq(now.ToShortDateString()) + "</td>");
                    html.Write("<td>" + html.strq(row["Ref"].ToString()) + "</td>");
                    html.Write("<td>" + html.strq(row["Tanker_No"].ToString()) + "</td>");
                    html.Write("<td align=right>" + html.strq(row["Max_Cap"].ToString()) + "</td>");
                    html.Write("<td align=right>" + html.strq(row["Net"].ToString()) + "</td>");
                    html.Write("<td>" + html.strq(row["ReleaseBy"].ToString()) + "</td>");
                    html.Write("<td>" + html.strq(row["Remark"].ToString()) + "</td>");
                    html.Write("</tr>");
                    this.rowCount++;
                }
                html.Write("</table>");
                html.Write("<br>");
                html.Write("<br>");
            }
            html.writeSign();
            html.Close();
            return html;
        }

        private void InitializeComponent()
        {
            this.label3 = new Label();
            this.labelProses2 = new Label();
            this.checkDate = new CheckBox();
            this.textTanker = new TextBox();
            this.groupBox1 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label5 = new Label();
            this.label6 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.labelProses1 = new Label();
            this.button2 = new Button();
            this.labelcommodity = new Label();
            this.button1 = new Button();
            this.buttonTanker = new Button();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(10, 11);
            this.label3.Name = "label3";
            this.label3.Size = new Size(200, 20);
            this.label3.TabIndex = 0x57;
            this.label3.Text = "Tanker Approval History";
            this.label3.TextAlign = ContentAlignment.TopCenter;
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0x150, 0x1d);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0xd6, 13);
            this.labelProses2.TabIndex = 0x55;
            this.labelProses2.Text = "Progresssss . . . . . . . . . . . . . . . . . ";
            this.labelProses2.TextAlign = ContentAlignment.MiddleRight;
            this.checkDate.AutoSize = true;
            this.checkDate.Checked = true;
            this.checkDate.CheckState = CheckState.Checked;
            this.checkDate.Location = new Point(14, 0x36);
            this.checkDate.Name = "checkDate";
            this.checkDate.Size = new Size(60, 0x11);
            this.checkDate.TabIndex = 0x54;
            this.checkDate.Text = "byDate";
            this.checkDate.UseVisualStyleBackColor = true;
            this.checkDate.CheckedChanged += new EventHandler(this.checkDate_CheckedChanged);
            this.textTanker.CharacterCasing = CharacterCasing.Upper;
            this.textTanker.Location = new Point(0x5d, 0x81);
            this.textTanker.Name = "textTanker";
            this.textTanker.Size = new Size(0x90, 20);
            this.textTanker.TabIndex = 80;
            this.groupBox1.Controls.Add(this.monthCalendar1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.monthCalendar2);
            this.groupBox1.Location = new Point(14, 0x42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x178, 0x2d);
            this.groupBox1.TabIndex = 0x4f;
            this.groupBox1.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(80, 0x10);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(8, 0x13);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x3e, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "From Date :";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xc6, 0x13);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x34, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x100, 0x10);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(0x153, 0x10);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0xd3, 13);
            this.labelProses1.TabIndex = 0x56;
            this.labelProses1.Text = "1/88888";
            this.labelProses1.TextAlign = ContentAlignment.MiddleRight;
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(440, 0x7b);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x22);
            this.button2.TabIndex = 0x52;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(11, 0x84);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3a, 13);
            this.labelcommodity.TabIndex = 0x53;
            this.labelcommodity.Text = "Tanker No";
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(440, 0x4c);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x22);
            this.button1.TabIndex = 0x51;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.buttonTanker.Location = new Point(0xf4, 0x7f);
            this.buttonTanker.Margin = new Padding(0);
            this.buttonTanker.Name = "buttonTanker";
            this.buttonTanker.Size = new Size(0x17, 0x17);
            this.buttonTanker.TabIndex = 0x7c;
            this.buttonTanker.Text = "...";
            this.buttonTanker.UseVisualStyleBackColor = true;
            this.buttonTanker.Click += new EventHandler(this.buttonTanker_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x239, 0xad);
            base.ControlBox = false;
            base.Controls.Add(this.buttonTanker);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.checkDate);
            base.Controls.Add(this.textTanker);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.button1);
            base.Name = "RepTankerLog";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Tanker Approval History";
            base.Load += new EventHandler(this.RepTankerLog_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private WBTable initTable(bool byDate, DateTime dateFrom, DateTime dateTo, string tankerNo)
        {
            WBTable table = new WBTable();
            string sqltext = "SELECT * FROM wb_tanker_log WHERE " + WBData.CompanyLocation("");
            if (byDate)
            {
                sqltext = (sqltext + " AND (Datetime>='" + dateFrom.ToString("yyyy-MM-dd") + " 00:00:00'") + " AND Datetime<='" + dateTo.ToString("yyyy-MM-dd") + " 00:00:00')";
            }
            if (this.textTanker.Text != "")
            {
                sqltext = sqltext + " AND Tanker_No = '" + tankerNo + "'";
            }
            this.chckSQL = sqltext;
            sqltext = sqltext + "ORDER BY datetime ASC";
            table.OpenTable("wb_tanker_Log", sqltext, WBData.conn);
            return table;
        }

        private void RepTankerLog_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.textTanker.Enabled = false;
            this.labelProses1.Text = "";
            this.labelProses2.Text = "";
            WBTable tbl = new WBTable();
            tbl.OpenTable("wb_tanker", "Select * from wb_tanker where " + WBData.CompanyLocation(""), WBData.conn);
            Program.AutoComp(tbl, "Tanker_No", this.textTanker);
        }
    }
}

