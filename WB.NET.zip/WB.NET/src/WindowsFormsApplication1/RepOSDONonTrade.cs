﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class RepOSDONonTrade : Form
    {
        private int jlhFillBaris = 0;
        private int WBDOOSLeft = 0;
        private int SumLoadQty = 0;
        private int Weightedin = 0;
        private int utoday = 0;
        private int checkrow = 0;
        private int totalrow = 0;
        private string Require_BC = "";
        private WBTable vwTransBC = new WBTable();
        private WBTable weighinTrans = new WBTable();
        private WBTable rowCount = new WBTable();
        private WBTable BCGrouping = new WBTable();
        private WBTable Require_BC1 = new WBTable();
        private WBTable Require_BC2 = new WBTable();
        public bool isOk = false;
        private WBTable tbl_Do;
        private string rptName;
        private int jlhKolomA = 0;
        private int jlhKolomB = 0;
        private IContainer components = null;
        private Panel panel1;
        private CheckBox checkPONoItem;
        private CheckBox checkCommodity;
        private CheckBox checkRelation;
        private CheckBox checkRef;
        public Label labelDisplayColumns;
        public Button button2;
        public Button button1;
        private CheckBox checkReportDate;
        private CheckBox cBoxAll;
        public Button buttonDoNo;
        public Label labelDoNo;
        public TextBox textDoNo;
        public GroupBox groupBox2;
        public RadioButton checkBox_calculateOSbyBCNo;
        public RadioButton checkBox_calculateOSbyWBDO;
        private CheckBox checkBox_FilterByDate;
        private Label lblDateTo;
        public DateTimePicker dtp_ToDate;
        public DateTimePicker dtp_FromDate;
        public Label labelDateFrom;
        public Label labelMaxRow;
        private NumericUpDown textMaxRow;

        public RepOSDONonTrade()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.checkBox_FilterByDate.Checked || (this.textDoNo.Text.Trim() != ""))
            {
                this.isOk = true;
                string sqltext = "";
                string str2 = "";
                string str3 = "";
                string str4 = "";
                string str5 = "";
                string str6 = "";
                if (!this.checkBox_FilterByDate.Checked)
                {
                    if (this.checkBox_calculateOSbyWBDO.Checked)
                    {
                        str2 = "Select SUM(CAST ([Item_Load_Qty] as INT)) as TtlQty from vw_TransBC where " + WBData.CompanyLocation(" and (report_date > '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')");
                    }
                    else if (this.checkBox_calculateOSbyBCNo.Checked)
                    {
                        str2 = "Select BC_No,BC_Item,BC_Type,BC_Date,SUM(CAST ([Item_Load_Qty] as INT)) as TtlQty from vw_TransBC where " + WBData.CompanyLocation(" and (report_date > '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')");
                        str4 = "Select BC_No, BC_Item, BC_Type, BC_Date, COUNT(STO) as Jmlh  from vw_TransBC where " + WBData.CompanyLocation(" and (report_date <'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')");
                    }
                    sqltext = "Select TOP(" + this.textMaxRow.Value.ToString() + ") * from vw_TransBC where " + WBData.CompanyLocation(" and (report_date >= '1900-01-01  00:00:00' and report_date <= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')");
                }
                else
                {
                    if (this.checkBox_calculateOSbyWBDO.Checked)
                    {
                        str2 = "Select SUM(CAST ([Item_Load_Qty] as INT)) as TtlQty from vw_TransBC where " + WBData.CompanyLocation(" and (report_date < '" + this.dtp_FromDate.Value.ToString("yyyy-MM-dd") + " 00:00:00')");
                    }
                    else if (this.checkBox_calculateOSbyBCNo.Checked)
                    {
                        str2 = "Select BC_No,BC_Item,BC_Type,BC_Date,SUM(CAST ([Item_Load_Qty] as INT)) as TtlQty from vw_TransBC where " + WBData.CompanyLocation(" and (report_date < '" + this.dtp_FromDate.Value.ToString("yyyy-MM-dd") + " 00:00:00')");
                        str4 = "Select BC_No, BC_Item, BC_Type, BC_Date, COUNT(STO) as Jmlh  from vw_TransBC where " + WBData.CompanyLocation(" and (report_date <='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')");
                    }
                    string[] textArray1 = new string[] { " and (report_date >= '", this.dtp_FromDate.Value.ToString("yyyy-MM-dd"), " 00:00:00' and report_date <= '", this.dtp_ToDate.Value.ToString("yyyy-MM-dd"), " 00:00:00')" };
                    sqltext = "Select TOP(" + this.textMaxRow.Value.ToString() + ") * from vw_TransBC where " + WBData.CompanyLocation(string.Concat(textArray1));
                }
                str5 = "Select TOP(" + this.textMaxRow.Value.ToString() + ") * from wb_contract where " + WBData.CompanyLocation("");
                str6 = "Select TOP(" + this.textMaxRow.Value.ToString() + ") * from wb_contract_detail_STO where " + WBData.CompanyLocation(" ");
                str3 = "Select  Count (Item_Load_Qty) as TtlRow from vw_TransBC where " + WBData.CompanyLocation(" and (report_date <= '" + this.dtp_ToDate.Value.ToString("yyyy-MM-dd") + " 00:00:00')");
                if (this.textDoNo.Text.Trim() != "")
                {
                    sqltext = sqltext + " and (Do_No = '" + this.textDoNo.Text + "')";
                    str2 = str2 + " and (Do_No = '" + this.textDoNo.Text + "')";
                    str3 = str3 + " and (Do_No = '" + this.textDoNo.Text + "')";
                    if (this.checkBox_calculateOSbyBCNo.Checked)
                    {
                        str4 = str4 + " and (Do_No = '" + this.textDoNo.Text + "')";
                    }
                    str5 = str5 + " and (Do_No = '" + this.textDoNo.Text + "')";
                    str6 = str6 + " and (Do_No = '" + this.textDoNo.Text + "')";
                }
                sqltext = ((sqltext + " and (deleted is null or deleted = 'N') and (trx_deleted is null or trx_deleted = 'N') ") + " and (NOT(REF like '%" + Constant.TITIP_TIMBUN_POSTFIX + "'))") + " and (NOT(REF like '%T'))";
                str2 = ((str2 + "and (deleted is null or deleted ='N') and (trx_deleted is null or trx_deleted = 'N') ") + " and (NOT(REF like '%" + Constant.TITIP_TIMBUN_POSTFIX + "'))") + " and (NOT(REF like '%T'))";
                str3 = ((str3 + "and(deleted  is null or deleted ='N') and (trx_deleted is null or trx_deleted = 'N') ") + " and (NOT(REF like '%" + Constant.TITIP_TIMBUN_POSTFIX + "'))") + " and (NOT(REF like '%T'))";
                if (!this.checkBox_calculateOSbyWBDO.Checked)
                {
                    if (this.checkBox_calculateOSbyBCNo.Checked)
                    {
                        str4 = ((str4 + "and(deleted  is null or deleted ='N') and (header_require_bc = 'Y' or detail_require_bc = 'Y')") + " and (NOT(REF like '%" + Constant.TITIP_TIMBUN_POSTFIX + "'))") + " and (NOT(REF like '%T'))" + "Group by BC_No, BC_Item, BC_Type, BC_Date";
                        sqltext = sqltext + " order by BC_No, BC_Item, BC_Type, BC_Date, Ref ";
                        str2 = str2 + "Group by BC_No,BC_Item,BC_Type,BC_Date";
                        this.BCGrouping.OpenTable("vw_transBC", str4, WBData.conn);
                        if (this.BCGrouping.DT.Rows.Count < 1)
                        {
                            MessageBox.Show("This WB DO does not require BC and does not have BC No", Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            return;
                        }
                        else
                        {
                            this.BCGrouping.DR = this.BCGrouping.DT.Rows[0];
                        }
                    }
                }
                else
                {
                    sqltext = sqltext + " order by STO";
                }
                str5 = str5 + " order by STO_Item";
                str6 = str6 + " order by STO_Item";
                this.vwTransBC.OpenTable("vw_transBC", sqltext, WBData.conn);
                this.rowCount.OpenTable("vw_transBC", str3, WBData.conn);
                this.weighinTrans.OpenTable("vw_transBC", str2, WBData.conn);
                this.Require_BC1.OpenTable("wb_contract_detail_STO", str5, WBData.conn);
                this.Require_BC2.OpenTable("wb_contract", str6, WBData.conn);
                if (this.rowCount.DT.Rows.Count >= 1)
                {
                    this.rowCount.DR = this.rowCount.DT.Rows[0];
                }
                if (this.weighinTrans.DT.Rows.Count >= 1)
                {
                    this.weighinTrans.DR = this.weighinTrans.DT.Rows[0];
                }
                if (this.Require_BC1.DT.Rows.Count >= 1)
                {
                    this.Require_BC1.DR = this.Require_BC1.DT.Rows[0];
                }
                if (this.Require_BC2.DT.Rows.Count >= 1)
                {
                    this.Require_BC2.DR = this.Require_BC2.DT.Rows[0];
                }
                if (this.vwTransBC.DT.Rows.Count == 0.0)
                {
                    MessageBox.Show(Resource.Mes_348, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    HTML rep = new HTML();
                    rep.File = rep.File + @"\" + WBUser.UserID + "_RecIssue.htm";
                    rep.Title = this.rptName;
                    rep.Open();
                    rep.Write(rep.Style());
                    rep.Write("<br><font size=5><b>REPORT OF OUTSTANDING DO NON-TRADE STORE</b></font><br>");
                    string[] textArray2 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                    rep.Write(string.Concat(textArray2));
                    string[] textArray3 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                    rep.Write(string.Concat(textArray3));
                    if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                    {
                        rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                    }
                    if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                    {
                        rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                    }
                    if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                    {
                        rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                    }
                    rep.Write("<br><br>");
                    rep.Write("<font size=3>");
                    if (this.checkBox_FilterByDate.Checked)
                    {
                        rep.Write("<br>DAILY REPORT");
                    }
                    else
                    {
                        rep.Write("<br>SUMMARY REPORT");
                    }
                    rep.Write("</font></b><br/>");
                    rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                    if (this.checkBox_FilterByDate.Checked)
                    {
                        rep.Write("<tr class=bd>");
                        rep.Write("<td>" + Resource.Report11_028 + "</td>");
                        string[] textArray4 = new string[] { "<td>: <b>", this.dtp_FromDate.Value.ToShortDateString(), " - ", this.dtp_ToDate.Value.ToShortDateString(), "</b></td>" };
                        rep.Write(string.Concat(textArray4));
                        rep.Write("</tr>");
                    }
                    if (this.textDoNo.Text.Trim() != "")
                    {
                        rep.Write("<tr class=bd>");
                        rep.Write("<td>" + Resource.Report11_017 + "</td>");
                        rep.Write("<td>: <b>" + this.textDoNo.Text + "</b></td>");
                        rep.Write("</tr>");
                    }
                    rep.Write("<tr class=bd>");
                    rep.Write("<td>Report Date</td>");
                    rep.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                    rep.Write("</tr>");
                    rep.Write("</table>");
                    rep.Write("<br/><br/>");
                    List<string> list = new List<string>();
                    foreach (DataRow row in this.vwTransBC.DT.Rows)
                    {
                        if (this.checkBox_calculateOSbyWBDO.Checked)
                        {
                            if (list.Contains(row["STO"].ToString() + "/" + row["STO_Item"].ToString()))
                            {
                                continue;
                            }
                            list.Add(row["STO"].ToString() + "/" + row["STO_Item"].ToString());
                        }
                        else if (this.checkBox_calculateOSbyBCNo.Checked)
                        {
                            string[] textArray5 = new string[] { row["BC_No"].ToString(), "/", row["BC_Item"].ToString(), "/", row["BC_Type"].ToString(), "/", row["BC_Date"].ToString() };
                            if (list.Contains(string.Concat(textArray5)))
                            {
                                continue;
                            }
                            string[] textArray6 = new string[] { row["BC_No"].ToString(), "/", row["BC_Item"].ToString(), "/", row["BC_Type"].ToString(), "/", row["BC_Date"].ToString() };
                            list.Add(string.Concat(textArray6));
                        }
                        this.jlhFillBaris = 0;
                        this.SumLoadQty = 0;
                        if (this.checkBox_calculateOSbyWBDO.Checked)
                        {
                            this.WBDOOSLeft = Convert.ToInt32(string.IsNullOrEmpty(row["STO_Qty"].ToString()) ? "0" : row["STO_Qty"].ToString());
                        }
                        else if (this.checkBox_calculateOSbyBCNo.Checked)
                        {
                            this.WBDOOSLeft = Convert.ToInt32(string.IsNullOrEmpty(row["BC_Qty"].ToString()) ? "0" : row["BC_Qty"].ToString());
                        }
                        rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                        this.initHeader(rep);
                        foreach (DataRow row2 in this.vwTransBC.DT.Rows)
                        {
                            string[] aField = new string[] { "STO_Item" };
                            string[] aFind = new string[] { row["STO_Item"].ToString() };
                            DataRow data = this.Require_BC1.GetData(aField, aFind);
                            bool flag30 = this.Require_BC2.DT.Rows.Count > 0;
                            this.Require_BC = !flag30 ? this.Require_BC1.DR["Require_BC"].ToString() : this.Require_BC2.DR["Require_BC"].ToString();
                            if (this.checkBox_calculateOSbyWBDO.Checked)
                            {
                                if ((row["STO"].ToString() != row2["STO"].ToString()) || (row["STO_Item"].ToString() != row2["STO_Item"].ToString()))
                                {
                                    continue;
                                }
                                this.fillTable(rep, row2);
                                continue;
                            }
                            if (this.checkBox_calculateOSbyBCNo.Checked && (((row["BC_No"].ToString() == row2["BC_No"].ToString()) && ((row["BC_Item"].ToString() == row2["BC_Item"].ToString()) && (row["BC_Type"].ToString() == row2["BC_Type"].ToString()))) && (row["BC_Date"].ToString() == row2["BC_Date"].ToString())))
                            {
                                string[] textArray9 = new string[] { "BC_No", "BC_Item", "BC_Type", "BC_Date" };
                                string[] textArray10 = new string[] { row["BC_No"].ToString(), row["BC_Item"].ToString(), row["BC_Type"].ToString(), row["BC_Date"].ToString() };
                                DataRow row4 = this.BCGrouping.GetData(textArray9, textArray10);
                                this.checkrow = Convert.ToInt32(row4["Jmlh"].ToString());
                                if (this.vwTransBC.DT.Rows.Count != this.totalrow)
                                {
                                    this.totalrow++;
                                }
                                this.fillTable(rep, row2);
                            }
                        }
                        if (this.checkBox_calculateOSbyWBDO.Checked)
                        {
                            this.subTotalDO(rep, row["STO"].ToString() + "/" + row["STO_Item"].ToString());
                        }
                        else if (this.checkBox_calculateOSbyBCNo.Checked)
                        {
                            string[] textArray11 = new string[] { row["BC_No"].ToString(), "/", row["BC_Item"].ToString(), " Type ", row["BC_Type"].ToString() };
                            this.subTotalBC(rep, string.Concat(textArray11));
                        }
                        rep.Write("</table>");
                        rep.Write("<br><br><br>");
                    }
                    rep.writeSign();
                    rep.Close();
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + rep.File) }
                    };
                    report.ShowDialog();
                    rep.Dispose();
                    report.Dispose();
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_599, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.textDoNo.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonDoNo_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFind = this.textDoNo.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDoNo.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        private void cBoxAll_CheckedChanged(object sender, EventArgs e)
        {
            if (this.cBoxAll.Checked)
            {
                foreach (Control control in this.panel1.GetOffsprings())
                {
                    if ((control.GetType() == typeof(CheckBox)) && control.Visible)
                    {
                        ((CheckBox) control).Checked = true;
                    }
                }
            }
            else
            {
                foreach (Control control2 in this.panel1.GetOffsprings())
                {
                    if ((control2.GetType() == typeof(CheckBox)) && control2.Visible)
                    {
                        ((CheckBox) control2).Checked = false;
                    }
                }
            }
        }

        private void checkBox_FilterByDate_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox_FilterByDate.Checked)
            {
                this.dtp_FromDate.Enabled = true;
                this.dtp_ToDate.Enabled = true;
            }
            else
            {
                this.dtp_FromDate.Enabled = false;
                this.dtp_ToDate.Enabled = false;
            }
            this.reportName();
        }

        private void checkRelation_CheckedChanged(object sender, EventArgs e)
        {
            Control control = (Control) sender;
            if ((control.GetType() == typeof(CheckBox)) && !((CheckBox) control).Checked)
            {
                this.cBoxAll.CheckedChanged -= new EventHandler(this.cBoxAll_CheckedChanged);
                this.cBoxAll.Checked = false;
                this.cBoxAll.CheckedChanged += new EventHandler(this.cBoxAll_CheckedChanged);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void fillTable(HTML rep, DataRow aRowTransBC)
        {
            this.jlhFillBaris++;
            rep.Write("<tr class='bd'>");
            rep.Write("<td rowspan='1' nowrap align=center>" + this.jlhFillBaris + "</td>");
            if (this.checkRef.Checked)
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + aRowTransBC["Ref"].ToString() + "</td>");
            }
            if (this.checkReportDate.Checked)
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + aRowTransBC["Report_Date"].ToString() + "</td>");
            }
            rep.Write("<td rowspan='1' nowrap align=left>" + aRowTransBC["Do_No"].ToString() + "</td>");
            if (this.checkRelation.Checked)
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + aRowTransBC["Relation_Name"].ToString() + "</td>");
            }
            if (this.checkCommodity.Checked)
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + aRowTransBC["Comm_Code"].ToString() + "</td>");
                rep.Write("<td rowspan='1' nowrap align=left>" + this.getCommName(aRowTransBC["Comm_Code"].ToString()) + "</td>");
            }
            if (this.checkPONoItem.Checked)
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + (string.IsNullOrEmpty(aRowTransBC["PO"].ToString()) ? "-" : aRowTransBC["PO"].ToString()) + "</td>");
                rep.Write("<td rowspan='1' nowrap align=left>" + (string.IsNullOrEmpty(aRowTransBC["PO_Item"].ToString()) ? "-" : aRowTransBC["PO_Item"].ToString()) + "</td>");
            }
            rep.Write("<td rowspan='1' nowrap align=left>" + aRowTransBC["STO"].ToString() + "</td>");
            rep.Write("<td rowspan='1' nowrap align=left>" + aRowTransBC["STO_Item"].ToString() + "</td>");
            rep.Write("<td rowspan='1' nowrap align=right>" + this.Require_BC + "</td>");
            if (aRowTransBC["BC_No"].ToString() == "")
            {
                rep.Write("<td rowspan='1' nowrap align=left>&nbsp; </td>");
            }
            else
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + aRowTransBC["BC_No"].ToString() + "</td>");
            }
            if (aRowTransBC["BC_Item"].ToString() == "")
            {
                rep.Write("<td rowspan='1' nowrap align=left>&nbsp; </td>");
            }
            else
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + aRowTransBC["BC_Item"].ToString() + "</td>");
            }
            if (aRowTransBC["BC_Type"].ToString() == "")
            {
                rep.Write("<td rowspan='1' nowrap align=left>&nbsp; </td>");
            }
            else
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + aRowTransBC["BC_Type"].ToString() + "</td>");
            }
            if (aRowTransBC["BC_Date"].ToString() == "")
            {
                rep.Write("<td rowspan='1' nowrap align=left>&nbsp; </td>");
            }
            else
            {
                rep.Write("<td rowspan='1' nowrap align=left>" + aRowTransBC["BC_Date"].ToString() + "</td>");
            }
            if (!this.checkBox_calculateOSbyWBDO.Checked)
            {
                if (this.checkBox_calculateOSbyBCNo.Checked)
                {
                    rep.Write("<td rowspan='1' nowrap align=right>" + aRowTransBC["BC_Qty"].ToString() + "</td>");
                    rep.Write("<td rowspan='1' nowrap align=right>" + aRowTransBC["BC_UoM"].ToString() + "</td>");
                }
            }
            else
            {
                rep.Write("<td rowspan='1' nowrap align=right>" + aRowTransBC["STO_Qty"].ToString() + "</td>");
                rep.Write("<td rowspan='1' nowrap align=right>" + aRowTransBC["STO_UoM"].ToString() + "</td>");
                if (aRowTransBC["Tolerance"].ToString() == "")
                {
                    rep.Write("<td rowspan='1' nowrap align=left>&nbsp; </td>");
                }
                else
                {
                    rep.Write("<td rowspan='1' nowrap align=left>" + aRowTransBC["Tolerance"].ToString() + "</td>");
                }
                this.totalrow = Convert.ToInt32(this.rowCount.DR["TtlRow"].ToString());
            }
            if (this.weighinTrans.DT.Rows.Count < 1)
            {
                if ((this.checkrow <= 1) || (this.vwTransBC.DT.Rows.Count == this.checkrow))
                {
                    this.Weightedin = 0;
                    if (this.vwTransBC.DT.Rows.Count != this.totalrow)
                    {
                        this.totalrow += 2;
                    }
                }
            }
            else if (this.weighinTrans.DT.Rows.Count >= 1)
            {
                if (this.weighinTrans.DR["TtlQty"].ToString() == "")
                {
                    this.Weightedin = 0;
                }
                else if (!this.checkBox_calculateOSbyBCNo.Checked)
                {
                    if (this.checkBox_calculateOSbyWBDO.Checked)
                    {
                        this.Weightedin = Convert.ToInt32(this.weighinTrans.DR["TtlQty"].ToString());
                    }
                }
                else
                {
                    string[] aField = new string[] { "BC_No", "BC_Item", "BC_Type", "BC_Date" };
                    string[] aFind = new string[] { aRowTransBC["BC_No"].ToString(), aRowTransBC["BC_Item"].ToString(), aRowTransBC["BC_Type"].ToString(), aRowTransBC["BC_Date"].ToString() };
                    DataRow data = this.weighinTrans.GetData(aField, aFind);
                    this.Weightedin = Convert.ToInt32(data["TtlQty"].ToString());
                }
            }
            rep.Write("<td rowspan='1' nowrap align=right>" + this.Weightedin + "</td>");
            rep.Write("<td rowspan='1' nowrap align=right><b>" + aRowTransBC["Item_Load_Qty"].ToString() + "</b></td>");
            this.SumLoadQty += Convert.ToInt32(aRowTransBC["Item_Load_Qty"].ToString());
            this.WBDOOSLeft -= Convert.ToInt32(aRowTransBC["Item_Load_Qty"].ToString());
            this.WBDOOSLeft -= this.Weightedin;
            if (this.checkBox_calculateOSbyWBDO.Checked)
            {
                this.utoday = Convert.ToInt32(aRowTransBC["STO_Qty"].ToString()) - this.WBDOOSLeft;
            }
            else if (this.checkBox_calculateOSbyBCNo.Checked)
            {
                this.utoday = Convert.ToInt32(aRowTransBC["BC_Qty"].ToString()) - this.WBDOOSLeft;
            }
            rep.Write("<td rowspan='1' nowrap align=right>" + this.utoday.ToString() + "</td>");
            rep.Write("<td rowspan='1' nowrap align=right><b>" + this.WBDOOSLeft.ToString() + "</b></td>");
            rep.Write("</tr>");
        }

        private string getCommName(string comm_code)
        {
            string str = "-";
            WBTable table = new WBTable();
            table.OpenTable("wb_commodity", "select * from wb_commodity where comm_code = '" + comm_code + "'", WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                str = table.DT.Rows[0]["Comm_Name"].ToString();
            }
            return str;
        }

        private void initHeader(HTML rep)
        {
            this.jlhKolomA = 0;
            this.jlhKolomB = 0;
            rep.Write("<tr class='bd'>");
            this.jlhKolomA++;
            if (this.checkRef.Checked)
            {
                this.jlhKolomA++;
            }
            if (this.checkReportDate.Checked)
            {
                this.jlhKolomA++;
            }
            this.jlhKolomA++;
            if (this.checkRelation.Checked)
            {
                this.jlhKolomA++;
            }
            if (this.checkCommodity.Checked)
            {
                this.jlhKolomA++;
                this.jlhKolomA++;
            }
            if (this.checkPONoItem.Checked)
            {
                this.jlhKolomA++;
                this.jlhKolomA++;
            }
            this.jlhKolomA++;
            this.jlhKolomA++;
            if (this.checkBox_calculateOSbyWBDO.Checked)
            {
                this.jlhKolomA++;
            }
            this.jlhKolomA++;
            this.jlhKolomA++;
            this.jlhKolomA++;
            this.jlhKolomA++;
            this.jlhKolomA++;
            this.jlhKolomA++;
            this.jlhKolomA++;
            this.jlhKolomB++;
            this.jlhKolomB++;
            rep.Write("<td rowspan='1' nowrap align=center><b>No.</b></td>");
            if (this.checkRef.Checked)
            {
                rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_012 + ".</b></td>");
            }
            if (this.checkReportDate.Checked)
            {
                rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_013 + "</b></td>");
            }
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_017 + "</b></td>");
            if (this.checkRelation.Checked)
            {
                rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_014 + "</b></td>");
            }
            if (this.checkCommodity.Checked)
            {
                rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_015 + "</b></td>");
                rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_031 + "</b></td>");
            }
            if (this.checkPONoItem.Checked)
            {
                rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_018 + "</b></td>");
                rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_019 + "</b></td>");
            }
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_020 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_021 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Lbl_Require_BC + " </b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_022 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_023 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_032 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_033 + "</b></td>");
            if (this.checkBox_calculateOSbyWBDO.Checked)
            {
                rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_039 + "</b></td>");
                rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_040 + "</b></td>");
                rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_041 + "</b></td>");
            }
            else if (this.checkBox_calculateOSbyBCNo.Checked)
            {
                rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_024 + "</b></td>");
                rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_030 + "</b></td>");
            }
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_035 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_034 + "</b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_036 + " </b></td>");
            rep.Write("<td rowspan='1' nowrap align=center><b>" + Resource.Report11_027 + "</b></td>");
            rep.Write("</tr>");
        }

        private void InitializeComponent()
        {
            this.panel1 = new Panel();
            this.checkReportDate = new CheckBox();
            this.checkPONoItem = new CheckBox();
            this.checkCommodity = new CheckBox();
            this.checkRelation = new CheckBox();
            this.checkRef = new CheckBox();
            this.labelDisplayColumns = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.cBoxAll = new CheckBox();
            this.buttonDoNo = new Button();
            this.labelDoNo = new Label();
            this.textDoNo = new TextBox();
            this.groupBox2 = new GroupBox();
            this.checkBox_calculateOSbyBCNo = new RadioButton();
            this.checkBox_calculateOSbyWBDO = new RadioButton();
            this.checkBox_FilterByDate = new CheckBox();
            this.lblDateTo = new Label();
            this.dtp_ToDate = new DateTimePicker();
            this.dtp_FromDate = new DateTimePicker();
            this.labelDateFrom = new Label();
            this.labelMaxRow = new Label();
            this.textMaxRow = new NumericUpDown();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.textMaxRow.BeginInit();
            base.SuspendLayout();
            this.panel1.BorderStyle = BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.checkReportDate);
            this.panel1.Controls.Add(this.checkPONoItem);
            this.panel1.Controls.Add(this.checkCommodity);
            this.panel1.Controls.Add(this.checkRelation);
            this.panel1.Controls.Add(this.checkRef);
            this.panel1.Location = new Point(0x13, 0xf3);
            this.panel1.Margin = new Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x35b, 0x40);
            this.panel1.TabIndex = 60;
            this.checkReportDate.AutoSize = true;
            this.checkReportDate.Checked = true;
            this.checkReportDate.CheckState = CheckState.Checked;
            this.checkReportDate.Location = new Point(8, 0x21);
            this.checkReportDate.Margin = new Padding(4);
            this.checkReportDate.Name = "checkReportDate";
            this.checkReportDate.Size = new Size(0x6b, 0x15);
            this.checkReportDate.TabIndex = 0x4b;
            this.checkReportDate.Text = "Report Date";
            this.checkReportDate.UseVisualStyleBackColor = true;
            this.checkReportDate.CheckedChanged += new EventHandler(this.checkRelation_CheckedChanged);
            this.checkPONoItem.AutoSize = true;
            this.checkPONoItem.Checked = true;
            this.checkPONoItem.CheckState = CheckState.Checked;
            this.checkPONoItem.Location = new Point(0x123, 6);
            this.checkPONoItem.Margin = new Padding(4);
            this.checkPONoItem.Name = "checkPONoItem";
            this.checkPONoItem.Size = new Size(0xab, 0x15);
            this.checkPONoItem.TabIndex = 12;
            this.checkPONoItem.Text = "PO Number && PO Item";
            this.checkPONoItem.UseVisualStyleBackColor = true;
            this.checkPONoItem.CheckedChanged += new EventHandler(this.checkRelation_CheckedChanged);
            this.checkCommodity.AutoSize = true;
            this.checkCommodity.Checked = true;
            this.checkCommodity.CheckState = CheckState.Checked;
            this.checkCommodity.Location = new Point(0x85, 0x21);
            this.checkCommodity.Margin = new Padding(4);
            this.checkCommodity.Name = "checkCommodity";
            this.checkCommodity.Size = new Size(0x63, 0x15);
            this.checkCommodity.TabIndex = 11;
            this.checkCommodity.Text = "Commodity";
            this.checkCommodity.UseVisualStyleBackColor = true;
            this.checkCommodity.CheckedChanged += new EventHandler(this.checkRelation_CheckedChanged);
            this.checkRelation.AutoSize = true;
            this.checkRelation.Checked = true;
            this.checkRelation.CheckState = CheckState.Checked;
            this.checkRelation.Location = new Point(0x85, 6);
            this.checkRelation.Margin = new Padding(4);
            this.checkRelation.Name = "checkRelation";
            this.checkRelation.Size = new Size(0x52, 0x15);
            this.checkRelation.TabIndex = 5;
            this.checkRelation.Text = "Relation";
            this.checkRelation.UseVisualStyleBackColor = true;
            this.checkRelation.CheckedChanged += new EventHandler(this.checkRelation_CheckedChanged);
            this.checkRef.AutoSize = true;
            this.checkRef.Checked = true;
            this.checkRef.CheckState = CheckState.Checked;
            this.checkRef.Location = new Point(8, 6);
            this.checkRef.Margin = new Padding(4);
            this.checkRef.Name = "checkRef";
            this.checkRef.Size = new Size(0x34, 0x15);
            this.checkRef.TabIndex = 1;
            this.checkRef.Text = "Ref";
            this.checkRef.UseVisualStyleBackColor = true;
            this.checkRef.CheckedChanged += new EventHandler(this.checkRelation_CheckedChanged);
            this.labelDisplayColumns.AutoSize = true;
            this.labelDisplayColumns.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelDisplayColumns.Location = new Point(0x13, 0xd9);
            this.labelDisplayColumns.Margin = new Padding(4, 0, 4, 0);
            this.labelDisplayColumns.Name = "labelDisplayColumns";
            this.labelDisplayColumns.Size = new Size(0x89, 0x11);
            this.labelDisplayColumns.TabIndex = 0x4f;
            this.labelDisplayColumns.Text = "Display Columns :";
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x2db, 0x6c);
            this.button2.Margin = new Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x93, 0x44);
            this.button2.TabIndex = 0x53;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x2db, 0x17);
            this.button1.Margin = new Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x93, 0x45);
            this.button1.TabIndex = 0x52;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.cBoxAll.AutoSize = true;
            this.cBoxAll.Checked = true;
            this.cBoxAll.CheckState = CheckState.Checked;
            this.cBoxAll.Location = new Point(0xa2, 0xd8);
            this.cBoxAll.Margin = new Padding(4);
            this.cBoxAll.Name = "cBoxAll";
            this.cBoxAll.Size = new Size(0x53, 0x15);
            this.cBoxAll.TabIndex = 0x71;
            this.cBoxAll.Text = "Show All";
            this.cBoxAll.UseVisualStyleBackColor = true;
            this.cBoxAll.CheckedChanged += new EventHandler(this.cBoxAll_CheckedChanged);
            this.buttonDoNo.Location = new Point(0x19d, 0x90);
            this.buttonDoNo.Margin = new Padding(0);
            this.buttonDoNo.Name = "buttonDoNo";
            this.buttonDoNo.Size = new Size(0x1f, 0x1c);
            this.buttonDoNo.TabIndex = 0x7b;
            this.buttonDoNo.Text = "...";
            this.buttonDoNo.UseVisualStyleBackColor = true;
            this.buttonDoNo.Click += new EventHandler(this.buttonDoNo_Click);
            this.labelDoNo.AutoSize = true;
            this.labelDoNo.Location = new Point(0x29, 0x95);
            this.labelDoNo.Margin = new Padding(4, 0, 4, 0);
            this.labelDoNo.Name = "labelDoNo";
            this.labelDoNo.Size = new Size(0x3f, 0x11);
            this.labelDoNo.TabIndex = 0x7e;
            this.labelDoNo.Text = "DO No. :";
            this.textDoNo.CharacterCasing = CharacterCasing.Upper;
            this.textDoNo.Location = new Point(0x99, 0x93);
            this.textDoNo.Margin = new Padding(4);
            this.textDoNo.Name = "textDoNo";
            this.textDoNo.Size = new Size(0xfd, 0x16);
            this.textDoNo.TabIndex = 0x79;
            this.groupBox2.Controls.Add(this.checkBox_calculateOSbyBCNo);
            this.groupBox2.Controls.Add(this.checkBox_calculateOSbyWBDO);
            this.groupBox2.Location = new Point(0x13, 0x11);
            this.groupBox2.Margin = new Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new Padding(4);
            this.groupBox2.Size = new Size(0x277, 0x37);
            this.groupBox2.TabIndex = 0x8d;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Calculate OS by:";
            this.checkBox_calculateOSbyBCNo.AutoSize = true;
            this.checkBox_calculateOSbyBCNo.Location = new Point(0xcf, 0x17);
            this.checkBox_calculateOSbyBCNo.Margin = new Padding(4);
            this.checkBox_calculateOSbyBCNo.Name = "checkBox_calculateOSbyBCNo";
            this.checkBox_calculateOSbyBCNo.Size = new Size(0x45, 0x15);
            this.checkBox_calculateOSbyBCNo.TabIndex = 0x11;
            this.checkBox_calculateOSbyBCNo.Text = "BC No";
            this.checkBox_calculateOSbyBCNo.UseVisualStyleBackColor = true;
            this.checkBox_calculateOSbyWBDO.AutoSize = true;
            this.checkBox_calculateOSbyWBDO.Checked = true;
            this.checkBox_calculateOSbyWBDO.Location = new Point(0x15, 0x17);
            this.checkBox_calculateOSbyWBDO.Margin = new Padding(4);
            this.checkBox_calculateOSbyWBDO.Name = "checkBox_calculateOSbyWBDO";
            this.checkBox_calculateOSbyWBDO.Size = new Size(0x4c, 0x15);
            this.checkBox_calculateOSbyWBDO.TabIndex = 0x10;
            this.checkBox_calculateOSbyWBDO.TabStop = true;
            this.checkBox_calculateOSbyWBDO.Text = "WB DO";
            this.checkBox_calculateOSbyWBDO.UseVisualStyleBackColor = true;
            this.checkBox_FilterByDate.AutoSize = true;
            this.checkBox_FilterByDate.Location = new Point(0x15, 0x53);
            this.checkBox_FilterByDate.Margin = new Padding(4);
            this.checkBox_FilterByDate.Name = "checkBox_FilterByDate";
            this.checkBox_FilterByDate.Size = new Size(0x72, 0x15);
            this.checkBox_FilterByDate.TabIndex = 0x8e;
            this.checkBox_FilterByDate.Text = "Filter by Date";
            this.checkBox_FilterByDate.UseVisualStyleBackColor = true;
            this.checkBox_FilterByDate.CheckedChanged += new EventHandler(this.checkBox_FilterByDate_CheckedChanged);
            this.lblDateTo.AutoSize = true;
            this.lblDateTo.Location = new Point(0x151, 0x73);
            this.lblDateTo.Margin = new Padding(4, 0, 4, 0);
            this.lblDateTo.Name = "lblDateTo";
            this.lblDateTo.Size = new Size(0x43, 0x11);
            this.lblDateTo.TabIndex = 0x59;
            this.lblDateTo.Text = "Date To :";
            this.dtp_ToDate.Enabled = false;
            this.dtp_ToDate.Format = DateTimePickerFormat.Short;
            this.dtp_ToDate.Location = new Point(0x1a0, 0x71);
            this.dtp_ToDate.Margin = new Padding(4);
            this.dtp_ToDate.Name = "dtp_ToDate";
            this.dtp_ToDate.Size = new Size(0x8b, 0x16);
            this.dtp_ToDate.TabIndex = 0x47;
            this.dtp_FromDate.Enabled = false;
            this.dtp_FromDate.Format = DateTimePickerFormat.Short;
            this.dtp_FromDate.Location = new Point(0x99, 0x71);
            this.dtp_FromDate.Margin = new Padding(4);
            this.dtp_FromDate.Name = "dtp_FromDate";
            this.dtp_FromDate.Size = new Size(0x8b, 0x16);
            this.dtp_FromDate.TabIndex = 0;
            this.labelDateFrom.AutoSize = true;
            this.labelDateFrom.Location = new Point(0x29, 0x73);
            this.labelDateFrom.Margin = new Padding(4, 0, 4, 0);
            this.labelDateFrom.Name = "labelDateFrom";
            this.labelDateFrom.Size = new Size(0x52, 0x11);
            this.labelDateFrom.TabIndex = 3;
            this.labelDateFrom.Text = "Date From :";
            this.labelDateFrom.TextAlign = ContentAlignment.MiddleRight;
            this.labelMaxRow.AutoSize = true;
            this.labelMaxRow.Location = new Point(0x29, 0xb8);
            this.labelMaxRow.Margin = new Padding(4, 0, 4, 0);
            this.labelMaxRow.Name = "labelMaxRow";
            this.labelMaxRow.Size = new Size(0x48, 0x11);
            this.labelMaxRow.TabIndex = 0x90;
            this.labelMaxRow.Text = "Max Row :";
            this.textMaxRow.Location = new Point(0x99, 0xb6);
            int[] bits = new int[4];
            bits[0] = 500;
            this.textMaxRow.Maximum = new decimal(bits);
            int[] numArray2 = new int[4];
            numArray2[0] = 1;
            this.textMaxRow.Minimum = new decimal(numArray2);
            this.textMaxRow.Name = "textMaxRow";
            this.textMaxRow.Size = new Size(0x3b, 0x16);
            this.textMaxRow.TabIndex = 0x91;
            int[] numArray3 = new int[4];
            numArray3[0] = 50;
            this.textMaxRow.Value = new decimal(numArray3);
            base.AutoScaleDimensions = new SizeF(8f, 16f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x382, 0x144);
            base.ControlBox = false;
            base.Controls.Add(this.textMaxRow);
            base.Controls.Add(this.labelMaxRow);
            base.Controls.Add(this.lblDateTo);
            base.Controls.Add(this.dtp_ToDate);
            base.Controls.Add(this.checkBox_FilterByDate);
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.buttonDoNo);
            base.Controls.Add(this.labelDoNo);
            base.Controls.Add(this.textDoNo);
            base.Controls.Add(this.cBoxAll);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.dtp_FromDate);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.labelDateFrom);
            base.Controls.Add(this.labelDisplayColumns);
            base.Controls.Add(this.panel1);
            base.Margin = new Padding(4);
            base.Name = "RepOSDONonTrade";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Goods Report Weighbridge System";
            base.Load += new EventHandler(this.RepDODetail_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepOSDONonTrade_KeyPress);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.textMaxRow.EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void initTable()
        {
            this.tbl_Do = new WBTable();
            this.tbl_Do.OpenTable("wb_contract", "Select * from wb_contract", WBData.conn);
            Program.AutoComp(this.tbl_Do, "Do_No", this.textDoNo);
        }

        private void RepDODetail_Load(object sender, EventArgs e)
        {
            this.translate();
            this.initTable();
            this.reportName();
        }

        private void reportName()
        {
            this.rptName = !this.checkBox_FilterByDate.Checked ? "Summary Report" : "Daily Report";
        }

        private void RepOSDONonTrade_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void subTotalBC(HTML rep, string BC)
        {
            rep.Write("<tr class='bd'>");
            object[] objArray1 = new object[] { "<td rowspan='1' colspan='", this.jlhKolomA, "' nowrap align=center><b>Subtotal BC ", BC, "</b></td>" };
            rep.Write(string.Concat(objArray1));
            rep.Write("<td rowspan='1' colspan='1' nowrap align=right><b>" + this.Weightedin + "</b></td>");
            rep.Write("<td rowspan='1' colspan='1' nowrap align=right><b>" + this.SumLoadQty.ToString() + "</b></td>");
            rep.Write("<td rowspan='1' colspan='1' nowrap align=right><b>" + this.utoday.ToString() + "</b></td>");
            rep.Write("<td rowspan='1' colspan='1' nowrap align=right><b>" + this.WBDOOSLeft.ToString() + "</b></td>");
            rep.Write("</tr>");
        }

        private void subTotalDO(HTML rep, string DoNo)
        {
            rep.Write("<tr class='bd'>");
            object[] objArray1 = new object[] { "<td rowspan='1' colspan='", this.jlhKolomA, "' nowrap align=center><b>Subtotal WB DO ", DoNo, "</b></td>" };
            rep.Write(string.Concat(objArray1));
            rep.Write("<td rowspan='1' colspan='1' nowrap align=right><b>" + this.Weightedin + "</b></td>");
            rep.Write("<td rowspan='1' colspan='1' nowrap align=right><b>" + this.SumLoadQty.ToString() + "</b></td>");
            rep.Write("<td rowspan='1' colspan='1' nowrap align=right><b>" + this.utoday.ToString() + "</b></td>");
            rep.Write("<td rowspan='1' colspan='1' nowrap align=right><b>" + this.WBDOOSLeft.ToString() + "</b></td>");
            rep.Write("</tr>");
        }

        private void translate()
        {
            this.Text = Resource.Report11_001;
            this.groupBox2.Text = Resource.Report11_002 + ":";
            this.checkBox_calculateOSbyWBDO.Text = Resource.Report11_003;
            this.checkBox_calculateOSbyBCNo.Text = Resource.Report11_004;
            this.checkBox_FilterByDate.Text = Resource.Report11_005;
            this.labelDateFrom.Text = Resource.Report11_006 + " : ";
            this.labelDateFrom.Text = Resource.Report11_007 + " : ";
            this.labelDoNo.Text = Resource.Report11_008 + " : ";
            this.labelMaxRow.Text = Resource.Report11_009 + " : ";
            this.button1.Text = Resource.Rep01_042;
            this.button2.Text = Resource.Menu_Close;
            this.labelDisplayColumns.Text = Resource.Report11_010;
            this.cBoxAll.Text = Resource.Report11_011;
            this.checkRef.Text = Resource.Report11_012;
            this.checkReportDate.Text = Resource.Report11_013;
            this.checkRelation.Text = Resource.Report11_014;
            this.checkCommodity.Text = Resource.Report11_015;
            this.checkPONoItem.Text = Resource.Report11_016;
        }
    }
}

