﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Data.SqlClient;
    using System.Drawing;
    using System.Windows.Forms;

    public class NewCoy : Form
    {
        private string str_conn;
        private SqlConnection conn;
        private IContainer components = null;
        private Label label1;
        private TextBox textBox1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textBox2;
        private Label label5;
        private TextBox textBox3;
        private Button button1;
        private Button button2;
        private Button button3;
        private Label labelProgress;
        private ComboBox comboBox1;

        public NewCoy()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table;
            WBTable table2;
            SqlDataReader reader;
            bool flag;
            bool flag2;
            if (MessageBox.Show(" Create/Copy to new company, process ? ", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.No)
            {
                if ((this.textBox1.Text.Trim() != WBData.sCoyCode) || (this.textBox2.Text != WBData.sLocCode))
                {
                    table = new WBTable();
                    table2 = new WBTable();
                    string[] textArray1 = new string[9];
                    textArray1[0] = "server=";
                    textArray1[1] = WBData.sServer;
                    textArray1[2] = "; database=";
                    textArray1[3] = WBData.sDatabase;
                    textArray1[4] = "; uid=";
                    textArray1[5] = WBData.sUserID;
                    textArray1[6] = "; password=";
                    textArray1[7] = WBData.sPassword;
                    textArray1[8] = ";";
                    this.str_conn = string.Concat(textArray1);
                    this.conn = new SqlConnection(this.str_conn);
                    SqlCommand command = this.conn.CreateCommand();
                    command.CommandText = "SELECT table_name AS Name FROM INFORMATION_SCHEMA.Tables WHERE TABLE_TYPE = 'BASE TABLE' Order By table_name";
                    this.conn.Open();
                    reader = command.ExecuteReader();
                    flag = false;
                    flag2 = false;
                }
                else
                {
                    MessageBox.Show("Company Code & Location Code not allowed..!");
                    return;
                }
            }
            else
            {
                return;
            }
            while (true)
            {
                if (!reader.Read())
                {
                    break;
                }
                string tablename = (string) reader[0];
                this.labelProgress.Text = tablename;
                this.labelProgress.Refresh();
                if (tablename.Substring(0, 3) == "wb_")
                {
                    if (((tablename.Trim() != "wb_transaction") && ((tablename.Trim() != "wb_transactionD") && ((tablename.Trim() != "wb_transContainer") && ((tablename.Trim() != "wb_transDivision") && ((tablename.Trim() != "wb_TransQC") && ((tablename.Trim() != "wb_trans_log") && ((tablename.Trim() != "wb_tanker_log") && ((tablename.Trim() != "wb_transDO") && ((tablename.Trim() != "wb_rlock") && ((tablename.Trim() != "wb_report") && ((tablename.Trim() != "wb_contract") && ((tablename.Trim() != "wb_ref") && ((tablename.Trim() != "wb_log") && ((tablename.Trim() != "wb_language") && ((tablename.Trim() != "wb_English") && ((tablename.Trim() != "wb_delivery_note") && ((tablename.Trim() != "wb_log") && ((tablename.Trim() != "wb_commd_temp") && ((tablename.Trim() != "wb_menu") && ((tablename.Trim() != "wb_barrier") && ((tablename.Trim() != "wb_report_daily") && (tablename.Trim() != "wb_contTEMP")))))))))))))))))))))) && (tablename.Trim() != "wb_transDO_Container"))
                    {
                        if (tablename.Trim() == "wb_company")
                        {
                            table.OpenTable(tablename, "Select * From " + tablename, WBData.conn);
                            table2.OpenTable(tablename, "Select * From " + tablename + " where 1=2", WBData.conn);
                        }
                        else
                        {
                            table.OpenTable(tablename, "Select * From " + tablename + " where " + WBData.CompanyLocation(""), WBData.conn);
                            table2.OpenTable(tablename, "Select * From " + tablename + " where 1=2", WBData.conn);
                        }
                        flag = false;
                        flag2 = false;
                        int num = 1;
                        foreach (DataRow row in table.DT.Rows)
                        {
                            string[] textArray2 = new string[] { tablename, ", rec : ", num.ToString(), "/", table.DT.Rows.Count.ToString() };
                            this.labelProgress.Text = string.Concat(textArray2);
                            this.labelProgress.Refresh();
                            num++;
                            foreach (DataColumn column in table.DT.Columns)
                            {
                                if (column.ColumnName.Trim().ToUpper() == "LOCATION_CODE")
                                {
                                    flag2 = true;
                                }
                            }
                            if (tablename == "wb_company")
                            {
                                row["Coy_Code"] = this.textBox1.Text.Trim();
                                row["Coy_Location_Code"] = this.textBox2.Text.Trim();
                                row["Coy_Name"] = this.textBox3.Text;
                            }
                            else if (flag2)
                            {
                                row["Coy"] = this.textBox1.Text.Trim();
                                row["Location_Code"] = this.textBox2.Text.Trim();
                            }
                            if (tablename == "wb_setting")
                            {
                                row["Coy_Name"] = this.textBox3.Text;
                            }
                            table2.DR = table2.DT.NewRow();
                            foreach (DataColumn column2 in table.DT.Columns)
                            {
                                table2.DR[column2.ColumnName] = row[column2.ColumnName];
                                if (column2.ColumnName.Trim().ToUpper() == "CHECKSUM")
                                {
                                    flag = true;
                                }
                            }
                            if (flag)
                            {
                                table2.DR["checksum"] = table2.Checksum(table2.DR);
                            }
                            table2.DT.Rows.Add(table2.DR);
                            table2.Save();
                        }
                    }
                    this.labelProgress.Text = "Finished";
                    table2.Close();
                    table.Close();
                    continue;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] textArray1 = new string[] { " Delete Coy:", this.textBox1.Text, " Loc:", this.textBox2.Text, ", process ? " };
            if (MessageBox.Show(string.Concat(textArray1), "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.No)
            {
                if ((this.textBox1.Text.Trim() == WBData.sCoyCode) && (this.textBox2.Text == WBData.sLocCode))
                {
                    MessageBox.Show("Company Code & Location Code not allowed..!");
                }
                else
                {
                    WBTable table = new WBTable();
                    WBTable table2 = new WBTable();
                    string[] textArray2 = new string[9];
                    textArray2[0] = "server=";
                    textArray2[1] = WBData.sServer;
                    textArray2[2] = "; database=";
                    textArray2[3] = WBData.sDatabase;
                    textArray2[4] = "; uid=";
                    textArray2[5] = WBData.sUserID;
                    textArray2[6] = "; password=";
                    textArray2[7] = WBData.sPassword;
                    textArray2[8] = ";";
                    this.str_conn = string.Concat(textArray2);
                    this.conn = new SqlConnection(this.str_conn);
                    SqlCommand command = this.conn.CreateCommand();
                    command.CommandText = "SELECT table_name AS Name FROM INFORMATION_SCHEMA.Tables WHERE TABLE_TYPE = 'BASE TABLE' Order By table_name";
                    this.conn.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (true)
                    {
                        if (!reader.Read())
                        {
                            this.labelProgress.Text = "Finished";
                            break;
                        }
                        string tablename = (string) reader[0];
                        this.labelProgress.Text = tablename;
                        this.labelProgress.Refresh();
                        bool flag3 = tablename.Substring(0, 3) == "wb_";
                        if (flag3 && (((tablename.Trim() != "wb_tanker_log") && ((tablename.Trim() != "wb_rlock") && ((tablename.Trim() != "wb_report") && ((tablename.Trim() != "wb_ref") && ((tablename.Trim() != "wb_log") && ((tablename.Trim() != "wb_language") && ((tablename.Trim() != "wb_English") && ((tablename.Trim() != "wb_delivery_note") && ((tablename.Trim() != "wb_log") && ((tablename.Trim() != "wb_commd_temp") && ((tablename.Trim() != "wb_menu") && (tablename.Trim() != "wb_barrier")))))))))))) && (tablename.Trim() != "wb_report_daily")))
                        {
                            this.labelProgress.Text = "Delete on Table : " + tablename;
                            if (tablename.Trim() == "wb_company")
                            {
                                string[] textArray3 = new string[] { "Delete From ", tablename, " where Coy_Code='", this.textBox1.Text.Trim(), "' and Coy_Location_Code='", this.textBox2.Text.Trim(), "'" };
                                table.OpenTable(tablename, string.Concat(textArray3), WBData.conn);
                                continue;
                            }
                            string[] textArray4 = new string[] { "Delete  From ", tablename, " where  Coy='", this.textBox1.Text.Trim(), "' and Location_Code='", this.textBox2.Text.Trim(), "'" };
                            table.OpenTable(tablename, string.Concat(textArray4), WBData.conn);
                        }
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.textBox1 = new TextBox();
            this.label2 = new Label();
            this.label3 = new Label();
            this.label4 = new Label();
            this.textBox2 = new TextBox();
            this.label5 = new Label();
            this.textBox3 = new TextBox();
            this.button1 = new Button();
            this.button2 = new Button();
            this.button3 = new Button();
            this.labelProgress = new Label();
            this.comboBox1 = new ComboBox();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Location = new Point(30, 0x16);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0xd7, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Create New Company & Location, copy from :";
            this.textBox1.Location = new Point(0x75, 80);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(80, 20);
            this.textBox1.TabIndex = 1;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(30, 0x39);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x31, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Copy to :";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x56, 0x53);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x19, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Coy";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0xce, 0x53);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x30, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Location";
            this.textBox2.Location = new Point(260, 80);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(80, 20);
            this.textBox2.TabIndex = 4;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x37, 0x6d);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x38, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Coy Name";
            this.textBox3.Location = new Point(0x75, 0x6a);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Size(0x13f, 20);
            this.textBox3.TabIndex = 6;
            this.button1.Location = new Point(0x66, 0xc4);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 8;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0xc0, 0xc4);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 9;
            this.button2.Text = "Delete";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button3.Location = new Point(0x169, 0xc4);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x4b, 0x17);
            this.button3.TabIndex = 10;
            this.button3.Text = "Close";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.labelProgress.AutoSize = true;
            this.labelProgress.Location = new Point(0x2b, 0x97);
            this.labelProgress.Name = "labelProgress";
            this.labelProgress.Size = new Size(0x3f, 13);
            this.labelProgress.TabIndex = 11;
            this.labelProgress.Text = "Progress.....";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new Point(12, 0xa7);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new Size(0xfb, 0x15);
            this.comboBox1.TabIndex = 12;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(470, 0xe9);
            base.Controls.Add(this.comboBox1);
            base.Controls.Add(this.labelProgress);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.textBox3);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label1);
            base.Name = "NewCoy";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "formset";
            base.Load += new EventHandler(this.NewCoy_Load);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void NewCoy_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.labelProgress.Text = "";
            this.label1.Text = "Create New Company && Location, copy from : " + WBData.sCoyCode + " - " + WBData.sLocCode;
            this.comboBox1.Visible = false;
        }
    }
}

