﻿namespace WindowsFormsApplication1
{
    using AxMSWinsockLib;
    using BarrierGate.Utility;
    using Camera.Utility;
    using Encryption.Utility;
    using Microsoft.VisualBasic;
    using NetworkShare.Utility;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Diagnostics;
    using System.Drawing;
    using System.IO;
    using System.IO.Ports;
    using System.Linq;
    using System.Threading;
    using System.Windows.Forms;

    public class FormSettingHardware : Form
    {
        public WBTable tSetting = new WBTable();
        public WBTable tLocation = new WBTable();
        public WBTable tCompany = new WBTable();
        public WBTable t_camera = new WBTable();
        public WBTable tbl_warning_trace;
        private WBCamera cam = new WBCamera();
        private WBTable tblTrans = new WBTable();
        private WBIndicator wbIndicator = new WBIndicator();
        public SerialPort serialPort1 = new SerialPort();
        public bool saved = false;
        public int nRowSetting = -1;
        public int nRowLocation = -1;
        public string result = "";
        public string logKey = "";
        public string pMode = "";
        private char bGate = 'F';
        private string _combo_cam1_web;
        private string _combo_cam1_ip;
        private string _combo_cam2_web;
        private string _combo_cam2_ip;
        private string _combo_cam3_web;
        private string _combo_cam3_ip;
        private string _combo_cam4_web;
        private string _combo_cam4_ip;
        private string _combo_cam5_web;
        private string _combo_cam5_ip;
        private IContainer components = null;
        private TabControl tabGate;
        private TabPage tabPage2;
        private Button button2;
        private Button button3;
        private Button button1;
        private Label label6;
        private TextBox textBuffers;
        private ComboBox comboBox5;
        private ComboBox comboBox4;
        private ComboBox comboBox3;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private Label label7;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label11;
        private Button button4;
        private Label label13;
        private Label label12;
        private TextBox textBox4;
        private Label label16;
        private Label label15;
        private TextBox textLength;
        private Label label14;
        private TextBox textStart;
        private Panel panel10;
        private Label label77;
        private Panel panel11;
        private RadioButton radioWBType2;
        private RadioButton radioWBType1;
        private Label labelErr;
        private TabPage tabBarrierGate;
        private GroupBox groupBox1;
        private RadioButton rboNo;
        private RadioButton rboYes;
        private OpenFileDialog openFileDialog1;
        private Label label30;
        private TextBox textBeforeKG;
        private Button buttonAuto;
        private SerialPort serialPort2;
        private RadioButton radioWBType3;
        private RichTextBox richTextBox1;
        private Label label123;
        private RadioButton radioWBType5;
        private RadioButton radioWBType4;
        private Label labelType5Status;
        private ListBox listBoxBuffer;
        private ListBox listBoxTmpRead;
        private ToolTip toolTip1;
        private TabPage tab_camera;
        private GroupBox gb_cam1;
        private Button btn_tes_cam1;
        private ComboBox combo_cam1_ip;
        private ComboBox combo_cam1_web;
        private RadioButton rb_cam1_ip;
        private RadioButton rb_cam1_web;
        private Label label98;
        private CheckBox cb_cam1;
        private GroupBox gb_enable_camera;
        private RadioButton rb_camera_off;
        private RadioButton rb_camera_on;
        private PageSetupDialog pageSetupDialog1;
        private GroupBox gb_cam2;
        private Button btn_tes_cam2;
        private ComboBox combo_cam2_ip;
        private ComboBox combo_cam2_web;
        private RadioButton rb_cam2_ip;
        private RadioButton rb_cam2_web;
        private Label label119;
        private CheckBox cb_cam2;
        private Label label120;
        private TabPage tabPage9;
        private AxWinsock axWinsock1;
        private GroupBox gBoxValvePLC;
        private Label lblCloseValve;
        private Label lblOpenValve;
        private Label lblReadLine;
        private Button btnCloseValve;
        private Button btnOpenValve;
        private Button btnReadLineValve;
        private TextBox txtPLC_Length;
        private Label lblLength;
        private TextBox txtStart;
        private Label lblStart;
        private TextBox txtregfb;
        private Label label121;
        private TextBox txtregLine;
        private Label Regline;
        private Label lblPort;
        private TextBox txtIP;
        private TextBox txtPort;
        private Label lblIP;
        private Button btnConnectPLC;
        private ComboBox comboBarrier;
        private TextBox textBarrierPort1;
        private TextBox textBarrierIP1;
        private Label labelPort1;
        private Label labelIP1;
        private TextBox textBarrierPort2;
        private TextBox textBarrierIP2;
        private Label label2;
        private Label label3;
        private TabControl tabControl1;
        private TabPage tabBarrierBat;
        private TabPage tabBarrierIP;
        private TextBox textBarrierPort4;
        private TextBox textBarrierIP4;
        private Label labelPort4;
        private Label labelIP4;
        private TextBox textBarrierPort3;
        private TextBox textBarrierIP3;
        private Label labelPort3;
        private Label labelIP3;
        private Button buttonOpenGateIP4;
        private Button buttonOpenGateIP3;
        private Button buttonOpenGateIP2;
        private Button buttonOpenGateIP1;
        private Panel panelBarrierBat;
        private Label label116;
        private Label label115;
        private Button tes2Out;
        private Label label93;
        private Label label94;
        private Button tes1Out;
        private Label label114;
        private Button button6;
        private TextBox textGate1Open;
        private Label label28;
        private Label label113;
        private Button btnTes;
        private TextBox textGate2Open;
        private Label label110;
        private TextBox textGate1OpenOut;
        private Label label88;
        private TextBox textGate1Close;
        private Label label111;
        private TextBox textGate2OpenOut;
        private Label label87;
        private TextBox textGate2Close;
        private Label label112;
        private TextBox textGate1CloseOut;
        private Label label99;
        private Button buttonGate1OpenFind;
        private TextBox textGate2CloseOut;
        private Label label100;
        private Button buttonGate1CloseFind;
        private Button buttonGate1OpenOutFind;
        private Button buttonGate2CloseFind;
        private Button buttonGate2OpenFind;
        private Button buttonGate1CloseOutFind;
        private Button buttonGate2OpenOutFind;
        private Button buttonGate2CloseOutFind;
        private Button buttonCloseGateIP4;
        private Button buttonCloseGateIP3;
        private Button buttonCloseGateIP2;
        private Button buttonCloseGateIP1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private Panel panelBarrierIP;
        private GroupBox groupBox4;
        private Label label19;
        private Label label23;
        private Label label26;
        private GroupBox groupBox5;
        private Label label27;
        private Label label34;
        private Label label35;
        private Button button5;
        private Button button7;
        private Button button9;
        private Button button8;
        private Label labelDestFolder;
        private TextBox textPathPhotos;
        private GroupBox gb_cam5;
        private Button btn_tes_cam5;
        private ComboBox combo_cam5_ip;
        private ComboBox combo_cam5_web;
        private RadioButton rb_cam5_ip;
        private RadioButton rb_cam5_web;
        private Label label17;
        private CheckBox cb_cam5;
        private GroupBox gb_cam4;
        private Button btn_tes_cam4;
        private ComboBox combo_cam4_ip;
        private ComboBox combo_cam4_web;
        private RadioButton rb_cam4_ip;
        private RadioButton rb_cam4_web;
        private Label label5;
        private CheckBox cb_cam4;
        private GroupBox gb_cam3;
        private Button btn_tes_cam3;
        private ComboBox combo_cam3_ip;
        private ComboBox combo_cam3_web;
        private RadioButton rb_cam3_ip;
        private RadioButton rb_cam3_web;
        private Label label4;
        private CheckBox cb_cam3;
        private Panel panel5;
        private Panel panel4;
        private Panel panel3;
        private Panel panel2;
        private Panel panel1;
        private TextBox textDomainFolder;
        private Label labelDomainUsername;
        private Label labelPassword;
        private GroupBox groupBox6;
        private Label label1;
        private TextBox textUsernameFolder;
        private Button button10;
        private TextBox textPasswordFolder;
        private TabPage tabPageGlobalSettings;
        private GroupBox groupBox_GlobalSetting_Camera;
        private CheckBox chkCheckDriverLicenseIDPhoto;
        private TextBox textPathPhotosServer;
        private Label label18;
        private Button button11;
        private TextBox textBackupPathPhotos;
        private Label lblBackupCameraPath;
        private Button btnBrowseBackupPathPhotos;
        private FolderBrowserDialog folderBrowserDialog1;

        public FormSettingHardware()
        {
            this.InitializeComponent();
        }

        private void btn_tes_cam1_Click(object sender, EventArgs e)
        {
            FormCameraPreview preview = new FormCameraPreview();
            if (!this.rb_cam1_ip.Checked)
            {
                preview.camera_type = "WEB_CAMERA";
                preview.webcam_name = this.combo_cam1_web.Text.Trim();
            }
            else
            {
                preview.camera_type = "IP_CAMERA";
                string[] aField = new string[] { "camera_code" };
                string[] aFind = new string[] { this.combo_cam1_ip.Text.Trim() };
                DataRow data = this.t_camera.GetData(aField, aFind);
                if (data != null)
                {
                    preview.username = data["username"].ToString().Trim();
                    preview.password = WBEncryption.Decrypt(data["password"].ToString().Trim());
                    preview.ip_address = data["ip_address"].ToString().Trim();
                    preview.web_url = data["web_url"].ToString().Trim();
                }
            }
            preview.ShowDialog();
            preview.Dispose();
        }

        private void btn_tes_cam2_Click(object sender, EventArgs e)
        {
            FormCameraPreview preview = new FormCameraPreview();
            if (!this.rb_cam2_ip.Checked)
            {
                preview.camera_type = "WEB_CAMERA";
                preview.webcam_name = this.combo_cam2_web.Text.Trim();
            }
            else
            {
                preview.camera_type = "IP_CAMERA";
                string[] aField = new string[] { "camera_code" };
                string[] aFind = new string[] { this.combo_cam2_ip.Text.Trim() };
                DataRow data = this.t_camera.GetData(aField, aFind);
                if (data != null)
                {
                    preview.username = data["username"].ToString().Trim();
                    preview.password = WBEncryption.Decrypt(data["password"].ToString().Trim());
                    preview.ip_address = data["ip_address"].ToString().Trim();
                    preview.web_url = data["web_url"].ToString().Trim();
                }
            }
            preview.ShowDialog();
            preview.Dispose();
        }

        private void btn_tes_cam3_Click(object sender, EventArgs e)
        {
            FormCameraPreview preview = new FormCameraPreview();
            if (!this.rb_cam3_ip.Checked)
            {
                preview.camera_type = "WEB_CAMERA";
                preview.webcam_name = this.combo_cam3_web.Text.Trim();
            }
            else
            {
                preview.camera_type = "IP_CAMERA";
                string[] aField = new string[] { "camera_code" };
                string[] aFind = new string[] { this.combo_cam3_ip.Text.Trim() };
                DataRow data = this.t_camera.GetData(aField, aFind);
                if (data != null)
                {
                    preview.username = data["username"].ToString().Trim();
                    preview.password = WBEncryption.Decrypt(data["password"].ToString().Trim());
                    preview.ip_address = data["ip_address"].ToString().Trim();
                    preview.web_url = data["web_url"].ToString().Trim();
                }
            }
            preview.ShowDialog();
            preview.Dispose();
        }

        private void btn_tes_cam4_Click(object sender, EventArgs e)
        {
            FormCameraPreview preview = new FormCameraPreview();
            if (!this.rb_cam4_ip.Checked)
            {
                preview.camera_type = "WEB_CAMERA";
                preview.webcam_name = this.combo_cam4_web.Text.Trim();
            }
            else
            {
                preview.camera_type = "IP_CAMERA";
                string[] aField = new string[] { "camera_code" };
                string[] aFind = new string[] { this.combo_cam4_ip.Text.Trim() };
                DataRow data = this.t_camera.GetData(aField, aFind);
                if (data != null)
                {
                    preview.username = data["username"].ToString().Trim();
                    preview.password = WBEncryption.Decrypt(data["password"].ToString().Trim());
                    preview.ip_address = data["ip_address"].ToString().Trim();
                    preview.web_url = data["web_url"].ToString().Trim();
                }
            }
            preview.ShowDialog();
            preview.Dispose();
        }

        private void btn_tes_cam5_Click(object sender, EventArgs e)
        {
            FormCameraPreview preview = new FormCameraPreview();
            if (!this.rb_cam5_ip.Checked)
            {
                preview.camera_type = "WEB_CAMERA";
                preview.webcam_name = this.combo_cam5_web.Text.Trim();
            }
            else
            {
                preview.camera_type = "IP_CAMERA";
                string[] aField = new string[] { "camera_code" };
                string[] aFind = new string[] { this.combo_cam5_ip.Text.Trim() };
                DataRow data = this.t_camera.GetData(aField, aFind);
                if (data != null)
                {
                    preview.username = data["username"].ToString().Trim();
                    preview.password = WBEncryption.Decrypt(data["password"].ToString().Trim());
                    preview.ip_address = data["ip_address"].ToString().Trim();
                    preview.web_url = data["web_url"].ToString().Trim();
                }
            }
            preview.ShowDialog();
            preview.Dispose();
        }

        private void btnBrowseBackupPathPhotos_Click(object sender, EventArgs e)
        {
            if (this.folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                this.textBackupPathPhotos.Text = string.IsNullOrEmpty(this.folderBrowserDialog1.SelectedPath) ? "" : this.folderBrowserDialog1.SelectedPath.Trim();
            }
        }

        private void btnChkSum_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_loc", "Select * from wb_location where " + WBData.CompanyLocation(""), WBData.conn);
            table.DR = table.DT.Rows[0];
            table.DR.BeginEdit();
            table.DR["checksum"] = table.Checksum(table.DR);
            table.DR.EndEdit();
            table.Save();
            table.Dispose();
            MessageBox.Show("Repair checksum Succeed...", "FINISH");
        }

        private void btnCloseValve_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("This will close automatic valve \n Make sure there is no truck at filling state. \nAre you sure to continue ? ", "VERY DANGEROUS !!!", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
            }
        }

        private void btnConnect_Click_1(object sender, EventArgs e)
        {
            if ((this.txtIP.Text == "") || (this.txtPort.Text == ""))
            {
                MessageBox.Show("Please fill in IP Address and Port");
            }
            else
            {
                if (this.axWinsock1.CtlState != 7)
                {
                    this.axWinsock1.RemoteHost = this.txtIP.Text;
                    this.axWinsock1.RemotePort = Convert.ToInt16(this.txtPort.Text);
                    this.axWinsock1.Connect();
                    Application.DoEvents();
                }
                if (this.axWinsock1.CtlState == 7)
                {
                    MessageBox.Show("Connect successfully");
                }
                else
                {
                    MessageBox.Show("Can't connect");
                }
            }
        }

        private void btnOpenValve_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("This will open automatic valve \n Make sure valve manual is CLOSE. \nAre you sure to continue ? ", "VERY DANGEROUS !!!", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
            }
        }

        private void btnReadLineValve_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.serialPort1.IsOpen)
            {
                this.serialPort1.Close();
            }
            this.serialPort1.PortName = this.comboBox1.Text;
            try
            {
                this.serialPort1.Open();
                this.comboBox1.Text = this.serialPort1.PortName;
                this.comboBox2.Text = this.serialPort1.BaudRate.ToString();
                this.comboBox3.Text = this.serialPort1.DataBits.ToString();
                this.comboBox4.Text = this.serialPort1.Parity.ToString();
                this.comboBox5.Text = this.serialPort1.StopBits.ToString();
                this.serialPort1.Close();
            }
            catch (Exception exception)
            {
                if (this.serialPort1.IsOpen)
                {
                    this.serialPort1.Close();
                }
                MessageBox.Show(exception.Message);
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.ShowDialog();
            if (this.openFileDialog1.FileName.Trim() != "")
            {
                this.textGate2CloseOut.Text = this.openFileDialog1.FileName;
            }
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            if (this.textPathPhotosServer.Text.Trim() == "")
            {
                MessageBox.Show("Please fill server path for storing photos!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.textPathPhotosServer.Focus();
            }
            else if (this.textPathPhotos.Text.Trim() == "")
            {
                MessageBox.Show("Please fill client path for storing photos!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.textPathPhotos.Focus();
            }
            else if (this.textDomainFolder.Text.Trim() == "")
            {
                MessageBox.Show("Please fill client domain for storing photos!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.textDomainFolder.Focus();
            }
            else if (this.textUsernameFolder.Text.Trim() == "")
            {
                MessageBox.Show("Please fill client username for storing photos!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.textUsernameFolder.Focus();
            }
            else if (this.textPasswordFolder.Text.Trim() == "")
            {
                MessageBox.Show("Please fill client password for storing photos!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.textPasswordFolder.Focus();
            }
            else
            {
                int num;
                if (int.TryParse(this.textPathPhotos.Text.Trim().Substring(0, 1), out num) || ((this.textPathPhotos.Text.Trim().Substring(0, 1) == @"\") && (this.textPathPhotos.Text.Trim().Substring(1, 1) != @"\")))
                {
                    if (this.textPathPhotos.Text.Trim().Substring(0, 1) != @"\")
                    {
                        this.textPathPhotos.Text = @"\\" + this.textPathPhotos.Text.Trim();
                    }
                    else if ((this.textPathPhotos.Text.Trim().Substring(0, 1) == @"\") && (this.textPathPhotos.Text.Trim().Substring(1, 1) != @"\"))
                    {
                        this.textPathPhotos.Text = @"\" + this.textPathPhotos.Text.Trim();
                    }
                }
                if (this.textPathPhotos.Text.Trim().Substring(this.textPathPhotos.Text.Length - 1, 1) != @"\")
                {
                    this.textPathPhotos.Text = this.textPathPhotos.Text.Trim() + @"\";
                }
                char[] separator = new char[] { '\\' };
                string str = WBNetworkShare.Access(this.textPathPhotos.Text.Split(separator)[2], this.textDomainFolder.Text.Trim(), this.textUsernameFolder.Text.Trim(), this.textPasswordFolder.Text.Trim());
                if (str != "")
                {
                    MessageBox.Show("Client path for storing photos is not accessible (" + str + ")", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else if (Directory.Exists(this.textPathPhotos.Text.Trim()))
                {
                    MessageBox.Show("Client path for storing photos exists and accessible!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Client path for storing photos doesn't exist!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (Directory.Exists(this.textPathPhotosServer.Text.Trim()))
            {
                MessageBox.Show("Server path for storing photos exists!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                MessageBox.Show("Server path for storing photos doesn't exists!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.button4.Text = "Test Capture";
            this.serialPort1.Close();
            this.serialPort2.Close();
            if (this.rb_camera_on.Checked)
            {
                if (!this.cb_cam1.Checked || !((!this.rb_cam1_web.Checked || (this.combo_cam1_web.Text.Trim() != "")) ? (this.rb_cam1_ip.Checked && (this.combo_cam1_ip.Text.Trim() == "")) : true))
                {
                    if (!this.cb_cam2.Checked || !((!this.rb_cam2_web.Checked || (this.combo_cam2_web.Text.Trim() != "")) ? (this.rb_cam2_ip.Checked && (this.combo_cam2_ip.Text.Trim() == "")) : true))
                    {
                        if (!this.cb_cam3.Checked || !((!this.rb_cam3_web.Checked || (this.combo_cam3_web.Text.Trim() != "")) ? (this.rb_cam3_ip.Checked && (this.combo_cam3_ip.Text.Trim() == "")) : true))
                        {
                            if (!this.cb_cam4.Checked || !((!this.rb_cam4_web.Checked || (this.combo_cam4_web.Text.Trim() != "")) ? (this.rb_cam4_ip.Checked && (this.combo_cam4_ip.Text.Trim() == "")) : true))
                            {
                                if (this.cb_cam5.Checked && ((!this.rb_cam5_web.Checked || (this.combo_cam5_web.Text.Trim() != "")) ? (this.rb_cam5_ip.Checked && (this.combo_cam5_ip.Text.Trim() == "")) : true))
                                {
                                    MessageBox.Show("Please maintain camera for 'Camera 5'", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    this.tabGate.SelectedTab = this.tab_camera;
                                    this.cb_cam5.Focus();
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please maintain camera for 'Camera 4'", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                this.tabGate.SelectedTab = this.tab_camera;
                                this.cb_cam4.Focus();
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please maintain camera for 'Camera 3'", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            this.tabGate.SelectedTab = this.tab_camera;
                            this.cb_cam3.Focus();
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please maintain camera for 'Camera 2'", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.tabGate.SelectedTab = this.tab_camera;
                        this.cb_cam2.Focus();
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Please maintain camera for 'Camera 1'", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.tabGate.SelectedTab = this.tab_camera;
                    this.cb_cam1.Focus();
                    return;
                }
            }
            if (!(this.rboYes.Checked && (this.comboBarrier.Text == "")))
            {
                if (this.rboYes.Checked && (this.comboBarrier.Text == "Using IP"))
                {
                    if (this.textBarrierIP1.Text != "")
                    {
                        if (this.textBarrierPort1.Text != "")
                        {
                            if (this.textBarrierIP2.Text != "")
                            {
                                if (this.textBarrierPort2.Text != "")
                                {
                                    if (this.textBarrierIP3.Text != "")
                                    {
                                        if (this.textBarrierPort3.Text != "")
                                        {
                                            if (this.textBarrierIP4.Text != "")
                                            {
                                                if (this.textBarrierPort4.Text == "")
                                                {
                                                    MessageBox.Show("Please enter port for gate 2 (truck out)!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                    this.tabGate.SelectedTab = this.tabBarrierGate;
                                                    this.tabControl1.SelectedTab = this.tabBarrierIP;
                                                    this.textBarrierPort4.Focus();
                                                    return;
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("Please enter IP for gate 2 (truck out)!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                this.tabGate.SelectedTab = this.tabBarrierGate;
                                                this.tabControl1.SelectedTab = this.tabBarrierIP;
                                                this.textBarrierIP4.Focus();
                                                return;
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Please enter port for gate 1 (truck out)!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                            this.tabGate.SelectedTab = this.tabBarrierGate;
                                            this.tabControl1.SelectedTab = this.tabBarrierIP;
                                            this.textBarrierPort3.Focus();
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Please enter IP for gate 1 (truck out)!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        this.tabGate.SelectedTab = this.tabBarrierGate;
                                        this.tabControl1.SelectedTab = this.tabBarrierIP;
                                        this.textBarrierIP3.Focus();
                                        return;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Please enter port for gate 2 (truck in)!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    this.tabGate.SelectedTab = this.tabBarrierGate;
                                    this.tabControl1.SelectedTab = this.tabBarrierIP;
                                    this.textBarrierPort2.Focus();
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please enter IP for gate 2 (truck in)!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                this.tabGate.SelectedTab = this.tabBarrierGate;
                                this.tabControl1.SelectedTab = this.tabBarrierIP;
                                this.textBarrierIP2.Focus();
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please enter port for gate 1 (truck in)!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            this.tabGate.SelectedTab = this.tabBarrierGate;
                            this.tabControl1.SelectedTab = this.tabBarrierIP;
                            this.textBarrierPort1.Focus();
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter IP for gate 1 (truck in)!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.tabGate.SelectedTab = this.tabBarrierGate;
                        this.tabControl1.SelectedTab = this.tabBarrierIP;
                        this.textBarrierIP1.Focus();
                        return;
                    }
                }
                this.result = Interaction.InputBox("Change Reasons", "Change Reasons", "", 150, 150);
                if (this.result != "")
                {
                    this.f_save();
                }
                else
                {
                    MessageBox.Show("Please Fill In Reason", "W A R N I N G ! !");
                }
            }
            else
            {
                MessageBox.Show("Please choose barrier gate method", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.comboBarrier.Focus();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.ThisClose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string str = "";
            this.labelErr.Text = "";
            this.labelErr.Refresh();
            if (!this.radioWBType5.Checked)
            {
                MessageBox.Show("Please choose type 5 (VWB) before try to read weight from indicator!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.radioWBType3.Checked || this.radioWBType4.Checked)
            {
                this.richTextBox1.Clear();
                this.serialPort1.Close();
                if (this.button4.Text != "Test Capture")
                {
                    this.button4.Text = "Test Capture";
                    this.serialPort2.Close();
                }
                else
                {
                    this.button4.Text = "Stop";
                    this.serialPort2.Close();
                    this.serialPort2.PortName = this.comboBox1.Text;
                    this.serialPort2.BaudRate = Convert.ToInt32(this.comboBox2.Text);
                    this.serialPort2.DataBits = Convert.ToInt32(this.comboBox3.Text[0].ToString());
                    this.serialPort2.Parity = (this.comboBox4.Text == "None") ? Parity.None : ((this.comboBox4.Text == "Even") ? Parity.Even : Parity.Odd);
                    this.serialPort2.StopBits = (this.comboBox5.Text == "One") ? StopBits.One : StopBits.Two;
                    this.serialPort2.RtsEnable = true;
                    this.serialPort2.DtrEnable = true;
                    try
                    {
                        this.serialPort2.Open();
                    }
                    catch (TimeoutException exception1)
                    {
                        MessageBox.Show(exception1.Message, "Receive Data Error. Read Timeout", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    catch (Exception exception6)
                    {
                        MessageBox.Show(exception6.Message);
                        this.button4.Text = "Test Capture";
                    }
                }
            }
            else if (!(this.radioWBType1.Checked || this.radioWBType2.Checked))
            {
                if (this.radioWBType5.Checked)
                {
                    this.wbIndicator.Init();
                    this.wbIndicator.checkStatus();
                    this.labelType5Status.Text = this.wbIndicator.msgStatus;
                    this.wbIndicator.readValue();
                    this.textBox4.Text = this.wbIndicator.wbValue;
                }
            }
            else
            {
                this.InitPort();
                try
                {
                    if (this.serialPort1.IsOpen)
                    {
                        this.serialPort1.Close();
                    }
                    else
                    {
                        this.serialPort1.Open();
                    }
                    str = this.serialPort1.ReadLine();
                    this.richTextBox1.Text = str + this.richTextBox1.Text;
                    this.richTextBox1.AppendText(this.serialPort1.ReadExisting());
                    this.serialPort1.Close();
                }
                catch (TimeoutException exception7)
                {
                    MessageBox.Show(exception7.Message, "Receive Data Error. Read Timeout", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (Exception exception4)
                {
                    if (this.serialPort1.IsOpen)
                    {
                        this.serialPort1.Close();
                    }
                    MessageBox.Show(exception4.Message);
                }
                if ((this.textStart.Text.Trim() != "0") && (this.textLength.Text.Trim() != "0"))
                {
                    if ((str.Trim().Length < Convert.ToInt32(this.textStart.Text.Trim())) || (str.Trim().Length < ((Convert.ToInt32(this.textStart.Text.Trim()) + Convert.ToInt32(this.textLength.Text.Trim())) - 1)))
                    {
                        this.labelErr.Text = "Wrong setting at 'Starts at' or 'Length', please check  . . . . . . !";
                        this.textBox4.Text = "0";
                    }
                    else
                    {
                        try
                        {
                            this.textBox4.Text = $"{Convert.ToInt32(str.Substring(Convert.ToInt32(this.textStart.Text.Trim()) - 1, Convert.ToInt32(this.textLength.Text.Trim()))):N0}";
                        }
                        catch (Exception)
                        {
                        }
                    }
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if ((this.textBarrierIP3.Text.Trim() != "") && (this.textBarrierPort3.Text.Trim() != ""))
            {
                if (WBBarrierGate2.getStatus(this.textBarrierIP3.Text.Trim(), this.textBarrierPort3.Text.Trim()))
                {
                    MessageBox.Show(WBBarrierGate2.strMsg, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Error get status of gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                MessageBox.Show("Please enter IP and Port!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                if (this.textBarrierIP3.Text.Trim() == "")
                {
                    this.textBarrierIP3.Focus();
                }
                else if (this.textBarrierPort3.Text.Trim() == "")
                {
                    this.textBarrierPort3.Focus();
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.ShowDialog();
            if (this.openFileDialog1.FileName.Trim() != "")
            {
                this.textGate1Open.Text = this.openFileDialog1.FileName;
            }
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            try
            {
                Process.Start(this.textGate1Open.Text);
                Thread.Sleep(0xbb8);
                Process.Start(this.textGate1Close.Text);
            }
            catch (Exception exception1)
            {
                MessageBox.Show(exception1.ToString());
            }
        }

        private void button6_Click_2(object sender, EventArgs e)
        {
            try
            {
                Process.Start(this.textGate2Open.Text);
                Thread.Sleep(0xbb8);
                Process.Start(this.textGate2Close.Text);
            }
            catch (Exception exception1)
            {
                MessageBox.Show(exception1.ToString());
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if ((this.textBarrierIP4.Text.Trim() != "") && (this.textBarrierPort4.Text.Trim() != ""))
            {
                if (WBBarrierGate2.getStatus(this.textBarrierIP4.Text.Trim(), this.textBarrierPort4.Text.Trim()))
                {
                    MessageBox.Show(WBBarrierGate2.strMsg, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Error get status of gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                MessageBox.Show("Please enter IP and Port!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                if (this.textBarrierIP4.Text.Trim() == "")
                {
                    this.textBarrierIP4.Focus();
                }
                else if (this.textBarrierPort4.Text.Trim() == "")
                {
                    this.textBarrierPort4.Focus();
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if ((this.textBarrierIP2.Text.Trim() != "") && (this.textBarrierPort2.Text.Trim() != ""))
            {
                if (WBBarrierGate2.getStatus(this.textBarrierIP2.Text.Trim(), this.textBarrierPort2.Text.Trim()))
                {
                    MessageBox.Show(WBBarrierGate2.strMsg, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Error get status of gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                MessageBox.Show("Please enter IP and Port!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                if (this.textBarrierIP2.Text.Trim() == "")
                {
                    this.textBarrierIP2.Focus();
                }
                else if (this.textBarrierPort2.Text.Trim() == "")
                {
                    this.textBarrierPort2.Focus();
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if ((this.textBarrierIP1.Text.Trim() != "") && (this.textBarrierPort1.Text.Trim() != ""))
            {
                if (WBBarrierGate2.getStatus(this.textBarrierIP1.Text.Trim(), this.textBarrierPort1.Text.Trim()))
                {
                    MessageBox.Show(WBBarrierGate2.strMsg, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Error get status of gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                MessageBox.Show("Please enter IP and Port!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                if (this.textBarrierIP1.Text.Trim() == "")
                {
                    this.textBarrierIP1.Focus();
                }
                else if (this.textBarrierPort1.Text.Trim() == "")
                {
                    this.textBarrierPort1.Focus();
                }
            }
        }

        private void buttonAuto_Click(object sender, EventArgs e)
        {
            string str = "";
            string str2 = "0";
            string str3 = "5";
            string str4 = "0";
            this.InitPort();
            try
            {
                this.serialPort1.Open();
                str = this.serialPort1.ReadLine();
                this.richTextBox1.Text = str + this.richTextBox1.Text;
                this.serialPort1.Close();
                int index = str.IndexOf("KG");
                str4 = "0";
                try
                {
                    if (str.Substring(index - 1, 1) != " ")
                    {
                        double num2 = Program.StrToDouble(str.Substring(index - 1, 1), 0);
                    }
                    else
                    {
                        str4 = "1";
                    }
                }
                catch
                {
                    str4 = "1";
                }
                str2 = (str4 != "0") ? Convert.ToString((int) (index - Convert.ToInt16(str3))) : Convert.ToString((int) ((index + 1) - Convert.ToInt16(str3)));
                this.textStart.Text = str2;
                this.textLength.Text = str3;
                this.textBeforeKG.Text = str4;
            }
            catch (Exception exception)
            {
                if (this.serialPort1.IsOpen)
                {
                    this.serialPort1.Close();
                }
                MessageBox.Show(exception.Message);
            }
        }

        private void buttonCloseGateIP1_Click(object sender, EventArgs e)
        {
            if ((this.textBarrierIP1.Text.Trim() != "") && (this.textBarrierPort1.Text.Trim() != ""))
            {
                if (WBBarrierGate2.closeGate(this.textBarrierIP1.Text.Trim(), this.textBarrierPort1.Text.Trim()))
                {
                    MessageBox.Show("Gate is closed", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Error close gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                MessageBox.Show("Please enter IP and Port before try to close barrier gate!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                if (this.textBarrierIP1.Text.Trim() == "")
                {
                    this.textBarrierIP1.Focus();
                }
                else if (this.textBarrierPort1.Text.Trim() == "")
                {
                    this.textBarrierPort1.Focus();
                }
            }
        }

        private void buttonCloseGateIP2_Click(object sender, EventArgs e)
        {
            if ((this.textBarrierIP2.Text.Trim() != "") && (this.textBarrierPort2.Text.Trim() != ""))
            {
                if (WBBarrierGate2.closeGate(this.textBarrierIP2.Text.Trim(), this.textBarrierPort2.Text.Trim()))
                {
                    MessageBox.Show("Gate is closed", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Error close gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                MessageBox.Show("Please enter IP and Port before try to close barrier gate!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                if (this.textBarrierIP2.Text.Trim() == "")
                {
                    this.textBarrierIP2.Focus();
                }
                else if (this.textBarrierPort2.Text.Trim() == "")
                {
                    this.textBarrierPort2.Focus();
                }
            }
        }

        private void buttonCloseGateIP3_Click(object sender, EventArgs e)
        {
            if ((this.textBarrierIP3.Text.Trim() != "") && (this.textBarrierPort3.Text.Trim() != ""))
            {
                if (WBBarrierGate2.closeGate(this.textBarrierIP3.Text.Trim(), this.textBarrierPort3.Text.Trim()))
                {
                    MessageBox.Show("Gate is closed", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Error close gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                MessageBox.Show("Please enter IP and Port before try to close barrier gate!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                if (this.textBarrierIP3.Text.Trim() == "")
                {
                    this.textBarrierIP3.Focus();
                }
                else if (this.textBarrierPort3.Text.Trim() == "")
                {
                    this.textBarrierPort3.Focus();
                }
            }
        }

        private void buttonCloseGateIP4_Click(object sender, EventArgs e)
        {
            if ((this.textBarrierIP4.Text.Trim() != "") && (this.textBarrierPort4.Text.Trim() != ""))
            {
                if (WBBarrierGate2.closeGate(this.textBarrierIP4.Text.Trim(), this.textBarrierPort4.Text.Trim()))
                {
                    MessageBox.Show("Gate is closed", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Error close gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                MessageBox.Show("Please enter IP and Port before try to close barrier gate!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                if (this.textBarrierIP4.Text.Trim() == "")
                {
                    this.textBarrierIP4.Focus();
                }
                else if (this.textBarrierPort4.Text.Trim() == "")
                {
                    this.textBarrierPort4.Focus();
                }
            }
        }

        private void buttonGate1CloseFind_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.ShowDialog();
            if (this.openFileDialog1.FileName.Trim() != "")
            {
                this.textGate1Close.Text = this.openFileDialog1.FileName;
            }
        }

        private void buttonGate1CloseOutFind_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.ShowDialog();
            if (this.openFileDialog1.FileName.Trim() != "")
            {
                this.textGate1CloseOut.Text = this.openFileDialog1.FileName;
            }
        }

        private void buttonGate1OpenOutFind_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.ShowDialog();
            if (this.openFileDialog1.FileName.Trim() != "")
            {
                this.textGate1OpenOut.Text = this.openFileDialog1.FileName;
            }
        }

        private void buttonGate2CloseFind_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.ShowDialog();
            if (this.openFileDialog1.FileName.Trim() != "")
            {
                this.textGate2Close.Text = this.openFileDialog1.FileName;
            }
        }

        private void buttonGate2OpenFind_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.ShowDialog();
            if (this.openFileDialog1.FileName.Trim() != "")
            {
                this.textGate2Open.Text = this.openFileDialog1.FileName;
            }
        }

        private void buttonGate2OpenOutFind_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.ShowDialog();
            if (this.openFileDialog1.FileName.Trim() != "")
            {
                this.textGate2OpenOut.Text = this.openFileDialog1.FileName;
            }
        }

        private void buttonOpenGateIP1_Click(object sender, EventArgs e)
        {
            if ((this.textBarrierIP1.Text.Trim() != "") && (this.textBarrierPort1.Text.Trim() != ""))
            {
                if (WBBarrierGate2.openGate(this.textBarrierIP1.Text.Trim(), this.textBarrierPort1.Text.Trim()))
                {
                    MessageBox.Show("Gate is opened", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Error open gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                MessageBox.Show("Please enter IP and Port before try to open barrier gate!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                if (this.textBarrierIP1.Text.Trim() == "")
                {
                    this.textBarrierIP1.Focus();
                }
                else if (this.textBarrierPort1.Text.Trim() == "")
                {
                    this.textBarrierPort1.Focus();
                }
            }
        }

        private void buttonOpenGateIP2_Click(object sender, EventArgs e)
        {
            if ((this.textBarrierIP2.Text.Trim() != "") && (this.textBarrierPort2.Text.Trim() != ""))
            {
                if (WBBarrierGate2.openGate(this.textBarrierIP2.Text.Trim(), this.textBarrierPort2.Text.Trim()))
                {
                    MessageBox.Show("Gate is opened", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Error open gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                MessageBox.Show("Please enter IP and Port before try to open barrier gate!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                if (this.textBarrierIP2.Text.Trim() == "")
                {
                    this.textBarrierIP2.Focus();
                }
                else if (this.textBarrierPort2.Text.Trim() == "")
                {
                    this.textBarrierPort2.Focus();
                }
            }
        }

        private void buttonOpenGateIP3_Click(object sender, EventArgs e)
        {
            if ((this.textBarrierIP3.Text.Trim() != "") && (this.textBarrierPort3.Text.Trim() != ""))
            {
                if (WBBarrierGate2.openGate(this.textBarrierIP3.Text.Trim(), this.textBarrierPort3.Text.Trim()))
                {
                    MessageBox.Show("Gate is opened", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Error open gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                MessageBox.Show("Please enter IP and Port before try to open barrier gate!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                if (this.textBarrierIP3.Text.Trim() == "")
                {
                    this.textBarrierIP3.Focus();
                }
                else if (this.textBarrierPort3.Text.Trim() == "")
                {
                    this.textBarrierPort3.Focus();
                }
            }
        }

        private void buttonOpenGateIP4_Click(object sender, EventArgs e)
        {
            if ((this.textBarrierIP4.Text.Trim() != "") && (this.textBarrierPort4.Text.Trim() != ""))
            {
                if (WBBarrierGate2.openGate(this.textBarrierIP4.Text.Trim(), this.textBarrierPort4.Text.Trim()))
                {
                    MessageBox.Show("Gate is opened", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("Error open gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                MessageBox.Show("Please enter IP and Port before try to open barrier gate!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                if (this.textBarrierIP4.Text.Trim() == "")
                {
                    this.textBarrierIP4.Focus();
                }
                else if (this.textBarrierPort4.Text.Trim() == "")
                {
                    this.textBarrierPort4.Focus();
                }
            }
        }

        private void buttonPath_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                dialog.Description = "Select a folder";
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    this.textPathPhotos.Text = dialog.SelectedPath;
                }
            }
        }

        private void buttonTestOpen_Click(object sender, EventArgs e)
        {
            new FormSAP_Test().ShowDialog();
        }

        private void buttonTicket1_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.Filter = "Rpt file (*.rpt)|*.rpt";
            this.openFileDialog1.ShowDialog();
        }

        private void cb_cam1_CheckedChanged(object sender, EventArgs e)
        {
            this.cekComboCamera();
        }

        private void cb_cam2_CheckedChanged(object sender, EventArgs e)
        {
            this.cekComboCamera();
        }

        private void cb_cam3_CheckedChanged(object sender, EventArgs e)
        {
            this.cekComboCamera();
        }

        private void cb_cam4_CheckedChanged(object sender, EventArgs e)
        {
            this.cekComboCamera();
        }

        private void cb_cam5_CheckedChanged(object sender, EventArgs e)
        {
            this.cekComboCamera();
        }

        private void cekComboCamera()
        {
            this.panel1.Enabled = this.cb_cam1.Checked;
            this.panel2.Enabled = this.cb_cam2.Checked;
            this.panel3.Enabled = this.cb_cam3.Checked;
            this.panel4.Enabled = this.cb_cam4.Checked;
            this.panel5.Enabled = this.cb_cam5.Checked;
        }

        private void cekRadioCamera()
        {
            if (this.rb_cam1_web.Checked)
            {
                this.combo_cam1_web.Enabled = true;
                this.combo_cam1_ip.Enabled = false;
            }
            else if (this.rb_cam1_ip.Checked)
            {
                this.combo_cam1_web.Enabled = false;
                this.combo_cam1_ip.Enabled = true;
            }
            if (this.rb_cam2_web.Checked)
            {
                this.combo_cam2_web.Enabled = true;
                this.combo_cam2_ip.Enabled = false;
            }
            else if (this.rb_cam2_ip.Checked)
            {
                this.combo_cam2_web.Enabled = false;
                this.combo_cam2_ip.Enabled = true;
            }
            if (this.rb_cam3_web.Checked)
            {
                this.combo_cam3_web.Enabled = true;
                this.combo_cam3_ip.Enabled = false;
            }
            else if (this.rb_cam3_ip.Checked)
            {
                this.combo_cam3_web.Enabled = false;
                this.combo_cam3_ip.Enabled = true;
            }
            if (this.rb_cam4_web.Checked)
            {
                this.combo_cam4_web.Enabled = true;
                this.combo_cam4_ip.Enabled = false;
            }
            else if (this.rb_cam4_ip.Checked)
            {
                this.combo_cam4_web.Enabled = false;
                this.combo_cam4_ip.Enabled = true;
            }
            if (this.rb_cam5_web.Checked)
            {
                this.combo_cam5_web.Enabled = true;
                this.combo_cam5_ip.Enabled = false;
            }
            else if (this.rb_cam1_ip.Checked)
            {
                this.combo_cam5_web.Enabled = false;
                this.combo_cam5_ip.Enabled = true;
            }
        }

        private void comboBarrier_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.comboBarrier.Text == "Using Bat File")
            {
                this.panelBarrierBat.Enabled = true;
                this.panelBarrierIP.Enabled = false;
                this.tabControl1.SelectedTab = this.tabBarrierBat;
            }
            else if (this.comboBarrier.Text == "Using IP")
            {
                this.panelBarrierIP.Enabled = true;
                this.panelBarrierBat.Enabled = false;
                this.tabControl1.SelectedTab = this.tabBarrierIP;
            }
            else
            {
                this.panelBarrierIP.Enabled = false;
                this.panelBarrierBat.Enabled = false;
                this.tabControl1.SelectedTab = this.tabBarrierBat;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public void f_load()
        {
            string sCoyCode = WBData.sCoyCode;
            string sLocCode = WBData.sLocCode;
            string sWBCode = WBData.sWBCode;
            this.tSetting.OpenTable("wb_setting", "Select * From wb_setting where " + WBData.CompanyLocation(" and wbCode = '" + WBData.sWBCode + "'"), WBData.conn);
            if (this.tSetting.DT.Rows.Count <= 0)
            {
                MessageBox.Show("Error loading data. Please ask administrator to set WB Setting first!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                DataRow row = this.tSetting.DT.Rows[0];
                this.comboBox1.Text = row["Comm_Port"].ToString();
                this.comboBox2.Text = row["Baudrate"].ToString();
                this.comboBox3.Text = row["Data_Bit"].ToString();
                this.comboBox4.Text = row["Parity"].ToString();
                this.comboBox5.Text = row["Stop_Bit"].ToString();
                this.textBuffers.Text = row["Buffer"].ToString();
                this.textStart.Text = row["Start_Get"].ToString();
                this.textLength.Text = row["Length"].ToString();
                this.textBeforeKG.Text = row["BeforeKG"].ToString();
                this.radioWBType1.Checked = row["WB_Type"].ToString() == "1";
                this.radioWBType2.Checked = row["WB_Type"].ToString() == "2";
                this.radioWBType3.Checked = row["WB_Type"].ToString() == "3";
                this.radioWBType4.Checked = row["WB_Type"].ToString() == "4";
                this.radioWBType5.Checked = row["WB_Type"].ToString() == "5";
                if (this.radioWBType4.Checked)
                {
                    this.listBoxBuffer.Visible = true;
                    this.listBoxTmpRead.Visible = true;
                }
                else
                {
                    this.listBoxBuffer.Visible = false;
                    this.listBoxTmpRead.Visible = false;
                }
                this.richTextBox1.Text = "";
                this.labelErr.Text = "";
                this.panelBarrierBat.Enabled = row["BarrierGate"].ToString() == "Y";
                this.comboBarrier.Items.Add("");
                this.comboBarrier.Items.Add("Using Bat File");
                this.comboBarrier.Items.Add("Using IP");
                if (row["BarrierGate"].ToString() != "Y")
                {
                    this.rboYes.Checked = false;
                    this.rboNo.Checked = true;
                }
                else
                {
                    this.rboYes.Checked = true;
                    this.rboNo.Checked = false;
                    if ((row["BarrierType"].ToString() == "1") || (row["BarrierType"].ToString() == ""))
                    {
                        this.comboBarrier.Text = "Using Bat File";
                    }
                    else if (row["BarrierType"].ToString() == "2")
                    {
                        this.comboBarrier.Text = "Using IP";
                    }
                }
                this.textGate1Open.Text = row["Barrier1Open"].ToString();
                this.textGate1Close.Text = row["Barrier1Close"].ToString();
                this.textGate2Open.Text = row["Barrier2Open"].ToString();
                this.textGate2Close.Text = row["Barrier2Close"].ToString();
                this.textGate1OpenOut.Text = row["Barrier1OpenOut"].ToString();
                this.textGate1CloseOut.Text = row["Barrier1CloseOut"].ToString();
                this.textGate2OpenOut.Text = row["Barrier2OpenOut"].ToString();
                this.textGate2CloseOut.Text = row["Barrier2CloseOut"].ToString();
                this.textBarrierIP1.Text = row["barrierIP1"].ToString();
                this.textBarrierPort1.Text = row["barrierPort1"].ToString();
                this.textBarrierIP2.Text = row["barrierIP2"].ToString();
                this.textBarrierPort2.Text = row["barrierPort2"].ToString();
                this.textBarrierIP3.Text = row["barrierIP1Out"].ToString();
                this.textBarrierPort3.Text = row["barrierPort1Out"].ToString();
                this.textBarrierIP4.Text = row["barrierIP2Out"].ToString();
                this.textBarrierPort4.Text = row["barrierPort2Out"].ToString();
                this.setPanelBarrier();
                this.cb_cam1.Checked = row["cam1"].ToString() == "Y";
                if (row["cam1_type"].ToString() == "IP_CAMERA")
                {
                    this.rb_cam1_ip.Checked = true;
                }
                else if (row["cam1_type"].ToString() == "WEB_CAMERA")
                {
                    this.rb_cam1_web.Checked = true;
                }
                this._combo_cam1_web = row["cam1_web"].ToString();
                this._combo_cam1_ip = row["cam1_ip_name"].ToString();
                this.cb_cam2.Checked = row["cam2"].ToString() == "Y";
                if (row["cam2_type"].ToString() == "IP_CAMERA")
                {
                    this.rb_cam2_ip.Checked = true;
                }
                else if (row["cam2_type"].ToString() == "WEB_CAMERA")
                {
                    this.rb_cam2_web.Checked = true;
                }
                this._combo_cam2_web = row["cam2_web"].ToString();
                this._combo_cam2_ip = row["cam2_ip_name"].ToString();
                this.cb_cam3.Checked = row["cam3"].ToString() == "Y";
                if (row["cam3_type"].ToString() == "IP_CAMERA")
                {
                    this.rb_cam3_ip.Checked = true;
                }
                else if (row["cam3_type"].ToString() == "WEB_CAMERA")
                {
                    this.rb_cam3_web.Checked = true;
                }
                this._combo_cam3_web = row["cam3_web"].ToString();
                this._combo_cam3_ip = row["cam3_ip_name"].ToString();
                this.cb_cam4.Checked = row["cam4"].ToString() == "Y";
                if (row["cam4_type"].ToString() == "IP_CAMERA")
                {
                    this.rb_cam4_ip.Checked = true;
                }
                else if (row["cam4_type"].ToString() == "WEB_CAMERA")
                {
                    this.rb_cam4_web.Checked = true;
                }
                this._combo_cam4_web = row["cam4_web"].ToString();
                this._combo_cam4_ip = row["cam4_ip_name"].ToString();
                this.cb_cam5.Checked = row["cam5"].ToString() == "Y";
                if (row["cam5_type"].ToString() == "IP_CAMERA")
                {
                    this.rb_cam5_ip.Checked = true;
                }
                else if (row["cam5_type"].ToString() == "WEB_CAMERA")
                {
                    this.rb_cam5_web.Checked = true;
                }
                this._combo_cam5_web = row["cam5_web"].ToString();
                this._combo_cam5_ip = row["cam5_ip_name"].ToString();
                this.txtStart.Text = row["Start_Address"].ToString();
                this.txtPLC_Length.Text = row["Reg_Length"].ToString();
                this.txtregfb.Text = row["Reg_feedback"].ToString();
                this.txtregLine.Text = row["Reg_Line"].ToString();
                this.tLocation.OpenTable("wb_location", "Select * From wb_location where " + WBData.CompanyLocation(""), WBData.conn);
                DataRow row2 = this.tLocation.DT.Rows[0];
                this.txtIP.Text = row2["PLC_IP"].ToString();
                this.txtPort.Text = row2["PLC_Port"].ToString();
                if (row2["camera_feature"].ToString() == "Y")
                {
                    this.rb_camera_on.Checked = true;
                }
                else
                {
                    this.rb_camera_off.Checked = true;
                }
                this.textPathPhotosServer.Text = row2["camera_path_server"].ToString();
                this.textPathPhotos.Text = row2["camera_path"].ToString();
                this.textDomainFolder.Text = row2["cameraDomainFolder"].ToString();
                this.textUsernameFolder.Text = row2["cameraUsernameFolder"].ToString();
                this.textPasswordFolder.Text = WBEncryption.Decrypt(row2["cameraPasswordFolder"].ToString());
                this.textBackupPathPhotos.Text = row2["camera_backup_path"].ToString();
                this.t_camera.OpenTable("wb_camera", "Select camera_code, ip_address, web_url, username, password FROM wb_camera where deleted is null or deleted = ''", WBData.conn);
                this.combo_cam1_ip.Items.Clear();
                this.combo_cam2_ip.Items.Clear();
                this.combo_cam3_ip.Items.Clear();
                this.combo_cam4_ip.Items.Clear();
                this.combo_cam5_ip.Items.Clear();
                int num = 0;
                while (true)
                {
                    if (num >= this.t_camera.DT.Rows.Count)
                    {
                        WBCamera camera = new WBCamera(0);
                        camera.getWebCamList(this.combo_cam1_web);
                        camera.getWebCamList(this.combo_cam2_web);
                        camera.getWebCamList(this.combo_cam3_web);
                        camera.getWebCamList(this.combo_cam4_web);
                        camera.getWebCamList(this.combo_cam5_web);
                        this.combo_cam1_web.Text = this._combo_cam1_web;
                        this.combo_cam1_ip.Text = this._combo_cam1_ip;
                        this.combo_cam2_web.Text = this._combo_cam2_web;
                        this.combo_cam2_ip.Text = this._combo_cam2_ip;
                        this.combo_cam3_web.Text = this._combo_cam3_web;
                        this.combo_cam3_ip.Text = this._combo_cam3_ip;
                        this.combo_cam4_web.Text = this._combo_cam4_web;
                        this.combo_cam4_ip.Text = this._combo_cam4_ip;
                        this.combo_cam5_web.Text = this._combo_cam5_web;
                        this.combo_cam5_ip.Text = this._combo_cam5_ip;
                        this.cekRadioCamera();
                        this.cekComboCamera();
                        this.setGroupBoxCamera();
                        if (WBSetting.activeRegistrationRequireLicensePhoto)
                        {
                            this.chkCheckDriverLicenseIDPhoto.Checked = true;
                        }
                        break;
                    }
                    DataRow row3 = this.t_camera.DT.Rows[num];
                    this.combo_cam1_ip.Items.Add(row3[0].ToString().Trim());
                    this.combo_cam2_ip.Items.Add(row3[0].ToString().Trim());
                    this.combo_cam3_ip.Items.Add(row3[0].ToString().Trim());
                    this.combo_cam4_ip.Items.Add(row3[0].ToString().Trim());
                    this.combo_cam5_ip.Items.Add(row3[0].ToString().Trim());
                    num++;
                }
            }
        }

        public void f_save()
        {
            Cursor.Current = Cursors.WaitCursor;
            this.tSetting.OpenTable("wb_setting", "Select * From wb_setting where " + WBData.CompanyLocation(" and wbCode = '" + WBData.sWBCode + "'"), WBData.conn);
            this.pMode = "EDIT";
            this.tSetting.DR = this.tSetting.DT.Rows[0];
            this.tSetting.DR.BeginEdit();
            this.logKey = this.tSetting.DR["uniq"].ToString();
            this.tSetting.DR["WB_Type"] = this.radioWBType1.Checked ? '1' : (this.radioWBType2.Checked ? '2' : (this.radioWBType3.Checked ? '3' : (this.radioWBType4.Checked ? '4' : '5')));
            this.tSetting.DR["Comm_Port"] = this.comboBox1.Text;
            this.tSetting.DR["Baudrate"] = this.comboBox2.Text;
            this.tSetting.DR["Data_Bit"] = this.comboBox3.Text;
            this.tSetting.DR["Parity"] = this.comboBox4.Text;
            this.tSetting.DR["Stop_Bit"] = this.comboBox5.Text;
            this.tSetting.DR["Buffer"] = this.textBuffers.Text;
            this.tSetting.DR["Start_Get"] = this.textStart.Text;
            this.tSetting.DR["Length"] = this.textLength.Text;
            this.tSetting.DR["BeforeKG"] = this.textBeforeKG.Text;
            this.tSetting.DR["barrierGate"] = this.bGate;
            this.tSetting.DR["Barrier1Open"] = this.textGate1Open.Text.Trim();
            this.tSetting.DR["Barrier1Close"] = this.textGate1Close.Text.Trim();
            this.tSetting.DR["Barrier2Open"] = this.textGate2Open.Text.Trim();
            this.tSetting.DR["Barrier2Close"] = this.textGate2Close.Text.Trim();
            this.tSetting.DR["Barrier1OpenOut"] = this.textGate1OpenOut.Text.Trim();
            this.tSetting.DR["Barrier1CloseOut"] = this.textGate1CloseOut.Text.Trim();
            this.tSetting.DR["Barrier2OpenOut"] = this.textGate2OpenOut.Text.Trim();
            this.tSetting.DR["Barrier2CloseOut"] = this.textGate2CloseOut.Text.Trim();
            if (this.comboBarrier.Text == "Using Bat File")
            {
                this.tSetting.DR["BarrierType"] = "1";
            }
            else if (this.comboBarrier.Text == "Using IP")
            {
                this.tSetting.DR["BarrierType"] = "2";
            }
            this.tSetting.DR["barrierIP1"] = this.textBarrierIP1.Text.Trim();
            this.tSetting.DR["barrierPort1"] = this.textBarrierPort1.Text.Trim();
            this.tSetting.DR["barrierIP2"] = this.textBarrierIP2.Text.Trim();
            this.tSetting.DR["barrierPort2"] = this.textBarrierPort2.Text.Trim();
            this.tSetting.DR["barrierIP1Out"] = this.textBarrierIP3.Text.Trim();
            this.tSetting.DR["barrierPort1Out"] = this.textBarrierPort3.Text.Trim();
            this.tSetting.DR["barrierIP2Out"] = this.textBarrierIP4.Text.Trim();
            this.tSetting.DR["barrierPort2Out"] = this.textBarrierPort4.Text.Trim();
            this.tSetting.DR["cam1"] = this.cb_cam1.Checked ? "Y" : "N";
            this.tSetting.DR["cam1_type"] = this.rb_cam1_ip.Checked ? "IP_CAMERA" : "WEB_CAMERA";
            this.tSetting.DR["cam1_web"] = this.combo_cam1_web.Text.Trim();
            this.tSetting.DR["cam1_ip_name"] = this.combo_cam1_ip.Text.Trim();
            this.tSetting.DR["cam2"] = this.cb_cam2.Checked ? "Y" : "N";
            this.tSetting.DR["cam2_type"] = this.rb_cam2_ip.Checked ? "IP_CAMERA" : "WEB_CAMERA";
            this.tSetting.DR["cam2_web"] = this.combo_cam2_web.Text.Trim();
            this.tSetting.DR["cam2_ip_name"] = this.combo_cam2_ip.Text.Trim();
            this.tSetting.DR["cam3"] = this.cb_cam3.Checked ? "Y" : "N";
            this.tSetting.DR["cam3_type"] = this.rb_cam3_ip.Checked ? "IP_CAMERA" : "WEB_CAMERA";
            this.tSetting.DR["cam3_web"] = this.combo_cam3_web.Text.Trim();
            this.tSetting.DR["cam3_ip_name"] = this.combo_cam3_ip.Text.Trim();
            this.tSetting.DR["cam4"] = this.cb_cam4.Checked ? "Y" : "N";
            this.tSetting.DR["cam4_type"] = this.rb_cam4_ip.Checked ? "IP_CAMERA" : "WEB_CAMERA";
            this.tSetting.DR["cam4_web"] = this.combo_cam4_web.Text.Trim();
            this.tSetting.DR["cam4_ip_name"] = this.combo_cam4_ip.Text.Trim();
            this.tSetting.DR["cam5"] = this.cb_cam5.Checked ? "Y" : "N";
            this.tSetting.DR["cam5_type"] = this.rb_cam5_ip.Checked ? "IP_CAMERA" : "WEB_CAMERA";
            this.tSetting.DR["cam5_web"] = this.combo_cam5_web.Text.Trim();
            this.tSetting.DR["cam5_ip_name"] = this.combo_cam5_ip.Text.Trim();
            this.tSetting.DR["reg_line"] = this.txtregLine.Text.Trim();
            this.tSetting.DR["reg_feedback"] = this.txtregfb.Text.Trim();
            this.tSetting.DR["Start_Address"] = this.txtStart.Text.Trim();
            this.tSetting.DR["Reg_Length"] = this.txtPLC_Length.Text.Trim();
            this.tSetting.DR.EndEdit();
            this.tSetting.Save();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { this.pMode, WBUser.UserID, this.result };
            Program.updateLogHeader("wb_setting", this.logKey, logField, logValue);
            this.tLocation.ReOpen();
            DataRow row = this.tLocation.DT.Rows[0];
            row.BeginEdit();
            this.logKey = row["uniq"].ToString();
            row["PLC_IP"] = this.txtIP.Text;
            row["PLC_Port"] = this.txtPort.Text;
            row["camera_feature"] = this.rb_camera_on.Checked ? "Y" : "N";
            row["camera_path"] = this.textPathPhotos.Text.Trim();
            row["camera_path_server"] = this.textPathPhotosServer.Text.Trim();
            row["cameraDomainFolder"] = this.textDomainFolder.Text;
            row["cameraUsernameFolder"] = this.textUsernameFolder.Text;
            row["cameraPasswordFolder"] = WBEncryption.Encrypt(this.textPasswordFolder.Text);
            row["camera_backup_path"] = this.textBackupPathPhotos.Text.Trim();
            row["Reason"] = this.result.Trim();
            row["checksum"] = this.tLocation.Checksum(row);
            row.EndEdit();
            this.tLocation.DR = row;
            this.tLocation.Save();
            WBTable table = new WBTable();
            table.OpenTable("wb_location", "select * from wb_Condition where Condition_Code='ACTIVE_REGISTRATION_REQUIRE_LICENSE_PHOTO'", WBData.conn);
            if (this.chkCheckDriverLicenseIDPhoto.Checked)
            {
                table.DR = table.DT.NewRow();
                table.DR["Condition_Code"] = "ACTIVE_REGISTRATION_REQUIRE_LICENSE_PHOTO";
                table.DR["Description"] = "Driver License ID Photo must be exist before Saving Registration data.";
                table.DT.Rows.Add(table.DR);
            }
            else
            {
                foreach (DataRow row2 in table.DT.Rows)
                {
                    row2.Delete();
                }
            }
            table.Save();
            string[] textArray3 = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] textArray4 = new string[] { "EDIT", WBUser.UserID, this.result };
            Program.updateLogHeader("wb_location", this.logKey, textArray3, textArray4);
            WBSetting.OpenSetting();
            this.saved = true;
            Cursor.Current = Cursors.Default;
            base.Close();
        }

        private void FormSettingHardware_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.button4.Text = "Test Capture";
            this.serialPort1.Close();
            this.serialPort2.Close();
            this.tSetting.Close();
        }

        private void FormSettingHardware_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.ThisClose();
            }
        }

        private void FormSettingHardware_Load(object sender, EventArgs e)
        {
            this.translate();
            this.f_load();
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            ComponentResourceManager manager = new ComponentResourceManager(typeof(FormSettingHardware));
            this.tabGate = new TabControl();
            this.tabPage2 = new TabPage();
            this.listBoxBuffer = new ListBox();
            this.listBoxTmpRead = new ListBox();
            this.buttonAuto = new Button();
            this.label30 = new Label();
            this.textBeforeKG = new TextBox();
            this.labelErr = new Label();
            this.panel10 = new Panel();
            this.label77 = new Label();
            this.panel11 = new Panel();
            this.radioWBType5 = new RadioButton();
            this.labelType5Status = new Label();
            this.radioWBType4 = new RadioButton();
            this.radioWBType3 = new RadioButton();
            this.radioWBType2 = new RadioButton();
            this.radioWBType1 = new RadioButton();
            this.label11 = new Label();
            this.button1 = new Button();
            this.label8 = new Label();
            this.label9 = new Label();
            this.label10 = new Label();
            this.label7 = new Label();
            this.comboBox1 = new ComboBox();
            this.comboBox2 = new ComboBox();
            this.comboBox3 = new ComboBox();
            this.comboBox4 = new ComboBox();
            this.comboBox5 = new ComboBox();
            this.textBuffers = new TextBox();
            this.label6 = new Label();
            this.button4 = new Button();
            this.textBox4 = new TextBox();
            this.label16 = new Label();
            this.label15 = new Label();
            this.textLength = new TextBox();
            this.label14 = new Label();
            this.textStart = new TextBox();
            this.label13 = new Label();
            this.label12 = new Label();
            this.richTextBox1 = new RichTextBox();
            this.tabBarrierGate = new TabPage();
            this.tabControl1 = new TabControl();
            this.tabBarrierBat = new TabPage();
            this.panelBarrierBat = new Panel();
            this.groupBox3 = new GroupBox();
            this.label116 = new Label();
            this.buttonGate2OpenOutFind = new Button();
            this.buttonGate1CloseOutFind = new Button();
            this.buttonGate2CloseOutFind = new Button();
            this.buttonGate1OpenOutFind = new Button();
            this.textGate2CloseOut = new TextBox();
            this.tes2Out = new Button();
            this.textGate1CloseOut = new TextBox();
            this.tes1Out = new Button();
            this.label112 = new Label();
            this.label114 = new Label();
            this.textGate2OpenOut = new TextBox();
            this.label28 = new Label();
            this.label111 = new Label();
            this.label113 = new Label();
            this.textGate1OpenOut = new TextBox();
            this.label110 = new Label();
            this.groupBox2 = new GroupBox();
            this.label115 = new Label();
            this.buttonGate2OpenFind = new Button();
            this.buttonGate2CloseFind = new Button();
            this.buttonGate1CloseFind = new Button();
            this.label100 = new Label();
            this.label93 = new Label();
            this.buttonGate1OpenFind = new Button();
            this.label94 = new Label();
            this.label99 = new Label();
            this.textGate2Close = new TextBox();
            this.label87 = new Label();
            this.button6 = new Button();
            this.textGate1Close = new TextBox();
            this.textGate1Open = new TextBox();
            this.label88 = new Label();
            this.textGate2Open = new TextBox();
            this.btnTes = new Button();
            this.tabBarrierIP = new TabPage();
            this.panelBarrierIP = new Panel();
            this.groupBox4 = new GroupBox();
            this.button7 = new Button();
            this.buttonCloseGateIP4 = new Button();
            this.button5 = new Button();
            this.label19 = new Label();
            this.textBarrierPort4 = new TextBox();
            this.buttonCloseGateIP3 = new Button();
            this.textBarrierIP4 = new TextBox();
            this.label23 = new Label();
            this.labelPort4 = new Label();
            this.textBarrierPort3 = new TextBox();
            this.labelIP4 = new Label();
            this.textBarrierIP3 = new TextBox();
            this.labelPort3 = new Label();
            this.label26 = new Label();
            this.buttonOpenGateIP4 = new Button();
            this.labelIP3 = new Label();
            this.buttonOpenGateIP3 = new Button();
            this.groupBox5 = new GroupBox();
            this.label27 = new Label();
            this.button8 = new Button();
            this.buttonCloseGateIP1 = new Button();
            this.buttonCloseGateIP2 = new Button();
            this.button9 = new Button();
            this.label34 = new Label();
            this.label35 = new Label();
            this.textBarrierIP1 = new TextBox();
            this.labelPort1 = new Label();
            this.textBarrierPort1 = new TextBox();
            this.labelIP1 = new Label();
            this.buttonOpenGateIP1 = new Button();
            this.label3 = new Label();
            this.label2 = new Label();
            this.textBarrierIP2 = new TextBox();
            this.buttonOpenGateIP2 = new Button();
            this.textBarrierPort2 = new TextBox();
            this.groupBox1 = new GroupBox();
            this.comboBarrier = new ComboBox();
            this.rboNo = new RadioButton();
            this.rboYes = new RadioButton();
            this.tab_camera = new TabPage();
            this.textBackupPathPhotos = new TextBox();
            this.lblBackupCameraPath = new Label();
            this.groupBox6 = new GroupBox();
            this.button11 = new Button();
            this.textPathPhotosServer = new TextBox();
            this.label18 = new Label();
            this.btnBrowseBackupPathPhotos = new Button();
            this.textPasswordFolder = new TextBox();
            this.label1 = new Label();
            this.textUsernameFolder = new TextBox();
            this.button10 = new Button();
            this.labelDestFolder = new Label();
            this.labelPassword = new Label();
            this.textPathPhotos = new TextBox();
            this.textDomainFolder = new TextBox();
            this.labelDomainUsername = new Label();
            this.gb_cam5 = new GroupBox();
            this.panel5 = new Panel();
            this.btn_tes_cam5 = new Button();
            this.label17 = new Label();
            this.combo_cam5_ip = new ComboBox();
            this.rb_cam5_web = new RadioButton();
            this.combo_cam5_web = new ComboBox();
            this.rb_cam5_ip = new RadioButton();
            this.cb_cam5 = new CheckBox();
            this.gb_cam4 = new GroupBox();
            this.panel4 = new Panel();
            this.btn_tes_cam4 = new Button();
            this.label5 = new Label();
            this.combo_cam4_ip = new ComboBox();
            this.rb_cam4_web = new RadioButton();
            this.combo_cam4_web = new ComboBox();
            this.rb_cam4_ip = new RadioButton();
            this.cb_cam4 = new CheckBox();
            this.gb_cam3 = new GroupBox();
            this.panel3 = new Panel();
            this.btn_tes_cam3 = new Button();
            this.label4 = new Label();
            this.combo_cam3_ip = new ComboBox();
            this.rb_cam3_web = new RadioButton();
            this.combo_cam3_web = new ComboBox();
            this.rb_cam3_ip = new RadioButton();
            this.cb_cam3 = new CheckBox();
            this.gb_cam2 = new GroupBox();
            this.panel2 = new Panel();
            this.btn_tes_cam2 = new Button();
            this.label119 = new Label();
            this.combo_cam2_ip = new ComboBox();
            this.rb_cam2_web = new RadioButton();
            this.combo_cam2_web = new ComboBox();
            this.rb_cam2_ip = new RadioButton();
            this.cb_cam2 = new CheckBox();
            this.gb_cam1 = new GroupBox();
            this.panel1 = new Panel();
            this.label120 = new Label();
            this.btn_tes_cam1 = new Button();
            this.rb_cam1_web = new RadioButton();
            this.combo_cam1_ip = new ComboBox();
            this.rb_cam1_ip = new RadioButton();
            this.combo_cam1_web = new ComboBox();
            this.label98 = new Label();
            this.cb_cam1 = new CheckBox();
            this.gb_enable_camera = new GroupBox();
            this.rb_camera_off = new RadioButton();
            this.rb_camera_on = new RadioButton();
            this.tabPage9 = new TabPage();
            this.axWinsock1 = new AxWinsock();
            this.gBoxValvePLC = new GroupBox();
            this.lblCloseValve = new Label();
            this.lblOpenValve = new Label();
            this.btnConnectPLC = new Button();
            this.lblReadLine = new Label();
            this.btnCloseValve = new Button();
            this.btnOpenValve = new Button();
            this.btnReadLineValve = new Button();
            this.txtPLC_Length = new TextBox();
            this.lblLength = new Label();
            this.txtStart = new TextBox();
            this.lblStart = new Label();
            this.txtregfb = new TextBox();
            this.label121 = new Label();
            this.txtregLine = new TextBox();
            this.Regline = new Label();
            this.lblPort = new Label();
            this.txtIP = new TextBox();
            this.txtPort = new TextBox();
            this.lblIP = new Label();
            this.tabPageGlobalSettings = new TabPage();
            this.groupBox_GlobalSetting_Camera = new GroupBox();
            this.chkCheckDriverLicenseIDPhoto = new CheckBox();
            this.button2 = new Button();
            this.button3 = new Button();
            this.openFileDialog1 = new OpenFileDialog();
            this.serialPort2 = new SerialPort(this.components);
            this.toolTip1 = new ToolTip(this.components);
            this.pageSetupDialog1 = new PageSetupDialog();
            this.folderBrowserDialog1 = new FolderBrowserDialog();
            this.tabGate.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.tabBarrierGate.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabBarrierBat.SuspendLayout();
            this.panelBarrierBat.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabBarrierIP.SuspendLayout();
            this.panelBarrierIP.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tab_camera.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.gb_cam5.SuspendLayout();
            this.panel5.SuspendLayout();
            this.gb_cam4.SuspendLayout();
            this.panel4.SuspendLayout();
            this.gb_cam3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.gb_cam2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.gb_cam1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gb_enable_camera.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.axWinsock1.BeginInit();
            this.gBoxValvePLC.SuspendLayout();
            this.tabPageGlobalSettings.SuspendLayout();
            this.groupBox_GlobalSetting_Camera.SuspendLayout();
            base.SuspendLayout();
            this.tabGate.Controls.Add(this.tabPage2);
            this.tabGate.Controls.Add(this.tabBarrierGate);
            this.tabGate.Controls.Add(this.tab_camera);
            this.tabGate.Controls.Add(this.tabPage9);
            this.tabGate.Controls.Add(this.tabPageGlobalSettings);
            this.tabGate.Location = new Point(12, 0x12);
            this.tabGate.Name = "tabGate";
            this.tabGate.SelectedIndex = 0;
            this.tabGate.Size = new Size(0x3af, 0x1fc);
            this.tabGate.TabIndex = 0;
            this.tabPage2.BackColor = SystemColors.ButtonFace;
            this.tabPage2.BorderStyle = BorderStyle.Fixed3D;
            this.tabPage2.Controls.Add(this.listBoxBuffer);
            this.tabPage2.Controls.Add(this.listBoxTmpRead);
            this.tabPage2.Controls.Add(this.buttonAuto);
            this.tabPage2.Controls.Add(this.label30);
            this.tabPage2.Controls.Add(this.textBeforeKG);
            this.tabPage2.Controls.Add(this.labelErr);
            this.tabPage2.Controls.Add(this.panel10);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.textBox4);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.textLength);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.textStart);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.richTextBox1);
            this.tabPage2.Location = new Point(4, 0x16);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new Padding(3);
            this.tabPage2.Size = new Size(0x3a7, 0x1e2);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Communication Port";
            this.tabPage2.Click += new EventHandler(this.tabPage2_Click);
            this.listBoxBuffer.FormattingEnabled = true;
            this.listBoxBuffer.Location = new Point(0x234, 0x138);
            this.listBoxBuffer.Name = "listBoxBuffer";
            this.listBoxBuffer.Size = new Size(0xf3, 0x86);
            this.listBoxBuffer.TabIndex = 0x3a;
            this.listBoxTmpRead.FormattingEnabled = true;
            this.listBoxTmpRead.Location = new Point(0x134, 0x138);
            this.listBoxTmpRead.Name = "listBoxTmpRead";
            this.listBoxTmpRead.Size = new Size(0xf3, 0x86);
            this.listBoxTmpRead.TabIndex = 0x39;
            this.buttonAuto.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonAuto.Location = new Point(0x29a, 0x9d);
            this.buttonAuto.Name = "buttonAuto";
            this.buttonAuto.Size = new Size(0x2f, 0x1f);
            this.buttonAuto.TabIndex = 0x37;
            this.buttonAuto.Text = "Auto";
            this.buttonAuto.UseVisualStyleBackColor = true;
            this.buttonAuto.Visible = false;
            this.buttonAuto.Click += new EventHandler(this.buttonAuto_Click);
            this.label30.AllowDrop = true;
            this.label30.AutoSize = true;
            this.label30.Location = new Point(0x214, 0xa6);
            this.label30.Name = "label30";
            this.label30.RightToLeft = RightToLeft.No;
            this.label30.Size = new Size(0x51, 13);
            this.label30.TabIndex = 0x36;
            this.label30.Text = "Char Before KG";
            this.textBeforeKG.Location = new Point(0x26b, 0xa3);
            this.textBeforeKG.Name = "textBeforeKG";
            this.textBeforeKG.Size = new Size(0x29, 20);
            this.textBeforeKG.TabIndex = 0x35;
            this.textBeforeKG.Text = "0";
            this.textBeforeKG.TextAlign = HorizontalAlignment.Right;
            this.labelErr.AllowDrop = true;
            this.labelErr.AutoSize = true;
            this.labelErr.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.labelErr.ForeColor = Color.DarkRed;
            this.labelErr.Location = new Point(0x131, 0xc1);
            this.labelErr.Name = "labelErr";
            this.labelErr.RightToLeft = RightToLeft.No;
            this.labelErr.Size = new Size(0x165, 0x10);
            this.labelErr.TabIndex = 0x34;
            this.labelErr.Text = "Wrong setting at 'Starts at' or 'Length', please check  . . . . . . !";
            this.panel10.BorderStyle = BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.label77);
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Controls.Add(this.label11);
            this.panel10.Controls.Add(this.button1);
            this.panel10.Controls.Add(this.label8);
            this.panel10.Controls.Add(this.label9);
            this.panel10.Controls.Add(this.label10);
            this.panel10.Controls.Add(this.label7);
            this.panel10.Controls.Add(this.comboBox1);
            this.panel10.Controls.Add(this.comboBox2);
            this.panel10.Controls.Add(this.comboBox3);
            this.panel10.Controls.Add(this.comboBox4);
            this.panel10.Controls.Add(this.comboBox5);
            this.panel10.Controls.Add(this.textBuffers);
            this.panel10.Controls.Add(this.label6);
            this.panel10.Location = new Point(6, 0x13);
            this.panel10.Name = "panel10";
            this.panel10.Size = new Size(0x114, 0x175);
            this.panel10.TabIndex = 0;
            this.label77.AllowDrop = true;
            this.label77.AutoSize = true;
            this.label77.Location = new Point(0x10, 0x12);
            this.label77.Name = "label77";
            this.label77.RightToLeft = RightToLeft.Yes;
            this.label77.Size = new Size(0x4b, 13);
            this.label77.TabIndex = 0x36;
            this.label77.Text = "Indicator Type";
            this.label77.TextAlign = ContentAlignment.TopRight;
            this.panel11.BorderStyle = BorderStyle.Fixed3D;
            this.panel11.Controls.Add(this.radioWBType5);
            this.panel11.Controls.Add(this.labelType5Status);
            this.panel11.Controls.Add(this.radioWBType4);
            this.panel11.Controls.Add(this.radioWBType3);
            this.panel11.Controls.Add(this.radioWBType2);
            this.panel11.Controls.Add(this.radioWBType1);
            this.panel11.Location = new Point(0x10, 0x24);
            this.panel11.Name = "panel11";
            this.panel11.Size = new Size(0xf1, 0x7b);
            this.panel11.TabIndex = 0x35;
            this.radioWBType5.AutoSize = true;
            this.radioWBType5.Checked = true;
            this.radioWBType5.Location = new Point(0x1b, 0x5d);
            this.radioWBType5.Name = "radioWBType5";
            this.radioWBType5.Size = new Size(0x44, 0x11);
            this.radioWBType5.TabIndex = 4;
            this.radioWBType5.TabStop = true;
            this.radioWBType5.Text = "5 )  VWB";
            this.radioWBType5.UseVisualStyleBackColor = true;
            this.labelType5Status.AllowDrop = true;
            this.labelType5Status.AutoSize = true;
            this.labelType5Status.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Underline | FontStyle.Italic, GraphicsUnit.Point, 0);
            this.labelType5Status.Location = new Point(0x8a, 0x5f);
            this.labelType5Status.Name = "labelType5Status";
            this.labelType5Status.RightToLeft = RightToLeft.Yes;
            this.labelType5Status.Size = new Size(0x60, 13);
            this.labelType5Status.TabIndex = 30;
            this.labelType5Status.Text = "Status Unavailable";
            this.labelType5Status.TextAlign = ContentAlignment.TopRight;
            this.radioWBType4.AutoSize = true;
            this.radioWBType4.Enabled = false;
            this.radioWBType4.Location = new Point(0x1b, 70);
            this.radioWBType4.Name = "radioWBType4";
            this.radioWBType4.Size = new Size(160, 0x11);
            this.radioWBType4.TabIndex = 3;
            this.radioWBType4.Text = "4 )  Continuous w/o new line";
            this.radioWBType4.UseVisualStyleBackColor = true;
            this.radioWBType4.CheckedChanged += new EventHandler(this.radioWBType4_CheckedChanged);
            this.radioWBType3.AutoSize = true;
            this.radioWBType3.Enabled = false;
            this.radioWBType3.Location = new Point(0x1b, 0x2f);
            this.radioWBType3.Name = "radioWBType3";
            this.radioWBType3.Size = new Size(0x45, 0x11);
            this.radioWBType3.TabIndex = 2;
            this.radioWBType3.Text = "3 )  Other";
            this.radioWBType3.UseVisualStyleBackColor = true;
            this.radioWBType2.AutoSize = true;
            this.radioWBType2.Enabled = false;
            this.radioWBType2.Location = new Point(0x1b, 0x1a);
            this.radioWBType2.Name = "radioWBType2";
            this.radioWBType2.Size = new Size(0x71, 0x11);
            this.radioWBType2.TabIndex = 1;
            this.radioWBType2.Text = "2 )  Once brodcast";
            this.radioWBType2.UseVisualStyleBackColor = true;
            this.radioWBType1.AutoSize = true;
            this.radioWBType1.Enabled = false;
            this.radioWBType1.Location = new Point(0x1b, 6);
            this.radioWBType1.Name = "radioWBType1";
            this.radioWBType1.Size = new Size(0x92, 0x11);
            this.radioWBType1.TabIndex = 0;
            this.radioWBType1.Text = "1 )  Continuous broadcast";
            this.radioWBType1.UseVisualStyleBackColor = true;
            this.label11.AllowDrop = true;
            this.label11.Location = new Point(15, 0xc7);
            this.label11.Name = "label11";
            this.label11.RightToLeft = RightToLeft.Yes;
            this.label11.Size = new Size(120, 13);
            this.label11.TabIndex = 0x1d;
            this.label11.Text = "Communication Port";
            this.button1.Location = new Point(0xd4, 0xc2);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x2f, 0x17);
            this.button1.TabIndex = 0x29;
            this.button1.Text = "Read to Var";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.label8.AllowDrop = true;
            this.label8.Location = new Point(15, 0xe2);
            this.label8.Name = "label8";
            this.label8.RightToLeft = RightToLeft.Yes;
            this.label8.Size = new Size(120, 0x12);
            this.label8.TabIndex = 30;
            this.label8.Text = "Baud Rate";
            this.label9.AllowDrop = true;
            this.label9.Location = new Point(0x10, 0xfd);
            this.label9.Name = "label9";
            this.label9.RightToLeft = RightToLeft.Yes;
            this.label9.Size = new Size(0x77, 0x11);
            this.label9.TabIndex = 0x20;
            this.label9.Text = "Data Bits";
            this.label10.AllowDrop = true;
            this.label10.Location = new Point(0x10, 280);
            this.label10.Name = "label10";
            this.label10.RightToLeft = RightToLeft.Yes;
            this.label10.Size = new Size(0x74, 0x12);
            this.label10.TabIndex = 0x21;
            this.label10.Text = "Parity";
            this.label7.AllowDrop = true;
            this.label7.Location = new Point(0x10, 0x133);
            this.label7.Name = "label7";
            this.label7.RightToLeft = RightToLeft.Yes;
            this.label7.Size = new Size(0x74, 0x12);
            this.label7.TabIndex = 0x22;
            this.label7.Text = "Stopbits";
            this.comboBox1.FormattingEnabled = true;
            object[] items = new object[0x12];
            items[0] = "COM1";
            items[1] = "COM2";
            items[2] = "COM3";
            items[3] = "COM4";
            items[4] = "COM5";
            items[5] = "COM6";
            items[6] = "COM7";
            items[7] = "COM8";
            items[8] = "COM9";
            items[9] = "COM10";
            items[10] = "COM11";
            items[11] = "COM12";
            items[12] = "COM13";
            items[13] = "COM14";
            items[14] = "COM15";
            items[15] = "COM16";
            items[0x10] = "COM17";
            items[0x11] = "COM18";
            this.comboBox1.Items.AddRange(items);
            this.comboBox1.Location = new Point(0x8a, 0xc4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new Size(0x43, 0x15);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.Text = "COM1";
            this.comboBox2.FormattingEnabled = true;
            object[] objArray2 = new object[11];
            objArray2[0] = "    150";
            objArray2[1] = "    300";
            objArray2[2] = "    600";
            objArray2[3] = "  1200";
            objArray2[4] = "  2400";
            objArray2[5] = "  4800";
            objArray2[6] = "  9600";
            objArray2[7] = " 19200";
            objArray2[8] = " 38400";
            objArray2[9] = " 57600";
            objArray2[10] = "115200";
            this.comboBox2.Items.AddRange(objArray2);
            this.comboBox2.Location = new Point(0x8a, 0xdf);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new Size(0x58, 0x15);
            this.comboBox2.TabIndex = 1;
            this.comboBox2.Text = "4800";
            this.comboBox3.FormattingEnabled = true;
            object[] objArray3 = new object[] { "7", "8" };
            this.comboBox3.Items.AddRange(objArray3);
            this.comboBox3.Location = new Point(0x8a, 250);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new Size(0x20, 0x15);
            this.comboBox3.TabIndex = 2;
            this.comboBox3.Text = "7";
            this.comboBox4.FormattingEnabled = true;
            object[] objArray4 = new object[] { "None", "Even", "Odd" };
            this.comboBox4.Items.AddRange(objArray4);
            this.comboBox4.Location = new Point(0x8a, 0x115);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new Size(0x4d, 0x15);
            this.comboBox4.TabIndex = 3;
            this.comboBox4.Text = "None";
            this.comboBox5.FormattingEnabled = true;
            object[] objArray5 = new object[] { "One", "Two" };
            this.comboBox5.Items.AddRange(objArray5);
            this.comboBox5.Location = new Point(0x8a, 0x130);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new Size(0x3a, 0x15);
            this.comboBox5.TabIndex = 4;
            this.comboBox5.Text = "One";
            this.textBuffers.Location = new Point(0x8a, 0x14b);
            this.textBuffers.Name = "textBuffers";
            this.textBuffers.Size = new Size(0x58, 20);
            this.textBuffers.TabIndex = 5;
            this.textBuffers.Text = "2048";
            this.textBuffers.TextAlign = HorizontalAlignment.Right;
            this.label6.AllowDrop = true;
            this.label6.Location = new Point(0x10, 0x14e);
            this.label6.Name = "label6";
            this.label6.RightToLeft = RightToLeft.Yes;
            this.label6.Size = new Size(0x74, 0x11);
            this.label6.TabIndex = 40;
            this.label6.Text = "Buffers";
            this.button4.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button4.Location = new Point(0x4c, 0x18e);
            this.button4.Name = "button4";
            this.button4.Size = new Size(0x7f, 0x30);
            this.button4.TabIndex = 2;
            this.button4.Text = "Test Capture";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new EventHandler(this.button4_Click);
            this.textBox4.BackColor = Color.Black;
            this.textBox4.Font = new Font("Courier New", 27.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textBox4.ForeColor = Color.Lime;
            this.textBox4.Location = new Point(510, 0xf1);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new Size(0x129, 0x31);
            this.textBox4.TabIndex = 0x33;
            this.textBox4.Text = "0";
            this.textBox4.TextAlign = HorizontalAlignment.Right;
            this.label16.AllowDrop = true;
            this.label16.AutoSize = true;
            this.label16.Font = new Font("Courier New", 27.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label16.Location = new Point(0x12e, 0xf6);
            this.label16.Name = "label16";
            this.label16.RightToLeft = RightToLeft.Yes;
            this.label16.Size = new Size(150, 0x29);
            this.label16.TabIndex = 50;
            this.label16.Text = "Result";
            this.label15.AllowDrop = true;
            this.label15.AutoSize = true;
            this.label15.Location = new Point(0x192, 0xa6);
            this.label15.Name = "label15";
            this.label15.RightToLeft = RightToLeft.No;
            this.label15.Size = new Size(40, 13);
            this.label15.TabIndex = 0x31;
            this.label15.Text = "Length";
            this.textLength.Location = new Point(0x1c0, 0xa3);
            this.textLength.Name = "textLength";
            this.textLength.Size = new Size(0x29, 20);
            this.textLength.TabIndex = 1;
            this.textLength.Text = "0";
            this.textLength.TextAlign = HorizontalAlignment.Right;
            this.label14.AllowDrop = true;
            this.label14.AutoSize = true;
            this.label14.Location = new Point(0x131, 0xa6);
            this.label14.Name = "label14";
            this.label14.RightToLeft = RightToLeft.No;
            this.label14.Size = new Size(0x2e, 13);
            this.label14.TabIndex = 0x2f;
            this.label14.Text = "Starts at";
            this.textStart.Location = new Point(0x160, 0xa3);
            this.textStart.Name = "textStart";
            this.textStart.Size = new Size(0x22, 20);
            this.textStart.TabIndex = 0;
            this.textStart.Text = "0";
            this.textStart.TextAlign = HorizontalAlignment.Right;
            this.label13.AutoSize = true;
            this.label13.BackColor = Color.FromArgb(0x40, 0x40, 0x40);
            this.label13.Font = new Font("Courier New", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label13.ForeColor = Color.White;
            this.label13.Location = new Point(0x12b, 0x13);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x1fc, 0x12);
            this.label13.TabIndex = 0x2d;
            this.label13.Text = "         1         2         3         4         5";
            this.label12.AutoSize = true;
            this.label12.BackColor = Color.FromArgb(0x40, 0x40, 0x40);
            this.label12.Font = new Font("Courier New", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label12.ForeColor = Color.White;
            this.label12.Location = new Point(0x12b, 0x25);
            this.label12.Margin = new Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x1fc, 0x12);
            this.label12.TabIndex = 0x2c;
            this.label12.Text = "123456789 123456789 123456789 123456789 123456789 ";
            this.richTextBox1.BackColor = Color.Black;
            this.richTextBox1.BorderStyle = BorderStyle.None;
            this.richTextBox1.Font = new Font("Courier New", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.richTextBox1.ForeColor = Color.Lime;
            this.richTextBox1.Location = new Point(0x12b, 0x37);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new Size(0x1fc, 0x60);
            this.richTextBox1.TabIndex = 0x2a;
            this.richTextBox1.Text = "ABCDEFGHIJKLMNOP";
            this.richTextBox1.TextChanged += new EventHandler(this.richTextBox1_TextChanged);
            this.tabBarrierGate.BackColor = SystemColors.ButtonFace;
            this.tabBarrierGate.BorderStyle = BorderStyle.Fixed3D;
            this.tabBarrierGate.Controls.Add(this.tabControl1);
            this.tabBarrierGate.Controls.Add(this.groupBox1);
            this.tabBarrierGate.Location = new Point(4, 0x16);
            this.tabBarrierGate.Name = "tabBarrierGate";
            this.tabBarrierGate.Padding = new Padding(3);
            this.tabBarrierGate.Size = new Size(0x3a7, 0x1e2);
            this.tabBarrierGate.TabIndex = 4;
            this.tabBarrierGate.Text = "Barrier Gate";
            this.tabControl1.Controls.Add(this.tabBarrierBat);
            this.tabControl1.Controls.Add(this.tabBarrierIP);
            this.tabControl1.Location = new Point(20, 0x60);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new Size(0x37c, 0x155);
            this.tabControl1.TabIndex = 4;
            this.tabBarrierBat.BackColor = SystemColors.ButtonFace;
            this.tabBarrierBat.BorderStyle = BorderStyle.Fixed3D;
            this.tabBarrierBat.Controls.Add(this.panelBarrierBat);
            this.tabBarrierBat.Location = new Point(4, 0x16);
            this.tabBarrierBat.Name = "tabBarrierBat";
            this.tabBarrierBat.Padding = new Padding(3);
            this.tabBarrierBat.Size = new Size(0x374, 0x13b);
            this.tabBarrierBat.TabIndex = 0;
            this.tabBarrierBat.Text = "Configuration for Bat File";
            this.panelBarrierBat.Controls.Add(this.groupBox3);
            this.panelBarrierBat.Controls.Add(this.groupBox2);
            this.panelBarrierBat.Location = new Point(5, 5);
            this.panelBarrierBat.Name = "panelBarrierBat";
            this.panelBarrierBat.Size = new Size(0x368, 0x12b);
            this.panelBarrierBat.TabIndex = 2;
            this.groupBox3.Controls.Add(this.label116);
            this.groupBox3.Controls.Add(this.buttonGate2OpenOutFind);
            this.groupBox3.Controls.Add(this.buttonGate1CloseOutFind);
            this.groupBox3.Controls.Add(this.buttonGate2CloseOutFind);
            this.groupBox3.Controls.Add(this.buttonGate1OpenOutFind);
            this.groupBox3.Controls.Add(this.textGate2CloseOut);
            this.groupBox3.Controls.Add(this.tes2Out);
            this.groupBox3.Controls.Add(this.textGate1CloseOut);
            this.groupBox3.Controls.Add(this.tes1Out);
            this.groupBox3.Controls.Add(this.label112);
            this.groupBox3.Controls.Add(this.label114);
            this.groupBox3.Controls.Add(this.textGate2OpenOut);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.label111);
            this.groupBox3.Controls.Add(this.label113);
            this.groupBox3.Controls.Add(this.textGate1OpenOut);
            this.groupBox3.Controls.Add(this.label110);
            this.groupBox3.Location = new Point(440, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(0x1a9, 0xf2);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.label116.AutoSize = true;
            this.label116.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label116.Location = new Point(9, 0x10);
            this.label116.Name = "label116";
            this.label116.Size = new Size(0x4f, 13);
            this.label116.TabIndex = 0x1f;
            this.label116.Text = "TRUCK OUT";
            this.buttonGate2OpenOutFind.Location = new Point(0x17e, 0x99);
            this.buttonGate2OpenOutFind.Name = "buttonGate2OpenOutFind";
            this.buttonGate2OpenOutFind.Size = new Size(0x19, 0x17);
            this.buttonGate2OpenOutFind.TabIndex = 0x20;
            this.buttonGate2OpenOutFind.Text = "...";
            this.buttonGate2OpenOutFind.UseVisualStyleBackColor = true;
            this.buttonGate2OpenOutFind.Click += new EventHandler(this.buttonGate2OpenOutFind_Click);
            this.buttonGate1CloseOutFind.Location = new Point(0x17e, 0x4e);
            this.buttonGate1CloseOutFind.Name = "buttonGate1CloseOutFind";
            this.buttonGate1CloseOutFind.Size = new Size(0x19, 0x17);
            this.buttonGate1CloseOutFind.TabIndex = 0x16;
            this.buttonGate1CloseOutFind.Text = "...";
            this.buttonGate1CloseOutFind.UseVisualStyleBackColor = true;
            this.buttonGate1CloseOutFind.Click += new EventHandler(this.buttonGate1CloseOutFind_Click);
            this.buttonGate2CloseOutFind.Location = new Point(0x17e, 0xb0);
            this.buttonGate2CloseOutFind.Name = "buttonGate2CloseOutFind";
            this.buttonGate2CloseOutFind.Size = new Size(0x19, 0x17);
            this.buttonGate2CloseOutFind.TabIndex = 0x21;
            this.buttonGate2CloseOutFind.Text = "...";
            this.buttonGate2CloseOutFind.UseVisualStyleBackColor = true;
            this.buttonGate2CloseOutFind.Click += new EventHandler(this.button10_Click);
            this.buttonGate1OpenOutFind.Location = new Point(0x17e, 0x37);
            this.buttonGate1OpenOutFind.Name = "buttonGate1OpenOutFind";
            this.buttonGate1OpenOutFind.Size = new Size(0x19, 0x17);
            this.buttonGate1OpenOutFind.TabIndex = 0x15;
            this.buttonGate1OpenOutFind.Text = "...";
            this.buttonGate1OpenOutFind.UseVisualStyleBackColor = true;
            this.buttonGate1OpenOutFind.Click += new EventHandler(this.buttonGate1OpenOutFind_Click);
            this.textGate2CloseOut.Location = new Point(0x59, 0xb2);
            this.textGate2CloseOut.Name = "textGate2CloseOut";
            this.textGate2CloseOut.Size = new Size(290, 20);
            this.textGate2CloseOut.TabIndex = 5;
            this.tes2Out.Location = new Point(0x14c, 0xcc);
            this.tes2Out.Name = "tes2Out";
            this.tes2Out.Size = new Size(0x4b, 0x17);
            this.tes2Out.TabIndex = 0x1d;
            this.tes2Out.Text = "Test Gate 2";
            this.tes2Out.UseVisualStyleBackColor = true;
            this.tes2Out.Click += new EventHandler(this.tes2Out_Click);
            this.textGate1CloseOut.Location = new Point(0x59, 80);
            this.textGate1CloseOut.Name = "textGate1CloseOut";
            this.textGate1CloseOut.Size = new Size(290, 20);
            this.textGate1CloseOut.TabIndex = 4;
            this.tes1Out.Location = new Point(0x14c, 0x6a);
            this.tes1Out.Name = "tes1Out";
            this.tes1Out.Size = new Size(0x4b, 0x17);
            this.tes1Out.TabIndex = 3;
            this.tes1Out.Text = "Test Gate 1";
            this.tes1Out.UseVisualStyleBackColor = true;
            this.tes1Out.Click += new EventHandler(this.tes1Out_Click_1);
            this.label112.AutoSize = true;
            this.label112.Location = new Point(0x15, 0x54);
            this.label112.Name = "label112";
            this.label112.Size = new Size(0x44, 13);
            this.label112.TabIndex = 0x19;
            this.label112.Text = "Gate 1 Close";
            this.label114.AutoSize = true;
            this.label114.Location = new Point(20, 60);
            this.label114.Name = "label114";
            this.label114.Size = new Size(0x44, 13);
            this.label114.TabIndex = 0;
            this.label114.Text = "Gate 1 Open";
            this.textGate2OpenOut.Location = new Point(0x59, 0x9b);
            this.textGate2OpenOut.Name = "textGate2OpenOut";
            this.textGate2OpenOut.Size = new Size(290, 20);
            this.textGate2OpenOut.TabIndex = 3;
            this.label28.AutoSize = true;
            this.label28.Location = new Point(0x15, 0x88);
            this.label28.Name = "label28";
            this.label28.Size = new Size(0x2d, 13);
            this.label28.TabIndex = 0x1c;
            this.label28.Text = "GATE 2";
            this.label111.AutoSize = true;
            this.label111.Location = new Point(20, 0xb6);
            this.label111.Name = "label111";
            this.label111.Size = new Size(0x44, 13);
            this.label111.TabIndex = 0x1a;
            this.label111.Text = "Gate 2 Close";
            this.label113.AutoSize = true;
            this.label113.Location = new Point(20, 0x9e);
            this.label113.Name = "label113";
            this.label113.Size = new Size(0x44, 13);
            this.label113.TabIndex = 1;
            this.label113.Text = "Gate 2 Open";
            this.textGate1OpenOut.Location = new Point(0x59, 0x39);
            this.textGate1OpenOut.Name = "textGate1OpenOut";
            this.textGate1OpenOut.Size = new Size(290, 20);
            this.textGate1OpenOut.TabIndex = 2;
            this.label110.AutoSize = true;
            this.label110.Location = new Point(0x15, 0x27);
            this.label110.Name = "label110";
            this.label110.Size = new Size(0x2d, 13);
            this.label110.TabIndex = 0x1b;
            this.label110.Text = "GATE 1";
            this.groupBox2.Controls.Add(this.label115);
            this.groupBox2.Controls.Add(this.buttonGate2OpenFind);
            this.groupBox2.Controls.Add(this.buttonGate2CloseFind);
            this.groupBox2.Controls.Add(this.buttonGate1CloseFind);
            this.groupBox2.Controls.Add(this.label100);
            this.groupBox2.Controls.Add(this.label93);
            this.groupBox2.Controls.Add(this.buttonGate1OpenFind);
            this.groupBox2.Controls.Add(this.label94);
            this.groupBox2.Controls.Add(this.label99);
            this.groupBox2.Controls.Add(this.textGate2Close);
            this.groupBox2.Controls.Add(this.label87);
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.textGate1Close);
            this.groupBox2.Controls.Add(this.textGate1Open);
            this.groupBox2.Controls.Add(this.label88);
            this.groupBox2.Controls.Add(this.textGate2Open);
            this.groupBox2.Controls.Add(this.btnTes);
            this.groupBox2.Location = new Point(5, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0x1a9, 0xf2);
            this.groupBox2.TabIndex = 0x22;
            this.groupBox2.TabStop = false;
            this.label115.AutoSize = true;
            this.label115.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label115.Location = new Point(9, 0x10);
            this.label115.Name = "label115";
            this.label115.Size = new Size(0x42, 13);
            this.label115.TabIndex = 30;
            this.label115.Text = "TRUCK IN";
            this.buttonGate2OpenFind.Location = new Point(0x17e, 0x99);
            this.buttonGate2OpenFind.Name = "buttonGate2OpenFind";
            this.buttonGate2OpenFind.Size = new Size(0x19, 0x17);
            this.buttonGate2OpenFind.TabIndex = 0x17;
            this.buttonGate2OpenFind.Text = "...";
            this.buttonGate2OpenFind.UseVisualStyleBackColor = true;
            this.buttonGate2OpenFind.Click += new EventHandler(this.buttonGate2OpenFind_Click);
            this.buttonGate2CloseFind.Location = new Point(0x17e, 0xb1);
            this.buttonGate2CloseFind.Name = "buttonGate2CloseFind";
            this.buttonGate2CloseFind.Size = new Size(0x19, 0x17);
            this.buttonGate2CloseFind.TabIndex = 0x18;
            this.buttonGate2CloseFind.Text = "...";
            this.buttonGate2CloseFind.UseVisualStyleBackColor = true;
            this.buttonGate2CloseFind.Click += new EventHandler(this.buttonGate2CloseFind_Click);
            this.buttonGate1CloseFind.Location = new Point(0x17e, 0x4f);
            this.buttonGate1CloseFind.Name = "buttonGate1CloseFind";
            this.buttonGate1CloseFind.Size = new Size(0x19, 0x17);
            this.buttonGate1CloseFind.TabIndex = 0x16;
            this.buttonGate1CloseFind.Text = "...";
            this.buttonGate1CloseFind.UseVisualStyleBackColor = true;
            this.buttonGate1CloseFind.Click += new EventHandler(this.buttonGate1CloseFind_Click);
            this.label100.AutoSize = true;
            this.label100.Location = new Point(20, 0x54);
            this.label100.Name = "label100";
            this.label100.Size = new Size(0x44, 13);
            this.label100.TabIndex = 0x19;
            this.label100.Text = "Gate 1 Close";
            this.label93.AutoSize = true;
            this.label93.Location = new Point(20, 0x3d);
            this.label93.Name = "label93";
            this.label93.Size = new Size(0x44, 13);
            this.label93.TabIndex = 0;
            this.label93.Text = "Gate 1 Open";
            this.buttonGate1OpenFind.Location = new Point(0x17e, 0x38);
            this.buttonGate1OpenFind.Name = "buttonGate1OpenFind";
            this.buttonGate1OpenFind.Size = new Size(0x19, 0x17);
            this.buttonGate1OpenFind.TabIndex = 0x15;
            this.buttonGate1OpenFind.Text = "...";
            this.buttonGate1OpenFind.UseVisualStyleBackColor = true;
            this.buttonGate1OpenFind.Click += new EventHandler(this.button6_Click);
            this.label94.AutoSize = true;
            this.label94.Location = new Point(20, 0x9e);
            this.label94.Name = "label94";
            this.label94.Size = new Size(0x44, 13);
            this.label94.TabIndex = 1;
            this.label94.Text = "Gate 2 Open";
            this.label99.AutoSize = true;
            this.label99.Location = new Point(20, 0xb5);
            this.label99.Name = "label99";
            this.label99.Size = new Size(0x44, 13);
            this.label99.TabIndex = 0x1a;
            this.label99.Text = "Gate 2 Close";
            this.textGate2Close.Location = new Point(0x59, 0xb2);
            this.textGate2Close.Name = "textGate2Close";
            this.textGate2Close.Size = new Size(290, 20);
            this.textGate2Close.TabIndex = 5;
            this.label87.AutoSize = true;
            this.label87.Location = new Point(20, 0x27);
            this.label87.Name = "label87";
            this.label87.Size = new Size(0x2d, 13);
            this.label87.TabIndex = 0x1b;
            this.label87.Text = "GATE 1";
            this.button6.Location = new Point(0x14c, 0xcc);
            this.button6.Name = "button6";
            this.button6.Size = new Size(0x4b, 0x17);
            this.button6.TabIndex = 0x1d;
            this.button6.Text = "Test Gate 2";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new EventHandler(this.button6_Click_2);
            this.textGate1Close.Location = new Point(0x59, 0x51);
            this.textGate1Close.Name = "textGate1Close";
            this.textGate1Close.Size = new Size(290, 20);
            this.textGate1Close.TabIndex = 4;
            this.textGate1Open.Location = new Point(0x59, 0x3a);
            this.textGate1Open.Name = "textGate1Open";
            this.textGate1Open.Size = new Size(290, 20);
            this.textGate1Open.TabIndex = 2;
            this.label88.AutoSize = true;
            this.label88.Location = new Point(20, 0x88);
            this.label88.Name = "label88";
            this.label88.Size = new Size(0x2d, 13);
            this.label88.TabIndex = 0x1c;
            this.label88.Text = "GATE 2";
            this.textGate2Open.Location = new Point(0x59, 0x9b);
            this.textGate2Open.Name = "textGate2Open";
            this.textGate2Open.Size = new Size(290, 20);
            this.textGate2Open.TabIndex = 3;
            this.btnTes.Location = new Point(0x14c, 0x6b);
            this.btnTes.Name = "btnTes";
            this.btnTes.Size = new Size(0x4b, 0x17);
            this.btnTes.TabIndex = 3;
            this.btnTes.Text = "Test Gate 1";
            this.btnTes.UseVisualStyleBackColor = true;
            this.btnTes.Click += new EventHandler(this.button6_Click_1);
            this.tabBarrierIP.BackColor = SystemColors.ButtonFace;
            this.tabBarrierIP.BorderStyle = BorderStyle.Fixed3D;
            this.tabBarrierIP.Controls.Add(this.panelBarrierIP);
            this.tabBarrierIP.Location = new Point(4, 0x16);
            this.tabBarrierIP.Name = "tabBarrierIP";
            this.tabBarrierIP.Padding = new Padding(3);
            this.tabBarrierIP.Size = new Size(0x374, 0x13b);
            this.tabBarrierIP.TabIndex = 1;
            this.tabBarrierIP.Text = "Configuration for IP";
            this.panelBarrierIP.Controls.Add(this.groupBox4);
            this.panelBarrierIP.Controls.Add(this.groupBox5);
            this.panelBarrierIP.Location = new Point(5, 5);
            this.panelBarrierIP.Name = "panelBarrierIP";
            this.panelBarrierIP.Size = new Size(0x368, 0x12b);
            this.panelBarrierIP.TabIndex = 3;
            this.groupBox4.Controls.Add(this.button7);
            this.groupBox4.Controls.Add(this.buttonCloseGateIP4);
            this.groupBox4.Controls.Add(this.button5);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.textBarrierPort4);
            this.groupBox4.Controls.Add(this.buttonCloseGateIP3);
            this.groupBox4.Controls.Add(this.textBarrierIP4);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.labelPort4);
            this.groupBox4.Controls.Add(this.textBarrierPort3);
            this.groupBox4.Controls.Add(this.labelIP4);
            this.groupBox4.Controls.Add(this.textBarrierIP3);
            this.groupBox4.Controls.Add(this.labelPort3);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.buttonOpenGateIP4);
            this.groupBox4.Controls.Add(this.labelIP3);
            this.groupBox4.Controls.Add(this.buttonOpenGateIP3);
            this.groupBox4.Location = new Point(440, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new Size(0x1a9, 0xf2);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.button7.Location = new Point(0x101, 0xd1);
            this.button7.Name = "button7";
            this.button7.Size = new Size(100, 0x17);
            this.button7.TabIndex = 0x23;
            this.button7.Text = "Get Gate 2 Status";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new EventHandler(this.button7_Click);
            this.buttonCloseGateIP4.Location = new Point(0x101, 0xba);
            this.buttonCloseGateIP4.Name = "buttonCloseGateIP4";
            this.buttonCloseGateIP4.Size = new Size(100, 0x17);
            this.buttonCloseGateIP4.TabIndex = 0x30;
            this.buttonCloseGateIP4.Text = "Test Close Gate 2";
            this.buttonCloseGateIP4.UseVisualStyleBackColor = true;
            this.buttonCloseGateIP4.Click += new EventHandler(this.buttonCloseGateIP4_Click);
            this.button5.Location = new Point(0x101, 0x65);
            this.button5.Name = "button5";
            this.button5.Size = new Size(100, 0x17);
            this.button5.TabIndex = 0x22;
            this.button5.Text = "Get Gate 1 Status";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new EventHandler(this.button5_Click);
            this.label19.AutoSize = true;
            this.label19.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label19.Location = new Point(9, 0x10);
            this.label19.Name = "label19";
            this.label19.Size = new Size(0x4f, 13);
            this.label19.TabIndex = 0x1f;
            this.label19.Text = "TRUCK OUT";
            this.textBarrierPort4.Location = new Point(0x59, 0xbc);
            this.textBarrierPort4.Name = "textBarrierPort4";
            this.textBarrierPort4.Size = new Size(0x3f, 20);
            this.textBarrierPort4.TabIndex = 0x2c;
            this.buttonCloseGateIP3.Location = new Point(0x101, 0x4e);
            this.buttonCloseGateIP3.Name = "buttonCloseGateIP3";
            this.buttonCloseGateIP3.Size = new Size(100, 0x17);
            this.buttonCloseGateIP3.TabIndex = 0x2f;
            this.buttonCloseGateIP3.Text = "Test Close Gate 1";
            this.buttonCloseGateIP3.UseVisualStyleBackColor = true;
            this.buttonCloseGateIP3.Click += new EventHandler(this.buttonCloseGateIP3_Click);
            this.textBarrierIP4.Location = new Point(0x59, 0xa5);
            this.textBarrierIP4.Name = "textBarrierIP4";
            this.textBarrierIP4.Size = new Size(0x99, 20);
            this.textBarrierIP4.TabIndex = 0x2b;
            this.label23.AutoSize = true;
            this.label23.Location = new Point(0x15, 0x92);
            this.label23.Name = "label23";
            this.label23.Size = new Size(0x2d, 13);
            this.label23.TabIndex = 0x1c;
            this.label23.Text = "GATE 2";
            this.labelPort4.AutoSize = true;
            this.labelPort4.Location = new Point(0x15, 0xbf);
            this.labelPort4.Name = "labelPort4";
            this.labelPort4.Size = new Size(0x1a, 13);
            this.labelPort4.TabIndex = 0x2a;
            this.labelPort4.Text = "Port";
            this.textBarrierPort3.Location = new Point(0x59, 80);
            this.textBarrierPort3.Name = "textBarrierPort3";
            this.textBarrierPort3.Size = new Size(0x3f, 20);
            this.textBarrierPort3.TabIndex = 40;
            this.labelIP4.AutoSize = true;
            this.labelIP4.Location = new Point(0x15, 0xa8);
            this.labelIP4.Name = "labelIP4";
            this.labelIP4.Size = new Size(0x3a, 13);
            this.labelIP4.TabIndex = 0x29;
            this.labelIP4.Text = "IP Address";
            this.textBarrierIP3.Location = new Point(0x59, 0x39);
            this.textBarrierIP3.Name = "textBarrierIP3";
            this.textBarrierIP3.Size = new Size(0x99, 20);
            this.textBarrierIP3.TabIndex = 0x27;
            this.labelPort3.AutoSize = true;
            this.labelPort3.Location = new Point(0x15, 0x53);
            this.labelPort3.Name = "labelPort3";
            this.labelPort3.Size = new Size(0x1a, 13);
            this.labelPort3.TabIndex = 0x26;
            this.labelPort3.Text = "Port";
            this.label26.AutoSize = true;
            this.label26.Location = new Point(0x15, 0x27);
            this.label26.Name = "label26";
            this.label26.Size = new Size(0x2d, 13);
            this.label26.TabIndex = 0x1b;
            this.label26.Text = "GATE 1";
            this.buttonOpenGateIP4.Location = new Point(0x101, 0xa3);
            this.buttonOpenGateIP4.Name = "buttonOpenGateIP4";
            this.buttonOpenGateIP4.Size = new Size(100, 0x17);
            this.buttonOpenGateIP4.TabIndex = 0x1d;
            this.buttonOpenGateIP4.Text = "Test Open Gate 2";
            this.buttonOpenGateIP4.UseVisualStyleBackColor = true;
            this.buttonOpenGateIP4.Click += new EventHandler(this.buttonOpenGateIP4_Click);
            this.labelIP3.AutoSize = true;
            this.labelIP3.Location = new Point(0x15, 60);
            this.labelIP3.Name = "labelIP3";
            this.labelIP3.Size = new Size(0x3a, 13);
            this.labelIP3.TabIndex = 0x25;
            this.labelIP3.Text = "IP Address";
            this.buttonOpenGateIP3.Location = new Point(0x101, 0x37);
            this.buttonOpenGateIP3.Name = "buttonOpenGateIP3";
            this.buttonOpenGateIP3.Size = new Size(100, 0x17);
            this.buttonOpenGateIP3.TabIndex = 3;
            this.buttonOpenGateIP3.Text = "Test Open Gate 1";
            this.buttonOpenGateIP3.UseVisualStyleBackColor = true;
            this.buttonOpenGateIP3.Click += new EventHandler(this.buttonOpenGateIP3_Click);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.button8);
            this.groupBox5.Controls.Add(this.buttonCloseGateIP1);
            this.groupBox5.Controls.Add(this.buttonCloseGateIP2);
            this.groupBox5.Controls.Add(this.button9);
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.textBarrierIP1);
            this.groupBox5.Controls.Add(this.labelPort1);
            this.groupBox5.Controls.Add(this.textBarrierPort1);
            this.groupBox5.Controls.Add(this.labelIP1);
            this.groupBox5.Controls.Add(this.buttonOpenGateIP1);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.textBarrierIP2);
            this.groupBox5.Controls.Add(this.buttonOpenGateIP2);
            this.groupBox5.Controls.Add(this.textBarrierPort2);
            this.groupBox5.Location = new Point(5, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new Size(0x1a9, 0xf2);
            this.groupBox5.TabIndex = 0x22;
            this.groupBox5.TabStop = false;
            this.label27.AutoSize = true;
            this.label27.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label27.Location = new Point(9, 0x10);
            this.label27.Name = "label27";
            this.label27.Size = new Size(0x42, 13);
            this.label27.TabIndex = 30;
            this.label27.Text = "TRUCK IN";
            this.button8.Location = new Point(260, 0xd1);
            this.button8.Name = "button8";
            this.button8.Size = new Size(100, 0x17);
            this.button8.TabIndex = 0x24;
            this.button8.Text = "Get Gate 2 Status";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new EventHandler(this.button8_Click);
            this.buttonCloseGateIP1.Location = new Point(260, 0x4e);
            this.buttonCloseGateIP1.Name = "buttonCloseGateIP1";
            this.buttonCloseGateIP1.Size = new Size(100, 0x17);
            this.buttonCloseGateIP1.TabIndex = 0x2d;
            this.buttonCloseGateIP1.Text = "Test Close Gate 1";
            this.buttonCloseGateIP1.UseVisualStyleBackColor = true;
            this.buttonCloseGateIP1.Click += new EventHandler(this.buttonCloseGateIP1_Click);
            this.buttonCloseGateIP2.Location = new Point(260, 0xba);
            this.buttonCloseGateIP2.Name = "buttonCloseGateIP2";
            this.buttonCloseGateIP2.Size = new Size(100, 0x17);
            this.buttonCloseGateIP2.TabIndex = 0x2e;
            this.buttonCloseGateIP2.Text = "Test Close Gate 2";
            this.buttonCloseGateIP2.UseVisualStyleBackColor = true;
            this.buttonCloseGateIP2.Click += new EventHandler(this.buttonCloseGateIP2_Click);
            this.button9.Location = new Point(260, 0x65);
            this.button9.Name = "button9";
            this.button9.Size = new Size(100, 0x17);
            this.button9.TabIndex = 0x25;
            this.button9.Text = "Get Gate 1 Status";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new EventHandler(this.button9_Click);
            this.label34.AutoSize = true;
            this.label34.Location = new Point(20, 0x27);
            this.label34.Name = "label34";
            this.label34.Size = new Size(0x2d, 13);
            this.label34.TabIndex = 0x1b;
            this.label34.Text = "GATE 1";
            this.label35.AutoSize = true;
            this.label35.Location = new Point(20, 0x92);
            this.label35.Name = "label35";
            this.label35.Size = new Size(0x2d, 13);
            this.label35.TabIndex = 0x1c;
            this.label35.Text = "GATE 2";
            this.textBarrierIP1.Location = new Point(0x59, 0x39);
            this.textBarrierIP1.Name = "textBarrierIP1";
            this.textBarrierIP1.Size = new Size(0x99, 20);
            this.textBarrierIP1.TabIndex = 2;
            this.labelPort1.AutoSize = true;
            this.labelPort1.Location = new Point(20, 0x53);
            this.labelPort1.Name = "labelPort1";
            this.labelPort1.Size = new Size(0x1a, 13);
            this.labelPort1.TabIndex = 1;
            this.labelPort1.Text = "Port";
            this.textBarrierPort1.Location = new Point(0x59, 80);
            this.textBarrierPort1.Name = "textBarrierPort1";
            this.textBarrierPort1.Size = new Size(0x3f, 20);
            this.textBarrierPort1.TabIndex = 3;
            this.labelIP1.AutoSize = true;
            this.labelIP1.Location = new Point(20, 60);
            this.labelIP1.Name = "labelIP1";
            this.labelIP1.Size = new Size(0x3a, 13);
            this.labelIP1.TabIndex = 0;
            this.labelIP1.Text = "IP Address";
            this.buttonOpenGateIP1.Location = new Point(260, 0x37);
            this.buttonOpenGateIP1.Name = "buttonOpenGateIP1";
            this.buttonOpenGateIP1.Size = new Size(100, 0x17);
            this.buttonOpenGateIP1.TabIndex = 3;
            this.buttonOpenGateIP1.Text = "Test Open Gate 1";
            this.buttonOpenGateIP1.UseVisualStyleBackColor = true;
            this.buttonOpenGateIP1.Click += new EventHandler(this.buttonOpenGateIP1_Click);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(20, 0xa8);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x3a, 13);
            this.label3.TabIndex = 0x21;
            this.label3.Text = "IP Address";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x15, 0xbf);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x1a, 13);
            this.label2.TabIndex = 0x22;
            this.label2.Text = "Port";
            this.textBarrierIP2.Location = new Point(0x59, 0xa5);
            this.textBarrierIP2.Name = "textBarrierIP2";
            this.textBarrierIP2.Size = new Size(0x99, 20);
            this.textBarrierIP2.TabIndex = 0x23;
            this.buttonOpenGateIP2.Location = new Point(260, 0xa3);
            this.buttonOpenGateIP2.Name = "buttonOpenGateIP2";
            this.buttonOpenGateIP2.Size = new Size(100, 0x17);
            this.buttonOpenGateIP2.TabIndex = 0x1d;
            this.buttonOpenGateIP2.Text = "Test Open Gate 2";
            this.buttonOpenGateIP2.UseVisualStyleBackColor = true;
            this.buttonOpenGateIP2.Click += new EventHandler(this.buttonOpenGateIP2_Click);
            this.textBarrierPort2.Location = new Point(0x59, 0xbc);
            this.textBarrierPort2.Name = "textBarrierPort2";
            this.textBarrierPort2.Size = new Size(0x3f, 20);
            this.textBarrierPort2.TabIndex = 0x24;
            this.groupBox1.Controls.Add(this.comboBarrier);
            this.groupBox1.Controls.Add(this.rboNo);
            this.groupBox1.Controls.Add(this.rboYes);
            this.groupBox1.Location = new Point(0x15, 0x15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(370, 0x37);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Barrier Gate";
            this.comboBarrier.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboBarrier.FormattingEnabled = true;
            this.comboBarrier.Location = new Point(0x88, 20);
            this.comboBarrier.Name = "comboBarrier";
            this.comboBarrier.Size = new Size(0xcc, 0x15);
            this.comboBarrier.TabIndex = 4;
            this.comboBarrier.SelectedIndexChanged += new EventHandler(this.comboBarrier_SelectedIndexChanged);
            this.rboNo.AutoSize = true;
            this.rboNo.Checked = true;
            this.rboNo.Location = new Point(20, 0x15);
            this.rboNo.Name = "rboNo";
            this.rboNo.Size = new Size(0x27, 0x11);
            this.rboNo.TabIndex = 3;
            this.rboNo.TabStop = true;
            this.rboNo.Text = "No";
            this.rboNo.UseVisualStyleBackColor = true;
            this.rboNo.CheckedChanged += new EventHandler(this.rboNo_CheckedChanged);
            this.rboYes.AutoSize = true;
            this.rboYes.Location = new Point(0x56, 0x15);
            this.rboYes.Name = "rboYes";
            this.rboYes.Size = new Size(0x2b, 0x11);
            this.rboYes.TabIndex = 1;
            this.rboYes.Text = "Yes";
            this.rboYes.UseVisualStyleBackColor = true;
            this.rboYes.CheckedChanged += new EventHandler(this.rboYes_CheckedChanged);
            this.tab_camera.BackColor = SystemColors.ButtonFace;
            this.tab_camera.BorderStyle = BorderStyle.Fixed3D;
            this.tab_camera.Controls.Add(this.groupBox6);
            this.tab_camera.Controls.Add(this.gb_cam5);
            this.tab_camera.Controls.Add(this.gb_cam4);
            this.tab_camera.Controls.Add(this.gb_cam3);
            this.tab_camera.Controls.Add(this.gb_cam2);
            this.tab_camera.Controls.Add(this.gb_cam1);
            this.tab_camera.Controls.Add(this.gb_enable_camera);
            this.tab_camera.Location = new Point(4, 0x16);
            this.tab_camera.Name = "tab_camera";
            this.tab_camera.Padding = new Padding(3);
            this.tab_camera.Size = new Size(0x3a7, 0x1e2);
            this.tab_camera.TabIndex = 7;
            this.tab_camera.Text = "Camera";
            this.textBackupPathPhotos.Location = new Point(0xab, 110);
            this.textBackupPathPhotos.Name = "textBackupPathPhotos";
            this.textBackupPathPhotos.Size = new Size(270, 20);
            this.textBackupPathPhotos.TabIndex = 0x4b;
            this.lblBackupCameraPath.AutoSize = true;
            this.lblBackupCameraPath.Location = new Point(0x1a, 0x71);
            this.lblBackupCameraPath.Name = "lblBackupCameraPath";
            this.lblBackupCameraPath.Size = new Size(110, 13);
            this.lblBackupCameraPath.TabIndex = 0x4a;
            this.lblBackupCameraPath.Text = "Backup / Local folder";
            this.groupBox6.Controls.Add(this.lblBackupCameraPath);
            this.groupBox6.Controls.Add(this.textBackupPathPhotos);
            this.groupBox6.Controls.Add(this.button11);
            this.groupBox6.Controls.Add(this.textPathPhotosServer);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.btnBrowseBackupPathPhotos);
            this.groupBox6.Controls.Add(this.textPasswordFolder);
            this.groupBox6.Controls.Add(this.label1);
            this.groupBox6.Controls.Add(this.textUsernameFolder);
            this.groupBox6.Controls.Add(this.button10);
            this.groupBox6.Controls.Add(this.labelDestFolder);
            this.groupBox6.Controls.Add(this.labelPassword);
            this.groupBox6.Controls.Add(this.textPathPhotos);
            this.groupBox6.Controls.Add(this.textDomainFolder);
            this.groupBox6.Controls.Add(this.labelDomainUsername);
            this.groupBox6.Location = new Point(0x10d, 0x15);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new Size(0x283, 0x94);
            this.groupBox6.TabIndex = 4;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Stored Photos Folder";
            this.button11.Location = new Point(0x1bf, 15);
            this.button11.Name = "button11";
            this.button11.Size = new Size(0x73, 0x17);
            this.button11.TabIndex = 0x4c;
            this.button11.Text = "Check Server Path";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new EventHandler(this.button11_Click);
            this.textPathPhotosServer.Location = new Point(0xab, 0x11);
            this.textPathPhotosServer.Name = "textPathPhotosServer";
            this.textPathPhotosServer.Size = new Size(270, 20);
            this.textPathPhotosServer.TabIndex = 0x4b;
            this.label18.AutoSize = true;
            this.label18.Location = new Point(0x1a, 0x2c);
            this.label18.Name = "label18";
            this.label18.Size = new Size(0x72, 13);
            this.label18.TabIndex = 0x4a;
            this.label18.Text = "Client Destination Path";
            this.btnBrowseBackupPathPhotos.Location = new Point(0x1bf, 0x6c);
            this.btnBrowseBackupPathPhotos.Name = "btnBrowseBackupPathPhotos";
            this.btnBrowseBackupPathPhotos.Size = new Size(30, 0x16);
            this.btnBrowseBackupPathPhotos.TabIndex = 0x4a;
            this.btnBrowseBackupPathPhotos.Text = "...";
            this.btnBrowseBackupPathPhotos.UseVisualStyleBackColor = true;
            this.btnBrowseBackupPathPhotos.Click += new EventHandler(this.btnBrowseBackupPathPhotos_Click);
            this.textPasswordFolder.Location = new Point(0xab, 0x57);
            this.textPasswordFolder.Name = "textPasswordFolder";
            this.textPasswordFolder.Size = new Size(0x7d, 20);
            this.textPasswordFolder.TabIndex = 0x49;
            this.textPasswordFolder.UseSystemPasswordChar = true;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(300, 0x43);
            this.label1.Name = "label1";
            this.label1.Size = new Size(12, 13);
            this.label1.TabIndex = 0x48;
            this.label1.Text = "/";
            this.textUsernameFolder.Location = new Point(0x13c, 0x40);
            this.textUsernameFolder.Name = "textUsernameFolder";
            this.textUsernameFolder.Size = new Size(0x7d, 20);
            this.textUsernameFolder.TabIndex = 0x47;
            this.button10.Location = new Point(0x1bf, 0x27);
            this.button10.Name = "button10";
            this.button10.Size = new Size(0x73, 0x17);
            this.button10.TabIndex = 70;
            this.button10.Text = "Check Client Path";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new EventHandler(this.button10_Click_1);
            this.labelDestFolder.AutoSize = true;
            this.labelDestFolder.Location = new Point(0x1a, 20);
            this.labelDestFolder.Name = "labelDestFolder";
            this.labelDestFolder.Size = new Size(0x77, 13);
            this.labelDestFolder.TabIndex = 2;
            this.labelDestFolder.Text = "Server Destination Path";
            this.labelPassword.AutoSize = true;
            this.labelPassword.Location = new Point(0x1a, 90);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new Size(0x35, 13);
            this.labelPassword.TabIndex = 0x44;
            this.labelPassword.Text = "Password";
            this.textPathPhotos.Location = new Point(0xab, 0x29);
            this.textPathPhotos.Name = "textPathPhotos";
            this.textPathPhotos.Size = new Size(270, 20);
            this.textPathPhotos.TabIndex = 0x3d;
            this.textDomainFolder.Location = new Point(0xab, 0x40);
            this.textDomainFolder.Name = "textDomainFolder";
            this.textDomainFolder.Size = new Size(0x7d, 20);
            this.textDomainFolder.TabIndex = 0x40;
            this.labelDomainUsername.AutoSize = true;
            this.labelDomainUsername.Location = new Point(0x1a, 0x43);
            this.labelDomainUsername.Name = "labelDomainUsername";
            this.labelDomainUsername.Size = new Size(0x66, 13);
            this.labelDomainUsername.TabIndex = 0x42;
            this.labelDomainUsername.Text = "Domain / Username";
            this.gb_cam5.Controls.Add(this.panel5);
            this.gb_cam5.Controls.Add(this.cb_cam5);
            this.gb_cam5.Location = new Point(320, 0x143);
            this.gb_cam5.Name = "gb_cam5";
            this.gb_cam5.Size = new Size(0x125, 150);
            this.gb_cam5.TabIndex = 8;
            this.gb_cam5.TabStop = false;
            this.panel5.Controls.Add(this.btn_tes_cam5);
            this.panel5.Controls.Add(this.label17);
            this.panel5.Controls.Add(this.combo_cam5_ip);
            this.panel5.Controls.Add(this.rb_cam5_web);
            this.panel5.Controls.Add(this.combo_cam5_web);
            this.panel5.Controls.Add(this.rb_cam5_ip);
            this.panel5.Location = new Point(6, 0x27);
            this.panel5.Name = "panel5";
            this.panel5.Size = new Size(280, 0x69);
            this.panel5.TabIndex = 10;
            this.btn_tes_cam5.Location = new Point(0xb5, 0x4a);
            this.btn_tes_cam5.Name = "btn_tes_cam5";
            this.btn_tes_cam5.Size = new Size(90, 0x17);
            this.btn_tes_cam5.TabIndex = 4;
            this.btn_tes_cam5.Text = "Test Capture";
            this.btn_tes_cam5.UseVisualStyleBackColor = true;
            this.btn_tes_cam5.Click += new EventHandler(this.btn_tes_cam5_Click);
            this.label17.AutoSize = true;
            this.label17.Location = new Point(8, 4);
            this.label17.Name = "label17";
            this.label17.Size = new Size(0x54, 13);
            this.label17.TabIndex = 1;
            this.label17.Text = "Choose camera:";
            this.combo_cam5_ip.DropDownStyle = ComboBoxStyle.DropDownList;
            this.combo_cam5_ip.FormattingEnabled = true;
            this.combo_cam5_ip.Location = new Point(0x6f, 0x2f);
            this.combo_cam5_ip.Name = "combo_cam5_ip";
            this.combo_cam5_ip.Size = new Size(160, 0x15);
            this.combo_cam5_ip.TabIndex = 5;
            this.rb_cam5_web.AutoSize = true;
            this.rb_cam5_web.Location = new Point(11, 0x17);
            this.rb_cam5_web.Name = "rb_cam5_web";
            this.rb_cam5_web.Size = new Size(0x57, 0x11);
            this.rb_cam5_web.TabIndex = 2;
            this.rb_cam5_web.Text = "Web Camera";
            this.rb_cam5_web.UseVisualStyleBackColor = true;
            this.rb_cam5_web.CheckedChanged += new EventHandler(this.rb_cam5_web_CheckedChanged);
            this.combo_cam5_web.DropDownStyle = ComboBoxStyle.DropDownList;
            this.combo_cam5_web.FormattingEnabled = true;
            this.combo_cam5_web.Location = new Point(0x6f, 0x16);
            this.combo_cam5_web.Name = "combo_cam5_web";
            this.combo_cam5_web.Size = new Size(160, 0x15);
            this.combo_cam5_web.TabIndex = 4;
            this.rb_cam5_ip.AutoSize = true;
            this.rb_cam5_ip.Checked = true;
            this.rb_cam5_ip.Location = new Point(11, 0x30);
            this.rb_cam5_ip.Name = "rb_cam5_ip";
            this.rb_cam5_ip.Size = new Size(0x4a, 0x11);
            this.rb_cam5_ip.TabIndex = 3;
            this.rb_cam5_ip.TabStop = true;
            this.rb_cam5_ip.Text = "IP Camera";
            this.rb_cam5_ip.UseVisualStyleBackColor = true;
            this.rb_cam5_ip.CheckedChanged += new EventHandler(this.rb_cam5_ip_CheckedChanged);
            this.cb_cam5.AutoSize = true;
            this.cb_cam5.Location = new Point(0x11, 0x12);
            this.cb_cam5.Name = "cb_cam5";
            this.cb_cam5.Size = new Size(0x6b, 0x11);
            this.cb_cam5.TabIndex = 0;
            this.cb_cam5.Text = "Enable Camera 5";
            this.cb_cam5.UseVisualStyleBackColor = true;
            this.cb_cam5.CheckedChanged += new EventHandler(this.cb_cam5_CheckedChanged);
            this.gb_cam4.Controls.Add(this.panel4);
            this.gb_cam4.Controls.Add(this.cb_cam4);
            this.gb_cam4.Location = new Point(0x15, 0x143);
            this.gb_cam4.Name = "gb_cam4";
            this.gb_cam4.Size = new Size(0x125, 150);
            this.gb_cam4.TabIndex = 7;
            this.gb_cam4.TabStop = false;
            this.panel4.Controls.Add(this.btn_tes_cam4);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.combo_cam4_ip);
            this.panel4.Controls.Add(this.rb_cam4_web);
            this.panel4.Controls.Add(this.combo_cam4_web);
            this.panel4.Controls.Add(this.rb_cam4_ip);
            this.panel4.Location = new Point(6, 0x27);
            this.panel4.Name = "panel4";
            this.panel4.Size = new Size(280, 0x69);
            this.panel4.TabIndex = 10;
            this.btn_tes_cam4.Location = new Point(0xb5, 0x4a);
            this.btn_tes_cam4.Name = "btn_tes_cam4";
            this.btn_tes_cam4.Size = new Size(90, 0x17);
            this.btn_tes_cam4.TabIndex = 4;
            this.btn_tes_cam4.Text = "Test Capture";
            this.btn_tes_cam4.UseVisualStyleBackColor = true;
            this.btn_tes_cam4.Click += new EventHandler(this.btn_tes_cam4_Click);
            this.label5.AutoSize = true;
            this.label5.Location = new Point(8, 4);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x54, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Choose camera:";
            this.combo_cam4_ip.DropDownStyle = ComboBoxStyle.DropDownList;
            this.combo_cam4_ip.FormattingEnabled = true;
            this.combo_cam4_ip.Location = new Point(0x6f, 0x2f);
            this.combo_cam4_ip.Name = "combo_cam4_ip";
            this.combo_cam4_ip.Size = new Size(160, 0x15);
            this.combo_cam4_ip.TabIndex = 5;
            this.rb_cam4_web.AutoSize = true;
            this.rb_cam4_web.Location = new Point(11, 0x17);
            this.rb_cam4_web.Name = "rb_cam4_web";
            this.rb_cam4_web.Size = new Size(0x57, 0x11);
            this.rb_cam4_web.TabIndex = 2;
            this.rb_cam4_web.Text = "Web Camera";
            this.rb_cam4_web.UseVisualStyleBackColor = true;
            this.rb_cam4_web.CheckedChanged += new EventHandler(this.rb_cam4_web_CheckedChanged);
            this.combo_cam4_web.DropDownStyle = ComboBoxStyle.DropDownList;
            this.combo_cam4_web.FormattingEnabled = true;
            this.combo_cam4_web.Location = new Point(0x6f, 0x16);
            this.combo_cam4_web.Name = "combo_cam4_web";
            this.combo_cam4_web.Size = new Size(160, 0x15);
            this.combo_cam4_web.TabIndex = 4;
            this.rb_cam4_ip.AutoSize = true;
            this.rb_cam4_ip.Checked = true;
            this.rb_cam4_ip.Location = new Point(11, 0x30);
            this.rb_cam4_ip.Name = "rb_cam4_ip";
            this.rb_cam4_ip.Size = new Size(0x4a, 0x11);
            this.rb_cam4_ip.TabIndex = 3;
            this.rb_cam4_ip.TabStop = true;
            this.rb_cam4_ip.Text = "IP Camera";
            this.rb_cam4_ip.UseVisualStyleBackColor = true;
            this.rb_cam4_ip.CheckedChanged += new EventHandler(this.rb_cam4_ip_CheckedChanged);
            this.cb_cam4.AutoSize = true;
            this.cb_cam4.Location = new Point(0x11, 0x12);
            this.cb_cam4.Name = "cb_cam4";
            this.cb_cam4.Size = new Size(0x6b, 0x11);
            this.cb_cam4.TabIndex = 0;
            this.cb_cam4.Text = "Enable Camera 4";
            this.cb_cam4.UseVisualStyleBackColor = true;
            this.cb_cam4.CheckedChanged += new EventHandler(this.cb_cam4_CheckedChanged);
            this.gb_cam3.Controls.Add(this.panel3);
            this.gb_cam3.Controls.Add(this.cb_cam3);
            this.gb_cam3.Location = new Point(0x26b, 0xa8);
            this.gb_cam3.Name = "gb_cam3";
            this.gb_cam3.Size = new Size(0x125, 150);
            this.gb_cam3.TabIndex = 6;
            this.gb_cam3.TabStop = false;
            this.panel3.Controls.Add(this.btn_tes_cam3);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.combo_cam3_ip);
            this.panel3.Controls.Add(this.rb_cam3_web);
            this.panel3.Controls.Add(this.combo_cam3_web);
            this.panel3.Controls.Add(this.rb_cam3_ip);
            this.panel3.Location = new Point(7, 0x27);
            this.panel3.Name = "panel3";
            this.panel3.Size = new Size(280, 0x69);
            this.panel3.TabIndex = 10;
            this.btn_tes_cam3.Location = new Point(180, 0x4a);
            this.btn_tes_cam3.Name = "btn_tes_cam3";
            this.btn_tes_cam3.Size = new Size(90, 0x17);
            this.btn_tes_cam3.TabIndex = 4;
            this.btn_tes_cam3.Text = "Test Capture";
            this.btn_tes_cam3.UseVisualStyleBackColor = true;
            this.btn_tes_cam3.Click += new EventHandler(this.btn_tes_cam3_Click);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(7, 4);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x54, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Choose camera:";
            this.combo_cam3_ip.DropDownStyle = ComboBoxStyle.DropDownList;
            this.combo_cam3_ip.FormattingEnabled = true;
            this.combo_cam3_ip.Location = new Point(110, 0x2f);
            this.combo_cam3_ip.Name = "combo_cam3_ip";
            this.combo_cam3_ip.Size = new Size(160, 0x15);
            this.combo_cam3_ip.TabIndex = 5;
            this.rb_cam3_web.AutoSize = true;
            this.rb_cam3_web.Location = new Point(10, 0x17);
            this.rb_cam3_web.Name = "rb_cam3_web";
            this.rb_cam3_web.Size = new Size(0x57, 0x11);
            this.rb_cam3_web.TabIndex = 2;
            this.rb_cam3_web.Text = "Web Camera";
            this.rb_cam3_web.UseVisualStyleBackColor = true;
            this.rb_cam3_web.CheckedChanged += new EventHandler(this.rb_cam3_web_CheckedChanged);
            this.combo_cam3_web.DropDownStyle = ComboBoxStyle.DropDownList;
            this.combo_cam3_web.FormattingEnabled = true;
            this.combo_cam3_web.Location = new Point(110, 0x16);
            this.combo_cam3_web.Name = "combo_cam3_web";
            this.combo_cam3_web.Size = new Size(160, 0x15);
            this.combo_cam3_web.TabIndex = 4;
            this.rb_cam3_ip.AutoSize = true;
            this.rb_cam3_ip.Checked = true;
            this.rb_cam3_ip.Location = new Point(10, 0x30);
            this.rb_cam3_ip.Name = "rb_cam3_ip";
            this.rb_cam3_ip.Size = new Size(0x4a, 0x11);
            this.rb_cam3_ip.TabIndex = 3;
            this.rb_cam3_ip.TabStop = true;
            this.rb_cam3_ip.Text = "IP Camera";
            this.rb_cam3_ip.UseVisualStyleBackColor = true;
            this.rb_cam3_ip.CheckedChanged += new EventHandler(this.rb_cam3_ip_CheckedChanged);
            this.cb_cam3.AutoSize = true;
            this.cb_cam3.Location = new Point(0x11, 0x12);
            this.cb_cam3.Name = "cb_cam3";
            this.cb_cam3.Size = new Size(0x6b, 0x11);
            this.cb_cam3.TabIndex = 0;
            this.cb_cam3.Text = "Enable Camera 3";
            this.cb_cam3.UseVisualStyleBackColor = true;
            this.cb_cam3.CheckedChanged += new EventHandler(this.cb_cam3_CheckedChanged);
            this.gb_cam2.Controls.Add(this.panel2);
            this.gb_cam2.Controls.Add(this.cb_cam2);
            this.gb_cam2.Location = new Point(320, 0xa8);
            this.gb_cam2.Name = "gb_cam2";
            this.gb_cam2.Size = new Size(0x125, 150);
            this.gb_cam2.TabIndex = 4;
            this.gb_cam2.TabStop = false;
            this.panel2.Controls.Add(this.btn_tes_cam2);
            this.panel2.Controls.Add(this.label119);
            this.panel2.Controls.Add(this.combo_cam2_ip);
            this.panel2.Controls.Add(this.rb_cam2_web);
            this.panel2.Controls.Add(this.combo_cam2_web);
            this.panel2.Controls.Add(this.rb_cam2_ip);
            this.panel2.Location = new Point(6, 0x27);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(280, 0x69);
            this.panel2.TabIndex = 10;
            this.btn_tes_cam2.Location = new Point(0xb5, 0x4a);
            this.btn_tes_cam2.Name = "btn_tes_cam2";
            this.btn_tes_cam2.Size = new Size(90, 0x17);
            this.btn_tes_cam2.TabIndex = 4;
            this.btn_tes_cam2.Text = "Test Capture";
            this.btn_tes_cam2.UseVisualStyleBackColor = true;
            this.btn_tes_cam2.Click += new EventHandler(this.btn_tes_cam2_Click);
            this.label119.AutoSize = true;
            this.label119.Location = new Point(8, 4);
            this.label119.Name = "label119";
            this.label119.Size = new Size(0x54, 13);
            this.label119.TabIndex = 1;
            this.label119.Text = "Choose camera:";
            this.combo_cam2_ip.DropDownStyle = ComboBoxStyle.DropDownList;
            this.combo_cam2_ip.FormattingEnabled = true;
            this.combo_cam2_ip.Location = new Point(0x6f, 0x2f);
            this.combo_cam2_ip.Name = "combo_cam2_ip";
            this.combo_cam2_ip.Size = new Size(160, 0x15);
            this.combo_cam2_ip.TabIndex = 5;
            this.rb_cam2_web.AutoSize = true;
            this.rb_cam2_web.Location = new Point(11, 0x17);
            this.rb_cam2_web.Name = "rb_cam2_web";
            this.rb_cam2_web.Size = new Size(0x57, 0x11);
            this.rb_cam2_web.TabIndex = 2;
            this.rb_cam2_web.Text = "Web Camera";
            this.rb_cam2_web.UseVisualStyleBackColor = true;
            this.rb_cam2_web.CheckedChanged += new EventHandler(this.rb_cam2_web_CheckedChanged);
            this.combo_cam2_web.DropDownStyle = ComboBoxStyle.DropDownList;
            this.combo_cam2_web.FormattingEnabled = true;
            this.combo_cam2_web.Location = new Point(0x6f, 0x16);
            this.combo_cam2_web.Name = "combo_cam2_web";
            this.combo_cam2_web.Size = new Size(160, 0x15);
            this.combo_cam2_web.TabIndex = 4;
            this.rb_cam2_ip.AutoSize = true;
            this.rb_cam2_ip.Checked = true;
            this.rb_cam2_ip.Location = new Point(11, 0x30);
            this.rb_cam2_ip.Name = "rb_cam2_ip";
            this.rb_cam2_ip.Size = new Size(0x4a, 0x11);
            this.rb_cam2_ip.TabIndex = 3;
            this.rb_cam2_ip.TabStop = true;
            this.rb_cam2_ip.Text = "IP Camera";
            this.rb_cam2_ip.UseVisualStyleBackColor = true;
            this.rb_cam2_ip.CheckedChanged += new EventHandler(this.rb_cam2_ip_CheckedChanged);
            this.cb_cam2.AutoSize = true;
            this.cb_cam2.Location = new Point(0x11, 0x12);
            this.cb_cam2.Name = "cb_cam2";
            this.cb_cam2.Size = new Size(0x6b, 0x11);
            this.cb_cam2.TabIndex = 0;
            this.cb_cam2.Text = "Enable Camera 2";
            this.cb_cam2.UseVisualStyleBackColor = true;
            this.cb_cam2.CheckedChanged += new EventHandler(this.cb_cam2_CheckedChanged);
            this.gb_cam1.Controls.Add(this.panel1);
            this.gb_cam1.Controls.Add(this.label98);
            this.gb_cam1.Controls.Add(this.cb_cam1);
            this.gb_cam1.Location = new Point(0x15, 0xa8);
            this.gb_cam1.Name = "gb_cam1";
            this.gb_cam1.Size = new Size(0x125, 150);
            this.gb_cam1.TabIndex = 3;
            this.gb_cam1.TabStop = false;
            this.panel1.Controls.Add(this.label120);
            this.panel1.Controls.Add(this.btn_tes_cam1);
            this.panel1.Controls.Add(this.rb_cam1_web);
            this.panel1.Controls.Add(this.combo_cam1_ip);
            this.panel1.Controls.Add(this.rb_cam1_ip);
            this.panel1.Controls.Add(this.combo_cam1_web);
            this.panel1.Location = new Point(6, 0x27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(280, 0x69);
            this.panel1.TabIndex = 9;
            this.label120.AutoSize = true;
            this.label120.Location = new Point(8, 4);
            this.label120.Name = "label120";
            this.label120.Size = new Size(0x54, 13);
            this.label120.TabIndex = 0x41;
            this.label120.Text = "Choose camera:";
            this.btn_tes_cam1.Location = new Point(0xb6, 0x4a);
            this.btn_tes_cam1.Name = "btn_tes_cam1";
            this.btn_tes_cam1.Size = new Size(90, 0x17);
            this.btn_tes_cam1.TabIndex = 4;
            this.btn_tes_cam1.Text = "Test Capture";
            this.btn_tes_cam1.UseVisualStyleBackColor = true;
            this.btn_tes_cam1.Click += new EventHandler(this.btn_tes_cam1_Click);
            this.rb_cam1_web.AutoSize = true;
            this.rb_cam1_web.Location = new Point(11, 0x17);
            this.rb_cam1_web.Name = "rb_cam1_web";
            this.rb_cam1_web.Size = new Size(0x57, 0x11);
            this.rb_cam1_web.TabIndex = 2;
            this.rb_cam1_web.Text = "Web Camera";
            this.rb_cam1_web.UseVisualStyleBackColor = true;
            this.rb_cam1_web.CheckedChanged += new EventHandler(this.rb_cam1_web_CheckedChanged);
            this.combo_cam1_ip.DropDownStyle = ComboBoxStyle.DropDownList;
            this.combo_cam1_ip.FormattingEnabled = true;
            this.combo_cam1_ip.Location = new Point(0x6f, 0x2f);
            this.combo_cam1_ip.Name = "combo_cam1_ip";
            this.combo_cam1_ip.Size = new Size(160, 0x15);
            this.combo_cam1_ip.TabIndex = 5;
            this.rb_cam1_ip.AutoSize = true;
            this.rb_cam1_ip.Checked = true;
            this.rb_cam1_ip.Location = new Point(11, 0x30);
            this.rb_cam1_ip.Name = "rb_cam1_ip";
            this.rb_cam1_ip.Size = new Size(0x4a, 0x11);
            this.rb_cam1_ip.TabIndex = 3;
            this.rb_cam1_ip.TabStop = true;
            this.rb_cam1_ip.Text = "IP Camera";
            this.rb_cam1_ip.UseVisualStyleBackColor = true;
            this.rb_cam1_ip.CheckedChanged += new EventHandler(this.rb_cam1_ip_CheckedChanged);
            this.combo_cam1_web.DropDownStyle = ComboBoxStyle.DropDownList;
            this.combo_cam1_web.FormattingEnabled = true;
            this.combo_cam1_web.Location = new Point(0x6f, 0x16);
            this.combo_cam1_web.Name = "combo_cam1_web";
            this.combo_cam1_web.Size = new Size(160, 0x15);
            this.combo_cam1_web.TabIndex = 4;
            this.label98.AutoSize = true;
            this.label98.Location = new Point(0x116, 0xd5);
            this.label98.Name = "label98";
            this.label98.Size = new Size(0x97, 13);
            this.label98.TabIndex = 0x40;
            this.label98.Text = "*Printed in Weighbridge Ticket";
            this.cb_cam1.AutoSize = true;
            this.cb_cam1.Location = new Point(0x10, 0x10);
            this.cb_cam1.Name = "cb_cam1";
            this.cb_cam1.Size = new Size(0x6b, 0x11);
            this.cb_cam1.TabIndex = 0;
            this.cb_cam1.Text = "Enable Camera 1";
            this.cb_cam1.UseVisualStyleBackColor = true;
            this.cb_cam1.CheckedChanged += new EventHandler(this.cb_cam1_CheckedChanged);
            this.gb_enable_camera.Controls.Add(this.rb_camera_off);
            this.gb_enable_camera.Controls.Add(this.rb_camera_on);
            this.gb_enable_camera.Location = new Point(0x15, 0x15);
            this.gb_enable_camera.Name = "gb_enable_camera";
            this.gb_enable_camera.Size = new Size(0xf2, 0x94);
            this.gb_enable_camera.TabIndex = 3;
            this.gb_enable_camera.TabStop = false;
            this.gb_enable_camera.Text = "Capture Photo";
            this.rb_camera_off.AutoSize = true;
            this.rb_camera_off.Checked = true;
            this.rb_camera_off.Location = new Point(0x11, 0x2e);
            this.rb_camera_off.Name = "rb_camera_off";
            this.rb_camera_off.Size = new Size(60, 0x11);
            this.rb_camera_off.TabIndex = 1;
            this.rb_camera_off.TabStop = true;
            this.rb_camera_off.Text = "Disable";
            this.rb_camera_off.UseVisualStyleBackColor = true;
            this.rb_camera_off.CheckedChanged += new EventHandler(this.rb_camera_off_CheckedChanged);
            this.rb_camera_on.AutoSize = true;
            this.rb_camera_on.Location = new Point(0x11, 0x17);
            this.rb_camera_on.Name = "rb_camera_on";
            this.rb_camera_on.Size = new Size(0x3a, 0x11);
            this.rb_camera_on.TabIndex = 0;
            this.rb_camera_on.Text = "Enable";
            this.rb_camera_on.UseVisualStyleBackColor = true;
            this.rb_camera_on.CheckedChanged += new EventHandler(this.rb_camera_on_CheckedChanged);
            this.tabPage9.BackColor = SystemColors.ButtonFace;
            this.tabPage9.BorderStyle = BorderStyle.Fixed3D;
            this.tabPage9.Controls.Add(this.axWinsock1);
            this.tabPage9.Controls.Add(this.gBoxValvePLC);
            this.tabPage9.Location = new Point(4, 0x16);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new Padding(3);
            this.tabPage9.Size = new Size(0x3a7, 0x1e2);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "PLC Valve";
            this.axWinsock1.Enabled = true;
            this.axWinsock1.Location = new Point(6, 380);
            this.axWinsock1.Name = "axWinsock1";
            this.axWinsock1.OcxState = (AxHost.State) manager.GetObject("axWinsock1.OcxState");
            this.axWinsock1.Size = new Size(0x1c, 0x1c);
            this.axWinsock1.TabIndex = 90;
            this.gBoxValvePLC.Controls.Add(this.lblCloseValve);
            this.gBoxValvePLC.Controls.Add(this.lblOpenValve);
            this.gBoxValvePLC.Controls.Add(this.btnConnectPLC);
            this.gBoxValvePLC.Controls.Add(this.lblReadLine);
            this.gBoxValvePLC.Controls.Add(this.btnCloseValve);
            this.gBoxValvePLC.Controls.Add(this.btnOpenValve);
            this.gBoxValvePLC.Controls.Add(this.btnReadLineValve);
            this.gBoxValvePLC.Controls.Add(this.txtPLC_Length);
            this.gBoxValvePLC.Controls.Add(this.lblLength);
            this.gBoxValvePLC.Controls.Add(this.txtStart);
            this.gBoxValvePLC.Controls.Add(this.lblStart);
            this.gBoxValvePLC.Controls.Add(this.txtregfb);
            this.gBoxValvePLC.Controls.Add(this.label121);
            this.gBoxValvePLC.Controls.Add(this.txtregLine);
            this.gBoxValvePLC.Controls.Add(this.Regline);
            this.gBoxValvePLC.Controls.Add(this.lblPort);
            this.gBoxValvePLC.Controls.Add(this.txtIP);
            this.gBoxValvePLC.Controls.Add(this.txtPort);
            this.gBoxValvePLC.Controls.Add(this.lblIP);
            this.gBoxValvePLC.Cursor = Cursors.Default;
            this.gBoxValvePLC.FlatStyle = FlatStyle.System;
            this.gBoxValvePLC.ForeColor = SystemColors.ControlText;
            this.gBoxValvePLC.Location = new Point(0x15, 0x15);
            this.gBoxValvePLC.Name = "gBoxValvePLC";
            this.gBoxValvePLC.RightToLeft = RightToLeft.No;
            this.gBoxValvePLC.Size = new Size(0x1ba, 0xe1);
            this.gBoxValvePLC.TabIndex = 0x59;
            this.gBoxValvePLC.TabStop = false;
            this.gBoxValvePLC.Text = "Valve PLC Setting";
            this.lblCloseValve.AllowDrop = true;
            this.lblCloseValve.Location = new Point(0x13d, 130);
            this.lblCloseValve.Name = "lblCloseValve";
            this.lblCloseValve.RightToLeft = RightToLeft.Yes;
            this.lblCloseValve.Size = new Size(0x75, 0x11);
            this.lblCloseValve.TabIndex = 0x3e;
            this.lblCloseValve.Text = "X";
            this.lblCloseValve.TextAlign = ContentAlignment.MiddleRight;
            this.lblCloseValve.Visible = false;
            this.lblOpenValve.AllowDrop = true;
            this.lblOpenValve.Location = new Point(0x13d, 0x6a);
            this.lblOpenValve.Name = "lblOpenValve";
            this.lblOpenValve.RightToLeft = RightToLeft.Yes;
            this.lblOpenValve.Size = new Size(0x72, 0x11);
            this.lblOpenValve.TabIndex = 0x3d;
            this.lblOpenValve.Text = "X";
            this.lblOpenValve.TextAlign = ContentAlignment.MiddleRight;
            this.lblOpenValve.Visible = false;
            this.btnConnectPLC.Location = new Point(0x1b, 0xbd);
            this.btnConnectPLC.Name = "btnConnectPLC";
            this.btnConnectPLC.Size = new Size(0x5f, 0x17);
            this.btnConnectPLC.TabIndex = 0;
            this.btnConnectPLC.Text = "Test Connect";
            this.btnConnectPLC.UseVisualStyleBackColor = true;
            this.btnConnectPLC.Click += new EventHandler(this.btnConnect_Click_1);
            this.lblReadLine.AllowDrop = true;
            this.lblReadLine.Location = new Point(0x13d, 0x4f);
            this.lblReadLine.Name = "lblReadLine";
            this.lblReadLine.RightToLeft = RightToLeft.Yes;
            this.lblReadLine.Size = new Size(0x72, 0x11);
            this.lblReadLine.TabIndex = 60;
            this.lblReadLine.Text = "X";
            this.lblReadLine.TextAlign = ContentAlignment.MiddleRight;
            this.lblReadLine.Visible = false;
            this.btnCloseValve.Location = new Point(0xd9, 0x80);
            this.btnCloseValve.Name = "btnCloseValve";
            this.btnCloseValve.Size = new Size(0x51, 0x17);
            this.btnCloseValve.TabIndex = 0x3b;
            this.btnCloseValve.Text = "Close Valve";
            this.btnCloseValve.UseVisualStyleBackColor = true;
            this.btnCloseValve.Visible = false;
            this.btnOpenValve.Location = new Point(0xd9, 0x67);
            this.btnOpenValve.Name = "btnOpenValve";
            this.btnOpenValve.Size = new Size(0x51, 0x17);
            this.btnOpenValve.TabIndex = 0x3a;
            this.btnOpenValve.Text = "Open Valve";
            this.btnOpenValve.UseVisualStyleBackColor = true;
            this.btnOpenValve.Visible = false;
            this.btnReadLineValve.Location = new Point(0xd9, 0x4d);
            this.btnReadLineValve.Name = "btnReadLineValve";
            this.btnReadLineValve.Size = new Size(0x51, 0x17);
            this.btnReadLineValve.TabIndex = 0x39;
            this.btnReadLineValve.Text = "Read Line";
            this.btnReadLineValve.UseVisualStyleBackColor = true;
            this.btnReadLineValve.Visible = false;
            this.txtPLC_Length.Location = new Point(0x7d, 0x9b);
            this.txtPLC_Length.MaxLength = 4;
            this.txtPLC_Length.Name = "txtPLC_Length";
            this.txtPLC_Length.Size = new Size(0x2b, 20);
            this.txtPLC_Length.TabIndex = 0x38;
            this.txtPLC_Length.TextAlign = HorizontalAlignment.Right;
            this.lblLength.AllowDrop = true;
            this.lblLength.Location = new Point(0x1b, 0x9c);
            this.lblLength.Name = "lblLength";
            this.lblLength.RightToLeft = RightToLeft.Yes;
            this.lblLength.Size = new Size(0x37, 0x11);
            this.lblLength.TabIndex = 0x37;
            this.lblLength.Text = "Length";
            this.lblLength.TextAlign = ContentAlignment.MiddleRight;
            this.txtStart.Location = new Point(0x7d, 130);
            this.txtStart.MaxLength = 4;
            this.txtStart.Name = "txtStart";
            this.txtStart.Size = new Size(0x2b, 20);
            this.txtStart.TabIndex = 0x36;
            this.txtStart.TextAlign = HorizontalAlignment.Right;
            this.lblStart.AllowDrop = true;
            this.lblStart.Location = new Point(0x1b, 0x83);
            this.lblStart.Name = "lblStart";
            this.lblStart.RightToLeft = RightToLeft.Yes;
            this.lblStart.Size = new Size(0x5b, 0x11);
            this.lblStart.TabIndex = 0x35;
            this.lblStart.Text = "Start Address";
            this.lblStart.TextAlign = ContentAlignment.MiddleRight;
            this.txtregfb.Location = new Point(0x7d, 0x69);
            this.txtregfb.MaxLength = 4;
            this.txtregfb.Name = "txtregfb";
            this.txtregfb.Size = new Size(0x2b, 20);
            this.txtregfb.TabIndex = 0x30;
            this.txtregfb.TextAlign = HorizontalAlignment.Right;
            this.label121.AllowDrop = true;
            this.label121.Location = new Point(0x1b, 0x6a);
            this.label121.Name = "label121";
            this.label121.RightToLeft = RightToLeft.Yes;
            this.label121.Size = new Size(0x5d, 0x11);
            this.label121.TabIndex = 0x2f;
            this.label121.Text = "Reg feedback";
            this.label121.TextAlign = ContentAlignment.MiddleRight;
            this.txtregLine.Location = new Point(0x7d, 0x4f);
            this.txtregLine.MaxLength = 4;
            this.txtregLine.Name = "txtregLine";
            this.txtregLine.Size = new Size(0x2b, 20);
            this.txtregLine.TabIndex = 0x2e;
            this.txtregLine.TextAlign = HorizontalAlignment.Right;
            this.Regline.AllowDrop = true;
            this.Regline.Location = new Point(0x1b, 0x4f);
            this.Regline.Name = "Regline";
            this.Regline.RightToLeft = RightToLeft.Yes;
            this.Regline.Size = new Size(0x37, 0x11);
            this.Regline.TabIndex = 0x2d;
            this.Regline.Text = "Reg Line";
            this.Regline.TextAlign = ContentAlignment.MiddleRight;
            this.lblPort.AllowDrop = true;
            this.lblPort.Location = new Point(0x1b, 0x38);
            this.lblPort.Name = "lblPort";
            this.lblPort.RightToLeft = RightToLeft.Yes;
            this.lblPort.Size = new Size(0x31, 0x11);
            this.lblPort.TabIndex = 0x2c;
            this.lblPort.Text = "PLC Port";
            this.txtIP.Location = new Point(0x7d, 0x1b);
            this.txtIP.MaxLength = 50;
            this.txtIP.Name = "txtIP";
            this.txtIP.Size = new Size(0x80, 20);
            this.txtIP.TabIndex = 0x2b;
            this.txtPort.Location = new Point(0x7d, 0x35);
            this.txtPort.MaxLength = 4;
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new Size(0x2b, 20);
            this.txtPort.TabIndex = 0x29;
            this.txtPort.Text = "502";
            this.txtPort.TextAlign = HorizontalAlignment.Right;
            this.lblIP.AllowDrop = true;
            this.lblIP.Location = new Point(0x16, 30);
            this.lblIP.Name = "lblIP";
            this.lblIP.RightToLeft = RightToLeft.Yes;
            this.lblIP.Size = new Size(0x3f, 0x11);
            this.lblIP.TabIndex = 0x2a;
            this.lblIP.Text = "IP Address";
            this.tabPageGlobalSettings.BackColor = SystemColors.ButtonFace;
            this.tabPageGlobalSettings.Controls.Add(this.groupBox_GlobalSetting_Camera);
            this.tabPageGlobalSettings.Location = new Point(4, 0x16);
            this.tabPageGlobalSettings.Margin = new Padding(2);
            this.tabPageGlobalSettings.Name = "tabPageGlobalSettings";
            this.tabPageGlobalSettings.Padding = new Padding(2);
            this.tabPageGlobalSettings.Size = new Size(0x3a7, 0x1e2);
            this.tabPageGlobalSettings.TabIndex = 9;
            this.tabPageGlobalSettings.Text = "Global Settings";
            this.groupBox_GlobalSetting_Camera.Controls.Add(this.chkCheckDriverLicenseIDPhoto);
            this.groupBox_GlobalSetting_Camera.Cursor = Cursors.Default;
            this.groupBox_GlobalSetting_Camera.FlatStyle = FlatStyle.System;
            this.groupBox_GlobalSetting_Camera.ForeColor = SystemColors.ControlText;
            this.groupBox_GlobalSetting_Camera.Location = new Point(0x15, 0x15);
            this.groupBox_GlobalSetting_Camera.Name = "groupBox_GlobalSetting_Camera";
            this.groupBox_GlobalSetting_Camera.RightToLeft = RightToLeft.No;
            this.groupBox_GlobalSetting_Camera.Size = new Size(0x1ba, 0x57);
            this.groupBox_GlobalSetting_Camera.TabIndex = 90;
            this.groupBox_GlobalSetting_Camera.TabStop = false;
            this.groupBox_GlobalSetting_Camera.Text = "Camera";
            this.chkCheckDriverLicenseIDPhoto.AutoSize = true;
            this.chkCheckDriverLicenseIDPhoto.Location = new Point(0x11, 0x17);
            this.chkCheckDriverLicenseIDPhoto.Margin = new Padding(2);
            this.chkCheckDriverLicenseIDPhoto.Name = "chkCheckDriverLicenseIDPhoto";
            this.chkCheckDriverLicenseIDPhoto.Size = new Size(0x141, 0x11);
            this.chkCheckDriverLicenseIDPhoto.TabIndex = 0;
            this.chkCheckDriverLicenseIDPhoto.Text = "Check Driver License ID Photo when saving Registration Data";
            this.chkCheckDriverLicenseIDPhoto.UseVisualStyleBackColor = true;
            this.button2.Location = new Point(0x2c0, 0x216);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x92, 0x1f);
            this.button2.TabIndex = 1;
            this.button2.Text = "&Save && Apply Setting";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button3.Location = new Point(0x358, 0x216);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x5f, 0x1f);
            this.button3.TabIndex = 2;
            this.button3.Text = "&Close";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.openFileDialog1.FileName = "openFileDialog1";
            this.serialPort2.DataReceived += new SerialDataReceivedEventHandler(this.serialPort2_DataReceived);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x3c7, 0x241);
            base.ControlBox = false;
            base.Controls.Add(this.button3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.tabGate);
            this.ForeColor = SystemColors.ActiveCaptionText;
            base.Icon = (Icon) manager.GetObject("$this.Icon");
            base.Name = "FormSettingHardware";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Hardware Configuration";
            base.FormClosing += new FormClosingEventHandler(this.FormSettingHardware_FormClosing);
            base.Load += new EventHandler(this.FormSettingHardware_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormSettingHardware_KeyPress);
            this.tabGate.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.tabBarrierGate.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabBarrierBat.ResumeLayout(false);
            this.panelBarrierBat.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabBarrierIP.ResumeLayout(false);
            this.panelBarrierIP.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tab_camera.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.gb_cam5.ResumeLayout(false);
            this.gb_cam5.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.gb_cam4.ResumeLayout(false);
            this.gb_cam4.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.gb_cam3.ResumeLayout(false);
            this.gb_cam3.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.gb_cam2.ResumeLayout(false);
            this.gb_cam2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.gb_cam1.ResumeLayout(false);
            this.gb_cam1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_enable_camera.ResumeLayout(false);
            this.gb_enable_camera.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.axWinsock1.EndInit();
            this.gBoxValvePLC.ResumeLayout(false);
            this.gBoxValvePLC.PerformLayout();
            this.tabPageGlobalSettings.ResumeLayout(false);
            this.groupBox_GlobalSetting_Camera.ResumeLayout(false);
            this.groupBox_GlobalSetting_Camera.PerformLayout();
            base.ResumeLayout(false);
        }

        private void InitPort()
        {
            if (this.serialPort1.IsOpen)
            {
                this.serialPort1.Close();
            }
            this.serialPort1.ReadTimeout = 0x3e8;
            this.serialPort1.RtsEnable = true;
            this.serialPort1.DtrEnable = true;
            this.serialPort1.ReadBufferSize = Convert.ToInt32(this.textBuffers.Text);
            this.serialPort1.PortName = this.comboBox1.Text;
            this.serialPort1.BaudRate = Convert.ToInt32(this.comboBox2.Text);
            this.serialPort1.DataBits = Convert.ToInt32(this.comboBox3.Text[0].ToString());
            this.serialPort1.Parity = (this.comboBox4.Text == "None") ? Parity.None : ((this.comboBox4.Text == "Even") ? Parity.Even : Parity.Odd);
            this.serialPort1.StopBits = (this.comboBox5.Text == "One") ? StopBits.One : StopBits.Two;
        }

        private void label132_Click(object sender, EventArgs e)
        {
        }

        private void label92_Click(object sender, EventArgs e)
        {
        }

        private void radioReportIN_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void radioWBType4_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioWBType4.Checked)
            {
                this.listBoxBuffer.Visible = true;
                this.listBoxTmpRead.Visible = true;
            }
            else
            {
                this.listBoxBuffer.Visible = false;
                this.listBoxTmpRead.Visible = false;
            }
        }

        private void rb_cam1_ip_CheckedChanged(object sender, EventArgs e)
        {
            this.cekRadioCamera();
        }

        private void rb_cam1_web_CheckedChanged(object sender, EventArgs e)
        {
            this.cekRadioCamera();
        }

        private void rb_cam2_ip_CheckedChanged(object sender, EventArgs e)
        {
            this.cekRadioCamera();
        }

        private void rb_cam2_web_CheckedChanged(object sender, EventArgs e)
        {
            this.cekRadioCamera();
        }

        private void rb_cam3_ip_CheckedChanged(object sender, EventArgs e)
        {
            this.cekRadioCamera();
        }

        private void rb_cam3_web_CheckedChanged(object sender, EventArgs e)
        {
            this.cekRadioCamera();
        }

        private void rb_cam4_ip_CheckedChanged(object sender, EventArgs e)
        {
            this.cekRadioCamera();
        }

        private void rb_cam4_web_CheckedChanged(object sender, EventArgs e)
        {
            this.cekRadioCamera();
        }

        private void rb_cam5_ip_CheckedChanged(object sender, EventArgs e)
        {
            this.cekRadioCamera();
        }

        private void rb_cam5_web_CheckedChanged(object sender, EventArgs e)
        {
            this.cekRadioCamera();
        }

        private void rb_camera_off_CheckedChanged(object sender, EventArgs e)
        {
            this.setGroupBoxCamera();
        }

        private void rb_camera_on_CheckedChanged(object sender, EventArgs e)
        {
            this.setGroupBoxCamera();
        }

        private void rboNo_CheckedChanged(object sender, EventArgs e)
        {
            this.setPanelBarrier();
        }

        private void rboScheduleYes_Leave(object sender, EventArgs e)
        {
        }

        private void rboYes_CheckedChanged(object sender, EventArgs e)
        {
            this.setPanelBarrier();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            int num3;
            string item = "";
            int length = WBSetting.Length;
            if (!this.radioWBType4.Checked)
            {
                if (this.richTextBox1.Lines.Count<string>() >= 2)
                {
                    item = this.richTextBox1.Lines[this.richTextBox1.Lines.Count<string>() - 2];
                    goto TR_0009;
                }
            }
            else if (this.listBoxTmpRead.Items.Count > 0)
            {
                item = this.listBoxTmpRead.Items[this.listBoxTmpRead.Items.Count - 1].ToString();
                this.listBoxBuffer.Items.Add(item);
                goto TR_0009;
            }
            return;
        TR_0009:
            if (item.ToUpper().IndexOf("KG", 0) <= -1)
            {
                try
                {
                    num3 = Convert.ToInt32(item.Substring(WBSetting.Start_Get - 1, length));
                }
                catch
                {
                    num3 = 0;
                }
            }
            else
            {
                int startIndex = (item.ToUpper().IndexOf("KG", 0) - WBSetting.beforeKG) - length;
                try
                {
                    num3 = Convert.ToInt32(item.Substring(startIndex, length));
                }
                catch
                {
                    num3 = 0;
                }
            }
            this.textBox4.Text = $"{num3:N0}" + " KG";
        }

        private void serialPort2_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            string cbuff = this.serialPort2.ReadExisting();
            if (this.radioWBType3.Checked)
            {
                base.BeginInvoke(() => this.richTextBox1.AppendText(cbuff));
            }
            else if (this.radioWBType4.Checked)
            {
                base.BeginInvoke(() => this.listBoxTmpRead.Items.Add(cbuff));
                this.richTextBox1.AppendText(this.listBoxTmpRead.Items[this.listBoxTmpRead.Items.Count - 1].ToString());
            }
        }

        private void setGroupBoxCamera()
        {
            if (this.rb_camera_on.Checked && (WBUser.CheckTrustee("CTR_CAMERA", "A") || WBUser.CheckTrustee("CTR_CAMERA", "E")))
            {
                this.gb_cam1.Enabled = true;
                this.gb_cam2.Enabled = true;
                this.gb_cam3.Enabled = true;
                this.gb_cam4.Enabled = true;
                this.gb_cam5.Enabled = true;
            }
            else
            {
                this.gb_cam1.Enabled = false;
                this.gb_cam2.Enabled = false;
                this.gb_cam3.Enabled = false;
                this.gb_cam4.Enabled = false;
                this.gb_cam5.Enabled = false;
            }
        }

        private void setPanelBarrier()
        {
            if (!this.rboYes.Checked)
            {
                this.panelBarrierBat.Enabled = false;
                this.panelBarrierIP.Enabled = false;
                this.bGate = 'F';
                this.comboBarrier.Text = "";
                this.comboBarrier.Enabled = false;
                this.tabControl1.SelectedTab = this.tabBarrierBat;
            }
            else
            {
                if (this.comboBarrier.Text == "Using Bat File")
                {
                    this.panelBarrierBat.Enabled = true;
                    this.panelBarrierIP.Enabled = false;
                    this.tabControl1.SelectedTab = this.tabBarrierBat;
                }
                else if (this.comboBarrier.Text == "Using IP")
                {
                    this.panelBarrierBat.Enabled = false;
                    this.panelBarrierIP.Enabled = true;
                    this.tabControl1.SelectedTab = this.tabBarrierIP;
                }
                this.bGate = 'Y';
                this.comboBarrier.Enabled = true;
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
        }

        private void tabPage5_Click(object sender, EventArgs e)
        {
        }

        private void tes1Out_Click_1(object sender, EventArgs e)
        {
            try
            {
                Process.Start(this.textGate1OpenOut.Text);
                Thread.Sleep(0xbb8);
                Process.Start(this.textGate1CloseOut.Text);
            }
            catch (Exception exception1)
            {
                MessageBox.Show(exception1.ToString());
            }
        }

        private void tes2Out_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(this.textGate2OpenOut.Text);
                Thread.Sleep(0xbb8);
                Process.Start(this.textGate2CloseOut.Text);
            }
            catch (Exception exception1)
            {
                MessageBox.Show(exception1.ToString());
            }
        }

        private void textPort_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "0123456789".IndexOfAny(anyOf) <= -1;
            }
        }

        private void textPort_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.txtPort.Text);
        }

        private void ThisClose()
        {
            if (MessageBox.Show(" Are you sure to close ?\n\n < If any changes will not be saved. >", "A L E R T", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                base.Close();
            }
        }

        private void translate()
        {
            this.tabPage2.Text = Resource.Setting_012;
            this.label77.Text = Resource.Setting_013;
            this.radioWBType1.Text = Resource.Setting_014;
            this.radioWBType2.Text = Resource.Setting_015;
            this.radioWBType3.Text = Resource.Setting_016;
            this.label8.Text = Resource.Setting_017;
            this.label9.Text = Resource.Setting_018;
            this.label10.Text = Resource.Setting_019;
            this.label7.Text = Resource.Setting_020;
            this.label6.Text = Resource.Setting_021;
            this.label14.Text = Resource.Setting_022;
            this.label15.Text = Resource.Setting_023;
            this.label30.Text = Resource.Setting_024;
            this.label16.Text = Resource.Setting_025;
            this.button4.Text = Resource.Setting_026;
            this.tabBarrierGate.Text = Resource.Setting_101;
            this.label115.Text = Resource.Setting_102;
            this.label27.Text = Resource.Setting_102;
            this.label110.Text = Resource.Setting_103;
            this.label93.Text = Resource.Setting_104;
            this.label112.Text = Resource.Setting_105;
            this.label28.Text = Resource.Setting_106;
            this.label113.Text = Resource.Setting_107;
            this.label111.Text = Resource.Setting_108;
            this.label116.Text = Resource.Setting_109;
            this.label19.Text = Resource.Setting_109;
            this.tes1Out.Text = Resource.Setting_110;
            this.tes2Out.Text = Resource.Setting_111;
            this.tabPageGlobalSettings.Text = Resource.Setting_157;
            this.groupBox_GlobalSetting_Camera.Text = Resource.Setting_158;
            this.chkCheckDriverLicenseIDPhoto.Text = Resource.Setting_159;
            this.button2.Text = Resource.Setting_155;
            this.button3.Text = Resource.Menu_Close;
        }

        private void txtIP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "0123456789.".IndexOfAny(anyOf) <= -1;
            }
        }

        private void txtIP_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.txtIP.Text);
        }

        private void txtLength_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "0123456789".IndexOfAny(anyOf) <= -1;
            }
        }

        private void txtLength_leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.txtPLC_Length.Text);
        }

        private void txtregfb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "0123456789".IndexOfAny(anyOf) <= -1;
            }
        }

        private void txtregfb_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.txtregfb.Text);
        }

        private void txtregfbOpen_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.txtregfb.Text);
        }

        private void txtregLine_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "0123456789".IndexOfAny(anyOf) <= -1;
            }
        }

        private void txtregLine_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.txtregLine.Text);
        }

        private void txtStart_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "0123456789".IndexOfAny(anyOf) <= -1;
            }
        }

        private void txtStart_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.txtStart.Text);
        }
    }
}

