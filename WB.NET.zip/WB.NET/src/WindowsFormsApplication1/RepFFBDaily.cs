﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;

    public class RepFFBDaily : Form
    {
        private int no = 0;
        private int x = 0;
        private string sqlTrans;
        private string relation_code;
        private string fruit;
        private string relation_name;
        private double sNet;
        private double sNetEstate;
        private double sRec;
        private double sRecAVG;
        private double tRecAVG;
        private double sDeduc;
        private double sBunch;
        private double sAvg;
        private double sUnit;
        private double OERCPO;
        private double TOERCPO;
        private double RVCPO;
        private double gTOERCPO;
        private double tRVCPO;
        private double NetToday;
        private double sgunny;
        private double tGunny;
        private double tNet = 0.0;
        private double tNetEstate = 0.0;
        private double tRec = 0.0;
        private double tDeduc = 0.0;
        private double tBunch = 0.0;
        private double tAvg = 0.0;
        private double tUnit = 0.0;
        private double tNetToday = 0.0;
        private double[] tNetGroup = new double[6];
        private double[] tRecGroup = new double[6];
        private double[] tPlasma1 = new double[6];
        private double[] tPlasma2 = new double[6];
        private double[] tIscc = new double[6];
        private double[] tFruitType = new double[6];
        private int count = 0;
        private string[] cbChecked = new string[5];
        private IContainer components = null;
        public Label labelRecNo;
        public Label labelProcess;
        public Button button2;
        public Button button1;
        public DateTimePicker monthCalendar1;
        public Label label1;
        public Label label5;
        private CheckBox cbGunny;
        public Label label2;
        private ComboBox comboCom;
        private GroupBox groupFType;
        private CheckBox checkR;
        private CheckBox checkK;
        private CheckBox checkS;
        private CheckBox checkB;
        private CheckBox checkM;
        public GroupBox grType;
        private RadioButton rboAll;
        public RadioButton rboGI;
        public RadioButton rboGR;

        public RepFFBDaily()
        {
            this.InitializeComponent();
        }

        private unsafe void button1_Click(object sender, EventArgs e)
        {
            if (this.comboCom.Text.Trim() == "")
            {
                MessageBox.Show("Please choose commodity!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.comboCom.Focus();
            }
            else
            {
                this.count = 0;
                int index = 0;
                while (true)
                {
                    if (index >= this.cbChecked.Count<string>())
                    {
                        foreach (Control control in this.groupFType.Controls)
                        {
                            CheckBox box = control as CheckBox;
                            if ((box != null) && box.Checked)
                            {
                                this.cbChecked[this.count] = box.Text;
                                this.count++;
                            }
                        }
                        this.labelProcess.Visible = true;
                        this.labelRecNo.Visible = true;
                        WBTable table = new WBTable();
                        this.sqlTrans = "Select * from vw_trans where " + WBData.CompanyLocation(" and report_date = '" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00' ");
                        this.sqlTrans = this.sqlTrans + " and (comm_code = '" + this.comboCom.Text.Trim() + "')";
                        this.sqlTrans = this.sqlTrans + " and (deleted is null or deleted = 'N' or deleted = '') ";
                        if (this.rboGI.Checked)
                        {
                            this.sqlTrans = this.sqlTrans + " and IO = 'O' ";
                        }
                        else if (this.rboGR.Checked)
                        {
                            this.sqlTrans = this.sqlTrans + " and IO = 'I' ";
                        }
                        if (this.count <= 0)
                        {
                            this.sqlTrans = this.sqlTrans + " and (Fruits_type = '' or Fruits_type is null) ";
                        }
                        else
                        {
                            int num3 = 0;
                            while (true)
                            {
                                if (num3 >= this.cbChecked.Count<string>())
                                {
                                    this.sqlTrans = this.sqlTrans + " ) ";
                                    break;
                                }
                                if (this.cbChecked[num3] != "")
                                {
                                    this.sqlTrans = (num3 != 0) ? (this.sqlTrans + " or Fruits_type = '" + this.cbChecked[num3] + "' ") : (this.sqlTrans + " and ( Fruits_type = '" + this.cbChecked[num3] + "' ");
                                }
                                num3++;
                            }
                        }
                        this.sqlTrans = this.sqlTrans + " order by relation_Code , Fruits_Type ";
                        table.OpenTable("vw_trans", this.sqlTrans, WBData.conn);
                        if (table.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                        else
                        {
                            int count = table.DT.Rows.Count;
                            this.labelRecNo.Text = "0/" + count.ToString();
                            this.labelRecNo.Refresh();
                            this.labelProcess.Refresh();
                            HTML rep = new HTML();
                            rep.File = rep.File + @"\" + WBUser.UserID + "_Compare.htm";
                            rep.Title = "Daily Report FFB";
                            rep.Open();
                            rep.Write(rep.Style());
                            rep.Write("<br><font size=5><b>DAILY REPORT</b></font><br>");
                            string[] textArray1 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                            rep.Write(string.Concat(textArray1));
                            string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                            rep.Write(string.Concat(textArray2));
                            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                            {
                                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                            }
                            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                            {
                                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                            }
                            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                            {
                                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                            }
                            rep.Write("<br><br>");
                            string str = Program.getFieldValue("wb_commodity", "Comm_Name", "comm_code", this.comboCom.Text);
                            rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                            rep.Write("<tr class=bd>");
                            rep.Write("<td>Commodity</td>");
                            string[] textArray3 = new string[] { "<td>: <b>", this.comboCom.Text.Trim(), " - ", str, "</b></td>" };
                            rep.Write(string.Concat(textArray3));
                            rep.Write("</tr>");
                            rep.Write("<tr class=bd>");
                            rep.Write("<td>Selected Date</td>");
                            rep.Write("<td>: <b>" + this.monthCalendar1.Value.ToShortDateString() + "</b></td>");
                            rep.Write("</tr>");
                            rep.Write("<tr class=bd>");
                            rep.Write("<td>Report Date</td>");
                            rep.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                            rep.Write("</tr>");
                            rep.Write("</table>");
                            rep.Write("<br/><br/><br/>");
                            rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                            rep.Write("<tr class='bd'>");
                            rep.Write("<td align=center><b>No.</b></td>");
                            rep.Write("<td align=center><b>Supplier/Customer</b></td>");
                            rep.Write("<td align=center><b>T</b></td>");
                            rep.Write("<td align=center><b>Avg</b></td>");
                            rep.Write("<td align=center><b>Bunch</b></td>");
                            rep.Write("<td align=center><b>Unit</b></td>");
                            rep.Write("<td align=center><b>RV.CPO</b></td>");
                            rep.Write("<td align=center><b>RV.PK</b></td>");
                            rep.Write("<td align=center><b>Net Estate</b></td>");
                            rep.Write("<td align=center><b>Received</b></td>");
                            rep.Write("<td align=center><b>Deduction</b></td>");
                            if (this.cbGunny.Checked)
                            {
                                rep.Write("<td align=center><b>Gunny</b></td>");
                            }
                            rep.Write("<td align=center><b>Net</b></td>");
                            rep.Write("<td align=center><b>Net U/ Today</b></td>");
                            rep.Write("</tr>");
                            table.DR = table.DT.Rows[0];
                            this.sUnit = 0.0;
                            this.sNet = 0.0;
                            this.sRec = 0.0;
                            this.sNetEstate = 0.0;
                            this.sDeduc = 0.0;
                            this.OERCPO = 0.0;
                            this.TOERCPO = 0.0;
                            this.sBunch = 0.0;
                            this.sAvg = 0.0;
                            this.gTOERCPO = 0.0;
                            this.TOERCPO = 0.0;
                            this.tUnit = 0.0;
                            this.tNet = 0.0;
                            this.tRec = 0.0;
                            this.tNetEstate = 0.0;
                            this.tDeduc = 0.0;
                            this.tBunch = 0.0;
                            this.tAvg = 0.0;
                            this.tNetToday = 0.0;
                            this.NetToday = 0.0;
                            this.sRecAVG = 0.0;
                            this.tRecAVG = 0.0;
                            this.sgunny = 0.0;
                            this.tGunny = 0.0;
                            this.x = 0;
                            while (true)
                            {
                                if (this.x >= this.tNetGroup.Length)
                                {
                                    this.relation_code = "";
                                    this.fruit = "";
                                    this.no = 0;
                                    this.relation_code = table.DR["Relation_code"].ToString();
                                    this.relation_name = Program.getFieldValue("wb_relation", "relation_name", "relation_code", this.relation_code);
                                    this.fruit = table.DR["Fruits_Type"].ToString();
                                    int num = 0;
                                    foreach (DataRow row in table.DT.Rows)
                                    {
                                        num++;
                                        this.labelRecNo.Text = num.ToString() + "/" + table.DT.Rows.Count.ToString();
                                        this.labelRecNo.Refresh();
                                        if ((this.fruit != row["Fruits_Type"].ToString()) && (this.relation_code == row["Relation_code"].ToString()))
                                        {
                                            this.no++;
                                            this.fillDetail(rep);
                                            this.sUnit = 0.0;
                                            this.sNet = 0.0;
                                            this.sNetEstate = 0.0;
                                            this.sRec = 0.0;
                                            this.sRecAVG = 0.0;
                                            this.sDeduc = 0.0;
                                            this.OERCPO = 0.0;
                                            this.sBunch = 0.0;
                                            this.sAvg = 0.0;
                                            this.TOERCPO = 0.0;
                                            this.sgunny = 0.0;
                                            this.fruit = row["Fruits_Type"].ToString();
                                        }
                                        if (this.relation_code != row["Relation_code"].ToString())
                                        {
                                            this.no++;
                                            this.fillDetail(rep);
                                            this.sUnit = 0.0;
                                            this.sNet = 0.0;
                                            this.sNetEstate = 0.0;
                                            this.sRec = 0.0;
                                            this.sRecAVG = 0.0;
                                            this.sDeduc = 0.0;
                                            this.OERCPO = 0.0;
                                            this.TOERCPO = 0.0;
                                            this.sBunch = 0.0;
                                            this.sAvg = 0.0;
                                            this.sgunny = 0.0;
                                            this.relation_code = row["Relation_code"].ToString();
                                            this.relation_name = Program.getFieldValue("wb_relation", "relation_name", "relation_code", this.relation_code);
                                            this.fruit = row["Fruits_Type"].ToString();
                                        }
                                        this.sUnit++;
                                        this.sNet += Program.StrToDouble(row["Netto"].ToString(), 0);
                                        this.sRec += Program.StrToDouble(row["Bruto"].ToString(), 0) - Program.StrToDouble(row["Tarra"].ToString(), 0);
                                        this.sDeduc += Program.StrToDouble(row["Deduction"].ToString(), 0);
                                        this.OERCPO = (Program.StrToDouble(row["Rend_CPO"].ToString(), 2) * Program.StrToDouble(row["Netto"].ToString(), 2)) / 100.0;
                                        this.TOERCPO += this.OERCPO;
                                        this.gTOERCPO += this.OERCPO;
                                        if (this.cbGunny.Checked)
                                        {
                                            this.sgunny += Program.StrToDouble(row["TotalBunch"].ToString(), 2) * Program.StrToDouble(row["WeightPerUnitName"].ToString(), 2);
                                        }
                                        this.RVCPO = (this.TOERCPO * 100.0) / this.sNet;
                                        if (Program.StrToDouble(row["TotalBunch"].ToString(), 0) > 0.0)
                                        {
                                            this.sRecAVG += Program.StrToDouble(row["Bruto"].ToString(), 0) - Program.StrToDouble(row["Tarra"].ToString(), 0);
                                            this.tRecAVG += Program.StrToDouble(row["Bruto"].ToString(), 0) - Program.StrToDouble(row["Tarra"].ToString(), 0);
                                        }
                                        this.sBunch += Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                                        this.sAvg = (this.sBunch <= 0.0) ? 0.0 : (this.sRecAVG / this.sBunch);
                                        this.sNetEstate += Program.StrToDouble(row["Estate_Qty"].ToString(), 0);
                                        this.tUnit++;
                                        this.tNet += Program.StrToDouble(row["Netto"].ToString(), 0);
                                        this.tRec += Program.StrToDouble(row["Bruto"].ToString(), 0) - Program.StrToDouble(row["Tarra"].ToString(), 0);
                                        this.tDeduc += Program.StrToDouble(row["Deduction"].ToString(), 0);
                                        this.tNetEstate += Program.StrToDouble(row["Estate_Qty"].ToString(), 0);
                                        this.tBunch += Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                                        if (this.cbGunny.Checked)
                                        {
                                            this.tGunny += Program.StrToDouble(row["TotalBunch"].ToString(), 2) * Program.StrToDouble(row["WeightPerUnitName"].ToString(), 2);
                                        }
                                        this.tRVCPO = (this.gTOERCPO * 100.0) / this.tNet;
                                        this.tAvg = this.tRecAVG / this.tBunch;
                                        if ((row["Plasma"].ToString() == "Y") && (row["Group_Type"].ToString() == "0"))
                                        {
                                            double* numPtr1 = this.tPlasma1;
                                            numPtr1[0] += Program.StrToDouble(row["Bruto"].ToString(), 0) - Program.StrToDouble(row["Tarra"].ToString(), 0);
                                            double* numPtr2 = this.tPlasma2;
                                            numPtr2[0] += Program.StrToDouble(row["Netto"].ToString(), 0);
                                        }
                                        else if ((row["Plasma"].ToString() == "Y") && (row["Group_Type"].ToString() == "1"))
                                        {
                                            double* numPtr3 = &(this.tPlasma1[1]);
                                            numPtr3[0] += Program.StrToDouble(row["Bruto"].ToString(), 0) - Program.StrToDouble(row["Tarra"].ToString(), 0);
                                            double* numPtr4 = &(this.tPlasma2[1]);
                                            numPtr4[0] += Program.StrToDouble(row["Netto"].ToString(), 0);
                                        }
                                        if ((row["Group_Type"].ToString().Trim() != "") && (row["Plasma"].ToString() != "Y"))
                                        {
                                            double* numPtr5 = &(this.tNetGroup[Convert.ToInt16(row["Group_type"].ToString())]);
                                            numPtr5[0] += Program.StrToDouble(row["Netto"].ToString(), 0);
                                            double* numPtr6 = &(this.tRecGroup[Convert.ToInt16(row["Group_type"].ToString())]);
                                            numPtr6[0] += Program.StrToDouble(row["Bruto"].ToString(), 0) - Program.StrToDouble(row["Tarra"].ToString(), 0);
                                        }
                                        if (row["ISCC_Checked"].ToString() == "N")
                                        {
                                            double* tIscc = this.tIscc;
                                            tIscc[0] += Program.StrToDouble(row["Netto"].ToString(), 0);
                                        }
                                        else if (row["ISCC_Checked"].ToString() == "Y")
                                        {
                                            double* numPtr8 = &(this.tIscc[1]);
                                            numPtr8[0] += Program.StrToDouble(row["Netto"].ToString(), 0);
                                        }
                                        if (row["Fruits_Type"].ToString().Trim() != "")
                                        {
                                            string str2 = row["Fruits_Type"].ToString();
                                            if (str2 == "M")
                                            {
                                                double* tFruitType = this.tFruitType;
                                                tFruitType[0] += Program.StrToDouble(row["Netto"].ToString(), 0);
                                            }
                                            else if (str2 == "B")
                                            {
                                                double* numPtr10 = &(this.tFruitType[1]);
                                                numPtr10[0] += Program.StrToDouble(row["Netto"].ToString(), 0);
                                            }
                                            else if (str2 == "S")
                                            {
                                                double* numPtr11 = &(this.tFruitType[2]);
                                                numPtr11[0] += Program.StrToDouble(row["Netto"].ToString(), 0);
                                            }
                                            else if (str2 == "K")
                                            {
                                                double* numPtr12 = &(this.tFruitType[3]);
                                                numPtr12[0] += Program.StrToDouble(row["Netto"].ToString(), 0);
                                            }
                                            else if (str2 == "R")
                                            {
                                                double* numPtr13 = &(this.tFruitType[4]);
                                                numPtr13[0] += Program.StrToDouble(row["Netto"].ToString(), 0);
                                            }
                                        }
                                    }
                                    if (double.IsNaN(this.tAvg))
                                    {
                                        this.tAvg = 0.0;
                                    }
                                    this.no++;
                                    this.fillDetail(rep);
                                    this.fillTotal(rep);
                                    rep.Write("</tr>");
                                    rep.Write("</table>");
                                    rep.Write("<br><br>");
                                    this.fillGroup(rep);
                                    rep.Write("<br><br><br>");
                                    rep.writeSign();
                                    rep.Close();
                                    ViewReport report = new ViewReport {
                                        webBrowser1 = { Url = new Uri("file:///" + rep.File) }
                                    };
                                    report.ShowDialog();
                                    rep.Dispose();
                                    report.Dispose();
                                    this.labelProcess.Visible = false;
                                    this.labelRecNo.Visible = false;
                                    break;
                                }
                                this.tNetGroup[this.x] = 0.0;
                                this.tRecGroup[this.x] = 0.0;
                                this.tPlasma1[this.x] = 0.0;
                                this.tPlasma2[this.x] = 0.0;
                                this.tIscc[this.x] = 0.0;
                                this.tFruitType[this.x] = 0.0;
                                this.x++;
                            }
                        }
                        break;
                    }
                    this.cbChecked[index] = "";
                    index++;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private double cekSDHI(string rcode, string pFruit)
        {
            double num;
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { " and (report_date >= '", Convert.ToDateTime(this.monthCalendar1.Value.ToString()).Year.ToString(), "-", Convert.ToDateTime(this.monthCalendar1.Value.ToString()).Month.ToString(), "-01 00:00:00' and report_date <= '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), " 00:00:00')" };
            string sqltext = ((("Select sum(Netto) as Netto from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray1))) + " and relation_code = '" + rcode + "' ") + " and comm_code = '" + this.comboCom.Text + "' ") + " and (deleted is null or deleted = 'N' or deleted = '') " + " and (report_date is not null) ";
            if (this.rboGI.Checked)
            {
                sqltext = sqltext + " and IO = 'O' ";
            }
            else if (this.rboGR.Checked)
            {
                sqltext = sqltext + " and IO = 'I' ";
            }
            sqltext = (this.count <= 0) ? (sqltext + " and (Fruits_type = '' or Fruits_type is null) ") : (sqltext + " and Fruits_Type = '" + pFruit + "' ");
            table.OpenTable("vw_trans", sqltext, WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                num = 0.0;
            }
            else
            {
                table.DR = table.DT.Rows[0];
                num = (table.DR["Netto"].ToString().Length <= 0) ? 0.0 : Convert.ToDouble(table.DR["Netto"].ToString());
            }
            return num;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void fillDetail(HTML rep)
        {
            rep.Write("<tr class='bd'>");
            rep.Write("<td align=right>" + this.no.ToString() + "</td>");
            rep.Write("<td align=left>" + this.relation_name + "</td>");
            rep.Write("<td align=center>" + this.fruit + "</td>");
            rep.Write("<td align=right>" + $"{this.sAvg:N2}" + "</td>");
            rep.Write("<td align=right>" + $"{this.sBunch:N0}" + "</td>");
            rep.Write("<td align=right>" + $"{this.sUnit:N0}" + "</td>");
            rep.Write("<td align=center>" + $"{this.RVCPO:N2}" + "</td>");
            rep.Write("<td align=center>0.00</td>");
            rep.Write("<td align=right>" + $"{this.sNetEstate:N0}" + "</td>");
            rep.Write("<td align=right>" + $"{this.sRec:N0}" + "</td>");
            rep.Write("<td align=right>" + $"{this.sDeduc:N0}" + "</td>");
            if (this.cbGunny.Checked)
            {
                rep.Write("<td align=right>" + $"{this.sgunny:N0}" + "</td>");
            }
            rep.Write("<td align=right>" + $"{this.sNet:N0}" + "</td>");
            this.NetToday = this.cekSDHI(this.relation_code, this.fruit);
            rep.Write("<td align=right>" + $"{this.NetToday:N0}" + "</td>");
            rep.Write("</tr>");
        }

        private void fillGroup(HTML rep)
        {
            string str = "&nbsp";
            rep.Write("<table border=0 rules=all cellpadding=3 cellspacing=-1>");
            this.x = 0;
            while (true)
            {
                if (this.x >= this.tNetGroup.Length)
                {
                    rep.Write("</table>");
                    return;
                }
                rep.Write("<tr class='bd'>");
                int x = this.x;
                switch (x)
                {
                    case 0:
                        str = "Group Estate";
                        break;

                    case 1:
                        str = "Other Group";
                        break;

                    case 2:
                        str = "Pekebun";
                        break;

                    case 3:
                        str = "Agen";
                        break;

                    case 4:
                        str = "Perkebun Agen";
                        break;

                    case 5:
                        str = "Ramp";
                        break;

                    default:
                        break;
                }
                rep.Write("<td align=left>" + str + "</td>");
                rep.Write("<td align=center>&nbsp</td>");
                rep.Write("<td align=center>&nbsp</td>");
                rep.Write("<td align=right>" + $"{this.tRecGroup[this.x]:N0}" + "</td>");
                rep.Write("<td align=left>kg</td>");
                rep.Write("<td align=center>&nbsp</td>");
                rep.Write("<td align=center>&nbsp</td>");
                rep.Write("<td align=right>" + $"{this.tNetGroup[this.x]:N0}" + "</td>");
                rep.Write("<td align=left>kg</td>");
                WBTable table = new WBTable();
                table.OpenTable("vw_trans", "Select * From vw_trans Where " + WBData.CompanyLocation(" and report_date = '" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00'"), WBData.conn);
                table.DR = table.DT.Rows[0];
                if (table.DR["Plasma"].ToString() != "")
                {
                    switch (this.x)
                    {
                        case 0:
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=left>Plasma (Own)</td>");
                            rep.Write("<td align=center>=</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=right>" + $"{this.tPlasma1[this.x]:N0}" + "</td>");
                            rep.Write("<td align=left>kg</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=right>" + $"{this.tPlasma2[this.x]:N0}" + "</td>");
                            rep.Write("<td align=left>kg</td>");
                            break;

                        case 1:
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=left>Plasma (Interco)</td>");
                            rep.Write("<td align=center>=</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=right>" + $"{this.tPlasma1[this.x]:N0}" + "</td>");
                            rep.Write("<td align=left>kg</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=right>" + $"{this.tPlasma2[this.x]:N0}" + "</td>");
                            rep.Write("<td align=left>kg</td>");
                            break;

                        case 2:
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            break;

                        case 3:
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            break;

                        case 4:
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            rep.Write("<td align=center>&nbsp</td>");
                            break;

                        default:
                            break;
                    }
                }
                switch (this.x)
                {
                    case 0:
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=left>M</td>");
                        rep.Write("<td align=center>=</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=right>" + $"{this.tFruitType[this.x]:N0}" + "</td>");
                        rep.Write("<td align=left>kg</td>");
                        break;

                    case 1:
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=left>B</td>");
                        rep.Write("<td align=center>=</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=right>" + $"{this.tFruitType[this.x]:N0}" + "</td>");
                        rep.Write("<td align=left>kg</td>");
                        break;

                    case 2:
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=left>S</td>");
                        rep.Write("<td align=center>=</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=right>" + $"{this.tFruitType[this.x]:N0}" + "</td>");
                        rep.Write("<td align=left>kg</td>");
                        break;

                    case 3:
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=left>K</td>");
                        rep.Write("<td align=center>=</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=right>" + $"{this.tFruitType[this.x]:N0}" + "</td>");
                        rep.Write("<td align=left>kg</td>");
                        break;

                    case 4:
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=left>R</td>");
                        rep.Write("<td align=center>=</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=right>" + $"{this.tFruitType[this.x]:N0}" + "</td>");
                        rep.Write("<td align=left>kg</td>");
                        break;

                    default:
                        break;
                }
                WBTable table2 = new WBTable();
                table2.OpenTable("wb_location", "Select * From wb_location Where " + WBData.CompanyLocation(""), WBData.conn);
                table2.DR = table2.DT.Rows[0];
                if (table2.DR["ISCC_Checked"].ToString() == "Y")
                {
                    int num4 = this.x;
                    if (num4 == 0)
                    {
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=left>NON ISCC</td>");
                        rep.Write("<td align=center>=</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=right>" + $"{this.tIscc[this.x]:N0}" + "</td>");
                        rep.Write("<td align=left>kg</td>");
                    }
                    else if (num4 == 1)
                    {
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=left>ISCC</td>");
                        rep.Write("<td align=center>=</td>");
                        rep.Write("<td align=center>&nbsp</td>");
                        rep.Write("<td align=right>" + $"{this.tIscc[this.x]:N0}" + "</td>");
                        rep.Write("<td align=left>kg</td>");
                    }
                }
                rep.Write("</tr>");
                this.x++;
            }
        }

        private void fillTotal(HTML rep)
        {
            rep.Write("<tr class='bd'>");
            rep.Write("<td colspan=3 align=right>&nbsp</td>");
            rep.Write("<td align=right><b>" + $"{this.tAvg:N2}" + "</b></td>");
            rep.Write("<td align=right><b>" + $"{this.tBunch:N0}" + "</b></td>");
            rep.Write("<td align=right><b>" + $"{this.tUnit:N0}" + "</b></td>");
            rep.Write("<td align=center><b>" + $"{this.tRVCPO:N2}" + "</b></td>");
            rep.Write("<td align=center>&nbsp</td>");
            rep.Write("<td align=right><b>" + $"{this.tNetEstate:N0}" + "</b></td>");
            rep.Write("<td align=right><b>" + $"{this.tRec:N0}" + "</b></td>");
            rep.Write("<td align=right><b>" + $"{this.tDeduc:N0}" + "</b></td>");
            if (this.cbGunny.Checked)
            {
                rep.Write("<td align=right><b>" + $"{this.tGunny:N0}" + "</b></td>");
            }
            rep.Write("<td align=right><b>" + $"{this.tNet:N0}" + "</b></td>");
            this.tNetToday = this.hitTotalSDHI();
            rep.Write("<td align=right><b>" + $"{this.tNetToday:N0}" + "</b></td>");
            rep.Write("</tr>");
        }

        private double hitTotalSDHI()
        {
            double num;
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { " and (report_date >= '", Convert.ToDateTime(this.monthCalendar1.Value.ToString()).Year.ToString(), "-", Convert.ToDateTime(this.monthCalendar1.Value.ToString()).Month.ToString(), "-01 00:00:00' and report_date <= '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), " 00:00:00')" };
            string sqltext = (("Select sum(Netto) as Netto from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray1))) + " and (deleted is null or deleted = 'N' or deleted = '') " + " and (report_date is not null) ") + " and comm_code = '" + this.comboCom.Text + "'";
            if (this.rboGI.Checked)
            {
                sqltext = sqltext + " and IO = 'O' ";
            }
            else if (this.rboGR.Checked)
            {
                sqltext = sqltext + " and IO = 'I' ";
            }
            if (this.count <= 0)
            {
                sqltext = sqltext + " and (Fruits_type = '' or Fruits_type is null) ";
            }
            else
            {
                int index = 0;
                while (true)
                {
                    if (index >= this.cbChecked.Count<string>())
                    {
                        sqltext = sqltext + " ) ";
                        break;
                    }
                    if (this.cbChecked[index] != "")
                    {
                        sqltext = (index != 0) ? (sqltext + " or Fruits_type = '" + this.cbChecked[index] + "' ") : (sqltext + " and ( Fruits_type = '" + this.cbChecked[index] + "' ");
                    }
                    index++;
                }
            }
            table.OpenTable("vw_trans_total", sqltext, WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                num = 0.0;
            }
            else
            {
                table.DR = table.DT.Rows[0];
                num = (table.DR["Netto"].ToString().Length <= 0) ? 0.0 : Convert.ToDouble(table.DR["Netto"].ToString());
            }
            return num;
        }

        private void InitializeComponent()
        {
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.monthCalendar1 = new DateTimePicker();
            this.label1 = new Label();
            this.label5 = new Label();
            this.cbGunny = new CheckBox();
            this.label2 = new Label();
            this.comboCom = new ComboBox();
            this.groupFType = new GroupBox();
            this.checkR = new CheckBox();
            this.checkK = new CheckBox();
            this.checkS = new CheckBox();
            this.checkB = new CheckBox();
            this.checkM = new CheckBox();
            this.grType = new GroupBox();
            this.rboAll = new RadioButton();
            this.rboGI = new RadioButton();
            this.rboGR = new RadioButton();
            this.groupFType.SuspendLayout();
            this.grType.SuspendLayout();
            base.SuspendLayout();
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x1cd, 0x16);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 0x60;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x135, 0x16);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 0x5f;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1a6, 0xd1);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x24);
            this.button2.TabIndex = 0x5e;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x132, 0xd1);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x25);
            this.button1.TabIndex = 0x5d;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x51, 0x79);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0x5b;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x11, 0x7f);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x21, 13);
            this.label1.TabIndex = 0x5c;
            this.label1.Text = "Date ";
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(15, 15);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0xae, 20);
            this.label5.TabIndex = 90;
            this.label5.Text = "Daily Report for FFB";
            this.cbGunny.AutoSize = true;
            this.cbGunny.Location = new Point(20, 0xbc);
            this.cbGunny.Name = "cbGunny";
            this.cbGunny.Size = new Size(0x99, 0x11);
            this.cbGunny.TabIndex = 0x63;
            this.cbGunny.Text = "Show Deduction by Gunny";
            this.cbGunny.UseVisualStyleBackColor = true;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x11, 0x97);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x3a, 13);
            this.label2.TabIndex = 100;
            this.label2.Text = "Commodity";
            this.comboCom.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboCom.FormattingEnabled = true;
            this.comboCom.Location = new Point(0x51, 0x94);
            this.comboCom.Name = "comboCom";
            this.comboCom.Size = new Size(0x9f, 0x15);
            this.comboCom.TabIndex = 0x65;
            this.groupFType.Controls.Add(this.checkR);
            this.groupFType.Controls.Add(this.checkK);
            this.groupFType.Controls.Add(this.checkS);
            this.groupFType.Controls.Add(this.checkB);
            this.groupFType.Controls.Add(this.checkM);
            this.groupFType.Location = new Point(0x138, 60);
            this.groupFType.Name = "groupFType";
            this.groupFType.Size = new Size(220, 0x2d);
            this.groupFType.TabIndex = 0x66;
            this.groupFType.TabStop = false;
            this.groupFType.Text = "Fruit Type";
            this.checkR.AutoSize = true;
            this.checkR.Checked = true;
            this.checkR.CheckState = CheckState.Checked;
            this.checkR.Location = new Point(0xb0, 20);
            this.checkR.Name = "checkR";
            this.checkR.Size = new Size(0x22, 0x11);
            this.checkR.TabIndex = 4;
            this.checkR.Text = "R";
            this.checkR.UseVisualStyleBackColor = true;
            this.checkK.AutoSize = true;
            this.checkK.Checked = true;
            this.checkK.CheckState = CheckState.Checked;
            this.checkK.Location = new Point(0x89, 20);
            this.checkK.Name = "checkK";
            this.checkK.Size = new Size(0x21, 0x11);
            this.checkK.TabIndex = 3;
            this.checkK.Text = "K";
            this.checkK.UseVisualStyleBackColor = true;
            this.checkS.AutoSize = true;
            this.checkS.Checked = true;
            this.checkS.CheckState = CheckState.Checked;
            this.checkS.Location = new Point(0x62, 20);
            this.checkS.Name = "checkS";
            this.checkS.Size = new Size(0x21, 0x11);
            this.checkS.TabIndex = 2;
            this.checkS.Text = "S";
            this.checkS.UseVisualStyleBackColor = true;
            this.checkB.AutoSize = true;
            this.checkB.Checked = true;
            this.checkB.CheckState = CheckState.Checked;
            this.checkB.Location = new Point(0x3b, 20);
            this.checkB.Name = "checkB";
            this.checkB.Size = new Size(0x21, 0x11);
            this.checkB.TabIndex = 1;
            this.checkB.Text = "B";
            this.checkB.UseVisualStyleBackColor = true;
            this.checkM.AutoSize = true;
            this.checkM.Checked = true;
            this.checkM.CheckState = CheckState.Checked;
            this.checkM.Location = new Point(0x12, 20);
            this.checkM.Name = "checkM";
            this.checkM.Size = new Size(0x23, 0x11);
            this.checkM.TabIndex = 0;
            this.checkM.Text = "M";
            this.checkM.UseVisualStyleBackColor = true;
            this.grType.Controls.Add(this.rboAll);
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x13, 60);
            this.grType.Name = "grType";
            this.grType.Size = new Size(0x11a, 0x2d);
            this.grType.TabIndex = 0x67;
            this.grType.TabStop = false;
            this.grType.Text = "Report Type";
            this.rboAll.AutoSize = true;
            this.rboAll.Checked = true;
            this.rboAll.Location = new Point(0x12, 0x12);
            this.rboAll.Name = "rboAll";
            this.rboAll.Size = new Size(0x24, 0x11);
            this.rboAll.TabIndex = 0x7c;
            this.rboAll.TabStop = true;
            this.rboAll.Text = "All";
            this.rboAll.UseVisualStyleBackColor = true;
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(0xba, 0x12);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 0x11;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.rboGR.AutoSize = true;
            this.rboGR.Location = new Point(0x49, 0x12);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0x10;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x22d, 0x10d);
            base.ControlBox = false;
            base.Controls.Add(this.grType);
            base.Controls.Add(this.groupFType);
            base.Controls.Add(this.comboCom);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.cbGunny);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.monthCalendar1);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.label5);
            base.Name = "RepFFBDaily";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Daily Report for FFB";
            base.Load += new EventHandler(this.RepFFBDaily_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepFFBDaily_KeyPress);
            this.groupFType.ResumeLayout(false);
            this.groupFType.PerformLayout();
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void RepFFBDaily_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepFFBDaily_Load(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" AND type='F'"), WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                this.comboCom.Items.Add(row["Comm_Code"].ToString());
            }
            table.Dispose();
        }
    }
}

