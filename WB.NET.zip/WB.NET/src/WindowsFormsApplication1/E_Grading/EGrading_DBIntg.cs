﻿namespace WindowsFormsApplication1.E_Grading
{
    using System;
    using System.ComponentModel;
    using System.Data.SqlClient;
    using WindowsFormsApplication1;

    public class EGrading_DBIntg : Component
    {
        public string sServer;
        public string sDatabase;
        public string sUserID;
        public string sPassword;
        public string ConnStr;
        public string ConnStr_2;
        public string sIntg_Server;
        public static bool connected = false;
        public static SqlConnection conn;
        public static SqlConnection conn_2;

        public static void Close()
        {
            conn.Close();
        }

        public bool Open()
        {
            this.sServer = WBSetting.EG_Server;
            this.sDatabase = WBSetting.EG_Database;
            this.sUserID = WBSetting.EG_usID;
            this.sPassword = WBSetting.EG_password;
            this.sIntg_Server = WBSetting.Intg_Database;
            string[] textArray1 = new string[9];
            textArray1[0] = "server=";
            textArray1[1] = this.sServer;
            textArray1[2] = "; database=";
            textArray1[3] = this.sDatabase;
            textArray1[4] = "; uid=";
            textArray1[5] = this.sUserID;
            textArray1[6] = "; password=";
            textArray1[7] = this.sPassword;
            textArray1[8] = ";MultipleActiveResultSets=true;";
            this.ConnStr = string.Concat(textArray1);
            string[] textArray2 = new string[9];
            textArray2[0] = "server= ";
            textArray2[1] = WBData.sServer;
            textArray2[2] = "; database= ";
            textArray2[3] = this.sIntg_Server;
            textArray2[4] = "; uid=";
            textArray2[5] = WBData.sUserID;
            textArray2[6] = "; password=";
            textArray2[7] = WBData.sPassword;
            textArray2[8] = ";MultipleActiveResultSets=true;";
            this.ConnStr_2 = string.Concat(textArray2);
            try
            {
                conn = new SqlConnection(this.ConnStr);
                conn.Open();
                conn_2 = new SqlConnection(this.ConnStr_2);
                conn_2.Open();
                connected = true;
                return true;
            }
            catch (Exception)
            {
                connected = false;
                return false;
            }
        }

        public bool TestConnect()
        {
            string[] textArray1 = new string[9];
            textArray1[0] = "server=";
            textArray1[1] = this.sServer;
            textArray1[2] = "; database=";
            textArray1[3] = this.sDatabase;
            textArray1[4] = "; uid=";
            textArray1[5] = this.sUserID;
            textArray1[6] = "; password=";
            textArray1[7] = this.sPassword;
            textArray1[8] = ";";
            this.ConnStr = string.Concat(textArray1);
            try
            {
                conn = new SqlConnection(this.ConnStr);
                conn.Open();
                connected = true;
                return true;
            }
            catch (Exception)
            {
                connected = false;
                return false;
            }
        }

        public bool TestConnect_intg()
        {
            this.sIntg_Server = WBSetting.Intg_Database;
            string[] textArray1 = new string[9];
            textArray1[0] = "server= ";
            textArray1[1] = WBData.sServer;
            textArray1[2] = "; database= ";
            textArray1[3] = this.sIntg_Server;
            textArray1[4] = "; uid=";
            textArray1[5] = WBData.sUserID;
            textArray1[6] = "; password=";
            textArray1[7] = WBData.sPassword;
            textArray1[8] = ";MultipleActiveResultSets=true;";
            this.ConnStr_2 = string.Concat(textArray1);
            try
            {
                conn_2 = new SqlConnection(this.ConnStr_2);
                conn_2.Open();
                connected = true;
                return true;
            }
            catch (Exception)
            {
                connected = false;
                return false;
            }
        }
    }
}

