﻿namespace WindowsFormsApplication1
{
    using Camera.Utility;
    using CrystalDecisions.CrystalReports.Engine;
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;
    using WindowsFormsApplication1.E_Grading;
    using WindowsFormsApplication1.Properties;
    using WindowsFormsApplication1.Utility;

    public class FormRegisGatepassEntryId : Form
    {
        private bool firstload = true;
        private bool loadAfterScanCardForSubmit = false;
        public bool saved = false;
        public bool ReplaceAll = false;
        public bool changeDO = false;
        public bool isCopied = false;
        public bool scaneSPB = false;
        public bool expiredSPB = false;
        public string pMode = "";
        public string pUniq = "";
        public string _ref = "";
        private string[] hasil = new string[3];
        public string cCoy = "";
        public string cLoc = "";
        public string gatepassNo = "";
        public string IO = "";
        private string oldUniqNo = "";
        private string oldTruck = "";
        private string oldWX = "";
        private string oldDriver = "";
        private string oldDriverName = "";
        private string oldTransporter = "";
        private string oldFirstTransType = "";
        private string oldContainerCheck = "";
        private string oldNOPW = "";
        private string oldTicketEstate = "";
        private string oldDateEstate = "";
        private string oldTimeEstate = "";
        private string oldGrossEstate = "";
        private string oldTareEstate = "";
        private string oldNetEstate = "";
        private string oldRend = "";
        private bool QCChanged = false;
        private bool update_egrading = false;
        private string lastWX = "-1";
        private string prevWX = "-1";
        public bool changeTDT = false;
        public bool readoptInternalNumber = false;
        public bool changeLoadingNote = false;
        public bool completed = false;
        public bool inprogress_token = false;
        public ReportDocument ticketRpt = new ReportDocument();
        public ReportDocument ticket_multi1 = new ReportDocument();
        public ReportDocument ticket_multi2 = new ReportDocument();
        public ReportDocument ticketLangsir = new ReportDocument();
        public ReportDocument ticketLangsir2 = new ReportDocument();
        public FormRpt fRpt;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private string oldComm = "";
        private string commCode = "";
        private string gpCode = "";
        private string logKey = "";
        private string reason = "";
        private string cardNo = "";
        private string uniqCardNo = "";
        private string Is_Return = "";
        private bool scanStatus = false;
        private string CommType = "";
        private string oldDeliveryNote = "";
        private string oldSeal = "";
        private string oldRemarkTicket = "";
        private string oldRemarkReport = "";
        private string oldAdditionalInfo = "";
        private string oldPL3 = "";
        private bool active_zdotrx = false;
        private bool active_lock_TDT = false;
        private bool oldEstateDifferent = false;
        private string linkedGatepass = "";
        private string[] oldDestination;
        private string tempDoubleSPBRef = "";
        private WBTable tblComm = new WBTable();
        private WBTable tblCtr = new WBTable();
        private WBTable t_truck = new WBTable();
        private WBTable t_tanker = new WBTable();
        private WBTable t_driver = new WBTable();
        private WBTable t_transporter = new WBTable();
        private WBTable t_gatepass = new WBTable();
        private WBTable t_gatepass_dest = new WBTable();
        private WBTable t_Coy = new WBTable();
        private WBTable t_LocationCode = new WBTable();
        private WBTable t_Source = new WBTable();
        private WBTable t_trans = new WBTable();
        private WBTable t_trans_temp = new WBTable();
        private WBTable t_trans_type = new WBTable();
        private WBTable tbl_warning_trace = new WBTable();
        private WBTable sh_return = new WBTable();
        private WBTable tblgp = new WBTable();
        private DataRow transBefore;
        private DataRow transDOBefore;
        private DataTable tmp_transDO = new DataTable();
        private DataTable tmpGP = new DataTable();
        private WBTable tblTransQC = new WBTable();
        private WBTable tblTransDO = new WBTable();
        private WBTable tblTransContainer = new WBTable();
        private WBTable tblTransDOContainer = new WBTable();
        private WBTable tblContainerCheck = new WBTable();
        private WBTable tblTransDiv = new WBTable();
        private WBTable tblCommD = new WBTable();
        private WBTable tblContractDetail = new WBTable();
        private WBTable tblQC = new WBTable();
        private DataGridView dgvDOCont = new DataGridView();
        private string editDoTrace = "";
        private string editTrace = "";
        private WBNFC nfcReader;
        private WBCamera camera;
        private IContainer components = null;
        private Label labelTruckNo;
        private TextBox txt_truck;
        private Button buttonTruck;
        private TextBox txt_transporter_code;
        private Button buttonTransporter;
        private Label labelTransporter;
        private GroupBox grpTruckInfo;
        private TextBox txt_driver_ic;
        private Label labelLicenseNo;
        private Button buttonDriver;
        private Button btn_save;
        private Button btn_cancel;
        private Label lbl_transporter_name;
        private TextBox txt_gp_no;
        private Label lbl_gp_no;
        private Label labelCardNo;
        private Label labelDestination;
        private TextBox textCardNo;
        private Label labelTankerNo;
        private TextBox textTrailerNo;
        private Button buttonTanker;
        private TextBox textTanker;
        private GroupBox groupPhoto;
        private TabControl tabControlPhoto;
        private TabPage tabPage1st;
        private TabPage tabPage2nd;
        private TextBox txtPassengersNames;
        private TextBox txtPassengers;
        private Label lbl_reg_date;
        private DateTimePicker dtRegistration;
        private MaskedTextBox txtRegistrationTime;
        private Label label22;
        private Label labelWX;
        private TabPage tabPage3rd;
        private TabPage tabPage4th;
        private ComboBox comboWX;
        private TabPage tabPageOP;
        private CheckBox checkNOPW;
        private TextBox textWBNo;
        private TextBox textNetEstate;
        private Label labelWBNo;
        private TextBox textTareEstate;
        private TextBox textGrossEstate;
        private Label labelOPNet;
        private Label labelOPTare;
        private Label labelOPGross;
        private Label labelOPDate;
        private DateTimePicker dateDelivery;
        private MaskedTextBox TimeDelivery;
        private TabPage tabPageGeneral;
        private TextBox textRemarkReport;
        private TextBox txt_deli_note;
        private TextBox txt_seal;
        private TextBox textRemarkTicket;
        private DataGridView dgvDO;
        public Button buttonViewDO;
        private Button buttonAddDO;
        public Button buttonDeleteDO;
        private Button buttonEditDO;
        private Label labelDeliveryNote;
        private Label labelRemarkReport;
        private Label labelSealNo;
        private Panel panel_return;
        private Button btn_check;
        private TextBox text_ref_return;
        private CheckBox chk_return;
        private Label labelRemarkTicket;
        private TabControl tabControlInformation;
        private TextBox txtAddInfo;
        private Label labelRef;
        private Label labelDestinationCode;
        private TabPage tabPageQC;
        private DataGridView dgvQC;
        private TabPage tabPageWBDO;
        private ComboBox comboBoxRef;
        private PictureBox _1st_cam4;
        private PictureBox _1st_cam3;
        private PictureBox _1st_cam2;
        private PictureBox _1st_cam5;
        private PictureBox _1st_cam1;
        private PictureBox _2nd_cam4;
        private PictureBox _2nd_cam3;
        private PictureBox _2nd_cam2;
        private PictureBox _2nd_cam5;
        private PictureBox _2nd_cam1;
        private PictureBox _3rd_cam4;
        private PictureBox _3rd_cam3;
        private PictureBox _3rd_cam2;
        private PictureBox _3rd_cam5;
        private PictureBox _3rd_cam1;
        private PictureBox _4th_cam4;
        private PictureBox _4th_cam3;
        private PictureBox _4th_cam2;
        private PictureBox _4th_cam5;
        private PictureBox _4th_cam1;
        private Button btn_print;
        private GroupBox groupOPW;
        private Label labelArrow;
        private Label labelPassengers;
        private Label labelAdditionalInfo;
        private Label labelPassengersNames;
        private TabPage tabPageCont;
        private DataGridView dgvCont;
        private Button buttonContDelete;
        private Button buttonContEdit;
        private Button buttonContAdd;
        private Button buttonAddDest;
        private DataGridView dgvGPDest;
        private Button buttonDeleteDest;
        private Label Garis1;
        private Label labelSplitTrans;
        private ComboBox comboBoxRefTemp;
        private Button btnCheck_OP;
        private TabPage tabPageFFB;
        private RadioButton radioButtonEntryAVG;
        private GroupBox groupBunch;
        private TextBox textBunchTotal;
        private TextBox textBunchDeduc;
        private Label labelTotalBunch;
        private Label labelTotalBunchDeduc;
        private TextBox textAvg;
        private Label labelAverageBunch;
        private RadioButton radioButtonEntryTotalBunch;
        private ShapeContainer shapeContainer2;
        private GroupBox groupFFBReject;
        private Label labelKg;
        private TextBox textRejectedFFBKG;
        private TextBox textRejectedFFBBunch;
        private Label labelRejectedFFBReason;
        private Label labelBunch;
        private TextBox textRejectedFFBReason;
        private Label labelRejectedFFB;
        private GroupBox groupRV;
        private Label labelOER;
        private TextBox textRendCPO;
        private TabPage tabPageDivision;
        private Button buttonDeleteDivision;
        private Button buttonEditDivision;
        private Button buttonAddDivision;
        private DataGridView dgvDivBlock;
        private CheckBox checkEstate;
        private CheckBox checkLastWeighing;
        private Button buttonESPB;
        private Label labelScanMessage;
        private TabPage tabPageDeduction;
        public Button buttonEntryDeduc;
        private CheckBox cBoxDataNotMatch;
        private TextBox textPL3;
        private Label labelPL3;
        private TextBox textDriverName;
        private TextBox textDestination;
        private Button buttonDestination;
        private TabPage tabPageDriverLicenseID;
        private PictureBox _driverLicense_img;
        private CheckBox checkNeedContainerCheck;
        private Button buttonDeleteAllDO;
        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private Label lblTotalDOQtyInKG;
        private Label lblTotalItem;
        private Label label34;
        private Label label59;
        private Label label61;
        private Label lblTotalAllocatedFactNet;
        private Label label63;
        private Button buttonDN;

        public FormRegisGatepassEntryId()
        {
            this.InitializeComponent();
        }

        private void _1st_cam1_Click(object sender, EventArgs e)
        {
            this.preview_img(this._1st_cam1, 1);
        }

        private void _1st_cam2_Click(object sender, EventArgs e)
        {
            this.preview_img(this._1st_cam2, 2);
        }

        private void _1st_cam3_Click(object sender, EventArgs e)
        {
            this.preview_img(this._1st_cam3, 3);
        }

        private void _1st_cam4_Click(object sender, EventArgs e)
        {
            this.preview_img(this._1st_cam4, 4);
        }

        private void _1st_cam5_Click(object sender, EventArgs e)
        {
            this.preview_img(this._1st_cam5, 5);
        }

        private void _2nd_cam1_Click(object sender, EventArgs e)
        {
            this.preview_img(this._2nd_cam1, 1);
        }

        private void _2nd_cam2_Click(object sender, EventArgs e)
        {
            this.preview_img(this._2nd_cam2, 2);
        }

        private void _2nd_cam3_Click(object sender, EventArgs e)
        {
            this.preview_img(this._2nd_cam3, 3);
        }

        private void _2nd_cam4_Click(object sender, EventArgs e)
        {
            this.preview_img(this._2nd_cam4, 4);
        }

        private void _2nd_cam5_Click(object sender, EventArgs e)
        {
            this.preview_img(this._2nd_cam5, 5);
        }

        private void _3rd_cam1_Click(object sender, EventArgs e)
        {
            this.preview_img(this._3rd_cam1, 1);
        }

        private void _3rd_cam2_Click(object sender, EventArgs e)
        {
            this.preview_img(this._3rd_cam2, 2);
        }

        private void _3rd_cam3_Click(object sender, EventArgs e)
        {
            this.preview_img(this._3rd_cam3, 3);
        }

        private void _3rd_cam4_Click(object sender, EventArgs e)
        {
            this.preview_img(this._3rd_cam4, 4);
        }

        private void _3rd_cam5_Click(object sender, EventArgs e)
        {
            this.preview_img(this._3rd_cam5, 5);
        }

        private void _4th_cam1_Click(object sender, EventArgs e)
        {
            this.preview_img(this._4th_cam1, 1);
        }

        private void _4th_cam2_Click(object sender, EventArgs e)
        {
            this.preview_img(this._4th_cam2, 2);
        }

        private void _4th_cam3_Click(object sender, EventArgs e)
        {
            this.preview_img(this._4th_cam3, 3);
        }

        private void _4th_cam4_Click(object sender, EventArgs e)
        {
            this.preview_img(this._4th_cam4, 4);
        }

        private void _4th_cam5_Click(object sender, EventArgs e)
        {
            this.preview_img(this._4th_cam5, 5);
        }

        private void _driverLicense_img_Click(object sender, EventArgs e)
        {
            this.preview_img(this._driverLicense_img, 1);
        }

        private void _InitBlankQC(string pDO_No)
        {
            this.dgvQC.Rows.Clear();
            int count = 0;
            string[] textArray1 = new string[] { "Select * From wb_commodity_detail where Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "' and Comm_Code='", this.dgvDO.Rows[0].Cells["Comm_Code"].Value.ToString().Trim(), "'" };
            this.tblCommD.OpenTable("wb_commodity_detail", string.Concat(textArray1), WBData.conn);
            foreach (DataRow row in this.tblCommD.DT.Rows)
            {
                count = this.dgvQC.Rows.Count;
                this.dgvQC.Rows.Add();
                this.dgvQC.Rows[count].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvQC.Rows[count].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvQC.Rows[count].Cells["DO_No"].Value = this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString();
                this.dgvQC.Rows[count].Cells["QualityControl"].Value = " ";
                this.dgvQC.Rows[count].Cells["Tank"].Value = " ";
                this.dgvQC.Rows[count].Cells["Estate"].Value = "0";
                this.dgvQC.Rows[count].Cells["Factory"].Value = "";
                this.dgvQC.Rows[count].Cells["deduct"].Value = (row["deduct"].ToString().ToUpper() == "TRUE") ? "Y" : "N";
                this.dgvQC.Rows[count].Cells["QCode"].Value = row["QCode"].ToString();
                this.dgvQC.Rows[count].Cells["QName"].Value = row["QName"].ToString();
                this.dgvQC.Rows[count].Cells["Comm_Code"].Value = this.dgvDO.Rows[0].Cells["Comm_Code"].Value;
                this.dgvQC.Rows[count].Cells["Relation_Code"].Value = this.dgvDO.Rows[0].Cells["Relation_Code"].Value;
                this.dgvQC.Rows[count].Cells["Estate_Code"].Value = this.dgvDO.Rows[0].Cells["Estate"].Value;
                string[] textArray2 = new string[9];
                textArray2[0] = "SELECT * FROM wb_contract_detail a, wb_yield b WHERE a.SAP_code = b.SAP_code AND b.Coy = '";
                textArray2[1] = WBData.sCoyCode;
                textArray2[2] = "' AND b.Location_Code = '";
                textArray2[3] = WBData.sLocCode;
                textArray2[4] = "' AND a.Do_No = '";
                textArray2[5] = this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString();
                textArray2[6] = "' AND b.Yield_Code = '";
                textArray2[7] = row["QCode"].ToString();
                textArray2[8] = "' ";
                string sqltext = string.Concat(textArray2);
                this.tblContractDetail.OpenTable("wb_contract_detail", sqltext, WBData.conn);
                this.dgvQC.Rows[count].Cells["SAP_Value"].Value = (this.tblContractDetail.DT.Rows.Count <= 0) ? "0" : this.tblContractDetail.DT.Rows[0]["SAP_Value"].ToString();
                this.dgvQC.Refresh();
            }
        }

        private void autoChooseDestination()
        {
            WBTable table;
            if (this.pMode != "ADD")
            {
                return;
            }
            else
            {
                table = new WBTable();
                string[] textArray1 = new string[] { "SELECT TOP 1 d.source_code  FROM wb_gatepass g, wb_gatepass_destination d  WHERE g.Coy = d.Coy AND g.Location_Code = d.Location_Code  AND g.gatepass_number = d.gatepass_number  AND g.Coy = '", WBData.sCoyCode, "' AND g.Location_Code = '", WBData.sLocCode, "'  AND g.truck_number = '", this.txt_truck.Text.Trim(), "'  ORDER BY g.uniq DESC" };
                table.OpenTable("wb_gatepass_destination", string.Concat(textArray1), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    try
                    {
                        this.labelDestinationCode.Text = table.DT.Rows[0]["Source_code"].ToString();
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_checkpoint", "SELECT description FROM wb_checkpoint  WHERE Checkpoint_Code = '" + this.labelDestinationCode.Text + "'", WBData.conn);
                        this.textDestination.Text = table2.DT.Rows[0]["Description"].ToString();
                        table2.Dispose();
                    }
                    catch
                    {
                        this.textDestination.Text = this.t_Source.DT.Rows[0]["Description"].ToString();
                        this.labelDestinationCode.Text = this.t_Source.DT.Rows[0]["Source_code"].ToString();
                    }
                }
            }
            table.Dispose();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btn_check_Click(object sender, EventArgs e)
        {
            this.text_ref_return.Text = this.text_ref_return.Text.Trim();
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "SELECT * FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND returref = '", this.text_ref_return.Text, "'  AND ( deleted <> 'Y' OR deleted IS NULL)" };
            string sqltext = string.Concat(textArray1);
            if (this.comboBoxRef.Text != "")
            {
                sqltext = sqltext + " AND ref <> '" + this.comboBoxRef.Text.Trim() + "' ";
            }
            table.OpenTable("wb_transaction", sqltext, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                MessageBox.Show("Reference no has been used! Please check again!", Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                table.OpenTable("wb_transDO", "SELECT * FROM wb_transdo WHERE " + WBData.CompanyLocation(" AND (return_qty_kg <> '' OR return_qty_pack <> '') and ref = '" + this.text_ref_return.Text + "'"), WBData.conn);
                string[] aField = new string[] { "ref" };
                string[] aFind = new string[] { this.text_ref_return.Text };
                DataRow data = this.sh_return.GetData(aField, aFind);
                if (ReferenceEquals(data, null))
                {
                    MessageBox.Show("Invalid reference no! Please check again.", Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else if ((this.comboBoxRef.Text != "") && (this.text_ref_return.Text == this.comboBoxRef.Text))
                {
                    MessageBox.Show("Can not do return with same reference no! Please check again!", Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else if (table.DT.Rows.Count <= 0)
                {
                    MessageBox.Show("Return qty for feference " + this.text_ref_return.Text.Trim() + " has not been filled yet! Please Check Again!", Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    string str2 = "";
                    this.t_trans_type.OpenTable("wb_transaction_type", "SELECT IO FROM wb_transaction_type WHERE " + WBData.CompanyLocation(" AND transaction_code = '" + data["transaction_code"].ToString() + "'"), WBData.conn);
                    string str3 = this.t_trans_type.DT.Rows[0]["IO"].ToString();
                    WBTable table2 = new WBTable();
                    if (str3 == "I")
                    {
                        table2.OpenTable("wb_transaction_type", "SELECT * FROM wb_transaction_type WHERE " + WBData.CompanyLocation(" AND is_return = 'Y' AND IO = 'O'"), WBData.conn);
                    }
                    else if (str3 == "O")
                    {
                        table2.OpenTable("wb_transaction_type", "SELECT * FROM wb_transaction_type WHERE " + WBData.CompanyLocation(" AND is_return = 'Y' AND IO = 'I'"), WBData.conn);
                    }
                    else
                    {
                        table2.OpenTable("wb_transaction_type", "SELECT * FROM wb_transaction_type WHERE " + WBData.CompanyLocation(" AND is_return = 'Y' AND IO = 'X'"), WBData.conn);
                    }
                    if (table2.DT.Rows.Count != 1)
                    {
                        MessageBox.Show("Please maintain return transaction type for " + data["transaction_code"].ToString(), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        str2 = table2.DT.Rows[0]["transaction_code"].ToString();
                        this.Is_Return = table2.DT.Rows[0]["Is_Return"].ToString().Trim();
                        string[] textArray4 = new string[15];
                        textArray4[0] = "Ref No: ";
                        textArray4[1] = data["ref"].ToString();
                        textArray4[2] = "\nTransaction Code: ";
                        textArray4[3] = data["transaction_code"].ToString();
                        textArray4[4] = "\nReport Date: ";
                        textArray4[5] = data["report_date"].ToString().Substring(0, 10);
                        textArray4[6] = "\nDO No: ";
                        textArray4[7] = data["do_no"].ToString();
                        textArray4[8] = "\nCommodity: ";
                        textArray4[9] = data["comm_code"].ToString();
                        textArray4[10] = "\nFactory Net: ";
                        textArray4[11] = data["net"].ToString();
                        textArray4[12] = "\n\nReturn Quantity from [ ";
                        textArray4[13] = this.text_ref_return.Text.ToUpper();
                        textArray4[14] = " ] will be copied to Other Party Quantity.";
                        MessageBox.Show(string.Concat(textArray4), "Ref Information", MessageBoxButtons.OK);
                        this.dateDelivery.Text = data["Delivery_Date"].ToString();
                        if (this.dgvDO.Rows.Count > 0)
                        {
                            int index = this.dgvDO.Rows.Count - 1;
                            while (true)
                            {
                                if (index < 0)
                                {
                                    break;
                                }
                                this.dgvDO.Rows.RemoveAt(index);
                                index--;
                            }
                        }
                        if (this.dgvDO.Rows.Count == 0)
                        {
                            this.dgvDO.Rows.Add();
                            int num2 = 0;
                            WBTable table3 = new WBTable();
                            table3.OpenTable("wb_transdo", "SELECT * FROM wb_transDo WHERE " + WBData.CompanyLocation(" AND ref = '" + this.text_ref_return.Text.Trim() + "'"), WBData.conn);
                            DataRow row2 = table3.DT.Rows[0];
                            this.dgvDO.Rows[num2].Cells["Coy"].Value = WBData.sCoyCode;
                            this.dgvDO.Rows[num2].Cells["Location_Code"].Value = WBData.sLocCode;
                            this.dgvDO.Rows[num2].Cells["Gatepass_number"].Value = "";
                            this.dgvDO.Rows[num2].Cells["Transaction_Code"].Value = str2;
                            this.dgvDO.Rows[num2].Cells["DO_No"].Value = row2["do_no"].ToString();
                            this.dgvDO.Rows[num2].Cells["Comm_Code"].Value = row2["comm_code"].ToString();
                            this.dgvDO.Rows[num2].Cells["Contract"].Value = row2["contract"].ToString();
                            this.dgvDO.Rows[num2].Cells["Relation_Code"].Value = row2["relation_code"].ToString();
                            this.dgvDO.Rows[num2].Cells["Relation_Name"].Value = row2["relation_name"].ToString();
                            this.dgvDO.Rows[num2].Cells["Netto"].Value = row2["netto"].ToString();
                            this.dgvDO.Rows[num2].Cells["Agen"].Value = row2["agen"].ToString();
                            this.dgvDO.Rows[num2].Cells["Estate"].Value = row2["estate"].ToString();
                            this.dgvDO.Rows[num2].Cells["ConvNett"].Value = row2["convnett"].ToString();
                            this.dgvDO.Rows[num2].Cells["ConvUnit"].Value = row2["convunit"].ToString();
                            this.dgvDO.Rows[num2].Cells["PI_No"].Value = row2["pi_no"].ToString();
                            this.dgvDO.Rows[num2].Cells["Transporter_Code"].Value = row2["transporter_code"].ToString();
                            this.dgvDO.Rows[num2].Cells["Storage_code"].Value = row2["storage_code"].ToString();
                            this.dgvDO.Rows[num2].Cells["STO1X"].Value = row2["sto1x"].ToString();
                            this.dgvDO.Rows[num2].Cells["DO1X"].Value = row2["do1x"].ToString();
                            this.dgvDO.Rows[num2].Cells["Tolling"].Value = row2["tolling"].ToString();
                            this.dgvDO.Rows[num2].Cells["Estate_qty"].Value = row2["return_qty_kg"].ToString();
                            this.textGrossEstate.Text = row2["return_qty_kg"].ToString();
                            this.textNetEstate.Text = row2["return_qty_kg"].ToString();
                            this.textTareEstate.Text = "0";
                            this.dgvDO.Rows[num2].Cells["loading_qty_opw"].Value = row2["return_qty_pack"].ToString();
                            this.dgvDO.Rows[num2].Cells["loading_qty"].Value = "0";
                            this.dgvDO.Rows[num2].Cells["so_item_detail"].Value = row2["so_item_detail"].ToString();
                            if ((row2["internal_number"].ToString() != "") && (row2["internal_number"].ToString().Length > 10))
                            {
                                this.dgvDO.Rows[num2].Cells["do_base_uom"].Value = row2["do_base_uom"].ToString();
                                this.dgvDO.Rows[num2].Cells["do_uom"].Value = row2["do_uom"].ToString();
                                this.dgvDO.Rows[num2].Cells["do_sap"].Value = row2["do_sap"].ToString();
                                this.dgvDO.Rows[num2].Cells["do_sap_item"].Value = row2["do_sap_item"].ToString();
                                this.dgvDO.Rows[num2].Cells["internal_number"].Value = row2["internal_number"].ToString();
                                this.dgvDO.Rows[num2].Cells["internal_number_item"].Value = row2["internal_number_item"].ToString();
                            }
                            this.dgvDO.Rows[num2].Cells["return_qty_kg"].Value = "0";
                            this.dgvDO.Rows[num2].Cells["return_qty_pack"].Value = "0";
                            this.dgvDO.Rows[num2].Cells["DeducUnitQty"].Value = "0";
                            string[] textArray5 = new string[] { "SELECT * FROM wb_commodity WHERE coy ='", this.cCoy, "' and location_code = '", this.cLoc, "' AND comm_code = '", this.dgvDO.Rows[num2].Cells["Comm_Code"].Value.ToString(), "'" };
                            this.tblComm.OpenTable("wb_commodity", string.Concat(textArray5), WBData.conn);
                            this.tblComm.DR = this.tblComm.DT.Rows[0];
                            object[] objArray1 = new object[] { "Select * from wb_transaction_type where coy ='", this.cCoy, "' and location_code = '", this.cLoc, "' and transaction_code = '", this.dgvDO.Rows[num2].Cells["Transaction_Code"].Value, "'" };
                            this.t_trans_type.OpenTable("wb_transaction_type", string.Concat(objArray1), WBData.conn);
                            this.t_trans_type.DR = this.t_trans_type.DT.Rows[0];
                            WBCondition condition = new WBCondition();
                            DataRow[] dgRows = new DataRow[] { this.t_trans_type.DR, this.tblComm.DR };
                            condition.fillParameter("NOPW", dgRows);
                            string str4 = condition.getResult() ? "Y" : "N";
                            condition.Dispose();
                            if ((WBSetting.Field("NOPW") == "Y") && (str4 == "Y"))
                            {
                                this.checkNOPW.Visible = true;
                                this.checkNOPW.Enabled = true;
                            }
                            else
                            {
                                this.checkNOPW.Checked = false;
                                this.checkNOPW.Visible = false;
                                this.checkNOPW.Enabled = false;
                            }
                        }
                    }
                }
            }
        }

        private void btn_print_Click(object sender, EventArgs e)
        {
            WBTable table;
            if (!WBSetting.gatepassWithoutCard || this.can_submit())
            {
                if (!(((this.textCardNo.Text.Trim() == "") || !this.scanStatus) ? !WBSetting.gatepassWithoutCard : false))
                {
                    if ((!WBSetting.activeBC || this.validDocBC(true)) && (MessageBox.Show(Resource.RegisGatepassMess_027, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes))
                    {
                        if (this.comboWX.SelectedValue.ToString() != "4")
                        {
                            this.updateGatepassandTransaction(this.gatepassNo);
                        }
                        Cursor.Current = Cursors.WaitCursor;
                        this.t_gatepass.DR = this.t_gatepass.DT.Rows[0];
                        this.logKey = this.t_gatepass.DR["uniq"].ToString();
                        this.t_gatepass.DR.BeginEdit();
                        table = new WBTable();
                        table.OpenTable("wb_transaction", "SELECT TOP 1 uniq, WX, date2, time2, printed, printed_by, printed_date FROM wb_transaction WHERE gatepass_number = '" + this.t_gatepass.DR["gatepass_number"].ToString() + "' and (deleted is null or deleted <> 'Y') ORDER BY ref DESC", WBData.conn);
                        if (table.DT.Rows.Count <= 0)
                        {
                            this.t_gatepass.DR["Out_Date"] = DateTime.Now.ToString();
                            this.t_gatepass.DR["Out_Time"] = DateTime.Now.ToString("HH:mm:ss");
                        }
                        else
                        {
                            DataRow row = table.DT.Rows[0];
                            if (((row["WX"].ToString() == "2X") || (row["WX"].ToString() == "NX")) || (row["WX"].ToString() == "4X"))
                            {
                                try
                                {
                                    this.t_gatepass.DR["Out_Date"] = row["Date2"].ToString();
                                    this.t_gatepass.DR["Out_Time"] = row["time2"].ToString();
                                }
                                catch
                                {
                                    this.t_gatepass.DR["Out_Date"] = DateTime.Now.ToString();
                                    this.t_gatepass.DR["Out_Time"] = DateTime.Now.ToString("HH:mm:ss");
                                }
                            }
                            else if (row["WX"].ToString() == "1X")
                            {
                                table.OpenTable("wb_transaction", "SELECT uniq, WX, date4, time4, printed, printed_by, printed_date FROM wb_transaction WHERE linked = '" + this.t_gatepass.DR["ref"].ToString() + "'", WBData.conn);
                                DataRow row2 = table.DT.Rows[0];
                                try
                                {
                                    this.t_gatepass.DR["Out_Date"] = row2["Date4"].ToString();
                                    this.t_gatepass.DR["Out_Time"] = row2["time4"].ToString();
                                }
                                catch
                                {
                                    this.t_gatepass.DR["Out_Date"] = DateTime.Now.ToString();
                                    this.t_gatepass.DR["Out_Time"] = DateTime.Now.ToString("HH:mm:ss");
                                }
                            }
                        }
                        goto TR_0068;
                    }
                }
                else
                {
                    MessageBox.Show(Resource.RegisGatepassMess_006, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.textCardNo.Focus();
                }
                return;
            }
            else
            {
                return;
            }
            goto TR_0068;
        TR_0006:
            base.Close();
            return;
        TR_0007:
            Cursor.Current = Cursors.Default;
            goto TR_0006;
        TR_0068:
            this.t_gatepass.DR["scaneSPB"] = this.scaneSPB ? "Y" : "N";
            this.t_gatepass.DR["Submit_Gatepass"] = "Y";
            this.t_gatepass.DR["Submit_Date"] = DateTime.Now.ToShortDateString();
            this.t_gatepass.DR["Submit_time"] = DateTime.Now.ToShortTimeString();
            this.t_gatepass.DR["Submit_By"] = WBUser.UserID;
            this.t_gatepass.DR.EndEdit();
            this.t_gatepass.Save();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { "SUBMIT-PRINT", WBUser.UserID, "Submit Gatepass" };
            Program.updateLogHeader("wb_gatepass", this.logKey, logField, logValue);
            Cursor.Current = Cursors.Default;
            WBCard.updateCardToFree(this.textCardNo.Text);
            MessageBox.Show(Resource.RegisGatepassMess_041, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            bool flag8 = true;
            if ((this.comboWX.SelectedValue.ToString() == "2") && !WBSetting.print_on_2nd_weight_4x)
            {
                flag8 = false;
            }
            else if (table.DT.Rows.Count <= 0)
            {
                flag8 = false;
            }
            if (this.comboWX.SelectedValue.ToString() == "4")
            {
                flag8 = false;
            }
            if (!flag8)
            {
                goto TR_0006;
            }
            else
            {
                Cursor.Current = Cursors.WaitCursor;
                string[] textArray3 = new string[] { " SELECT * FROM wb_transaction WHERE Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "'  AND gatepass_number = '", this.txt_gp_no.Text.Trim(), "'  AND ((Deleted = 'N' OR Deleted = '' OR Deleted IS NULL) OR (Deleted = 'Y' AND cancel_type = 'R')) AND (zAuto IS NULL OR zAuto = '' OR zAuto = 'N') ORDER BY ref" };
                this.t_trans.OpenTable("wb_transaction", string.Concat(textArray3), WBData.conn);
                if (this.t_gatepass.DT.Rows[0]["WX"].ToString() == "3")
                {
                    using (IEnumerator enumerator = this.t_trans.DT.Rows.GetEnumerator())
                    {
                        WBTable table2;
                        goto TR_001E;
                    TR_0008:
                        table2.Dispose();
                    TR_001E:
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            DataRow current = (DataRow) enumerator.Current;
                            table2 = new WBTable();
                            string[] textArray4 = new string[] { " SELECT * FROM wb_transaction WHERE Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "'  AND linked = '", current["ref"].ToString(), "'  AND ((Deleted = 'N' OR Deleted = '' OR Deleted IS NULL)  OR (Deleted = 'Y' AND cancel_type = 'R')) ORDER BY ref " };
                            table2.OpenTable("wb_transaction", string.Concat(textArray4), WBData.conn);
                            bool flag18 = false;
                            WBTable table3 = new WBTable();
                            int num = 0;
                            while (true)
                            {
                                if (num < table2.DT.Rows.Count)
                                {
                                    string str = table2.DT.Rows[num]["Do_No"].ToString().Trim();
                                    table3.OpenTable("wb_contract", "SELECT so_item FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + str + "'"), WBData.conn);
                                    if (table3.DT.Rows[0]["so_item"].ToString() != "*")
                                    {
                                        num++;
                                        continue;
                                    }
                                    flag18 = true;
                                }
                                table3.Dispose();
                                if (flag18)
                                {
                                    this.print(table2.DT.Rows[0]["ref"].ToString(), table2.DT.Rows[0]["do_no"].ToString(), this.ticket_multi1, false);
                                    this.print(table2.DT.Rows[0]["ref"].ToString(), table2.DT.Rows[0]["do_no"].ToString(), this.ticket_multi2, true);
                                }
                                else
                                {
                                    foreach (DataRow row4 in table2.DT.Rows)
                                    {
                                        this.print(row4["ref"].ToString(), row4["do_no"].ToString(), this.ticketRpt, true);
                                    }
                                }
                                break;
                            }
                            goto TR_0008;
                        }
                        goto TR_0007;
                    }
                }
                if (this.t_gatepass.DT.Rows[0]["WX"].ToString() != "1")
                {
                    bool flag25 = false;
                    WBTable table15 = new WBTable();
                    int num4 = 0;
                    while (true)
                    {
                        if (num4 < this.t_trans.DT.Rows.Count)
                        {
                            string str7 = this.t_trans.DT.Rows[num4]["Do_No"].ToString().Trim();
                            table15.OpenTable("wb_contract", "SELECT so_item FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + str7 + "'"), WBData.conn);
                            if (table15.DT.Rows[0]["so_item"].ToString() != "*")
                            {
                                num4++;
                                continue;
                            }
                            flag25 = true;
                        }
                        table15.Dispose();
                        if (flag25)
                        {
                            this.print(this.t_trans.DT.Rows[0]["ref"].ToString(), this.t_trans.DT.Rows[0]["do_no"].ToString(), this.ticket_multi1, false);
                            this.print(this.t_trans.DT.Rows[0]["ref"].ToString(), this.t_trans.DT.Rows[0]["do_no"].ToString(), this.ticket_multi2, true);
                        }
                        else
                        {
                            foreach (DataRow row13 in this.t_trans.DT.Rows)
                            {
                                this.print(row13["ref"].ToString(), row13["do_no"].ToString(), this.ticketRpt, true);
                            }
                        }
                        break;
                    }
                }
                else
                {
                    int num3 = 0;
                    WBTable table4 = new WBTable();
                    table4.OpenTable("wb_transaction", " SELECT trx.printed, trx.Delivery_Note, trx.printed_by, trx.printed_date, trx.uniq, trx.gatepass_number,  trans.Transporter_Name, trx.truck_number, trx.Name, trx.Time1, trx.Time2,  trx.ref, trx.Date1, trx.Date2, trx.Gross, trx.Tare, trx.Received, trx.Deduction,  trx.net, trx.Printed, trx.Printed_By, trx.Printed_Date  FROM wb_transaction AS trx LEFT JOIN wb_transporter AS trans  ON trans.Transporter_Code = trx.Transporter_Code  AND trans.Coy = trx.Coy  AND trans.Location_Code = trx.Location_Code  WHERE trx.Gatepass_Number = '" + this.t_gatepass.DT.Rows[0]["gatepass_number"].ToString() + "'  AND ((trx.Deleted = 'N' OR trx.Deleted = '' OR trx.Deleted IS NULL)  OR (trx.Deleted = 'Y' AND trx.cancel_type = 'R'))", WBData.conn);
                    string gatepass = table4.DT.Rows[0]["gatepass_number"].ToString();
                    DataSet2 ds = new DataSet2();
                    DataTable table5 = ds.Tables["DataTable1"];
                    string str3 = "";
                    string str4 = "";
                    string str5 = "";
                    DataView defaultView = table4.DT.DefaultView;
                    defaultView.Sort = "[Date2], [Time2]";
                    foreach (DataRow row7 in defaultView.ToTable().Rows)
                    {
                        num3++;
                        DataRow row8 = table5.NewRow();
                        row8["TRANSPORTER"] = row7["Transporter_Name"].ToString();
                        row8["TRUCK"] = row7["Truck_Number"].ToString();
                        row8["DRIVER"] = row7["Name"].ToString();
                        str3 = row7["Name"].ToString();
                        row8["No"] = num3;
                        row8["REF"] = row7["ref"].ToString();
                        str4 = row7["Date1"].ToString().Substring(0, 10);
                        str5 = row7["Time1"].ToString().Substring(0, 5);
                        row8["IN DATETIME"] = str4 + " " + str5;
                        if (row7["Date2"].ToString() != "")
                        {
                            str4 = row7["Date2"].ToString().Substring(0, 10);
                        }
                        if (row7["Time2"].ToString() != "")
                        {
                            str5 = row7["Time2"].ToString().Substring(0, 5);
                        }
                        row8["OUT DATETIME"] = str4 + " " + str5;
                        row8["GROSS"] = row7["Gross"].ToString();
                        row8["TARE"] = row7["Tare"].ToString();
                        row8["RECEIVED"] = row7["Received"].ToString();
                        row8["DEDUCTION"] = row7["Deduction"].ToString();
                        row8["NET"] = row7["net"].ToString();
                        row8["DELIVERYNOTE"] = row7["Delivery_Note"].ToString();
                        table5.Rows.Add(row8);
                    }
                    WBTable table7 = new WBTable();
                    WBTable table8 = new WBTable();
                    DataTable table9 = ds.Tables["DataTable3"];
                    string[] textArray5 = new string[] { "select  coy_addr1, coy_addr2 from wb_location where coy = '", WBData.sCoyCode, "' AND Location_Code = '", WBData.sLocCode, "'" };
                    table7.OpenTable("wb_location", string.Concat(textArray5), WBData.conn);
                    table8.OpenTable("wb_company", "select coy_name from wb_company where coy_code = '" + WBData.sCoyCode + "'", WBData.conn);
                    string str6 = table8.DT.Rows[0]["Coy_Name"].ToString();
                    DataRow row = table9.NewRow();
                    foreach (DataRow row9 in table7.DT.Rows)
                    {
                        row["COY1"] = str6;
                        row["COY2"] = row9["coy_addr1"];
                        row["COY3"] = row9["coy_addr2"];
                    }
                    table9.Rows.Add(row);
                    WBTable table10 = new WBTable();
                    DataTable table11 = ds.Tables["DataTable4"];
                    string[] textArray6 = new string[] { "select Appr_By from wb_location where coy = '", WBData.sCoyCode, "' AND Location_Code = '", WBData.sLocCode, "'" };
                    table10.OpenTable("wb_location", string.Concat(textArray6), WBData.conn);
                    DataRow row6 = table11.NewRow();
                    foreach (DataRow row10 in table10.DT.Rows)
                    {
                        row6["USER"] = WBUser.UserName;
                        row6["APPROVED"] = row10["Appr_By"];
                        row6["TRANSPORTED"] = str3;
                    }
                    table11.Rows.Add(row6);
                    this.print(gatepass, ds, this.ticketLangsir, false);
                    WBTable table12 = new WBTable();
                    DataTable table13 = ds.Tables["DataTable2"];
                    table12.OpenTable("wb_transaction", " SELECT trx.do_no, trxtype.Transaction_Name, comm.comm_name, rel.relation_name, *  FROM wb_transaction AS trx LEFT JOIN wb_transaction_type AS trxtype  ON trx.Transaction_Code = trxtype.Transaction_Code  AND trxtype.Coy = trx.Coy  AND trxtype.Location_Code = trx.Location_Code  LEFT JOIN wb_commodity AS comm  ON trx.Comm_Code = comm.Comm_Code  AND comm.Coy = trx.Coy  AND comm.Location_Code = trx.Location_Code  LEFT JOIN wb_relation AS rel  ON trx.Relation_Code = rel.Relation_Code  AND rel.Coy = trx.Coy  AND rel.Location_Code = trx.Location_Code  WHERE trx.Gatepass_Number = '" + this.t_gatepass.DT.Rows[0]["gatepass_number"].ToString() + "'  AND ((trx.Deleted = 'N' OR trx.Deleted = '' OR trx.Deleted IS NULL)  OR (trx.Deleted = 'Y' AND trx.cancel_type = 'R'))", WBData.conn);
                    DataView view2 = table12.DT.DefaultView;
                    view2.Sort = "[Date2], [Time2]";
                    num3 = 0;
                    foreach (DataRow row11 in view2.ToTable().Rows)
                    {
                        num3++;
                        DataRow row12 = table13.NewRow();
                        row12["No"] = num3;
                        row12["WB DO"] = row11["do_no"].ToString();
                        row12["TRANSACTION TYPE"] = row11["Transaction_Name"].ToString();
                        row12["COMMODITY"] = row11["comm_name"].ToString();
                        row12["RELATION"] = row11["relation_name"].ToString();
                        table13.Rows.Add(row12);
                    }
                    this.print(gatepass, ds, this.ticketLangsir2, true);
                }
            }
            goto TR_0007;
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            bool flag5;
            FormTransCancel cancel;
            WBTable table;
            string str14;
            if (((this.pMode != "EDIT") && (this.pMode != "EDIT_TDT")) || !this.t_gatepass.Locked(this.t_gatepass.DT.Rows[0]["uniq"].ToString(), '0'))
            {
                if (this.can_save())
                {
                    if ((this.pMode != "EDIT") && (this.pMode != "EDIT_TDT"))
                    {
                        goto TR_00D7;
                    }
                    else
                    {
                        this.update_egrading = true;
                        if ((this.active_lock_TDT && (WBSetting.IntegrationSAP == "Y")) && (((this.txt_driver_ic.Text.Trim() != this.oldDriver.Trim()) || (this.txt_truck.Text.Trim() != this.oldTruck.Trim())) || (this.txt_transporter_code.Text.Trim() != this.oldTransporter.Trim())))
                        {
                            if (this.pMode != "EDIT")
                            {
                                if (this.tblCtr.CekTokenCompleted(this.gatepassNo, "", "UNLOCK_TDT", true) != "")
                                {
                                    if (this.tblCtr.DelTokenCompleted(this.gatepassNo, "", "UNLOCK_TDT", true))
                                    {
                                    }
                                }
                                else
                                {
                                    this.cBoxDataNotMatch.Checked = true;
                                    this.cBoxDataNotMatch.Enabled = false;
                                    this.cBoxDataNotMatch.Visible = true;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please use menu EDIT TDT to change TDT info");
                                return;
                            }
                        }
                        if (this.comboBoxRef.Text == "")
                        {
                            goto TR_00DA;
                        }
                        else
                        {
                            table = new WBTable();
                            table.OpenTable("wb_transaction", "SELECT uniq FROM wb_transaction WHERE " + WBData.CompanyLocation(" and Gatepass_Number='" + this.txt_gp_no.Text.Trim() + "'"), WBData.conn);
                            if (table.DT.Rows.Count <= 0)
                            {
                                goto TR_00DC;
                            }
                            else
                            {
                                object[] objArray1 = new object[] { Resource.RegisGatepassMess_028, " ", table.DT.Rows.Count, " ", Resource.RegisGatepassMess_029 };
                                if (MessageBox.Show(string.Concat(objArray1), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                {
                                    int num = 0;
                                    while (true)
                                    {
                                        if (num < table.DT.Rows.Count)
                                        {
                                            table.DR = table.DT.Rows[num];
                                            if (!table.Locked(table.DR["uniq"].ToString(), '0'))
                                            {
                                                num++;
                                                continue;
                                            }
                                            string[] textArray2 = new string[] { Resource.RegisGatepassMess_030, " ", table.DR["ref"].ToString(), " ", Resource.RegisGatepassMess_031 };
                                            MessageBox.Show(string.Concat(textArray2), "FAILED", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        }
                                        else
                                        {
                                            this.ReplaceAll = true;
                                            goto TR_00DC;
                                        }
                                        break;
                                    }
                                }
                                else
                                {
                                    this.ReplaceAll = false;
                                }
                            }
                        }
                        return;
                    }
                }
                else
                {
                    return;
                }
            }
            else
            {
                string text = Resource.RegisGatepassMess_060 + " " + this.t_gatepass.DT.Rows[0]["Gatepass_Number"].ToString();
                if (this.t_gatepass.lockingUser == "SYSTEM")
                {
                    text = text + " " + Resource.RegisGatepassMess_057;
                }
                else
                {
                    string[] textArray1 = new string[] { text, " ", Resource.RegisGatepassMess_058, " (", this.t_gatepass.lockingUser, "). ", Resource.RegisGatepassMess_059 };
                    text = string.Concat(textArray1);
                }
                MessageBox.Show(text, "FAILED", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return;
            }
            goto TR_00DA;
        TR_004D:
            if ((this.pMode == "ADD") && this.isCopied)
            {
                this.t_gatepass_dest.OpenTable("wb_gatepass_destination", "SELECT * FROM wb_gatepass_destination where 1 = 2", WBData.conn);
            }
            foreach (DataGridViewRow row15 in (IEnumerable) this.dgvGPDest.Rows)
            {
                row15.Cells["Gatepass_Number"].Value = this.gatepassNo;
            }
            this.t_gatepass_dest.AddFromDGV_new(this.dgvGPDest, "Gatepass_Number", this.gatepassNo, "", "");
            WBCard.updateCardToActive(this.textCardNo.Text);
            this.insertToQueueTCS();
            if (this.pMode == "ADD")
            {
                WBCard.insertToCardLogforRegistration(this.dgvGPDest, this.gatepassNo, WBCard.getUniqCardNo(this.textCardNo.Text), flag5, this.checkNeedContainerCheck.Enabled);
            }
            if (this.pMode == "EDIT")
            {
                WBCard.checkAndDeleteCardLogforContainerCheck(this.dgvGPDest, this.gatepassNo);
            }
            if (this.oldUniqNo != WBCard.getUniqCardNo(this.textCardNo.Text.Trim()))
            {
                WBCard.updateCardLogIfCardIsChanged(this.gatepassNo, WBCard.getUniqCardNo(this.textCardNo.Text.Trim()));
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            if ((this.pMode == "EDIT") && (WBSetting.Field("Check_Email").Trim() == "Y"))
            {
                if (this.editWarning())
                {
                    object[] objArray3 = new object[0x15];
                    objArray3[0] = "Dear All,<br><br>This email is to notify you that the following registration has been edited :<table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : ";
                    objArray3[1] = WBData.sCoyName;
                    objArray3[2] = "</td></tr><tr class='bd'><td nowrap>Location</td><td nowrap> : ";
                    objArray3[3] = WBSetting.Field("Location_name");
                    objArray3[4] = "</td></tr><tr class='bd'><td nowrap>Date & Time</td><td nowrap> : ";
                    objArray3[5] = WBUtility.GetServerDatetime();
                    objArray3[6] = "</td></tr><tr class='bd'><td nowrap>Gatepass Number</td><td nowrap> : ";
                    objArray3[7] = this.txt_gp_no.Text;
                    objArray3[8] = "</td></tr><tr class='bd'><td nowrap>Truck Number</td><td nowrap> : ";
                    objArray3[9] = this.txt_truck.Text.Trim();
                    objArray3[10] = "</td></tr><tr class='bd'><td nowrap>Change Reason</td><td nowrap> : ";
                    objArray3[11] = this.reason;
                    objArray3[12] = "</td></tr><tr class='bd'><td nowrap>WB User</td><td nowrap> : ";
                    objArray3[13] = WBUser.UserGroup.Trim();
                    objArray3[14] = " ( ";
                    objArray3[15] = WBUser.UserID;
                    objArray3[0x10] = " - ";
                    objArray3[0x11] = WBUser.UserName.Trim();
                    objArray3[0x12] = " ) </td></tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : ";
                    objArray3[0x13] = WBData.sWBCode;
                    objArray3[20] = "</td></tr></table>";
                    string str15 = string.Concat(objArray3);
                    if (this.editTrace.Length > 0)
                    {
                        str15 = str15 + "<br><br>~Changes on Data~<table border=1 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Field</td><td nowrap>Before Edit</td><td nowrap>After Edit</td></tr>" + this.editTrace + "</table><br><br>";
                    }
                    if (this.editDoTrace.Length > 0)
                    {
                        str15 = str15 + "<br><br>~Changes On DO No~<br>" + this.editDoTrace;
                    }
                    WBMail mail = new WBMail();
                    mail.SendMail_Edit(str15 + "<br>Thank you.");
                    mail.Dispose();
                }
                WBTable table9 = new WBTable();
                table9.OpenTable("wb_email", "select * from wb_email where " + WBData.CompanyLocation(" and email_code = 'TRANSLOG' and email_date = '" + DateTime.Now.ToString("yyyy-MM-dd") + " 00:00:00' "), WBData.conn);
                if (table9.DT.Rows.Count <= 0)
                {
                    table9.DR = table9.DT.NewRow();
                    table9.DR["COY"] = WBData.sCoyCode;
                    table9.DR["LOCATION_CODE"] = WBData.sLocCode;
                    table9.DR["Email_code"] = "TRANSLOG";
                    table9.DR["Email_date"] = DateTime.Now.ToString("dd/MM/yyyy");
                    table9.DR["Status"] = "N";
                    table9.DT.Rows.Add(table9.DR);
                    table9.Save();
                }
                else if (table9.DT.Rows[0]["Status"].ToString() == "Y")
                {
                    table9.DR = table9.DT.Rows[0];
                    table9.DR.BeginEdit();
                    table9.DR["Status"] = "N";
                    table9.DR.EndEdit();
                    table9.Save();
                }
                table9.Dispose();
            }
            base.Close();
            return;
        TR_0060:
            foreach (DataGridViewRow row12 in (IEnumerable) this.dgvCont.Rows)
            {
                row12.Cells["Gatepass_Number"].Value = this.gatepassNo;
                row12.Cells["ref"].Value = this.comboBoxRef.Text;
            }
            this.tblTransContainer.AddFromDGV_new(this.dgvCont, "Gatepass_Number", this.gatepassNo, "", "");
            foreach (DataGridViewRow row13 in (IEnumerable) this.dgvDOCont.Rows)
            {
                row13.Cells["Gatepass_Number"].Value = this.gatepassNo;
                row13.Cells["ref"].Value = this.comboBoxRef.Text;
            }
            this.tblTransDOContainer.AddFromDGV_new(this.dgvDOCont, "Gatepass_Number", this.gatepassNo, "", "");
            if (this.tblContainerCheck.DT != null)
            {
                this.tblContainerCheck.Save();
            }
            foreach (DataGridViewRow row14 in (IEnumerable) this.dgvDivBlock.Rows)
            {
                row14.Cells["Gatepass_Number"].Value = this.gatepassNo;
                row14.Cells["ref"].Value = this.comboBoxRef.Text;
            }
            this.tblTransDiv.AddFromDGV_new(this.dgvDivBlock, "Gatepass_Number", this.gatepassNo, "", "");
            goto TR_004D;
        TR_00D7:
            Cursor.Current = Cursors.WaitCursor;
            if (this.pMode == "ADD")
            {
                this.gatepassNo = this.generate_gatepass_no();
                this.t_gatepass.DR = this.t_gatepass.DT.NewRow();
                this.t_gatepass.DR["Gatepass_Number"] = this.gatepassNo;
            }
            else
            {
                this.t_gatepass.DR = this.t_gatepass.DT.Rows[0];
                this.logKey = this.t_gatepass.DR["uniq"].ToString();
                this.t_gatepass.DR.BeginEdit();
            }
            this.t_gatepass.DR["Coy"] = this.cCoy;
            this.t_gatepass.DR["Location_Code"] = this.cLoc;
            this.t_gatepass.DR["WX"] = this.comboWX.SelectedValue.ToString();
            this.t_gatepass.DR["Card_No"] = WBCard.getUniqCardNo(this.textCardNo.Text);
            this.t_gatepass.DR["RegCard_No"] = this.textCardNo.Text.Trim();
            this.t_gatepass.DR["Truck_Number"] = this.txt_truck.Text.Trim();
            this.t_gatepass.DR["Trailer_Number"] = this.textTrailerNo.Text.Trim();
            this.t_gatepass.DR["Transporter_Code"] = this.txt_transporter_code.Text.Trim();
            this.t_gatepass.DR["License_No"] = this.txt_driver_ic.Text.Trim();
            this.t_gatepass.DR["tanker_no"] = this.textTanker.Text;
            this.t_gatepass.DR["Passenger_qty"] = this.txtPassengers.Text;
            this.t_gatepass.DR["Passenger_Names"] = this.txtPassengersNames.Text;
            this.t_gatepass.DR["LastWeighCheck"] = this.checkLastWeighing.Checked ? "Y" : "N";
            this.t_gatepass.DR["EstateDiff"] = this.checkEstate.Checked ? "Y" : "N";
            this.t_gatepass.DR["delivery_note"] = this.txt_deli_note.Text.Trim();
            this.t_gatepass.DR["seal"] = this.txt_seal.Text.Trim();
            this.t_gatepass.DR["remark_ticket"] = this.textRemarkTicket.Text.Trim();
            this.t_gatepass.DR["remark_report"] = this.textRemarkReport.Text.Trim();
            this.t_gatepass.DR["addi_info"] = this.txtAddInfo.Text.Trim();
            this.t_gatepass.DR["PL3_No"] = this.textPL3.Text.Trim();
            this.t_gatepass.DR["mark_return"] = this.chk_return.Checked ? "Y" : "N";
            this.t_gatepass.DR["return_ref"] = this.text_ref_return.Text;
            this.t_gatepass.DR["nopw"] = this.checkNOPW.Checked ? "Y" : "N";
            this.t_gatepass.DR["opref"] = this.textWBNo.Text;
            this.t_gatepass.DR["gross_estate"] = this.textGrossEstate.Text;
            this.t_gatepass.DR["tare_estate"] = this.textTareEstate.Text;
            this.t_gatepass.DR["net_estate"] = this.textNetEstate.Text;
            this.t_gatepass.DR["Delivery_Date"] = this.dateDelivery.Value;
            this.t_gatepass.DR["Delivery_Time"] = this.TimeDelivery.Text;
            this.t_gatepass.DR["entryAVGorBunch"] = !this.radioButtonEntryTotalBunch.Checked ? "0" : "1";
            this.t_gatepass.DR["TotalBunch"] = (this.textBunchTotal.Text.Trim() == "") ? "0" : this.textBunchTotal.Text.Trim();
            this.t_gatepass.DR["TotalBunchGrading"] = (this.textBunchDeduc.Text.Trim() == "") ? "0" : this.textBunchDeduc.Text.Trim();
            this.t_gatepass.DR["Average"] = (this.textAvg.Text.Trim() == "") ? "0" : this.textAvg.Text.Trim();
            this.t_gatepass.DR["Rend_CPO"] = (this.textRendCPO.Text.Trim() == "") ? "0" : this.textRendCPO.Text.Trim();
            this.t_gatepass.DR["TBS_Reject"] = (this.textRejectedFFBBunch.Text.Trim() == "") ? "0" : this.textRejectedFFBBunch.Text.Trim();
            this.t_gatepass.DR["Reason"] = this.textRejectedFFBReason.Text.Trim();
            if (this.dgvQC.Rows.Count <= 0)
            {
                this.t_gatepass.DR["qc_status"] = "P";
            }
            else
            {
                bool flag20 = false;
                string str3 = null;
                if (this.comboWX.SelectedValue.ToString() != this.oldWX.Trim())
                {
                    flag20 = true;
                }
                else if ((this.comboWX.SelectedValue.ToString() != "3") && (this.oldFirstTransType != this.dgvDO.Rows[0].Cells["Transaction_Code"].Value.ToString()))
                {
                    flag20 = true;
                }
                if (flag20)
                {
                    if (this.comboWX.SelectedValue.ToString() == "3")
                    {
                        str3 = "P";
                    }
                    else
                    {
                        DataTable table2 = new DataTable();
                        table2.Columns.Add("WX", typeof(string));
                        object[] values = new object[] { this.comboWX.SelectedValue.ToString() };
                        table2.Rows.Add(values);
                        DataRow row = table2.Rows[0];
                        table2.Dispose();
                        WBTable table3 = new WBTable();
                        WBTable table4 = new WBTable();
                        table3.OpenTable("wb_transaction_type", "SELECT * FROM wb_transaction_type WHERE " + WBData.CompanyLocation(" AND transaction_code = '" + this.dgvDO.Rows[0].Cells["transaction_code"].Value.ToString() + "'"), WBData.conn);
                        table4.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString() + "'"), WBData.conn);
                        string[] aField = new string[] { "Transaction_Code" };
                        string[] aFind = new string[] { this.dgvDO.Rows[0].Cells["transaction_code"].Value.ToString() };
                        DataRow data = table3.GetData(aField, aFind);
                        string[] textArray5 = new string[] { "comm_code" };
                        string[] textArray6 = new string[] { this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString() };
                        DataRow row3 = table4.GetData(textArray5, textArray6);
                        foreach (DataGridViewRow row4 in (IEnumerable) this.dgvGPDest.Rows)
                        {
                            WBTable table5 = new WBTable();
                            table5.OpenTable("wb_checkpoint", "SELECT * FROM wb_checkpoint  WHERE checkpoint_code = '" + row4.Cells["source_code"].Value.ToString() + "'", WBData.conn);
                            string[] textArray7 = new string[] { "checkpoint_code" };
                            string[] textArray8 = new string[] { row4.Cells["source_code"].Value.ToString() };
                            DataRow row5 = table5.GetData(textArray7, textArray8);
                            if (((data != null) && ((row != null) && (row3 != null))) && (row5 != null))
                            {
                                WBCondition condition = new WBCondition();
                                DataRow[] dgRows = new DataRow[] { row5, row, data, row3 };
                                condition.fillParameter("CHECK_QC", dgRows);
                                if (condition.getResult())
                                {
                                    str3 = null;
                                    break;
                                }
                                str3 = "P";
                                condition.Dispose();
                            }
                            table5.Dispose();
                        }
                        table3.Dispose();
                        table4.Dispose();
                        this.t_gatepass.DR["qc_status"] = str3;
                    }
                }
            }
            flag5 = this.checkNeedContainerCheck.Checked;
            this.t_gatepass.DR["need_container_check"] = flag5 ? "Y" : "N";
            if (this.pMode != "ADD")
            {
                this.t_gatepass.DR["Change_By"] = WBUser.UserID;
                this.t_gatepass.DR["Change_Date"] = DateTime.Now;
                this.t_gatepass.DR.EndEdit();
            }
            else
            {
                this.t_gatepass.DR["Deleted"] = "N";
                this.t_gatepass.DR["Submit_Gatepass"] = "N";
                this.t_gatepass.DR["Type"] = "T";
                this.t_gatepass.DR["In_Date"] = DateTime.Now;
                this.t_gatepass.DR["In_Time"] = DateTime.Now.ToString("HH:mm");
                this.t_gatepass.DR["Create_By"] = WBUser.UserID;
                this.t_gatepass.DR["Create_Date"] = DateTime.Now;
                if (this.isCopied)
                {
                    this.t_gatepass.DR["gpmanual"] = "COPY";
                }
                this.t_gatepass.DT.Rows.Add(this.t_gatepass.DR);
            }
            this.t_gatepass.DR["scaneSPB"] = this.scaneSPB ? "Y" : "N";
            this.t_gatepass.Save();
            if (this.update_egrading && WBSetting.activeEGrading)
            {
                try
                {
                    if (new EGrading_DBIntg().TestConnect_intg())
                    {
                        WBTable table6 = new WBTable();
                        table6.OpenTable("wb_trx_edit", "select top 1 * from wb_trx_edit where ref = '" + this.comboBoxRef.Text + "' and flag_edited = 'Y' ", EGrading_DBIntg.conn_2);
                        if (table6.DT.Rows.Count > 0)
                        {
                            table6.DR = table6.DT.Rows[0];
                            table6.DR.BeginEdit();
                            table6.DR["Edit_date"] = DateTime.Now;
                            table6.DR.EndEdit();
                            table6.Save();
                        }
                        else
                        {
                            table6.DR = table6.DT.NewRow();
                            table6.DR["Ref"] = this.comboBoxRef.Text;
                            table6.DR["flag_edited"] = "Y";
                            table6.DR["Edit_date"] = DateTime.Now;
                            table6.DT.Rows.Add(table6.DR);
                            table6.Save();
                        }
                        table6.Dispose();
                    }
                }
                catch (Exception)
                {
                }
            }
            if (((((this.pMode == "EDIT") || (this.pMode == "EDIT_TDT")) && this.ReplaceAll) && (this.comboWX.SelectedValue.ToString() != "4")) && ((((this.txt_driver_ic.Text.Trim() != this.oldDriver.Trim()) || ((this.txt_truck.Text.Trim() != this.oldTruck.Trim()) || ((this.txt_transporter_code.Text.Trim() != this.oldTransporter.Trim()) || ((this.comboWX.SelectedValue.ToString() != this.oldWX.Trim()) || ((this.oldDeliveryNote != this.txt_deli_note.Text.Trim()) || ((this.oldEstateDifferent != this.checkEstate.Checked) || ((this.oldSeal != this.txt_seal.Text.Trim()) || ((this.oldRemarkReport != this.textRemarkReport.Text.Trim()) || ((this.oldRemarkTicket != this.textRemarkTicket.Text.Trim()) || ((this.oldAdditionalInfo != this.txtAddInfo.Text.Trim()) || ((this.oldPL3 != this.textPL3.Text.Trim()) || ((this.oldNOPW != (this.checkNOPW.Checked ? "Y" : "N")) || (this.textWBNo.Text.Trim() != this.oldTicketEstate.Trim()))))))))))))) || ((this.dateDelivery.Value.ToString() != this.oldDateEstate.Trim()) || ((this.TimeDelivery.Text.Trim() != this.oldTimeEstate.Trim()) || ((this.textGrossEstate.Text.Trim() != this.oldGrossEstate.Trim()) || ((this.textTareEstate.Text.Trim() != this.oldTareEstate.Trim()) || ((this.textNetEstate.Text.Trim() != this.oldNetEstate.Trim()) || ((this.textDriverName.Text.Trim() != this.oldDriverName.Trim()) || (this.textRendCPO.Text.Trim() != this.oldRend.Trim())))))))) || this.changeDO))
            {
                string str4 = "";
                if ((this.comboWX.SelectedValue.ToString() == "0") || (this.comboWX.SelectedValue.ToString() == "1"))
                {
                    str4 = "2X";
                }
                else if (this.comboWX.SelectedValue.ToString() == "2")
                {
                    str4 = "4X";
                }
                else if (this.comboWX.SelectedValue.ToString() == "3")
                {
                    str4 = "1X";
                }
                string str5 = this.comboWX.SelectedValue.ToString();
                string str6 = (str5 == "3") ? "" : this.dgvDO.Rows[0].Cells["Comm_Code"].Value.ToString();
                string str7 = (str5 == "3") ? "" : this.dgvDO.Rows[0].Cells["Relation_Code"].Value.ToString();
                string str8 = (str5 == "3") ? "" : this.dgvDO.Rows[0].Cells["Transaction_Code"].Value.ToString();
                string str9 = (str5 == "3") ? "" : this.dgvDO.Rows[0].Cells["Do_No"].Value.ToString();
                string str10 = (str5 == "3") ? "" : this.dgvDO.Rows[0].Cells["PI_NO"].Value.ToString();
                string[] aField = new string[0x1b];
                aField[0] = "License_No";
                aField[1] = "Name";
                aField[2] = "Truck_Number";
                aField[3] = "Transporter_Code";
                aField[4] = "WX";
                aField[5] = "Comm_Code";
                aField[6] = "Relation_Code";
                aField[7] = "Transaction_code";
                aField[8] = "Do_No";
                aField[9] = "PI_NO";
                aField[10] = "EstateDiff";
                aField[11] = "delivery_note";
                aField[12] = "seal";
                aField[13] = "remark_ticket";
                aField[14] = "remark_report";
                aField[15] = "addi_info";
                aField[0x10] = "PL3_No";
                aField[0x11] = "nopw";
                aField[0x12] = "Ticket";
                aField[0x13] = "Delivery_Date";
                aField[20] = "Delivery_Time";
                aField[0x15] = "gross_estate";
                aField[0x16] = "tare_estate";
                aField[0x17] = "net_estate";
                aField[0x18] = "Rend_CPO";
                aField[0x19] = "posted";
                aField[0x1a] = "reposted";
                string[] textArray10 = new string[0x1b];
                textArray10[0] = this.txt_driver_ic.Text.Trim();
                textArray10[1] = this.textDriverName.Text.Trim();
                textArray10[2] = this.txt_truck.Text.Trim();
                textArray10[3] = this.txt_transporter_code.Text.Trim();
                textArray10[4] = str4;
                textArray10[5] = str6;
                textArray10[6] = str7;
                textArray10[7] = str8;
                textArray10[8] = str9;
                textArray10[9] = str10;
                textArray10[10] = this.checkEstate.Checked ? "Y" : "N";
                string[] local1 = textArray10;
                local1[11] = this.txt_deli_note.Text.Trim();
                local1[12] = this.txt_seal.Text.Trim();
                local1[13] = this.textRemarkTicket.Text.Trim();
                local1[14] = this.textRemarkReport.Text.Trim();
                local1[15] = this.txtAddInfo.Text.Trim();
                local1[0x10] = this.textPL3.Text.Trim();
                local1[0x11] = this.checkNOPW.Checked ? "Y" : "N";
                string[] aNewValue = local1;
                aNewValue[0x12] = this.textWBNo.Text.Trim();
                aNewValue[0x13] = this.dateDelivery.Value.ToString();
                aNewValue[20] = this.TimeDelivery.Text.Trim();
                aNewValue[0x15] = this.textGrossEstate.Text.Trim();
                aNewValue[0x16] = this.textTareEstate.Text.Trim();
                aNewValue[0x17] = this.textNetEstate.Text.Trim();
                aNewValue[0x18] = this.textRendCPO.Text.Trim();
                aNewValue[0x19] = "N";
                aNewValue[0x1a] = "N";
                Program.ReplaceAll("wb_transaction", aField, aNewValue, " Gatepass_Number = '" + this.txt_gp_no.Text.Trim() + "'", this.reason + " (Edit gatepass)");
            }
            if (this.pMode == "ADD")
            {
                string[] textArray11 = new string[] { "SELECT uniq FROM wb_gatepass WHERE coy = '", this.cCoy, "' AND location_code = '", this.cLoc, "' AND gatepass_number = '", this.gatepassNo, "' " };
                string sqltext = string.Concat(textArray11);
                WBTable table7 = new WBTable();
                table7.OpenTable("wb_gatepass", sqltext, WBData.conn);
                this.logKey = table7.DT.Rows[0]["uniq"].ToString();
                table7.Dispose();
            }
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { this.pMode, WBUser.UserID, this.reason };
            Program.updateLogHeader("wb_gatepass", this.logKey, logField, logValue);
            if (((this.prevWX != "3") && (this.comboWX.SelectedValue.ToString() == "3")) && (this.tblTransDO.DT.Rows.Count > 0))
            {
                foreach (DataRow row6 in this.tblTransDO.DT.Rows)
                {
                    row6.Delete();
                }
                this.tblTransDO.Save();
            }
            if ((this.comboWX.SelectedValue.ToString() == "3") || (this.comboWX.SelectedValue.ToString() == "4"))
            {
                goto TR_004D;
            }
            else
            {
                int num2 = 0x40;
                int num3 = 0;
                if (this.tblTransDO.DT.Rows.Count > 0)
                {
                    foreach (DataRow row7 in this.tblTransDO.DT.Rows)
                    {
                        row7.Delete();
                    }
                    this.tblTransDO.Save();
                }
                string str12 = "";
                foreach (DataGridViewRow row8 in (IEnumerable) this.dgvDO.Rows)
                {
                    this.tblTransDO.DR = this.tblTransDO.DT.NewRow();
                    int num4 = 0;
                    while (true)
                    {
                        if (num4 >= this.tblTransDO.DT.Columns.Count)
                        {
                            this.tblTransDO.DR["Coy"] = WBData.sCoyCode;
                            this.tblTransDO.DR["Location_Code"] = WBData.sLocCode;
                            this.tblTransDO.DR["Gatepass_Number"] = this.gatepassNo;
                            this.tblTransDO.DR["ref"] = this.comboBoxRef.Text;
                            this.tblTransDO.DR["estate_qty"] = row8.Cells["estate_qty"].Value.ToString();
                            this.tblTransDO.DR["Netto"] = row8.Cells["Netto"].Value.ToString();
                            if (this.chk_return.Checked)
                            {
                                this.tblTransDO.DR["loading_qty_opw"] = this.dgvDO.Rows[0].Cells["loading_qty_opw"].Value.ToString();
                                this.tblTransDO.DR["loading_qty"] = this.dgvDO.Rows[0].Cells["loading_qty"].Value.ToString();
                            }
                            if (this.comboBoxRef.Text != "")
                            {
                                this.tblTransDO.DR["Ref"] = (num3 != 0) ? (this.comboBoxRef.Text + WBUtility.getSplitV2Ext(num2)) : this.comboBoxRef.Text;
                            }
                            this.tblTransDO.DT.Rows.Add(this.tblTransDO.DR);
                            this.tblTransDO.Save();
                            num3++;
                            num2++;
                            break;
                        }
                        str12 = this.tblTransDO.DT.Columns[num4].ColumnName.ToString();
                        bool flag42 = str12.ToUpper() != "UNIQ".ToUpper();
                        if (flag42 && ((row8.Cells[str12].Value != null) && (row8.Cells[str12].Value.ToString().Trim() != "")))
                        {
                            this.tblTransDO.DR[str12] = row8.Cells[str12].Value;
                        }
                        num4++;
                    }
                }
                foreach (DataGridViewRow row9 in (IEnumerable) this.dgvQC.Rows)
                {
                    row9.Cells["Gatepass_Number"].Value = this.gatepassNo;
                    row9.Cells["ref"].Value = this.comboBoxRef.Text;
                }
                this.tblTransQC.AddFromDGV_new(this.dgvQC, "Gatepass_Number", this.gatepassNo, "", "");
                this.tblTransQC.ReOpen();
                if (this.comboBoxRef.Items.Count > 0)
                {
                    int num5 = 1;
                    while (true)
                    {
                        if (num5 >= this.comboBoxRef.Items.Count)
                        {
                            break;
                        }
                        string pVal = this.comboBoxRef.Text + WBUtility.getSplitV2Ext(0x40 + num5);
                        WBTable table8 = new WBTable();
                        table8.OpenTable("wb_transQC", "SELECT * FROM wb_transQC WHERE " + WBData.CompanyLocation(" AND ref = '" + pVal + "'"), WBData.conn);
                        table8.AddFromDGV_new(this.dgvQC, "Ref", pVal, "", "");
                        table8.ReOpen();
                        table8.Dispose();
                        num5++;
                    }
                }
                if (this.pMode != "EDIT")
                {
                    goto TR_0060;
                }
                else
                {
                    str14 = this.checkNeedContainerCheck.Checked ? "Y" : "N";
                    if ((this.oldContainerCheck == "Y") && (str14 == "N"))
                    {
                        WBCard.insertToCardLogforContainerCheck(this.dgvGPDest, this.gatepassNo, WBCard.getUniqCardNo(this.textCardNo.Text));
                        foreach (DataGridViewRow row10 in (IEnumerable) this.dgvCont.Rows)
                        {
                            row10.Cells["pass_flag"].Value = "P";
                        }
                    }
                }
            }
            if ((this.oldContainerCheck == "N") && (str14 == "Y"))
            {
                WBCard.deleteCardLogforContainerCheck(this.gatepassNo, "|reason:EDIT TICK NEED CONTAINER CHECK FROM N to Y");
                foreach (DataGridViewRow row11 in (IEnumerable) this.dgvCont.Rows)
                {
                    row11.Cells["pass_flag"].Value = "R";
                }
            }
            goto TR_0060;
        TR_00DA:
            cancel = new FormTransCancel();
            cancel.label1.Text = "Gatepass No.";
            cancel.textRefNo.Text = this.txt_gp_no.Text;
            cancel.Text = Resource.Main_090;
            cancel.label2.Text = Resource.Main_090 + " : ";
            cancel.textReason.Focus();
            cancel.ShowDialog();
            if (cancel.Saved)
            {
                this.reason = cancel.textReason.Text;
                cancel.Dispose();
                goto TR_00D7;
            }
            return;
        TR_00DC:
            table.Dispose();
            goto TR_00DA;
        }

        private void btnCheck_OP_Click(object sender, EventArgs e)
        {
            if (this.textWBNo.Text.Trim() == "")
            {
                MessageBox.Show("Please Fill in Other Party Reference Doc No");
            }
            else if (this.try_connect())
            {
                string[] strArray = WBSAP.RFC_GET_REF_OP(this.textWBNo.Text.Trim());
                if (strArray[0] != "Error")
                {
                    this.textGrossEstate.Text = strArray[1];
                    this.textTareEstate.Text = strArray[2];
                    this.textNetEstate.Text = strArray[3];
                    this.groupOPW.Enabled = false;
                }
            }
        }

        private void buttonAddDest_Click(object sender, EventArgs e)
        {
            if (this.textDestination.Text != "")
            {
                using (IEnumerator enumerator = ((IEnumerable) this.dgvGPDest.Rows).GetEnumerator())
                {
                    while (true)
                    {
                        if (!enumerator.MoveNext())
                        {
                            break;
                        }
                        DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                        if (current.Cells["source_code"].Value.ToString() == this.labelDestinationCode.Text)
                        {
                            string[] textArray1 = new string[] { Resource.RegisGatepassEntry_004, " ", current.Cells["source_code"].Value.ToString(), " ", Resource.RegisGatepassMess_037 };
                            MessageBox.Show(string.Concat(textArray1), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            return;
                        }
                    }
                }
                if ((this.comboWX.SelectedValue.ToString() != "1") || (this.dgvGPDest.Rows.Count <= 0))
                {
                    DataRow[] rowArray = this.t_Source.DT.Select(" source_Code = '" + this.labelDestinationCode.Text.ToString() + "'");
                    if (rowArray.Length == 0)
                    {
                        MessageBox.Show(Resource.RegisGatepassMess_068, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        bool flag6 = !string.IsNullOrEmpty(rowArray[0]["start_multiple"].ToString());
                        if (this.comboWX.SelectedValue.ToString() != "1")
                        {
                            if (flag6)
                            {
                                MessageBox.Show(Resource.RegisGatepassMess_067, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                return;
                            }
                        }
                        else if (!flag6)
                        {
                            MessageBox.Show(Resource.RegisGatepassMess_066, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return;
                        }
                        this.dgvGPDest.Rows.Add(1);
                        this.dgvGPDest.Rows[this.dgvGPDest.RowCount - 1].Cells["coy"].Value = this.cCoy;
                        this.dgvGPDest.Rows[this.dgvGPDest.RowCount - 1].Cells["location_code"].Value = this.cLoc;
                        this.dgvGPDest.Rows[this.dgvGPDest.RowCount - 1].Cells["source_code"].Value = this.labelDestinationCode.Text;
                        this.dgvGPDest.Rows[this.dgvGPDest.RowCount - 1].Cells["description"].Value = this.textDestination.Text;
                        this.dgvGPDest.Rows[this.dgvGPDest.RowCount - 1].Cells[0].Selected = true;
                        this.checkDestinationRoutes(Constant.CHECKPOINT_CONTAINER_CHECK);
                    }
                }
                else
                {
                    MessageBox.Show(Resource.RegisGatepassEntry_029, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        private void buttonAddDivision_Click(object sender, EventArgs e)
        {
            this.EntryDivBlock("ADD");
        }

        private void buttonAddDO_Click(object sender, EventArgs e)
        {
            this.entryDO("ADD");
            this.countAdditionalInformation();
            if (this.dgvDO.Rows.Count > 0)
            {
                if ((this.oldComm == null) || (this.oldComm == ""))
                {
                    this.oldComm = this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString();
                }
                this.commCode = this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString();
            }
        }

        private void buttonContAdd_Click(object sender, EventArgs e)
        {
            this.entryCont("ADD");
        }

        private void buttonContDelete_Click(object sender, EventArgs e)
        {
            if (this.dgvCont.Rows.Count > 0)
            {
                int index = this.dgvCont.CurrentRow.Index;
                string str = this.dgvCont.Rows[index].Cells["Container"].Value.ToString();
                DataRow[] rowArray = new DataRow[0];
                bool flag = false;
                if (this.dgvCont.Rows[index].Cells["uniq"].Value != null)
                {
                    rowArray = this.tblContainerCheck.DT.Select("uniq_transContainer = '" + this.dgvCont.Rows[index].Cells["uniq"].Value.ToString() + "'");
                    if (rowArray.Length != 0)
                    {
                        flag = true;
                    }
                }
                if (!flag)
                {
                    if (MessageBox.Show(Resource.Mes_Delete_Container + " " + str + "?", "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        this.dgvCont.Rows.Remove(this.dgvCont.Rows[index]);
                        foreach (DataGridViewRow row3 in (IEnumerable) this.dgvDOCont.Rows)
                        {
                            if (row3.Cells["Container"].Value.ToString().Equals(str))
                            {
                                this.dgvDOCont.Rows.Remove(row3);
                            }
                        }
                    }
                }
                else
                {
                    string[] textArray1 = new string[] { Resource.Mes_Delete_Container, " ", str, "? ", Resource.Mes_Delete_Container_2 };
                    if (MessageBox.Show(string.Concat(textArray1), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        this.dgvCont.Rows.Remove(this.dgvCont.Rows[index]);
                        foreach (DataGridViewRow row in (IEnumerable) this.dgvDOCont.Rows)
                        {
                            if (row.Cells["Container"].Value.ToString().Equals(str))
                            {
                                this.dgvDOCont.Rows.Remove(row);
                            }
                        }
                        foreach (DataRow row2 in rowArray)
                        {
                            row2.Delete();
                        }
                    }
                }
            }
        }

        private void buttonContEdit_Click(object sender, EventArgs e)
        {
            this.entryCont("EDIT");
        }

        private void buttonDeleteAllDO_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Resource.Mes_629, "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                int index = this.dgvDO.Rows.Count - 1;
                while (true)
                {
                    if (index <= -1)
                    {
                        this.changeDO = true;
                        this.countAdditionalInformation();
                        break;
                    }
                    this.dgvDO.Rows.RemoveAt(index);
                    index--;
                }
            }
        }

        private void buttonDeleteDest_Click(object sender, EventArgs e)
        {
            int index = 0;
            if (this.dgvGPDest.Rows.Count > 0)
            {
                index = this.dgvGPDest.CurrentRow.Index;
                this.dgvGPDest.Rows.RemoveAt(this.dgvGPDest.SelectedRows[0].Index);
                if (index > 0)
                {
                    this.dgvGPDest.Rows[index - 1].Cells[0].Selected = true;
                }
                this.checkDestinationRoutes(Constant.CHECKPOINT_CONTAINER_CHECK);
            }
        }

        private void buttonDeleteDivision_Click(object sender, EventArgs e)
        {
            if (this.dgvDivBlock.Rows.Count > 0)
            {
                int index = this.dgvDivBlock.CurrentRow.Index;
                if (MessageBox.Show(Resource.Mes_452, "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.dgvDivBlock.Rows.Remove(this.dgvDivBlock.Rows[index]);
                }
            }
        }

        private void buttonDeleteDO_Click(object sender, EventArgs e)
        {
            if (this.dgvDO.Rows.Count > 0)
            {
                int index = this.dgvDO.CurrentRow.Index;
                if (MessageBox.Show(Resource.Mes_452, "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.dgvDO.Rows.Remove(this.dgvDO.Rows[index]);
                    this.changeDO = true;
                    this.countAdditionalInformation();
                }
            }
        }

        private void buttonDestination_Click(object sender, EventArgs e)
        {
            FormDestination destination = new FormDestination {
                pMode = "CHOOSE",
                sentWX = this.comboWX.SelectedValue.ToString(),
                pFind = this.textDestination.Text
            };
            destination.ShowDialog();
            if (destination.ReturnRow != null)
            {
                this.textDestination.Text = destination.ReturnRow["Description"].ToString();
                this.labelDestinationCode.Text = destination.ReturnRow["Source_Code"].ToString();
                this.textDestination.Focus();
            }
            destination.Dispose();
            this.textDestination.Focus();
        }

        private void buttonDN_Click(object sender, EventArgs e)
        {
            FormSPBv2 bv = new FormSPBv2();
            bv.ShowDialog();
            bv.Dispose();
        }

        private void buttonDriver_Click(object sender, EventArgs e)
        {
            FormDriver driver = new FormDriver();
            if ((this.active_lock_TDT && (this.pMode != "EDIT_TDT")) && (WBSetting.IntegrationSAP == "Y"))
            {
                driver.pMode = "";
            }
            else
            {
                driver.pMode = "CHOOSE";
                driver.pFind = this.txt_driver_ic.Text;
            }
            driver.ShowDialog();
            if (driver.ReturnRow != null)
            {
                this.txt_driver_ic.Text = driver.ReturnRow["License_No"].ToString();
                this.textDriverName.Text = driver.ReturnRow["Name"].ToString();
                if (this.txt_truck.Text.Trim() == "")
                {
                    this.txt_truck.Text = driver.ReturnRow["Truck_Number"].ToString();
                    this.txt_truck.Focus();
                }
                if (WBSetting.activeRegistrationRequireLicensePhoto)
                {
                    this.camera.loadImageV2(WBSetting.licensePhoto_path, "LICENSEID_" + driver.ReturnRow["Uniq"].ToString() + ".jpg", this._driverLicense_img);
                }
            }
            driver.Dispose();
            this.txt_driver_ic.Focus();
        }

        private void buttonEditDivision_Click(object sender, EventArgs e)
        {
            if (this.dgvDivBlock.Rows.Count > 0)
            {
                this.EntryDivBlock("EDIT");
            }
        }

        private void buttonEditDO_Click(object sender, EventArgs e)
        {
            if (this.dgvDO.Rows.Count >= 1)
            {
                this.entryDO("EDIT");
                this.countAdditionalInformation();
            }
        }

        private void buttonEntryDeduc_Click(object sender, EventArgs e)
        {
            FormTransDeducUnitEntry entry = new FormTransDeducUnitEntry {
                dgvDO = this.dgvDO
            };
            entry.ShowDialog();
            if (entry.saved)
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
                {
                    foreach (DataGridViewRow row2 in (IEnumerable) entry.dgvDODeduc.Rows)
                    {
                        if (row.Cells["DO_NO"].Value.ToString().Trim().ToUpper() == row2.Cells["DO_NO"].Value.ToString().Trim().ToUpper())
                        {
                            row.Cells["WeightPerUnitName"].Value = row2.Cells["WeightPerUnitName"].Value;
                            row.Cells["DeducUnitQty"].Value = row2.Cells["DeducUnitQty"].Value;
                            row.Cells["TotalDeducUnit"].Value = row2.Cells["TotalDeducUnit"].Value;
                            row.Cells["Deduction"].Value = row2.Cells["TotalDeducUnit"].Value;
                            row.Cells["UnitName"].Value = row2.Cells["UnitName"].Value;
                            break;
                        }
                    }
                }
            }
            entry.Dispose();
        }

        private void buttonESPB_Click(object sender, EventArgs e)
        {
            if (!this.nfcReader.connected())
            {
                MessageBox.Show(Resource.RegisGatepassMess_055, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                string str = this.nfcReader.readCard();
                if (str != "0")
                {
                    MessageBox.Show(Resource.RegisGatepassMess_017 + "\n" + str, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    this.tabPageShow("F", this.tabPageGeneral);
                    this.txt_truck.Text = ((this.nfcReader.getTruck() != null) || (this.nfcReader.getTruck() != "")) ? this.nfcReader.getTruck() : this.txt_truck.Text;
                    this.txt_driver_ic.Text = ((this.nfcReader.getDriverID() != null) || (this.nfcReader.getDriverID() != "")) ? this.nfcReader.getDriverID() : this.txt_driver_ic.Text;
                    this.textDriverName.Text = ((this.nfcReader.getDriverName() != null) || (this.nfcReader.getDriverName() != "")) ? this.nfcReader.getDriverName() : this.textDriverName.Text;
                    this.txt_deli_note.Text = ((this.nfcReader.getSPB() != null) || (this.nfcReader.getSPB() != "")) ? this.nfcReader.getSPB() : this.txt_deli_note.Text;
                    this.txt_deli_note.Enabled = (this.nfcReader.getSPB() == null) && (this.nfcReader.getSPB() == "");
                    this.textRemarkTicket.Text = ((this.nfcReader.getRemarkTicket() != null) || (this.nfcReader.getRemarkTicket() != "")) ? this.nfcReader.getRemarkTicket() : this.textRemarkTicket.Text;
                    this.textRemarkReport.Text = ((this.nfcReader.getRemarkReport() != null) || (this.nfcReader.getRemarkReport() != "")) ? this.nfcReader.getRemarkReport() : this.textRemarkReport.Text;
                    this.txt_seal.Text = ((this.nfcReader.getSeal() != null) || (this.nfcReader.getSeal() != "")) ? this.nfcReader.getSeal() : this.txt_seal.Text;
                    this.txtAddInfo.Text = ((this.nfcReader.getAddiInfo() != null) || (this.nfcReader.getAddiInfo() != "")) ? this.nfcReader.getAddiInfo() : this.txtAddInfo.Text;
                    this.textGrossEstate.Text = ((this.nfcReader.getGrossOPW() != null) || (this.nfcReader.getGrossOPW() != "")) ? this.nfcReader.getGrossOPW() : this.textGrossEstate.Text;
                    this.textGrossEstate.Text = (this.textGrossEstate.Text.Trim() == "") ? "0" : this.textGrossEstate.Text;
                    this.textTareEstate.Text = ((this.nfcReader.getTareOPW() != null) || (this.nfcReader.getTareOPW() != "")) ? this.nfcReader.getTareOPW() : this.textTareEstate.Text;
                    this.textTareEstate.Text = (this.textTareEstate.Text.Trim() == "") ? "0" : this.textTareEstate.Text;
                    this.textNetEstate.Text = ((this.nfcReader.getNetOPW() != null) || (this.nfcReader.getNetOPW() != "")) ? this.nfcReader.getNetOPW() : this.textNetEstate.Text;
                    this.textNetEstate.Text = (this.textNetEstate.Text.Trim() == "") ? "0" : this.textNetEstate.Text;
                    this.dateDelivery.Text = ((this.nfcReader.getDeliveryDate() != null) || (this.nfcReader.getDeliveryDate() != "")) ? this.nfcReader.getDeliveryDate() : this.dateDelivery.Text;
                    this.TimeDelivery.Text = ((this.nfcReader.getDeliveryTime() != null) || (this.nfcReader.getDeliveryTime() != "")) ? this.nfcReader.getDeliveryTime() : this.TimeDelivery.Text;
                    this.textBunchTotal.Text = ((this.nfcReader.getTotalBunch() != null) || (this.nfcReader.getTotalBunch() != "")) ? this.nfcReader.getTotalBunch() : this.textBunchTotal.Text;
                    this.textBunchTotal.Text = (this.textBunchTotal.Text.Trim() == "") ? "0" : this.textBunchTotal.Text;
                    this.textBunchDeduc.Text = ((this.nfcReader.getTotalBunchDeduc() != null) || (this.nfcReader.getTotalBunchDeduc() != "")) ? this.nfcReader.getTotalBunchDeduc() : this.textBunchDeduc.Text;
                    this.textBunchDeduc.Text = (this.textBunchDeduc.Text.Trim() == "") ? "0" : this.textBunchDeduc.Text;
                    this.textBunchDeduc.Text = (this.textBunchDeduc.Text == "0") ? this.textBunchTotal.Text : this.textBunchDeduc.Text;
                    this.textAvg.Text = ((this.nfcReader.getAVG() != null) || (this.nfcReader.getAVG() != "")) ? this.nfcReader.getAVG() : this.textAvg.Text;
                    this.textAvg.Text = (this.textAvg.Text.Trim() == "") ? "0" : this.textAvg.Text;
                    this.textRendCPO.Text = ((this.nfcReader.getRendCPO() != null) || (this.nfcReader.getRendCPO() != "")) ? this.nfcReader.getRendCPO() : this.textRendCPO.Text;
                    this.textRendCPO.Text = (this.textRendCPO.Text.Trim() == "") ? "0" : this.textRendCPO.Text;
                    this.textRejectedFFBBunch.Text = ((this.nfcReader.getTBSRejectBunch() != null) || (this.nfcReader.getTBSRejectBunch() != "")) ? this.nfcReader.getTBSRejectBunch() : this.textRejectedFFBBunch.Text;
                    this.textRejectedFFBBunch.Text = (this.textRejectedFFBBunch.Text.Trim() == "") ? "0" : this.textRejectedFFBBunch.Text;
                    this.textRejectedFFBKG.Text = ((this.nfcReader.getTBSRejectKG() != null) || (this.nfcReader.getTBSRejectKG() != "")) ? this.nfcReader.getTBSRejectKG() : this.textRejectedFFBKG.Text;
                    this.textRejectedFFBKG.Text = (this.textRejectedFFBKG.Text.Trim() == "") ? "0" : this.textRejectedFFBKG.Text;
                    this.textRejectedFFBReason.Text = ((this.nfcReader.getTBSRejectReason() != null) || (this.nfcReader.getTBSRejectReason() != "")) ? this.nfcReader.getTBSRejectReason() : this.textRejectedFFBReason.Text;
                    this.txt_transporter_code.Text = ((this.nfcReader.getTransporter() != null) || (this.nfcReader.getTransporter() != "")) ? this.nfcReader.getTransporter() : this.txt_transporter_code.Text;
                    if (!this.validTruck())
                    {
                        MessageBox.Show(Resource.RegisGatepassMess_016, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    if (!this.validTransporter())
                    {
                        MessageBox.Show(Resource.RegisGatepassMess_053, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    if (!this.validDriverID())
                    {
                        MessageBox.Show(Resource.RegisGatepassMess_017, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    if (this.dgvCont.Rows.Count == 0)
                    {
                        if (this.check_truck_inyard(this.txt_truck.Text))
                        {
                            this.txt_truck.SelectAll();
                            this.txt_truck.Focus();
                        }
                        if (this.check_driver_inyard(this.txt_driver_ic.Text))
                        {
                            this.txt_driver_ic.SelectAll();
                            this.txt_driver_ic.Focus();
                        }
                    }
                    this.scaneSPB = true;
                }
                this.HitNetEstate();
            }
        }

        private void buttonTanker_Click(object sender, EventArgs e)
        {
            FormTanker tanker = new FormTanker {
                pMode = "CHOOSE"
            };
            tanker.ShowDialog();
            if (tanker.ReturnRow != null)
            {
                this.textTanker.Text = tanker.ReturnRow["Tanker_No"].ToString();
                this.textTanker.Focus();
            }
            tanker.Dispose();
        }

        private void buttonTransporter_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter();
            if ((this.active_lock_TDT && (this.pMode != "EDIT_TDT")) && (WBSetting.IntegrationSAP == "Y"))
            {
                transporter.pMode = "";
            }
            else
            {
                transporter.pMode = "CHOOSE";
                transporter.pFind = this.txt_transporter_code.Text;
            }
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.txt_transporter_code.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.lbl_transporter_name.Text = transporter.ReturnRow["Transporter_Name"].ToString();
                this.txt_transporter_code.Focus();
            }
            transporter.Dispose();
            this.txt_transporter_code.Focus();
        }

        private void buttonTruck_Click(object sender, EventArgs e)
        {
            FormTruck truck = new FormTruck();
            if ((this.active_lock_TDT && (this.pMode != "EDIT_TDT")) && (WBSetting.IntegrationSAP == "Y"))
            {
                truck.pMode = "";
            }
            else
            {
                truck.pMode = "CHOOSE";
                truck.pFind = this.txt_truck.Text;
            }
            truck.ShowDialog();
            if (truck.ReturnRow != null)
            {
                this.txt_truck.Text = truck.ReturnRow["Truck_Number"].ToString();
                if (this.txt_transporter_code.Text.Trim() == "")
                {
                    this.txt_transporter_code.Text = truck.ReturnRow["Transporter_Code"].ToString();
                    string[] aField = new string[] { "Transporter_Code" };
                    string[] aFind = new string[] { this.txt_transporter_code.Text };
                    DataRow data = this.t_transporter.GetData(aField, aFind);
                    if (data != null)
                    {
                        this.lbl_transporter_name.Text = data["Transporter_Name"].ToString();
                    }
                }
            }
            truck.Dispose();
            this.txt_truck.Focus();
        }

        private void buttonViewDO_Click(object sender, EventArgs e)
        {
            if (this.dgvDO.Rows.Count >= 1)
            {
                this.entryDO("VIEW");
            }
        }

        private bool can_save()
        {
            double num;
            bool flag3;
            if (!(((this.pMode == "ADD") && WBCamera.ImageCompareString(this._driverLicense_img.Image, Resources.NoImage)) && WBSetting.activeRegistrationRequireLicensePhoto))
            {
                if ((this.textCardNo.Text.Trim() != "") || WBSetting.gatepassWithoutCard)
                {
                    if (this.comboWX.Text.Trim() != "")
                    {
                        if ((this.pMode == "ADD") || (this.pMode == "VIEW"))
                        {
                            string pMode = this.pMode;
                            this.uniqCardNo = this.textCardNo.Text;
                            Tuple<bool, string, string, string, string, string, string> tuple = WBCard.scanCard(this.textCardNo.Text, pMode, this.txt_gp_no.Text);
                            this.scanStatus = tuple.Item1;
                            this.labelScanMessage.Text = tuple.Item2;
                            this.cardNo = this.textCardNo.Text.ToUpper();
                            this.textCardNo.Text = tuple.Item7.ToUpper();
                            if (!this.scanStatus)
                            {
                                this.labelScanMessage.ForeColor = Color.Red;
                            }
                            else
                            {
                                this.labelScanMessage.Text = "OK";
                                this.labelScanMessage.ForeColor = Color.Black;
                            }
                        }
                        if (this.scanStatus || WBSetting.gatepassWithoutCard)
                        {
                            if (this.comboWX.Text.Trim() != "")
                            {
                                if (this.txt_truck.Text.Trim() != "")
                                {
                                    if (this.txt_driver_ic.Text.Trim() != "")
                                    {
                                        if ((Convert.ToInt16(this.txtPassengers.Text) <= 0) || (this.txtPassengersNames.Text.Trim() != ""))
                                        {
                                            if (((this.dgvDO.Rows.Count != 0) || (this.comboWX.SelectedValue.ToString() == "3")) || (this.comboWX.SelectedValue.ToString() == "4"))
                                            {
                                                if (this.dgvGPDest.Rows.Count > 0)
                                                {
                                                    if (this.validTruck())
                                                    {
                                                        if (this.validTransporter())
                                                        {
                                                            if (this.validDriverID())
                                                            {
                                                                if (this.dgvCont.Rows.Count != 0)
                                                                {
                                                                    goto TR_00A6;
                                                                }
                                                                else if (!this.check_truck_inyard(this.txt_truck.Text))
                                                                {
                                                                    if (!this.check_driver_inyard(this.txt_driver_ic.Text))
                                                                    {
                                                                        goto TR_00A6;
                                                                    }
                                                                    else
                                                                    {
                                                                        this.txt_driver_ic.SelectAll();
                                                                        this.txt_driver_ic.Focus();
                                                                        flag3 = false;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    this.txt_truck.SelectAll();
                                                                    this.txt_truck.Focus();
                                                                    flag3 = false;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                MessageBox.Show(Resource.RegisGatepassMess_017, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                                this.txt_driver_ic.SelectAll();
                                                                this.txt_driver_ic.Focus();
                                                                flag3 = false;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            MessageBox.Show(Resource.RegisGatepassMess_053, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                            this.txt_transporter_code.SelectAll();
                                                            this.txt_transporter_code.Focus();
                                                            flag3 = false;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        MessageBox.Show(Resource.RegisGatepassMess_016, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                        this.txt_truck.SelectAll();
                                                        this.txt_truck.Focus();
                                                        flag3 = false;
                                                    }
                                                }
                                                else
                                                {
                                                    MessageBox.Show(Resource.RegisGatepassMess_011, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                    flag3 = false;
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show(Resource.Mes_292, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                this.tabControlInformation.SelectedTab = this.tabPageWBDO;
                                                flag3 = false;
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show(Resource.RegisGatepassMess_010, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                            this.txtPassengersNames.Focus();
                                            flag3 = false;
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show(Resource.RegisGatepassMess_008, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        this.txt_driver_ic.Focus();
                                        flag3 = false;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(Resource.RegisGatepassMess_007, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    this.txt_truck.Focus();
                                    flag3 = false;
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.RegisGatepassMess_014, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                flag3 = false;
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.RegisGatepassMess_006, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            this.textCardNo.Focus();
                            flag3 = false;
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.RegisGatepassMess_014, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.textCardNo.Focus();
                        flag3 = false;
                    }
                }
                else
                {
                    MessageBox.Show(Resource.RegisGatepassMess_006, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.textCardNo.Focus();
                    flag3 = false;
                }
            }
            else
            {
                MessageBox.Show(Resource.RegisGatepassMess_069, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                flag3 = false;
            }
            return flag3;
        TR_00A6:
            num = Program.StrToDouble(this.textNetEstate.Text, 0);
            double num2 = 0.0;
            if (Program.StrToDouble(this.textNetEstate.Text, 0) > 0.0)
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
                {
                    num2 += Program.StrToDouble(row.Cells["Estate_qty"].Value.ToString(), 0);
                }
            }
            if (num2 == num)
            {
                if (this.dgvDO.Rows.Count > 1)
                {
                    string[] source = new string[this.dgvDO.Rows.Count];
                    int index = 0;
                    bool flag24 = false;
                    foreach (DataGridViewRow row2 in (IEnumerable) this.dgvDO.Rows)
                    {
                        if (source.Contains<string>(row2.Cells["Do_No"].Value.ToString()))
                        {
                            flag24 = true;
                            break;
                        }
                        source[index] = row2.Cells["Do_No"].Value.ToString();
                        index++;
                    }
                    if (flag24 && (MessageBox.Show(Resource.RegisGatepassMess_018, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No))
                    {
                        return false;
                    }
                }
                if (this.dgvDO.RowCount > 0)
                {
                    this.t_trans_type.OpenTable("wb_transaction_type", "select * from wb_transaction_type where " + WBData.CompanyLocation(" and transaction_code = '" + this.dgvDO.Rows[0].Cells["transaction_code"].Value.ToString() + "'"), WBData.conn);
                    this.t_trans_type.DR = this.t_trans_type.DT.Rows[0];
                    this.tblComm.OpenTable("wb_comm", "select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString() + "'"), WBData.conn);
                    string[] aField = new string[] { "Comm_Code" };
                    string[] aFind = new string[] { this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString() };
                    this.tblComm.DR = this.tblComm.GetData(aField, aFind);
                    WBCondition condition = new WBCondition();
                    DataRow[] dgRows = new DataRow[] { this.t_trans_type.DR, this.tblComm.DR };
                    condition.fillParameter("NOPW", dgRows);
                    string str3 = condition.getResult() ? "Y" : "N";
                    condition.Dispose();
                    if (((WBSetting.Field("NOPW") != "Y") || (str3 != "Y")) || (this.checkNOPW.Checked || ((this.textGrossEstate.Text != "0") && (this.textGrossEstate.Text != ""))))
                    {
                        WBCondition condition2 = new WBCondition();
                        DataRow[] rowArray2 = new DataRow[] { this.t_trans_type.DR };
                        condition2.fillParameter("TRANS_TANKERNO", rowArray2);
                        string str4 = condition2.getResult() ? "Y" : "N";
                        condition2.Dispose();
                        if ((str4 != "Y") || (this.textTanker.Text.Trim() != ""))
                        {
                            if (!WBSetting.CheckSPB() || !(((this.txt_deli_note.Text.Length > 0) && (this.txt_deli_note.Text != "-")) && this.checkDoubleSPB()))
                            {
                                if (WBSetting.Field("DeliveryNote") == "Y")
                                {
                                    if (!((this.tblComm.DR["TYpe"].ToString() == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))))
                                    {
                                        if (!((this.tblComm.DR["TYpe"].ToString() == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))))
                                        {
                                            if (this.txt_deli_note.Text.Trim() == "")
                                            {
                                                MessageBox.Show(Resource.Mes_294, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                this.tabControlInformation.SelectedTab = this.tabPageGeneral;
                                                this.txt_deli_note.Focus();
                                                return false;
                                            }
                                        }
                                        else
                                        {
                                            this.txt_deli_note.Enabled = false;
                                        }
                                    }
                                    else
                                    {
                                        this.txt_deli_note.Enabled = false;
                                    }
                                    if (this.txt_deli_note.Text.Trim() != "-")
                                    {
                                        if (this.dgvDO.Rows.Count <= 0)
                                        {
                                            MessageBox.Show(Resource.Mes_305, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                            this.tabControlInformation.SelectedTab = this.tabPageGeneral;
                                            this.txt_deli_note.Text = "";
                                            return false;
                                        }
                                        else if (!((this.tblComm.DR["TYpe"].ToString() == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))))
                                        {
                                            if (!((this.tblComm.DR["TYpe"].ToString() == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))))
                                            {
                                                if (((this.tblComm.DR["TYpe"].ToString() == "F") && !this.scaneSPB) && !WBUtility.CheckValidSPB(this.txt_deli_note.Text, this.dgvDO))
                                                {
                                                    this.txt_deli_note.Focus();
                                                    return false;
                                                }
                                            }
                                            else
                                            {
                                                this.txt_deli_note.Enabled = false;
                                            }
                                        }
                                        else
                                        {
                                            this.txt_deli_note.Enabled = false;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show(string.Format(Resource.DeliveryNote_010, this.tempDoubleSPBRef), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.tabControlInformation.SelectedTab = this.tabPageGeneral;
                                this.txt_deli_note.Focus();
                                return false;
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.RegisGatepassEntry_027, "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.textTanker.Focus();
                            return false;
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.RegisGatepassMess_020, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        this.tabControlInformation.SelectedTab = this.tabPageOP;
                        return false;
                    }
                }
                if (this.Is_Return != "Y")
                {
                    using (IEnumerator enumerator3 = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
                    {
                        while (true)
                        {
                            if (!enumerator3.MoveNext())
                            {
                                break;
                            }
                            DataGridViewRow current = (DataGridViewRow) enumerator3.Current;
                            if (this.checkDoOrInternal(current))
                            {
                                flag3 = false;
                            }
                            else if ((current.Cells["do_sap"].Value != null) && (!string.IsNullOrEmpty(current.Cells["do_sap"].Value.ToString()) && this.chekDoOrInternalNo("do_sap", "do_sap_item", "do_besar")))
                            {
                                object[] objArray1 = new object[] { "There are two or more same Do SAP: ", current.Cells["do_sap"].Value, " and DO SAP Item: ", current.Cells["do_sap_item"].Value, " No." };
                                MessageBox.Show(string.Concat(objArray1), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                flag3 = false;
                            }
                            else
                            {
                                if ((current.Cells["internal_number"].Value == null) || (string.IsNullOrEmpty(current.Cells["internal_number"].Value.ToString()) || !this.chekDoOrInternalNo("internal_number", "internal_number_item", "do_besar")))
                                {
                                    continue;
                                }
                                object[] objArray2 = new object[] { "There are two or more same Internal Number: ", current.Cells["internal_number"].Value, " and Internal Number Item: ", current.Cells["internal_number_item"].Value, " No." };
                                MessageBox.Show(string.Concat(objArray2), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                flag3 = false;
                            }
                            return flag3;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show(Resource.RegisGatepassMess_015, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.tabControlInformation.SelectedTab = this.tabPageWBDO;
                return false;
            }
            if (!(WBSetting.activeBC && (this.pMode == "ADD")) || this.validDocBC(false))
            {
                if ((this.comboWX.SelectedValue.ToString() != "2") || (this.dgvDOCont.RowCount > 0))
                {
                    if (this.dgvDO.Rows.Count > 1)
                    {
                        string str5 = "";
                        string str6 = "";
                        WBTable table = new WBTable();
                        WBTable table2 = new WBTable();
                        string[] textArray3 = new string[] { "SELECT * FROM wb_transaction_type WHERE coy = '", this.cCoy, "' AND location_code = '", this.cLoc, "' AND transaction_code = '", this.dgvDO.Rows[0].Cells["transaction_code"].Value.ToString(), "'" };
                        table.OpenTable("wb_transaction_type", string.Concat(textArray3), WBData.conn);
                        if (table.DT.Rows.Count > 0)
                        {
                            str5 = table.DT.Rows[0]["IO"].ToString();
                        }
                        table.Dispose();
                        string[] textArray4 = new string[] { "SELECT * FROM wb_contract WHERE coy = '", this.cCoy, "' AND location_code = '", this.cLoc, "' AND do_no = '", this.dgvDO.Rows[0].Cells["do_no"].Value.ToString(), "'" };
                        table2.OpenTable("wb_contract", string.Concat(textArray4), WBData.conn);
                        if (table2.DT.Rows.Count > 0)
                        {
                            str6 = table2.DT.Rows[0]["DeductedBy"].ToString();
                        }
                        table2.Dispose();
                        if (str5 != "I")
                        {
                            if (str5 == "O")
                            {
                                WBTable table3 = new WBTable();
                                string[] textArray5 = new string[] { "SELECT * FROM wb_commodity WHERE coy = '", this.cCoy, "'  AND location_code = '", this.cLoc, "' AND comm_code = '", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString(), "'" };
                                table3.OpenTable("wb_commodity", string.Concat(textArray5), WBData.conn);
                                if ((table3.DT.Rows.Count > 0) && (table3.DT.Rows[0]["bulkpack"].ToString() == "B"))
                                {
                                    int num4 = 0;
                                    while (true)
                                    {
                                        if (num4 >= this.dgvDO.RowCount)
                                        {
                                            break;
                                        }
                                        if ((this.dgvDO.Rows[num4].Cells["Netto"].Value.ToString() != "") && (this.dgvDO.Rows[num4].Cells["Netto"].Value.ToString() != "0"))
                                        {
                                            num4++;
                                            continue;
                                        }
                                        string[] textArray6 = new string[] { Resource.RegisGatepassMess_032, " ", this.dgvDO.Rows[num4].Cells["Do_No"].Value.ToString(), " ", Resource.RegisGatepassMess_033 };
                                        MessageBox.Show(string.Concat(textArray6), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        this.tabControlInformation.SelectedTab = this.tabPageWBDO;
                                        this.dgvDO.CurrentCell = this.dgvDO.Rows[num4].Cells["Netto"];
                                        return false;
                                    }
                                }
                            }
                        }
                        else if (!this.checkNOPW.Checked)
                        {
                            if (Program.StrToDouble(this.textNetEstate.Text, 0) <= 0.0)
                            {
                                using (IEnumerator enumerator6 = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
                                {
                                    while (true)
                                    {
                                        if (!enumerator6.MoveNext())
                                        {
                                            break;
                                        }
                                        DataGridViewRow current = (DataGridViewRow) enumerator6.Current;
                                        if (current.Cells["netto"].Value.ToString() == "0")
                                        {
                                            MessageBox.Show("Please entry factory net for WB DO " + current.Cells["Do_No"].Value.ToString() + "!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                            this.tabControlInformation.SelectedTab = this.tabPageWBDO;
                                            this.dgvDO.CurrentCell = current.Cells["Netto"];
                                            return false;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                using (IEnumerator enumerator5 = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
                                {
                                    while (true)
                                    {
                                        if (!enumerator5.MoveNext())
                                        {
                                            break;
                                        }
                                        DataGridViewRow current = (DataGridViewRow) enumerator5.Current;
                                        if (current.Cells["estate_qty"].Value.ToString() == "0")
                                        {
                                            MessageBox.Show("Please entry estate quantity for WB DO " + current.Cells["Do_No"].Value.ToString() + "!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                            this.tabControlInformation.SelectedTab = this.tabPageWBDO;
                                            this.dgvDO.CurrentCell = current.Cells["estate_qty"];
                                            return false;
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            using (IEnumerator enumerator4 = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
                            {
                                while (true)
                                {
                                    if (!enumerator4.MoveNext())
                                    {
                                        break;
                                    }
                                    DataGridViewRow current = (DataGridViewRow) enumerator4.Current;
                                    if (current.Cells["netto"].Value.ToString() == "0")
                                    {
                                        MessageBox.Show("Please entry factory net for WB DO " + current.Cells["Do_No"].Value.ToString() + "!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        this.tabControlInformation.SelectedTab = this.tabPageWBDO;
                                        this.dgvDO.CurrentCell = current.Cells["Netto"];
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show(Resource.RegisGatepassMess_023, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.tabControlInformation.SelectedTab = this.tabPageCont;
                    return false;
                }
            }
            else
            {
                return false;
            }
            bool flag = false;
            string text = "";
            if (((this.dgvDO.Rows.Count > 0) && !this.cBoxDataNotMatch.Checked) && this.cBoxDataNotMatch.Visible)
            {
                foreach (DataGridViewRow row7 in (IEnumerable) this.dgvDO.Rows)
                {
                    if ((((row7.Cells["truck_number"].Value != null) && ((row7.Cells["license_number"].Value != null) && (row7.Cells["driver_name"].Value != null))) && (row7.Cells["transporter_code"].Value != null)) && (((row7.Cells["truck_number"].Value.ToString() != "") || ((row7.Cells["license_number"].Value.ToString() == "") || (row7.Cells["driver_name"].Value.ToString() == ""))) || (row7.Cells["transporter_code"].Value.ToString() == "")))
                    {
                        object[] objArray3 = new object[] { text, "DO No ", row7.Cells["Do_No"].Value, " : " };
                        text = (string.Concat(objArray3) + ("\nTruck       : " + row7.Cells["truck_number"].Value.ToString()) + ("\nTransporter : " + row7.Cells["transporter_code"].Value.ToString())) + ("\nDriver      : " + row7.Cells["license_number"].Value.ToString() + " - " + row7.Cells["driver_name"].Value.ToString()) + "\n\n";
                        if (((row7.Cells["truck_number"].Value.ToString() != this.txt_truck.Text) || ((row7.Cells["license_number"].Value.ToString() != this.txt_driver_ic.Text) || (row7.Cells["driver_name"].Value.ToString() != this.textDriverName.Text))) || (row7.Cells["transporter_code"].Value.ToString() != this.txt_transporter_code.Text))
                        {
                            flag = true;
                        }
                    }
                }
                if (flag)
                {
                    if (MessageBox.Show(text, "Data Transportation for each DO is different", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                    {
                        return false;
                    }
                    else
                    {
                        this.cBoxDataNotMatch.Checked = true;
                    }
                }
            }
            if (this.cBoxDataNotMatch.Checked)
            {
                if (this.pMode == "ADD")
                {
                    this.gatepassNo = this.get_latest_gatepassno();
                }
                if (!this.changeTDT)
                {
                    this.hasil = this.tblCtr.tokenOrApp(this.gatepassNo, "", "UNLOCK_TDT", "TOKEN_UNLOCK_TDT", "UNLOCK_TDT", "E", "", null);
                    return (this.hasil[0] != "cancel");
                }
            }
            return (this.CheckTruckNumber(false) ? (this.CheckTransporterCode() ? this.CheckLicenseNumber() : false) : false);
        }

        private bool can_submit()
        {
            WBTable table;
            bool flag = true;
            this.t_gatepass.DR = this.t_gatepass.DT.Rows[0];
            if (this.t_gatepass.DR["Deleted"].ToString() != "Y")
            {
                if (this.t_gatepass.DR["Submit_Gatepass"].ToString() != "Y")
                {
                    if (this.comboWX.SelectedValue.ToString() != "3")
                    {
                        bool flag3;
                        table = new WBTable();
                        string[] textArray1 = new string[] { "SELECT ref, report_date, WX, _2nd, split FROM wb_transaction  WHERE coy = '", this.cCoy, "' AND location_code = '", this.cLoc, "' AND gatepass_number = '", this.txt_gp_no.Text, "' AND ((deleted != 'Y' OR deleted IS NULL) OR (Deleted = 'Y' AND cancel_type = 'R'))" };
                        table.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
                        if (table.DT.Rows.Count <= 0)
                        {
                            if (this.comboWX.SelectedValue.ToString() == "4")
                            {
                                goto TR_0017;
                            }
                            else
                            {
                                MessageBox.Show(Resource.RegisGatepassMess_074, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                flag3 = false;
                            }
                        }
                        else
                        {
                            bool flag11 = false;
                            string str = "";
                            foreach (DataRow row2 in table.DT.Rows)
                            {
                                bool flag12 = row2["split"].ToString() != "X";
                                if (flag12 && (((row2["report_date"].ToString().Trim() != "") || (row2["WX"].ToString() != "2X")) ? (((row2["_2nd"].ToString() == "") || (row2["_2nd"].ToString() == "0")) ? (row2["WX"].ToString() == "4X") : false) : true))
                                {
                                    str = row2["ref"].ToString();
                                    flag11 = true;
                                    break;
                                }
                            }
                            if (!flag11)
                            {
                                goto TR_0017;
                            }
                            else
                            {
                                MessageBox.Show(Resource.RegisGatepassMess_026, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                this.t_trans.Dispose();
                                flag3 = false;
                            }
                        }
                        return flag3;
                    }
                    else if (this.t_gatepass.DR["Ref"].ToString() != "")
                    {
                        if (this.t_trans.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show(Resource.RegisGatepassMess_026, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            this.t_trans.Dispose();
                            return false;
                        }
                        else
                        {
                            using (IEnumerator enumerator = this.t_trans.DT.Rows.GetEnumerator())
                            {
                                while (true)
                                {
                                    if (!enumerator.MoveNext())
                                    {
                                        break;
                                    }
                                    DataRow current = (DataRow) enumerator.Current;
                                    bool flag8 = current["split"].ToString() != "X";
                                    if (flag8 && (((current["_4th"].ToString() == "") || (current["_4th"].ToString() == "0")) ? (current["Report_Date"].ToString() == "") : false))
                                    {
                                        MessageBox.Show(Resource.RegisGatepassMess_026, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        this.t_trans.Dispose();
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show(Resource.RegisGatepassMess_025, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return false;
                }
            }
            else
            {
                MessageBox.Show(Resource.RegisGatepassMess_024, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return false;
            }
            return flag;
        TR_0017:
            table.Dispose();
            return flag;
        }

        private bool check_driver_inyard(string licenseNo)
        {
            bool flag = false;
            string sqltext = "";
            string str2 = "";
            WBTable table = new WBTable();
            if (!this.GetRepDate())
            {
                sqltext = "SELECT * FROM wb_gatepass WHERE  (license_no = '" + licenseNo + "') AND (deleted is null or deleted = 'N')  AND (submit_gatepass is null or submit_gatepass= 'N' or submit_gatepass='') ";
                if (this.txt_gp_no.Text.Trim() != "")
                {
                    sqltext = sqltext + " AND gatepass_number != '" + this.txt_gp_no.Text + "'";
                }
                table.OpenTable("wb_gatepass", sqltext, WBData.conn);
                if (table.DT.Rows.Count != 0)
                {
                    foreach (DataRow row2 in table.DT.Rows)
                    {
                        if (this.txt_gp_no.Text.Trim() != row2["gatepass_number"].ToString())
                        {
                            flag = true;
                            MessageBox.Show("Driver Already Registered with Reference No " + row2["Gatepass_number"].ToString() + "!", Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            break;
                        }
                    }
                }
                else
                {
                    WBTable table2 = new WBTable();
                    str2 = "SELECT _2nd,license_no,ref FROM wb_transaction with (nolock) WHERE   license_no = '" + this.txt_driver_ic.Text.Trim() + "' AND (deleted is null or deleted = 'N')  AND (mark_accident IS NULL OR mark_accident = '' or mark_accident = 'N' ) AND (((WX='4X' or WX='2X') AND _2nd=0) or (WX='4X' and (linked IS NOT NULL AND linked != '') and _4th=0) OR (WX='1X' AND (linked is null or linked = '')) OR WX='') AND report_date is null ";
                    if (this.txt_gp_no.Text.Trim() != "")
                    {
                        str2 = str2 + "AND gatepass_number <> '" + this.txt_gp_no.Text + "'";
                    }
                    table2.OpenTable("checkTrx", str2, WBData.conn);
                    int num = 0;
                    while (true)
                    {
                        if (num > table2.DT.Rows.Count)
                        {
                            DataRow row = table2.DT.Rows[num];
                            if (this.txt_gp_no.Text.Trim() == row["gatepass_number"].ToString())
                            {
                                num++;
                                continue;
                            }
                            flag = true;
                            MessageBox.Show("Driver Already Registered with Reference No " + row["ref"].ToString() + "!", Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        table2.Dispose();
                        break;
                    }
                }
            }
            table.Dispose();
            return flag;
        }

        private bool check_truck_inyard(string truck_no)
        {
            bool flag = false;
            string sqltext = "";
            string str2 = "";
            WBTable table = new WBTable();
            if (!this.GetRepDate())
            {
                sqltext = "SELECT * FROM wb_gatepass WHERE  (truck_number = '" + truck_no + "') AND (deleted is null or deleted = 'N')  AND (submit_gatepass is null or submit_gatepass= 'N' or submit_gatepass='') ";
                if (this.txt_gp_no.Text.Trim() != "")
                {
                    sqltext = sqltext + " AND gatepass_number != '" + this.txt_gp_no.Text + "'";
                }
                table.OpenTable("wb_gatepass", sqltext, WBData.conn);
                if (table.DT.Rows.Count != 0)
                {
                    foreach (DataRow row2 in table.DT.Rows)
                    {
                        if (this.txt_gp_no.Text.Trim() != row2["gatepass_number"].ToString())
                        {
                            flag = true;
                            MessageBox.Show(Resource.RegisGatepassMess_012 + " " + row2["Gatepass_number"].ToString() + "!", Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            break;
                        }
                    }
                }
                else
                {
                    WBTable table2 = new WBTable();
                    str2 = "SELECT _2nd,license_no,ref FROM wb_transaction with (nolock) WHERE   (truck_number = '" + truck_no + "') AND (deleted is null or deleted = 'N')  AND (mark_accident IS NULL OR mark_accident = '' or mark_accident = 'N' ) AND (((WX='4X' or WX='2X') AND _2nd=0) or (WX='4X' and (linked IS NOT NULL AND linked != '') and _4th=0) OR (WX='1X' AND (linked is null or linked = '')) OR WX='') AND report_date is null ";
                    if (this.txt_gp_no.Text.Trim() != "")
                    {
                        str2 = str2 + "AND gatepass_number <> '" + this.txt_gp_no.Text + "'";
                    }
                    table2.OpenTable("chkTrx", str2, WBData.conn);
                    int num = 0;
                    while (true)
                    {
                        if (num > table2.DT.Rows.Count)
                        {
                            DataRow row = table2.DT.Rows[num];
                            if (this.txt_gp_no.Text.Trim() == row["gatepass_number"].ToString())
                            {
                                num++;
                                continue;
                            }
                            flag = true;
                            MessageBox.Show(Resource.RegisGatepassMess_012 + " " + row["Gatepass_number"].ToString() + "!", Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        break;
                    }
                }
            }
            table.Dispose();
            return flag;
        }

        private void checkDestinationRoutes(string checkpointCode)
        {
            WBTable table = new WBTable();
            bool flag = false;
            foreach (DataGridViewRow row in (IEnumerable) this.dgvGPDest.Rows)
            {
                string str = row.Cells["source_code"].Value.ToString();
                string[] textArray1 = new string[] { "SELECT * FROM wb_destination_checkpoint WHERE destination_code = '", str, "' AND checkpoint_code = '", checkpointCode, "'" };
                table.OpenTable("wb_destination_checkpoint", string.Concat(textArray1), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    flag = true;
                    break;
                }
            }
            if (flag)
            {
                this.checkNeedContainerCheck.Enabled = true;
            }
            else
            {
                this.checkNeedContainerCheck.Checked = false;
                this.checkNeedContainerCheck.Enabled = false;
            }
        }

        public bool checkDoOrInternal(DataGridViewRow dgv)
        {
            string str = dgv.Cells["do_besar"].Value.ToString();
            string str2 = dgv.Cells["do_sap"].Value.ToString();
            string str3 = dgv.Cells["do_sap_item"].Value.ToString();
            string str4 = dgv.Cells["internal_number"].Value.ToString();
            string str5 = dgv.Cells["internal_number_item"].Value.ToString();
            string mssg = "";
            string text = this.comboBoxRef.Text;
            bool flag = false;
            bool flag2 = false;
            if (((str2 != "") && (str3 != "")) && (str == ""))
            {
                flag = true;
            }
            else if (str4 != "")
            {
                flag2 = true;
            }
            if (flag | flag2)
            {
                string sqltext = "SELECT do.gatepass_number, do.ref, trans.deleted, gate.submit_gatepass, gate.deleted as gdeleted FROM wb_transdo do LEFT JOIN wb_transaction trans ON trans.ref = Do.ref  LEFT JOIN wb_gatepass gate on do.gatepass_number = gate.gatepass_number WHERE (mark_accident IS NULL OR mark_accident = '')   AND ((gate.Deleted IS NULL OR gate.Deleted = '' OR gate.Deleted = 'N') or (gate.Submit_Gatepass IS NULL OR gate.Submit_Gatepass = '' OR gate.Submit_Gatepass = 'N')) ";
                if (flag)
                {
                    string[] textArray1 = new string[] { sqltext, " AND do.do_sap = '", str2, "' AND do.do_sap_item = '", str3, "' " };
                    sqltext = string.Concat(textArray1);
                }
                else if (flag2)
                {
                    string[] textArray2 = new string[] { sqltext, " AND do.internal_number = '", str4, "' AND do.internal_number_item = '", str5, "' " };
                    sqltext = string.Concat(textArray2);
                }
                if (text != "")
                {
                    sqltext = sqltext + " AND Do.ref <> '" + text + "'";
                }
                if (this.text_ref_return.Text != "")
                {
                    sqltext = sqltext + " AND Do.ref <> '" + this.text_ref_return.Text + "'";
                }
                sqltext = sqltext + " order by gate.gatepass_number desc ";
                WBTable table = new WBTable();
                table.OpenTable("wb_transDo", sqltext, WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    string str9 = table.DT.Rows[0]["ref"].ToString();
                    string str10 = table.DT.Rows[0]["gatepass_number"].ToString();
                    string str11 = table.DT.Rows[0]["submit_gatepass"].ToString();
                    if ((((table.DT.Rows[0]["Ref"].ToString() != "") && ((table.DT.Rows[0]["Deleted"].ToString() != "Y") || (table.DT.Rows[0]["submit_gatepass"].ToString() != "Y"))) || (table.DT.Rows[0]["submit_gatepass"].ToString() == "Y")) || (table.DT.Rows[0]["submit_gatepass"].ToString() == "N"))
                    {
                        DataTable dT = table.DT;
                        if (this.checkInUsedDoSapOrInternal(dT, out mssg))
                        {
                            if (flag)
                            {
                                mssg = string.Format(mssg, "DO KECIL " + this.sapIDSYS, "DO KECIL " + this.sapIDSYS);
                            }
                            else if (flag2)
                            {
                                mssg = !WBSetting.adopt_zdotrx ? string.Format(mssg, "Internal Number [ " + str4 + " ]", "Internal Number") : string.Format(mssg, "Loading Note [ " + str4 + " ]", "Loading Note");
                            }
                        }
                    }
                    else if (flag)
                    {
                        string[] textArray3 = new string[] { "DO KECIL ", this.sapIDSYS, " has been used in Gatepass Number ", table.DT.Rows[0]["Gatepass_no"].ToString(), ".\nPlease check again, or use another DO ", this.sapIDSYS, ".\nThank you." };
                        mssg = string.Concat(textArray3);
                    }
                    else if (flag2)
                    {
                        if (WBSetting.adopt_zdotrx)
                        {
                            string[] textArray4 = new string[] { "Loading Note [ ", str4, " ] has been used in Ref [ ", table.DT.Rows[0]["Ref"].ToString(), " ] \nPlease use another Loading Note.\nThank you." };
                            mssg = string.Concat(textArray4);
                        }
                        else
                        {
                            string[] textArray5 = new string[] { "Internal Number [ ", str4, " ] has been used in Ref [ ", table.DT.Rows[0]["Ref"].ToString(), " ] \nPlease use another Internal Number.\nThank you." };
                            mssg = string.Concat(textArray5);
                        }
                    }
                }
                if (mssg != "")
                {
                    MessageBox.Show(mssg, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return true;
                }
            }
            return false;
        }

        private bool checkDoubleSPB()
        {
            bool flag = false;
            string sqltext = "";
            string str2 = "";
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            if (this.gatepassNo == "")
            {
                str2 = "select gatepass_number from wb_gatepass WITH (NOLOCK) where (deleted = 'N' or deleted IS NULL or deleted = '') and Delivery_note = '" + this.txt_deli_note.Text + "'";
            }
            else
            {
                string[] textArray1 = new string[] { "select gatepass_number from wb_gatepass WITH (NOLOCK) where (deleted = 'N' or deleted IS NULL or deleted = '') and gatepass_number <> '", this.gatepassNo, "' and Delivery_note = '", this.txt_deli_note.Text, "'" };
                str2 = string.Concat(textArray1);
            }
            table2.OpenTable("wb_gatepass", str2, WBData.conn);
            if (table2.DT.Rows.Count > 0)
            {
                this.tempDoubleSPBRef = table2.DT.Rows[0]["gatepass_number"].ToString();
                flag = true;
            }
            else if (table2.DT.Rows.Count != 0)
            {
                flag = false;
            }
            else
            {
                if (this.gatepassNo == "")
                {
                    sqltext = "select ref from wb_transaction WITH (NOLOCK) where (deleted = 'N' or deleted IS NULL or deleted = '') and Delivery_note = '" + this.txt_deli_note.Text + "'";
                }
                else
                {
                    string[] textArray2 = new string[] { "select ref from wb_transaction WITH (NOLOCK) where (deleted = 'N' or deleted IS NULL or deleted = '') and gatepass_number <> '", this.gatepassNo, "' and Delivery_note = '", this.txt_deli_note.Text, "'" };
                    sqltext = string.Concat(textArray2);
                }
                table.OpenTable("wb_transaction", sqltext, WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    flag = false;
                }
                else
                {
                    this.tempDoubleSPBRef = table.DT.Rows[0]["ref"].ToString();
                    flag = true;
                }
                table.Dispose();
            }
            table2.Dispose();
            return flag;
        }

        private void checkEntryAVGorTotalBunch()
        {
            if (this.radioButtonEntryAVG.Checked)
            {
                this.textAvg.ReadOnly = false;
                this.textBunchTotal.ReadOnly = true;
            }
            else if (this.radioButtonEntryTotalBunch.Checked)
            {
                this.textAvg.ReadOnly = true;
                this.textBunchTotal.ReadOnly = false;
            }
        }

        private bool checkFilledDataForContOut() => 
            (this.checkEstate.Checked || ((this.txt_deli_note.Text != "") || ((this.txt_seal.Text != "") || ((this.textRemarkTicket.Text != "") || ((this.textRemarkReport.Text != "") || ((this.txtAddInfo.Text != "") || ((this.textPL3.Text != "") || (this.chk_return.Checked || ((this.text_ref_return.Text != "") || (this.checkNOPW.Checked || ((this.textWBNo.Text != "") || ((this.textGrossEstate.Text != "0") || ((this.textTareEstate.Text != "0") || ((this.textNetEstate.Text != "0") || ((this.dgvCont.Rows.Count > 0) || ((this.dgvDO.Rows.Count > 0) || (this.dgvDOCont.Rows.Count > 0))))))))))))))))) || (this.dgvQC.Rows.Count > 0);

        public bool checkInUsedDoSapOrInternal(DataTable dt, out string mssg)
        {
            mssg = "";
            bool flag = false;
            string objA = "";
            WBTable table = new WBTable();
            using (IEnumerator enumerator = dt.Rows.GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataRow current = (DataRow) enumerator.Current;
                    if ((((current["ref"].ToString() == "") && (current["gdeleted"].ToString() == "N")) && (current["submit_gatepass"].ToString() == "N")) && ((this.pMode == "ADD") || ((this.pMode != "ADD") && (current["gatepass_number"].ToString() != this.txt_gp_no.Text))))
                    {
                        mssg = "{0} has been used in Gatepass Number " + current["gatepass_number"].ToString() + ".\nPlease check again, or use another {1}.\nThank you.";
                        return true;
                    }
                }
            }
            foreach (DataRow row2 in dt.Rows)
            {
                objA = row2["ref"].ToString();
                if ((objA == "") || ReferenceEquals(objA, null))
                {
                    objA = this.comboBoxRef.Text;
                }
                int length = objA.Length;
                if (length > 0)
                {
                    if (objA.Substring(length - 1).All<char>(new Func<char, bool>(char.IsLetter)))
                    {
                        objA = objA.Substring(0, length - 1);
                    }
                    string[] textArray1 = new string[] { "Select gatepass_number from wb_transaction Where ref like '", objA, "%' AND ((mark_accident IS NULL OR mark_accident = '') AND (Deleted IS NULL OR Deleted = ''  OR Deleted='N'))  and coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "'" };
                    table.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
                    if ((table.DT.Rows.Count > 0) && ((this.pMode == "ADD") || ((this.pMode != "ADD") && (this.comboBoxRef.Text != objA))))
                    {
                        mssg = "{0} has been used in Ref " + objA + ".\nPlease check again, or use another {1}.\nThank you.";
                        flag = true;
                        break;
                    }
                }
            }
            return flag;
        }

        private bool CheckLicenseNumber()
        {
            if (this.txt_driver_ic.Text.Trim() != "")
            {
                this.t_driver.ReOpen();
                string[] aField = new string[] { "License_No" };
                string[] aFind = new string[] { this.txt_driver_ic.Text.Trim() };
                int recNo = this.t_driver.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.buttonDriver.PerformClick();
                    this.txt_driver_ic.Focus();
                }
                else
                {
                    bool flag9;
                    bool flag3 = false;
                    if ((this.pMode == "EDIT") || (this.pMode == "EDIT_TDT"))
                    {
                        if (this.oldDriver != this.txt_driver_ic.Text.Trim())
                        {
                            flag3 = true;
                        }
                    }
                    else if (this.pMode == "ADD")
                    {
                        flag3 = true;
                    }
                    if (flag3)
                    {
                        string str = "";
                        string str2 = "";
                        WBTable table = new WBTable();
                        string[] textArray3 = new string[] { "SELECT * FROM wb_driver WHERE License_No = '", this.txt_driver_ic.Text.Trim(), "' AND Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "'" };
                        table.OpenTable("wb_driver", string.Concat(textArray3), WBData.conn);
                        str = table.DT.Rows[0]["Black_List"].ToString();
                        str2 = table.DT.Rows[0]["deleted"].ToString();
                        table.Dispose();
                        if (str2 != "Y")
                        {
                            if (str == "Y")
                            {
                                MessageBox.Show(Resource.Mes_610, Resource.Title_002);
                                this.txt_driver_ic.Focus();
                                return false;
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_627, Resource.Title_002);
                            this.txt_driver_ic.Focus();
                            return false;
                        }
                    }
                    this.textDriverName.Text = this.t_driver.DT.Rows[recNo]["Name"].ToString();
                    if ((this.dgvCont.Rows.Count == 0) && this.check_driver_inyard(this.txt_driver_ic.Text))
                    {
                        this.txt_driver_ic.SelectAll();
                        this.txt_driver_ic.Focus();
                        flag9 = false;
                    }
                    else
                    {
                        if (WBSetting.activeRegistrationRequireLicensePhoto)
                        {
                            this.camera.loadImageV2(WBSetting.licensePhoto_path, "LICENSEID_" + this.t_driver.DT.Rows[recNo]["Uniq"].ToString() + ".jpg", this._driverLicense_img);
                        }
                        flag9 = true;
                    }
                    return flag9;
                }
            }
            return false;
        }

        private void checkNeedContainerCheck_CheckedChanged(object sender, EventArgs e)
        {
            string str = "P";
            if (this.checkNeedContainerCheck.Checked)
            {
                str = "R";
            }
            foreach (DataGridViewRow row in (IEnumerable) this.dgvCont.Rows)
            {
                row.Cells["pass_flag"].Value = str;
            }
        }

        private void checkNOPW_CheckedChanged(object sender, EventArgs e)
        {
            this.setOtherParty();
        }

        private bool CheckSPB()
        {
            WBTable table = new WBTable();
            using (IEnumerator enumerator = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                    string text = this.txt_deli_note.Text;
                    table.OpenTable("wb_delivery_note", "Select * From wb_delivery_note where Do_No='" + current.Cells["DO_No"].Value.ToString().Trim() + "'", WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num >= table.DT.Rows.Count)
                            {
                                break;
                            }
                            table.DR = table.DT.Rows[num];
                            bool flag2 = text.Length != table.DR["delivery_note_from"].ToString().Length;
                            if (flag2 || ((string.Compare(text, table.DR["Delivery_Note_From"].ToString()) < 0) || (string.Compare(text, table.DR["Delivery_Note_To"].ToString()) > 0)))
                            {
                                num++;
                                continue;
                            }
                            return true;
                        }
                    }
                }
            }
            table.Dispose();
            return false;
        }

        private bool CheckSPBv2()
        {
            WBTable table = new WBTable();
            using (IEnumerator enumerator = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                    string text = this.txt_deli_note.Text;
                    table.OpenTable("wb_delivery_note", "Select * From wb_delivery_note where relation_code='" + current.Cells["relation_code"].Value.ToString().Trim() + "'", WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num >= table.DT.Rows.Count)
                            {
                                break;
                            }
                            table.DR = table.DT.Rows[num];
                            bool flag2 = text.Length != table.DR["delivery_note_from"].ToString().Length;
                            if (!flag2 && ((string.Compare(text, table.DR["Delivery_Note_From"].ToString()) >= 0) && (string.Compare(text, table.DR["Delivery_Note_to"].ToString()) <= 0)))
                            {
                                if (Convert.ToDateTime(WBUtility.GetServerDatetime()) > Convert.ToDateTime(table.DR["expired_date"].ToString()))
                                {
                                    this.expiredSPB = true;
                                }
                                else
                                {
                                    return true;
                                }
                            }
                            num++;
                        }
                    }
                }
            }
            table.Dispose();
            return false;
        }

        private bool CheckTransporterCode()
        {
            bool flag9;
            if (this.txt_transporter_code.Text.Trim() == "")
            {
                flag9 = true;
            }
            else
            {
                this.t_transporter.ReOpen();
                string[] aField = new string[] { "transporter_code" };
                string[] aFind = new string[] { this.txt_transporter_code.Text.Trim() };
                int recNo = this.t_transporter.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.buttonTransporter.PerformClick();
                    this.txt_transporter_code.Focus();
                    flag9 = false;
                }
                else
                {
                    bool flag3 = false;
                    if ((this.pMode == "EDIT") || (this.pMode == "EDIT_TDT"))
                    {
                        if (this.oldTransporter != this.txt_transporter_code.Text.Trim())
                        {
                            flag3 = false;
                        }
                    }
                    else if (this.pMode == "ADD")
                    {
                        flag3 = true;
                    }
                    if (flag3)
                    {
                        string str = "";
                        string str2 = "";
                        WBTable table = new WBTable();
                        string[] textArray3 = new string[] { "SELECT * FROM wb_transporter WHERE Transporter_Code = '", this.txt_transporter_code.Text.Trim(), "' AND Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "'" };
                        table.OpenTable("wb_transporter", string.Concat(textArray3), WBData.conn);
                        str = table.DT.Rows[0]["Black_List"].ToString();
                        str2 = table.DT.Rows[0]["deleted"].ToString();
                        table.Dispose();
                        if (str2 != "Y")
                        {
                            if (str == "Y")
                            {
                                MessageBox.Show(Resource.Mes_612, Resource.Title_002);
                                this.txt_transporter_code.Focus();
                                return false;
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_626, Resource.Title_002);
                            this.txt_transporter_code.Focus();
                            return false;
                        }
                    }
                    this.txt_transporter_code.Text = this.t_transporter.DT.Rows[recNo]["Transporter_Code"].ToString().Trim();
                    this.lbl_transporter_name.Text = this.t_transporter.DT.Rows[recNo]["Transporter_Name"].ToString().Trim();
                    flag9 = true;
                }
            }
            return flag9;
        }

        private bool CheckTruckNumber(bool fillTransporter)
        {
            if (this.txt_truck.Text.Trim() != "")
            {
                this.t_truck.ReOpen();
                string[] aField = new string[] { "Truck_Number" };
                string[] aFind = new string[] { this.txt_truck.Text.Trim() };
                int recNo = this.t_truck.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.buttonTruck.PerformClick();
                    this.txt_truck.Focus();
                }
                else
                {
                    bool flag9;
                    bool flag3 = false;
                    if ((this.pMode == "EDIT") || (this.pMode == "EDIT_TDT"))
                    {
                        if (this.oldTruck != this.txt_truck.Text.Trim())
                        {
                            flag3 = true;
                        }
                    }
                    else if (this.pMode == "ADD")
                    {
                        flag3 = true;
                    }
                    if (flag3)
                    {
                        string str = "";
                        string str2 = "";
                        WBTable table = new WBTable();
                        string[] textArray3 = new string[] { "SELECT * FROM wb_truck WHERE Truck_Number = '", this.txt_truck.Text.Trim(), "' AND Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "'" };
                        table.OpenTable("wb_truck", string.Concat(textArray3), WBData.conn);
                        str = table.DT.Rows[0]["Black_List"].ToString();
                        str2 = table.DT.Rows[0]["deleted"].ToString();
                        table.Dispose();
                        if (str2 != "Y")
                        {
                            if (str == "Y")
                            {
                                MessageBox.Show(Resource.Mes_611, Resource.Title_002);
                                this.txt_truck.Focus();
                                return false;
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_620, Resource.Title_002);
                            this.txt_truck.Focus();
                            return false;
                        }
                    }
                    if ((this.dgvCont.Rows.Count == 0) && this.check_truck_inyard(this.txt_truck.Text))
                    {
                        this.txt_truck.SelectAll();
                        this.txt_truck.Focus();
                        flag9 = false;
                    }
                    else
                    {
                        this.txt_truck.Text = this.t_truck.DT.Rows[recNo]["Truck_Number"].ToString().Trim();
                        if ((this.txt_transporter_code.Text == "") & fillTransporter)
                        {
                            this.txt_transporter_code.Text = this.t_truck.DT.Rows[recNo]["Transporter_Code"].ToString().Trim();
                            string[] textArray4 = new string[] { "Transporter_Code" };
                            string[] textArray5 = new string[] { this.txt_transporter_code.Text };
                            DataRow data = this.t_transporter.GetData(textArray4, textArray5);
                            if (data != null)
                            {
                                this.lbl_transporter_name.Text = data["Transporter_Name"].ToString().Trim();
                            }
                        }
                        this.autoChooseDestination();
                        flag9 = true;
                    }
                    return flag9;
                }
            }
            return false;
        }

        public bool chekDoOrInternalNo(string DoOrInternalNo, string DoOrInternalNo_item, string DoOrInternalNo_besar)
        {
            string[] source = new string[this.dgvDO.Rows.Count];
            int index = 0;
            bool flag = false;
            Cursor.Current = Cursors.WaitCursor;
            foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
            {
                if (!string.IsNullOrEmpty(row.Cells[DoOrInternalNo].Value.ToString()) && (row.Cells[DoOrInternalNo_besar].Value.ToString() != "X"))
                {
                    string str = row.Cells[DoOrInternalNo].Value.ToString() + row.Cells[DoOrInternalNo_item].Value.ToString();
                    if (source.Contains<string>(str))
                    {
                        flag = true;
                        break;
                    }
                    source[index] = str;
                    index++;
                }
            }
            return flag;
        }

        private void chk_return_CheckedChanged(object sender, EventArgs e)
        {
            this.text_ref_return.Text = "";
            if (this.chk_return.Checked)
            {
                this.panel_return.Visible = true;
                this.sh_return.OpenTable("wb_transaction", "SELECT transaction_code, ref, do_no, report_date, comm_code, gross, tare, net, delivery_date FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND (mark_return = '' OR mark_return IS NULL) AND (report_date IS NOT NULL) ORDER BY ref"), WBData.conn);
                if (this.sh_return.DT.Rows.Count > 0)
                {
                    Program.AutoComp(this.sh_return, "ref", this.text_ref_return);
                }
                this.buttonAddDO.Enabled = false;
            }
            else
            {
                this.panel_return.Visible = false;
                if (this.dgvDO.RowCount > 0)
                {
                    string str = this.dgvDO.Rows[0].Cells["DO_No"].Value.ToString();
                    WBTable table = new WBTable();
                    table.OpenTable("wb_tmpDO", "SELECT * FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + str + "'"), WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        table.DR = table.DT.Rows[0];
                        this.dgvDO.CurrentRow.Cells["transaction_code"].Value = table.DR["transaction_code"].ToString();
                    }
                }
                if ((this.pMode != "SPLIT") && (this.pMode != "DL"))
                {
                    this.buttonEditDO.Enabled = true;
                }
                this.buttonAddDO.Enabled = true;
            }
        }

        private void comboBoxRef_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!this.firstload)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.initTableTransWithRef();
                this.fillDataGeneralInfo();
                this.fillDGDO();
                this.fillDataOtherParty();
                this.fillDGQC();
                this.fillDGContainer();
                this.fillDGDOContainer();
                this.fillDGDivBlock();
                this.fillDataFFB();
                this.initImage(this.pMode);
                this.tabControlInformation.SelectedTab = this.tabPageGeneral;
                this.tabControlPhoto.SelectedTab = this.tabPage1st;
                Cursor.Current = Cursors.Default;
            }
        }

        private void comboBoxRefTemp_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!this.firstload)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.initTableTransWithRef();
                this.fillDataGeneralInfo();
                this.fillDGDO();
                this.fillDataOtherParty();
                this.fillDGQC();
                this.fillDGContainer();
                this.fillDGDOContainer();
                this.fillDGDivBlock();
                this.fillDataFFB();
                this.initImage(this.pMode);
                this.tabControlInformation.SelectedTab = this.tabPageGeneral;
                this.tabControlPhoto.SelectedTab = this.tabPage1st;
                Cursor.Current = Cursors.Default;
            }
        }

        private void comboDestination_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void comboDestination_TextChanged(object sender, EventArgs e)
        {
        }

        private void comboWX_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((this.lastWX == "1") && (this.comboWX.SelectedValue.ToString() != "1"))
            {
                this.dgvGPDest.Rows.Clear();
            }
            if ((this.lastWX != "1") && (this.comboWX.SelectedValue.ToString() == "1"))
            {
                this.dgvGPDest.Rows.Clear();
            }
            if ((this.comboWX.SelectedValue.ToString() == this.lastWX) || ((this.comboWX.SelectedValue.ToString() != "3") && (this.comboWX.SelectedValue.ToString() != "4")))
            {
                this.checkNOPW.Enabled = true;
                this.textWBNo.Enabled = true;
                this.dateDelivery.Enabled = true;
                this.TimeDelivery.Enabled = true;
                this.textGrossEstate.Enabled = true;
                this.textTareEstate.Enabled = true;
                this.textNetEstate.Enabled = true;
                this.buttonAddDO.Enabled = true;
                this.buttonEditDO.Enabled = true;
                this.buttonDeleteDO.Enabled = true;
                this.buttonDeleteAllDO.Enabled = true;
                this.buttonViewDO.Enabled = true;
                this.buttonContAdd.Enabled = true;
                this.buttonContEdit.Enabled = true;
                this.buttonContDelete.Enabled = true;
                this.txt_deli_note.Enabled = true;
                this.txt_seal.Enabled = true;
                this.textRemarkTicket.Enabled = true;
                this.textRemarkReport.Enabled = true;
                this.txtAddInfo.Enabled = true;
                this.textPL3.Enabled = true;
                this.text_ref_return.Enabled = true;
                this.chk_return.Enabled = true;
                this.checkEstate.Enabled = true;
                this.buttonEntryDeduc.Enabled = true;
            }
            else if (((this.pMode != "EDIT") || (this.comboBoxRef.Text.Trim() == "")) || ((this.comboWX.SelectedValue.ToString() != "4") && (this.comboWX.SelectedValue.ToString() != "3")))
            {
                if (!this.checkFilledDataForContOut())
                {
                    this.checkNOPW.Enabled = false;
                    this.textWBNo.Enabled = false;
                    this.dateDelivery.Enabled = false;
                    this.TimeDelivery.Enabled = false;
                    this.textGrossEstate.Enabled = false;
                    this.textTareEstate.Enabled = false;
                    this.textNetEstate.Enabled = false;
                    this.buttonAddDO.Enabled = false;
                    this.buttonEditDO.Enabled = false;
                    this.buttonDeleteDO.Enabled = false;
                    this.buttonDeleteAllDO.Enabled = false;
                    this.buttonViewDO.Enabled = false;
                    this.buttonContAdd.Enabled = false;
                    this.buttonContEdit.Enabled = false;
                    this.buttonContDelete.Enabled = false;
                    this.txt_deli_note.Enabled = true;
                    this.txt_seal.Enabled = true;
                    this.textRemarkTicket.Enabled = true;
                    this.textRemarkReport.Enabled = true;
                    this.txtAddInfo.Enabled = true;
                    this.textPL3.Enabled = true;
                    this.text_ref_return.Enabled = true;
                    this.chk_return.Enabled = true;
                    this.checkEstate.Enabled = true;
                    this.buttonEntryDeduc.Enabled = true;
                }
                else
                {
                    string text = "";
                    text = (this.comboWX.SelectedValue.ToString() != "3") ? Resource.RegisGatepassMess_062 : Resource.RegisGatepassMess_036;
                    if (MessageBox.Show(text, "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                    {
                        this.comboWX.SelectedValue = this.lastWX;
                    }
                    else
                    {
                        this.resetDataForContOut();
                        this.checkNOPW.Enabled = false;
                        this.textWBNo.Enabled = false;
                        this.dateDelivery.Enabled = false;
                        this.TimeDelivery.Enabled = false;
                        this.textGrossEstate.Enabled = false;
                        this.textTareEstate.Enabled = false;
                        this.textNetEstate.Enabled = false;
                        this.buttonAddDO.Enabled = false;
                        this.buttonEditDO.Enabled = false;
                        this.buttonDeleteDO.Enabled = false;
                        this.buttonDeleteAllDO.Enabled = false;
                        this.buttonViewDO.Enabled = false;
                        this.buttonContAdd.Enabled = false;
                        this.buttonContEdit.Enabled = false;
                        this.buttonContDelete.Enabled = false;
                        this.dgvDO.Rows.Clear();
                        this.dgvQC.Rows.Clear();
                        this.dgvCont.Rows.Clear();
                        this.dgvDOCont.Rows.Clear();
                        this.dgvDivBlock.Rows.Clear();
                    }
                }
                if (this.comboWX.SelectedValue.ToString() == "4")
                {
                    this.txt_deli_note.Enabled = false;
                    this.txt_deli_note.Text = "";
                    this.txt_seal.Enabled = false;
                    this.txt_seal.Text = "";
                    this.textRemarkTicket.Enabled = false;
                    this.textRemarkTicket.Text = "";
                    this.textRemarkReport.Enabled = false;
                    this.textRemarkReport.Text = "";
                    this.txtAddInfo.Enabled = false;
                    this.txtAddInfo.Text = "";
                    this.textPL3.Enabled = false;
                    this.textPL3.Text = "";
                    this.text_ref_return.Enabled = false;
                    this.text_ref_return.Text = "";
                    this.chk_return.Enabled = false;
                    this.chk_return.Checked = false;
                    this.checkEstate.Enabled = false;
                    this.checkEstate.Checked = false;
                    this.buttonEntryDeduc.Enabled = false;
                }
            }
            else
            {
                string text = "";
                text = (this.comboWX.SelectedValue.ToString() != "4") ? Resource.RegisGatepassMess_065 : Resource.RegisGatepassMess_063;
                MessageBox.Show(text, "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.comboWX.SelectedValue = this.lastWX;
                return;
            }
            this.lastWX = this.comboWX.SelectedValue.ToString();
            this.checkDestinationRoutes(Constant.CHECKPOINT_CONTAINER_CHECK);
        }

        private void countAdditionalInformation()
        {
            int count = 0;
            double num2 = 0.0;
            double num3 = 0.0;
            count = this.dgvDO.Rows.Count;
            foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
            {
                if (row.Cells["DO_QTY_KG"].Value != null)
                {
                    num2 += Program.StrToDouble(row.Cells["DO_QTY_KG"].Value.ToString(), 3);
                }
                if (row.Cells["Netto"].Value != null)
                {
                    num3 += Program.StrToDouble(row.Cells["Netto"].Value.ToString(), 2);
                }
            }
            this.lblTotalItem.Text = count.ToString();
            this.lblTotalDOQtyInKG.Text = num2.ToString("0.###");
            this.lblTotalAllocatedFactNet.Text = num3.ToString("0.##");
        }

        private void countOSinDgvDO()
        {
            double num = 0.0;
            double num2 = 0.0;
            if (this.dgvDO.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
                {
                    row.Cells["OSDO"].Value = 0;
                    this.tblComm.OpenTable("wb_comm", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + row.Cells["comm_code"].Value.ToString() + "'"), WBData.conn);
                    string[] aField = new string[] { "comm_code" };
                    string[] aFind = new string[] { row.Cells["comm_code"].Value.ToString() };
                    DataRow data = this.tblComm.GetData(aField, aFind);
                    bool flag2 = data != null;
                    string str2 = !flag2 ? "N" : data["using_gunny"].ToString();
                    if (str2 == "Y")
                    {
                        num = Convert.ToDouble($"{Program.checkOSbyGunny(row.Cells["do_no"].Value.ToString(), "", this.comboBoxRef.Text, "N"):N0}");
                        row.Cells["OSDO"].Value = num;
                        continue;
                    }
                    num2 = Program.checkOS(row.Cells["do_no"].Value.ToString(), "", this.comboBoxRef.Text, "N");
                    num = Convert.ToDouble($"{num2:N0}");
                    row.Cells["OSDO"].Value = Math.Floor(num2);
                }
            }
        }

        private void dgvDO_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            WBTable table = new WBTable();
            if ((e.ColumnIndex == this.dgvDO.Columns["comm_code"].Index) && (e.Value != null))
            {
                DataGridViewCell cell = this.dgvDO.Rows[e.RowIndex].Cells[e.ColumnIndex];
                table.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + e.Value.ToString().Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    cell.ToolTipText = table.DT.Rows[0]["comm_name"].ToString();
                }
            }
        }

        private void dgvGPDest_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
        }

        private void dgvQC_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            string[] aField = new string[] { "Yield_Code" };
            string[] aFind = new string[] { this.dgvQC.Rows[this.dgvQC.CurrentCell.RowIndex].Cells["Qcode"].Value.ToString() };
            if (this.tblQC.GetData(aField, aFind)["Type"].ToString() != "1")
            {
                if (((this.dgvQC.CurrentCell.Value != null) && (this.dgvQC.CurrentCell.Value.ToString() != "")) && (this.dgvQC.CurrentCell.Value.ToString().Length > 10))
                {
                    MessageBox.Show(Resource.RegisGatepassMess_040, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }
            }
            else
            {
                try
                {
                    string str = "";
                    str = ((this.dgvQC.CurrentCell.Value != null) && (this.dgvQC.CurrentCell.Value.ToString() != "")) ? this.dgvQC.CurrentCell.Value.ToString() : "0";
                    if (((float) Convert.ToDouble(str)) > 99.999)
                    {
                        MessageBox.Show(Resource.RegisGatepassMess_038, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.dgvQC.CurrentCell.Value = "";
                    }
                    else if ((this.dgvQC.CurrentCell.Value != null) && (this.dgvQC.CurrentCell.Value.ToString() != ""))
                    {
                        this.dgvQC.CurrentCell.Value = $"{Program.StrToDouble(this.dgvQC.CurrentCell.Value.ToString(), 3):N3}";
                    }
                }
                catch
                {
                    MessageBox.Show(Resource.RegisGatepassMess_039, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.dgvQC.CurrentCell.Value = "";
                }
            }
            this.QCChanged = true;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool editWarning()
        {
            this.editTrace = "";
            bool flag = false;
            this.tblgp.ReOpen();
            this.tblgp.DR = this.tblgp.DT.Rows[0];
            this.tblTransDO.ReOpen();
            foreach (DataRow row in this.tbl_warning_trace.DT.Rows)
            {
                if (row["selected"].ToString() == "Y")
                {
                    if (row["name"].ToString().ToUpper().Trim() != "DO")
                    {
                        if (this.tblgp.DR[row["FieldName"].ToString()].ToString().ToUpper().Trim() == this.transBefore[row["FieldName"].ToString()].ToString().ToUpper().Trim())
                        {
                            continue;
                        }
                        flag = true;
                        string str = "Blank";
                        if (this.transBefore[row["FieldName"].ToString()].ToString().Trim().Length > 0)
                        {
                            str = this.transBefore[row["FieldName"].ToString()].ToString().Trim();
                        }
                        string[] textArray1 = new string[] { this.editTrace, "<tr class='bd'><td nowrap>", row["Name"].ToString().Trim().PadRight(20, ' '), "</td><td nowrap>", str.PadRight(20, ' '), "</td><td nowrap>", this.tblgp.DR[row["FieldName"].ToString()].ToString().Trim().PadRight(20, ' '), "</td></tr>" };
                        this.editTrace = string.Concat(textArray1);
                        continue;
                    }
                    if (this.tblTransDO.DT.Rows.Count != this.tmp_transDO.Rows.Count)
                    {
                        flag = true;
                        this.editDoTrace = this.editDoTrace + "DO Before :<br>";
                        int num = 0;
                        while (true)
                        {
                            if (num >= this.tmp_transDO.Rows.Count)
                            {
                                this.editDoTrace = this.editDoTrace + "<br>DO After :<br>";
                                int num2 = 0;
                                while (true)
                                {
                                    if (num2 >= this.tblTransDO.DT.Rows.Count)
                                    {
                                        break;
                                    }
                                    this.tblTransDO.DR = this.tblTransDO.DT.Rows[num2];
                                    object[] objArray2 = new object[] { this.editDoTrace, num2 + 1, ". ", this.tblTransDO.DR["Do_No"].ToString(), ". Qty :", this.tblTransDO.DR["Netto"].ToString(), "<br>" };
                                    this.editDoTrace = string.Concat(objArray2);
                                    num2++;
                                }
                                break;
                            }
                            this.transDOBefore = this.tmp_transDO.Rows[num];
                            object[] objArray1 = new object[] { this.editDoTrace, num + 1, ". ", this.transDOBefore["Do_No"].ToString(), ". Qty :", this.transDOBefore["Netto"].ToString(), "<br>" };
                            this.editDoTrace = string.Concat(objArray1);
                            num++;
                        }
                        continue;
                    }
                    bool flag9 = false;
                    int count = this.tmp_transDO.Rows.Count;
                    int num4 = 0;
                    while (true)
                    {
                        if (num4 >= count)
                        {
                            break;
                        }
                        this.tblTransDO.DR = this.tblTransDO.DT.Rows[num4];
                        this.transDOBefore = this.tmp_transDO.Rows[num4];
                        if (this.tblTransDO.DR["Do_No"].ToString().Trim().ToUpper() != this.transDOBefore["Do_No"].ToString().Trim().ToUpper())
                        {
                            flag = true;
                            flag9 = true;
                        }
                        if (flag9)
                        {
                            this.editDoTrace = "<tr class='bd'>";
                            string[] textArray2 = new string[] { this.editDoTrace, "<td nowrap>Before</td><td nowrap>", this.transDOBefore["Do_No"].ToString(), "</td><td nowrap>", this.transDOBefore["Netto"].ToString(), "</td>" };
                            this.editDoTrace = string.Concat(textArray2);
                            this.editDoTrace = this.editDoTrace + "</tr>";
                            this.editDoTrace = this.editDoTrace + "<tr class='bd'>";
                            string[] textArray3 = new string[] { this.editDoTrace, "<td nowrap>After</td><td nowrap>", this.tblTransDO.DR["Do_No"].ToString(), "</td><td nowrap>", this.tblTransDO.DR["Netto"].ToString(), "</td>" };
                            this.editDoTrace = string.Concat(textArray3);
                            this.editDoTrace = this.editDoTrace + "</tr>";
                        }
                        num4++;
                    }
                }
            }
            return flag;
        }

        private void entryCont(string pMod)
        {
            int index;
            FormTransContEntry entry;
            if ((pMod == "ADD") || (this.dgvCont.Rows.Count > 0))
            {
                if ((this.comboWX.SelectedValue.ToString() == "2") || (this.comboWX.SelectedValue.ToString() == "0"))
                {
                    index = -1;
                    entry = new FormTransContEntry {
                        pMode = pMod
                    };
                    if (pMod == "EDIT")
                    {
                        index = this.dgvCont.CurrentRow.Index;
                        entry.OldContainer = this.dgvCont.CurrentRow.Cells["Container"].Value.ToString();
                        entry.textBox1.Text = this.dgvCont.CurrentRow.Cells["Container"].Value.ToString();
                        entry.textBox2.Text = this.dgvCont.CurrentRow.Cells["Seal"].Value.ToString();
                    }
                    entry.dgvCont = this.dgvCont;
                    entry.ShowDialog();
                    if (!entry.pSave)
                    {
                        goto TR_0002;
                    }
                    else
                    {
                        string str2 = "P";
                        if (this.checkNeedContainerCheck.Checked)
                        {
                            str2 = "R";
                        }
                        if (pMod == "ADD")
                        {
                            index = this.dgvCont.Rows.Count;
                            this.dgvCont.Rows.Add();
                            this.dgvCont.Rows[index].Cells["pass_flag"].Value = str2;
                        }
                        else if (pMod == "EDIT")
                        {
                            if (!entry.pEditContainerNo)
                            {
                                foreach (DataGridViewRow row2 in (IEnumerable) this.dgvDOCont.Rows)
                                {
                                    if (row2.Cells["Container"].Value.ToString().Equals(entry.OldContainer))
                                    {
                                        row2.Cells["Seal"].Value = entry.textBox2.Text.Trim();
                                    }
                                }
                            }
                            else
                            {
                                foreach (DataGridViewRow row in (IEnumerable) this.dgvDOCont.Rows)
                                {
                                    if (row.Cells["Container"].Value.ToString().Equals(entry.OldContainer))
                                    {
                                        row.Cells["Container"].Value = entry.textBox1.Text.Trim();
                                        row.Cells["Seal"].Value = entry.textBox2.Text.Trim();
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    string str = (pMod == "ADD") ? Resource.RegisGatepassEntry_031 : ((pMod == "EDIT") ? Resource.RegisGatepassEntry_032 : ((pMod == "DELETE") ? Resource.RegisGatepassEntry_033 : ""));
                    string[] textArray1 = new string[] { Resource.RegisGatepassMess_034, " ", str, " ", Resource.RegisGatepassMess_035 };
                    MessageBox.Show(string.Concat(textArray1), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            else
            {
                return;
            }
            this.dgvCont.Rows[index].Cells["Coy"].Value = WBData.sCoyCode;
            this.dgvCont.Rows[index].Cells["Location_Code"].Value = WBData.sLocCode;
            this.dgvCont.Rows[index].Cells["Container"].Value = entry.textBox1.Text.Trim();
            this.dgvCont.Rows[index].Cells["Seal"].Value = entry.textBox2.Text.Trim();
        TR_0002:
            entry.Dispose();
        }

        private void EntryDivBlock(string pmode)
        {
            int index = -1;
            FormTransDivision division = new FormTransDivision {
                dgvDiv = this.dgvDivBlock,
                jTandan = Convert.ToInt32(this.textBunchTotal.Text),
                maskedAVG = { Text = this.textAvg.Text },
                entryFromRegistration = true,
                pMode = pmode
            };
            if (pmode == "ADD")
            {
                division.Text = "Add Division/Block item";
            }
            else
            {
                index = this.dgvDivBlock.CurrentRow.Index;
                division.Text = "Edit Division/Block item";
                division.textEstate.Text = this.dgvDivBlock.CurrentRow.Cells["Estate_Code"].Value.ToString();
                division.textEstateName.Text = this.dgvDivBlock.CurrentRow.Cells["Estate_Name"].Value.ToString();
                division.textDiv.Text = this.dgvDivBlock.CurrentRow.Cells["Division_Code"].Value.ToString();
                division.textDivName.Text = this.dgvDivBlock.CurrentRow.Cells["Division_Name"].Value.ToString();
                division.textBlockCode.Text = this.dgvDivBlock.CurrentRow.Cells["Block_Code"].Value.ToString();
                division.textBlockName.Text = this.dgvDivBlock.CurrentRow.Cells["Block_Name"].Value.ToString();
                division.maskedAVG.Text = this.dgvDivBlock.CurrentRow.Cells["Average"].Value.ToString().PadLeft(5, '0');
                division.textBunch.Text = this.dgvDivBlock.CurrentRow.Cells["Bunch"].Value.ToString();
                division.textWeight.Text = this.dgvDivBlock.CurrentRow.Cells["Weight"].Value.ToString();
                division.textYear.Text = this.dgvDivBlock.CurrentRow.Cells["yearPlanting"].Value.ToString();
            }
            division.ShowDialog();
            if (division.Saved)
            {
                Cursor.Current = Cursors.WaitCursor;
                if (pmode == "ADD")
                {
                    index = this.dgvDivBlock.Rows.Count;
                    this.dgvDivBlock.Rows.Add();
                }
                this.dgvDivBlock.Rows[index].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvDivBlock.Rows[index].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvDivBlock.Rows[index].Cells["Estate_Code"].Value = division.textEstate.Text;
                this.dgvDivBlock.Rows[index].Cells["Estate_Name"].Value = division.textEstateName.Text;
                this.dgvDivBlock.Rows[index].Cells["Division_Code"].Value = division.textDiv.Text;
                this.dgvDivBlock.Rows[index].Cells["Division_Name"].Value = division.textDivName.Text;
                this.dgvDivBlock.Rows[index].Cells["Block_Code"].Value = division.textBlockCode.Text;
                this.dgvDivBlock.Rows[index].Cells["Block_Name"].Value = division.textBlockName.Text;
                this.dgvDivBlock.Rows[index].Cells["Average"].Value = division.maskedAVG.Text;
                this.dgvDivBlock.Rows[index].Cells["Bunch"].Value = Convert.ToDouble(division.textBunch.Text);
                this.dgvDivBlock.Rows[index].Cells["Weight"].Value = Convert.ToDouble(division.textWeight.Text);
                this.dgvDivBlock.Rows[index].Cells["YearPlanting"].Value = Convert.ToDouble(division.textYear.Text);
                Cursor.Current = Cursors.Default;
            }
            division.Dispose();
        }

        private void entryDO(string doEntryMode)
        {
            string oldDO = "";
            if ((doEntryMode == "ADD") && (this.dgvDO.RowCount > 0))
            {
                WBTable table = new WBTable();
                string[] textArray1 = new string[] { "SELECT * FROM wb_transaction_type WHERE coy = '", this.cCoy, "' AND location_code = '", this.cLoc, "' AND transaction_code = '", this.dgvDO.Rows[0].Cells["transaction_code"].Value.ToString(), "'" };
                table.OpenTable("wb_transaction_type", string.Concat(textArray1), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    this.IO = table.DT.Rows[0]["IO"].ToString();
                }
                table.Dispose();
                if (this.IO != "I")
                {
                    string[] textArray3 = new string[] { "SELECT * FROM wb_commodity WHERE coy = '", this.cCoy, "' AND location_code = '", this.cLoc, "' AND comm_code = '", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString(), "'" };
                    this.tblComm.OpenTable("wb_commodity", string.Concat(textArray3), WBData.conn);
                    if (this.tblComm.DT.Rows.Count > 0)
                    {
                        if (this.tblComm.DT.Rows[0]["bulkpack"].ToString() != "B")
                        {
                            if (this.tblComm.DT.Rows[0]["bulkpack"].ToString() == "P")
                            {
                            }
                        }
                        else
                        {
                            int num5 = 0;
                            while (true)
                            {
                                if (num5 >= this.dgvDO.RowCount)
                                {
                                    break;
                                }
                                if ((this.dgvDO.Rows[num5].Cells["Netto"].Value.ToString() != "") && (this.dgvDO.Rows[num5].Cells["Netto"].Value.ToString() != "0"))
                                {
                                    num5++;
                                    continue;
                                }
                                string[] textArray4 = new string[] { Resource.RegisGatepassMess_032, " ", this.dgvDO.Rows[num5].Cells["Do_No"].Value.ToString(), " ", Resource.RegisGatepassMess_033 };
                                MessageBox.Show(string.Concat(textArray4), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                this.dgvDO.CurrentCell = this.dgvDO.Rows[num5].Cells["Netto"];
                                return;
                            }
                        }
                    }
                }
                else if (this.textNetEstate.Text == "0")
                {
                    int num4 = 0;
                    while (true)
                    {
                        if (num4 >= this.dgvDO.RowCount)
                        {
                            break;
                        }
                        if ((this.dgvDO.Rows[num4].Cells["Netto"].Value.ToString() != "") && (this.dgvDO.Rows[num4].Cells["Netto"].Value.ToString() != "0"))
                        {
                            num4++;
                            continue;
                        }
                        string[] textArray2 = new string[] { Resource.RegisGatepassMess_032, " ", this.dgvDO.Rows[num4].Cells["Do_No"].Value.ToString(), " ", Resource.RegisGatepassMess_033 };
                        MessageBox.Show(string.Concat(textArray2), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        this.dgvDO.CurrentCell = this.dgvDO.Rows[num4].Cells["Netto"];
                        return;
                    }
                }
            }
            int count = this.dgvDO.Rows.Count;
            double oldEstate = 0.0;
            oldEstate = (this.dgvDO.Rows.Count != 0) ? Program.StrToDouble(this.dgvDO.CurrentRow.Cells["estate_qty"].Value.ToString(), 0) : 0.0;
            FormRegisDOEntry fr = new FormRegisDOEntry {
                Text = doEntryMode + " WB DO Item",
                gatepassNumber = this.txt_gp_no.Text,
                RefNo = this.comboBoxRef.Text,
                doEntryMode = doEntryMode,
                pMode = this.pMode,
                tblTransDO = this.tblTransDO,
                tblComm = this.tblComm,
                dgvDO = this.dgvDO,
                totalNetEstate = Convert.ToDouble(this.textNetEstate.Text),
                nopw = this.checkNOPW.Checked,
                refDate = this.dtRegistration.Text,
                delivery_note = this.txt_deli_note.Text,
                tblDOContainer = this.tblTransDOContainer,
                dgvCont = this.dgvCont,
                dgvDoCont = this.dgvDOCont,
                scaneSPB = this.scaneSPB
            };
            if (((doEntryMode == "ADD") && (this.dgvDO.RowCount == 0)) && ((this.textNetEstate.Text != "") || (this.textNetEstate.Text != "0")))
            {
                fr.textOthNet.Text = this.textNetEstate.Text;
            }
            else if (((doEntryMode == "EDIT") || ((doEntryMode == "EDIT_OPW") || (doEntryMode == "ADD_RETUR"))) || (doEntryMode == "VIEW"))
            {
                fr.dgvDOCurrRow = this.dgvDO.CurrentRow.Index;
                fr.oldComm = this.dgvDO.CurrentRow.Cells["comm_code"].Value.ToString();
                oldDO = this.dgvDO.CurrentRow.Cells["do_no"].Value.ToString();
                fr.IsReturn = this.chk_return.Checked;
                fr.textDO.Text = this.dgvDO.CurrentRow.Cells["DO_No"].Value.ToString();
                if (((doEntryMode != "VIEW") & !this.chk_return.Checked) || ((doEntryMode == "VIEW") & WBSetting.adopt_zdotrx))
                {
                    fr.txtInternalNum.Text = this.dgvDO.CurrentRow.Cells["internal_number"].Value.ToString();
                    fr.txtInNumItem.Text = this.dgvDO.CurrentRow.Cells["internal_number_item"].Value.ToString();
                    fr.text_do_sap.Text = this.dgvDO.CurrentRow.Cells["do_sap"].Value.ToString();
                    fr.text_do_sap_item.Text = this.dgvDO.CurrentRow.Cells["do_sap_item"].Value.ToString();
                    fr.text_do_sap_qty.Text = this.dgvDO.CurrentRow.Cells["do_qty"].Value.ToString();
                    fr.text_do_sap_unit.Text = this.dgvDO.CurrentRow.Cells["do_uom"].Value.ToString();
                    fr.textBoxQtyBaseUOM.Text = this.dgvDO.CurrentRow.Cells["do_base_qty"].Value.ToString();
                    fr.textBoxBaseUOM.Text = this.dgvDO.CurrentRow.Cells["do_base_uom"].Value.ToString();
                    fr.text_do_sap_qty_kg.Text = this.dgvDO.CurrentRow.Cells["do_qty_kg"].Value.ToString();
                    fr.isDOBesar = this.dgvDO.CurrentRow.Cells["do_besar"].Value.ToString();
                    fr.textSOItem_detail.Text = this.dgvDO.CurrentRow.Cells["so_item_detail"].Value.ToString();
                    fr.txtBox_QQ.Text = this.dgvDO.CurrentRow.Cells["customer_QQ"].Value.ToString();
                }
                if (this.dgvDO.CurrentRow.Cells["loading_qty"].Value == null)
                {
                    this.dgvDO.CurrentRow.Cells["loading_qty"].Value = 0;
                }
                if (this.dgvDO.CurrentRow.Cells["loading_qty_opw"].Value == null)
                {
                    this.dgvDO.CurrentRow.Cells["loading_qty_opw"].Value = 0;
                }
                if (this.dgvDO.CurrentRow.Cells["return_qty_kg"].Value == null)
                {
                    this.dgvDO.CurrentRow.Cells["return_qty_kg"].Value = 0;
                }
                if (this.dgvDO.CurrentRow.Cells["return_qty_pack"].Value == null)
                {
                    this.dgvDO.CurrentRow.Cells["return_qty_pack"].Value = 0;
                }
                if (this.dgvDO.CurrentRow.Cells["density"].Value == null)
                {
                    this.dgvDO.CurrentRow.Cells["density"].Value = 0;
                }
                string str2 = this.dgvDO.CurrentRow.Cells["transaction_code"].Value.ToString();
            }
            fr.ShowDialog();
            this.readoptInternalNumber = fr.checkReadopt();
            this.changeLoadingNote = fr.checkLoadingNote();
            if (fr.saved)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.changeDO = true;
                int dgvDOCurrRow = fr.dgvDOCurrRow;
                if (fr.retTable_DSAP_DO.Rows.Count > 0)
                {
                    this.fillDGV_fromRegisDOEntry(fr, doEntryMode, oldEstate, oldDO, true, false, false);
                }
                else if (fr.retTable_DSAP_DOTRX.Rows.Count > 0)
                {
                    this.fillDGV_fromRegisDOEntry(fr, doEntryMode, oldEstate, oldDO, false, true, false);
                }
                else if (fr.retTable_DSAP_DR.Rows.Count > 0)
                {
                    this.fillDGV_fromRegisDOEntry(fr, doEntryMode, oldEstate, oldDO, false, false, true);
                }
                else
                {
                    dgvDOCurrRow = fr.dgvDOCurrRow;
                    if (doEntryMode != "ADD")
                    {
                        if (this.dgvDO.CurrentRow.Index > 0)
                        {
                            this.dgvDO.Rows[0].Cells["Estate_qty"].Value = (Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString()) - Convert.ToDouble(fr.textOthNet.Text)) + oldEstate;
                        }
                    }
                    else
                    {
                        this.dgvDO.Rows.Add();
                        dgvDOCurrRow = this.dgvDO.Rows.Count - 1;
                        if ((this.dgvDO.Rows.Count > 0) && (dgvDOCurrRow > 0))
                        {
                            this.dgvDO.Rows[0].Cells["Estate_qty"].Value = Program.StrToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString(), 0) - Program.StrToDouble(fr.textOthNet.Text, 0);
                            this.dgvDO.Rows[0].Cells["DeliNo"].Value = this.txt_deli_note.Text;
                        }
                    }
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Coy"].Value = this.cCoy;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Location_Code"].Value = this.cLoc;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["DeliNo"].Value = fr.txtDeliveryNote.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Ref"].Value = this.comboBoxRef.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["gatepass_number"].Value = this.txt_gp_no.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_sap"].Value = fr.text_do_sap.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_sap_item"].Value = fr.text_do_sap_item.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["internal_number"].Value = fr.txtInternalNum.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["internal_number_item"].Value = fr.txtInNumItem.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["loading_qty_opw"].Value = fr.text_opw_loading_qty.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_qty"].Value = fr.text_do_sap_qty.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_uom"].Value = fr.text_do_sap_unit.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_base_qty"].Value = fr.textBoxQtyBaseUOM.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_base_uom"].Value = fr.textBoxBaseUOM.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_qty_kg"].Value = fr.text_do_sap_qty_kg.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_besar"].Value = fr.isDOBesar;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["DO_No"].Value = fr.textDO.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Comm_Code"].Value = fr.textComm.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Contract"].Value = fr.textCont.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Relation_Code"].Value = fr.textRCode.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Relation_Name"].Value = fr.textRName.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Netto"].Value = Program.StrToDouble(fr.textFactNet.Text, 2);
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Estate_qty"].Value = Program.StrToDouble(fr.textOthNet.Text, 2);
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Estate"].Value = fr.textEstate.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["PI_No"].Value = fr.textPI_No.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Transporter_Code"].Value = fr.textTransporter.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["license_number"].Value = fr.license_number;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["truck_number"].Value = fr.truck_number;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["driver_name"].Value = fr.driver_name;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Transaction_Code"].Value = fr.pTransType;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Storage_code"].Value = fr.textStorage.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Tolling"].Value = fr.tolling;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["OSDO"].Value = fr.labelQtyLeft.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Bruto"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["Bruto"].Value == null) ? 0 : this.dgvDO.Rows[dgvDOCurrRow].Cells["Bruto"].Value;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Tarra"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["Tarra"].Value == null) ? 0 : this.dgvDO.Rows[dgvDOCurrRow].Cells["Tarra"].Value;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["loading_qty"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["loading_qty"].Value == null) ? "0" : this.dgvDO.Rows[dgvDOCurrRow].Cells["loading_qty"].Value;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Return_Qty_KG"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["Return_Qty_KG"].Value == null) ? "0" : this.dgvDO.Rows[dgvDOCurrRow].Cells["Return_Qty_KG"].Value;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Return_Qty_Pack"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["Return_Qty_Pack"].Value == null) ? "0" : this.dgvDO.Rows[dgvDOCurrRow].Cells["Return_Qty_Pack"].Value;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value = fr.textSOItem_detail.Text;
                    if (this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value.ToString() == "")
                    {
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value = fr.so_item;
                    }
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["customer_QQ"].Value = fr.txtBox_QQ.Text;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["WeightPerUnitName"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["WeightPerUnitName"].Value == null) ? 0 : this.dgvDO.Rows[dgvDOCurrRow].Cells["WeightPerUnitName"].Value;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["DeducUnitQty"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["DeducUnitQty"].Value == null) ? 0 : this.dgvDO.Rows[dgvDOCurrRow].Cells["DeducUnitQty"].Value;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["TotalDeducUnit"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["TotalDeducUnit"].Value == null) ? 0 : this.dgvDO.Rows[dgvDOCurrRow].Cells["TotalDeducUnit"].Value;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Deduction"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["Deduction"].Value == null) ? 0 : this.dgvDO.Rows[dgvDOCurrRow].Cells["Deduction"].Value;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["UnitName"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["UnitName"].Value == null) ? "" : this.dgvDO.Rows[dgvDOCurrRow].Cells["UnitName"].Value;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["STO_No"].Value = fr.sto_no;
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["STO_Item"].Value = fr.sto_no_item;
                    if (dgvDOCurrRow != 0)
                    {
                        if (dgvDOCurrRow > 0)
                        {
                            this.dgvDO.Rows[dgvDOCurrRow].Cells["Bruto"].Value = Convert.ToDouble(this.dgvDO.Rows[dgvDOCurrRow].Cells["Netto"].Value.ToString());
                            this.dgvDO.Rows[dgvDOCurrRow].Cells["Tarra"].Value = "0";
                            this.dgvDO.Rows[dgvDOCurrRow].Cells["Netto"].Value = fr.textFactNet.Text;
                            if ((fr.active_lock_tdt || this.active_lock_TDT) ? (WBSetting.IntegrationSAP == "Y") : false)
                            {
                                this.cBoxDataNotMatch.Visible = true;
                                this.dgvDO.Rows[dgvDOCurrRow].Cells["Transporter_Code"].Value = fr.transporter;
                                if (((this.txt_truck.Text != fr.truck_number) || ((this.txt_transporter_code.Text != fr.transporter) || (this.txt_driver_ic.Text != fr.license_number))) || (this.textDriverName.Text != fr.driver_name))
                                {
                                    if (this.txt_truck.Text != fr.truck_number)
                                    {
                                        MessageBox.Show("Data Truck Number is Different Between Each Loading Note");
                                    }
                                    else if (this.txt_transporter_code.Text != fr.transporter)
                                    {
                                        MessageBox.Show("Data Transporter is Different Between Each Loading Note");
                                    }
                                    else if (this.txt_driver_ic.Text != fr.license_number)
                                    {
                                        MessageBox.Show("Data Driver License is Different Between Each Loading Note");
                                    }
                                    else if (this.textDriverName.Text != fr.driver_name)
                                    {
                                        MessageBox.Show("Data Driver Name is Different Between Each Loading Note");
                                    }
                                    this.cBoxDataNotMatch.Checked = true;
                                    this.cBoxDataNotMatch.Enabled = false;
                                }
                            }
                        }
                    }
                    else
                    {
                        if (fr.active_zdotrx)
                        {
                            this.active_zdotrx = true;
                        }
                        if (!(fr.active_lock_tdt && (WBSetting.IntegrationSAP == "Y")))
                        {
                            this.active_lock_TDT = false;
                            this.textDriverName.Enabled = true;
                            this.textDriverName.ReadOnly = false;
                            this.buttonDriver.Enabled = true;
                            this.txt_truck.Enabled = true;
                            this.buttonTruck.Enabled = true;
                            this.txt_transporter_code.Enabled = true;
                            this.buttonTransporter.Enabled = true;
                            this.cBoxDataNotMatch.Visible = false;
                            this.txt_driver_ic.Enabled = true;
                            this.txt_transporter_code.Text = fr.textTransporter.Text;
                        }
                        else
                        {
                            this.active_lock_TDT = true;
                            if (((doEntryMode == "ADD") || ((oldDO != fr.textDO.Text) || ((fr.truck_number != "") || (fr.driver_name != "")))) || (fr.license_number != ""))
                            {
                                this.txt_truck.Text = fr.truck_number;
                                this.txt_transporter_code.Text = fr.transporter;
                                this.dgvDO.Rows[dgvDOCurrRow].Cells["Transporter_Code"].Value = fr.transporter;
                                this.txt_driver_ic.Text = fr.license_number;
                                this.textDriverName.Text = fr.driver_name;
                            }
                            this.textDriverName.Enabled = false;
                            this.textDriverName.ReadOnly = true;
                            this.txt_truck.Enabled = false;
                            this.txt_transporter_code.Enabled = false;
                            this.txt_driver_ic.Enabled = false;
                            this.cBoxDataNotMatch.Visible = true;
                            string[] textArray5 = new string[] { "Transporter_Code" };
                            string[] textArray6 = new string[] { this.txt_transporter_code.Text };
                            DataRow row3 = this.t_transporter.GetData(textArray5, textArray6);
                            if (this.txt_transporter_code.Text != "")
                            {
                                if (row3 != null)
                                {
                                    this.lbl_transporter_name.Text = row3["Transporter_Name"].ToString();
                                }
                                else
                                {
                                    MessageBox.Show("Transporter has not been maintain in WB.NET");
                                }
                            }
                        }
                        if (this.textRemarkTicket.Text.Trim() == "")
                        {
                            this.textRemarkTicket.Text = fr.remark;
                        }
                        this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and  comm_code = '" + fr.textComm.Text.Trim() + "'"), WBData.conn);
                        string[] aField = new string[] { "Comm_Code" };
                        string[] aFind = new string[] { fr.textComm.Text };
                        DataRow data = this.tblComm.GetData(aField, aFind);
                        if (data != null)
                        {
                            this.CommType = data["Type"].ToString();
                        }
                        string[] textArray9 = new string[] { "Transporter_Code" };
                        string[] textArray10 = new string[] { this.txt_transporter_code.Text };
                        DataRow row2 = this.t_transporter.GetData(textArray9, textArray10);
                        if (this.txt_transporter_code.Text != "")
                        {
                            this.lbl_transporter_name.Text = (row2 == null) ? "" : row2["Transporter_Name"].ToString();
                        }
                        this.CommType = fr.CommType;
                        this.tabPageShow(this.CommType, this.tabPageWBDO);
                        if (fr.changeComm || ((doEntryMode == "ADD") && (this.dgvDO.Rows.Count == 1)))
                        {
                            this._InitBlankQC(this.dgvDO.Rows[dgvDOCurrRow].Cells["DO_NO"].Value.ToString());
                        }
                        if (fr.changeComm)
                        {
                            this.oldComm = fr.textComm.Text.Trim();
                        }
                    }
                }
            }
            if (fr.saved)
            {
                string str3 = "";
                if (this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString() != "")
                {
                    this.tblComm.OpenTable("wb_comm", "select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString() + "'"), WBData.conn);
                    this.tblComm.DR = this.tblComm.DT.Rows[0];
                    WBCondition condition = new WBCondition();
                    string[] textArray11 = new string[] { "Select * from wb_transaction_type where coy ='", this.cCoy, "' and location_code = '", this.cLoc, "' and transaction_code = '", this.dgvDO.Rows[0].Cells["transaction_code"].Value.ToString(), "'" };
                    this.t_trans_type.OpenTable("wb_transaction_type", string.Concat(textArray11), WBData.conn);
                    this.t_trans_type.DR = this.t_trans_type.DT.Rows[0];
                    DataRow[] dgRows = new DataRow[] { this.t_trans_type.DR, this.tblComm.DR };
                    condition.fillParameter("NOPW", dgRows);
                    str3 = condition.getResult() ? "Y" : "N";
                    condition.Dispose();
                }
                if ((WBSetting.Field("NOPW") == "Y") && (str3 == "Y"))
                {
                    this.checkNOPW.Visible = true;
                    this.checkNOPW.Enabled = true;
                }
                else
                {
                    this.checkNOPW.Checked = false;
                    this.checkNOPW.Visible = false;
                    this.checkNOPW.Enabled = false;
                }
            }
            fr.Dispose();
            Cursor.Current = Cursors.Default;
        }

        public void f_load()
        {
            this.camera = new WBCamera();
            this.labelSplitTrans.Text = "";
            this.lbl_transporter_name.Text = "";
            this.textDriverName.Text = "";
            this.labelScanMessage.Text = "";
            this.dtRegistration.Enabled = false;
            this.txtRegistrationTime.Enabled = false;
            if (!WBSetting.activeRegistrationRequireLicensePhoto)
            {
                this.tabControlPhoto.TabPages.Remove(this.tabPageDriverLicenseID);
            }
            if ((WBSetting.region == "2") && (WBSetting.locType == "1"))
            {
                this.labelPL3.Visible = true;
                this.textPL3.Visible = true;
            }
            else
            {
                this.labelPL3.Visible = false;
                this.textPL3.Visible = false;
            }
            this.txt_gp_no.Text = this.gatepassNo;
            this.initTable();
            this.tabControlInformation.TabPages.Remove(this.tabPageFFB);
            this.tabControlInformation.TabPages.Remove(this.tabPageDivision);
            if (WBSetting.locType != "0")
            {
                this.tabControlInformation.TabPages.Remove(this.tabPageCont);
            }
            this.initDGDO();
            this.initDGQC();
            this.initDGContainer();
            this.initDGDOContainer();
            this.initDGGPDest();
            this.initDGDivBlock();
            if (this.pMode == "ADD")
            {
                this.gpCode = this.t_LocationCode.DT.Rows[0]["GatepassCode"].ToString();
            }
            string str = (this.pMode == "ADD") ? Resource.Mainform_089 : ((this.pMode == "EDIT") ? Resource.Mainform_090 : ((this.pMode == "EDIT_TDT") ? Resource.Mainform_097 : ((this.pMode == "VIEW") ? Resource.Mainform_091 : ((this.pMode == "SUBMIT") ? Resource.Mainform_092 : ""))));
            string[] textArray1 = new string[10];
            textArray1[0] = str;
            textArray1[1] = " ";
            textArray1[2] = this.cCoy;
            textArray1[3] = "/";
            textArray1[4] = this.cLoc;
            textArray1[5] = "(";
            textArray1[6] = this.t_Coy.DT.Rows[0]["coy_name"].ToString();
            textArray1[7] = "/";
            textArray1[8] = this.t_LocationCode.DT.Rows[0]["location_name"].ToString();
            textArray1[9] = ")";
            this.Text = string.Concat(textArray1);
            Program.AutoComp(this.t_truck, "truck_number", this.txt_truck);
            Program.AutoComp(this.t_transporter, "transporter_code", this.txt_transporter_code);
            Program.AutoComp(this.t_tanker, "tanker_no", this.textTanker);
            Program.AutoComp(this.t_driver, "license_no", this.txt_driver_ic);
            Program.AutoComp(this.t_driver, "Name", this.textDriverName);
            Program.AutoComp(this.t_Source, "Description", this.textDestination);
            this.comboWX.DisplayMember = "Text";
            this.comboWX.ValueMember = "Value";
            List<object> list = new List<object> {
                new { 
                    Text = "2X Normal Weighing",
                    Value = "0"
                },
                new { 
                    Text = "NX Multiple Weighing",
                    Value = "1"
                }
            };
            if (WBSetting.Container != "Y")
            {
                list.Add(new { 
                    Text = "Non Weighing",
                    Value = "4"
                });
                this.comboWX.DataSource = list;
                this.comboWX.Text = "2X Normal Weighing";
            }
            else
            {
                list.Add(new { 
                    Text = "4X / Container Weighing In (1st,2nd)",
                    Value = "2"
                });
                list.Add(new { 
                    Text = "4X / Container Weighing Out (3rd,4th)",
                    Value = "3"
                });
                list.Add(new { 
                    Text = "Non Weighing",
                    Value = "4"
                });
                this.comboWX.DataSource = list;
                this.comboWX.Text = "";
            }
            if (WBSetting.Field("ScanCardSPB") == "Y")
            {
                this.radioButtonEntryAVG.Checked = false;
                this.radioButtonEntryTotalBunch.Checked = true;
            }
            else
            {
                this.radioButtonEntryAVG.Checked = true;
                this.radioButtonEntryTotalBunch.Checked = false;
            }
            if (((this.pMode == "EDIT") || ((this.pMode == "EDIT_TDT") || ((this.pMode == "VIEW") || ((this.pMode == "SUBMIT") && (this.txt_gp_no.Text.Trim() != ""))))) || ((this.pMode == "ADD") && this.isCopied))
            {
                this.scaneSPB = !string.IsNullOrEmpty(this.t_gatepass.DT.Rows[0]["scanespb"].ToString()) ? (this.t_gatepass.DT.Rows[0]["scanespb"].ToString() == "Y") : false;
                if (this.t_gatepass.DT.Rows.Count == 1)
                {
                    string[] textArray2 = new string[] { "SELECT * FROM wb_transaction WHERE Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "'  AND gatepass_number = '", this.txt_gp_no.Text.Trim(), "' AND ((Deleted = 'N' OR Deleted = '' OR Deleted IS NULL) OR (Deleted = 'Y' AND cancel_type = 'R')) AND (zAuto IS NULL OR zAuto = '' OR zAuto = 'N')" };
                    this.t_trans.OpenTable("wb_transaction", string.Concat(textArray2), WBData.conn);
                    this.comboBoxRef.Items.Clear();
                    if (this.t_trans.DT.Rows.Count > 0)
                    {
                        foreach (DataRow row3 in this.t_trans.DT.Rows)
                        {
                            this.comboBoxRef.Items.Add(row3["ref"].ToString());
                        }
                        this.comboBoxRef.SelectedIndex = 0;
                    }
                    if (this.comboBoxRef.Text != "")
                    {
                        this.t_trans_temp.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE linked = '" + this.comboBoxRef.Text + "'", WBData.conn);
                        if (this.t_trans_temp.DT.Rows.Count > 0)
                        {
                            this.linkedGatepass = this.t_trans_temp.DT.Rows[0]["gatepass_number"].ToString();
                            foreach (DataRow row4 in this.t_trans_temp.DT.Rows)
                            {
                                this.comboBoxRefTemp.Items.Add(row4["ref"].ToString());
                            }
                            this.comboBoxRefTemp.SelectedIndex = 0;
                        }
                    }
                    DataRow row = this.t_gatepass.DT.Rows[0];
                    this.uniqCardNo = row["Card_No"].ToString();
                    this.textCardNo.Text = WBCard.getCardNo(this.uniqCardNo);
                    if (row["ref"].ToString() != "")
                    {
                        this.initTableTransWithRef();
                    }
                    try
                    {
                        this.lastWX = row["WX"].ToString();
                        this.comboWX.SelectedValue = Convert.ToInt16(row["WX"].ToString()).ToString();
                        this.prevWX = Convert.ToInt16(row["WX"].ToString()).ToString();
                    }
                    catch (Exception)
                    {
                        this.lastWX = "0";
                        this.comboWX.SelectedValue = "0";
                        this.prevWX = "0";
                    }
                    if (row["WX"].ToString() == "0")
                    {
                        this.comboWX.Text = "2X Normal Weighing";
                    }
                    else if (row["WX"].ToString() == "1")
                    {
                        this.comboWX.Text = "NX Multiple Weighing";
                    }
                    else if (row["WX"].ToString() == "2")
                    {
                        this.comboWX.Text = "4X / Container Weighing In (1st,2nd)";
                    }
                    else if (row["WX"].ToString() == "3")
                    {
                        this.comboWX.Text = "4X / Container Weighing Out (3rd,4th)";
                    }
                    else if (row["WX"].ToString() == "4")
                    {
                        this.comboWX.Text = "Non Weighing";
                    }
                    this.dtRegistration.Value = Convert.ToDateTime(row["in_date"].ToString());
                    this.txtRegistrationTime.Text = row["In_time"].ToString();
                    this.txt_truck.Text = row["truck_number"].ToString();
                    this.txt_transporter_code.Text = row["transporter_code"].ToString();
                    this.textTrailerNo.Text = row["trailer_Number"].ToString();
                    this.txt_driver_ic.Text = row["License_No"].ToString();
                    this.textTanker.Text = row["tanker_no"].ToString();
                    this.txtPassengers.Text = row["Passenger_Qty"].ToString();
                    this.txtPassengersNames.Text = row["Passenger_Names"].ToString();
                    this.checkLastWeighing.Checked = row["LastWeighCheck"].ToString() == "Y";
                    this.checkNeedContainerCheck.Checked = row["need_container_check"].ToString() == "Y";
                    string[] aField = new string[] { "Transporter_Code" };
                    string[] aFind = new string[] { this.txt_transporter_code.Text };
                    DataRow data = this.t_transporter.GetData(aField, aFind);
                    if (data != null)
                    {
                        this.lbl_transporter_name.Text = data["Transporter_Name"].ToString();
                    }
                    string[] textArray5 = new string[] { "License_No" };
                    string[] textArray6 = new string[] { this.txt_driver_ic.Text.Trim() };
                    data = this.t_driver.GetData(textArray5, textArray6);
                    if (data != null)
                    {
                        this.textDriverName.Text = data["Name"].ToString();
                    }
                    this.labelDestinationCode.Text = this.t_gatepass_dest.DT.Rows[0]["source_code"].ToString();
                    string[] textArray7 = new string[] { "Source_code" };
                    string[] textArray8 = new string[] { this.labelDestinationCode.Text };
                    data = this.t_Source.GetData(textArray7, textArray8);
                    if (data != null)
                    {
                        this.textDestination.Text = data["Description"].ToString();
                    }
                    if (((this.comboWX.SelectedValue.ToString() == "0") || (this.comboWX.SelectedValue.ToString() == "2")) ? (this.comboBoxRef.Items.Count > 1) : false)
                    {
                        this.labelSplitTrans.Text = "Split Transaction ( " + this.comboBoxRef.Items.Count + " )";
                    }
                    else if ((this.comboWX.SelectedValue.ToString() == "1") && (this.comboBoxRef.Items.Count > 1))
                    {
                        this.labelSplitTrans.Text = "Langsir Transaction ( " + this.comboBoxRef.Items.Count + " )";
                    }
                    else if ((this.comboWX.SelectedValue.ToString() == "3") && (this.comboBoxRefTemp.Items.Count > 1))
                    {
                        this.labelSplitTrans.Text = "Split Transaction ( " + this.comboBoxRefTemp.Items.Count + " )";
                    }
                    if (row["entryAVGorBunch"].ToString() == "1")
                    {
                        this.radioButtonEntryTotalBunch.Checked = true;
                    }
                    else
                    {
                        this.radioButtonEntryAVG.Checked = true;
                    }
                }
                this.fillDataOtherParty();
                this.fillDataGeneralInfo();
                this.fillDGDO();
                this.fillDGQC();
                this.fillDGContainer();
                this.fillDGDOContainer();
                this.fillDGGPDest();
                this.fillDGDivBlock();
                this.fillDataFFB();
                this.countAdditionalInformation();
                if (((this.pMode == "EDIT") || (this.pMode == "VIEW")) || (this.pMode == "EDIT_TDT"))
                {
                    this.countOSinDgvDO();
                }
                if (this.dgvDO.Rows.Count <= 0)
                {
                    this.tabPageShow("", this.tabPageGeneral);
                }
                else
                {
                    this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and  comm_code = '" + this.dgvDO.Rows[0].Cells["Comm_Code"].Value.ToString() + "'"), WBData.conn);
                    if (this.tblComm.DT.Rows.Count > 0)
                    {
                        this.CommType = this.tblComm.DT.Rows[0]["Type"].ToString();
                    }
                    this.tabPageShow(this.tblComm.DT.Rows[0]["Type"].ToString(), this.tabPageGeneral);
                }
            }
            this.initImage(this.pMode);
            this.setOtherParty();
            if (this.pMode == "SUBMIT")
            {
                if (this.pMode == "SUBMIT")
                {
                    this.btn_save.Enabled = false;
                    if (this.comboWX.SelectedValue.ToString() == "3")
                    {
                        this.labelArrow.Visible = true;
                        this.comboBoxRefTemp.Visible = true;
                    }
                    this.buttonAddDest.Enabled = false;
                    this.buttonDeleteDest.Enabled = false;
                    this.textDestination.Enabled = false;
                    this.buttonDestination.Enabled = false;
                    this.comboWX.Enabled = false;
                    this.txt_truck.Enabled = false;
                    this.buttonTruck.Enabled = false;
                    this.textTrailerNo.Enabled = false;
                    this.txt_transporter_code.Enabled = false;
                    this.buttonTransporter.Enabled = false;
                    this.txt_driver_ic.Enabled = false;
                    this.textDriverName.Enabled = false;
                    this.buttonDriver.Enabled = false;
                    this.textTanker.Enabled = false;
                    this.buttonTanker.Enabled = false;
                    this.txtPassengers.Enabled = false;
                    this.txtPassengersNames.Enabled = false;
                    this.checkLastWeighing.Enabled = false;
                    WBTable table = new WBTable();
                    string[] textArray9 = new string[] { " SELECT uniq FROM wb_condition  WHERE Coy = '", this.cCoy, "'  AND Location_Code = '", this.cLoc, "'  AND Condition_Code = 'ENABLE_CHANGE_TRUCK_DRIVER_WHEN_SUBMIT'" };
                    string sqltext = string.Concat(textArray9);
                    table.OpenTable("wb_condition", sqltext, WBData.conn);
                    if ((table.DT.Rows.Count > 0) && this.loadAfterScanCardForSubmit)
                    {
                        this.txt_truck.Enabled = true;
                        this.buttonTruck.Enabled = true;
                        this.txt_driver_ic.Enabled = true;
                        this.buttonDriver.Enabled = true;
                        this.textDriverName.Enabled = true;
                    }
                    table.Dispose();
                    if (this.comboWX.SelectedValue.ToString() == "1")
                    {
                        this.checkEstate.Enabled = false;
                        this.txt_deli_note.Enabled = false;
                        this.chk_return.Enabled = false;
                        this.text_ref_return.Enabled = false;
                        this.btn_check.Enabled = false;
                        this.txt_seal.Enabled = false;
                        this.textRemarkTicket.Enabled = false;
                        this.textRemarkReport.Enabled = false;
                        this.txtAddInfo.Enabled = false;
                        this.textPL3.Enabled = false;
                    }
                    else
                    {
                        this.checkEstate.Enabled = true;
                        this.txt_deli_note.Enabled = true;
                        this.chk_return.Enabled = false;
                        this.text_ref_return.Enabled = false;
                        this.btn_check.Enabled = false;
                        this.txt_seal.Enabled = true;
                        this.textRemarkTicket.Enabled = true;
                        this.textRemarkReport.Enabled = true;
                        this.txtAddInfo.Enabled = true;
                        this.textPL3.Enabled = true;
                    }
                    this.checkNOPW.Enabled = false;
                    this.textWBNo.Enabled = false;
                    this.dateDelivery.Enabled = false;
                    this.TimeDelivery.Enabled = false;
                    this.textGrossEstate.Enabled = false;
                    this.textTareEstate.Enabled = false;
                    this.textNetEstate.Enabled = false;
                    this.buttonAddDO.Enabled = false;
                    this.buttonEditDO.Enabled = false;
                    this.buttonDeleteDO.Enabled = false;
                    this.buttonDeleteAllDO.Enabled = false;
                    this.buttonViewDO.Enabled = false;
                    if (WBSetting.locType != "1")
                    {
                        this.dgvQC.Columns["Estate"].ReadOnly = true;
                        this.dgvQC.Columns["Estate"].DefaultCellStyle.BackColor = Color.LightGray;
                        this.dgvQC.Columns["Factory"].ReadOnly = true;
                        this.dgvQC.Columns["Factory"].DefaultCellStyle.BackColor = Color.LightGray;
                    }
                    else
                    {
                        this.dgvQC.Columns["Estate"].ReadOnly = !WBUser.CheckTrustee("TRANS_QC", "E");
                        if (this.dgvQC.Columns["Estate"].ReadOnly)
                        {
                            this.dgvQC.Columns["Estate"].DefaultCellStyle.BackColor = Color.LightGray;
                        }
                        this.dgvQC.Columns["Factory"].ReadOnly = !WBUser.CheckTrustee("TRANS_QC", "A");
                        if (this.dgvQC.Columns["Factory"].ReadOnly)
                        {
                            this.dgvQC.Columns["Factory"].DefaultCellStyle.BackColor = Color.LightGray;
                        }
                    }
                    this.buttonContAdd.Enabled = false;
                    this.buttonContEdit.Enabled = false;
                    this.buttonContDelete.Enabled = false;
                    this.buttonAddDivision.Enabled = false;
                    this.buttonEditDivision.Enabled = false;
                    this.buttonDeleteDivision.Enabled = false;
                    this.groupBunch.Enabled = false;
                    this.groupRV.Enabled = false;
                    this.groupFFBReject.Enabled = false;
                    this.buttonEntryDeduc.Enabled = false;
                }
            }
            else
            {
                this.btn_print.Enabled = false;
                if (this.pMode == "VIEW")
                {
                    this.comboWX.Enabled = false;
                    this.btn_save.Enabled = false;
                    if (this.comboWX.SelectedValue.ToString() == "3")
                    {
                        this.labelArrow.Visible = true;
                        this.comboBoxRefTemp.Visible = true;
                    }
                }
                else if ((this.pMode == "EDIT") || (this.pMode == "EDIT_TDT"))
                {
                    if (this.comboBoxRef.Items.Count > 0)
                    {
                        this.labelArrow.Visible = true;
                        this.comboBoxRefTemp.Visible = true;
                    }
                    if (this.completed)
                    {
                        this.checkEstate.Enabled = false;
                        this.txt_deli_note.Enabled = false;
                        this.chk_return.Enabled = false;
                        this.text_ref_return.Enabled = false;
                        this.btn_check.Enabled = false;
                        this.txt_seal.Enabled = false;
                        this.textRemarkTicket.Enabled = false;
                        this.textRemarkReport.Enabled = false;
                        this.txtAddInfo.Enabled = false;
                        this.textPL3.Enabled = false;
                        this.checkNOPW.Enabled = false;
                        this.textWBNo.Enabled = false;
                        this.dateDelivery.Enabled = false;
                        this.TimeDelivery.Enabled = false;
                        this.textGrossEstate.Enabled = false;
                        this.textTareEstate.Enabled = false;
                        this.textNetEstate.Enabled = false;
                        this.buttonAddDO.Enabled = false;
                        this.buttonEditDO.Enabled = false;
                        this.buttonDeleteDO.Enabled = false;
                        this.buttonDeleteAllDO.Enabled = false;
                        this.buttonViewDO.Enabled = false;
                        this.buttonDeleteAllDO.Enabled = false;
                        this.dgvQC.Columns["Estate"].ReadOnly = true;
                        this.dgvQC.Columns["Estate"].DefaultCellStyle.BackColor = Color.LightGray;
                        this.dgvQC.Columns["Factory"].ReadOnly = true;
                        this.dgvQC.Columns["Factory"].DefaultCellStyle.BackColor = Color.LightGray;
                        this.buttonContAdd.Enabled = false;
                        this.buttonContEdit.Enabled = false;
                        this.buttonContDelete.Enabled = false;
                        this.buttonAddDivision.Enabled = false;
                        this.buttonEditDivision.Enabled = false;
                        this.buttonDeleteDivision.Enabled = false;
                        this.groupBunch.Enabled = false;
                        this.groupRV.Enabled = false;
                        this.groupFFBReject.Enabled = false;
                    }
                    if ((!this.inprogress_token && this.active_lock_TDT) && (WBSetting.IntegrationSAP == "Y"))
                    {
                        this.textDriverName.Enabled = false;
                        this.txt_transporter_code.Enabled = false;
                        this.buttonTransporter.Enabled = false;
                        this.txt_driver_ic.Enabled = false;
                        this.buttonDriver.Enabled = false;
                        this.txt_truck.Enabled = false;
                        this.buttonTruck.Enabled = false;
                        this.cBoxDataNotMatch.Visible = true;
                        this.buttonAddDO.Enabled = true;
                        this.buttonEditDO.Enabled = false;
                        this.buttonDeleteDO.Enabled = true;
                        this.buttonDeleteAllDO.Enabled = true;
                        this.buttonViewDO.Enabled = true;
                    }
                    else if (this.pMode == "EDIT_TDT")
                    {
                        foreach (Control control in this.GetOffsprings())
                        {
                            if (((control.Name != "tabPageWBDO") && (control.Name != "tabControlInformation")) && ((control.GetType() != typeof(Label)) || (control.GetType() != typeof(TabControl))))
                            {
                                control.Enabled = false;
                            }
                        }
                        this.grpTruckInfo.Enabled = true;
                        this.textDriverName.Enabled = true;
                        this.txt_transporter_code.Enabled = true;
                        this.buttonTransporter.Enabled = true;
                        this.txt_driver_ic.Enabled = true;
                        this.buttonDriver.Enabled = true;
                        this.txt_truck.Enabled = true;
                        this.buttonTruck.Enabled = true;
                        this.cBoxDataNotMatch.Visible = false;
                        this.buttonAddDO.Enabled = false;
                        this.buttonEditDO.Enabled = true;
                        this.btn_save.Enabled = true;
                        this.btn_cancel.Enabled = true;
                        this.buttonDeleteDO.Enabled = false;
                        this.buttonDeleteAllDO.Enabled = false;
                        this.buttonViewDO.Enabled = false;
                    }
                    this.txt_deli_note.Enabled = (this.pMode == "EDIT") && ((this.t_trans.DT.Rows.Count == 0) || ((this.t_trans.DT.Rows.Count > 0) && string.IsNullOrEmpty(this.t_trans.DT.Rows[0]["Report_Date"].ToString())));
                    this.buttonEntryDeduc.Enabled = (this.pMode == "EDIT") && ((this.t_trans.DT.Rows.Count == 0) || ((this.t_trans.DT.Rows.Count > 0) && string.IsNullOrEmpty(this.t_trans.DT.Rows[0]["Report_Date"].ToString())));
                }
            }
            this.buttonDN.Visible = WBSetting.locType == "1";
            this.oldUniqNo = WBCard.getUniqCardNo(this.textCardNo.Text.Trim());
            this.oldTruck = this.txt_truck.Text;
            this.oldWX = this.comboWX.SelectedValue.ToString();
            this.oldDriver = this.txt_driver_ic.Text;
            this.oldDriverName = this.textDriverName.Text.Trim();
            this.oldTransporter = this.txt_transporter_code.Text;
            this.oldNOPW = this.checkNOPW.Checked ? "Y" : "N";
            this.oldTicketEstate = this.textWBNo.Text.Trim();
            this.oldDateEstate = this.dateDelivery.Value.ToString();
            this.oldTimeEstate = this.TimeDelivery.Text.Trim();
            this.oldGrossEstate = this.textGrossEstate.Text.Trim();
            this.oldTareEstate = this.textTareEstate.Text.Trim();
            this.oldNetEstate = this.textNetEstate.Text.Trim();
            this.oldContainerCheck = this.checkNeedContainerCheck.Checked ? "Y" : "N";
            this.oldRend = this.textRendCPO.Text.Trim();
            if (this.dgvDO.Rows.Count > 0)
            {
                this.oldFirstTransType = this.dgvDO.Rows[0].Cells["transaction_code"].Value.ToString();
            }
            if (WBSetting.gatepassWithoutCard)
            {
                this.textCardNo.Enabled = false;
                this.labelScanMessage.Visible = false;
            }
            this.checkEntryAVGorTotalBunch();
            this.textCardNo.Select();
            if ((this.pMode == "ADD") && this.isCopied)
            {
                this.txt_gp_no.Text = "";
                this.textCardNo.Text = "";
                this.comboBoxRef.Items.Clear();
                this.labelSplitTrans.Visible = false;
                this.tabControlInformation.SelectedTab = this.tabPageWBDO;
            }
            this.firstload = false;
            this.checkDestinationRoutes(Constant.CHECKPOINT_CONTAINER_CHECK);
            if (this.pMode == "EDIT_TDT")
            {
                this.scanStatus = true;
            }
            if (this.pMode == "EDIT")
            {
                this.tbl_warning_trace.OpenTable("wb_warning_trace", "select * from wb_warning_trace with (nolock) where " + WBData.CompanyLocation(" and type = 'GATEPASS'"), WBData.conn);
                this.tmpGP = this.tblgp.DT.Clone();
                this.transBefore = this.tmpGP.NewRow();
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.tblgp.DT.Rows[0]["uniq"].ToString() };
                this.transBefore.ItemArray = this.tblgp.GetData(aField, aFind).ItemArray;
                this.tmpGP.Rows.Add(this.transBefore);
                this.tmp_transDO = this.tblTransDO.DT.Clone();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.tblTransDO.DT.Rows.Count)
                    {
                        break;
                    }
                    this.transDOBefore = this.tmp_transDO.NewRow();
                    this.tblTransDO.DR = this.tblTransDO.DT.Rows[num2];
                    this.transDOBefore.ItemArray = this.tblTransDO.DR.ItemArray;
                    this.tmp_transDO.Rows.Add(this.transDOBefore);
                    num2++;
                }
            }
        }

        private void fillDataFFB()
        {
            this.t_gatepass.ReOpen();
            if (this.t_gatepass.DT.Rows.Count > 0)
            {
                this.radioButtonEntryAVG.Enabled = false;
                this.radioButtonEntryTotalBunch.Enabled = false;
                this.textBunchTotal.Enabled = false;
                this.textBunchDeduc.Enabled = false;
                this.textAvg.Enabled = false;
                this.textRejectedFFBBunch.Enabled = false;
                this.textRejectedFFBKG.Enabled = false;
                this.textRejectedFFBReason.Enabled = false;
                this.textRendCPO.Enabled = false;
                if (this.t_gatepass.DT.Rows[0]["ref"].ToString() == "")
                {
                    DataRow row = this.t_gatepass.DT.Rows[0];
                    this.textBunchTotal.Text = row["TotalBunch"].ToString();
                    this.textBunchDeduc.Text = row["TotalBunchGrading"].ToString();
                    this.textAvg.Text = row["Average"].ToString();
                    this.textRendCPO.Text = row["Rend_CPO"].ToString();
                    this.textRejectedFFBBunch.Text = row["TBS_Reject"].ToString();
                    this.textRejectedFFBReason.Text = row["Reason"].ToString();
                }
                else if (this.t_trans.DT.Rows.Count > 0)
                {
                    DataRow row2 = this.t_trans.DT.Rows[0];
                    this.textBunchTotal.Text = row2["TotalBunch"].ToString();
                    this.textBunchDeduc.Text = row2["TotalBunchGrading"].ToString();
                    this.textAvg.Text = row2["Average"].ToString();
                    this.textRendCPO.Text = row2["Rend_CPO"].ToString();
                    this.textRejectedFFBBunch.Text = row2["TBS_Reject"].ToString();
                    this.textRejectedFFBReason.Text = row2["Reason"].ToString();
                }
            }
            if ((this.pMode == "ADD") && this.isCopied)
            {
                this.radioButtonEntryTotalBunch.Checked = true;
                this.textBunchTotal.Text = "0";
                this.textBunchDeduc.Text = "0";
                this.textAvg.Text = "0";
                this.textRendCPO.Text = "0";
                this.textRejectedFFBBunch.Text = "0";
                this.textRejectedFFBKG.Text = "0";
                this.textRejectedFFBReason.Text = "";
            }
        }

        private void fillDataGeneralInfo()
        {
            this.t_gatepass.ReOpen();
            if (this.t_gatepass.DT.Rows.Count > 0)
            {
                if (this.t_gatepass.DT.Rows[0]["ref"].ToString() == "")
                {
                    DataRow row = this.t_gatepass.DT.Rows[0];
                    this.checkEstate.Checked = row["EstateDiff"].ToString() == "Y";
                    this.txt_deli_note.Text = row["delivery_note"].ToString();
                    this.txt_seal.Text = row["seal"].ToString();
                    this.textRemarkTicket.Text = row["remark_ticket"].ToString();
                    this.textRemarkReport.Text = row["remark_report"].ToString();
                    this.txtAddInfo.Text = row["addi_info"].ToString();
                    this.textPL3.Text = row["PL3_No"].ToString();
                    this.chk_return.Checked = row["mark_return"].ToString() == "X";
                    if (this.chk_return.Checked)
                    {
                        this.text_ref_return.Text = row["return_ref"].ToString();
                        this.panel_return.Visible = true;
                    }
                }
                else if (this.t_trans.DT.Rows.Count > 0)
                {
                    DataRow row2 = this.t_trans.DT.Rows[0];
                    this.checkEstate.Checked = row2["EstateDiff"].ToString() == "Y";
                    this.txt_deli_note.Text = row2["delivery_note"].ToString();
                    this.txt_seal.Text = row2["seal"].ToString();
                    this.textRemarkTicket.Text = row2["remark_ticket"].ToString();
                    this.textRemarkReport.Text = row2["remark_report"].ToString();
                    this.txtAddInfo.Text = row2["addi_info"].ToString();
                    this.textPL3.Text = row2["PL3_No"].ToString();
                    this.chk_return.Checked = row2["mark_return"].ToString() == "X";
                    if (this.chk_return.Checked)
                    {
                        this.text_ref_return.Text = row2["return_ref"].ToString();
                        this.panel_return.Visible = true;
                    }
                }
            }
            this.oldDeliveryNote = this.txt_deli_note.Text.Trim();
            this.oldEstateDifferent = this.checkEstate.Checked;
            this.oldSeal = this.txt_seal.Text.Trim();
            this.oldRemarkReport = this.textRemarkReport.Text.Trim();
            this.oldRemarkTicket = this.textRemarkTicket.Text.Trim();
            this.oldAdditionalInfo = this.txtAddInfo.Text.Trim();
            this.oldPL3 = this.textPL3.Text.Trim();
        }

        private void fillDataOtherParty()
        {
            this.t_gatepass.ReOpen();
            if (this.t_gatepass.DT.Rows.Count > 0)
            {
                if (this.t_gatepass.DT.Rows[0]["ref"].ToString() == "")
                {
                    DataRow row = this.t_gatepass.DT.Rows[0];
                    this.textWBNo.Text = row["OPRef"].ToString();
                    this.checkNOPW.Checked = row["nopw"].ToString() == "Y";
                    this.checkNOPW.Visible = this.checkNOPW.Enabled;
                    this.dateDelivery.Text = row["Delivery_Date"].ToString();
                    this.TimeDelivery.Text = row["Delivery_Time"].ToString();
                    this.textGrossEstate.Text = (row["Gross_Estate"].ToString() == "") ? "0" : $"{row["Gross_Estate"]:N0}";
                    this.textTareEstate.Text = (row["Tare_Estate"].ToString() == "") ? "0" : $"{row["Tare_Estate"]:N0}";
                    this.textNetEstate.Text = (row["Net_Estate"].ToString() == "") ? "0" : $"{row["Net_Estate"]:N0}";
                }
                else if (this.t_trans.DT.Rows.Count > 0)
                {
                    DataRow row2 = this.t_trans.DT.Rows[0];
                    this.textWBNo.Text = row2["Ticket"].ToString();
                    this.checkNOPW.Checked = row2["nopw"].ToString() == "Y";
                    this.checkNOPW.Visible = this.checkNOPW.Enabled;
                    this.dateDelivery.Text = row2["Delivery_Date"].ToString();
                    this.TimeDelivery.Text = row2["Delivery_Time"].ToString();
                    this.textGrossEstate.Text = (row2["Gross_Estate"].ToString() == "") ? "0" : $"{row2["Gross_Estate"]:N0}";
                    this.textTareEstate.Text = (row2["Tare_Estate"].ToString() == "") ? "0" : $"{row2["Tare_Estate"]:N0}";
                    this.textNetEstate.Text = (row2["Net_Estate"].ToString() == "") ? "0" : $"{row2["Net_Estate"]:N0}";
                }
            }
            if (((this.pMode == "ADD") && this.isCopied) && !this.checkNOPW.Checked)
            {
                this.textWBNo.Text = "";
                this.dateDelivery.Text = DateTime.Now.ToString("dd/MM/yyyy");
                this.TimeDelivery.Text = "";
                this.textGrossEstate.Text = "0";
                this.textTareEstate.Text = "0";
                this.textNetEstate.Text = "0";
            }
        }

        private void fillDGContainer()
        {
            this.dgvCont.Rows.Clear();
            if (this.tblTransContainer.DT.Rows.Count > 0)
            {
                this.tblTransContainer.ToDGV(this.dgvCont);
                this.dgvCont.Rows[0].Selected = true;
            }
        }

        private void fillDGDivBlock()
        {
            this.dgvDivBlock.Rows.Clear();
            if (this.tblTransDiv.DT.Rows.Count > 0)
            {
                this.tblTransDiv.ToDGV(this.dgvDivBlock);
                this.dgvDivBlock.Rows[0].Selected = true;
            }
        }

        private void fillDGDO()
        {
            this.dgvDO.Rows.Clear();
            if (this.tblTransDO.DT.Rows.Count > 0)
            {
                this.tblTransDO.ToDGV(this.dgvDO);
                this.dgvDO.Rows[0].Selected = true;
            }
        }

        private void fillDGDOContainer()
        {
            this.dgvDOCont.Rows.Clear();
            if (this.tblTransDOContainer.DT.Rows.Count > 0)
            {
                this.tblTransDOContainer.ToDGV(this.dgvDOCont);
                this.dgvDOCont.Rows[0].Selected = true;
            }
        }

        private void fillDGGPDest()
        {
            this.dgvGPDest.Rows.Clear();
            if (this.t_gatepass_dest.DT.Rows.Count > 0)
            {
                this.t_gatepass_dest.ToDGV(this.dgvGPDest);
                this.dgvGPDest.Rows[0].Selected = true;
            }
            this.oldDestination = new string[this.dgvGPDest.Rows.Count];
            if (this.dgvGPDest.Rows.Count > 0)
            {
                int index = 0;
                foreach (DataGridViewRow row in (IEnumerable) this.dgvGPDest.Rows)
                {
                    DataRow[] rowArray = this.t_Source.DT.Select(" source_Code = '" + row.Cells["source_code"].Value.ToString() + "'");
                    if (rowArray.Length != 0)
                    {
                        row.Cells["description"].Value = rowArray[0]["description"].ToString();
                    }
                    this.oldDestination[index] = row.Cells["source_code"].Value.ToString();
                    index++;
                }
            }
            if ((this.pMode == "ADD") && this.isCopied)
            {
                foreach (DataGridViewRow row2 in (IEnumerable) this.dgvDO.Rows)
                {
                    row2.Cells["gatepass_number"].Value = "";
                }
                this.oldDestination = null;
            }
        }

        private void fillDGQC()
        {
            this.dgvQC.Rows.Clear();
            if (this.tblTransQC.DT.Rows.Count > 0)
            {
                this.tblTransQC.ToDGV(this.dgvQC);
                this.dgvQC.Rows[0].Selected = true;
            }
        }

        public void fillDGV_fromRegisDOEntry(FormRegisDOEntry fr, string doEntryMode, double oldEstate, string oldDO, bool from_do, bool from_dotrx, bool from_dr)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            DataGridView view = new DataGridView();
            string str = "";
            string str2 = "";
            float num2 = 0f;
            if (doEntryMode == "ADD")
            {
                table.OpenTable("wb_contract", "select * from wb_contract where" + WBData.CompanyLocation(" and (closed is null or closed <> 'X' or closed = 'N') and zAuto = 'N'"), WBData.conn);
            }
            else
            {
                table.OpenTable("wb_contract", "select * from wb_contract where" + WBData.CompanyLocation(" and ((closed is null or closed <> 'X' or closed = 'N') and zAuto = 'N' or do_no = '" + fr.textDO.Text.Trim() + "')"), WBData.conn);
            }
            string[] aField = new string[] { "Do_No" };
            string[] aFind = new string[] { fr.textDO.Text.Trim() };
            DataRow data = table.GetData(aField, aFind);
            table2.OpenTable("wb_comm", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + data["Comm_Code"].ToString() + "'"), WBData.conn);
            string[] textArray3 = new string[] { "comm_code" };
            string[] textArray4 = new string[] { data["Comm_Code"].ToString() };
            DataRow row2 = table2.GetData(textArray3, textArray4);
            if (row2 != null)
            {
                str2 = row2["Unit"].ToString();
                str = row2["BulkPack"].ToString();
                num2 = float.Parse((row2["netto_weight"].ToString() == "") ? "0" : row2["netto_weight"].ToString());
            }
            if (from_do)
            {
                view = fr.retTable_DSAP_DO;
            }
            else if (from_dotrx)
            {
                view = fr.retTable_DSAP_DOTRX;
            }
            else if (from_dr)
            {
                view = fr.retTable_DSAP_DR;
            }
            foreach (DataGridViewRow row3 in (IEnumerable) view.Rows)
            {
                int dgvDOCurrRow = fr.dgvDOCurrRow;
                if (doEntryMode != "ADD")
                {
                    if (this.dgvDO.CurrentRow.Index > 0)
                    {
                        this.dgvDO.Rows[0].Cells["Estate_qty"].Value = (Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString()) - Convert.ToDouble(fr.textOthNet.Text)) + oldEstate;
                    }
                }
                else
                {
                    this.dgvDO.Rows.Add();
                    dgvDOCurrRow = this.dgvDO.Rows.Count - 1;
                    if ((this.dgvDO.Rows.Count > 0) && (dgvDOCurrRow > 0))
                    {
                        this.dgvDO.Rows[0].Cells["Estate_qty"].Value = Program.StrToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString(), 0) - Program.StrToDouble(fr.textOthNet.Text, 0);
                        this.dgvDO.Rows[0].Cells["DeliNo"].Value = this.txt_deli_note.Text;
                    }
                }
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Coy"].Value = this.cCoy;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Location_Code"].Value = this.cLoc;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["DeliNo"].Value = fr.txtDeliveryNote.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Ref"].Value = this.comboBoxRef.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["gatepass_number"].Value = this.txt_gp_no.Text;
                if (WBSetting.integrationIDSYS)
                {
                    if (from_do)
                    {
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["internal_number"].Value = row3.Cells["do_"].Value.ToString();
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["internal_number_item"].Value = row3.Cells["do_item"].Value.ToString();
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["do_sap"].Value = "";
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["do_sap_item"].Value = "";
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["do_qty"].Value = row3.Cells["qty_do"].Value.ToString();
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["do_uom"].Value = row3.Cells["do_uom"].Value.ToString();
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["do_base_qty"].Value = row3.Cells["qty_base"].Value.ToString();
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["do_base_uom"].Value = row3.Cells["base_uom"].Value.ToString();
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["do_qty_kg"].Value = row3.Cells["qty_kg"].Value.ToString();
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["do_besar"].Value = "";
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value = "";
                        if (this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value.ToString() == "")
                        {
                            this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value = fr.so_item;
                        }
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["license_number"].Value = "";
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["truck_number"].Value = "";
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["driver_name"].Value = "";
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["STO_No"].Value = "";
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["STO_Item"].Value = "";
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["customer_QQ"].Value = "";
                    }
                }
                else if (from_do)
                {
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["internal_number"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["internal_number_item"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_sap"].Value = row3.Cells["VBELN"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_sap_item"].Value = row3.Cells["POSNR"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_qty"].Value = row3.Cells["LFIMG"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_uom"].Value = row3.Cells["VRKME"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_base_qty"].Value = row3.Cells["LFIMG_BASE"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_base_uom"].Value = row3.Cells["BASE_UOM"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_qty_kg"].Value = row3.Cells["LFIMG_KG"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_besar"].Value = row3.Cells["ZZDO_INDICATOR"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value = row3.Cells["POSNR_VA"].Value.ToString();
                    if (this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value.ToString() == "")
                    {
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value = fr.so_item;
                    }
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["license_number"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["truck_number"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["driver_name"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["STO_No"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["STO_Item"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["customer_QQ"].Value = "";
                }
                else if (from_dr)
                {
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["internal_number"].Value = row3.Cells["ZDCONR"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["internal_number_item"].Value = row3.Cells["POSNR"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_sap"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_sap_item"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_qty"].Value = row3.Cells["DLFIMG"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_uom"].Value = row3.Cells["VRKME"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_base_qty"].Value = row3.Cells["DLFIMG_BASE"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_base_uom"].Value = row3.Cells["BASE_UOM"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_qty_kg"].Value = row3.Cells["DLFIMG_NET"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_besar"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value = row3.Cells["POSNR_VA"].Value.ToString();
                    if (this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value.ToString() == "")
                    {
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value = fr.so_item;
                    }
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["license_number"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["truck_number"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["driver_name"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["STO_No"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["STO_Item"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["customer_QQ"].Value = "";
                }
                else if (from_dotrx)
                {
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["internal_number"].Value = row3.Cells["ZDCONR"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["internal_number_item"].Value = row3.Cells["DOPLINE"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_sap"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_sap_item"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_qty"].Value = row3.Cells["PLN_LFIMG"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_uom"].Value = row3.Cells["Q_VRKME"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_base_qty"].Value = row3.Cells["QTYBUOM"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_base_uom"].Value = row3.Cells["BUOM"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_qty_kg"].Value = row3.Cells["QTYKG"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["do_besar"].Value = "";
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value = row3.Cells["POSNR"].Value.ToString();
                    if (this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value.ToString() == "")
                    {
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value = fr.so_item;
                    }
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["license_number"].Value = row3.Cells["WNOSIM"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["truck_number"].Value = row3.Cells["WNOPOLISI"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["driver_name"].Value = row3.Cells["WSUPIR"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["STO_No"].Value = row3.Cells["EBELN_REF"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["STO_Item"].Value = row3.Cells["EBELP"].Value.ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["customer_QQ"].Value = row3.Cells["SOKUN3RD"].Value.ToString();
                }
                if (!string.IsNullOrEmpty(this.dgvDO.Rows[dgvDOCurrRow].Cells["do_sap"].Value.ToString()) && ((str == "P") && (str2 != "KG")))
                {
                    float num3 = 0f;
                    num3 = float.Parse(this.dgvDO.Rows[dgvDOCurrRow].Cells["do_base_qty"].Value.ToString());
                    if ((data["so_item"].ToString() != "*") && (data["so_item"].ToString() != ""))
                    {
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["do_qty_kg"].Value = (num3 * num2).ToString();
                    }
                    else
                    {
                        WBTable table3 = new WBTable();
                        WBTable table4 = new WBTable();
                        string[] textArray5 = new string[] { " AND do_no = '", fr.textDO.Text.Trim(), "' and so_item = '", Program.StrToDouble(this.dgvDO.Rows[dgvDOCurrRow].Cells["so_item_detail"].Value.ToString(), 0).ToString(), "'" };
                        table3.OpenTable("wb_contract_sapinformation", "SELECT comm_code FROM wb_contract_sapinformation WHERE " + WBData.CompanyLocation(string.Concat(textArray5)), WBData.conn);
                        table4.OpenTable("wb_commodity", "SELECT netto_weight FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + table3.DT.Rows[0]["comm_code"].ToString() + "'"), WBData.conn);
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["do_qty_kg"].Value = (num3 * float.Parse((table4.DT.Rows[0]["netto_weight"].ToString() == "") ? "0" : table4.DT.Rows[0]["netto_weight"].ToString())).ToString();
                        table3.Dispose();
                        table4.Dispose();
                    }
                }
                this.dgvDO.Rows[dgvDOCurrRow].Cells["DO_No"].Value = fr.textDO.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Comm_Code"].Value = fr.textComm.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Contract"].Value = fr.textCont.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Relation_Code"].Value = fr.textRCode.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Relation_Name"].Value = fr.textRName.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Netto"].Value = Program.StrToDouble(fr.textFactNet.Text, 2);
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Estate_qty"].Value = Program.StrToDouble(fr.textOthNet.Text, 2);
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Estate"].Value = fr.textEstate.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["PI_No"].Value = fr.textPI_No.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Transporter_Code"].Value = fr.textTransporter.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Transaction_Code"].Value = data["Transaction_Code"].ToString();
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Storage_code"].Value = fr.textStorage.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Tolling"].Value = data["Tolling"].ToString();
                this.dgvDO.Rows[dgvDOCurrRow].Cells["OSDO"].Value = fr.labelQtyLeft.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Bruto"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["Bruto"].Value == null) ? 0 : this.dgvDO.Rows[dgvDOCurrRow].Cells["Bruto"].Value;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Tarra"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["Tarra"].Value == null) ? 0 : this.dgvDO.Rows[dgvDOCurrRow].Cells["Tarra"].Value;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["loading_qty"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["loading_qty"].Value == null) ? "0" : this.dgvDO.Rows[dgvDOCurrRow].Cells["loading_qty"].Value;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["loading_qty_opw"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["loading_qty_opw"].Value == null) ? "0" : this.dgvDO.Rows[dgvDOCurrRow].Cells["loading_qty_opw"].Value;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Return_Qty_KG"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["Return_Qty_KG"].Value == null) ? "0" : this.dgvDO.Rows[dgvDOCurrRow].Cells["Return_Qty_KG"].Value;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Return_Qty_Pack"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["Return_Qty_Pack"].Value == null) ? "0" : this.dgvDO.Rows[dgvDOCurrRow].Cells["Return_Qty_Pack"].Value;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["WeightPerUnitName"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["WeightPerUnitName"].Value == null) ? 0 : this.dgvDO.Rows[dgvDOCurrRow].Cells["WeightPerUnitName"].Value;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["DeducUnitQty"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["DeducUnitQty"].Value == null) ? 0 : this.dgvDO.Rows[dgvDOCurrRow].Cells["DeducUnitQty"].Value;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["TotalDeducUnit"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["TotalDeducUnit"].Value == null) ? 0 : this.dgvDO.Rows[dgvDOCurrRow].Cells["TotalDeducUnit"].Value;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Deduction"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["Deduction"].Value == null) ? 0 : this.dgvDO.Rows[dgvDOCurrRow].Cells["Deduction"].Value;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["UnitName"].Value = (this.dgvDO.Rows[dgvDOCurrRow].Cells["UnitName"].Value == null) ? "" : this.dgvDO.Rows[dgvDOCurrRow].Cells["UnitName"].Value;
                if (this.dgvDO.Rows[dgvDOCurrRow].Cells["STO_No"].Value.ToString() == "")
                {
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["STO_No"].Value = data["sto"].ToString();
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["STO_Item"].Value = data["sto_item"].ToString();
                }
                if (dgvDOCurrRow != 0)
                {
                    if (dgvDOCurrRow > 0)
                    {
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["Bruto"].Value = Convert.ToDouble(this.dgvDO.Rows[dgvDOCurrRow].Cells["Netto"].Value.ToString());
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["Tarra"].Value = "0";
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["Netto"].Value = fr.textFactNet.Text;
                        if (fr.active_lock_tdt || this.active_lock_TDT)
                        {
                            this.cBoxDataNotMatch.Visible = true;
                            this.dgvDO.Rows[dgvDOCurrRow].Cells["Transporter_Code"].Value = fr.transporter;
                            if (((this.txt_truck.Text != fr.truck_number) || ((this.txt_transporter_code.Text != fr.transporter) || (this.txt_driver_ic.Text != fr.license_number))) || (this.textDriverName.Text != fr.driver_name))
                            {
                                if (this.txt_truck.Text != fr.truck_number)
                                {
                                    MessageBox.Show("Data Truck Number is Different Between Each Loading Note");
                                }
                                else if (this.txt_transporter_code.Text != fr.transporter)
                                {
                                    MessageBox.Show("Data Transporter is Different Between Each Loading Note");
                                }
                                else if (this.txt_driver_ic.Text != fr.license_number)
                                {
                                    MessageBox.Show("Data Driver License is Different Between Each Loading Note");
                                }
                                else if (this.textDriverName.Text != fr.driver_name)
                                {
                                    MessageBox.Show("Data Driver Name is Different Between Each Loading Note");
                                }
                                this.cBoxDataNotMatch.Checked = true;
                                this.cBoxDataNotMatch.Enabled = false;
                            }
                        }
                    }
                }
                else
                {
                    if (fr.active_zdotrx)
                    {
                        this.active_zdotrx = true;
                    }
                    if (!fr.active_lock_tdt)
                    {
                        this.active_lock_TDT = false;
                        this.textDriverName.Enabled = true;
                        this.textDriverName.ReadOnly = false;
                        this.buttonDriver.Enabled = true;
                        this.txt_truck.Enabled = true;
                        this.buttonTruck.Enabled = true;
                        this.txt_transporter_code.Enabled = true;
                        this.buttonTransporter.Enabled = true;
                        this.cBoxDataNotMatch.Visible = false;
                        this.txt_driver_ic.Enabled = true;
                        this.txt_transporter_code.Text = fr.textTransporter.Text;
                    }
                    else
                    {
                        this.active_lock_TDT = true;
                        if (((doEntryMode == "ADD") || ((oldDO != fr.textDO.Text) || ((fr.truck_number != "") || (fr.driver_name != "")))) || (fr.license_number != ""))
                        {
                            this.txt_truck.Text = fr.truck_number;
                            this.txt_transporter_code.Text = fr.transporter;
                            this.dgvDO.Rows[dgvDOCurrRow].Cells["Transporter_Code"].Value = fr.transporter;
                            this.txt_driver_ic.Text = fr.license_number;
                            this.textDriverName.Text = fr.driver_name;
                        }
                        this.textDriverName.Enabled = false;
                        this.textDriverName.ReadOnly = true;
                        this.txt_truck.Enabled = false;
                        this.txt_transporter_code.Enabled = false;
                        this.txt_driver_ic.Enabled = false;
                        this.cBoxDataNotMatch.Visible = true;
                        string[] textArray6 = new string[] { "Transporter_Code" };
                        string[] textArray7 = new string[] { this.txt_transporter_code.Text };
                        DataRow row6 = this.t_transporter.GetData(textArray6, textArray7);
                        if (this.txt_transporter_code.Text != "")
                        {
                            if (row6 != null)
                            {
                                this.lbl_transporter_name.Text = row6["Transporter_Name"].ToString();
                            }
                            else
                            {
                                MessageBox.Show("Transporter has not been maintain in WB.NET");
                            }
                        }
                    }
                    if (this.textRemarkTicket.Text.Trim() == "")
                    {
                        this.textRemarkTicket.Text = fr.remark;
                    }
                    table2.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and  comm_code = '" + fr.textComm.Text.Trim() + "'"), WBData.conn);
                    string[] textArray8 = new string[] { "Comm_Code" };
                    string[] textArray9 = new string[] { fr.textComm.Text };
                    DataRow row4 = table2.GetData(textArray8, textArray9);
                    if (row4 != null)
                    {
                        this.CommType = row4["Type"].ToString();
                    }
                    string[] textArray10 = new string[] { "Transporter_Code" };
                    string[] textArray11 = new string[] { this.txt_transporter_code.Text };
                    DataRow row5 = this.t_transporter.GetData(textArray10, textArray11);
                    if (this.txt_transporter_code.Text != "")
                    {
                        this.lbl_transporter_name.Text = (row5 == null) ? "" : row5["Transporter_Name"].ToString();
                    }
                    this.CommType = fr.CommType;
                    this.tabPageShow(this.CommType, this.tabPageWBDO);
                    if (fr.changeComm || ((doEntryMode == "ADD") && (this.dgvDO.Rows.Count == 1)))
                    {
                        this._InitBlankQC(this.dgvDO.Rows[dgvDOCurrRow].Cells["DO_NO"].Value.ToString());
                    }
                    if (fr.changeComm)
                    {
                        this.oldComm = fr.textComm.Text.Trim();
                    }
                }
            }
        }

        private void FormRegisGatepassEntryId_Load(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.f_load();
            this.translate();
            Cursor.Current = Cursors.Default;
        }

        private void FormRegisGatepassEntryId_Shown(object sender, EventArgs e)
        {
            if (WBSetting.Field("ScanCardSPB").ToString() != "Y")
            {
                this.buttonESPB.Visible = false;
            }
            else
            {
                this.buttonESPB.Visible = true;
                this.nfcReader = new WBNFC();
            }
        }

        private string generate_gatepass_no()
        {
            bool flag = false;
            string str = "";
            int num = 0;
            string str2 = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_ref", "SELECT * FROM wb_ref WHERE  ref_code ='GATEPASS'", WBData.conn);
            if (table.DT.Rows.Count == 0)
            {
                string sqltext = "INSERT INTO [wb_ref]([Ref_Code],[Ref_No],[locked])\r\n                    VALUES('GATEPASS',0,'N') ";
                table.OpenTable("WB_COMPANY", sqltext, WBData.conn);
            }
            while (true)
            {
                table.OpenTable("wb_ref", "SELECT * FROM wb_ref WHERE  ref_code ='GATEPASS'", WBData.conn);
                table.DR = table.DT.Rows[0];
                if (table.DR["Locked"].ToString() != "Y")
                {
                    flag = false;
                }
                else if (table.DR["LockedBy"].ToString().ToUpper() == WBSetting.WBCode)
                {
                    flag = false;
                }
                else
                {
                    flag = true;
                    str = table.DR["LockedBy"].ToString().ToUpper();
                    if ((num + 1) == 20)
                    {
                        MessageBox.Show(Resource.RegisGatepassMess_013 + str, Resource.Title_002);
                        num = 0;
                    }
                }
                if (!flag)
                {
                    table.DR = table.DT.Rows[0];
                    table.DR.BeginEdit();
                    table.DR["locked"] = "Y";
                    table.DR["lockedBy"] = WBSetting.WBCode;
                    table.DR.EndEdit();
                    table.Save();
                    table.OpenTable("wb_ref", "UPDATE wb_ref SET ref_no = ref_no + 1 WHERE  ref_code ='GATEPASS'", WBData.conn);
                    table.OpenTable("wb_ref", "SELECT * FROM wb_ref WHERE  ref_code ='GATEPASS'", WBData.conn);
                    int result = 0;
                    int.TryParse(table.DT.Rows[0]["ref_no"].ToString(), out result);
                    str2 = this.gpCode + result.ToString().PadLeft(7, '0');
                    table.DR = table.DT.Rows[0];
                    table.DR.BeginEdit();
                    table.DR["locked"] = "N";
                    table.DR["lockedBy"] = "";
                    table.DR.EndEdit();
                    table.Save();
                    return str2;
                }
            }
        }

        private string get_latest_gatepassno()
        {
            string str = "";
            int result = 0;
            WBTable table = new WBTable();
            table.OpenTable("wb_ref", "SELECT ref_no + 1 as ref_no FROM wb_ref WHERE  ref_code ='GATEPASS'", WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                str = "1";
            }
            else
            {
                int.TryParse(table.DT.Rows[0]["ref_no"].ToString(), out result);
                str = this.gpCode + result.ToString().PadLeft(7, '0');
            }
            return str;
        }

        private bool GetRepDate()
        {
            bool flag = false;
            WBTable table = new WBTable();
            if (!string.IsNullOrEmpty(this.comboBoxRef.Text))
            {
                table.OpenTable("repDate", "select report_date from wb_transaction with (nolock) where ref = '" + this.comboBoxRef.Text + "'", WBData.conn);
                if ((table.DT.Rows.Count > 0) && !string.IsNullOrEmpty(table.DT.Rows[0]["report_date"].ToString()))
                {
                    flag = true;
                }
            }
            return flag;
        }

        private void groupPhoto_Enter(object sender, EventArgs e)
        {
        }

        private void grpTruckInfo_Enter(object sender, EventArgs e)
        {
        }

        private void HitNetEstate()
        {
            if (Program.CheckNumeric(this.textGrossEstate) && Program.CheckNumeric(this.textTareEstate))
            {
                double num = Math.Abs((double) (Convert.ToDouble(this.textGrossEstate.Text) - Convert.ToDouble(this.textTareEstate.Text)));
                this.textNetEstate.Text = $"{num:N0}";
                if (this.dgvDO.Rows.Count > 0)
                {
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 >= this.dgvDO.Rows.Count)
                        {
                            this.dgvDO.Rows[0].Cells["estate_qty"].Value = num;
                            break;
                        }
                        num -= Convert.ToDouble(this.dgvDO.Rows[num2].Cells["estate_qty"].Value);
                        num2++;
                    }
                }
            }
        }

        private void initDGContainer()
        {
            this.dgvCont.ColumnCount = this.tblTransContainer.DT.Columns.Count;
            int num = 0;
            while (true)
            {
                if (num >= this.tblTransContainer.DT.Columns.Count)
                {
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= this.dgvCont.Columns.Count)
                        {
                            this.dgvCont.Columns["Container"].Visible = true;
                            this.dgvCont.Columns["Seal"].Visible = true;
                            return;
                        }
                        this.dgvCont.Columns[num2].Visible = false;
                        num2++;
                    }
                }
                this.dgvCont.Columns[num].Name = this.tblTransContainer.DT.Columns[num].ColumnName;
                num++;
            }
        }

        private void initDGDivBlock()
        {
            this.dgvDivBlock.ColumnCount = this.tblTransDiv.DT.Columns.Count;
            int num = 0;
            while (true)
            {
                if (num >= this.tblTransDiv.DT.Columns.Count)
                {
                    this.dgvDivBlock.Columns["Coy"].Visible = false;
                    this.dgvDivBlock.Columns["Location_Code"].Visible = false;
                    this.dgvDivBlock.Columns["SAP_Code"].Visible = false;
                    this.dgvDivBlock.Columns["Uniq"].Visible = false;
                    this.dgvDivBlock.Columns["UnitName"].Visible = false;
                    this.dgvDivBlock.Columns["Ref"].Visible = false;
                    this.dgvDivBlock.Columns["Gatepass_Number"].Visible = false;
                    this.dgvDivBlock.Columns["Estate_Code"].HeaderText = "Estate Code";
                    this.dgvDivBlock.Columns["Estate_Name"].HeaderText = "Estate Name";
                    this.dgvDivBlock.Columns["Division_Code"].HeaderText = "Division Code";
                    this.dgvDivBlock.Columns["Division_Name"].HeaderText = "Division Name";
                    this.dgvDivBlock.Columns["Block_Code"].HeaderText = "Block Code";
                    this.dgvDivBlock.Columns["Block_Name"].HeaderText = "Block Name";
                    this.dgvDivBlock.Columns["UnitName"].HeaderText = "Unit Name";
                    this.dgvDivBlock.Columns["YearPlanting"].HeaderText = "Year of Planting";
                    this.dgvDivBlock.Columns["Bunch"].HeaderText = "Bunch";
                    this.dgvDivBlock.Columns["Bunch"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDivBlock.Columns["Weight"].HeaderText = "Weight (Kg)";
                    this.dgvDivBlock.Columns["Weight"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDivBlock = this.tblTransDiv.ToDGV(this.dgvDivBlock);
                    return;
                }
                this.dgvDivBlock.Columns[num].Name = this.tblTransDiv.DT.Columns[num].ColumnName;
                num++;
            }
        }

        private void initDGDO()
        {
            this.dgvDO.ColumnCount = this.tblTransDO.DT.Columns.Count + 4;
            this.dgvDO.ColumnCount++;
            int num = 0;
            while (true)
            {
                if (num >= this.tblTransDO.DT.Columns.Count)
                {
                    this.dgvDO.Columns[num].Name = "DeliNo";
                    this.dgvDO.Columns[num + 1].Name = "OSDO";
                    this.dgvDO.Columns[num + 2].Name = "Truck_Number";
                    this.dgvDO.Columns[num + 3].Name = "License_Number";
                    this.dgvDO.Columns[num + 4].Name = "Driver_Name";
                    foreach (DataGridViewColumn column in this.dgvDO.Columns)
                    {
                        column.Visible = false;
                    }
                    this.dgvDO.Columns["Do_No"].Visible = true;
                    this.dgvDO.Columns["Contract"].Visible = true;
                    this.dgvDO.Columns["Comm_Code"].Visible = true;
                    this.dgvDO.Columns["Transaction_Code"].Visible = true;
                    this.dgvDO.Columns["Transporter_Code"].Visible = true;
                    this.dgvDO.Columns["Relation_Code"].Visible = true;
                    this.dgvDO.Columns["Relation_Name"].Visible = true;
                    this.dgvDO.Columns["Netto"].Visible = true;
                    this.dgvDO.Columns["Estate_qty"].Visible = true;
                    this.dgvDO.Columns["Bruto"].Visible = true;
                    this.dgvDO.Columns["Tarra"].Visible = true;
                    if (WBSetting.locType == "1")
                    {
                        this.dgvDO.Columns["DeliNo"].Visible = true;
                    }
                    this.dgvDO.Columns["PI_No"].Visible = true;
                    this.dgvDO.Columns["OSDO"].Visible = true;
                    this.dgvDO.Columns["do_sap"].Visible = true;
                    this.dgvDO.Columns["do_sap_item"].Visible = true;
                    this.dgvDO.Columns["internal_number"].Visible = true;
                    this.dgvDO.Columns["internal_number_item"].Visible = true;
                    this.dgvDO.Columns["loading_qty"].Visible = true;
                    this.dgvDO.Columns["so_item_detail"].Visible = true;
                    this.dgvDO.Columns["so_item_detail"].HeaderText = "SO Item";
                    this.dgvDO.Columns["Relation_Name"].Width = 300;
                    this.dgvDO.Columns["Netto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["Netto"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["Estate_qty"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["Estate_qty"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["Bruto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["Bruto"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["Tarra"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["Tarra"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["ConvNett"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["ConvNett"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["DeliNo"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["DeliNo"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["Contract"].DisplayIndex = this.dgvDO.Columns["Contract"].Index + 2;
                    this.dgvDO.Columns["OSDO"].DisplayIndex = this.dgvDO.Columns["Do_No"].Index + 2;
                    this.dgvDO.Columns["OSDO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["OSDO"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["truck_number"].Visible = false;
                    this.dgvDO.Columns["license_number"].Visible = false;
                    this.dgvDO.Columns["driver_name"].Visible = false;
                    this.dgvDO.Columns["STO_No"].Visible = true;
                    this.dgvDO.Columns["STO_Item"].Visible = true;
                    this.dgvDO.Columns["customer_qq"].Visible = true;
                    return;
                }
                this.dgvDO.Columns[num].Name = this.tblTransDO.DT.Columns[num].ColumnName;
                num++;
            }
        }

        private void initDGDOContainer()
        {
            this.dgvDOCont.ColumnCount = this.tblTransDOContainer.DT.Columns.Count;
            int num = 0;
            while (true)
            {
                if (num >= this.tblTransDOContainer.DT.Columns.Count)
                {
                    this.dgvDOCont.AllowUserToAddRows = false;
                    return;
                }
                this.dgvDOCont.Columns[num].Name = this.tblTransDOContainer.DT.Columns[num].ColumnName;
                num++;
            }
        }

        private void initDGGPDest()
        {
            this.dgvGPDest.ColumnCount = this.t_gatepass_dest.DT.Columns.Count + 1;
            int num = 0;
            while (true)
            {
                if (num >= this.t_gatepass_dest.DT.Columns.Count)
                {
                    this.dgvGPDest.Columns[this.dgvGPDest.ColumnCount - 1].Name = "description";
                    this.dgvGPDest.Columns[this.dgvGPDest.ColumnCount - 1].HeaderText = "Destination";
                    this.dgvGPDest.Columns[this.dgvGPDest.ColumnCount - 1].Visible = true;
                    this.dgvGPDest.Columns["source_code"].Visible = true;
                    this.dgvGPDest.Columns["source_code"].HeaderText = "Code";
                    return;
                }
                this.dgvGPDest.Columns[num].Name = this.t_gatepass_dest.DT.Columns[num].ColumnName;
                this.dgvGPDest.Columns[num].Visible = false;
                num++;
            }
        }

        private void initDGQC()
        {
            this.dgvQC.ColumnCount = this.tblTransQC.DT.Columns.Count;
            int num = 0;
            while (true)
            {
                if (num >= this.tblTransQC.DT.Columns.Count)
                {
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= this.dgvQC.Columns.Count)
                        {
                            this.dgvQC.Columns["QCode"].Visible = true;
                            this.dgvQC.Columns["QCode"].ReadOnly = true;
                            this.dgvQC.Columns["QCode"].DefaultCellStyle.BackColor = Color.LightGray;
                            this.dgvQC.Columns["QCode"].DisplayIndex = 0;
                            this.dgvQC.Columns["QName"].Visible = true;
                            this.dgvQC.Columns["QName"].ReadOnly = true;
                            this.dgvQC.Columns["QName"].DefaultCellStyle.BackColor = Color.LightGray;
                            this.dgvQC.Columns["QName"].DisplayIndex = 1;
                            this.dgvQC.Columns["SAP_Value"].Visible = true;
                            this.dgvQC.Columns["SAP_Value"].ReadOnly = true;
                            this.dgvQC.Columns["SAP_Value"].DefaultCellStyle.BackColor = Color.LightGray;
                            this.dgvQC.Columns["SAP_Value"].DisplayIndex = 2;
                            this.dgvQC.Columns["Estate"].Visible = true;
                            this.dgvQC.Columns["Estate"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            this.dgvQC.Columns["Estate"].ReadOnly = !WBUser.CheckTrustee("TRANS_QC", "E");
                            this.dgvQC.Columns["Estate"].DefaultCellStyle.Format = "N3";
                            this.dgvQC.Columns["Estate"].DisplayIndex = 3;
                            if (this.dgvQC.Columns["Estate"].ReadOnly)
                            {
                                this.dgvQC.Columns["Estate"].DefaultCellStyle.BackColor = Color.LightGray;
                            }
                            this.dgvQC.Columns["Factory"].Visible = true;
                            this.dgvQC.Columns["Factory"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            this.dgvQC.Columns["Factory"].ReadOnly = !WBUser.CheckTrustee("TRANS_QC", "A");
                            this.dgvQC.Columns["Factory"].DefaultCellStyle.Format = "N3";
                            this.dgvQC.Columns["Factory"].DisplayIndex = 4;
                            if (this.dgvQC.Columns["Factory"].ReadOnly)
                            {
                                this.dgvQC.Columns["Factory"].DefaultCellStyle.BackColor = Color.LightGray;
                            }
                            this.dgvQC.Columns["deduct"].Visible = true;
                            this.dgvQC.Columns["deduct"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                            this.dgvQC.Columns["deduct"].ReadOnly = true;
                            this.dgvQC.Columns["deduct"].DefaultCellStyle.BackColor = Color.LightGray;
                            this.dgvQC.Columns["deduct"].DisplayIndex = 5;
                            return;
                        }
                        this.dgvQC.Columns[num2].Visible = false;
                        num2++;
                    }
                }
                this.dgvQC.Columns[num].Name = this.tblTransQC.DT.Columns[num].ColumnName;
                num++;
            }
        }

        private void InitializeComponent()
        {
            ComponentResourceManager manager = new ComponentResourceManager(typeof(FormRegisGatepassEntryId));
            this.labelTruckNo = new Label();
            this.txt_truck = new TextBox();
            this.buttonTruck = new Button();
            this.txt_transporter_code = new TextBox();
            this.buttonTransporter = new Button();
            this.labelTransporter = new Label();
            this.grpTruckInfo = new GroupBox();
            this.cBoxDataNotMatch = new CheckBox();
            this.buttonDestination = new Button();
            this.textDestination = new TextBox();
            this.textDriverName = new TextBox();
            this.labelScanMessage = new Label();
            this.buttonESPB = new Button();
            this.checkLastWeighing = new CheckBox();
            this.Garis1 = new Label();
            this.buttonDeleteDest = new Button();
            this.buttonAddDest = new Button();
            this.dgvGPDest = new DataGridView();
            this.labelPassengersNames = new Label();
            this.labelPassengers = new Label();
            this.comboWX = new ComboBox();
            this.txtPassengersNames = new TextBox();
            this.txtPassengers = new TextBox();
            this.labelWX = new Label();
            this.textCardNo = new TextBox();
            this.labelCardNo = new Label();
            this.label22 = new Label();
            this.labelTankerNo = new Label();
            this.textTrailerNo = new TextBox();
            this.buttonTanker = new Button();
            this.textTanker = new TextBox();
            this.labelDestinationCode = new Label();
            this.lbl_transporter_name = new Label();
            this.txt_driver_ic = new TextBox();
            this.labelLicenseNo = new Label();
            this.labelDestination = new Label();
            this.buttonDriver = new Button();
            this.txt_gp_no = new TextBox();
            this.lbl_gp_no = new Label();
            this.groupPhoto = new GroupBox();
            this.tabControlPhoto = new TabControl();
            this.tabPageDriverLicenseID = new TabPage();
            this._driverLicense_img = new PictureBox();
            this.tabPage1st = new TabPage();
            this._1st_cam4 = new PictureBox();
            this._1st_cam3 = new PictureBox();
            this._1st_cam2 = new PictureBox();
            this._1st_cam5 = new PictureBox();
            this._1st_cam1 = new PictureBox();
            this.tabPage2nd = new TabPage();
            this._2nd_cam4 = new PictureBox();
            this._2nd_cam3 = new PictureBox();
            this._2nd_cam2 = new PictureBox();
            this._2nd_cam5 = new PictureBox();
            this._2nd_cam1 = new PictureBox();
            this.tabPage3rd = new TabPage();
            this._3rd_cam4 = new PictureBox();
            this._3rd_cam3 = new PictureBox();
            this._3rd_cam2 = new PictureBox();
            this._3rd_cam5 = new PictureBox();
            this._3rd_cam1 = new PictureBox();
            this.tabPage4th = new TabPage();
            this._4th_cam4 = new PictureBox();
            this._4th_cam3 = new PictureBox();
            this._4th_cam2 = new PictureBox();
            this._4th_cam5 = new PictureBox();
            this._4th_cam1 = new PictureBox();
            this.lbl_reg_date = new Label();
            this.dtRegistration = new DateTimePicker();
            this.txtRegistrationTime = new MaskedTextBox();
            this.tabPageOP = new TabPage();
            this.groupOPW = new GroupBox();
            this.labelWBNo = new Label();
            this.btnCheck_OP = new Button();
            this.textWBNo = new TextBox();
            this.textNetEstate = new TextBox();
            this.labelOPDate = new Label();
            this.textTareEstate = new TextBox();
            this.dateDelivery = new DateTimePicker();
            this.textGrossEstate = new TextBox();
            this.labelOPNet = new Label();
            this.TimeDelivery = new MaskedTextBox();
            this.labelOPTare = new Label();
            this.labelOPGross = new Label();
            this.checkNOPW = new CheckBox();
            this.tabPageGeneral = new TabPage();
            this.buttonDN = new Button();
            this.textPL3 = new TextBox();
            this.labelPL3 = new Label();
            this.checkEstate = new CheckBox();
            this.labelAdditionalInfo = new Label();
            this.txtAddInfo = new TextBox();
            this.textRemarkReport = new TextBox();
            this.txt_deli_note = new TextBox();
            this.panel_return = new Panel();
            this.btn_check = new Button();
            this.text_ref_return = new TextBox();
            this.txt_seal = new TextBox();
            this.textRemarkTicket = new TextBox();
            this.labelDeliveryNote = new Label();
            this.labelRemarkReport = new Label();
            this.labelSealNo = new Label();
            this.chk_return = new CheckBox();
            this.labelRemarkTicket = new Label();
            this.dgvDO = new DataGridView();
            this.buttonViewDO = new Button();
            this.buttonAddDO = new Button();
            this.buttonDeleteDO = new Button();
            this.buttonEditDO = new Button();
            this.tabControlInformation = new TabControl();
            this.tabPageCont = new TabPage();
            this.checkNeedContainerCheck = new CheckBox();
            this.buttonContDelete = new Button();
            this.dgvCont = new DataGridView();
            this.buttonContEdit = new Button();
            this.buttonContAdd = new Button();
            this.tabPageWBDO = new TabPage();
            this.tableLayoutPanel1 = new TableLayoutPanel();
            this.label1 = new Label();
            this.lblTotalDOQtyInKG = new Label();
            this.lblTotalItem = new Label();
            this.label34 = new Label();
            this.label59 = new Label();
            this.label61 = new Label();
            this.lblTotalAllocatedFactNet = new Label();
            this.label63 = new Label();
            this.buttonDeleteAllDO = new Button();
            this.tabPageDeduction = new TabPage();
            this.buttonEntryDeduc = new Button();
            this.tabPageQC = new TabPage();
            this.dgvQC = new DataGridView();
            this.tabPageFFB = new TabPage();
            this.groupFFBReject = new GroupBox();
            this.labelKg = new Label();
            this.textRejectedFFBKG = new TextBox();
            this.textRejectedFFBBunch = new TextBox();
            this.labelRejectedFFBReason = new Label();
            this.labelBunch = new Label();
            this.textRejectedFFBReason = new TextBox();
            this.labelRejectedFFB = new Label();
            this.groupRV = new GroupBox();
            this.labelOER = new Label();
            this.textRendCPO = new TextBox();
            this.groupBunch = new GroupBox();
            this.textBunchTotal = new TextBox();
            this.radioButtonEntryAVG = new RadioButton();
            this.textBunchDeduc = new TextBox();
            this.labelTotalBunch = new Label();
            this.radioButtonEntryTotalBunch = new RadioButton();
            this.labelTotalBunchDeduc = new Label();
            this.textAvg = new TextBox();
            this.labelAverageBunch = new Label();
            this.tabPageDivision = new TabPage();
            this.buttonDeleteDivision = new Button();
            this.buttonEditDivision = new Button();
            this.buttonAddDivision = new Button();
            this.dgvDivBlock = new DataGridView();
            this.comboBoxRef = new ComboBox();
            this.labelRef = new Label();
            this.labelArrow = new Label();
            this.btn_print = new Button();
            this.btn_cancel = new Button();
            this.btn_save = new Button();
            this.labelSplitTrans = new Label();
            this.comboBoxRefTemp = new ComboBox();
            this.shapeContainer2 = new ShapeContainer();
            this.grpTruckInfo.SuspendLayout();
            ((ISupportInitialize) this.dgvGPDest).BeginInit();
            this.groupPhoto.SuspendLayout();
            this.tabControlPhoto.SuspendLayout();
            this.tabPageDriverLicenseID.SuspendLayout();
            ((ISupportInitialize) this._driverLicense_img).BeginInit();
            this.tabPage1st.SuspendLayout();
            ((ISupportInitialize) this._1st_cam4).BeginInit();
            ((ISupportInitialize) this._1st_cam3).BeginInit();
            ((ISupportInitialize) this._1st_cam2).BeginInit();
            ((ISupportInitialize) this._1st_cam5).BeginInit();
            ((ISupportInitialize) this._1st_cam1).BeginInit();
            this.tabPage2nd.SuspendLayout();
            ((ISupportInitialize) this._2nd_cam4).BeginInit();
            ((ISupportInitialize) this._2nd_cam3).BeginInit();
            ((ISupportInitialize) this._2nd_cam2).BeginInit();
            ((ISupportInitialize) this._2nd_cam5).BeginInit();
            ((ISupportInitialize) this._2nd_cam1).BeginInit();
            this.tabPage3rd.SuspendLayout();
            ((ISupportInitialize) this._3rd_cam4).BeginInit();
            ((ISupportInitialize) this._3rd_cam3).BeginInit();
            ((ISupportInitialize) this._3rd_cam2).BeginInit();
            ((ISupportInitialize) this._3rd_cam5).BeginInit();
            ((ISupportInitialize) this._3rd_cam1).BeginInit();
            this.tabPage4th.SuspendLayout();
            ((ISupportInitialize) this._4th_cam4).BeginInit();
            ((ISupportInitialize) this._4th_cam3).BeginInit();
            ((ISupportInitialize) this._4th_cam2).BeginInit();
            ((ISupportInitialize) this._4th_cam5).BeginInit();
            ((ISupportInitialize) this._4th_cam1).BeginInit();
            this.tabPageOP.SuspendLayout();
            this.groupOPW.SuspendLayout();
            this.tabPageGeneral.SuspendLayout();
            this.panel_return.SuspendLayout();
            ((ISupportInitialize) this.dgvDO).BeginInit();
            this.tabControlInformation.SuspendLayout();
            this.tabPageCont.SuspendLayout();
            ((ISupportInitialize) this.dgvCont).BeginInit();
            this.tabPageWBDO.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabPageDeduction.SuspendLayout();
            this.tabPageQC.SuspendLayout();
            ((ISupportInitialize) this.dgvQC).BeginInit();
            this.tabPageFFB.SuspendLayout();
            this.groupFFBReject.SuspendLayout();
            this.groupRV.SuspendLayout();
            this.groupBunch.SuspendLayout();
            this.tabPageDivision.SuspendLayout();
            ((ISupportInitialize) this.dgvDivBlock).BeginInit();
            base.SuspendLayout();
            this.labelTruckNo.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelTruckNo.Location = new Point(5, 110);
            this.labelTruckNo.Name = "labelTruckNo";
            this.labelTruckNo.Size = new Size(130, 0x13);
            this.labelTruckNo.TabIndex = 1;
            this.labelTruckNo.Text = "Truck / Trailer No.";
            this.labelTruckNo.TextAlign = ContentAlignment.MiddleRight;
            this.txt_truck.CharacterCasing = CharacterCasing.Upper;
            this.txt_truck.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txt_truck.Location = new Point(0x8a, 110);
            this.txt_truck.MaxLength = 50;
            this.txt_truck.Name = "txt_truck";
            this.txt_truck.Size = new Size(0x88, 20);
            this.txt_truck.TabIndex = 3;
            this.txt_truck.TextChanged += new EventHandler(this.txt_truck_TextChanged);
            this.txt_truck.KeyPress += new KeyPressEventHandler(this.txt_truck_KeyPress);
            this.txt_truck.Leave += new EventHandler(this.txt_truck_Leave);
            this.buttonTruck.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonTruck.Location = new Point(0x115, 0x6c);
            this.buttonTruck.Margin = new Padding(0);
            this.buttonTruck.Name = "buttonTruck";
            this.buttonTruck.Size = new Size(0x17, 0x17);
            this.buttonTruck.TabIndex = 4;
            this.buttonTruck.Text = "...";
            this.buttonTruck.UseVisualStyleBackColor = true;
            this.buttonTruck.Click += new EventHandler(this.buttonTruck_Click);
            this.txt_transporter_code.CharacterCasing = CharacterCasing.Upper;
            this.txt_transporter_code.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txt_transporter_code.Location = new Point(0x8a, 0x87);
            this.txt_transporter_code.MaxLength = 50;
            this.txt_transporter_code.Name = "txt_transporter_code";
            this.txt_transporter_code.Size = new Size(0x88, 20);
            this.txt_transporter_code.TabIndex = 5;
            this.txt_transporter_code.TextChanged += new EventHandler(this.txt_transporter_code_TextChanged);
            this.txt_transporter_code.KeyPress += new KeyPressEventHandler(this.txt_transporter_code_KeyPress);
            this.txt_transporter_code.Leave += new EventHandler(this.txt_transporter_code_Leave);
            this.buttonTransporter.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonTransporter.Location = new Point(0x115, 0x85);
            this.buttonTransporter.Margin = new Padding(0);
            this.buttonTransporter.Name = "buttonTransporter";
            this.buttonTransporter.Size = new Size(0x17, 0x17);
            this.buttonTransporter.TabIndex = 6;
            this.buttonTransporter.Text = "...";
            this.buttonTransporter.UseVisualStyleBackColor = true;
            this.buttonTransporter.Click += new EventHandler(this.buttonTransporter_Click);
            this.labelTransporter.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelTransporter.Location = new Point(5, 0x87);
            this.labelTransporter.Name = "labelTransporter";
            this.labelTransporter.Size = new Size(130, 0x13);
            this.labelTransporter.TabIndex = 13;
            this.labelTransporter.Text = "Transporter";
            this.labelTransporter.TextAlign = ContentAlignment.MiddleRight;
            this.grpTruckInfo.Controls.Add(this.cBoxDataNotMatch);
            this.grpTruckInfo.Controls.Add(this.buttonDestination);
            this.grpTruckInfo.Controls.Add(this.textDestination);
            this.grpTruckInfo.Controls.Add(this.textDriverName);
            this.grpTruckInfo.Controls.Add(this.labelScanMessage);
            this.grpTruckInfo.Controls.Add(this.buttonESPB);
            this.grpTruckInfo.Controls.Add(this.checkLastWeighing);
            this.grpTruckInfo.Controls.Add(this.Garis1);
            this.grpTruckInfo.Controls.Add(this.buttonDeleteDest);
            this.grpTruckInfo.Controls.Add(this.buttonAddDest);
            this.grpTruckInfo.Controls.Add(this.dgvGPDest);
            this.grpTruckInfo.Controls.Add(this.labelPassengersNames);
            this.grpTruckInfo.Controls.Add(this.labelPassengers);
            this.grpTruckInfo.Controls.Add(this.comboWX);
            this.grpTruckInfo.Controls.Add(this.txtPassengersNames);
            this.grpTruckInfo.Controls.Add(this.txtPassengers);
            this.grpTruckInfo.Controls.Add(this.labelWX);
            this.grpTruckInfo.Controls.Add(this.textCardNo);
            this.grpTruckInfo.Controls.Add(this.labelCardNo);
            this.grpTruckInfo.Controls.Add(this.label22);
            this.grpTruckInfo.Controls.Add(this.labelTankerNo);
            this.grpTruckInfo.Controls.Add(this.textTrailerNo);
            this.grpTruckInfo.Controls.Add(this.buttonTanker);
            this.grpTruckInfo.Controls.Add(this.textTanker);
            this.grpTruckInfo.Controls.Add(this.labelDestinationCode);
            this.grpTruckInfo.Controls.Add(this.lbl_transporter_name);
            this.grpTruckInfo.Controls.Add(this.txt_driver_ic);
            this.grpTruckInfo.Controls.Add(this.labelLicenseNo);
            this.grpTruckInfo.Controls.Add(this.labelDestination);
            this.grpTruckInfo.Controls.Add(this.txt_truck);
            this.grpTruckInfo.Controls.Add(this.labelTransporter);
            this.grpTruckInfo.Controls.Add(this.buttonDriver);
            this.grpTruckInfo.Controls.Add(this.labelTruckNo);
            this.grpTruckInfo.Controls.Add(this.buttonTruck);
            this.grpTruckInfo.Controls.Add(this.txt_transporter_code);
            this.grpTruckInfo.Controls.Add(this.buttonTransporter);
            this.grpTruckInfo.Location = new Point(12, 0x37);
            this.grpTruckInfo.Name = "grpTruckInfo";
            this.grpTruckInfo.Size = new Size(490, 0x249);
            this.grpTruckInfo.TabIndex = 0;
            this.grpTruckInfo.TabStop = false;
            this.grpTruckInfo.Text = "[ Truck Information ]";
            this.grpTruckInfo.Enter += new EventHandler(this.grpTruckInfo_Enter);
            this.cBoxDataNotMatch.AutoSize = true;
            this.cBoxDataNotMatch.Location = new Point(0x103, 0xd3);
            this.cBoxDataNotMatch.Name = "cBoxDataNotMatch";
            this.cBoxDataNotMatch.Size = new Size(0xad, 0x11);
            this.cBoxDataNotMatch.TabIndex = 0x6c;
            this.cBoxDataNotMatch.Text = "Data Transportation Not Match";
            this.cBoxDataNotMatch.UseVisualStyleBackColor = true;
            this.cBoxDataNotMatch.Visible = false;
            this.buttonDestination.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonDestination.Location = new Point(0x19d, 0x14b);
            this.buttonDestination.Margin = new Padding(0);
            this.buttonDestination.Name = "buttonDestination";
            this.buttonDestination.Size = new Size(0x19, 0x19);
            this.buttonDestination.TabIndex = 0x6d;
            this.buttonDestination.Text = "...";
            this.buttonDestination.UseVisualStyleBackColor = true;
            this.buttonDestination.Click += new EventHandler(this.buttonDestination_Click);
            this.textDestination.CharacterCasing = CharacterCasing.Upper;
            this.textDestination.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textDestination.Location = new Point(0x8a, 0x14c);
            this.textDestination.MaxLength = 50;
            this.textDestination.Name = "textDestination";
            this.textDestination.Size = new Size(0x110, 0x17);
            this.textDestination.TabIndex = 0x6c;
            this.textDestination.Leave += new EventHandler(this.textDestination_Leave_1);
            this.textDriverName.CharacterCasing = CharacterCasing.Upper;
            this.textDriverName.Location = new Point(0x135, 160);
            this.textDriverName.MaxLength = 50;
            this.textDriverName.Name = "textDriverName";
            this.textDriverName.Size = new Size(0x97, 20);
            this.textDriverName.TabIndex = 0x6c;
            this.textDriverName.TextChanged += new EventHandler(this.textDriverName_TextChanged);
            this.textDriverName.KeyPress += new KeyPressEventHandler(this.textDriverName_KeyPress);
            this.textDriverName.Leave += new EventHandler(this.textDriverName_Leave);
            this.labelScanMessage.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelScanMessage.ImageAlign = ContentAlignment.TopLeft;
            this.labelScanMessage.Location = new Point(0x88, 0x30);
            this.labelScanMessage.Name = "labelScanMessage";
            this.labelScanMessage.Size = new Size(0xfc, 0x1f);
            this.labelScanMessage.TabIndex = 0x6a;
            this.labelScanMessage.Text = "Remark for ticket";
            this.buttonESPB.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonESPB.Location = new Point(0x18a, 11);
            this.buttonESPB.Name = "buttonESPB";
            this.buttonESPB.Size = new Size(90, 0x2b);
            this.buttonESPB.TabIndex = 0x6b;
            this.buttonESPB.Text = "Scan E-SPB Card";
            this.buttonESPB.UseVisualStyleBackColor = true;
            this.buttonESPB.Click += new EventHandler(this.buttonESPB_Click);
            this.checkLastWeighing.AutoSize = true;
            this.checkLastWeighing.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.checkLastWeighing.Location = new Point(0x8a, 0x121);
            this.checkLastWeighing.Name = "checkLastWeighing";
            this.checkLastWeighing.Size = new Size(0xc5, 0x13);
            this.checkLastWeighing.TabIndex = 0x6a;
            this.checkLastWeighing.Text = "Require check on last weighing";
            this.checkLastWeighing.UseVisualStyleBackColor = true;
            this.Garis1.BorderStyle = BorderStyle.Fixed3D;
            this.Garis1.Location = new Point(6, 0x13b);
            this.Garis1.Margin = new Padding(1, 0, 1, 0);
            this.Garis1.Name = "Garis1";
            this.Garis1.Size = new Size(480, 2);
            this.Garis1.TabIndex = 0x31;
            this.buttonDeleteDest.Image = Resources.cancel_24px;
            this.buttonDeleteDest.Location = new Point(0x19e, 0x173);
            this.buttonDeleteDest.Name = "buttonDeleteDest";
            this.buttonDeleteDest.Size = new Size(0x2e, 0x24);
            this.buttonDeleteDest.TabIndex = 15;
            this.buttonDeleteDest.UseVisualStyleBackColor = true;
            this.buttonDeleteDest.Click += new EventHandler(this.buttonDeleteDest_Click);
            this.buttonAddDest.Image = Resources.add_24px;
            this.buttonAddDest.Location = new Point(0x16c, 0x173);
            this.buttonAddDest.Name = "buttonAddDest";
            this.buttonAddDest.Size = new Size(0x2e, 0x24);
            this.buttonAddDest.TabIndex = 14;
            this.buttonAddDest.UseVisualStyleBackColor = true;
            this.buttonAddDest.Click += new EventHandler(this.buttonAddDest_Click);
            this.dgvGPDest.AllowUserToAddRows = false;
            this.dgvGPDest.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvGPDest.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGPDest.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvGPDest.Location = new Point(0x1f, 0x19e);
            this.dgvGPDest.Name = "dgvGPDest";
            this.dgvGPDest.ReadOnly = true;
            this.dgvGPDest.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvGPDest.Size = new Size(0x1ad, 150);
            this.dgvGPDest.TabIndex = 0x2e;
            this.dgvGPDest.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dgvGPDest_CellFormatting);
            this.labelPassengersNames.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelPassengersNames.Location = new Point(5, 0xeb);
            this.labelPassengersNames.Name = "labelPassengersNames";
            this.labelPassengersNames.Size = new Size(130, 0x13);
            this.labelPassengersNames.TabIndex = 0x2d;
            this.labelPassengersNames.Text = "Passenger's Name";
            this.labelPassengersNames.TextAlign = ContentAlignment.MiddleRight;
            this.labelPassengers.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelPassengers.Location = new Point(5, 210);
            this.labelPassengers.Name = "labelPassengers";
            this.labelPassengers.Size = new Size(130, 0x13);
            this.labelPassengers.TabIndex = 0x2c;
            this.labelPassengers.Text = "Passengers";
            this.labelPassengers.TextAlign = ContentAlignment.MiddleRight;
            this.comboWX.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboWX.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.comboWX.FormattingEnabled = true;
            this.comboWX.Location = new Point(0x8a, 0x52);
            this.comboWX.Name = "comboWX";
            this.comboWX.Size = new Size(0x111, 0x17);
            this.comboWX.TabIndex = 2;
            this.comboWX.SelectedIndexChanged += new EventHandler(this.comboWX_SelectedIndexChanged);
            this.txtPassengersNames.CharacterCasing = CharacterCasing.Upper;
            this.txtPassengersNames.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtPassengersNames.Location = new Point(0x8a, 0xeb);
            this.txtPassengersNames.Multiline = true;
            this.txtPassengersNames.Name = "txtPassengersNames";
            this.txtPassengersNames.Size = new Size(0x130, 0x2e);
            this.txtPassengersNames.TabIndex = 11;
            this.txtPassengersNames.KeyPress += new KeyPressEventHandler(this.txtPassengersNames_KeyPress);
            this.txtPassengers.CharacterCasing = CharacterCasing.Upper;
            this.txtPassengers.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtPassengers.Location = new Point(0x8a, 210);
            this.txtPassengers.Name = "txtPassengers";
            this.txtPassengers.Size = new Size(0x3a, 20);
            this.txtPassengers.TabIndex = 12;
            this.txtPassengers.Text = "0";
            this.txtPassengers.TextAlign = HorizontalAlignment.Right;
            this.txtPassengers.KeyPress += new KeyPressEventHandler(this.txtPassengers_KeyPress);
            this.txtPassengers.Leave += new EventHandler(this.txtPassengers_Leave);
            this.labelWX.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelWX.Location = new Point(5, 0x54);
            this.labelWX.Name = "labelWX";
            this.labelWX.Size = new Size(130, 0x13);
            this.labelWX.TabIndex = 40;
            this.labelWX.Text = "Weighing Type";
            this.labelWX.TextAlign = ContentAlignment.MiddleRight;
            this.textCardNo.CharacterCasing = CharacterCasing.Upper;
            this.textCardNo.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textCardNo.Location = new Point(0x8a, 0x15);
            this.textCardNo.MaxLength = 50;
            this.textCardNo.Name = "textCardNo";
            this.textCardNo.Size = new Size(0xf3, 0x1a);
            this.textCardNo.TabIndex = 0;
            this.textCardNo.TextChanged += new EventHandler(this.textCardNo_TextChanged);
            this.textCardNo.Enter += new EventHandler(this.textCardNo_Enter);
            this.textCardNo.KeyDown += new KeyEventHandler(this.textCardNo_KeyDown);
            this.textCardNo.KeyPress += new KeyPressEventHandler(this.textCardNo_KeyPress);
            this.textCardNo.Leave += new EventHandler(this.textCardNo_Leave);
            this.textCardNo.MouseEnter += new EventHandler(this.textCardNo_MouseEnter);
            this.labelCardNo.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelCardNo.Location = new Point(14, 0x16);
            this.labelCardNo.Name = "labelCardNo";
            this.labelCardNo.Size = new Size(0x79, 0x16);
            this.labelCardNo.TabIndex = 0x17;
            this.labelCardNo.Text = "Card No";
            this.labelCardNo.TextAlign = ContentAlignment.MiddleRight;
            this.label22.AutoSize = true;
            this.label22.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label22.Location = new Point(0x135, 0x71);
            this.label22.Name = "label22";
            this.label22.Size = new Size(10, 15);
            this.label22.TabIndex = 0x27;
            this.label22.Text = "/";
            this.label22.TextAlign = ContentAlignment.TopRight;
            this.label22.Visible = false;
            this.labelTankerNo.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelTankerNo.Location = new Point(5, 0xb9);
            this.labelTankerNo.Name = "labelTankerNo";
            this.labelTankerNo.Size = new Size(130, 0x13);
            this.labelTankerNo.TabIndex = 0x22;
            this.labelTankerNo.Text = "Tanker No.";
            this.labelTankerNo.TextAlign = ContentAlignment.MiddleRight;
            this.textTrailerNo.CharacterCasing = CharacterCasing.Upper;
            this.textTrailerNo.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textTrailerNo.Location = new Point(0x145, 110);
            this.textTrailerNo.MaxLength = 20;
            this.textTrailerNo.Name = "textTrailerNo";
            this.textTrailerNo.Size = new Size(0x88, 20);
            this.textTrailerNo.TabIndex = 3;
            this.textTrailerNo.Visible = false;
            this.textTrailerNo.KeyPress += new KeyPressEventHandler(this.textTrailerNo_KeyPress);
            this.buttonTanker.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonTanker.Location = new Point(0x115, 0xb7);
            this.buttonTanker.Margin = new Padding(0);
            this.buttonTanker.Name = "buttonTanker";
            this.buttonTanker.Size = new Size(0x17, 0x17);
            this.buttonTanker.TabIndex = 10;
            this.buttonTanker.Text = "...";
            this.buttonTanker.UseVisualStyleBackColor = true;
            this.buttonTanker.Click += new EventHandler(this.buttonTanker_Click);
            this.textTanker.CharacterCasing = CharacterCasing.Upper;
            this.textTanker.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textTanker.Location = new Point(0x8a, 0xb9);
            this.textTanker.Name = "textTanker";
            this.textTanker.Size = new Size(0x88, 20);
            this.textTanker.TabIndex = 9;
            this.textTanker.KeyPress += new KeyPressEventHandler(this.textTanker_KeyPress);
            this.textTanker.Leave += new EventHandler(this.textTanker_Leave);
            this.labelDestinationCode.AutoSize = true;
            this.labelDestinationCode.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelDestinationCode.Location = new Point(0x88, 0x166);
            this.labelDestinationCode.Name = "labelDestinationCode";
            this.labelDestinationCode.Size = new Size(0x63, 15);
            this.labelDestinationCode.TabIndex = 20;
            this.labelDestinationCode.Text = "Destination code";
            this.labelDestinationCode.TextAlign = ContentAlignment.MiddleRight;
            this.lbl_transporter_name.AutoSize = true;
            this.lbl_transporter_name.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.lbl_transporter_name.Location = new Point(0x132, 0x8a);
            this.lbl_transporter_name.Name = "lbl_transporter_name";
            this.lbl_transporter_name.Size = new Size(0x69, 15);
            this.lbl_transporter_name.TabIndex = 14;
            this.lbl_transporter_name.Text = "Transporter name";
            this.lbl_transporter_name.TextAlign = ContentAlignment.TopRight;
            this.txt_driver_ic.CharacterCasing = CharacterCasing.Upper;
            this.txt_driver_ic.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txt_driver_ic.Location = new Point(0x8a, 160);
            this.txt_driver_ic.MaxLength = 50;
            this.txt_driver_ic.Name = "txt_driver_ic";
            this.txt_driver_ic.Size = new Size(0x88, 20);
            this.txt_driver_ic.TabIndex = 7;
            this.txt_driver_ic.TextChanged += new EventHandler(this.txt_driver_ic_TextChanged);
            this.txt_driver_ic.KeyPress += new KeyPressEventHandler(this.txt_driver_ic_KeyPress);
            this.txt_driver_ic.Leave += new EventHandler(this.txt_driver_ic_Leave);
            this.labelLicenseNo.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelLicenseNo.Location = new Point(5, 160);
            this.labelLicenseNo.Name = "labelLicenseNo";
            this.labelLicenseNo.Size = new Size(130, 0x13);
            this.labelLicenseNo.TabIndex = 8;
            this.labelLicenseNo.Text = "License No.";
            this.labelLicenseNo.TextAlign = ContentAlignment.MiddleRight;
            this.labelDestination.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelDestination.Location = new Point(5, 0x14e);
            this.labelDestination.Name = "labelDestination";
            this.labelDestination.Size = new Size(130, 0x13);
            this.labelDestination.TabIndex = 0x12;
            this.labelDestination.Text = "Destination";
            this.labelDestination.TextAlign = ContentAlignment.MiddleRight;
            this.buttonDriver.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonDriver.Location = new Point(0x115, 0x9e);
            this.buttonDriver.Margin = new Padding(0);
            this.buttonDriver.Name = "buttonDriver";
            this.buttonDriver.Size = new Size(0x17, 0x17);
            this.buttonDriver.TabIndex = 8;
            this.buttonDriver.Text = "...";
            this.buttonDriver.UseVisualStyleBackColor = true;
            this.buttonDriver.Click += new EventHandler(this.buttonDriver_Click);
            this.txt_gp_no.CharacterCasing = CharacterCasing.Upper;
            this.txt_gp_no.Font = new Font("Microsoft Sans Serif", 15f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txt_gp_no.Location = new Point(0x8f, 12);
            this.txt_gp_no.MaxLength = 50;
            this.txt_gp_no.Name = "txt_gp_no";
            this.txt_gp_no.ReadOnly = true;
            this.txt_gp_no.Size = new Size(0xd6, 30);
            this.txt_gp_no.TabIndex = 15;
            this.lbl_gp_no.AutoSize = true;
            this.lbl_gp_no.Font = new Font("Microsoft Sans Serif", 15f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.lbl_gp_no.Location = new Point(13, 14);
            this.lbl_gp_no.Name = "lbl_gp_no";
            this.lbl_gp_no.Size = new Size(0x7e, 0x19);
            this.lbl_gp_no.TabIndex = 20;
            this.lbl_gp_no.Text = "Gatepass No";
            this.lbl_gp_no.TextAlign = ContentAlignment.TopRight;
            this.groupPhoto.Controls.Add(this.tabControlPhoto);
            this.groupPhoto.Location = new Point(0x1fd, 0x6a);
            this.groupPhoto.Name = "groupPhoto";
            this.groupPhoto.Size = new Size(700, 0x11c);
            this.groupPhoto.TabIndex = 0x13;
            this.groupPhoto.TabStop = false;
            this.groupPhoto.Text = "[ Photo ]";
            this.tabControlPhoto.Controls.Add(this.tabPageDriverLicenseID);
            this.tabControlPhoto.Controls.Add(this.tabPage1st);
            this.tabControlPhoto.Controls.Add(this.tabPage2nd);
            this.tabControlPhoto.Controls.Add(this.tabPage3rd);
            this.tabControlPhoto.Controls.Add(this.tabPage4th);
            this.tabControlPhoto.Location = new Point(6, 0x12);
            this.tabControlPhoto.Name = "tabControlPhoto";
            this.tabControlPhoto.SelectedIndex = 0;
            this.tabControlPhoto.Size = new Size(0x2a6, 260);
            this.tabControlPhoto.TabIndex = 1;
            this.tabPageDriverLicenseID.BackColor = SystemColors.ButtonFace;
            this.tabPageDriverLicenseID.Controls.Add(this._driverLicense_img);
            this.tabPageDriverLicenseID.ForeColor = SystemColors.ControlText;
            this.tabPageDriverLicenseID.Location = new Point(4, 0x16);
            this.tabPageDriverLicenseID.Margin = new Padding(2);
            this.tabPageDriverLicenseID.Name = "tabPageDriverLicenseID";
            this.tabPageDriverLicenseID.Padding = new Padding(3);
            this.tabPageDriverLicenseID.Size = new Size(670, 0xea);
            this.tabPageDriverLicenseID.TabIndex = 4;
            this.tabPageDriverLicenseID.Text = "Driver License";
            this._driverLicense_img.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._driverLicense_img.BackgroundImageLayout = ImageLayout.Stretch;
            this._driverLicense_img.BorderStyle = BorderStyle.FixedSingle;
            this._driverLicense_img.Image = Resources.NoImage;
            this._driverLicense_img.Location = new Point(8, 7);
            this._driverLicense_img.Margin = new Padding(4);
            this._driverLicense_img.Name = "_driverLicense_img";
            this._driverLicense_img.Size = new Size(0xb6, 0x84);
            this._driverLicense_img.SizeMode = PictureBoxSizeMode.StretchImage;
            this._driverLicense_img.TabIndex = 11;
            this._driverLicense_img.TabStop = false;
            this._driverLicense_img.Click += new EventHandler(this._driverLicense_img_Click);
            this.tabPage1st.BackColor = SystemColors.ButtonFace;
            this.tabPage1st.Controls.Add(this._1st_cam4);
            this.tabPage1st.Controls.Add(this._1st_cam3);
            this.tabPage1st.Controls.Add(this._1st_cam2);
            this.tabPage1st.Controls.Add(this._1st_cam5);
            this.tabPage1st.Controls.Add(this._1st_cam1);
            this.tabPage1st.Location = new Point(4, 0x16);
            this.tabPage1st.Name = "tabPage1st";
            this.tabPage1st.Padding = new Padding(3);
            this.tabPage1st.Size = new Size(670, 0xea);
            this.tabPage1st.TabIndex = 1;
            this.tabPage1st.Text = "1st Weight";
            this._1st_cam4.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._1st_cam4.BackgroundImageLayout = ImageLayout.Stretch;
            this._1st_cam4.BorderStyle = BorderStyle.FixedSingle;
            this._1st_cam4.Location = new Point(0x1e6, 6);
            this._1st_cam4.Name = "_1st_cam4";
            this._1st_cam4.Size = new Size(0x89, 0x6c);
            this._1st_cam4.SizeMode = PictureBoxSizeMode.StretchImage;
            this._1st_cam4.TabIndex = 0x10;
            this._1st_cam4.TabStop = false;
            this._1st_cam4.Visible = false;
            this._1st_cam4.Click += new EventHandler(this._1st_cam4_Click);
            this._1st_cam3.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._1st_cam3.BackgroundImageLayout = ImageLayout.Stretch;
            this._1st_cam3.BorderStyle = BorderStyle.FixedSingle;
            this._1st_cam3.Location = new Point(0x147, 6);
            this._1st_cam3.Name = "_1st_cam3";
            this._1st_cam3.Size = new Size(0x89, 0x6c);
            this._1st_cam3.SizeMode = PictureBoxSizeMode.StretchImage;
            this._1st_cam3.TabIndex = 14;
            this._1st_cam3.TabStop = false;
            this._1st_cam3.Click += new EventHandler(this._1st_cam3_Click);
            this._1st_cam2.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._1st_cam2.BackgroundImageLayout = ImageLayout.Stretch;
            this._1st_cam2.BorderStyle = BorderStyle.FixedSingle;
            this._1st_cam2.Location = new Point(0xa6, 6);
            this._1st_cam2.Name = "_1st_cam2";
            this._1st_cam2.Size = new Size(0x89, 0x6c);
            this._1st_cam2.SizeMode = PictureBoxSizeMode.StretchImage;
            this._1st_cam2.TabIndex = 12;
            this._1st_cam2.TabStop = false;
            this._1st_cam2.Click += new EventHandler(this._1st_cam2_Click);
            this._1st_cam5.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._1st_cam5.BackgroundImageLayout = ImageLayout.Stretch;
            this._1st_cam5.BorderStyle = BorderStyle.FixedSingle;
            this._1st_cam5.Location = new Point(6, 120);
            this._1st_cam5.Name = "_1st_cam5";
            this._1st_cam5.Size = new Size(0x89, 0x6c);
            this._1st_cam5.SizeMode = PictureBoxSizeMode.StretchImage;
            this._1st_cam5.TabIndex = 11;
            this._1st_cam5.TabStop = false;
            this._1st_cam5.Visible = false;
            this._1st_cam5.Click += new EventHandler(this._1st_cam5_Click);
            this._1st_cam1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._1st_cam1.BackgroundImageLayout = ImageLayout.Stretch;
            this._1st_cam1.BorderStyle = BorderStyle.FixedSingle;
            this._1st_cam1.Image = Resources.NoImage;
            this._1st_cam1.Location = new Point(6, 6);
            this._1st_cam1.Name = "_1st_cam1";
            this._1st_cam1.Size = new Size(0x89, 0x6c);
            this._1st_cam1.SizeMode = PictureBoxSizeMode.StretchImage;
            this._1st_cam1.TabIndex = 10;
            this._1st_cam1.TabStop = false;
            this._1st_cam1.Click += new EventHandler(this._1st_cam1_Click);
            this.tabPage2nd.BackColor = SystemColors.ButtonFace;
            this.tabPage2nd.Controls.Add(this._2nd_cam4);
            this.tabPage2nd.Controls.Add(this._2nd_cam3);
            this.tabPage2nd.Controls.Add(this._2nd_cam2);
            this.tabPage2nd.Controls.Add(this._2nd_cam5);
            this.tabPage2nd.Controls.Add(this._2nd_cam1);
            this.tabPage2nd.Location = new Point(4, 0x16);
            this.tabPage2nd.Name = "tabPage2nd";
            this.tabPage2nd.Padding = new Padding(3);
            this.tabPage2nd.Size = new Size(670, 0xea);
            this.tabPage2nd.TabIndex = 1;
            this.tabPage2nd.Text = "2nd Weight";
            this._2nd_cam4.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._2nd_cam4.BackgroundImageLayout = ImageLayout.Stretch;
            this._2nd_cam4.BorderStyle = BorderStyle.FixedSingle;
            this._2nd_cam4.Location = new Point(0x1e6, 6);
            this._2nd_cam4.Name = "_2nd_cam4";
            this._2nd_cam4.Size = new Size(0x89, 0x6c);
            this._2nd_cam4.SizeMode = PictureBoxSizeMode.StretchImage;
            this._2nd_cam4.TabIndex = 0x15;
            this._2nd_cam4.TabStop = false;
            this._2nd_cam4.Visible = false;
            this._2nd_cam4.Click += new EventHandler(this._2nd_cam4_Click);
            this._2nd_cam3.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._2nd_cam3.BackgroundImageLayout = ImageLayout.Stretch;
            this._2nd_cam3.BorderStyle = BorderStyle.FixedSingle;
            this._2nd_cam3.Location = new Point(0x147, 6);
            this._2nd_cam3.Name = "_2nd_cam3";
            this._2nd_cam3.Size = new Size(0x89, 0x6c);
            this._2nd_cam3.SizeMode = PictureBoxSizeMode.StretchImage;
            this._2nd_cam3.TabIndex = 20;
            this._2nd_cam3.TabStop = false;
            this._2nd_cam3.Click += new EventHandler(this._2nd_cam3_Click);
            this._2nd_cam2.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._2nd_cam2.BackgroundImageLayout = ImageLayout.Stretch;
            this._2nd_cam2.BorderStyle = BorderStyle.FixedSingle;
            this._2nd_cam2.Location = new Point(0xa6, 6);
            this._2nd_cam2.Name = "_2nd_cam2";
            this._2nd_cam2.Size = new Size(0x89, 0x6c);
            this._2nd_cam2.SizeMode = PictureBoxSizeMode.StretchImage;
            this._2nd_cam2.TabIndex = 0x13;
            this._2nd_cam2.TabStop = false;
            this._2nd_cam2.Click += new EventHandler(this._2nd_cam2_Click);
            this._2nd_cam5.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._2nd_cam5.BackgroundImageLayout = ImageLayout.Stretch;
            this._2nd_cam5.BorderStyle = BorderStyle.FixedSingle;
            this._2nd_cam5.Location = new Point(6, 120);
            this._2nd_cam5.Name = "_2nd_cam5";
            this._2nd_cam5.Size = new Size(0x89, 0x6c);
            this._2nd_cam5.SizeMode = PictureBoxSizeMode.StretchImage;
            this._2nd_cam5.TabIndex = 0x12;
            this._2nd_cam5.TabStop = false;
            this._2nd_cam5.Visible = false;
            this._2nd_cam5.Click += new EventHandler(this._2nd_cam5_Click);
            this._2nd_cam1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._2nd_cam1.BackgroundImageLayout = ImageLayout.Stretch;
            this._2nd_cam1.BorderStyle = BorderStyle.FixedSingle;
            this._2nd_cam1.Location = new Point(6, 6);
            this._2nd_cam1.Name = "_2nd_cam1";
            this._2nd_cam1.Size = new Size(0x89, 0x6c);
            this._2nd_cam1.SizeMode = PictureBoxSizeMode.StretchImage;
            this._2nd_cam1.TabIndex = 0x11;
            this._2nd_cam1.TabStop = false;
            this._2nd_cam1.Click += new EventHandler(this._2nd_cam1_Click);
            this.tabPage3rd.BackColor = SystemColors.ButtonFace;
            this.tabPage3rd.Controls.Add(this._3rd_cam4);
            this.tabPage3rd.Controls.Add(this._3rd_cam3);
            this.tabPage3rd.Controls.Add(this._3rd_cam2);
            this.tabPage3rd.Controls.Add(this._3rd_cam5);
            this.tabPage3rd.Controls.Add(this._3rd_cam1);
            this.tabPage3rd.Location = new Point(4, 0x16);
            this.tabPage3rd.Name = "tabPage3rd";
            this.tabPage3rd.Size = new Size(670, 0xea);
            this.tabPage3rd.TabIndex = 2;
            this.tabPage3rd.Text = "3rd Weight";
            this._3rd_cam4.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._3rd_cam4.BackgroundImageLayout = ImageLayout.Stretch;
            this._3rd_cam4.BorderStyle = BorderStyle.FixedSingle;
            this._3rd_cam4.Location = new Point(0x1e6, 6);
            this._3rd_cam4.Name = "_3rd_cam4";
            this._3rd_cam4.Size = new Size(0x89, 0x6c);
            this._3rd_cam4.SizeMode = PictureBoxSizeMode.StretchImage;
            this._3rd_cam4.TabIndex = 0x15;
            this._3rd_cam4.TabStop = false;
            this._3rd_cam4.Visible = false;
            this._3rd_cam4.Click += new EventHandler(this._3rd_cam4_Click);
            this._3rd_cam3.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._3rd_cam3.BackgroundImageLayout = ImageLayout.Stretch;
            this._3rd_cam3.BorderStyle = BorderStyle.FixedSingle;
            this._3rd_cam3.Location = new Point(0x147, 6);
            this._3rd_cam3.Name = "_3rd_cam3";
            this._3rd_cam3.Size = new Size(0x89, 0x6c);
            this._3rd_cam3.SizeMode = PictureBoxSizeMode.StretchImage;
            this._3rd_cam3.TabIndex = 20;
            this._3rd_cam3.TabStop = false;
            this._3rd_cam3.Click += new EventHandler(this._3rd_cam3_Click);
            this._3rd_cam2.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._3rd_cam2.BackgroundImageLayout = ImageLayout.Stretch;
            this._3rd_cam2.BorderStyle = BorderStyle.FixedSingle;
            this._3rd_cam2.Location = new Point(0xa6, 6);
            this._3rd_cam2.Name = "_3rd_cam2";
            this._3rd_cam2.Size = new Size(0x89, 0x6c);
            this._3rd_cam2.SizeMode = PictureBoxSizeMode.StretchImage;
            this._3rd_cam2.TabIndex = 0x13;
            this._3rd_cam2.TabStop = false;
            this._3rd_cam2.Click += new EventHandler(this._3rd_cam2_Click);
            this._3rd_cam5.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._3rd_cam5.BackgroundImageLayout = ImageLayout.Stretch;
            this._3rd_cam5.BorderStyle = BorderStyle.FixedSingle;
            this._3rd_cam5.Location = new Point(6, 120);
            this._3rd_cam5.Name = "_3rd_cam5";
            this._3rd_cam5.Size = new Size(0x89, 0x6c);
            this._3rd_cam5.SizeMode = PictureBoxSizeMode.StretchImage;
            this._3rd_cam5.TabIndex = 0x12;
            this._3rd_cam5.TabStop = false;
            this._3rd_cam5.Visible = false;
            this._3rd_cam5.Click += new EventHandler(this._3rd_cam5_Click);
            this._3rd_cam1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._3rd_cam1.BackgroundImageLayout = ImageLayout.Stretch;
            this._3rd_cam1.BorderStyle = BorderStyle.FixedSingle;
            this._3rd_cam1.Location = new Point(6, 6);
            this._3rd_cam1.Name = "_3rd_cam1";
            this._3rd_cam1.Size = new Size(0x89, 0x6c);
            this._3rd_cam1.SizeMode = PictureBoxSizeMode.StretchImage;
            this._3rd_cam1.TabIndex = 0x11;
            this._3rd_cam1.TabStop = false;
            this._3rd_cam1.Click += new EventHandler(this._3rd_cam1_Click);
            this.tabPage4th.BackColor = SystemColors.ButtonFace;
            this.tabPage4th.Controls.Add(this._4th_cam4);
            this.tabPage4th.Controls.Add(this._4th_cam3);
            this.tabPage4th.Controls.Add(this._4th_cam2);
            this.tabPage4th.Controls.Add(this._4th_cam5);
            this.tabPage4th.Controls.Add(this._4th_cam1);
            this.tabPage4th.Location = new Point(4, 0x16);
            this.tabPage4th.Name = "tabPage4th";
            this.tabPage4th.Size = new Size(670, 0xea);
            this.tabPage4th.TabIndex = 3;
            this.tabPage4th.Text = "4th Weight";
            this._4th_cam4.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._4th_cam4.BackgroundImageLayout = ImageLayout.Stretch;
            this._4th_cam4.BorderStyle = BorderStyle.FixedSingle;
            this._4th_cam4.Location = new Point(0x1e6, 6);
            this._4th_cam4.Name = "_4th_cam4";
            this._4th_cam4.Size = new Size(0x89, 0x6c);
            this._4th_cam4.SizeMode = PictureBoxSizeMode.StretchImage;
            this._4th_cam4.TabIndex = 0x15;
            this._4th_cam4.TabStop = false;
            this._4th_cam4.Visible = false;
            this._4th_cam4.Click += new EventHandler(this._4th_cam4_Click);
            this._4th_cam3.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._4th_cam3.BackgroundImageLayout = ImageLayout.Stretch;
            this._4th_cam3.BorderStyle = BorderStyle.FixedSingle;
            this._4th_cam3.Location = new Point(0x147, 6);
            this._4th_cam3.Name = "_4th_cam3";
            this._4th_cam3.Size = new Size(0x89, 0x6c);
            this._4th_cam3.SizeMode = PictureBoxSizeMode.StretchImage;
            this._4th_cam3.TabIndex = 20;
            this._4th_cam3.TabStop = false;
            this._4th_cam3.Click += new EventHandler(this._4th_cam3_Click);
            this._4th_cam2.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._4th_cam2.BackgroundImageLayout = ImageLayout.Stretch;
            this._4th_cam2.BorderStyle = BorderStyle.FixedSingle;
            this._4th_cam2.Location = new Point(0xa6, 6);
            this._4th_cam2.Name = "_4th_cam2";
            this._4th_cam2.Size = new Size(0x89, 0x6c);
            this._4th_cam2.SizeMode = PictureBoxSizeMode.StretchImage;
            this._4th_cam2.TabIndex = 0x13;
            this._4th_cam2.TabStop = false;
            this._4th_cam2.Click += new EventHandler(this._4th_cam2_Click);
            this._4th_cam5.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._4th_cam5.BackgroundImageLayout = ImageLayout.Stretch;
            this._4th_cam5.BorderStyle = BorderStyle.FixedSingle;
            this._4th_cam5.Location = new Point(6, 120);
            this._4th_cam5.Name = "_4th_cam5";
            this._4th_cam5.Size = new Size(0x89, 0x6c);
            this._4th_cam5.SizeMode = PictureBoxSizeMode.StretchImage;
            this._4th_cam5.TabIndex = 0x12;
            this._4th_cam5.TabStop = false;
            this._4th_cam5.Visible = false;
            this._4th_cam5.Click += new EventHandler(this._4th_cam5_Click);
            this._4th_cam1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._4th_cam1.BackgroundImageLayout = ImageLayout.Stretch;
            this._4th_cam1.BorderStyle = BorderStyle.FixedSingle;
            this._4th_cam1.Location = new Point(6, 6);
            this._4th_cam1.Name = "_4th_cam1";
            this._4th_cam1.Size = new Size(0x89, 0x6c);
            this._4th_cam1.SizeMode = PictureBoxSizeMode.StretchImage;
            this._4th_cam1.TabIndex = 0x11;
            this._4th_cam1.TabStop = false;
            this._4th_cam1.Click += new EventHandler(this._4th_cam1_Click);
            this.lbl_reg_date.AutoSize = true;
            this.lbl_reg_date.BackColor = SystemColors.ButtonFace;
            this.lbl_reg_date.Font = new Font("Microsoft Sans Serif", 15f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.lbl_reg_date.Location = new Point(0x342, 14);
            this.lbl_reg_date.Name = "lbl_reg_date";
            this.lbl_reg_date.Size = new Size(160, 0x19);
            this.lbl_reg_date.TabIndex = 0x67;
            this.lbl_reg_date.Text = "Registration Date";
            this.lbl_reg_date.TextAlign = ContentAlignment.TopRight;
            this.dtRegistration.CustomFormat = "dd/MM/yyyy";
            this.dtRegistration.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.dtRegistration.Format = DateTimePickerFormat.Custom;
            this.dtRegistration.Location = new Point(0x3f4, 15);
            this.dtRegistration.Name = "dtRegistration";
            this.dtRegistration.Size = new Size(0x80, 0x1a);
            this.dtRegistration.TabIndex = 0x65;
            this.dtRegistration.Value = new DateTime(0x7e2, 3, 8, 12, 0, 0, 0);
            this.txtRegistrationTime.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtRegistrationTime.Location = new Point(0x47a, 15);
            this.txtRegistrationTime.Mask = "00:00";
            this.txtRegistrationTime.Name = "txtRegistrationTime";
            this.txtRegistrationTime.Size = new Size(0x2f, 0x1a);
            this.txtRegistrationTime.TabIndex = 0x66;
            this.txtRegistrationTime.ValidatingType = typeof(DateTime);
            this.tabPageOP.BackColor = SystemColors.ButtonFace;
            this.tabPageOP.Controls.Add(this.groupOPW);
            this.tabPageOP.Controls.Add(this.checkNOPW);
            this.tabPageOP.Location = new Point(4, 0x16);
            this.tabPageOP.Name = "tabPageOP";
            this.tabPageOP.Padding = new Padding(3);
            this.tabPageOP.Size = new Size(0x2b4, 0xda);
            this.tabPageOP.TabIndex = 1;
            this.tabPageOP.Text = "Other Party";
            this.groupOPW.Controls.Add(this.labelWBNo);
            this.groupOPW.Controls.Add(this.btnCheck_OP);
            this.groupOPW.Controls.Add(this.textWBNo);
            this.groupOPW.Controls.Add(this.textNetEstate);
            this.groupOPW.Controls.Add(this.labelOPDate);
            this.groupOPW.Controls.Add(this.textTareEstate);
            this.groupOPW.Controls.Add(this.dateDelivery);
            this.groupOPW.Controls.Add(this.textGrossEstate);
            this.groupOPW.Controls.Add(this.labelOPNet);
            this.groupOPW.Controls.Add(this.TimeDelivery);
            this.groupOPW.Controls.Add(this.labelOPTare);
            this.groupOPW.Controls.Add(this.labelOPGross);
            this.groupOPW.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.groupOPW.Location = new Point(0x12, 0x1c);
            this.groupOPW.Name = "groupOPW";
            this.groupOPW.Size = new Size(520, 0xad);
            this.groupOPW.TabIndex = 0x65;
            this.groupOPW.TabStop = false;
            this.labelWBNo.AutoSize = true;
            this.labelWBNo.Location = new Point(0x12, 0x13);
            this.labelWBNo.Name = "labelWBNo";
            this.labelWBNo.Size = new Size(0x9b, 15);
            this.labelWBNo.TabIndex = 8;
            this.labelWBNo.Text = "Other Party Reference Doc.";
            this.btnCheck_OP.Location = new Point(0x1b2, 14);
            this.btnCheck_OP.Name = "btnCheck_OP";
            this.btnCheck_OP.Size = new Size(0x41, 0x17);
            this.btnCheck_OP.TabIndex = 0x6c;
            this.btnCheck_OP.Text = "&Check";
            this.btnCheck_OP.UseVisualStyleBackColor = true;
            this.btnCheck_OP.Click += new EventHandler(this.btnCheck_OP_Click);
            this.textWBNo.CharacterCasing = CharacterCasing.Upper;
            this.textWBNo.Location = new Point(0xfb, 0x10);
            this.textWBNo.MaxLength = 30;
            this.textWBNo.Name = "textWBNo";
            this.textWBNo.Size = new Size(0xb1, 20);
            this.textWBNo.TabIndex = 1;
            this.textWBNo.KeyPress += new KeyPressEventHandler(this.textWBNo_KeyPress);
            this.textNetEstate.Location = new Point(0xfb, 0x70);
            this.textNetEstate.MaxLength = 15;
            this.textNetEstate.Name = "textNetEstate";
            this.textNetEstate.ReadOnly = true;
            this.textNetEstate.Size = new Size(0x39, 20);
            this.textNetEstate.TabIndex = 6;
            this.textNetEstate.Text = "0";
            this.textNetEstate.TextAlign = HorizontalAlignment.Right;
            this.labelOPDate.AutoSize = true;
            this.labelOPDate.Location = new Point(0x13, 0x2b);
            this.labelOPDate.Name = "labelOPDate";
            this.labelOPDate.Size = new Size(0x60, 15);
            this.labelOPDate.TabIndex = 7;
            this.labelOPDate.Text = "Other Party Date";
            this.textTareEstate.Location = new Point(0xfb, 0x58);
            this.textTareEstate.MaxLength = 15;
            this.textTareEstate.Name = "textTareEstate";
            this.textTareEstate.Size = new Size(0x39, 20);
            this.textTareEstate.TabIndex = 5;
            this.textTareEstate.Text = "0";
            this.textTareEstate.TextAlign = HorizontalAlignment.Right;
            this.textTareEstate.KeyPress += new KeyPressEventHandler(this.textGrossEstate_KeyPress);
            this.textTareEstate.Leave += new EventHandler(this.textTareEstate_Leave);
            this.dateDelivery.Format = DateTimePickerFormat.Short;
            this.dateDelivery.Location = new Point(0xfb, 40);
            this.dateDelivery.Name = "dateDelivery";
            this.dateDelivery.Size = new Size(0x66, 20);
            this.dateDelivery.TabIndex = 2;
            this.textGrossEstate.Location = new Point(0xfb, 0x40);
            this.textGrossEstate.MaxLength = 15;
            this.textGrossEstate.Name = "textGrossEstate";
            this.textGrossEstate.Size = new Size(0x39, 20);
            this.textGrossEstate.TabIndex = 4;
            this.textGrossEstate.Text = "0";
            this.textGrossEstate.TextAlign = HorizontalAlignment.Right;
            this.textGrossEstate.KeyPress += new KeyPressEventHandler(this.textGrossEstate_KeyPress);
            this.textGrossEstate.Leave += new EventHandler(this.textGrossEstate_Leave);
            this.labelOPNet.AutoSize = true;
            this.labelOPNet.Location = new Point(0x12, 0x73);
            this.labelOPNet.Name = "labelOPNet";
            this.labelOPNet.Size = new Size(0x1a, 15);
            this.labelOPNet.TabIndex = 9;
            this.labelOPNet.Text = "Net";
            this.TimeDelivery.Location = new Point(0x167, 40);
            this.TimeDelivery.Mask = "00:00";
            this.TimeDelivery.Name = "TimeDelivery";
            this.TimeDelivery.Size = new Size(0x25, 20);
            this.TimeDelivery.TabIndex = 3;
            this.TimeDelivery.ValidatingType = typeof(DateTime);
            this.labelOPTare.AutoSize = true;
            this.labelOPTare.Location = new Point(0x12, 0x5b);
            this.labelOPTare.Name = "labelOPTare";
            this.labelOPTare.Size = new Size(0x20, 15);
            this.labelOPTare.TabIndex = 6;
            this.labelOPTare.Text = "Tare";
            this.labelOPGross.AutoSize = true;
            this.labelOPGross.Location = new Point(0x13, 0x43);
            this.labelOPGross.Name = "labelOPGross";
            this.labelOPGross.Size = new Size(0x27, 15);
            this.labelOPGross.TabIndex = 5;
            this.labelOPGross.Text = "Gross";
            this.checkNOPW.AutoSize = true;
            this.checkNOPW.CheckAlign = ContentAlignment.TopLeft;
            this.checkNOPW.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.checkNOPW.Location = new Point(0x13, 10);
            this.checkNOPW.Name = "checkNOPW";
            this.checkNOPW.Size = new Size(0xcf, 0x13);
            this.checkNOPW.TabIndex = 100;
            this.checkNOPW.Text = "No other party weight in WB ticket";
            this.checkNOPW.UseVisualStyleBackColor = true;
            this.checkNOPW.CheckedChanged += new EventHandler(this.checkNOPW_CheckedChanged);
            this.tabPageGeneral.BackColor = SystemColors.ButtonFace;
            this.tabPageGeneral.Controls.Add(this.buttonDN);
            this.tabPageGeneral.Controls.Add(this.textPL3);
            this.tabPageGeneral.Controls.Add(this.labelPL3);
            this.tabPageGeneral.Controls.Add(this.checkEstate);
            this.tabPageGeneral.Controls.Add(this.labelAdditionalInfo);
            this.tabPageGeneral.Controls.Add(this.txtAddInfo);
            this.tabPageGeneral.Controls.Add(this.textRemarkReport);
            this.tabPageGeneral.Controls.Add(this.txt_deli_note);
            this.tabPageGeneral.Controls.Add(this.panel_return);
            this.tabPageGeneral.Controls.Add(this.txt_seal);
            this.tabPageGeneral.Controls.Add(this.textRemarkTicket);
            this.tabPageGeneral.Controls.Add(this.labelDeliveryNote);
            this.tabPageGeneral.Controls.Add(this.labelRemarkReport);
            this.tabPageGeneral.Controls.Add(this.labelSealNo);
            this.tabPageGeneral.Controls.Add(this.chk_return);
            this.tabPageGeneral.Controls.Add(this.labelRemarkTicket);
            this.tabPageGeneral.Location = new Point(4, 0x16);
            this.tabPageGeneral.Name = "tabPageGeneral";
            this.tabPageGeneral.Padding = new Padding(3);
            this.tabPageGeneral.Size = new Size(0x2b4, 0xda);
            this.tabPageGeneral.TabIndex = 1;
            this.tabPageGeneral.Text = "General";
            this.buttonDN.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonDN.Location = new Point(0x10f, 14);
            this.buttonDN.Margin = new Padding(0);
            this.buttonDN.Name = "buttonDN";
            this.buttonDN.Size = new Size(0x17, 0x17);
            this.buttonDN.TabIndex = 110;
            this.buttonDN.Text = "...";
            this.buttonDN.UseVisualStyleBackColor = true;
            this.buttonDN.Click += new EventHandler(this.buttonDN_Click);
            this.textPL3.CharacterCasing = CharacterCasing.Upper;
            this.textPL3.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textPL3.Location = new Point(0x225, 0x76);
            this.textPL3.MaxLength = 50;
            this.textPL3.Name = "textPL3";
            this.textPL3.Size = new Size(0x83, 20);
            this.textPL3.TabIndex = 0x6b;
            this.textPL3.Visible = false;
            this.labelPL3.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelPL3.Location = new Point(0x1ef, 0x76);
            this.labelPL3.Name = "labelPL3";
            this.labelPL3.Size = new Size(0x30, 0x13);
            this.labelPL3.TabIndex = 0x6a;
            this.labelPL3.Text = "PL3 No";
            this.labelPL3.TextAlign = ContentAlignment.MiddleRight;
            this.labelPL3.Visible = false;
            this.checkEstate.AutoSize = true;
            this.checkEstate.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.checkEstate.Location = new Point(0x129, 0x11);
            this.checkEstate.Name = "checkEstate";
            this.checkEstate.Size = new Size(0x77, 0x13);
            this.checkEstate.TabIndex = 0x69;
            this.checkEstate.Text = "Estate is different";
            this.checkEstate.UseVisualStyleBackColor = true;
            this.labelAdditionalInfo.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelAdditionalInfo.Location = new Point(6, 120);
            this.labelAdditionalInfo.Name = "labelAdditionalInfo";
            this.labelAdditionalInfo.Size = new Size(0x9b, 15);
            this.labelAdditionalInfo.TabIndex = 0x68;
            this.labelAdditionalInfo.Text = "Additional Info";
            this.labelAdditionalInfo.TextAlign = ContentAlignment.MiddleRight;
            this.txtAddInfo.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtAddInfo.Location = new Point(0xa2, 0x76);
            this.txtAddInfo.MaxLength = 100;
            this.txtAddInfo.Name = "txtAddInfo";
            this.txtAddInfo.Size = new Size(0x147, 20);
            this.txtAddInfo.TabIndex = 0x13;
            this.txtAddInfo.KeyPress += new KeyPressEventHandler(this.txtAddInfo_KeyPress);
            this.textRemarkReport.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textRemarkReport.Location = new Point(0xa2, 0x5c);
            this.textRemarkReport.MaxLength = 100;
            this.textRemarkReport.Name = "textRemarkReport";
            this.textRemarkReport.Size = new Size(0x206, 20);
            this.textRemarkReport.TabIndex = 0x12;
            this.textRemarkReport.KeyPress += new KeyPressEventHandler(this.textRemarkReport_KeyPress);
            this.txt_deli_note.CharacterCasing = CharacterCasing.Upper;
            this.txt_deli_note.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txt_deli_note.Location = new Point(0xa2, 15);
            this.txt_deli_note.MaxLength = 30;
            this.txt_deli_note.Name = "txt_deli_note";
            this.txt_deli_note.Size = new Size(0x69, 20);
            this.txt_deli_note.TabIndex = 12;
            this.txt_deli_note.KeyPress += new KeyPressEventHandler(this.txt_deli_note_KeyPress);
            this.txt_deli_note.Leave += new EventHandler(this.txt_deli_note_Leave);
            this.panel_return.Controls.Add(this.btn_check);
            this.panel_return.Controls.Add(this.text_ref_return);
            this.panel_return.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.panel_return.Location = new Point(0x204, 6);
            this.panel_return.Name = "panel_return";
            this.panel_return.Size = new Size(0xa8, 0x20);
            this.panel_return.TabIndex = 0x1a;
            this.panel_return.Visible = false;
            this.btn_check.Location = new Point(0x72, 5);
            this.btn_check.Name = "btn_check";
            this.btn_check.Size = new Size(50, 0x17);
            this.btn_check.TabIndex = 1;
            this.btn_check.Text = "Check";
            this.btn_check.UseVisualStyleBackColor = true;
            this.btn_check.Click += new EventHandler(this.btn_check_Click);
            this.text_ref_return.Location = new Point(6, 7);
            this.text_ref_return.Name = "text_ref_return";
            this.text_ref_return.Size = new Size(0x6b, 20);
            this.text_ref_return.TabIndex = 1;
            this.text_ref_return.KeyPress += new KeyPressEventHandler(this.text_ref_return_KeyPress);
            this.txt_seal.CharacterCasing = CharacterCasing.Upper;
            this.txt_seal.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txt_seal.Location = new Point(0xa2, 0x29);
            this.txt_seal.MaxLength = 50;
            this.txt_seal.Name = "txt_seal";
            this.txt_seal.Size = new Size(0x206, 20);
            this.txt_seal.TabIndex = 14;
            this.txt_seal.TextChanged += new EventHandler(this.txt_seal_TextChanged);
            this.txt_seal.KeyPress += new KeyPressEventHandler(this.txt_seal_KeyPress);
            this.textRemarkTicket.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textRemarkTicket.Location = new Point(0xa2, 0x42);
            this.textRemarkTicket.MaxLength = 100;
            this.textRemarkTicket.Name = "textRemarkTicket";
            this.textRemarkTicket.Size = new Size(0x206, 20);
            this.textRemarkTicket.TabIndex = 0x11;
            this.textRemarkTicket.KeyPress += new KeyPressEventHandler(this.textRemarkTicket_KeyPress);
            this.labelDeliveryNote.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelDeliveryNote.Location = new Point(6, 0x11);
            this.labelDeliveryNote.Name = "labelDeliveryNote";
            this.labelDeliveryNote.Size = new Size(0x9b, 15);
            this.labelDeliveryNote.TabIndex = 11;
            this.labelDeliveryNote.Text = "Delivery Note";
            this.labelDeliveryNote.TextAlign = ContentAlignment.MiddleRight;
            this.labelRemarkReport.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelRemarkReport.Location = new Point(6, 0x5e);
            this.labelRemarkReport.Name = "labelRemarkReport";
            this.labelRemarkReport.Size = new Size(0x9b, 15);
            this.labelRemarkReport.TabIndex = 20;
            this.labelRemarkReport.Text = "Remark for Report";
            this.labelRemarkReport.TextAlign = ContentAlignment.MiddleRight;
            this.labelSealNo.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelSealNo.Location = new Point(6, 0x2b);
            this.labelSealNo.Name = "labelSealNo";
            this.labelSealNo.Size = new Size(0x9b, 15);
            this.labelSealNo.TabIndex = 13;
            this.labelSealNo.Text = "Seal No.";
            this.labelSealNo.TextAlign = ContentAlignment.MiddleRight;
            this.chk_return.AutoSize = true;
            this.chk_return.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.chk_return.Location = new Point(0x1a0, 0x11);
            this.chk_return.Name = "chk_return";
            this.chk_return.Size = new Size(0x3f, 0x13);
            this.chk_return.TabIndex = 0x19;
            this.chk_return.Text = "Return";
            this.chk_return.UseVisualStyleBackColor = true;
            this.chk_return.CheckedChanged += new EventHandler(this.chk_return_CheckedChanged);
            this.labelRemarkTicket.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelRemarkTicket.Location = new Point(6, 0x44);
            this.labelRemarkTicket.Name = "labelRemarkTicket";
            this.labelRemarkTicket.Size = new Size(0x9b, 15);
            this.labelRemarkTicket.TabIndex = 0x13;
            this.labelRemarkTicket.Text = "Remark for Ticket";
            this.labelRemarkTicket.TextAlign = ContentAlignment.MiddleRight;
            this.dgvDO.AllowUserToAddRows = false;
            this.dgvDO.AllowUserToDeleteRows = false;
            this.dgvDO.AllowUserToResizeRows = false;
            this.dgvDO.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDO.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dgvDO.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDO.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvDO.Location = new Point(0x6c, 9);
            this.dgvDO.MultiSelect = false;
            this.dgvDO.Name = "dgvDO";
            this.dgvDO.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDO.Size = new Size(0x234, 160);
            this.dgvDO.TabIndex = 5;
            this.dgvDO.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dgvDO_CellFormatting);
            this.buttonViewDO.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonViewDO.Location = new Point(8, 0x69);
            this.buttonViewDO.Name = "buttonViewDO";
            this.buttonViewDO.Size = new Size(0x5e, 0x1a);
            this.buttonViewDO.TabIndex = 110;
            this.buttonViewDO.Text = "View";
            this.buttonViewDO.UseVisualStyleBackColor = true;
            this.buttonViewDO.Click += new EventHandler(this.buttonViewDO_Click);
            this.buttonAddDO.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonAddDO.Location = new Point(8, 9);
            this.buttonAddDO.Name = "buttonAddDO";
            this.buttonAddDO.Size = new Size(0x5e, 0x1a);
            this.buttonAddDO.TabIndex = 0x6b;
            this.buttonAddDO.Text = "&Add";
            this.buttonAddDO.UseVisualStyleBackColor = true;
            this.buttonAddDO.Click += new EventHandler(this.buttonAddDO_Click);
            this.buttonDeleteDO.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonDeleteDO.Location = new Point(8, 0x49);
            this.buttonDeleteDO.Name = "buttonDeleteDO";
            this.buttonDeleteDO.Size = new Size(0x5e, 0x1a);
            this.buttonDeleteDO.TabIndex = 0x6d;
            this.buttonDeleteDO.Text = "Delete";
            this.buttonDeleteDO.UseVisualStyleBackColor = true;
            this.buttonDeleteDO.Click += new EventHandler(this.buttonDeleteDO_Click);
            this.buttonEditDO.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonEditDO.Location = new Point(8, 0x29);
            this.buttonEditDO.Name = "buttonEditDO";
            this.buttonEditDO.Size = new Size(0x5e, 0x1a);
            this.buttonEditDO.TabIndex = 0x6c;
            this.buttonEditDO.Text = "&Edit";
            this.buttonEditDO.UseVisualStyleBackColor = true;
            this.buttonEditDO.Click += new EventHandler(this.buttonEditDO_Click);
            this.tabControlInformation.Controls.Add(this.tabPageGeneral);
            this.tabControlInformation.Controls.Add(this.tabPageCont);
            this.tabControlInformation.Controls.Add(this.tabPageOP);
            this.tabControlInformation.Controls.Add(this.tabPageWBDO);
            this.tabControlInformation.Controls.Add(this.tabPageDeduction);
            this.tabControlInformation.Controls.Add(this.tabPageQC);
            this.tabControlInformation.Controls.Add(this.tabPageFFB);
            this.tabControlInformation.Controls.Add(this.tabPageDivision);
            this.tabControlInformation.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.tabControlInformation.Location = new Point(0x1fd, 0x18c);
            this.tabControlInformation.Name = "tabControlInformation";
            this.tabControlInformation.SelectedIndex = 0;
            this.tabControlInformation.Size = new Size(700, 0xf4);
            this.tabControlInformation.TabIndex = 1;
            this.tabPageCont.BackColor = SystemColors.Control;
            this.tabPageCont.Controls.Add(this.checkNeedContainerCheck);
            this.tabPageCont.Controls.Add(this.buttonContDelete);
            this.tabPageCont.Controls.Add(this.dgvCont);
            this.tabPageCont.Controls.Add(this.buttonContEdit);
            this.tabPageCont.Controls.Add(this.buttonContAdd);
            this.tabPageCont.Location = new Point(4, 0x16);
            this.tabPageCont.Name = "tabPageCont";
            this.tabPageCont.Padding = new Padding(3);
            this.tabPageCont.Size = new Size(0x2b4, 0xda);
            this.tabPageCont.TabIndex = 6;
            this.tabPageCont.Text = "Container No ";
            this.checkNeedContainerCheck.AutoSize = true;
            this.checkNeedContainerCheck.Enabled = false;
            this.checkNeedContainerCheck.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.checkNeedContainerCheck.Location = new Point(0x4d, 0xc4);
            this.checkNeedContainerCheck.Name = "checkNeedContainerCheck";
            this.checkNeedContainerCheck.Size = new Size(0x95, 0x13);
            this.checkNeedContainerCheck.TabIndex = 110;
            this.checkNeedContainerCheck.Text = "Need Container Check";
            this.checkNeedContainerCheck.UseVisualStyleBackColor = true;
            this.checkNeedContainerCheck.CheckedChanged += new EventHandler(this.checkNeedContainerCheck_CheckedChanged);
            this.buttonContDelete.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonContDelete.Location = new Point(8, 0x49);
            this.buttonContDelete.Name = "buttonContDelete";
            this.buttonContDelete.Size = new Size(0x3f, 0x1a);
            this.buttonContDelete.TabIndex = 2;
            this.buttonContDelete.Text = "Delete";
            this.buttonContDelete.UseVisualStyleBackColor = true;
            this.buttonContDelete.Click += new EventHandler(this.buttonContDelete_Click);
            this.dgvCont.AllowUserToAddRows = false;
            this.dgvCont.AllowUserToDeleteRows = false;
            this.dgvCont.AllowUserToResizeRows = false;
            this.dgvCont.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvCont.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dgvCont.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCont.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvCont.Location = new Point(0x4d, 9);
            this.dgvCont.MultiSelect = false;
            this.dgvCont.Name = "dgvCont";
            this.dgvCont.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvCont.Size = new Size(0x253, 0xb5);
            this.dgvCont.TabIndex = 2;
            this.buttonContEdit.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonContEdit.Location = new Point(8, 0x29);
            this.buttonContEdit.Name = "buttonContEdit";
            this.buttonContEdit.Size = new Size(0x3f, 0x1a);
            this.buttonContEdit.TabIndex = 1;
            this.buttonContEdit.Text = "Edit";
            this.buttonContEdit.UseVisualStyleBackColor = true;
            this.buttonContEdit.Click += new EventHandler(this.buttonContEdit_Click);
            this.buttonContAdd.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonContAdd.Location = new Point(8, 9);
            this.buttonContAdd.Name = "buttonContAdd";
            this.buttonContAdd.Size = new Size(0x3f, 0x1a);
            this.buttonContAdd.TabIndex = 0;
            this.buttonContAdd.Text = "Add ";
            this.buttonContAdd.UseVisualStyleBackColor = true;
            this.buttonContAdd.Click += new EventHandler(this.buttonContAdd_Click);
            this.tabPageWBDO.BackColor = SystemColors.ButtonFace;
            this.tabPageWBDO.Controls.Add(this.tableLayoutPanel1);
            this.tabPageWBDO.Controls.Add(this.buttonDeleteAllDO);
            this.tabPageWBDO.Controls.Add(this.buttonViewDO);
            this.tabPageWBDO.Controls.Add(this.dgvDO);
            this.tabPageWBDO.Controls.Add(this.buttonAddDO);
            this.tabPageWBDO.Controls.Add(this.buttonDeleteDO);
            this.tabPageWBDO.Controls.Add(this.buttonEditDO);
            this.tabPageWBDO.Location = new Point(4, 0x16);
            this.tabPageWBDO.Name = "tabPageWBDO";
            this.tabPageWBDO.Padding = new Padding(3);
            this.tabPageWBDO.Size = new Size(0x2b4, 0xda);
            this.tabPageWBDO.TabIndex = 3;
            this.tabPageWBDO.Text = "WB DO";
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40.36481f));
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20.76317f));
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.62195f));
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 3.495003f));
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20.75507f));
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblTotalDOQtyInKG, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblTotalItem, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label34, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label59, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label61, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblTotalAllocatedFactNet, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.label63, 6, 1);
            this.tableLayoutPanel1.Location = new Point(0x6c, 0xac);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel1.Size = new Size(0x236, 0x2a);
            this.tableLayoutPanel1.TabIndex = 0x89;
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(3, 0x15);
            this.label1.Name = "label1";
            this.label1.Padding = new Padding(9, 4, 0, 4);
            this.label1.Size = new Size(0x81, 0x15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Total DO Qty in KG :";
            this.lblTotalDOQtyInKG.AutoSize = true;
            this.lblTotalDOQtyInKG.Dock = DockStyle.Fill;
            this.lblTotalDOQtyInKG.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.lblTotalDOQtyInKG.Location = new Point(0x8d, 0x15);
            this.lblTotalDOQtyInKG.Name = "lblTotalDOQtyInKG";
            this.lblTotalDOQtyInKG.Padding = new Padding(9, 4, 0, 4);
            this.lblTotalDOQtyInKG.Size = new Size(0x41, 0x15);
            this.lblTotalDOQtyInKG.TabIndex = 2;
            this.lblTotalDOQtyInKG.Text = "0";
            this.lblTotalDOQtyInKG.TextAlign = ContentAlignment.TopRight;
            this.lblTotalItem.AutoSize = true;
            this.lblTotalItem.Dock = DockStyle.Fill;
            this.lblTotalItem.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.lblTotalItem.Location = new Point(0x8d, 0);
            this.lblTotalItem.Name = "lblTotalItem";
            this.lblTotalItem.Padding = new Padding(9, 4, 0, 4);
            this.lblTotalItem.Size = new Size(0x41, 0x15);
            this.lblTotalItem.TabIndex = 1;
            this.lblTotalItem.Text = "0";
            this.lblTotalItem.TextAlign = ContentAlignment.TopRight;
            this.label34.AutoSize = true;
            this.label34.Dock = DockStyle.Fill;
            this.label34.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label34.Location = new Point(3, 0);
            this.label34.Name = "label34";
            this.label34.Padding = new Padding(9, 4, 0, 4);
            this.label34.Size = new Size(0x84, 0x15);
            this.label34.TabIndex = 0;
            this.label34.Text = "Total WB DO :";
            this.label59.AutoSize = true;
            this.label59.Dock = DockStyle.Fill;
            this.label59.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label59.Location = new Point(0xd4, 0x15);
            this.label59.Name = "label59";
            this.label59.Padding = new Padding(2, 4, 0, 4);
            this.label59.Size = new Size(0x2c, 0x15);
            this.label59.TabIndex = 4;
            this.label59.Text = "KG";
            this.label61.AutoSize = true;
            this.label61.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label61.Location = new Point(0x112, 0x15);
            this.label61.Name = "label61";
            this.label61.Padding = new Padding(9, 4, 0, 4);
            this.label61.Size = new Size(0xb8, 0x15);
            this.label61.TabIndex = 5;
            this.label61.Text = "Total Allocated Factory Nett :";
            this.lblTotalAllocatedFactNet.AutoSize = true;
            this.lblTotalAllocatedFactNet.Dock = DockStyle.Fill;
            this.lblTotalAllocatedFactNet.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.lblTotalAllocatedFactNet.Location = new Point(0x1d0, 0x15);
            this.lblTotalAllocatedFactNet.Name = "lblTotalAllocatedFactNet";
            this.lblTotalAllocatedFactNet.Padding = new Padding(9, 4, 0, 4);
            this.lblTotalAllocatedFactNet.Size = new Size(0x41, 0x15);
            this.lblTotalAllocatedFactNet.TabIndex = 6;
            this.lblTotalAllocatedFactNet.Text = "0";
            this.lblTotalAllocatedFactNet.TextAlign = ContentAlignment.TopRight;
            this.label63.AutoSize = true;
            this.label63.Dock = DockStyle.Fill;
            this.label63.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label63.Location = new Point(0x217, 0x15);
            this.label63.Name = "label63";
            this.label63.Padding = new Padding(2, 4, 0, 4);
            this.label63.Size = new Size(0x1c, 0x15);
            this.label63.TabIndex = 7;
            this.label63.Text = "KG";
            this.buttonDeleteAllDO.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonDeleteAllDO.Location = new Point(8, 0x89);
            this.buttonDeleteAllDO.Name = "buttonDeleteAllDO";
            this.buttonDeleteAllDO.Size = new Size(0x5e, 0x1a);
            this.buttonDeleteAllDO.TabIndex = 0x6f;
            this.buttonDeleteAllDO.Text = "Delete All";
            this.buttonDeleteAllDO.UseVisualStyleBackColor = true;
            this.buttonDeleteAllDO.Click += new EventHandler(this.buttonDeleteAllDO_Click);
            this.tabPageDeduction.BackColor = SystemColors.ButtonFace;
            this.tabPageDeduction.Controls.Add(this.buttonEntryDeduc);
            this.tabPageDeduction.Location = new Point(4, 0x16);
            this.tabPageDeduction.Name = "tabPageDeduction";
            this.tabPageDeduction.Padding = new Padding(3);
            this.tabPageDeduction.Size = new Size(0x2b4, 0xda);
            this.tabPageDeduction.TabIndex = 9;
            this.tabPageDeduction.Text = "Deduction";
            this.buttonEntryDeduc.Location = new Point(0x10, 0x12);
            this.buttonEntryDeduc.Name = "buttonEntryDeduc";
            this.buttonEntryDeduc.Size = new Size(0x87, 0x26);
            this.buttonEntryDeduc.TabIndex = 130;
            this.buttonEntryDeduc.Text = "Entry Unit Deduction\r\nPer Contract\r\n";
            this.buttonEntryDeduc.UseVisualStyleBackColor = true;
            this.buttonEntryDeduc.Click += new EventHandler(this.buttonEntryDeduc_Click);
            this.tabPageQC.BackColor = SystemColors.ButtonFace;
            this.tabPageQC.Controls.Add(this.dgvQC);
            this.tabPageQC.Location = new Point(4, 0x16);
            this.tabPageQC.Name = "tabPageQC";
            this.tabPageQC.Padding = new Padding(3);
            this.tabPageQC.Size = new Size(0x2b4, 0xda);
            this.tabPageQC.TabIndex = 2;
            this.tabPageQC.Text = "Quality Control";
            this.dgvQC.AllowUserToAddRows = false;
            this.dgvQC.AllowUserToDeleteRows = false;
            this.dgvQC.AllowUserToResizeRows = false;
            this.dgvQC.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvQC.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dgvQC.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQC.EditMode = DataGridViewEditMode.EditOnKeystroke;
            this.dgvQC.Location = new Point(9, 9);
            this.dgvQC.MultiSelect = false;
            this.dgvQC.Name = "dgvQC";
            this.dgvQC.SelectionMode = DataGridViewSelectionMode.CellSelect;
            this.dgvQC.Size = new Size(0x296, 0xcb);
            this.dgvQC.TabIndex = 4;
            this.dgvQC.CellEndEdit += new DataGridViewCellEventHandler(this.dgvQC_CellEndEdit);
            this.tabPageFFB.BackColor = SystemColors.ButtonFace;
            this.tabPageFFB.Controls.Add(this.groupFFBReject);
            this.tabPageFFB.Controls.Add(this.groupRV);
            this.tabPageFFB.Controls.Add(this.groupBunch);
            this.tabPageFFB.Location = new Point(4, 0x16);
            this.tabPageFFB.Name = "tabPageFFB";
            this.tabPageFFB.Padding = new Padding(3);
            this.tabPageFFB.Size = new Size(0x2b4, 0xda);
            this.tabPageFFB.TabIndex = 7;
            this.tabPageFFB.Text = "FFB";
            this.groupFFBReject.Controls.Add(this.labelKg);
            this.groupFFBReject.Controls.Add(this.textRejectedFFBKG);
            this.groupFFBReject.Controls.Add(this.textRejectedFFBBunch);
            this.groupFFBReject.Controls.Add(this.labelRejectedFFBReason);
            this.groupFFBReject.Controls.Add(this.labelBunch);
            this.groupFFBReject.Controls.Add(this.textRejectedFFBReason);
            this.groupFFBReject.Controls.Add(this.labelRejectedFFB);
            this.groupFFBReject.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.groupFFBReject.Location = new Point(0x160, 60);
            this.groupFFBReject.Name = "groupFFBReject";
            this.groupFFBReject.Size = new Size(330, 0x4f);
            this.groupFFBReject.TabIndex = 0x8b;
            this.groupFFBReject.TabStop = false;
            this.labelKg.AutoSize = true;
            this.labelKg.Location = new Point(0x12f, 0x16);
            this.labelKg.Name = "labelKg";
            this.labelKg.Size = new Size(20, 15);
            this.labelKg.TabIndex = 0x15;
            this.labelKg.Text = "kg";
            this.textRejectedFFBKG.Location = new Point(0xed, 0x13);
            this.textRejectedFFBKG.MaxLength = 10;
            this.textRejectedFFBKG.Name = "textRejectedFFBKG";
            this.textRejectedFFBKG.Size = new Size(0x41, 20);
            this.textRejectedFFBKG.TabIndex = 20;
            this.textRejectedFFBKG.Text = "0";
            this.textRejectedFFBKG.TextAlign = HorizontalAlignment.Right;
            this.textRejectedFFBBunch.Location = new Point(0x79, 20);
            this.textRejectedFFBBunch.MaxLength = 10;
            this.textRejectedFFBBunch.Name = "textRejectedFFBBunch";
            this.textRejectedFFBBunch.Size = new Size(0x41, 20);
            this.textRejectedFFBBunch.TabIndex = 9;
            this.textRejectedFFBBunch.Text = "0";
            this.textRejectedFFBBunch.TextAlign = HorizontalAlignment.Right;
            this.labelRejectedFFBReason.AutoSize = true;
            this.labelRejectedFFBReason.Location = new Point(10, 0x2e);
            this.labelRejectedFFBReason.Name = "labelRejectedFFBReason";
            this.labelRejectedFFBReason.Size = new Size(50, 15);
            this.labelRejectedFFBReason.TabIndex = 11;
            this.labelRejectedFFBReason.Text = "Reason";
            this.labelRejectedFFBReason.TextAlign = ContentAlignment.MiddleLeft;
            this.labelBunch.AutoSize = true;
            this.labelBunch.Location = new Point(0xbc, 0x17);
            this.labelBunch.Name = "labelBunch";
            this.labelBunch.Size = new Size(0x2a, 15);
            this.labelBunch.TabIndex = 13;
            this.labelBunch.Text = "Bunch";
            this.textRejectedFFBReason.Location = new Point(0x79, 0x2b);
            this.textRejectedFFBReason.MaxLength = 150;
            this.textRejectedFFBReason.Name = "textRejectedFFBReason";
            this.textRejectedFFBReason.Size = new Size(0xc7, 20);
            this.textRejectedFFBReason.TabIndex = 10;
            this.labelRejectedFFB.AutoSize = true;
            this.labelRejectedFFB.Location = new Point(10, 0x16);
            this.labelRejectedFFB.Name = "labelRejectedFFB";
            this.labelRejectedFFB.Size = new Size(0x51, 15);
            this.labelRejectedFFB.TabIndex = 12;
            this.labelRejectedFFB.Text = "Rejected FFB";
            this.labelRejectedFFB.TextAlign = ContentAlignment.MiddleLeft;
            this.groupRV.Controls.Add(this.labelOER);
            this.groupRV.Controls.Add(this.textRendCPO);
            this.groupRV.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.groupRV.Location = new Point(0x160, 6);
            this.groupRV.Name = "groupRV";
            this.groupRV.Size = new Size(330, 0x30);
            this.groupRV.TabIndex = 0x8a;
            this.groupRV.TabStop = false;
            this.labelOER.AutoSize = true;
            this.labelOER.Location = new Point(10, 0x15);
            this.labelOER.Name = "labelOER";
            this.labelOER.Size = new Size(0x21, 15);
            this.labelOER.TabIndex = 0x10;
            this.labelOER.Text = "OER";
            this.textRendCPO.Location = new Point(0x79, 0x12);
            this.textRendCPO.Name = "textRendCPO";
            this.textRendCPO.Size = new Size(0x43, 20);
            this.textRendCPO.TabIndex = 3;
            this.textRendCPO.Text = "0.00";
            this.groupBunch.Controls.Add(this.textBunchTotal);
            this.groupBunch.Controls.Add(this.radioButtonEntryAVG);
            this.groupBunch.Controls.Add(this.textBunchDeduc);
            this.groupBunch.Controls.Add(this.labelTotalBunch);
            this.groupBunch.Controls.Add(this.radioButtonEntryTotalBunch);
            this.groupBunch.Controls.Add(this.labelTotalBunchDeduc);
            this.groupBunch.Controls.Add(this.textAvg);
            this.groupBunch.Controls.Add(this.labelAverageBunch);
            this.groupBunch.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.groupBunch.Location = new Point(10, 6);
            this.groupBunch.Name = "groupBunch";
            this.groupBunch.Size = new Size(0x14f, 0x85);
            this.groupBunch.TabIndex = 0x87;
            this.groupBunch.TabStop = false;
            this.textBunchTotal.Location = new Point(0xd5, 0x2c);
            this.textBunchTotal.MaxLength = 15;
            this.textBunchTotal.Name = "textBunchTotal";
            this.textBunchTotal.Size = new Size(0x39, 20);
            this.textBunchTotal.TabIndex = 0;
            this.textBunchTotal.Text = "0";
            this.textBunchTotal.TextAlign = HorizontalAlignment.Right;
            this.textBunchTotal.Leave += new EventHandler(this.textBunchTotal_Leave);
            this.radioButtonEntryAVG.AutoSize = true;
            this.radioButtonEntryAVG.Location = new Point(0x8e, 14);
            this.radioButtonEntryAVG.Name = "radioButtonEntryAVG";
            this.radioButtonEntryAVG.Size = new Size(0xbf, 0x13);
            this.radioButtonEntryAVG.TabIndex = 0x89;
            this.radioButtonEntryAVG.Text = "Entry Average Weight of Bunch";
            this.radioButtonEntryAVG.UseVisualStyleBackColor = true;
            this.radioButtonEntryAVG.CheckedChanged += new EventHandler(this.radioButtonEntryAVG_CheckedChanged);
            this.textBunchDeduc.Location = new Point(0xd5, 0x45);
            this.textBunchDeduc.MaxLength = 15;
            this.textBunchDeduc.Name = "textBunchDeduc";
            this.textBunchDeduc.Size = new Size(0x39, 20);
            this.textBunchDeduc.TabIndex = 1;
            this.textBunchDeduc.Text = "0";
            this.textBunchDeduc.TextAlign = HorizontalAlignment.Right;
            this.labelTotalBunch.Location = new Point(10, 0x2f);
            this.labelTotalBunch.Name = "labelTotalBunch";
            this.labelTotalBunch.Size = new Size(0xc7, 15);
            this.labelTotalBunch.TabIndex = 5;
            this.labelTotalBunch.Text = "Total Bunch";
            this.labelTotalBunch.TextAlign = ContentAlignment.MiddleRight;
            this.radioButtonEntryTotalBunch.AutoSize = true;
            this.radioButtonEntryTotalBunch.Location = new Point(10, 14);
            this.radioButtonEntryTotalBunch.Name = "radioButtonEntryTotalBunch";
            this.radioButtonEntryTotalBunch.Size = new Size(0x85, 0x13);
            this.radioButtonEntryTotalBunch.TabIndex = 0x88;
            this.radioButtonEntryTotalBunch.Text = "Entry Total of Bunch";
            this.radioButtonEntryTotalBunch.UseVisualStyleBackColor = true;
            this.radioButtonEntryTotalBunch.CheckedChanged += new EventHandler(this.radioButtonEntryTotalBunch_CheckedChanged);
            this.labelTotalBunchDeduc.Location = new Point(10, 0x48);
            this.labelTotalBunchDeduc.Name = "labelTotalBunchDeduc";
            this.labelTotalBunchDeduc.Size = new Size(0xc7, 15);
            this.labelTotalBunchDeduc.TabIndex = 4;
            this.labelTotalBunchDeduc.Text = "Total Bunch for Deduction Calc.";
            this.labelTotalBunchDeduc.TextAlign = ContentAlignment.MiddleRight;
            this.textAvg.Location = new Point(0xd5, 0x5e);
            this.textAvg.MaxLength = 15;
            this.textAvg.Name = "textAvg";
            this.textAvg.Size = new Size(0x39, 20);
            this.textAvg.TabIndex = 2;
            this.textAvg.Text = "0";
            this.textAvg.TextAlign = HorizontalAlignment.Right;
            this.labelAverageBunch.Location = new Point(10, 0x61);
            this.labelAverageBunch.Name = "labelAverageBunch";
            this.labelAverageBunch.Size = new Size(0xc7, 15);
            this.labelAverageBunch.TabIndex = 3;
            this.labelAverageBunch.Text = "Average Weight of Bunch";
            this.labelAverageBunch.TextAlign = ContentAlignment.MiddleRight;
            this.tabPageDivision.BackColor = SystemColors.ButtonFace;
            this.tabPageDivision.Controls.Add(this.buttonDeleteDivision);
            this.tabPageDivision.Controls.Add(this.buttonEditDivision);
            this.tabPageDivision.Controls.Add(this.buttonAddDivision);
            this.tabPageDivision.Controls.Add(this.dgvDivBlock);
            this.tabPageDivision.Location = new Point(4, 0x16);
            this.tabPageDivision.Name = "tabPageDivision";
            this.tabPageDivision.Padding = new Padding(3);
            this.tabPageDivision.Size = new Size(0x2b4, 0xda);
            this.tabPageDivision.TabIndex = 8;
            this.tabPageDivision.Text = "Division";
            this.buttonDeleteDivision.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonDeleteDivision.Location = new Point(8, 0x49);
            this.buttonDeleteDivision.Name = "buttonDeleteDivision";
            this.buttonDeleteDivision.Size = new Size(0x3f, 0x1a);
            this.buttonDeleteDivision.TabIndex = 5;
            this.buttonDeleteDivision.Text = "Delete";
            this.buttonDeleteDivision.UseVisualStyleBackColor = true;
            this.buttonDeleteDivision.Click += new EventHandler(this.buttonDeleteDivision_Click);
            this.buttonEditDivision.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonEditDivision.Location = new Point(8, 0x29);
            this.buttonEditDivision.Name = "buttonEditDivision";
            this.buttonEditDivision.Size = new Size(0x3f, 0x1a);
            this.buttonEditDivision.TabIndex = 4;
            this.buttonEditDivision.Text = "Edit";
            this.buttonEditDivision.UseVisualStyleBackColor = true;
            this.buttonEditDivision.Click += new EventHandler(this.buttonEditDivision_Click);
            this.buttonAddDivision.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonAddDivision.Location = new Point(8, 9);
            this.buttonAddDivision.Name = "buttonAddDivision";
            this.buttonAddDivision.Size = new Size(0x3f, 0x1a);
            this.buttonAddDivision.TabIndex = 3;
            this.buttonAddDivision.Text = "Add ";
            this.buttonAddDivision.UseVisualStyleBackColor = true;
            this.buttonAddDivision.Click += new EventHandler(this.buttonAddDivision_Click);
            this.dgvDivBlock.AllowUserToAddRows = false;
            this.dgvDivBlock.AllowUserToDeleteRows = false;
            this.dgvDivBlock.AllowUserToResizeRows = false;
            this.dgvDivBlock.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDivBlock.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dgvDivBlock.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDivBlock.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvDivBlock.Location = new Point(0x4d, 9);
            this.dgvDivBlock.MultiSelect = false;
            this.dgvDivBlock.Name = "dgvDivBlock";
            this.dgvDivBlock.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDivBlock.Size = new Size(0x253, 0xc0);
            this.dgvDivBlock.TabIndex = 6;
            this.comboBoxRef.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboBoxRef.FormattingEnabled = true;
            this.comboBoxRef.Location = new Point(0x27c, 0x41);
            this.comboBoxRef.Name = "comboBoxRef";
            this.comboBoxRef.Size = new Size(0xdf, 0x15);
            this.comboBoxRef.TabIndex = 0x2c;
            this.comboBoxRef.SelectedIndexChanged += new EventHandler(this.comboBoxRef_SelectedIndexChanged);
            this.labelRef.AutoSize = true;
            this.labelRef.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelRef.Location = new Point(0x1fa, 0x42);
            this.labelRef.Name = "labelRef";
            this.labelRef.Size = new Size(100, 0x11);
            this.labelRef.TabIndex = 0x7d;
            this.labelRef.Text = "Reference No.";
            this.labelRef.TextAlign = ContentAlignment.TopRight;
            this.labelArrow.AutoSize = true;
            this.labelArrow.Font = new Font("Microsoft Sans Serif", 14f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelArrow.Location = new Point(0x362, 0x3e);
            this.labelArrow.Name = "labelArrow";
            this.labelArrow.Size = new Size(30, 0x18);
            this.labelArrow.TabIndex = 0x83;
            this.labelArrow.Text = "↔";
            this.labelArrow.Visible = false;
            this.btn_print.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btn_print.Image = (Image) manager.GetObject("btn_print.Image");
            this.btn_print.ImageAlign = ContentAlignment.MiddleLeft;
            this.btn_print.Location = new Point(0x337, 0x28b);
            this.btn_print.Name = "btn_print";
            this.btn_print.Padding = new Padding(0, 0, 5, 0);
            this.btn_print.Size = new Size(0xa8, 0x25);
            this.btn_print.TabIndex = 0x80;
            this.btn_print.Text = "Submit Gatepass";
            this.btn_print.TextAlign = ContentAlignment.MiddleRight;
            this.btn_print.UseVisualStyleBackColor = true;
            this.btn_print.Click += new EventHandler(this.btn_print_Click);
            this.btn_cancel.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btn_cancel.Image = Resources.cancel_24px;
            this.btn_cancel.ImageAlign = ContentAlignment.MiddleLeft;
            this.btn_cancel.Location = new Point(0x44f, 0x28b);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Padding = new Padding(0, 0, 10, 0);
            this.btn_cancel.Size = new Size(0x6a, 0x25);
            this.btn_cancel.TabIndex = 0x13;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.TextAlign = ContentAlignment.MiddleRight;
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new EventHandler(this.btn_cancel_Click);
            this.btn_save.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btn_save.Image = Resources.Save;
            this.btn_save.ImageAlign = ContentAlignment.MiddleLeft;
            this.btn_save.Location = new Point(0x3e5, 0x28b);
            this.btn_save.Name = "btn_save";
            this.btn_save.Padding = new Padding(5, 0, 10, 0);
            this.btn_save.Size = new Size(100, 0x25);
            this.btn_save.TabIndex = 0x12;
            this.btn_save.Text = "Save";
            this.btn_save.TextAlign = ContentAlignment.MiddleRight;
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new EventHandler(this.btn_save_Click);
            this.labelSplitTrans.AutoSize = true;
            this.labelSplitTrans.Font = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelSplitTrans.Location = new Point(0x279, 0x59);
            this.labelSplitTrans.Name = "labelSplitTrans";
            this.labelSplitTrans.Size = new Size(0x5e, 15);
            this.labelSplitTrans.TabIndex = 0x85;
            this.labelSplitTrans.Text = "Split transaction";
            this.comboBoxRefTemp.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboBoxRefTemp.FormattingEnabled = true;
            this.comboBoxRefTemp.Location = new Point(0x385, 0x42);
            this.comboBoxRefTemp.Name = "comboBoxRefTemp";
            this.comboBoxRefTemp.Size = new Size(0xdf, 0x15);
            this.comboBoxRefTemp.TabIndex = 0x86;
            this.comboBoxRefTemp.Visible = false;
            this.comboBoxRefTemp.SelectedIndexChanged += new EventHandler(this.comboBoxRefTemp_SelectedIndexChanged);
            this.shapeContainer2.Location = new Point(3, 3);
            this.shapeContainer2.Margin = new Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            this.shapeContainer2.Size = new Size(0x37d, 0xcb);
            this.shapeContainer2.TabIndex = 0;
            this.shapeContainer2.TabStop = false;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x4c3, 0x2ba);
            base.ControlBox = false;
            base.Controls.Add(this.comboBoxRefTemp);
            base.Controls.Add(this.labelSplitTrans);
            base.Controls.Add(this.tabControlInformation);
            base.Controls.Add(this.btn_print);
            base.Controls.Add(this.labelArrow);
            base.Controls.Add(this.comboBoxRef);
            base.Controls.Add(this.labelRef);
            base.Controls.Add(this.lbl_reg_date);
            base.Controls.Add(this.groupPhoto);
            base.Controls.Add(this.dtRegistration);
            base.Controls.Add(this.txtRegistrationTime);
            base.Controls.Add(this.lbl_gp_no);
            base.Controls.Add(this.txt_gp_no);
            base.Controls.Add(this.btn_cancel);
            base.Controls.Add(this.btn_save);
            base.Controls.Add(this.grpTruckInfo);
            base.KeyPreview = true;
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormRegisGatepassEntryId";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Gatepass Registration";
            base.Load += new EventHandler(this.FormRegisGatepassEntryId_Load);
            base.Shown += new EventHandler(this.FormRegisGatepassEntryId_Shown);
            this.grpTruckInfo.ResumeLayout(false);
            this.grpTruckInfo.PerformLayout();
            ((ISupportInitialize) this.dgvGPDest).EndInit();
            this.groupPhoto.ResumeLayout(false);
            this.tabControlPhoto.ResumeLayout(false);
            this.tabPageDriverLicenseID.ResumeLayout(false);
            ((ISupportInitialize) this._driverLicense_img).EndInit();
            this.tabPage1st.ResumeLayout(false);
            ((ISupportInitialize) this._1st_cam4).EndInit();
            ((ISupportInitialize) this._1st_cam3).EndInit();
            ((ISupportInitialize) this._1st_cam2).EndInit();
            ((ISupportInitialize) this._1st_cam5).EndInit();
            ((ISupportInitialize) this._1st_cam1).EndInit();
            this.tabPage2nd.ResumeLayout(false);
            ((ISupportInitialize) this._2nd_cam4).EndInit();
            ((ISupportInitialize) this._2nd_cam3).EndInit();
            ((ISupportInitialize) this._2nd_cam2).EndInit();
            ((ISupportInitialize) this._2nd_cam5).EndInit();
            ((ISupportInitialize) this._2nd_cam1).EndInit();
            this.tabPage3rd.ResumeLayout(false);
            ((ISupportInitialize) this._3rd_cam4).EndInit();
            ((ISupportInitialize) this._3rd_cam3).EndInit();
            ((ISupportInitialize) this._3rd_cam2).EndInit();
            ((ISupportInitialize) this._3rd_cam5).EndInit();
            ((ISupportInitialize) this._3rd_cam1).EndInit();
            this.tabPage4th.ResumeLayout(false);
            ((ISupportInitialize) this._4th_cam4).EndInit();
            ((ISupportInitialize) this._4th_cam3).EndInit();
            ((ISupportInitialize) this._4th_cam2).EndInit();
            ((ISupportInitialize) this._4th_cam5).EndInit();
            ((ISupportInitialize) this._4th_cam1).EndInit();
            this.tabPageOP.ResumeLayout(false);
            this.tabPageOP.PerformLayout();
            this.groupOPW.ResumeLayout(false);
            this.groupOPW.PerformLayout();
            this.tabPageGeneral.ResumeLayout(false);
            this.tabPageGeneral.PerformLayout();
            this.panel_return.ResumeLayout(false);
            this.panel_return.PerformLayout();
            ((ISupportInitialize) this.dgvDO).EndInit();
            this.tabControlInformation.ResumeLayout(false);
            this.tabPageCont.ResumeLayout(false);
            this.tabPageCont.PerformLayout();
            ((ISupportInitialize) this.dgvCont).EndInit();
            this.tabPageWBDO.ResumeLayout(false);
            this.tabPageWBDO.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tabPageDeduction.ResumeLayout(false);
            this.tabPageQC.ResumeLayout(false);
            ((ISupportInitialize) this.dgvQC).EndInit();
            this.tabPageFFB.ResumeLayout(false);
            this.groupFFBReject.ResumeLayout(false);
            this.groupFFBReject.PerformLayout();
            this.groupRV.ResumeLayout(false);
            this.groupRV.PerformLayout();
            this.groupBunch.ResumeLayout(false);
            this.groupBunch.PerformLayout();
            this.tabPageDivision.ResumeLayout(false);
            ((ISupportInitialize) this.dgvDivBlock).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void initImage(string mode)
        {
            if ((mode == "ADD") || ((mode == "SUBMIT") && (this.comboBoxRef.Text == "")))
            {
                this._1st_cam1.Image = Resources.NoImage;
                this._1st_cam2.Image = Resources.NoImage;
                this._1st_cam3.Image = Resources.NoImage;
                this._1st_cam4.Image = Resources.NoImage;
                this._1st_cam5.Image = Resources.NoImage;
                this._2nd_cam1.Image = Resources.NoImage;
                this._2nd_cam2.Image = Resources.NoImage;
                this._2nd_cam3.Image = Resources.NoImage;
                this._2nd_cam4.Image = Resources.NoImage;
                this._2nd_cam5.Image = Resources.NoImage;
                this._3rd_cam1.Image = Resources.NoImage;
                this._3rd_cam2.Image = Resources.NoImage;
                this._3rd_cam3.Image = Resources.NoImage;
                this._3rd_cam4.Image = Resources.NoImage;
                this._3rd_cam5.Image = Resources.NoImage;
                this._4th_cam1.Image = Resources.NoImage;
                this._4th_cam2.Image = Resources.NoImage;
                this._4th_cam3.Image = Resources.NoImage;
                this._4th_cam4.Image = Resources.NoImage;
                this._4th_cam5.Image = Resources.NoImage;
                this._driverLicense_img.Image = Resources.NoImage;
            }
            else
            {
                if (((this.comboWX.SelectedValue.ToString() != "0") && (this.comboWX.SelectedValue.ToString() != "1")) && (this.comboWX.SelectedValue.ToString() != "2"))
                {
                    if (this.comboWX.SelectedValue.ToString() == "3")
                    {
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRefTemp.Text, this._1st_cam1, "1ST", "1");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRefTemp.Text, this._1st_cam2, "1ST", "2");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRefTemp.Text, this._1st_cam3, "1ST", "3");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRefTemp.Text, this._1st_cam4, "1ST", "4");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRefTemp.Text, this._1st_cam5, "1ST", "5");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRefTemp.Text, this._2nd_cam1, "2ND", "1");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRefTemp.Text, this._2nd_cam2, "2ND", "2");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRefTemp.Text, this._2nd_cam3, "2ND", "3");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRefTemp.Text, this._2nd_cam4, "2ND", "4");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRefTemp.Text, this._2nd_cam5, "2ND", "5");
                        this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRefTemp.Text, this._3rd_cam1, "3RD", "1");
                        this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRefTemp.Text, this._3rd_cam2, "3RD", "2");
                        this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRefTemp.Text, this._3rd_cam3, "3RD", "3");
                        this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRefTemp.Text, this._3rd_cam4, "3RD", "4");
                        this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRefTemp.Text, this._3rd_cam5, "3RD", "5");
                        this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRefTemp.Text, this._4th_cam1, "4TH", "1");
                        this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRefTemp.Text, this._4th_cam2, "4TH", "2");
                        this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRefTemp.Text, this._4th_cam3, "4TH", "3");
                        this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRefTemp.Text, this._4th_cam4, "4TH", "4");
                        this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRefTemp.Text, this._4th_cam5, "4TH", "5");
                    }
                }
                else
                {
                    this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRef.Text, this._1st_cam1, "1ST", "1");
                    this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRef.Text, this._1st_cam2, "1ST", "2");
                    this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRef.Text, this._1st_cam3, "1ST", "3");
                    this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRef.Text, this._1st_cam4, "1ST", "4");
                    this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRef.Text, this._1st_cam5, "1ST", "5");
                    this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRef.Text, this._2nd_cam1, "2ND", "1");
                    this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRef.Text, this._2nd_cam2, "2ND", "2");
                    this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRef.Text, this._2nd_cam3, "2ND", "3");
                    this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRef.Text, this._2nd_cam4, "2ND", "4");
                    this.camera.loadImageFromServer(this.txt_gp_no.Text, this.comboBoxRef.Text, this._2nd_cam5, "2ND", "5");
                    if (((this.comboWX.SelectedValue.ToString() == "2") && (this.t_trans.DT.Rows.Count > 0)) && (this.t_trans.DT.Rows[0]["report_date"].ToString() != ""))
                    {
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRef.Text, this._3rd_cam1, "3RD", "1");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRef.Text, this._3rd_cam2, "3RD", "2");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRef.Text, this._3rd_cam3, "3RD", "3");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRef.Text, this._3rd_cam4, "3RD", "4");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRef.Text, this._3rd_cam5, "3RD", "5");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRef.Text, this._4th_cam1, "4TH", "1");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRef.Text, this._4th_cam2, "4TH", "2");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRef.Text, this._4th_cam3, "4TH", "3");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRef.Text, this._4th_cam4, "4TH", "4");
                        this.camera.loadImageFromServer(this.linkedGatepass, this.comboBoxRef.Text, this._4th_cam5, "4TH", "5");
                    }
                    else
                    {
                        this._3rd_cam1.Image = Resources.NoImage;
                        this._3rd_cam2.Image = Resources.NoImage;
                        this._3rd_cam3.Image = Resources.NoImage;
                        this._3rd_cam4.Image = Resources.NoImage;
                        this._3rd_cam5.Image = Resources.NoImage;
                        this._4th_cam1.Image = Resources.NoImage;
                        this._4th_cam2.Image = Resources.NoImage;
                        this._4th_cam3.Image = Resources.NoImage;
                        this._4th_cam4.Image = Resources.NoImage;
                        this._4th_cam5.Image = Resources.NoImage;
                    }
                }
                string[] aField = new string[] { "License_No" };
                string[] aFind = new string[] { this.txt_driver_ic.Text.Trim() };
                int recNo = this.t_driver.GetRecNo(aField, aFind);
                if ((recNo > -1) && WBSetting.activeRegistrationRequireLicensePhoto)
                {
                    this.camera.loadImageV2(WBSetting.licensePhoto_path, "LICENSEID_" + this.t_driver.DT.Rows[recNo]["Uniq"].ToString() + ".jpg", this._driverLicense_img);
                }
            }
        }

        private void initTable()
        {
            this.dgvDO.Rows.Clear();
            this.dgvDOCont.Rows.Clear();
            this.dgvQC.Rows.Clear();
            this.dgvCont.Rows.Clear();
            this.dgvGPDest.Rows.Clear();
            this.t_Coy.OpenTable("wb_Company", "Select * from wb_company where Coy_Code = '" + this.cCoy + "'", WBData.conn);
            string[] textArray1 = new string[] { "Select * from wb_location where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "'" };
            this.t_LocationCode.OpenTable("wb_location", string.Concat(textArray1), WBData.conn);
            this.tblgp.OpenTable("wb_gatepass", "select top 1 * from wb_gatepass where gatepass_number = '" + this.gatepassNo + "'", WBData.conn);
            if (((this.pMode == "ADD") || (this.pMode == "SUBMIT")) || (this.pMode == "EDIT_TDT"))
            {
                string[] textArray2 = new string[] { "Select * from wb_truck where Coy = '", this.cCoy, "' and Location_Code = '", this.cLoc, "'" };
                this.t_truck.OpenTable("wb_truck", string.Concat(textArray2), WBData.conn);
            }
            else if (this.tblgp.DT.Rows.Count > 0)
            {
                string[] textArray3 = new string[11];
                textArray3[0] = "select * from wb_truck where Coy = '";
                textArray3[1] = this.cCoy;
                textArray3[2] = "' and Location_Code = '";
                textArray3[3] = this.cLoc;
                textArray3[4] = "' or  (truck_number = '";
                textArray3[5] = this.tblgp.DT.Rows[0]["truck_number"].ToString();
                textArray3[6] = "' and Coy = '";
                textArray3[7] = this.cCoy;
                textArray3[8] = "' and Location_Code = '";
                textArray3[9] = this.cLoc;
                textArray3[10] = "')";
                this.t_truck.OpenTable("wb_truck", string.Concat(textArray3), WBData.conn);
            }
            if (((this.pMode == "ADD") || (this.pMode == "SUBMIT")) || (this.pMode == "EDIT_TDT"))
            {
                string[] textArray4 = new string[] { "SELECT * FROM wb_transporter WHERE Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "'" };
                this.t_transporter.OpenTable("wb_transporter", string.Concat(textArray4), WBData.conn);
            }
            else if (this.tblgp.DT.Rows.Count > 0)
            {
                string[] textArray5 = new string[11];
                textArray5[0] = "SELECT * FROM wb_transporter WHERE Coy = '";
                textArray5[1] = this.cCoy;
                textArray5[2] = "' and Location_code = '";
                textArray5[3] = this.cLoc;
                textArray5[4] = "' or (transporter_code = '";
                textArray5[5] = this.tblgp.DT.Rows[0]["transporter_code"].ToString();
                textArray5[6] = "' and Coy = '";
                textArray5[7] = this.cCoy;
                textArray5[8] = "' and Location_Code = '";
                textArray5[9] = this.cLoc;
                textArray5[10] = "')";
                this.t_transporter.OpenTable("wb_transporter", string.Concat(textArray5), WBData.conn);
            }
            if (((this.pMode == "ADD") || (this.pMode == "SUBMIT")) || (this.pMode == "EDIT_TDT"))
            {
                string[] textArray6 = new string[] { "SELECT * FROM wb_driver WHERE Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "'" };
                this.t_driver.OpenTable("wb_driver", string.Concat(textArray6), WBData.conn);
            }
            else if (this.tblgp.DT.Rows.Count > 0)
            {
                string[] textArray7 = new string[11];
                textArray7[0] = "SELECT * FROM wb_driver WHERE Coy = '";
                textArray7[1] = this.cCoy;
                textArray7[2] = "' and Location_code = '";
                textArray7[3] = this.cLoc;
                textArray7[4] = "' or (license_no = '";
                textArray7[5] = this.tblgp.DT.Rows[0]["license_no"].ToString();
                textArray7[6] = "' and Coy = '";
                textArray7[7] = this.cCoy;
                textArray7[8] = "' and Location_Code = '";
                textArray7[9] = this.cLoc;
                textArray7[10] = "')";
                this.t_driver.OpenTable("wb_driver", string.Concat(textArray7), WBData.conn);
            }
            this.tblgp.Dispose();
            string[] textArray8 = new string[] { "SELECT * FROM wb_tanker WHERE Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "'" };
            this.t_tanker.OpenTable("wb_tanker", string.Concat(textArray8), WBData.conn);
            string[] textArray9 = new string[] { "Select s.checkpoint_code AS source_code, s.description, s.start_multiple, s.end_multiple from wb_checkpoint s, wb_source_mapping m  WHERE s.checkpoint_code = m.source_code  AND Type = 'D'  AND Deleted = 'N'  AND m.Coy = '", this.cCoy, "' and m.Location_code = '", this.cLoc, "'" };
            this.t_Source.OpenTable("wb_source", string.Concat(textArray9), WBData.conn);
            string[] textArray10 = new string[] { "Select * from wb_yield where Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "'" };
            this.tblQC.OpenTable("wb_yield", string.Concat(textArray10), WBData.conn);
            if (((this.pMode != "ADD") || this.isCopied) ? ((this.pMode == "SUBMIT") && (this.txt_gp_no.Text.Trim() == "")) : true)
            {
                string[] textArray11 = new string[] { "SELECT * FROM wb_gatepass WHERE Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' AND 1 = 0" };
                this.t_gatepass.OpenTable("wb_gatepass", string.Concat(textArray11), WBData.conn);
                string[] textArray12 = new string[] { "SELECT * FROM wb_gatepass_destination WHERE Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' AND 1 = 0" };
                this.t_gatepass_dest.OpenTable("wb_gatepass_destination", string.Concat(textArray12), WBData.conn);
                string[] textArray13 = new string[] { "SELECT * FROM wb_transaction WHERE Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' AND 1 = 0" };
                this.t_trans.OpenTable("wb_trans", string.Concat(textArray13), WBData.conn);
                string[] textArray14 = new string[] { "Select * from wb_transDO where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And 1 = 0" };
                this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray14), WBData.conn);
                string[] textArray15 = new string[] { "Select * from wb_TransQC where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And 1 = 0" };
                this.tblTransQC.OpenTable("wb_TransQC", string.Concat(textArray15), WBData.conn);
                string[] textArray16 = new string[] { "Select * from wb_TransContainer where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And 1 = 0" };
                this.tblTransContainer.OpenTable("wb_TransContainer", string.Concat(textArray16), WBData.conn);
                string[] textArray17 = new string[] { "Select * from wb_TransDO_Container where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And 1 = 0" };
                this.tblTransDOContainer.OpenTable("wb_TransDO_Container", string.Concat(textArray17), WBData.conn);
                string[] textArray18 = new string[] { "Select * from wb_TransDivision where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And 1 = 0" };
                this.tblTransDiv.OpenTable("wb_TransDivision", string.Concat(textArray18), WBData.conn);
            }
            else if (((this.pMode != "EDIT") && ((this.pMode != "EDIT_TDT") && (this.pMode != "VIEW"))) && ((this.pMode != "SUBMIT") || (this.txt_gp_no.Text.Trim() == "")))
            {
                if ((this.pMode == "ADD") && this.isCopied)
                {
                    string[] textArray29 = new string[] { "SELECT * FROM wb_gatepass WHERE Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "' AND gatepass_number = '", this.txt_gp_no.Text.Trim(), "'" };
                    this.t_gatepass.OpenTable("wb_gatepass", string.Concat(textArray29), WBData.conn);
                    string[] textArray30 = new string[] { "SELECT * FROM wb_gatepass_destination WHERE Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "' AND gatepass_number = '", this.txt_gp_no.Text.Trim(), "'" };
                    this.t_gatepass_dest.OpenTable("wb_gatepass_destination", string.Concat(textArray30), WBData.conn);
                    string[] textArray31 = new string[] { "SELECT TOP 1 * FROM wb_transaction WHERE Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "' AND gatepass_number = '", this.txt_gp_no.Text.Trim(), "' AND ((Deleted = 'N' OR Deleted = '' OR Deleted IS NULL) OR (Deleted = 'Y' AND cancel_type = 'R')) ORDER BY UNIQ DESC" };
                    this.t_trans.OpenTable("wb_transaction", string.Concat(textArray31), WBData.conn);
                    this.tblTransDO.OpenTable("wb_transDO", "Select * from wb_transDO where 1 = 2", WBData.conn);
                    this.tblTransQC.OpenTable("wb_TransQC", "Select * from wb_TransQC where 1 = 2", WBData.conn);
                    this.tblTransContainer.OpenTable("wb_TransContainer", "Select * from wb_TransContainer where 1 = 2", WBData.conn);
                    this.tblTransDOContainer.OpenTable("wb_TransDO_Container", "Select * from wb_TransDO_Container where 1 = 2", WBData.conn);
                    this.tblTransDiv.OpenTable("wb_TransDivision", "Select * from wb_TransDivision where 1 = 2", WBData.conn);
                }
            }
            else
            {
                string[] textArray19 = new string[] { "SELECT * FROM wb_gatepass WHERE Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "' AND gatepass_number = '", this.txt_gp_no.Text.Trim(), "'" };
                this.t_gatepass.OpenTable("wb_gatepass", string.Concat(textArray19), WBData.conn);
                if (this.t_gatepass.DT.Rows[0]["ref"].ToString() != "")
                {
                    this.initTableTransWithRef();
                }
                else
                {
                    string[] textArray20 = new string[] { "SELECT * FROM wb_gatepass_destination WHERE Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "' AND gatepass_number = '", this.txt_gp_no.Text.Trim(), "'" };
                    this.t_gatepass_dest.OpenTable("wb_gatepass_destination", string.Concat(textArray20), WBData.conn);
                    string[] textArray21 = new string[] { "SELECT * FROM wb_transaction WHERE Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "' AND gatepass_number = '", this.txt_gp_no.Text.Trim(), "' AND ((Deleted = 'N' OR Deleted = '' OR Deleted IS NULL) OR (Deleted = 'Y' AND cancel_type = 'R'))" };
                    this.t_trans.OpenTable("wb_transaction", string.Concat(textArray21), WBData.conn);
                    string[] textArray22 = new string[] { "Select * from wb_transDO where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And gatepass_number = '", this.txt_gp_no.Text.Trim(), "' order by uniq asc" };
                    this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray22), WBData.conn);
                    if (this.tblTransDO.DT.Rows.Count > 0)
                    {
                        string[] textArray23 = new string[] { "Select * from wb_commodity where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And comm_code = '", this.tblTransDO.DT.Rows[0]["Comm_code"].ToString(), "'" };
                        this.tblComm.OpenTable("wb_commodity", string.Concat(textArray23), WBData.conn);
                        if (WBSetting.adopt_zdotrx)
                        {
                            WBCondition condition2 = new WBCondition();
                            DataRow[] rowArray1 = new DataRow[] { this.tblTransDO.DT.Rows[0], this.tblComm.DT.Rows[0] };
                            condition2.fillParameter("ACTIVE_ADOPT_ZDOTRX", rowArray1);
                            if (condition2.getResult())
                            {
                                this.active_zdotrx = true;
                            }
                            condition2.Dispose();
                        }
                        WBCondition condition = new WBCondition();
                        DataRow[] dgRows = new DataRow[] { this.tblTransDO.DT.Rows[0], this.tblComm.DT.Rows[0] };
                        condition.fillParameter("LOCK_DATA_TDT", dgRows);
                        if (condition.getResult())
                        {
                            this.active_lock_TDT = true;
                            this.cBoxDataNotMatch.Visible = true;
                            this.cBoxDataNotMatch.Enabled = true;
                        }
                        condition.Dispose();
                    }
                    string[] textArray24 = new string[] { "Select * from wb_TransQC where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And gatepass_number = '", this.txt_gp_no.Text.Trim(), "'" };
                    this.tblTransQC.OpenTable("wb_TransQC", string.Concat(textArray24), WBData.conn);
                    string[] textArray25 = new string[] { "Select * from wb_TransContainer where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And gatepass_number = '", this.txt_gp_no.Text.Trim(), "'" };
                    this.tblTransContainer.OpenTable("wb_TransContainer", string.Concat(textArray25), WBData.conn);
                    string[] textArray26 = new string[] { "Select * from wb_TransDO_Container where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And gatepass_number = '", this.txt_gp_no.Text.Trim(), "'" };
                    this.tblTransDOContainer.OpenTable("wb_TransDO_Container", string.Concat(textArray26), WBData.conn);
                    string[] textArray27 = new string[] { "SELECT * FROM wb_container_check cc WHERE uniq_transContainer IN (SELECT uniq FROM wb_transContainer WHERE Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And gatepass_number = '", this.txt_gp_no.Text.Trim(), "')" };
                    this.tblContainerCheck.OpenTable("wb_container_check", string.Concat(textArray27), WBData.conn);
                    string[] textArray28 = new string[] { "Select * from wb_TransDivision where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And gatepass_number = '", this.txt_gp_no.Text.Trim(), "'" };
                    this.tblTransDiv.OpenTable("wb_TransDivision", string.Concat(textArray28), WBData.conn);
                }
            }
        }

        private void initTableTransWithRef()
        {
            if (!this.isCopied)
            {
                this.dgvDO.Rows.Clear();
                this.dgvDOCont.Rows.Clear();
                this.dgvQC.Rows.Clear();
                this.dgvCont.Rows.Clear();
                this.dgvGPDest.Rows.Clear();
                this.dgvDivBlock.Rows.Clear();
                if (this.t_gatepass.DT.Rows[0]["WX"].ToString() == "3")
                {
                    string[] textArray1 = new string[] { "SELECT * FROM wb_transaction WHERE Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "' AND ref = '", this.comboBoxRefTemp.Text, "'" };
                    this.t_trans.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
                    string[] textArray2 = new string[] { "SELECT * FROM wb_gatepass_destination WHERE Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And gatepass_number = '", this.txt_gp_no.Text.Trim(), "' " };
                    this.t_gatepass_dest.OpenTable("wb_gatepass_destination", string.Concat(textArray2), WBData.conn);
                    if (this.t_trans.DT.Rows.Count <= 0)
                    {
                        string[] textArray13 = new string[9];
                        textArray13[0] = "Select * from wb_transDO where Coy = '";
                        textArray13[1] = this.cCoy;
                        textArray13[2] = "' AND Location_code = '";
                        textArray13[3] = this.cLoc;
                        textArray13[4] = "' And gatepass_number = '";
                        textArray13[5] = this.txt_gp_no.Text.Trim();
                        textArray13[6] = "' AND ref = '";
                        textArray13[7] = this.comboBoxRef.Text;
                        textArray13[8] = "' order by uniq asc";
                        this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray13), WBData.conn);
                        string[] textArray14 = new string[9];
                        textArray14[0] = "Select * from wb_TransQC where Coy = '";
                        textArray14[1] = this.cCoy;
                        textArray14[2] = "' AND Location_code = '";
                        textArray14[3] = this.cLoc;
                        textArray14[4] = "' And gatepass_number = '";
                        textArray14[5] = this.txt_gp_no.Text.Trim();
                        textArray14[6] = "' AND ref = '";
                        textArray14[7] = this.comboBoxRef.Text;
                        textArray14[8] = "'";
                        this.tblTransQC.OpenTable("wb_TransQC", string.Concat(textArray14), WBData.conn);
                        string[] textArray15 = new string[9];
                        textArray15[0] = "Select * from wb_TransContainer where Coy = '";
                        textArray15[1] = this.cCoy;
                        textArray15[2] = "' AND Location_code = '";
                        textArray15[3] = this.cLoc;
                        textArray15[4] = "' And gatepass_number = '";
                        textArray15[5] = this.txt_gp_no.Text.Trim();
                        textArray15[6] = "' AND ref = '";
                        textArray15[7] = this.comboBoxRef.Text;
                        textArray15[8] = "'";
                        this.tblTransContainer.OpenTable("wb_TransContainer", string.Concat(textArray15), WBData.conn);
                        string[] textArray16 = new string[9];
                        textArray16[0] = "Select * from wb_TransDO_Container where Coy = '";
                        textArray16[1] = this.cCoy;
                        textArray16[2] = "' AND Location_code = '";
                        textArray16[3] = this.cLoc;
                        textArray16[4] = "' And gatepass_number = '";
                        textArray16[5] = this.txt_gp_no.Text.Trim();
                        textArray16[6] = "' AND ref = '";
                        textArray16[7] = this.comboBoxRef.Text;
                        textArray16[8] = "'";
                        this.tblTransDOContainer.OpenTable("wb_TransDO_Container", string.Concat(textArray16), WBData.conn);
                        string[] textArray17 = new string[9];
                        textArray17[0] = "Select * from wb_TransDivision where Coy = '";
                        textArray17[1] = this.cCoy;
                        textArray17[2] = "' AND Location_code = '";
                        textArray17[3] = this.cLoc;
                        textArray17[4] = "' And gatepass_number = '";
                        textArray17[5] = this.txt_gp_no.Text.Trim();
                        textArray17[6] = "' AND ref = '";
                        textArray17[7] = this.comboBoxRef.Text;
                        textArray17[8] = "'";
                        this.tblTransDiv.OpenTable("wb_TransDivision", string.Concat(textArray17), WBData.conn);
                    }
                    else if (this.t_trans.DT.Rows[0]["report_date"].ToString() == "")
                    {
                        string[] textArray3 = new string[] { "Select * from wb_transDO where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' AND ref like '", this.comboBoxRefTemp.Text, "%' order by uniq asc" };
                        this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray3), WBData.conn);
                        string[] textArray4 = new string[] { "Select * from wb_TransQC where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' AND ref like '", this.comboBoxRefTemp.Text, "%'" };
                        this.tblTransQC.OpenTable("wb_TransQC", string.Concat(textArray4), WBData.conn);
                        string[] textArray5 = new string[] { "Select * from wb_TransContainer where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' AND ref like '", this.comboBoxRefTemp.Text, "%'" };
                        this.tblTransContainer.OpenTable("wb_TransContainer", string.Concat(textArray5), WBData.conn);
                        string[] textArray6 = new string[] { "Select * from wb_TransDO_Container where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' AND ref like '", this.comboBoxRefTemp.Text, "%'" };
                        this.tblTransDOContainer.OpenTable("wb_TransDO_Container", string.Concat(textArray6), WBData.conn);
                        string[] textArray7 = new string[] { "Select * from wb_TransDivision where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' AND ref like '", this.comboBoxRefTemp.Text, "%'" };
                        this.tblTransDiv.OpenTable("wb_TransDivision", string.Concat(textArray7), WBData.conn);
                    }
                    else
                    {
                        string[] textArray8 = new string[] { "Select * from wb_transDO where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' AND ref = '", this.comboBoxRefTemp.Text, "' order by uniq asc" };
                        this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray8), WBData.conn);
                        string[] textArray9 = new string[] { "Select * from wb_TransQC where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' AND ref = '", this.comboBoxRefTemp.Text, "'" };
                        this.tblTransQC.OpenTable("wb_TransQC", string.Concat(textArray9), WBData.conn);
                        string[] textArray10 = new string[] { "Select * from wb_TransContainer where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' AND ref = '", this.comboBoxRefTemp.Text, "'" };
                        this.tblTransContainer.OpenTable("wb_TransContainer", string.Concat(textArray10), WBData.conn);
                        string[] textArray11 = new string[] { "Select * from wb_TransDO_Container where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' AND ref = '", this.comboBoxRefTemp.Text, "'" };
                        this.tblTransDOContainer.OpenTable("wb_TransDO_Container", string.Concat(textArray11), WBData.conn);
                        string[] textArray12 = new string[] { "Select * from wb_TransDivision where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' AND ref = '", this.comboBoxRefTemp.Text, "'" };
                        this.tblTransDiv.OpenTable("wb_TransDivision", string.Concat(textArray12), WBData.conn);
                    }
                }
                else
                {
                    string[] textArray18 = new string[9];
                    textArray18[0] = "SELECT * FROM wb_transaction WHERE Coy = '";
                    textArray18[1] = this.cCoy;
                    textArray18[2] = "' and Location_code = '";
                    textArray18[3] = this.cLoc;
                    textArray18[4] = "' AND gatepass_number = '";
                    textArray18[5] = this.txt_gp_no.Text.Trim();
                    textArray18[6] = "' AND ref = '";
                    textArray18[7] = this.comboBoxRef.Text;
                    textArray18[8] = "'";
                    this.t_trans.OpenTable("wb_transaction", string.Concat(textArray18), WBData.conn);
                    string[] textArray19 = new string[] { "SELECT * FROM wb_gatepass_destination WHERE Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And gatepass_number = '", this.txt_gp_no.Text.Trim(), "' " };
                    this.t_gatepass_dest.OpenTable("wb_gatepass_destination", string.Concat(textArray19), WBData.conn);
                    if (this.t_trans.DT.Rows.Count <= 0)
                    {
                        string[] textArray31 = new string[9];
                        textArray31[0] = "Select * from wb_transDO where Coy = '";
                        textArray31[1] = this.cCoy;
                        textArray31[2] = "' AND Location_code = '";
                        textArray31[3] = this.cLoc;
                        textArray31[4] = "' And gatepass_number = '";
                        textArray31[5] = this.txt_gp_no.Text.Trim();
                        textArray31[6] = "' AND ref = '";
                        textArray31[7] = this.comboBoxRef.Text;
                        textArray31[8] = "' order by uniq asc";
                        this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray31), WBData.conn);
                        string[] textArray32 = new string[9];
                        textArray32[0] = "Select * from wb_TransQC where Coy = '";
                        textArray32[1] = this.cCoy;
                        textArray32[2] = "' AND Location_code = '";
                        textArray32[3] = this.cLoc;
                        textArray32[4] = "' And gatepass_number = '";
                        textArray32[5] = this.txt_gp_no.Text.Trim();
                        textArray32[6] = "' AND ref = '";
                        textArray32[7] = this.comboBoxRef.Text;
                        textArray32[8] = "'";
                        this.tblTransQC.OpenTable("wb_TransQC", string.Concat(textArray32), WBData.conn);
                        string[] textArray33 = new string[9];
                        textArray33[0] = "Select * from wb_TransContainer where Coy = '";
                        textArray33[1] = this.cCoy;
                        textArray33[2] = "' AND Location_code = '";
                        textArray33[3] = this.cLoc;
                        textArray33[4] = "' And gatepass_number = '";
                        textArray33[5] = this.txt_gp_no.Text.Trim();
                        textArray33[6] = "' AND ref = '";
                        textArray33[7] = this.comboBoxRef.Text;
                        textArray33[8] = "'";
                        this.tblTransContainer.OpenTable("wb_TransContainer", string.Concat(textArray33), WBData.conn);
                        string[] textArray34 = new string[9];
                        textArray34[0] = "Select * from wb_TransDO_Container where Coy = '";
                        textArray34[1] = this.cCoy;
                        textArray34[2] = "' AND Location_code = '";
                        textArray34[3] = this.cLoc;
                        textArray34[4] = "' And gatepass_number = '";
                        textArray34[5] = this.txt_gp_no.Text.Trim();
                        textArray34[6] = "' AND ref = '";
                        textArray34[7] = this.comboBoxRef.Text;
                        textArray34[8] = "'";
                        this.tblTransDOContainer.OpenTable("wb_TransDO_Container", string.Concat(textArray34), WBData.conn);
                        string[] textArray35 = new string[9];
                        textArray35[0] = "Select * from wb_TransDivision where Coy = '";
                        textArray35[1] = this.cCoy;
                        textArray35[2] = "' AND Location_code = '";
                        textArray35[3] = this.cLoc;
                        textArray35[4] = "' And gatepass_number = '";
                        textArray35[5] = this.txt_gp_no.Text.Trim();
                        textArray35[6] = "' AND ref = '";
                        textArray35[7] = this.comboBoxRef.Text;
                        textArray35[8] = "'";
                        this.tblTransDiv.OpenTable("wb_TransDivision", string.Concat(textArray35), WBData.conn);
                    }
                    else
                    {
                        string[] textArray20 = new string[] { "Select * from wb_commodity where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And comm_code = '", this.t_trans.DT.Rows[0]["Comm_code"].ToString(), "'" };
                        this.tblComm.OpenTable("wb_commodity", string.Concat(textArray20), WBData.conn);
                        if (WBSetting.adopt_zdotrx)
                        {
                            WBCondition condition2 = new WBCondition();
                            DataRow[] rowArray1 = new DataRow[] { this.t_trans.DT.Rows[0], this.tblComm.DT.Rows[0] };
                            condition2.fillParameter("ACTIVE_ADOPT_ZDOTRX", rowArray1);
                            if (condition2.getResult())
                            {
                                this.active_zdotrx = true;
                            }
                            condition2.Dispose();
                        }
                        WBCondition condition = new WBCondition();
                        DataRow[] dgRows = new DataRow[] { this.t_trans.DT.Rows[0], this.tblComm.DT.Rows[0] };
                        condition.fillParameter("LOCK_DATA_TDT", dgRows);
                        if (condition.getResult())
                        {
                            this.active_lock_TDT = true;
                            this.cBoxDataNotMatch.Visible = true;
                            this.cBoxDataNotMatch.Enabled = true;
                        }
                        condition.Dispose();
                        if (this.t_trans.DT.Rows[0]["report_date"].ToString() == "")
                        {
                            string[] textArray21 = new string[9];
                            textArray21[0] = "Select * from wb_transDO where Coy = '";
                            textArray21[1] = this.cCoy;
                            textArray21[2] = "' AND Location_code = '";
                            textArray21[3] = this.cLoc;
                            textArray21[4] = "' And gatepass_number = '";
                            textArray21[5] = this.txt_gp_no.Text.Trim();
                            textArray21[6] = "' AND ref like '";
                            textArray21[7] = this.comboBoxRef.Text;
                            textArray21[8] = "%' order by uniq asc";
                            this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray21), WBData.conn);
                            string[] textArray22 = new string[9];
                            textArray22[0] = "Select * from wb_TransQC where Coy = '";
                            textArray22[1] = this.cCoy;
                            textArray22[2] = "' AND Location_code = '";
                            textArray22[3] = this.cLoc;
                            textArray22[4] = "' And gatepass_number = '";
                            textArray22[5] = this.txt_gp_no.Text.Trim();
                            textArray22[6] = "' AND ref like '";
                            textArray22[7] = this.comboBoxRef.Text;
                            textArray22[8] = "%'";
                            this.tblTransQC.OpenTable("wb_TransQC", string.Concat(textArray22), WBData.conn);
                            string[] textArray23 = new string[9];
                            textArray23[0] = "Select * from wb_TransContainer where Coy = '";
                            textArray23[1] = this.cCoy;
                            textArray23[2] = "' AND Location_code = '";
                            textArray23[3] = this.cLoc;
                            textArray23[4] = "' And gatepass_number = '";
                            textArray23[5] = this.txt_gp_no.Text.Trim();
                            textArray23[6] = "' AND ref like '";
                            textArray23[7] = this.comboBoxRef.Text;
                            textArray23[8] = "%'";
                            this.tblTransContainer.OpenTable("wb_TransContainer", string.Concat(textArray23), WBData.conn);
                            string[] textArray24 = new string[9];
                            textArray24[0] = "Select * from wb_TransDO_Container where Coy = '";
                            textArray24[1] = this.cCoy;
                            textArray24[2] = "' AND Location_code = '";
                            textArray24[3] = this.cLoc;
                            textArray24[4] = "' And gatepass_number = '";
                            textArray24[5] = this.txt_gp_no.Text.Trim();
                            textArray24[6] = "' AND ref like '";
                            textArray24[7] = this.comboBoxRef.Text;
                            textArray24[8] = "%'";
                            this.tblTransDOContainer.OpenTable("wb_TransDO_Container", string.Concat(textArray24), WBData.conn);
                            string[] textArray25 = new string[9];
                            textArray25[0] = "Select * from wb_TransDivision where Coy = '";
                            textArray25[1] = this.cCoy;
                            textArray25[2] = "' AND Location_code = '";
                            textArray25[3] = this.cLoc;
                            textArray25[4] = "' And gatepass_number = '";
                            textArray25[5] = this.txt_gp_no.Text.Trim();
                            textArray25[6] = "' AND ref like '";
                            textArray25[7] = this.comboBoxRef.Text;
                            textArray25[8] = "%'";
                            this.tblTransDiv.OpenTable("wb_TransDivision", string.Concat(textArray25), WBData.conn);
                        }
                        else
                        {
                            string[] textArray26 = new string[9];
                            textArray26[0] = "Select * from wb_transDO where Coy = '";
                            textArray26[1] = this.cCoy;
                            textArray26[2] = "' AND Location_code = '";
                            textArray26[3] = this.cLoc;
                            textArray26[4] = "' And gatepass_number = '";
                            textArray26[5] = this.txt_gp_no.Text.Trim();
                            textArray26[6] = "' AND ref = '";
                            textArray26[7] = this.comboBoxRef.Text;
                            textArray26[8] = "' order by uniq asc";
                            this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray26), WBData.conn);
                            string[] textArray27 = new string[9];
                            textArray27[0] = "Select * from wb_TransQC where Coy = '";
                            textArray27[1] = this.cCoy;
                            textArray27[2] = "' AND Location_code = '";
                            textArray27[3] = this.cLoc;
                            textArray27[4] = "' And gatepass_number = '";
                            textArray27[5] = this.txt_gp_no.Text.Trim();
                            textArray27[6] = "' AND ref = '";
                            textArray27[7] = this.comboBoxRef.Text;
                            textArray27[8] = "'";
                            this.tblTransQC.OpenTable("wb_TransQC", string.Concat(textArray27), WBData.conn);
                            string[] textArray28 = new string[9];
                            textArray28[0] = "Select * from wb_TransContainer where Coy = '";
                            textArray28[1] = this.cCoy;
                            textArray28[2] = "' AND Location_code = '";
                            textArray28[3] = this.cLoc;
                            textArray28[4] = "' And gatepass_number = '";
                            textArray28[5] = this.txt_gp_no.Text.Trim();
                            textArray28[6] = "' AND ref = '";
                            textArray28[7] = this.comboBoxRef.Text;
                            textArray28[8] = "'";
                            this.tblTransContainer.OpenTable("wb_TransContainer", string.Concat(textArray28), WBData.conn);
                            string[] textArray29 = new string[9];
                            textArray29[0] = "Select * from wb_TransDO_Container where Coy = '";
                            textArray29[1] = this.cCoy;
                            textArray29[2] = "' AND Location_code = '";
                            textArray29[3] = this.cLoc;
                            textArray29[4] = "' And gatepass_number = '";
                            textArray29[5] = this.txt_gp_no.Text.Trim();
                            textArray29[6] = "' AND ref = '";
                            textArray29[7] = this.comboBoxRef.Text;
                            textArray29[8] = "'";
                            this.tblTransDOContainer.OpenTable("wb_TransDO_Container", string.Concat(textArray29), WBData.conn);
                            string[] textArray30 = new string[9];
                            textArray30[0] = "Select * from wb_TransDivision where Coy = '";
                            textArray30[1] = this.cCoy;
                            textArray30[2] = "' AND Location_code = '";
                            textArray30[3] = this.cLoc;
                            textArray30[4] = "' And gatepass_number = '";
                            textArray30[5] = this.txt_gp_no.Text.Trim();
                            textArray30[6] = "' AND ref = '";
                            textArray30[7] = this.comboBoxRef.Text;
                            textArray30[8] = "'";
                            this.tblTransDiv.OpenTable("wb_TransDivision", string.Concat(textArray30), WBData.conn);
                        }
                    }
                }
            }
        }

        private void insertToQueueTCS()
        {
            if (this.oldDestination != null)
            {
                int index = 0;
                while (true)
                {
                    if (index >= this.oldDestination.Length)
                    {
                        break;
                    }
                    bool flag2 = false;
                    foreach (DataGridViewRow row in (IEnumerable) this.dgvGPDest.Rows)
                    {
                        if (this.oldDestination[index] == row.Cells["source_code"].Value.ToString())
                        {
                            flag2 = true;
                            break;
                        }
                    }
                    if (!flag2)
                    {
                        WBQueue.deleteFromQueue(this.gatepassNo, this.oldDestination[index]);
                    }
                    index++;
                }
            }
            foreach (DataGridViewRow row2 in (IEnumerable) this.dgvGPDest.Rows)
            {
                bool flag6 = false;
                if (this.oldDestination != null)
                {
                    int index = 0;
                    while (true)
                    {
                        if (index < this.oldDestination.Length)
                        {
                            if (row2.Cells["source_code"].Value.ToString() != this.oldDestination[index])
                            {
                                index++;
                                continue;
                            }
                            flag6 = true;
                        }
                        break;
                    }
                }
                if (!flag6)
                {
                    WBQueue.insertToQueue(this.gatepassNo, row2.Cells["source_code"].Value.ToString());
                }
            }
        }

        public void load_detail()
        {
        }

        public void load_image(PictureBox video_panel, string mode, string cam)
        {
            try
            {
                string[] textArray1 = new string[] { this.comboBoxRef.Text, "_", mode.Substring(0, 1), "_", cam, ".jpg" };
                video_panel.Image = Image.FromFile(WBSetting.camera_path + string.Concat(textArray1));
            }
            catch (Exception)
            {
                video_panel.Image = Resources.NoImage;
            }
        }

        private void preview_img(PictureBox video_panel, int camera_no)
        {
            if (!ReferenceEquals(video_panel.Image, null))
            {
                FormCameraPreview preview = new FormCameraPreview {
                    camera_type = "PREVIEW_IMAGE",
                    pic_box = { Image = video_panel.Image }
                };
                preview.ShowDialog();
                preview.Dispose();
            }
        }

        private void print(string gatepass, DataSet ds, ReportDocument cryRpt, bool cek)
        {
            string[] strArray = new string[2];
            string[] strArray2 = new string[] { gatepass, WBUser.UserName };
            strArray[0] = "gatepass";
            strArray[1] = "user";
            cryRpt.Refresh();
            cryRpt.DataSourceConnections.Clear();
            cryRpt.SetDataSource(ds);
            this.fRpt.setReport(cryRpt);
            if (WBSetting.sCheckDirect == "Y")
            {
                this.updatePrinted("", gatepass, cek);
                cryRpt.PrintToPrinter(1, false, 0, 0);
            }
            else
            {
                this.fRpt.setDoPrint(false);
                this.fRpt.ShowDialog();
                if (this.fRpt.doPrint)
                {
                    this.updatePrinted("", gatepass, cek);
                    cryRpt.PrintToPrinter(1, true, 0, 0);
                }
            }
        }

        private void print(string refno, string Do_No, ReportDocument cryRpt, bool cek)
        {
            string[] paramName = new string[4];
            string[] paramValue = new string[] { refno, Do_No, WBUser.UserName, Program.getSplitGross(refno) };
            paramName[0] = "ref";
            paramName[1] = "Do_No";
            paramName[2] = "user";
            paramName[3] = "Total_Split_DO";
            cryRpt.Refresh();
            cryRpt = Program.setParam2(cryRpt, paramName, paramValue);
            this.fRpt.setReport(cryRpt);
            if (WBSetting.sCheckDirect == "Y")
            {
                this.updatePrinted(refno, "", cek);
                cryRpt.PrintToPrinter(1, false, 0, 0);
            }
            else
            {
                this.fRpt.setDoPrint(false);
                this.fRpt.ShowDialog();
                if (this.fRpt.doPrint)
                {
                    this.updatePrinted(refno, "", cek);
                    cryRpt.PrintToPrinter(1, true, 0, 0);
                }
            }
        }

        private void radioButtonEntryAVG_CheckedChanged(object sender, EventArgs e)
        {
            this.checkEntryAVGorTotalBunch();
        }

        private void radioButtonEntryTotalBunch_CheckedChanged(object sender, EventArgs e)
        {
            this.checkEntryAVGorTotalBunch();
        }

        private void resetDataForContOut()
        {
            this.checkEstate.Checked = false;
            this.txt_deli_note.Text = "";
            this.txt_seal.Text = "";
            this.textRemarkTicket.Text = "";
            this.textRemarkReport.Text = "";
            this.txtAddInfo.Text = "";
            this.textPL3.Text = "";
            this.chk_return.Checked = false;
            this.text_ref_return.Text = "";
            this.checkNOPW.Checked = false;
            this.textWBNo.Text = "";
            this.TimeDelivery.Text = "";
            this.textGrossEstate.Text = "0";
            this.textTareEstate.Text = "0";
            this.textNetEstate.Text = "0";
            this.dgvCont.Rows.Clear();
            this.dgvDO.Rows.Clear();
            this.dgvDOCont.Rows.Clear();
            this.dgvQC.Rows.Clear();
            this.dgvDivBlock.Rows.Clear();
        }

        private void setOtherParty()
        {
            if (!this.checkNOPW.Checked)
            {
                this.groupOPW.Enabled = true;
            }
            else
            {
                this.textWBNo.Text = "";
                this.textGrossEstate.Text = "0";
                this.textTareEstate.Text = "0";
                this.textNetEstate.Text = "0";
                this.groupOPW.Enabled = false;
                foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
                {
                    row.Cells["estate_qty"].Value = "0";
                }
            }
        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void tabPageShow(string pCommType, TabPage shownPage)
        {
            if (this.tabControlInformation.TabPages.IndexOf(this.tabPageFFB) >= 0)
            {
                this.tabControlInformation.TabPages.Remove(this.tabPageFFB);
            }
            if (this.tabControlInformation.TabPages.IndexOf(this.tabPageDivision) >= 0)
            {
                this.tabControlInformation.TabPages.Remove(this.tabPageDivision);
            }
            if (pCommType == "S")
            {
                if (this.tabControlInformation.TabPages.IndexOf(this.tabPageFFB) >= 0)
                {
                    this.tabControlInformation.TabPages.Remove(this.tabPageFFB);
                }
                if (this.tabControlInformation.TabPages.IndexOf(this.tabPageDivision) >= 0)
                {
                    this.tabControlInformation.TabPages.Remove(this.tabPageDivision);
                }
                if (this.tabControlInformation.TabPages.IndexOf(this.tabPageQC) < 0)
                {
                    this.tabControlInformation.TabPages.Add(this.tabPageQC);
                }
                this.tabControlInformation.SelectedTab = shownPage;
            }
            else if (pCommType == "F")
            {
                if (this.tabControlInformation.TabPages.IndexOf(this.tabPageQC) >= 0)
                {
                    this.tabControlInformation.TabPages.Remove(this.tabPageQC);
                }
                if (this.tabControlInformation.TabPages.IndexOf(this.tabPageFFB) < 0)
                {
                    this.tabControlInformation.TabPages.Add(this.tabPageFFB);
                }
                if (this.tabControlInformation.TabPages.IndexOf(this.tabPageDivision) < 0)
                {
                    this.tabControlInformation.TabPages.Add(this.tabPageDivision);
                }
                this.tabControlInformation.SelectedTab = shownPage;
            }
        }

        private void text_ref_return_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBunchTotal_Leave(object sender, EventArgs e)
        {
            if ((this.textBunchDeduc.Text.Trim() == "0") || (this.textBunchDeduc.Text.Trim() == ""))
            {
                this.textBunchDeduc.Text = this.textBunchTotal.Text;
            }
        }

        private void textCardNo_Enter(object sender, EventArgs e)
        {
            this.textCardNo.SelectAll();
        }

        private void textCardNo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string pMode = this.pMode;
                this.uniqCardNo = this.textCardNo.Text;
                Tuple<bool, string, string, string, string, string, string> tuple = WBCard.scanCard(this.textCardNo.Text, pMode, this.txt_gp_no.Text);
                this.scanStatus = tuple.Item1;
                this.labelScanMessage.Text = tuple.Item2;
                this.cardNo = this.textCardNo.Text.ToUpper();
                this.textCardNo.Text = tuple.Item7.ToUpper();
                if (!this.scanStatus)
                {
                    this.labelScanMessage.ForeColor = Color.Red;
                }
                else
                {
                    if (this.pMode != "SUBMIT")
                    {
                        this.comboWX.Focus();
                    }
                    else
                    {
                        Cursor.Current = Cursors.WaitCursor;
                        this.pUniq = tuple.Item6;
                        this.txt_gp_no.Text = tuple.Item4;
                        this.gatepassNo = tuple.Item4;
                        this.firstload = true;
                        this.loadAfterScanCardForSubmit = true;
                        this.f_load();
                        this.loadAfterScanCardForSubmit = false;
                        this.scanStatus = true;
                        this.labelScanMessage.Text = tuple.Item2;
                        if (!this.can_submit())
                        {
                            base.Close();
                        }
                        this.btn_print.Focus();
                        Cursor.Current = Cursors.Default;
                    }
                    this.labelScanMessage.Text = "OK";
                    this.labelScanMessage.ForeColor = Color.Black;
                }
                this.textCardNo.SelectAll();
            }
        }

        private void textCardNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textCardNo_Leave(object sender, EventArgs e)
        {
            if ((WBCard.getUniqCardNo(this.textCardNo.Text.Trim()) == this.uniqCardNo) && (this.pMode == "EDIT"))
            {
                this.scanStatus = true;
            }
        }

        private void textCardNo_MouseEnter(object sender, EventArgs e)
        {
            this.textCardNo.SelectAll();
        }

        private void textCardNo_TextChanged(object sender, EventArgs e)
        {
            if ((WBCard.getUniqCardNo(this.textCardNo.Text.Trim()) != this.cardNo) && this.scanStatus)
            {
                this.scanStatus = false;
                this.labelScanMessage.Text = "";
            }
        }

        private void textDestination_Leave(object sender, EventArgs e)
        {
        }

        private void textDestination_Leave_1(object sender, EventArgs e)
        {
            if (this.textDestination.Text.Trim() != "")
            {
                this.t_Source.ReOpen();
                string[] aField = new string[] { "Description" };
                string[] aFind = new string[] { this.textDestination.Text.Trim() };
                int recNo = this.t_Source.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.textDestination.Text = this.t_Source.DT.Rows[recNo]["Description"].ToString().Trim();
                    this.labelDestinationCode.Text = this.t_Source.DT.Rows[recNo]["Source_Code"].ToString().Trim();
                }
                else
                {
                    MessageBox.Show("Destination is not found! Please recheck destination!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.textDestination.Focus();
                    this.labelDestinationCode.Text = "";
                    this.buttonDestination.PerformClick();
                }
            }
        }

        private void textDriverName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDriverName_Leave(object sender, EventArgs e)
        {
            if (this.textDriverName.Text.Trim() != "")
            {
                this.t_driver.ReOpen();
                int recNo = 0;
                if (string.IsNullOrEmpty(this.txt_driver_ic.Text))
                {
                    string[] aField = new string[] { "Name" };
                    string[] aFind = new string[] { this.textDriverName.Text.Trim() };
                    recNo = this.t_driver.GetRecNo(aField, aFind);
                }
                else
                {
                    string[] aField = new string[] { "Name", "License_no" };
                    string[] aFind = new string[] { this.textDriverName.Text.Trim(), this.txt_driver_ic.Text.Trim() };
                    recNo = this.t_driver.GetRecNo(aField, aFind);
                }
                if (recNo <= -1)
                {
                    this.txt_driver_ic.Text = "";
                    this.buttonDriver.PerformClick();
                    this.txt_driver_ic.Focus();
                }
                else
                {
                    this.txt_driver_ic.Text = this.t_driver.DT.Rows[recNo]["License_No"].ToString();
                    this.textDriverName.Text = this.t_driver.DT.Rows[recNo]["Name"].ToString();
                    if ((this.pMode != "EDIT") && (this.pMode != "EDIT_TDT"))
                    {
                        if (this.pMode == "ADD")
                        {
                            string str3 = "";
                            string str4 = "";
                            WBTable table2 = new WBTable();
                            string[] textArray6 = new string[] { "SELECT * FROM wb_driver WHERE uniq = '", this.t_driver.DT.Rows[recNo]["uniq"].ToString(), "' AND Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "'" };
                            table2.OpenTable("wb_driver", string.Concat(textArray6), WBData.conn);
                            str3 = table2.DT.Rows[0]["Black_List"].ToString();
                            str4 = table2.DT.Rows[0]["deleted"].ToString();
                            table2.Dispose();
                            if (str4 != "Y")
                            {
                                if (str3 == "Y")
                                {
                                    MessageBox.Show(Resource.Mes_610, Resource.Title_002);
                                    this.textDriverName.Focus();
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_627, Resource.Title_002);
                                this.textDriverName.Focus();
                                return;
                            }
                        }
                    }
                    else if (this.oldDriverName != this.textDriverName.Text.Trim())
                    {
                        string str = "";
                        string str2 = "";
                        WBTable table = new WBTable();
                        string[] textArray5 = new string[] { "SELECT * FROM wb_driver WHERE uniq = '", this.t_driver.DT.Rows[recNo]["uniq"].ToString(), "' AND Coy = '", this.cCoy, "' and Location_code = '", this.cLoc, "'" };
                        table.OpenTable("wb_driver", string.Concat(textArray5), WBData.conn);
                        str = table.DT.Rows[0]["Black_List"].ToString();
                        str2 = table.DT.Rows[0]["deleted"].ToString();
                        table.Dispose();
                        if (str2 != "Y")
                        {
                            if (str == "Y")
                            {
                                MessageBox.Show(Resource.Mes_610, Resource.Title_002);
                                this.textDriverName.Focus();
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_627, Resource.Title_002);
                            this.textDriverName.Focus();
                            return;
                        }
                    }
                    this.txt_driver_ic.Text = this.t_driver.DT.Rows[recNo]["License_No"].ToString();
                    this.textDriverName.Text = this.t_driver.DT.Rows[recNo]["Name"].ToString();
                    if ((this.dgvCont.Rows.Count == 0) && this.check_driver_inyard(this.txt_driver_ic.Text))
                    {
                        this.textDriverName.SelectAll();
                        this.textDriverName.Focus();
                    }
                    else if (this.txt_driver_ic.Text.Trim() == "")
                    {
                        this.txt_driver_ic.Text = this.t_driver.DT.Rows[recNo]["Truck_Number"].ToString();
                        this.txt_driver_ic.Focus();
                    }
                }
            }
        }

        private void textDriverName_TextChanged(object sender, EventArgs e)
        {
            if ((this.readoptInternalNumber || this.changeLoadingNote) ? (this.comboBoxRef.Items.Count == 0) : false)
            {
                this.changeTDT = true;
            }
        }

        private void textGrossEstate_KeyPress(object sender, KeyPressEventArgs e)
        {
            bool flag = true;
            if (((e.KeyChar < '0') || (e.KeyChar > '9')) ? (e.KeyChar == '\b') : true)
            {
                flag = false;
            }
            e.Handled = flag;
        }

        private void textGrossEstate_Leave(object sender, EventArgs e)
        {
            this.HitNetEstate();
        }

        private void textRemarkReport_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textRemarkTicket_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTanker_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTanker_Leave(object sender, EventArgs e)
        {
            this.t_tanker.ReOpen();
            string[] aField = new string[] { "Tanker_No" };
            string[] aFind = new string[] { this.textTanker.Text.Trim() };
            int recNo = this.t_tanker.GetRecNo(aField, aFind);
            if (recNo > -1)
            {
                this.textTanker.Text = this.t_tanker.DT.Rows[recNo]["Tanker_No"].ToString().Trim();
            }
        }

        private void textTareEstate_Leave(object sender, EventArgs e)
        {
            this.HitNetEstate();
        }

        private void textTrailerNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textWBNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.lbl_gp_no.Text = Resource.Gatepass_001;
            this.lbl_reg_date.Text = Resource.Gatepass_069;
            this.btn_print.Text = Resource.Gatepass_016;
            this.btn_save.Text = Resource.Gatepass_048;
            this.btn_cancel.Text = Resource.Gatepass_036;
            this.grpTruckInfo.Text = Resource.RegisGatepassEntry_003;
            this.labelCardNo.Text = Resource.Gatepass_056;
            this.labelDestination.Text = Resource.RegisGatepassEntry_004;
            this.labelWX.Text = Resource.RegisGatepassEntry_005;
            this.labelTruckNo.Text = Resource.Gatepass_003;
            this.labelTransporter.Text = Resource.Gatepass_002;
            this.labelLicenseNo.Text = Resource.Gatepass_059;
            this.labelTankerNo.Text = Resource.Gatepass_058;
            this.labelPassengers.Text = Resource.RegisGatepassEntry_006;
            this.labelPassengersNames.Text = Resource.RegisGatepassEntry_007;
            this.buttonESPB.Text = Resource.RegisGatepassEntry_011;
            this.checkLastWeighing.Text = Resource.RegisGatepassEntry_012;
            this.checkEstate.Text = Resource.RegisGatepassEntry_013;
            this.groupPhoto.Text = Resource.RegisGatepassEntry_008;
            this.tabPage1st.Text = Resource._1stWeight;
            this.tabPage2nd.Text = Resource._2ndWeight;
            this.tabPage3rd.Text = Resource._3rdWeight;
            this.tabPage4th.Text = Resource._4thWeight;
            this.labelRef.Text = Resource.Gatepass_057;
            this.tabPageGeneral.Text = Resource.Trans_050;
            this.labelDeliveryNote.Text = Resource.Trans_001;
            this.labelSealNo.Text = Resource.Trans_004;
            this.labelRemarkTicket.Text = Resource.Trans_002;
            this.labelRemarkReport.Text = Resource.Trans_003;
            this.labelAdditionalInfo.Text = Resource.Trans_100;
            this.chk_return.Text = Resource.Trans_101;
            this.btn_check.Text = Resource.Trans_102;
            this.tabPageOP.Text = Resource.Trans_008;
            this.checkNOPW.Text = Resource.Trans_105;
            this.labelWBNo.Text = Resource.Trans_104;
            this.labelOPDate.Text = Resource.Trans_103;
            this.labelOPGross.Text = Resource.Trans_009;
            this.labelOPTare.Text = Resource.Trans_010;
            this.labelOPNet.Text = Resource.Trans_011;
            this.tabPageWBDO.Text = Resource.RegisGatepassEntry_009;
            this.buttonAddDO.Text = Resource.Trans_055;
            this.buttonEditDO.Text = Resource.Trans_056;
            this.buttonDeleteDO.Text = Resource.Trans_057;
            this.buttonViewDO.Text = Resource.Trans_106;
            this.buttonDeleteAllDO.Text = Resource.Trans_115;
            this.dgvDO.Columns["loading_qty"].HeaderText = Resource.Trans_109;
            this.dgvDO.Columns["Do_No"].HeaderText = Resource.Trans_025;
            this.dgvDO.Columns["Contract"].HeaderText = Resource.Trans_032;
            this.dgvDO.Columns["PI_No"].HeaderText = Resource.Trans_026;
            this.dgvDO.Columns["Comm_Code"].HeaderText = Resource.Trans_027;
            this.dgvDO.Columns["Transaction_Code"].HeaderText = Resource.Trans_114;
            this.dgvDO.Columns["Transporter_Code"].HeaderText = Resource.Trans_042;
            this.dgvDO.Columns["Relation_Code"].HeaderText = Resource.Trans_029;
            this.dgvDO.Columns["Relation_Name"].HeaderText = Resource.Trans_030;
            this.dgvDO.Columns["do_sap"].HeaderText = Resource.Trans_110 + this.sapIDSYS;
            this.dgvDO.Columns["do_sap_item"].HeaderText = Resource.Trans_111 + this.sapIDSYS + " Item";
            this.dgvDO.Columns["internal_number"].HeaderText = Resource.Trans_112;
            this.dgvDO.Columns["internal_number_item"].HeaderText = Resource.Trans_113;
            this.dgvDO.Columns["Netto"].HeaderText = Resource.Trans_038;
            this.dgvDO.Columns["Estate_qty"].HeaderText = Resource.Trans_035;
            this.dgvDO.Columns["Bruto"].HeaderText = Resource.Trans_036;
            this.dgvDO.Columns["Tarra"].HeaderText = Resource.Trans_037;
            this.dgvDO.Columns["DeliNo"].HeaderText = Resource.Trans_001;
            this.dgvDO.Columns["OSDO"].HeaderText = Resource.Trans_108;
            this.tabPageQC.Text = Resource.Trans_062;
            this.dgvQC.Columns["QCode"].HeaderText = Resource.Trans_064;
            this.dgvQC.Columns["QName"].HeaderText = Resource.Trans_065;
            this.dgvQC.Columns["SAP_Value"].HeaderText = this.sapIDSYS + Resource.Trans_107;
            this.dgvQC.Columns["Estate"].HeaderText = Resource.Trans_066;
            this.dgvQC.Columns["Factory"].HeaderText = Resource.Trans_067;
            this.dgvQC.Columns["deduct"].HeaderText = Resource.Col_Deduct_Net;
            this.tabPageCont.Text = Resource.Gatepass_070;
            this.dgvCont.Columns["Container"].HeaderText = Resource.Gatepass_070;
            this.dgvCont.Columns["Seal"].HeaderText = Resource.Trans_045;
            this.buttonContAdd.Text = Resource.Trans_055;
            this.buttonContEdit.Text = Resource.Trans_056;
            this.buttonContDelete.Text = Resource.Trans_057;
            this.tabPageDeduction.Text = Resource.RegisGatepassEntry_014;
            this.buttonEntryDeduc.Text = Resource.RegisGatepassEntry_015;
            this.tabPageFFB.Text = Resource.RegisGatepassEntry_016;
            this.radioButtonEntryTotalBunch.Text = Resource.RegisGatepassEntry_017;
            this.radioButtonEntryAVG.Text = Resource.RegisGatepassEntry_018;
            this.labelTotalBunch.Text = Resource.RegisGatepassEntry_019;
            this.labelTotalBunchDeduc.Text = Resource.RegisGatepassEntry_020;
            this.labelAverageBunch.Text = Resource.RegisGatepassEntry_021;
            this.labelOER.Text = Resource.RegisGatepassEntry_022;
            this.labelRejectedFFB.Text = Resource.RegisGatepassEntry_023;
            this.labelBunch.Text = Resource.RegisGatepassEntry_024;
            this.labelRejectedFFBReason.Text = Resource.RegisGatepassEntry_025;
            this.dgvGPDest.Columns["description"].HeaderText = Resource.RegisGatepassEntry_004;
            this.dgvGPDest.Columns["source_code"].HeaderText = Resource.Setting_120;
            this.tabPageDivision.Text = Resource.RegisGatepassEntry_026;
            this.buttonAddDivision.Text = Resource.Trans_055;
            this.buttonEditDivision.Text = Resource.Trans_056;
            this.buttonDeleteDivision.Text = Resource.Trans_057;
            this.dgvDivBlock.Columns["Estate_Code"].HeaderText = Resource.Trans_084;
            this.dgvDivBlock.Columns["Estate_Name"].HeaderText = Resource.Trans_085;
            this.dgvDivBlock.Columns["Division_Code"].HeaderText = Resource.Trans_086;
            this.dgvDivBlock.Columns["Division_Name"].HeaderText = Resource.Trans_087;
            this.dgvDivBlock.Columns["Block_Code"].HeaderText = Resource.Trans_088;
            this.dgvDivBlock.Columns["Block_Name"].HeaderText = Resource.Trans_089;
            this.dgvDivBlock.Columns["UnitName"].HeaderText = Resource.Trans_068;
            this.dgvDivBlock.Columns["YearPlanting"].HeaderText = Resource.Trans_090;
            this.dgvDivBlock.Columns["Bunch"].HeaderText = Resource.Trans_091;
            this.dgvDivBlock.Columns["Weight"].HeaderText = Resource.Trans_093;
        }

        private bool try_connect()
        {
            if (!WBSAP.connect())
            {
                DialogResult result2 = MessageBox.Show("WB.NET cannot connect to SAP.\nPlease check your connection.\nDo you want to retry?\n\nPress YES to Retry.", "WARNING", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk);
                if (result2 == DialogResult.Cancel)
                {
                    return false;
                }
                else if (result2 == DialogResult.Yes)
                {
                    this.try_connect();
                }
                else
                {
                    return (result2 == DialogResult.No);
                }
            }
            return true;
        }

        private void txt_deli_note_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void txt_deli_note_Leave(object sender, EventArgs e)
        {
            if (((WBSetting.Field("DeliveryNote") == "Y") && (this.comboWX.SelectedValue.ToString() != "3")) && ((this.txt_deli_note.Text.Trim() != "-") && !string.IsNullOrEmpty(this.txt_deli_note.Text)))
            {
                if (this.dgvDO.Rows.Count <= 0)
                {
                    MessageBox.Show("Please input DO first", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.txt_deli_note.Text = "";
                }
                else if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    this.txt_deli_note.Enabled = false;
                }
                else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    this.txt_deli_note.Enabled = false;
                }
                else if (((this.CommType == "F") && !this.scaneSPB) && !WBUtility.CheckValidSPB(this.txt_deli_note.Text, this.dgvDO))
                {
                    this.txt_deli_note.Focus();
                }
            }
        }

        private void txt_driver_ic_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void txt_driver_ic_Leave(object sender, EventArgs e)
        {
            this.CheckLicenseNumber();
        }

        private void txt_driver_ic_TextChanged(object sender, EventArgs e)
        {
            if ((this.readoptInternalNumber || this.changeLoadingNote) ? (this.comboBoxRef.Items.Count == 0) : false)
            {
                this.changeTDT = true;
            }
        }

        private void txt_seal_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void txt_seal_TextChanged(object sender, EventArgs e)
        {
        }

        private void txt_transporter_code_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void txt_transporter_code_Leave(object sender, EventArgs e)
        {
            this.CheckTransporterCode();
        }

        private void txt_transporter_code_TextChanged(object sender, EventArgs e)
        {
            if ((this.readoptInternalNumber || this.changeLoadingNote) ? (this.comboBoxRef.Items.Count == 0) : false)
            {
                this.changeTDT = true;
            }
        }

        private void txt_truck_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void txt_truck_Leave(object sender, EventArgs e)
        {
            this.CheckTruckNumber(true);
        }

        private void txt_truck_TextChanged(object sender, EventArgs e)
        {
            if ((this.readoptInternalNumber || this.changeLoadingNote) ? (this.comboBoxRef.Items.Count == 0) : false)
            {
                this.changeTDT = true;
            }
        }

        private void txtAddInfo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void txtPassengers_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtPassengers_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.txtPassengers);
        }

        private void txtPassengersNames_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void updateGatepassandTransaction(string gatepassNo)
        {
            if (((this.oldDeliveryNote != this.txt_deli_note.Text.Trim()) || ((this.oldEstateDifferent != this.checkEstate.Checked) || ((this.oldSeal != this.txt_seal.Text.Trim()) || ((this.oldRemarkReport != this.textRemarkReport.Text.Trim()) || ((this.oldRemarkTicket != this.textRemarkTicket.Text.Trim()) || ((this.oldAdditionalInfo != this.txtAddInfo.Text.Trim()) || ((this.oldPL3 != this.textPL3.Text.Trim()) || ((this.oldTruck.Trim() != this.txt_truck.Text.Trim()) || ((this.oldDriver.Trim() != this.txt_driver_ic.Text.Trim()) || (this.oldDriverName.Trim() != this.textDriverName.Text.Trim())))))))))) || this.QCChanged)
            {
                this.t_gatepass.DR = this.t_gatepass.DT.Rows[0];
                this.t_gatepass.DR.BeginEdit();
                this.t_gatepass.DR["EstateDiff"] = this.checkEstate.Checked ? "Y" : "N";
                this.t_gatepass.DR["delivery_note"] = this.txt_deli_note.Text.Trim();
                this.t_gatepass.DR["seal"] = this.txt_seal.Text.Trim();
                this.t_gatepass.DR["remark_ticket"] = this.textRemarkTicket.Text.Trim();
                this.t_gatepass.DR["remark_report"] = this.textRemarkReport.Text.Trim();
                this.t_gatepass.DR["addi_info"] = this.txtAddInfo.Text.Trim();
                this.t_gatepass.DR["PL3_No"] = this.textPL3.Text.Trim();
                this.t_gatepass.DR["Truck_Number"] = this.txt_truck.Text;
                this.t_gatepass.DR["License_No"] = this.txt_driver_ic.Text;
                this.t_gatepass.DR.EndEdit();
                this.t_gatepass.Save();
                this.t_gatepass.ReOpen();
                this.logKey = this.t_gatepass.DT.Rows[0]["uniq"].ToString();
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, "SUBMIT-PRINT" };
                Program.updateLogHeader("wb_gatepass", this.logKey, logField, logValue);
                if (this.comboWX.SelectedValue.ToString() == "3")
                {
                    int num = 0;
                    while (true)
                    {
                        if (num >= this.comboBoxRefTemp.Items.Count)
                        {
                            break;
                        }
                        string str = this.comboBoxRefTemp.GetItemText(this.comboBoxRefTemp.Items[num]).Trim();
                        WBTable table = new WBTable();
                        table.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Ref = '" + str + "'"), WBData.conn);
                        foreach (DataRow row in table.DT.Rows)
                        {
                            this.logKey = row["uniq"].ToString();
                            row.BeginEdit();
                            row["EstateDiff"] = this.checkEstate.Checked ? "Y" : "N";
                            row["delivery_note"] = this.txt_deli_note.Text.Trim();
                            row["seal"] = this.txt_seal.Text.Trim();
                            row["remark_ticket"] = this.textRemarkTicket.Text.Trim();
                            row["remark_report"] = this.textRemarkReport.Text.Trim();
                            row["addi_info"] = this.txtAddInfo.Text.Trim();
                            row["PL3_No"] = this.textPL3.Text.Trim();
                            row["Truck_Number"] = this.txt_truck.Text;
                            row["License_No"] = this.txt_driver_ic.Text;
                            row["Name"] = this.textDriverName.Text.Trim();
                            row.EndEdit();
                            table.Save();
                            string[] textArray3 = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] textArray4 = new string[] { this.pMode, WBUser.UserID, "SUBMIT-PRINT" };
                            Program.updateLogHeader("wb_transaction", this.logKey, textArray3, textArray4);
                        }
                        table.Dispose();
                        num++;
                    }
                }
                else
                {
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= this.comboBoxRef.Items.Count)
                        {
                            break;
                        }
                        string str2 = this.comboBoxRef.GetItemText(this.comboBoxRef.Items[num2]).Trim();
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Ref = '" + str2 + "'"), WBData.conn);
                        foreach (DataRow row2 in table2.DT.Rows)
                        {
                            this.logKey = row2["uniq"].ToString();
                            row2.BeginEdit();
                            row2["EstateDiff"] = this.checkEstate.Checked ? "Y" : "N";
                            row2["delivery_note"] = this.txt_deli_note.Text.Trim();
                            row2["seal"] = this.txt_seal.Text.Trim();
                            row2["remark_ticket"] = this.textRemarkTicket.Text.Trim();
                            row2["remark_report"] = this.textRemarkReport.Text.Trim();
                            row2["addi_info"] = this.txtAddInfo.Text.Trim();
                            row2["PL3_No"] = this.textPL3.Text.Trim();
                            row2["Truck_Number"] = this.txt_truck.Text;
                            row2["License_No"] = this.txt_driver_ic.Text;
                            row2["Name"] = this.textDriverName.Text.Trim();
                            row2.EndEdit();
                            table2.Save();
                            string[] textArray5 = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] textArray6 = new string[] { this.pMode, WBUser.UserID, "SUBMIT-PRINT" };
                            Program.updateLogHeader("wb_transaction", this.logKey, textArray5, textArray6);
                        }
                        table2.Dispose();
                        num2++;
                    }
                }
                foreach (DataGridViewRow row3 in (IEnumerable) this.dgvQC.Rows)
                {
                    row3.Cells["Gatepass_Number"].Value = gatepassNo;
                    row3.Cells["ref"].Value = this.comboBoxRef.Text;
                }
                this.tblTransQC.AddFromDGV_new(this.dgvQC, "Gatepass_Number", gatepassNo, "", "");
                this.tblTransQC.ReOpen();
                if (this.comboBoxRef.Items.Count > 0)
                {
                    int num3 = 1;
                    while (true)
                    {
                        if (num3 >= this.comboBoxRef.Items.Count)
                        {
                            break;
                        }
                        string pVal = this.comboBoxRef.Text + WBUtility.getSplitV2Ext(0x40 + num3);
                        WBTable table3 = new WBTable();
                        table3.OpenTable("wb_transQC", "SELECT * FROM wb_transQC WHERE " + WBData.CompanyLocation(" AND ref = '" + pVal + "'"), WBData.conn);
                        table3.AddFromDGV_new(this.dgvQC, "Ref", pVal, "", "");
                        table3.ReOpen();
                        table3.Dispose();
                        num3++;
                    }
                }
            }
        }

        private void updatePrinted(string refno, string gatepass, bool cek)
        {
            int num = 0;
            string keyField = "";
            if (refno != "")
            {
                WBTable table = new WBTable();
                string[] textArray1 = new string[] { "Select * from wb_transaction Where ref='", refno, "' and coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "'" };
                table.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
                table.DR = table.DT.Rows[0];
                num = (table.DR["printed"].ToString().Trim() == "") ? 0 : Convert.ToInt32(table.DR["printed"].ToString());
                table.DR.BeginEdit();
                if (cek)
                {
                    num++;
                }
                keyField = table.DR["uniq"].ToString();
                table.DR["printed"] = num;
                table.DR["Printed_By"] = WBUser.UserID.Trim();
                table.DR["Printed_Date"] = DateTime.Now;
                table.DR["checksum"] = table.Checksum_Main(table.DR);
                table.DR.EndEdit();
                table.Save();
                table.Dispose();
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { "PRINT", WBUser.UserID, "(PRINT MAIN TICKET)" };
                Program.updateLogHeader("wb_transaction", keyField, logField, logValue);
            }
            else
            {
                WBTable table2 = new WBTable();
                string[] textArray4 = new string[] { "Select * from wb_transaction Where gatepass_number='", gatepass, "' and coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "'" };
                table2.OpenTable("wb_transaction", string.Concat(textArray4), WBData.conn);
                int num2 = 0;
                while (true)
                {
                    if (num2 >= table2.DT.Rows.Count)
                    {
                        break;
                    }
                    bool flag4 = table2.DT.Rows[num2]["printed"].ToString().Trim() != "";
                    num = !flag4 ? 0 : Convert.ToInt32(table2.DT.Rows[num2]["printed"].ToString());
                    table2.DT.Rows[num2].BeginEdit();
                    if (cek)
                    {
                        num++;
                    }
                    keyField = table2.DT.Rows[num2]["uniq"].ToString();
                    table2.DT.Rows[num2]["printed"] = num;
                    table2.DT.Rows[num2]["Printed_By"] = WBUser.UserID.Trim();
                    table2.DT.Rows[num2]["Printed_Date"] = DateTime.Now;
                    table2.DT.Rows[num2]["checksum"] = table2.Checksum_Main(table2.DT.Rows[num2]);
                    table2.DT.Rows[num2].EndEdit();
                    table2.Save();
                    table2.Dispose();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "PRINT", WBUser.UserID, "(PRINT MAIN TICKET)" };
                    Program.updateLogHeader("wb_transaction", keyField, logField, logValue);
                    num2++;
                }
            }
        }

        private bool validDocBC(bool submit_gatepass)
        {
            bool flag = true;
            string str = "";
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            DateTime time = new DateTime(0x76c, 1, 1, 0, 0, 0);
            DateTime time2 = new DateTime(0x76c, 1, 1, 0, 0, 0);
            using (IEnumerator enumerator = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                    this.tblCtr.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and DO_NO = '" + current.Cells["DO_NO"].Value.ToString() + "' and (deleted <> 'Y' or deleted is null)"), WBData.conn);
                    if (this.tblCtr.DT.Rows.Count > 0)
                    {
                        if (this.tblCtr.DT.Rows[0]["BC_No"].ToString() == "")
                        {
                            string[] textArray1 = new string[] { " and DO_NO = '", current.Cells["DO_NO"].Value.ToString(), "'  and ref = '", this.comboBoxRef.Text, "' and (deleted <> 'Y' or deleted is null)" };
                            table.OpenTable("wb_transBC", "select * from wb_transBC where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                            if (table.DT.Rows.Count <= 0)
                            {
                                return flag;
                            }
                            else
                            {
                                string[] textArray2 = new string[] { " and DO_NO = '", table.DT.Rows[0]["DO_NO"].ToString(), "'  and bc_no = '", table.DT.Rows[0]["bc_no"].ToString(), "' and bc_item = '", table.DT.Rows[0]["bc_item"].ToString(), "'" };
                                table2.OpenTable("wb_contract_detail_BC", "select * from wb_contract_detail_BC where " + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
                                if (table2.DT.Rows.Count <= 0)
                                {
                                    return flag;
                                }
                                else
                                {
                                    str = table2.DT.Rows[0]["BC_No"].ToString();
                                    time = Convert.ToDateTime(table2.DT.Rows[0]["BC_Date"].ToString());
                                    time2 = Convert.ToDateTime(table2.DT.Rows[0]["BC_Exp_Date"].ToString());
                                }
                            }
                        }
                        else
                        {
                            str = this.tblCtr.DT.Rows[0]["BC_No"].ToString();
                            time = Convert.ToDateTime(this.tblCtr.DT.Rows[0]["BC_Date"].ToString());
                            time2 = Convert.ToDateTime(this.tblCtr.DT.Rows[0]["BC_Exp_Date"].ToString());
                        }
                        if (this.tblCtr.DT.Rows[0]["Lock_KB"].ToString() == "N")
                        {
                            MessageBox.Show(WBSetting.integrationIDSYS ? Resource.RegisGatepassMess_051_IDSYS : Resource.RegisGatepassMess_051, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            flag = false;
                        }
                        if (time.Date > DateTime.Now.Date)
                        {
                            string[] textArray3 = new string[9];
                            textArray3[0] = Resource.RegisGatepassMess_047;
                            textArray3[1] = " (No. BC : ";
                            textArray3[2] = str;
                            textArray3[3] = " ";
                            textArray3[4] = Resource.Composite_001;
                            textArray3[5] = ": ";
                            textArray3[6] = time.ToString("yyyy-MM-dd");
                            textArray3[7] = ") \n\n ";
                            textArray3[8] = Resource.RegisGatepassMess_052;
                            MessageBox.Show(string.Concat(textArray3), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            flag = false;
                        }
                        if (time2.Date < DateTime.Now.Date)
                        {
                            string str2 = "";
                            if (submit_gatepass)
                            {
                                str2 = this.tblCtr.CekTokenCompleted(this.txt_truck.Text, current.Cells["DO_NO"].Value.ToString(), "BYPASS_EXPIRED_BC", true);
                            }
                            if (!(submit_gatepass && (str2 != "")))
                            {
                                string[] textArray4 = new string[9];
                                textArray4[0] = Resource.RegisGatepassMess_048;
                                textArray4[1] = " (No. BC : ";
                                textArray4[2] = str;
                                textArray4[3] = " ";
                                textArray4[4] = Resource.Composite_001;
                                textArray4[5] = ": ";
                                textArray4[6] = time.ToString("yyyy-MM-dd");
                                textArray4[7] = ") \n\n";
                                textArray4[8] = Resource.RegisGatepassMess_050;
                                if (MessageBox.Show(string.Concat(textArray4), Resource.Title_003, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                                {
                                    flag = false;
                                }
                                else
                                {
                                    this.hasil = this.tblCtr.tokenOrApp(this.txt_truck.Text, current.Cells["DO_NO"].Value.ToString(), "BYPASS_EXPIRED_BC", "TOKEN_EXPIRED_BC", "BYPASS_EXPIRED_BC", "E", "", null);
                                    if (this.hasil[0] != "completed")
                                    {
                                        flag = false;
                                    }
                                    else if (!submit_gatepass)
                                    {
                                        flag = true;
                                    }
                                    else if (this.tblCtr.DelTokenCompleted(this.txt_truck.Text, current.Cells["DO_NO"].Value.ToString(), "BYPASS_EXPIRED_BC", true))
                                    {
                                        flag = true;
                                    }
                                }
                            }
                            else if (this.tblCtr.DelTokenCompleted(this.txt_truck.Text, current.Cells["DO_NO"].Value.ToString(), "BYPASS_EXPIRED_BC", true))
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            return flag;
        }

        private bool validDriverID()
        {
            bool flag = false;
            if (this.txt_driver_ic.Text.Trim() != "")
            {
                this.t_driver.ReOpen();
                string[] aField = new string[] { "License_No" };
                string[] aFind = new string[] { this.txt_driver_ic.Text.Trim() };
                int recNo = this.t_driver.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    flag = false;
                }
                else
                {
                    this.textDriverName.Text = this.t_driver.DT.Rows[recNo]["Name"].ToString();
                    flag = true;
                }
            }
            return flag;
        }

        private bool validTransporter()
        {
            bool flag = true;
            if (this.txt_transporter_code.Text != "")
            {
                this.t_transporter.ReOpen();
                string[] aField = new string[] { "Transporter_Code" };
                string[] aFind = new string[] { this.txt_transporter_code.Text };
                DataRow data = this.t_transporter.GetData(aField, aFind);
                if (data == null)
                {
                    this.lbl_transporter_name.Text = "";
                    flag = false;
                }
                else
                {
                    this.lbl_transporter_name.Text = data["Transporter_Name"].ToString().Trim();
                    this.lbl_transporter_name.Refresh();
                    flag = true;
                }
            }
            return flag;
        }

        private bool validTruck()
        {
            bool flag = false;
            if (this.txt_truck.Text.Trim() != "")
            {
                this.t_truck.ReOpen();
                string[] aField = new string[] { "Truck_Number" };
                string[] aFind = new string[] { this.txt_truck.Text.Trim() };
                int recNo = this.t_truck.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    flag = false;
                }
                else
                {
                    this.txt_truck.Text = this.t_truck.DT.Rows[recNo]["Truck_Number"].ToString().Trim();
                    flag = true;
                }
            }
            return flag;
        }
    }
}

