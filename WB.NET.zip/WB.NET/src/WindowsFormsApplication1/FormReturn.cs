﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormReturn : Form
    {
        public WBTable tblCust = new WBTable();
        public WBTable tblComm = new WBTable();
        public WBTable tblReturn = new WBTable();
        public string TANumber = "";
        private bool delete = false;
        private IContainer components = null;
        private TextBox textDO;
        private TextBox textComm;
        private TextBox textQty;
        private TextBox textUnit;
        private TextBox textCust;
        private Button buttonComm;
        private Button buttonCust;
        private DataGridView dgReturn;
        private StatusStrip statusStrip1;
        private Button buttonAdd;
        private Button buttonDelete;
        private Button buttonSave;
        private Button buttonCancel;
        private Label labelCommName;

        public FormReturn()
        {
            this.InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            int num = 0;
            this.dgReturn.Rows.Add(1);
            num = this.dgReturn.RowCount - 1;
            this.dgReturn.Rows[num].Cells["DO_No"].Value = this.textDO.Text;
            this.dgReturn.Rows[num].Cells["Comm_code"].Value = this.textDO.Text;
            this.dgReturn.Rows[num].Cells["Quantity"].Value = this.textDO.Text;
            this.dgReturn.Rows[num].Cells["Unit"].Value = this.textDO.Text;
            this.dgReturn.Rows[num].Cells["Relation_Code"].Value = this.textDO.Text;
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE",
                pFind = this.textComm.Text.Trim()
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textComm.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
            }
            commodity.Dispose();
        }

        private void buttonCust_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE",
                pFind = this.textCust.Text.Trim()
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textCust.Text = vendor.ReturnRow["relation_code"].ToString();
                this.textCust.Focus();
            }
            vendor.Dispose();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if ((this.dgReturn.Rows.Count > 0) && (MessageBox.Show(Resource.Mes_203, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes))
            {
                this.dgReturn.Rows.Remove(this.dgReturn.CurrentRow);
                this.delete = true;
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            this.tblReturn.AddFromDGV_new(this.dgReturn, "TA_NUMBER", this.TANumber, "", "");
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormReturn_Load(object sender, EventArgs e)
        {
            this.labelCommName.Text = "";
            this.tblComm.OpenTable("wb_comm", "Select * from wb_Commodity " + WBData.CompanyLocation(""), WBData.conn);
            Program.AutoComp(this.tblComm, "comm_code", this.textComm);
            this.tblCust.OpenTable("wb_cust", "Select * from wb_relation where " + WBData.CompanyLocation(""), WBData.conn);
            Program.AutoComp(this.tblCust, "relation_code", this.textCust);
            this.tblReturn.OpenTable("wb_ret", "Select * from wb_return_Comm where " + WBData.CompanyLocation(" and TA_Number = '" + this.TANumber + "'"), WBData.conn);
            this.dgReturn.DataSource = this.tblReturn.DT;
            this.initDGReturn();
            this.Text = "Return Commodity for TA Number " + this.TANumber;
        }

        private void initDGReturn()
        {
            this.dgReturn.ColumnCount = this.tblReturn.DT.Columns.Count;
            this.dgReturn.ColumnCount++;
            for (int i = 0; i < this.tblReturn.DT.Columns.Count; i++)
            {
                this.dgReturn.Columns[i].Name = this.tblReturn.DT.Columns[i].ColumnName;
                this.dgReturn.Columns[i].Visible = false;
            }
        }

        private void InitializeComponent()
        {
            this.textDO = new TextBox();
            this.textComm = new TextBox();
            this.textQty = new TextBox();
            this.textUnit = new TextBox();
            this.textCust = new TextBox();
            this.buttonComm = new Button();
            this.buttonCust = new Button();
            this.dgReturn = new DataGridView();
            this.statusStrip1 = new StatusStrip();
            this.buttonAdd = new Button();
            this.buttonDelete = new Button();
            this.buttonSave = new Button();
            this.buttonCancel = new Button();
            this.labelCommName = new Label();
            ((ISupportInitialize) this.dgReturn).BeginInit();
            base.SuspendLayout();
            this.textDO.Location = new Point(0x24, 0x16);
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0x7b, 20);
            this.textDO.TabIndex = 0;
            this.textDO.KeyPress += new KeyPressEventHandler(this.textDO_KeyPress);
            this.textComm.Location = new Point(0xa5, 0x16);
            this.textComm.Name = "textComm";
            this.textComm.Size = new Size(0x7b, 20);
            this.textComm.TabIndex = 1;
            this.textComm.KeyPress += new KeyPressEventHandler(this.textComm_KeyPress);
            this.textComm.Leave += new EventHandler(this.textComm_Leave);
            this.textQty.Location = new Point(0x1ca, 0x16);
            this.textQty.Name = "textQty";
            this.textQty.Size = new Size(0x54, 20);
            this.textQty.TabIndex = 2;
            this.textUnit.Location = new Point(0x224, 0x16);
            this.textUnit.Name = "textUnit";
            this.textUnit.Size = new Size(0x42, 20);
            this.textUnit.TabIndex = 3;
            this.textUnit.KeyPress += new KeyPressEventHandler(this.textUnit_KeyPress);
            this.textCust.Location = new Point(620, 0x16);
            this.textCust.Name = "textCust";
            this.textCust.Size = new Size(0x7b, 20);
            this.textCust.TabIndex = 4;
            this.textCust.KeyPress += new KeyPressEventHandler(this.textCust_KeyPress);
            this.textCust.Leave += new EventHandler(this.textCust_Leave);
            this.buttonComm.Location = new Point(0x126, 0x12);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x1f, 0x1a);
            this.buttonComm.TabIndex = 5;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.buttonCust.Location = new Point(0x2ed, 0x12);
            this.buttonCust.Name = "buttonCust";
            this.buttonCust.Size = new Size(0x1f, 0x1a);
            this.buttonCust.TabIndex = 6;
            this.buttonCust.Text = "...";
            this.buttonCust.UseVisualStyleBackColor = true;
            this.buttonCust.Click += new EventHandler(this.buttonCust_Click);
            this.dgReturn.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgReturn.Location = new Point(0x24, 50);
            this.dgReturn.Name = "dgReturn";
            this.dgReturn.Size = new Size(0x2c3, 0xe3);
            this.dgReturn.TabIndex = 7;
            this.statusStrip1.Location = new Point(0, 0x160);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(0x317, 0x16);
            this.statusStrip1.TabIndex = 8;
            this.statusStrip1.Text = "statusStrip1";
            this.buttonAdd.Location = new Point(0x2ed, 0x34);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new Size(0x1f, 0x1a);
            this.buttonAdd.TabIndex = 9;
            this.buttonAdd.Text = "+";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new EventHandler(this.buttonAdd_Click);
            this.buttonDelete.Location = new Point(0x2ed, 0x54);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new Size(0x1f, 0x1a);
            this.buttonDelete.TabIndex = 10;
            this.buttonDelete.Text = "-";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new EventHandler(this.buttonDelete_Click);
            this.buttonSave.Location = new Point(0x207, 0x11b);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x6d, 0x2c);
            this.buttonSave.TabIndex = 11;
            this.buttonSave.Text = "&Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.buttonCancel.Location = new Point(0x27a, 0x11b);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x6d, 0x2c);
            this.buttonCancel.TabIndex = 12;
            this.buttonCancel.Text = "&Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.labelCommName.AutoSize = true;
            this.labelCommName.Location = new Point(0x14b, 0x19);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x40, 13);
            this.labelCommName.TabIndex = 13;
            this.labelCommName.Text = "CommName";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x317, 0x176);
            base.ControlBox = false;
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.buttonDelete);
            base.Controls.Add(this.buttonAdd);
            base.Controls.Add(this.statusStrip1);
            base.Controls.Add(this.dgReturn);
            base.Controls.Add(this.buttonCust);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.textCust);
            base.Controls.Add(this.textUnit);
            base.Controls.Add(this.textQty);
            base.Controls.Add(this.textComm);
            base.Controls.Add(this.textDO);
            base.Name = "FormReturn";
            this.Text = "Return Commodity For TA Number ";
            base.Load += new EventHandler(this.FormReturn_Load);
            ((ISupportInitialize) this.dgReturn).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textComm_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textComm_Leave(object sender, EventArgs e)
        {
            if (this.textComm.Text.Trim() != "")
            {
                string[] aField = new string[] { "comm_code" };
                string[] aFind = new string[] { this.textComm.Text };
                DataRow data = this.tblComm.GetData(aField, aFind);
                if (data != null)
                {
                    this.labelCommName.Text = data["Comm_Name"].ToString();
                }
                else
                {
                    MessageBox.Show(Resource.Mes_201, Resource.Title_002);
                    this.textComm.SelectAll();
                    this.textComm.Focus();
                }
            }
        }

        private void textCust_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textCust_Leave(object sender, EventArgs e)
        {
            if (this.textCust.Text.Trim() != "")
            {
                string[] aField = new string[] { "Relation_code" };
                string[] aFind = new string[] { this.textCust.Text };
                DataRow data = this.tblCust.GetData(aField, aFind);
                if (data != null)
                {
                    this.textCust.Text = data["Relation_Code"].ToString();
                }
                else
                {
                    MessageBox.Show(Resource.Mes_202, Resource.Title_002);
                    this.textCust.SelectAll();
                    this.textCust.Focus();
                }
            }
        }

        private void textDO_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textUnit_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }
    }
}

