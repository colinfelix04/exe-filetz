﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTransDOContainer : Form
    {
        public string Do_No;
        public string sqlText;
        public string RefNo;
        public string DoConv;
        public string DoConvUnit;
        public string DoConvTol;
        public int nCurrRow;
        public DataGridView dataGridView1;
        public DataGridView dgvDOCont;
        public DataGridView dgvContainer;
        public DataGridView dgvDoContAll;
        public WBTable zTable = new WBTable();
        public double sisaNet;
        public double qty;
        public double qtyTol;
        public bool pSave = false;
        public string gatepass_number;
        private IContainer components = null;
        public ComboBox comboDOContainer;
        private Label labelContainer;
        public Label labelConvUnit;
        public TextBox textConvNett;
        private Label labelQtyConv;
        private Button button8;
        private Button button6;
        public DataGridView dataGridView2;
        private Label labelRefNo;
        public TextBox textDO_No;
        private Label labelWBDO;
        public Label labelQty;
        public Label labelQuantity;
        public Label label3;
        private Label labelQtyNet;
        public TextBox textNett;
        public Label label5;
        private Button buttonSave;
        private Button buttonCancel;
        public Label labelTotal;
        public Label labelSum;
        public Label labelSealNo;
        public Label labelSeal;

        public FormTransDOContainer()
        {
            this.InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            using (IEnumerator enumerator = ((IEnumerable) this.dataGridView2.Rows).GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                    if (current.Cells["Container"].Value.ToString() == this.comboDOContainer.Text)
                    {
                        MessageBox.Show("Container already Existed");
                        return;
                    }
                }
            }
            double num = this.cekSisa()[0];
            double num2 = num;
            if ((num - Convert.ToDouble(this.textNett.Text)) < 0.0)
            {
                MessageBox.Show("Quantity not Enough, qty Left = " + Convert.ToString(num2));
            }
            else
            {
                string[] values = new string[] { WBData.sCoyCode, WBData.sLocCode, this.RefNo, this.comboDOContainer.Text, this.labelSeal.Text, this.Do_No, $"{this.textConvNett.Text:N0}", $"{this.textNett.Text:N0}" };
                values[9] = this.gatepass_number;
                this.dataGridView2.Rows.Add(values);
                this.dgvDoContAll.Rows.Add(values);
                this.labelSum.Text = $"{this.cekSisa()[1]:N0}" + " Kg";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.nCurrRow = this.dataGridView2.CurrentRow.Index;
            this.dataGridView2.Rows.Remove(this.dataGridView2.Rows[this.nCurrRow]);
            foreach (DataGridViewRow row in (IEnumerable) this.dgvDoContAll.Rows)
            {
                if ((row.Cells["Container"].Value.ToString() == this.comboDOContainer.Text) & (row.Cells["DO_No"].Value.ToString() == this.textDO_No.Text))
                {
                    this.nCurrRow = row.Index;
                }
            }
            this.dgvDoContAll.Rows.Remove(this.dgvDoContAll.Rows[this.nCurrRow]);
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.pSave = false;
            base.Close();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            double num = 0.0;
            num = this.cekSisa()[0];
            if ((num <= 0.0) || (num <= this.qty))
            {
                this.pSave = true;
                base.Close();
            }
            else
            {
                object[] objArray1 = new object[] { "Quantity not split correctly, Qty Left ", Convert.ToString(num), " qty Tolerance = ", Convert.ToDouble(this.qty) };
                MessageBox.Show(string.Concat(objArray1));
            }
        }

        private double[] cekSisa()
        {
            double num = 0.0;
            double qty = 0.0;
            qty = this.qty;
            foreach (DataGridViewRow row in (IEnumerable) this.dataGridView2.Rows)
            {
                if (row.Cells["ConvNett"].Value != null)
                {
                    num = Convert.ToDouble(row.Cells["ConvNett"].Value.ToString()) * Convert.ToDouble(this.DoConv);
                }
                qty -= num;
            }
            return new double[] { qty, num };
        }

        private void comboDOContainer_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in (IEnumerable) this.dgvContainer.Rows)
            {
                if (row.Cells["Container"].Value.ToString() == this.comboDOContainer.Text)
                {
                    this.labelSeal.Text = row.Cells["Seal"].Value.ToString();
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void fillDG()
        {
            string[] values = new string[10];
            foreach (DataGridViewRow row in (IEnumerable) this.dgvDoContAll.Rows)
            {
                if (row.Cells["DO_No"].Value.ToString() == this.Do_No)
                {
                    values[0] = row.Cells["Coy"].Value.ToString();
                    values[1] = row.Cells["Location_code"].Value.ToString();
                    values[2] = row.Cells["Ref"].Value.ToString();
                    values[3] = row.Cells["Container"].Value.ToString();
                    values[4] = row.Cells["Seal"].Value.ToString();
                    values[5] = row.Cells["DO_No"].Value.ToString();
                    values[6] = row.Cells["ConvNett"].Value.ToString();
                    values[7] = $"{values[5]:N0}";
                    values[8] = Convert.ToString((double) (Convert.ToDouble(values[6]) * Convert.ToDouble(this.DoConv)));
                    values[8] = $"{values[8]:N0}";
                    values[9] = (row.Cells["Gatepass_Number"].Value == null) ? "" : row.Cells["Gatepass_Number"].Value.ToString();
                    this.dataGridView2.Rows.Add(values);
                }
            }
        }

        private void FormTransDOContainer_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.pSave = false;
                base.Close();
            }
        }

        private void FormTransDOContainer_Load(object sender, EventArgs e)
        {
            this.dgvDoContAll = this.dgvDOCont;
            this.labelRefNo.Text = this.RefNo;
            this.textDO_No.Text = this.Do_No;
            this.labelQty.Text = $"{this.qty:N0}";
            this.comboDOContainer.Items.Clear();
            this.labelConvUnit.Text = this.DoConvUnit;
            if (this.DoConv == "")
            {
                this.DoConv = "0";
            }
            this.qtyTol = (Convert.ToDouble(this.labelQty.Text) / 1000.0) * Convert.ToDouble(this.DoConvTol);
            foreach (DataGridViewRow row in (IEnumerable) this.dgvContainer.Rows)
            {
                this.comboDOContainer.Items.Add(row.Cells["Container"].Value.ToString());
            }
            this.labelSeal.Text = "";
            this.initDG();
            this.fillDG();
            this.labelSum.Text = this.cekSisa()[1].ToString() + " Kg";
        }

        private void initDG()
        {
            this.dataGridView2.ColumnCount = this.zTable.DT.Columns.Count;
            int num = 0;
            while (true)
            {
                if (num >= this.zTable.DT.Columns.Count)
                {
                    this.dataGridView2.AllowUserToAddRows = false;
                    this.dataGridView2.Columns["Coy"].Visible = false;
                    this.dataGridView2.Columns["Location_Code"].Visible = false;
                    this.dataGridView2.Columns["Gatepass_Number"].Visible = false;
                    this.dataGridView2.Columns["Ref"].Visible = false;
                    this.dataGridView2.Columns["Uniq"].Visible = false;
                    DataGridViewTextBoxColumn dataGridViewColumn = new DataGridViewTextBoxColumn {
                        Name = "KgConv",
                        HeaderText = "Kg Convertion"
                    };
                    this.dataGridView2.Columns.Add(dataGridViewColumn);
                    this.dataGridView2.Columns["KgConv"].DefaultCellStyle.Format = "N0";
                    this.dataGridView2.Columns["KgConv"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dataGridView2.Columns["ConvNett"].DefaultCellStyle.Format = "N0";
                    this.dataGridView2.Columns["ConvNett"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    return;
                }
                this.dataGridView2.Columns[num].Name = this.zTable.DT.Columns[num].ColumnName;
                num++;
            }
        }

        private void InitializeComponent()
        {
            this.comboDOContainer = new ComboBox();
            this.labelContainer = new Label();
            this.labelConvUnit = new Label();
            this.textConvNett = new TextBox();
            this.labelQtyConv = new Label();
            this.button8 = new Button();
            this.button6 = new Button();
            this.dataGridView2 = new DataGridView();
            this.labelRefNo = new Label();
            this.textDO_No = new TextBox();
            this.labelWBDO = new Label();
            this.labelQty = new Label();
            this.labelQuantity = new Label();
            this.label3 = new Label();
            this.labelQtyNet = new Label();
            this.textNett = new TextBox();
            this.label5 = new Label();
            this.buttonSave = new Button();
            this.buttonCancel = new Button();
            this.labelTotal = new Label();
            this.labelSum = new Label();
            this.labelSealNo = new Label();
            this.labelSeal = new Label();
            ((ISupportInitialize) this.dataGridView2).BeginInit();
            base.SuspendLayout();
            this.comboDOContainer.FormattingEnabled = true;
            this.comboDOContainer.Location = new Point(0x88, 0x2f);
            this.comboDOContainer.Name = "comboDOContainer";
            this.comboDOContainer.Size = new Size(0x8d, 0x15);
            this.comboDOContainer.TabIndex = 1;
            this.comboDOContainer.SelectedIndexChanged += new EventHandler(this.comboDOContainer_SelectedIndexChanged);
            this.labelContainer.Location = new Point(12, 50);
            this.labelContainer.Name = "labelContainer";
            this.labelContainer.Size = new Size(0x59, 13);
            this.labelContainer.TabIndex = 0x21;
            this.labelContainer.Text = "Container No";
            this.labelContainer.Click += new EventHandler(this.labelContainer_Click);
            this.labelConvUnit.AutoSize = true;
            this.labelConvUnit.Location = new Point(0xe1, 0x70);
            this.labelConvUnit.Name = "labelConvUnit";
            this.labelConvUnit.Size = new Size(80, 13);
            this.labelConvUnit.TabIndex = 0x25;
            this.labelConvUnit.Text = "Convertion Unit";
            this.textConvNett.Location = new Point(0x88, 0x6d);
            this.textConvNett.Name = "textConvNett";
            this.textConvNett.Size = new Size(0x53, 20);
            this.textConvNett.TabIndex = 2;
            this.textConvNett.Text = "0";
            this.textConvNett.TextAlign = HorizontalAlignment.Right;
            this.textConvNett.TextChanged += new EventHandler(this.textConvNett_TextChanged);
            this.textConvNett.Leave += new EventHandler(this.textConvNett_Leave);
            this.labelQtyConv.Location = new Point(12, 0x70);
            this.labelQtyConv.Name = "labelQtyConv";
            this.labelQtyConv.Size = new Size(0x59, 13);
            this.labelQtyConv.TabIndex = 0x24;
            this.labelQtyConv.Text = "Qty Convertion";
            this.button8.Location = new Point(0x5d, 0xac);
            this.button8.Name = "button8";
            this.button8.Size = new Size(0x4b, 0x1c);
            this.button8.TabIndex = 5;
            this.button8.Text = "Delete";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new EventHandler(this.button8_Click);
            this.button6.Location = new Point(12, 0xac);
            this.button6.Name = "button6";
            this.button6.Size = new Size(0x4b, 0x1c);
            this.button6.TabIndex = 4;
            this.button6.Text = "Add ";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new EventHandler(this.button6_Click);
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new Point(12, 0xd3);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new Size(0x1cf, 0x88);
            this.dataGridView2.TabIndex = 0;
            this.labelRefNo.AutoSize = true;
            this.labelRefNo.Dock = DockStyle.Right;
            this.labelRefNo.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelRefNo.Location = new Point(0x1a2, 0);
            this.labelRefNo.Name = "labelRefNo";
            this.labelRefNo.Size = new Size(0x4d, 0x10);
            this.labelRefNo.TabIndex = 0x34;
            this.labelRefNo.Text = "labelRefNo";
            this.labelRefNo.TextAlign = ContentAlignment.MiddleRight;
            this.textDO_No.Location = new Point(0x88, 0x15);
            this.textDO_No.Name = "textDO_No";
            this.textDO_No.ReadOnly = true;
            this.textDO_No.Size = new Size(0x53, 20);
            this.textDO_No.TabIndex = 0;
            this.textDO_No.TextAlign = HorizontalAlignment.Right;
            this.labelWBDO.Location = new Point(12, 0x18);
            this.labelWBDO.Name = "labelWBDO";
            this.labelWBDO.Size = new Size(0x59, 13);
            this.labelWBDO.TabIndex = 0x36;
            this.labelWBDO.Text = "WB DO";
            this.labelQty.AutoSize = true;
            this.labelQty.Location = new Point(0x170, 0x18);
            this.labelQty.Name = "labelQty";
            this.labelQty.Size = new Size(0x17, 13);
            this.labelQty.TabIndex = 0x37;
            this.labelQty.Text = "Qty";
            this.labelQuantity.AutoSize = true;
            this.labelQuantity.Location = new Point(310, 0x18);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new Size(0x34, 13);
            this.labelQuantity.TabIndex = 0x38;
            this.labelQuantity.Text = "Quantity :";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x1c7, 0x18);
            this.label3.Name = "label3";
            this.label3.Size = new Size(20, 13);
            this.label3.TabIndex = 0x39;
            this.label3.Text = "Kg";
            this.labelQtyNet.Location = new Point(12, 0x89);
            this.labelQtyNet.Name = "labelQtyNet";
            this.labelQtyNet.Size = new Size(0x59, 13);
            this.labelQtyNet.TabIndex = 0x3a;
            this.labelQtyNet.Text = "Qty Net";
            this.textNett.Location = new Point(0x88, 0x86);
            this.textNett.Name = "textNett";
            this.textNett.ReadOnly = true;
            this.textNett.Size = new Size(0x53, 20);
            this.textNett.TabIndex = 3;
            this.textNett.Text = "0";
            this.textNett.TextAlign = HorizontalAlignment.Right;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0xe1, 0x89);
            this.label5.Name = "label5";
            this.label5.Size = new Size(20, 13);
            this.label5.TabIndex = 60;
            this.label5.Text = "Kg";
            this.buttonSave.Location = new Point(0x12a, 0x18d);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x4b, 0x25);
            this.buttonSave.TabIndex = 6;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.buttonCancel.Location = new Point(400, 0x18d);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x4b, 0x25);
            this.buttonCancel.TabIndex = 7;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.labelTotal.AutoSize = true;
            this.labelTotal.Location = new Point(0xe0, 0x16a);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new Size(0x7a, 13);
            this.labelTotal.TabIndex = 0x3d;
            this.labelTotal.Text = "Total Weight Convertion";
            this.labelSum.AutoSize = true;
            this.labelSum.Location = new Point(0x1b5, 0x16a);
            this.labelSum.Name = "labelSum";
            this.labelSum.Size = new Size(0x26, 13);
            this.labelSum.TabIndex = 0x3e;
            this.labelSum.Text = "xxx Kg";
            this.labelSum.TextAlign = ContentAlignment.TopRight;
            this.labelSealNo.Location = new Point(12, 0x4a);
            this.labelSealNo.Name = "labelSealNo";
            this.labelSealNo.Size = new Size(0x59, 13);
            this.labelSealNo.TabIndex = 0x3f;
            this.labelSealNo.Text = "Seal No";
            this.labelSeal.AutoSize = true;
            this.labelSeal.BorderStyle = BorderStyle.FixedSingle;
            this.labelSeal.Location = new Point(0x88, 0x4a);
            this.labelSeal.Name = "labelSeal";
            this.labelSeal.Size = new Size(0x38, 15);
            this.labelSeal.TabIndex = 0x40;
            this.labelSeal.Text = "LabelSeal";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1ef, 0x1b5);
            base.ControlBox = false;
            base.Controls.Add(this.labelSeal);
            base.Controls.Add(this.labelSealNo);
            base.Controls.Add(this.labelSum);
            base.Controls.Add(this.labelTotal);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.textNett);
            base.Controls.Add(this.labelQtyNet);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.labelQuantity);
            base.Controls.Add(this.labelQty);
            base.Controls.Add(this.textDO_No);
            base.Controls.Add(this.labelWBDO);
            base.Controls.Add(this.labelRefNo);
            base.Controls.Add(this.dataGridView2);
            base.Controls.Add(this.button8);
            base.Controls.Add(this.button6);
            base.Controls.Add(this.labelConvUnit);
            base.Controls.Add(this.textConvNett);
            base.Controls.Add(this.labelQtyConv);
            base.Controls.Add(this.labelContainer);
            base.Controls.Add(this.comboDOContainer);
            base.KeyPreview = true;
            base.Name = "FormTransDOContainer";
            this.RightToLeft = RightToLeft.No;
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Alocate Container to WB DO";
            base.Load += new EventHandler(this.FormTransDOContainer_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransDOContainer_KeyPress);
            ((ISupportInitialize) this.dataGridView2).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void labelContainer_Click(object sender, EventArgs e)
        {
        }

        private void textConvNett_Leave(object sender, EventArgs e)
        {
            if (Program.CheckNumeric(this.textConvNett))
            {
                this.textNett.Text = Convert.ToString((double) (Convert.ToDouble(this.textConvNett.Text) * Convert.ToDouble(this.DoConv)));
            }
            else
            {
                this.textConvNett.Focus();
            }
        }

        private void textConvNett_TextChanged(object sender, EventArgs e)
        {
            if (this.textConvNett.Text != "0")
            {
            }
        }

        private void translate()
        {
            this.Text = Resource.TransDOContainer_001;
            this.labelWBDO.Text = Resource.RegisGatepassEntry_009;
            this.labelContainer.Text = Resource.Gatepass_070;
            this.labelSealNo.Text = Resource.Trans_004;
            this.labelQtyConv.Text = Resource.TransDOContainer_002;
            this.labelQtyNet.Text = Resource.TransDOContainer_003;
            this.labelTotal.Text = Resource.TransDOContainer_004;
        }
    }
}

