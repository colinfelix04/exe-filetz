﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormMulesoftEntry : Form
    {
        public string pMode;
        public string changeReason = "";
        public string logKey = "";
        public WBTable zTable;
        public int nCurrRow;
        public bool saved;
        private IContainer components = null;
        private Button button2;
        private Button button1;
        public TextBox textName;
        private Label labelName;
        private Label labelDescription;
        private TextBox textDescription;
        private Label labelURL;
        private TextBox textURL;

        public FormMulesoftEntry()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textName.Text.Trim() != "")
            {
                if (this.textDescription.Text.Trim() != "")
                {
                    if (this.textURL.Text.Trim() != "")
                    {
                        if (this.pMode == "EDIT")
                        {
                            FormTransCancel cancel = new FormTransCancel {
                                label1 = { Text = "RFC Name" },
                                textRefNo = { Text = this.textName.Text },
                                Text = Resource.Title_Change_Reason,
                                label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                            };
                            cancel.textReason.Focus();
                            cancel.ShowDialog();
                            if (cancel.Saved)
                            {
                                this.changeReason = cancel.textReason.Text;
                                cancel.Dispose();
                            }
                            else
                            {
                                return;
                            }
                        }
                        Cursor.Current = Cursors.WaitCursor;
                        if (this.pMode == "ADD")
                        {
                            this.zTable.DR = this.zTable.DT.NewRow();
                        }
                        else
                        {
                            this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                            this.logKey = this.zTable.DR["uniq"].ToString();
                            this.zTable.DR.BeginEdit();
                        }
                        this.zTable.DR["Coy"] = WBData.sCoyCode;
                        this.zTable.DR["Location_Code"] = WBData.sLocCode;
                        this.zTable.DR["RFC_Name"] = this.textName.Text.Trim();
                        this.zTable.DR["RFC_Description"] = this.textDescription.Text.Trim();
                        this.zTable.DR["RFC_URL"] = this.textURL.Text.Trim();
                        if (this.pMode == "ADD")
                        {
                            this.zTable.DR["Create_By"] = WBUser.UserID;
                            this.zTable.DR["Create_Date"] = DateTime.Now;
                            this.zTable.DT.Rows.Add(this.zTable.DR);
                        }
                        else
                        {
                            this.zTable.DR["Change_By"] = WBUser.UserID;
                            this.zTable.DR["Change_Date"] = DateTime.Now;
                            this.zTable.DR.EndEdit();
                        }
                        this.zTable.Save();
                        Cursor.Current = Cursors.Default;
                        this.saved = true;
                        base.Close();
                    }
                    else
                    {
                        MessageBox.Show("Please enter URL!", Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        this.textURL.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please enter description!", Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textDescription.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please enter RFC name!", Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textName.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormMulesoftEntry_Load(object sender, EventArgs e)
        {
            if (this.pMode == "ADD")
            {
                this.textName.Text = "";
                this.textDescription.Text = "";
                this.textURL.Text = "";
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.textName.Text = this.zTable.DR["RFC_Name"].ToString();
                this.textDescription.Text = this.zTable.DR["RFC_Description"].ToString();
                this.textURL.Text = this.zTable.DR["RFC_URL"].ToString();
                if ((this.pMode == "EDIT") && (Convert.ToInt16(WBUser.UserLevel) > 1))
                {
                    this.textName.Enabled = false;
                }
                if (this.pMode == "VIEW")
                {
                    foreach (Control control in base.Controls)
                    {
                        control.Enabled = false;
                    }
                    this.button2.Text = Resource.Btn_Close;
                    this.button2.Enabled = true;
                }
            }
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.textName = new TextBox();
            this.labelName = new Label();
            this.labelDescription = new Label();
            this.textDescription = new TextBox();
            this.labelURL = new Label();
            this.textURL = new TextBox();
            base.SuspendLayout();
            this.button2.Location = new Point(0x169, 0xa9);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 0x37;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x10b, 0xa9);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 0x36;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textName.CharacterCasing = CharacterCasing.Upper;
            this.textName.Location = new Point(140, 0x13);
            this.textName.Name = "textName";
            this.textName.Size = new Size(0x128, 20);
            this.textName.TabIndex = 0x3a;
            this.labelName.Location = new Point(0x16, 0x16);
            this.labelName.Name = "labelName";
            this.labelName.Size = new Size(0x65, 0x11);
            this.labelName.TabIndex = 0x3b;
            this.labelName.Text = "RFC Name";
            this.labelDescription.Location = new Point(0x16, 0x2e);
            this.labelDescription.Name = "labelDescription";
            this.labelDescription.Size = new Size(0x65, 0x11);
            this.labelDescription.TabIndex = 60;
            this.labelDescription.Text = "Description";
            this.textDescription.Location = new Point(140, 0x2e);
            this.textDescription.Multiline = true;
            this.textDescription.Name = "textDescription";
            this.textDescription.Size = new Size(0x128, 0x2d);
            this.textDescription.TabIndex = 0x3d;
            this.labelURL.Location = new Point(0x16, 0x61);
            this.labelURL.Name = "labelURL";
            this.labelURL.Size = new Size(0x65, 0x11);
            this.labelURL.TabIndex = 0x3e;
            this.labelURL.Text = "URL";
            this.textURL.Location = new Point(140, 0x61);
            this.textURL.Multiline = true;
            this.textURL.Name = "textURL";
            this.textURL.Size = new Size(0x128, 0x31);
            this.textURL.TabIndex = 0x3f;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1cf, 0xd3);
            base.ControlBox = false;
            base.Controls.Add(this.textURL);
            base.Controls.Add(this.labelURL);
            base.Controls.Add(this.textDescription);
            base.Controls.Add(this.labelDescription);
            base.Controls.Add(this.textName);
            base.Controls.Add(this.labelName);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.KeyPreview = true;
            base.Name = "FormMulesoftEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Entry URL for Mulesoft";
            base.Load += new EventHandler(this.FormMulesoftEntry_Load);
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

