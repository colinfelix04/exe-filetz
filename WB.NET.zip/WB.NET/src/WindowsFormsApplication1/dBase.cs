﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data.SqlClient;
    using System.Windows.Forms;

    public class dBase : Component
    {
        public string sServer;
        public string sDatabase;
        public string sUserID;
        public string sPassword;
        public string ConnStr;
        public string Prefix;
        public SqlConnection conn;

        public void Close()
        {
            this.conn.Close();
        }

        public bool Open()
        {
            string[] textArray1 = new string[9];
            textArray1[0] = "server=";
            textArray1[1] = this.sServer;
            textArray1[2] = "; database=";
            textArray1[3] = this.sDatabase;
            textArray1[4] = "; uid=";
            textArray1[5] = this.sUserID;
            textArray1[6] = "; password=";
            textArray1[7] = this.sPassword;
            textArray1[8] = ";";
            this.ConnStr = string.Concat(textArray1);
            try
            {
                this.conn = new SqlConnection(this.ConnStr);
                this.conn.Open();
                return true;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Resource.Mes_545 + "\n\n" + exception.Message, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return false;
            }
        }
    }
}

