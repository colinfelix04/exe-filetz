﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Globalization;
    using System.IO;
    using System.Text;
    using System.Windows.Forms;

    public class RepTransLog_New : Form
    {
        public int rowCount = 0;
        private bool titleEditDetail;
        private bool titleDeleteDetail;
        public string[,] tableDetail;
        private WBTable editLog;
        private WBTable editQtyLog;
        private WBTable cancelLog;
        private WBTable printLog;
        private WBTable detailLog;
        private WBTable getUser;
        private IContainer components;
        public Label labelProses2;
        public Label labelProses1;
        public Button buttonClose;
        public Button buttonProcess;
        public Label labelHeader;
        private RadioButton radioMenu;
        public GroupBox groupBox3;
        public DateTimePicker monthCalendar1;
        public Label labelFromDate;
        public Label labelToDate;
        public DateTimePicker monthCalendar2;
        private TextBox textRef;
        private RadioButton radioRef;
        private GroupBox groupBox1;

        public RepTransLog_New()
        {
            string[] textArray1 = new string[14, 3];
            textArray1[0, 0] = "wb_TransactionCL";
            textArray1[0, 1] = "Consignment Lab";
            textArray1[0, 2] = "";
            textArray1[1, 0] = "wb_transactionD";
            textArray1[1, 1] = "Deduction";
            textArray1[1, 2] = "Code";
            textArray1[2, 0] = "wb_transactionPorla";
            textArray1[2, 1] = "Porla";
            textArray1[2, 2] = "Code";
            textArray1[3, 0] = "wb_transBatch";
            textArray1[3, 1] = "Batch";
            textArray1[3, 2] = "";
            textArray1[4, 0] = "wb_transContainer";
            textArray1[4, 1] = "Container";
            textArray1[4, 2] = "";
            textArray1[5, 0] = "wb_transCopra";
            textArray1[5, 1] = "Copra";
            textArray1[5, 2] = "";
            textArray1[6, 0] = "wb_transDivision";
            textArray1[6, 1] = "Division";
            textArray1[6, 2] = "";
            textArray1[7, 0] = "wb_transDO";
            textArray1[7, 1] = "Transaction DO";
            textArray1[7, 2] = "";
            textArray1[8, 0] = "wb_transDO_Container";
            textArray1[8, 1] = "DO Container";
            textArray1[8, 2] = "";
            textArray1[9, 0] = "wb_TransQC";
            textArray1[9, 1] = "Quality Control";
            textArray1[9, 2] = "QCode";
            textArray1[10, 0] = "wb_TransQC_CL";
            textArray1[10, 1] = "Quality Control Consigment";
            textArray1[10, 2] = "";
            textArray1[11, 0] = "wb_transSplit";
            textArray1[11, 1] = "Transaction Split";
            textArray1[11, 2] = "";
            textArray1[12, 0] = "wb_divide_BlockD";
            textArray1[12, 1] = "Block Detail";
            textArray1[12, 2] = "Block_Code";
            textArray1[13, 0] = "wb_divide_BlockH";
            textArray1[13, 1] = "Block Header";
            textArray1[13, 2] = "";
            this.tableDetail = textArray1;
            this.editLog = new WBTable();
            this.editQtyLog = new WBTable();
            this.cancelLog = new WBTable();
            this.printLog = new WBTable();
            this.detailLog = new WBTable();
            this.getUser = new WBTable();
            this.components = null;
            this.InitializeComponent();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.radioRef.Checked && (this.textRef.Text == ""))
            {
                MessageBox.Show("Please enter reference number!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.textRef.Focus();
            }
            else if (Math.Abs((this.monthCalendar1.Value - this.monthCalendar2.Value).Days) > Math.Abs(90))
            {
                MessageBox.Show("Date interval must be less than 3 months", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                HTML html = new HTML();
                html = this.generateRep(this.radioMenu.Checked, this.monthCalendar1.Value, this.monthCalendar2.Value, this.textRef.Text, WBData.sCoyCode, WBData.sLocCode, "0");
                if (html != null)
                {
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + html.File) }
                    };
                    report.ShowDialog();
                    html.Dispose();
                    report.Dispose();
                }
                this.labelProses1.Text = "";
                this.labelProses1.Refresh();
                this.labelProses2.Text = "";
                this.labelProses2.Refresh();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private string firstLetterToUpper(string reason)
        {
            string str = reason.ToLower();
            return ((str.Length <= 1) ? str : (char.ToUpper(str[0]).ToString() + str.Substring(1)));
        }

        public HTML generateRep(bool byDate, DateTime dateFrom, DateTime dateTo, string refNo, string coy, string loc, string zAuto)
        {
            this.titleEditDetail = true;
            this.titleDeleteDetail = true;
            HTML rep = new HTML();
            string path = rep.File + @"\LogReport";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            HTML html2 = rep;
            string[] textArray1 = new string[] { html2.File, @"\LogReport\", coy, loc, "TRANSLOG_", dateFrom.ToString("ddMMyyyy"), ".htm" };
            html2.File = string.Concat(textArray1);
            rep.Title = "Log of Transaction";
            rep.Open();
            rep.Write(rep.Style());
            rep.Write("<br><font size=5><b>LOG OF TRANSACTION</b></font><br>");
            string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblSetting.DR["Coy_Name"].ToString(), " (", coy, ")</font>" };
            rep.Write(string.Concat(textArray2));
            string[] textArray3 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", loc, ")</font><br>" };
            rep.Write(string.Concat(textArray3));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            rep.Write("<br><br>");
            rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
            if (this.radioRef.Checked && (this.textRef.Text.Trim() != ""))
            {
                rep.Write("<tr class=bd>");
                rep.Write("<td>Reference No</td>");
                rep.Write("<td>: <b>" + this.textRef.Text + "</b></td>");
                rep.Write("</tr>");
            }
            else if (this.radioMenu.Checked)
            {
                rep.Write("<tr class=bd>");
                rep.Write("<td>Selected date</td>");
                string[] textArray4 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                rep.Write(string.Concat(textArray4));
                rep.Write("</tr>");
            }
            rep.Write("<tr class=bd>");
            rep.Write("<td>Report Date</td>");
            rep.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
            rep.Write("</tr>");
            rep.Write("</table>");
            rep.Write("<br/><br/><br/>");
            this.rowCount = 1;
            string[] textArray5 = new string[] { "SELECT * FROM wb_user with (nolock) WHERE coy = '", coy, "' and location_code = '", loc, "'" };
            this.getUser.OpenTable("wb_user", string.Concat(textArray5), WBData.conn);
            string[] pMode = new string[] { "QTY" };
            this.editQtyLog = this.openLogTableForUpdate(byDate, dateFrom, dateTo, refNo, coy, loc, pMode, "wb_transaction");
            this.templateHeaderForEdit(rep, this.editQtyLog, "EDIT QUANTITY", "wb_transaction");
            string[] textArray7 = new string[] { "CANCEL" };
            this.cancelLog = this.openLogTableForUpdate(byDate, dateFrom, dateTo, refNo, coy, loc, textArray7, "wb_transaction");
            this.templateHeaderForCancel(rep, this.cancelLog, "Cancel", "CANCEL TRANSACTION", "wb_transaction");
            string[] textArray8 = new string[] { "REPRINT" };
            this.printLog = this.openLogTableForUpdate(byDate, dateFrom, dateTo, refNo, coy, loc, textArray8, "wb_transaction");
            this.templateHeaderForCancel(rep, this.printLog, "Reprint", "REPRINT TRANSACTION", "wb_transaction");
            string[] textArray9 = new string[] { "EDIT", "QC", "EDIT_OPW" };
            this.editLog = this.openLogTableForUpdate(byDate, dateFrom, dateTo, refNo, coy, loc, textArray9, "wb_transaction");
            this.templateHeaderForEdit(rep, this.editLog, "EDIT MAIN INFORMATION (EXCLUDE QUANTITY)", "wb_transaction");
            int num = 0;
            while (true)
            {
                if (num >= (this.tableDetail.Length / 3))
                {
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= (this.tableDetail.Length / 3))
                        {
                            HTML html3;
                            if (this.rowCount <= 1)
                            {
                                if (zAuto != "1")
                                {
                                    MessageBox.Show("No records found!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                }
                                rep.Close();
                                html3 = null;
                            }
                            else
                            {
                                rep.Write("<br>");
                                rep.Write("<br>");
                                rep.writeSign();
                                rep.Close();
                                this.detailLog.Dispose();
                                html3 = rep;
                            }
                            return html3;
                        }
                        string[] textArray11 = new string[] { "EDIT" };
                        this.detailLog = this.openLogTableForDelete(this.radioMenu.Checked, this.monthCalendar1.Value, this.monthCalendar2.Value, this.textRef.Text, coy, loc, textArray11, this.tableDetail[num2, 0]);
                        this.templateDetailForDelete(rep, this.detailLog, "DELETE DETAIL INFORMATION", "Delete " + this.tableDetail[num2, 1], this.tableDetail[num2, 0]);
                        num2++;
                    }
                }
                string[] textArray10 = new string[] { "EDIT", "QC" };
                this.detailLog = this.openLogTableForUpdate(this.radioMenu.Checked, this.monthCalendar1.Value, this.monthCalendar2.Value, this.textRef.Text, coy, loc, textArray10, this.tableDetail[num, 0]);
                this.templateDetailForEdit(rep, this.detailLog, "EDIT DETAIL INFORMATION", "Edit " + this.tableDetail[num, 1], this.tableDetail[num, 0], this.tableDetail[num, 2]);
                num++;
            }
        }

        private void InitializeComponent()
        {
            this.labelProses2 = new Label();
            this.labelProses1 = new Label();
            this.buttonClose = new Button();
            this.buttonProcess = new Button();
            this.labelHeader = new Label();
            this.radioMenu = new RadioButton();
            this.groupBox3 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.labelFromDate = new Label();
            this.labelToDate = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.textRef = new TextBox();
            this.radioRef = new RadioButton();
            this.groupBox1 = new GroupBox();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0xf4, 30);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0xd6, 13);
            this.labelProses2.TabIndex = 0x4c;
            this.labelProses2.Text = "Progress . . . . . . . . . . . ";
            this.labelProses2.TextAlign = ContentAlignment.MiddleRight;
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(0xf4, 0x11);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0xd3, 13);
            this.labelProses1.TabIndex = 0x4d;
            this.labelProses1.Text = "1/88888";
            this.labelProses1.TextAlign = ContentAlignment.MiddleRight;
            this.buttonClose.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonClose.Location = new Point(0x159, 0xc0);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new Size(110, 0x22);
            this.buttonClose.TabIndex = 0x47;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new EventHandler(this.buttonClose_Click);
            this.buttonProcess.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonProcess.Location = new Point(0xe5, 0xc0);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(110, 0x22);
            this.buttonProcess.TabIndex = 70;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.labelHeader.AutoSize = true;
            this.labelHeader.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelHeader.Location = new Point(11, 12);
            this.labelHeader.Name = "labelHeader";
            this.labelHeader.Size = new Size(0x9f, 20);
            this.labelHeader.TabIndex = 0x4e;
            this.labelHeader.Text = "Log of Transaction";
            this.labelHeader.TextAlign = ContentAlignment.TopCenter;
            this.radioMenu.AutoSize = true;
            this.radioMenu.Checked = true;
            this.radioMenu.Location = new Point(9, 13);
            this.radioMenu.Name = "radioMenu";
            this.radioMenu.Size = new Size(0x6d, 0x11);
            this.radioMenu.TabIndex = 0x5e;
            this.radioMenu.TabStop = true;
            this.radioMenu.Text = "Generate by Date";
            this.radioMenu.UseVisualStyleBackColor = true;
            this.radioMenu.CheckedChanged += new EventHandler(this.radioMenu_CheckedChanged);
            this.groupBox3.Controls.Add(this.monthCalendar1);
            this.groupBox3.Controls.Add(this.labelFromDate);
            this.groupBox3.Controls.Add(this.labelToDate);
            this.groupBox3.Controls.Add(this.monthCalendar2);
            this.groupBox3.Location = new Point(0x17, 30);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(0x18e, 0x30);
            this.groupBox3.TabIndex = 0x5b;
            this.groupBox3.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x56, 0x11);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.labelFromDate.AutoSize = true;
            this.labelFromDate.Location = new Point(14, 20);
            this.labelFromDate.Name = "labelFromDate";
            this.labelFromDate.Size = new Size(0x3e, 13);
            this.labelFromDate.TabIndex = 3;
            this.labelFromDate.Text = "From Date :";
            this.labelToDate.AutoSize = true;
            this.labelToDate.Location = new Point(0xd3, 20);
            this.labelToDate.Name = "labelToDate";
            this.labelToDate.Size = new Size(0x34, 13);
            this.labelToDate.TabIndex = 4;
            this.labelToDate.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x10d, 0x11);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.textRef.Location = new Point(0xac, 0x5e);
            this.textRef.Name = "textRef";
            this.textRef.Size = new Size(0x98, 20);
            this.textRef.TabIndex = 0x5d;
            this.radioRef.AutoSize = true;
            this.radioRef.Location = new Point(9, 0x5f);
            this.radioRef.Name = "radioRef";
            this.radioRef.Size = new Size(0x9c, 0x11);
            this.radioRef.TabIndex = 0x5f;
            this.radioRef.Text = "Generate by Reference No.";
            this.radioRef.UseVisualStyleBackColor = true;
            this.radioRef.CheckedChanged += new EventHandler(this.radioRef_CheckedChanged);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.radioMenu);
            this.groupBox1.Controls.Add(this.radioRef);
            this.groupBox1.Controls.Add(this.textRef);
            this.groupBox1.Location = new Point(15, 0x30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(440, 0x81);
            this.groupBox1.TabIndex = 0x60;
            this.groupBox1.TabStop = false;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1de, 0xf2);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.labelHeader);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.buttonClose);
            base.Controls.Add(this.buttonProcess);
            base.Name = "RepTransLog_New";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Transaction Log Report";
            base.Load += new EventHandler(this.RepTransLog_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepTransLog_KeyPress);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private WBTable openLogTableForDelete(bool byDate, DateTime dateFrom, DateTime dateTo, string refNo, string coy, string loc, string[] pMode, string tableName)
        {
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "SELECT * FROM wb_log_header h, wb_log_detail d with (nolock) WHERE h.uniq = d.keyHeader  AND h.coy = '", coy, "'  AND h.location_code = '", loc, "' AND h.tableName = '", tableName, "'" };
            string sqltext = string.Concat(textArray1);
            if (byDate)
            {
                sqltext = (sqltext + " AND (substring(convert(varchar, h.logDate, 120), 0, 11)>='" + dateFrom.ToString("yyyy-MM-dd") + "'") + " AND substring(convert(varchar, h.logdate, 120), 0, 11)<='" + dateTo.ToString("yyyy-MM-dd") + "')";
            }
            sqltext = sqltext + " AND d.fieldName = 'ref' ";
            if (!byDate)
            {
                sqltext = sqltext + " AND d.oldValue = '" + refNo + "'";
            }
            sqltext = ((sqltext + " AND h.Type = 'D' " + " AND h.PMode is not null ") + " AND h.UserID is not null " + " AND h.ChangeReason is not null ") + " AND (h.pMode = '" + pMode[0] + "' ";
            int index = 1;
            while (true)
            {
                if (index >= pMode.Length)
                {
                    sqltext = sqltext + " ) ";
                    if (this.radioRef.Checked)
                    {
                        sqltext = sqltext + " ORDER BY h.keyField, h.uniq ASC";
                    }
                    if (this.radioMenu.Checked)
                    {
                        sqltext = sqltext + " ORDER BY h.logDate, h.keyField, h.uniq ASC";
                    }
                    table.OpenTable("wb_log_header", sqltext, WBData.conn);
                    return table;
                }
                sqltext = sqltext + " OR h.pMode = '" + pMode[index] + "' ";
                index++;
            }
        }

        private WBTable openLogTableForUpdate(bool byDate, DateTime dateFrom, DateTime dateTo, string refNo, string coy, string loc, string[] pMode, string tableName)
        {
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "SELECT * FROM wb_log_header with (nolock)  WHERE coy = '", coy, "'  AND location_code = '", loc, "' AND tableName = '", tableName, "'" };
            string sqltext = string.Concat(textArray1);
            if (byDate)
            {
                sqltext = (sqltext + " AND (substring(convert(varchar, logDate, 120), 0, 11)>='" + dateFrom.ToString("yyyy-MM-dd") + "'") + " AND substring(convert(varchar, logdate, 120), 0, 11)<='" + dateTo.ToString("yyyy-MM-dd") + "')";
            }
            else
            {
                WBTable table2 = new WBTable();
                table2.OpenTable(tableName, "SELECT * FROM " + tableName + " with (nolock) WHERE " + WBData.CompanyLocation(" AND Ref = '" + refNo + "'"), WBData.conn);
                if (table2.DT.Rows.Count <= 0)
                {
                    sqltext = sqltext + " AND keyField = ''";
                }
                else
                {
                    sqltext = sqltext + " AND (keyField = '" + table2.DT.Rows[0]["uniq"].ToString() + "' ";
                    int num = 1;
                    while (true)
                    {
                        if (num >= table2.DT.Rows.Count)
                        {
                            sqltext = sqltext + " ) ";
                            break;
                        }
                        sqltext = sqltext + " OR keyField = '" + table2.DT.Rows[num]["uniq"].ToString() + "' ";
                        num++;
                    }
                }
                table2.Dispose();
            }
            sqltext = ((sqltext + " AND Type = 'U' " + " AND PMode is not null ") + " AND UserID is not null " + " AND ChangeReason is not null ") + " AND (pMode = '" + pMode[0] + "' ";
            int index = 1;
            while (true)
            {
                if (index >= pMode.Length)
                {
                    sqltext = sqltext + " ) ";
                    if (this.radioRef.Checked)
                    {
                        sqltext = sqltext + " ORDER BY keyField, uniq ASC";
                    }
                    if (this.radioMenu.Checked)
                    {
                        sqltext = sqltext + " ORDER BY logDate, keyField, uniq ASC";
                    }
                    table.OpenTable("wb_log_header", sqltext, WBData.conn);
                    return table;
                }
                sqltext = sqltext + " OR pMode = '" + pMode[index] + "' ";
                index++;
            }
        }

        private void radioMenu_CheckedChanged(object sender, EventArgs e)
        {
            this.groupBox3.Enabled = true;
            this.textRef.Text = "";
            this.textRef.Enabled = false;
        }

        private void radioRef_CheckedChanged(object sender, EventArgs e)
        {
            this.groupBox3.Enabled = false;
            this.textRef.Enabled = true;
        }

        private void RepTransLog_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepTransLog_Load(object sender, EventArgs e)
        {
            this.translate();
            base.KeyPreview = true;
            this.textRef.Enabled = false;
            this.labelProses1.Text = "";
            this.labelProses2.Text = "";
            WBTable tbl = new WBTable();
            tbl.OpenTable("wb_transaction", "Select Ref from wb_transaction with (nolock)", WBData.conn);
            Program.AutoComp(tbl, "Ref", this.textRef);
        }

        private void templateDetailForDelete(HTML rep, WBTable log, string title, string subtitle, string tableName)
        {
            if (log.DT.Rows.Count > 0)
            {
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                WBTable table3 = new WBTable();
                if (this.titleDeleteDetail)
                {
                    rep.Write("<font size=3><b>" + title + "</b></font><br/><br/>");
                    this.titleDeleteDetail = false;
                }
                rep.Write("<font size=2><b>- " + subtitle + "</b></font><br/><br/>");
                rep.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                rep.Write("<tr class=bd>");
                rep.Write("<th>Ref No.</th>");
                table2.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail with (nolock) WHERE keyHeader = '" + log.DT.Rows[0]["keyHeader"].ToString() + "' AND fieldName != 'ref'", WBData.conn);
                foreach (DataRow row in table2.DT.Rows)
                {
                    char[] separator = new char[] { '_' };
                    string[] strArray = row["fieldName"].ToString().Split(separator);
                    string str = "";
                    int index = 0;
                    while (true)
                    {
                        if (index >= strArray.Length)
                        {
                            rep.Write("<th>" + CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str) + "</th>");
                            break;
                        }
                        str = str + strArray[index] + " ";
                        index++;
                    }
                }
                rep.Write("<th>Reason</th>");
                rep.Write("<th nowrap>Delete By</th>");
                rep.Write("<th nowrap>Delete Date/Time</th>");
                rep.Write("</tr>");
                int num = 0;
                foreach (DataRow row2 in log.DT.Rows)
                {
                    string str2 = "??REF??";
                    table.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail with (nolock) WHERE keyHeader = '" + row2["uniq"].ToString() + "'", WBData.conn);
                    foreach (DataRow row4 in table.DT.Rows)
                    {
                        if (row4["fieldName"].ToString() == "ref")
                        {
                            str2 = row4["oldValue"].ToString();
                        }
                    }
                    this.labelProses1.Text = this.rowCount.ToString();
                    this.labelProses1.Refresh();
                    this.labelProses2.Text = str2;
                    this.labelProses2.Refresh();
                    rep.Write("<tr class=bd>");
                    rep.Write("<td>" + str2 + "</td>");
                    table2.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail with (nolock) WHERE keyHeader = '" + log.DT.Rows[num]["keyHeader"].ToString() + "' AND fieldName != 'ref'", WBData.conn);
                    foreach (DataRow row5 in table2.DT.Rows)
                    {
                        rep.Write("<td>" + row5["oldValue"].ToString() + "</td>");
                    }
                    string str3 = row2["UserID"].ToString();
                    string[] aField = new string[] { "User_ID" };
                    string[] aFind = new string[] { str3 };
                    DataRow data = this.getUser.GetData(aField, aFind);
                    if (data != null)
                    {
                        str3 = data["User_name"].ToString();
                    }
                    rep.Write("<td>" + this.firstLetterToUpper(row2["changeReason"].ToString()) + "</td>");
                    rep.Write("<td>" + CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str3.ToLower()) + "</td>");
                    rep.Write("<td>" + row2["logDate"].ToString() + "</td>");
                    rep.Write("</tr>");
                    this.rowCount++;
                    num++;
                }
                rep.Write("</table>");
                rep.Write("<br/><br/><br/>");
                table.Dispose();
                table2.Dispose();
            }
        }

        private void templateDetailForEdit(HTML rep, WBTable log, string title, string subtitle, string tableName, string code)
        {
            if (log.DT.Rows.Count > 0)
            {
                DataRow data;
                StringBuilder builder = new StringBuilder();
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                WBTable table3 = new WBTable();
                WBTable table4 = new WBTable();
                bool flag2 = false;
                bool flag3 = false;
                table4.OpenTable("wb_warning_trace", "SELECT * FROM wb_warning_trace with (nolock) WHERE " + WBData.CompanyLocation(" AND (selected = 'Y' OR traceOnly = 'Y')  AND tableName = '" + tableName + "'"), WBData.conn);
                foreach (DataRow row2 in log.DT.Rows)
                {
                    table2.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail with (nolock) WHERE keyHeader = '" + row2["uniq"].ToString() + "'", WBData.conn);
                    foreach (DataRow row3 in table2.DT.Rows)
                    {
                        string[] aField = new string[] { "fieldName" };
                        string[] aFind = new string[] { row3["fieldName"].ToString() };
                        data = table4.GetData(aField, aFind);
                        if (data != null)
                        {
                            flag2 = true;
                            break;
                        }
                    }
                }
                foreach (DataRow row4 in log.DT.Rows)
                {
                    string[] textArray3 = new string[] { "SELECT * FROM ", tableName, " with (nolock) WHERE uniq = '", row4["keyField"].ToString(), "'" };
                    table2.OpenTable(tableName, string.Concat(textArray3), WBData.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        flag3 = true;
                        break;
                    }
                }
                if (flag2 & flag3)
                {
                    if (this.titleEditDetail)
                    {
                        builder.Append("<font size=3><b>" + title + "</b></font><br/><br/>");
                        this.titleEditDetail = false;
                    }
                    builder.Append("<font size=2><b>- " + subtitle + "</b></font><br/><br/>");
                    builder.Append("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                    builder.Append("<tr class=bd>");
                    builder.Append("<th>Ref No.</th>");
                    if (code != "")
                    {
                        builder.Append("<th>Code</th>");
                    }
                    builder.Append("<th>Change Field</th>");
                    builder.Append("<th>Before</th>");
                    builder.Append("<th>After</th>");
                    builder.Append("<th>Reason</th>");
                    builder.Append("<th nowrap>Change By</th>");
                    builder.Append("<th nowrap>Change Date/Time</th>");
                    builder.Append("</tr>");
                    bool flag7 = true;
                    foreach (DataRow row5 in log.DT.Rows)
                    {
                        string[] textArray4 = new string[] { "SELECT * FROM ", tableName, " with (nolock) WHERE uniq = '", row5["keyField"].ToString(), "'" };
                        table.OpenTable(tableName, string.Concat(textArray4), WBData.conn);
                        string str = "??REF??";
                        if (table.DT.Rows.Count > 0)
                        {
                            str = table.DT.Rows[0]["Ref"].ToString();
                            this.labelProses1.Text = this.rowCount.ToString();
                            this.labelProses1.Refresh();
                            this.labelProses2.Text = str;
                            this.labelProses2.Refresh();
                            table2.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail with (nolock) WHERE keyHeader = '" + row5["uniq"].ToString() + "'", WBData.conn);
                            string[] textArray5 = new string[] { "SELECT * FROM ", tableName, " with (nolock) WHERE uniq = '", row5["keyField"].ToString(), "'" };
                            table3.OpenTable(tableName, string.Concat(textArray5), WBData.conn);
                            int num = 0;
                            bool flag11 = true;
                            int num2 = 0;
                            while (true)
                            {
                                if (num2 >= table2.DT.Rows.Count)
                                {
                                    builder.Replace("nSpan", num);
                                    break;
                                }
                                table2.DR = table2.DT.Rows[num2];
                                string[] aField = new string[] { "fieldName" };
                                string[] aFind = new string[] { table2.DR["fieldName"].ToString() };
                                data = table4.GetData(aField, aFind);
                                bool flag12 = data != null;
                                if (flag12 && (table2.DR["oldValue"].ToString() != table2.DR["newValue"].ToString()))
                                {
                                    flag7 = false;
                                    num++;
                                    if (!flag11)
                                    {
                                        builder.Append("<tr class=bd>");
                                        builder.Append("<td>" + data["Name"].ToString() + "</td>");
                                        builder.Append("<td>" + table2.DR["oldValue"].ToString() + "</td>");
                                        builder.Append("<td>" + table2.DR["newValue"].ToString() + "</td>");
                                        builder.Append("</tr>");
                                    }
                                    else
                                    {
                                        string str2 = row5["UserID"].ToString();
                                        string[] textArray8 = new string[] { "User_ID" };
                                        string[] textArray9 = new string[] { str2 };
                                        DataRow data = this.getUser.GetData(textArray8, textArray9);
                                        if (data != null)
                                        {
                                            str2 = data["User_name"].ToString();
                                        }
                                        builder.Append("<tr class=bd>");
                                        builder.Append("<td rowspan=nSpan valign=top>" + str + "</td>");
                                        if (code != "")
                                        {
                                            builder.Append("<td rowspan=nSpan valign=top>" + table3.DT.Rows[0][code].ToString() + "</td>");
                                        }
                                        builder.Append("<td>" + data["Name"].ToString() + "</td>");
                                        builder.Append("<td>" + table2.DR["oldValue"].ToString() + "</td>");
                                        builder.Append("<td>" + table2.DR["newValue"].ToString() + "</td>");
                                        builder.Append("<td rowspan=nSpan valign=top>" + row5["changeReason"].ToString() + "</td>");
                                        builder.Append("<td rowspan=nSpan valign=top>" + CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str2.ToLower()) + "</td>");
                                        builder.Append("<td rowspan=nSpan valign=top nowrap>" + row5["logDate"].ToString() + "</td>");
                                        builder.Append("</tr>");
                                        flag11 = false;
                                        this.rowCount++;
                                    }
                                }
                                num2++;
                            }
                        }
                    }
                    if (!flag7)
                    {
                        rep.Write(builder.ToString());
                        rep.Write("</table>");
                        rep.Write("<br/><br/><br/>");
                    }
                }
                builder.Clear();
                table.Dispose();
                table2.Dispose();
            }
        }

        private void templateHeaderForCancel(HTML rep, WBTable log, string mode, string title, string tableName)
        {
            if (log.DT.Rows.Count > 0)
            {
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                rep.Write("<font size=3><b>" + title + "</b></font><br/><br/>");
                rep.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                rep.Write("<tr class=bd>");
                rep.Write("<th>Ref No.</th>");
                rep.Write("<th>Reason</th>");
                rep.Write("<th nowrap>" + mode + " By</th>");
                rep.Write("<th nowrap>" + mode + " Date/Time</th>");
                rep.Write("</tr>");
                foreach (DataRow row in log.DT.Rows)
                {
                    string[] textArray1 = new string[] { "SELECT * FROM ", tableName, " with (nolock) WHERE uniq = '", row["keyField"].ToString(), "'" };
                    table.OpenTable(tableName, string.Concat(textArray1), WBData.conn);
                    string str = "??REF??";
                    if (table.DT.Rows.Count > 0)
                    {
                        str = table.DT.Rows[0]["Ref"].ToString();
                    }
                    this.labelProses1.Text = this.rowCount.ToString();
                    this.labelProses1.Refresh();
                    this.labelProses2.Text = str;
                    this.labelProses2.Refresh();
                    string str2 = row["UserID"].ToString();
                    string[] aField = new string[] { "User_ID" };
                    string[] aFind = new string[] { str2 };
                    DataRow data = this.getUser.GetData(aField, aFind);
                    if (data != null)
                    {
                        str2 = data["User_name"].ToString();
                    }
                    rep.Write("<tr class=bd>");
                    rep.Write("<td>" + str + "</td>");
                    rep.Write("<td>" + this.firstLetterToUpper(row["changeReason"].ToString()) + "</td>");
                    rep.Write("<td>" + CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str2.ToLower()) + "</td>");
                    rep.Write("<td>" + row["logDate"].ToString() + "</td>");
                    rep.Write("</tr>");
                    this.rowCount++;
                }
                rep.Write("</table>");
                rep.Write("<br/><br/><br/>");
                table.Dispose();
                table2.Dispose();
            }
        }

        private void templateHeaderForEdit(HTML rep, WBTable log, string title, string tableName)
        {
            if (log.DT.Rows.Count > 0)
            {
                DataRow data;
                StringBuilder builder = new StringBuilder();
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                WBTable table3 = new WBTable();
                bool flag2 = false;
                table3.OpenTable("wb_warning_trace", "SELECT * FROM wb_warning_trace with (nolock) WHERE " + WBData.CompanyLocation(" AND (selected = 'Y' OR traceOnly = 'Y')  AND tableName = '" + tableName + "'"), WBData.conn);
                foreach (DataRow row2 in log.DT.Rows)
                {
                    table2.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail with (nolock) WHERE keyHeader = '" + row2["uniq"].ToString() + "'", WBData.conn);
                    foreach (DataRow row3 in table2.DT.Rows)
                    {
                        string[] aField = new string[] { "fieldName" };
                        string[] aFind = new string[] { row3["fieldName"].ToString() };
                        data = table3.GetData(aField, aFind);
                        if (data != null)
                        {
                            flag2 = true;
                            break;
                        }
                    }
                }
                if (flag2)
                {
                    builder.Append("<font size=3><b>" + title + "</b></font><br/><br/>");
                    builder.Append("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                    builder.Append("<tr class=bd>");
                    builder.Append("<th>Ref No.</th>");
                    builder.Append("<th>Change Field</th>");
                    builder.Append("<th>Before</th>");
                    builder.Append("<th>After</th>");
                    builder.Append("<th>Reason</th>");
                    builder.Append("<th nowrap>Change By</th>");
                    builder.Append("<th nowrap>Change Date/Time</th>");
                    builder.Append("</tr>");
                    bool flag5 = true;
                    foreach (DataRow row4 in log.DT.Rows)
                    {
                        string[] textArray3 = new string[] { "SELECT * FROM ", tableName, " with (nolock) WHERE uniq = '", row4["keyField"].ToString(), "'" };
                        table.OpenTable(tableName, string.Concat(textArray3), WBData.conn);
                        string str = "??REF??";
                        if (table.DT.Rows.Count > 0)
                        {
                            str = table.DT.Rows[0]["Ref"].ToString();
                        }
                        this.labelProses1.Text = this.rowCount.ToString();
                        this.labelProses1.Refresh();
                        this.labelProses2.Text = str;
                        this.labelProses2.Refresh();
                        table2.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail with (nolock) WHERE keyHeader = '" + row4["uniq"].ToString() + "'", WBData.conn);
                        int num = 0;
                        bool flag6 = true;
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= table2.DT.Rows.Count)
                            {
                                builder.Replace("nSpan", num);
                                break;
                            }
                            table2.DR = table2.DT.Rows[num2];
                            string[] aField = new string[] { "fieldName" };
                            string[] aFind = new string[] { table2.DR["fieldName"].ToString() };
                            data = table3.GetData(aField, aFind);
                            bool flag8 = data != null;
                            if (flag8 && (table2.DR["oldValue"].ToString() != table2.DR["newValue"].ToString()))
                            {
                                flag5 = false;
                                num++;
                                if (!flag6)
                                {
                                    builder.Append("<tr class=bd>");
                                    builder.Append("<td>" + data["Name"].ToString() + "</td>");
                                    builder.Append("<td>" + table2.DR["oldValue"].ToString() + "</td>");
                                    builder.Append("<td>" + table2.DR["newValue"].ToString() + "</td>");
                                    builder.Append("</tr>");
                                }
                                else
                                {
                                    string str2 = row4["UserID"].ToString();
                                    string[] textArray6 = new string[] { "User_ID" };
                                    string[] textArray7 = new string[] { str2 };
                                    DataRow data = this.getUser.GetData(textArray6, textArray7);
                                    if (data != null)
                                    {
                                        str2 = data["User_name"].ToString();
                                    }
                                    builder.Append("<tr class=bd>");
                                    builder.Append("<td rowspan=nSpan valign=top>" + str + "</td>");
                                    builder.Append("<td>" + data["Name"].ToString() + "</td>");
                                    builder.Append("<td>" + table2.DR["oldValue"].ToString() + "</td>");
                                    builder.Append("<td>" + table2.DR["newValue"].ToString() + "</td>");
                                    builder.Append("<td rowspan=nSpan valign=top>" + row4["changeReason"].ToString() + "</td>");
                                    builder.Append("<td rowspan=nSpan valign=top>" + CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str2.ToLower()) + "</td>");
                                    builder.Append("<td rowspan=nSpan valign=top nowrap>" + row4["logDate"].ToString() + "</td>");
                                    builder.Append("</tr>");
                                    flag6 = false;
                                    this.rowCount++;
                                }
                            }
                            num2++;
                        }
                    }
                    if (!flag5)
                    {
                        rep.Write(builder.ToString());
                        rep.Write("</table>");
                        rep.Write("<br/><br/><br/>");
                    }
                }
                builder.Clear();
                table3.Dispose();
                table.Dispose();
                table2.Dispose();
            }
        }

        private void textRef_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.Text = Resource.Report09_001;
            this.labelHeader.Text = Resource.Report09_002;
            this.buttonProcess.Text = Resource.Rep01_042;
            this.buttonClose.Text = Resource.Menu_Close;
        }
    }
}

