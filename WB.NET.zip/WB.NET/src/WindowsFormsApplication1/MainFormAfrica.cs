﻿namespace WindowsFormsApplication1
{
    using CrystalDecisions.CrystalReports.Engine;
    using Microsoft.VisualBasic;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.IO.Ports;
    using System.Net;
    using System.Net.Sockets;
    using System.Threading;
    using System.Windows.Forms;
    using System.Xml.Serialization;

    public class MainFormAfrica : Form
    {
        private int idxFind = 0;
        public string pMode;
        public string cField;
        public string fNoRef;
        public int nCurrRow;
        public WBTable Trans = new WBTable();
        public DateTime dFrom;
        public DateTime dTo;
        public string doviewComm = "";
        public string doviewRefNo = "";
        public string doviewRelation = "";
        public string doviewDO_No = "";
        public string doviewPI_No = "";
        public bool doviewFirsttime = true;
        public bool tambahRecord = true;
        public Thread td;
        public ReportDocument ticketRpt = new ReportDocument();
        public ReportDocument ticket2Rpt = new ReportDocument();
        public ReportDocument ticketGrading = new ReportDocument();
        private FormRpt fRpt;
        public bool autoUpd = false;
        public bool updSuccess = true;
        public bool isUpload = false;
        public bool isSendEmail = false;
        private string[] sapJamKirim;
        private FormMessage fm = new FormMessage();
        private string gatepassNumber = "";
        public int intervalForCalibration = 30;
        private IContainer components = null;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem ReportToolStripMenuItem;
        private ToolStripMenuItem masterDataToolStripMenuItem1;
        private ToolStripMenuItem DOToolStripMenuItem;
        private ToolStripMenuItem commodityToolStripMenuItem;
        private ToolStripMenuItem relationToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem truckToolStripMenuItem;
        private ToolStripMenuItem driverToolStripMenuItem;
        private ToolStripMenuItem configurationToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private StatusStrip statusWB;
        private ToolStripStatusLabel Status1;
        private ToolStripMenuItem transpoterToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem2;
        private ToolStripMenuItem locationToolStripMenuItem;
        private ToolStripMenuItem storageToolStripMenuItem;
        private ToolStripMenuItem divisionToolStripMenuItemPOM;
        private ToolStripMenuItem estateToolStripMenuItem;
        private ToolStripMenuItem qualityToolStripMenuItem;
        private ToolStripMenuItem tankerToolStripMenuItem;
        private ToolStripMenuItem gradingToolStripMenuItemPOM;
        private ToolStripSeparator toolStripMenuItem3;
        private ToolStripMenuItem transactionTypeToolStripMenuItem;
        private TableLayoutPanel tableLayoutPanel1;
        private DataGridView dataGridView1;
        private Label label1;
        private Panel panel1;
        private TextBox TextFind;
        private Button buttonFind;
        private ToolStripMenuItem FFBReportToolStripMenuItemPOM;
        private ToolStripMenuItem subRP1ToolStripMenuItem;
        private ToolStripMenuItem WeighingMenuItem;
        private ToolStripMenuItem ndWeightToolStripMenuItem;
        private ToolStripMenuItem rdWeightToolStripMenuItem;
        private ToolStripMenuItem thWeightToolStripMenuItem;
        private ToolStripMenuItem databaseConnectionToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem5;
        private Button buttonFilter;
        private ToolStripSeparator toolStripMenuItem6;
        private ToolStripMenuItem userListToolStripMenuItem;
        private ToolStripMenuItem userGroupToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem7;
        private ToolStripMenuItem weighBridgeSettingToolStripMenuItem;
        private Label Garis1;
        private ToolStripMenuItem blockStripMenuItemPOM;
        private ToolStripSeparator toolStripMenuItem4;
        private ToolStripMenuItem coytoolStripMenuItem;
        private Label Garis2;
        private DateTimePicker dateTimePicker2;
        private DateTimePicker dateTimePicker1;
        private Label label3;
        private Label label4;
        private CheckBox checkBox1;
        private Label labelStatus1;
        private ToolStripSeparator toolStripMenuItem8;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem cancelRecordToolStripMenuItem;
        private ToolStripMenuItem printToolStripMenuItem;
        private ToolStripMenuItem laporanTotalPenerimaanTBSToolStripMenuItem;
        private ToolStripMenuItem fFBGradingReportToolStripMenuItem;
        private ToolStripMenuItem repairChecksumToolStripMenuItem;
        private CheckBox checkShowCheckSum;
        private ToolStripMenuItem uploadSAPToolStripMenuItem;
        private ToolStripMenuItem templateSAPToolStripMenuItem;
        private Timer timerSAPUpd;
        private Label lblNow;
        private Label lblDate;
        private ToolStripMenuItem qCItemToolStripMenuItem;
        private ToolStripMenuItem compositToolStripMenuItem;
        private ToolStripMenuItem qcStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripSeparator toolStripSeparator2;
        private CheckBox checkPartial;
        private ToolStripMenuItem stWeightToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem9;
        private ToolStripMenuItem toolStripMenuItem10;
        private ToolStripSeparator toolStripSeparator3;
        private SerialPort serialPort1;
        private ToolStripMenuItem toolStripMenuRekapHarian;
        private ToolStripMenuItem vendorSummaryTBSToolStripMenuItem;
        private BackgroundWorker backgroundWorkerSAP;
        private ToolStripMenuItem qCReportToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem11;
        private ToolStripMenuItem ManualEntryMenuItem;
        private ToolStripMenuItem divisionReportToolStripMenuItem;
        private ToolStripMenuItem listOfWeighningToolStripMenuItem1;
        private ToolStripMenuItem doDetailToolStripMenuItem;
        private ToolStripMenuItem compareDatabaseToolStripMenuItem;
        private ToolStripMenuItem receivingEstimationFrom3rdPartyToolStripMenuItem;
        private CheckBox checkWBCode;
        private ToolStripMenuItem copyToNewCompanyToolStripMenuItem;
        private ToolStripMenuItem repairAllChecksumToolStripMenuItem;
        private ToolStripMenuItem splitReferenceToolStripMenuItem;
        private ToolStripMenuItem mergeDOToolStripMenuItem;
        private ToolStripMenuItem laporanPeneriamPerSupploerLA1ToolStripMenuItem;
        private ToolStripMenuItem formulaRendemenToolStripMenuItemPOM;
        private ToolStripMenuItem nonContractTransactionToolStripMenuItem;
        private ToolStripMenuItem vendorSummaryToolStripMenuItem;
        private ToolStripMenuItem logOffToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem12;
        private ToolStripMenuItem copraReportToolStripMenuItem;
        private ToolStripMenuItem dailyReceiptSupplierToolStripMenuItem;
        private Timer timer1;
        private ToolStripMenuItem UploadTypeToolStripMenuItem;
        private ToolStripMenuItem reportOutstandingDOToolStripMenuItem;
        private ToolStripMenuItem DLAdoptMenuItem;
        private ToolStripMenuItem tokenToolStripMenuItem;
        private ToolStripMenuItem editQuantityToolStripMenuItem;
        private Timer timerTokenEmail;
        private BackgroundWorker backgroundWorkerEmail;
        private ToolStripMenuItem mapCommTrxTypeToolStripMenuItem;
        private Label label2;
        private ToolStripMenuItem truckArrivalToolStripMenuItem;
        private ToolStripMenuItem gatepassToolStripMenuItem;
        private ToolStripMenuItem sourceToolStripMenuItem;
        private ToolStripMenuItem loadUloadToolStripMenuItem;
        private ToolStripMenuItem divideBlockToolStripMenuItem;
        private ToolStripMenuItem aBWBlockToolStripMenuItemPOM;
        private ToolStripMenuItem emailRecipientToolStripMenuItem;
        private ToolStripMenuItem bagToolStripMenuItem;
        private ToolStripMenuItem gatepassReportToolStripMenuItem;
        private ToolStripMenuItem dailyFFBReportByYearOfPlantationToolStripMenuItem;
        private ToolStripMenuItem dailyFFBReportByAllYearOfPlantationToolStripMenuItem;
        private ToolStripMenuItem millToolStripMenuItem;
        private ToolStripMenuItem containerToolStripMenuItem;
        private ToolStripMenuItem batchToolStripMenuItem;
        private ToolStripMenuItem weighbridgeControlToolStripMenuItem;
        private ToolStripMenuItem changeProfileToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator4;
        private ToolStripMenuItem saveColumnPositionToolStripMenuItem;
        private ToolStripMenuItem loadColumnPositionToolStripMenuItem;
        private ToolStripMenuItem deductedByToolStripMenuItem;
        private ToolStripMenuItem logReportToolStripMenuItem;
        private ToolStripMenuItem transactionLogToolStripMenuItem;
        private ToolStripMenuItem masterDataLogToolStripMenuItem;
        private ToolStripMenuItem migrateOldLogToNewOneToolStripMenuItem;
        private ToolStripMenuItem settingLogToolStripMenuItem;
        private ToolStripMenuItem locationLogToolStripMenuItem;
        private ToolStripMenuItem userListLogToolStripMenuItem;
        private ToolStripMenuItem userLoginLogoutLogToolStripMenuItem;
        private ToolStripMenuItem authorizationLogToolStripMenuItem;
        private ToolStripMenuItem templateSAPLogToolStripMenuItem;
        private ToolStripMenuItem indicatorStabilityReportToolStripMenuItem;
        private ToolStripMenuItem userManagementReportToolStripMenuItem;
        private ToolStripMenuItem userListReportToolStripMenuItem;
        private ToolStripMenuItem accessRightReportToolStripMenuItem;
        private ToolStripMenuItem emailRecipientReportToolStripMenuItem;
        private ToolStripMenuItem hardwareConfigurationToolStripMenuItem;

        public MainFormAfrica()
        {
            this.fm.label1.Text = "Preparing . . . . . . . ";
            this.fm.Show();
            this.fm.Refresh();
            this.InitializeComponent();
        }

        private void _weighMenuActivate()
        {
            if (WBSetting.transflow == "1")
            {
                this.truckArrivalToolStripMenuItem.Visible = false;
                this.gatepassToolStripMenuItem.Visible = false;
            }
            else if (WBSetting.transflow == "2")
            {
                this.gatepassToolStripMenuItem.Visible = true;
                this.truckArrivalToolStripMenuItem.Visible = false;
            }
            else if (WBSetting.transflow == "3")
            {
                this.truckArrivalToolStripMenuItem.Visible = true;
                this.gatepassToolStripMenuItem.Visible = true;
            }
            this.divideBlockToolStripMenuItem.Visible = WBSetting.locType == "1";
            this.stWeightToolStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS", "A");
            this.toolStripMenuItem11.Enabled = WBUser.CheckTrustee("TRANS", "A");
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.qcStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS_QC", "E");
            this.printToolStripMenuItem.Enabled = (WBSetting.Field("GM").ToString() != "Y") ? WBUser.CheckTrustee("MN_PRINT", "V") : true;
            if (WBSetting.Field("GM") == "Y")
            {
                this.editQuantityToolStripMenuItem.Visible = true;
                this.editQuantityToolStripMenuItem.Enabled = true;
            }
            else if ((WBUser.UserLevel != "2") && (WBUser.UserLevel != "1"))
            {
                this.editQuantityToolStripMenuItem.Visible = false;
                this.editQuantityToolStripMenuItem.Enabled = true;
            }
            else
            {
                this.editQuantityToolStripMenuItem.Visible = true;
                this.editQuantityToolStripMenuItem.Enabled = true;
            }
            if (this.dataGridView1.Rows.Count <= 0)
            {
                this.ndWeightToolStripMenuItem.Enabled = false;
                this.rdWeightToolStripMenuItem.Enabled = false;
                this.thWeightToolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
                this.cancelRecordToolStripMenuItem.Enabled = false;
                this.printToolStripMenuItem.Enabled = false;
                this.qcStripMenuItem.Enabled = false;
                if (WBSetting.Field("GM") == "Y")
                {
                    this.editQuantityToolStripMenuItem.Enabled = false;
                }
            }
            else
            {
                if (this.dataGridView1.CurrentRow.Cells["deleted"].Value.ToString().Trim() == "Y")
                {
                    this.ndWeightToolStripMenuItem.Enabled = false;
                    this.rdWeightToolStripMenuItem.Enabled = false;
                    this.thWeightToolStripMenuItem.Enabled = false;
                    this.editRecordToolStripMenuItem.Enabled = true;
                    this.editRecordToolStripMenuItem.Text = "View Record";
                    this.cancelRecordToolStripMenuItem.Enabled = false;
                    this.printToolStripMenuItem.Enabled = false;
                    this.qcStripMenuItem.Enabled = false;
                    if (WBSetting.Field("GM") == "Y")
                    {
                        this.editQuantityToolStripMenuItem.Enabled = false;
                    }
                }
                else
                {
                    string str2 = this.dataGridView1.CurrentRow.Cells["_2ND"].Value.ToString().Trim();
                    string str3 = this.dataGridView1.CurrentRow.Cells["_3RD"].Value.ToString().Trim();
                    string str4 = this.dataGridView1.CurrentRow.Cells["_4TH"].Value.ToString().Trim();
                    string str5 = this.dataGridView1.CurrentRow.Cells["Printed"].Value.ToString().Trim();
                    this.ndWeightToolStripMenuItem.Enabled = ((str2 == "0") || (str2 == "")) ? WBUser.CheckTrustee("TRANS", "A") : false;
                    this.rdWeightToolStripMenuItem.Enabled = (!this.ndWeightToolStripMenuItem.Enabled && ((str3 == "0") || (str3 == ""))) && WBUser.CheckTrustee("TRANS", "A");
                    this.thWeightToolStripMenuItem.Enabled = (!this.ndWeightToolStripMenuItem.Enabled && (!this.rdWeightToolStripMenuItem.Enabled && ((str4 == "0") || (str4 == "")))) && WBUser.CheckTrustee("TRANS", "A");
                    if (WBSetting.Field("GM").ToString() == "N")
                    {
                        this.printToolStripMenuItem.Enabled = (str5.Trim() == "") || WBUser.CheckTrustee("MN_PRINT", "V");
                        this.editRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS", "E");
                        this.cancelRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS", "D");
                    }
                    else
                    {
                        this.printToolStripMenuItem.Enabled = true;
                        this.editRecordToolStripMenuItem.Enabled = true;
                        this.cancelRecordToolStripMenuItem.Enabled = true;
                        this.editQuantityToolStripMenuItem.Enabled = true;
                    }
                    this.repairAllChecksumToolStripMenuItem.Visible = Convert.ToInt32(WBUser.UserLevel) == 1;
                    this.repairChecksumToolStripMenuItem.Enabled = Convert.ToInt32(WBUser.UserLevel) == 1;
                    this.splitReferenceToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TRANS_SPLIT", "A");
                    this.mergeDOToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TRANS_SPLIT", "E");
                }
                string str = this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim();
                if ((str == "2X") || (str == ""))
                {
                    this.rdWeightToolStripMenuItem.Enabled = false;
                    this.thWeightToolStripMenuItem.Enabled = false;
                }
                if (str == "")
                {
                    this.ndWeightToolStripMenuItem.Enabled = false;
                }
            }
        }

        private void aBWBlockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormBlockABW kabw = new FormBlockABW();
            kabw.ShowDialog();
            kabw.Dispose();
        }

        private void accessRightReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new RepAccessRight().generateRep();
        }

        private void authorizationLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepMasterDataLog log = new RepMasterDataLog {
                Text = "Authorization Log Report",
                labelHeader = { Text = "Log of Authorization" },
                labelMasterData = { Text = "Log for: " },
                flag = "AUTHORIZATION"
            };
            log.ShowDialog();
            log.Dispose();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            if (WBSetting.cpuSAP == "Y")
            {
                this.uploadSAP();
            }
        }

        private void backgroundWorker2_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
        }

        private void backgroundWorkerEmail_DoWork(object sender, DoWorkEventArgs e)
        {
            DateTime time;
            this.isSendEmail = true;
            WBMail mail = new WBMail();
            string str = "";
            string str2 = "";
            string zPath = "";
            WBTable table = new WBTable();
            table.OpenTable("Wb_email", "select * from wb_email where " + WBData.CompanyLocation(" and Email_date = '" + DateTime.Now.AddDays(-1.0).ToString("yyyy-MM-dd") + " 00:00:00' order by Email_code"), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                table.DR = table.DT.NewRow();
                table.DR["Email_code"] = "NOLOG";
                table.DR["Status"] = "N";
                table.DR["Coy"] = WBData.sCoyCode;
                table.DR["location_code"] = WBData.sLocCode;
                table.DR["Email_Date"] = DateTime.Now.AddDays(-1.0).ToString("yyyy-MM-dd");
                table.DT.Rows.Add(table.DR);
                table.Save();
            }
            table = new WBTable();
            string[] textArray1 = new string[] { "SELECT * FROM wb_email WHERE ", WBData.CompanyLocation(" "), "AND Status = 'N' AND Email_date < '", DateTime.Now.ToString("yyyy-MM-dd"), " 00:00:00' AND email_code != 'WB_CALIBRATION' ORDER BY Email_code" };
            string sqltext = string.Concat(textArray1);
            table.OpenTable("Wb_email", sqltext, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                foreach (DataRow row in table.DT.Rows)
                {
                    try
                    {
                        row.BeginEdit();
                        str = row["email_code"].ToString().ToUpper();
                        time = Convert.ToDateTime(row["email_date"].ToString());
                        time.AddDays(-1.0);
                        if (str == "CONTRACTLOG")
                        {
                            RepMasterDataLog log = new RepMasterDataLog();
                            log.defineCombo();
                            log.monthCalendar1.Value = time;
                            log.monthCalendar2.Value = time;
                            log.flag = "MASTER_DATA";
                            log.comboMasterData.Text = "CONTRACT";
                            log.generateRep(true, time, time, "", row["coy"].ToString(), row["location_code"].ToString(), "1");
                            log.Dispose();
                        }
                        else if (str == "TRANSLOG")
                        {
                            RepTransLog_New new2 = new RepTransLog_New {
                                monthCalendar1 = { Value = time },
                                monthCalendar2 = { Value = time }
                            };
                            new2.generateRep(true, time, time, "", row["coy"].ToString(), row["location_code"].ToString(), "1");
                            new2.Dispose();
                        }
                        mail.To = WBSetting.Field("GMEMail").ToString();
                        mail.CC = WBSetting.Field("GMEMailCC").ToString();
                        if (str == "NOLOG")
                        {
                            string[] textArray6 = new string[] { "NO WB.NET REPORT (", row["coy"].ToString().Trim(), " - ", row["location_code"].ToString().Trim(), ") " };
                            mail.Subject = string.Concat(textArray6);
                            str2 = (((("Dear All, <br><br><table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name")) + "</tr></table>") + "<br><br>NO HISTORY Report For Date : " + time.ToString("dd/MM/yyyy")) + "<br><br>Thank You. ";
                        }
                        else
                        {
                            if (str == "CONTRACTLOG")
                            {
                                string[] textArray2 = new string[] { Application.UserAppDataPath, @"\LogReport\", row["coy"].ToString(), row["location_code"].ToString(), "MASTERLOG_", time.ToString("ddMMyyyy"), ".htm" };
                                zPath = string.Concat(textArray2);
                            }
                            else
                            {
                                string[] textArray3 = new string[] { Application.UserAppDataPath, @"\LogReport\", row["coy"].ToString(), row["location_code"].ToString(), str, "_", time.ToString("ddMMyyyy"), ".htm" };
                                zPath = string.Concat(textArray3);
                            }
                            mail.mailAttachment(zPath);
                            str2 = (("Dear All, <br><br><table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name")) + "</tr></table>";
                            if (str == "CONTRACTLOG")
                            {
                                str2 = str2 + "<br><br>Attached DO HISTORY Report For Date : " + time.ToString("dd/MM/yyyy");
                            }
                            else if (str == "TRANSLOG")
                            {
                                str2 = str2 + "<br><br>Attached TRANSACTION HISTORY Report For Date : " + time.ToString("dd/MM/yyyy");
                            }
                            str2 = str2 + "<br><br>Thank You. ";
                            if (str == "CONTRACTLOG")
                            {
                                string[] textArray4 = new string[] { "DO HISTORY REPORT WB.NET (", row["coy"].ToString().Trim(), " - ", row["location_code"].ToString().Trim(), ") " };
                                mail.Subject = string.Concat(textArray4);
                            }
                            else if (str == "TRANSLOG")
                            {
                                string[] textArray5 = new string[] { "TRANSACTION HISTORY REPORT WB.NET (", row["coy"].ToString().Trim(), " - ", row["location_code"].ToString().Trim(), ") " };
                                mail.Subject = string.Concat(textArray5);
                            }
                        }
                        mail.Body = str2;
                        mail.SendMail();
                        row["Status"] = 'Y';
                        row.EndEdit();
                    }
                    catch
                    {
                    }
                }
                table.Save();
                mail.Dispose();
            }
            table = new WBTable();
            string[] textArray7 = new string[] { "SELECT * FROM wb_email WHERE ", WBData.CompanyLocation(" "), "AND Status = 'N' AND Email_date <= '", DateTime.Now.ToString("yyyy-MM-dd"), " 00:00:00' AND email_code = 'WB_CALIBRATION' ORDER BY Email_date" };
            sqltext = string.Concat(textArray7);
            table.OpenTable("Wb_email", sqltext, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                foreach (DataRow row2 in table.DT.Rows)
                {
                    try
                    {
                        row2.BeginEdit();
                        str = row2["email_code"].ToString().ToUpper();
                        time = Convert.ToDateTime(row2["email_date"].ToString());
                        time.AddDays(-1.0);
                        mail.To = WBSetting.Field("GMEMail").ToString();
                        mail.CC = WBSetting.Field("GMEMailCC").ToString();
                        mail.haveAttachment = false;
                        str2 = (((("Dear All, <br><br><table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBData.sLocName) + "</tr></table>") + "<br><br>Below is list of expired / almost expired WB Calibration Certification per : " + time.ToString("dd/MM/yyyy") + "<br><br>") + "<table border=1 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><th nowrap>No.</th><th nowrap>WB Code</th><th nowrap>Certification No</th><th nowrap>Calibration Date</th><th nowrap>Valid Date</th><th nowrap>Remark</th></tr>";
                        WBTable table2 = new WBTable();
                        int num = 1;
                        table2.OpenTable("wb_setting", "SELECT DISTINCT(wbCode) FROM wb_setting WHERE " + WBData.CompanyLocation("  AND usedForWeighing = 'Y'"), WBData.conn);
                        foreach (DataRow row3 in table2.DT.Rows)
                        {
                            WBTable table3 = new WBTable();
                            table3.OpenTable("wb_calibration", "SELECT TOP 1 * FROM wb_calibration WHERE " + WBData.CompanyLocation(" AND WBCode = '" + row3["wbcode"].ToString() + "' ORDER BY valid_date DESC"), WBData.conn);
                            if (table3.DT.Rows.Count > 0)
                            {
                                table3.DR = table3.DT.Rows[0];
                                DateTime time3 = Convert.ToDateTime(Convert.ToDateTime(table3.DR["valid_date"].ToString()).ToShortDateString());
                                DateTime time4 = Convert.ToDateTime(Convert.ToDateTime(table3.DR["calibration_date"].ToString()).ToShortDateString());
                                DateTime time5 = Convert.ToDateTime(DateTime.Now.ToShortDateString());
                                if (time3 <= time5)
                                {
                                    object[] objArray1 = new object[12];
                                    objArray1[0] = str2;
                                    objArray1[1] = "<tr class='bd' style='background-color:red'><td nowrap align='center'>";
                                    objArray1[2] = num;
                                    objArray1[3] = "</td><td nowrap>";
                                    objArray1[4] = table3.DR["wbcode"].ToString();
                                    objArray1[5] = "</td><td nowrap>";
                                    objArray1[6] = table3.DR["certification_no"].ToString();
                                    objArray1[7] = "</td><td nowrap>";
                                    objArray1[8] = Convert.ToDateTime(table3.DR["calibration_date"].ToString()).ToString("dd/MM/yyyy");
                                    objArray1[9] = "</td><td nowrap>";
                                    objArray1[10] = Convert.ToDateTime(table3.DR["valid_date"].ToString()).ToString("dd/MM/yyyy");
                                    objArray1[11] = "</td><td nowrap>Certification has been expired</td></tr>";
                                    str2 = string.Concat(objArray1);
                                }
                                else if (((time3 > time5) && (time4 <= time5)) && ((time3 - time5).Days <= this.intervalForCalibration))
                                {
                                    object[] objArray2 = new object[14];
                                    objArray2[0] = str2;
                                    objArray2[1] = "<tr class='bd' style='background-color:yellow'><td nowrap align='center'>";
                                    objArray2[2] = num;
                                    objArray2[3] = "</td><td nowrap>";
                                    objArray2[4] = table3.DR["wbcode"].ToString();
                                    objArray2[5] = "</td><td nowrap>";
                                    objArray2[6] = table3.DR["certification_no"].ToString();
                                    objArray2[7] = "</td><td nowrap>";
                                    objArray2[8] = Convert.ToDateTime(table3.DR["calibration_date"].ToString()).ToString("dd/MM/yyyy");
                                    objArray2[9] = "</td><td nowrap>";
                                    objArray2[10] = Convert.ToDateTime(table3.DR["valid_date"].ToString()).ToString("dd/MM/yyyy");
                                    objArray2[11] = "</td><td nowrap>Certification will be expired in ";
                                    objArray2[12] = (time3 - time5).Days;
                                    objArray2[13] = " day(s)</td></tr>";
                                    str2 = string.Concat(objArray2);
                                }
                                num++;
                            }
                            table3.Dispose();
                        }
                        table2.Dispose();
                        mail.Body = str2 + "</table>" + "<br><br>Thank You. ";
                        if (mail.SendMail())
                        {
                            row2["Status"] = 'Y';
                        }
                        row2.EndEdit();
                    }
                    catch
                    {
                    }
                }
                mail.Dispose();
                table.Save();
            }
            this.isSendEmail = false;
        }

        private void bagToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormBag bag = new FormBag();
            bag.ShowDialog();
            bag.Dispose();
        }

        private void batchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormBatch batch = new FormBatch();
            batch.ShowDialog();
            batch.Dispose();
        }

        private void bgWorkerLoading_DoWork(object sender, DoWorkEventArgs e)
        {
        }

        private void bgWorkerLoading_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
        }

        private void blockStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_BLOCK", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormBlock block = new FormBlock();
                block.ShowDialog();
                block.Dispose();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            string sqltext = !this.checkBox1.Checked ? ("Select " + this.cField + " From wb_transaction Where " + WBData.CompanyLocation(" AND " + WBData.NotMarkDeleted)) : ("Select " + this.cField + " From wb_transaction Where " + WBData.CompanyLocation(""));
            if (this.checkPartial.Checked)
            {
                sqltext = sqltext + " and (_2nd=0 or( WX='4X' and (_3rd=0 or _4th=0)))" + " and (split ='N' or split is null) ";
            }
            else
            {
                this.dFrom = this.dateTimePicker1.Value;
                this.dTo = this.dateTimePicker2.Value;
                string str2 = Program.DTOC(this.dFrom) + " 00:00:00";
                string str3 = Program.DTOC(this.dTo) + " 00:00:00";
                string[] textArray1 = new string[] { sqltext, " and (Ref_Date>='", str2, "' and Ref_Date<='", str3, "')" };
                sqltext = string.Concat(textArray1);
            }
            if (this.checkWBCode.Checked)
            {
                string[] textArray2 = new string[] { sqltext, " and (WBCode1 = '", WBData.sWBCode, "' or WBCode2 = '", WBData.sWBCode, "' )" };
                sqltext = string.Concat(textArray2);
            }
            this.Trans.Close();
            this.Trans.OpenTable("wb_transaction", sqltext, WBData.conn);
            this.DataReset();
            Cursor.Current = Cursors.Default;
            this.ShowStatus();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.Trans.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void CacheDisplayOrder()
        {
            FileStream stream = new FileStream(Directory.GetParent(Application.UserAppDataPath) + @"\col_pos.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            int[] o = new int[this.dataGridView1.ColumnCount];
            int index = 0;
            while (true)
            {
                if (index >= this.dataGridView1.ColumnCount)
                {
                    new XmlSerializer(typeof(int[])).Serialize((Stream) stream, o);
                    stream.Close();
                    return;
                }
                o[index] = this.dataGridView1.Columns[index].DisplayIndex;
                index++;
            }
        }

        private void cancelRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Resource.Mes_492 + " (Ref = " + this.dataGridView1.CurrentRow.Cells["REF"].Value.ToString() + " ) ? ", Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                if ((this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == "X") || (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == "Y"))
                {
                    MessageBox.Show(Resource.Mes_494, Resource.Title_002);
                }
                else
                {
                    string str = "";
                    string str2 = "";
                    str = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                    if (str.Substring(str.Length - 1, 1) == "T")
                    {
                        MessageBox.Show(Resource.Mes_493, Resource.Title_002);
                    }
                    else
                    {
                        str = "";
                        if (this.checkWeightValid("DELETE") && (this.dataGridView1.Rows.Count > 0))
                        {
                            string[] aField = new string[] { "Uniq" };
                            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString() };
                            int recNo = this.Trans.GetRecNo(aField, aFind);
                            if ((this.Trans.DT.Rows[recNo]["Deleted"].ToString() != "Y") && !this.Trans.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1'))
                            {
                                str2 = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                                if (this.Trans.BeforeEdit(this.dataGridView1, "CANCEL"))
                                {
                                    FormTransactionAfrica africa = new FormTransactionAfrica {
                                        tblTrans = this.Trans,
                                        pMode = "CANCEL",
                                        dgvTrans = this.dataGridView1,
                                        nCurrRow = recNo,
                                        sUniq = str2
                                    };
                                    africa.ShowDialog();
                                    this.Trans.UnLock();
                                    africa.Dispose();
                                    this.Trans.ReOpen();
                                    this.dataGridView1 = this.Trans.AfterEdit("CANCEL");
                                }
                            }
                        }
                    }
                }
            }
        }

        private void changeProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Hide();
            if (!WBUser.Login())
            {
                base.Show();
            }
            else
            {
                base.WindowState = FormWindowState.Minimized;
                this.Refresh();
                base.Show();
                this.fm = new FormMessage();
                this.fm.label1.Text = "Preparing . . . . . . . ";
                this.fm.Show();
                this.fm.Refresh();
                this.f_load();
                base.WindowState = FormWindowState.Maximized;
                this.fm.Dispose();
            }
        }

        private bool checkCompleteTrans(string aMenu)
        {
            string str = "0";
            string str2 = "0";
            if (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() != "2X")
            {
                if (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() != "4X")
                {
                    if (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() == "")
                    {
                        MessageBox.Show(Resource.Mes_506, Resource.Title_002);
                        return false;
                    }
                }
                else
                {
                    str2 = this.dataGridView1.CurrentRow.Cells["_4TH"].Value.ToString().Trim();
                    if ((str2 == "0") || (str2 == ""))
                    {
                        MessageBox.Show(Resource.Mes_503, Resource.Title_002);
                        return false;
                    }
                }
            }
            else
            {
                str = this.dataGridView1.CurrentRow.Cells["_2ND"].Value.ToString().Trim();
                if ((str == "0") || (str == ""))
                {
                    MessageBox.Show(Resource.Mes_503, Resource.Title_002);
                    return false;
                }
            }
            str = "0";
            str2 = "0";
            return true;
        }

        private void checkPartial_CheckedChanged(object sender, EventArgs e)
        {
            this.dateTimePicker1.Enabled = !this.checkPartial.Checked;
            this.dateTimePicker2.Enabled = !this.checkPartial.Checked;
            this.buttonFilter.PerformClick();
        }

        private void checkShowCheckSum_CheckedChanged(object sender, EventArgs e)
        {
            this.dataGridView1.Refresh();
        }

        private void checkWBCode_CheckedChanged(object sender, EventArgs e)
        {
            this.buttonFilter.PerformClick();
        }

        private bool checkWeightValid(string vpmode)
        {
            if (vpmode == "QC")
            {
                this.qcStripMenuItem.Enabled = WBUser.CheckTrustee("TRANS_QC", "E");
                if (!this.qcStripMenuItem.Enabled)
                {
                    return false;
                }
            }
            if (vpmode == "DL")
            {
                this.DLAdoptMenuItem.Enabled = WBUser.CheckTrustee("DL_ADOPT", "E");
                if (!this.qcStripMenuItem.Enabled)
                {
                    return false;
                }
            }
            if (vpmode != "2ND")
            {
                if (vpmode != "3RD")
                {
                    if (vpmode == "4TH")
                    {
                        string str3 = this.dataGridView1.CurrentRow.Cells["_4TH"].Value.ToString().Trim();
                        this.thWeightToolStripMenuItem.Enabled = (!this.ndWeightToolStripMenuItem.Enabled && !this.rdWeightToolStripMenuItem.Enabled) && ((str3 == "0") || (str3 == ""));
                        if (!this.thWeightToolStripMenuItem.Enabled)
                        {
                            return false;
                        }
                    }
                }
                else
                {
                    string str2 = this.dataGridView1.CurrentRow.Cells["_3RD"].Value.ToString().Trim();
                    this.rdWeightToolStripMenuItem.Enabled = !this.ndWeightToolStripMenuItem.Enabled && ((str2 == "0") || (str2 == ""));
                    if (!this.rdWeightToolStripMenuItem.Enabled)
                    {
                        return false;
                    }
                }
            }
            else
            {
                string str = this.dataGridView1.CurrentRow.Cells["_2ND"].Value.ToString().Trim();
                this.ndWeightToolStripMenuItem.Enabled = (str == "0") || (str == "");
                if (!this.ndWeightToolStripMenuItem.Enabled)
                {
                    return false;
                }
            }
            this.repairAllChecksumToolStripMenuItem.Visible = Convert.ToInt32(WBUser.UserLevel) == 1;
            if (vpmode == "EDIT")
            {
                if (!WBUser.CheckTrustee("TRANS", "E"))
                {
                    this.editRecordToolStripMenuItem.Enabled = false;
                    this.repairChecksumToolStripMenuItem.Enabled = false;
                    return false;
                }
                else
                {
                    this.editRecordToolStripMenuItem.Enabled = true;
                    this.repairChecksumToolStripMenuItem.Enabled = Convert.ToInt32(WBUser.UserLevel) < 3;
                }
            }
            return true;
        }

        private void compareDatabaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCompareDB edb = new FormCompareDB();
            edb.ShowDialog();
            edb.Dispose();
        }

        private void compositToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormComposit composit = new FormComposit();
            composit.ShowDialog();
            composit.Dispose();
        }

        private void configurationToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
        }

        private void containerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormContainer container = new FormContainer();
            container.ShowDialog();
            container.Dispose();
        }

        private void contractLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepContractLog log = new RepContractLog();
            log.ShowDialog();
            log.Dispose();
        }

        private void copraReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBLA1 pffbla = new RepFFBLA1 {
                checkBunch = { Checked = false },
                checkColly = { Checked = true },
                ffb = false
            };
            pffbla.ShowDialog();
            pffbla.Dispose();
        }

        private void copyToNewCompanyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewCoy coy = new NewCoy();
            coy.ShowDialog();
            coy.Dispose();
        }

        private void coytoolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCompany company = new FormCompany();
            company.ShowDialog();
            company.Dispose();
        }

        private void dailyFFBReportByAllYearOfPlantationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBYOPAll all = new RepFFBYOPAll();
            all.ShowDialog();
            all.Dispose();
        }

        private void dailyFFBReportByYearOfPlantationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBYOP pffbyop = new RepFFBYOP();
            pffbyop.ShowDialog();
            pffbyop.Dispose();
        }

        private void dailyReceiptSupplierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBLA2 pffbla = new RepFFBLA2 {
                checkBunch = { Checked = false },
                checkColly = { Checked = true },
                ffb = false
            };
            pffbla.ShowDialog();
            pffbla.Dispose();
        }

        private void databaseConnectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCfg cfg = new FormCfg {
                firstrun = false
            };
            cfg.ShowDialog();
            if (cfg.pReturn)
            {
                this.ShowLayout();
                this.DataReset();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.Timbang("VIEW");
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1.Rows[e.RowIndex].Cells["Deleted"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Red;
                e.CellStyle.SelectionBackColor = Color.HotPink;
            }
            else if (this.dataGridView1.Rows[e.RowIndex].Cells["zAuto"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Yellow;
                e.CellStyle.SelectionBackColor = Color.YellowGreen;
            }
            else if (this.checkShowCheckSum.Checked)
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.dataGridView1.Rows[e.RowIndex].Cells["uniq"].Value.ToString() };
                int recNo = this.Trans.GetRecNo(aField, aFind);
                if (!this.Trans.ValidChecksum(this.Trans.DT.Rows[recNo]))
                {
                    e.CellStyle.BackColor = Color.DimGray;
                    e.CellStyle.SelectionBackColor = Color.Gray;
                    e.CellStyle.ForeColor = Color.White;
                }
            }
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
            }
        }

        public void DataReset()
        {
            string str = this.dataGridView1.SortOrder.ToString();
            DataGridViewColumn sortedColumn = this.dataGridView1.SortedColumn;
            if (this.Trans.BeforeEdit(this.dataGridView1, "REFRESH"))
            {
                this.Trans.ReOpen();
                this.Trans.AfterEdit("REFRESH");
                ListSortDirection direction = (str != "Ascending") ? ListSortDirection.Descending : ListSortDirection.Ascending;
                this.dataGridView1.Sort(this.dataGridView1.Columns[sortedColumn.Name.ToString()], direction);
                if (this.Trans.DT.Rows.Count > 0)
                {
                    foreach (DataColumn column2 in this.Trans.DT.Columns)
                    {
                        this.Trans.DR = this.Trans.DT.Rows[0];
                        if (column2.ColumnName.ToString().ToUpper() == "NET")
                        {
                        }
                        if (this.Trans.DR[column2.ColumnName].GetType().ToString() == "System.Double")
                        {
                            this.dataGridView1.Columns[column2.ColumnName].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            this.dataGridView1.Columns[column2.ColumnName].DefaultCellStyle.Format = "N0";
                        }
                    }
                }
            }
            else
            {
                return;
            }
            this.dataGridView1.Refresh();
        }

        private void dateTimePicker1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFilter.PerformClick();
            }
        }

        private void dateTimePicker2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFilter.PerformClick();
            }
        }

        private void deductedByToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_DEDUCTED", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormDeductedBy by = new FormDeductedBy();
                by.ShowDialog();
                by.Dispose();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void divideBlockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                string str = "";
                if (this.dataGridView1.CurrentRow.Cells["Report_Date"].Value.ToString().Trim() == "")
                {
                    MessageBox.Show(Resource.Mes_257, Resource.Title_002);
                }
                else
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_comm", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.dataGridView1.CurrentRow.Cells["Comm_code"].Value.ToString().Trim() + "'"), WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        MessageBox.Show(Resource.Mes_511, Resource.Title_002);
                    }
                    else
                    {
                        table.DR = table.DT.Rows[0];
                        if (table.DR["type"].ToString().Trim() != "F")
                        {
                            MessageBox.Show(Resource.Mes_495, Resource.Title_002);
                            table.Dispose();
                        }
                        else
                        {
                            table.Dispose();
                            FormDivideBlock block = new FormDivideBlock();
                            str = this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString();
                            block.textRef.Text = this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString();
                            block.textNet.Text = $"{Program.StrToDouble(this.dataGridView1.CurrentRow.Cells["net"].Value.ToString(), 2):N0}";
                            block.textTransBunch.Text = $"{Program.StrToDouble(this.dataGridView1.CurrentRow.Cells["totalBunch"].Value.ToString(), 2):N0}";
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_transdo", "Select * from wb_transDO where ref = '" + str + "'", WBData.conn);
                            if (table2.DT.Rows.Count > 0)
                            {
                                block.labelEstateCode.Text = table2.DT.Rows[0]["Estate"].ToString();
                                WBTable table3 = new WBTable();
                                table3.OpenTable("wb_estate", "Select * from wb_estate where estate_code = '" + table2.DT.Rows[0]["Estate"].ToString() + "'", WBData.conn);
                                if (table3.DT.Rows.Count > 0)
                                {
                                    block.labelEstateName.Text = table3.DT.Rows[0]["Estate_name"].ToString();
                                }
                                table3.Dispose();
                            }
                            table2.Dispose();
                            block.ShowDialog();
                            this.Trans.ReOpen();
                            this.dataGridView1 = this.Trans.AfterEdit(this.pMode);
                            this.dataGridView1.Sort(this.dataGridView1.Columns["Ref"], ListSortDirection.Ascending);
                            string[] aField = new string[] { "Ref" };
                            string[] aFind = new string[] { str };
                            this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                        }
                    }
                }
            }
        }

        private void divisionReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepDivision division = new RepDivision();
            division.ShowDialog();
            division.Dispose();
        }

        private void DLAdoptMenuItem_Click(object sender, EventArgs e)
        {
            if (WBUser.CheckTrustee("DL_ADOPT", "V"))
            {
                this.Timbang("DL");
            }
        }

        private void doDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepRecIssue issue = new RepRecIssue();
            issue.ShowDialog();
            issue.Dispose();
        }

        private void editQuantityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Timbang("QTY");
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkWeightValid("EDIT"))
            {
                this.Timbang("EDIT");
            }
        }

        private void emailRecipientReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepEmailRecipient recipient = new RepEmailRecipient();
            recipient.ShowDialog();
            recipient.Dispose();
        }

        private void emailRecipientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_EMAIL", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormEmail email = new FormEmail();
                email.ShowDialog();
                email.Dispose();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Resource.Mes_184, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string keyField = "";
                string machineName = Environment.MachineName;
                string str3 = "";
                IPAddress[] addressList = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
                int index = 0;
                while (true)
                {
                    if (index >= addressList.Length)
                    {
                        WBTable table = new WBTable();
                        table.OpenTable("wb_user", "SELECT * FROM wb_user WHERE " + WBData.CompanyLocation(" AND user_id = '" + WBUser.UserID + "'"), WBData.conn);
                        if (table.DT.Rows.Count > 0)
                        {
                            table.DR = table.DT.Rows[0];
                            keyField = table.DR["uniq"].ToString();
                            table.DR.BeginEdit();
                            table.DR["lastLogout"] = DateTime.Now;
                            table.DR["lastLogoutIP"] = DateTime.Now.ToString("HH:mm:ss") + str3;
                            table.DR["lastLogoutCompName"] = DateTime.Now.ToString("HH:mm:ss") + machineName;
                            table.DR["checksum"] = table.Checksum(table.DR);
                            table.DR.EndEdit();
                            table.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "LOGSYS", WBUser.UserID, "Logout from system" };
                            Program.updateLogHeader("wb_user", keyField, logField, logValue);
                        }
                        table.Dispose();
                        if (Program.TMCready)
                        {
                            base.Close();
                        }
                        else
                        {
                            Application.Exit();
                        }
                        break;
                    }
                    IPAddress address = addressList[index];
                    AddressFamily addressFamily = address.AddressFamily;
                    if (addressFamily.ToString() == "InterNetwork")
                    {
                        str3 = address.ToString();
                    }
                    index++;
                }
            }
        }

        public void f_load()
        {
            int num1;
            WBSetting.OpenSetting(true);
            this.Status1.Text = "Wilmar Group - Copyright \x00a9, V." + base.ProductVersion.ToString() + "  Region : " + WBSetting.region;
            WBTable table = new WBTable();
            table.OpenTable("wb_loc", "select * from wb_location", WBData.conn);
            if ((table.DT.Rows[0]["version"].ToString() != base.ProductVersion.ToString()) && (string.Compare(base.ProductVersion.ToString(), table.DT.Rows[0]["version"].ToString()) >= 0))
            {
                table.DT.Rows[0]["version"] = base.ProductVersion.ToString();
                table.DT.Rows[0]["checksum"] = table.Checksum(table.DT.Rows[0]);
                table.Save();
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { "LOAD-LOGIN", "SYSTEM", "Update Version" };
                Program.updateLogHeader("wb_location", table.DT.Rows[0]["uniq"].ToString(), logField, logValue);
            }
            table.Dispose();
            this.timerSAPUpd.Enabled = false;
            this.lblDate.Visible = false;
            this.fm.label1.Text = "Loading WB.Net Setting . . . . . .";
            this.fm.label1.Refresh();
            this.cField = WBTable.cFieldTransAfrica;
            string s = WBSetting.colour.ToString();
            uint num3 = <PrivateImplementationDetails>.ComputeStringHash(s);
            if (num3 > 0x727b390b)
            {
                if (num3 > 0xa37f187c)
                {
                    if (num3 == 0xa953c75c)
                    {
                        if (s == "Green")
                        {
                            this.label1.BackColor = Color.Green;
                            goto TR_004D;
                        }
                    }
                    else if ((num3 == 0xb682ba1f) && (s == "Purple"))
                    {
                        this.label1.BackColor = Color.Purple;
                        goto TR_004D;
                    }
                }
                else if (num3 == 0x8bb8038d)
                {
                    if (s == "Pink")
                    {
                        this.label1.BackColor = Color.Pink;
                        goto TR_004D;
                    }
                }
                else if ((num3 == 0xa37f187c) && (s == "Red"))
                {
                    this.label1.BackColor = Color.Red;
                    goto TR_004D;
                }
            }
            else if (num3 == 0x2b043744)
            {
                if (s == "Black")
                {
                    this.label1.BackColor = Color.Black;
                    goto TR_004D;
                }
            }
            else if (num3 == 0x6c94b6b3)
            {
                if (s == "Gold")
                {
                    this.label1.BackColor = Color.Gold;
                    goto TR_004D;
                }
            }
            else if ((num3 == 0x727b390b) && (s == "Orange"))
            {
                this.label1.BackColor = Color.Orange;
                goto TR_004D;
            }
            this.label1.BackColor = Color.RoyalBlue;
        TR_004D:
            this.fm.label1.Text = "Loading WB.Net Data . . . . . .";
            this.fm.label1.Refresh();
            if (WBUser.UserGroup != "ADMIN")
            {
                this.locationToolStripMenuItem.Visible = false;
                this.coytoolStripMenuItem.Visible = false;
                this.copyToNewCompanyToolStripMenuItem.Visible = false;
                this.compareDatabaseToolStripMenuItem.Visible = false;
            }
            else
            {
                this.locationToolStripMenuItem.Visible = true;
                this.coytoolStripMenuItem.Visible = true;
                this.copyToNewCompanyToolStripMenuItem.Visible = true;
                this.compareDatabaseToolStripMenuItem.Visible = true;
            }
            this.Trans.OpenTable("wb_transaction", "Select " + this.cField + " From wb_transaction Where " + WBData.CompanyLocation(" AND 1=2 AND " + WBData.NotMarkDeleted), WBData.conn);
            this.dataGridView1.DataSource = this.Trans.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Date1"], ListSortDirection.Descending);
            this.dataGridView1.Columns["coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["seal"].Visible = false;
            this.dataGridView1.Columns["Delete_By"].Visible = false;
            this.dataGridView1.Columns["Delete_Date"].Visible = false;
            this.dataGridView1.Columns["deleted"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["In_Time"].Visible = false;
            this.dataGridView1.Columns["Out_Time"].Visible = false;
            this.dataGridView1.Columns["Nego"].Visible = false;
            this.dataGridView1.Columns["Sto"].Visible = false;
            this.dataGridView1.Columns["Gr"].Visible = false;
            this.dataGridView1.Columns["Do"].Visible = false;
            this.dataGridView1.Columns["Checksum"].Visible = false;
            this.dataGridView1.Columns["Report2_Date"].Visible = false;
            this.dataGridView1.Columns["Relation_Code"].Visible = false;
            this.dataGridView1.Columns["Tolling"].Visible = false;
            this.dataGridView1.Columns["zAuto"].Visible = false;
            if (Convert.ToInt16(WBSetting.transflow) < 2)
            {
                this.dataGridView1.Columns["Gatepass_Number"].Visible = false;
            }
            else
            {
                this.dataGridView1.Columns["Gatepass_Number"].Visible = true;
                this.dataGridView1.Columns["Gatepass_Number"].Width = 0x69;
            }
            this.dataGridView1.Columns["Edit_qty"].Visible = false;
            this.dataGridView1.Columns["Edit_data"].Visible = false;
            if (WBSetting.Field("GM") == "Y")
            {
                this.dataGridView1.Columns["token"].Visible = true;
                this.dataGridView1.Columns["Completed"].Visible = true;
            }
            else
            {
                this.dataGridView1.Columns["token"].Visible = false;
                this.dataGridView1.Columns["Completed"].Visible = false;
            }
            this.dataGridView1.Columns["WX"].HeaderText = "WX";
            this.dataGridView1.Columns["WX"].Width = 50;
            this.dataGridView1.Columns["Transaction_Code"].HeaderText = "Tx";
            this.dataGridView1.Columns["ref"].HeaderText = Resource.Main_013;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Ref"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["ref"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            this.dataGridView1.Columns["Ref"].Width = 0x69;
            this.dataGridView1.Columns["Ref_Date"].HeaderText = Resource.Main_011;
            this.dataGridView1.Columns["Gatepass_Number"].HeaderText = Resource.Main_012;
            this.dataGridView1.Columns["Comm_Code"].HeaderText = Resource.Main_016;
            this.dataGridView1.Columns["Truck_Number"].HeaderText = Resource.Main_017;
            if (WBSetting.Container != "Y")
            {
                this.dataGridView1.Columns["Truck_Trailer_Number"].Visible = false;
                this.dataGridView1.Columns["Truck_Number2"].Visible = false;
            }
            else
            {
                this.dataGridView1.Columns["Truck_Trailer_Number"].Visible = true;
                this.dataGridView1.Columns["Truck_Number2"].Visible = true;
                this.dataGridView1.Columns["Truck_Number2"].HeaderText = "2nd Vehicle No.";
                this.dataGridView1.Columns["Truck_Trailer_Number"].HeaderText = "Trailer No.";
            }
            this.dataGridView1.Columns["License_No"].HeaderText = Resource.Main_042;
            this.dataGridView1.Columns["Name"].HeaderText = Resource.Main_043;
            this.dataGridView1.Columns["Transporter_Code"].HeaderText = Resource.Main_044;
            this.dataGridView1.Columns["Delivery_Note"].HeaderText = Resource.Main_045;
            this.dataGridView1.Columns["Do_No"].HeaderText = Resource.Main_018;
            this.dataGridView1.Columns["Delivery_Date"].HeaderText = Resource.Main_036;
            this.dataGridView1.Columns["Delivery_Time"].HeaderText = Resource.Main_037;
            this.dataGridView1.Columns["Register_Date"].HeaderText = Resource.Main_038;
            this.dataGridView1.Columns["Register_Time"].HeaderText = Resource.Main_039;
            this.dataGridView1.Columns["Report_Date"].HeaderText = Resource.Main_035;
            this.dataGridView1.Columns["_1st"].HeaderText = Resource.Main_056;
            this.dataGridView1.Columns["Date1"].HeaderText = Resource.Main_057;
            this.dataGridView1.Columns["Time1"].HeaderText = Resource.Main_014;
            this.dataGridView1.Columns["_2nd"].HeaderText = Resource.Main_058;
            this.dataGridView1.Columns["Date2"].HeaderText = Resource.Main_059;
            this.dataGridView1.Columns["Time2"].HeaderText = Resource.Main_015;
            this.dataGridView1.Columns["_3rd"].HeaderText = Resource.Main_060;
            this.dataGridView1.Columns["Date3"].HeaderText = Resource.Main_061;
            this.dataGridView1.Columns["Time3"].HeaderText = Resource.Main_062;
            this.dataGridView1.Columns["_4th"].HeaderText = Resource.Main_063;
            this.dataGridView1.Columns["Date4"].HeaderText = Resource.Main_064;
            this.dataGridView1.Columns["Time4"].HeaderText = Resource.Main_065;
            this.dataGridView1.Columns["Estate_Code"].HeaderText = Resource.Main_040;
            this.dataGridView1.Columns["Storage"].HeaderText = Resource.Main_041;
            this.dataGridView1.Columns["Tanker"].HeaderText = Resource.Main_082;
            this.dataGridView1.Columns["TankQC"].HeaderText = Resource.Main_083;
            this.dataGridView1.Columns["MaxCap"].HeaderText = Resource.Main_084;
            this.dataGridView1.Columns["Unloading"].HeaderText = Resource.Main_046;
            this.dataGridView1.Columns["Remark_Ticket"].HeaderText = Resource.Main_047;
            this.dataGridView1.Columns["Remark_Report"].HeaderText = Resource.Main_048;
            this.dataGridView1.Columns["Gross"].HeaderText = Resource.Main_019;
            this.dataGridView1.Columns["Tare"].HeaderText = Resource.Main_020;
            this.dataGridView1.Columns["Received"].HeaderText = Resource.Main_021;
            this.dataGridView1.Columns["Deduction"].HeaderText = Resource.Main_022;
            this.dataGridView1.Columns["Net"].HeaderText = Resource.Main_023;
            this.dataGridView1.Columns["Gross_Estate"].HeaderText = Resource.Main_049;
            this.dataGridView1.Columns["Tare_Estate"].HeaderText = Resource.Main_050;
            this.dataGridView1.Columns["Net_Estate"].HeaderText = "Net Estate";
            this.dataGridView1.Columns["TotalBunch"].HeaderText = Resource.Main_024;
            this.dataGridView1.Columns["UnitName"].HeaderText = Resource.Main_066;
            this.dataGridView1.Columns["WeightPerUnitName"].HeaderText = Resource.Main_067;
            this.dataGridView1.Columns["TotalBunchGrading"].HeaderText = Resource.Main_025;
            this.dataGridView1.Columns["Average"].HeaderText = Resource.Main_051;
            this.dataGridView1.Columns["Fruits_Type"].HeaderText = Resource.Main_052;
            this.dataGridView1.Columns["Rend_CPO"].HeaderText = Resource.Main_053;
            this.dataGridView1.Columns["ISCC_Checked"].HeaderText = Resource.Main_085;
            this.dataGridView1.Columns["ISCC_No"].HeaderText = Resource.Main_087;
            this.dataGridView1.Columns["ISCC_No2"].HeaderText = Resource.Main_088;
            this.dataGridView1.Columns["ISCC_GC_Checked"].HeaderText = Resource.Main_086;
            this.dataGridView1.Columns["ISCC_Weight"].HeaderText = Resource.Main_089;
            this.dataGridView1.Columns["Estate"].HeaderText = Resource.Main_040;
            this.dataGridView1.Columns["ChangeReason"].HeaderText = Resource.Main_090;
            this.dataGridView1.Columns["Create_By"].HeaderText = Resource.Main_069;
            this.dataGridView1.Columns["Create_Date"].HeaderText = Resource.Main_070;
            this.dataGridView1.Columns["Change_By"].HeaderText = Resource.Main_071;
            this.dataGridView1.Columns["Change_Date"].HeaderText = Resource.Main_072;
            this.dataGridView1.Columns["Edit_By"].HeaderText = Resource.Main_073;
            this.dataGridView1.Columns["Edit_Date"].HeaderText = Resource.Main_074;
            this.dataGridView1.Columns["Edit_QC_By"].HeaderText = Resource.Main_075;
            this.dataGridView1.Columns["Edit_QC_Date"].HeaderText = Resource.Main_076;
            this.dataGridView1.Columns["Printed"].HeaderText = Resource.Main_077;
            this.dataGridView1.Columns["Printed_By"].HeaderText = Resource.Main_078;
            this.dataGridView1.Columns["Printed_Date"].HeaderText = Resource.Main_079;
            this.dataGridView1.Columns["Ticket"].HeaderText = Resource.Main_080;
            this.dataGridView1.Columns["ReturRef"].HeaderText = Resource.Main_081;
            this.dataGridView1.Columns["Approve"].HeaderText = Resource.Main_091;
            this.dataGridView1.Columns["ApproveBy1"].HeaderText = Resource.Main_092;
            this.dataGridView1.Columns["ApproveBy2"].HeaderText = Resource.Main_093;
            this.dataGridView1.Columns["WBCode1"].HeaderText = Resource.Main_094;
            this.dataGridView1.Columns["WBCode2"].HeaderText = Resource.Main_095;
            this.dataGridView1.Columns["WBCode3"].HeaderText = Resource.Main_096;
            this.dataGridView1.Columns["WBCode4"].HeaderText = Resource.Main_097;
            this.dataGridView1.Columns["Posted"].HeaderText = Resource.Main_098;
            this.dataGridView1.Columns["Manual"].HeaderText = Resource.Main_099;
            this.dataGridView1.Columns["NonContract"].HeaderText = Resource.Main_100;
            this.dataGridView1.Columns["EstateDiff"].HeaderText = Resource.Main_101;
            this.dataGridView1.Columns["Split"].HeaderText = Resource.Main_102;
            this.dataGridView1.Columns["TotalGunny"].HeaderText = Resource.Main_103;
            DateTime now = DateTime.Now;
            this.dateTimePicker1.Value = now.AddDays(-1.0);
            this.dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.dateTimePicker2.Value = DateTime.Now;
            this.dateTimePicker2.Format = DateTimePickerFormat.Short;
            this.checkPartial.Checked = true;
            int num = 3;
            this.Garis1.Width = num;
            this.Garis2.Width = num;
            base.KeyPreview = true;
            this.fm.label1.Text = "Loading WB.Net Layout . . . . . .";
            this.fm.label1.Refresh();
            this.ShowLayout();
            this.fm.label1.Text = "Loading WB.Net Authorization . . . . . .";
            this.fm.label1.Refresh();
            Cursor.Current = Cursors.WaitCursor;
            this.databaseConnectionToolStripMenuItem.Enabled = WBUser.CheckTrustee("CONFIG", "V");
            this.weighBridgeSettingToolStripMenuItem.Enabled = WBUser.CheckTrustee("CONFIG", "V");
            this.DOToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_CONTRACT", "V");
            this.commodityToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_STOCK", "V");
            this.relationToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_VENDOR", "V");
            this.truckToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TRUCK", "V");
            this.driverToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_DRIVER", "V");
            this.transpoterToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TRANSPORTER", "V");
            this.storageToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_STORAGE", "V");
            this.divisionToolStripMenuItemPOM.Enabled = WBUser.CheckTrustee("MD_DIVISION", "V");
            this.estateToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_ESTATE", "V");
            this.qCItemToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_QC", "V");
            this.DLAdoptMenuItem.Enabled = WBUser.CheckTrustee("DL_ADOPT", "V");
            this.compositToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_COMPOSIT", "V");
            this.tankerToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_CAPACITY", "V");
            this.gradingToolStripMenuItemPOM.Enabled = WBUser.CheckTrustee("MD_GRADING", "V");
            this.blockStripMenuItemPOM.Enabled = WBUser.CheckTrustee("MD_BLOCK", "V");
            this.templateSAPToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TEMPLATE", "V");
            this.transactionTypeToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TRANS_TYPE", "V");
            this.UploadTypeToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_UPLOAD_TYPE_LIST", "V");
            this.ManualEntryMenuItem.Enabled = (WBSetting.Field("GM").ToString() != "N") || (Convert.ToInt32(WBUser.UserLevel) < 3);
            this.hardwareConfigurationToolStripMenuItem.Enabled = (WBUser.UserLevel == "1") || WBUser.CheckTrustee("CONFIG_HARDWARE", "V");
            if ((WBUser.CheckTrustee("MN_PRINT", "V") || WBUser.CheckTrustee("TRANS", "P")) || (WBSetting.Field("GM").ToString() == "Y"))
            {
                this.fRpt = new FormRpt();
                try
                {
                    this.ticketRpt.Load(WBSetting.ticket);
                    this.ticketRpt = Program.rptLogon(this.ticketRpt);
                    this.fRpt.setReport(this.ticketRpt);
                }
                catch
                {
                    this.fm.label1.Text = "Weighning Ticket is Not Correctly Loaded . . . . . .";
                    this.fm.label1.Refresh();
                    MessageBox.Show(Resource.Mes_536, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                if (WBSetting.locType == "1")
                {
                    try
                    {
                        this.ticketGrading.Load(Application.StartupPath.ToString() + @"\Report\ticketGrading.rpt");
                        this.ticketGrading = Program.rptLogon(this.ticketGrading);
                        this.fRpt.setReport(this.ticketGrading);
                    }
                    catch
                    {
                        this.fm.label1.Text = "Grading Ticket is Not Correctly Loaded . . . . . .";
                        this.fm.label1.Refresh();
                        MessageBox.Show(Resource.Mes_512, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
            int num2 = 0;
            if (Program.StrToDouble(WBSetting.SAPInterval, 3) > 0.0)
            {
                num2 = Convert.ToInt16((double) (24.0 / Program.StrToDouble(WBSetting.SAPInterval, 3)));
                string[] strArray = new string[num2];
                int index = 0;
                while (true)
                {
                    if (index >= num2)
                    {
                        this.sapJamKirim = strArray;
                        this.timerSAPUpd.Enabled = true;
                        this.timerSAPUpd.Interval = 0xea60;
                        break;
                    }
                    DateTime time = Convert.ToDateTime(WBSetting.startTime).AddHours(index * Program.StrToDouble(WBSetting.SAPInterval, 3));
                    strArray[index] = Convert.ToString(time);
                    index++;
                }
            }
            if (WBSetting.SAPsch == "Y")
            {
                this.timerSAPUpd.Enabled = true;
                this.timerSAPUpd.Interval = 0xea60;
            }
            if ((WBSetting.Field("GM").ToString() == "Y") && (WBSetting.GMSend == "Y"))
            {
                this.timerTokenEmail.Enabled = true;
                this.timerTokenEmail.Interval = 0xea60;
            }
            if (WBSetting.locType == "0")
            {
                this.divisionToolStripMenuItemPOM.Visible = false;
                this.blockStripMenuItemPOM.Visible = false;
                this.aBWBlockToolStripMenuItemPOM.Visible = false;
                this.gradingToolStripMenuItemPOM.Visible = false;
                this.FFBReportToolStripMenuItemPOM.Visible = false;
                this.estateToolStripMenuItem.Visible = true;
            }
            else if (WBSetting.locType == "1")
            {
                this.divisionToolStripMenuItemPOM.Visible = true;
                this.blockStripMenuItemPOM.Visible = true;
                this.aBWBlockToolStripMenuItemPOM.Visible = true;
                this.estateToolStripMenuItem.Visible = true;
                this.gradingToolStripMenuItemPOM.Visible = true;
                this.FFBReportToolStripMenuItemPOM.Visible = true;
            }
            this.fm.label1.Text = "Loading WB.Net Menu . . . . . .";
            this.fm.label1.Refresh();
            this._weighMenuActivate();
            this.fm.label1.Text = "Application Ready";
            this.fm.label1.Refresh();
            if (WBSetting.checkISCC != "Y")
            {
                num1 = 0;
            }
            else
            {
                DateTime validDateISCC = WBSetting.validDateISCC;
                num1 = 1;
            }
            if (num1 != 0)
            {
                TimeSpan span = (TimeSpan) (WBSetting.validDateISCC - DateTime.Now);
                int num5 = span.Days + 1;
                if (num5 > 0)
                {
                    if (num5 <= 10)
                    {
                        MessageBox.Show(Resource.Mes_535A + num5 + Resource.Mes_535B, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_533, Resource.Title_008, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }
            }
            WBTable table2 = new WBTable();
            string str = "";
            bool flag = false;
            table2.OpenTable("wb_setting", "SELECT DISTINCT(wbCode) FROM wb_setting WHERE " + WBData.CompanyLocation("  AND usedForWeighing = 'Y'"), WBData.conn);
            foreach (DataRow row in table2.DT.Rows)
            {
                WBTable table3 = new WBTable();
                table3.OpenTable("wb_calibration", "SELECT TOP 1 * FROM wb_calibration WHERE " + WBData.CompanyLocation(" AND WBCode = '" + row["wbcode"].ToString() + "' ORDER BY valid_date DESC"), WBData.conn);
                if (table3.DT.Rows.Count > 0)
                {
                    table3.DR = table3.DT.Rows[0];
                    DateTime time3 = Convert.ToDateTime(Convert.ToDateTime(table3.DR["valid_date"].ToString()).ToShortDateString());
                    DateTime time4 = Convert.ToDateTime(Convert.ToDateTime(table3.DR["calibration_date"].ToString()).ToShortDateString());
                    DateTime time5 = Convert.ToDateTime(DateTime.Now.ToShortDateString());
                    if (time3 <= time5)
                    {
                        flag = true;
                        string[] textArray3 = new string[] { str, "Certification No ", table3.DR["certification_no"].ToString(), " for WBCode ", table3.DR["WBCode"].ToString(), " " };
                        str = ((string.Concat(textArray3) + "has been expired!\n") + "Calibration Date : " + Convert.ToDateTime(table3.DR["calibration_date"].ToString()).ToString("dd/MM/yyyy") + "\n") + "Valid Date : " + Convert.ToDateTime(table3.DR["valid_date"].ToString()).ToString("dd/MM/yyyy") + "\n\n";
                        if ((time3 == time5) && (table3.DR["lock_weighing"].ToString() == ""))
                        {
                            table3.DR.BeginEdit();
                            table3.DR["lock_weighing"] = "Y";
                            table3.DR.EndEdit();
                            table3.Save();
                        }
                    }
                    else if (((time3 > time5) && (time4 <= time5)) && ((time3 - time5).Days <= this.intervalForCalibration))
                    {
                        flag = true;
                        string[] textArray4 = new string[] { str, "Certification No ", table3.DR["certification_no"].ToString(), " for WBCode ", table3.DR["WBCode"].ToString(), " " };
                        str = string.Concat(textArray4);
                        object[] objArray1 = new object[] { str, "will be expired in ", (time3 - time5).Days, " day(s)!\n" };
                        str = (string.Concat(objArray1) + "Calibration Date : " + Convert.ToDateTime(table3.DR["calibration_date"].ToString()).ToString("dd/MM/yyyy") + "\n") + "Valid Date : " + Convert.ToDateTime(table3.DR["valid_date"].ToString()).ToString("dd/MM/yyyy") + "\n\n";
                    }
                }
                table3.Dispose();
            }
            if (flag)
            {
                MessageBox.Show("You WB Calibration period has been / almost expired!\n\n" + str + "Please renew period of WB Calibration.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                if (DateTime.Now.DayOfWeek == DayOfWeek.Monday)
                {
                    WBTable table4 = new WBTable();
                    table4.OpenTable("wb_email", "select * from wb_email where " + WBData.CompanyLocation(" and email_code = 'WB_CALIBRATION' and email_date = '" + DateTime.Now.ToString("yyyy-MM-dd") + " 00:00:00' "), WBData.conn);
                    if (table4.DT.Rows.Count <= 0)
                    {
                        table4.DR = table4.DT.NewRow();
                        table4.DR["COY"] = WBData.sCoyCode;
                        table4.DR["LOCATION_CODE"] = WBData.sLocCode;
                        table4.DR["Email_code"] = "WB_CALIBRATION";
                        table4.DR["Email_date"] = DateTime.Now.ToString("dd/MM/yyyy");
                        table4.DR["Status"] = "N";
                        table4.DT.Rows.Add(table4.DR);
                        table4.Save();
                    }
                    table4.Dispose();
                }
            }
            table2.Dispose();
            this.indicatorStabilityReportToolStripMenuItem.Visible = WBSetting.AutoCapture;
        }

        private void fFBGradingReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBGrading grading = new RepFFBGrading {
                tableDeduction = "wb_transactionD"
            };
            grading.ShowDialog();
            grading.Dispose();
        }

        private void FFBReportToolStripMenuItemPOM_Click(object sender, EventArgs e)
        {
        }

        private void formulaRendemenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormRendemen rendemen = new FormRendemen();
            rendemen.ShowDialog();
            rendemen.Dispose();
        }

        private void gatepassReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepGatepass gatepass = new RepGatepass();
            gatepass.ShowDialog();
            gatepass.Dispose();
        }

        private void gatepassToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MN_GATEPASS", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormGatepass gatepass = new FormGatepass();
                gatepass.ShowDialog();
                gatepass.Dispose();
            }
        }

        private void gegerateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            string text = random.Next(0, 0x1869f).ToString();
            while (true)
            {
                if (text.Length < 5)
                {
                    MessageBox.Show(text);
                    return;
                }
                text = random.Next(0, 0x1869f).ToString();
            }
        }

        private void hardwareConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSettingHardware hardware = new FormSettingHardware();
            hardware.ShowDialog();
            hardware.Dispose();
        }

        private void indicatorStabilityReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepIndicator indicator = new RepIndicator();
            indicator.ShowDialog();
            indicator.Dispose();
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            ComponentResourceManager manager = new ComponentResourceManager(typeof(MainFormAfrica));
            this.menuStrip1 = new MenuStrip();
            this.WeighingMenuItem = new ToolStripMenuItem();
            this.truckArrivalToolStripMenuItem = new ToolStripMenuItem();
            this.gatepassToolStripMenuItem = new ToolStripMenuItem();
            this.stWeightToolStripMenuItem = new ToolStripMenuItem();
            this.ndWeightToolStripMenuItem = new ToolStripMenuItem();
            this.rdWeightToolStripMenuItem = new ToolStripMenuItem();
            this.thWeightToolStripMenuItem = new ToolStripMenuItem();
            this.splitReferenceToolStripMenuItem = new ToolStripMenuItem();
            this.mergeDOToolStripMenuItem = new ToolStripMenuItem();
            this.divideBlockToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem11 = new ToolStripMenuItem();
            this.ManualEntryMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem8 = new ToolStripSeparator();
            this.qcStripMenuItem = new ToolStripMenuItem();
            this.DLAdoptMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator1 = new ToolStripSeparator();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editQuantityToolStripMenuItem = new ToolStripMenuItem();
            this.cancelRecordToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem9 = new ToolStripMenuItem();
            this.printToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator2 = new ToolStripSeparator();
            this.toolStripMenuItem10 = new ToolStripMenuItem();
            this.toolStripSeparator3 = new ToolStripSeparator();
            this.repairChecksumToolStripMenuItem = new ToolStripMenuItem();
            this.repairAllChecksumToolStripMenuItem = new ToolStripMenuItem();
            this.masterDataToolStripMenuItem1 = new ToolStripMenuItem();
            this.DOToolStripMenuItem = new ToolStripMenuItem();
            this.commodityToolStripMenuItem = new ToolStripMenuItem();
            this.relationToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripSeparator();
            this.truckToolStripMenuItem = new ToolStripMenuItem();
            this.containerToolStripMenuItem = new ToolStripMenuItem();
            this.driverToolStripMenuItem = new ToolStripMenuItem();
            this.transpoterToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem2 = new ToolStripSeparator();
            this.coytoolStripMenuItem = new ToolStripMenuItem();
            this.locationToolStripMenuItem = new ToolStripMenuItem();
            this.estateToolStripMenuItem = new ToolStripMenuItem();
            this.divisionToolStripMenuItemPOM = new ToolStripMenuItem();
            this.blockStripMenuItemPOM = new ToolStripMenuItem();
            this.aBWBlockToolStripMenuItemPOM = new ToolStripMenuItem();
            this.millToolStripMenuItem = new ToolStripMenuItem();
            this.sourceToolStripMenuItem = new ToolStripMenuItem();
            this.loadUloadToolStripMenuItem = new ToolStripMenuItem();
            this.bagToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem4 = new ToolStripSeparator();
            this.UploadTypeToolStripMenuItem = new ToolStripMenuItem();
            this.batchToolStripMenuItem = new ToolStripMenuItem();
            this.storageToolStripMenuItem = new ToolStripMenuItem();
            this.gradingToolStripMenuItemPOM = new ToolStripMenuItem();
            this.qualityToolStripMenuItem = new ToolStripMenuItem();
            this.qCItemToolStripMenuItem = new ToolStripMenuItem();
            this.compositToolStripMenuItem = new ToolStripMenuItem();
            this.tankerToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem3 = new ToolStripSeparator();
            this.transactionTypeToolStripMenuItem = new ToolStripMenuItem();
            this.templateSAPToolStripMenuItem = new ToolStripMenuItem();
            this.formulaRendemenToolStripMenuItemPOM = new ToolStripMenuItem();
            this.mapCommTrxTypeToolStripMenuItem = new ToolStripMenuItem();
            this.emailRecipientToolStripMenuItem = new ToolStripMenuItem();
            this.deductedByToolStripMenuItem = new ToolStripMenuItem();
            this.configurationToolStripMenuItem = new ToolStripMenuItem();
            this.databaseConnectionToolStripMenuItem = new ToolStripMenuItem();
            this.weighBridgeSettingToolStripMenuItem = new ToolStripMenuItem();
            this.weighbridgeControlToolStripMenuItem = new ToolStripMenuItem();
            this.hardwareConfigurationToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem6 = new ToolStripSeparator();
            this.userListToolStripMenuItem = new ToolStripMenuItem();
            this.userGroupToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem7 = new ToolStripSeparator();
            this.copyToNewCompanyToolStripMenuItem = new ToolStripMenuItem();
            this.compareDatabaseToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator4 = new ToolStripSeparator();
            this.saveColumnPositionToolStripMenuItem = new ToolStripMenuItem();
            this.loadColumnPositionToolStripMenuItem = new ToolStripMenuItem();
            this.ReportToolStripMenuItem = new ToolStripMenuItem();
            this.FFBReportToolStripMenuItemPOM = new ToolStripMenuItem();
            this.subRP1ToolStripMenuItem = new ToolStripMenuItem();
            this.dailyFFBReportByYearOfPlantationToolStripMenuItem = new ToolStripMenuItem();
            this.dailyFFBReportByAllYearOfPlantationToolStripMenuItem = new ToolStripMenuItem();
            this.laporanPeneriamPerSupploerLA1ToolStripMenuItem = new ToolStripMenuItem();
            this.laporanTotalPenerimaanTBSToolStripMenuItem = new ToolStripMenuItem();
            this.fFBGradingReportToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem12 = new ToolStripMenuItem();
            this.vendorSummaryTBSToolStripMenuItem = new ToolStripMenuItem();
            this.divisionReportToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuRekapHarian = new ToolStripMenuItem();
            this.listOfWeighningToolStripMenuItem1 = new ToolStripMenuItem();
            this.copraReportToolStripMenuItem = new ToolStripMenuItem();
            this.dailyReceiptSupplierToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem5 = new ToolStripSeparator();
            this.reportOutstandingDOToolStripMenuItem = new ToolStripMenuItem();
            this.receivingEstimationFrom3rdPartyToolStripMenuItem = new ToolStripMenuItem();
            this.doDetailToolStripMenuItem = new ToolStripMenuItem();
            this.nonContractTransactionToolStripMenuItem = new ToolStripMenuItem();
            this.qCReportToolStripMenuItem = new ToolStripMenuItem();
            this.vendorSummaryToolStripMenuItem = new ToolStripMenuItem();
            this.gatepassReportToolStripMenuItem = new ToolStripMenuItem();
            this.logReportToolStripMenuItem = new ToolStripMenuItem();
            this.transactionLogToolStripMenuItem = new ToolStripMenuItem();
            this.masterDataLogToolStripMenuItem = new ToolStripMenuItem();
            this.settingLogToolStripMenuItem = new ToolStripMenuItem();
            this.locationLogToolStripMenuItem = new ToolStripMenuItem();
            this.userListLogToolStripMenuItem = new ToolStripMenuItem();
            this.userLoginLogoutLogToolStripMenuItem = new ToolStripMenuItem();
            this.authorizationLogToolStripMenuItem = new ToolStripMenuItem();
            this.templateSAPLogToolStripMenuItem = new ToolStripMenuItem();
            this.migrateOldLogToNewOneToolStripMenuItem = new ToolStripMenuItem();
            this.indicatorStabilityReportToolStripMenuItem = new ToolStripMenuItem();
            this.userManagementReportToolStripMenuItem = new ToolStripMenuItem();
            this.userListReportToolStripMenuItem = new ToolStripMenuItem();
            this.accessRightReportToolStripMenuItem = new ToolStripMenuItem();
            this.emailRecipientReportToolStripMenuItem = new ToolStripMenuItem();
            this.uploadSAPToolStripMenuItem = new ToolStripMenuItem();
            this.changeProfileToolStripMenuItem = new ToolStripMenuItem();
            this.logOffToolStripMenuItem = new ToolStripMenuItem();
            this.exitToolStripMenuItem = new ToolStripMenuItem();
            this.statusWB = new StatusStrip();
            this.Status1 = new ToolStripStatusLabel();
            this.tableLayoutPanel1 = new TableLayoutPanel();
            this.dataGridView1 = new DataGridView();
            this.panel1 = new Panel();
            this.checkWBCode = new CheckBox();
            this.checkPartial = new CheckBox();
            this.checkShowCheckSum = new CheckBox();
            this.Garis2 = new Label();
            this.labelStatus1 = new Label();
            this.checkBox1 = new CheckBox();
            this.dateTimePicker2 = new DateTimePicker();
            this.dateTimePicker1 = new DateTimePicker();
            this.label3 = new Label();
            this.label4 = new Label();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.buttonFilter = new Button();
            this.Garis1 = new Label();
            this.label1 = new Label();
            this.timerSAPUpd = new Timer(this.components);
            this.lblNow = new Label();
            this.lblDate = new Label();
            this.serialPort1 = new SerialPort(this.components);
            this.backgroundWorkerSAP = new BackgroundWorker();
            this.timer1 = new Timer(this.components);
            this.timerTokenEmail = new Timer(this.components);
            this.backgroundWorkerEmail = new BackgroundWorker();
            this.label2 = new Label();
            this.menuStrip1.SuspendLayout();
            this.statusWB.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.menuStrip1.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.menuStrip1.ImageScalingSize = new Size(20, 20);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.WeighingMenuItem, this.masterDataToolStripMenuItem1, this.configurationToolStripMenuItem, this.ReportToolStripMenuItem, this.uploadSAPToolStripMenuItem, this.changeProfileToolStripMenuItem, this.logOffToolStripMenuItem, this.exitToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new Size(0x550, 0x1c);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            ToolStripItem[] itemArray2 = new ToolStripItem[0x19];
            itemArray2[0] = this.truckArrivalToolStripMenuItem;
            itemArray2[1] = this.gatepassToolStripMenuItem;
            itemArray2[2] = this.stWeightToolStripMenuItem;
            itemArray2[3] = this.ndWeightToolStripMenuItem;
            itemArray2[4] = this.rdWeightToolStripMenuItem;
            itemArray2[5] = this.thWeightToolStripMenuItem;
            itemArray2[6] = this.splitReferenceToolStripMenuItem;
            itemArray2[7] = this.mergeDOToolStripMenuItem;
            itemArray2[8] = this.divideBlockToolStripMenuItem;
            itemArray2[9] = this.toolStripMenuItem11;
            itemArray2[10] = this.ManualEntryMenuItem;
            itemArray2[11] = this.toolStripMenuItem8;
            itemArray2[12] = this.qcStripMenuItem;
            itemArray2[13] = this.DLAdoptMenuItem;
            itemArray2[14] = this.toolStripSeparator1;
            itemArray2[15] = this.editRecordToolStripMenuItem;
            itemArray2[0x10] = this.editQuantityToolStripMenuItem;
            itemArray2[0x11] = this.cancelRecordToolStripMenuItem;
            itemArray2[0x12] = this.toolStripMenuItem9;
            itemArray2[0x13] = this.printToolStripMenuItem;
            itemArray2[20] = this.toolStripSeparator2;
            itemArray2[0x15] = this.toolStripMenuItem10;
            itemArray2[0x16] = this.toolStripSeparator3;
            itemArray2[0x17] = this.repairChecksumToolStripMenuItem;
            itemArray2[0x18] = this.repairAllChecksumToolStripMenuItem;
            this.WeighingMenuItem.DropDownItems.AddRange(itemArray2);
            this.WeighingMenuItem.Name = "WeighingMenuItem";
            this.WeighingMenuItem.Size = new Size(0x54, 0x18);
            this.WeighingMenuItem.Text = "&Weighing";
            this.WeighingMenuItem.DropDownOpening += new EventHandler(this.WeighingMenuItem_DropDownOpening);
            this.WeighingMenuItem.Click += new EventHandler(this.WeighingMenuItem_Click);
            this.truckArrivalToolStripMenuItem.Name = "truckArrivalToolStripMenuItem";
            this.truckArrivalToolStripMenuItem.ShortcutKeys = Keys.F7;
            this.truckArrivalToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.truckArrivalToolStripMenuItem.Text = "Truck Arrival";
            this.truckArrivalToolStripMenuItem.Click += new EventHandler(this.truckArrivalToolStripMenuItem_Click);
            this.gatepassToolStripMenuItem.Name = "gatepassToolStripMenuItem";
            this.gatepassToolStripMenuItem.ShortcutKeys = Keys.F8;
            this.gatepassToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.gatepassToolStripMenuItem.Text = "Gatepass";
            this.gatepassToolStripMenuItem.Click += new EventHandler(this.gatepassToolStripMenuItem_Click);
            this.stWeightToolStripMenuItem.Name = "stWeightToolStripMenuItem";
            this.stWeightToolStripMenuItem.ShortcutKeys = Keys.F1;
            this.stWeightToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.stWeightToolStripMenuItem.Text = "1st Weight or Registration";
            this.stWeightToolStripMenuItem.Click += new EventHandler(this.stWeightToolStripMenuItem_Click);
            this.ndWeightToolStripMenuItem.Name = "ndWeightToolStripMenuItem";
            this.ndWeightToolStripMenuItem.ShortcutKeys = Keys.F2;
            this.ndWeightToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.ndWeightToolStripMenuItem.Text = "2nd Weight";
            this.ndWeightToolStripMenuItem.Click += new EventHandler(this.ndWeightToolStripMenuItem_Click);
            this.rdWeightToolStripMenuItem.Name = "rdWeightToolStripMenuItem";
            this.rdWeightToolStripMenuItem.ShortcutKeys = Keys.F3;
            this.rdWeightToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.rdWeightToolStripMenuItem.Text = "3rd Weight";
            this.rdWeightToolStripMenuItem.Click += new EventHandler(this.rdWeightToolStripMenuItem_Click);
            this.thWeightToolStripMenuItem.Name = "thWeightToolStripMenuItem";
            this.thWeightToolStripMenuItem.ShortcutKeys = Keys.F4;
            this.thWeightToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.thWeightToolStripMenuItem.Text = "4th Weight";
            this.thWeightToolStripMenuItem.Click += new EventHandler(this.thWeightToolStripMenuItem_Click);
            this.splitReferenceToolStripMenuItem.Name = "splitReferenceToolStripMenuItem";
            this.splitReferenceToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.splitReferenceToolStripMenuItem.Text = "Split Reference";
            this.splitReferenceToolStripMenuItem.Click += new EventHandler(this.splitReferenceToolStripMenuItem_Click);
            this.mergeDOToolStripMenuItem.Name = "mergeDOToolStripMenuItem";
            this.mergeDOToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.mergeDOToolStripMenuItem.Text = "Merge DO";
            this.mergeDOToolStripMenuItem.Click += new EventHandler(this.mergeDOToolStripMenuItem_Click);
            this.divideBlockToolStripMenuItem.Name = "divideBlockToolStripMenuItem";
            this.divideBlockToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.divideBlockToolStripMenuItem.Text = "Divide Block";
            this.divideBlockToolStripMenuItem.Click += new EventHandler(this.divideBlockToolStripMenuItem_Click);
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.ShortcutKeys = Keys.Insert;
            this.toolStripMenuItem11.Size = new Size(0x155, 0x1a);
            this.toolStripMenuItem11.Text = "Copy Record / Insert for 2X Weight";
            this.toolStripMenuItem11.Click += new EventHandler(this.toolStripMenuItem11_Click);
            this.ManualEntryMenuItem.Name = "ManualEntryMenuItem";
            this.ManualEntryMenuItem.ShortcutKeyDisplayString = "F6";
            this.ManualEntryMenuItem.ShortcutKeys = Keys.F6;
            this.ManualEntryMenuItem.Size = new Size(0x155, 0x1a);
            this.ManualEntryMenuItem.Text = "Manual Entry";
            this.ManualEntryMenuItem.Click += new EventHandler(this.toolStripMenuItem12_Click);
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new Size(0x152, 6);
            this.qcStripMenuItem.Name = "qcStripMenuItem";
            this.qcStripMenuItem.ShortcutKeys = Keys.Control | Keys.Q;
            this.qcStripMenuItem.Size = new Size(0x155, 0x1a);
            this.qcStripMenuItem.Text = "&Consignment && Laboratory";
            this.qcStripMenuItem.Click += new EventHandler(this.qcStripMenuItem_Click);
            this.DLAdoptMenuItem.Name = "DLAdoptMenuItem";
            this.DLAdoptMenuItem.Size = new Size(0x155, 0x1a);
            this.DLAdoptMenuItem.Text = "Adopt Delivery Letter";
            this.DLAdoptMenuItem.Click += new EventHandler(this.DLAdoptMenuItem_Click);
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new Size(0x152, 6);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.E;
            this.editRecordToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.editRecordToolStripMenuItem.Text = "&Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.editQuantityToolStripMenuItem.Name = "editQuantityToolStripMenuItem";
            this.editQuantityToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.editQuantityToolStripMenuItem.Text = "Edit Quantity";
            this.editQuantityToolStripMenuItem.Click += new EventHandler(this.editQuantityToolStripMenuItem_Click);
            this.cancelRecordToolStripMenuItem.Name = "cancelRecordToolStripMenuItem";
            this.cancelRecordToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.C;
            this.cancelRecordToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.cancelRecordToolStripMenuItem.Text = "&Cancel Record";
            this.cancelRecordToolStripMenuItem.Click += new EventHandler(this.cancelRecordToolStripMenuItem_Click);
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.ShortcutKeys = Keys.Control | Keys.V;
            this.toolStripMenuItem9.Size = new Size(0x155, 0x1a);
            this.toolStripMenuItem9.Text = "&View Record";
            this.toolStripMenuItem9.Click += new EventHandler(this.toolStripMenuItem9_Click);
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.P;
            this.printToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.printToolStripMenuItem.Text = "&Print";
            this.printToolStripMenuItem.Click += new EventHandler(this.printToolStripMenuItem_Click);
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new Size(0x152, 6);
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.ShortcutKeys = Keys.Control | Keys.D;
            this.toolStripMenuItem10.Size = new Size(0x155, 0x1a);
            this.toolStripMenuItem10.Text = "View &DO Transaction";
            this.toolStripMenuItem10.Click += new EventHandler(this.toolStripMenuItem10_Click);
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new Size(0x152, 6);
            this.repairChecksumToolStripMenuItem.Name = "repairChecksumToolStripMenuItem";
            this.repairChecksumToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.R;
            this.repairChecksumToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.repairChecksumToolStripMenuItem.Text = "&Repair Checksum";
            this.repairChecksumToolStripMenuItem.Click += new EventHandler(this.repairChecksumToolStripMenuItem_Click);
            this.repairAllChecksumToolStripMenuItem.Name = "repairAllChecksumToolStripMenuItem";
            this.repairAllChecksumToolStripMenuItem.Size = new Size(0x155, 0x1a);
            this.repairAllChecksumToolStripMenuItem.Text = "Repair All Checksum";
            this.repairAllChecksumToolStripMenuItem.Click += new EventHandler(this.repairAllChecksumToolStripMenuItem_Click);
            ToolStripItem[] itemArray3 = new ToolStripItem[0x21];
            itemArray3[0] = this.DOToolStripMenuItem;
            itemArray3[1] = this.commodityToolStripMenuItem;
            itemArray3[2] = this.relationToolStripMenuItem;
            itemArray3[3] = this.toolStripMenuItem1;
            itemArray3[4] = this.truckToolStripMenuItem;
            itemArray3[5] = this.containerToolStripMenuItem;
            itemArray3[6] = this.driverToolStripMenuItem;
            itemArray3[7] = this.transpoterToolStripMenuItem;
            itemArray3[8] = this.toolStripMenuItem2;
            itemArray3[9] = this.coytoolStripMenuItem;
            itemArray3[10] = this.locationToolStripMenuItem;
            itemArray3[11] = this.estateToolStripMenuItem;
            itemArray3[12] = this.divisionToolStripMenuItemPOM;
            itemArray3[13] = this.blockStripMenuItemPOM;
            itemArray3[14] = this.aBWBlockToolStripMenuItemPOM;
            itemArray3[15] = this.millToolStripMenuItem;
            itemArray3[0x10] = this.sourceToolStripMenuItem;
            itemArray3[0x11] = this.loadUloadToolStripMenuItem;
            itemArray3[0x12] = this.bagToolStripMenuItem;
            itemArray3[0x13] = this.toolStripMenuItem4;
            itemArray3[20] = this.UploadTypeToolStripMenuItem;
            itemArray3[0x15] = this.batchToolStripMenuItem;
            itemArray3[0x16] = this.storageToolStripMenuItem;
            itemArray3[0x17] = this.gradingToolStripMenuItemPOM;
            itemArray3[0x18] = this.qualityToolStripMenuItem;
            itemArray3[0x19] = this.tankerToolStripMenuItem;
            itemArray3[0x1a] = this.toolStripMenuItem3;
            itemArray3[0x1b] = this.transactionTypeToolStripMenuItem;
            itemArray3[0x1c] = this.templateSAPToolStripMenuItem;
            itemArray3[0x1d] = this.formulaRendemenToolStripMenuItemPOM;
            itemArray3[30] = this.mapCommTrxTypeToolStripMenuItem;
            itemArray3[0x1f] = this.emailRecipientToolStripMenuItem;
            itemArray3[0x20] = this.deductedByToolStripMenuItem;
            this.masterDataToolStripMenuItem1.DropDownItems.AddRange(itemArray3);
            this.masterDataToolStripMenuItem1.Name = "masterDataToolStripMenuItem1";
            this.masterDataToolStripMenuItem1.Size = new Size(0x66, 0x18);
            this.masterDataToolStripMenuItem1.Text = "&Master Data";
            this.masterDataToolStripMenuItem1.DropDownOpening += new EventHandler(this.masterDataToolStripMenuItem1_DropDownOpening);
            this.DOToolStripMenuItem.Name = "DOToolStripMenuItem";
            this.DOToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.DOToolStripMenuItem.Text = "DO/Contract/Confirmation";
            this.DOToolStripMenuItem.Click += new EventHandler(this.md1ToolStripMenuItem_Click);
            this.commodityToolStripMenuItem.Name = "commodityToolStripMenuItem";
            this.commodityToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.commodityToolStripMenuItem.Text = "Commodity";
            this.commodityToolStripMenuItem.Click += new EventHandler(this.md2ToolStripMenuItem_Click);
            this.relationToolStripMenuItem.Name = "relationToolStripMenuItem";
            this.relationToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.relationToolStripMenuItem.Text = "Relation List ( Customer/Vendor)";
            this.relationToolStripMenuItem.Click += new EventHandler(this.md3ToolStripMenuItem_Click);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0x128, 6);
            this.truckToolStripMenuItem.Name = "truckToolStripMenuItem";
            this.truckToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.truckToolStripMenuItem.Text = "Truck";
            this.truckToolStripMenuItem.Click += new EventHandler(this.md4ToolStripMenuItem_Click);
            this.containerToolStripMenuItem.Name = "containerToolStripMenuItem";
            this.containerToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.containerToolStripMenuItem.Text = "Container";
            this.containerToolStripMenuItem.Click += new EventHandler(this.containerToolStripMenuItem_Click);
            this.driverToolStripMenuItem.Name = "driverToolStripMenuItem";
            this.driverToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.driverToolStripMenuItem.Text = "Driver ID";
            this.driverToolStripMenuItem.Click += new EventHandler(this.md5ToolStripMenuItem_Click);
            this.transpoterToolStripMenuItem.Name = "transpoterToolStripMenuItem";
            this.transpoterToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.transpoterToolStripMenuItem.Text = "Transporter";
            this.transpoterToolStripMenuItem.Click += new EventHandler(this.md6rToolStripMenuItem_Click);
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new Size(0x128, 6);
            this.coytoolStripMenuItem.Name = "coytoolStripMenuItem";
            this.coytoolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.coytoolStripMenuItem.Text = "Company";
            this.coytoolStripMenuItem.Click += new EventHandler(this.coytoolStripMenuItem_Click);
            this.locationToolStripMenuItem.Name = "locationToolStripMenuItem";
            this.locationToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.locationToolStripMenuItem.Text = "Location";
            this.locationToolStripMenuItem.Click += new EventHandler(this.md7ToolStripMenuItem_Click);
            this.estateToolStripMenuItem.Name = "estateToolStripMenuItem";
            this.estateToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.estateToolStripMenuItem.Text = "Estate";
            this.estateToolStripMenuItem.Click += new EventHandler(this.md10ToolStripMenuItem_Click);
            this.divisionToolStripMenuItemPOM.Name = "divisionToolStripMenuItemPOM";
            this.divisionToolStripMenuItemPOM.Size = new Size(0x12b, 0x1a);
            this.divisionToolStripMenuItemPOM.Text = "Division";
            this.divisionToolStripMenuItemPOM.Click += new EventHandler(this.md9ToolStripMenuItem_Click);
            this.blockStripMenuItemPOM.Name = "blockStripMenuItemPOM";
            this.blockStripMenuItemPOM.Size = new Size(0x12b, 0x1a);
            this.blockStripMenuItemPOM.Text = "Block";
            this.blockStripMenuItemPOM.Click += new EventHandler(this.blockStripMenuItem_Click);
            this.aBWBlockToolStripMenuItemPOM.Name = "aBWBlockToolStripMenuItemPOM";
            this.aBWBlockToolStripMenuItemPOM.Size = new Size(0x12b, 0x1a);
            this.aBWBlockToolStripMenuItemPOM.Text = "ABW/Block";
            this.aBWBlockToolStripMenuItemPOM.Click += new EventHandler(this.aBWBlockToolStripMenuItem_Click);
            this.millToolStripMenuItem.Name = "millToolStripMenuItem";
            this.millToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.millToolStripMenuItem.Text = "Mill";
            this.millToolStripMenuItem.Click += new EventHandler(this.millToolStripMenuItem_Click);
            this.sourceToolStripMenuItem.Name = "sourceToolStripMenuItem";
            this.sourceToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.sourceToolStripMenuItem.Text = "Source";
            this.sourceToolStripMenuItem.Click += new EventHandler(this.sourceToolStripMenuItem_Click);
            this.loadUloadToolStripMenuItem.Name = "loadUloadToolStripMenuItem";
            this.loadUloadToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.loadUloadToolStripMenuItem.Text = "Load/Unload";
            this.loadUloadToolStripMenuItem.Click += new EventHandler(this.loadUloadToolStripMenuItem_Click);
            this.bagToolStripMenuItem.Name = "bagToolStripMenuItem";
            this.bagToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.bagToolStripMenuItem.Text = "Bag";
            this.bagToolStripMenuItem.Click += new EventHandler(this.bagToolStripMenuItem_Click);
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new Size(0x128, 6);
            this.UploadTypeToolStripMenuItem.Name = "UploadTypeToolStripMenuItem";
            this.UploadTypeToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.UploadTypeToolStripMenuItem.Text = "Upload Type";
            this.UploadTypeToolStripMenuItem.Click += new EventHandler(this.UploadTypeToolStripMenuItem_Click);
            this.batchToolStripMenuItem.Name = "batchToolStripMenuItem";
            this.batchToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.batchToolStripMenuItem.Text = "Batch";
            this.batchToolStripMenuItem.Click += new EventHandler(this.batchToolStripMenuItem_Click);
            this.storageToolStripMenuItem.Name = "storageToolStripMenuItem";
            this.storageToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.storageToolStripMenuItem.Text = "Storage";
            this.storageToolStripMenuItem.Click += new EventHandler(this.md8ToolStripMenuItem_Click);
            this.gradingToolStripMenuItemPOM.Name = "gradingToolStripMenuItemPOM";
            this.gradingToolStripMenuItemPOM.Size = new Size(0x12b, 0x1a);
            this.gradingToolStripMenuItemPOM.Text = "Grading";
            this.gradingToolStripMenuItemPOM.Click += new EventHandler(this.md13ToolStripMenuItem_Click);
            ToolStripItem[] itemArray4 = new ToolStripItem[] { this.qCItemToolStripMenuItem, this.compositToolStripMenuItem };
            this.qualityToolStripMenuItem.DropDownItems.AddRange(itemArray4);
            this.qualityToolStripMenuItem.Name = "qualityToolStripMenuItem";
            this.qualityToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.qualityToolStripMenuItem.Text = "Quality Control";
            this.qCItemToolStripMenuItem.Name = "qCItemToolStripMenuItem";
            this.qCItemToolStripMenuItem.Size = new Size(0x94, 0x1a);
            this.qCItemToolStripMenuItem.Text = "QC Item";
            this.qCItemToolStripMenuItem.Click += new EventHandler(this.qCItemToolStripMenuItem_Click);
            this.compositToolStripMenuItem.Name = "compositToolStripMenuItem";
            this.compositToolStripMenuItem.Size = new Size(0x94, 0x1a);
            this.compositToolStripMenuItem.Text = "Composit";
            this.compositToolStripMenuItem.Click += new EventHandler(this.compositToolStripMenuItem_Click);
            this.tankerToolStripMenuItem.Name = "tankerToolStripMenuItem";
            this.tankerToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.tankerToolStripMenuItem.Text = "Tanker List && Capacity";
            this.tankerToolStripMenuItem.Click += new EventHandler(this.md12ToolStripMenuItem_Click);
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new Size(0x128, 6);
            this.transactionTypeToolStripMenuItem.Name = "transactionTypeToolStripMenuItem";
            this.transactionTypeToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.transactionTypeToolStripMenuItem.Text = "Transaction Type";
            this.transactionTypeToolStripMenuItem.Click += new EventHandler(this.transactionTypeToolStripMenuItem_Click);
            this.templateSAPToolStripMenuItem.Name = "templateSAPToolStripMenuItem";
            this.templateSAPToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.templateSAPToolStripMenuItem.Text = "Template SAP";
            this.templateSAPToolStripMenuItem.Click += new EventHandler(this.templateSAPToolStripMenuItem_Click);
            this.formulaRendemenToolStripMenuItemPOM.Name = "formulaRendemenToolStripMenuItemPOM";
            this.formulaRendemenToolStripMenuItemPOM.Size = new Size(0x12b, 0x1a);
            this.formulaRendemenToolStripMenuItemPOM.Text = "Formula Rendemen";
            this.formulaRendemenToolStripMenuItemPOM.Click += new EventHandler(this.formulaRendemenToolStripMenuItem_Click);
            this.mapCommTrxTypeToolStripMenuItem.Name = "mapCommTrxTypeToolStripMenuItem";
            this.mapCommTrxTypeToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.mapCommTrxTypeToolStripMenuItem.Text = "Map Comm-Trx Type";
            this.mapCommTrxTypeToolStripMenuItem.Click += new EventHandler(this.mapCommTrxTypeToolStripMenuItem_Click);
            this.emailRecipientToolStripMenuItem.Name = "emailRecipientToolStripMenuItem";
            this.emailRecipientToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.emailRecipientToolStripMenuItem.Text = "Email Recipient";
            this.emailRecipientToolStripMenuItem.Click += new EventHandler(this.emailRecipientToolStripMenuItem_Click);
            this.deductedByToolStripMenuItem.Name = "deductedByToolStripMenuItem";
            this.deductedByToolStripMenuItem.Size = new Size(0x12b, 0x1a);
            this.deductedByToolStripMenuItem.Text = "Deducted By";
            this.deductedByToolStripMenuItem.Click += new EventHandler(this.deductedByToolStripMenuItem_Click);
            ToolStripItem[] itemArray5 = new ToolStripItem[13];
            itemArray5[0] = this.databaseConnectionToolStripMenuItem;
            itemArray5[1] = this.weighBridgeSettingToolStripMenuItem;
            itemArray5[2] = this.weighbridgeControlToolStripMenuItem;
            itemArray5[3] = this.hardwareConfigurationToolStripMenuItem;
            itemArray5[4] = this.toolStripMenuItem6;
            itemArray5[5] = this.userListToolStripMenuItem;
            itemArray5[6] = this.userGroupToolStripMenuItem;
            itemArray5[7] = this.toolStripMenuItem7;
            itemArray5[8] = this.copyToNewCompanyToolStripMenuItem;
            itemArray5[9] = this.compareDatabaseToolStripMenuItem;
            itemArray5[10] = this.toolStripSeparator4;
            itemArray5[11] = this.saveColumnPositionToolStripMenuItem;
            itemArray5[12] = this.loadColumnPositionToolStripMenuItem;
            this.configurationToolStripMenuItem.DropDownItems.AddRange(itemArray5);
            this.configurationToolStripMenuItem.Name = "configurationToolStripMenuItem";
            this.configurationToolStripMenuItem.Size = new Size(0x70, 0x18);
            this.configurationToolStripMenuItem.Text = "&Configuration";
            this.configurationToolStripMenuItem.DropDownOpening += new EventHandler(this.configurationToolStripMenuItem_DropDownOpening);
            this.databaseConnectionToolStripMenuItem.Name = "databaseConnectionToolStripMenuItem";
            this.databaseConnectionToolStripMenuItem.Size = new Size(0xf4, 0x1a);
            this.databaseConnectionToolStripMenuItem.Text = "Database Connection";
            this.databaseConnectionToolStripMenuItem.Click += new EventHandler(this.databaseConnectionToolStripMenuItem_Click);
            this.weighBridgeSettingToolStripMenuItem.Name = "weighBridgeSettingToolStripMenuItem";
            this.weighBridgeSettingToolStripMenuItem.Size = new Size(0xf4, 0x1a);
            this.weighBridgeSettingToolStripMenuItem.Text = "WeighBridge Setting";
            this.weighBridgeSettingToolStripMenuItem.Click += new EventHandler(this.weighBridgeSettingToolStripMenuItem_Click);
            this.weighbridgeControlToolStripMenuItem.Name = "weighbridgeControlToolStripMenuItem";
            this.weighbridgeControlToolStripMenuItem.Size = new Size(0xf4, 0x1a);
            this.weighbridgeControlToolStripMenuItem.Text = "Weighbridge Control";
            this.weighbridgeControlToolStripMenuItem.Click += new EventHandler(this.weighbridgeControlToolStripMenuItem_Click);
            this.hardwareConfigurationToolStripMenuItem.Name = "hardwareConfigurationToolStripMenuItem";
            this.hardwareConfigurationToolStripMenuItem.Size = new Size(0xf4, 0x1a);
            this.hardwareConfigurationToolStripMenuItem.Text = "Hardware Configuration";
            this.hardwareConfigurationToolStripMenuItem.Click += new EventHandler(this.hardwareConfigurationToolStripMenuItem_Click);
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new Size(0xf1, 6);
            this.userListToolStripMenuItem.Name = "userListToolStripMenuItem";
            this.userListToolStripMenuItem.Size = new Size(0xf4, 0x1a);
            this.userListToolStripMenuItem.Text = "User List";
            this.userListToolStripMenuItem.Click += new EventHandler(this.userListToolStripMenuItem_Click);
            this.userGroupToolStripMenuItem.Name = "userGroupToolStripMenuItem";
            this.userGroupToolStripMenuItem.Size = new Size(0xf4, 0x1a);
            this.userGroupToolStripMenuItem.Text = "User Group";
            this.userGroupToolStripMenuItem.Click += new EventHandler(this.userGroupToolStripMenuItem_Click);
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new Size(0xf1, 6);
            this.copyToNewCompanyToolStripMenuItem.Name = "copyToNewCompanyToolStripMenuItem";
            this.copyToNewCompanyToolStripMenuItem.Size = new Size(0xf4, 0x1a);
            this.copyToNewCompanyToolStripMenuItem.Text = "Copy to New Company";
            this.copyToNewCompanyToolStripMenuItem.Click += new EventHandler(this.copyToNewCompanyToolStripMenuItem_Click);
            this.compareDatabaseToolStripMenuItem.Name = "compareDatabaseToolStripMenuItem";
            this.compareDatabaseToolStripMenuItem.Size = new Size(0xf4, 0x1a);
            this.compareDatabaseToolStripMenuItem.Text = "Compare Database";
            this.compareDatabaseToolStripMenuItem.Click += new EventHandler(this.compareDatabaseToolStripMenuItem_Click);
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new Size(0xf1, 6);
            this.saveColumnPositionToolStripMenuItem.Name = "saveColumnPositionToolStripMenuItem";
            this.saveColumnPositionToolStripMenuItem.Size = new Size(0xf4, 0x1a);
            this.saveColumnPositionToolStripMenuItem.Text = "Save Column Position";
            this.saveColumnPositionToolStripMenuItem.Click += new EventHandler(this.saveColumnPositionToolStripMenuItem_Click);
            this.loadColumnPositionToolStripMenuItem.Name = "loadColumnPositionToolStripMenuItem";
            this.loadColumnPositionToolStripMenuItem.Size = new Size(0xf4, 0x1a);
            this.loadColumnPositionToolStripMenuItem.Text = "Load Column Position";
            this.loadColumnPositionToolStripMenuItem.Click += new EventHandler(this.loadColumnPositionToolStripMenuItem_Click);
            ToolStripItem[] itemArray6 = new ToolStripItem[0x10];
            itemArray6[0] = this.FFBReportToolStripMenuItemPOM;
            itemArray6[1] = this.listOfWeighningToolStripMenuItem1;
            itemArray6[2] = this.copraReportToolStripMenuItem;
            itemArray6[3] = this.dailyReceiptSupplierToolStripMenuItem;
            itemArray6[4] = this.toolStripMenuItem5;
            itemArray6[5] = this.reportOutstandingDOToolStripMenuItem;
            itemArray6[6] = this.receivingEstimationFrom3rdPartyToolStripMenuItem;
            itemArray6[7] = this.doDetailToolStripMenuItem;
            itemArray6[8] = this.nonContractTransactionToolStripMenuItem;
            itemArray6[9] = this.qCReportToolStripMenuItem;
            itemArray6[10] = this.vendorSummaryToolStripMenuItem;
            itemArray6[11] = this.gatepassReportToolStripMenuItem;
            itemArray6[12] = this.logReportToolStripMenuItem;
            itemArray6[13] = this.indicatorStabilityReportToolStripMenuItem;
            itemArray6[14] = this.userManagementReportToolStripMenuItem;
            itemArray6[15] = this.emailRecipientReportToolStripMenuItem;
            this.ReportToolStripMenuItem.DropDownItems.AddRange(itemArray6);
            this.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem";
            this.ReportToolStripMenuItem.Size = new Size(0x42, 0x18);
            this.ReportToolStripMenuItem.Text = "&Report";
            this.ReportToolStripMenuItem.DropDownOpening += new EventHandler(this.ReportToolStripMenuItem_DropDownOpening);
            ToolStripItem[] itemArray7 = new ToolStripItem[10];
            itemArray7[0] = this.subRP1ToolStripMenuItem;
            itemArray7[1] = this.dailyFFBReportByYearOfPlantationToolStripMenuItem;
            itemArray7[2] = this.dailyFFBReportByAllYearOfPlantationToolStripMenuItem;
            itemArray7[3] = this.laporanPeneriamPerSupploerLA1ToolStripMenuItem;
            itemArray7[4] = this.laporanTotalPenerimaanTBSToolStripMenuItem;
            itemArray7[5] = this.fFBGradingReportToolStripMenuItem;
            itemArray7[6] = this.toolStripMenuItem12;
            itemArray7[7] = this.vendorSummaryTBSToolStripMenuItem;
            itemArray7[8] = this.divisionReportToolStripMenuItem;
            itemArray7[9] = this.toolStripMenuRekapHarian;
            this.FFBReportToolStripMenuItemPOM.DropDownItems.AddRange(itemArray7);
            this.FFBReportToolStripMenuItemPOM.Name = "FFBReportToolStripMenuItemPOM";
            this.FFBReportToolStripMenuItemPOM.Size = new Size(0x142, 0x1a);
            this.FFBReportToolStripMenuItemPOM.Text = "FFB Report";
            this.FFBReportToolStripMenuItemPOM.Click += new EventHandler(this.FFBReportToolStripMenuItemPOM_Click);
            this.subRP1ToolStripMenuItem.Name = "subRP1ToolStripMenuItem";
            this.subRP1ToolStripMenuItem.Size = new Size(0x165, 0x1a);
            this.subRP1ToolStripMenuItem.Text = "Daily Report FFB (LA)";
            this.subRP1ToolStripMenuItem.Click += new EventHandler(this.subRP1ToolStripMenuItem_Click);
            this.dailyFFBReportByYearOfPlantationToolStripMenuItem.Name = "dailyFFBReportByYearOfPlantationToolStripMenuItem";
            this.dailyFFBReportByYearOfPlantationToolStripMenuItem.Size = new Size(0x165, 0x1a);
            this.dailyFFBReportByYearOfPlantationToolStripMenuItem.Text = "Daily FFB Report By Year Of Plantation";
            this.dailyFFBReportByYearOfPlantationToolStripMenuItem.Click += new EventHandler(this.dailyFFBReportByYearOfPlantationToolStripMenuItem_Click);
            this.dailyFFBReportByAllYearOfPlantationToolStripMenuItem.Name = "dailyFFBReportByAllYearOfPlantationToolStripMenuItem";
            this.dailyFFBReportByAllYearOfPlantationToolStripMenuItem.Size = new Size(0x165, 0x1a);
            this.dailyFFBReportByAllYearOfPlantationToolStripMenuItem.Text = "Daily FFB Report By All Year of Plantation";
            this.dailyFFBReportByAllYearOfPlantationToolStripMenuItem.Click += new EventHandler(this.dailyFFBReportByAllYearOfPlantationToolStripMenuItem_Click);
            this.laporanPeneriamPerSupploerLA1ToolStripMenuItem.Name = "laporanPeneriamPerSupploerLA1ToolStripMenuItem";
            this.laporanPeneriamPerSupploerLA1ToolStripMenuItem.Size = new Size(0x165, 0x1a);
            this.laporanPeneriamPerSupploerLA1ToolStripMenuItem.Text = "Laporan Penerimaan Per Supplier (LA1)";
            this.laporanPeneriamPerSupploerLA1ToolStripMenuItem.Click += new EventHandler(this.laporanPeneriamPerSupploerLA1ToolStripMenuItem_Click);
            this.laporanTotalPenerimaanTBSToolStripMenuItem.Name = "laporanTotalPenerimaanTBSToolStripMenuItem";
            this.laporanTotalPenerimaanTBSToolStripMenuItem.Size = new Size(0x165, 0x1a);
            this.laporanTotalPenerimaanTBSToolStripMenuItem.Text = "Laporan Total Penerimaan TBS (LA2)";
            this.laporanTotalPenerimaanTBSToolStripMenuItem.Click += new EventHandler(this.laporanTotalPenerimaanTBSToolStripMenuItem_Click);
            this.fFBGradingReportToolStripMenuItem.Name = "fFBGradingReportToolStripMenuItem";
            this.fFBGradingReportToolStripMenuItem.Size = new Size(0x165, 0x1a);
            this.fFBGradingReportToolStripMenuItem.Text = "FFB Grading Report";
            this.fFBGradingReportToolStripMenuItem.Click += new EventHandler(this.fFBGradingReportToolStripMenuItem_Click);
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new Size(0x165, 0x1a);
            this.toolStripMenuItem12.Text = "FFB Porla Report";
            this.toolStripMenuItem12.Click += new EventHandler(this.toolStripMenuItem12_Click_1);
            this.vendorSummaryTBSToolStripMenuItem.Name = "vendorSummaryTBSToolStripMenuItem";
            this.vendorSummaryTBSToolStripMenuItem.Size = new Size(0x165, 0x1a);
            this.vendorSummaryTBSToolStripMenuItem.Text = "Vendor Summary TBS";
            this.vendorSummaryTBSToolStripMenuItem.Click += new EventHandler(this.vendorSummaryTBSToolStripMenuItem_Click);
            this.divisionReportToolStripMenuItem.Name = "divisionReportToolStripMenuItem";
            this.divisionReportToolStripMenuItem.Size = new Size(0x165, 0x1a);
            this.divisionReportToolStripMenuItem.Text = "Division Report";
            this.divisionReportToolStripMenuItem.Click += new EventHandler(this.divisionReportToolStripMenuItem_Click);
            this.toolStripMenuRekapHarian.Name = "toolStripMenuRekapHarian";
            this.toolStripMenuRekapHarian.Size = new Size(0x165, 0x1a);
            this.toolStripMenuRekapHarian.Text = "Rekap Harian FFB";
            this.toolStripMenuRekapHarian.Click += new EventHandler(this.toolStripMenuRekapHarian_Click);
            this.listOfWeighningToolStripMenuItem1.Name = "listOfWeighningToolStripMenuItem1";
            this.listOfWeighningToolStripMenuItem1.Size = new Size(0x142, 0x1a);
            this.listOfWeighningToolStripMenuItem1.Text = "List Of Weighning";
            this.listOfWeighningToolStripMenuItem1.Click += new EventHandler(this.listOfWeighningToolStripMenuItem1_Click);
            this.copraReportToolStripMenuItem.Name = "copraReportToolStripMenuItem";
            this.copraReportToolStripMenuItem.Size = new Size(0x142, 0x1a);
            this.copraReportToolStripMenuItem.Text = "Daily Receipt Per Supplier (LA1)";
            this.copraReportToolStripMenuItem.Click += new EventHandler(this.copraReportToolStripMenuItem_Click);
            this.dailyReceiptSupplierToolStripMenuItem.Name = "dailyReceiptSupplierToolStripMenuItem";
            this.dailyReceiptSupplierToolStripMenuItem.Size = new Size(0x142, 0x1a);
            this.dailyReceiptSupplierToolStripMenuItem.Text = "Daily Receipt per Supplier (LA2)";
            this.dailyReceiptSupplierToolStripMenuItem.Click += new EventHandler(this.dailyReceiptSupplierToolStripMenuItem_Click);
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new Size(0x13f, 6);
            this.reportOutstandingDOToolStripMenuItem.Name = "reportOutstandingDOToolStripMenuItem";
            this.reportOutstandingDOToolStripMenuItem.Size = new Size(0x142, 0x1a);
            this.reportOutstandingDOToolStripMenuItem.Text = "Report Outstanding DO/Contract";
            this.reportOutstandingDOToolStripMenuItem.Click += new EventHandler(this.reportOutstandingDOToolStripMenuItem_Click);
            this.receivingEstimationFrom3rdPartyToolStripMenuItem.Name = "receivingEstimationFrom3rdPartyToolStripMenuItem";
            this.receivingEstimationFrom3rdPartyToolStripMenuItem.Size = new Size(0x142, 0x1a);
            this.receivingEstimationFrom3rdPartyToolStripMenuItem.Text = "Receiving Estimation From 3rd Party";
            this.receivingEstimationFrom3rdPartyToolStripMenuItem.Click += new EventHandler(this.receivingEstimationFrom3rdPartyToolStripMenuItem_Click);
            this.doDetailToolStripMenuItem.Name = "doDetailToolStripMenuItem";
            this.doDetailToolStripMenuItem.Size = new Size(0x142, 0x1a);
            this.doDetailToolStripMenuItem.Text = "Good Receive / Good Issue";
            this.doDetailToolStripMenuItem.Click += new EventHandler(this.doDetailToolStripMenuItem_Click);
            this.nonContractTransactionToolStripMenuItem.Name = "nonContractTransactionToolStripMenuItem";
            this.nonContractTransactionToolStripMenuItem.Size = new Size(0x142, 0x1a);
            this.nonContractTransactionToolStripMenuItem.Text = "NonContract Transaction";
            this.nonContractTransactionToolStripMenuItem.Click += new EventHandler(this.nonContractTransactionToolStripMenuItem_Click);
            this.qCReportToolStripMenuItem.Name = "qCReportToolStripMenuItem";
            this.qCReportToolStripMenuItem.Size = new Size(0x142, 0x1a);
            this.qCReportToolStripMenuItem.Text = "QC Report";
            this.qCReportToolStripMenuItem.Click += new EventHandler(this.qCReportToolStripMenuItem_Click);
            this.vendorSummaryToolStripMenuItem.Name = "vendorSummaryToolStripMenuItem";
            this.vendorSummaryToolStripMenuItem.Size = new Size(0x142, 0x1a);
            this.vendorSummaryToolStripMenuItem.Text = "Vendor Summary";
            this.vendorSummaryToolStripMenuItem.Click += new EventHandler(this.vendorSummaryToolStripMenuItem_Click);
            this.gatepassReportToolStripMenuItem.Name = "gatepassReportToolStripMenuItem";
            this.gatepassReportToolStripMenuItem.Size = new Size(0x142, 0x1a);
            this.gatepassReportToolStripMenuItem.Text = "Gatepass Report";
            this.gatepassReportToolStripMenuItem.Click += new EventHandler(this.gatepassReportToolStripMenuItem_Click);
            ToolStripItem[] itemArray8 = new ToolStripItem[9];
            itemArray8[0] = this.transactionLogToolStripMenuItem;
            itemArray8[1] = this.masterDataLogToolStripMenuItem;
            itemArray8[2] = this.settingLogToolStripMenuItem;
            itemArray8[3] = this.locationLogToolStripMenuItem;
            itemArray8[4] = this.userListLogToolStripMenuItem;
            itemArray8[5] = this.userLoginLogoutLogToolStripMenuItem;
            itemArray8[6] = this.authorizationLogToolStripMenuItem;
            itemArray8[7] = this.templateSAPLogToolStripMenuItem;
            itemArray8[8] = this.migrateOldLogToNewOneToolStripMenuItem;
            this.logReportToolStripMenuItem.DropDownItems.AddRange(itemArray8);
            this.logReportToolStripMenuItem.Name = "logReportToolStripMenuItem";
            this.logReportToolStripMenuItem.Size = new Size(0x142, 0x1a);
            this.logReportToolStripMenuItem.Text = "Log Report";
            this.transactionLogToolStripMenuItem.Name = "transactionLogToolStripMenuItem";
            this.transactionLogToolStripMenuItem.Size = new Size(0x114, 0x1a);
            this.transactionLogToolStripMenuItem.Text = "Transaction Log";
            this.transactionLogToolStripMenuItem.Click += new EventHandler(this.transactionLogToolStripMenuItem1_Click);
            this.masterDataLogToolStripMenuItem.Name = "masterDataLogToolStripMenuItem";
            this.masterDataLogToolStripMenuItem.Size = new Size(0x114, 0x1a);
            this.masterDataLogToolStripMenuItem.Text = "Master Data Log";
            this.masterDataLogToolStripMenuItem.Click += new EventHandler(this.masterDataLogToolStripMenuItem_Click);
            this.settingLogToolStripMenuItem.Name = "settingLogToolStripMenuItem";
            this.settingLogToolStripMenuItem.Size = new Size(0x114, 0x1a);
            this.settingLogToolStripMenuItem.Text = "Setting Log";
            this.settingLogToolStripMenuItem.Click += new EventHandler(this.settingLogToolStripMenuItem_Click);
            this.locationLogToolStripMenuItem.Name = "locationLogToolStripMenuItem";
            this.locationLogToolStripMenuItem.Size = new Size(0x114, 0x1a);
            this.locationLogToolStripMenuItem.Text = "Location Log";
            this.locationLogToolStripMenuItem.Click += new EventHandler(this.locationLogToolStripMenuItem_Click);
            this.userListLogToolStripMenuItem.Name = "userListLogToolStripMenuItem";
            this.userListLogToolStripMenuItem.Size = new Size(0x114, 0x1a);
            this.userListLogToolStripMenuItem.Text = "User List Log";
            this.userListLogToolStripMenuItem.Click += new EventHandler(this.userListLogToolStripMenuItem_Click);
            this.userLoginLogoutLogToolStripMenuItem.Name = "userLoginLogoutLogToolStripMenuItem";
            this.userLoginLogoutLogToolStripMenuItem.Size = new Size(0x114, 0x1a);
            this.userLoginLogoutLogToolStripMenuItem.Text = "User Login/Logout Log";
            this.userLoginLogoutLogToolStripMenuItem.Click += new EventHandler(this.userLoginLogoutLogToolStripMenuItem_Click);
            this.authorizationLogToolStripMenuItem.Name = "authorizationLogToolStripMenuItem";
            this.authorizationLogToolStripMenuItem.Size = new Size(0x114, 0x1a);
            this.authorizationLogToolStripMenuItem.Text = "Authorization Log";
            this.authorizationLogToolStripMenuItem.Click += new EventHandler(this.authorizationLogToolStripMenuItem_Click);
            this.templateSAPLogToolStripMenuItem.Name = "templateSAPLogToolStripMenuItem";
            this.templateSAPLogToolStripMenuItem.Size = new Size(0x114, 0x1a);
            this.templateSAPLogToolStripMenuItem.Text = "Template SAP Log";
            this.templateSAPLogToolStripMenuItem.Click += new EventHandler(this.templateSAPLogToolStripMenuItem_Click);
            this.migrateOldLogToNewOneToolStripMenuItem.Name = "migrateOldLogToNewOneToolStripMenuItem";
            this.migrateOldLogToNewOneToolStripMenuItem.Size = new Size(0x114, 0x1a);
            this.migrateOldLogToNewOneToolStripMenuItem.Text = "Migrate Old Log to New One";
            this.migrateOldLogToNewOneToolStripMenuItem.Click += new EventHandler(this.migrateOldLogToNewOneToolStripMenuItem_Click);
            this.indicatorStabilityReportToolStripMenuItem.Name = "indicatorStabilityReportToolStripMenuItem";
            this.indicatorStabilityReportToolStripMenuItem.Size = new Size(0x142, 0x1a);
            this.indicatorStabilityReportToolStripMenuItem.Text = "Indicator Stability Report";
            this.indicatorStabilityReportToolStripMenuItem.Click += new EventHandler(this.indicatorStabilityReportToolStripMenuItem_Click);
            ToolStripItem[] itemArray9 = new ToolStripItem[] { this.userListReportToolStripMenuItem, this.accessRightReportToolStripMenuItem };
            this.userManagementReportToolStripMenuItem.DropDownItems.AddRange(itemArray9);
            this.userManagementReportToolStripMenuItem.Name = "userManagementReportToolStripMenuItem";
            this.userManagementReportToolStripMenuItem.Size = new Size(0x142, 0x1a);
            this.userManagementReportToolStripMenuItem.Text = "User Management Report";
            this.userListReportToolStripMenuItem.Name = "userListReportToolStripMenuItem";
            this.userListReportToolStripMenuItem.Size = new Size(0xd8, 0x1a);
            this.userListReportToolStripMenuItem.Text = "User List Report";
            this.userListReportToolStripMenuItem.Click += new EventHandler(this.userListReportToolStripMenuItem_Click);
            this.accessRightReportToolStripMenuItem.Name = "accessRightReportToolStripMenuItem";
            this.accessRightReportToolStripMenuItem.Size = new Size(0xd8, 0x1a);
            this.accessRightReportToolStripMenuItem.Text = "Access Right Report";
            this.accessRightReportToolStripMenuItem.Click += new EventHandler(this.accessRightReportToolStripMenuItem_Click);
            this.emailRecipientReportToolStripMenuItem.Name = "emailRecipientReportToolStripMenuItem";
            this.emailRecipientReportToolStripMenuItem.Size = new Size(0x142, 0x1a);
            this.emailRecipientReportToolStripMenuItem.Text = "Email Recipient Report";
            this.emailRecipientReportToolStripMenuItem.Click += new EventHandler(this.emailRecipientReportToolStripMenuItem_Click);
            this.uploadSAPToolStripMenuItem.Name = "uploadSAPToolStripMenuItem";
            this.uploadSAPToolStripMenuItem.Size = new Size(0x76, 0x18);
            this.uploadSAPToolStripMenuItem.Text = "&Upload to SAP";
            this.uploadSAPToolStripMenuItem.Click += new EventHandler(this.uploadSAPToolStripMenuItem_Click);
            this.changeProfileToolStripMenuItem.Name = "changeProfileToolStripMenuItem";
            this.changeProfileToolStripMenuItem.Size = new Size(0x76, 0x18);
            this.changeProfileToolStripMenuItem.Text = "Change Profile";
            this.changeProfileToolStripMenuItem.Click += new EventHandler(this.changeProfileToolStripMenuItem_Click);
            this.logOffToolStripMenuItem.Name = "logOffToolStripMenuItem";
            this.logOffToolStripMenuItem.Size = new Size(0x44, 0x18);
            this.logOffToolStripMenuItem.Text = "&Logout";
            this.logOffToolStripMenuItem.Click += new EventHandler(this.logOffToolStripMenuItem_Click);
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new Size(0x2d, 0x18);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new EventHandler(this.exitToolStripMenuItem_Click);
            this.statusWB.BackColor = Color.FromArgb(0x80, 0x80, 0xff);
            this.statusWB.ImageScalingSize = new Size(20, 20);
            ToolStripItem[] itemArray10 = new ToolStripItem[] { this.Status1 };
            this.statusWB.Items.AddRange(itemArray10);
            this.statusWB.Location = new Point(0, 0x29b);
            this.statusWB.Name = "statusWB";
            this.statusWB.Padding = new Padding(1, 0, 0x13, 0);
            this.statusWB.Size = new Size(0x550, 0x19);
            this.statusWB.TabIndex = 1;
            this.statusWB.Text = "statusStrip1";
            this.statusWB.ItemClicked += new ToolStripItemClickedEventHandler(this.statusWB_ItemClicked);
            this.Status1.Name = "Status1";
            this.Status1.Size = new Size(0xc6, 20);
            this.Status1.Text = "Wilmar Group - Copyright \x00a9";
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Dock = DockStyle.Fill;
            this.tableLayoutPanel1.Location = new Point(0, 0x1c);
            this.tableLayoutPanel1.Margin = new Padding(4, 4, 4, 4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 30f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 91.74312f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 68f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 10f));
            this.tableLayoutPanel1.Size = new Size(0x550, 0x27f);
            this.tableLayoutPanel1.TabIndex = 2;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = style;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = style2;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(4, 0x22);
            this.dataGridView1.Margin = new Padding(4, 4, 4, 4);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = style3;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x548, 0x20b);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.dataGridView1.MouseClick += new MouseEventHandler(this.dataGridView1_MouseClick);
            this.panel1.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.panel1.Controls.Add(this.checkWBCode);
            this.panel1.Controls.Add(this.checkPartial);
            this.panel1.Controls.Add(this.checkShowCheckSum);
            this.panel1.Controls.Add(this.Garis2);
            this.panel1.Controls.Add(this.labelStatus1);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.dateTimePicker2);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Controls.Add(this.buttonFilter);
            this.panel1.Controls.Add(this.Garis1);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.ForeColor = Color.Black;
            this.panel1.Location = new Point(0, 0x237);
            this.panel1.Margin = new Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x550, 0x3e);
            this.panel1.TabIndex = 2;
            this.checkWBCode.Location = new Point(0x38c, 0x1f);
            this.checkWBCode.Margin = new Padding(4, 4, 4, 4);
            this.checkWBCode.Name = "checkWBCode";
            this.checkWBCode.Size = new Size(0xc4, 0x17);
            this.checkWBCode.TabIndex = 15;
            this.checkWBCode.Text = "WB Code";
            this.checkWBCode.UseVisualStyleBackColor = true;
            this.checkWBCode.CheckedChanged += new EventHandler(this.checkWBCode_CheckedChanged);
            this.checkPartial.AutoSize = true;
            this.checkPartial.Location = new Point(0x30d, 30);
            this.checkPartial.Margin = new Padding(4, 4, 4, 4);
            this.checkPartial.Name = "checkPartial";
            this.checkPartial.Size = new Size(70, 0x15);
            this.checkPartial.TabIndex = 14;
            this.checkPartial.Text = "Partial";
            this.checkPartial.UseVisualStyleBackColor = true;
            this.checkPartial.CheckedChanged += new EventHandler(this.checkPartial_CheckedChanged);
            this.checkShowCheckSum.Location = new Point(0x38c, 4);
            this.checkShowCheckSum.Margin = new Padding(4, 4, 4, 4);
            this.checkShowCheckSum.Name = "checkShowCheckSum";
            this.checkShowCheckSum.Size = new Size(0x9c, 0x19);
            this.checkShowCheckSum.TabIndex = 12;
            this.checkShowCheckSum.Text = "Checksum Error";
            this.checkShowCheckSum.UseVisualStyleBackColor = true;
            this.checkShowCheckSum.Visible = false;
            this.checkShowCheckSum.CheckedChanged += new EventHandler(this.checkShowCheckSum_CheckedChanged);
            this.Garis2.BorderStyle = BorderStyle.Fixed3D;
            this.Garis2.Location = new Point(0x378, -34);
            this.Garis2.Margin = new Padding(1, 0, 1, 0);
            this.Garis2.Name = "Garis2";
            this.Garis2.Size = new Size(15, 0x5f);
            this.Garis2.TabIndex = 5;
            this.labelStatus1.AutoSize = true;
            this.labelStatus1.Dock = DockStyle.Right;
            this.labelStatus1.Location = new Point(0x522, 0);
            this.labelStatus1.Margin = new Padding(4, 0, 4, 0);
            this.labelStatus1.Name = "labelStatus1";
            this.labelStatus1.Size = new Size(0x2e, 0x11);
            this.labelStatus1.TabIndex = 11;
            this.labelStatus1.Text = "label5";
            this.checkBox1.Location = new Point(0x27d, 4);
            this.checkBox1.Margin = new Padding(4, 4, 4, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new Size(0xf5, 0x19);
            this.checkBox1.TabIndex = 10;
            this.checkBox1.Text = "Show Cancelled";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.dateTimePicker2.Format = DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new Point(0x1f0, 0x1c);
            this.dateTimePicker2.Margin = new Padding(4, 4, 4, 4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new Size(0x81, 0x16);
            this.dateTimePicker2.TabIndex = 9;
            this.dateTimePicker2.KeyPress += new KeyPressEventHandler(this.dateTimePicker2_KeyPress);
            this.dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new Point(0x14c, 0x1c);
            this.dateTimePicker1.Margin = new Padding(4, 4, 4, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new Size(0x7d, 0x16);
            this.dateTimePicker1.TabIndex = 8;
            this.dateTimePicker1.KeyPress += new KeyPressEventHandler(this.dateTimePicker1_KeyPress);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x1d3, 0x24);
            this.label3.Margin = new Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new Size(20, 0x11);
            this.label3.TabIndex = 7;
            this.label3.Text = "to";
            this.label4.Location = new Point(0x148, 7);
            this.label4.Margin = new Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x12b, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Filter data from";
            this.TextFind.CharacterCasing = CharacterCasing.Upper;
            this.TextFind.Location = new Point(4, 4);
            this.TextFind.Margin = new Padding(4, 4, 4, 4);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xf4, 0x16);
            this.TextFind.TabIndex = 1;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.buttonFind.Location = new Point(0x8b, 0x24);
            this.buttonFind.Margin = new Padding(4, 4, 4, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x6f, 0x19);
            this.buttonFind.TabIndex = 2;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.buttonFilter.Location = new Point(0x27b, 30);
            this.buttonFilter.Margin = new Padding(4, 4, 4, 4);
            this.buttonFilter.Name = "buttonFilter";
            this.buttonFilter.Size = new Size(0x89, 0x1a);
            this.buttonFilter.TabIndex = 4;
            this.buttonFilter.Text = "Filter";
            this.buttonFilter.UseVisualStyleBackColor = true;
            this.buttonFilter.Click += new EventHandler(this.button5_Click);
            this.Garis1.BorderStyle = BorderStyle.Fixed3D;
            this.Garis1.Location = new Point(0x130, -12);
            this.Garis1.Margin = new Padding(1, 0, 1, 0);
            this.Garis1.Name = "Garis1";
            this.Garis1.Size = new Size(0x13, 0x4b);
            this.Garis1.TabIndex = 4;
            this.label1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = Color.FromArgb(0x80, 0x80, 0xff);
            this.label1.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.ForeColor = Color.White;
            this.label1.Location = new Point(0, 0);
            this.label1.Margin = new Padding(0);
            this.label1.Name = "label1";
            this.label1.RightToLeft = RightToLeft.Yes;
            this.label1.Size = new Size(0x550, 30);
            this.label1.TabIndex = 1;
            this.label1.Text = "WEIGHING TRANSACTION";
            this.label1.TextAlign = ContentAlignment.TopCenter;
            this.timerSAPUpd.Interval = 0x3e8;
            this.timerSAPUpd.Tick += new EventHandler(this.timerSAPUpd_Tick);
            this.lblNow.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lblNow.AutoSize = true;
            this.lblNow.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.lblNow.Location = new Point(0x353, 6);
            this.lblNow.Margin = new Padding(4, 0, 4, 0);
            this.lblNow.Name = "lblNow";
            this.lblNow.Size = new Size(0x40, 0x11);
            this.lblNow.TabIndex = 4;
            this.lblNow.Text = "00:00:00";
            this.lblNow.Visible = false;
            this.lblDate.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lblDate.AutoSize = true;
            this.lblDate.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.lblDate.Location = new Point(0x319, 9);
            this.lblDate.Margin = new Padding(4, 0, 4, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new Size(50, 0x11);
            this.lblDate.TabIndex = 5;
            this.lblDate.Text = "progre";
            this.backgroundWorkerSAP.DoWork += new DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.timer1.Tick += new EventHandler(this.timer1_Tick_1);
            this.timerTokenEmail.Tick += new EventHandler(this.timerTokenEmail_Tick);
            this.backgroundWorkerEmail.DoWork += new DoWorkEventHandler(this.backgroundWorkerEmail_DoWork);
            this.label2.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.label2.AutoEllipsis = true;
            this.label2.AutoSize = true;
            this.label2.BackColor = Color.FromArgb(0x80, 0x80, 0xff);
            this.label2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label2.ForeColor = Color.White;
            this.label2.Location = new Point(0x3a8, 0x29c);
            this.label2.Margin = new Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x6a, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "User ID : xxx";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            base.AutoScaleDimensions = new SizeF(8f, 16f);
            base.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.Lavender;
            base.ClientSize = new Size(0x550, 0x2b4);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.lblDate);
            base.Controls.Add(this.lblNow);
            base.Controls.Add(this.tableLayoutPanel1);
            base.Controls.Add(this.statusWB);
            base.Controls.Add(this.menuStrip1);
            base.Icon = (Icon) manager.GetObject("$this.Icon");
            base.MainMenuStrip = this.menuStrip1;
            base.Margin = new Padding(4, 4, 4, 4);
            base.Name = "MainFormAfrica";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "WB System";
            base.WindowState = FormWindowState.Maximized;
            base.FormClosing += new FormClosingEventHandler(this.MainForm_FormClosing);
            base.Load += new EventHandler(this.MainForm_Load);
            base.KeyPress += new KeyPressEventHandler(this.MainForm_KeyPress);
            base.Leave += new EventHandler(this.MainForm_Leave);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusWB.ResumeLayout(false);
            this.statusWB.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void laporanPeneriamPerSupploerLA1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBLA1 pffbla = new RepFFBLA1 {
                ffb = true
            };
            pffbla.ShowDialog();
            pffbla.Dispose();
        }

        private void laporanPenerimaanTBSSupplierLA1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void laporanTotalPenerimaanTBSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBLA2 pffbla = new RepFFBLA2 {
                ffb = true
            };
            pffbla.ShowDialog();
            pffbla.Dispose();
        }

        private void listOfWeighningToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void listOfWeighningToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            RepListWeighing weighing = new RepListWeighing();
            weighing.ShowDialog();
            weighing.Dispose();
        }

        private void loadColumnPositionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.SetDisplayOrder();
        }

        private void loadUloadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormLoadUnload unload = new FormLoadUnload();
            unload.ShowDialog();
            unload.Dispose();
        }

        private void locationLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepMasterDataLog log = new RepMasterDataLog {
                Text = "Location Log Report",
                labelHeader = { Text = "Log of Location" },
                labelMasterData = { Text = "Log for: " },
                flag = "LOCATION"
            };
            log.ShowDialog();
            log.Dispose();
        }

        private void logOffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Resource.Mes_514 + " " + WBUser.UserID + " ? ", Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string keyField = "";
                string machineName = Environment.MachineName;
                string str3 = "";
                IPAddress[] addressList = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
                int index = 0;
                while (true)
                {
                    if (index >= addressList.Length)
                    {
                        WBTable table = new WBTable();
                        table.OpenTable("wb_user", "SELECT * FROM wb_user WHERE " + WBData.CompanyLocation(" AND user_id = '" + WBUser.UserID + "'"), WBData.conn);
                        if (table.DT.Rows.Count > 0)
                        {
                            table.DR = table.DT.Rows[0];
                            keyField = table.DR["uniq"].ToString();
                            table.DR.BeginEdit();
                            table.DR["lastLogout"] = DateTime.Now;
                            table.DR["lastLogoutIP"] = DateTime.Now.ToString("HH:mm:ss") + str3;
                            table.DR["lastLogoutCompName"] = DateTime.Now.ToString("HH:mm:ss") + machineName;
                            table.DR["checksum"] = table.Checksum(table.DR);
                            table.DR.EndEdit();
                            table.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "LOGSYS", WBUser.UserID, "Logout from system" };
                            Program.updateLogHeader("wb_user", keyField, logField, logValue);
                        }
                        table.Dispose();
                        base.Hide();
                        WBUser.UserID = "";
                        WBUser.UserPass = "";
                        if (!WBUser.Login())
                        {
                            Application.Exit();
                        }
                        else
                        {
                            base.WindowState = FormWindowState.Minimized;
                            this.Refresh();
                            base.Show();
                            this.fm = new FormMessage();
                            this.fm.label1.Text = "Preparing . . . . . . . ";
                            this.fm.Show();
                            this.fm.Refresh();
                            this.f_load();
                            base.WindowState = FormWindowState.Maximized;
                            this.fm.Dispose();
                        }
                        break;
                    }
                    IPAddress address = addressList[index];
                    AddressFamily addressFamily = address.AddressFamily;
                    if (addressFamily.ToString() == "InterNetwork")
                    {
                        str3 = address.ToString();
                    }
                    index++;
                }
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            WBData.Close();
        }

        private void MainForm_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.exitToolStripMenuItem.PerformClick();
            }
        }

        private void MainForm_Leave(object sender, EventArgs e)
        {
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.translate();
            Cursor.Current = Cursors.WaitCursor;
            base.Opacity = 0.0;
            this.f_load();
            base.WindowState = FormWindowState.Maximized;
            base.Opacity = 100.0;
            this.SetDisplayOrder();
            Cursor.Current = Cursors.Default;
            this.fm.Dispose();
        }

        private void mapCommTrxTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCommTrx trx = new FormCommTrx();
            trx.ShowDialog();
            trx.Dispose();
        }

        private void masterDataLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepMasterDataLog log = new RepMasterDataLog();
            log.ShowDialog();
            log.Dispose();
        }

        private void masterDataToolStripMenuItem1_DropDownOpening(object sender, EventArgs e)
        {
            int length = 0;
            try
            {
                foreach (object obj2 in this.masterDataToolStripMenuItem1.DropDownItems)
                {
                    if (obj2.GetType().Equals(typeof(ToolStripMenuItem)))
                    {
                        ToolStripMenuItem item = (ToolStripMenuItem) obj2;
                        string str = (WBSetting.locType != "0") ? "REF" : "POM";
                        length = item.Name.Length;
                        if (length > 2)
                        {
                            item.Visible = item.Name.Substring(length - 3, 3).ToUpper() != str;
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void md10ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_ESTATE", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormEstate estate = new FormEstate();
                estate.ShowDialog();
                estate.Dispose();
            }
        }

        private void md12ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_CAPACITY", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormTanker tanker = new FormTanker();
                tanker.ShowDialog();
                tanker.Dispose();
            }
        }

        private void md13ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_GRADING", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormGrading grading = new FormGrading();
                grading.ShowDialog();
                grading.Dispose();
            }
        }

        private void md1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_CONTRACT", "V"))
            {
                WBUser.ShowErr();
            }
            else if (WBSetting.Field("region") == "1")
            {
                FormContractAfrica africa = new FormContractAfrica();
                africa.ShowDialog();
                africa.Dispose();
            }
            else
            {
                FormContract contract = new FormContract();
                contract.ShowDialog();
                contract.Dispose();
            }
        }

        private void md2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_STOCK", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormCommodity commodity = new FormCommodity();
                commodity.ShowDialog();
                commodity.Dispose();
            }
        }

        private void md3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_VENDOR", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormVendor vendor = new FormVendor();
                vendor.ShowDialog();
                vendor.Dispose();
            }
        }

        private void md4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_TRUCK", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormTruck truck = new FormTruck();
                truck.ShowDialog();
                truck.Dispose();
            }
        }

        private void md5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_DRIVER", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormDriver driver = new FormDriver();
                driver.ShowDialog();
                driver.Dispose();
            }
        }

        private void md6rToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_TRANSPORTER", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormTransporter transporter = new FormTransporter();
                transporter.ShowDialog();
                transporter.Dispose();
            }
        }

        private void md7ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormLocation location = new FormLocation();
            location.ShowDialog();
            location.Dispose();
        }

        private void md8ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_STORAGE", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormStorage storage = new FormStorage();
                storage.ShowDialog();
                storage.Dispose();
            }
        }

        private void md9ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MD_DIVISION", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormDivision division = new FormDivision();
                division.ShowDialog();
                division.Dispose();
            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void mergeDOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                string str = "";
                str = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mes_496);
                }
                else
                {
                    str = "";
                    if (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == "X")
                    {
                        MessageBox.Show(Resource.Mes_518, Resource.Title_002);
                    }
                    else if ((this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == "N") || (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == ""))
                    {
                        MessageBox.Show(Resource.Mes_497, Resource.Title_002);
                    }
                    else if ((this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == "Y") && ((MessageBox.Show(Resource.Mes_524, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes) && (this.Trans.BeforeEdit(this.dataGridView1, "MERGE") && !this.Trans.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1'))))
                    {
                        WBTable table = new WBTable();
                        WBTable table2 = new WBTable();
                        WBTable table3 = new WBTable();
                        WBTable table4 = new WBTable();
                        string str2 = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                        string str3 = "";
                        string str4 = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                        table3.OpenTable("wb_transDOTemp", "Select * from wb_transDO where " + WBData.CompanyLocation(" and ref like '" + str2 + "%'"), WBData.conn);
                        int count = table3.DT.Rows.Count;
                        string[] strArray = new string[count];
                        table.OpenTable("wb_transSplit", "Select * from wb_transSPlit where " + WBData.CompanyLocation(" and ref = '" + str2 + "'"), WBData.conn);
                        if (table.DT.Rows.Count > 0)
                        {
                            table.DR = table.DT.Rows[0];
                        }
                        string keyField = "";
                        string[,] strArray2 = new string[count, 2];
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= count)
                            {
                                table3.Save();
                                int num5 = 0;
                                while (true)
                                {
                                    if (num5 >= count)
                                    {
                                        table2.OpenTable("wb_transTemp", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref like '" + str2 + "%'"), WBData.conn);
                                        count = table2.DT.Rows.Count;
                                        if (table2.DT.Rows.Count > 0)
                                        {
                                            int num6 = 0;
                                            while (true)
                                            {
                                                if (num6 >= count)
                                                {
                                                    break;
                                                }
                                                table2.DR = table2.DT.Rows[num6];
                                                if (((str2 == table2.DR["REF"].ToString()) || ((str2 + "T") == table2.DR["REF"].ToString())) && (table2.DR["split"].ToString() == "Y"))
                                                {
                                                    table2.DR.BeginEdit();
                                                    table2.DR["Split"] = "N";
                                                    table2.DR["posted"] = "N";
                                                    table2.DR["_1ST"] = table.DR["_1ST"].ToString();
                                                    table2.DR["_2ND"] = table.DR["_2ND"].ToString();
                                                    table2.DR["_3RD"] = table.DR["_3RD"].ToString();
                                                    table2.DR["_4TH"] = table.DR["_4TH"].ToString();
                                                    table2.DR["Gross"] = table.DR["Gross"].ToString();
                                                    table2.DR["Tare"] = table.DR["Tare"].ToString();
                                                    table2.DR["Received"] = table.DR["Received"].ToString();
                                                    table2.DR["Net"] = table.DR["Net"].ToString();
                                                    table2.DR["Gross_Estate"] = table.DR["Gross_Estate"].ToString();
                                                    table2.DR["Tare_Estate"] = table.DR["Tare_Estate"].ToString();
                                                    table2.DR["Net_Estate"] = table.DR["Net_Estate"].ToString();
                                                    table2.DR["checksum"] = table2.Checksum(table2.DR);
                                                    table2.DR.EndEdit();
                                                    table2.Save();
                                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                    string[] logValue = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                    Program.updateLogHeader("wb_transaction", table2.DR["uniq"].ToString(), logField, logValue);
                                                }
                                                num6++;
                                            }
                                        }
                                        table.Close();
                                        table2.Close();
                                        this.Trans.ReOpen();
                                        this.dataGridView1 = this.Trans.AfterEdit(this.pMode);
                                        this.dataGridView1.Sort(this.dataGridView1.Columns["Ref"], ListSortDirection.Ascending);
                                        string[] aField = new string[] { "Ref" };
                                        string[] aFind = new string[] { str2 };
                                        this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                                        table.Dispose();
                                        table4.Dispose();
                                        table3.Dispose();
                                        table2.Dispose();
                                        MessageBox.Show(Resource.Mes_515, Resource.Title_007);
                                        this.Trans.UnLock();
                                        break;
                                    }
                                    if (strArray2[num5, 1] == "del")
                                    {
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                        Program.updateLogHeader("wb_transDO", strArray2[num5, 0], logField, logValue);
                                    }
                                    else if (strArray2[num5, 1] == "edit")
                                    {
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                        Program.updateLogHeader("wb_transDO", strArray2[num5, 0], logField, logValue);
                                    }
                                    num5++;
                                }
                                break;
                            }
                            table3.DR = table3.DT.Rows[num2];
                            str3 = table3.DR["ref"].ToString().Trim();
                            if ((str3 == str2) || (str3 == (str2 + "T")))
                            {
                                if ((str3 == str2) || (str3 == (str2 + "T")))
                                {
                                    table2.OpenTable("wb_transTemp", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + str3 + "'"), WBData.conn);
                                    if (table2.DT.Rows.Count > 0)
                                    {
                                        table2.DR = table2.DT.Rows[0];
                                        if (table2.DR["split"].ToString() == "Y")
                                        {
                                            strArray2[num2, 0] = table3.DR["uniq"].ToString();
                                            strArray2[num2, 1] = "edit";
                                            table3.DR.BeginEdit();
                                            table3.DR["Bruto"] = table.DR["Gross"].ToString();
                                            table3.DR["Tarra"] = table.DR["Tare"].ToString();
                                            table3.DR["Netto"] = table.DR["Net"].ToString();
                                            table3.DR["Estate_qty"] = table.DR["Net_Estate"].ToString();
                                            table3.DR.EndEdit();
                                        }
                                    }
                                    table2.Close();
                                }
                            }
                            else
                            {
                                table2.OpenTable("wb_transTemp", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + str3 + "'"), WBData.conn);
                                if (table2.DT.Rows.Count > 0)
                                {
                                    table2.DR = table2.DT.Rows[0];
                                    if (table2.DR["split"].ToString() == "X")
                                    {
                                        strArray2[num2, 0] = table3.DR["uniq"].ToString();
                                        strArray2[num2, 1] = "del";
                                        table3.DR.Delete();
                                        keyField = table2.DR["uniq"].ToString();
                                        table2.DR.Delete();
                                        table4.OpenTable("wb_transQCtemp", "Select * from wb_transQC where " + WBData.CompanyLocation(" and ref = '" + str3 + "'"), WBData.conn);
                                        string[] strArray3 = new string[table4.DT.Rows.Count];
                                        int index = 0;
                                        while (true)
                                        {
                                            if (index >= table4.DT.Rows.Count)
                                            {
                                                table4.Save();
                                                int num4 = 0;
                                                while (true)
                                                {
                                                    if (num4 >= strArray3.Length)
                                                    {
                                                        table4.Close();
                                                        table2.Save();
                                                        string[] textArray3 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                        string[] textArray4 = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                        Program.updateLogHeader("wb_transaction", keyField, textArray3, textArray4);
                                                        table2.Close();
                                                        break;
                                                    }
                                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                    string[] logValue = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                    Program.updateLogHeader("wb_transQC", strArray3[num4], logField, logValue);
                                                    num4++;
                                                }
                                                break;
                                            }
                                            strArray3[index] = table4.DT.Rows[index]["uniq"].ToString();
                                            table4.DT.Rows[index].Delete();
                                            index++;
                                        }
                                    }
                                }
                            }
                            num2++;
                        }
                    }
                }
            }
        }

        private void migrateOldLogToNewOneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WBTable table;
            WBTable table2;
            WBTable table3;
            WBTable table4;
            WBTable table5;
            string str;
            if (MessageBox.Show("Are you sure want to migrate data from old log to the new one?", Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
            {
                return;
            }
            else
            {
                Cursor.Current = Cursors.WaitCursor;
                table = new WBTable();
                table2 = new WBTable();
                table3 = new WBTable();
                table4 = new WBTable();
                table5 = new WBTable();
                table3.OpenTable("wb_log_header", "SELECT * FROM wb_log_header WHERE " + WBData.CompanyLocation(""), WBData.conn);
                table4.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail WHERE " + WBData.CompanyLocation(""), WBData.conn);
                str = "";
                str = ("SELECT distinct(ref) FROM wb_trans_log WHERE " + WBData.CompanyLocation("") + " AND ((WX='2X' AND _2nd>0) or (WX='4X' AND _4th>0)) ") + " AND (EDIT_BY is not null AND EDIT_BY <> '') " + " Order by ref asc";
                table2.OpenTable("wb_trans_log", str, WBData.conn);
                foreach (DataRow row in table2.DT.Rows)
                {
                    str = ((("SELECT * FROM wb_trans_log WHERE " + WBData.CompanyLocation("")) + " AND ((WX='2X' AND _2nd>0) or (WX='4X' AND _4th>0)) " + " AND (EDIT_BY is not null AND EDIT_BY <> '') ") + " AND Ref = '" + row["ref"].ToString() + "'") + " Order by ref,uniq asc";
                    table5.OpenTable("wb_transaction", "SELECT uniq FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Ref = '" + row["ref"].ToString() + "'"), WBData.conn);
                    table.OpenTable("wb_trans_log", str, WBData.conn);
                    if (table5.DT.Rows.Count > 0)
                    {
                        int num = 1;
                        while (true)
                        {
                            if (num >= table.DT.Rows.Count)
                            {
                                break;
                            }
                            bool flag3 = false;
                            string str2 = "";
                            int num2 = 0;
                            while (true)
                            {
                                if (num2 >= table.DT.Columns.Count)
                                {
                                    if (flag3)
                                    {
                                        string[] textArray1 = new string[9];
                                        textArray1[0] = "Coy";
                                        textArray1[1] = "Location_Code";
                                        textArray1[2] = "logDate";
                                        textArray1[3] = "pMode";
                                        textArray1[4] = "userID";
                                        textArray1[5] = "changeReason";
                                        textArray1[6] = "Type";
                                        textArray1[7] = "TableName";
                                        textArray1[8] = "keyField";
                                        string[] aField = textArray1;
                                        string[] textArray2 = new string[9];
                                        textArray2[0] = WBData.sCoyCode;
                                        textArray2[1] = WBData.sLocCode;
                                        textArray2[2] = table.DT.Rows[num]["log_time"].ToString();
                                        textArray2[3] = str2;
                                        textArray2[4] = table.DT.Rows[num]["Edit_By"].ToString();
                                        textArray2[5] = table.DT.Rows[num]["changeReason"].ToString();
                                        textArray2[6] = "U";
                                        textArray2[7] = "wb_transaction";
                                        textArray2[8] = table5.DT.Rows[0]["uniq"].ToString();
                                        string[] aFind = textArray2;
                                        if ((table3.GetData(aField, aFind) == null) && (table.DT.Rows[num]["log_time"].ToString() != ""))
                                        {
                                            table3.DR = table3.DT.NewRow();
                                            table3.DR["Coy"] = WBData.sCoyCode;
                                            table3.DR["Location_Code"] = WBData.sLocCode;
                                            table3.DR["logDate"] = table.DT.Rows[num]["log_time"].ToString();
                                            table3.DR["pMode"] = str2;
                                            table3.DR["userID"] = table.DT.Rows[num]["Edit_By"].ToString();
                                            table3.DR["changeReason"] = table.DT.Rows[num]["changeReason"].ToString();
                                            table3.DR["Type"] = "U";
                                            table3.DR["TableName"] = "wb_transaction";
                                            table3.DR["keyField"] = table5.DT.Rows[0]["uniq"].ToString();
                                            table3.DT.Rows.Add(table3.DR);
                                            table3.Save();
                                            string str4 = "";
                                            table3.ReOpen();
                                            DataRow data = table3.GetData(aField, aFind);
                                            if (data != null)
                                            {
                                                str4 = data["uniq"].ToString();
                                            }
                                            int num3 = 0;
                                            while (true)
                                            {
                                                if (num3 >= table.DT.Columns.Count)
                                                {
                                                    break;
                                                }
                                                string str5 = table.DT.Columns[num3].ColumnName.ToString();
                                                bool flag13 = table.DT.Rows[num]["log_time"].ToString() == table.DT.Rows[num - 1]["log_time"].ToString();
                                                if (flag13 && ((table.DT.Columns[num3].ColumnName.ToString().ToUpper() != "UNIQ") && (table.DT.Rows[num][num3].ToString() != table.DT.Rows[num - 1][num3].ToString())))
                                                {
                                                    table4.DR = table4.DT.NewRow();
                                                    table4.DR["Coy"] = WBData.sCoyCode;
                                                    table4.DR["Location_Code"] = WBData.sLocCode;
                                                    table4.DR["TableName"] = "wb_transaction";
                                                    table4.DR["FieldName"] = str5;
                                                    table4.DR["OldValue"] = table.DT.Rows[num - 1][num3].ToString();
                                                    table4.DR["NewValue"] = table.DT.Rows[num][num3].ToString();
                                                    table4.DR["keyField"] = table5.DT.Rows[0]["uniq"].ToString();
                                                    table4.DR["keyHeader"] = str4;
                                                    table4.DT.Rows.Add(table4.DR);
                                                    table4.Save();
                                                }
                                                num3++;
                                            }
                                        }
                                    }
                                    num++;
                                    break;
                                }
                                string str3 = table.DT.Columns[num2].ColumnName.ToString();
                                bool flag4 = table.DT.Rows[num]["log_time"].ToString() == table.DT.Rows[num - 1]["log_time"].ToString();
                                if (flag4 && ((table.DT.Columns[num2].ColumnName.ToString().ToUpper() != "UNIQ") && (table.DT.Rows[num][num2].ToString() != table.DT.Rows[num - 1][num2].ToString())))
                                {
                                    flag3 = true;
                                    if (str3 == "edit_data")
                                    {
                                        str2 = "EDIT";
                                    }
                                    else if (str3 == "edit_qty")
                                    {
                                        str2 = "QTY";
                                    }
                                }
                                num2++;
                            }
                        }
                    }
                }
                table5.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND deleted = 'Y'"), WBData.conn);
                if (table5.DT.Rows.Count > 0)
                {
                    foreach (DataRow row4 in table5.DT.Rows)
                    {
                        table3.DR = table3.DT.NewRow();
                        table3.DR["Coy"] = WBData.sCoyCode;
                        table3.DR["Location_Code"] = WBData.sLocCode;
                        table3.DR["logDate"] = row4["delete_date"].ToString();
                        table3.DR["pMode"] = "CANCEL";
                        table3.DR["userID"] = row4["delete_by"].ToString();
                        table3.DR["changeReason"] = row4["changeReason"].ToString();
                        table3.DR["Type"] = "U";
                        table3.DR["TableName"] = "wb_transaction";
                        table3.DR["keyField"] = row4["uniq"].ToString();
                        table3.DT.Rows.Add(table3.DR);
                        table3.Save();
                    }
                }
            }
            str = ((" SELECT printed, printed_by, printed_date, edit_by, changeReason, * FROM wb_trans_log " + " WHERE " + WBData.CompanyLocation("")) + " AND printed > 1 " + " AND ((WX = '2X' AND _2nd > 0) or (WX = '4X' AND _4th > 0))") + " AND (printed_by IS NOT NULL AND printed_date IS NOT NULL)" + " AND (edit_by = '' OR edit_by IS NULL)";
            table.OpenTable("wb_trans_log", str, WBData.conn);
            foreach (DataRow row5 in table.DT.Rows)
            {
                table5.OpenTable("wb_transaction", "SELECT uniq FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Ref = '" + row5["ref"].ToString() + "'"), WBData.conn);
                if (table5.DT.Rows.Count > 0)
                {
                    table3.DR = table3.DT.NewRow();
                    table3.DR["Coy"] = WBData.sCoyCode;
                    table3.DR["Location_Code"] = WBData.sLocCode;
                    table3.DR["logDate"] = row5["printed_date"].ToString();
                    table3.DR["pMode"] = "REPRINT";
                    table3.DR["userID"] = row5["printed_by"].ToString();
                    table3.DR["changeReason"] = row5["changeReason"].ToString();
                    table3.DR["Type"] = "U";
                    table3.DR["TableName"] = "wb_transaction";
                    table3.DR["keyField"] = table5.DT.Rows[0]["uniq"].ToString();
                    table3.DT.Rows.Add(table3.DR);
                    table3.Save();
                }
            }
            str = ("SELECT distinct(do_no) FROM wb_contract_log WHERE " + WBData.CompanyLocation("")) + " AND (Change_By is not null AND Change_By <> '') " + " Order by do_no asc";
            table2.OpenTable("wb_contract_log", str, WBData.conn);
            foreach (DataRow row6 in table2.DT.Rows)
            {
                str = (("SELECT * FROM wb_contract_log WHERE " + WBData.CompanyLocation("") + " AND (Change_By is not null AND Change_By <> '') ") + " AND do_no = '" + row6["do_no"].ToString() + "'") + " Order by do_no, uniq asc";
                table5.OpenTable("wb_contract", "SELECT uniq FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + row6["do_no"].ToString() + "'"), WBData.conn);
                table.OpenTable("wb_contract_log", str, WBData.conn);
                if (table5.DT.Rows.Count > 0)
                {
                    int num4 = 1;
                    while (true)
                    {
                        if (num4 >= table.DT.Rows.Count)
                        {
                            break;
                        }
                        bool flag21 = false;
                        int num5 = 0;
                        while (true)
                        {
                            if (num5 < table.DT.Columns.Count)
                            {
                                string str6 = table.DT.Columns[num5].ColumnName.ToString();
                                bool flag22 = table.DT.Rows[num4]["log_time"].ToString() == table.DT.Rows[num4 - 1]["log_time"].ToString();
                                if (!flag22 || ((table.DT.Columns[num5].ColumnName.ToString().ToUpper() == "UNIQ") || (table.DT.Rows[num4][num5].ToString() == table.DT.Rows[num4 - 1][num5].ToString())))
                                {
                                    num5++;
                                    continue;
                                }
                                flag21 = true;
                            }
                            if (flag21)
                            {
                                string[] textArray3 = new string[9];
                                textArray3[0] = "Coy";
                                textArray3[1] = "Location_Code";
                                textArray3[2] = "logDate";
                                textArray3[3] = "pMode";
                                textArray3[4] = "userID";
                                textArray3[5] = "changeReason";
                                textArray3[6] = "Type";
                                textArray3[7] = "TableName";
                                textArray3[8] = "keyField";
                                string[] aField = textArray3;
                                string[] textArray4 = new string[9];
                                textArray4[0] = WBData.sCoyCode;
                                textArray4[1] = WBData.sLocCode;
                                textArray4[2] = table.DT.Rows[num4]["log_time"].ToString();
                                textArray4[3] = "EDIT";
                                textArray4[4] = table.DT.Rows[num4]["Change_By"].ToString();
                                textArray4[5] = "-";
                                textArray4[6] = "U";
                                textArray4[7] = "wb_contract";
                                textArray4[8] = table5.DT.Rows[0]["uniq"].ToString();
                                string[] aFind = textArray4;
                                if (ReferenceEquals(table3.GetData(aField, aFind), null))
                                {
                                    table3.DR = table3.DT.NewRow();
                                    table3.DR["Coy"] = WBData.sCoyCode;
                                    table3.DR["Location_Code"] = WBData.sLocCode;
                                    table3.DR["logDate"] = table.DT.Rows[num4]["log_time"].ToString();
                                    table3.DR["pMode"] = "EDIT";
                                    table3.DR["userID"] = table.DT.Rows[num4]["Change_By"].ToString();
                                    table3.DR["changeReason"] = "-";
                                    table3.DR["Type"] = "U";
                                    table3.DR["TableName"] = "wb_contract";
                                    table3.DR["keyField"] = table5.DT.Rows[0]["uniq"].ToString();
                                    table3.DT.Rows.Add(table3.DR);
                                    table3.Save();
                                    string str7 = "";
                                    table3.ReOpen();
                                    DataRow data = table3.GetData(aField, aFind);
                                    if (data != null)
                                    {
                                        str7 = data["uniq"].ToString();
                                    }
                                    int num6 = 0;
                                    while (true)
                                    {
                                        if (num6 >= table.DT.Columns.Count)
                                        {
                                            break;
                                        }
                                        string str8 = table.DT.Columns[num6].ColumnName.ToString();
                                        bool flag29 = table.DT.Rows[num4]["log_time"].ToString() == table.DT.Rows[num4 - 1]["log_time"].ToString();
                                        if (flag29 && ((table.DT.Columns[num6].ColumnName.ToString().ToUpper() != "UNIQ") && (table.DT.Rows[num4][num6].ToString() != table.DT.Rows[num4 - 1][num6].ToString())))
                                        {
                                            table4.DR = table4.DT.NewRow();
                                            table4.DR["Coy"] = WBData.sCoyCode;
                                            table4.DR["Location_Code"] = WBData.sLocCode;
                                            table4.DR["TableName"] = "wb_contract";
                                            table4.DR["FieldName"] = str8;
                                            table4.DR["OldValue"] = table.DT.Rows[num4 - 1][num6].ToString();
                                            table4.DR["NewValue"] = table.DT.Rows[num4][num6].ToString();
                                            table4.DR["keyField"] = table5.DT.Rows[0]["uniq"].ToString();
                                            table4.DR["keyHeader"] = str7;
                                            table4.DT.Rows.Add(table4.DR);
                                            table4.Save();
                                        }
                                        num6++;
                                    }
                                }
                            }
                            num4++;
                            break;
                        }
                    }
                }
            }
            table.Dispose();
            table2.Dispose();
            table3.Dispose();
            table4.Dispose();
            table5.Dispose();
            Cursor.Current = Cursors.Default;
            MessageBox.Show("Transaction & Contract Log Migration has finished!");
        }

        private void millToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormMill mill = new FormMill();
            mill.ShowDialog();
            mill.Dispose();
        }

        private void ndWeightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkWeightValid("2ND"))
            {
                this.Timbang("2ND");
            }
        }

        private void nonContractTransactionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepNonContract contract = new RepNonContract();
            contract.ShowDialog();
            contract.Dispose();
        }

        private void nonToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (((e.CloseReason == CloseReason.UserClosing) || (e.CloseReason == CloseReason.WindowsShutDown)) || (e.CloseReason == CloseReason.TaskManagerClosing))
            {
                if (MessageBox.Show(" Close this program ? ", " CONFIRM ", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                {
                    e.Cancel = true;
                }
                else
                {
                    string keyField = "";
                    string machineName = Environment.MachineName;
                    string str3 = "";
                    IPAddress[] addressList = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
                    int index = 0;
                    while (true)
                    {
                        if (index >= addressList.Length)
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_user", "SELECT * FROM wb_user WHERE " + WBData.CompanyLocation(" AND user_id = '" + WBUser.UserID + "'"), WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                table.DR = table.DT.Rows[0];
                                keyField = table.DR["uniq"].ToString();
                                table.DR.BeginEdit();
                                table.DR["lastLogout"] = DateTime.Now;
                                table.DR["lastLogoutIP"] = DateTime.Now.ToString("HH:mm:ss") + str3;
                                table.DR["lastLogoutCompName"] = DateTime.Now.ToString("HH:mm:ss") + machineName;
                                table.DR["checksum"] = table.Checksum(table.DR);
                                table.DR.EndEdit();
                                table.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "LOGSYS", WBUser.UserID, "Logout from system" };
                                Program.updateLogHeader("wb_user", keyField, logField, logValue);
                            }
                            table.Dispose();
                            if (Program.TMCready)
                            {
                                base.Close();
                            }
                            else
                            {
                                Application.Exit();
                            }
                            break;
                        }
                        IPAddress address = addressList[index];
                        AddressFamily addressFamily = address.AddressFamily;
                        if (addressFamily.ToString() == "InterNetwork")
                        {
                            str3 = address.ToString();
                        }
                        index++;
                    }
                }
            }
        }

        private void print(string refno, ReportDocument cryRpt)
        {
            string[] paramName = new string[2];
            string[] paramValue = new string[] { refno, WBUser.UserName };
            paramName[0] = "ref";
            paramName[1] = "user";
            cryRpt.Refresh();
            cryRpt = Program.setParam2(this.ticket2Rpt, paramName, paramValue);
            this.fRpt.setReport(cryRpt);
            this.fRpt.ShowDialog();
            if (this.fRpt.doPrint)
            {
                cryRpt.PrintToPrinter(1, true, 0, 0);
            }
        }

        private void print(string refno, string Do_No, ReportDocument cryRpt)
        {
            string[] paramName = new string[3];
            string[] paramValue = new string[] { refno, Do_No, WBUser.UserName };
            paramName[0] = "ref";
            paramName[1] = "Do_No";
            paramName[2] = "user";
            cryRpt.Refresh();
            cryRpt = Program.setParam2(this.ticketRpt, paramName, paramValue);
            this.fRpt.setReport(cryRpt);
            this.fRpt.ShowDialog();
            if (this.fRpt.doPrint)
            {
                cryRpt.PrintToPrinter(1, true, 0, 0);
            }
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((!WBUser.CheckTrustee("MN_PRINT", "V") && (this.dataGridView1.CurrentRow.Cells["printed"].Value.ToString() != "")) && (this.dataGridView1.CurrentRow.Cells["printed"].Value.ToString() != "0"))
            {
                MessageBox.Show(Resource.Mes_499, Resource.Title_008);
            }
            else
            {
                string str2 = "";
                string str = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                str2 = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                if (str.Substring(str.Length - 1, 1) == "T")
                {
                    MessageBox.Show(Resource.Mes_498, Resource.Title_002);
                }
                else if (this.dataGridView1.CurrentRow.Cells["report_date"].Value.ToString().Trim() == "")
                {
                    MessageBox.Show(Resource.Mes_500, Resource.Title_002);
                }
                else
                {
                    str = "";
                    string[] aField = new string[] { "Uniq" };
                    string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString() };
                    int recNo = this.Trans.GetRecNo(aField, aFind);
                    string str3 = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                    Cursor.Current = Cursors.WaitCursor;
                    string str5 = Interaction.InputBox("Reprint", "Reason for reprint", "", 300, 300);
                    if (str5 != "")
                    {
                        int num2 = 0;
                        WBTable table = new WBTable();
                        table.OpenTable("wb_transaction", " select " + this.cField + " from wb_transaction where uniq = " + str2.Trim(), WBData.conn);
                        table.DR = table.DT.Rows[0];
                        num2 = (table.DR["printed"].ToString().Trim() == "") ? 0 : Convert.ToInt32(table.DR["printed"].ToString());
                        table.DR.BeginEdit();
                        num2++;
                        table.DR["printed"] = num2;
                        table.DR["Printed_By"] = WBUser.UserID.Trim();
                        table.DR["Printed_Date"] = DateTime.Now;
                        table.DR["checksum"] = table.Checksum(table.DR);
                        table.DR.EndEdit();
                        table.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "REPRINT", WBUser.UserID, str5 };
                        Program.updateLogHeader("wb_transaction", table.DR["Uniq"].ToString(), logField, logValue);
                        table.Dispose();
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_transDo", "select * from wb_transDo where ref = '" + str3.Trim() + "' order by uniq", WBData.conn);
                        table2.DR = table2.DT.Rows[0];
                        string str4 = table2.DR["Do_No"].ToString().Trim();
                        this.print(str3.Trim(), str4, this.ticketRpt);
                        table2.Dispose();
                        this.DataReset();
                        Cursor.Current = Cursors.Default;
                    }
                }
            }
        }

        private void qCItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormYield yield = new FormYield();
            yield.ShowDialog();
            yield.Dispose();
        }

        private void qCReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepQualityControl control = new RepQualityControl();
            control.ShowDialog();
            control.Dispose();
        }

        private void qcStripMenuItem_Click(object sender, EventArgs e)
        {
            string str = "";
            this.nCurrRow = 0;
            if (WBUser.CheckTrustee("TRANS_QC", "V"))
            {
                if (this.dataGridView1.Rows.Count > 0)
                {
                    str = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                    this.Trans.ReOpen();
                    this.dataGridView1 = this.Trans.AfterEdit(this.pMode);
                    string[] aField = new string[] { "uniq" };
                    string[] aFind = new string[] { str };
                    this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                FormConsignmentAfrica africa = new FormConsignmentAfrica {
                    dgTrans = this.dataGridView1
                };
                africa.ShowDialog();
                africa.Dispose();
            }
        }

        private void rdWeightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkWeightValid("3RD"))
            {
                this.Timbang("3RD");
            }
        }

        private void receivingEstimationFrom3rdPartyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepEstimate estimate = new RepEstimate();
            estimate.ShowDialog();
            estimate.Dispose();
        }

        private void repairAllChecksumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string text = this.labelStatus1.Text;
            if (this.dataGridView1.Rows.Count > 0)
            {
                int num = 0;
                while (true)
                {
                    if (num >= this.dataGridView1.Rows.Count)
                    {
                        this.labelStatus1.Text = text;
                        this.labelStatus1.Refresh();
                        break;
                    }
                    this.labelStatus1.Text = num.ToString() + "/" + this.dataGridView1.Rows.Count.ToString();
                    this.labelStatus1.Refresh();
                    string[] aField = new string[] { "Uniq" };
                    string[] aFind = new string[] { this.dataGridView1.Rows[num].Cells["Uniq"].Value.ToString() };
                    int recNo = this.Trans.GetRecNo(aField, aFind);
                    this.Trans.DR = this.Trans.DT.Rows[recNo];
                    if (!this.Trans.ValidChecksum(this.Trans.DR))
                    {
                        this.Trans.DR.BeginEdit();
                        this.Trans.DR["checksum"] = this.Trans.Checksum(this.Trans.DR);
                        this.Trans.DR.EndEdit();
                        this.Trans.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Repair Checksum" };
                        Program.updateLogHeader("wb_transaction", this.Trans.DR["Uniq"].ToString(), logField, logValue);
                        this.dataGridView1.Rows[num].Cells["checksum"].Value = this.Trans.DR["checksum"].ToString();
                    }
                    num++;
                }
            }
        }

        private void repairChecksumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                string[] aField = new string[] { "Uniq" };
                string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["Uniq"].Value.ToString() };
                int recNo = this.Trans.GetRecNo(aField, aFind);
                string str = this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString();
                if (MessageBox.Show(Resource.Mes_523 + str.Trim(), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    this.Trans.DR = this.Trans.DT.Rows[recNo];
                    this.Trans.DR.BeginEdit();
                    this.Trans.DR["checksum"] = this.Trans.Checksum(this.Trans.DR);
                    this.Trans.DR.EndEdit();
                    this.Trans.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Repair Checksum" };
                    Program.updateLogHeader("wb_transaction", this.Trans.DR["Uniq"].ToString(), logField, logValue);
                    this.dataGridView1.CurrentRow.Cells["checksum"].Value = this.Trans.DR["checksum"].ToString();
                }
            }
        }

        private void reportOutstandingDOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepOutstandingDO gdo = new RepOutstandingDO();
            gdo.ShowDialog();
            gdo.Dispose();
        }

        private void ReportToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            int length = 0;
            try
            {
                foreach (object obj2 in this.ReportToolStripMenuItem.DropDownItems)
                {
                    if (obj2.GetType().Equals(typeof(ToolStripMenuItem)))
                    {
                        ToolStripMenuItem item = (ToolStripMenuItem) obj2;
                        string str = (WBSetting.locType != "0") ? "REF" : "POM";
                        if (WBSetting.NonContract != "Y")
                        {
                            this.nonContractTransactionToolStripMenuItem.Visible = false;
                        }
                        length = item.Name.Length;
                        if (length > 2)
                        {
                            item.Visible = item.Name.Substring(length - 3, 3).ToUpper() != str;
                        }
                    }
                }
                if (!WBUser.CheckTrustee("MN_LOGREPORT", "V"))
                {
                    this.masterDataLogToolStripMenuItem.Visible = false;
                    this.transactionLogToolStripMenuItem.Visible = false;
                }
                else
                {
                    this.masterDataLogToolStripMenuItem.Visible = true;
                    this.transactionLogToolStripMenuItem.Visible = true;
                }
                this.userManagementReportToolStripMenuItem.Visible = (Convert.ToInt16(WBUser.UserLevel) == 1) || WBUser.CheckTrustee("MN_USERMGTREPORT", "V");
                this.emailRecipientReportToolStripMenuItem.Visible = (Convert.ToInt16(WBUser.UserLevel) == 1) || WBUser.CheckTrustee("MN_EMAILREPORT", "V");
            }
            catch
            {
            }
        }

        private void saveColumnPositionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.CacheDisplayOrder();
            MessageBox.Show(Resource.Mes_606, Resource.Title_007, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void SetDisplayOrder()
        {
            try
            {
                FileStream stream = File.Open(Directory.GetParent(Application.UserAppDataPath) + @"\col_pos.xml", FileMode.Open);
                try
                {
                    int[] numArray = (int[]) new XmlSerializer(typeof(int[])).Deserialize(stream);
                    int index = 0;
                    while (true)
                    {
                        if (index >= numArray.Length)
                        {
                            break;
                        }
                        this.dataGridView1.Columns[index].DisplayIndex = numArray[index];
                        index++;
                    }
                }
                catch
                {
                }
                finally
                {
                    if (stream != null)
                    {
                        stream.Dispose();
                    }
                }
            }
            catch
            {
            }
        }

        private void settingLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepMasterDataLog log = new RepMasterDataLog {
                Text = "Setting Log Report",
                labelHeader = { Text = "Log of Setting" },
                labelMasterData = { Text = "Log for: " },
                flag = "SETTING"
            };
            log.ShowDialog();
            log.Dispose();
        }

        public void ShowLayout()
        {
            string[] textArray1 = new string[] { "User : ", WBUser.UserID.Trim(), " (", WBUser.UserName.Trim(), ") - ", WBUser.UserGroup.Trim() };
            this.label2.Text = string.Concat(textArray1);
            WBTable table = new WBTable();
            table.OpenTable("wb_company", "Select * From wb_company Where Coy_Code='" + WBData.sCoyCode.Trim() + "'", WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                WBData.sCoyName = table.DT.Rows[0]["coy_name"].ToString();
            }
            table.Dispose();
            this.Text = "WB System,   " + WBData.sCoyName + ", Loc : " + WBData.sLocCode;
            this.buttonFilter.PerformClick();
        }

        public void ShowStatus()
        {
            this.labelStatus1.Text = this.Trans.DT.Rows.Count.ToString() + " " + Resource.Main_034;
        }

        private void sourceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSource source = new FormSource();
            source.ShowDialog();
            source.Dispose();
        }

        private void splitReferenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.checkCompleteTrans("Split"))
            {
                string str = "";
                str = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mes_505, Resource.Title_002);
                }
                else
                {
                    str = "";
                    if (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == "X")
                    {
                        MessageBox.Show(Resource.Mes_519, Resource.Title_002);
                    }
                    else if (!this.Trans.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1'))
                    {
                        if (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() == "Y")
                        {
                            MessageBox.Show(Resource.Mes_526, Resource.Title_007);
                        }
                        else if (this.Trans.BeforeEdit(this.dataGridView1, "SPLIT"))
                        {
                            this.Timbang("SPLIT");
                            this.Trans.UnLock();
                        }
                    }
                }
            }
        }

        public int squared(int i) => 
            i * i;

        private void statusWB_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void stWeightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Timbang("1ST");
        }

        private void subRP1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBLA pffbla = new RepFFBLA();
            pffbla.ShowDialog();
            pffbla.Dispose();
        }

        private void templateSAPLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepMasterDataLog log = new RepMasterDataLog {
                Text = "Template SAP Log Report",
                labelHeader = { Text = "Log of Template SAP" },
                labelMasterData = { Text = "Log for: " },
                flag = "TEMPLATE SAP"
            };
            log.ShowDialog();
            log.Dispose();
        }

        private void templateSAPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTemplateSAP esap = new FormTemplateSAP();
            esap.ShowDialog();
            esap.Dispose();
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void thPrint()
        {
            string[] strArray = new string[2];
            string[] strArray2 = new string[] { "", "" };
            strArray[0] = "ref";
            strArray[1] = "DO_No";
        }

        private void thWeightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkWeightValid("4TH"))
            {
                this.Timbang("4TH");
            }
        }

        private void Timbang(string pMode)
        {
            WBTable table2;
            WBTable table3;
            WBTable table5;
            string wX = "";
            string str2 = "";
            this.nCurrRow = 0;
            if ((WBSetting.checkISCC != "Y") || (((WBSetting.validDateISCC - DateTime.Now).Days + 1) > 0))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_calibration", "SELECT TOP 1 * FROM wb_calibration WHERE " + WBData.CompanyLocation(" AND WBCode = '" + WBData.sWBCode + "' ORDER BY valid_date DESC"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || (table.DT.Rows[0]["lock_weighing"].ToString() != "Y"))
                {
                    table.Dispose();
                    if (this.dataGridView1.Rows.Count > 0)
                    {
                        str2 = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                        this.Trans.ReOpen();
                        this.dataGridView1 = this.Trans.AfterEdit(pMode);
                        string[] aField = new string[] { "uniq" };
                        string[] aFind = new string[] { str2 };
                        this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                    }
                    if ((((pMode != "CANCEL") && (pMode != "2ND")) && (pMode != "COPY")) || (this.dataGridView1.CurrentRow.Cells["Split"].Value.ToString() != "X"))
                    {
                        if (((pMode == "1ST") || (pMode == "MANUAL")) || (this.dataGridView1.Rows.Count > 0))
                        {
                            if (WBSetting.region == "1")
                            {
                                if ((pMode == "2ND") && (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString() == "2X"))
                                {
                                    table2 = new WBTable();
                                    table2.OpenTable("wb_transType", "Select * from wb_transaction_type where " + WBData.CompanyLocation(" and transaction_code = '" + this.dataGridView1.CurrentRow.Cells["transaction_code"].Value.ToString().Trim() + "' "), WBData.conn);
                                    if (table2.DT.Rows.Count <= 0)
                                    {
                                        MessageBox.Show(this.dataGridView1.CurrentRow.Cells["Transaction_code"].Value.ToString().Trim() + " " + Resource.Mes_527);
                                        table2.Dispose();
                                    }
                                    else
                                    {
                                        table2.DR = table2.DT.Rows[0];
                                        if (table2.DR["IO"].ToString() != "I")
                                        {
                                            goto TR_0048;
                                        }
                                        else
                                        {
                                            table3 = new WBTable();
                                            table3.OpenTable("wb_commoditytmp", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_Code = '" + this.dataGridView1.CurrentRow.Cells["comm_code"].Value.ToString().Trim() + "'"), WBData.conn);
                                            if (table3.DT.Rows.Count <= 0)
                                            {
                                                MessageBox.Show(this.dataGridView1.CurrentRow.Cells["comm_code"].Value.ToString().Trim() + " " + Resource.Mes_510);
                                                table2.Dispose();
                                                table3.Dispose();
                                            }
                                            else
                                            {
                                                table3.DR = table3.DT.Rows[0];
                                                if (table3.DR["QCApprove"].ToString() != "Y")
                                                {
                                                    goto TR_0049;
                                                }
                                                else
                                                {
                                                    WBTable table4 = new WBTable();
                                                    table4.OpenTable("tbl_tmpTransQC", "Select * from wb_TransQC_CL where " + WBData.CompanyLocation(" and Ref = '" + this.dataGridView1.CurrentRow.Cells["Ref"].Value.ToString().Trim() + "'"), WBData.conn);
                                                    if (table4.DT.Rows.Count <= 0)
                                                    {
                                                        MessageBox.Show(Resource.Mes_521, Resource.Title_002);
                                                        table3.Dispose();
                                                        table2.Dispose();
                                                        table4.Dispose();
                                                    }
                                                    else
                                                    {
                                                        table4.DR = table4.DT.Rows[0];
                                                        if (table4.DR["Status"].ToString() != "1")
                                                        {
                                                            if (table4.DR["Status"] != null)
                                                            {
                                                                table4.Dispose();
                                                                goto TR_0049;
                                                            }
                                                            else
                                                            {
                                                                MessageBox.Show(Resource.Mes_521, Resource.Title_002);
                                                                table3.Dispose();
                                                                table2.Dispose();
                                                                table4.Dispose();
                                                            }
                                                        }
                                                        else
                                                        {
                                                            MessageBox.Show(Resource.Mes_520, Resource.Title_002);
                                                            table3.Dispose();
                                                            table2.Dispose();
                                                            table4.Dispose();
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    return;
                                }
                                goto TR_0047;
                            }
                        }
                        else
                        {
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_502, Resource.Title_002);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("WB Calibration Certification of this WB has been expired!\nWeighing menu is blocked. Please renew valid date of WB Calibration Certification!", "F A I L E D", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    table.Dispose();
                    return;
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_534, Resource.Title_008, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return;
            }
        TR_0040:
            if ((pMode == "1ST") || (pMode == "MANUAL"))
            {
                FormTransGatepass gatepass = new FormTransGatepass();
                if ((WBSetting.transflow == "2") || (WBSetting.transflow == "3"))
                {
                    gatepass.ShowDialog();
                    if (gatepass.saved)
                    {
                        this.gatepassNumber = gatepass.comboGatepass.Text.Trim();
                        if (WBSetting.Field("Weight4X") != "Y")
                        {
                            wX = "2X";
                            this.tambahRecord = true;
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                gatepass.Dispose();
                FormTransRegis regis = new FormTransRegis();
                if (pMode == "MANUAL")
                {
                    regis.Regis = true;
                    regis.buttonRegis.Enabled = false;
                }
                else
                {
                    regis.buttonRegis.Enabled = true;
                    regis.Regis = (this.dataGridView1.Rows.Count > 0) ? (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() != "") : true;
                }
                regis.ShowDialog();
                if (regis.pSave)
                {
                    wX = regis.WX;
                    this.tambahRecord = regis.Regis;
                    regis.Dispose();
                }
                else
                {
                    return;
                }
            }
            if ((this.dataGridView1.Rows.Count > 0) && (((pMode != "1ST") || (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString() != "")) ? ((pMode != "1ST") && (pMode != "MANUAL")) : true))
            {
                string str3 = "";
                str3 = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
                if (this.dataGridView1.CurrentRow.Cells["zAuto"].Value.ToString() != "Y")
                {
                    if ((((pMode == "VIEW") || (pMode == "COPY")) || (pMode == "1ST")) || !this.Trans.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1'))
                    {
                        if (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString().Trim() != "")
                        {
                            wX = this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString();
                        }
                        string[] aField = new string[] { "uniq" };
                        string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
                        this.nCurrRow = this.Trans.GetRecNo(aField, aFind);
                        str2 = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_501, Resource.Title_002);
                    return;
                }
            }
            if (((((WBSetting.WB_Type == "1") || ((WBSetting.WB_Type == "2") || (WBSetting.WB_Type == "3"))) || (WBSetting.WB_Type == "4")) && (((wX != "") & (((pMode == "1ST") || ((pMode == "2ND") || ((pMode == "3RD") || (pMode == "4TH")))) || (pMode == "COPY"))) && (Convert.ToInt16(WBUser.UserLevel) > 2))) && (WBSetting.CheckZero() != 0))
            {
                MessageBox.Show(Resource.Mes_513);
            }
            else
            {
                if (pMode != "EDIT")
                {
                    if (pMode != "QTY")
                    {
                        if ((pMode == "MANUAL") && (Convert.ToInt16(WBUser.UserLevel) > 1))
                        {
                            WBTable table6 = new WBTable();
                            table6.OpenTable("wb_loc", "select coy, location_code, Ref_no, tokenManual, tokenExpiredDate, maxEntry, currEntry,startRef, uniq from wb_location", WBData.conn);
                            if (table6.DT.Rows[0]["tokenExpiredDate"].ToString() != "")
                            {
                                string str4 = Program.shoot(table6.DT.Rows[0]["tokenExpiredDate"].ToString(), false);
                                if (DateTime.Today.ToString("dd/MM/yyyy") != str4)
                                {
                                    MessageBox.Show(Resource.Mes_525, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    table6.DT.Rows[0]["tokenManual"] = "";
                                    table6.DT.Rows[0]["maxEntry"] = "";
                                    table6.DT.Rows[0]["currEntry"] = "";
                                    table6.DT.Rows[0]["tokenExpiredDate"] = DBNull.Value;
                                    table6.DT.Rows[0]["StartRef"] = "";
                                    table6.Save();
                                    return;
                                }
                            }
                        }
                    }
                    else if ((this.dataGridView1.CurrentRow.Cells["edit_qty"].Value.ToString() == "5") && (Convert.ToInt16(WBUser.UserLevel) > 1))
                    {
                        MessageBox.Show(Resource.Mes_517, Resource.Title_002);
                        return;
                    }
                }
                else if ((this.dataGridView1.CurrentRow.Cells["edit_data"].Value.ToString() == "5") && (Convert.ToInt16(WBUser.UserLevel) > 1))
                {
                    MessageBox.Show(Resource.Mes_516, Resource.Title_002);
                    return;
                }
                if (this.Trans.BeforeEdit(this.dataGridView1, pMode))
                {
                    if (WBSetting.region == "0")
                    {
                        FormTransaction transaction = new FormTransaction {
                            nCurrRow = this.nCurrRow,
                            sUniq = str2,
                            tblTrans = this.Trans,
                            pMode = pMode,
                            dgvTrans = this.dataGridView1,
                            WX = wX,
                            tambahRecord = this.tambahRecord,
                            ticketRpt = this.ticketRpt,
                            ticket2Rpt = this.ticket2Rpt,
                            fRpt = this.fRpt
                        };
                        transaction.ShowDialog();
                        if (transaction.Saved)
                        {
                            this.Trans.ReOpen();
                            this.dataGridView1 = this.Trans.AfterEdit(pMode);
                            string[] aField = new string[] { "Ref" };
                            string[] aFind = new string[] { transaction.textRefNo.Text };
                            this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                        }
                        this.Trans.UnLock();
                        transaction.Dispose();
                    }
                    else if (WBSetting.region == "1")
                    {
                        FormTransactionAfrica africa = new FormTransactionAfrica();
                        if ((WBSetting.transflow == "2") || (WBSetting.transflow == "3"))
                        {
                            africa.gatepassNumber = this.gatepassNumber;
                        }
                        africa.nCurrRow = this.nCurrRow;
                        africa.sUniq = str2;
                        africa.tblTrans = this.Trans;
                        africa.pMode = pMode;
                        africa.dgvTrans = this.dataGridView1;
                        africa.WX = wX;
                        africa.tambahRecord = this.tambahRecord;
                        africa.ticketRpt = this.ticketRpt;
                        if (WBSetting.locType == "1")
                        {
                            africa.ticketGradingRpt = this.ticketGrading;
                        }
                        africa.fRpt = this.fRpt;
                        africa.ShowDialog();
                        if (africa.Saved)
                        {
                            this.Trans.ReOpen();
                            this.dataGridView1 = this.Trans.AfterEdit(pMode);
                            string[] aField = new string[] { "Ref" };
                            string[] aFind = new string[] { africa.textRefNo.Text };
                            this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                        }
                        this.Trans.UnLock();
                        africa.Dispose();
                    }
                    Cursor.Current = Cursors.Default;
                }
            }
            return;
        TR_0041:
            table5.Dispose();
            goto TR_0040;
        TR_0047:
            if (((pMode != "2ND") || (this.dataGridView1.CurrentRow.Cells["WX"].Value.ToString() != "2X")) || ((Convert.ToInt16(WBSetting.transflow) < 2) || (WBSetting.Field("LoadUnload") != "Y")))
            {
                goto TR_0040;
            }
            else
            {
                table5 = new WBTable();
                table5.OpenTable("wb_gatepass", "select * from wb_gatepass where gatepass_number = '" + this.dataGridView1.CurrentRow.Cells["gatepass_number"].Value.ToString().Trim() + "'", WBData.conn);
                if (table5.DT.Rows.Count <= 0)
                {
                    goto TR_0041;
                }
                else
                {
                    table5.DR = table5.DT.Rows[0];
                    if (table5.DR["loaddate"] != null)
                    {
                        if (table5.DR["loaddate"].ToString().Trim() != "")
                        {
                            goto TR_0041;
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_528, Resource.Title_002);
                            table5.Dispose();
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_528, Resource.Title_002);
                        table5.Dispose();
                    }
                }
            }
            return;
        TR_0048:
            table2.Dispose();
            goto TR_0047;
        TR_0049:
            table3.Dispose();
            goto TR_0048;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Console.WriteLine("!!!");
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
        }

        private void timerSAPUpd_Tick(object sender, EventArgs e)
        {
            this.lblNow.Text = DateTime.Now.ToString("HH:mm");
            if (WBSetting.SAPsch == "Y")
            {
                if (Convert.ToDateTime(this.lblNow.Text).ToString("HH:mm") != Convert.ToDateTime(WBSetting.SAPTime).ToString("HH:mm"))
                {
                    this.updSuccess = true;
                }
                else if (!this.isUpload)
                {
                    this.backgroundWorkerSAP.RunWorkerAsync();
                    this.updSuccess = false;
                }
            }
            if (Program.StrToDouble(WBSetting.SAPInterval, 3) > 0.0)
            {
                int index = 0;
                while (true)
                {
                    if (index >= this.sapJamKirim.Length)
                    {
                        break;
                    }
                    DateTime time = Convert.ToDateTime(this.sapJamKirim[index]);
                    if (Convert.ToDateTime(this.lblNow.Text).ToString("HH:mm") != time.ToString("HH:mm"))
                    {
                        this.updSuccess = true;
                    }
                    else if (!this.isUpload)
                    {
                        this.backgroundWorkerSAP.RunWorkerAsync();
                        this.updSuccess = false;
                    }
                    index++;
                }
            }
        }

        private void timerTokenEmail_Tick(object sender, EventArgs e)
        {
            string startTime = WBSetting.startTime;
            TimeSpan span = Convert.ToDateTime(DateTime.Now.ToString("HH:mm")).Subtract(Convert.ToDateTime(Convert.ToDateTime(WBSetting.startTime).ToString("HH:mm")));
            if (((span.Hours <= 2) && (span.Hours >= 0)) && !this.isSendEmail)
            {
                this.backgroundWorkerEmail.RunWorkerAsync();
            }
        }

        private void tokenToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            FormTransDO_View view = new FormTransDO_View {
                textDO = { Text = this.doviewDO_No },
                textRefNo = { Text = this.doviewRefNo },
                textRelation = { Text = this.doviewRelation },
                textCommodity = { Text = this.doviewComm },
                textPI_No = { Text = this.doviewPI_No },
                doviewFirsttime = this.doviewFirsttime
            };
            view.ShowDialog();
            this.doviewDO_No = view.textDO.Text;
            this.doviewRefNo = view.textRefNo.Text;
            this.doviewRelation = view.textRelation.Text;
            this.doviewComm = view.textCommodity.Text;
            this.doviewPI_No = view.textPI_No.Text;
            this.doviewFirsttime = view.doviewFirsttime;
            if (view.fMode == "FIND")
            {
                try
                {
                    string[] aField = new string[] { "Ref" };
                    string[] aFind = new string[] { view.fNoRef };
                    this.Trans.SetCursor(this.dataGridView1, this.Trans.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                catch
                {
                }
            }
            view.Dispose();
        }

        private void toolStripMenuItem11_Click(object sender, EventArgs e)
        {
            this.Timbang("COPY");
        }

        private void toolStripMenuItem12_Click(object sender, EventArgs e)
        {
            this.Timbang("MANUAL");
        }

        private void toolStripMenuItem12_Click_1(object sender, EventArgs e)
        {
            RepFFBGrading grading = new RepFFBGrading {
                Text = "FFB Porla Report",
                label5 = { Text = "FFB Porla Report" },
                tableDeduction = "wb_transactionPorla"
            };
            grading.ShowDialog();
            grading.Dispose();
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            this.Timbang("VIEW");
        }

        private void toolStripMenuRekapHarian_Click(object sender, EventArgs e)
        {
            RepFFBDaily daily = new RepFFBDaily();
            daily.ShowDialog();
            daily.Dispose();
        }

        private void transactionLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepTransLog log = new RepTransLog();
            log.ShowDialog();
            log.Dispose();
        }

        private void transactionLogToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            RepTransLog_New new2 = new RepTransLog_New();
            new2.ShowDialog();
            new2.Dispose();
        }

        private void transactionTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTransType type = new FormTransType();
            type.ShowDialog();
            type.Dispose();
        }

        private void translate()
        {
            this.truckArrivalToolStripMenuItem.Text = Resource.Menu_001;
            this.gatepassToolStripMenuItem.Text = Resource.Menu_002;
            this.stWeightToolStripMenuItem.Text = Resource.Menu_003;
            this.ndWeightToolStripMenuItem.Text = Resource.Menu_004;
            this.splitReferenceToolStripMenuItem.Text = Resource.Menu_005;
            this.mergeDOToolStripMenuItem.Text = Resource.Menu_006;
            this.divideBlockToolStripMenuItem.Text = Resource.Menu_007;
            this.toolStripMenuItem11.Text = Resource.Menu_008;
            this.ManualEntryMenuItem.Text = Resource.Menu_009;
            this.qcStripMenuItem.Text = Resource.Menu_010;
            this.DLAdoptMenuItem.Text = Resource.Menu_011;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_012;
            this.editQuantityToolStripMenuItem.Text = Resource.Menu_013;
            this.cancelRecordToolStripMenuItem.Text = Resource.Menu_014;
            this.toolStripMenuItem9.Text = Resource.Menu_015;
            this.printToolStripMenuItem.Text = Resource.Menu_016;
            this.toolStripMenuItem10.Text = Resource.Menu_017;
            this.repairChecksumToolStripMenuItem.Text = Resource.Menu_018;
            this.repairAllChecksumToolStripMenuItem.Text = Resource.Menu_019;
            this.DOToolStripMenuItem.Text = Resource.Menu_020;
            this.commodityToolStripMenuItem.Text = Resource.Menu_021;
            this.relationToolStripMenuItem.Text = Resource.Menu_022;
            this.truckToolStripMenuItem.Text = Resource.Menu_023;
            this.driverToolStripMenuItem.Text = Resource.Menu_024;
            this.transpoterToolStripMenuItem.Text = Resource.Menu_025;
            this.coytoolStripMenuItem.Text = Resource.Menu_026;
            this.locationToolStripMenuItem.Text = Resource.Menu_027;
            this.estateToolStripMenuItem.Text = Resource.Menu_028;
            this.divisionToolStripMenuItemPOM.Text = Resource.Menu_029;
            this.blockStripMenuItemPOM.Text = Resource.Menu_030;
            this.aBWBlockToolStripMenuItemPOM.Text = Resource.Menu_031;
            this.sourceToolStripMenuItem.Text = Resource.Menu_032;
            this.loadUloadToolStripMenuItem.Text = Resource.Menu_033;
            this.UploadTypeToolStripMenuItem.Text = Resource.Menu_034;
            this.storageToolStripMenuItem.Text = Resource.Menu_035;
            this.gradingToolStripMenuItemPOM.Text = Resource.Menu_036;
            this.qualityToolStripMenuItem.Text = Resource.Menu_037;
            this.qCItemToolStripMenuItem.Text = Resource.Menu_038;
            this.compositToolStripMenuItem.Text = Resource.Menu_039;
            this.tankerToolStripMenuItem.Text = Resource.Menu_040;
            this.transactionTypeToolStripMenuItem.Text = Resource.Menu_041;
            this.templateSAPToolStripMenuItem.Text = Resource.Menu_042;
            this.formulaRendemenToolStripMenuItemPOM.Text = Resource.Menu_043;
            this.mapCommTrxTypeToolStripMenuItem.Text = Resource.Menu_044;
            this.databaseConnectionToolStripMenuItem.Text = Resource.Menu_045;
            this.weighBridgeSettingToolStripMenuItem.Text = Resource.Menu_046;
            this.userListToolStripMenuItem.Text = Resource.Menu_047;
            this.userGroupToolStripMenuItem.Text = Resource.Menu_048;
            this.copyToNewCompanyToolStripMenuItem.Text = Resource.Menu_049;
            this.compareDatabaseToolStripMenuItem.Text = Resource.Menu_050;
            this.FFBReportToolStripMenuItemPOM.Text = Resource.Menu_051;
            this.listOfWeighningToolStripMenuItem1.Text = Resource.Menu_052;
            this.copraReportToolStripMenuItem.Text = Resource.Menu_053;
            this.dailyReceiptSupplierToolStripMenuItem.Text = Resource.Menu_054;
            this.reportOutstandingDOToolStripMenuItem.Text = Resource.Menu_055;
            this.receivingEstimationFrom3rdPartyToolStripMenuItem.Text = Resource.Menu_056;
            this.doDetailToolStripMenuItem.Text = Resource.Menu_057;
            this.nonContractTransactionToolStripMenuItem.Text = Resource.Menu_058;
            this.qCReportToolStripMenuItem.Text = Resource.Menu_059;
            this.vendorSummaryToolStripMenuItem.Text = Resource.Menu_060;
            this.transactionLogToolStripMenuItem.Text = Resource.Menu_061;
            this.masterDataLogToolStripMenuItem.Text = Resource.Menu_062;
            this.Text = Resource.Main_001;
            this.WeighingMenuItem.Text = Resource.Main_002;
            this.masterDataToolStripMenuItem1.Text = Resource.Main_003;
            this.configurationToolStripMenuItem.Text = Resource.Main_004;
            this.ReportToolStripMenuItem.Text = Resource.Main_005;
            this.uploadSAPToolStripMenuItem.Text = Resource.Main_006;
            this.logOffToolStripMenuItem.Text = Resource.Main_007;
            this.exitToolStripMenuItem.Text = Resource.Main_008;
            this.changeProfileToolStripMenuItem.Text = Resource.Main_104;
            this.label1.Text = Resource.Main_010;
            this.buttonFind.Text = Resource.Main_026;
            this.buttonFilter.Text = Resource.Main_027;
            this.label4.Text = Resource.Main_028;
            this.label3.Text = Resource.Main_029;
            this.checkBox1.Text = Resource.Main_030;
            this.checkShowCheckSum.Text = Resource.Main_031;
            this.checkPartial.Text = Resource.Main_032;
            this.checkWBCode.Text = Resource.Main_033;
        }

        private void TransToLog(string pUniq, string result)
        {
            WBTable table = new WBTable();
            if (pUniq.Trim() != "")
            {
                table.OpenTable("wb_transaction", "Select * From wb_transaction where Uniq=" + pUniq.Trim(), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_trans_log", "Select * From wb_trans_log where 1=2", WBData.conn);
                    table2.DR = table2.DT.NewRow();
                    foreach (DataColumn column in table2.DT.Columns)
                    {
                        try
                        {
                            if (((column.ColumnName.ToUpper() != "UNIQ") && (column.ColumnName.ToUpper() != "LOG_DATE".ToUpper())) && (column.ColumnName.ToUpper() != "LOG_TIME".ToUpper()))
                            {
                                table2.DR[column.ColumnName] = table.DT.Rows[0][column.ColumnName];
                            }
                        }
                        catch
                        {
                        }
                    }
                    table2.DR["log_Date"] = DateTime.Now.ToString("dd/MM/yyyy");
                    table2.DR["log_time"] = DateTime.Now.ToString("HH:mm");
                    table2.DR["Printed_By"] = WBUser.UserID.Trim();
                    table2.DR["ChangeReason"] = result;
                    table2.DR["Edit_By"] = "";
                    table2.DR["Printed_Date"] = DateTime.Now;
                    table2.DT.Rows.Add(table2.DR);
                    table2.Save();
                    table2.Dispose();
                }
            }
            else
            {
                return;
            }
            table.Dispose();
        }

        private void truckArrivalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MN_TRUCKARRIVAL", "V"))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormTruckArrival arrival = new FormTruckArrival();
                arrival.ShowDialog();
                arrival.Dispose();
            }
        }

        private void uploadSAP()
        {
            this.isUpload = true;
            string str = "1";
            string str2 = "MM";
            if (WBSetting.zwb == "Y")
            {
                str2 = "ZWB";
                str = "1";
            }
            FormUploadZWB dzwb = new FormUploadZWB {
                module = str2,
                type = str
            };
            if (WBSetting.zwb == "Y")
            {
                dzwb.sapDest = "ZWB";
            }
            dzwb.auto = 'Y';
            dzwb.initTransFlag();
            dzwb.initTable();
            dzwb.btnUpload();
            this.autoUpd = false;
            this.updSuccess = true;
            this.isUpload = false;
        }

        private void uploadSAPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormUpload upload = new FormUpload();
            upload.ShowDialog();
            upload.Dispose();
        }

        private void UploadTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormUploadType type = new FormUploadType {
                Text = "List of Upload Type"
            };
            type.ShowDialog();
            type.Dispose();
        }

        private void userGroupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FormUserGroup().ShowDialog();
        }

        private void userListLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepMasterDataLog log = new RepMasterDataLog {
                Text = "User List Log Report",
                labelHeader = { Text = "Log of User List" },
                labelMasterData = { Text = "Log for: " },
                flag = "USER LIST"
            };
            log.ShowDialog();
            log.Dispose();
        }

        private void userListReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new RepUserList().generateRep();
        }

        private void userListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FormUser().ShowDialog();
        }

        private void userLoginLogoutLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepLoginLogout logout = new RepLoginLogout();
            logout.ShowDialog();
            logout.Dispose();
        }

        private void vendorSummaryTBSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepFFBVendorSummary summary = new RepFFBVendorSummary();
            summary.ShowDialog();
            summary.Dispose();
        }

        private void vendorSummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepVendorSummary summary = new RepVendorSummary();
            summary.ShowDialog();
            summary.Dispose();
        }

        private void weighbridgeControlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!(WBUser.CheckTrustee("MD_CONTROL", "E") || WBUser.CheckTrustee("MD_CONTROL", "V")))
            {
                WBUser.ShowErr();
            }
            else
            {
                FormDeepSetting setting = new FormDeepSetting();
                setting.ShowDialog();
                setting.Dispose();
            }
        }

        private void weighBridgeSettingToolStripMenuItem_CheckStateChanged(object sender, EventArgs e)
        {
        }

        private void weighBridgeSettingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSetting setting = new FormSetting();
            setting.ShowDialog();
            WBSetting.ReOpen();
            int num = 0;
            if (Program.StrToDouble(WBSetting.SAPInterval, 3) > 0.0)
            {
                num = Convert.ToInt16((double) (24.0 / Program.StrToDouble(WBSetting.SAPInterval, 3)));
                string[] strArray = new string[num];
                int index = 0;
                while (true)
                {
                    if (index >= num)
                    {
                        this.sapJamKirim = strArray;
                        this.timerSAPUpd.Enabled = true;
                        this.timerSAPUpd.Interval = 0xea60;
                        break;
                    }
                    DateTime time = Convert.ToDateTime(WBSetting.startTime).AddHours(index * Program.StrToDouble(WBSetting.SAPInterval, 3));
                    strArray[index] = Convert.ToString(time);
                    index++;
                }
            }
            if (setting.saved)
            {
                WBSetting.ReOpen();
                this.f_load();
                if (setting.reloadTicket)
                {
                    FormMessage message = new FormMessage {
                        label1 = { Text = "Preparing . . . . . . ." }
                    };
                    this.ticketRpt.Load(WBSetting.ticket);
                    message.Show();
                    this.ticketRpt = Program.rptLogon(this.ticketRpt);
                    message.label1.Text = "Application is Ready";
                    message.Close();
                    message.Dispose();
                }
            }
        }

        private void WeighingMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void WeighingMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            this._weighMenuActivate();
        }
    }
}

