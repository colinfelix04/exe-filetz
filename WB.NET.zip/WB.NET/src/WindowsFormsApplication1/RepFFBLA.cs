﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;

    public class RepFFBLA : Form
    {
        private string sqlTrans = "";
        private string relation_code = "";
        private int countGrad = 0;
        private int no = 0;
        private int idxGrad = 0;
        private int jlhKolomA = 0;
        private double bruto = 0.0;
        private double tarra = 0.0;
        private double netto = 0.0;
        private double received = 0.0;
        private double deduc = 0.0;
        private double RSDHI = 0.0;
        private double PSUPP = 0.0;
        private double NPSUPP = 0.0;
        private double eNetto = 0.0;
        private double bunch = 0.0;
        private double reject = 0.0;
        private double tbruto = 0.0;
        private double ttarra = 0.0;
        private double tnetto = 0.0;
        private double treceived = 0.0;
        private double tdeduc = 0.0;
        private double teNetto = 0.0;
        private double tbunch = 0.0;
        private double treject = 0.0;
        private double[] vDeduc;
        private double[] tvDeduc;
        private double gunny;
        private double tgunny;
        private int count = 0;
        private string[] cbChecked = new string[5];
        private IContainer components = null;
        public Label label5;
        public DateTimePicker monthCalendar1;
        public Label label1;
        public Button button2;
        public Button button1;
        public Label labelRecNo;
        public Label labelProcess;
        private CheckBox checkProcess;
        private CheckBox cbGunny;
        private CheckBox checkBoxRejectKG;
        public Label label2;
        private ComboBox comboCom;
        private GroupBox groupFType;
        private CheckBox checkR;
        private CheckBox checkK;
        private CheckBox checkS;
        private CheckBox checkB;
        private CheckBox checkM;
        public GroupBox grType;
        private RadioButton rboAll;
        public RadioButton rboGI;
        public RadioButton rboGR;

        public RepFFBLA()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.comboCom.Text.Trim() == "")
            {
                MessageBox.Show("Please choose commodity!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.comboCom.Focus();
            }
            else
            {
                this.count = 0;
                int index = 0;
                while (true)
                {
                    if (index >= this.cbChecked.Count<string>())
                    {
                        foreach (Control control in this.groupFType.Controls)
                        {
                            CheckBox box = control as CheckBox;
                            if ((box != null) && box.Checked)
                            {
                                this.cbChecked[this.count] = box.Text;
                                this.count++;
                            }
                        }
                        this.countGrad = 0;
                        this.no = 0;
                        this.idxGrad = 0;
                        this.jlhKolomA = 0;
                        this.bruto = 0.0;
                        this.tarra = 0.0;
                        this.netto = 0.0;
                        this.received = 0.0;
                        this.deduc = 0.0;
                        this.RSDHI = 0.0;
                        this.PSUPP = 0.0;
                        this.NPSUPP = 0.0;
                        this.eNetto = 0.0;
                        this.bunch = 0.0;
                        this.reject = 0.0;
                        this.tbruto = 0.0;
                        this.ttarra = 0.0;
                        this.tnetto = 0.0;
                        this.treceived = 0.0;
                        this.tdeduc = 0.0;
                        this.teNetto = 0.0;
                        this.tbunch = 0.0;
                        this.treject = 0.0;
                        this.gunny = 0.0;
                        this.tgunny = 0.0;
                        this.labelProcess.Visible = true;
                        this.labelRecNo.Visible = true;
                        WBTable table = new WBTable();
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_comm_grading", "select * from wb_commodity_grading where " + WBData.CompanyLocation(" AND comm_code = '" + this.comboCom.Text + "'"), WBData.conn);
                        this.countGrad = table2.DT.Rows.Count;
                        this.vDeduc = new double[this.countGrad];
                        this.tvDeduc = new double[this.countGrad];
                        WBTable table3 = new WBTable();
                        if (!this.checkProcess.Checked)
                        {
                            this.sqlTrans = "Select * from vw_trans where " + WBData.CompanyLocation(" and report_date = '" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00' ");
                        }
                        else
                        {
                            string[] textArray1 = new string[] { " and (report_date = '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), " 00:00:00' or ref_Date = '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), " 00:00:00') " };
                            this.sqlTrans = "Select * from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray1));
                        }
                        this.sqlTrans = this.sqlTrans + " and Comm_Code = '" + this.comboCom.Text + "'";
                        this.sqlTrans = this.sqlTrans + " and (deleted is null or deleted = 'N' or deleted = '') ";
                        if (this.rboGI.Checked)
                        {
                            this.sqlTrans = this.sqlTrans + " and IO = 'O' ";
                        }
                        else if (this.rboGR.Checked)
                        {
                            this.sqlTrans = this.sqlTrans + " and IO = 'I' ";
                        }
                        if (this.count <= 0)
                        {
                            this.sqlTrans = this.sqlTrans + " and (Fruits_type = '' or Fruits_type is null) ";
                        }
                        else
                        {
                            int num2 = 0;
                            while (true)
                            {
                                if (num2 >= this.cbChecked.Count<string>())
                                {
                                    this.sqlTrans = this.sqlTrans + " ) ";
                                    break;
                                }
                                if (this.cbChecked[num2] != "")
                                {
                                    this.sqlTrans = (num2 != 0) ? (this.sqlTrans + " or Fruits_type = '" + this.cbChecked[num2] + "' ") : (this.sqlTrans + " and ( Fruits_type = '" + this.cbChecked[num2] + "' ");
                                }
                                num2++;
                            }
                        }
                        this.sqlTrans = this.sqlTrans + " order by relation_Code , ref ";
                        table3.OpenTable("vw_trans", this.sqlTrans, WBData.conn);
                        if (table3.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                        else
                        {
                            this.labelRecNo.Text = "0/" + table3.DT.Rows.Count.ToString();
                            this.labelRecNo.Refresh();
                            this.labelProcess.Refresh();
                            HTML html = new HTML();
                            html.File = html.File + @"\" + WBUser.UserID + "_FFBLA.htm";
                            html.Title = "List of Weighing";
                            html.Open();
                            html.Write(html.Style());
                            html.Write("<br><font size=5><b>LA REPORT</b></font><br>");
                            string[] textArray2 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                            html.Write(string.Concat(textArray2));
                            string[] textArray3 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                            html.Write(string.Concat(textArray3));
                            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                            {
                                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                            }
                            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                            {
                                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                            }
                            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                            {
                                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                            }
                            html.Write("<br><br>");
                            string str = Program.getFieldValue("wb_commodity", "Comm_Name", "comm_code", this.comboCom.Text);
                            html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                            html.Write("<tr class=bd>");
                            html.Write("<td>Commodity</td>");
                            string[] textArray4 = new string[] { "<td>: <b>", this.comboCom.Text.Trim(), " - ", str, "</b></td>" };
                            html.Write(string.Concat(textArray4));
                            html.Write("</tr>");
                            html.Write("<tr class=bd>");
                            html.Write("<td>Selected Date</td>");
                            html.Write("<td>: <b>" + this.monthCalendar1.Value.ToShortDateString() + "</b></td>");
                            html.Write("</tr>");
                            html.Write("<tr class=bd>");
                            html.Write("<td>Report Date</td>");
                            html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                            html.Write("</tr>");
                            html.Write("</table>");
                            html.Write("<br/><br/><br/>");
                            html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                            html.Write("<tr class='bd'>");
                            html.Write("<td nowrap rowspan='2' align=center><b>No.</b></td>");
                            this.jlhKolomA++;
                            html.Write("<td nowrap rowspan='2' align=center><b>Relation</b></td>");
                            this.jlhKolomA++;
                            html.Write("<td nowrap rowspan='2' align=center><b>RV.CPO</b></td>");
                            this.jlhKolomA++;
                            html.Write("<td nowrap rowspan='2' align=center><b>Transporter</b></td>");
                            this.jlhKolomA++;
                            html.Write("<td nowrap rowspan='2' align=center><b>Truck No</b></td>");
                            this.jlhKolomA++;
                            html.Write("<td nowrap rowspan='2' align=center><b>Date</b></td>");
                            this.jlhKolomA++;
                            html.Write("<td nowrap rowspan='2' align=center><b>Del.Note</b></td>");
                            this.jlhKolomA++;
                            html.Write("<td nowrap rowspan='2' align=center><b>F</b></td>");
                            this.jlhKolomA++;
                            html.Write("<td  rowspan='2' align=center><b>Tot. Bunch</b></td>");
                            html.Write("<td nowrap rowspan='2' align=center><b>AVG</b></td>");
                            html.Write("<td  rowspan='2' align=center><b>Est. Nett</b></td>");
                            html.Write("<td nowrap rowspan='2' align=center><b>Ref</b></td>");
                            html.Write("<td nowrap rowspan='2' align=center><b>Gross</b></td>");
                            html.Write("<td nowrap rowspan='2' align=center><b>Tarra</b></td>");
                            html.Write("<td nowrap rowspan='2' align=center><b>Received</b></td>");
                            html.Write("<td nowrap rowspan='2' align=center><b>PSupp</b></td>");
                            html.Write("<td nowrap rowspan='2' align=center><b>RSDHI</b></td>");
                            if (table2.DT.Rows.Count > 0)
                            {
                                int num3 = this.countGrad + (this.cbGunny.Checked ? 1 : 0);
                                html.Write("<td nowrap colspan='" + num3.ToString() + "' align=center><b>Deduction</b></td>");
                            }
                            html.Write("<td nowrap rowspan='2' align=center><b>Netto</b></td>");
                            html.Write("<td  rowspan='2' align=center><b>Netto/ Supplier</b></td>");
                            if (this.checkBoxRejectKG.Checked)
                            {
                                html.Write("<td  rowspan='2' align=center><b>TBS Reject (KG)</b></td>");
                            }
                            else
                            {
                                html.Write("<td  rowspan='2' align=center><b>TBS Reject (Bunch)</b></td>");
                            }
                            html.Write("<td  rowspan='2' align=center><b>Reason</b></td>");
                            html.Write("<td nowrap rowspan='2' align=center><b>Remark Ticket</b></td>");
                            html.Write("</tr>");
                            html.Write("<tr class='bd'>");
                            this.idxGrad = 0;
                            foreach (DataRow row in table2.DT.Rows)
                            {
                                html.Write("<td align=center><b>" + row["Code"] + "</b></td>");
                                this.tvDeduc[this.idxGrad] = 0.0;
                                this.idxGrad++;
                            }
                            if (this.cbGunny.Checked)
                            {
                                html.Write("<td align=center><b>Gunny</b></td>");
                            }
                            html.Write("</tr>");
                            this.no = 0;
                            this.relation_code = "";
                            this.PSUPP = 0.0;
                            this.NPSUPP = 0.0;
                            foreach (DataRow row2 in table3.DT.Rows)
                            {
                                this.no++;
                                this.labelRecNo.Text = this.no.ToString() + "/" + table3.DT.Rows.Count.ToString();
                                this.labelRecNo.Refresh();
                                html.Write("<tr class='bd'>");
                                html.Write("<td nowrap >" + this.no.ToString() + "</td>");
                                html.Write("<td nowrap>" + html.strq(row2["Relation_Code"].ToString()) + "</td>");
                                if (this.relation_code != row2["Relation_Code"].ToString())
                                {
                                    this.PSUPP = 0.0;
                                    this.NPSUPP = 0.0;
                                    this.relation_code = row2["Relation_Code"].ToString();
                                    this.RSDHI = this.cekSDHI(this.relation_code);
                                }
                                html.Write("<td nowrap>" + html.strq($"{Program.StrToDouble(row2["Rend_CPO"].ToString(), 2):N2}") + "</td>");
                                html.Write("<td nowrap>" + html.strq(row2["Transporter_Code"].ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row2["Truck_Number"].ToString()) + "</td>");
                                if (row2["Report_date"].ToString() != "")
                                {
                                    html.Write("<td nowrap>" + html.strq(row2["Report_date"].ToString().Substring(0, 10)) + "</td>");
                                }
                                else
                                {
                                    html.Write("<td nowrap>" + html.strq(row2["Ref_date"].ToString().Substring(0, 10)) + "</td>");
                                }
                                html.Write("<td nowrap>" + html.strq(row2["Delivery_note"].ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row2["Fruits_Type"].ToString()) + "</td>");
                                this.bunch = Program.StrToDouble(row2["TotalBunch"].ToString(), 0);
                                html.Write("<td nowrap align=right>" + html.strq($"{this.bunch:N0}") + "</td>");
                                html.Write("<td nowrap align=right>" + html.strq($"{Program.StrToDouble(row2["Average"].ToString(), 2):N2}") + "</td>");
                                this.eNetto = Program.StrToDouble(row2["Estate_qty"].ToString(), 0);
                                html.Write("<td nowrap align=right>" + html.strq($"{this.eNetto:N0}") + "</td>");
                                html.Write("<td nowrap>" + html.strq(row2["Ref"].ToString()) + "</td>");
                                this.bruto = Program.StrToDouble(row2["Bruto"].ToString(), 0);
                                this.tarra = Program.StrToDouble(row2["Tarra"].ToString(), 0);
                                this.netto = Program.StrToDouble(row2["Netto"].ToString(), 0);
                                this.reject = this.checkBoxRejectKG.Checked ? (Program.StrToDouble(row2["TBS_Reject"].ToString(), 2) * Program.StrToDouble(row2["Average"].ToString(), 2)) : Program.StrToDouble(row2["TBS_Reject"].ToString(), 0);
                                this.treject += this.reject;
                                this.received = this.bruto - this.tarra;
                                this.PSUPP += this.received;
                                this.NPSUPP += this.netto;
                                this.idxGrad = 0;
                                foreach (DataRow row3 in table2.DT.Rows)
                                {
                                    string[] textArray5 = new string[] { " and ref = '", row2["Ref"].ToString(), "' and code = '", row3["Code"].ToString(), "'" };
                                    table.OpenTable("wb_transactionD", "Select * from wb_transactionD where " + WBData.CompanyLocation(string.Concat(textArray5)), WBData.conn);
                                    if (table.DT.Rows.Count <= 0)
                                    {
                                        this.vDeduc[this.idxGrad] = 0.0;
                                    }
                                    else
                                    {
                                        table.DR = table.DT.Rows[0];
                                        this.vDeduc[this.idxGrad] = Program.StrToDouble(table.DR["kgDeduc"].ToString(), 0);
                                    }
                                    this.deduc += this.vDeduc[this.idxGrad];
                                    this.idxGrad++;
                                }
                                if (this.cbGunny.Checked)
                                {
                                    this.gunny = Program.StrToDouble(row2["TotalBunch"].ToString(), 2) * Program.StrToDouble(row2["WeightPerUnitName"].ToString(), 2);
                                }
                                html.Write("<td nowrap align=right>" + html.strq($"{this.bruto:N0}") + "</td>");
                                html.Write("<td nowrap align=right>" + html.strq($"{this.tarra:N0}") + "</td>");
                                html.Write("<td nowrap align=right>" + html.strq($"{this.received:N0}") + "</td>");
                                html.Write("<td nowrap align=right>" + html.strq($"{this.PSUPP:N0}") + "</td>");
                                html.Write("<td nowrap align=right>" + html.strq($"{this.RSDHI:N0}") + "</td>");
                                int num4 = 0;
                                while (true)
                                {
                                    if (num4 >= this.idxGrad)
                                    {
                                        if (this.cbGunny.Checked)
                                        {
                                            html.Write("<td nowrap align=right>" + html.strq($"{this.gunny:N0}") + "</td>");
                                        }
                                        html.Write("<td nowrap align=right>" + html.strq($"{this.netto:N0}") + "</td>");
                                        html.Write("<td nowrap align=right>" + html.strq($"{this.NPSUPP:N0}") + "</td>");
                                        html.Write("<td nowrap align=right>" + html.strq($"{this.reject:N0}") + "</td>");
                                        html.Write("<td nowrap >" + html.strq(row2["Reason"].ToString()) + "</td>");
                                        html.Write("<td nowrap align=right>" + html.strq(row2["Remark_Ticket"].ToString()) + "</td>");
                                        html.Write("</tr>");
                                        if (row2["Report_date"].ToString() != "")
                                        {
                                            this.tbruto += this.bruto;
                                            this.ttarra += this.tarra;
                                            this.tnetto += this.netto;
                                            this.teNetto += this.eNetto;
                                            this.treceived += this.received;
                                            this.tbunch += this.bunch;
                                            int num5 = 0;
                                            while (true)
                                            {
                                                if (num5 >= this.idxGrad)
                                                {
                                                    if (this.cbGunny.Checked)
                                                    {
                                                        this.tgunny += this.gunny;
                                                    }
                                                    break;
                                                }
                                                this.tvDeduc[num5] += this.vDeduc[num5];
                                                num5++;
                                            }
                                        }
                                        break;
                                    }
                                    html.Write("<td nowrap align=right>" + html.strq($"{this.vDeduc[num4]:N0}") + "</td>");
                                    num4++;
                                }
                            }
                            html.Write("<tr class='bd'>");
                            html.Write("<td nowrap colspan='" + this.jlhKolomA + "' align=center><b>Total</b></td>");
                            html.Write("<td nowrap align=right><b>" + html.strq($"{this.tbunch:N0}") + "</b></td>");
                            html.Write("<td nowrap align=center><b>&nbsp</b></td>");
                            html.Write("<td nowrap align=right><b>" + html.strq($"{this.teNetto:N0}") + "</b></td>");
                            html.Write("<td nowrap align=center><b>&nbsp</b></td>");
                            html.Write("<td nowrap align=right><b>" + html.strq($"{this.tbruto:N0}") + "</b></td>");
                            html.Write("<td nowrap align=right><b>" + html.strq($"{this.ttarra:N0}") + "</b></td>");
                            html.Write("<td nowrap align=right><b>" + html.strq($"{this.treceived:N0}") + "</b></td>");
                            html.Write("<td nowrap colspan='2' align=center><b>&nbsp</b></td>");
                            int num6 = 0;
                            while (true)
                            {
                                if (num6 >= this.idxGrad)
                                {
                                    if (this.cbGunny.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + html.strq($"{this.tgunny:N0}") + "</b></td>");
                                    }
                                    html.Write("<td nowrap align=right><b>" + html.strq($"{this.tnetto:N0}") + "</b></td>");
                                    html.Write("<td nowrap align=center><b>&nbsp</b></td>");
                                    html.Write("<td nowrap align=right><b>" + html.strq($"{this.treject:N0}") + "</b></td>");
                                    html.Write("<td nowrap colspan='2' align=center><b>&nbsp</b></td>");
                                    html.Write("</tr>");
                                    html.Write("</table>");
                                    html.Write("<br><br><br>");
                                    html.writeSign();
                                    html.Close();
                                    ViewReport report = new ViewReport {
                                        webBrowser1 = { Url = new Uri("file:///" + html.File) }
                                    };
                                    report.ShowDialog();
                                    html.Dispose();
                                    report.Dispose();
                                    this.labelProcess.Visible = false;
                                    this.labelRecNo.Visible = false;
                                    break;
                                }
                                html.Write("<td nowrap align=right><b>" + html.strq($"{this.tvDeduc[num6]:N0}") + "</b></td>");
                                num6++;
                            }
                        }
                        break;
                    }
                    this.cbChecked[index] = "";
                    index++;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private double cekSDHI(string rcode)
        {
            double num;
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { " and (report_date >= '", Convert.ToDateTime(this.monthCalendar1.Value.ToString()).Year.ToString(), "-", Convert.ToDateTime(this.monthCalendar1.Value.ToString()).Month.ToString(), "-01 00:00:00' and report_date <= '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), " 00:00:00')" };
            string sqltext = ((("Select sum(Bruto - Tarra) as Rec from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray1))) + " and relation_code = '" + rcode + "'") + " and (deleted is null or deleted = 'N' or deleted = '') " + " and (report_date is not null) ") + " and comm_code = '" + this.comboCom.Text + "'";
            if (this.rboGI.Checked)
            {
                sqltext = sqltext + " and IO = 'O' ";
            }
            else if (this.rboGR.Checked)
            {
                sqltext = sqltext + " and IO = 'I' ";
            }
            if (this.count <= 0)
            {
                sqltext = sqltext + " and (Fruits_type = '' or Fruits_type is null) ";
            }
            else
            {
                int index = 0;
                while (true)
                {
                    if (index >= this.cbChecked.Count<string>())
                    {
                        sqltext = sqltext + " ) ";
                        break;
                    }
                    if (this.cbChecked[index] != "")
                    {
                        sqltext = (index != 0) ? (sqltext + " or Fruits_type = '" + this.cbChecked[index] + "' ") : (sqltext + " and ( Fruits_type = '" + this.cbChecked[index] + "' ");
                    }
                    index++;
                }
            }
            table.OpenTable("vw_trans", sqltext, WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                num = 0.0;
            }
            else
            {
                table.DR = table.DT.Rows[0];
                num = (table.DR["Rec"].ToString().Length <= 0) ? 0.0 : Convert.ToDouble(table.DR["Rec"].ToString());
            }
            return num;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormReportFFBLA_Load(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" AND type='F'"), WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                this.comboCom.Items.Add(row["Comm_Code"].ToString());
            }
            table.Dispose();
        }

        private void InitializeComponent()
        {
            this.label5 = new Label();
            this.monthCalendar1 = new DateTimePicker();
            this.label1 = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.checkProcess = new CheckBox();
            this.cbGunny = new CheckBox();
            this.checkBoxRejectKG = new CheckBox();
            this.label2 = new Label();
            this.comboCom = new ComboBox();
            this.groupFType = new GroupBox();
            this.checkR = new CheckBox();
            this.checkK = new CheckBox();
            this.checkS = new CheckBox();
            this.checkB = new CheckBox();
            this.checkM = new CheckBox();
            this.grType = new GroupBox();
            this.rboAll = new RadioButton();
            this.rboGI = new RadioButton();
            this.rboGR = new RadioButton();
            this.groupFType.SuspendLayout();
            this.grType.SuspendLayout();
            base.SuspendLayout();
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(15, 15);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x9d, 20);
            this.label5.TabIndex = 0x51;
            this.label5.Text = "LA Report for FFB";
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x53, 0x7a);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0x53;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x13, 0x7b);
            this.label1.Name = "label1";
            this.label1.Size = new Size(30, 13);
            this.label1.TabIndex = 0x54;
            this.label1.Text = "Date";
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1a1, 0xd1);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x24);
            this.button2.TabIndex = 0x56;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x121, 0xd1);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x25);
            this.button1.TabIndex = 0x55;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x1d1, 0x16);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 0x58;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x139, 0x16);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 0x57;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.checkProcess.AutoSize = true;
            this.checkProcess.Location = new Point(0x133, 0x7a);
            this.checkProcess.Name = "checkProcess";
            this.checkProcess.Size = new Size(0x93, 0x11);
            this.checkProcess.TabIndex = 0x59;
            this.checkProcess.Text = "Include Processing Truck";
            this.checkProcess.UseVisualStyleBackColor = true;
            this.cbGunny.AutoSize = true;
            this.cbGunny.Location = new Point(0x133, 0x91);
            this.cbGunny.Name = "cbGunny";
            this.cbGunny.Size = new Size(0x99, 0x11);
            this.cbGunny.TabIndex = 100;
            this.cbGunny.Text = "Show Deduction by Gunny";
            this.cbGunny.UseVisualStyleBackColor = true;
            this.checkBoxRejectKG.AutoSize = true;
            this.checkBoxRejectKG.Location = new Point(0x133, 0xa7);
            this.checkBoxRejectKG.Name = "checkBoxRejectKG";
            this.checkBoxRejectKG.Size = new Size(0x8a, 0x11);
            this.checkBoxRejectKG.TabIndex = 0x65;
            this.checkBoxRejectKG.Text = "Show FFB Reject in KG";
            this.checkBoxRejectKG.UseVisualStyleBackColor = true;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x12, 0x98);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x3a, 13);
            this.label2.TabIndex = 0x66;
            this.label2.Text = "Commodity";
            this.comboCom.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboCom.FormattingEnabled = true;
            this.comboCom.Location = new Point(0x53, 0x95);
            this.comboCom.Name = "comboCom";
            this.comboCom.Size = new Size(0x99, 0x15);
            this.comboCom.TabIndex = 0x67;
            this.groupFType.Controls.Add(this.checkR);
            this.groupFType.Controls.Add(this.checkK);
            this.groupFType.Controls.Add(this.checkS);
            this.groupFType.Controls.Add(this.checkB);
            this.groupFType.Controls.Add(this.checkM);
            this.groupFType.Location = new Point(0x133, 0x3b);
            this.groupFType.Name = "groupFType";
            this.groupFType.Size = new Size(220, 0x2d);
            this.groupFType.TabIndex = 0x68;
            this.groupFType.TabStop = false;
            this.groupFType.Text = "Fruit Type";
            this.checkR.AutoSize = true;
            this.checkR.Checked = true;
            this.checkR.CheckState = CheckState.Checked;
            this.checkR.Location = new Point(0xb0, 20);
            this.checkR.Name = "checkR";
            this.checkR.Size = new Size(0x22, 0x11);
            this.checkR.TabIndex = 4;
            this.checkR.Text = "R";
            this.checkR.UseVisualStyleBackColor = true;
            this.checkK.AutoSize = true;
            this.checkK.Checked = true;
            this.checkK.CheckState = CheckState.Checked;
            this.checkK.Location = new Point(0x89, 20);
            this.checkK.Name = "checkK";
            this.checkK.Size = new Size(0x21, 0x11);
            this.checkK.TabIndex = 3;
            this.checkK.Text = "K";
            this.checkK.UseVisualStyleBackColor = true;
            this.checkS.AutoSize = true;
            this.checkS.Checked = true;
            this.checkS.CheckState = CheckState.Checked;
            this.checkS.Location = new Point(0x62, 20);
            this.checkS.Name = "checkS";
            this.checkS.Size = new Size(0x21, 0x11);
            this.checkS.TabIndex = 2;
            this.checkS.Text = "S";
            this.checkS.UseVisualStyleBackColor = true;
            this.checkB.AutoSize = true;
            this.checkB.Checked = true;
            this.checkB.CheckState = CheckState.Checked;
            this.checkB.Location = new Point(0x3b, 20);
            this.checkB.Name = "checkB";
            this.checkB.Size = new Size(0x21, 0x11);
            this.checkB.TabIndex = 1;
            this.checkB.Text = "B";
            this.checkB.UseVisualStyleBackColor = true;
            this.checkM.AutoSize = true;
            this.checkM.Checked = true;
            this.checkM.CheckState = CheckState.Checked;
            this.checkM.Location = new Point(0x12, 20);
            this.checkM.Name = "checkM";
            this.checkM.Size = new Size(0x23, 0x11);
            this.checkM.TabIndex = 0;
            this.checkM.Text = "M";
            this.checkM.UseVisualStyleBackColor = true;
            this.grType.Controls.Add(this.rboAll);
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x13, 0x3b);
            this.grType.Name = "grType";
            this.grType.Size = new Size(0x11a, 0x2d);
            this.grType.TabIndex = 0xa4;
            this.grType.TabStop = false;
            this.grType.Text = "Report Type";
            this.rboAll.AutoSize = true;
            this.rboAll.Checked = true;
            this.rboAll.Location = new Point(0x12, 0x12);
            this.rboAll.Name = "rboAll";
            this.rboAll.Size = new Size(0x24, 0x11);
            this.rboAll.TabIndex = 0x7c;
            this.rboAll.TabStop = true;
            this.rboAll.Text = "All";
            this.rboAll.UseVisualStyleBackColor = true;
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(0xba, 0x12);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 0x11;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.rboGR.AutoSize = true;
            this.rboGR.Location = new Point(0x49, 0x12);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0x10;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x229, 270);
            base.ControlBox = false;
            base.Controls.Add(this.grType);
            base.Controls.Add(this.groupFType);
            base.Controls.Add(this.comboCom);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.checkBoxRejectKG);
            base.Controls.Add(this.cbGunny);
            base.Controls.Add(this.checkProcess);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.monthCalendar1);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.label5);
            base.Name = "RepFFBLA";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Report FFB LA";
            base.Load += new EventHandler(this.FormReportFFBLA_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepFFBLA_KeyPress);
            this.groupFType.ResumeLayout(false);
            this.groupFType.PerformLayout();
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void RepFFBLA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }
    }
}

