﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.Text;
    using System.Windows.Forms;

    public class RepTransLog : Form
    {
        public string tipe;
        private WBTable tbl_info;
        private string fName = "";
        public bool zAuto = false;
        public bool firsttime = true;
        public string chckSQL;
        public int refCount = 0;
        public int rowCount = 0;
        public string fValue = "";
        public DataRow tmpRow;
        private StringBuilder sDetail = new StringBuilder("");
        public string refNo;
        public bool checkData = false;
        private IContainer components = null;
        public Label labelProses2;
        public CheckBox checkDate;
        public TextBox textRef;
        public GroupBox groupBox1;
        public DateTimePicker monthCalendar1;
        public Label label5;
        public Label label6;
        public DateTimePicker monthCalendar2;
        public Label labelProses1;
        public Button button2;
        public Label labelcommodity;
        public Button button1;
        public Label label3;

        public RepTransLog()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable vTransLog = new WBTable();
            vTransLog = this.initTable(this.checkDate.Checked, this.monthCalendar1.Value, this.monthCalendar2.Value, this.textRef.Text, WBData.sCoyCode, WBData.sLocCode);
            if (vTransLog.DT.Rows.Count <= 0)
            {
                MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                HTML html = new HTML();
                html = this.generateRep(vTransLog, this.monthCalendar1.Value, WBData.sCoyCode, WBData.sLocCode);
                ViewReport report = new ViewReport {
                    webBrowser1 = { Url = new Uri("file:///" + html.File) }
                };
                report.ShowDialog();
                this.labelProses1.Text = "";
                this.labelProses1.Refresh();
                this.labelProses2.Text = "";
                this.labelProses2.Refresh();
                html.Dispose();
                report.Dispose();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
        }

        private void checkDate_CheckedChanged(object sender, EventArgs e)
        {
            this.textRef.Enabled = !this.checkDate.Checked;
            this.monthCalendar1.Enabled = this.checkDate.Checked;
            this.monthCalendar2.Enabled = this.checkDate.Checked;
            this.textRef.Text = "";
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public HTML generateRep(WBTable vTransLog, DateTime dt, string coy, string loc)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            string[] textArray1 = new string[] { "SELECT * FROM wb_location WHERE coy = '", coy, "' and location_code = '", loc, "'" };
            table2.OpenTable("wb_loc", string.Concat(textArray1), WBData.conn);
            table.OpenTable("wb_coy", "SELECT * FROM wb_company WHERE coy_code = '" + coy + "'", WBData.conn);
            WBTable table3 = new WBTable();
            this.tbl_info = new WBTable();
            string sqltext = "Select ORDINAL_POSITION as NO, COLUMN_NAME as FIELD, DATA_TYPE as TYPE, CHARACTER_MAXIMUM_LENGTH as LENGTH, IS_NULLABLE as ISNULL from INFORMATION_SCHEMA.COLUMNS WHERE table_name ='wb_trans_log'";
            this.tbl_info.OpenTable("wb_info", sqltext, WBData.conn);
            int count = 0;
            count = this.tbl_info.DT.Rows.Count;
            this.labelProses1.Text = "0/" + vTransLog.DT.Rows.Count;
            HTML html = new HTML();
            string path = html.File + @"\LogReport";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            HTML html2 = html;
            string[] textArray2 = new string[] { html2.File, @"\LogReport\", coy, loc, "TRANSLOG_", dt.ToString("ddMMyyyy"), ".htm" };
            html2.File = string.Concat(textArray2);
            html.Title = "List of Transaction Log";
            html.Open();
            html.Write(html.Style());
            html.Write("<br><font size=5><b>LOG LIST OF TRANSACTION</b></font><br>");
            string[] textArray3 = new string[] { "<br><font size=4>", table.DT.Rows[0]["coy_name"].ToString(), " (", coy, ")</font>" };
            html.Write(string.Concat(textArray3));
            string[] textArray4 = new string[] { "<br><font size=4>", table2.DT.Rows[0]["location_name"].ToString(), " (", loc, ")</font>" };
            html.Write(string.Concat(textArray4));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                html.Write("<br><font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font>");
            }
            else
            {
                html.Write("<br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                html.Write("<br><font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br><br>");
            }
            else
            {
                html.Write("<br>");
            }
            html.Write("<font size=3>");
            if (this.textRef.Text.Trim() != "")
            {
                html.Write("<br>Ref Number : <b>" + this.textRef.Text + "</b>");
            }
            if (this.checkDate.Checked)
            {
                string[] textArray5 = new string[] { "<br>Date : <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b>" };
                html.Write(string.Concat(textArray5));
            }
            table3.OpenTable("wb_trans_Log", this.chckSQL + " and Delete_by is null and Printed_By is null ORDER BY REF, uniq", WBData.conn);
            if (table3.DT.Rows.Count > 0)
            {
                html.Write("<br>");
                html.Write("<br><b>CHANGES ON TRANSACTION</b>");
                html.Write("<br>");
                html.Write("<br>");
                html.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                html.Write("<tr class='bd'> ");
                html.Write("<tr class='bd'> ");
                foreach (DataRow row in this.tbl_info.DT.Rows)
                {
                    this.fName = row["Field"].ToString().ToUpper();
                    if (((this.fName != "UNIQ") && ((this.fName != "COY") && ((this.fName != "LOCATION_CODE") && (this.fName != "PRINTED_BY")))) && (this.fName != "PRINTED_DATE"))
                    {
                        html.Write("<th rowspan=nowrap align=center>" + row["Field"].ToString() + "</th> ");
                    }
                }
                html.Write("</tr> ");
                html.Write("</tr> ");
                this.fName = "";
                this.fName = "";
                this.refCount = 0;
                this.rowCount = 0;
                this.fValue = "";
                this.tmpRow = vTransLog.DT.Rows[0];
                this.sDetail = new StringBuilder("");
                this.checkData = false;
                using (IEnumerator enumerator2 = vTransLog.DT.Rows.GetEnumerator())
                {
                    DataRow current;
                    goto TR_00A5;
                TR_0081:
                    this.tmpRow = current;
                    goto TR_00A5;
                TR_0082:
                    this.checkData = true;
                    this.sDetail.Append("</tr> ");
                    this.refCount++;
                    this.rowCount++;
                    goto TR_0081;
                TR_00A5:
                    while (true)
                    {
                        if (enumerator2.MoveNext())
                        {
                            current = (DataRow) enumerator2.Current;
                            this.fValue = current["Deleted"].ToString();
                            if ((this.fValue != "Y") && (current["Printed_By"].ToString() == ""))
                            {
                                this.labelProses1.Text = this.rowCount.ToString();
                                this.labelProses1.Refresh();
                                this.labelProses2.Text = current["Ref"].ToString();
                                this.labelProses2.Refresh();
                                this.fName = "";
                                if (this.firsttime)
                                {
                                    this.refCount = 1;
                                    this.sDetail.Append("<tr class='bd'> ");
                                    this.sDetail.Append("<td valign=top nowrap rowspan=?x?x?rowz>" + current["Ref"].ToString().Trim() + "</td> ");
                                    this.refNo = current["Ref"].ToString().Trim();
                                    this.firsttime = false;
                                }
                                if (this.refNo.Trim().ToUpper() == current["Ref"].ToString().Trim().ToUpper())
                                {
                                    if (this.rowCount > 0)
                                    {
                                        this.sDetail.Append("<tr class='bd'> ");
                                    }
                                }
                                else
                                {
                                    this.sDetail.Replace("?x?x?rowz", (this.refCount - 1));
                                    html.Write(this.sDetail.ToString());
                                    this.sDetail.Clear();
                                    this.refNo = current["Ref"].ToString().Trim();
                                    this.tmpRow = current;
                                    this.refCount = 1;
                                    this.sDetail.Append("<tr class='bd'> ");
                                    this.sDetail.Append("<td valign=top nowrap rowspan=?x?x?rowz>" + current["Ref"].ToString().Trim() + "</td> ");
                                }
                                using (IEnumerator enumerator3 = this.tbl_info.DT.Rows.GetEnumerator())
                                {
                                    DataRow current;
                                    goto TR_0098;
                                TR_008D:
                                    if (current["TYPE"].ToString().ToUpper().Trim() == "FLOAT")
                                    {
                                        this.fValue = $"{this.fValue:N0}";
                                    }
                                    string str3 = "bgcolor=white";
                                    if (!this.checkData)
                                    {
                                        str3 = "bgcolor=white";
                                    }
                                    else if (this.checkData)
                                    {
                                        str3 = (this.tmpRow[this.fName].ToString().Trim() == current[this.fName].ToString().Trim()) ? "bgcolor=white" : "bgcolor=yellow";
                                    }
                                    if (this.fName.ToUpper() != "REF")
                                    {
                                        string[] textArray6 = new string[] { "<td valign=top nowrap ", str3, ">", html.strq(this.fValue), "</td> " };
                                        this.sDetail.Append(string.Concat(textArray6));
                                    }
                                    else if (this.fName.ToUpper() == "REF")
                                    {
                                        string[] textArray7 = new string[] { "<td valign=top nowrap ", str3, ">", html.strq(this.fValue), "</td> " };
                                        this.sDetail.Append(string.Concat(textArray7));
                                    }
                                TR_0098:
                                    while (true)
                                    {
                                        if (enumerator3.MoveNext())
                                        {
                                            current = (DataRow) enumerator3.Current;
                                            this.fName = current["Field"].ToString().ToUpper();
                                            if (((this.fName == "UNIQ") || ((this.fName == "COY") || ((this.fName == "LOCATION_CODE") || ((this.fName == "REF") || (this.fName == "PRINTED_BY"))))) || (this.fName == "PRINTED_DATE"))
                                            {
                                                continue;
                                            }
                                            this.fValue = current[this.fName].ToString();
                                            if ((this.fName.Length > 4) && (this.fName.ToUpper() != "CHANGE_DATE"))
                                            {
                                                if (this.fName.Substring(this.fName.Length - 4, 4).Trim().ToUpper() == "DATE")
                                                {
                                                    this.fValue = (this.fValue.Length >= 10) ? this.fValue.Substring(0, 10) : this.fValue;
                                                }
                                                else if (this.fName.Substring(this.fName.Length - 4, 4).Trim().ToUpper() == "TIME")
                                                {
                                                    try
                                                    {
                                                        this.fValue = Convert.ToDateTime(this.fValue).ToString("HH:mm:ss");
                                                    }
                                                    catch
                                                    {
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            goto TR_0082;
                                        }
                                        break;
                                    }
                                    goto TR_008D;
                                }
                            }
                        }
                        else
                        {
                            this.sDetail.Replace("?x?x?rowz", (this.refCount + 1));
                            html.Write(this.sDetail.ToString());
                            this.sDetail.Clear();
                            html.Write("</table>");
                            html.Write("<br>");
                            html.Write("<br>");
                            goto TR_007A;
                        }
                        break;
                    }
                    goto TR_0081;
                }
            }
        TR_007A:
            table3.OpenTable("wb_trans_Log", this.chckSQL + " and Deleted = 'Y'", WBData.conn);
            if (table3.DT.Rows.Count > 0)
            {
                html.Write("<br><b>CANCEL ON TRANSACTION</b>");
                html.Write("<br>");
                html.Write("<br>");
                html.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                html.Write("<tr class='bd'> ");
                html.Write("<tr class='bd'> ");
                foreach (DataRow row4 in this.tbl_info.DT.Rows)
                {
                    this.fName = row4["Field"].ToString().ToUpper();
                    if (((this.fName != "UNIQ") && ((this.fName != "COY") && ((this.fName != "LOCATION_CODE") && (this.fName != "PRINTED_BY")))) && (this.fName != "PRINTED_DATE"))
                    {
                        html.Write("<th rowspan=nowrap align=center>" + row4["Field"].ToString() + "</th> ");
                    }
                }
                html.Write("</tr> ");
                html.Write("</tr> ");
                this.fName = "";
                this.fName = "";
                this.fValue = "";
                this.tmpRow = vTransLog.DT.Rows[0];
                this.sDetail = new StringBuilder("");
                this.checkData = false;
                this.firsttime = true;
                using (IEnumerator enumerator5 = vTransLog.DT.Rows.GetEnumerator())
                {
                    goto TR_0070;
                TR_004D:
                    this.checkData = true;
                    this.sDetail.Append("</tr> ");
                    this.refCount++;
                    this.rowCount++;
                TR_0070:
                    while (enumerator5.MoveNext())
                    {
                        DataRow current = (DataRow) enumerator5.Current;
                        this.fValue = current["Deleted"].ToString();
                        if ((this.fValue == "Y") && (current["Printed_By"].ToString() == ""))
                        {
                            this.labelProses1.Text = this.rowCount.ToString();
                            this.labelProses1.Refresh();
                            this.labelProses2.Text = current["Ref"].ToString();
                            this.labelProses2.Refresh();
                            this.fName = "";
                            if (this.firsttime)
                            {
                                this.refCount = 1;
                                this.sDetail.Append("<tr class='bd'> ");
                                this.sDetail.Append("<td valign=top nowrap rowspan=?x?x?rowz>" + current["Ref"].ToString().Trim() + "</td> ");
                                this.refNo = current["Ref"].ToString().Trim();
                                this.firsttime = false;
                            }
                            if ((this.refNo.Trim().ToUpper() == current["Ref"].ToString().Trim().ToUpper()) || (this.refNo.Trim().ToUpper() == ""))
                            {
                                if (this.rowCount > 0)
                                {
                                    this.sDetail.Append("<tr class='bd'> ");
                                }
                            }
                            else
                            {
                                this.sDetail.Replace("?x?x?rowz", this.refCount);
                                html.Write(this.sDetail.ToString());
                                this.sDetail.Clear();
                                this.refNo = current["Ref"].ToString().Trim();
                                this.tmpRow = current;
                                this.refCount = 0;
                                this.sDetail.Append("<tr class='bd'> ");
                                this.sDetail.Append("<td valign=top nowrap rowspan=?x?x?rowz>" + current["Ref"].ToString().Trim() + "</td> ");
                            }
                            using (IEnumerator enumerator6 = this.tbl_info.DT.Rows.GetEnumerator())
                            {
                                DataRow row6;
                                goto TR_0063;
                            TR_0058:
                                if (row6["TYPE"].ToString().ToUpper().Trim() == "FLOAT")
                                {
                                    this.fValue = $"{this.fValue:N0}";
                                }
                                string str4 = "bgcolor=white";
                                if (!this.checkData)
                                {
                                    str4 = "bgcolor=white";
                                }
                                else if (this.checkData)
                                {
                                    str4 = (this.tmpRow[this.fName].ToString().Trim() == current[this.fName].ToString().Trim()) ? "bgcolor=white" : "bgcolor=yellow";
                                }
                                if (this.fName.ToUpper() != "REF")
                                {
                                    string[] textArray8 = new string[] { "<td valign=top nowrap ", str4, ">", html.strq(this.fValue), "</td> " };
                                    this.sDetail.Append(string.Concat(textArray8));
                                }
                                else if (this.fName.ToUpper() == "REF")
                                {
                                    string[] textArray9 = new string[] { "<td valign=top nowrap ", str4, ">", html.strq(this.fValue), "</td> " };
                                    this.sDetail.Append(string.Concat(textArray9));
                                }
                            TR_0063:
                                while (true)
                                {
                                    if (enumerator6.MoveNext())
                                    {
                                        row6 = (DataRow) enumerator6.Current;
                                        this.fName = row6["Field"].ToString().ToUpper();
                                        if (((this.fName == "UNIQ") || ((this.fName == "COY") || ((this.fName == "LOCATION_CODE") || ((this.fName == "REF") || (this.fName == "PRINTED_BY"))))) || (this.fName == "PRINTED_DATE"))
                                        {
                                            continue;
                                        }
                                        this.fValue = current[this.fName].ToString();
                                        if ((this.fName.Length > 4) && (this.fName.ToUpper() != "CHANGE_DATE"))
                                        {
                                            if (this.fName.Substring(this.fName.Length - 4, 4).Trim().ToUpper() == "DATE")
                                            {
                                                this.fValue = (this.fValue.Length >= 10) ? this.fValue.Substring(0, 10) : this.fValue;
                                            }
                                            else if (this.fName.Substring(this.fName.Length - 4, 4).Trim().ToUpper() == "TIME")
                                            {
                                                try
                                                {
                                                    this.fValue = Convert.ToDateTime(this.fValue).ToString("HH:mm:ss");
                                                }
                                                catch
                                                {
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        goto TR_004D;
                                    }
                                    break;
                                }
                                goto TR_0058;
                            }
                        }
                    }
                    this.sDetail.Replace("?x?x?rowz", (this.refCount + 1));
                    html.Write(this.sDetail.ToString());
                    this.sDetail.Clear();
                    html.Write("</table>");
                    html.Write("<br>");
                    html.Write("<br>");
                }
            }
            table3.OpenTable("wb_trans_Log", this.chckSQL + " and Printed > '1'", WBData.conn);
            if (table3.DT.Rows.Count > 0)
            {
                html.Write("<br><b>PRINTED ON TRANSACTION</b>");
                html.Write("<br>");
                html.Write("<br>");
                html.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                html.Write("<tr class='bd'> ");
                html.Write("<tr class='bd'> ");
                foreach (DataRow row7 in this.tbl_info.DT.Rows)
                {
                    this.fName = row7["Field"].ToString().ToUpper();
                    if (((this.fName == "REF") || ((this.fName == "WX") || ((this.fName == "TRANSACTION_CODE") || ((this.fName == "PRINTED") || ((this.fName == "PRINTED_BY") || (this.fName == "PRINTED_DATE")))))) || (this.fName == "CHANGEREASON"))
                    {
                        if (this.fName == "CHANGEREASON")
                        {
                            html.Write("<th rowspan=nowrap align=center> Reprint Reason</th> ");
                            continue;
                        }
                        html.Write("<th rowspan=nowrap align=center>" + row7["Field"].ToString() + "</th> ");
                    }
                }
                html.Write("</tr> ");
                html.Write("</tr> ");
                this.fName = "";
                this.fName = "";
                this.fValue = "";
                this.tmpRow = vTransLog.DT.Rows[0];
                this.sDetail = new StringBuilder("");
                this.checkData = false;
                this.firsttime = true;
                foreach (DataRow row8 in vTransLog.DT.Rows)
                {
                    if ((row8["Printed_By"].ToString() != "") && (Convert.ToInt16(row8["Printed"].ToString()) > 1))
                    {
                        this.labelProses1.Text = this.rowCount.ToString();
                        this.labelProses1.Refresh();
                        this.labelProses2.Text = row8["Ref"].ToString();
                        this.labelProses2.Refresh();
                        this.fName = "";
                        if (this.firsttime)
                        {
                            this.refCount = 1;
                            this.sDetail.Append("<tr class='bd'> ");
                            this.sDetail.Append("<td valign=top nowrap rowspan=?x?x?rowz>" + row8["Ref"].ToString().Trim() + "</td> ");
                            this.refNo = row8["Ref"].ToString().Trim();
                            this.firsttime = false;
                        }
                        if ((this.refNo.Trim().ToUpper() == row8["Ref"].ToString().Trim().ToUpper()) || (this.refNo.Trim().ToUpper() == ""))
                        {
                            if (this.rowCount > 0)
                            {
                                this.sDetail.Append("<tr class='bd'> ");
                            }
                        }
                        else
                        {
                            this.sDetail.Replace("?x?x?rowz", this.refCount);
                            html.Write(this.sDetail.ToString());
                            this.sDetail.Clear();
                            this.refNo = row8["Ref"].ToString().Trim();
                            this.tmpRow = row8;
                            this.refCount = 0;
                            this.sDetail.Append("<tr class='bd'> ");
                            this.sDetail.Append("<td valign=top nowrap rowspan=?x?x?rowz>" + row8["Ref"].ToString().Trim() + "</td> ");
                        }
                        foreach (DataRow row9 in this.tbl_info.DT.Rows)
                        {
                            this.fName = row9["Field"].ToString().ToUpper();
                            if (((this.fName == "WX") || ((this.fName == "TRANSACTION_CODE") || ((this.fName == "PRINTED") || ((this.fName == "PRINTED_BY") || (this.fName == "PRINTED_DATE"))))) || (this.fName == "CHANGEREASON"))
                            {
                                this.fValue = row8[this.fName].ToString();
                                if (row9["TYPE"].ToString().ToUpper().Trim() == "FLOAT")
                                {
                                    this.fValue = $"{this.fValue:N0}";
                                }
                                string str5 = "bgcolor=white";
                                if (!this.checkData)
                                {
                                    str5 = "bgcolor=white";
                                }
                                else if (this.checkData)
                                {
                                    str5 = (this.tmpRow[this.fName].ToString().Trim() == row8[this.fName].ToString().Trim()) ? "bgcolor=white" : "bgcolor=yellow";
                                }
                                if (this.fName.ToUpper() != "REF")
                                {
                                    string[] textArray10 = new string[] { "<td valign=top nowrap ", str5, ">", html.strq(this.fValue), "</td> " };
                                    this.sDetail.Append(string.Concat(textArray10));
                                }
                                else if (this.fName.ToUpper() == "REF")
                                {
                                    string[] textArray11 = new string[] { "<td valign=top nowrap ", str5, ">", html.strq(this.fValue), "</td> " };
                                    this.sDetail.Append(string.Concat(textArray11));
                                }
                            }
                        }
                        this.checkData = true;
                        this.sDetail.Append("</tr> ");
                        this.refCount++;
                        this.rowCount++;
                    }
                }
            }
            this.sDetail.Replace("?x?x?rowz", (this.refCount + 1));
            html.Write(this.sDetail.ToString());
            this.sDetail.Clear();
            html.Write("</table>");
            html.Write("<br>");
            html.Write("<br>");
            html.writeSign();
            html.Close();
            return html;
        }

        private void InitializeComponent()
        {
            this.labelProses2 = new Label();
            this.checkDate = new CheckBox();
            this.textRef = new TextBox();
            this.groupBox1 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label5 = new Label();
            this.label6 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.labelProses1 = new Label();
            this.button2 = new Button();
            this.labelcommodity = new Label();
            this.button1 = new Button();
            this.label3 = new Label();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0x150, 0x1b);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0xd6, 13);
            this.labelProses2.TabIndex = 0x4c;
            this.labelProses2.Text = "Progresssss . . . . . . . . . . . . . . . . . ";
            this.labelProses2.TextAlign = ContentAlignment.MiddleRight;
            this.checkDate.AutoSize = true;
            this.checkDate.Checked = true;
            this.checkDate.CheckState = CheckState.Checked;
            this.checkDate.Location = new Point(14, 0x2a);
            this.checkDate.Name = "checkDate";
            this.checkDate.Size = new Size(60, 0x11);
            this.checkDate.TabIndex = 0x4b;
            this.checkDate.Text = "byDate";
            this.checkDate.UseVisualStyleBackColor = true;
            this.checkDate.CheckedChanged += new EventHandler(this.checkDate_CheckedChanged);
            this.textRef.CharacterCasing = CharacterCasing.Upper;
            this.textRef.Location = new Point(0x5d, 0x7b);
            this.textRef.Name = "textRef";
            this.textRef.Size = new Size(0xc0, 20);
            this.textRef.TabIndex = 0x45;
            this.textRef.KeyPress += new KeyPressEventHandler(this.textRef_KeyPress);
            this.groupBox1.Controls.Add(this.monthCalendar1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.monthCalendar2);
            this.groupBox1.Location = new Point(14, 0x40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x178, 0x2d);
            this.groupBox1.TabIndex = 0x44;
            this.groupBox1.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(80, 0x10);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(8, 0x13);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x3e, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "From Date :";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xc6, 0x13);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x34, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x100, 0x10);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(0x153, 14);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0xd3, 13);
            this.labelProses1.TabIndex = 0x4d;
            this.labelProses1.Text = "1/88888";
            this.labelProses1.TextAlign = ContentAlignment.MiddleRight;
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(440, 0x79);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x22);
            this.button2.TabIndex = 0x47;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x15, 0x7e);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x2c, 13);
            this.labelcommodity.TabIndex = 0x49;
            this.labelcommodity.Text = "No. Ref";
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(440, 0x4a);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x22);
            this.button1.TabIndex = 70;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(10, 9);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0xc1, 20);
            this.label3.TabIndex = 0x4e;
            this.label3.Text = "List of Transaction Log";
            this.label3.TextAlign = ContentAlignment.TopCenter;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x233, 0xa8);
            base.ControlBox = false;
            base.Controls.Add(this.label3);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.checkDate);
            base.Controls.Add(this.textRef);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.button1);
            base.Name = "RepTransLog";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Report Transaction Log";
            base.Load += new EventHandler(this.RepTransLog_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepTransLog_KeyPress);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        public WBTable initTable(bool byDate, DateTime dateFrom, DateTime dateTo, string refNo, string coy, string loc)
        {
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "SELECT * FROM wb_trans_log WHERE coy = '", coy, "' and location_code = '", loc, "'" };
            string sqltext = string.Concat(textArray1);
            if (byDate && !this.zAuto)
            {
                sqltext = (sqltext + " AND (log_date>='" + dateFrom.ToString("yyyy-MM-dd") + " 00:00:00'") + " AND log_date<='" + dateTo.ToString("yyyy-MM-dd") + " 00:00:00')";
            }
            else if (byDate && this.zAuto)
            {
                sqltext = sqltext + " AND (log_date ='" + dateTo.ToString("yyyy-MM-dd") + " 00:00:00')";
            }
            if (this.textRef.Text != "")
            {
                sqltext = sqltext + " AND Ref='" + refNo + "'";
            }
            this.chckSQL = sqltext;
            sqltext = sqltext + "ORDER BY Ref, uniq ASC";
            table.OpenTable("wb_transLog", sqltext, WBData.conn);
            return table;
        }

        private void RepTransLog_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepTransLog_Load(object sender, EventArgs e)
        {
            this.translate();
            base.KeyPreview = true;
            this.textRef.Enabled = false;
            this.labelProses1.Text = "";
            this.labelProses2.Text = "";
        }

        private void textRef_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.Text = Resource.Report09_001;
            this.label3.Text = Resource.Report09_002;
            this.checkDate.Text = Resource.Report09_003;
            this.label5.Text = Resource.Report09_004;
            this.label6.Text = Resource.Report09_005;
            this.labelcommodity.Text = Resource.Report09_006;
            this.button1.Text = Resource.Rep01_042;
            this.button2.Text = Resource.Menu_Close;
        }
    }
}

