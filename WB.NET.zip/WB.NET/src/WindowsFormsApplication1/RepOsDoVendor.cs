﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class RepOsDoVendor : Form
    {
        private string sqlDo;
        private string sqlTrans;
        private string do_no;
        private int jlhRecord;
        private double os;
        private double issue;
        private double party;
        private double ttlos;
        private double ttlissue;
        private double ttlparty;
        private double colly;
        private double tcolly;
        public WBTable tblRelation = new WBTable();
        private WBTable tbl_do = new WBTable();
        private WBTable tbl_OS = new WBTable();
        private IContainer components = null;
        public RadioButton rboGI;
        public GroupBox grType;
        public RadioButton rboGR;
        public Button butClose;
        public Button butProcess;
        public Label labelRecNo;
        public Label labelProcess;
        public Label label5;
        public GroupBox groupBox1;
        public DateTimePicker monthCalendar1;
        public Label label6;
        public DateTimePicker monthCalendar2;
        public Label label1;
        public RadioButton rboAll;
        public Button buttonRelation;
        public Label label2;
        public TextBox textRelation;
        private GroupBox gbDispOpt;
        private CheckBox cBoxLossInPack;
        private CheckBox cBoxLossInKg;
        private CheckBox cBoxReturInPack;
        private CheckBox cBoxReturInKg;

        public RepOsDoVendor()
        {
            this.InitializeComponent();
        }

        private void butClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void butProcess_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                this.sqlDo = "SELECT Contract_Date, Do_No, Relation_Code, Comm_Code, Transaction_Code, Quantity,deductedby FROM wb_contract ";
                this.sqlDo = this.sqlDo + "WHERE Coy = '" + WBData.sCoyCode;
                this.sqlDo = this.sqlDo + "' AND Location_Code = '" + WBData.sLocCode + "'";
                this.sqlDo = this.sqlDo + " and Contract_Date >= '" + Program.DTOC(Convert.ToDateTime(this.monthCalendar1.Value.ToString())) + " 00:00:00' ";
                this.sqlDo = this.sqlDo + " and Contract_Date <= '" + Program.DTOC(Convert.ToDateTime(this.monthCalendar2.Value.ToString())) + " 23:59:59' ";
                if (this.rboGI.Checked)
                {
                    this.sqlDo = this.sqlDo + " AND Transaction_Code IN (SELECT Transaction_Code FROM wb_transaction_type WHERE IO = 'O' )";
                }
                if (this.rboGR.Checked)
                {
                    this.sqlDo = this.sqlDo + " AND Transaction_Code IN (SELECT Transaction_Code FROM wb_transaction_type WHERE IO = 'I' )";
                }
                if (this.textRelation.Text.Trim() != "")
                {
                    this.sqlDo = this.sqlDo + " AND Relation_Code = '" + this.textRelation.Text + "'";
                }
                this.sqlDo = this.sqlDo + " AND (closed IS null OR closed <> 'X' OR closed = 'N')";
                this.sqlDo = this.sqlDo + " ORDER BY Relation_Code, Contract_Date, Do_No";
                this.tbl_do = new WBTable();
                this.tbl_do.OpenTable("wb_contract", this.sqlDo, WBData.conn);
                if (this.tbl_do.DT.Rows.Count <= 0)
                {
                    MessageBox.Show("No Records Found", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    this.labelProcess.Visible = true;
                    this.labelRecNo.Visible = true;
                    this.labelProcess.Refresh();
                    this.labelRecNo.Refresh();
                    this.jlhRecord = this.tbl_do.DT.Rows.Count;
                    this.printReport();
                    this.labelProcess.Visible = false;
                    this.labelRecNo.Visible = false;
                }
            }
        }

        private void buttonRelation_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textRelation.Text = vendor.ReturnRow["relation_code"].ToString();
            }
            vendor.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void initHeader(HTML rep)
        {
            rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
            rep.Write("<tr class='bd'>");
            rep.Write("<td nowrap align=center><b>No.</b></td>");
            rep.Write("<td nowrap align=center><b>DO/SO Date</b></td>");
            rep.Write("<td nowrap align=center width=250><b>DO/SO No</b></td>");
            rep.Write("<td nowrap align=center width=250><b>Commodity</b></td>");
            rep.Write("<td nowrap align=center><b>Transaction Type</b></td>");
            rep.Write("<td nowrap align=center width=100><b>Party</b></td>");
            rep.Write("<td nowrap align=center width=100><b>Opening Qty</b></td>");
            rep.Write("<td nowrap align=center width=100><b>Weighted in Qty</b></td>");
            rep.Write("<td nowrap align=center width=100><b>Outstanding</b></td>");
            if (this.cBoxReturInKg.Checked)
            {
                rep.Write("<td align=center width=100><b>Return (Kg)</b></td>");
            }
            if (this.cBoxReturInPack.Checked)
            {
                rep.Write("<td align=center width=100><b>Return (Pack)</b></td>");
            }
            if (this.cBoxLossInKg.Checked)
            {
                rep.Write("<td align=center width=130><b>Loss(-)/Gain(+) (Kg)</b></td>");
            }
            if (this.cBoxLossInPack.Checked)
            {
                rep.Write("<td align=center width=130><b>Loss(-)/Gain(+) (Pack)</b></td>");
            }
            rep.Write("</tr>");
        }

        private void InitializeComponent()
        {
            this.rboGI = new RadioButton();
            this.grType = new GroupBox();
            this.rboAll = new RadioButton();
            this.rboGR = new RadioButton();
            this.butClose = new Button();
            this.butProcess = new Button();
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.label5 = new Label();
            this.groupBox1 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label1 = new Label();
            this.label6 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.buttonRelation = new Button();
            this.label2 = new Label();
            this.textRelation = new TextBox();
            this.gbDispOpt = new GroupBox();
            this.cBoxLossInPack = new CheckBox();
            this.cBoxLossInKg = new CheckBox();
            this.cBoxReturInPack = new CheckBox();
            this.cBoxReturInKg = new CheckBox();
            this.grType.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbDispOpt.SuspendLayout();
            base.SuspendLayout();
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(0xc7, 0x13);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 0x11;
            this.rboGI.TabStop = true;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.grType.Controls.Add(this.rboAll);
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x2d, 0x4f);
            this.grType.Name = "grType";
            this.grType.Size = new Size(0x176, 0x2d);
            this.grType.TabIndex = 0x9f;
            this.grType.TabStop = false;
            this.grType.Text = "Transaction Type";
            this.rboAll.AutoSize = true;
            this.rboAll.Location = new Point(13, 0x13);
            this.rboAll.Name = "rboAll";
            this.rboAll.Size = new Size(0x24, 0x11);
            this.rboAll.TabIndex = 0x12;
            this.rboAll.TabStop = true;
            this.rboAll.Text = "All";
            this.rboAll.UseVisualStyleBackColor = true;
            this.rboGR.AutoSize = true;
            this.rboGR.Location = new Point(0x4e, 0x13);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0x10;
            this.rboGR.TabStop = true;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            this.butClose.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.butClose.Location = new Point(0x16f, 0x102);
            this.butClose.Name = "butClose";
            this.butClose.Size = new Size(0x58, 0x20);
            this.butClose.TabIndex = 0x9c;
            this.butClose.Text = "Close";
            this.butClose.UseVisualStyleBackColor = true;
            this.butClose.Click += new EventHandler(this.butClose_Click);
            this.butProcess.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.butProcess.Location = new Point(0x111, 0x102);
            this.butProcess.Name = "butProcess";
            this.butProcess.Size = new Size(0x58, 0x21);
            this.butProcess.TabIndex = 0x9b;
            this.butProcess.Text = "Process";
            this.butProcess.UseVisualStyleBackColor = true;
            this.butProcess.Click += new EventHandler(this.butProcess_Click);
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0xa5, 0x10d);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 0x92;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x2d, 0x10d);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 0x91;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(0x2a, 0x17);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0xcd, 13);
            this.label5.TabIndex = 0x90;
            this.label5.Text = "Report Outstanding DO per Vendor";
            this.groupBox1.Controls.Add(this.monthCalendar1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.monthCalendar2);
            this.groupBox1.Location = new Point(0x2d, 0x80);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x176, 0x2d);
            this.groupBox1.TabIndex = 0xa1;
            this.groupBox1.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x4e, 0x12);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(6, 0x15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3e, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "From Date :";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xc4, 0x15);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x34, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0xfe, 0x12);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.buttonRelation.Location = new Point(0x155, 0x34);
            this.buttonRelation.Margin = new Padding(0);
            this.buttonRelation.Name = "buttonRelation";
            this.buttonRelation.Size = new Size(0x17, 0x17);
            this.buttonRelation.TabIndex = 0xa7;
            this.buttonRelation.Text = "...";
            this.buttonRelation.UseVisualStyleBackColor = true;
            this.buttonRelation.Click += new EventHandler(this.buttonRelation_Click);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x2d, 0x38);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x4a, 13);
            this.label2.TabIndex = 0xa6;
            this.label2.Text = "Relation Code";
            this.textRelation.CharacterCasing = CharacterCasing.Upper;
            this.textRelation.Location = new Point(0x93, 0x35);
            this.textRelation.Name = "textRelation";
            this.textRelation.Size = new Size(0xc0, 20);
            this.textRelation.TabIndex = 1;
            this.textRelation.KeyPress += new KeyPressEventHandler(this.textRelation_KeyPress);
            this.gbDispOpt.Controls.Add(this.cBoxLossInPack);
            this.gbDispOpt.Controls.Add(this.cBoxLossInKg);
            this.gbDispOpt.Controls.Add(this.cBoxReturInPack);
            this.gbDispOpt.Controls.Add(this.cBoxReturInKg);
            this.gbDispOpt.Location = new Point(0x2d, 0xb8);
            this.gbDispOpt.Name = "gbDispOpt";
            this.gbDispOpt.Size = new Size(0xd6, 0x48);
            this.gbDispOpt.TabIndex = 0xb0;
            this.gbDispOpt.TabStop = false;
            this.gbDispOpt.Text = "Display Options";
            this.cBoxLossInPack.AutoSize = true;
            this.cBoxLossInPack.Location = new Point(0x77, 0x2c);
            this.cBoxLossInPack.Name = "cBoxLossInPack";
            this.cBoxLossInPack.Size = new Size(0x57, 0x11);
            this.cBoxLossInPack.TabIndex = 0xb0;
            this.cBoxLossInPack.Text = "Loss in Pack";
            this.cBoxLossInPack.UseVisualStyleBackColor = true;
            this.cBoxLossInKg.AutoSize = true;
            this.cBoxLossInKg.Location = new Point(0x77, 0x15);
            this.cBoxLossInKg.Name = "cBoxLossInKg";
            this.cBoxLossInKg.Size = new Size(0x4d, 0x11);
            this.cBoxLossInKg.TabIndex = 0xb0;
            this.cBoxLossInKg.Text = "Loss in KG";
            this.cBoxLossInKg.UseVisualStyleBackColor = true;
            this.cBoxReturInPack.AutoSize = true;
            this.cBoxReturInPack.Location = new Point(14, 0x2c);
            this.cBoxReturInPack.Name = "cBoxReturInPack";
            this.cBoxReturInPack.Size = new Size(0x61, 0x11);
            this.cBoxReturInPack.TabIndex = 0xb0;
            this.cBoxReturInPack.Text = "Return in Pack";
            this.cBoxReturInPack.UseVisualStyleBackColor = true;
            this.cBoxReturInKg.AutoSize = true;
            this.cBoxReturInKg.Location = new Point(14, 0x15);
            this.cBoxReturInKg.Name = "cBoxReturInKg";
            this.cBoxReturInKg.Size = new Size(0x57, 0x11);
            this.cBoxReturInKg.TabIndex = 0xb0;
            this.cBoxReturInKg.Text = "Return in KG";
            this.cBoxReturInKg.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1e8, 0x12e);
            base.Controls.Add(this.gbDispOpt);
            base.Controls.Add(this.buttonRelation);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textRelation);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.grType);
            base.Controls.Add(this.butClose);
            base.Controls.Add(this.butProcess);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.label5);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "RepOsDoVendor";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Report Outstanding DO per Vendor";
            base.Load += new EventHandler(this.RepOsDoVendor_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepOsDoVendor_KeyPress);
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbDispOpt.ResumeLayout(false);
            this.gbDispOpt.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void PrintRelation(HTML rep, string relation)
        {
            rep.Write("<br><font size=2>Relation Code: " + relation + "</font>");
        }

        private void printReport()
        {
            HTML rep = new HTML();
            rep.File = rep.File + @"\" + WBUser.UserID + "_Oustanding_DO.htm";
            rep.Title = "Report of Outstanding DO/SO per Vendor";
            rep.Open();
            rep.Write(rep.Style());
            rep.Write("<br><font size=5><b>REPORT OF OUTSTANDING DO/SO PER VENDOR</b></font><br>");
            string[] textArray1 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
            rep.Write(string.Concat(textArray1));
            string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
            rep.Write(string.Concat(textArray2));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            rep.Write("<br><br>");
            rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
            rep.Write("<tr class=bd>");
            rep.Write("<td>Selected Date</td>");
            string[] textArray3 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
            rep.Write(string.Concat(textArray3));
            rep.Write("</tr>");
            rep.Write("<tr class=bd>");
            rep.Write("<td>Report Date</td>");
            rep.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
            rep.Write("</tr>");
            rep.Write("</table>");
            rep.Write("<br/><br/>");
            int num3 = 0;
            int num4 = 0;
            this.os = 0.0;
            double num5 = 0.0;
            string str = "0";
            string str2 = "";
            int num7 = 0;
            string relation = "";
            WBTable table = new WBTable();
            string str4 = "";
            string str5 = "";
            string str6 = "KG";
            string str7 = "";
            double num8 = 0.0;
            foreach (DataRow row in this.tbl_do.DT.Rows)
            {
                double num10;
                num7++;
                this.labelRecNo.Text = num4.ToString() + " / " + this.jlhRecord.ToString();
                this.labelRecNo.Refresh();
                num3++;
                num4++;
                str = row["deductedBy"].ToString();
                if (relation != row["Relation_Code"].ToString().Trim())
                {
                    if (relation != "")
                    {
                        rep.Write("</table>");
                    }
                    relation = row["Relation_Code"].ToString();
                    this.PrintRelation(rep, relation);
                    num7 = 1;
                    this.initHeader(rep);
                }
                if (str4 != row["comm_Code"].ToString().Trim())
                {
                    str4 = row["comm_Code"].ToString().Trim();
                    table.OpenTable("wb_Comm", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + str4 + "'"), WBData.conn);
                    table.DR = table.DT.Rows[0];
                    str5 = table.DR["BulkPack"].ToString();
                    str6 = table.DR["Unit"].ToString();
                    str7 = table.DR["Type"].ToString();
                    num8 = Program.StrToDouble(table.DR["Netto_Weight"].ToString(), 0);
                }
                this.do_no = row["do_no"].ToString();
                string[] textArray4 = new string[] { "SELECT sum(netFactory) as NetFactory ,  sum(case when netOther = '0' then netFactory else netOther end) as NetOther,  sum(loading_qty) as loading_qty, sum(loading_qty_opw) as loading_qty_opw,SUM (return_qty_kg) as ReturInKg, SUM (return_qty_pack) as ReturInPack,SUM (case when loading_qty_opw > 0 or return_qty_pack > 0 then loading_qty - loading_qty_opw - return_qty_pack else 0 end) as lossinpack,sum (case when estate_qty > 0 or return_qty_kg > 0 then netto - estate_qty - return_qty_kg else 0 end) as lossinkg  from vw_outstanding where ", WBData.CompanyLocation(" and do_no = '" + this.do_no + "' and (is_return <> 'Y' or is_return is null)"), " and report_date < '", Program.DTOC(Convert.ToDateTime(this.monthCalendar1.Value.ToString())), "' " };
                string sqltext = string.Concat(textArray4);
                this.tbl_OS = new WBTable();
                this.tbl_OS.OpenTable("vw_os", sqltext, WBData.conn);
                num5 = 0.0;
                num5 = (this.tbl_OS.DT.Rows.Count <= 0) ? 0.0 : ((str != "1") ? (((str6 != "KG") && (str6 != "")) ? (Program.StrToDouble(this.tbl_OS.DT.Rows[0]["loading_qty"].ToString(), 0) * num8) : Program.StrToDouble(this.tbl_OS.DT.Rows[0]["NetFactory"].ToString(), 0)) : (((str6 != "KG") && (str6 != "")) ? (Program.StrToDouble(this.tbl_OS.DT.Rows[0]["loading_qty_opw"].ToString(), 0) * num8) : Program.StrToDouble(this.tbl_OS.DT.Rows[0]["NetOther"].ToString(), 0)));
                this.tbl_OS.Close();
                sqltext = (("SELECT sum(netFactory) as NetFactory ,  sum(case when netOther = '0' then netFactory else netOther end) as NetOther,  sum(loading_qty) as loading_qty, sum(loading_qty_opw) as loading_qty_opw,SUM (return_qty_kg) as ReturInKg, SUM (return_qty_pack) as ReturInPack,SUM (case when loading_qty_opw > 0 or return_qty_pack > 0 then loading_qty - loading_qty_opw - return_qty_pack else 0 end) as lossinpack,sum (case when estate_qty > 0 or return_qty_kg > 0 then netto - estate_qty - return_qty_kg else 0 end) as lossinkg  from vw_outstanding where " + WBData.CompanyLocation(" AND DO_No = '" + this.do_no + "' and (is_return <> 'Y' or is_return is null)")) + " and report_date >= '" + Program.DTOC(Convert.ToDateTime(this.monthCalendar1.Value.ToString())) + "' ") + " and report_date <= '" + Program.DTOC(Convert.ToDateTime(this.monthCalendar2.Value.ToString())) + "' ";
                this.tbl_OS = new WBTable();
                this.tbl_OS.OpenTable("vw_os", sqltext, WBData.conn);
                this.issue = (this.tbl_OS.DT.Rows.Count <= 0) ? 0.0 : ((str != "1") ? (((str6 != "KG") && (str6 != "")) ? (Program.StrToDouble(this.tbl_OS.DT.Rows[0]["loading_qty"].ToString(), 0) * num8) : Program.StrToDouble(this.tbl_OS.DT.Rows[0]["NetFactory"].ToString(), 0)) : (((str6 != "KG") && (str6 != "")) ? (Program.StrToDouble(this.tbl_OS.DT.Rows[0]["loading_qty_opw"].ToString(), 0) * num8) : Program.StrToDouble(this.tbl_OS.DT.Rows[0]["NetOther"].ToString(), 0)));
                this.party = Convert.ToDouble(row["quantity"].ToString());
                this.os = this.party - (num5 + this.issue);
                rep.Write("<tr class='bd'>");
                rep.Write("<td nowrap align=right>" + $"{num7:N0}" + "</td>");
                str2 = row["Contract_Date"].ToString();
                rep.Write("<td nowrap align=left>" + rep.strq((str2.Length > 10) ? str2.Substring(0, 10) : str2) + "</td>");
                rep.Write("<td nowrap align=left>" + rep.strq(this.do_no) + "</td>");
                rep.Write("<td nowrap align=left>" + rep.strq(row["Comm_Code"].ToString()) + "</td>");
                rep.Write("<td nowrap align=left>" + rep.strq(row["Transaction_Code"].ToString()) + "</td>");
                rep.Write("<td nowrap align=right>" + $"{this.party:N0}" + "</td>");
                rep.Write("<td nowrap align=right>" + $"{num5:N0}" + "</td>");
                rep.Write("<td nowrap align=right>" + $"{this.issue:N0}" + "</td>");
                rep.Write("<td nowrap align=right>" + $"{this.os:N0}" + "</td>");
                if (this.cBoxReturInKg.Checked)
                {
                    rep.Write("<td nowrap align=right>" + Program.StrToDouble(this.tbl_OS.DT.Rows[0]["Returinkg"].ToString(), 0) + "</td>");
                }
                if (this.cBoxReturInPack.Checked)
                {
                    rep.Write("<td nowrap align=right>" + Program.StrToDouble(this.tbl_OS.DT.Rows[0]["Returinpack"].ToString(), 0) + "</td>");
                }
                if (this.cBoxLossInKg.Checked)
                {
                    if (!(Program.StrToDouble(this.tbl_OS.DT.Rows[0]["lossinpack"].ToString(), 0) == 0.0))
                    {
                        rep.Write("<td nowrap align=right>0</td>");
                    }
                    else
                    {
                        num10 = Program.StrToDouble(this.tbl_OS.DT.Rows[0]["lossinkg"].ToString(), 0);
                        if (!(num10 == 0.0))
                        {
                            num10 *= -1.0;
                        }
                        rep.Write("<td nowrap align=right>" + num10 + "</td>");
                    }
                }
                if (this.cBoxLossInPack.Checked)
                {
                    num10 = Program.StrToDouble(this.tbl_OS.DT.Rows[0]["lossinpack"].ToString(), 0);
                    if (!(num10 == 0.0))
                    {
                        num10 *= -1.0;
                    }
                    rep.Write("<td nowrap align=right>" + num10 + "</td>");
                }
                rep.Write("</tr>");
            }
            num7++;
            this.labelRecNo.Text = num4.ToString() + " / " + this.jlhRecord.ToString();
            this.labelRecNo.Refresh();
            rep.Write("</table>");
            rep.Write("<br>");
            rep.Write("<br>");
            rep.Write("<br>");
            rep.writeSign();
            rep.Close();
            ViewReport report = new ViewReport {
                webBrowser1 = { Url = new Uri("file:///" + rep.File) }
            };
            report.ShowDialog();
            rep.Dispose();
            report.Dispose();
        }

        private void RepOsDoVendor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepOsDoVendor_Load(object sender, EventArgs e)
        {
            this.rboAll.Checked = true;
            this.tblRelation.OpenTable("wb_relation", "Select * From wb_relation", WBData.conn);
            Program.AutoComp(this.tblRelation, "relation_code", this.textRelation);
        }

        private void textRelation_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }
    }
}

