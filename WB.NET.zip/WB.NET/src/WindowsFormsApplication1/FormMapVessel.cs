﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormMapVessel : Form
    {
        public string uniq;
        public WBTable vessel = new WBTable();
        public WBTable search_help = new WBTable();
        public WBTable tbl = new WBTable();
        public WBTable trans = new WBTable();
        public string pMode = "";
        private long qty;
        private long qty_header;
        private string transporter;
        private CheckBox headerCheckBox = new CheckBox();
        private CheckBox headerCheckBox_MapResult = new CheckBox();
        private IContainer components = null;
        private GroupBox groupBox1;
        private Label label3;
        private Label label2;
        private TextBox text_DO_Qty;
        private Label label1;
        private TextBox text_DO_Vessel;
        private GroupBox groupBox2;
        private Button btn_Delete;
        private Label labelMappingSearch;
        private TextBox text_DONo;
        private Button btn_Search;
        private DataGridView dGV_Map;
        private Button btn_Save;
        private Button btn_Cancel;
        private Button buttonDO;
        private Label label5;
        private TextBox text_Total;
        private Label label6;
        private CheckBox cb_completed;
        private Label label8;
        private Label label7;
        private NumericUpDown numeric_VesselMaxToleranceforSplitDO;
        private RadioButton radio_SplitAfterTolerance01;
        private RadioButton radio_SplitAfterTolerance02;
        private Label label10;
        private RadioButton radioMapSearch_PO;
        private RadioButton radioMapSearch_DO;
        private Label label9;
        private Button btn_Map_DO;
        private GroupBox groupBox3;
        private DataGridView dGV_MapResult;
        private RadioButton radioMapSearch_STO;
        private LinkLabel linkLabel1;

        public FormMapVessel()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (!this.can_modify_mapping(this.text_DO_Vessel.Text.Trim()))
            {
                MessageBox.Show(Resource.Mes_Warning_Error_Cannot_Add_Vessel_Map, Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                bool flag = false;
                WBTable table = new WBTable();
                foreach (DataGridViewRow row in (IEnumerable) this.dGV_Map.Rows)
                {
                    string str = "";
                    bool flag3 = true;
                    string str2 = row.Cells["DO_NO"].Value.ToString();
                    DataGridViewCheckBoxCell cell = row.Cells["checkBoxColumn"] as DataGridViewCheckBoxCell;
                    if ((cell.Value != null) && (cell.Value.ToString().ToLower() == "true"))
                    {
                        table.OpenTable("wb_contract", this.getQuery("DO_NO", false, str2), WBData.conn);
                        DataRow row2 = table.DT.Rows[0];
                        if (row2["zAuto"].ToString() == "Y")
                        {
                            str = Resource.Mes_354;
                            flag = true;
                            flag3 = false;
                        }
                        if ((WBSetting.Field("GM") == "Y") && (row2["completedGRCust"].ToString() == "N"))
                        {
                            str = Resource.Mes_064;
                            flag = true;
                            flag3 = false;
                        }
                        if (this.dGV_MapResult.Rows.Count == 0)
                        {
                            this.transporter = row2["transporter_code"].ToString().Trim();
                        }
                        else if ((this.dGV_MapResult.Rows.Count > 0) && (this.transporter != row2["transporter_code"].ToString().Trim()))
                        {
                            str = Resource.Mes_Warning_Different_Transporter_Code;
                            flag3 = false;
                        }
                        WBTable table2 = new WBTable();
                        string[] textArray1 = new string[] { "SELECT uniq_item, qty_map from wb_vessel_map WHERE uniq_vessel <> '", this.uniq, "' AND uniq_item = '", row2["uniq_item"].ToString(), "'" };
                        table2.OpenTable("wb_vessel_map", string.Concat(textArray1), WBData.conn);
                        long num = long.Parse(row2["Quantity"].ToString());
                        string str3 = num.ToString("n0");
                        long num2 = 0L;
                        string str4 = num2.ToString("n0");
                        if (table2.DT.Rows.Count == 0)
                        {
                            num2 = 0L;
                        }
                        else
                        {
                            foreach (DataRow row3 in table2.DT.Rows)
                            {
                                num2 += long.Parse(row3["qty_map"].ToString());
                            }
                            str4 = num2.ToString("n0");
                            if (num2 == num)
                            {
                                str = Resource.Mes_Info_Full_Map_DO_Vessel + "\n" + Resource.Mes_Info_Full_Map_DO_Vessel_2;
                                flag = true;
                                flag3 = false;
                            }
                            else
                            {
                                string[] textArray2 = new string[9];
                                textArray2[0] = Resource.Mes_Info_Map_DO_Vessel;
                                textArray2[1] = "\n";
                                textArray2[2] = Resource.Mes_Info_Map_DO_Vessel_2;
                                textArray2[3] = ": ";
                                textArray2[4] = str4;
                                textArray2[5] = "\n";
                                textArray2[6] = Resource.Mes_Info_Map_DO_Vessel_3;
                                textArray2[7] = ": ";
                                textArray2[8] = str3;
                                str = string.Concat(textArray2);
                                flag = false;
                                flag3 = true;
                            }
                        }
                        num2 = num - num2;
                        str4 = num2.ToString("n0");
                        if (!flag3)
                        {
                            row.Cells["validation_remark"].Value = str;
                            row.DefaultCellStyle.BackColor = Color.OrangeRed;
                        }
                        else
                        {
                            row.Cells["validation_remark"].Value = string.IsNullOrEmpty(str) ? "OK" : str;
                            int num3 = 0;
                            num3 = this.getIndexOfExistingMappedResult(str2);
                            if (num3 >= 0)
                            {
                                row.Cells["validation_remark"].Value = "Mapping data updated";
                            }
                            else
                            {
                                this.dGV_MapResult.Rows.Add();
                                num3 = this.dGV_MapResult.Rows.Count - 1;
                            }
                            this.dGV_MapResult.Rows[num3].Cells["uniq_vessel"].Value = this.uniq;
                            this.dGV_MapResult.Rows[num3].Cells["DO_NO"].Value = row2["DO_NO"].ToString();
                            this.dGV_MapResult.Rows[num3].Cells["Quantity"].Value = str3;
                            this.dGV_MapResult.Rows[num3].Cells["qty_map"].Value = str4;
                            this.dGV_MapResult.Rows[num3].Cells["os_max"].Value = num2;
                            this.dGV_MapResult.Rows[num3].Cells["uniq_item"].Value = row2["uniq_item"].ToString();
                            this.dGV_MapResult.Rows[num3].Cells["transporter_code"].Value = row2["transporter_code"].ToString();
                            row.DefaultCellStyle.BackColor = Color.LightGray;
                        }
                    }
                }
                table.Dispose();
                if (flag)
                {
                    this.dGV_MapResult.Rows.Clear();
                    MessageBox.Show(Resource.Mes_Warning_Error_Please_Check_Remark, Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                this.count_total();
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (!this.can_modify_mapping(this.text_DO_Vessel.Text.Trim()))
            {
                MessageBox.Show(Resource.Mes_Warning_Error_Cannot_Delete_Vessel_Map, Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                if (this.dGV_MapResult.Rows.Count > 0)
                {
                    int num = this.dGV_MapResult.Rows.Count - 1;
                    while (true)
                    {
                        if (num < 0)
                        {
                            break;
                        }
                        DataGridViewCheckBoxCell cell = this.dGV_MapResult.Rows[num].Cells["checkBoxColumn_delete"] as DataGridViewCheckBoxCell;
                        if ((cell.Value != null) && (cell.Value.ToString().ToLower() == "true"))
                        {
                            this.dGV_MapResult.Rows.Remove(this.dGV_MapResult.Rows[num]);
                        }
                        num--;
                    }
                }
                this.count_total();
            }
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (this.can_save())
            {
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                if (this.pMode == "EDIT_PERCENTAGE_TOLERANCE")
                {
                    object[] objArray1 = new object[] { "UPDATE wb_contract SET transporter_code ='", this.transporter, "', VesselLimitTolerance = '", this.numeric_VesselMaxToleranceforSplitDO.Value, "' WHERE uniq = '", this.uniq, "'" };
                    table2.OpenTable("wb_contract", string.Concat(objArray1), WBData.conn);
                    base.Dispose();
                }
                else
                {
                    table2.OpenTable("wb_vessel_map", "DELETE FROM wb_vessel_map WHERE uniq_vessel ='" + this.uniq + "'", WBData.conn);
                    table.OpenTable("wb_vessel_map", "SELECT * FROM wb_vessel_map", WBData.conn);
                    bool flag3 = false;
                    WBTable table3 = new WBTable();
                    foreach (DataGridViewRow row in (IEnumerable) this.dGV_MapResult.Rows)
                    {
                        table.ReOpen();
                        table.DR = table.DT.NewRow();
                        table.DR["Coy"] = WBData.sCoyCode;
                        table.DR["Location_Code"] = WBData.sLocCode;
                        table.DR["uniq_vessel"] = this.uniq;
                        table.DR["uniq_item"] = ((DataGridViewTextBoxCell) row.Cells["uniq_item"]).Value;
                        table.DR["qty_map"] = ((DataGridViewTextBoxCell) row.Cells["qty_map"]).Value;
                        bool flag4 = this.cb_completed.Checked;
                        table.DR["completed"] = !flag4 ? "" : "Y";
                        table.DT.Rows.Add(table.DR);
                        table.Save();
                        if (!flag3)
                        {
                            table3.OpenTable("wb_contract", "select * from wb_contract where uniq = '" + this.uniq + "'", WBData.conn);
                            if (table3.DT.Rows.Count > 0)
                            {
                                table3.DR = table3.DT.Rows[0];
                                table3.DR.BeginEdit();
                                table3.DR["Closed"] = !this.cb_completed.Checked ? ((object) DBNull.Value) : ((object) "X");
                                table3.DR.EndEdit();
                                table3.Save();
                            }
                            flag3 = true;
                        }
                        table3.OpenTable("wb_contract", "select * from wb_contract where uniq = '" + ((DataGridViewTextBoxCell) row.Cells["uniq_item"]).Value.ToString() + "'", WBData.conn);
                        if (table3.DT.Rows.Count > 0)
                        {
                            table3.DR = table3.DT.Rows[0];
                            table3.DR.BeginEdit();
                            table3.DR["Closed"] = !this.cb_completed.Checked ? ((object) DBNull.Value) : ((object) "X");
                            table3.DR.EndEdit();
                            table3.Save();
                        }
                    }
                    table3.Dispose();
                    string str = "0";
                    if (this.radio_SplitAfterTolerance02.Checked)
                    {
                        str = "1";
                    }
                    else if (this.radio_SplitAfterTolerance01.Checked)
                    {
                        str = "0";
                    }
                    object[] objArray2 = new object[9];
                    objArray2[0] = "UPDATE wb_contract SET transporter_code ='";
                    objArray2[1] = this.transporter;
                    objArray2[2] = "', VesselLimitTolerance = '";
                    objArray2[3] = this.numeric_VesselMaxToleranceforSplitDO.Value;
                    objArray2[4] = "', VesselAfterToleranceSplitMethod = '";
                    objArray2[5] = str;
                    objArray2[6] = "' WHERE uniq = '";
                    objArray2[7] = this.uniq;
                    objArray2[8] = "'";
                    table2.OpenTable("wb_contract", string.Concat(objArray2), WBData.conn);
                    base.Dispose();
                }
            }
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            WBTable table;
            if (!string.IsNullOrEmpty(this.text_DONo.Text.Trim()))
            {
                string sqltext = "";
                this.dGV_Map.Rows.Clear();
                this.headerCheckBox.Checked = false;
                if (this.radioMapSearch_DO.Checked)
                {
                    sqltext = this.getQuery("DO_NO", false, this.text_DONo.Text.Trim());
                }
                if (this.radioMapSearch_PO.Checked)
                {
                    sqltext = this.getQuery("PO", false, this.text_DONo.Text.Trim());
                }
                if (this.radioMapSearch_STO.Checked)
                {
                    sqltext = this.getQuery("STO", false, this.text_DONo.Text.Trim());
                }
                table = new WBTable();
                table.OpenTable("wb_contract", sqltext, WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    foreach (DataRow row in table.DT.Rows)
                    {
                        string str2 = long.Parse(row["Quantity"].ToString()).ToString("n0");
                        this.dGV_Map.Rows.Add();
                        this.dGV_Map.Rows[this.dGV_Map.Rows.Count - 1].Cells["DO_NO"].Value = row["DO_NO"].ToString();
                        this.dGV_Map.Rows[this.dGV_Map.Rows.Count - 1].Cells["Quantity"].Value = str2;
                    }
                }
            }
            else
            {
                return;
            }
            table.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonDO_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFind = this.text_DONo.Text.Trim()
            };
            contract.ShowDialog();
            this.text_DONo.Text = (contract.ReturnRow == null) ? "" : contract.ReturnRow["Do_NO"].ToString();
            contract.Dispose();
        }

        private bool can_modify_mapping(string do_ayah)
        {
            bool flag = true;
            string sqltext = "";
            string str2 = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_contract", "select * from wb_contract where do_no = '" + do_ayah + "'", WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                str2 = table.DT.Rows[0]["uniq"].ToString();
            }
            sqltext = "select * from wb_vessel_map a\r\n            inner join wb_contract b on\r\n            a.uniq_item = b.uniq\r\n            inner join wb_transaction c on\r\n            b.do_no = c.do_no\r\n            where a.uniq_vessel = '" + str2 + "' and (c.deleted is null or c.Deleted <> 'Y') and(c.mark_accident is null or c.mark_accident <> 'X')";
            table.OpenTable("wb_vessel_map", sqltext, WBData.conn);
            flag = table.DT.Rows.Count <= 0;
            table.Dispose();
            return flag;
        }

        private bool can_save()
        {
            bool flag = true;
            if (this.pMode == "EDIT_PERCENTAGE_TOLERANCE")
            {
                long num = this.getTotalWeighedNet(this.text_DO_Vessel.Text.Trim());
                long num2 = Convert.ToInt64(this.vessel.DT.Rows[0]["Quantity"].ToString());
                long num3 = num - num2;
                double num4 = (((double) num3) / ((double) num2)) * 100.0;
                double num5 = Math.Ceiling((double) (100.0 - (-1.0 * num4)));
                if (Program.StrToDouble(this.numeric_VesselMaxToleranceforSplitDO.Value.ToString(), 0) > num5)
                {
                    string[] textArray1 = new string[] { num.ToString(), num3.ToString(), Program.StrToDouble(num4.ToString(), 2).ToString(), Program.StrToDouble(num5.ToString(), 2).ToString() };
                    MessageBox.Show(string.Format(Resource.DOMapVessel_004, (object[]) textArray1), Resource.Mes_Error_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    flag = false;
                }
            }
            else
            {
                if (this.qty_header != this.qty)
                {
                    flag = false;
                    MessageBox.Show(Resource.Mes_Error_Qty_Vessel_Not_Equal, Resource.Mes_Error_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                if (this.dGV_MapResult.Rows.Count == 1)
                {
                    flag = false;
                    MessageBox.Show(Resource.Mes_Error_Vessel_DO_Empty, Resource.Mes_Error_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                if (flag)
                {
                    foreach (DataGridViewRow row in (IEnumerable) this.dGV_MapResult.Rows)
                    {
                        string s = ((DataGridViewTextBoxCell) row.Cells["qty_map"]).Value.ToString().Replace(",", "").Replace(".", "");
                        long num8 = long.Parse(s);
                        long num9 = long.Parse(((DataGridViewTextBoxCell) row.Cells["os_max"]).Value.ToString());
                        if (num8 > num9)
                        {
                            flag = false;
                            string[] textArray2 = new string[] { Resource.Mes_Error_DO_Check_Max_Qty, " ", ((DataGridViewTextBoxCell) row.Cells["do_no"]).Value.ToString(), "\n", Resource.Mes_Error_DO_Check_Max_Qty_2, ": ", ((DataGridViewTextBoxCell) row.Cells["os_max"]).Value.ToString() };
                            MessageBox.Show(string.Concat(textArray2), Resource.Mes_Error_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                }
            }
            return flag;
        }

        private void cb_completed_CheckedChanged(object sender, EventArgs e)
        {
            WBTable table;
            if (!this.cb_completed.Checked)
            {
                if (this.dGV_MapResult.Rows.Count <= 0)
                {
                    goto TR_0003;
                }
                else
                {
                    table = new WBTable();
                    string sqltext = "";
                    string[] textArray1 = new string[9];
                    textArray1[0] = "select TOP(1) * from wb_transaction q\r\n                        where Coy = '";
                    textArray1[1] = WBData.sCoyCode;
                    textArray1[2] = "' and Location_Code = '";
                    textArray1[3] = WBData.sLocCode;
                    textArray1[4] = "' and Do_No in (\r\n                        select do_no from wb_contract where uniq in \r\n                        (select uniq_item from wb_vessel_map where uniq_vessel = '";
                    textArray1[5] = this.uniq;
                    textArray1[6] = "') or uniq = '";
                    textArray1[7] = this.uniq;
                    textArray1[8] = "')AND((mark_accident IS NULL OR mark_accident <> 'Y') AND(Deleted IS NULL OR Deleted <> 'Y') AND(Split = 'Y' or Split = 'X') AND(REPORT_DATE is not null and REPORT_DATE <> ''))\r\n                        order by report_date desc, ref desc";
                    sqltext = string.Concat(textArray1);
                    table.OpenTable("wb_transaction", sqltext, WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        goto TR_0004;
                    }
                    else
                    {
                        string str2 = table.DT.Rows[0]["uniq"].ToString();
                        double num = 0.0;
                        double num2 = this.getTotalQtyDOAnakAMSTolerance();
                        string[] textArray2 = new string[11];
                        textArray2[0] = "select (\r\n                                        select ISNULL(SUM(Net), '') as Total_Netto from wb_transaction trx_1\r\n                                                    where Coy = '";
                        textArray2[1] = WBData.sCoyCode;
                        textArray2[2] = "' and Location_Code = '";
                        textArray2[3] = WBData.sLocCode;
                        textArray2[4] = "' and Do_No in (\r\n                                                    select do_no from wb_contract where uniq in \r\n                                                    (select uniq_item from wb_vessel_map where uniq_vessel = '";
                        textArray2[5] = this.uniq;
                        textArray2[6] = "') or uniq = '";
                        textArray2[7] = this.uniq;
                        textArray2[8] = "')\r\n                                                    AND((mark_accident IS NULL OR mark_accident <> 'Y') AND(Deleted IS NULL OR Deleted <> 'Y') AND(REPORT_DATE is not null and REPORT_DATE <> '')\r\n\r\n                                                    AND((trx_1.Report_Date = trx_2.Report_Date and trx_2.Ref >= trx_1.ref ) OR(trx_2.Report_Date > trx_1.report_date))))\r\n\t                            from wb_transaction trx_2\r\n                                where trx_2.uniq = '";
                        textArray2[9] = str2;
                        textArray2[10] = "'";
                        sqltext = string.Concat(textArray2);
                        table.OpenTable("wb_transaction", sqltext, WBData.conn);
                        if (table.DT.Rows.Count > 0)
                        {
                            table.DR = table.DT.Rows[0];
                            if (!string.IsNullOrEmpty(table.DR["Column1"].ToString()) && (table.DR["Column1"].ToString() != "0"))
                            {
                                num = Program.StrToDouble(table.DR["Column1"].ToString(), 0);
                                if (num > num2)
                                {
                                    string[] textArray3 = new string[] { num.ToString(), num2.ToString() };
                                    MessageBox.Show(string.Format(Resource.DOMapVessel_003, (object[]) textArray3), Resource.Mes_Error_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    this.cb_completed.CheckedChanged -= new EventHandler(this.cb_completed_CheckedChanged);
                                    this.cb_completed.Checked = true;
                                    this.cb_completed.CheckedChanged += new EventHandler(this.cb_completed_CheckedChanged);
                                    table.Dispose();
                                    return;
                                }
                            }
                        }
                        goto TR_0004;
                    }
                }
            }
            else
            {
                this.btn_Map_DO.Enabled = false;
                this.btn_Delete.Enabled = false;
                this.radio_SplitAfterTolerance01.Enabled = false;
                this.radio_SplitAfterTolerance02.Enabled = false;
                MessageBox.Show(Resource.DOMapVessel_001, Resource.Mes_Notice, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            return;
        TR_0003:
            this.btn_Map_DO.Enabled = true;
            this.btn_Delete.Enabled = true;
            this.radio_SplitAfterTolerance01.Enabled = true;
            this.radio_SplitAfterTolerance02.Enabled = true;
            MessageBox.Show(Resource.DOMapVessel_002, Resource.Mes_Notice, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            return;
        TR_0004:
            table.Dispose();
            goto TR_0003;
        }

        private void count_total()
        {
            char[] chArray = new char[] { '*', ' ', '.', ',' };
            this.qty = 0L;
            foreach (DataGridViewRow row in (IEnumerable) this.dGV_MapResult.Rows)
            {
                string str = ((DataGridViewTextBoxCell) row.Cells["qty_map"]).Value.ToString().Replace(",", "").Replace(".", "");
                this.qty += long.Parse(str.Trim());
            }
            this.text_Total.Text = this.qty.ToString("n0");
        }

        private void dGV_MapResult_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            this.count_total();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editControls(string pMode)
        {
            if (pMode != "EDIT_PERCENTAGE_TOLERANCE")
            {
                this.numeric_VesselMaxToleranceforSplitDO.Enabled = false;
                foreach (Control control3 in this.numeric_VesselMaxToleranceforSplitDO.Controls)
                {
                    control3.Enabled = false;
                }
            }
            else
            {
                foreach (Control control in this.GetOffsprings())
                {
                    if ((control.GetType() != typeof(Label)) && (control.GetType() != typeof(TabControl)))
                    {
                        control.Enabled = false;
                    }
                }
                this.groupBox1.Enabled = true;
                this.numeric_VesselMaxToleranceforSplitDO.Enabled = true;
                foreach (Control control2 in this.numeric_VesselMaxToleranceforSplitDO.Controls)
                {
                    control2.Enabled = true;
                }
            }
            this.btn_Save.Enabled = true;
            this.btn_Cancel.Enabled = true;
        }

        private void FormMapVessel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormMapVessel_Load(object sender, EventArgs e)
        {
            this.editControls(this.pMode);
            this.search_help.OpenTable("wb_contract", this.getQuery("DO_NO", true, null), WBData.conn);
            this.tbl.OpenTable("wb_vessel_map", "SELECT uniq_item, qty_map, completed from wb_vessel_map where uniq_vessel = '" + this.uniq + "'", WBData.conn);
            if (this.tbl.DT.Rows.Count == 0)
            {
                this.tbl.OpenTable("wb_contract", "SELECT Do_No, Quantity, Quantity AS qty_map, Quantity AS os_max, uniq as uniq_item, uniq as uniq_vessel, transporter_code from wb_contract where 1 = 2", WBData.conn);
            }
            else
            {
                this.cb_completed.CheckedChanged -= new EventHandler(this.cb_completed_CheckedChanged);
                this.cb_completed.Checked = this.tbl.DT.Rows[0]["completed"].ToString() == "Y";
                this.cb_completed.CheckedChanged += new EventHandler(this.cb_completed_CheckedChanged);
                if (this.cb_completed.Checked)
                {
                    this.radio_SplitAfterTolerance01.Enabled = false;
                    this.radio_SplitAfterTolerance02.Enabled = false;
                }
                else
                {
                    this.radio_SplitAfterTolerance01.Enabled = true;
                    this.radio_SplitAfterTolerance02.Enabled = true;
                }
                string sqltext = ("SELECT c.Do_No, c.Quantity, m.qty_map, c.Quantity AS os_max, c.uniq AS uniq_item, c.transporter_code, " + this.uniq + " AS uniq_vessel FROM wb_vessel_map m ") + "LEFT JOIN wb_contract c ON m.uniq_item = c.uniq WHERE uniq_vessel = '" + this.uniq + "'";
                this.tbl.OpenTable("wb_contract", sqltext, WBData.conn);
                this.transporter = this.tbl.DT.Rows[0]["transporter_code"].ToString();
                if (this.pMode != "EDIT_PERCENTAGE_TOLERANCE")
                {
                    this.numeric_VesselMaxToleranceforSplitDO.Enabled = false;
                }
            }
            if (this.search_help.DT.Rows.Count > 0)
            {
                Program.AutoComp(this.search_help, "Do_No", this.text_DONo);
            }
            this.vessel.OpenTable("wb_contract", "SELECT * FROM wb_contract WHERE uniq = '" + this.uniq + "'", WBData.conn);
            this.text_DO_Vessel.Text = this.vessel.DT.Rows[0]["Do_No"].ToString();
            this.text_DO_Qty.Text = long.Parse(this.vessel.DT.Rows[0]["Quantity"].ToString()).ToString("n0");
            this.numeric_VesselMaxToleranceforSplitDO.Value = !string.IsNullOrEmpty(this.vessel.DT.Rows[0]["VesselLimitTolerance"].ToString()) ? Convert.ToDecimal(this.vessel.DT.Rows[0]["VesselLimitTolerance"].ToString()) : this.load_WBLocation_VesselLimitTolerance();
            if (this.vessel.DT.Rows[0]["VesselAfterToleranceSplitMethod"].ToString() == "1")
            {
                this.radio_SplitAfterTolerance02.Checked = true;
            }
            else
            {
                this.radio_SplitAfterTolerance01.Checked = true;
            }
            this.btn_Save.Enabled = true;
            try
            {
                if (this.vessel.DT.Rows[0]["closed"].ToString() == "X")
                {
                    MessageBox.Show(this.text_DO_Vessel.Text + " " + Resource.Mes_Warning_Save_Closed_DO, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.btn_Save.Enabled = false;
                }
            }
            catch
            {
            }
            this.qty_header = long.Parse(this.vessel.DT.Rows[0]["Quantity"].ToString());
            this.dGV_Map.ColumnCount = 3;
            this.dGV_Map.Columns[0].Name = "do_no";
            this.dGV_Map.Columns[1].Name = "quantity";
            this.dGV_Map.Columns[2].Name = "validation_remark";
            this.dGV_Map.Columns["do_no"].ReadOnly = true;
            this.dGV_Map.Columns["do_no"].HeaderText = Resource.Contract_002;
            this.dGV_Map.Columns["do_no"].Width = 0x7d;
            this.dGV_Map.Columns["quantity"].HeaderText = Resource.Col_DO_Qty;
            this.dGV_Map.Columns["quantity"].DefaultCellStyle.Format = "n0";
            this.dGV_Map.Columns["quantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dGV_Map.Columns["quantity"].ReadOnly = true;
            this.dGV_Map.Columns["validation_remark"].HeaderText = Resource.Contract_030;
            this.dGV_Map.Columns["validation_remark"].ReadOnly = true;
            this.dGV_Map.Columns["validation_remark"].Width = 150;
            this.dGV_Map.DefaultCellStyle.BackColor = Color.LightGray;
            Point location = this.dGV_Map.GetCellDisplayRectangle(0, -1, true).Location;
            this.headerCheckBox.Location = new Point(location.X + 8, location.Y + 2);
            this.headerCheckBox.BackColor = Color.White;
            this.headerCheckBox.Size = new Size(0x12, 0x12);
            this.headerCheckBox.Click += new EventHandler(this.HeaderCheckBox_Clicked);
            this.dGV_Map.Controls.Add(this.headerCheckBox);
            DataGridViewCheckBoxColumn dataGridViewColumn = new DataGridViewCheckBoxColumn {
                HeaderText = "",
                Width = 30,
                Name = "checkBoxColumn"
            };
            this.dGV_Map.Columns.Insert(0, dataGridViewColumn);
            this.dGV_MapResult.ColumnCount = this.tbl.DT.Columns.Count;
            int num2 = 0;
            while (true)
            {
                if (num2 >= this.tbl.DT.Columns.Count)
                {
                    this.dGV_MapResult.Columns["do_no"].ReadOnly = true;
                    this.dGV_MapResult.Columns["do_no"].HeaderText = Resource.Contract_002;
                    this.dGV_MapResult.Columns["uniq_item"].Visible = false;
                    this.dGV_MapResult.Columns["uniq_vessel"].Visible = false;
                    this.dGV_MapResult.Columns["os_max"].Visible = false;
                    this.dGV_MapResult.Columns["quantity"].HeaderText = Resource.Col_DO_Qty;
                    this.dGV_MapResult.Columns["quantity"].DefaultCellStyle.Format = "n0";
                    this.dGV_MapResult.Columns["quantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dGV_MapResult.Columns["quantity"].ReadOnly = true;
                    this.dGV_MapResult.DefaultCellStyle.BackColor = Color.LightGray;
                    this.dGV_MapResult.Columns["qty_map"].HeaderText = Resource.Col_Qty_Used;
                    this.dGV_MapResult.Columns["qty_map"].DefaultCellStyle.Format = "n0";
                    this.dGV_MapResult.Columns["qty_map"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dGV_MapResult.Columns["qty_map"].DefaultCellStyle.BackColor = Color.LightGreen;
                    this.dGV_MapResult.Columns["transporter_code"].HeaderText = Resource.Contract_017;
                    this.dGV_MapResult.Columns["transporter_code"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                    this.dGV_MapResult.Columns["transporter_code"].ReadOnly = true;
                    this.dGV_MapResult.DefaultCellStyle.BackColor = Color.LightGray;
                    this.dGV_MapResult = this.tbl.ToDGV(this.dGV_MapResult);
                    this.headerCheckBox_MapResult.Location = new Point(location.X + 8, location.Y + 8);
                    this.headerCheckBox_MapResult.BackColor = Color.White;
                    this.headerCheckBox_MapResult.Size = new Size(0x12, 0x12);
                    this.headerCheckBox_MapResult.Click += new EventHandler(this.HeaderCheckBox_MapResult_Clicked);
                    this.dGV_MapResult.Controls.Add(this.headerCheckBox_MapResult);
                    DataGridViewCheckBoxColumn column2 = new DataGridViewCheckBoxColumn {
                        HeaderText = "",
                        Width = 30,
                        Name = "checkBoxColumn_delete"
                    };
                    this.dGV_MapResult.Columns.Insert(0, column2);
                    this.count_total();
                    return;
                }
                this.dGV_MapResult.Columns[num2].Name = this.tbl.DT.Columns[num2].ColumnName;
                num2++;
            }
        }

        private int getIndexOfExistingMappedResult(string do_no)
        {
            int index = -1;
            foreach (DataGridViewRow row in (IEnumerable) this.dGV_MapResult.Rows)
            {
                if (row.Cells["DO_NO"].Value.ToString() == do_no)
                {
                    index = row.Index;
                    break;
                }
            }
            return index;
        }

        private string getQuery(string mode, bool is_for_autocomplete, string filter_key = null)
        {
            string str = "";
            string str2 = "";
            string str3 = "";
            if ((mode == "DO_NO") || !is_for_autocomplete)
            {
                str3 = "Do_No, Quantity, zauto, completedgrcust, transporter_code, c.uniq AS uniq_item";
            }
            else if (is_for_autocomplete)
            {
                if (mode == "PO")
                {
                    str3 = "DISTINCT PO";
                }
                else if (mode == "STO")
                {
                    str3 = "DISTINCT STO";
                }
            }
            if (!string.IsNullOrEmpty(filter_key))
            {
                if (filter_key.Contains("*"))
                {
                    string[] textArray1 = new string[] { str2, "AND c.", mode, " LIKE '%", filter_key.Substring(0, filter_key.IndexOf('*')), "%'" };
                    str2 = string.Concat(textArray1);
                }
                else
                {
                    string[] textArray2 = new string[] { str2, "AND c.", mode, " = '", filter_key, "'" };
                    str2 = string.Concat(textArray2);
                }
            }
            string[] textArray3 = new string[12];
            textArray3[0] = "SELECT ";
            textArray3[1] = str3;
            textArray3[2] = " FROM wb_contract AS c LEFT JOIN wb_transaction_type AS m ON c.Transaction_Code = m.Transaction_Code WHERE (closed IS NULL or closed <> 'X' or closed = 'N') and zAuto = 'N' AND (m.is_vessel is null OR m.is_vessel = '' OR m.is_vessel = 'N') AND c.Coy = '";
            textArray3[3] = WBData.sCoyCode;
            textArray3[4] = "' AND m.Coy = '";
            textArray3[5] = WBData.sCoyCode;
            textArray3[6] = "' AND c.Location_Code = '";
            textArray3[7] = WBData.sLocCode;
            textArray3[8] = "' AND m.Location_Code = '";
            textArray3[9] = WBData.sLocCode;
            textArray3[10] = "' ";
            textArray3[11] = str2;
            str = string.Concat(textArray3);
            if ((mode == "DO_NO") || !is_for_autocomplete)
            {
                str = str + "ORDER BY Do_No";
            }
            return str;
        }

        private double getTotalQtyDOAnakAMSTolerance() => 
            Program.StrToDouble(((Convert.ToInt64(this.vessel.DT.Rows[0]["Quantity"].ToString()) * Program.StrToDouble(this.numeric_VesselMaxToleranceforSplitDO.Value.ToString(), 0)) / 100.0).ToString(), 0);

        private long getTotalWeighedNet(string do_ayah)
        {
            long num = 0L;
            string str = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_contract", "select * from wb_contract where do_no = '" + do_ayah + "'", WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                str = table.DT.Rows[0]["uniq"].ToString();
            }
            if (!string.IsNullOrEmpty(str))
            {
                string[] textArray1 = new string[9];
                textArray1[0] = "select Sum(Net) as TotalWeighedNet from wb_transaction\r\n                                      where Coy = '";
                textArray1[1] = WBData.sCoyCode;
                textArray1[2] = "' and Location_Code = '";
                textArray1[3] = WBData.sLocCode;
                textArray1[4] = "' and Do_No in (\r\n                                      select do_no from wb_contract where uniq in \r\n                                      (select uniq_item from wb_vessel_map where uniq_vessel = '";
                textArray1[5] = str;
                textArray1[6] = "') or uniq = '";
                textArray1[7] = str;
                textArray1[8] = "')\r\n                                      AND((mark_accident IS NULL) AND(Deleted IS NULL) AND\r\n                                    (Report_Date IS NOT NULL) OR(mark_accident = '') AND(Deleted = ''))";
                string sqltext = string.Concat(textArray1);
                table.OpenTable("wb_vessel_map", sqltext, WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    num = Convert.ToInt64(table.DT.Rows[0]["TotalWeighedNet"].ToString());
                }
            }
            return num;
        }

        private void HeaderCheckBox_Clicked(object sender, EventArgs e)
        {
            this.dGV_Map.EndEdit();
            foreach (DataGridViewRow row in (IEnumerable) this.dGV_Map.Rows)
            {
                DataGridViewCheckBoxCell cell = row.Cells["checkBoxColumn"] as DataGridViewCheckBoxCell;
                cell.Value = this.headerCheckBox.Checked;
            }
        }

        private void HeaderCheckBox_MapResult_Clicked(object sender, EventArgs e)
        {
            this.dGV_MapResult.EndEdit();
            foreach (DataGridViewRow row in (IEnumerable) this.dGV_MapResult.Rows)
            {
                DataGridViewCheckBoxCell cell = row.Cells["checkBoxColumn_delete"] as DataGridViewCheckBoxCell;
                cell.Value = this.headerCheckBox_MapResult.Checked;
            }
        }

        private void InitializeComponent()
        {
            this.groupBox1 = new GroupBox();
            this.linkLabel1 = new LinkLabel();
            this.radio_SplitAfterTolerance01 = new RadioButton();
            this.radio_SplitAfterTolerance02 = new RadioButton();
            this.label10 = new Label();
            this.numeric_VesselMaxToleranceforSplitDO = new NumericUpDown();
            this.label8 = new Label();
            this.label7 = new Label();
            this.label3 = new Label();
            this.label2 = new Label();
            this.text_DO_Qty = new TextBox();
            this.label1 = new Label();
            this.text_DO_Vessel = new TextBox();
            this.groupBox2 = new GroupBox();
            this.radioMapSearch_STO = new RadioButton();
            this.radioMapSearch_PO = new RadioButton();
            this.radioMapSearch_DO = new RadioButton();
            this.label9 = new Label();
            this.btn_Map_DO = new Button();
            this.buttonDO = new Button();
            this.labelMappingSearch = new Label();
            this.text_DONo = new TextBox();
            this.btn_Search = new Button();
            this.dGV_Map = new DataGridView();
            this.label6 = new Label();
            this.label5 = new Label();
            this.text_Total = new TextBox();
            this.btn_Delete = new Button();
            this.btn_Save = new Button();
            this.btn_Cancel = new Button();
            this.cb_completed = new CheckBox();
            this.groupBox3 = new GroupBox();
            this.dGV_MapResult = new DataGridView();
            this.groupBox1.SuspendLayout();
            this.numeric_VesselMaxToleranceforSplitDO.BeginInit();
            this.groupBox2.SuspendLayout();
            ((ISupportInitialize) this.dGV_Map).BeginInit();
            this.groupBox3.SuspendLayout();
            ((ISupportInitialize) this.dGV_MapResult).BeginInit();
            base.SuspendLayout();
            this.groupBox1.Controls.Add(this.linkLabel1);
            this.groupBox1.Controls.Add(this.radio_SplitAfterTolerance01);
            this.groupBox1.Controls.Add(this.radio_SplitAfterTolerance02);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.numeric_VesselMaxToleranceforSplitDO);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.text_DO_Qty);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.text_DO_Vessel);
            this.groupBox1.Location = new Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(460, 0x9e);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Vessel Information";
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new Point(320, 12);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new Size(0x84, 13);
            this.linkLabel1.TabIndex = 12;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Click here for User Manual";
            this.linkLabel1.LinkClicked += new LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            this.radio_SplitAfterTolerance01.AutoSize = true;
            this.radio_SplitAfterTolerance01.Checked = true;
            this.radio_SplitAfterTolerance01.Location = new Point(0xd8, 0x6b);
            this.radio_SplitAfterTolerance01.Name = "radio_SplitAfterTolerance01";
            this.radio_SplitAfterTolerance01.Size = new Size(140, 0x11);
            this.radio_SplitAfterTolerance01.TabIndex = 0x10;
            this.radio_SplitAfterTolerance01.TabStop = true;
            this.radio_SplitAfterTolerance01.Text = "Proportionate Gain/Loss";
            this.radio_SplitAfterTolerance01.UseVisualStyleBackColor = true;
            this.radio_SplitAfterTolerance02.AutoSize = true;
            this.radio_SplitAfterTolerance02.Location = new Point(0xd8, 0x80);
            this.radio_SplitAfterTolerance02.Name = "radio_SplitAfterTolerance02";
            this.radio_SplitAfterTolerance02.Size = new Size(0x5b, 0x11);
            this.radio_SplitAfterTolerance02.TabIndex = 14;
            this.radio_SplitAfterTolerance02.Text = "No Gain/Loss";
            this.radio_SplitAfterTolerance02.UseVisualStyleBackColor = true;
            this.label10.Location = new Point(50, 0x6a);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x9b, 0x12);
            this.label10.TabIndex = 0x10;
            this.label10.Text = "Split After Tolerance Method";
            this.label10.TextAlign = ContentAlignment.MiddleRight;
            this.numeric_VesselMaxToleranceforSplitDO.Location = new Point(0xd8, 80);
            this.numeric_VesselMaxToleranceforSplitDO.Name = "numeric_VesselMaxToleranceforSplitDO";
            this.numeric_VesselMaxToleranceforSplitDO.Size = new Size(0x51, 20);
            this.numeric_VesselMaxToleranceforSplitDO.TabIndex = 8;
            this.numeric_VesselMaxToleranceforSplitDO.TextAlign = HorizontalAlignment.Right;
            this.numeric_VesselMaxToleranceforSplitDO.KeyPress += new KeyPressEventHandler(this.numeric_VesselMaxToleranceforSplitDO_KeyPress);
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0x12f, 0x56);
            this.label8.Name = "label8";
            this.label8.Size = new Size(15, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "%";
            this.label7.Location = new Point(10, 0x51);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0xc3, 0x13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Max Tolerance for Split DO";
            this.label7.TextAlign = ContentAlignment.MiddleRight;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x12e, 60);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x16, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "KG";
            this.label2.Location = new Point(0x5b, 0x39);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x72, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "BL Quantity";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.text_DO_Qty.Location = new Point(0xd8, 0x36);
            this.text_DO_Qty.Name = "text_DO_Qty";
            this.text_DO_Qty.ReadOnly = true;
            this.text_DO_Qty.Size = new Size(0x51, 20);
            this.text_DO_Qty.TabIndex = 2;
            this.text_DO_Qty.TextAlign = HorizontalAlignment.Right;
            this.label1.Location = new Point(0x5b, 0x1f);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x72, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Vessel Name + BL No.";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.text_DO_Vessel.Location = new Point(0xd8, 0x1c);
            this.text_DO_Vessel.Name = "text_DO_Vessel";
            this.text_DO_Vessel.ReadOnly = true;
            this.text_DO_Vessel.Size = new Size(0xec, 20);
            this.text_DO_Vessel.TabIndex = 0;
            this.groupBox2.Controls.Add(this.radioMapSearch_STO);
            this.groupBox2.Controls.Add(this.radioMapSearch_PO);
            this.groupBox2.Controls.Add(this.radioMapSearch_DO);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.btn_Map_DO);
            this.groupBox2.Controls.Add(this.buttonDO);
            this.groupBox2.Controls.Add(this.labelMappingSearch);
            this.groupBox2.Controls.Add(this.text_DONo);
            this.groupBox2.Controls.Add(this.btn_Search);
            this.groupBox2.Controls.Add(this.dGV_Map);
            this.groupBox2.Location = new Point(12, 0xab);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(460, 0xed);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Mapping";
            this.radioMapSearch_STO.AutoSize = true;
            this.radioMapSearch_STO.Location = new Point(0xdf, 20);
            this.radioMapSearch_STO.Name = "radioMapSearch_STO";
            this.radioMapSearch_STO.Size = new Size(0x2f, 0x11);
            this.radioMapSearch_STO.TabIndex = 0x10;
            this.radioMapSearch_STO.Text = "STO";
            this.radioMapSearch_STO.UseVisualStyleBackColor = true;
            this.radioMapSearch_STO.CheckedChanged += new EventHandler(this.radioMapSearch_STO_CheckedChanged);
            this.radioMapSearch_PO.AutoSize = true;
            this.radioMapSearch_PO.Location = new Point(0x9c, 20);
            this.radioMapSearch_PO.Name = "radioMapSearch_PO";
            this.radioMapSearch_PO.Size = new Size(40, 0x11);
            this.radioMapSearch_PO.TabIndex = 15;
            this.radioMapSearch_PO.Text = "PO";
            this.radioMapSearch_PO.UseVisualStyleBackColor = true;
            this.radioMapSearch_PO.CheckedChanged += new EventHandler(this.radioMapSearch_PO_CheckedChanged);
            this.radioMapSearch_DO.AutoSize = true;
            this.radioMapSearch_DO.Checked = true;
            this.radioMapSearch_DO.Location = new Point(0x4f, 20);
            this.radioMapSearch_DO.Name = "radioMapSearch_DO";
            this.radioMapSearch_DO.Size = new Size(0x3a, 0x11);
            this.radioMapSearch_DO.TabIndex = 13;
            this.radioMapSearch_DO.TabStop = true;
            this.radioMapSearch_DO.Text = "DO No";
            this.radioMapSearch_DO.UseVisualStyleBackColor = true;
            this.radioMapSearch_DO.CheckedChanged += new EventHandler(this.radioMapSearch_DO_CheckedChanged);
            this.label9.Location = new Point(8, 0x13);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x44, 0x12);
            this.label9.TabIndex = 12;
            this.label9.Text = "Search by :";
            this.label9.TextAlign = ContentAlignment.MiddleRight;
            this.btn_Map_DO.Location = new Point(0x16d, 0xcf);
            this.btn_Map_DO.Name = "btn_Map_DO";
            this.btn_Map_DO.Size = new Size(0x57, 0x17);
            this.btn_Map_DO.TabIndex = 11;
            this.btn_Map_DO.Text = "Add";
            this.btn_Map_DO.UseVisualStyleBackColor = true;
            this.btn_Map_DO.Click += new EventHandler(this.btn_Add_Click);
            this.buttonDO.Location = new Point(0xb8, 0x29);
            this.buttonDO.Margin = new Padding(0);
            this.buttonDO.Name = "buttonDO";
            this.buttonDO.Size = new Size(0x17, 0x17);
            this.buttonDO.TabIndex = 7;
            this.buttonDO.Text = "...";
            this.buttonDO.UseVisualStyleBackColor = true;
            this.buttonDO.Visible = false;
            this.buttonDO.Click += new EventHandler(this.buttonDO_Click);
            this.labelMappingSearch.Location = new Point(10, 0x2e);
            this.labelMappingSearch.Name = "labelMappingSearch";
            this.labelMappingSearch.Size = new Size(0x2d, 13);
            this.labelMappingSearch.TabIndex = 5;
            this.labelMappingSearch.Text = "DO No";
            this.labelMappingSearch.TextAlign = ContentAlignment.MiddleRight;
            this.text_DONo.Location = new Point(0x3d, 0x2b);
            this.text_DONo.Name = "text_DONo";
            this.text_DONo.Size = new Size(120, 20);
            this.text_DONo.TabIndex = 0;
            this.text_DONo.KeyPress += new KeyPressEventHandler(this.text_DONo_KeyPress);
            this.btn_Search.Location = new Point(0xd7, 0x29);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new Size(0x3b, 0x17);
            this.btn_Search.TabIndex = 3;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = true;
            this.btn_Search.Click += new EventHandler(this.btn_Search_Click);
            this.dGV_Map.AllowUserToAddRows = false;
            this.dGV_Map.AllowUserToDeleteRows = false;
            this.dGV_Map.AllowUserToOrderColumns = true;
            this.dGV_Map.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_Map.Location = new Point(6, 0x45);
            this.dGV_Map.Name = "dGV_Map";
            this.dGV_Map.Size = new Size(0x1c0, 0x84);
            this.dGV_Map.TabIndex = 2;
            this.dGV_Map.CellEndEdit += new DataGridViewCellEventHandler(this.dGV_MapResult_CellEndEdit);
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xba, 0x99);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x16, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "KG";
            this.label5.Location = new Point(9, 0x99);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x2d, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Total";
            this.label5.TextAlign = ContentAlignment.MiddleRight;
            this.text_Total.Enabled = false;
            this.text_Total.Location = new Point(60, 150);
            this.text_Total.Name = "text_Total";
            this.text_Total.Size = new Size(120, 20);
            this.text_Total.TabIndex = 8;
            this.text_Total.TextAlign = HorizontalAlignment.Right;
            this.btn_Delete.Location = new Point(0x17a, 0x94);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new Size(0x4b, 0x17);
            this.btn_Delete.TabIndex = 6;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new EventHandler(this.btn_Delete_Click);
            this.btn_Save.Location = new Point(310, 0x256);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new Size(0x4b, 0x17);
            this.btn_Save.TabIndex = 4;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new EventHandler(this.btn_Save_Click);
            this.btn_Cancel.Location = new Point(0x187, 0x256);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new Size(0x4b, 0x17);
            this.btn_Cancel.TabIndex = 5;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new EventHandler(this.button4_Click);
            this.cb_completed.AutoSize = true;
            this.cb_completed.Location = new Point(0x12, 0x259);
            this.cb_completed.Name = "cb_completed";
            this.cb_completed.Size = new Size(0xa1, 0x11);
            this.cb_completed.TabIndex = 11;
            this.cb_completed.Text = "Vessel Discharge Completed";
            this.cb_completed.UseVisualStyleBackColor = true;
            this.cb_completed.CheckedChanged += new EventHandler(this.cb_completed_CheckedChanged);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.dGV_MapResult);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.text_Total);
            this.groupBox3.Controls.Add(this.btn_Delete);
            this.groupBox3.Location = new Point(13, 0x19e);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(460, 0xb3);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Mapped DO(s)";
            this.dGV_MapResult.AllowUserToAddRows = false;
            this.dGV_MapResult.AllowUserToDeleteRows = false;
            this.dGV_MapResult.AllowUserToOrderColumns = true;
            this.dGV_MapResult.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_MapResult.Location = new Point(6, 0x13);
            this.dGV_MapResult.Name = "dGV_MapResult";
            this.dGV_MapResult.Size = new Size(0x1c0, 0x7d);
            this.dGV_MapResult.TabIndex = 2;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1e4, 0x275);
            base.Controls.Add(this.groupBox3);
            base.Controls.Add(this.cb_completed);
            base.Controls.Add(this.btn_Cancel);
            base.Controls.Add(this.btn_Save);
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.groupBox1);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormMapVessel";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "DO Vessel Mapping";
            base.Load += new EventHandler(this.FormMapVessel_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormMapVessel_KeyPress);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.numeric_VesselMaxToleranceforSplitDO.EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((ISupportInitialize) this.dGV_Map).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((ISupportInitialize) this.dGV_MapResult).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            WBManual.LoadManual("DO_VESSEL");
        }

        private int load_WBLocation_VesselLimitTolerance()
        {
            int num = 0;
            WBTable table = new WBTable();
            table.OpenTable("wb_location", "select VesselLimitTolerance from wb_location WHERE" + WBData.CompanyLocation(""), WBData.conn);
            if ((table.DT != null) && (table.DT.Rows.Count > 0))
            {
                try
                {
                    num = string.IsNullOrEmpty(table.DT.Rows[0]["VesselLimitTolerance"].ToString()) ? 0 : Convert.ToInt32(table.DT.Rows[0]["VesselLimitTolerance"].ToString());
                }
                catch (Exception)
                {
                    num = 0;
                }
            }
            return num;
        }

        private void numeric_VesselMaxToleranceforSplitDO_KeyPress(object sender, KeyPressEventArgs e)
        {
            WBUtility.NumberDecimalSeparator(e);
        }

        private void radioMapSearch_Change(int i)
        {
            if (i == 0)
            {
                this.labelMappingSearch.Text = Resource.Contract_002;
                this.buttonDO.Visible = false;
                this.search_help.OpenTable("wb_contract", this.getQuery("DO_NO", true, null), WBData.conn);
                if (this.search_help.DT.Rows.Count > 0)
                {
                    Program.AutoComp(this.search_help, "Do_No", this.text_DONo);
                }
            }
            else if (i == 1)
            {
                this.labelMappingSearch.Text = Resource.Contract_026;
                this.buttonDO.Visible = false;
                this.search_help.OpenTable("wb_contract", this.getQuery("PO", true, null), WBData.conn);
                if (this.search_help.DT.Rows.Count > 0)
                {
                    Program.AutoComp(this.search_help, "PO", this.text_DONo);
                }
            }
            else if (i == 2)
            {
                this.labelMappingSearch.Text = Resource.ContractE_013;
                this.buttonDO.Visible = false;
                this.search_help.OpenTable("wb_contract", this.getQuery("STO", true, null), WBData.conn);
                if (this.search_help.DT.Rows.Count > 0)
                {
                    Program.AutoComp(this.search_help, "STO", this.text_DONo);
                }
            }
        }

        private void radioMapSearch_DO_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioMapSearch_DO.Checked)
            {
                this.radioMapSearch_Change(0);
            }
        }

        private void radioMapSearch_PO_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioMapSearch_PO.Checked)
            {
                this.radioMapSearch_Change(1);
            }
        }

        private void radioMapSearch_STO_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioMapSearch_STO.Checked)
            {
                this.radioMapSearch_Change(2);
            }
        }

        private void text_DONo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.label2.Text = Resource.Lbl_BL_Quantity;
            this.label1.Text = Resource.Lbl_Vessel_Name_BL_No;
            this.label5.Text = Resource.Menu_Total;
            this.labelMappingSearch.Text = Resource.Contract_002;
            this.label7.Text = Resource.Lbl_Vessel_Max_Tolerance_for_Split;
            this.groupBox1.Text = Resource.Gbx_Vessel_Info;
            this.groupBox2.Text = Resource.Gbx_Mapping;
            this.cb_completed.Text = Resource.Chk_DO_Vessel_Completed;
            this.btn_Delete.Text = Resource.Trans_057;
            this.btn_Search.Text = Resource.Lbl_btn_search;
            this.btn_Save.Text = Resource.Save;
            this.btn_Cancel.Text = Resource.Menu_Cancel;
            this.btn_Map_DO.Text = Resource.Trans_055;
            this.Text = Resource.Title_Map_Vessel;
        }
    }
}

