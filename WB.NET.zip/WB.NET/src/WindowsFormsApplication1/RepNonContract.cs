﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class RepNonContract : Form
    {
        private WBTable tbl_Comm;
        private WBTable tbl_Relation;
        private WBTable tbl_Transporter;
        private IContainer components = null;
        public Label labelRecNo;
        public Label labelProcess;
        public DateTimePicker monthCalendar1;
        public Label label1;
        public Label label5;
        private ShapeContainer shapeContainer1;
        private LineShape lineShape1;
        public DateTimePicker monthCalendar2;
        public Label label2;
        public Button buttonTransporter;
        public Label label4;
        public TextBox textTransport;
        public Button buttonComm;
        public TextBox textCommodity;
        public Label labelcommodity;
        public Button buttonRelation;
        public Label label3;
        public TextBox textRelation;
        public Button button2;
        public Button button1;
        private CheckBox check3rdParty;
        private CheckBox checkDelivery;
        private CheckBox checkDeliNote;
        private RectangleShape rectangleShape1;
        private SaveFileDialog saveFileDialog1;
        private CheckBox checkSourceDesc;
        private CheckBox checkSourceCode;
        private CheckBox checkTransporterName;
        private CheckBox checkCommName;
        private CheckBox checkCommCode;
        private CheckBox checkRelationName;
        private CheckBox checkTransporter;
        private CheckBox checkRelation;
        private CheckBox checkBoxGatepassNumber;

        public RepNonContract()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                int num2 = 0;
                if (Convert.ToDateTime(this.monthCalendar2.Value.ToShortDateString()) < Convert.ToDateTime(this.monthCalendar1.Value.ToShortDateString()))
                {
                    MessageBox.Show(Resource.Mes_573, Resource.Title_002);
                }
                else
                {
                    string sqltext = "Select * From Vw_trans where " + WBData.CompanyLocation("");
                    if (this.textCommodity.Text != "")
                    {
                        sqltext = sqltext + " and Comm_Code='" + this.textCommodity.Text.Trim() + "'";
                    }
                    if (this.textTransport.Text != "")
                    {
                        sqltext = sqltext + " and Transporter_Code='" + this.textTransport.Text.Trim() + "'";
                    }
                    if (this.textRelation.Text != "")
                    {
                        sqltext = sqltext + " and Relation_Code='" + this.textRelation.Text.Trim() + "'";
                    }
                    sqltext = sqltext + " and (noncontract = 'Y') and (deleted is null or deleted = 'N') and ( report_Date is not null or report_date <> '') Order By Comm_Code,Ref Asc";
                    WBTable table = new WBTable();
                    table.OpenTable("view", sqltext, WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        MessageBox.Show(Resource.Mes_348, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        table.Dispose();
                    }
                    else
                    {
                        HTML html = new HTML();
                        html.File = html.File + @"\" + WBUser.UserID + "_NonContract.htm";
                        html.Title = "NonContract Report";
                        html.Open();
                        html.Write(html.Style());
                        html.Write("<head><meta charset='UTF-8'></head>");
                        string[] textArray1 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                        html.Write(string.Concat(textArray1));
                        string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                        html.Write(string.Concat(textArray2));
                        if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                        {
                            html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                        }
                        if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                        {
                            html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                        }
                        if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                        {
                            html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                        }
                        html.Write("<br><br>");
                        html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                        if (this.textCommodity.Text.Trim() != "")
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>Commodity</td>");
                            html.Write("<td>: <b>" + this.textCommodity.Text + "</b></td>");
                            html.Write("</tr>");
                        }
                        if (this.textTransport.Text.Trim() != "")
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>Transporter</td>");
                            html.Write("<td>: <b>" + this.textTransport.Text + "</b></td>");
                            html.Write("</tr>");
                        }
                        html.Write("<tr class=bd>");
                        html.Write("<td>Selected Date</td>");
                        string[] textArray3 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                        html.Write(string.Concat(textArray3));
                        html.Write("</tr>");
                        html.Write("<tr class=bd>");
                        html.Write("<td>Report Date</td>");
                        html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                        html.Write("</tr>");
                        html.Write("</table>");
                        html.Write("<br/><br/><br/>");
                        html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                        html.Write("<tr class='bd'>");
                        html.Write("<td nowrap><b>No.</b></td>");
                        num2++;
                        html.Write("<td nowrap><b>TX</b></td>");
                        num2++;
                        html.Write("<td nowrap><b>" + Resource.Trans_005 + "</b></td>");
                        num2++;
                        if (this.checkBoxGatepassNumber.Checked)
                        {
                            html.Write("<td nowrap><b>" + Resource.Gatepass_001 + "</b></td>");
                            num2++;
                        }
                        html.Write("<td nowrap><b>" + Resource.Main_057 + "</b></td>");
                        num2++;
                        html.Write("<td nowrap><b>" + Resource.Main_014 + "</b></td>");
                        num2++;
                        html.Write("<td nowrap><b>" + Resource.Main_059 + "</b></td>");
                        num2++;
                        html.Write("<td nowrap><b>" + Resource.Main_015 + "</b></td>");
                        num2++;
                        if (this.checkDelivery.Checked)
                        {
                            html.Write("<td nowrap><b>" + Resource.Main_036 + "</b></td>");
                            num2++;
                            html.Write("<td nowrap><b>" + Resource.Main_037 + "</b></td>");
                            num2++;
                        }
                        if (this.checkCommCode.Checked)
                        {
                            html.Write("<td nowrap><b>" + Resource.Composite_004 + "</b></td>");
                            num2++;
                        }
                        if (this.checkCommName.Checked)
                        {
                            html.Write("<td nowrap><b>" + Resource.CommE_003 + "</b></td>");
                            num2++;
                        }
                        if (this.checkRelation.Checked)
                        {
                            html.Write("<td nowrap><b>" + Resource.Composite_002 + "</b></td>");
                            num2++;
                        }
                        if (this.checkRelationName.Checked)
                        {
                            html.Write("<td nowrap><b>" + Resource.Rep01_027 + "</b></td>");
                            num2++;
                        }
                        html.Write("<td nowrap><b>" + Resource.DriverE_003 + "</b></td>");
                        num2++;
                        if (this.checkTransporter.Checked)
                        {
                            html.Write("<td nowrap><b>" + Resource.Contract_017 + "</b></td>");
                            num2++;
                        }
                        if (this.checkTransporterName.Checked)
                        {
                            html.Write("<td nowrap><b>" + Resource.Transporter_002 + "</b></td>");
                            num2++;
                        }
                        if (this.checkDeliNote.Checked)
                        {
                            html.Write("<td nowrap><b>" + Resource.DoE_009 + "</b></td>");
                            num2++;
                        }
                        if (this.checkSourceCode.Checked)
                        {
                            html.Write("<td nowrap><b>" + Resource.Trans_059 + "</b></td>");
                            num2++;
                        }
                        if (this.checkSourceDesc.Checked)
                        {
                            string[] textArray4 = new string[] { "<td nowrap><b>", Resource.Trans_059, " ", Resource.Source_002, "</b></td>" };
                            html.Write(string.Concat(textArray4));
                            num2++;
                        }
                        if (this.check3rdParty.Checked)
                        {
                            html.Write("<td nowrap><b>GROSS (3rd_Party)</b></td>");
                            html.Write("<td nowrap><b>TARE  (3rd_Party)</b></td>");
                            html.Write("<td nowrap><b>NETT  (3rd_Party)</b></td>");
                        }
                        string[] textArray5 = new string[] { "<td nowrap><b>", Resource.Main_019, " (", Resource.ContractE_038, ")</b></td>" };
                        html.Write(string.Concat(textArray5));
                        string[] textArray6 = new string[] { "<td nowrap><b>", Resource.Main_020, "  (", Resource.ContractE_038, ")</b></td>" };
                        html.Write(string.Concat(textArray6));
                        string[] textArray7 = new string[] { "<td nowrap><b>", Resource.Main_021, "  (", Resource.ContractE_038, ")</b></td>" };
                        html.Write(string.Concat(textArray7));
                        string[] textArray8 = new string[] { "<td nowrap><b>", Resource.Main_023, "  (", Resource.ContractE_038, ")</b></td>" };
                        html.Write(string.Concat(textArray8));
                        html.Write("<td nowrap><b>DIFF</b></td>");
                        html.Write("<td nowrap><b>DIFF %</b></td>");
                        html.Write("<td nowrap><b>" + Resource.Rep01_037 + "</b></td>");
                        html.Write("<td nowrap><b>" + Resource.Rep01_036 + "</b></td>");
                        html.Write("<td nowrap><b>" + Resource.Rep01_038 + "</b></td>");
                        html.Write("</tr>");
                        double num3 = 0.0;
                        double num4 = 0.0;
                        double num5 = 0.0;
                        double num6 = 0.0;
                        double num7 = 0.0;
                        double num8 = 0.0;
                        double num9 = 0.0;
                        double num10 = 0.0;
                        double num11 = 0.0;
                        double num12 = 0.0;
                        double num13 = 0.0;
                        double num14 = 0.0;
                        double num15 = 0.0;
                        double num16 = 0.0;
                        double num17 = 0.0;
                        double num18 = 0.0;
                        double num19 = 0.0;
                        int num21 = 0;
                        this.labelProcess.Visible = true;
                        this.labelRecNo.Visible = true;
                        this.labelProcess.Refresh();
                        this.labelRecNo.Refresh();
                        foreach (DataRow row in table.DT.Rows)
                        {
                            num18 = 0.0;
                            num21++;
                            this.labelRecNo.Text = num21.ToString() + "/" + table.DT.Rows.Count.ToString();
                            this.labelRecNo.Refresh();
                            html.Write("<tr class='bd'>");
                            html.Write("<td nowrap>" + html.strq(num21.ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(row["Transaction_Code"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(row["Ref"].ToString()) + "</td>");
                            if (this.checkBoxGatepassNumber.Checked)
                            {
                                html.Write("<td nowrap>" + html.strq(row["Gatepass_Number"].ToString()) + "</td>");
                            }
                            html.Write("<td nowrap>" + html.strq(row["Date1"].ToString().Substring(0, 10)) + "</td>");
                            html.Write("<td nowrap>" + html.strq(row["Time1"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(row["Date2"].ToString().Substring(0, 10)) + "</td>");
                            html.Write("<td nowrap>" + html.strq(row["Time2"].ToString()) + "</td>");
                            if (this.checkDelivery.Checked)
                            {
                                html.Write("<td nowrap>" + html.strq(row["Delivery_Date"].ToString().Substring(0, 10)) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row["Delivery_Time"].ToString()) + "</td>");
                            }
                            if (this.checkCommCode.Checked)
                            {
                                html.Write("<td nowrap>" + html.strq(row["Comm_code"].ToString()) + "</td>");
                            }
                            if (this.checkCommName.Checked)
                            {
                                html.Write("<td nowrap>" + html.strq(row["Comm_Name"].ToString()) + "</td>");
                            }
                            if (this.checkRelation.Checked)
                            {
                                html.Write("<td nowrap>" + html.strq(row["Relation_code"].ToString()) + "</td>");
                            }
                            if (this.checkRelationName.Checked)
                            {
                                html.Write("<td nowrap>" + html.strq(row["Relation_Name"].ToString()) + "</td>");
                            }
                            html.Write("<td nowrap>" + html.strq(row["Truck_Number"].ToString()) + "</td>");
                            if (this.checkTransporter.Checked)
                            {
                                html.Write("<td nowrap>" + html.strq(row["Transporter_Code"].ToString()) + "</td>");
                            }
                            if (this.checkTransporterName.Checked)
                            {
                                html.Write("<td nowrap>" + html.strq(row["Transporter_Name"].ToString()) + "</td>");
                            }
                            if (this.checkDeliNote.Checked)
                            {
                                html.Write("<td nowrap>" + html.strq(row["Delivery_Note"].ToString()) + "</td>");
                            }
                            if (this.checkSourceCode.Checked)
                            {
                                html.Write("<td nowrap>" + html.strq(row["Source_code"].ToString()) + "</td>");
                            }
                            if (this.checkSourceDesc.Checked)
                            {
                                html.Write("<td nowrap>" + html.strq(row["SourceDesc"].ToString()) + "</td>");
                            }
                            num14 = Program.StrToDouble(row["Tare_Estate"].ToString(), 0);
                            num12 = Program.StrToDouble(row["Gross_Estate"].ToString(), 0);
                            num13 = Program.StrToDouble(row["Net_Estate"].ToString(), 0);
                            num15 = Program.StrToDouble(row["Bruto"].ToString(), 0);
                            num16 = Program.StrToDouble(row["Tarra"].ToString(), 0);
                            num19 = num15 - num16;
                            num17 = Program.StrToDouble(row["netto"].ToString(), 0);
                            num3 += num12;
                            num4 += num14;
                            num5 += num13;
                            num6 += num15;
                            num7 += num16;
                            num8 += num17;
                            num10 += Program.StrToDouble(row["deduction"].ToString(), 0);
                            num11 += num19;
                            num18 = (num13 <= 0.0) ? 0.0 : (num13 - num17);
                            num9 += num18;
                            if (this.check3rdParty.Checked)
                            {
                                html.Write("<td nowrap align=right>" + html.strq($"{num12:N0}") + "</td>");
                                html.Write("<td nowrap align=right>" + html.strq($"{num14:N0}") + "</td>");
                                html.Write("<td nowrap align=right>" + html.strq($"{num13:N0}") + "</td>");
                            }
                            html.Write("<td nowrap align=right>" + html.strq($"{num15:N0}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{num16:N0}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{num19:N0}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{num17:N0}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{num18:N0}") + "</td>");
                            if (!(num13 == 0.0))
                            {
                                html.Write("<td nowrap align=right>" + html.strq($"{(num18 / num13) * 100.0:N2}") + "</td>");
                            }
                            else
                            {
                                html.Write("<td nowrap align=right>0.00</td>");
                            }
                            html.Write("<td nowrap>" + html.strq(row["Remark_Ticket"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(row["Remark_Report"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(row["Seal"].ToString()) + "</td>");
                            html.Write("</tr>");
                        }
                        html.Write("<tr class='bd'>");
                        object[] objArray1 = new object[] { "<td colspan=", num2, " nowrap>", html.strq(""), "</td>" };
                        html.Write(string.Concat(objArray1));
                        if (this.check3rdParty.Checked)
                        {
                            html.Write("<td nowrap align=right><b>" + html.strq($"{num3:N0}") + "</b></td>");
                            html.Write("<td nowrap align=right><b>" + html.strq($"{num4:N0}") + "</b></td>");
                            html.Write("<td nowrap align=right><b>" + html.strq($"{num5:N0}") + "</b></td>");
                        }
                        html.Write("<td nowrap align=right><b>" + html.strq($"{num6:N0}") + "</b></td>");
                        html.Write("<td nowrap align=right><b>" + html.strq($"{num7:N0}") + "</b></td>");
                        html.Write("<td nowrap align=right><b>" + html.strq($"{num11:N0}") + "</b></td>");
                        html.Write("<td nowrap align=right><b>" + html.strq($"{num8:N0}") + "</b></td>");
                        html.Write("<td nowrap align=right><b>" + html.strq($"{num9:N0}") + "</b></td>");
                        if (!(num13 == 0.0))
                        {
                            html.Write("<td nowrap align=right>" + html.strq($"{(num9 / num8) * 100.0:N2}") + "</td>");
                        }
                        else
                        {
                            html.Write("<td nowrap align=right>0.00</td>");
                        }
                        html.Write("<td colspan=3 nowrap>" + html.strq("") + "</td>");
                        html.Write("</tr>");
                        html.Write("</table>");
                        html.Write("<br>");
                        html.Write("<br>");
                        html.Write("<br>");
                        html.writeSign();
                        html.Close();
                        ViewReport report = new ViewReport {
                            webBrowser1 = { Url = new Uri("file:///" + html.File) }
                        };
                        report.ShowDialog();
                        html.Dispose();
                        report.Dispose();
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.textCommodity.Focus();
            }
            commodity.Dispose();
        }

        private void buttonRelation_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textRelation.Text = vendor.ReturnRow["relation_code"].ToString();
            }
            vendor.Dispose();
        }

        private void buttonTransporter_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransport.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.textTransport.Focus();
            }
            transporter.Dispose();
        }

        private void checkTransporter_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void checkTransporterName_CheckedChanged(object sender, EventArgs e)
        {
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.monthCalendar1 = new DateTimePicker();
            this.label1 = new Label();
            this.label5 = new Label();
            this.shapeContainer1 = new ShapeContainer();
            this.rectangleShape1 = new RectangleShape();
            this.lineShape1 = new LineShape();
            this.monthCalendar2 = new DateTimePicker();
            this.label2 = new Label();
            this.buttonTransporter = new Button();
            this.label4 = new Label();
            this.textTransport = new TextBox();
            this.buttonComm = new Button();
            this.textCommodity = new TextBox();
            this.labelcommodity = new Label();
            this.buttonRelation = new Button();
            this.label3 = new Label();
            this.textRelation = new TextBox();
            this.button2 = new Button();
            this.button1 = new Button();
            this.check3rdParty = new CheckBox();
            this.checkDelivery = new CheckBox();
            this.checkDeliNote = new CheckBox();
            this.saveFileDialog1 = new SaveFileDialog();
            this.checkSourceDesc = new CheckBox();
            this.checkSourceCode = new CheckBox();
            this.checkTransporterName = new CheckBox();
            this.checkCommName = new CheckBox();
            this.checkCommCode = new CheckBox();
            this.checkRelationName = new CheckBox();
            this.checkTransporter = new CheckBox();
            this.checkRelation = new CheckBox();
            this.checkBoxGatepassNumber = new CheckBox();
            base.SuspendLayout();
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x181, 0x1b);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 0x5d;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0xe9, 0x1b);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 0x5c;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x48, 0x41);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 90;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x24, 0x47);
            this.label1.Name = "label1";
            this.label1.Size = new Size(30, 13);
            this.label1.TabIndex = 0x5b;
            this.label1.Text = "From";
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(30, 0x1b);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x99, 13);
            this.label5.TabIndex = 0x59;
            this.label5.Text = "Non Contract Transaction";
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.rectangleShape1, this.lineShape1 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(0x210, 0x17f);
            this.shapeContainer1.TabIndex = 0x5e;
            this.shapeContainer1.TabStop = false;
            this.rectangleShape1.Location = new Point(0x21, 0xbd);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new Size(0x1d1, 0xb3);
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 0x18;
            this.lineShape1.X2 = 0x1bc;
            this.lineShape1.Y1 = 0x2d;
            this.lineShape1.Y2 = 0x2d;
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0xd1, 0x41);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 0x5f;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0xb7, 70);
            this.label2.Name = "label2";
            this.label2.Size = new Size(20, 13);
            this.label2.TabIndex = 0x60;
            this.label2.Text = "To";
            this.buttonTransporter.Location = new Point(0x12d, 0x9b);
            this.buttonTransporter.Margin = new Padding(0);
            this.buttonTransporter.Name = "buttonTransporter";
            this.buttonTransporter.Size = new Size(0x17, 0x17);
            this.buttonTransporter.TabIndex = 100;
            this.buttonTransporter.Text = "...";
            this.buttonTransporter.UseVisualStyleBackColor = true;
            this.buttonTransporter.Click += new EventHandler(this.buttonTransporter_Click);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x26, 0x9f);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x3d, 13);
            this.label4.TabIndex = 0x67;
            this.label4.Text = "Transporter";
            this.textTransport.CharacterCasing = CharacterCasing.Upper;
            this.textTransport.Location = new Point(0x6b, 0x9c);
            this.textTransport.Name = "textTransport";
            this.textTransport.Size = new Size(0xc0, 20);
            this.textTransport.TabIndex = 0x62;
            this.buttonComm.Location = new Point(0x12d, 0x67);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 0x63;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.textCommodity.CharacterCasing = CharacterCasing.Upper;
            this.textCommodity.Location = new Point(0x6b, 0x68);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0xc0, 20);
            this.textCommodity.TabIndex = 0x61;
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x27, 0x6b);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3a, 13);
            this.labelcommodity.TabIndex = 0x65;
            this.labelcommodity.Text = "Commodity";
            this.buttonRelation.Location = new Point(0x12d, 0x81);
            this.buttonRelation.Margin = new Padding(0);
            this.buttonRelation.Name = "buttonRelation";
            this.buttonRelation.Size = new Size(0x17, 0x17);
            this.buttonRelation.TabIndex = 0x69;
            this.buttonRelation.Text = "...";
            this.buttonRelation.UseVisualStyleBackColor = true;
            this.buttonRelation.Click += new EventHandler(this.buttonRelation_Click);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x33, 0x85);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x2e, 13);
            this.label3.TabIndex = 0x6a;
            this.label3.Text = "Relation";
            this.textRelation.CharacterCasing = CharacterCasing.Upper;
            this.textRelation.Location = new Point(0x6b, 130);
            this.textRelation.Name = "textRelation";
            this.textRelation.Size = new Size(0xc0, 20);
            this.textRelation.TabIndex = 0x68;
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x184, 0x8e);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x22);
            this.button2.TabIndex = 0x6c;
            this.button2.Text = "&Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x184, 0x65);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x22);
            this.button1.TabIndex = 0x6b;
            this.button1.Text = "&Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.check3rdParty.AutoSize = true;
            this.check3rdParty.Location = new Point(0x2a, 0xde);
            this.check3rdParty.Name = "check3rdParty";
            this.check3rdParty.Size = new Size(0xb3, 0x11);
            this.check3rdParty.TabIndex = 110;
            this.check3rdParty.Text = "Other Party Quantity (Estate Qty)";
            this.check3rdParty.UseVisualStyleBackColor = true;
            this.checkDelivery.AutoSize = true;
            this.checkDelivery.Location = new Point(0x2a, 0xc7);
            this.checkDelivery.Name = "checkDelivery";
            this.checkDelivery.Size = new Size(0x7c, 0x11);
            this.checkDelivery.TabIndex = 0x6d;
            this.checkDelivery.Text = "Delivery Date / Time";
            this.checkDelivery.UseVisualStyleBackColor = true;
            this.checkDeliNote.AutoSize = true;
            this.checkDeliNote.Location = new Point(0x2a, 0xf4);
            this.checkDeliNote.Name = "checkDeliNote";
            this.checkDeliNote.Size = new Size(90, 0x11);
            this.checkDeliNote.TabIndex = 0x72;
            this.checkDeliNote.Text = "Delivery Note";
            this.checkDeliNote.UseVisualStyleBackColor = true;
            this.checkSourceDesc.AutoSize = true;
            this.checkSourceDesc.Location = new Point(250, 0x10c);
            this.checkSourceDesc.Name = "checkSourceDesc";
            this.checkSourceDesc.Size = new Size(0x76, 0x11);
            this.checkSourceDesc.TabIndex = 0x74;
            this.checkSourceDesc.Text = "Source/Dest Desc.";
            this.checkSourceDesc.UseVisualStyleBackColor = true;
            this.checkSourceCode.AutoSize = true;
            this.checkSourceCode.Location = new Point(250, 0xf5);
            this.checkSourceCode.Name = "checkSourceCode";
            this.checkSourceCode.Size = new Size(0x73, 0x11);
            this.checkSourceCode.TabIndex = 0x73;
            this.checkSourceCode.Text = "Source/Dest Code";
            this.checkSourceCode.UseVisualStyleBackColor = true;
            this.checkTransporterName.AutoSize = true;
            this.checkTransporterName.Location = new Point(250, 0xde);
            this.checkTransporterName.Name = "checkTransporterName";
            this.checkTransporterName.Size = new Size(0x6f, 0x11);
            this.checkTransporterName.TabIndex = 0x7a;
            this.checkTransporterName.Text = "Transporter Name";
            this.checkTransporterName.UseVisualStyleBackColor = true;
            this.checkTransporterName.CheckedChanged += new EventHandler(this.checkTransporterName_CheckedChanged);
            this.checkCommName.AutoSize = true;
            this.checkCommName.Location = new Point(0x2a, 290);
            this.checkCommName.Name = "checkCommName";
            this.checkCommName.Size = new Size(0x6c, 0x11);
            this.checkCommName.TabIndex = 0x79;
            this.checkCommName.Text = "Commodity Name";
            this.checkCommName.UseVisualStyleBackColor = true;
            this.checkCommCode.AutoSize = true;
            this.checkCommCode.Checked = true;
            this.checkCommCode.CheckState = CheckState.Checked;
            this.checkCommCode.Location = new Point(0x2a, 0x10b);
            this.checkCommCode.Name = "checkCommCode";
            this.checkCommCode.Size = new Size(0x69, 0x11);
            this.checkCommCode.TabIndex = 120;
            this.checkCommCode.Text = "Commodity Code";
            this.checkCommCode.UseVisualStyleBackColor = true;
            this.checkRelationName.AutoSize = true;
            this.checkRelationName.Location = new Point(0x2a, 0x150);
            this.checkRelationName.Name = "checkRelationName";
            this.checkRelationName.Size = new Size(0x60, 0x11);
            this.checkRelationName.TabIndex = 0x77;
            this.checkRelationName.Text = "Relation Name";
            this.checkRelationName.UseVisualStyleBackColor = true;
            this.checkTransporter.AutoSize = true;
            this.checkTransporter.Checked = true;
            this.checkTransporter.CheckState = CheckState.Checked;
            this.checkTransporter.Location = new Point(250, 0xc7);
            this.checkTransporter.Name = "checkTransporter";
            this.checkTransporter.Size = new Size(0x6c, 0x11);
            this.checkTransporter.TabIndex = 0x76;
            this.checkTransporter.Text = "Transporter Code";
            this.checkTransporter.UseVisualStyleBackColor = true;
            this.checkTransporter.CheckedChanged += new EventHandler(this.checkTransporter_CheckedChanged);
            this.checkRelation.AutoSize = true;
            this.checkRelation.Checked = true;
            this.checkRelation.CheckState = CheckState.Checked;
            this.checkRelation.Location = new Point(0x2a, 0x139);
            this.checkRelation.Name = "checkRelation";
            this.checkRelation.Size = new Size(0x41, 0x11);
            this.checkRelation.TabIndex = 0x75;
            this.checkRelation.Text = "Relation";
            this.checkRelation.UseVisualStyleBackColor = true;
            this.checkBoxGatepassNumber.AutoSize = true;
            this.checkBoxGatepassNumber.Location = new Point(250, 290);
            this.checkBoxGatepassNumber.Name = "checkBoxGatepassNumber";
            this.checkBoxGatepassNumber.Size = new Size(0x6f, 0x11);
            this.checkBoxGatepassNumber.TabIndex = 0x7b;
            this.checkBoxGatepassNumber.Text = "Gatepass Number";
            this.checkBoxGatepassNumber.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x210, 0x17f);
            base.ControlBox = false;
            base.Controls.Add(this.checkBoxGatepassNumber);
            base.Controls.Add(this.checkTransporterName);
            base.Controls.Add(this.checkCommName);
            base.Controls.Add(this.checkCommCode);
            base.Controls.Add(this.checkRelationName);
            base.Controls.Add(this.checkTransporter);
            base.Controls.Add(this.checkRelation);
            base.Controls.Add(this.checkSourceDesc);
            base.Controls.Add(this.checkSourceCode);
            base.Controls.Add(this.checkDeliNote);
            base.Controls.Add(this.check3rdParty);
            base.Controls.Add(this.checkDelivery);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.buttonRelation);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textRelation);
            base.Controls.Add(this.buttonTransporter);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textTransport);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.monthCalendar2);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.monthCalendar1);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.shapeContainer1);
            base.KeyPreview = true;
            base.Name = "RepNonContract";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Non Contract Transaction Report";
            base.Load += new EventHandler(this.RepNonContract_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepNonContract_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void RepNonContract_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepNonContract_Load(object sender, EventArgs e)
        {
            this.translate();
            this.tbl_Comm = new WBTable();
            this.tbl_Comm.OpenTable("wb_commodity", "Select * from wb_commodity", WBData.conn);
            Program.AutoComp(this.tbl_Comm, "Comm_code", this.textCommodity);
            this.tbl_Transporter = new WBTable();
            this.tbl_Transporter.OpenTable("wb_transporter", "Select * from wb_transporter", WBData.conn);
            Program.AutoComp(this.tbl_Transporter, "transporter_code", this.textTransport);
            this.tbl_Relation = new WBTable();
            this.tbl_Relation.OpenTable("wb_contract", "Select Relation_code from wb_Relation", WBData.conn);
            Program.AutoComp(this.tbl_Relation, "Relation_code", this.textRelation);
            if (WBSetting.transflow == "1")
            {
                this.checkBoxGatepassNumber.Visible = false;
                this.checkBoxGatepassNumber.Checked = false;
            }
            else if (WBSetting.transflow == "2")
            {
                this.checkBoxGatepassNumber.Visible = true;
                this.checkBoxGatepassNumber.Checked = true;
            }
            else if (WBSetting.transflow == "3")
            {
                this.checkBoxGatepassNumber.Visible = true;
                this.checkBoxGatepassNumber.Checked = true;
            }
        }

        private void translate()
        {
            this.Text = Resource.Report06_001;
            this.label5.Text = Resource.Report06_002;
            this.label1.Text = Resource.Report06_003;
            this.label2.Text = Resource.Report06_004;
            this.labelcommodity.Text = Resource.Report06_005;
            this.label3.Text = Resource.Report06_006;
            this.label4.Text = Resource.Report06_007;
            this.checkDelivery.Text = Resource.Report06_008;
            this.check3rdParty.Text = Resource.Report06_009;
            this.checkDeliNote.Text = Resource.Report06_010;
            this.button1.Text = Resource.Rep01_042;
            this.button2.Text = Resource.Menu_Close;
            this.checkRelation.Text = Resource.Rep01_026;
            this.checkRelationName.Text = Resource.Rep01_027;
            this.checkCommCode.Text = Resource.Trans_027;
            this.checkCommName.Text = Resource.CommE_003;
            this.checkTransporter.Text = Resource.Rep01_011;
            this.checkTransporterName.Text = Resource.Transporter_002;
            this.checkSourceCode.Text = Resource.Source_014;
            this.checkSourceDesc.Text = Resource.Trans_059;
            this.checkBoxGatepassNumber.Text = Resource.Gatepass_001;
        }
    }
}

