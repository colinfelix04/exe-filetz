﻿namespace WindowsFormsApplication1
{
    using Camera.Utility;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Properties;
    using WindowsFormsApplication1.Utility;

    public class FormDriver : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pFind = "";
        public string pFilter = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public WBTable truck = new WBTable();
        public WBTable trans = new WBTable();
        public DataRow ReturnRow;
        private DataTable updTable = new DataTable();
        private DataTable retTable = new DataTable();
        private string[] zwbResult = new string[3];
        private string[] zwbRow = new string[0x16];
        public string sField;
        private IContainer components = null;
        public ToolStripMenuItem closeToolStripMenuItem;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem printToolStripMenuItem;
        public TextBox TextFind;
        public Button buttonFind;
        public Panel panel1;
        private DataGridView dataGridView1;
        private ToolStripMenuItem chooseStripMenuItem1;
        private ToolStripMenuItem zWBToolStripMenuItem;
        private ToolStripMenuItem synchronizeToolStripMenuItem;
        private ToolStripMenuItem synchToolStripMenuItem;
        private ImageList imageList1;
        private ProgressBar progressBar1;
        private ToolStripMenuItem filterToolStripMenuItem;
        private ToolStripMenuItem unFilterToolStripMenuItem;
        private ToolStripMenuItem copyToAllLocationsToolStripMenuItem;
        private ToolStripMenuItem copyThisDriverToolStripMenuItem;
        private ToolStripMenuItem copyAllDriversToolStripMenuItem;
        private ToolStripMenuItem viewRecordToolStripMenuItem;
        private ToolStripMenuItem blacklistToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator2;
        private CheckBox checkDeleted;
        private ToolStripSeparator toolStripSeparator3;
        private ToolStripMenuItem captureDriverLicenseIDToolStripMenuItem;

        public FormDriver()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            WBSetting.OpenSetting();
            this.zWBToolStripMenuItem.Visible = WBSetting.zwb == "Y";
            string str = (this.dataGridView1.Rows.Count > 0) ? this.dataGridView1.CurrentRow.Cells["Black_List"].Value.ToString().Trim() : "N";
            string str2 = (this.dataGridView1.Rows.Count > 0) ? this.dataGridView1.CurrentRow.Cells["deleted"].Value.ToString().Trim() : "N";
            if (str == "Y")
            {
                this.blacklistToolStripMenuItem.Enabled = WBUser.CheckTrustee("BLACKLIST_DRIVER", "E");
                this.editRecordToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
                this.blacklistToolStripMenuItem.Text = Resource.Menu_Unblacklist;
                this.deleteToolStripMenuItem.Text = Resource.Menu_Mark_Delete;
            }
            else if (str2 == "Y")
            {
                this.blacklistToolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_DRIVER", "D");
                this.blacklistToolStripMenuItem.Text = Resource.Menu_Blacklist;
                this.deleteToolStripMenuItem.Text = Resource.Menu_Unmark_Delete;
            }
            else
            {
                this.blacklistToolStripMenuItem.Enabled = WBUser.CheckTrustee("BLACKLIST_DRIVER", "A");
                this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_DRIVER", "D");
                this.editRecordToolStripMenuItem.Enabled = true;
                this.deleteToolStripMenuItem.Enabled = true;
                this.blacklistToolStripMenuItem.Text = Resource.Menu_Blacklist;
                this.deleteToolStripMenuItem.Text = Resource.Menu_Mark_Delete;
            }
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormDriverEntry entry = new FormDriverEntry {
                    pMode = "ADD",
                    zTable = this.ztable,
                    Text = Resource.Title_Add_Driver,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                    string[] aField = new string[] { "License_No" };
                    string[] aFind = new string[] { entry.textBoxLicenseNo.Text };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                entry.Dispose();
                this.ztable.UnLock();
                if (this.dataGridView1.RowCount > 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = true;
                    this.editRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_DRIVER", "E");
                    this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_DRIVER", "D");
                    this.printToolStripMenuItem.Enabled = true;
                    this.zWBToolStripMenuItem.Enabled = true;
                    this.blacklistToolStripMenuItem.Enabled = WBUser.CheckTrustee("BLACKLIST_DRIVER", "A");
                    this.copyToAllLocationsToolStripMenuItem.Enabled = true;
                    this.filterToolStripMenuItem.Enabled = true;
                    this.unFilterToolStripMenuItem.Enabled = true;
                    this.chooseStripMenuItem1.Enabled = true;
                }
            }
        }

        private void blacklistToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
            string key = this.dataGridView1.CurrentRow.Cells["License_No"].Value.ToString().Trim();
            if (this.dataGridView1.CurrentRow.Cells["black_list"].Value.ToString() != "Y")
            {
                string[] textArray3 = new string[] { Resource.DriverE_007, " ", Resource.DriverE_001, " ", key, "?" };
                if (MessageBox.Show(string.Concat(textArray3), Resource.DriverE_007, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    if (this.ztable.BeforeEdit(this.dataGridView1, "BLACKLIST"))
                    {
                        FormTransCancel cancel2 = new FormTransCancel {
                            label1 = { Text = Resource.Gatepass_026 },
                            textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["License_No"].ToString() },
                            Text = Resource.Form_Blacklist_Reason,
                            label2 = { Text = Resource.Lbl_Blacklist_Reason }
                        };
                        cancel2.textReason.Focus();
                        cancel2.ShowDialog();
                        if (cancel2.Saved)
                        {
                            this.changeReason = cancel2.textReason.Text;
                            cancel2.Dispose();
                            WBUtility.BlacklistData("wb_driver", this.nCurrRow, this.changeReason, this.ztable);
                            this.ztable.AfterEdit("Blacklist");
                            string[] textArray4 = new string[] { "(Triggered Unblacklist License Number in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                            Program.copyToLoc("wb_driver", key, 0, this.changeReason + " " + string.Concat(textArray4));
                        }
                        else
                        {
                            return;
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                this.ztable.UnLock();
            }
            else
            {
                string[] textArray1 = new string[] { Resource.Trans_057, " ", Resource.DriverE_007, " ", Resource.DriverE_001, " ", key, "?" };
                if (MessageBox.Show(string.Concat(textArray1), "Un" + Resource.DriverE_007, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    if (this.ztable.BeforeEdit(this.dataGridView1, "BLACKLIST"))
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = Resource.Gatepass_026 },
                            textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["License_No"].ToString() },
                            Text = Resource.Form_Unblacklist_Reason,
                            label2 = { Text = Resource.Lbl_Unblacklist_Reason }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                            WBUtility.UnblacklistData("wb_driver", this.nCurrRow, this.changeReason, this.ztable);
                            this.ztable.AfterEdit("Blacklist");
                            string[] textArray2 = new string[] { "(Triggered Unblacklist License Number in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                            Program.copyToLoc("wb_driver", key, 0, this.changeReason + " " + string.Concat(textArray2));
                        }
                        else
                        {
                            return;
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                this.ztable.UnLock();
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void captureDriverLicenseIDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.f_CaptureImg();
        }

        private void checkDeleted_CheckedChanged(object sender, EventArgs e)
        {
            this.filter();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void copyAllDriversToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this.dataGridView1.Rows.Count + " " + Resource.Mes_Confirm_Copy_Driver, Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Program.copyToLoc("wb_driver", "", 1, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                MessageBox.Show(Resource.Mes_Driver_Copied);
            }
        }

        private void copyThisDriverToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string key = this.dataGridView1.CurrentRow.Cells["license_no"].Value.ToString().Trim();
            if (MessageBox.Show(key + " " + Resource.Mes_Confirm_Copy, Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Program.copyToLoc("wb_driver", key, 0, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                MessageBox.Show(Resource.Mes_Copied_All_Location);
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseStripMenuItem1.PerformClick();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1.Rows[e.RowIndex].Cells["black_list"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Red;
                e.CellStyle.SelectionBackColor = Color.HotPink;
            }
            if (this.dataGridView1.Rows[e.RowIndex].Cells["Deleted"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Gray;
                e.CellStyle.SelectionBackColor = Color.Black;
            }
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.chooseStripMenuItem1.PerformClick();
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                if (this.dataGridView1.CurrentRow.Cells["deleted"].Value.ToString() != "Y")
                {
                    if (MessageBox.Show(this.ztable.DT.Rows[this.nCurrRow]["License_No"].ToString() + "\n" + Resource.Mes_006, Resource.Menu_Mark_Delete, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        if (this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
                        {
                            FormTransCancel cancel2 = new FormTransCancel {
                                label1 = { Text = Resource.Gatepass_026 },
                                textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["License_No"].ToString() },
                                Text = Resource.Form_Mark_Delete_Reason,
                                label2 = { Text = Resource.Lbl_Mark_Delete_Reason }
                            };
                            cancel2.textReason.Focus();
                            cancel2.ShowDialog();
                            if (cancel2.Saved)
                            {
                                this.changeReason = cancel2.textReason.Text;
                                cancel2.Dispose();
                                WBUtility.MarkDeleteData("wb_driver", this.nCurrRow, this.changeReason, this.ztable);
                                this.ztable.AfterEdit("DELETE");
                                string[] textArray2 = new string[] { "(Triggered Mark Deleted truck in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                                Program.copyToLoc("wb_driver", this.ztable.DT.Rows[this.nCurrRow]["License_No"].ToString(), 0, this.changeReason + " " + string.Concat(textArray2));
                            }
                            else
                            {
                                return;
                            }
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                else if (MessageBox.Show(this.ztable.DT.Rows[this.nCurrRow]["License_No"].ToString() + "\n" + Resource.Mes_006A, Resource.Menu_Unmark_Delete, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    if (this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = Resource.Gatepass_026 },
                            textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["License_No"].ToString() },
                            Text = Resource.Form_Unmark_Delete_Reason,
                            label2 = { Text = Resource.Lbl_Unmark_Delete_Reason }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                            WBUtility.UnMarkDeleteData("wb_driver", this.nCurrRow, this.changeReason, this.ztable);
                            this.ztable.AfterEdit("DELETE");
                            string[] textArray1 = new string[] { "(Triggered Mark Deleted License Number in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                            Program.copyToLoc("wb_driver", this.ztable.DT.Rows[this.nCurrRow]["License_No"].ToString(), 0, this.changeReason + " " + string.Concat(textArray1));
                        }
                        else
                        {
                            return;
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                this.ztable.UnLock();
                if (this.dataGridView1.RowCount == 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = false;
                    this.editRecordToolStripMenuItem.Enabled = false;
                    this.deleteToolStripMenuItem.Enabled = false;
                    this.zWBToolStripMenuItem.Enabled = false;
                    this.blacklistToolStripMenuItem.Enabled = false;
                    this.copyToAllLocationsToolStripMenuItem.Enabled = false;
                    this.filterToolStripMenuItem.Enabled = false;
                    this.unFilterToolStripMenuItem.Enabled = false;
                    this.chooseStripMenuItem1.Enabled = false;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                if (this.dataGridView1.CurrentRow.Cells["Deleted"].Value.ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mes_026, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
                {
                    FormDriverEntry entry = new FormDriverEntry {
                        pMode = "EDIT",
                        zTable = this.ztable,
                        Text = Resource.Title_Edit_Driver,
                        dataGridView1 = this.dataGridView1
                    };
                    entry.ShowDialog();
                    if (entry.saved)
                    {
                        this.ztable.ReOpen();
                        this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                    }
                    entry.Dispose();
                    this.ztable.UnLock();
                }
            }
        }

        private void f_CaptureImg()
        {
            this.ztable.DR = this.ztable.DT.Rows[this.nCurrRow];
            FormCameraCapture capture = new FormCameraCapture();
            if ((string.IsNullOrEmpty(WBSetting.cam1_type) || ((WBSetting.cam1_type != "WEB_CAMERA") || string.IsNullOrEmpty(WBSetting.cam1))) || (WBSetting.cam1 != "Y"))
            {
                if ((string.IsNullOrEmpty(WBSetting.cam2_type) || ((WBSetting.cam2_type != "WEB_CAMERA") || string.IsNullOrEmpty(WBSetting.cam2))) || (WBSetting.cam2 != "Y"))
                {
                    if ((string.IsNullOrEmpty(WBSetting.cam3_type) || ((WBSetting.cam3_type != "WEB_CAMERA") || string.IsNullOrEmpty(WBSetting.cam3))) || (WBSetting.cam3 != "Y"))
                    {
                        if ((string.IsNullOrEmpty(WBSetting.cam4_type) || ((WBSetting.cam4_type != "WEB_CAMERA") || string.IsNullOrEmpty(WBSetting.cam4))) || (WBSetting.cam4 != "Y"))
                        {
                            if ((string.IsNullOrEmpty(WBSetting.cam5_type) || ((WBSetting.cam5_type != "WEB_CAMERA") || string.IsNullOrEmpty(WBSetting.cam5))) || (WBSetting.cam5 != "Y"))
                            {
                                MessageBox.Show(Resource.Mes_Please_Maintain_Web_Camera, Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                return;
                            }
                            else
                            {
                                MessageBox.Show(string.Format(Resource.Mes_Connecting_to_Camera, 5), Resource.Mes_Success, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                capture.webcam_name = WBSetting.cam5_web;
                                capture.camera_type = "WEB_CAMERA";
                            }
                        }
                        else
                        {
                            MessageBox.Show(string.Format(Resource.Mes_Connecting_to_Camera, 4), Resource.Mes_Success, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            capture.webcam_name = WBSetting.cam4_web;
                            capture.camera_type = "WEB_CAMERA";
                        }
                    }
                    else
                    {
                        MessageBox.Show(string.Format(Resource.Mes_Connecting_to_Camera, 3), Resource.Mes_Success, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        capture.webcam_name = WBSetting.cam3_web;
                        capture.camera_type = "WEB_CAMERA";
                    }
                }
                else
                {
                    MessageBox.Show(string.Format(Resource.Mes_Connecting_to_Camera, 2), Resource.Mes_Success, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    capture.webcam_name = WBSetting.cam2_web;
                    capture.camera_type = "WEB_CAMERA";
                }
            }
            else
            {
                MessageBox.Show(string.Format(Resource.Mes_Connecting_to_Camera, 1), Resource.Mes_Success, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                capture.webcam_name = WBSetting.cam1_web;
                capture.camera_type = "WEB_CAMERA";
            }
            capture.pic_box.Image = Resources.NoImage;
            capture.ShowDialog();
            if (capture.captured)
            {
                new WBCamera().savePhoto(WBSetting.licensePhoto_path, "LICENSEID_" + this.ztable.DR["uniq"].ToString() + ".jpg", capture.pic_box.Image, "");
            }
            capture.Dispose();
        }

        private void filter()
        {
            string pStr = "";
            pStr = this.checkDeleted.Checked ? "" : " and (Deleted IS NULL OR Deleted <> 'Y') ";
            this.ztable.OpenTable("wb_driver", "SELECT " + this.sField + " FROM wb_driver where " + ((this.pFilter == "") ? WBData.CompanyLocation(pStr) : WBData.CompanyLocation(this.pFilter + pStr)), WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["License_No"], ListSortDirection.Ascending);
            this.dataGridView1.Update();
            this.dataGridView1.Refresh();
        }

        private void filterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDriverFilter filter = new FormDriverFilter();
            filter.ShowDialog();
            if (filter.saved)
            {
                try
                {
                    this.pFilter = filter.pFilter;
                    if (this.pFilter != "")
                    {
                        this.ztable.OpenTable("wb_driver", "SELECT  " + this.sField + " FROM wb_driver Where " + WBData.CompanyLocation(this.pFilter), WBData.conn);
                    }
                    else
                    {
                        this.ztable.OpenTable("wb_driver", "SELECT " + this.sField + " FROM wb_driver ", WBData.conn);
                    }
                    this.dataGridView1.DataSource = this.ztable.DT;
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_077, Resource.Title_002);
                    this.unFilterToolStripMenuItem.PerformClick();
                    return;
                }
                this.dataGridView1.Sort(this.dataGridView1.Columns["License_No"], ListSortDirection.Descending);
                this.dataGridView1.Refresh();
                filter.Dispose();
            }
        }

        private void FormDriver_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormDriver_Load(object sender, EventArgs e)
        {
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 0x16)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    this.retTable.Columns.Add(column);
                    column.Dispose();
                    this.progressBar1.Visible = false;
                    this.sField = " Coy,Location_Code,License_No,Name,Truck_Number,Address,Phone,Birth_Place,Birth_Date,Black_List,Reason,Create_By,Create_Date,Change_By,Change_Date,Delete_By,Delete_Date,Deleted,zwb,token,uniq,completed";
                    string[] textArray1 = new string[] { "SELECT ", this.sField, " FROM wb_driver WHERE ", WBData.CompanyLocation(""), " AND (Deleted IS NULL OR Deleted <> 'Y')" };
                    this.ztable.OpenTable("wb_driver", string.Concat(textArray1), WBData.conn);
                    this.dataGridView1.DataSource = this.ztable.DT;
                    this.dataGridView1.Sort(this.dataGridView1.Columns["License_No"], ListSortDirection.Ascending);
                    this.dataGridView1.Columns["Coy"].Visible = false;
                    this.dataGridView1.Columns["Location_Code"].Visible = false;
                    this.dataGridView1.Columns["Delete_By"].Visible = false;
                    this.dataGridView1.Columns["Delete_Date"].Visible = false;
                    this.dataGridView1.Columns["uniq"].Visible = false;
                    this.dataGridView1.Columns["token"].Visible = true;
                    this.dataGridView1.Columns["completed"].Visible = true;
                    this.dataGridView1.Columns["deleted"].Visible = false;
                    this.dataGridView1.Columns["License_No"].HeaderText = Resource.DriverE_001;
                    this.dataGridView1.Columns["Name"].HeaderText = Resource.DriverE_002;
                    this.dataGridView1.Columns["Truck_Number"].HeaderText = Resource.DriverE_003;
                    this.dataGridView1.Columns["Address"].HeaderText = Resource.DriverE_004;
                    this.dataGridView1.Columns["Birth_Date"].HeaderText = Resource.DriverE_006;
                    this.dataGridView1.Columns["Birth_Date"].DefaultCellStyle.Format = "dd-MMM-yyyy";
                    this.dataGridView1.Columns["Birth_Place"].HeaderText = Resource.DriverE_005;
                    this.dataGridView1.Columns["Black_List"].HeaderText = Resource.DriverE_007;
                    this.dataGridView1.Columns["Reason"].HeaderText = Resource.DriverE_008;
                    base.KeyPreview = true;
                    if (!WBUser.CheckTrustee("MD_DRIVER", "A"))
                    {
                        this.addNewRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_DRIVER", "E"))
                    {
                        this.editRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_DRIVER", "D"))
                    {
                        this.deleteToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("BLACKLIST_DRIVER", "A"))
                    {
                        this.blacklistToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_SYNCH", "A"))
                    {
                        this.zWBToolStripMenuItem.Enabled = false;
                    }
                    if ((this.pMode != "") && (this.pFind.Trim() != ""))
                    {
                        this.TextFind.Text = this.pFind;
                        this.buttonFind.PerformClick();
                    }
                    this.chooseStripMenuItem1.Visible = this.pMode != "";
                    this.copyToAllLocationsToolStripMenuItem.Enabled = (WBSetting.copyToLoc == "Y") && (WBUser.CheckTrustee("MD_DRIVER", "A") || WBUser.CheckTrustee("MD_DRIVER", "E"));
                    if (this.dataGridView1.RowCount == 0)
                    {
                        this.viewRecordToolStripMenuItem.Enabled = false;
                        this.editRecordToolStripMenuItem.Enabled = false;
                        this.deleteToolStripMenuItem.Enabled = false;
                        this.zWBToolStripMenuItem.Enabled = false;
                        this.blacklistToolStripMenuItem.Enabled = false;
                        this.copyToAllLocationsToolStripMenuItem.Enabled = false;
                        this.filterToolStripMenuItem.Enabled = false;
                        this.unFilterToolStripMenuItem.Enabled = false;
                        this.chooseStripMenuItem1.Enabled = false;
                    }
                    this.zWBToolStripMenuItem.Text = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                    this.zWBToolStripMenuItem.Enabled = !WBSetting.integrationIDSYS;
                    return;
                }
                column = new DataColumn();
                this.updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.printToolStripMenuItem = new ToolStripMenuItem();
            this.blacklistToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator3 = new ToolStripSeparator();
            this.captureDriverLicenseIDToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator2 = new ToolStripSeparator();
            this.zWBToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeToolStripMenuItem = new ToolStripMenuItem();
            this.synchToolStripMenuItem = new ToolStripMenuItem();
            this.copyToAllLocationsToolStripMenuItem = new ToolStripMenuItem();
            this.copyThisDriverToolStripMenuItem = new ToolStripMenuItem();
            this.copyAllDriversToolStripMenuItem = new ToolStripMenuItem();
            this.filterToolStripMenuItem = new ToolStripMenuItem();
            this.unFilterToolStripMenuItem = new ToolStripMenuItem();
            this.chooseStripMenuItem1 = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.panel1 = new Panel();
            this.checkDeleted = new CheckBox();
            this.progressBar1 = new ProgressBar();
            this.dataGridView1 = new DataGridView();
            this.imageList1 = new ImageList(this.components);
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            base.SuspendLayout();
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            this.menuStrip1.ImageScalingSize = new Size(20, 20);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.filterToolStripMenuItem, this.unFilterToolStripMenuItem, this.chooseStripMenuItem1, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x305, 0x18);
            this.menuStrip1.TabIndex = 0x12;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[10];
            itemArray2[0] = this.addNewRecordToolStripMenuItem;
            itemArray2[1] = this.viewRecordToolStripMenuItem;
            itemArray2[2] = this.editRecordToolStripMenuItem;
            itemArray2[3] = this.deleteToolStripMenuItem;
            itemArray2[4] = this.blacklistToolStripMenuItem;
            itemArray2[5] = this.toolStripSeparator3;
            itemArray2[6] = this.captureDriverLicenseIDToolStripMenuItem;
            itemArray2[7] = this.toolStripSeparator2;
            itemArray2[8] = this.zWBToolStripMenuItem;
            itemArray2[9] = this.copyToAllLocationsToolStripMenuItem;
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xf1, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xf1, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xf1, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xf1, 0x16);
            this.deleteToolStripMenuItem.Text = "Mark Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new Size(0xf1, 0x16);
            this.printToolStripMenuItem.Text = "Print";
            this.blacklistToolStripMenuItem.Name = "blacklistToolStripMenuItem";
            this.blacklistToolStripMenuItem.Size = new Size(0xf1, 0x16);
            this.blacklistToolStripMenuItem.Text = "&Blacklist";
            this.blacklistToolStripMenuItem.Click += new EventHandler(this.blacklistToolStripMenuItem_Click);
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new Size(0xee, 6);
            this.captureDriverLicenseIDToolStripMenuItem.Name = "captureDriverLicenseIDToolStripMenuItem";
            this.captureDriverLicenseIDToolStripMenuItem.Size = new Size(0xf1, 0x16);
            this.captureDriverLicenseIDToolStripMenuItem.Text = "&Capture Driver License ID Photo";
            this.captureDriverLicenseIDToolStripMenuItem.Click += new EventHandler(this.captureDriverLicenseIDToolStripMenuItem_Click);
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new Size(0xee, 6);
            ToolStripItem[] itemArray3 = new ToolStripItem[] { this.synchronizeToolStripMenuItem, this.synchToolStripMenuItem };
            this.zWBToolStripMenuItem.DropDownItems.AddRange(itemArray3);
            this.zWBToolStripMenuItem.Name = "zWBToolStripMenuItem";
            this.zWBToolStripMenuItem.Size = new Size(0xf1, 0x16);
            this.zWBToolStripMenuItem.Text = "ZWB";
            this.synchronizeToolStripMenuItem.Name = "synchronizeToolStripMenuItem";
            this.synchronizeToolStripMenuItem.Size = new Size(0xa9, 0x16);
            this.synchronizeToolStripMenuItem.Text = "Synchronize";
            this.synchronizeToolStripMenuItem.Click += new EventHandler(this.synchronizeToolStripMenuItem_Click);
            this.synchToolStripMenuItem.Name = "synchToolStripMenuItem";
            this.synchToolStripMenuItem.Size = new Size(0xa9, 0x16);
            this.synchToolStripMenuItem.Text = "Synchronize to All";
            this.synchToolStripMenuItem.Click += new EventHandler(this.synchToolStripMenuItem_Click);
            ToolStripItem[] itemArray4 = new ToolStripItem[] { this.copyThisDriverToolStripMenuItem, this.copyAllDriversToolStripMenuItem };
            this.copyToAllLocationsToolStripMenuItem.DropDownItems.AddRange(itemArray4);
            this.copyToAllLocationsToolStripMenuItem.Name = "copyToAllLocationsToolStripMenuItem";
            this.copyToAllLocationsToolStripMenuItem.Size = new Size(0xf1, 0x16);
            this.copyToAllLocationsToolStripMenuItem.Text = "Copy To All Location";
            this.copyThisDriverToolStripMenuItem.Name = "copyThisDriverToolStripMenuItem";
            this.copyThisDriverToolStripMenuItem.Size = new Size(0xa1, 0x16);
            this.copyThisDriverToolStripMenuItem.Text = "Copy This Driver";
            this.copyThisDriverToolStripMenuItem.Click += new EventHandler(this.copyThisDriverToolStripMenuItem_Click);
            this.copyAllDriversToolStripMenuItem.Name = "copyAllDriversToolStripMenuItem";
            this.copyAllDriversToolStripMenuItem.Size = new Size(0xa1, 0x16);
            this.copyAllDriversToolStripMenuItem.Text = "Copy All Drivers";
            this.copyAllDriversToolStripMenuItem.Click += new EventHandler(this.copyAllDriversToolStripMenuItem_Click);
            this.filterToolStripMenuItem.Name = "filterToolStripMenuItem";
            this.filterToolStripMenuItem.ShortcutKeys = Keys.Shift | Keys.F5;
            this.filterToolStripMenuItem.Size = new Size(0x2d, 20);
            this.filterToolStripMenuItem.Text = "Filter";
            this.filterToolStripMenuItem.Click += new EventHandler(this.filterToolStripMenuItem_Click);
            this.unFilterToolStripMenuItem.Name = "unFilterToolStripMenuItem";
            this.unFilterToolStripMenuItem.Size = new Size(60, 20);
            this.unFilterToolStripMenuItem.Text = "UnFilter";
            this.unFilterToolStripMenuItem.Click += new EventHandler(this.unFilterToolStripMenuItem_Click);
            this.chooseStripMenuItem1.Name = "chooseStripMenuItem1";
            this.chooseStripMenuItem1.Size = new Size(0x3b, 20);
            this.chooseStripMenuItem1.Text = "Choose";
            this.chooseStripMenuItem1.Click += new EventHandler(this.toolStripMenuItem1_Click);
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.checkDeleted);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x18e);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x305, 0x21);
            this.panel1.TabIndex = 0x11;
            this.checkDeleted.AutoSize = true;
            this.checkDeleted.Location = new Point(0x11f, 8);
            this.checkDeleted.Name = "checkDeleted";
            this.checkDeleted.Size = new Size(0x5d, 0x11);
            this.checkDeleted.TabIndex = 0x16;
            this.checkDeleted.Text = "Show Deleted";
            this.checkDeleted.UseVisualStyleBackColor = true;
            this.checkDeleted.CheckedChanged += new EventHandler(this.checkDeleted_CheckedChanged);
            this.progressBar1.Location = new Point(0x25b, 6);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xa7, 0x11);
            this.progressBar1.TabIndex = 0x13;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x305, 0x176);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.imageList1.ColorDepth = ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new Size(0x10, 0x10);
            this.imageList1.TransparentColor = Color.Transparent;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x305, 0x1af);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.Name = "FormDriver";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of Driver ";
            base.Load += new EventHandler(this.FormDriver_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormDriver_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void synchronizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str2 = this.dataGridView1.CurrentRow.Cells["License_no"].Value.ToString().Trim();
            string str = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString().Trim();
            if (MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_034_IDSYS : (Resource.Mes_034 + " " + str2), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                if (WBSetting.activeMulesoftIntegration)
                {
                    Sync.sync_driver_with_mulesoft("uniq = '" + str + "'");
                }
                else
                {
                    Sync.sync_driver("uniq = '" + str + "'");
                }
            }
        }

        private void synchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int count = this.dataGridView1.Rows.Count;
            this.updTable.Rows.Clear();
            this.retTable.Rows.Clear();
            if (MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_035_IDSYS : Resource.Mes_035, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.progressBar1.Visible = true;
                this.progressBar1.Maximum = count;
                if (WBSetting.activeMulesoftIntegration)
                {
                    Sync.sync_driver_with_mulesoft(WBData.CompanyLocation(""));
                }
                else
                {
                    Sync.sync_driver(WBData.CompanyLocation(""));
                }
                this.progressBar1.Visible = false;
            }
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["black_list"].Value.ToString() == "Y")
            {
                MessageBox.Show(Resource.Mes_622, Resource.Title_002);
            }
            else if (this.dataGridView1.CurrentRow.Cells["Deleted"].Value.ToString() == "Y")
            {
                MessageBox.Show(Resource.Mes_621, Resource.Title_002);
            }
            else
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
                this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
                this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
                base.Close();
            }
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseStripMenuItem1.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.filterToolStripMenuItem.Text = Resource.Menu_Filter;
            this.unFilterToolStripMenuItem.Text = Resource.Menu_Unfilter;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Mark_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
            this.zWBToolStripMenuItem.Text = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.Contract_068;
            this.synchronizeToolStripMenuItem.Text = Resource.Menu_Synchronize;
            this.synchToolStripMenuItem.Text = Resource.Menu_Synchronize_All;
            this.copyToAllLocationsToolStripMenuItem.Text = Resource.Menu_Copy_To_All_Locations;
            this.copyThisDriverToolStripMenuItem.Text = Resource.Menu_Copy_Driver;
            this.copyAllDriversToolStripMenuItem.Text = Resource.Menu_Copy_All_Driver;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.captureDriverLicenseIDToolStripMenuItem.Text = Resource.Menu_Capture_Driver_License_ID_Photo;
            this.Text = Resource.Title_Driver;
        }

        private void unblacklistToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void unFilterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.pFilter = "";
            this.filter();
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.ztable.BeforeEdit(this.dataGridView1, "VIEW"))
            {
                FormDriverEntry entry = new FormDriverEntry {
                    pMode = "VIEW",
                    zTable = this.ztable,
                    Text = Resource.Title_View_Driver,
                    nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                this.ztable.UnLock();
                entry.Dispose();
            }
        }
    }
}

