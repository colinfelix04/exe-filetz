﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormEstate : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private DataTable updTable = new DataTable();
        private DataTable retTable = new DataTable();
        private string[] zwbResult = new string[3];
        private string[] zwbRow = new string[0x10];
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private DataGridView dataGridView1;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem printToolStripMenuItem;
        public ToolStripMenuItem closeToolStripMenuItem;
        public TextBox TextFind;
        public Button buttonFind;
        public Panel panel1;
        private ToolStripMenuItem chooseStripMenuItem1;
        private ToolStripMenuItem zWBToolStripMenuItem;
        private ToolStripMenuItem synchronizeToolStripMenuItem;
        private ToolStripMenuItem synchronizeAllToolStripMenuItem;
        private ProgressBar progressBar1;
        private ToolStripMenuItem copyToAllLocationToolStripMenuItem;
        private ToolStripMenuItem copyThisEstateToolStripMenuItem;
        private ToolStripMenuItem copyAllEstatesToolStripMenuItem;
        private ToolStripMenuItem viewRecordToolStripMenuItem;

        public FormEstate()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            WBSetting.OpenSetting();
            this.zWBToolStripMenuItem.Visible = WBSetting.zwb == "Y";
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormEstateEntry entry = new FormEstateEntry {
                    pMode = "ADD",
                    zTable = this.ztable,
                    Text = Resource.Title_Add_Estate,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                    string[] aField = new string[] { "Estate_Code" };
                    string[] aFind = new string[] { entry.textBox1.Text };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                entry.Dispose();
                this.ztable.UnLock();
                if (this.dataGridView1.RowCount > 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = true;
                    this.editRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_ESTATE", "E");
                    this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_ESTATE", "D");
                    this.printToolStripMenuItem.Enabled = true;
                    this.zWBToolStripMenuItem.Enabled = true;
                    this.chooseStripMenuItem1.Enabled = true;
                    this.copyToAllLocationToolStripMenuItem.Enabled = true;
                }
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void chooseStripMenuItem1_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void copyAllEstatesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this.dataGridView1.Rows.Count + " " + Resource.Mes_Confirm_Copy_Estate, Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                string[] textArray1 = new string[] { Resource.Mes_Copy_From, " ", WBData.sCoyCode, " - ", WBData.sLocCode };
                Program.copyToLoc("wb_estate", "", 1, string.Concat(textArray1));
                MessageBox.Show(Resource.Mes_Estate_Copied);
            }
        }

        private void copyThisEstateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string key = this.dataGridView1.CurrentRow.Cells["estate_code"].Value.ToString().Trim();
            if (MessageBox.Show(key + " " + Resource.Mes_Confirm_Copy, Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                string[] textArray1 = new string[] { Resource.Mes_Copy_From, " ", WBData.sCoyCode, " - ", WBData.sLocCode };
                Program.copyToLoc("wb_estate", key, 0, string.Concat(textArray1));
                MessageBox.Show(Resource.Mes_Copied_All_Location);
            }
        }

        private void copyToAllLocationToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseStripMenuItem1.PerformClick();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.chooseStripMenuItem1.PerformClick();
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                WBTable table3 = new WBTable();
                WBTable table4 = new WBTable();
                WBTable table5 = new WBTable();
                table.OpenTable("wb_division", "Select estate_code From wb_division where " + WBData.Company(" and ( Estate_Code='" + this.ztable.DT.Rows[this.nCurrRow]["Estate_Code"].ToString() + "')"), WBData.conn);
                table2.OpenTable("wb_block", "Select estate_code From wb_block where " + WBData.Company(" and ( Estate_Code='" + this.ztable.DT.Rows[this.nCurrRow]["Estate_Code"].ToString() + "')"), WBData.conn);
                table3.OpenTable("wb_transaction", "Select ref From wb_transaction where " + WBData.Company(" and ( Estate_Code='" + this.ztable.DT.Rows[this.nCurrRow]["Estate_Code"].ToString() + "')"), WBData.conn);
                table4.OpenTable("wb_transDivision", "Select ref From wb_transDivision where " + WBData.Company(" and ( Estate_Code='" + this.ztable.DT.Rows[this.nCurrRow]["Estate_Code"].ToString() + "')"), WBData.conn);
                string[] textArray1 = new string[] { " and ((Estate1_Code='", this.ztable.DT.Rows[this.nCurrRow]["Estate_Code"].ToString(), "') or (Estate2_Code='", this.ztable.DT.Rows[this.nCurrRow]["Estate_Code"].ToString(), "'))" };
                table5.OpenTable("wb_contract", "Select uniq From wb_contract where " + WBData.Company(string.Concat(textArray1)), WBData.conn);
                if (((table3.DT.Rows.Count <= 0) && ((table5.DT.Rows.Count <= 0) && (table.DT.Rows.Count <= 0))) && (table2.DT.Rows.Count <= 0))
                {
                    string[] textArray3 = new string[] { this.ztable.DT.Rows[this.nCurrRow]["Estate_Code"].ToString(), " - ", this.ztable.DT.Rows[this.nCurrRow]["Estate_Name"].ToString(), ".\n\n ", Resource.Mes_006 };
                    if (MessageBox.Show(string.Concat(textArray3), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        if (this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
                        {
                            FormTransCancel cancel = new FormTransCancel {
                                label1 = { Text = Resource.Estate_001 },
                                textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Estate_Code"].ToString() },
                                Text = Resource.Form_Delete_Reason,
                                label2 = { Text = Resource.Lbl_Delete_Reason }
                            };
                            cancel.textReason.Focus();
                            cancel.ShowDialog();
                            if (cancel.Saved)
                            {
                                this.changeReason = cancel.textReason.Text;
                                cancel.Dispose();
                                this.ztable.ReOpen();
                                this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                                this.ztable.DT.Rows[this.nCurrRow].Delete();
                                this.ztable.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                                Program.updateLogHeader("wb_estate", this.logKey, logField, logValue);
                                this.ztable.ReOpen();
                                this.ztable.AfterEdit("DELETE");
                            }
                            else
                            {
                                return;
                            }
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                else
                {
                    string[] textArray2 = new string[0x20];
                    textArray2[0] = Resource.Mes_150;
                    textArray2[1] = "\n\n- ";
                    textArray2[2] = Resource.Mes_Transaction;
                    textArray2[3] = "   : ";
                    textArray2[4] = table3.DT.Rows.Count.ToString();
                    textArray2[5] = " ";
                    textArray2[6] = Resource.Mes_047B;
                    textArray2[7] = "\n- ";
                    textArray2[8] = Resource.Mes_Trans_Detail;
                    textArray2[9] = " : ";
                    textArray2[10] = table4.DT.Rows.Count.ToString();
                    textArray2[11] = " ";
                    textArray2[12] = Resource.Mes_047B;
                    textArray2[13] = "\n- ";
                    textArray2[14] = Resource.Mes_DO_Contract;
                    textArray2[15] = "   : ";
                    textArray2[0x10] = table5.DT.Rows.Count.ToString();
                    textArray2[0x11] = " ";
                    textArray2[0x12] = Resource.Mes_047B;
                    textArray2[0x13] = "\n- ";
                    textArray2[20] = Resource.Mes_Block_List;
                    textArray2[0x15] = "    : ";
                    textArray2[0x16] = table2.DT.Rows.Count.ToString();
                    textArray2[0x17] = " ";
                    textArray2[0x18] = Resource.Mes_047B;
                    textArray2[0x19] = "\n- ";
                    textArray2[0x1a] = Resource.Mes_Div_List;
                    textArray2[0x1b] = "     : ";
                    textArray2[0x1c] = table.DT.Rows.Count.ToString();
                    textArray2[0x1d] = " ";
                    textArray2[30] = Resource.Mes_047B;
                    textArray2[0x1f] = "\n\n";
                    MessageBox.Show(string.Concat(textArray2), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                table3.Dispose();
                this.ztable.UnLock();
                if (this.dataGridView1.RowCount == 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = false;
                    this.editRecordToolStripMenuItem.Enabled = false;
                    this.deleteToolStripMenuItem.Enabled = false;
                    this.printToolStripMenuItem.Enabled = false;
                    this.zWBToolStripMenuItem.Enabled = false;
                    this.chooseStripMenuItem1.Enabled = false;
                    this.copyToAllLocationToolStripMenuItem.Enabled = false;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                FormEstateEntry entry = new FormEstateEntry {
                    pMode = "EDIT",
                    zTable = this.ztable,
                    Text = Resource.Title_Edit_Estate,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                    string[] aField = new string[] { "Estate_Code" };
                    string[] aFind = new string[] { entry.textBox1.Text };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                entry.Dispose();
                this.ztable.UnLock();
            }
        }

        private void FormEstate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormEstate_Load(object sender, EventArgs e)
        {
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 0x10)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    this.retTable.Columns.Add(column);
                    column.Dispose();
                    string str = " Coy,Location_Code,Estate_Code,Estate_Name,Address,City,Type_Estate,SAP_Code,show_GHG, show_RSPO, GHG_Value, RSPO_Value,Create_By,Create_Date,Change_By,Change_Date,Delete_By,Delete_Date,Deleted,zwb,token,uniq, completed";
                    if (this.pFilter != "")
                    {
                        this.ztable.OpenTable("wb_estate", "SELECT " + str + " FROM wb_estate where " + WBData.CompanyLocation(this.pFilter), WBData.conn);
                    }
                    else
                    {
                        this.ztable.OpenTable("wb_estate", "SELECT " + str + " FROM wb_estate", WBData.conn);
                    }
                    this.dataGridView1.DataSource = this.ztable.DT;
                    this.dataGridView1.Sort(this.dataGridView1.Columns["Estate_Code"], ListSortDirection.Ascending);
                    this.dataGridView1.Columns["Coy"].Visible = false;
                    this.dataGridView1.Columns["Location_Code"].Visible = false;
                    this.dataGridView1.Columns["Delete_By"].Visible = false;
                    this.dataGridView1.Columns["Delete_Date"].Visible = false;
                    this.dataGridView1.Columns["uniq"].Visible = false;
                    this.dataGridView1.Columns["token"].Visible = true;
                    this.dataGridView1.Columns["completed"].Visible = true;
                    this.dataGridView1.Columns["deleted"].Visible = false;
                    this.dataGridView1.Columns["Estate_Code"].HeaderText = Resource.Estate_001;
                    this.dataGridView1.Columns["Estate_Name"].HeaderText = Resource.Estate_002;
                    this.dataGridView1.Columns["Address"].HeaderText = Resource.Estate_003;
                    this.dataGridView1.Columns["City"].HeaderText = Resource.Estate_004;
                    this.dataGridView1.Columns["SAP_Code"].HeaderText = this.sapIDSYS + Resource.Estate_006;
                    this.dataGridView1.Columns["Type_Estate"].HeaderText = Resource.Estate_007;
                    base.KeyPreview = true;
                    if (!WBUser.CheckTrustee("MD_ESTATE", "A"))
                    {
                        this.addNewRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_ESTATE", "E"))
                    {
                        this.editRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_ESTATE", "D"))
                    {
                        this.deleteToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_ESTATE", "P"))
                    {
                        this.printToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_SYNCH", "A"))
                    {
                        this.zWBToolStripMenuItem.Enabled = false;
                    }
                    if ((this.pMode != "") && (this.pFind.Trim() != ""))
                    {
                        this.TextFind.Text = this.pFind;
                        this.buttonFind.PerformClick();
                    }
                    this.chooseStripMenuItem1.Visible = this.pMode != "";
                    this.copyToAllLocationToolStripMenuItem.Enabled = (WBSetting.copyToLoc == "Y") && (WBUser.CheckTrustee("MD_ESTATE", "A") || WBUser.CheckTrustee("MD_ESTATE", "E"));
                    if (this.dataGridView1.RowCount == 0)
                    {
                        this.viewRecordToolStripMenuItem.Enabled = false;
                        this.editRecordToolStripMenuItem.Enabled = false;
                        this.deleteToolStripMenuItem.Enabled = false;
                        this.printToolStripMenuItem.Enabled = false;
                        this.zWBToolStripMenuItem.Enabled = false;
                        this.chooseStripMenuItem1.Enabled = false;
                        this.copyToAllLocationToolStripMenuItem.Enabled = false;
                    }
                    this.zWBToolStripMenuItem.Text = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                    this.zWBToolStripMenuItem.Enabled = !WBSetting.integrationIDSYS;
                    return;
                }
                column = new DataColumn();
                this.updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        private void InitializeComponent()
        {
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.printToolStripMenuItem = new ToolStripMenuItem();
            this.zWBToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeAllToolStripMenuItem = new ToolStripMenuItem();
            this.copyToAllLocationToolStripMenuItem = new ToolStripMenuItem();
            this.copyThisEstateToolStripMenuItem = new ToolStripMenuItem();
            this.copyAllEstatesToolStripMenuItem = new ToolStripMenuItem();
            this.chooseStripMenuItem1 = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x305, 0x176);
            this.dataGridView1.TabIndex = 0x10;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseStripMenuItem1, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x305, 0x18);
            this.menuStrip1.TabIndex = 0x12;
            this.menuStrip1.Text = "menuStrip1";
            this.activitiesToolStripMenuItem.Checked = true;
            this.activitiesToolStripMenuItem.CheckState = CheckState.Checked;
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.viewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem, this.printToolStripMenuItem, this.zWBToolStripMenuItem, this.copyToAllLocationToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xb6, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xb6, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xb6, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new Size(0xb6, 0x16);
            this.printToolStripMenuItem.Text = "Print";
            ToolStripItem[] itemArray3 = new ToolStripItem[] { this.synchronizeToolStripMenuItem, this.synchronizeAllToolStripMenuItem };
            this.zWBToolStripMenuItem.DropDownItems.AddRange(itemArray3);
            this.zWBToolStripMenuItem.Name = "zWBToolStripMenuItem";
            this.zWBToolStripMenuItem.Size = new Size(0xb6, 0x16);
            this.zWBToolStripMenuItem.Text = "ZWB";
            this.synchronizeToolStripMenuItem.Name = "synchronizeToolStripMenuItem";
            this.synchronizeToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeToolStripMenuItem.Text = "Synchronize";
            this.synchronizeToolStripMenuItem.Click += new EventHandler(this.synchronizeToolStripMenuItem_Click);
            this.synchronizeAllToolStripMenuItem.Name = "synchronizeAllToolStripMenuItem";
            this.synchronizeAllToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeAllToolStripMenuItem.Text = "Synchronize All";
            this.synchronizeAllToolStripMenuItem.Click += new EventHandler(this.synchronizeAllToolStripMenuItem_Click);
            ToolStripItem[] itemArray4 = new ToolStripItem[] { this.copyThisEstateToolStripMenuItem, this.copyAllEstatesToolStripMenuItem };
            this.copyToAllLocationToolStripMenuItem.DropDownItems.AddRange(itemArray4);
            this.copyToAllLocationToolStripMenuItem.Name = "copyToAllLocationToolStripMenuItem";
            this.copyToAllLocationToolStripMenuItem.Size = new Size(0xb6, 0x16);
            this.copyToAllLocationToolStripMenuItem.Text = "Copy to All Location";
            this.copyThisEstateToolStripMenuItem.Name = "copyThisEstateToolStripMenuItem";
            this.copyThisEstateToolStripMenuItem.Size = new Size(0xa1, 0x16);
            this.copyThisEstateToolStripMenuItem.Text = "Copy This Estate";
            this.copyThisEstateToolStripMenuItem.Click += new EventHandler(this.copyThisEstateToolStripMenuItem_Click);
            this.copyAllEstatesToolStripMenuItem.Name = "copyAllEstatesToolStripMenuItem";
            this.copyAllEstatesToolStripMenuItem.Size = new Size(0xa1, 0x16);
            this.copyAllEstatesToolStripMenuItem.Text = "Copy All Estates";
            this.copyAllEstatesToolStripMenuItem.Click += new EventHandler(this.copyAllEstatesToolStripMenuItem_Click);
            this.chooseStripMenuItem1.Name = "chooseStripMenuItem1";
            this.chooseStripMenuItem1.Size = new Size(0x3b, 20);
            this.chooseStripMenuItem1.Text = "Choose";
            this.chooseStripMenuItem1.Click += new EventHandler(this.chooseStripMenuItem1_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x18e);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x305, 0x21);
            this.panel1.TabIndex = 0x11;
            this.progressBar1.Location = new Point(0x25b, 9);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xa7, 0x11);
            this.progressBar1.TabIndex = 11;
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xb6, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x305, 0x1af);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.Name = "FormEstate";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of Estate";
            base.Load += new EventHandler(this.FormEstate_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormEstate_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void synchronizeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int count = this.dataGridView1.Rows.Count;
            if (MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_035_IDSYS : Resource.Mes_035, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.progressBar1.Visible = true;
                this.progressBar1.Maximum = count;
                if (WBSetting.activeMulesoftIntegration)
                {
                    Sync.sync_estate_with_mulesoft(WBData.CompanyLocation(""));
                }
                else
                {
                    Sync.sync_estate(WBData.CompanyLocation(""));
                }
                this.progressBar1.Visible = false;
            }
        }

        private void synchronizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str = this.dataGridView1.CurrentRow.Cells["Estate_Code"].Value.ToString().Trim();
            if (MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_034_IDSYS : (Resource.Mes_034 + " " + str), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                string str2 = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString().Trim();
                if (WBSetting.activeMulesoftIntegration)
                {
                    Sync.sync_estate_with_mulesoft("uniq = '" + str2 + "'");
                }
                else
                {
                    Sync.sync_estate("uniq = '" + str2 + "'");
                }
            }
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseStripMenuItem1.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
            this.printToolStripMenuItem.Text = Resource.Menu_016;
            this.zWBToolStripMenuItem.Text = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.Contract_068;
            this.synchronizeToolStripMenuItem.Text = Resource.Menu_Synchronize;
            this.synchronizeAllToolStripMenuItem.Text = Resource.Menu_Synchronize_All;
            this.copyToAllLocationToolStripMenuItem.Text = Resource.Menu_Copy_To_All_Locations;
            this.copyThisEstateToolStripMenuItem.Text = Resource.Menu_Copy_Estate;
            this.copyAllEstatesToolStripMenuItem.Text = Resource.Menu_Copy_All_Estate;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.Text = Resource.Title_Estate;
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormEstateEntry entry = new FormEstateEntry {
                    pMode = "VIEW",
                    zTable = this.ztable,
                    Text = Resource.Title_View_Estate,
                    nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                this.ztable.UnLock();
                entry.Dispose();
            }
        }
    }
}

