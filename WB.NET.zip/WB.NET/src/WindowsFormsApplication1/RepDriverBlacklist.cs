﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class RepDriverBlacklist : Form
    {
        private IContainer components = null;
        private Label label1;
        private GroupBox groupCoyLoc;
        private Label label2;
        private Button buttonLoc;
        private TextBox textLoc;
        private Label label3;
        private Button buttonCoy;
        private TextBox textCoy;
        private Label labelCompanyName;
        private Label labelLocName;
        private GroupBox groupDate;
        private CheckBox checkBox1;
        private Label label4;
        public DateTimePicker dateTimePicker1;
        private MaskedTextBox TimeFrom;
        public DateTimePicker dateTimePicker2;
        private Label label6;
        private MaskedTextBox TimeTo;
        private Button buttonProcess;
        private Button buttonClose;

        public RepDriverBlacklist()
        {
            this.InitializeComponent();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonCoy_Click(object sender, EventArgs e)
        {
            FormCompany company = new FormCompany {
                pMode = "CHOOSE"
            };
            company.ShowDialog();
            if (company.ReturnRow != null)
            {
                this.textCoy.Text = company.ReturnRow["Coy_Code"].ToString().Trim();
                this.labelCompanyName.Text = company.ReturnRow["Coy_Name"].ToString().Trim();
            }
            company.Dispose();
        }

        private void buttonLoc_Click(object sender, EventArgs e)
        {
            if (this.textCoy.Text.Trim() == "")
            {
                MessageBox.Show(Resource.Mes_185, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textCoy.Focus();
            }
            else
            {
                FormLocation location = new FormLocation {
                    pMode = "CHOOSE",
                    pCoy = this.textCoy.Text.Trim()
                };
                location.ShowDialog();
                if (location.ReturnRow != null)
                {
                    this.textLoc.Text = location.ReturnRow["Location_Code"].ToString().Trim();
                    this.labelLocName.Text = location.ReturnRow["Location_Name"].ToString().Trim();
                }
                location.Dispose();
            }
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            if ((this.dateTimePicker2.Value - this.dateTimePicker1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                WBTable supir = this.getQuery();
                DateTime now = GetNow();
                if (supir.DT.Rows.Count <= 0)
                {
                    MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    HTML rep = new HTML();
                    rep.File = rep.File + @"\" + WBUser.UserID + "_BlacklistDriver.htm";
                    rep.Title = "Report Blacklist Driver";
                    rep.Open();
                    rep.Write(rep.Style());
                    rep.Write("<br><font size=5><b>REPORT OF BLACKLIST DRIVER</b></font><br>");
                    if (this.checkBox1.Checked)
                    {
                        rep.Write("<br><font size=3><b>For All Company & Location</b></b></font><br>");
                    }
                    else
                    {
                        string[] textArray1 = new string[] { "<br><font size=4>", this.labelCompanyName.Text, " (", this.textCoy.Text, ")</font>" };
                        rep.Write(string.Concat(textArray1));
                        string[] textArray2 = new string[] { "<br><font size=4>", this.labelLocName.Text, " (", this.textLoc.Text, ")</font><br>" };
                        rep.Write(string.Concat(textArray2));
                    }
                    rep.Write("<br><br>");
                    rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                    rep.Write("<tr class=bd>");
                    rep.Write("<td>Report Date</td>");
                    rep.Write("<td>: <b>" + now.ToShortDateString() + "</b></td>");
                    rep.Write("</tr>");
                    rep.Write("</table>");
                    rep.Write("<br/><br/>");
                    rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                    rep.Write("<tr class=bd>");
                    rep.Write("<td>Blacklist Date Between </td>");
                    rep.Write("<td>: <b>" + this.dateTimePicker1.Value.ToString("dd/MM/yyyy") + "</b></td>");
                    rep.Write("<td>&nbsp And <b>" + this.dateTimePicker2.Value.ToString("dd/MM/yyyy") + "</b></td>");
                    rep.Write("</tr>");
                    rep.Write("</table>");
                    rep.Write("<br/><br/>");
                    this.generateReport(rep, supir);
                    rep.writeSign();
                    rep.Close();
                    if (rep != null)
                    {
                        ViewReport report = new ViewReport {
                            webBrowser1 = { Url = new Uri("file:///" + rep.File) }
                        };
                        report.ShowDialog();
                        rep.Dispose();
                        report.Dispose();
                    }
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (!this.checkBox1.Checked)
            {
                this.buttonCoy.Enabled = true;
                this.buttonLoc.Enabled = true;
            }
            else
            {
                this.buttonCoy.Enabled = false;
                this.buttonLoc.Enabled = false;
                this.textCoy.Text = "";
                this.textLoc.Text = "";
                this.labelCompanyName.Text = "";
                this.labelLocName.Text = "";
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void generateReport(HTML rep, WBTable supir)
        {
            int num = 1;
            string str = "";
            string str2 = "";
            for (int i = 0; i < supir.DT.Rows.Count; i++)
            {
                DataRow row = supir.DT.Rows[i];
                if ((str != row["coy"].ToString()) || (str2 != row["location_code"].ToString()))
                {
                    if (this.checkBox1.Checked)
                    {
                        WBTable table = new WBTable();
                        WBTable table2 = new WBTable();
                        table.OpenTable("wb_company", "SELECT coy_name FROM wb_company WHERE coy_code='" + row["coy"].ToString() + "'", WBData.conn);
                        string[] textArray1 = new string[] { "SELECT location_name FROM wb_location WHERE coy = '", row["coy"].ToString(), "' AND location_code = '", row["location_code"].ToString(), "'" };
                        table2.OpenTable("wb_location", string.Concat(textArray1), WBData.conn);
                        if (table.DT.Rows.Count <= 0)
                        {
                            rep.Write("<br><br><font size=3><b>(" + row["coy"].ToString() + ")</b></font>");
                        }
                        else
                        {
                            string[] textArray2 = new string[] { "<br><br><font size=3><b>", table.DT.Rows[0]["Coy_Name"].ToString(), " (", row["coy"].ToString(), ")</b></font>" };
                            rep.Write(string.Concat(textArray2));
                        }
                        if (table2.DT.Rows.Count <= 0)
                        {
                            rep.Write("<br><font size=3><b>(" + row["location_code"].ToString() + ")</b></font><br><br>");
                        }
                        else
                        {
                            string[] textArray3 = new string[] { "<br><font size=3><b>", table2.DT.Rows[0]["Location_Name"].ToString(), " (", row["location_code"].ToString(), ")</b></font><br><br>" };
                            rep.Write(string.Concat(textArray3));
                        }
                        table.Dispose();
                        table2.Dispose();
                    }
                    rep.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                    rep.Write("<tr class=bd>");
                    rep.Write("<td nowrap>No.</td>");
                    rep.Write("<td nowrap>" + Resource.DriverE_001 + "</td>");
                    rep.Write("<td nowrap>" + Resource.DriverE_002 + "</td>");
                    rep.Write("<td nowrap>" + Resource.DriverE_004 + "</td>");
                    rep.Write("<td nowrap>" + Resource.DriverE_005 + "</td>");
                    rep.Write("<td nowrap>" + Resource.DriverE_006 + "</td>");
                    rep.Write("<td nowrap>" + Resource.DriverE_008 + "</td>");
                    rep.Write("<td nowrap>" + Resource.DriverE_003 + "</td>");
                    rep.Write("</tr>");
                    str = row["coy"].ToString();
                    str2 = row["location_code"].ToString();
                    num = 1;
                }
                rep.Write("<tr class=bd>");
                rep.Write("<td valign=top>" + num + "</td>");
                rep.Write("<td valign=top>" + row["License_No"].ToString() + "</td>");
                rep.Write("<td valign=top>" + row["Name"].ToString() + "</td>");
                rep.Write("<td valign=top>" + row["Address"].ToString() + "</td>");
                rep.Write("<td valign=top>" + row["Birth_Place"].ToString() + "</td>");
                rep.Write("<td valign=top>" + row["Birth_Date"].ToString() + "</td>");
                rep.Write("<td valign=top>" + row["Reason"].ToString() + "</td>");
                rep.Write("<td valign=top>" + row["Truck_Number"].ToString() + "</td>");
                rep.Write("</tr>");
                num++;
                DataRow row2 = null;
                if (i >= (supir.DT.Rows.Count - 1))
                {
                    if (i == (supir.DT.Rows.Count - 1))
                    {
                        rep.Write("</table><br><br>");
                    }
                }
                else
                {
                    row2 = supir.DT.Rows[i + 1];
                    if ((row["coy"].ToString() != row2["coy"].ToString()) || (row["location_code"].ToString() != row2["location_code"].ToString()))
                    {
                        rep.Write("</table><br><br>");
                    }
                }
            }
        }

        public static DateTime GetNow()
        {
            WBTable table = new WBTable();
            table.OpenTable("Tbl_now", "Select getdate() as now where 1=1", WBData.conn);
            return Convert.ToDateTime(table.DT.Rows[0]["now"].ToString());
        }

        private WBTable getQuery()
        {
            WBTable table = new WBTable();
            string sqltext = "";
            DateTime time = this.dateTimePicker2.Value.AddDays(1.0);
            string[] textArray1 = new string[] { sqltext, "Select * From wb_driver where change_date >= '", this.dateTimePicker1.Value.ToString("yyyy-MM-dd"), " 00:00:00'AND change_date <= '", time.ToString("yyyy-MM-dd"), " 00:00:00'" };
            sqltext = string.Concat(textArray1);
            if (this.checkBox1.Checked)
            {
                sqltext = sqltext + " AND black_list = 'Y'";
            }
            else
            {
                string[] textArray2 = new string[] { sqltext, " AND coy = '", this.textCoy.Text, "' and location_code = '", this.textLoc.Text, "' and black_list = 'Y'" };
                sqltext = string.Concat(textArray2);
            }
            sqltext = sqltext + "ORDER BY coy, location_code, license_no";
            table.OpenTable("wb_driver", sqltext, WBData.conn);
            return table;
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.groupCoyLoc = new GroupBox();
            this.checkBox1 = new CheckBox();
            this.labelLocName = new Label();
            this.labelCompanyName = new Label();
            this.buttonLoc = new Button();
            this.textLoc = new TextBox();
            this.label3 = new Label();
            this.buttonCoy = new Button();
            this.textCoy = new TextBox();
            this.label2 = new Label();
            this.groupDate = new GroupBox();
            this.TimeTo = new MaskedTextBox();
            this.dateTimePicker2 = new DateTimePicker();
            this.label6 = new Label();
            this.TimeFrom = new MaskedTextBox();
            this.dateTimePicker1 = new DateTimePicker();
            this.label4 = new Label();
            this.buttonProcess = new Button();
            this.buttonClose = new Button();
            this.groupCoyLoc.SuspendLayout();
            this.groupDate.SuspendLayout();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x87, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Report Blacklist Driver";
            this.groupCoyLoc.Controls.Add(this.checkBox1);
            this.groupCoyLoc.Controls.Add(this.labelLocName);
            this.groupCoyLoc.Controls.Add(this.labelCompanyName);
            this.groupCoyLoc.Controls.Add(this.buttonLoc);
            this.groupCoyLoc.Controls.Add(this.textLoc);
            this.groupCoyLoc.Controls.Add(this.label3);
            this.groupCoyLoc.Controls.Add(this.buttonCoy);
            this.groupCoyLoc.Controls.Add(this.textCoy);
            this.groupCoyLoc.Controls.Add(this.label2);
            this.groupCoyLoc.Location = new Point(15, 0x27);
            this.groupCoyLoc.Name = "groupCoyLoc";
            this.groupCoyLoc.Size = new Size(0x1d9, 0x5c);
            this.groupCoyLoc.TabIndex = 1;
            this.groupCoyLoc.TabStop = false;
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new Point(0x1f, 0x45);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new Size(0x72, 0x11);
            this.checkBox1.TabIndex = 8;
            this.checkBox1.Text = "Select All Location";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new EventHandler(this.checkBox1_CheckedChanged);
            this.labelLocName.AutoSize = true;
            this.labelLocName.Location = new Point(180, 0x2e);
            this.labelLocName.Name = "labelLocName";
            this.labelLocName.Size = new Size(0x4f, 13);
            this.labelLocName.TabIndex = 7;
            this.labelLocName.Text = "Location Name";
            this.labelCompanyName.AutoSize = true;
            this.labelCompanyName.Location = new Point(180, 0x10);
            this.labelCompanyName.Name = "labelCompanyName";
            this.labelCompanyName.Size = new Size(0x52, 13);
            this.labelCompanyName.TabIndex = 6;
            this.labelCompanyName.Text = "Company Name";
            this.buttonLoc.Location = new Point(0x97, 0x29);
            this.buttonLoc.Margin = new Padding(0);
            this.buttonLoc.Name = "buttonLoc";
            this.buttonLoc.Size = new Size(0x17, 0x17);
            this.buttonLoc.TabIndex = 5;
            this.buttonLoc.Text = "..";
            this.buttonLoc.UseVisualStyleBackColor = true;
            this.buttonLoc.Click += new EventHandler(this.buttonLoc_Click);
            this.textLoc.BackColor = SystemColors.Control;
            this.textLoc.CharacterCasing = CharacterCasing.Upper;
            this.textLoc.Location = new Point(0x55, 0x2b);
            this.textLoc.Name = "textLoc";
            this.textLoc.ReadOnly = true;
            this.textLoc.Size = new Size(60, 20);
            this.textLoc.TabIndex = 4;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x1c, 0x2e);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x30, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Location";
            this.buttonCoy.Location = new Point(0x97, 11);
            this.buttonCoy.Margin = new Padding(0);
            this.buttonCoy.Name = "buttonCoy";
            this.buttonCoy.Size = new Size(0x17, 0x17);
            this.buttonCoy.TabIndex = 2;
            this.buttonCoy.Text = "..";
            this.buttonCoy.UseVisualStyleBackColor = true;
            this.buttonCoy.Click += new EventHandler(this.buttonCoy_Click);
            this.textCoy.BackColor = SystemColors.Control;
            this.textCoy.CharacterCasing = CharacterCasing.Upper;
            this.textCoy.Location = new Point(0x55, 13);
            this.textCoy.Name = "textCoy";
            this.textCoy.ReadOnly = true;
            this.textCoy.Size = new Size(60, 20);
            this.textCoy.TabIndex = 1;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x1c, 0x10);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x33, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Company";
            this.groupDate.Controls.Add(this.TimeTo);
            this.groupDate.Controls.Add(this.dateTimePicker2);
            this.groupDate.Controls.Add(this.label6);
            this.groupDate.Controls.Add(this.TimeFrom);
            this.groupDate.Controls.Add(this.dateTimePicker1);
            this.groupDate.Controls.Add(this.label4);
            this.groupDate.Location = new Point(15, 0x89);
            this.groupDate.Name = "groupDate";
            this.groupDate.Size = new Size(0x1d9, 0x2b);
            this.groupDate.TabIndex = 2;
            this.groupDate.TabStop = false;
            this.TimeTo.Location = new Point(0x19b, 15);
            this.TimeTo.Mask = "00:00";
            this.TimeTo.Name = "TimeTo";
            this.TimeTo.Size = new Size(0x29, 20);
            this.TimeTo.TabIndex = 0x47;
            this.TimeTo.ValidatingType = typeof(DateTime);
            this.dateTimePicker2.Format = DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new Point(300, 15);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new Size(0x69, 20);
            this.dateTimePicker2.TabIndex = 4;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xf2, 0x13);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x34, 13);
            this.label6.TabIndex = 70;
            this.label6.Text = "To Date :";
            this.TimeFrom.Location = new Point(0xc3, 15);
            this.TimeFrom.Mask = "00:00";
            this.TimeFrom.Name = "TimeFrom";
            this.TimeFrom.Size = new Size(0x24, 20);
            this.TimeFrom.TabIndex = 0x45;
            this.TimeFrom.ValidatingType = typeof(DateTime);
            this.dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new Point(0x54, 15);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new Size(0x69, 20);
            this.dateTimePicker1.TabIndex = 3;
            this.label4.AutoSize = true;
            this.label4.Location = new Point(12, 0x13);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x3e, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "From Date :";
            this.buttonProcess.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonProcess.Location = new Point(0x106, 0xc0);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(110, 0x22);
            this.buttonProcess.TabIndex = 3;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.buttonClose.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonClose.Location = new Point(0x17a, 0xc0);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new Size(110, 0x22);
            this.buttonClose.TabIndex = 4;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new EventHandler(this.buttonClose_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1f7, 0xee);
            base.ControlBox = false;
            base.Controls.Add(this.buttonClose);
            base.Controls.Add(this.buttonProcess);
            base.Controls.Add(this.groupDate);
            base.Controls.Add(this.groupCoyLoc);
            base.Controls.Add(this.label1);
            base.Name = "RepDriverBlacklist";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "RepDriverBlacklist";
            this.groupCoyLoc.ResumeLayout(false);
            this.groupCoyLoc.PerformLayout();
            this.groupDate.ResumeLayout(false);
            this.groupDate.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

