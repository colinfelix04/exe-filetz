﻿namespace WindowsFormsApplication1
{
    using Camera.Utility;
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Properties;
    using WindowsFormsApplication1.Utility;

    public class FormDriverEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public int nCurrRowD;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public WBTable trans = new WBTable();
        private IContainer components = null;
        private TextBox textBox5;
        private Label label8;
        private Button button2;
        private Button button1;
        private CheckBox checkBox1;
        private TextBox textBoxName;
        public TextBox textBoxLicenseNo;
        private Label label9;
        private Label label4;
        private Label label3;
        private Label label1;
        private TextBox textBox3;
        private Label label2;
        private TextBox textBox4;
        private Label label5;
        private DateTimePicker dateTimePicker1;
        private Label label6;
        private TextBox textTruck_Number;
        private TextBox textPhone;
        private Label labelTelephone;
        private PictureBox _captureImgPreview;
        private Button btnCapturePhoto;
        private Label labelCapturePreview;
        private GroupBox LicensePictureBox;

        public FormDriverEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void _captureImgPreview_Click(object sender, EventArgs e)
        {
            FormCameraPreview preview = new FormCameraPreview {
                camera_type = "PREVIEW_IMAGE",
                pic_box = { Image = this._captureImgPreview.Image }
            };
            preview.ShowDialog();
            preview.Dispose();
        }

        private void btnCapturePhoto_Click(object sender, EventArgs e)
        {
            this.capture_img(this._captureImgPreview);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table3;
            if (!(((this.pMode == "ADD") && WBCamera.ImageCompareString(this._captureImgPreview.Image, Resources.NoImage)) && WBSetting.activeRegistrationRequireLicensePhoto))
            {
                if ((this.textBoxLicenseNo.Text.Length < 8) || (this.textBoxLicenseNo.Text.Length > 20))
                {
                    MessageBox.Show("License Number must be more than 8 and less than 20", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textBoxLicenseNo.Focus();
                    return;
                }
                else
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_condition", "SELECT uniq FROM wb_condition WHERE Condition_Code = 'SMS_TOKEN_AUTO_CALLING'", WBData.conn);
                    if ((table.DT.Rows.Count <= 0) || (this.textPhone.Text.Trim() != ""))
                    {
                        table.Dispose();
                        TextBox[] aText = new TextBox[] { this.textBoxLicenseNo, this.textBoxName, this.textBox3 };
                        if (!Program.CheckEmpty(aText))
                        {
                            if (this.checkBox1.Checked)
                            {
                                TextBox[] boxArray2 = new TextBox[] { this.textBox5 };
                                if (Program.CheckEmpty(boxArray2))
                                {
                                    MessageBox.Show(Resource.Mes_Blacklist_Reason);
                                    return;
                                }
                            }
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_driver", "Select Uniq,deleted From wb_driver Where " + WBData.CompanyLocation(" and License_No='" + this.textBoxLicenseNo.Text.Trim() + "'"), WBData.conn);
                            if ((table2.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table2.DT.Rows[0]["uniq"].ToString().Trim()))))
                            {
                                table2.Dispose();
                                Cursor.Current = Cursors.WaitCursor;
                                this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                                if ((this.pMode != "EDIT") || (this.textBoxLicenseNo.Text.Trim() == this.OldCode.Trim()))
                                {
                                    goto TR_0028;
                                }
                                else
                                {
                                    table3 = new WBTable();
                                    table3.OpenTable("wb_transaction", "Select uniq From wb_transaction where " + WBData.Company(" and (License_No='" + this.zTable.DT.Rows[this.nCurrRow]["License_No"].ToString() + "')"), WBData.conn);
                                    Cursor.Current = Cursors.Default;
                                    if (table3.DT.Rows.Count <= 0)
                                    {
                                        goto TR_0029;
                                    }
                                    else
                                    {
                                        string[] textArray1 = new string[13];
                                        textArray1[0] = Resource.Mes_Replace_License_No;
                                        textArray1[1] = " ";
                                        textArray1[2] = this.OldCode;
                                        textArray1[3] = " -> ";
                                        textArray1[4] = this.textBoxLicenseNo.Text;
                                        textArray1[5] = "\n\n";
                                        textArray1[6] = Resource.Msg_Replace_Warning;
                                        textArray1[7] = "\n( ";
                                        textArray1[8] = table3.DT.Rows.Count.ToString();
                                        textArray1[9] = " ";
                                        textArray1[10] = Resource.Mes_Records;
                                        textArray1[11] = " )\n\n";
                                        textArray1[12] = Resource.Mes_Confirm_Continue;
                                        if (MessageBox.Show(string.Concat(textArray1), Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                        {
                                            this.ReplaceAll = true;
                                            goto TR_0029;
                                        }
                                        else
                                        {
                                            this.ReplaceAll = false;
                                            this.textBoxLicenseNo.Focus();
                                        }
                                    }
                                }
                            }
                            else if (table2.DT.Rows[0]["deleted"].ToString() == "Y")
                            {
                                table2.Dispose();
                                MessageBox.Show(Resource.Mes_624, Resource.Title_007, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.textBoxLicenseNo.Focus();
                            }
                            else
                            {
                                table2.Dispose();
                                MessageBox.Show(Resource.Mes_044, Resource.Title_007, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.textBoxLicenseNo.Focus();
                            }
                            return;
                        }
                        else
                        {
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.DriverE_009, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        table.Dispose();
                        this.textPhone.Focus();
                        return;
                    }
                }
            }
            else
            {
                MessageBox.Show(Resource.DriverE_011, Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return;
            }
            goto TR_0029;
        TR_0028:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.DriverE_001 },
                    textRefNo = { Text = this.textBoxLicenseNo.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            if (WBSetting.activeRegistrationRequireLicensePhoto && !new WBCamera().savePhoto(WBSetting.licensePhoto_path, "LICENSEID_" + this.textBoxLicenseNo.Text.ToString().Trim() + ".jpg", this._captureImgPreview.Image, ""))
            {
                MessageBox.Show("Error when saving photo. Please try again. \n If problem still presists, please contact IT for assitance.");
            }
            else
            {
                this.zTable.ReOpen();
                this.nCurrRowD = this.zTable.GetPosRec(this.zTable.uniq);
                if (this.pMode == "ADD")
                {
                    this.zTable.DR = this.zTable.DT.NewRow();
                }
                else
                {
                    this.zTable.DR = this.zTable.DT.Rows[this.nCurrRowD];
                    this.logKey = this.zTable.DR["uniq"].ToString();
                    this.zTable.DR.BeginEdit();
                }
                this.zTable.DR["Coy"] = WBData.sCoyCode;
                this.zTable.DR["Location_Code"] = WBData.sLocCode;
                this.zTable.DR["License_No"] = this.textBoxLicenseNo.Text.ToString().Trim();
                this.zTable.DR["Name"] = this.textBoxName.Text.ToString().Trim();
                if (this.textBox3.Text == "")
                {
                    this.textBox3.Text = "-";
                }
                this.zTable.DR["Address"] = this.textBox3.Text;
                this.zTable.DR["Birth_Place"] = this.textBox4.Text;
                this.zTable.DR["Reason"] = this.textBox5.Text;
                this.zTable.DR["Truck_Number"] = this.textTruck_Number.Text;
                this.zTable.DR["Birth_Date"] = DateTime.Parse(this.dateTimePicker1.Value.ToString().Substring(0, 10));
                this.zTable.DR["Black_List"] = this.checkBox1.Checked ? "Y" : "N";
                this.zTable.DR["Phone"] = this.textPhone.Text;
                if (this.pMode == "ADD")
                {
                    this.zTable.DR["Create_By"] = WBUser.UserID;
                    this.zTable.DR["Create_Date"] = DateTime.Now;
                    this.zTable.DT.Rows.Add(this.zTable.DR);
                }
                else
                {
                    this.zTable.DR["Change_By"] = WBUser.UserID;
                    this.zTable.DR["Change_Date"] = DateTime.Now;
                    this.zTable.DR.EndEdit();
                }
                this.zTable.Save();
                if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
                {
                    if (this.pMode == "ADD")
                    {
                        WBTable table4 = new WBTable();
                        table4.OpenTable("wb_driver", "SELECT uniq FROM wb_driver WHERE " + WBData.CompanyLocation(" AND license_no = '" + this.textBoxLicenseNo.Text.ToString().Trim() + "' and (Deleted IS NULL OR Deleted <> 'Y') "), WBData.conn);
                        this.logKey = table4.DT.Rows[0]["uniq"].ToString();
                        table4.Dispose();
                    }
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                    Program.updateLogHeader("wb_driver", this.logKey, logField, logValue);
                }
                string str = "";
                if (this.pMode == "ADD")
                {
                    string[] textArray4 = new string[] { "(Triggered add new driver in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                    str = string.Concat(textArray4);
                }
                else if (this.pMode == "EDIT")
                {
                    string[] textArray5 = new string[] { "(Triggered edit driver in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                    str = string.Concat(textArray5);
                }
                Program.copyToLoc("wb_driver", this.textBoxLicenseNo.Text, 0, this.changeReason + " " + str);
                if ((this.pMode == "EDIT") && (this.textBoxLicenseNo.Text != this.OldCode))
                {
                    Program.copyToLoc("wb_driver", this.OldCode, 0, this.changeReason + " " + str);
                }
                if ((this.pMode == "EDIT") && this.ReplaceAll)
                {
                }
                this.saved = true;
                Cursor.Current = Cursors.Default;
                base.Close();
            }
            return;
        TR_0029:
            table3.Dispose();
            goto TR_0028;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void capture_img(PictureBox video_panel)
        {
            if (!ReferenceEquals(video_panel.Image, null))
            {
                FormCameraCapture capture = new FormCameraCapture();
                if ((string.IsNullOrEmpty(WBSetting.cam1_type) || ((WBSetting.cam1_type != "WEB_CAMERA") || string.IsNullOrEmpty(WBSetting.cam1))) || (WBSetting.cam1 != "Y"))
                {
                    if ((string.IsNullOrEmpty(WBSetting.cam2_type) || ((WBSetting.cam2_type != "WEB_CAMERA") || string.IsNullOrEmpty(WBSetting.cam2))) || (WBSetting.cam2 != "Y"))
                    {
                        if ((string.IsNullOrEmpty(WBSetting.cam3_type) || ((WBSetting.cam3_type != "WEB_CAMERA") || string.IsNullOrEmpty(WBSetting.cam3))) || (WBSetting.cam3 != "Y"))
                        {
                            if ((string.IsNullOrEmpty(WBSetting.cam4_type) || ((WBSetting.cam4_type != "WEB_CAMERA") || string.IsNullOrEmpty(WBSetting.cam4))) || (WBSetting.cam4 != "Y"))
                            {
                                if ((string.IsNullOrEmpty(WBSetting.cam5_type) || ((WBSetting.cam5_type != "WEB_CAMERA") || string.IsNullOrEmpty(WBSetting.cam5))) || (WBSetting.cam5 != "Y"))
                                {
                                    MessageBox.Show(Resource.Mes_Please_Maintain_Web_Camera, Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    return;
                                }
                                else
                                {
                                    MessageBox.Show(string.Format(Resource.Mes_Connecting_to_Camera, 5), Resource.Mes_Success, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    capture.webcam_name = WBSetting.cam5_web;
                                    capture.camera_type = "WEB_CAMERA";
                                }
                            }
                            else
                            {
                                MessageBox.Show(string.Format(Resource.Mes_Connecting_to_Camera, 4), Resource.Mes_Success, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                capture.webcam_name = WBSetting.cam4_web;
                                capture.camera_type = "WEB_CAMERA";
                            }
                        }
                        else
                        {
                            MessageBox.Show(string.Format(Resource.Mes_Connecting_to_Camera, 3), Resource.Mes_Success, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            capture.webcam_name = WBSetting.cam3_web;
                            capture.camera_type = "WEB_CAMERA";
                        }
                    }
                    else
                    {
                        MessageBox.Show(string.Format(Resource.Mes_Connecting_to_Camera, 2), Resource.Mes_Success, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        capture.webcam_name = WBSetting.cam2_web;
                        capture.camera_type = "WEB_CAMERA";
                    }
                }
                else
                {
                    MessageBox.Show(string.Format(Resource.Mes_Connecting_to_Camera, 1), Resource.Mes_Success, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    capture.webcam_name = WBSetting.cam1_web;
                    capture.camera_type = "WEB_CAMERA";
                }
                capture.pic_box.Image = video_panel.Image;
                capture.ShowDialog();
                if (capture.captured)
                {
                    this._captureImgPreview.Image = capture.pic_box.Image;
                }
                capture.Dispose();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            this.textBox5.Enabled = this.checkBox1.Checked;
            if (this.checkBox1.Checked)
            {
                this.textBox5.Focus();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormDriverEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormDriverEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.dateTimePicker1.MaxDate = DateTime.Now;
            if (this.pMode == "EDIT")
            {
                this.textBoxLicenseNo.ReadOnly = true;
            }
            this.LicensePictureBox.Visible = WBSetting.activeRegistrationRequireLicensePhoto;
            if (this.pMode != "ADD")
            {
                this.textBoxLicenseNo.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["License_No"].Value.ToString();
                this.OldCode = this.textBoxLicenseNo.Text;
                this.textBoxName.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Name"].Value.ToString();
                this.textBox3.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Address"].Value.ToString();
                this.textBox4.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Birth_Place"].Value.ToString();
                this.textBox5.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Reason"].Value.ToString();
                this.textTruck_Number.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Truck_Number"].Value.ToString();
                this.textPhone.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Phone"].Value.ToString();
                this.checkBox1.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Black_List"].Value.ToString() == "Y";
                this.checkBox1.Enabled = !this.checkBox1.Checked ? WBUser.CheckTrustee("BLACKLIST_DRIVER", "A") : WBUser.CheckTrustee("BLACKLIST_DRIVER", "E");
                this.textBox5.Enabled = this.checkBox1.Enabled && this.checkBox1.Checked;
                this.dateTimePicker1.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Birth_Date"].Value.ToString();
                this.btnCapturePhoto.Enabled = false;
                if (WBSetting.activeRegistrationRequireLicensePhoto)
                {
                    this.btnCapturePhoto.Enabled = true;
                    new WBCamera().loadImageV2(WBSetting.licensePhoto_path, "LICENSEID_" + this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Uniq"].Value.ToString() + ".jpg", this._captureImgPreview);
                }
            }
            if (this.pMode == "VIEW")
            {
                if (this.checkBox1.Checked)
                {
                    this.label9.Visible = true;
                    this.checkBox1.Visible = true;
                    this.textBox5.Visible = true;
                    this.label8.Visible = true;
                }
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.button2.Text = Resource.Btn_Close;
                this.button2.Enabled = true;
            }
        }

        private void InitializeComponent()
        {
            this.textBox5 = new TextBox();
            this.label8 = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.checkBox1 = new CheckBox();
            this.textBoxName = new TextBox();
            this.textBoxLicenseNo = new TextBox();
            this.label9 = new Label();
            this.label4 = new Label();
            this.label3 = new Label();
            this.label1 = new Label();
            this.textBox3 = new TextBox();
            this.label2 = new Label();
            this.textBox4 = new TextBox();
            this.label5 = new Label();
            this.dateTimePicker1 = new DateTimePicker();
            this.label6 = new Label();
            this.textTruck_Number = new TextBox();
            this.textPhone = new TextBox();
            this.labelTelephone = new Label();
            this._captureImgPreview = new PictureBox();
            this.btnCapturePhoto = new Button();
            this.labelCapturePreview = new Label();
            this.LicensePictureBox = new GroupBox();
            ((ISupportInitialize) this._captureImgPreview).BeginInit();
            this.LicensePictureBox.SuspendLayout();
            base.SuspendLayout();
            this.textBox5.CharacterCasing = CharacterCasing.Upper;
            this.textBox5.Enabled = false;
            this.textBox5.Location = new Point(0xab, 0x134);
            this.textBox5.Margin = new Padding(4, 4, 4, 4);
            this.textBox5.MaxLength = 50;
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new Size(0xf8, 0x18);
            this.textBox5.TabIndex = 7;
            this.textBox5.Visible = false;
            this.label8.Location = new Point(13, 0x137);
            this.label8.Margin = new Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x95, 0x10);
            this.label8.TabIndex = 0x43;
            this.label8.Text = "Blacklist Reason";
            this.label8.TextAlign = ContentAlignment.MiddleRight;
            this.label8.Visible = false;
            this.button2.Location = new Point(0x37d, 0x114);
            this.button2.Margin = new Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new Size(100, 0x3a);
            this.button2.TabIndex = 9;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x311, 0x114);
            this.button1.Margin = new Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new Size(100, 0x3a);
            this.button1.TabIndex = 8;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new Point(0xa9, 0x11a);
            this.checkBox1.Margin = new Padding(4, 4, 4, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new Size(80, 0x15);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "Blocked";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.Visible = false;
            this.checkBox1.CheckedChanged += new EventHandler(this.checkBox1_CheckedChanged);
            this.textBoxName.CharacterCasing = CharacterCasing.Upper;
            this.textBoxName.Location = new Point(0xab, 0x2f);
            this.textBoxName.Margin = new Padding(4, 4, 4, 4);
            this.textBoxName.MaxLength = 50;
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new Size(0x16b, 0x16);
            this.textBoxName.TabIndex = 2;
            this.textBoxName.KeyPress += new KeyPressEventHandler(this.textBoxName_KeyPress);
            this.textBoxName.Leave += new EventHandler(this.textBoxName_Leave);
            this.textBoxLicenseNo.CharacterCasing = CharacterCasing.Upper;
            this.textBoxLicenseNo.Location = new Point(0xab, 15);
            this.textBoxLicenseNo.Margin = new Padding(4, 4, 4, 4);
            this.textBoxLicenseNo.MaxLength = 20;
            this.textBoxLicenseNo.Name = "textBoxLicenseNo";
            this.textBoxLicenseNo.Size = new Size(0x16b, 0x16);
            this.textBoxLicenseNo.TabIndex = 1;
            this.textBoxLicenseNo.KeyPress += new KeyPressEventHandler(this.textBoxLicenseNo_KeyPress);
            this.textBoxLicenseNo.Leave += new EventHandler(this.textBoxLicenseNo_Leave);
            this.label9.Location = new Point(13, 0x11b);
            this.label9.Margin = new Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x95, 0x10);
            this.label9.TabIndex = 0x3e;
            this.label9.Text = "Blacklist";
            this.label9.TextAlign = ContentAlignment.MiddleRight;
            this.label9.Visible = false;
            this.label4.Location = new Point(13, 0x52);
            this.label4.Margin = new Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x95, 0x10);
            this.label4.TabIndex = 60;
            this.label4.Text = "Address";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            this.label3.Location = new Point(13, 50);
            this.label3.Margin = new Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x95, 0x10);
            this.label3.TabIndex = 0x3b;
            this.label3.Text = "Driver Name";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.label1.Location = new Point(13, 0x12);
            this.label1.Margin = new Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x95, 0x10);
            this.label1.TabIndex = 0x3a;
            this.label1.Text = "License No.";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.textBox3.Location = new Point(0xa9, 0x4f);
            this.textBox3.Margin = new Padding(4, 4, 4, 4);
            this.textBox3.MaxLength = 150;
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Size(0x240, 0x29);
            this.textBox3.TabIndex = 3;
            this.textBox3.KeyPress += new KeyPressEventHandler(this.textBox3_KeyPress);
            this.label2.Location = new Point(13, 0x84);
            this.label2.Margin = new Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x95, 0x10);
            this.label2.TabIndex = 0x45;
            this.label2.Text = "Place of Birth";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.textBox4.Location = new Point(0xab, 0x80);
            this.textBox4.Margin = new Padding(4, 4, 4, 4);
            this.textBox4.MaxLength = 50;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Size(0x16b, 0x16);
            this.textBox4.TabIndex = 4;
            this.label5.Location = new Point(13, 0xee);
            this.label5.Margin = new Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x95, 0x10);
            this.label5.TabIndex = 0x47;
            this.label5.Text = "Date of Birth";
            this.label5.TextAlign = ContentAlignment.MiddleRight;
            this.dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new Point(0xa9, 0xea);
            this.dateTimePicker1.Margin = new Padding(4, 4, 4, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new Size(0x88, 0x16);
            this.dateTimePicker1.TabIndex = 5;
            this.label6.Location = new Point(13, 0xce);
            this.label6.Margin = new Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x95, 0x10);
            this.label6.TabIndex = 0x48;
            this.label6.Text = "Vehicle No.";
            this.label6.TextAlign = ContentAlignment.MiddleRight;
            this.textTruck_Number.Location = new Point(0xab, 0xca);
            this.textTruck_Number.Margin = new Padding(4, 4, 4, 4);
            this.textTruck_Number.MaxLength = 20;
            this.textTruck_Number.Name = "textTruck_Number";
            this.textTruck_Number.Size = new Size(0xad, 0x16);
            this.textTruck_Number.TabIndex = 0x49;
            this.textPhone.Location = new Point(0xab, 160);
            this.textPhone.Margin = new Padding(4, 4, 4, 4);
            this.textPhone.MaxLength = 12;
            this.textPhone.Name = "textPhone";
            this.textPhone.Size = new Size(0xad, 0x16);
            this.textPhone.TabIndex = 0x4a;
            this.textPhone.KeyPress += new KeyPressEventHandler(this.textPhone_KeyPress);
            this.labelTelephone.Location = new Point(13, 0xa4);
            this.labelTelephone.Margin = new Padding(4, 0, 4, 0);
            this.labelTelephone.Name = "labelTelephone";
            this.labelTelephone.Size = new Size(0x95, 0x10);
            this.labelTelephone.TabIndex = 0x4b;
            this.labelTelephone.Text = "Phone";
            this.labelTelephone.TextAlign = ContentAlignment.MiddleRight;
            this._captureImgPreview.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this._captureImgPreview.BackgroundImageLayout = ImageLayout.Stretch;
            this._captureImgPreview.BorderStyle = BorderStyle.FixedSingle;
            this._captureImgPreview.Image = Resources.NoImage;
            this._captureImgPreview.Location = new Point(8, 0x2a);
            this._captureImgPreview.Margin = new Padding(4, 4, 4, 4);
            this._captureImgPreview.Name = "_captureImgPreview";
            this._captureImgPreview.Size = new Size(0xd1, 0xa9);
            this._captureImgPreview.SizeMode = PictureBoxSizeMode.StretchImage;
            this._captureImgPreview.TabIndex = 0x4c;
            this._captureImgPreview.TabStop = false;
            this._captureImgPreview.Click += new EventHandler(this._captureImgPreview_Click);
            this.btnCapturePhoto.Location = new Point(8, 0xdb);
            this.btnCapturePhoto.Margin = new Padding(4, 4, 4, 4);
            this.btnCapturePhoto.Name = "btnCapturePhoto";
            this.btnCapturePhoto.Size = new Size(0xd0, 0x25);
            this.btnCapturePhoto.TabIndex = 0x4d;
            this.btnCapturePhoto.Text = "&Capture Photo";
            this.btnCapturePhoto.UseVisualStyleBackColor = true;
            this.btnCapturePhoto.Click += new EventHandler(this.btnCapturePhoto_Click);
            this.labelCapturePreview.AutoSize = true;
            this.labelCapturePreview.Location = new Point(9, 0x16);
            this.labelCapturePreview.Name = "labelCapturePreview";
            this.labelCapturePreview.Size = new Size(0x76, 0x11);
            this.labelCapturePreview.TabIndex = 0x4e;
            this.labelCapturePreview.Text = "License Preview :";
            this.LicensePictureBox.Controls.Add(this.btnCapturePhoto);
            this.LicensePictureBox.Controls.Add(this.labelCapturePreview);
            this.LicensePictureBox.Controls.Add(this._captureImgPreview);
            this.LicensePictureBox.Location = new Point(0x304, 5);
            this.LicensePictureBox.Margin = new Padding(4, 4, 4, 4);
            this.LicensePictureBox.Name = "LicensePictureBox";
            this.LicensePictureBox.Padding = new Padding(4, 4, 4, 4);
            this.LicensePictureBox.Size = new Size(0xdd, 0x107);
            this.LicensePictureBox.TabIndex = 0x4f;
            this.LicensePictureBox.TabStop = false;
            this.LicensePictureBox.Text = "License Picture";
            base.AutoScaleDimensions = new SizeF(8f, 16f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x3ef, 0x15b);
            base.ControlBox = false;
            base.Controls.Add(this.LicensePictureBox);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.textPhone);
            base.Controls.Add(this.labelTelephone);
            base.Controls.Add(this.textTruck_Number);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.dateTimePicker1);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.textBox4);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textBox3);
            base.Controls.Add(this.textBox5);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.checkBox1);
            base.Controls.Add(this.textBoxName);
            base.Controls.Add(this.textBoxLicenseNo);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label1);
            base.Margin = new Padding(4, 4, 4, 4);
            base.Name = "FormDriverEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Add/Edit Driver";
            base.Load += new EventHandler(this.FormDriverEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormDriverEntry_KeyPress);
            ((ISupportInitialize) this._captureImgPreview).EndInit();
            this.LicensePictureBox.ResumeLayout(false);
            this.LicensePictureBox.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBoxLicenseNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBoxLicenseNo_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.textBoxLicenseNo.Text) && WBUtility.CheckLeave(this.textBoxLicenseNo.Text, "N|A"))
            {
                MessageBox.Show(Resource.Filter_004, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textBoxLicenseNo.Focus();
            }
        }

        private void textBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
            WBUtility.CheckInput(e, "A|S");
        }

        private void textBoxName_Leave(object sender, EventArgs e)
        {
            if (WBUtility.CheckLeave(this.textBoxName.Text, "A|S"))
            {
                MessageBox.Show(Resource.Filter_002, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textBoxName.Focus();
            }
        }

        private void textPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar) && (e.KeyChar != '-')) && (e.KeyChar != '\b'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '-') && ((sender as TextBox).Text.IndexOf('-') > -1))
            {
                e.Handled = true;
            }
        }

        private void translate()
        {
            this.label1.Text = Resource.DriverE_001;
            this.label3.Text = Resource.DriverE_002;
            this.label6.Text = Resource.DriverE_003;
            this.label4.Text = Resource.DriverE_004;
            this.label2.Text = Resource.DriverE_005;
            this.label5.Text = Resource.DriverE_006;
            this.label9.Text = Resource.DriverE_007;
            this.label8.Text = Resource.DriverE_008;
            this.labelCapturePreview.Text = Resource.DriverE_010 + ":";
            this.button1.Text = Resource.Save;
            this.button2.Text = Resource.Menu_Cancel;
            this.btnCapturePhoto.Text = Resource.Btn_Test_Capture;
            this.checkBox1.Text = Resource.Transporter_010;
            this.labelTelephone.Text = Resource.Transporter_004;
            this.Text = Resource.Title_Driver_Entry;
        }
    }
}

