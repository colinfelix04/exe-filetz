﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Runtime.CompilerServices;

    public class TokenOrAppModal
    {
        public string key_1 { get; set; }

        public string key_2 { get; set; }

        public string token_code { get; set; }

        public string email_code { get; set; }

        public string otoObj { get; set; }

        public string otoAct { get; set; }

        public string email_msg { get; set; }

        public string error_msg { get; set; }

        public bool baru { get; set; }
    }
}

