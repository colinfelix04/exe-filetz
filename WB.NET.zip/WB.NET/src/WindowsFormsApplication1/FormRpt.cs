﻿namespace WindowsFormsApplication1
{
    using CrystalDecisions.CrystalReports.Engine;
    using CrystalDecisions.Windows.Forms;
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormRpt : Form
    {
        public bool doPrint;
        private IContainer components;
        public CrystalReportViewer crystalReportViewer1;
        public ReportDocument reportDocument1;
        private MenuStrip menuStrip1;
        public ToolStripMenuItem printToolStripMenuItem;
        private ToolStripMenuItem closeToolStripMenuItem;

        public FormRpt()
        {
            this.components = null;
            this.InitializeComponent();
        }

        public FormRpt(ReportDocument cryRpt)
        {
            this.components = null;
            this.InitializeComponent();
            this.crystalReportViewer1.ReportSource = cryRpt;
            this.crystalReportViewer1.Refresh();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.closeToolStripMenuItem.PerformClick();
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            this.printToolStripMenuItem.PerformClick();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormRpt_Load(object sender, EventArgs e)
        {
            this.Text = Resource.Menu_Print_Preview;
        }

        private void InitializeComponent()
        {
            this.crystalReportViewer1 = new CrystalReportViewer();
            this.reportDocument1 = new ReportDocument();
            this.menuStrip1 = new MenuStrip();
            this.printToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = Cursors.Default;
            this.crystalReportViewer1.DisplayBackgroundEdge = false;
            this.crystalReportViewer1.Dock = DockStyle.Fill;
            this.crystalReportViewer1.Location = new Point(0, 0x18);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.ReuseParameterValuesOnRefresh = true;
            this.crystalReportViewer1.ShowCloseButton = false;
            this.crystalReportViewer1.ShowCopyButton = false;
            this.crystalReportViewer1.ShowExportButton = false;
            this.crystalReportViewer1.ShowGotoPageButton = false;
            this.crystalReportViewer1.ShowGroupTreeButton = false;
            this.crystalReportViewer1.ShowLogo = false;
            this.crystalReportViewer1.ShowParameterPanelButton = false;
            this.crystalReportViewer1.ShowPrintButton = false;
            this.crystalReportViewer1.ShowRefreshButton = false;
            this.crystalReportViewer1.ShowTextSearchButton = false;
            this.crystalReportViewer1.Size = new Size(0x33f, 310);
            this.crystalReportViewer1.TabIndex = 0;
            this.crystalReportViewer1.ToolPanelView = ToolPanelViewType.None;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.printToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x33f, 0x18);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.P;
            this.printToolStripMenuItem.Size = new Size(0x2c, 20);
            this.printToolStripMenuItem.Text = "&Print";
            this.printToolStripMenuItem.Click += new EventHandler(this.printToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "&Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x33f, 0x14e);
            base.Controls.Add(this.crystalReportViewer1);
            base.Controls.Add(this.menuStrip1);
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "FormRpt";
            this.Text = "Preview Print";
            base.WindowState = FormWindowState.Maximized;
            base.Load += new EventHandler(this.FormRpt_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.doPrint = true;
            base.Close();
        }

        public void setDoPrint(bool x)
        {
            this.doPrint = x;
        }

        public void setReport(ReportDocument cryRpt)
        {
            this.crystalReportViewer1.ReportSource = cryRpt;
            this.crystalReportViewer1.Refresh();
        }
    }
}

