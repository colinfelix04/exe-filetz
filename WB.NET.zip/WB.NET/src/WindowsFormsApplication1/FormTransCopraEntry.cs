﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTransCopraEntry : Form
    {
        public WBTable tbl_bag = new WBTable();
        public string totalTarra = "0";
        public double totalCollyDeduc = 0.0;
        private IContainer components = null;
        private Panel panel2;
        private Label label24;
        private Label label27;
        private Label label36;
        private Label label28;
        private Label label48;
        private Label label50;
        private Label label51;
        private Label label52;
        private Label label53;
        private Label label54;
        private Label label55;
        private Label label56;
        private Label label57;
        private Label label58;
        private Label label59;
        private Label label60;
        private Label label61;
        private Label label62;
        private Label label63;
        private Label label64;
        private Label label66;
        private Label label65;
        private Label label67;
        private Label label68;
        private Label label69;
        private Label label70;
        private Label label71;
        private Label label72;
        private Label label73;
        private Label label74;
        private Label label75;
        private Label label76;
        private Label label77;
        private Label label78;
        private Label label79;
        private Label label80;
        private Label label3;
        private Label label9;
        private Label label12;
        private Label label14;
        private Label label16;
        private Label label18;
        private Label label19;
        private Label label22;
        private Label label25;
        private Label label29;
        private Label label30;
        private Label label31;
        private Label label11;
        private Label label10;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label20;
        private Label label21;
        private Label label23;
        private Label label15;
        private Label label17;
        private Label label13;
        private Button buttonSisa;
        private Label label26;
        private Label label32;
        private Label label33;
        private Label label35;
        private Label label34;
        private Label label38;
        private Label label37;
        private Button buttonOK;
        private Label label39;
        private ShapeContainer shapeContainer1;
        private LineShape lineShape2;
        private LineShape lineShape1;
        private LineShape lineShape4;
        private LineShape lineShape3;
        public TextBox textPotLain;
        public TextBox textTotalCopra;
        public TextBox textJlhColly1;
        public TextBox textJlhColly2;
        public TextBox textJlhColly3;
        public TextBox textJlhColly4;
        public TextBox textJlhColly5;
        public TextBox textJlhColly6;
        public TextBox textJlhColly7;
        public TextBox textColly1;
        public TextBox textColly2;
        public TextBox textColly3;
        public TextBox textColly4;
        public TextBox textColly5;
        public TextBox textColly6;
        public TextBox textColly7;
        public TextBox textColly8;
        public TextBox textJlhColly;
        public TextBox textForm1;
        public TextBox textForm2;
        public TextBox textForm3;
        public TextBox textForm4;
        public TextBox textForm5;
        public TextBox textForm6;
        public TextBox textForm7;
        public TextBox textTarra;
        public TextBox textFormTotalKG;
        public TextBox textForm7KG;
        public TextBox textForm6KG;
        public TextBox textForm5KG;
        public TextBox textForm4KG;
        public TextBox textForm3KG;
        public TextBox textForm2KG;
        public TextBox textForm1KG;
        public TextBox textTPAir;
        public TextBox textColly7KG;
        public TextBox textColly6KG;
        public TextBox textColly5KG;
        public TextBox textColly4KG;
        public TextBox textColly3KG;
        public TextBox textColly2KG;
        public TextBox textColly1KG;
        public TextBox textColly8KG;
        public TextBox textAVGColly;
        private Button buttonCancel;
        private Label label1;
        public TextBox textPotAbu;
        private Label label2;

        public FormTransCopraEntry()
        {
            this.InitializeComponent();
        }

        private void bagWeight(string bagCode, string jlh, TextBox aResult)
        {
            double num = 0.0;
            int num2 = 0;
            while (true)
            {
                if (num2 >= this.tbl_bag.DT.Rows.Count)
                {
                    aResult.Text = Convert.ToString(Program.StrToDouble(Convert.ToString(num), 0));
                    this.textFormTotalKG.Text = Convert.ToString((double) ((((((Convert.ToDouble(this.textForm1KG.Text) + Convert.ToDouble(this.textForm2KG.Text)) + Convert.ToDouble(this.textForm3KG.Text)) + Convert.ToDouble(this.textForm4KG.Text)) + Convert.ToDouble(this.textForm5KG.Text)) + Convert.ToDouble(this.textForm6KG.Text)) + Convert.ToDouble(this.textForm7KG.Text)));
                    return;
                }
                if (bagCode.Trim().ToUpper() == this.tbl_bag.DT.Rows[num2]["Bag_code"].ToString().Trim().ToUpper())
                {
                    num = Program.StrToDouble(jlh, 3) * Program.StrToDouble(this.tbl_bag.DT.Rows[num2]["Weight"].ToString(), 3);
                }
                num2++;
            }
        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.reCalculate();
            this.totalCollyDeduc = (((((Program.StrToDouble(this.textJlhColly1.Text.Trim(), 0) + Program.StrToDouble(this.textJlhColly2.Text.Trim(), 0)) + Program.StrToDouble(this.textJlhColly3.Text.Trim(), 0)) + Program.StrToDouble(this.textJlhColly4.Text.Trim(), 0)) + Program.StrToDouble(this.textJlhColly5.Text.Trim(), 0)) + Program.StrToDouble(this.textJlhColly6.Text.Trim(), 0)) + Program.StrToDouble(this.textJlhColly7.Text.Trim(), 0);
            if (this.totalCollyDeduc > Program.StrToDouble(this.textJlhColly.Text.Trim(), 0))
            {
                string[] textArray1 = new string[] { Resource.Mes_339, "(", this.textJlhColly.Text.Trim(), " & ", Convert.ToString(this.totalCollyDeduc), ")" };
                MessageBox.Show(string.Concat(textArray1), Resource.Title_002);
                this.textJlhColly.Focus();
            }
            else if (this.totalCollyDeduc < Program.StrToDouble(this.textJlhColly.Text.Trim(), 0))
            {
                string[] textArray2 = new string[] { Resource.Mes_338, "(", this.textJlhColly.Text.Trim(), " & ", Convert.ToString(this.totalCollyDeduc), ")" };
                MessageBox.Show(string.Concat(textArray2), Resource.Title_002);
                this.textJlhColly.Focus();
            }
            else if (Program.StrToDouble(this.totalTarra, 0) >= Program.StrToDouble(this.textTotalCopra.Text.Trim(), 0))
            {
                base.Hide();
            }
            else
            {
                string[] textArray3 = new string[] { Resource.Mes_340, "(", this.textTotalCopra.Text.Trim(), " & ", Convert.ToString(this.totalTarra), ")" };
                MessageBox.Show(string.Concat(textArray3), Resource.Title_002);
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
        }

        private void buttonCancel_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show(Resource.Mes_337, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.textJlhColly.Text = "0";
                this.textJlhColly1.Text = "0";
                this.textJlhColly2.Text = "0";
                this.textJlhColly3.Text = "0";
                this.textJlhColly4.Text = "0";
                this.textJlhColly5.Text = "0";
                this.textJlhColly6.Text = "0";
                this.textJlhColly7.Text = "0";
                this.textForm1.Text = "0";
                this.textForm2.Text = "0";
                this.textForm3.Text = "0";
                this.textForm4.Text = "0";
                this.textForm5.Text = "0";
                this.textForm6.Text = "0";
                this.textForm7.Text = "0";
                this.textForm1KG.Text = "0";
                this.textForm2KG.Text = "0";
                this.textForm3KG.Text = "0";
                this.textForm4KG.Text = "0";
                this.textForm5KG.Text = "0";
                this.textForm6KG.Text = "0";
                this.textForm7KG.Text = "0";
                this.textPotAbu.Text = "0";
                this.textPotLain.Text = "0";
                this.textAVGColly.Text = "0";
                this.textColly1.Text = "0";
                this.textColly2.Text = "0";
                this.textColly3.Text = "0";
                this.textColly4.Text = "0";
                this.textColly5.Text = "0";
                this.textColly6.Text = "0";
                this.textColly7.Text = "0";
                this.textColly8.Text = "0";
                this.textColly1KG.Text = "0";
                this.textColly2KG.Text = "0";
                this.textColly3KG.Text = "0";
                this.textColly4KG.Text = "0";
                this.textColly5KG.Text = "0";
                this.textColly6KG.Text = "0";
                this.textColly7KG.Text = "0";
                this.textColly8KG.Text = "0";
                this.textTotalCopra.Text = "0";
                this.textTPAir.Text = "0";
                this.textPotAbu.Text = "0";
                this.textTarra.Text = "0";
                this.textFormTotalKG.Text = "0";
            }
        }

        private void buttonCancel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonSisa_Click(object sender, EventArgs e)
        {
            double num = 0.0;
            num = ((((Convert.ToDouble(this.textJlhColly1.Text) + Convert.ToDouble(this.textJlhColly2.Text)) + Convert.ToDouble(this.textJlhColly3.Text)) + Convert.ToDouble(this.textJlhColly4.Text)) + Convert.ToDouble(this.textJlhColly5.Text)) + Convert.ToDouble(this.textJlhColly6.Text);
            this.textJlhColly7.Text = Convert.ToString((double) (Convert.ToDouble(this.textJlhColly.Text) - num));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransCopraEntry_Load(object sender, EventArgs e)
        {
            this.reCalculate();
        }

        public void hitungAir(TextBox p1, TextBox p2, TextBox aResult)
        {
            aResult.Text = Program.StrToDouble(Convert.ToString((double) (((Convert.ToDouble(this.textTarra.Text) / Convert.ToDouble(this.textJlhColly.Text)) * Convert.ToDouble(p1.Text)) * (Convert.ToDouble(p2.Text) / 100.0))), 0).ToString();
            p2.Text = Convert.ToString(Program.StrToDouble(p2.Text, 2));
            this.textTPAir.Text = Convert.ToString((double) (((((((Convert.ToDouble(this.textColly1KG.Text) + Convert.ToDouble(this.textColly2KG.Text)) + Convert.ToDouble(this.textColly3KG.Text)) + Convert.ToDouble(this.textColly4KG.Text)) + Convert.ToDouble(this.textColly5KG.Text)) + Convert.ToDouble(this.textColly6KG.Text)) + Convert.ToDouble(this.textColly7KG.Text)) + Convert.ToDouble(this.textColly8KG.Text)));
        }

        private void hitungTotal()
        {
            this.textTotalCopra.Text = Convert.ToString((double) (((Convert.ToDouble(this.textFormTotalKG.Text) + Convert.ToDouble(this.textTPAir.Text)) + Convert.ToDouble(this.textPotAbu.Text)) + Convert.ToDouble(this.textPotLain.Text)));
        }

        private void InitializeComponent()
        {
            this.panel2 = new Panel();
            this.textTarra = new TextBox();
            this.label39 = new Label();
            this.textAVGColly = new TextBox();
            this.label38 = new Label();
            this.label37 = new Label();
            this.textTotalCopra = new TextBox();
            this.label35 = new Label();
            this.textPotLain = new TextBox();
            this.label34 = new Label();
            this.label26 = new Label();
            this.label32 = new Label();
            this.textColly8 = new TextBox();
            this.label33 = new Label();
            this.textColly8KG = new TextBox();
            this.buttonSisa = new Button();
            this.label20 = new Label();
            this.label21 = new Label();
            this.label23 = new Label();
            this.label15 = new Label();
            this.label17 = new Label();
            this.label13 = new Label();
            this.label11 = new Label();
            this.label10 = new Label();
            this.label8 = new Label();
            this.label7 = new Label();
            this.label6 = new Label();
            this.label5 = new Label();
            this.label4 = new Label();
            this.textColly1 = new TextBox();
            this.textColly2 = new TextBox();
            this.textColly3 = new TextBox();
            this.textColly4 = new TextBox();
            this.textColly5 = new TextBox();
            this.textColly6 = new TextBox();
            this.textColly7 = new TextBox();
            this.label3 = new Label();
            this.label9 = new Label();
            this.textTPAir = new TextBox();
            this.label12 = new Label();
            this.label14 = new Label();
            this.label16 = new Label();
            this.label18 = new Label();
            this.label19 = new Label();
            this.label22 = new Label();
            this.label25 = new Label();
            this.label29 = new Label();
            this.textJlhColly1 = new TextBox();
            this.label30 = new Label();
            this.textJlhColly2 = new TextBox();
            this.textColly7KG = new TextBox();
            this.textJlhColly3 = new TextBox();
            this.textColly6KG = new TextBox();
            this.textJlhColly4 = new TextBox();
            this.textColly5KG = new TextBox();
            this.textJlhColly5 = new TextBox();
            this.textColly4KG = new TextBox();
            this.textJlhColly6 = new TextBox();
            this.textColly3KG = new TextBox();
            this.textJlhColly7 = new TextBox();
            this.textColly2KG = new TextBox();
            this.label31 = new Label();
            this.textColly1KG = new TextBox();
            this.label24 = new Label();
            this.label27 = new Label();
            this.textJlhColly = new TextBox();
            this.label36 = new Label();
            this.label28 = new Label();
            this.label48 = new Label();
            this.label50 = new Label();
            this.label51 = new Label();
            this.label52 = new Label();
            this.label53 = new Label();
            this.label54 = new Label();
            this.label55 = new Label();
            this.label56 = new Label();
            this.textFormTotalKG = new TextBox();
            this.label57 = new Label();
            this.label58 = new Label();
            this.label59 = new Label();
            this.label60 = new Label();
            this.label61 = new Label();
            this.label62 = new Label();
            this.label63 = new Label();
            this.label64 = new Label();
            this.label66 = new Label();
            this.label65 = new Label();
            this.label67 = new Label();
            this.label68 = new Label();
            this.label69 = new Label();
            this.label70 = new Label();
            this.label71 = new Label();
            this.label72 = new Label();
            this.textForm1 = new TextBox();
            this.label73 = new Label();
            this.textForm2 = new TextBox();
            this.textForm7KG = new TextBox();
            this.textForm3 = new TextBox();
            this.textForm6KG = new TextBox();
            this.textForm4 = new TextBox();
            this.textForm5KG = new TextBox();
            this.textForm5 = new TextBox();
            this.textForm4KG = new TextBox();
            this.textForm6 = new TextBox();
            this.textForm3KG = new TextBox();
            this.textForm7 = new TextBox();
            this.textForm2KG = new TextBox();
            this.label74 = new Label();
            this.textForm1KG = new TextBox();
            this.label75 = new Label();
            this.label76 = new Label();
            this.label77 = new Label();
            this.label78 = new Label();
            this.label79 = new Label();
            this.label80 = new Label();
            this.shapeContainer1 = new ShapeContainer();
            this.lineShape4 = new LineShape();
            this.lineShape3 = new LineShape();
            this.lineShape2 = new LineShape();
            this.lineShape1 = new LineShape();
            this.buttonOK = new Button();
            this.buttonCancel = new Button();
            this.label1 = new Label();
            this.textPotAbu = new TextBox();
            this.label2 = new Label();
            this.panel2.SuspendLayout();
            base.SuspendLayout();
            this.panel2.AutoScroll = true;
            this.panel2.AutoScrollMinSize = new Size(0, 700);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.textPotAbu);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.textTarra);
            this.panel2.Controls.Add(this.label39);
            this.panel2.Controls.Add(this.textAVGColly);
            this.panel2.Controls.Add(this.label38);
            this.panel2.Controls.Add(this.label37);
            this.panel2.Controls.Add(this.textTotalCopra);
            this.panel2.Controls.Add(this.label35);
            this.panel2.Controls.Add(this.textPotLain);
            this.panel2.Controls.Add(this.label34);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label32);
            this.panel2.Controls.Add(this.textColly8);
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.textColly8KG);
            this.panel2.Controls.Add(this.buttonSisa);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.textColly1);
            this.panel2.Controls.Add(this.textColly2);
            this.panel2.Controls.Add(this.textColly3);
            this.panel2.Controls.Add(this.textColly4);
            this.panel2.Controls.Add(this.textColly5);
            this.panel2.Controls.Add(this.textColly6);
            this.panel2.Controls.Add(this.textColly7);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.textTPAir);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.textJlhColly1);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.textJlhColly2);
            this.panel2.Controls.Add(this.textColly7KG);
            this.panel2.Controls.Add(this.textJlhColly3);
            this.panel2.Controls.Add(this.textColly6KG);
            this.panel2.Controls.Add(this.textJlhColly4);
            this.panel2.Controls.Add(this.textColly5KG);
            this.panel2.Controls.Add(this.textJlhColly5);
            this.panel2.Controls.Add(this.textColly4KG);
            this.panel2.Controls.Add(this.textJlhColly6);
            this.panel2.Controls.Add(this.textColly3KG);
            this.panel2.Controls.Add(this.textJlhColly7);
            this.panel2.Controls.Add(this.textColly2KG);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Controls.Add(this.textColly1KG);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.textJlhColly);
            this.panel2.Controls.Add(this.label36);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.label48);
            this.panel2.Controls.Add(this.label50);
            this.panel2.Controls.Add(this.label51);
            this.panel2.Controls.Add(this.label52);
            this.panel2.Controls.Add(this.label53);
            this.panel2.Controls.Add(this.label54);
            this.panel2.Controls.Add(this.label55);
            this.panel2.Controls.Add(this.label56);
            this.panel2.Controls.Add(this.textFormTotalKG);
            this.panel2.Controls.Add(this.label57);
            this.panel2.Controls.Add(this.label58);
            this.panel2.Controls.Add(this.label59);
            this.panel2.Controls.Add(this.label60);
            this.panel2.Controls.Add(this.label61);
            this.panel2.Controls.Add(this.label62);
            this.panel2.Controls.Add(this.label63);
            this.panel2.Controls.Add(this.label64);
            this.panel2.Controls.Add(this.label66);
            this.panel2.Controls.Add(this.label65);
            this.panel2.Controls.Add(this.label67);
            this.panel2.Controls.Add(this.label68);
            this.panel2.Controls.Add(this.label69);
            this.panel2.Controls.Add(this.label70);
            this.panel2.Controls.Add(this.label71);
            this.panel2.Controls.Add(this.label72);
            this.panel2.Controls.Add(this.textForm1);
            this.panel2.Controls.Add(this.label73);
            this.panel2.Controls.Add(this.textForm2);
            this.panel2.Controls.Add(this.textForm7KG);
            this.panel2.Controls.Add(this.textForm3);
            this.panel2.Controls.Add(this.textForm6KG);
            this.panel2.Controls.Add(this.textForm4);
            this.panel2.Controls.Add(this.textForm5KG);
            this.panel2.Controls.Add(this.textForm5);
            this.panel2.Controls.Add(this.textForm4KG);
            this.panel2.Controls.Add(this.textForm6);
            this.panel2.Controls.Add(this.textForm3KG);
            this.panel2.Controls.Add(this.textForm7);
            this.panel2.Controls.Add(this.textForm2KG);
            this.panel2.Controls.Add(this.label74);
            this.panel2.Controls.Add(this.textForm1KG);
            this.panel2.Controls.Add(this.label75);
            this.panel2.Controls.Add(this.label76);
            this.panel2.Controls.Add(this.label77);
            this.panel2.Controls.Add(this.label78);
            this.panel2.Controls.Add(this.label79);
            this.panel2.Controls.Add(this.label80);
            this.panel2.Controls.Add(this.shapeContainer1);
            this.panel2.Location = new Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x21e, 0x247);
            this.panel2.TabIndex = 2;
            this.textTarra.Location = new Point(0x5e, 260);
            this.textTarra.Name = "textTarra";
            this.textTarra.ReadOnly = true;
            this.textTarra.Size = new Size(90, 20);
            this.textTarra.TabIndex = 0x45;
            this.textTarra.Text = "0";
            this.textTarra.TextAlign = HorizontalAlignment.Right;
            this.textTarra.TextChanged += new EventHandler(this.textTarra_TextChanged);
            this.label39.AutoSize = true;
            this.label39.Location = new Point(0x1ac, 0x120);
            this.label39.Name = "label39";
            this.label39.Size = new Size(0x16, 13);
            this.label39.TabIndex = 0x49;
            this.label39.Text = "KG";
            this.textAVGColly.Location = new Point(0x14e, 0x11d);
            this.textAVGColly.Name = "textAVGColly";
            this.textAVGColly.ReadOnly = true;
            this.textAVGColly.Size = new Size(0x58, 20);
            this.textAVGColly.TabIndex = 9;
            this.textAVGColly.Text = "0";
            this.textAVGColly.TextAlign = HorizontalAlignment.Right;
            this.label38.AutoSize = true;
            this.label38.ForeColor = Color.Blue;
            this.label38.Location = new Point(0x1af, 0x29f);
            this.label38.Name = "label38";
            this.label38.Size = new Size(0x16, 13);
            this.label38.TabIndex = 0x72;
            this.label38.Text = "KG";
            this.label37.AutoSize = true;
            this.label37.Location = new Point(0x1af, 0x278);
            this.label37.Name = "label37";
            this.label37.Size = new Size(0x16, 13);
            this.label37.TabIndex = 0x73;
            this.label37.Text = "KG";
            this.textTotalCopra.BackColor = SystemColors.Control;
            this.textTotalCopra.ForeColor = Color.Blue;
            this.textTotalCopra.Location = new Point(0x152, 0x29c);
            this.textTotalCopra.Name = "textTotalCopra";
            this.textTotalCopra.ReadOnly = true;
            this.textTotalCopra.Size = new Size(0x59, 20);
            this.textTotalCopra.TabIndex = 0x71;
            this.textTotalCopra.Text = "0";
            this.textTotalCopra.TextAlign = HorizontalAlignment.Right;
            this.textTotalCopra.TextChanged += new EventHandler(this.textTotalCopra_TextChanged);
            this.label35.AutoSize = true;
            this.label35.ForeColor = Color.Blue;
            this.label35.Location = new Point(0xd9, 0x29f);
            this.label35.Name = "label35";
            this.label35.Size = new Size(0x73, 13);
            this.label35.TabIndex = 0x70;
            this.label35.Text = "TOTAL POTONGAN =";
            this.textPotLain.Location = new Point(0x152, 0x275);
            this.textPotLain.Name = "textPotLain";
            this.textPotLain.Size = new Size(0x59, 20);
            this.textPotLain.TabIndex = 0x1a;
            this.textPotLain.Text = "0";
            this.textPotLain.TextAlign = HorizontalAlignment.Right;
            this.textPotLain.Leave += new EventHandler(this.textPotLain_Leave);
            this.label34.AutoSize = true;
            this.label34.Location = new Point(0xdd, 0x278);
            this.label34.Name = "label34";
            this.label34.Size = new Size(0x6c, 13);
            this.label34.TabIndex = 0x6f;
            this.label34.Text = "Potongan Lain-Lain =";
            this.label26.AutoSize = true;
            this.label26.Location = new Point(0x130, 0x213);
            this.label26.Name = "label26";
            this.label26.Size = new Size(0x18, 13);
            this.label26.TabIndex = 0x53;
            this.label26.Text = "% =";
            this.label32.AutoSize = true;
            this.label32.Location = new Point(0x86, 0x211);
            this.label32.Name = "label32";
            this.label32.Size = new Size(0x4b, 13);
            this.label32.TabIndex = 0x52;
            this.label32.Text = "Dump Truck =";
            this.textColly8.Location = new Point(0xe5, 0x20e);
            this.textColly8.Name = "textColly8";
            this.textColly8.Size = new Size(0x49, 20);
            this.textColly8.TabIndex = 0x19;
            this.textColly8.Text = "0";
            this.textColly8.TextAlign = HorizontalAlignment.Right;
            this.textColly8.Leave += new EventHandler(this.textColly8_Leave);
            this.label33.AutoSize = true;
            this.label33.Location = new Point(0x1b1, 0x211);
            this.label33.Name = "label33";
            this.label33.Size = new Size(0x16, 13);
            this.label33.TabIndex = 0x6d;
            this.label33.Text = "KG";
            this.textColly8KG.Location = new Point(0x153, 0x20e);
            this.textColly8KG.Name = "textColly8KG";
            this.textColly8KG.ReadOnly = true;
            this.textColly8KG.Size = new Size(0x58, 20);
            this.textColly8KG.TabIndex = 0x57;
            this.textColly8KG.Text = "0";
            this.textColly8KG.TextAlign = HorizontalAlignment.Right;
            this.buttonSisa.Location = new Point(0x19, 0x1f1);
            this.buttonSisa.Name = "buttonSisa";
            this.buttonSisa.Size = new Size(0x3d, 0x17);
            this.buttonSisa.TabIndex = 0x18;
            this.buttonSisa.Text = "Sisa";
            this.buttonSisa.UseVisualStyleBackColor = true;
            this.buttonSisa.Click += new EventHandler(this.buttonSisa_Click);
            this.label20.AutoSize = true;
            this.label20.Location = new Point(0x12f, 0x1f9);
            this.label20.Name = "label20";
            this.label20.Size = new Size(0x18, 13);
            this.label20.TabIndex = 0x58;
            this.label20.Text = "% =";
            this.label21.AutoSize = true;
            this.label21.Location = new Point(0x12f, 0x1dd);
            this.label21.Name = "label21";
            this.label21.Size = new Size(0x18, 13);
            this.label21.TabIndex = 0x5b;
            this.label21.Text = "% =";
            this.label23.AutoSize = true;
            this.label23.Location = new Point(0x12f, 0x1c3);
            this.label23.Name = "label23";
            this.label23.Size = new Size(0x18, 13);
            this.label23.TabIndex = 0x5c;
            this.label23.Text = "% =";
            this.label15.AutoSize = true;
            this.label15.Location = new Point(0x131, 0x1ab);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x18, 13);
            this.label15.TabIndex = 0x5f;
            this.label15.Text = "% =";
            this.label17.AutoSize = true;
            this.label17.Location = new Point(0x131, 0x18f);
            this.label17.Name = "label17";
            this.label17.Size = new Size(0x18, 13);
            this.label17.TabIndex = 0x60;
            this.label17.Text = "% =";
            this.label13.AutoSize = true;
            this.label13.Location = new Point(0x131, 0x175);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x18, 13);
            this.label13.TabIndex = 0x63;
            this.label13.Text = "% =";
            this.label11.AutoSize = true;
            this.label11.Location = new Point(0xab, 0x1f7);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x26, 13);
            this.label11.TabIndex = 0x51;
            this.label11.Text = "Colly =";
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0xab, 0x1dd);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x26, 13);
            this.label10.TabIndex = 80;
            this.label10.Text = "Colly =";
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0xab, 0x1c3);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x26, 13);
            this.label8.TabIndex = 0x4f;
            this.label8.Text = "Colly =";
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0xad, 0x1a9);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x26, 13);
            this.label7.TabIndex = 0x4e;
            this.label7.Text = "Colly =";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xad, 0x18f);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x26, 13);
            this.label6.TabIndex = 0x4d;
            this.label6.Text = "Colly =";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0xad, 0x175);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x26, 13);
            this.label5.TabIndex = 0x4c;
            this.label5.Text = "Colly =";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0xad, 0x159);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x26, 13);
            this.label4.TabIndex = 0x4b;
            this.label4.Text = "Colly =";
            this.textColly1.Location = new Point(0xe4, 0x156);
            this.textColly1.Name = "textColly1";
            this.textColly1.Size = new Size(0x4b, 20);
            this.textColly1.TabIndex = 11;
            this.textColly1.Text = "0";
            this.textColly1.TextAlign = HorizontalAlignment.Right;
            this.textColly1.Leave += new EventHandler(this.textColly1_Leave);
            this.textColly2.Location = new Point(0xe4, 370);
            this.textColly2.Name = "textColly2";
            this.textColly2.Size = new Size(0x4b, 20);
            this.textColly2.TabIndex = 13;
            this.textColly2.Text = "0";
            this.textColly2.TextAlign = HorizontalAlignment.Right;
            this.textColly2.Leave += new EventHandler(this.textColly2_Leave);
            this.textColly3.Location = new Point(0xe4, 0x18c);
            this.textColly3.Name = "textColly3";
            this.textColly3.Size = new Size(0x4b, 20);
            this.textColly3.TabIndex = 15;
            this.textColly3.Text = "0";
            this.textColly3.TextAlign = HorizontalAlignment.Right;
            this.textColly3.Leave += new EventHandler(this.textColly3_Leave);
            this.textColly4.Location = new Point(0xe4, 0x1a6);
            this.textColly4.Name = "textColly4";
            this.textColly4.Size = new Size(0x4b, 20);
            this.textColly4.TabIndex = 0x11;
            this.textColly4.Text = "0";
            this.textColly4.TextAlign = HorizontalAlignment.Right;
            this.textColly4.Leave += new EventHandler(this.textColly4_Leave);
            this.textColly5.Location = new Point(0xe4, 0x1c0);
            this.textColly5.Name = "textColly5";
            this.textColly5.Size = new Size(0x49, 20);
            this.textColly5.TabIndex = 0x13;
            this.textColly5.Text = "0";
            this.textColly5.TextAlign = HorizontalAlignment.Right;
            this.textColly5.Leave += new EventHandler(this.textColly5_Leave);
            this.textColly6.Location = new Point(0xe4, 0x1da);
            this.textColly6.Name = "textColly6";
            this.textColly6.Size = new Size(0x49, 20);
            this.textColly6.TabIndex = 0x15;
            this.textColly6.Text = "0";
            this.textColly6.TextAlign = HorizontalAlignment.Right;
            this.textColly6.Leave += new EventHandler(this.textColly6_Leave);
            this.textColly7.Location = new Point(0xe4, 500);
            this.textColly7.Name = "textColly7";
            this.textColly7.Size = new Size(0x49, 20);
            this.textColly7.TabIndex = 0x17;
            this.textColly7.Text = "0";
            this.textColly7.TextAlign = HorizontalAlignment.Right;
            this.textColly7.Leave += new EventHandler(this.textColly7_Leave);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(11, 0x141);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x63, 13);
            this.label3.TabIndex = 0x4a;
            this.label3.Text = "Potongan Kadar Air";
            this.label9.AutoSize = true;
            this.label9.ForeColor = Color.Blue;
            this.label9.Location = new Point(0x1b0, 0x22f);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x16, 13);
            this.label9.TabIndex = 110;
            this.label9.Text = "KG";
            this.textTPAir.BackColor = SystemColors.Control;
            this.textTPAir.ForeColor = Color.Blue;
            this.textTPAir.Location = new Point(0x153, 0x22c);
            this.textTPAir.Name = "textTPAir";
            this.textTPAir.ReadOnly = true;
            this.textTPAir.Size = new Size(0x58, 20);
            this.textTPAir.TabIndex = 0x56;
            this.textTPAir.Text = "0";
            this.textTPAir.TextAlign = HorizontalAlignment.Right;
            this.textTPAir.TextChanged += new EventHandler(this.textTPAir_TextChanged);
            this.label12.AutoSize = true;
            this.label12.ForeColor = Color.Blue;
            this.label12.Location = new Point(0x139, 0x22f);
            this.label12.Name = "label12";
            this.label12.Size = new Size(13, 13);
            this.label12.TabIndex = 0x55;
            this.label12.Text = "=";
            this.label14.AutoSize = true;
            this.label14.ForeColor = Color.Blue;
            this.label14.Location = new Point(0x106, 0x22f);
            this.label14.Name = "label14";
            this.label14.Size = new Size(40, 13);
            this.label14.TabIndex = 0x54;
            this.label14.Text = "Jumlah";
            this.label16.AutoSize = true;
            this.label16.Location = new Point(0x1b0, 0x1f7);
            this.label16.Name = "label16";
            this.label16.Size = new Size(0x16, 13);
            this.label16.TabIndex = 0x6c;
            this.label16.Text = "KG";
            this.label18.AutoSize = true;
            this.label18.Location = new Point(0x1b0, 0x1df);
            this.label18.Name = "label18";
            this.label18.Size = new Size(0x16, 13);
            this.label18.TabIndex = 0x6b;
            this.label18.Text = "KG";
            this.label19.AutoSize = true;
            this.label19.Location = new Point(0x1b0, 0x1c5);
            this.label19.Name = "label19";
            this.label19.Size = new Size(0x16, 13);
            this.label19.TabIndex = 0x6a;
            this.label19.Text = "KG";
            this.label22.AutoSize = true;
            this.label22.Location = new Point(0x1b0, 0x1ab);
            this.label22.Name = "label22";
            this.label22.Size = new Size(0x16, 13);
            this.label22.TabIndex = 0x69;
            this.label22.Text = "KG";
            this.label25.AutoSize = true;
            this.label25.Location = new Point(0x1b0, 0x191);
            this.label25.Name = "label25";
            this.label25.Size = new Size(0x16, 13);
            this.label25.TabIndex = 0x68;
            this.label25.Text = "KG";
            this.label29.AutoSize = true;
            this.label29.Location = new Point(0x1b0, 0x177);
            this.label29.Name = "label29";
            this.label29.Size = new Size(0x16, 13);
            this.label29.TabIndex = 0x67;
            this.label29.Text = "KG";
            this.textJlhColly1.Location = new Point(0x5c, 0x156);
            this.textJlhColly1.Name = "textJlhColly1";
            this.textJlhColly1.Size = new Size(0x4b, 20);
            this.textJlhColly1.TabIndex = 10;
            this.textJlhColly1.Text = "0";
            this.textJlhColly1.TextAlign = HorizontalAlignment.Right;
            this.textJlhColly1.Leave += new EventHandler(this.textJlhColly1_Leave);
            this.label30.AutoSize = true;
            this.label30.Location = new Point(0x1b0, 0x15b);
            this.label30.Name = "label30";
            this.label30.Size = new Size(0x16, 13);
            this.label30.TabIndex = 0x66;
            this.label30.Text = "KG";
            this.textJlhColly2.Location = new Point(0x5c, 370);
            this.textJlhColly2.Name = "textJlhColly2";
            this.textJlhColly2.Size = new Size(0x4b, 20);
            this.textJlhColly2.TabIndex = 12;
            this.textJlhColly2.Text = "0";
            this.textJlhColly2.TextAlign = HorizontalAlignment.Right;
            this.textJlhColly2.Leave += new EventHandler(this.textJlhColly2_Leave);
            this.textColly7KG.Location = new Point(0x152, 500);
            this.textColly7KG.Name = "textColly7KG";
            this.textColly7KG.ReadOnly = true;
            this.textColly7KG.Size = new Size(0x58, 20);
            this.textColly7KG.TabIndex = 0x59;
            this.textColly7KG.Text = "0";
            this.textColly7KG.TextAlign = HorizontalAlignment.Right;
            this.textJlhColly3.Location = new Point(0x5c, 0x18c);
            this.textJlhColly3.Name = "textJlhColly3";
            this.textJlhColly3.Size = new Size(0x4b, 20);
            this.textJlhColly3.TabIndex = 14;
            this.textJlhColly3.Text = "0";
            this.textJlhColly3.TextAlign = HorizontalAlignment.Right;
            this.textJlhColly3.Leave += new EventHandler(this.textJlhColly3_Leave);
            this.textColly6KG.Location = new Point(0x152, 0x1da);
            this.textColly6KG.Name = "textColly6KG";
            this.textColly6KG.ReadOnly = true;
            this.textColly6KG.Size = new Size(0x58, 20);
            this.textColly6KG.TabIndex = 90;
            this.textColly6KG.Text = "0";
            this.textColly6KG.TextAlign = HorizontalAlignment.Right;
            this.textJlhColly4.Location = new Point(0x5c, 0x1a6);
            this.textJlhColly4.Name = "textJlhColly4";
            this.textJlhColly4.Size = new Size(0x4b, 20);
            this.textJlhColly4.TabIndex = 0x10;
            this.textJlhColly4.Text = "0";
            this.textJlhColly4.TextAlign = HorizontalAlignment.Right;
            this.textJlhColly4.Leave += new EventHandler(this.textJlhColly4_Leave);
            this.textColly5KG.Location = new Point(0x152, 0x1c0);
            this.textColly5KG.Name = "textColly5KG";
            this.textColly5KG.ReadOnly = true;
            this.textColly5KG.Size = new Size(0x58, 20);
            this.textColly5KG.TabIndex = 0x5d;
            this.textColly5KG.Text = "0";
            this.textColly5KG.TextAlign = HorizontalAlignment.Right;
            this.textJlhColly5.Location = new Point(0x5c, 0x1c0);
            this.textJlhColly5.Name = "textJlhColly5";
            this.textJlhColly5.Size = new Size(0x49, 20);
            this.textJlhColly5.TabIndex = 0x12;
            this.textJlhColly5.Text = "0";
            this.textJlhColly5.TextAlign = HorizontalAlignment.Right;
            this.textJlhColly5.Leave += new EventHandler(this.textJlhColly5_Leave);
            this.textColly4KG.Location = new Point(0x153, 0x1a6);
            this.textColly4KG.Name = "textColly4KG";
            this.textColly4KG.ReadOnly = true;
            this.textColly4KG.Size = new Size(0x59, 20);
            this.textColly4KG.TabIndex = 0x5e;
            this.textColly4KG.Text = "0";
            this.textColly4KG.TextAlign = HorizontalAlignment.Right;
            this.textJlhColly6.Location = new Point(0x5c, 0x1da);
            this.textJlhColly6.Name = "textJlhColly6";
            this.textJlhColly6.Size = new Size(0x49, 20);
            this.textJlhColly6.TabIndex = 20;
            this.textJlhColly6.Text = "0";
            this.textJlhColly6.TextAlign = HorizontalAlignment.Right;
            this.textJlhColly6.Leave += new EventHandler(this.textJlhColly6_Leave);
            this.textColly3KG.Location = new Point(0x153, 0x18c);
            this.textColly3KG.Name = "textColly3KG";
            this.textColly3KG.ReadOnly = true;
            this.textColly3KG.Size = new Size(0x59, 20);
            this.textColly3KG.TabIndex = 0x61;
            this.textColly3KG.Text = "0";
            this.textColly3KG.TextAlign = HorizontalAlignment.Right;
            this.textJlhColly7.Location = new Point(0x5c, 500);
            this.textJlhColly7.Name = "textJlhColly7";
            this.textJlhColly7.Size = new Size(0x49, 20);
            this.textJlhColly7.TabIndex = 0x16;
            this.textJlhColly7.Text = "0";
            this.textJlhColly7.TextAlign = HorizontalAlignment.Right;
            this.textJlhColly7.Leave += new EventHandler(this.textJlhColly7_Leave);
            this.textColly2KG.Location = new Point(0x153, 370);
            this.textColly2KG.Name = "textColly2KG";
            this.textColly2KG.ReadOnly = true;
            this.textColly2KG.Size = new Size(0x59, 20);
            this.textColly2KG.TabIndex = 0x62;
            this.textColly2KG.Text = "0";
            this.textColly2KG.TextAlign = HorizontalAlignment.Right;
            this.label31.AutoSize = true;
            this.label31.Location = new Point(0x131, 0x159);
            this.label31.Name = "label31";
            this.label31.Size = new Size(0x18, 13);
            this.label31.TabIndex = 100;
            this.label31.Text = "% =";
            this.textColly1KG.Location = new Point(0x153, 0x156);
            this.textColly1KG.Name = "textColly1KG";
            this.textColly1KG.ReadOnly = true;
            this.textColly1KG.Size = new Size(0x59, 20);
            this.textColly1KG.TabIndex = 0x65;
            this.textColly1KG.Text = "0";
            this.textColly1KG.TextAlign = HorizontalAlignment.Right;
            this.label24.AutoSize = true;
            this.label24.Location = new Point(0x13a, 0x120);
            this.label24.Name = "label24";
            this.label24.Size = new Size(13, 13);
            this.label24.TabIndex = 0x48;
            this.label24.Text = "=";
            this.label27.AutoSize = true;
            this.label27.Location = new Point(0xd5, 0x120);
            this.label27.Name = "label27";
            this.label27.Size = new Size(0x5f, 13);
            this.label27.TabIndex = 0x47;
            this.label27.Text = "Rata-rata Per Colly";
            this.textJlhColly.Location = new Point(0x5e, 0x11d);
            this.textJlhColly.Name = "textJlhColly";
            this.textJlhColly.Size = new Size(90, 20);
            this.textJlhColly.TabIndex = 8;
            this.textJlhColly.Text = "0";
            this.textJlhColly.TextAlign = HorizontalAlignment.Right;
            this.textJlhColly.Leave += new EventHandler(this.textJlhColly_Leave);
            this.label36.AutoSize = true;
            this.label36.Location = new Point(10, 0x120);
            this.label36.Name = "label36";
            this.label36.Size = new Size(0x3f, 13);
            this.label36.TabIndex = 70;
            this.label36.Text = "JLH COLLY";
            this.label28.AutoSize = true;
            this.label28.Location = new Point(10, 0x107);
            this.label28.Name = "label28";
            this.label28.Size = new Size(0x2c, 13);
            this.label28.TabIndex = 0x44;
            this.label28.Text = "TARRA";
            this.label48.AutoSize = true;
            this.label48.Location = new Point(12, 14);
            this.label48.Name = "label48";
            this.label48.Size = new Size(0x4e, 13);
            this.label48.TabIndex = 0x1c;
            this.label48.Text = "Potongan Colly";
            this.label50.AutoSize = true;
            this.label50.Location = new Point(12, 0x26);
            this.label50.Name = "label50";
            this.label50.Size = new Size(0x13, 13);
            this.label50.TabIndex = 0x1d;
            this.label50.Text = "01";
            this.label51.AutoSize = true;
            this.label51.Location = new Point(12, 0x42);
            this.label51.Name = "label51";
            this.label51.Size = new Size(0x13, 13);
            this.label51.TabIndex = 0x1f;
            this.label51.Text = "02";
            this.label52.AutoSize = true;
            this.label52.Location = new Point(12, 0x5c);
            this.label52.Name = "label52";
            this.label52.Size = new Size(0x13, 13);
            this.label52.TabIndex = 0x21;
            this.label52.Text = "03";
            this.label53.AutoSize = true;
            this.label53.Location = new Point(12, 0x76);
            this.label53.Name = "label53";
            this.label53.Size = new Size(0x13, 13);
            this.label53.TabIndex = 0x24;
            this.label53.Text = "04";
            this.label54.AutoSize = true;
            this.label54.Location = new Point(12, 0x90);
            this.label54.Name = "label54";
            this.label54.Size = new Size(0x13, 13);
            this.label54.TabIndex = 0x25;
            this.label54.Text = "05";
            this.label55.AutoSize = true;
            this.label55.ForeColor = Color.Blue;
            this.label55.Location = new Point(0x1ab, 0xe0);
            this.label55.Name = "label55";
            this.label55.Size = new Size(0x16, 13);
            this.label55.TabIndex = 0x3d;
            this.label55.Text = "KG";
            this.label56.AutoSize = true;
            this.label56.Location = new Point(12, 170);
            this.label56.Name = "label56";
            this.label56.Size = new Size(0x13, 13);
            this.label56.TabIndex = 0x27;
            this.label56.Text = "06";
            this.textFormTotalKG.BackColor = SystemColors.Control;
            this.textFormTotalKG.ForeColor = Color.Blue;
            this.textFormTotalKG.Location = new Point(0x14e, 0xdd);
            this.textFormTotalKG.Name = "textFormTotalKG";
            this.textFormTotalKG.ReadOnly = true;
            this.textFormTotalKG.Size = new Size(0x58, 20);
            this.textFormTotalKG.TabIndex = 60;
            this.textFormTotalKG.Text = "0";
            this.textFormTotalKG.TextAlign = HorizontalAlignment.Right;
            this.textFormTotalKG.TextChanged += new EventHandler(this.textFormTotalKG_TextChanged);
            this.label57.AutoSize = true;
            this.label57.Location = new Point(12, 0xc4);
            this.label57.Name = "label57";
            this.label57.Size = new Size(0x13, 13);
            this.label57.TabIndex = 0x29;
            this.label57.Text = "07";
            this.label58.AutoSize = true;
            this.label58.ForeColor = Color.Blue;
            this.label58.Location = new Point(0x13b, 0xe0);
            this.label58.Name = "label58";
            this.label58.Size = new Size(13, 13);
            this.label58.TabIndex = 0x3b;
            this.label58.Text = "=";
            this.label59.AutoSize = true;
            this.label59.Location = new Point(0x25, 0x26);
            this.label59.Name = "label59";
            this.label59.Size = new Size(0x22, 13);
            this.label59.TabIndex = 30;
            this.label59.Text = "GONI";
            this.label60.AutoSize = true;
            this.label60.ForeColor = Color.Blue;
            this.label60.Location = new Point(0x108, 0xe0);
            this.label60.Name = "label60";
            this.label60.Size = new Size(40, 13);
            this.label60.TabIndex = 0x3a;
            this.label60.Text = "Jumlah";
            this.label61.AutoSize = true;
            this.label61.Location = new Point(0x25, 0x42);
            this.label61.Name = "label61";
            this.label61.Size = new Size(0x33, 13);
            this.label61.TabIndex = 0x20;
            this.label61.Text = "PLASTIK";
            this.label62.AutoSize = true;
            this.label62.Location = new Point(0x1ac, 0xc4);
            this.label62.Name = "label62";
            this.label62.Size = new Size(0x16, 13);
            this.label62.TabIndex = 0x3e;
            this.label62.Text = "KG";
            this.label63.AutoSize = true;
            this.label63.Location = new Point(0x25, 0x5c);
            this.label63.Name = "label63";
            this.label63.Size = new Size(0x6a, 13);
            this.label63.TabIndex = 0x22;
            this.label63.Text = "RANGKAP PLASTIK";
            this.label64.AutoSize = true;
            this.label64.Location = new Point(0x1ac, 0xac);
            this.label64.Name = "label64";
            this.label64.Size = new Size(0x16, 13);
            this.label64.TabIndex = 0x3f;
            this.label64.Text = "KG";
            this.label66.AutoSize = true;
            this.label66.Location = new Point(0x1ac, 0x92);
            this.label66.Name = "label66";
            this.label66.Size = new Size(0x16, 13);
            this.label66.TabIndex = 0x40;
            this.label66.Text = "KG";
            this.label65.AutoSize = true;
            this.label65.Location = new Point(0x25, 0x90);
            this.label65.Name = "label65";
            this.label65.Size = new Size(0x8a, 13);
            this.label65.TabIndex = 0x26;
            this.label65.Text = "RANGKAP GONI/PLASTIK";
            this.label67.AutoSize = true;
            this.label67.Location = new Point(0x25, 0x76);
            this.label67.Name = "label67";
            this.label67.Size = new Size(0x59, 13);
            this.label67.TabIndex = 0x23;
            this.label67.Text = "RANGKAP GONI";
            this.label68.AutoSize = true;
            this.label68.Location = new Point(0x1ac, 0x76);
            this.label68.Name = "label68";
            this.label68.Size = new Size(0x16, 13);
            this.label68.TabIndex = 0x41;
            this.label68.Text = "KG";
            this.label69.AutoSize = true;
            this.label69.Location = new Point(0x25, 170);
            this.label69.Name = "label69";
            this.label69.Size = new Size(80, 13);
            this.label69.TabIndex = 40;
            this.label69.Text = "GONI TAMBAL";
            this.label70.AutoSize = true;
            this.label70.Location = new Point(0x1ac, 0x5c);
            this.label70.Name = "label70";
            this.label70.Size = new Size(0x16, 13);
            this.label70.TabIndex = 0x42;
            this.label70.Text = "KG";
            this.label71.AutoSize = true;
            this.label71.Location = new Point(0x25, 0xc4);
            this.label71.Name = "label71";
            this.label71.Size = new Size(0x73, 13);
            this.label71.TabIndex = 0x2a;
            this.label71.Text = "RANGKAP 3 PLASTIK";
            this.label72.AutoSize = true;
            this.label72.Location = new Point(0x1ac, 0x42);
            this.label72.Name = "label72";
            this.label72.Size = new Size(0x16, 13);
            this.label72.TabIndex = 0x43;
            this.label72.Text = "KG";
            this.textForm1.Location = new Point(0xec, 0x23);
            this.textForm1.Name = "textForm1";
            this.textForm1.Size = new Size(0x49, 20);
            this.textForm1.TabIndex = 1;
            this.textForm1.Text = "0";
            this.textForm1.TextAlign = HorizontalAlignment.Right;
            this.textForm1.Leave += new EventHandler(this.textForm1_Leave);
            this.label73.AutoSize = true;
            this.label73.Location = new Point(0x1ac, 0x26);
            this.label73.Name = "label73";
            this.label73.Size = new Size(0x16, 13);
            this.label73.TabIndex = 0x2d;
            this.label73.Text = "KG";
            this.textForm2.Location = new Point(0xec, 0x3f);
            this.textForm2.Name = "textForm2";
            this.textForm2.Size = new Size(0x49, 20);
            this.textForm2.TabIndex = 2;
            this.textForm2.Text = "0";
            this.textForm2.TextAlign = HorizontalAlignment.Right;
            this.textForm2.Leave += new EventHandler(this.textForm2_Leave);
            this.textForm7KG.Location = new Point(0x14e, 0xc1);
            this.textForm7KG.Name = "textForm7KG";
            this.textForm7KG.ReadOnly = true;
            this.textForm7KG.Size = new Size(0x58, 20);
            this.textForm7KG.TabIndex = 0x39;
            this.textForm7KG.Text = "0";
            this.textForm7KG.TextAlign = HorizontalAlignment.Right;
            this.textForm3.Location = new Point(0xec, 0x59);
            this.textForm3.Name = "textForm3";
            this.textForm3.Size = new Size(0x49, 20);
            this.textForm3.TabIndex = 3;
            this.textForm3.Text = "0";
            this.textForm3.TextAlign = HorizontalAlignment.Right;
            this.textForm3.Leave += new EventHandler(this.textForm3_Leave);
            this.textForm6KG.Location = new Point(0x14e, 0xa7);
            this.textForm6KG.Name = "textForm6KG";
            this.textForm6KG.ReadOnly = true;
            this.textForm6KG.Size = new Size(0x58, 20);
            this.textForm6KG.TabIndex = 0x37;
            this.textForm6KG.Text = "0";
            this.textForm6KG.TextAlign = HorizontalAlignment.Right;
            this.textForm4.Location = new Point(0xec, 0x73);
            this.textForm4.Name = "textForm4";
            this.textForm4.Size = new Size(0x49, 20);
            this.textForm4.TabIndex = 4;
            this.textForm4.Text = "0";
            this.textForm4.TextAlign = HorizontalAlignment.Right;
            this.textForm4.Leave += new EventHandler(this.textForm4_Leave);
            this.textForm5KG.Location = new Point(0x14e, 0x8d);
            this.textForm5KG.Name = "textForm5KG";
            this.textForm5KG.ReadOnly = true;
            this.textForm5KG.Size = new Size(0x58, 20);
            this.textForm5KG.TabIndex = 0x35;
            this.textForm5KG.Text = "0";
            this.textForm5KG.TextAlign = HorizontalAlignment.Right;
            this.textForm5.Location = new Point(0xec, 0x8d);
            this.textForm5.Name = "textForm5";
            this.textForm5.Size = new Size(0x49, 20);
            this.textForm5.TabIndex = 5;
            this.textForm5.Text = "0";
            this.textForm5.TextAlign = HorizontalAlignment.Right;
            this.textForm5.Leave += new EventHandler(this.textForm5_Leave);
            this.textForm4KG.Location = new Point(0x14e, 0x73);
            this.textForm4KG.Name = "textForm4KG";
            this.textForm4KG.ReadOnly = true;
            this.textForm4KG.Size = new Size(0x58, 20);
            this.textForm4KG.TabIndex = 0x33;
            this.textForm4KG.Text = "0";
            this.textForm4KG.TextAlign = HorizontalAlignment.Right;
            this.textForm6.Location = new Point(0xec, 0xa7);
            this.textForm6.Name = "textForm6";
            this.textForm6.Size = new Size(0x49, 20);
            this.textForm6.TabIndex = 6;
            this.textForm6.Text = "0";
            this.textForm6.TextAlign = HorizontalAlignment.Right;
            this.textForm6.Leave += new EventHandler(this.textForm6_Leave);
            this.textForm3KG.Location = new Point(0x14e, 0x59);
            this.textForm3KG.Name = "textForm3KG";
            this.textForm3KG.ReadOnly = true;
            this.textForm3KG.Size = new Size(0x58, 20);
            this.textForm3KG.TabIndex = 0x31;
            this.textForm3KG.Text = "0";
            this.textForm3KG.TextAlign = HorizontalAlignment.Right;
            this.textForm7.Location = new Point(0xec, 0xc1);
            this.textForm7.Name = "textForm7";
            this.textForm7.Size = new Size(0x49, 20);
            this.textForm7.TabIndex = 7;
            this.textForm7.Text = "0";
            this.textForm7.TextAlign = HorizontalAlignment.Right;
            this.textForm7.Leave += new EventHandler(this.textForm7_Leave);
            this.textForm2KG.Location = new Point(0x14e, 0x3f);
            this.textForm2KG.Name = "textForm2KG";
            this.textForm2KG.ReadOnly = true;
            this.textForm2KG.Size = new Size(0x58, 20);
            this.textForm2KG.TabIndex = 0x2f;
            this.textForm2KG.Text = "0";
            this.textForm2KG.TextAlign = HorizontalAlignment.Right;
            this.label74.AutoSize = true;
            this.label74.Location = new Point(0x13b, 0x26);
            this.label74.Name = "label74";
            this.label74.Size = new Size(13, 13);
            this.label74.TabIndex = 0x2b;
            this.label74.Text = "=";
            this.textForm1KG.Location = new Point(0x14e, 0x23);
            this.textForm1KG.Name = "textForm1KG";
            this.textForm1KG.ReadOnly = true;
            this.textForm1KG.Size = new Size(0x58, 20);
            this.textForm1KG.TabIndex = 0x2c;
            this.textForm1KG.Text = "0";
            this.textForm1KG.TextAlign = HorizontalAlignment.Right;
            this.label75.AutoSize = true;
            this.label75.Location = new Point(0x13b, 0x42);
            this.label75.Name = "label75";
            this.label75.Size = new Size(13, 13);
            this.label75.TabIndex = 0x2e;
            this.label75.Text = "=";
            this.label76.AutoSize = true;
            this.label76.Location = new Point(0x13b, 0xc4);
            this.label76.Name = "label76";
            this.label76.Size = new Size(13, 13);
            this.label76.TabIndex = 0x38;
            this.label76.Text = "=";
            this.label77.AutoSize = true;
            this.label77.Location = new Point(0x13b, 0x5c);
            this.label77.Name = "label77";
            this.label77.Size = new Size(13, 13);
            this.label77.TabIndex = 0x30;
            this.label77.Text = "=";
            this.label78.AutoSize = true;
            this.label78.Location = new Point(0x13b, 0xac);
            this.label78.Name = "label78";
            this.label78.Size = new Size(13, 13);
            this.label78.TabIndex = 0x36;
            this.label78.Text = "=";
            this.label79.AutoSize = true;
            this.label79.Location = new Point(0x13b, 0x76);
            this.label79.Name = "label79";
            this.label79.Size = new Size(13, 13);
            this.label79.TabIndex = 50;
            this.label79.Text = "=";
            this.label80.AutoSize = true;
            this.label80.Location = new Point(0x13b, 0x92);
            this.label80.Name = "label80";
            this.label80.Size = new Size(13, 13);
            this.label80.TabIndex = 0x34;
            this.label80.Text = "=";
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.lineShape4, this.lineShape3, this.lineShape2, this.lineShape1 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(0x20d, 700);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 0x11;
            this.lineShape4.X2 = 0x1c1;
            this.lineShape4.Y1 = 0x293;
            this.lineShape4.Y2 = 0x293;
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 0x12;
            this.lineShape3.X2 = 450;
            this.lineShape3.Y1 = 0x249;
            this.lineShape3.Y2 = 0x249;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 12;
            this.lineShape2.X2 = 0x1bc;
            this.lineShape2.Y1 = 0x139;
            this.lineShape2.Y2 = 0x139;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 12;
            this.lineShape1.X2 = 0x1bc;
            this.lineShape1.Y1 = 0xfb;
            this.lineShape1.Y2 = 0xfb;
            this.buttonOK.Location = new Point(0x1a5, 0x25d);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new Size(0x74, 0x25);
            this.buttonOK.TabIndex = 0x1b;
            this.buttonOK.Text = "&OK";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new EventHandler(this.buttonBack_Click);
            this.buttonCancel.Location = new Point(12, 0x25d);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x74, 0x25);
            this.buttonCancel.TabIndex = 0x1c;
            this.buttonCancel.Text = "&RESET";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click_1);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x1b0, 0x255);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x16, 13);
            this.label1.TabIndex = 0x76;
            this.label1.Text = "KG";
            this.textPotAbu.Location = new Point(0x153, 0x252);
            this.textPotAbu.Name = "textPotAbu";
            this.textPotAbu.Size = new Size(0x59, 20);
            this.textPotAbu.TabIndex = 0x74;
            this.textPotAbu.Text = "0";
            this.textPotAbu.TextAlign = HorizontalAlignment.Right;
            this.textPotAbu.Leave += new EventHandler(this.textPotAbu_Leave);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0xd5, 0x255);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x73, 13);
            this.label2.TabIndex = 0x75;
            this.label2.Text = "Potongan Abu/Debu =";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x232, 0x2a6);
            base.ControlBox = false;
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.buttonOK);
            base.Name = "FormTransCopraEntry";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Entry Copra Deduction";
            base.Load += new EventHandler(this.FormTransCopraEntry_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            base.ResumeLayout(false);
        }

        private void reCalculate()
        {
            this.textTarra.Text = Convert.ToString((double) (Convert.ToDouble(this.totalTarra) - Convert.ToDouble(this.textFormTotalKG.Text)));
            if (Program.StrToDouble(this.textJlhColly.Text.Trim(), 0) > 0.0)
            {
                this.textAVGColly.Text = Program.StrToDouble(Convert.ToString((double) (Convert.ToDouble(this.textTarra.Text) / Convert.ToDouble(this.textJlhColly.Text))), 0).ToString();
            }
            if (Program.StrToDouble(this.textJlhColly.Text.Trim(), 0) > 0.0)
            {
                this.hitungAir(this.textJlhColly1, this.textColly1, this.textColly1KG);
                this.hitungAir(this.textJlhColly2, this.textColly2, this.textColly2KG);
                this.hitungAir(this.textJlhColly3, this.textColly3, this.textColly3KG);
                this.hitungAir(this.textJlhColly4, this.textColly4, this.textColly4KG);
                this.hitungAir(this.textJlhColly5, this.textColly5, this.textColly5KG);
                this.hitungAir(this.textJlhColly6, this.textColly6, this.textColly6KG);
                this.hitungAir(this.textJlhColly7, this.textColly7, this.textColly7KG);
            }
            this.textColly8KG.Text = Program.StrToDouble(Convert.ToString((double) ((Convert.ToDouble(this.textColly8.Text) / 100.0) * Convert.ToDouble(this.textTarra.Text))), 0).ToString();
            this.textTPAir.Text = Convert.ToString((double) (((((((Convert.ToDouble(this.textColly1KG.Text) + Convert.ToDouble(this.textColly2KG.Text)) + Convert.ToDouble(this.textColly3KG.Text)) + Convert.ToDouble(this.textColly4KG.Text)) + Convert.ToDouble(this.textColly5KG.Text)) + Convert.ToDouble(this.textColly6KG.Text)) + Convert.ToDouble(this.textColly7KG.Text)) + Convert.ToDouble(this.textColly8KG.Text)));
            this.textTotalCopra.Text = Convert.ToString((double) (((Convert.ToDouble(this.textFormTotalKG.Text) + Convert.ToDouble(this.textTPAir.Text)) + Convert.ToDouble(this.textPotAbu.Text)) + Convert.ToDouble(this.textPotLain.Text)));
        }

        private void selectAll(TextBox aText)
        {
            if (!string.IsNullOrEmpty(aText.Text))
            {
                aText.SelectAll();
            }
        }

        private void textColly1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textColly1);
            this.hitungAir(this.textJlhColly1, this.textColly1, this.textColly1KG);
        }

        private void textColly2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textColly2);
            this.hitungAir(this.textJlhColly2, this.textColly2, this.textColly2KG);
        }

        private void textColly3_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textColly3);
            this.hitungAir(this.textJlhColly3, this.textColly3, this.textColly3KG);
        }

        private void textColly4_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textColly4);
            this.hitungAir(this.textJlhColly4, this.textColly4, this.textColly4KG);
        }

        private void textColly5_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textColly5);
            this.hitungAir(this.textJlhColly5, this.textColly5, this.textColly5KG);
        }

        private void textColly6_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textColly6);
            this.hitungAir(this.textJlhColly6, this.textColly6, this.textColly6KG);
        }

        private void textColly7_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textColly7);
            this.hitungAir(this.textJlhColly7, this.textColly7, this.textColly7KG);
        }

        private void textColly8_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textColly8);
            this.textColly8KG.Text = Program.StrToDouble(Convert.ToString((double) ((Convert.ToDouble(this.textColly8.Text) / 100.0) * Convert.ToDouble(this.textTarra.Text))), 0).ToString();
            this.textTPAir.Text = Convert.ToString((double) (((((((Convert.ToDouble(this.textColly1KG.Text) + Convert.ToDouble(this.textColly2KG.Text)) + Convert.ToDouble(this.textColly3KG.Text)) + Convert.ToDouble(this.textColly4KG.Text)) + Convert.ToDouble(this.textColly5KG.Text)) + Convert.ToDouble(this.textColly6KG.Text)) + Convert.ToDouble(this.textColly7KG.Text)) + Convert.ToDouble(this.textColly8KG.Text)));
        }

        private void textForm1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textForm1);
            this.bagWeight("01", this.textForm1.Text, this.textForm1KG);
        }

        private void textForm2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textForm2);
            this.bagWeight("02", this.textForm2.Text, this.textForm2KG);
        }

        private void textForm3_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textForm3);
            this.bagWeight("03", this.textForm3.Text, this.textForm3KG);
        }

        private void textForm4_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textForm4);
            this.bagWeight("04", this.textForm4.Text, this.textForm4KG);
        }

        private void textForm5_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textForm5);
            this.bagWeight("05", this.textForm5.Text, this.textForm5KG);
        }

        private void textForm6_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textForm6);
            this.bagWeight("06", this.textForm6.Text, this.textForm6KG);
        }

        private void textForm7_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textForm7);
            this.bagWeight("07", this.textForm7.Text, this.textForm7KG);
        }

        private void textFormTotalKG_TextChanged(object sender, EventArgs e)
        {
            this.hitungTotal();
            this.textTarra.Text = Convert.ToString((double) (Convert.ToDouble(this.totalTarra) - Convert.ToDouble(this.textFormTotalKG.Text)));
        }

        private void textJlhColly_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textJlhColly);
            this.textAVGColly.Text = (Program.StrToDouble(this.textJlhColly.Text.Trim(), 0) <= 0.0) ? "0" : Program.StrToDouble(Convert.ToString((double) (Convert.ToDouble(this.textTarra.Text) / Convert.ToDouble(this.textJlhColly.Text))), 0).ToString();
        }

        private void textJlhColly1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textJlhColly1);
            this.hitungAir(this.textJlhColly1, this.textColly1, this.textColly1KG);
        }

        private void textJlhColly2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textJlhColly2);
            this.hitungAir(this.textJlhColly2, this.textColly2, this.textColly2KG);
        }

        private void textJlhColly3_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textJlhColly3);
            this.hitungAir(this.textJlhColly3, this.textColly3, this.textColly3KG);
        }

        private void textJlhColly4_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textJlhColly4);
            this.hitungAir(this.textJlhColly4, this.textColly4, this.textColly4KG);
        }

        private void textJlhColly5_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textJlhColly5);
            this.hitungAir(this.textJlhColly5, this.textColly5, this.textColly5KG);
        }

        private void textJlhColly6_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textJlhColly6);
            this.hitungAir(this.textJlhColly6, this.textColly6, this.textColly6KG);
        }

        private void textJlhColly7_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textJlhColly7);
            this.hitungAir(this.textJlhColly7, this.textColly7, this.textColly7KG);
        }

        private void textPotAbu_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textPotAbu);
            this.hitungTotal();
        }

        private void textPotLain_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textPotLain);
            this.hitungTotal();
        }

        private void textTarra_TextChanged(object sender, EventArgs e)
        {
            if (Program.StrToDouble(this.textJlhColly.Text.Trim(), 0) > 0.0)
            {
                this.textAVGColly.Text = Program.StrToDouble(Convert.ToString((double) (Convert.ToDouble(this.textTarra.Text) / Convert.ToDouble(this.textJlhColly.Text))), 0).ToString();
            }
        }

        private void textTotalCopra_TextChanged(object sender, EventArgs e)
        {
        }

        private void textTPAir_TextChanged(object sender, EventArgs e)
        {
            this.hitungTotal();
        }
    }
}

