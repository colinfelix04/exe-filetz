﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormSPB : Form
    {
        public string pMode = "";
        public string pDo_No;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public int zUniq;
        private IContainer components = null;
        private DataGridView dataGridView1;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        public ToolStripMenuItem closeToolStripMenuItem;

        public FormSPB()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Simpan("ADD");
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
            {
                this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                string[] textArray1 = new string[11];
                textArray1[0] = this.ztable.DT.Rows[this.nCurrRow]["Do_No"].ToString();
                textArray1[1] = " : ";
                textArray1[2] = Resource.Setting_046;
                textArray1[3] = " ";
                textArray1[4] = this.ztable.DT.Rows[this.nCurrRow]["Delivery_Note_From"].ToString();
                textArray1[5] = " ";
                textArray1[6] = Resource.Main_029;
                textArray1[7] = " ";
                textArray1[8] = this.ztable.DT.Rows[this.nCurrRow]["Delivery_Note_to"].ToString();
                textArray1[9] = "\n\n ";
                textArray1[10] = Resource.Mes_006;
                if (MessageBox.Show(string.Concat(textArray1), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    FormTransCancel cancel = new FormTransCancel {
                        label1 = { Text = Resource.Lbl_DO_Delivery_Note },
                        textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Do_No"].ToString() },
                        Text = Resource.Form_Delete_Reason,
                        label2 = { Text = Resource.Lbl_Delete_Reason }
                    };
                    cancel.textReason.Focus();
                    cancel.ShowDialog();
                    if (cancel.Saved)
                    {
                        this.changeReason = cancel.textReason.Text;
                        cancel.Dispose();
                        this.ztable.ReOpen();
                        this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                        this.ztable.DT.Rows[this.nCurrRow].Delete();
                        this.ztable.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_delivery_note", this.logKey, logField, logValue);
                        this.ztable.ReOpen();
                        this.ztable.AfterEdit("DELETE");
                    }
                    else
                    {
                        return;
                    }
                }
                this.ztable.UnLock();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                this.Simpan("EDIT");
            }
        }

        private void FormSPB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormSPB_Load(object sender, EventArgs e)
        {
            this.ztable.OpenTable("wb_delivery_note", "SELECT * FROM wb_delivery_note where Do_No='" + this.pDo_No + "'", WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Do_No"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["Delete_By"].Visible = false;
            this.dataGridView1.Columns["Delete_Date"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["deleted"].Visible = false;
            this.dataGridView1.Columns["token"].Visible = false;
            this.dataGridView1.Columns["Do_No"].HeaderText = Resource.Main_018;
            this.dataGridView1.Columns["Delivery_Note_From"].HeaderText = Resource.Setting_046;
            this.dataGridView1.Columns["Delivery_Note_To"].HeaderText = Resource.Setting_053;
            base.KeyPreview = true;
            this.addNewRecordToolStripMenuItem.Enabled = false;
            this.editRecordToolStripMenuItem.Enabled = false;
            this.deleteToolStripMenuItem.Enabled = false;
        }

        private void InitializeComponent()
        {
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x18f, 0xcf);
            this.dataGridView1.TabIndex = 0;
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x18f, 0x18);
            this.menuStrip1.TabIndex = 0x12;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x18f, 0xe7);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Name = "FormSPB";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Range of Delivery Note Number";
            base.Load += new EventHandler(this.FormSPB_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormSPB_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void Simpan(string prMode)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, prMode))
            {
                FormSPBEntry entry = new FormSPBEntry {
                    pMode = prMode,
                    pDo_No = this.pDo_No,
                    zTable = this.ztable,
                    Text = (prMode == "ADD") ? Resource.Menu_Add : Resource.Menu_Edit,
                    dataGridView1 = this.dataGridView1
                };
                if (this.dataGridView1.Rows.Count > 0)
                {
                    entry.sUniq = Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                }
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                }
                entry.Dispose();
                this.ztable.UnLock();
            }
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Trans_057;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.Text = Resource.Title_Form_SPB;
        }
    }
}

