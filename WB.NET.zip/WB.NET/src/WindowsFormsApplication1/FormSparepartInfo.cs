﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormSparepartInfo : Form
    {
        private WBTable tblTrans = new WBTable();
        private WBTable tblContract = new WBTable();
        private WBTable tblDetailSTO = new WBTable();
        private WBTable tblDetailBC = new WBTable();
        private WBTable tblTransBC = new WBTable();
        private WBTable tblTransDO = new WBTable();
        private Dictionary<string, string> DO_query_source = new Dictionary<string, string>();
        private int BC_NO_INDEX = 14;
        private int BC_ITEM_INDEX = 15;
        private int ITEM_LOAD_QTY_INDEX = 0x13;
        private DataTable DT_DetailSTO = new DataTable();
        private DataTable DT_DetailBC = new DataTable();
        private List<string> List_BC_No = new List<string>();
        private Dictionary<string, string> do_ref = new Dictionary<string, string>();
        private string report_date;
        private string approve;
        private string approve_type;
        private string approveBy1;
        private string approveBy2;
        private string Approve_Reason;
        private string[] hasil = new string[3];
        private int selected_row = -1;
        private IContainer components = null;
        public TextBox txtRefNo;
        private Label lblVehicle;
        private TextBox txtVehicle;
        private DataGridView dgvDO;
        private Button btnSave;
        private Button btnCancel;
        private StatusStrip statusStrip1;
        private ToolTip toolTipInformation;
        private Label labelTableSTO;
        private Label label35;
        public TextBox textRef_Date;
        private Label label3;
        private TextBox textDriverID;
        private Label labelDriverName;
        private TextBox textReport_Date;
        private Label label37;
        private Button btnFilter;
        public TextBox txtFilterKeyword;
        private CheckBox chkBoxFilter;
        private Button btnDeleteRow;
        private Button btnDuplicateRow;
        private Label lblRef;

        public FormSparepartInfo()
        {
            this.InitializeComponent();
        }

        private void append_data_to_dgv()
        {
            string sqltext = "";
            WBTable table = new WBTable();
            sqltext = "select a.*, c.Comm_Code, c.Comm_Name, c.STO_Qty, c.STO_UoM, c.Tolerance, c.Require_BC, b.BC_No, b.BC_Item, b.BC_Date, b.BC_Exp_Date, b.BC_Qty, b.BC_UoM, c.Tracking_No, c.Tracking_Item from wb_transBC a \r\n            left join wb_contract_detail_BC b\r\n            on a.Coy = b.Coy and a.Location_Code = b.Location_Code and a.BC_No = b.BC_No and a.BC_Item = b.BC_Item and a.do_no = b.do_no \r\n\r\n            left join (select \r\n\t            CASE \r\n\t\t            WHEN cts.uniq is not null THEN cts.Coy\r\n\t\t            ELSE ct.Coy\r\n\t            END as Coy,\r\n\r\n\t            CASE \r\n\t\t            WHEN cts.uniq is not null THEN cts.Location_Code\r\n\t\t            ELSE ct.Location_Code\r\n\t            END as Location_Code,\r\n                CASE \r\n              WHEN cts.do_no is not null THEN cts.do_no\r\n              ELSE ct.do_No\r\n             END as do_No,\r\n\t            CASE \r\n\t\t            WHEN cts.uniq is not null THEN cts.Tracking_No\r\n\t\t            ELSE ct.Tracking_No\r\n\t            END as Tracking_No,\r\n\r\n\t            CASE \r\n\t\t            WHEN cts.uniq is not null THEN cts.Tracking_Item\r\n\t\t            ELSE ct.Tracking_Item\r\n\t            END as Tracking_Item,\r\n\r\n\t            CASE \r\n\t\t            WHEN cts.uniq is not null THEN cts.STO\r\n\t\t            ELSE ct.STO\r\n\t            END as STO,\r\n\r\n\t            CASE \r\n\t\t            WHEN cts.uniq is not null THEN cts.STO_Item\r\n\t\t            ELSE ct.STO_Item\r\n\t            END as STO_Item,\r\n\t            CASE \r\n\t\t            WHEN cts.uniq is not null THEN cts.Comm_Code\r\n\t\t            ELSE ct.Comm_Code\r\n\t            END as Comm_Code,\r\n\t\t\t\tCASE\r\n\t\t\t\t\tWHEN cts.uniq is not null THEN cts.Comm_Name\r\n\t\t\t\t\tELSE ct.Comm_Name\r\n\t\t\t\tEND as Comm_Name,\r\n\t            CASE \r\n\t\t            WHEN cts.uniq is not null THEN cts.STO_Qty\r\n\t\t            ELSE ct.STO_Qty\r\n\t            END as STO_Qty,\r\n\r\n\t            CASE \r\n\t\t            WHEN cts.uniq is not null THEN cts.STO_UoM\r\n\t\t            ELSE ct.STO_UoM\r\n\t            END as STO_UoM,\r\n                CASE \r\n\t\t            WHEN cts.uniq is not null THEN cts.tolerance\r\n\t\t            ELSE ct.tolerance\r\n\t            END as tolerance,\r\n\t            CASE \r\n\t\t            WHEN cts.uniq is not null THEN cts.Require_BC\r\n\t\t            ELSE ct.Require_BC\r\n\t            END as Require_BC\r\n\r\n\t            from (select xct.*, xcom.Comm_Name from wb_contract xct left join wb_commodity xcom on xct.Coy = xcom.Coy and xct.Location_Code = xcom.Location_Code and xct.Comm_Code = xcom.comm_code) ct\r\n\t            left join (select xcts.*, xcom.Comm_Name from wb_contract_detail_STO xcts left join wb_commodity xcom on xcts.Coy = xcom.Coy and xcts.Location_Code = xcom.Location_Code and xcts.Comm_Code = xcom.comm_code) cts\r\n\t            on ct.Coy = cts.Coy and ct.Location_Code = cts.Location_Code and ct.Do_No = cts.Do_No) c\r\n            on a.Coy = c.Coy and a.Location_Code = c.Location_Code and a.STO = c.STO and a.STO_Item = c.STO_Item and a.do_no = c.do_no\r\n\r\n            where (a.deleted = 'N' or a.deleted is null or a.deleted = '') and a.Ref Like '" + this.txtRefNo.Text.Trim() + "%' order by a.STO asc, a.STO_Item asc";
            table.OpenTable("wb_transBC", sqltext, WBData.conn);
            int count = this.dgvDO.Rows.Count;
            int num2 = 0;
            if (table.DT.Rows.Count > 0)
            {
                int num3 = 0;
                while (true)
                {
                    if (num3 >= table.DT.Rows.Count)
                    {
                        break;
                    }
                    num2 = 0;
                    int num4 = 0;
                    while (true)
                    {
                        if (num4 >= count)
                        {
                            if (num2 == 0)
                            {
                                int num5 = this.dgvDO.Rows.Add();
                                this.dgvDO.Rows[num5].Cells["Do_No"].Value = table.DT.Rows[num3]["Do_No"].ToString();
                                this.dgvDO.Rows[num5].Cells["Coy"].Value = table.DT.Rows[num3]["Coy"].ToString();
                                this.dgvDO.Rows[num5].Cells["Location_Code"].Value = table.DT.Rows[num3]["Location_Code"].ToString();
                                this.dgvDO.Rows[num5].Cells["Tracking_No"].Value = table.DT.Rows[num3]["Tracking_No"].ToString();
                                this.dgvDO.Rows[num5].Cells["Tracking_Item"].Value = table.DT.Rows[num3]["Tracking_Item"].ToString();
                                this.dgvDO.Rows[num5].Cells["STO"].Value = table.DT.Rows[num3]["STO"].ToString();
                                this.dgvDO.Rows[num5].Cells["STO_Item"].Value = table.DT.Rows[num3]["STO_Item"].ToString();
                                this.dgvDO.Rows[num5].Cells["STO_Qty"].Value = table.DT.Rows[num3]["STO_Qty"].ToString();
                                this.dgvDO.Rows[num5].Cells["STO_UoM"].Value = table.DT.Rows[num3]["STO_UoM"].ToString();
                                this.dgvDO.Rows[num5].Cells["Tolerance"].Value = table.DT.Rows[num3]["Tolerance"].ToString();
                                this.dgvDO.Rows[num5].Cells["Comm_Code"].Value = table.DT.Rows[num3]["Comm_Code"].ToString();
                                this.dgvDO.Rows[num5].Cells["Comm_Name"].Value = table.DT.Rows[num3]["Comm_Name"].ToString();
                                this.dgvDO.Rows[num5].Cells["Require_BC"].Value = table.DT.Rows[num3]["Require_BC"].ToString();
                                List<string> list4 = this.getDistinctBCNo(this.dgvDO.Rows[num5].Cells["DO_No"].Value.ToString(), this.dgvDO.Rows[num5].Cells["STO"].Value.ToString(), this.dgvDO.Rows[num5].Cells["STO_Item"].Value.ToString(), true);
                                ((DataGridViewComboBoxCell) this.dgvDO.Rows[num5].Cells[this.BC_NO_INDEX]).DataSource = list4;
                                if (list4.Count == 1)
                                {
                                    this.dgvDO.Rows[num5].Cells[this.BC_NO_INDEX].Value = list4[0];
                                }
                                DataGridViewComboBoxCell cell6 = (DataGridViewComboBoxCell) this.dgvDO.Rows[num5].Cells[this.BC_ITEM_INDEX];
                                if (!string.IsNullOrEmpty(table.DT.Rows[num3]["BC_No"].ToString()) && !string.IsNullOrEmpty(table.DT.Rows[num3]["BC_Item"].ToString()))
                                {
                                    this.dgvDO.Rows[num5].Cells[this.BC_NO_INDEX].Value = table.DT.Rows[num3]["BC_No"].ToString();
                                    List<string> list5 = this.getDistinctBCItem(table.DT.Rows[num3]["DO_No"].ToString(), table.DT.Rows[num3]["STO"].ToString(), table.DT.Rows[num3]["STO_Item"].ToString(), table.DT.Rows[num3]["BC_No"].ToString(), true);
                                    cell6.DataSource = list5;
                                    if (list5.Count == 1)
                                    {
                                        this.dgvDO.Rows[num5].Cells[this.BC_ITEM_INDEX].Value = list5[0];
                                    }
                                    this.dgvDO.Rows[num5].Cells[this.BC_ITEM_INDEX].Value = table.DT.Rows[num3]["BC_Item"].ToString();
                                    this.dgvDO.Rows[num5].Cells["BC_Type"].Value = table.DT.Rows[num3]["BC_Type"].ToString();
                                    this.dgvDO.Rows[num5].Cells["BC_Date"].Value = table.DT.Rows[num3]["BC_Date"].ToString();
                                    this.dgvDO.Rows[num5].Cells["BC_Exp_Date"].Value = table.DT.Rows[num3]["BC_Exp_Date"].ToString();
                                    this.dgvDO.Rows[num5].Cells["BC_Qty"].Value = table.DT.Rows[num3]["BC_Qty"].ToString();
                                    this.dgvDO.Rows[num5].Cells["BC_UoM"].Value = table.DT.Rows[num3]["BC_UoM"].ToString();
                                }
                                else
                                {
                                    this.dgvDO.Rows[num5].Cells[this.BC_NO_INDEX].Value = null;
                                    this.dgvDO.Rows[num5].Cells[this.BC_ITEM_INDEX].Value = null;
                                    this.dgvDO.Rows[num5].Cells["BC_Type"].Value = "";
                                    this.dgvDO.Rows[num5].Cells["BC_Date"].Value = "";
                                    this.dgvDO.Rows[num5].Cells["BC_Exp_Date"].Value = "";
                                    this.dgvDO.Rows[num5].Cells["BC_Qty"].Value = "";
                                    this.dgvDO.Rows[num5].Cells["BC_UoM"].Value = "";
                                    if (!string.IsNullOrEmpty(table.DT.Rows[num3]["BC_No"].ToString()))
                                    {
                                        this.dgvDO.Rows[num5].Cells[this.BC_NO_INDEX].Value = table.DT.Rows[num3]["BC_No"].ToString();
                                        List<string> list6 = this.getDistinctBCItem(table.DT.Rows[num3]["DO_No"].ToString(), table.DT.Rows[num3]["STO"].ToString(), table.DT.Rows[num3]["STO_Item"].ToString(), table.DT.Rows[num3]["BC_No"].ToString(), true);
                                        cell6.DataSource = list6;
                                        if (list6.Count == 1)
                                        {
                                            this.dgvDO.Rows[num5].Cells[this.BC_ITEM_INDEX].Value = list6[0];
                                        }
                                    }
                                }
                                this.dgvDO.Rows[num5].Cells["Item_Load_Qty"].Value = table.DT.Rows[num3]["Item_Load_Qty"].ToString();
                                this.dgvDO.Rows[num5].Cells["Deleted"].Value = "E";
                                this.dgvDO.Rows[num5].Cells["transBC_uniq"].Value = table.DT.Rows[num3]["uniq"].ToString();
                                DataGridViewComboBoxCell cell7 = (DataGridViewComboBoxCell) this.dgvDO.Rows[num5].Cells[this.BC_NO_INDEX];
                                cell7.DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing;
                                cell7.Style.BackColor = Color.LightGray;
                                cell7.ReadOnly = true;
                                DataGridViewComboBoxCell cell8 = (DataGridViewComboBoxCell) this.dgvDO.Rows[num5].Cells[this.BC_ITEM_INDEX];
                                cell8.DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing;
                                cell8.Style.BackColor = Color.LightGray;
                                cell8.ReadOnly = true;
                                this.dgvDO.Rows[num5].Cells["Item_Load_Qty"].ReadOnly = false;
                                this.dgvDO.Rows[num5].Cells["Item_Load_Qty"].Style.BackColor = Color.White;
                            }
                            num3++;
                            break;
                        }
                        if (((table.DT.Rows[num3]["STO"].ToString() == this.dgvDO.Rows[num4].Cells["STO"].Value.ToString()) && ((table.DT.Rows[num3]["STO_Item"].ToString() == this.dgvDO.Rows[num4].Cells["STO_Item"].Value.ToString()) && (this.dgvDO.Rows[num4].Cells[this.BC_NO_INDEX].Value == null))) && (this.dgvDO.Rows[num4].Cells[this.BC_ITEM_INDEX].Value == null))
                        {
                            DataGridViewRow row = this.dgvDO.Rows[num4];
                            row.Cells["Do_No"].Value = table.DT.Rows[num3]["Do_No"].ToString();
                            row.Cells["Coy"].Value = table.DT.Rows[num3]["Coy"].ToString();
                            row.Cells["Location_Code"].Value = table.DT.Rows[num3]["Location_Code"].ToString();
                            row.Cells["Tracking_No"].Value = table.DT.Rows[num3]["Tracking_No"].ToString();
                            row.Cells["Tracking_Item"].Value = table.DT.Rows[num3]["Tracking_Item"].ToString();
                            List<string> list = this.getDistinctBCNo(row.Cells["DO_No"].Value.ToString(), row.Cells["STO"].Value.ToString(), row.Cells["STO_Item"].Value.ToString(), true);
                            ((DataGridViewComboBoxCell) row.Cells[this.BC_NO_INDEX]).DataSource = list;
                            if (list.Count == 1)
                            {
                                row.Cells[this.BC_NO_INDEX].Value = list[0];
                            }
                            DataGridViewComboBoxCell cell2 = (DataGridViewComboBoxCell) row.Cells[this.BC_ITEM_INDEX];
                            if (!string.IsNullOrEmpty(table.DT.Rows[num3]["BC_No"].ToString()) && !string.IsNullOrEmpty(table.DT.Rows[num3]["BC_Item"].ToString()))
                            {
                                row.Cells[this.BC_NO_INDEX].Value = table.DT.Rows[num3]["BC_No"].ToString();
                                List<string> list2 = this.getDistinctBCItem(table.DT.Rows[num3]["DO_No"].ToString(), table.DT.Rows[num3]["STO"].ToString(), table.DT.Rows[num3]["STO_Item"].ToString(), table.DT.Rows[num3]["BC_No"].ToString(), true);
                                cell2.DataSource = list2;
                                if (list2.Count == 1)
                                {
                                    row.Cells[this.BC_ITEM_INDEX].Value = list2[0];
                                }
                                row.Cells[this.BC_ITEM_INDEX].Value = table.DT.Rows[num3]["BC_Item"].ToString();
                                row.Cells["BC_Type"].Value = table.DT.Rows[num3]["BC_Type"].ToString();
                                row.Cells["BC_Date"].Value = table.DT.Rows[num3]["BC_Date"].ToString();
                                row.Cells["BC_Exp_Date"].Value = table.DT.Rows[num3]["BC_Exp_Date"].ToString();
                                row.Cells["BC_Qty"].Value = table.DT.Rows[num3]["BC_Qty"].ToString();
                                row.Cells["BC_UoM"].Value = table.DT.Rows[num3]["BC_UoM"].ToString();
                            }
                            else
                            {
                                row.Cells[this.BC_NO_INDEX].Value = null;
                                row.Cells[this.BC_ITEM_INDEX].Value = null;
                                row.Cells["BC_Type"].Value = "";
                                row.Cells["BC_Date"].Value = "";
                                row.Cells["BC_Exp_Date"].Value = "";
                                row.Cells["BC_Qty"].Value = "";
                                row.Cells["BC_UoM"].Value = "";
                                if (!string.IsNullOrEmpty(table.DT.Rows[num3]["BC_No"].ToString()))
                                {
                                    row.Cells[this.BC_NO_INDEX].Value = table.DT.Rows[num3]["BC_No"].ToString();
                                    List<string> list3 = this.getDistinctBCItem(table.DT.Rows[num3]["DO_No"].ToString(), table.DT.Rows[num3]["STO"].ToString(), table.DT.Rows[num3]["STO_Item"].ToString(), table.DT.Rows[num3]["BC_No"].ToString(), true);
                                    cell2.DataSource = list3;
                                    if (list3.Count == 1)
                                    {
                                        row.Cells[this.BC_ITEM_INDEX].Value = list3[0];
                                    }
                                }
                            }
                            row.Cells["Item_Load_Qty"].Value = table.DT.Rows[num3]["Item_Load_Qty"].ToString();
                            row.Cells["Deleted"].Value = "E";
                            row.Cells["transBC_uniq"].Value = table.DT.Rows[num3]["uniq"].ToString();
                            DataGridViewComboBoxCell cell3 = (DataGridViewComboBoxCell) row.Cells[this.BC_NO_INDEX];
                            cell3.DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing;
                            cell3.Style.BackColor = Color.LightGray;
                            cell3.ReadOnly = true;
                            DataGridViewComboBoxCell cell4 = (DataGridViewComboBoxCell) row.Cells[this.BC_ITEM_INDEX];
                            cell4.DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing;
                            cell4.Style.BackColor = Color.LightGray;
                            cell4.ReadOnly = true;
                            row.Cells["Item_Load_Qty"].ReadOnly = false;
                            row.Cells["Item_Load_Qty"].Style.BackColor = Color.White;
                            num2++;
                        }
                        num4++;
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btnDeleteRow_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MN_SPAREPART_ENTRY", "D"))
            {
                MessageBox.Show(Resource.SPRI_Mes_013, "N O T I C E");
            }
            else if (MessageBox.Show(Resource.SPRI_Mes_014, "W A R N I N G", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                if ((this.dgvDO.Rows[this.selected_row].Cells["Deleted"].Value == null) || (this.dgvDO.Rows[this.selected_row].Cells["Deleted"].Value.ToString() == ""))
                {
                    this.dgvDO.Rows.RemoveAt(this.selected_row);
                }
                else
                {
                    this.dgvDO.Rows[this.selected_row].Cells["Deleted"].Value = "D";
                    this.dgvDO.Rows[this.selected_row].Visible = false;
                }
                this.selected_row = -1;
                this.btnDuplicateRow.Enabled = false;
                this.btnDeleteRow.Enabled = false;
            }
        }

        private void btnDuplicateRow_Click(object sender, EventArgs e)
        {
            if (this.selected_row <= -1)
            {
                MessageBox.Show(Resource.SPRI_Mes_012, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else if (this.dgvDO.Rows[this.selected_row].Cells["Require_BC"].ToString() != "Y")
            {
                MessageBox.Show(Resource.SPRI_Mes_017, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                int num = this.dgvDO.Rows.Add();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.dgvDO.Rows[this.selected_row].Cells.Count)
                    {
                        this.dgvDO.Rows[num].Cells[this.BC_ITEM_INDEX].Value = "";
                        this.dgvDO.Rows[num].Cells["BC_Type"].Value = "";
                        this.dgvDO.Rows[num].Cells["BC_Date"].Value = "";
                        this.dgvDO.Rows[num].Cells["BC_Exp_Date"].Value = "";
                        this.dgvDO.Rows[num].Cells["BC_Qty"].Value = "";
                        this.dgvDO.Rows[num].Cells["Item_Load_Qty"].Value = "0";
                        this.dgvDO.Rows[num].Cells["BC_UoM"].Value = "";
                        this.dgvDO.Rows[num].Cells["Deleted"].Value = "";
                        this.dgvDO.Rows[num].Cells["transBC_uniq"].Value = "";
                        this.selected_row = num;
                        this.dgvDO.ClearSelection();
                        this.dgvDO.CurrentCell = this.dgvDO.Rows[this.selected_row].Cells[5];
                        this.dgvDO.Rows[this.selected_row].Selected = true;
                        this.dgvDO.FirstDisplayedScrollingRowIndex = this.selected_row;
                        break;
                    }
                    if (num2 == this.BC_NO_INDEX)
                    {
                        List<string> list = this.getDistinctBCNo(this.dgvDO.Rows[num].Cells["DO_No"].Value.ToString(), this.dgvDO.Rows[num].Cells["STO"].Value.ToString(), this.dgvDO.Rows[num].Cells["STO_Item"].Value.ToString(), false);
                        ((DataGridViewComboBoxCell) this.dgvDO.Rows[num].Cells[this.BC_NO_INDEX]).DataSource = list;
                        if (list.Count == 1)
                        {
                            this.dgvDO.Rows[num].Cells[this.BC_NO_INDEX].Value = list[0];
                        }
                    }
                    this.dgvDO.Rows[num].Cells[num2].Value = (num2 != this.BC_ITEM_INDEX) ? this.dgvDO.Rows[this.selected_row].Cells[num2].Value : "";
                    num2++;
                }
            }
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string keyword = this.txtFilterKeyword.Text.Trim().ToLower();
            if (this.chkBoxFilter.Checked)
            {
                this.filter(true, keyword);
            }
            else
            {
                this.filter(false, keyword);
            }
            this.dgvDO.Refresh();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (WBUser.CheckTrustee("MN_SPAREPART_ENTRY", "A"))
            {
                int num2 = 0;
                while (true)
                {
                    if (num2 < this.dgvDO.Rows.Count)
                    {
                        if ((((this.dgvDO.Rows[num2].Cells["Item_Load_Qty"].Value == null) || (this.dgvDO.Rows[num2].Cells["Item_Load_Qty"].Value.ToString().Trim() == "")) || (this.dgvDO.Rows[num2].Cells["Item_Load_Qty"].Value.ToString().Trim() == "0")) || (((((this.dgvDO.Rows[num2].Cells[this.BC_NO_INDEX].Value != null) && ((this.dgvDO.Rows[num2].Cells[this.BC_NO_INDEX].Value.ToString() != "") && (this.dgvDO.Rows[num2].Cells[this.BC_ITEM_INDEX].Value != null))) && (this.dgvDO.Rows[num2].Cells[this.BC_ITEM_INDEX].Value.ToString() != "")) || (this.dgvDO.Rows[num2].Cells["Require_BC"].Value == null)) || (this.dgvDO.Rows[num2].Cells["Require_BC"].Value.ToString() != "Y")))
                        {
                            num2++;
                            continue;
                        }
                        MessageBox.Show(string.Format(Resource.SPRI_Mes_006, (num2 + 1).ToString(), this.dgvDO.Rows[num2].Cells["STO"].Value.ToString().Trim(), this.dgvDO.Rows[num2].Cells["STO_Item"].Value.ToString().Trim()), "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        bool flag = false;
                        using (IEnumerator enumerator = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
                        {
                            while (true)
                            {
                                if (!enumerator.MoveNext())
                                {
                                    break;
                                }
                                DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                                if (((current.Cells["Item_Load_Qty"].Value != null) && (current.Cells["Item_Load_Qty"].Value.ToString().Trim() != "")) && (current.Cells["Item_Load_Qty"].Value.ToString().Trim() != "0"))
                                {
                                    bool flag8 = ((current.Cells[this.BC_NO_INDEX].Value != null) && ((current.Cells[this.BC_NO_INDEX].Value.ToString() != "") && (current.Cells[this.BC_ITEM_INDEX].Value != null))) && (current.Cells[this.BC_ITEM_INDEX].Value.ToString() != "");
                                    int num4 = Convert.ToInt32(current.Cells["Item_Load_Qty"].Value.ToString().Trim());
                                    int num5 = 0;
                                    int num6 = 0;
                                    int num7 = 0;
                                    if (flag8)
                                    {
                                        num5 = this.calculateTotalNewValue_BC(current.Cells[this.BC_NO_INDEX].Value.ToString(), current.Cells[this.BC_ITEM_INDEX].Value.ToString());
                                        num6 = Convert.ToInt32(current.Cells["BC_Qty"].Value.ToString().Trim());
                                    }
                                    int num8 = this.calculateTotalNewValue_STO(current.Cells["STO"].Value.ToString(), current.Cells["STO_Item"].Value.ToString());
                                    decimal num10 = Math.Round(Convert.ToDecimal((double) ((Convert.ToDouble(current.Cells["STO_Qty"].Value.ToString().Trim()) * Convert.ToDouble(current.Cells["Tolerance"].Value.ToString().Trim())) / 100.0)), 2, MidpointRounding.AwayFromZero);
                                    int num11 = Convert.ToInt32(current.Cells["STO_Qty"].Value.ToString().Trim()) + Convert.ToInt32(num10);
                                    int num12 = 0;
                                    string sqltext = "";
                                    string str2 = "";
                                    WBTable table = new WBTable();
                                    WBTable table2 = new WBTable();
                                    string str3 = "";
                                    if (current.Cells["Deleted"].Value != null)
                                    {
                                        str3 = current.Cells["Deleted"].Value.ToString().Trim();
                                    }
                                    if (str3 != "D")
                                    {
                                        object[] objArray1 = new object[11];
                                        objArray1[0] = "select SUM(cast(Item_Load_Qty as int)) as used_qty from \r\n                        (select b.* from wb_transBC as b inner join wb_transaction as c on b.ref = c.ref where (b.deleted <> 'Y' or b.deleted is null) and b.Ref NOT LIKE '";
                                        objArray1[1] = this.getRefTransDO(current.Cells["Do_No"].Value.ToString());
                                        objArray1[2] = "%' and (c.deleted <> 'Y' or c.deleted is null)) as temp group by temp.Coy, temp.Location_Code, temp.STO, temp.STO_Item \r\n                                    having \r\n                                    temp.Coy = '";
                                        objArray1[3] = current.Cells["Coy"].Value;
                                        objArray1[4] = "' and temp.Location_code = '";
                                        objArray1[5] = current.Cells["Location_Code"].Value;
                                        objArray1[6] = "' and temp.STO = '";
                                        objArray1[7] = current.Cells["STO"].Value;
                                        objArray1[8] = "' and temp.STO_Item = '";
                                        objArray1[9] = current.Cells["STO_Item"].Value;
                                        objArray1[10] = "'";
                                        str2 = string.Concat(objArray1);
                                        table.OpenTable("WB_LOCATION", str2, WBData.conn);
                                        if (table.DT.Rows.Count > 0)
                                        {
                                            num12 = Convert.ToInt32(table.DT.Rows[0]["used_qty"].ToString());
                                        }
                                        if (num11 >= (num12 + num8))
                                        {
                                            if (flag8)
                                            {
                                                object[] objArray4 = new object[15];
                                                objArray4[0] = "select SUM(cast(Item_Load_Qty as int)) as used_qty from\r\n                                    (select b.* from wb_transBC as b inner join wb_transaction as c on b.ref = c.ref where (b.deleted <> 'Y' or b.deleted is null) and b.Ref NOT LIKE '";
                                                objArray4[1] = this.getRefTransDO(current.Cells["Do_No"].Value.ToString());
                                                objArray4[2] = "%' and (c.deleted <> 'Y' or c.deleted is null)) as temp group by temp.Coy, temp.Location_Code, temp.BC_No, temp.BC_Item, temp.BC_Type, temp.BC_Date\r\n                                    having \r\n                                    temp.Coy = '";
                                                objArray4[3] = current.Cells["Coy"].Value;
                                                objArray4[4] = "' and temp.Location_code = '";
                                                objArray4[5] = current.Cells["Location_Code"].Value;
                                                objArray4[6] = "' and temp.BC_No = '";
                                                objArray4[7] = current.Cells[this.BC_NO_INDEX].Value;
                                                objArray4[8] = "' and temp.BC_Item = '";
                                                objArray4[9] = current.Cells[this.BC_ITEM_INDEX].Value;
                                                objArray4[10] = "' and temp.BC_Type = '";
                                                objArray4[11] = current.Cells["BC_Type"].Value;
                                                objArray4[12] = "' and temp.BC_Date = '";
                                                objArray4[13] = Convert.ToDateTime(current.Cells["BC_Date"].Value).ToString("yyyy-MM-dd HH:mm:ss");
                                                objArray4[14] = "'";
                                                sqltext = string.Concat(objArray4);
                                                table2.OpenTable("WB_LOCATION", sqltext, WBData.conn);
                                                if (table2.DT.Rows.Count > 0)
                                                {
                                                    num7 = Convert.ToInt32(table2.DT.Rows[0]["used_qty"].ToString());
                                                }
                                                if (num6 < (num7 + num5))
                                                {
                                                    MessageBox.Show(string.Format(Resource.SPRI_Mes_007, new object[] { current.Cells["STO"].Value.ToString().Trim(), current.Cells["STO_Item"].Value.ToString().Trim(), current.Cells["Comm_Code"].Value.ToString().Trim(), current.Cells[this.BC_NO_INDEX].Value.ToString().Trim(), current.Cells[this.BC_ITEM_INDEX].Value.ToString().Trim(), current.Cells["BC_Type"].Value.ToString().Trim(), num6 - num7 }), "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                    flag = true;
                                                }
                                            }
                                            continue;
                                        }
                                        if (!flag8)
                                        {
                                            MessageBox.Show(string.Format(Resource.SPRI_Mes_008_02, new object[] { current.Cells["STO"].Value.ToString().Trim(), current.Cells["STO_Item"].Value.ToString().Trim(), current.Cells["Comm_Code"].Value.ToString().Trim(), num11 - num12 }), "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        }
                                        else
                                        {
                                            MessageBox.Show(string.Format(Resource.SPRI_Mes_008_01, new object[] { current.Cells["STO"].Value.ToString().Trim(), current.Cells["STO_Item"].Value.ToString().Trim(), current.Cells["Comm_Code"].Value.ToString().Trim(), current.Cells[this.BC_NO_INDEX].Value.ToString().Trim(), current.Cells[this.BC_ITEM_INDEX].Value.ToString().Trim(), current.Cells["BC_Type"].Value.ToString().Trim(), num11 - num12 }), "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                        if (!flag)
                        {
                            new WBTable().ClearToken(this.txtRefNo.Text.Trim(), "", "OVER_BC_QTY", false);
                        }
                        else
                        {
                            if (this.report_date != "")
                            {
                                MessageBox.Show("Over Quantity BC data. Can not edit sparepart quantity. Please re-adopt BC quantity from SAP and make sure BC quantity is not over.");
                                break;
                            }
                            if (MessageBox.Show(Resource.Mes_616, Resource.Mes_Notice, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                            {
                                break;
                            }
                            this.hasil = new WBTable().tokenOrApp(this.txtRefNo.Text.Trim(), "", "OVER_BC_QTY", "TOKEN_OVER_BC_QTY", "OVER_BC_QTY", "E", "", null);
                            if (this.hasil[0] != "completed")
                            {
                                if (this.hasil[0] == "process")
                                {
                                    base.Close();
                                }
                                break;
                            }
                            this.approve_type = "OVER_BC_QTY";
                            this.approveBy1 = this.hasil[1];
                            this.Approve_Reason = this.hasil[2];
                        }
                        int index = 0;
                        string[] strArray = new string[this.dgvDO.Rows.Count];
                        foreach (DataGridViewRow row2 in (IEnumerable) this.dgvDO.Rows)
                        {
                            if (((row2.Cells["Item_Load_Qty"].Value != null) && (row2.Cells["Item_Load_Qty"].Value.ToString().Trim() != "")) && (row2.Cells["Item_Load_Qty"].Value.ToString().Trim() != "0"))
                            {
                                bool flag24 = ((row2.Cells[this.BC_NO_INDEX].Value != null) && ((row2.Cells[this.BC_NO_INDEX].Value.ToString() != "") && (row2.Cells[this.BC_ITEM_INDEX].Value != null))) && (row2.Cells[this.BC_ITEM_INDEX].Value.ToString() != "");
                                int num13 = Convert.ToInt32(row2.Cells["Item_Load_Qty"].Value.ToString().Trim());
                                int num14 = 0;
                                int num15 = 0;
                                int num16 = 0;
                                if (flag24)
                                {
                                    num14 = this.calculateTotalNewValue_BC(row2.Cells[this.BC_NO_INDEX].Value.ToString(), row2.Cells[this.BC_ITEM_INDEX].Value.ToString());
                                    num15 = Convert.ToInt32(row2.Cells["BC_Qty"].Value.ToString().Trim());
                                }
                                int num17 = this.calculateTotalNewValue_STO(row2.Cells["STO"].Value.ToString(), row2.Cells["STO_Item"].Value.ToString());
                                int num18 = Convert.ToInt32(row2.Cells["STO_Qty"].Value.ToString().Trim());
                                int num19 = 0;
                                bool flag25 = false;
                                bool flag26 = false;
                                string sqltext = "";
                                string str5 = "";
                                WBTable table6 = new WBTable();
                                WBTable table7 = new WBTable();
                                string str6 = "";
                                if (row2.Cells["Deleted"].Value != null)
                                {
                                    str6 = row2.Cells["Deleted"].Value.ToString().Trim();
                                }
                                if (str6 != "D")
                                {
                                    if (flag24)
                                    {
                                        object[] objArray6 = new object[15];
                                        objArray6[0] = "select SUM(cast(Item_Load_Qty as int)) as used_qty from (select * from wb_transBC where (deleted <> 'Y' or deleted is null) and Ref NOT LIKE '";
                                        objArray6[1] = this.getRefTransDO(row2.Cells["Do_No"].Value.ToString());
                                        objArray6[2] = "%') as temp group by temp.Coy, temp.Location_Code, temp.BC_No, temp.BC_Item, temp.BC_Type, temp.BC_Date\r\n                                    having \r\n                                    temp.Coy = '";
                                        objArray6[3] = row2.Cells["Coy"].Value;
                                        objArray6[4] = "' and temp.Location_code = '";
                                        objArray6[5] = row2.Cells["Location_Code"].Value;
                                        objArray6[6] = "' and temp.BC_No = '";
                                        objArray6[7] = row2.Cells[this.BC_NO_INDEX].Value;
                                        objArray6[8] = "' and temp.BC_Item = '";
                                        objArray6[9] = row2.Cells[this.BC_ITEM_INDEX].Value;
                                        objArray6[10] = "' and temp.BC_Type = '";
                                        objArray6[11] = row2.Cells["BC_Type"].Value;
                                        objArray6[12] = "' and temp.BC_Date = '";
                                        objArray6[13] = Convert.ToDateTime(row2.Cells["BC_Date"].Value).ToString("yyyy-MM-dd HH:mm:ss");
                                        objArray6[14] = "'";
                                        sqltext = string.Concat(objArray6);
                                        table7.OpenTable("WB_LOCATION", sqltext, WBData.conn);
                                        if (table7.DT.Rows.Count > 0)
                                        {
                                            num16 = Convert.ToInt32(table7.DT.Rows[0]["used_qty"].ToString());
                                        }
                                        if (num15 <= (num16 + num14))
                                        {
                                            flag26 = true;
                                        }
                                    }
                                    object[] objArray7 = new object[11];
                                    objArray7[0] = "select SUM(cast(Item_Load_Qty as int)) as used_qty from (select * from wb_transBC where (deleted <> 'Y' or deleted is null) and Ref NOT LIKE '";
                                    objArray7[1] = this.getRefTransDO(row2.Cells["Do_No"].Value.ToString());
                                    objArray7[2] = "%') as temp group by temp.Coy, temp.Location_Code, temp.Ref, temp.STO, temp.STO_Item \r\n                                    having \r\n                                    temp.Coy = '";
                                    objArray7[3] = row2.Cells["Coy"].Value;
                                    objArray7[4] = "' and temp.Location_code = '";
                                    objArray7[5] = row2.Cells["Location_Code"].Value;
                                    objArray7[6] = "' and temp.STO = '";
                                    objArray7[7] = row2.Cells["STO"].Value;
                                    objArray7[8] = "' and temp.STO_Item = '";
                                    objArray7[9] = row2.Cells["STO_Item"].Value;
                                    objArray7[10] = "'";
                                    str5 = string.Concat(objArray7);
                                    table6.OpenTable("WB_LOCATION", str5, WBData.conn);
                                    if (table6.DT.Rows.Count > 0)
                                    {
                                        num19 = Convert.ToInt32(table6.DT.Rows[0]["used_qty"].ToString());
                                    }
                                    if (num18 <= (num19 + num17))
                                    {
                                        flag25 = true;
                                    }
                                }
                                string str7 = "";
                                string str8 = "";
                                string str9 = "";
                                WBTable table8 = new WBTable();
                                WBTable table9 = new WBTable();
                                WBTable table10 = new WBTable();
                                if (str6 == "D")
                                {
                                    str9 = "select * from \r\n                                wb_transBC where uniq = '" + row2.Cells["transBC_uniq"].Value.ToString().Trim() + "'";
                                    table8.OpenTable("WB_LOCATION", str9, WBData.conn);
                                    if (table8.DT.Rows.Count > 0)
                                    {
                                        table8.DR = table8.DT.Rows[0];
                                        table8.DR.BeginEdit();
                                        table8.DR["Deleted"] = "Y";
                                        table8.DR.EndEdit();
                                        table8.Save();
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Mark as deleted." };
                                        Program.updateLogHeader("wb_transBC", table8.DT.Rows[0]["uniq"].ToString(), logField, logValue);
                                    }
                                    if (flag24)
                                    {
                                        string[] textArray3 = new string[11];
                                        textArray3[0] = "select * from wb_contract_detail_BC where BC_No = '";
                                        textArray3[1] = row2.Cells[this.BC_NO_INDEX].Value.ToString().Trim();
                                        textArray3[2] = "'and do_no = '";
                                        textArray3[3] = row2.Cells["DO_No"].Value.ToString().Trim();
                                        textArray3[4] = "' and BC_Item = '";
                                        textArray3[5] = row2.Cells[this.BC_ITEM_INDEX].Value.ToString().Trim();
                                        textArray3[6] = "' and BC_Type = '";
                                        textArray3[7] = row2.Cells["BC_Type"].Value.ToString().Trim();
                                        textArray3[8] = "' and BC_Date = '";
                                        textArray3[9] = Convert.ToDateTime(row2.Cells["BC_Date"].Value.ToString().Trim()).ToString("yyyy-MM-dd HH:mm:ss");
                                        textArray3[10] = "'";
                                        str7 = string.Concat(textArray3);
                                        table10.OpenTable("WB_LOCATION", str7, WBData.conn);
                                        if (table10.DT.Rows.Count > 0)
                                        {
                                            int num20 = 0;
                                            while (true)
                                            {
                                                if (num20 >= table10.DT.Rows.Count)
                                                {
                                                    break;
                                                }
                                                table10.DR = table10.DT.Rows[num20];
                                                table10.DR.BeginEdit();
                                                table10.DR["BC_OS_Closed"] = "N";
                                                table10.DR.EndEdit();
                                                table10.Save();
                                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Unlock due to deleting transBC Entry." };
                                                Program.updateLogHeader("wb_contract_detail_BC", table8.DT.Rows[num20]["uniq"].ToString(), logField, logValue);
                                                num20++;
                                            }
                                        }
                                    }
                                    if (this.DO_query_source[row2.Cells["Do_No"].Value.ToString().Trim()] == "0")
                                    {
                                        string[] textArray6 = new string[] { "select * from wb_contract where STO = '", row2.Cells["STO"].Value.ToString().Trim(), "' and STO_Item = '", row2.Cells["STO_Item"].Value.ToString().Trim(), "'" };
                                        str8 = string.Concat(textArray6);
                                    }
                                    else if (this.DO_query_source[row2.Cells["Do_No"].Value.ToString().Trim()] == "1")
                                    {
                                        string[] textArray7 = new string[] { "select * from wb_contract_detail_STO where STO = '", row2.Cells["STO"].Value.ToString().Trim(), "' and STO_Item = '", row2.Cells["STO_Item"].Value.ToString().Trim(), "'" };
                                        str8 = string.Concat(textArray7);
                                    }
                                    table9.OpenTable("WB_LOCATION", str8, WBData.conn);
                                    if (table9.DT.Rows.Count > 0)
                                    {
                                        int num21 = 0;
                                        while (true)
                                        {
                                            if (num21 >= table9.DT.Rows.Count)
                                            {
                                                break;
                                            }
                                            table9.DR = table9.DT.Rows[num21];
                                            table9.DR.BeginEdit();
                                            table9.DR["STO_OS_Closed"] = "N";
                                            table9.DR.EndEdit();
                                            table9.Save();
                                            if (this.DO_query_source[row2.Cells["Do_No"].Value.ToString().Trim()] == "0")
                                            {
                                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Unlock due to deleting transBC Entry." };
                                                Program.updateLogHeader("wb_contract", table9.DT.Rows[num21]["uniq"].ToString(), logField, logValue);
                                            }
                                            else if (this.DO_query_source[row2.Cells["Do_No"].Value.ToString().Trim()] == "1")
                                            {
                                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Unlock due to deleting transBC Entry." };
                                                Program.updateLogHeader("wb_contract_detail_STO", table9.DT.Rows[num21]["uniq"].ToString(), logField, logValue);
                                            }
                                            num21++;
                                        }
                                    }
                                }
                                else if (str6 != "D")
                                {
                                    if ((row2.Cells["transBC_uniq"].Value != null) && (row2.Cells["transBC_uniq"].Value.ToString().Trim() != ""))
                                    {
                                        str9 = "select * from \r\n                                    wb_transBC where uniq = '" + row2.Cells["transBC_uniq"].Value.ToString().Trim() + "'";
                                    }
                                    else if (!flag24)
                                    {
                                        string[] textArray13 = new string[9];
                                        textArray13[0] = "select * from \r\n                                    wb_transBC where Ref LIKE '";
                                        textArray13[1] = this.txtRefNo.Text;
                                        textArray13[2] = "%' and Do_No = '";
                                        textArray13[3] = row2.Cells["Do_No"].Value.ToString().Trim();
                                        textArray13[4] = "' and STO = '";
                                        textArray13[5] = row2.Cells["STO"].Value.ToString().Trim();
                                        textArray13[6] = "' and STO_Item = '";
                                        textArray13[7] = row2.Cells["STO_Item"].Value.ToString().Trim();
                                        textArray13[8] = "'";
                                        str9 = string.Concat(textArray13);
                                    }
                                    else
                                    {
                                        string[] textArray12 = new string[0x11];
                                        textArray12[0] = "select * from \r\n                                    wb_transBC where Ref LIKE '";
                                        textArray12[1] = this.txtRefNo.Text;
                                        textArray12[2] = "%' and Do_No = '";
                                        textArray12[3] = row2.Cells["Do_No"].Value.ToString().Trim();
                                        textArray12[4] = "' and STO = '";
                                        textArray12[5] = row2.Cells["STO"].Value.ToString().Trim();
                                        textArray12[6] = "' and STO_Item = '";
                                        textArray12[7] = row2.Cells["STO_Item"].Value.ToString().Trim();
                                        textArray12[8] = "' and BC_No = '";
                                        textArray12[9] = row2.Cells[this.BC_NO_INDEX].Value.ToString().Trim();
                                        textArray12[10] = "' and BC_Item = '";
                                        textArray12[11] = row2.Cells[this.BC_ITEM_INDEX].Value.ToString().Trim();
                                        textArray12[12] = "' and BC_Type = '";
                                        textArray12[13] = row2.Cells["BC_Type"].Value.ToString().Trim();
                                        textArray12[14] = "' and BC_Date = '";
                                        textArray12[15] = Convert.ToDateTime(row2.Cells["BC_Date"].Value.ToString().Trim()).ToString("yyyy-MM-dd HH:mm:ss");
                                        textArray12[0x10] = "'";
                                        str9 = string.Concat(textArray12);
                                    }
                                    table8.OpenTable("WB_LOCATION", str9, WBData.conn);
                                    if (table8.DT.Rows.Count != 0)
                                    {
                                        table8.DR = table8.DT.Rows[0];
                                        table8.DR.BeginEdit();
                                        if (flag24)
                                        {
                                            table8.DR["BC_No"] = row2.Cells[this.BC_NO_INDEX].Value.ToString().Trim().ToString();
                                            table8.DR["BC_Item"] = row2.Cells[this.BC_ITEM_INDEX].Value.ToString().Trim().ToString();
                                            table8.DR["BC_Type"] = row2.Cells["BC_Type"].Value.ToString().Trim().ToString();
                                            table8.DR["BC_Date"] = Convert.ToDateTime(row2.Cells["BC_Date"].Value.ToString().Trim().ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                                        }
                                        else
                                        {
                                            table8.DR["BC_No"] = DBNull.Value;
                                            table8.DR["BC_Item"] = DBNull.Value;
                                            table8.DR["BC_Type"] = DBNull.Value;
                                            table8.DR["BC_Date"] = DBNull.Value;
                                        }
                                        table8.DR["Item_Load_Qty"] = Convert.ToInt32(row2.Cells["Item_Load_Qty"].Value.ToString().Trim()).ToString();
                                        table8.DR["Deleted"] = "N";
                                        table8.DR.EndEdit();
                                    }
                                    else
                                    {
                                        table8.DR = table8.DT.NewRow();
                                        table8.DR["Coy"] = row2.Cells["Coy"].Value.ToString().Trim();
                                        table8.DR["Location_Code"] = row2.Cells["Location_Code"].Value.ToString().Trim();
                                        table8.DR["Ref"] = this.getRefTransDO(row2.Cells["Do_No"].Value.ToString());
                                        table8.DR["Do_No"] = row2.Cells["Do_No"].Value;
                                        table8.DR["STO"] = row2.Cells["STO"].Value.ToString().Trim();
                                        table8.DR["STO_Item"] = row2.Cells["STO_Item"].Value.ToString().Trim();
                                        if (flag24)
                                        {
                                            table8.DR["BC_No"] = row2.Cells[this.BC_NO_INDEX].Value.ToString().Trim().ToString();
                                            table8.DR["BC_Item"] = row2.Cells[this.BC_ITEM_INDEX].Value.ToString().Trim().ToString();
                                            table8.DR["BC_Type"] = row2.Cells["BC_Type"].Value.ToString().Trim().ToString();
                                            table8.DR["BC_Date"] = Convert.ToDateTime(row2.Cells["BC_Date"].Value.ToString().Trim().ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                                        }
                                        else
                                        {
                                            table8.DR["BC_No"] = DBNull.Value;
                                            table8.DR["BC_Item"] = DBNull.Value;
                                            table8.DR["BC_Type"] = DBNull.Value;
                                            table8.DR["BC_Date"] = DBNull.Value;
                                        }
                                        table8.DR["Item_Load_Qty"] = Convert.ToInt32(row2.Cells["Item_Load_Qty"].Value.ToString().Trim()).ToString();
                                        table8.DR["Deleted"] = "N";
                                        table8.DT.Rows.Add(table8.DR);
                                    }
                                    table8.Save();
                                    if (table8.DT.Rows.Count > 0)
                                    {
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Update / Mark the record as not deleted." };
                                        Program.updateLogHeader("wb_transBC", table8.DT.Rows[0]["uniq"].ToString(), logField, logValue);
                                    }
                                    if (flag24)
                                    {
                                        string[] textArray16 = new string[9];
                                        textArray16[0] = "select * from wb_contract_detail_BC where BC_No = '";
                                        textArray16[1] = row2.Cells[this.BC_NO_INDEX].Value.ToString().Trim();
                                        textArray16[2] = "' and BC_Item = '";
                                        textArray16[3] = row2.Cells[this.BC_ITEM_INDEX].Value.ToString().Trim();
                                        textArray16[4] = "' and BC_Type = '";
                                        textArray16[5] = row2.Cells["BC_Type"].Value.ToString().Trim();
                                        textArray16[6] = "' and BC_Date = '";
                                        textArray16[7] = Convert.ToDateTime(row2.Cells["BC_Date"].Value.ToString().Trim()).ToString("yyyy-MM-dd HH:mm:ss");
                                        textArray16[8] = "'";
                                        str7 = string.Concat(textArray16);
                                        table10.OpenTable("WB_LOCATION", str7, WBData.conn);
                                        if (table10.DT.Rows.Count > 0)
                                        {
                                            int num22 = 0;
                                            while (true)
                                            {
                                                if (num22 >= table10.DT.Rows.Count)
                                                {
                                                    break;
                                                }
                                                table10.DR = table10.DT.Rows[num22];
                                                string str10 = table10.DR["BC_OS_Closed"].ToString();
                                                table10.DR.BeginEdit();
                                                table10.DR["BC_OS_Closed"] = flag26 ? "Y" : "N";
                                                table10.DR.EndEdit();
                                                table10.Save();
                                                if ((str10 != table10.DR["BC_OS_Closed"].ToString()) & flag26)
                                                {
                                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Lock due to reaching Outstanding." };
                                                    Program.updateLogHeader("wb_contract_detail_BC", table10.DT.Rows[num22]["uniq"].ToString(), logField, logValue);
                                                }
                                                else if ((str10 != table10.DR["BC_OS_Closed"].ToString()) && !flag26)
                                                {
                                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Unlock due to not reaching Outstanding anymore." };
                                                    Program.updateLogHeader("wb_contract_detail_BC", table10.DT.Rows[num22]["uniq"].ToString(), logField, logValue);
                                                }
                                                num22++;
                                            }
                                        }
                                    }
                                    if (this.DO_query_source[row2.Cells["Do_No"].Value.ToString().Trim()] == "0")
                                    {
                                        string[] textArray21 = new string[] { "select * from wb_contract where STO = '", row2.Cells["STO"].Value.ToString().Trim(), "' and STO_Item = '", row2.Cells["STO_Item"].Value.ToString().Trim(), "'" };
                                        str8 = string.Concat(textArray21);
                                    }
                                    else if (this.DO_query_source[row2.Cells["Do_No"].Value.ToString().Trim()] == "1")
                                    {
                                        string[] textArray22 = new string[] { "select * from wb_contract_detail_STO where STO = '", row2.Cells["STO"].Value.ToString().Trim(), "' and STO_Item = '", row2.Cells["STO_Item"].Value.ToString().Trim(), "'" };
                                        str8 = string.Concat(textArray22);
                                    }
                                    table9.OpenTable("WB_LOCATION", str8, WBData.conn);
                                    if (table9.DT.Rows.Count > 0)
                                    {
                                        int num23 = 0;
                                        while (true)
                                        {
                                            if (num23 >= table9.DT.Rows.Count)
                                            {
                                                break;
                                            }
                                            table9.DR = table9.DT.Rows[num23];
                                            string str11 = table9.DR["STO_OS_Closed"].ToString();
                                            table9.DR.BeginEdit();
                                            table9.DR["STO_OS_Closed"] = flag25 ? "Y" : "N";
                                            table9.DR.EndEdit();
                                            table9.Save();
                                            if ((str11 != table9.DR["STO_OS_Closed"].ToString()) & flag25)
                                            {
                                                if (this.DO_query_source[row2.Cells["Do_No"].Value.ToString().Trim()] == "0")
                                                {
                                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Lock due to reaching Outstanding." };
                                                    Program.updateLogHeader("wb_contract", table9.DT.Rows[num23]["uniq"].ToString(), logField, logValue);
                                                }
                                                else if (this.DO_query_source[row2.Cells["Do_No"].Value.ToString().Trim()] == "1")
                                                {
                                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Lock due to reaching Outstanding." };
                                                    Program.updateLogHeader("wb_contract_detail_STO", table9.DT.Rows[num23]["uniq"].ToString(), logField, logValue);
                                                }
                                            }
                                            else if ((str11 != table9.DR["STO_OS_Closed"].ToString()) && !flag25)
                                            {
                                                if (this.DO_query_source[row2.Cells["Do_No"].Value.ToString().Trim()] == "0")
                                                {
                                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Unlock due to not reaching Outstanding anymore." };
                                                    Program.updateLogHeader("wb_contract", table9.DT.Rows[num23]["uniq"].ToString(), logField, logValue);
                                                }
                                                else if (this.DO_query_source[row2.Cells["Do_No"].Value.ToString().Trim()] == "1")
                                                {
                                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Unlock due to not reaching Outstanding anymore." };
                                                    Program.updateLogHeader("wb_contract_detail_STO", table9.DT.Rows[num23]["uniq"].ToString(), logField, logValue);
                                                }
                                            }
                                            num23++;
                                        }
                                    }
                                }
                                WBTable table5 = new WBTable();
                                table5.OpenTable("wb_contract_detail_BC", "select * from wb_contract_detail_bc where " + WBData.CompanyLocation(" and do_no = '" + row2.Cells["DO_NO"].Value.ToString().Trim() + "' and (bc_os_closed <> 'Y' or bc_os_closed is null)"), WBData.conn);
                                if (table5.DT.Rows.Count <= 0)
                                {
                                    WBTable table11 = new WBTable();
                                    WBTable table12 = new WBTable();
                                    table11.OpenTable("wb_contract_detail_sto", "select UNIQ, COY, LOCATION_CODE, DO_NO, COMM_CODE, STO, STO_ITEM, STO_QTY, STO_UOM, TRACKING_NO, TRACKING_ITEM, case when (sto_os_closed is null or sto_os_closed <> 'Y') then 'N' else 'Y' end as sto_os_closed, REQUIRE_BC from wb_contract_detail_sto where " + WBData.CompanyLocation(" and do_no = '" + row2.Cells["DO_NO"].Value.ToString().Trim() + "'"), WBData.conn);
                                    if (table11.DT.Rows.Count <= 0)
                                    {
                                        table12.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and do_no = '" + row2.Cells["DO_NO"].Value.ToString().Trim() + "' and sto_os_closed = 'Y'"), WBData.conn);
                                        if (table12.DT.Rows.Count > 0)
                                        {
                                            strArray[index] = table12.DT.Rows[0]["uniq"].ToString();
                                        }
                                    }
                                    else
                                    {
                                        string[] aField = new string[] { "STO_OS_Closed" };
                                        string[] aFind = new string[] { "N" };
                                        table11.DR = table11.GetData(aField, aFind);
                                        if (ReferenceEquals(table11.DR, null))
                                        {
                                            table12.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and do_no = '" + row2.Cells["DO_NO"].Value.ToString().Trim() + "'"), WBData.conn);
                                            strArray[index] = table12.DT.Rows[0]["uniq"].ToString();
                                        }
                                    }
                                    table11.Dispose();
                                    table12.Dispose();
                                }
                                index += index;
                                table5.Dispose();
                            }
                        }
                        if (strArray != null)
                        {
                            Program.AutoCloseDO(strArray);
                        }
                        MessageBox.Show(Resource.SPRI_Mes_009_02, "S U C C C E S S", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        base.Close();
                    }
                    break;
                }
            }
            else
            {
                MessageBox.Show(Resource.SPRI_Mes_005, "N O T I C E");
            }
        }

        private int calculateTotalNewValue_BC(string BC_No, string BC_Item)
        {
            int num = 0;
            for (int i = 0; i < this.dgvDO.Rows.Count; i++)
            {
                if (((this.dgvDO.Rows[i].Cells[this.BC_NO_INDEX].Value != null) && ((this.dgvDO.Rows[i].Cells[this.BC_ITEM_INDEX].Value != null) && (this.dgvDO.Rows[i].Cells[this.BC_NO_INDEX].Value.ToString() == BC_No))) && (this.dgvDO.Rows[i].Cells[this.BC_ITEM_INDEX].Value.ToString() == BC_Item))
                {
                    num = (this.dgvDO.Rows[i].Cells["Item_Load_Qty"].Value != null) ? (num + ((this.dgvDO.Rows[i].Cells["Item_Load_Qty"].Value.ToString().Trim() == "") ? 0 : Convert.ToInt32(this.dgvDO.Rows[i].Cells["Item_Load_Qty"].Value.ToString()))) : num;
                }
            }
            return num;
        }

        private int calculateTotalNewValue_STO(string STO, string STO_Item)
        {
            int num = 0;
            for (int i = 0; i < this.dgvDO.Rows.Count; i++)
            {
                if ((this.dgvDO.Rows[i].Cells["STO"].Value.ToString() == STO) && (this.dgvDO.Rows[i].Cells["STO_Item"].Value.ToString() == STO_Item))
                {
                    num = (this.dgvDO.Rows[i].Cells["Item_Load_Qty"].Value != null) ? (num + ((this.dgvDO.Rows[i].Cells["Item_Load_Qty"].Value.ToString().Trim() == "") ? 0 : Convert.ToInt32(this.dgvDO.Rows[i].Cells["Item_Load_Qty"].Value.ToString()))) : num;
                }
            }
            return num;
        }

        private void cekDuplicateBC()
        {
            int num = 0;
            while (true)
            {
                if (num >= (this.dgvDO.Rows.Count - 1))
                {
                    break;
                }
                if ((this.dgvDO.Rows[num].Cells["Deleted"].Value == null) || ((this.dgvDO.Rows[num].Cells["Deleted"].Value != null) && (this.dgvDO.Rows[num].Cells["Deleted"].Value.ToString() != "D")))
                {
                    int num2 = num + 1;
                    while (true)
                    {
                        if (num2 >= this.dgvDO.Rows.Count)
                        {
                            break;
                        }
                        bool flag2 = ((this.dgvDO.Rows[num].Cells["Do_No"].Value == null) || ((this.dgvDO.Rows[num].Cells["STO"].Value == null) || ((this.dgvDO.Rows[num].Cells["STO_Item"].Value == null) || (this.dgvDO.Rows[num].Cells[this.BC_ITEM_INDEX].Value == null)))) || (this.dgvDO.Rows[num].Cells[this.BC_NO_INDEX].Value == null);
                        bool flag3 = ((this.dgvDO.Rows[num].Cells["Do_No"].Value == null) || ((this.dgvDO.Rows[num2].Cells["STO"].Value == null) || ((this.dgvDO.Rows[num2].Cells["STO_Item"].Value == null) || (this.dgvDO.Rows[num2].Cells[this.BC_ITEM_INDEX].Value == null)))) || (this.dgvDO.Rows[num2].Cells[this.BC_NO_INDEX].Value == null);
                        if (!flag2 && !flag3)
                        {
                            bool flag7 = this.dgvDO.Rows[num].Cells[this.BC_ITEM_INDEX].Value.ToString() == this.dgvDO.Rows[num2].Cells[this.BC_ITEM_INDEX].Value.ToString();
                            bool flag8 = this.dgvDO.Rows[num].Cells["STO"].Value.ToString() == this.dgvDO.Rows[num2].Cells["STO"].Value.ToString();
                            bool flag9 = this.dgvDO.Rows[num].Cells["STO_Item"].Value.ToString() == this.dgvDO.Rows[num2].Cells["STO_Item"].Value.ToString();
                            if (((((this.dgvDO.Rows[num].Cells["Do_No"].Value.ToString() == this.dgvDO.Rows[num2].Cells["Do_No"].Value.ToString()) & (this.dgvDO.Rows[num].Cells[this.BC_NO_INDEX].Value.ToString() == this.dgvDO.Rows[num2].Cells[this.BC_NO_INDEX].Value.ToString())) & flag7) & flag8) & flag9)
                            {
                                this.dgvDO.Rows[num2].Cells[this.BC_ITEM_INDEX].Value = "";
                                this.dgvDO.Rows[num2].Cells["BC_Date"].Value = "";
                                this.dgvDO.Rows[num2].Cells["BC_Exp_Date"].Value = "";
                                this.dgvDO.Rows[num2].Cells["BC_Qty"].Value = "";
                                this.dgvDO.Rows[num2].Cells["BC_UoM"].Value = "";
                                MessageBox.Show(Resource.SPRI_Mes_015, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                break;
                            }
                        }
                        num2++;
                    }
                }
                num++;
            }
        }

        private void dgvDO_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                this.selected_row = e.RowIndex;
                this.btnDuplicateRow.Enabled = true;
                this.btnDeleteRow.Enabled = true;
            }
            else
            {
                this.selected_row = -1;
                this.btnDuplicateRow.Enabled = false;
                this.btnDeleteRow.Enabled = false;
            }
        }

        private void dgvDO_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex == this.ITEM_LOAD_QTY_INDEX)
            {
                int num;
                if (!int.TryParse(Convert.ToString(e.FormattedValue), out num) && (Convert.ToString(e.FormattedValue).Trim() != ""))
                {
                    e.Cancel = true;
                    MessageBox.Show(Resource.SPRI_Mes_010, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else if (num < 0)
                {
                    e.Cancel = true;
                    MessageBox.Show(Resource.SPRI_Mes_011, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        private void dgvDO_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            string str = "";
            if (e.ColumnIndex == this.BC_NO_INDEX)
            {
                str = this.dgvDO.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                DataGridViewComboBoxCell cell = (DataGridViewComboBoxCell) this.dgvDO.Rows[e.RowIndex].Cells[this.BC_ITEM_INDEX];
                List<string> list = new List<string>();
                if (!string.IsNullOrEmpty(str))
                {
                    list = this.getDistinctBCItem(this.dgvDO.Rows[e.RowIndex].Cells["DO_No"].Value.ToString(), this.dgvDO.Rows[e.RowIndex].Cells["STO"].Value.ToString(), this.dgvDO.Rows[e.RowIndex].Cells["STO_Item"].Value.ToString(), str, false);
                }
                this.dgvDO.Rows[e.RowIndex].Cells[this.BC_ITEM_INDEX].Value = null;
                cell.DataSource = list;
                this.dgvDO.Rows[e.RowIndex].Cells["BC_Type"].Value = "";
                this.dgvDO.Rows[e.RowIndex].Cells["BC_Date"].Value = "";
                this.dgvDO.Rows[e.RowIndex].Cells["BC_Exp_Date"].Value = "";
                this.dgvDO.Rows[e.RowIndex].Cells["BC_Qty"].Value = "";
                this.dgvDO.Rows[e.RowIndex].Cells["BC_UoM"].Value = "";
                this.dgvDO.Rows[e.RowIndex].Cells["Item_Load_Qty"].ReadOnly = true;
                this.dgvDO.Rows[e.RowIndex].Cells["Item_Load_Qty"].Style.BackColor = Color.LightGray;
                if (list.Count == 1)
                {
                    this.dgvDO.Rows[e.RowIndex].Cells[this.BC_ITEM_INDEX].Value = list[0];
                }
            }
            else if ((e.ColumnIndex == this.BC_ITEM_INDEX) && (this.dgvDO.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null))
            {
                str = this.dgvDO.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                if (string.IsNullOrEmpty(str))
                {
                    this.dgvDO.Rows[e.RowIndex].Cells["BC_Type"].Value = "";
                    this.dgvDO.Rows[e.RowIndex].Cells["BC_Date"].Value = "";
                    this.dgvDO.Rows[e.RowIndex].Cells["BC_Exp_Date"].Value = "";
                    this.dgvDO.Rows[e.RowIndex].Cells["BC_Qty"].Value = "";
                    this.dgvDO.Rows[e.RowIndex].Cells["BC_UoM"].Value = "";
                    this.dgvDO.Rows[e.RowIndex].Cells["Item_Load_Qty"].ReadOnly = false;
                    this.dgvDO.Rows[e.RowIndex].Cells["Item_Load_Qty"].Style.BackColor = Color.White;
                }
                else
                {
                    foreach (DataRow row in this.DT_DetailBC.Rows)
                    {
                        if ((row["BC_No"].ToString() == this.dgvDO.Rows[e.RowIndex].Cells[this.BC_NO_INDEX].Value.ToString()) && (row["BC_Item"].ToString() == str))
                        {
                            this.dgvDO.Rows[e.RowIndex].Cells["BC_Type"].Value = row["BC_Type"].ToString();
                            this.dgvDO.Rows[e.RowIndex].Cells["BC_Date"].Value = row["BC_Date"].ToString();
                            this.dgvDO.Rows[e.RowIndex].Cells["BC_Exp_Date"].Value = row["BC_Exp_Date"].ToString();
                            this.dgvDO.Rows[e.RowIndex].Cells["BC_Qty"].Value = row["BC_Qty"].ToString();
                            this.dgvDO.Rows[e.RowIndex].Cells["BC_UoM"].Value = row["BC_UoM"].ToString();
                            break;
                        }
                    }
                    this.dgvDO.Rows[e.RowIndex].Cells["Item_Load_Qty"].ReadOnly = false;
                    this.dgvDO.Rows[e.RowIndex].Cells["Item_Load_Qty"].Style.BackColor = Color.White;
                    this.cekDuplicateBC();
                }
            }
        }

        private void dgvDO_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (this.dgvDO.IsCurrentCellDirty)
            {
                this.dgvDO.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        private void dgvDO_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void f_load()
        {
            string sqltext = "";
            if (this.txtRefNo.Text == "")
            {
                MessageBox.Show(Resource.SPRI_Mes_004, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                base.Close();
            }
            else
            {
                this.tblTrans.OpenTable("wb_transaction", "select * from wb_transaction where " + WBData.CompanyLocation(" AND (deleted = '' OR deleted = 'N' OR deleted IS null) and ref = '" + this.txtRefNo.Text + "'"), WBData.conn);
                if (this.tblTrans.DT.Rows.Count <= 0)
                {
                    MessageBox.Show(Resource.SPRI_Mes_001, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    base.Close();
                }
                else
                {
                    this.txtVehicle.Text = this.tblTrans.DT.Rows[0]["truck_number"].ToString();
                    this.textDriverID.Text = this.tblTrans.DT.Rows[0]["License_No"].ToString();
                    this.labelDriverName.Text = this.tblTrans.DT.Rows[0]["Name"].ToString();
                    this.report_date = this.tblTrans.DT.Rows[0]["report_date"].ToString();
                    this.tblTransDO.OpenTable("wb_transDO", "select * from wb_transDO where " + WBData.CompanyLocation(" And ref like'" + this.txtRefNo.Text + "%'"), WBData.conn);
                    if (this.tblTransDO.DT.Rows.Count <= 0)
                    {
                        MessageBox.Show(Resource.SPRI_Mes_002, "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        base.Close();
                    }
                    else
                    {
                        this.tblContract.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" AND Do_No IN (select DO_No from wb_transDO where ref like'" + this.txtRefNo.Text + "%')"), WBData.conn);
                        if (this.tblContract.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show(Resource.SPRI_Mes_003, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            base.Close();
                        }
                        else
                        {
                            foreach (DataRow row in this.tblContract.DT.Rows)
                            {
                                string[] textArray1 = new string[] { "select \r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Do_No\r\n                            ELSE a.Do_No\r\n                        END as Do_No,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Coy\r\n                            ELSE a.Coy\r\n                        END as Coy,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Location_Code\r\n                            ELSE a.Location_Code\r\n                        END as Location_Code,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Tracking_No\r\n                            ELSE a.Tracking_No\r\n                        END as Tracking_No,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Tracking_Item\r\n                            ELSE a.Tracking_Item\r\n                        END as Tracking_Item,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.STO\r\n                            ELSE (case when a.sto = '' then a.PO else a.sto end)\r\n                        END as STO,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.STO_Item\r\n                            ELSE (case when a.sto_item = '' then a.PO_item else a.sto_item end)\r\n                        END as STO_Item,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Comm_Code\r\n                            ELSE a.Comm_Code\r\n                        END as Comm_Code,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Comm_Name\r\n                            ELSE a.Comm_Name\r\n                        END as Comm_Name,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.STO_Qty\r\n                            ELSE a.STO_Qty\r\n                        END as STO_Qty,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.STO_UoM\r\n                            ELSE a.STO_UoM\r\n                        END as STO_UoM,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.tolerance\r\n                            ELSE a.tolerance\r\n                        END as tolerance,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Require_BC\r\n                            ELSE a.Require_BC\r\n                        END as Require_BC,\r\n                        b.uniq as contract_detail_STO_uniq\r\n                        from (select xct.*, xcom.Comm_Name from wb_contract xct left join wb_commodity xcom on xct.Coy = xcom.Coy and xct.Location_Code = xcom.Location_Code and xct.Comm_Code = xcom.comm_code) a\r\n                        left\r\n                        join (select xcts.*, xcom.Comm_Name from wb_contract_detail_STO xcts left join wb_commodity xcom on xcts.Coy = xcom.Coy and xcts.Location_Code = xcom.Location_Code and xcts.Comm_Code = xcom.comm_code) b\r\n                        on a.Coy = b.Coy and a.Location_Code = b.Location_Code and a.Do_No = b.Do_No where \r\n                        a.Coy = '", WBData.sCoyCode, "' AND a.Location_Code = '", WBData.sLocCode, "' AND a.Do_No = '", row["Do_No"].ToString(), "'" };
                                this.tblDetailSTO.OpenTable("wb_contract_detail_STO", string.Concat(textArray1), WBData.conn);
                                if (this.tblDetailSTO.DT.Rows.Count == 1)
                                {
                                    if (!string.IsNullOrEmpty(this.tblDetailSTO.DT.Rows[0]["contract_detail_STO_uniq"].ToString()))
                                    {
                                        if (this.DO_query_source.ContainsKey(this.tblDetailSTO.DT.Rows[0]["Do_No"].ToString()))
                                        {
                                            continue;
                                        }
                                        this.DO_query_source.Add(this.tblDetailSTO.DT.Rows[0]["Do_No"].ToString(), "1");
                                        continue;
                                    }
                                    if (this.DO_query_source.ContainsKey(this.tblDetailSTO.DT.Rows[0]["Do_No"].ToString()))
                                    {
                                        continue;
                                    }
                                    this.DO_query_source.Add(this.tblDetailSTO.DT.Rows[0]["Do_No"].ToString(), "0");
                                    continue;
                                }
                                if (this.tblDetailSTO.DT.Rows.Count > 1)
                                {
                                    int num = 0;
                                    while (true)
                                    {
                                        if (num >= this.tblDetailSTO.DT.Rows.Count)
                                        {
                                            break;
                                        }
                                        if (!this.DO_query_source.ContainsKey(this.tblDetailSTO.DT.Rows[num]["Do_No"].ToString()))
                                        {
                                            this.DO_query_source.Add(this.tblDetailSTO.DT.Rows[num]["Do_No"].ToString(), "1");
                                        }
                                        num++;
                                    }
                                }
                            }
                            foreach (DataRow row2 in this.tblContract.DT.Rows)
                            {
                                if (((row2["closed"].ToString() != "X") || string.IsNullOrEmpty(row2["closed"].ToString())) ? ((row2["deleted"].ToString() != "Y") || string.IsNullOrEmpty(row2["deleted"].ToString())) : false)
                                {
                                    string[] textArray2 = new string[] { "select \r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Do_No\r\n                            ELSE a.Do_No\r\n                        END as Do_No,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Coy\r\n                            ELSE a.Coy\r\n                        END as Coy,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Location_Code\r\n                            ELSE a.Location_Code\r\n                        END as Location_Code,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Tracking_No\r\n                            ELSE a.Tracking_No\r\n                        END as Tracking_No,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Tracking_Item\r\n                            ELSE a.Tracking_Item\r\n                        END as Tracking_Item,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.STO\r\n                            ELSE (case when a.sto = '' then a.PO else a.sto end)\r\n                        END as STO,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.STO_Item\r\n                            ELSE (case when a.sto_item = '' then a.PO_item else a.sto_item end)\r\n                        END as STO_Item,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Comm_Code\r\n                            ELSE a.Comm_Code\r\n                        END as Comm_Code,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Comm_Name\r\n                            ELSE a.Comm_Name\r\n                        END as Comm_Name,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.STO_Qty\r\n                            ELSE a.STO_Qty\r\n                        END as STO_Qty,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.STO_UoM\r\n                            ELSE a.STO_UoM\r\n                        END as STO_UoM,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.tolerance\r\n                            ELSE a.tolerance\r\n                        END as tolerance,\r\n                        CASE\r\n                            WHEN b.uniq is not null THEN b.Require_BC\r\n                            ELSE a.Require_BC\r\n                        END as Require_BC,\r\n                        b.uniq as contract_detail_STO_uniq\r\n                        from (select xct.*, xcom.Comm_Name from wb_contract xct left join wb_commodity xcom on xct.Coy = xcom.Coy and xct.Location_Code = xcom.Location_Code and xct.Comm_Code = xcom.comm_code) a\r\n                        left\r\n                        join (select xcts.*, xcom.Comm_Name from wb_contract_detail_STO xcts left join wb_commodity xcom on xcts.Coy = xcom.Coy and xcts.Location_Code = xcom.Location_Code and xcts.Comm_Code = xcom.comm_code) b\r\n                        on a.Coy = b.Coy and a.Location_Code = b.Location_Code and a.Do_No = b.Do_No where \r\n                        a.Coy = '", WBData.sCoyCode, "' AND a.Location_Code = '", WBData.sLocCode, "' AND a.Do_No = '", row2["Do_No"].ToString(), "' AND ((a.STO_OS_Closed is null or a.STO_OS_Closed <> 'Y') and (b.STO_OS_Closed is null or b.STO_OS_Closed <> 'Y'))" };
                                    this.tblDetailSTO.OpenTable("wb_contract_detail_STO", string.Concat(textArray2), WBData.conn);
                                    if (this.tblDetailSTO.DT.Rows.Count > 0)
                                    {
                                        this.DT_DetailSTO.Merge(this.tblDetailSTO.DT.Copy());
                                    }
                                }
                            }
                            foreach (DataRow row3 in this.tblContract.DT.Rows)
                            {
                                if (this.DO_query_source[row3["Do_No"].ToString()] == "0")
                                {
                                    string[] textArray3 = new string[] { "select a.Do_No, case when a.sto = '' then a.po else a.sto end as STO, case when a.STO_Item = '' then a.po_item else a.STO_Item end as STO_Item, a.STO_Qty, b.*  from (select * from wb_contract) as a\r\n                                left join (select * from wb_contract_detail_BC\r\n                                where Uniq In \r\n                                (select max(uniq)from wb_contract_detail_BC\r\n                                group by Coy, Location_Code, BC_No, BC_Item, BC_Exp_Date, BC_Qty, BC_UoM, Tracking_No, Tracking_Item, do_no, bc_date)) as b\r\n                                on a.Coy = b.Coy and a.Location_Code = b.Location_Code and a.Do_No = b.Do_No\r\n                                where a.Coy = '", WBData.sCoyCode, "' and a.Location_Code = '", WBData.sLocCode, "' and a.Do_No = '", row3["Do_No"].ToString(), "' and (b.uniq is not null and b.uniq != '') order by sto asc, STO_Item asc" };
                                    sqltext = string.Concat(textArray3);
                                }
                                else if (this.DO_query_source[row3["Do_No"].ToString()] == "1")
                                {
                                    string str2 = "";
                                    if (this.tblDetailSTO.DT.Rows.Count <= 0)
                                    {
                                        string[] textArray5 = new string[9];
                                        textArray5[0] = "select a.Do_No, a.STO, a.STO_Item, a.STO_Qty, b.*  from (select * from wb_contract_detail_STO) as a\r\n                                left join (select * from wb_contract_detail_BC\r\n                                where Uniq In \r\n                                (select max(uniq)from wb_contract_detail_BC\r\n                                group by Coy, Location_Code, BC_No, BC_Item, BC_Exp_Date, BC_Qty, BC_UoM, Tracking_No, Tracking_Item, do_no, bc_date)) as b\r\n                                on a.Coy = b.Coy and a.Location_Code = b.Location_Code and a.Do_No = b.Do_No ";
                                        textArray5[1] = str2;
                                        textArray5[2] = " where a.Coy = '";
                                        textArray5[3] = WBData.sCoyCode;
                                        textArray5[4] = "' and a.Location_Code = '";
                                        textArray5[5] = WBData.sLocCode;
                                        textArray5[6] = "' and a.Do_No = '";
                                        textArray5[7] = row3["Do_No"].ToString();
                                        textArray5[8] = "'  and (b.uniq is not null and b.uniq != '') order by sto asc, STO_Item asc";
                                        sqltext = string.Concat(textArray5);
                                    }
                                    else
                                    {
                                        str2 = ((this.tblDetailSTO.DT.Rows[0]["Tracking_No"].ToString() != "") && (this.tblDetailSTO.DT.Rows[0]["Tracking_No"] != null)) ? " and a.tracking_no = b.tracking_no and a.tracking_item = b.tracking_item" : " and a.sto = b.tracking_no and a.sto_item = b.tracking_item ";
                                        string[] textArray4 = new string[9];
                                        textArray4[0] = "select a.Do_No, a.STO, a.STO_Item, a.STO_Qty, b.*  from (select * from wb_contract_detail_STO) as a\r\n                                left join (select * from wb_contract_detail_BC\r\n                                where Uniq In \r\n                                (select max(uniq)from wb_contract_detail_BC\r\n                                group by Coy, Location_Code, BC_No, BC_Item, BC_Exp_Date, BC_Qty, BC_UoM, Tracking_No, Tracking_Item, do_no, bc_date)) as b\r\n                                on a.Coy = b.Coy and a.Location_Code = b.Location_Code and a.Do_No = b.Do_No ";
                                        textArray4[1] = str2;
                                        textArray4[2] = " where a.Coy = '";
                                        textArray4[3] = WBData.sCoyCode;
                                        textArray4[4] = "' and a.Location_Code = '";
                                        textArray4[5] = WBData.sLocCode;
                                        textArray4[6] = "' and a.Do_No = '";
                                        textArray4[7] = row3["Do_No"].ToString();
                                        textArray4[8] = "'  and (b.uniq is not null and b.uniq != '') order by sto asc, STO_Item asc";
                                        sqltext = string.Concat(textArray4);
                                    }
                                }
                                this.tblDetailBC.OpenTable("wb_contract_detail_BC", sqltext, WBData.conn);
                                if ((this.tblDetailBC.DT.Rows.Count > 0) && !string.IsNullOrEmpty(this.tblDetailBC.DT.Rows[0]["uniq"].ToString()))
                                {
                                    this.DT_DetailBC.Merge(this.tblDetailBC.DT.Copy());
                                }
                            }
                            this.load_dgv();
                        }
                    }
                }
            }
        }

        private void filter(bool filter_mode, string keyword)
        {
            this.selected_row = -1;
            this.btnDuplicateRow.Enabled = false;
            this.btnDeleteRow.Enabled = false;
            bool flag = true;
            bool flag2 = false;
            for (int i = 0; i < this.dgvDO.Rows.Count; i++)
            {
                flag = false;
                this.dgvDO.Rows[i].Visible = true;
                if ((this.dgvDO.Rows[i].Cells["Deleted"].Value != null) && (this.dgvDO.Rows[i].Cells["Deleted"].Value.ToString() == "D"))
                {
                    flag = false;
                }
                else
                {
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 < this.dgvDO.Rows[i].Cells.Count)
                        {
                            bool flag4 = this.dgvDO.Rows[i].Cells[num2].Value != null;
                            if (!flag4 || !(string.IsNullOrEmpty(keyword) || (this.dgvDO.Rows[i].Cells[num2].Visible && (this.dgvDO.Rows[i].Cells[num2].Value.ToString().Trim().ToLower().IndexOf(keyword) > -1))))
                            {
                                num2++;
                                continue;
                            }
                            flag = true;
                        }
                        break;
                    }
                }
                if (flag)
                {
                    if ((this.dgvDO.Rows[i].Cells["Deleted"].Value != null) && (this.dgvDO.Rows[i].Cells["Deleted"].Value.ToString() != "D"))
                    {
                        this.dgvDO.Rows[i].Visible = true;
                        if (!flag2)
                        {
                            this.dgvDO.ClearSelection();
                            this.dgvDO.CurrentCell = this.dgvDO.Rows[i].Cells[5];
                            this.dgvDO.Rows[i].Selected = true;
                            this.dgvDO.FirstDisplayedScrollingRowIndex = i;
                            flag2 = true;
                            this.selected_row = i;
                            this.btnDuplicateRow.Enabled = true;
                            this.btnDeleteRow.Enabled = true;
                        }
                    }
                }
                else if (!filter_mode)
                {
                    this.dgvDO.Rows[i].Visible = (this.dgvDO.Rows[i].Cells["Deleted"].Value == null) || (this.dgvDO.Rows[i].Cells["Deleted"].Value.ToString() != "D");
                }
                else if (!string.IsNullOrEmpty(keyword))
                {
                    this.dgvDO.Rows[i].Visible = false;
                }
                else if ((this.dgvDO.Rows[i].Cells["Deleted"].Value != null) && (this.dgvDO.Rows[i].Cells["Deleted"].Value.ToString() != "D"))
                {
                    this.dgvDO.Rows[i].Visible = true;
                }
            }
        }

        private void FormSparepartInfo_Load(object sender, EventArgs e)
        {
            this.f_load();
            this.append_data_to_dgv();
            if (this.dgvDO.Rows.Count > 0)
            {
                this.dgvDO.Sort(this.dgvDO.Columns["STO_Item"], ListSortDirection.Ascending);
            }
            this.dgvDO.ClearSelection();
            this.translate();
        }

        private List<string> getDistinctBCItem(string DO_No, string STO_No, string STO_Item, string BC_No, bool show_closed)
        {
            List<string> list = new List<string>();
            bool flag = true;
            foreach (DataRow row in this.DT_DetailBC.Rows)
            {
                if ((((row["DO_No"].ToString() == DO_No) && (row["STO"].ToString() == STO_No)) && (row["STO_Item"].ToString() == STO_Item)) && ((row["BC_No"].ToString() == BC_No) && !list.Contains(row["BC_Item"].ToString())))
                {
                    if (show_closed)
                    {
                        list.Add(row["BC_Item"].ToString());
                        continue;
                    }
                    if (!show_closed && (row["BC_OS_Closed"].ToString().ToUpper() != "Y"))
                    {
                        if (flag)
                        {
                            list.Add("");
                            flag = false;
                        }
                        list.Add(row["BC_Item"].ToString());
                    }
                }
            }
            return list;
        }

        private List<string> getDistinctBCNo(string DO_No, string STO_No, string STO_Item, bool show_closed)
        {
            List<string> list = new List<string>();
            bool flag = true;
            foreach (DataRow row in this.DT_DetailBC.Rows)
            {
                if ((((row["DO_No"].ToString() == DO_No) && (row["STO"].ToString() == STO_No)) && (row["STO_Item"].ToString() == STO_Item)) && !list.Contains(row["BC_No"].ToString()))
                {
                    if (show_closed)
                    {
                        list.Add(row["BC_No"].ToString());
                        continue;
                    }
                    if (!show_closed && (row["BC_OS_Closed"].ToString().ToUpper() != "Y"))
                    {
                        if (this.DT_DetailBC.Rows.Count <= 1)
                        {
                            list.Add(row["BC_No"].ToString());
                            continue;
                        }
                        if (flag)
                        {
                            list.Add("");
                            flag = false;
                        }
                        list.Add(row["BC_No"].ToString());
                    }
                }
            }
            return list;
        }

        private string getRefTransDO(string do_no)
        {
            string str = "";
            foreach (DataRow row in this.tblTransDO.DT.Rows)
            {
                if (row["DO_no"].ToString() == do_no)
                {
                    str = row["ref"].ToString();
                    break;
                }
            }
            return str;
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.txtRefNo = new TextBox();
            this.lblVehicle = new Label();
            this.txtVehicle = new TextBox();
            this.lblRef = new Label();
            this.dgvDO = new DataGridView();
            this.btnSave = new Button();
            this.btnCancel = new Button();
            this.statusStrip1 = new StatusStrip();
            this.toolTipInformation = new ToolTip(this.components);
            this.labelTableSTO = new Label();
            this.textRef_Date = new TextBox();
            this.label35 = new Label();
            this.label3 = new Label();
            this.textDriverID = new TextBox();
            this.labelDriverName = new Label();
            this.textReport_Date = new TextBox();
            this.label37 = new Label();
            this.btnFilter = new Button();
            this.txtFilterKeyword = new TextBox();
            this.chkBoxFilter = new CheckBox();
            this.btnDeleteRow = new Button();
            this.btnDuplicateRow = new Button();
            ((ISupportInitialize) this.dgvDO).BeginInit();
            base.SuspendLayout();
            this.txtRefNo.BackColor = SystemColors.Control;
            this.txtRefNo.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.txtRefNo.Location = new Point(0x61, 12);
            this.txtRefNo.MaxLength = 0x10;
            this.txtRefNo.Name = "txtRefNo";
            this.txtRefNo.ReadOnly = true;
            this.txtRefNo.Size = new Size(0xc1, 0x1a);
            this.txtRefNo.TabIndex = 0x65;
            this.lblVehicle.AutoSize = true;
            this.lblVehicle.Location = new Point(9, 100);
            this.lblVehicle.Name = "lblVehicle";
            this.lblVehicle.Size = new Size(0x3e, 13);
            this.lblVehicle.TabIndex = 0x68;
            this.lblVehicle.Text = "Vehicle No.";
            this.txtVehicle.BackColor = SystemColors.Control;
            this.txtVehicle.CharacterCasing = CharacterCasing.Upper;
            this.txtVehicle.Enabled = false;
            this.txtVehicle.Location = new Point(0x61, 0x62);
            this.txtVehicle.MaxLength = 20;
            this.txtVehicle.Name = "txtVehicle";
            this.txtVehicle.Size = new Size(0x7b, 20);
            this.txtVehicle.TabIndex = 0x66;
            this.lblRef.AutoSize = true;
            this.lblRef.Location = new Point(9, 20);
            this.lblRef.Name = "lblRef";
            this.lblRef.Size = new Size(0x2c, 13);
            this.lblRef.TabIndex = 0x69;
            this.lblRef.Text = "Ref No.";
            this.dgvDO.AllowUserToAddRows = false;
            this.dgvDO.AllowUserToDeleteRows = false;
            this.dgvDO.AllowUserToResizeRows = false;
            this.dgvDO.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDO.EditMode = DataGridViewEditMode.EditOnEnter;
            this.dgvDO.Location = new Point(0, 0x108);
            this.dgvDO.MultiSelect = false;
            this.dgvDO.Name = "dgvDO";
            this.dgvDO.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDO.Size = new Size(0x368, 0xa3);
            this.dgvDO.TabIndex = 0x6d;
            this.dgvDO.CellClick += new DataGridViewCellEventHandler(this.dgvDO_CellClick);
            this.dgvDO.CellValidating += new DataGridViewCellValidatingEventHandler(this.dgvDO_CellValidating);
            this.dgvDO.CellValueChanged += new DataGridViewCellEventHandler(this.dgvDO_CellValueChanged);
            this.dgvDO.CurrentCellDirtyStateChanged += new EventHandler(this.dgvDO_CurrentCellDirtyStateChanged);
            this.dgvDO.DataError += new DataGridViewDataErrorEventHandler(this.dgvDO_DataError);
            this.btnSave.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.btnSave.Location = new Point(0x291, 0xa9);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new Size(0x5f, 0x38);
            this.btnSave.TabIndex = 110;
            this.btnSave.Text = "&SAVE";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new EventHandler(this.btnSave_Click);
            this.btnCancel.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.btnCancel.Location = new Point(0x2fd, 0xa9);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(0x5f, 0x38);
            this.btnCancel.TabIndex = 0x6f;
            this.btnCancel.Text = "&CANCEL";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);
            this.statusStrip1.ImageScalingSize = new Size(20, 20);
            this.statusStrip1.Location = new Point(0, 0x1da);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(0x368, 0x16);
            this.statusStrip1.TabIndex = 0x70;
            this.statusStrip1.Text = "statusStrip1";
            this.labelTableSTO.BackColor = SystemColors.ActiveCaption;
            this.labelTableSTO.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelTableSTO.Location = new Point(0, 0xec);
            this.labelTableSTO.Name = "labelTableSTO";
            this.labelTableSTO.Size = new Size(0x368, 0x1c);
            this.labelTableSTO.TabIndex = 0x71;
            this.labelTableSTO.Text = "PO/STO Table";
            this.labelTableSTO.TextAlign = ContentAlignment.MiddleCenter;
            this.textRef_Date.BackColor = SystemColors.Control;
            this.textRef_Date.Location = new Point(0x61, 0x2e);
            this.textRef_Date.Name = "textRef_Date";
            this.textRef_Date.ReadOnly = true;
            this.textRef_Date.Size = new Size(0x66, 20);
            this.textRef_Date.TabIndex = 0x75;
            this.textRef_Date.Text = "08/08/2013";
            this.label35.AutoSize = true;
            this.label35.Location = new Point(9, 0x31);
            this.label35.Name = "label35";
            this.label35.Size = new Size(50, 13);
            this.label35.TabIndex = 0x76;
            this.label35.Text = "Ref Date";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(9, 0x7f);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x31, 13);
            this.label3.TabIndex = 0x79;
            this.label3.Text = "Driver ID";
            this.textDriverID.CharacterCasing = CharacterCasing.Upper;
            this.textDriverID.Location = new Point(0x61, 0x7c);
            this.textDriverID.MaxLength = 50;
            this.textDriverID.Name = "textDriverID";
            this.textDriverID.ReadOnly = true;
            this.textDriverID.Size = new Size(0x7b, 20);
            this.textDriverID.TabIndex = 0x77;
            this.labelDriverName.AutoSize = true;
            this.labelDriverName.Location = new Point(0xe2, 0x7f);
            this.labelDriverName.Name = "labelDriverName";
            this.labelDriverName.Size = new Size(0x3f, 13);
            this.labelDriverName.TabIndex = 0x7a;
            this.labelDriverName.Text = "DriverName";
            this.textReport_Date.BackColor = SystemColors.Control;
            this.textReport_Date.Location = new Point(0x61, 0x48);
            this.textReport_Date.MaxLength = 10;
            this.textReport_Date.Name = "textReport_Date";
            this.textReport_Date.ReadOnly = true;
            this.textReport_Date.Size = new Size(0x66, 20);
            this.textReport_Date.TabIndex = 0x7e;
            this.label37.AutoSize = true;
            this.label37.Location = new Point(9, 0x4b);
            this.label37.Name = "label37";
            this.label37.Size = new Size(0x41, 13);
            this.label37.TabIndex = 0x7f;
            this.label37.Text = "Report Date";
            this.btnFilter.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.btnFilter.Location = new Point(0xe4, 0xb2);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new Size(0x5f, 0x2f);
            this.btnFilter.TabIndex = 0x80;
            this.btnFilter.Text = "&FIND";
            this.btnFilter.UseVisualStyleBackColor = true;
            this.btnFilter.Click += new EventHandler(this.btnFilter_Click);
            this.txtFilterKeyword.BackColor = SystemColors.Window;
            this.txtFilterKeyword.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.txtFilterKeyword.Location = new Point(11, 0xb2);
            this.txtFilterKeyword.MaxLength = 0x10;
            this.txtFilterKeyword.Name = "txtFilterKeyword";
            this.txtFilterKeyword.Size = new Size(0xd1, 0x1a);
            this.txtFilterKeyword.TabIndex = 0x81;
            this.txtFilterKeyword.KeyPress += new KeyPressEventHandler(this.txtFilterKeyword_KeyPress);
            this.chkBoxFilter.AutoSize = true;
            this.chkBoxFilter.Location = new Point(11, 0xd0);
            this.chkBoxFilter.Margin = new Padding(2, 2, 2, 2);
            this.chkBoxFilter.Name = "chkBoxFilter";
            this.chkBoxFilter.Size = new Size(0x62, 0x11);
            this.chkBoxFilter.TabIndex = 130;
            this.chkBoxFilter.Text = "Enable Filtering";
            this.chkBoxFilter.UseVisualStyleBackColor = true;
            this.btnDeleteRow.Enabled = false;
            this.btnDeleteRow.Font = new Font("Microsoft Sans Serif", 7.8f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btnDeleteRow.Location = new Point(0x2fd, 0x1b4);
            this.btnDeleteRow.Name = "btnDeleteRow";
            this.btnDeleteRow.Size = new Size(0x5f, 0x23);
            this.btnDeleteRow.TabIndex = 0x83;
            this.btnDeleteRow.Text = "Delete";
            this.btnDeleteRow.UseVisualStyleBackColor = true;
            this.btnDeleteRow.Click += new EventHandler(this.btnDeleteRow_Click);
            this.btnDuplicateRow.Enabled = false;
            this.btnDuplicateRow.Font = new Font("Microsoft Sans Serif", 7.8f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btnDuplicateRow.Location = new Point(0x291, 0x1b4);
            this.btnDuplicateRow.Name = "btnDuplicateRow";
            this.btnDuplicateRow.Size = new Size(0x5f, 0x23);
            this.btnDuplicateRow.TabIndex = 0x84;
            this.btnDuplicateRow.Text = "Duplicate";
            this.btnDuplicateRow.UseVisualStyleBackColor = true;
            this.btnDuplicateRow.Click += new EventHandler(this.btnDuplicateRow_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x368, 0x1f0);
            base.ControlBox = false;
            base.Controls.Add(this.btnDuplicateRow);
            base.Controls.Add(this.btnDeleteRow);
            base.Controls.Add(this.chkBoxFilter);
            base.Controls.Add(this.txtFilterKeyword);
            base.Controls.Add(this.btnFilter);
            base.Controls.Add(this.textReport_Date);
            base.Controls.Add(this.label37);
            base.Controls.Add(this.labelDriverName);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textDriverID);
            base.Controls.Add(this.textRef_Date);
            base.Controls.Add(this.label35);
            base.Controls.Add(this.labelTableSTO);
            base.Controls.Add(this.dgvDO);
            base.Controls.Add(this.statusStrip1);
            base.Controls.Add(this.btnCancel);
            base.Controls.Add(this.btnSave);
            base.Controls.Add(this.lblRef);
            base.Controls.Add(this.lblVehicle);
            base.Controls.Add(this.txtVehicle);
            base.Controls.Add(this.txtRefNo);
            base.FormBorderStyle = FormBorderStyle.FixedDialog;
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormSparepartInfo";
            base.ShowIcon = false;
            base.SizeGripStyle = SizeGripStyle.Hide;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Sparepart Info";
            base.Load += new EventHandler(this.FormSparepartInfo_Load);
            ((ISupportInitialize) this.dgvDO).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void load_dgv()
        {
            this.dgvDO.ColumnCount = this.tblDetailSTO.DT.Columns.Count;
            int num = 0;
            while (true)
            {
                if (num >= this.tblDetailSTO.DT.Columns.Count)
                {
                    this.dgvDO.Columns["STO"].Visible = true;
                    this.dgvDO.Columns["STO_Item"].Visible = true;
                    this.dgvDO.Columns["Tolerance"].Visible = true;
                    this.dgvDO.Columns["Comm_Code"].Visible = true;
                    this.dgvDO.Columns["Comm_Name"].Visible = true;
                    this.dgvDO.Columns["STO_Qty"].Visible = true;
                    this.dgvDO.Columns["STO_UoM"].Visible = true;
                    this.dgvDO.Columns["Require_BC"].Visible = true;
                    DataGridViewComboBoxColumn column = new DataGridViewComboBoxColumn {
                        DataSource = this.List_BC_No,
                        HeaderText = Resource.Lbl_No_BC,
                        DataPropertyName = "BC_No"
                    };
                    DataGridViewColumn[] dataGridViewColumns = new DataGridViewColumn[] { column };
                    this.dgvDO.Columns.AddRange(dataGridViewColumns);
                    DataGridViewComboBoxColumn column2 = new DataGridViewComboBoxColumn {
                        DataSource = new List<string>(),
                        HeaderText = Resource.Col_BC_Item,
                        DataPropertyName = "BC_Item"
                    };
                    DataGridViewColumn[] columnArray2 = new DataGridViewColumn[] { column2 };
                    this.dgvDO.Columns.AddRange(columnArray2);
                    this.dgvDO.Columns.Add("BC_Type", Resource.Col_BC_Type);
                    this.dgvDO.Columns["BC_Type"].ReadOnly = true;
                    this.dgvDO.Columns["BC_Type"].DefaultCellStyle.BackColor = Color.LightGray;
                    this.dgvDO.Columns.Add("BC_Date", Resource.Lbl_BC_Date);
                    this.dgvDO.Columns["BC_Date"].ReadOnly = true;
                    this.dgvDO.Columns["BC_Date"].DefaultCellStyle.BackColor = Color.LightGray;
                    this.dgvDO.Columns.Add("BC_Exp_Date", Resource.Lbl_BC_Exp_Date);
                    this.dgvDO.Columns["BC_Exp_Date"].ReadOnly = true;
                    this.dgvDO.Columns["BC_Exp_Date"].DefaultCellStyle.BackColor = Color.LightGray;
                    this.dgvDO.Columns.Add("BC_Qty", Resource.Lbl_BC_Quantity);
                    this.dgvDO.Columns["BC_Qty"].ReadOnly = true;
                    this.dgvDO.Columns["BC_Qty"].DefaultCellStyle.BackColor = Color.LightGray;
                    this.dgvDO.Columns.Add("Item_Load_Qty", "Sparepart Qty");
                    this.dgvDO.Columns["Item_Load_Qty"].ReadOnly = false;
                    this.dgvDO.Columns["Item_Load_Qty"].DefaultCellStyle.BackColor = Color.White;
                    this.dgvDO.Columns.Add("BC_UoM", Resource.Col_BC_UoM);
                    this.dgvDO.Columns["BC_UoM"].ReadOnly = true;
                    this.dgvDO.Columns["BC_UoM"].DefaultCellStyle.BackColor = Color.LightGray;
                    this.dgvDO.Columns.Add("Deleted", "Deleted");
                    this.dgvDO.Columns["Deleted"].ReadOnly = true;
                    this.dgvDO.Columns["Deleted"].DefaultCellStyle.BackColor = Color.LightGray;
                    this.dgvDO.Columns["Deleted"].Visible = false;
                    this.dgvDO.Columns.Add("transBC_uniq", "transBC_uniq");
                    this.dgvDO.Columns["transBC_uniq"].ReadOnly = true;
                    this.dgvDO.Columns["transBC_uniq"].DefaultCellStyle.BackColor = Color.LightGray;
                    this.dgvDO.Columns["transBC_uniq"].Visible = false;
                    this.dgvDO = this.ToDGV(this.DT_DetailSTO, this.dgvDO);
                    this.dgvDO.Columns["STO"].HeaderText = "PO/STO";
                    this.dgvDO.Columns["STO_Item"].HeaderText = "PO/STO Item";
                    this.dgvDO.Columns["Comm_Code"].HeaderText = Resource.Lbl_Comm_Code;
                    this.dgvDO.Columns["Comm_Name"].HeaderText = Resource.Lbl_Comm_Name;
                    this.dgvDO.Columns["STO_Qty"].HeaderText = Resource.Lbl_STO_Quantity;
                    this.dgvDO.Columns["STO_UoM"].HeaderText = Resource.Lbl_STO_UoM;
                    this.dgvDO.Columns["Require_BC"].HeaderText = Resource.Lbl_Require_BC;
                    this.dgvDO.Columns["STO"].DisplayIndex = 0;
                    this.dgvDO.Columns["STO_Item"].DisplayIndex = 1;
                    this.dgvDO.Columns["Comm_Code"].DisplayIndex = 2;
                    this.dgvDO.Columns["Comm_Name"].DisplayIndex = 3;
                    this.dgvDO.Columns["STO_Qty"].DisplayIndex = 4;
                    this.dgvDO.Columns["STO_UoM"].DisplayIndex = 5;
                    this.dgvDO.Columns["Tolerance"].DisplayIndex = 6;
                    this.dgvDO.Columns["Require_BC"].DisplayIndex = 7;
                    this.dgvDO.Columns[this.BC_NO_INDEX].DisplayIndex = 8;
                    this.dgvDO.Columns[this.BC_ITEM_INDEX].DisplayIndex = 9;
                    this.dgvDO.Columns["BC_Type"].DisplayIndex = 10;
                    this.dgvDO.Columns["BC_Date"].DisplayIndex = 11;
                    this.dgvDO.Columns["BC_Exp_Date"].DisplayIndex = 12;
                    this.dgvDO.Columns["BC_Qty"].DisplayIndex = 13;
                    this.dgvDO.Columns["Item_Load_Qty"].DisplayIndex = 14;
                    this.dgvDO.Columns["BC_UoM"].DisplayIndex = 15;
                    foreach (DataGridViewColumn column3 in this.dgvDO.Columns)
                    {
                        column3.SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                    for (int i = 0; i < this.dgvDO.Rows.Count; i++)
                    {
                        DataGridViewComboBoxCell cell = (DataGridViewComboBoxCell) this.dgvDO.Rows[i].Cells[this.BC_NO_INDEX];
                        List<string> list3 = this.getDistinctBCNo(this.dgvDO.Rows[i].Cells["DO_No"].Value.ToString(), this.dgvDO.Rows[i].Cells["STO"].Value.ToString(), this.dgvDO.Rows[i].Cells["STO_Item"].Value.ToString(), false);
                        cell.DataSource = list3;
                        this.dgvDO.Rows[i].Cells[this.ITEM_LOAD_QTY_INDEX].Value = "0";
                    }
                    return;
                }
                this.dgvDO.Columns[num].Name = this.tblDetailSTO.DT.Columns[num].ColumnName;
                this.dgvDO.Columns[num].ReadOnly = true;
                this.dgvDO.Columns[num].DefaultCellStyle.BackColor = Color.LightGray;
                this.dgvDO.Columns[num].Visible = false;
                num++;
            }
        }

        public DataGridView ToDGV(DataTable DT, DataGridView pDGV)
        {
            foreach (DataRow row in DT.Rows)
            {
                int count = pDGV.Rows.Count;
                pDGV.Rows.Add();
                int num2 = 0;
                while (true)
                {
                    if (num2 >= DT.Columns.Count)
                    {
                        break;
                    }
                    pDGV.Rows[count].Cells[num2].Value = row[num2];
                    num2++;
                }
            }
            return pDGV;
        }

        private void translate()
        {
            this.btnFilter.Text = "&" + Resource.Lbl_Btn_Find.ToUpper();
            this.btnSave.Text = Resource.Btn_Save.ToUpper();
            this.btnCancel.Text = Resource.Btn_Cancel.ToUpper();
            this.btnDeleteRow.Text = "&" + Resource.Lbl_Btn_Delete;
            this.btnDuplicateRow.Text = "&" + Resource.Lbl_Btn_Duplicate;
            this.chkBoxFilter.Text = Resource.Lbl_Chk_Enable_Filtering;
            this.labelTableSTO.Text = Resource.Lbl_Table_STO;
            this.lblRef.Text = Resource.Lbl_Ref_No_02;
            this.label35.Text = Resource.Lbl_Ref_Date;
            this.lblVehicle.Text = Resource.Lbl_Vehicle_No;
            this.label3.Text = Resource.Lbl_Driver_ID;
        }

        private void txtFilterKeyword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.btnFilter.PerformClick();
            }
        }
    }
}

