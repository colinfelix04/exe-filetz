﻿namespace WindowsFormsApplication1
{
    using Encryption.Utility;
    using SAP.Middleware.Connector;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Diagnostics;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormUploadZWB : Form
    {
        private DateTime uploadstart;
        private DateTime uploadFinish;
        private DateTime UpdateStart;
        private DateTime UpdateFinish;
        private DataTable tblTrans = new DataTable();
        private DataTable tblTransD = new DataTable();
        private DataTable tblTransC = new DataTable();
        private DataTable tblTransQC = new DataTable();
        private DataTable tblTransBC = new DataTable();
        private DataTable tblTransW = new DataTable();
        private DataTable tblField = new DataTable();
        private DataTable retTable = new DataTable();
        private ExpressionVariabel owner = new ExpressionVariabel();
        private string[] retValue = new string[3];
        private string sapFunc;
        private string sapTable;
        private string sapReturn;
        private string sapType;
        private string zwbRef;
        private string zwbRefDo;
        public string tipeTrans = "";
        public string comm = "";
        public string Do_No = "";
        public string sapDest = "";
        public string transpt = "";
        public string logKey = "";
        public string refNo = "";
        public string module;
        public string type;
        public string sqlText;
        public string date1;
        public string date2;
        public DateTime dateFrom;
        public DateTime dateTo;
        private int rCount;
        private int jlhkolom;
        private int countRef = 0;
        public bool showAll;
        public bool locked = false;
        public bool cTrans = false;
        public char auto = 'N';
        private string estateDiff = "N";
        private string adopt = "N";
        private int count_trans_w_template = 0;
        public double pendingTrx = 0.0;
        public double uploadtrx = 0.0;
        private WBTable tbl_transaction = new WBTable();
        private WBTable tbl_Gatepass = new WBTable();
        private WBTable tbl_templateTrans = new WBTable();
        private WBTable tbl_templateTransD = new WBTable();
        private WBTable tbl_templateTransQC = new WBTable();
        private WBTable tbl_templateTransC = new WBTable();
        private WBTable tbl_templateTransW_1 = new WBTable();
        private WBTable tbl_templateTransW_2 = new WBTable();
        private WBTable tbl_templateTransW_3 = new WBTable();
        private WBTable tbl_templateTransBC = new WBTable();
        private string zwbIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB");
        private WBTable aTable = new WBTable();
        private WBTable bTable = new WBTable();
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private int QCCount = 0;
        private int BCCount = 0;
        private Dictionary<string, object> dataUploadIDSYS;
        private IContainer components = null;
        private MenuStrip menuStrip1;
        public ToolStripMenuItem mnUpd;
        private ToolStripMenuItem excelToolStripMenuItem;
        private ToolStripMenuItem repostMutuToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private Panel panel1;
        private Panel panel2;
        private DataGridView dgTrans;
        private Button buttonUnSelect;
        private Button buttonSelectAll;
        private Label labelTotalRecord3;
        private Label labelTotalRecord2;
        private Label labelTotalRecord;
        private ProgressBar prgBar;
        private DataGridView dgTransC;
        private DataGridView dgTransQC;
        private DataGridView dgTransD;
        private DataGridView dgTransFlag;
        private Panel panelDetail;
        private Panel panel6;
        private Panel panel5;
        private Panel panel4;
        private DataGridView dgTransW;
        private Panel panel4X;
        private ToolStripMenuItem helpToolStripMenuItem;
        private Label labelMulesoftData;
        private Label labelMulesoft4;
        private Label labelMulesoftCycle;
        private Label labelMulesoft3;
        private Label labelMulesoft1;
        private GroupBox panelMulesoft;
        private Label labelMulesoft5;
        private DataGridView dgTransBC;

        public FormUploadZWB()
        {
            this.InitializeComponent();
        }

        private string AddToList(DataTable dtData)
        {
            List<string> list = new List<string>();
            List<string> list2 = new List<string>();
            foreach (DataRow row in dtData.Rows)
            {
                foreach (DataColumn column in dtData.Columns)
                {
                    if (column.ColumnName == "WREF")
                    {
                        list.Add("WBREF_NO:'" + row[column].ToString() + "'");
                        continue;
                    }
                    list.Add(column.ColumnName + ":'" + row[column].ToString() + "'");
                }
                list2.Add("{" + string.Join(",", list.ToArray()) + "}");
            }
            return string.Join(",", list2.ToArray());
        }

        public void btnUpload()
        {
            bool flag = false;
            foreach (DataGridViewRow row in (IEnumerable) this.dgTrans.Rows)
            {
                if (this.auto == 'Y')
                {
                    row.Cells["select"].Value = true;
                }
                if (Convert.ToBoolean(row.Cells["select"].Value))
                {
                    flag = true;
                    break;
                }
            }
            if (!flag && (this.auto != 'Y'))
            {
                MessageBox.Show("Please select record to be uploaded!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            if (flag)
            {
                if (WBSetting.integrationIDSYS)
                {
                    this.uploadIDSYS();
                }
                else
                {
                    this.uploadZWB();
                    WBSAP.SyncCommTrx();
                }
            }
        }

        private void buttonSelectAll_Click(object sender, EventArgs e)
        {
            this.selectAll();
        }

        private void buttonUnSelect_Click(object sender, EventArgs e)
        {
            if (this.dgTrans.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgTrans.Rows)
                {
                    row.Cells["select"].Value = true;
                    row.Cells["select"].ReadOnly = true;
                }
            }
        }

        private bool cekFlag(string pRef)
        {
            int num = 0;
            while (true)
            {
                bool flag3;
                if (num >= this.dgTransFlag.Rows.Count)
                {
                    flag3 = false;
                }
                else
                {
                    bool flag = this.dgTransFlag.Rows[num].Cells["WREF"].Value.ToString().Trim() == pRef.Trim();
                    if (!flag || (this.dgTransFlag.Rows[num].Cells["EstateDiff"].Value.ToString() != "Y"))
                    {
                        num++;
                        continue;
                    }
                    flag3 = true;
                }
                return flag3;
            }
        }

        private void chkPosted_CheckedChanged(object sender, EventArgs e)
        {
            this.tblTrans.Rows.Clear();
            this.retTable.Rows.Clear();
            this.dgTrans.Rows.Clear();
            this.dgTrans.Refresh();
        }

        public static string cutOff(string Ref)
        {
            string str2 = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_condition", "select Ref, Kode_Sap from wb_Condition where Condition_code = 'CUT_OFF_LOCATION'  and " + WBData.CompanyLocation(""), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                table.DR = table.DT.Rows[0];
                string str = table.DR["Ref"].ToString();
                WBTable table2 = new WBTable();
                string[] textArray1 = new string[] { "select * from wb_transaction where (ref > '", Ref, "' and ref <= '", str, "') and ", WBData.CompanyLocation("") };
                table2.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
                if (table2.DT.Rows.Count > 0)
                {
                    str2 = table.DR["Kode_Sap"].ToString();
                }
            }
            return str2;
        }

        private void dgTrans_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int columnIndex = this.dgTrans.CurrentCell.ColumnIndex;
            if (this.dgTrans.Columns[columnIndex].Name.ToUpper() == "SELECT".ToUpper())
            {
                this.dgTrans.CurrentCell.Value = !Convert.ToBoolean(this.dgTrans.CurrentCell.Value);
            }
        }

        private void dgTrans_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            int columnIndex = this.dgTrans.CurrentCell.ColumnIndex;
            if (this.dgTrans.Columns[columnIndex].Name.ToUpper() == "SELECT".ToUpper())
            {
                this.dgTrans.CurrentCell.Value = !Convert.ToBoolean(this.dgTrans.CurrentCell.Value);
            }
        }

        private void dgTrans_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (this.dgTrans.CurrentCell.ColumnIndex != 0)
            {
                this.ViewTimbang();
            }
        }

        private void dgTrans_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
            }
        }

        private void dgTransFlag_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dgvDetailToTable(DataGridView aDgv, DataTable mainTable, DataTable subTable, string key, string nametable)
        {
            try
            {
                subTable.Rows.Clear();
                foreach (DataRow row2 in mainTable.Rows)
                {
                    string str = row2[key].ToString();
                    foreach (DataGridViewRow row3 in (IEnumerable) aDgv.Rows)
                    {
                        if (row3.Cells[key].Value.ToString() == str)
                        {
                            DataRow row = subTable.NewRow();
                            int num = 0;
                            while (true)
                            {
                                if (num >= subTable.Columns.Count)
                                {
                                    subTable.Rows.Add(row);
                                    break;
                                }
                                row[subTable.Columns[num].ColumnName] = row3.Cells[subTable.Columns[num].ColumnName].Value;
                                num++;
                            }
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private DataTable dgvToPartialDataTable(DataGridView dgv, DataTable dt, string[] refNo)
        {
            if (dgv.Columns.Contains("WREF"))
            {
                foreach (DataGridViewColumn column in dgv.Columns)
                {
                    dt.Columns.Add(column.Name);
                }
                foreach (DataGridViewRow row in (IEnumerable) dgv.Rows)
                {
                    int index = 0;
                    while (true)
                    {
                        if (index >= refNo.Length)
                        {
                            break;
                        }
                        if (((refNo[index] != null) && (refNo[index] != "")) && row.Cells["WREF"].Value.ToString().Contains(refNo[index]))
                        {
                            DataRow row2 = dt.NewRow();
                            foreach (DataGridViewCell cell in row.Cells)
                            {
                                row2[cell.ColumnIndex] = cell.Value;
                            }
                            dt.Rows.Add(row2);
                        }
                        index++;
                    }
                }
            }
            return dt;
        }

        private void dgvToTable(DataGridView aDgv, DataTable aTable)
        {
            try
            {
                aTable.Rows.Clear();
                foreach (DataGridViewRow row2 in (IEnumerable) aDgv.Rows)
                {
                    if (Convert.ToBoolean(row2.Cells["select"].Value))
                    {
                        DataRow row = aTable.NewRow();
                        int num = 0;
                        while (true)
                        {
                            if (num >= aTable.Columns.Count)
                            {
                                aTable.Rows.Add(row);
                                break;
                            }
                            row[aTable.Columns[num].ColumnName] = row2.Cells[aTable.Columns[num].ColumnName].Value;
                            num++;
                        }
                    }
                }
            }
            catch
            {
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void excelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.dgTrans.Rows.Count > 0)
                {
                    Cursor.Current = Cursors.WaitCursor;
                    if (WBUser.UserLevel == "1")
                    {
                        Program.export2Excel(this.dgTrans, "ZWB", "I_RECORD_" + DateTime.Now.ToString("ddMMyyyy_HHmmss"), false);
                        Cursor.Current = Cursors.Default;
                        MessageBox.Show(this.dgTransD.Rows.Count + " data of I_RECORD have been extracted.", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        Program.export2Excel(this.dgTrans, "ZWB", "ZWB_" + DateTime.Now.ToString("ddMMyyyy_HHmmss"), false);
                        Cursor.Current = Cursors.Default;
                        MessageBox.Show(this.dgTrans.Rows.Count + " data have been extracted to excel successfully!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
                if (WBUser.UserLevel == "1")
                {
                    if (this.dgTransD.Rows.Count > 0)
                    {
                        Cursor.Current = Cursors.WaitCursor;
                        Program.export2Excel(this.dgTransD, "ZWB", "I_RECORD_D_" + DateTime.Now.ToString("ddMMyyyy_HHmmss"), false);
                        Cursor.Current = Cursors.Default;
                        MessageBox.Show(this.dgTransD.Rows.Count + " data of I_RECORD_D have been extracted.", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    if (this.dgTransQC.Rows.Count > 0)
                    {
                        Cursor.Current = Cursors.WaitCursor;
                        Program.export2Excel(this.dgTransQC, "ZWB", "I_RECORD_QUALITY_" + DateTime.Now.ToString("ddMMyyyy_HHmmss"), false);
                        Cursor.Current = Cursors.Default;
                        MessageBox.Show(this.dgTransQC.Rows.Count + " data of I_RECORD_QUALITY have been extracted.", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    if (this.dgTransC.Rows.Count > 0)
                    {
                        Cursor.Current = Cursors.WaitCursor;
                        Program.export2Excel(this.dgTransC, "ZWB", "I_RECORD_COPRA_" + DateTime.Now.ToString("ddMMyyyy_HHmmss"), false);
                        Cursor.Current = Cursors.Default;
                        MessageBox.Show(this.dgTransC.Rows.Count + " data of I_RECORD_COPRA have been extracted.", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    if (this.dgTransW.Rows.Count > 0)
                    {
                        Cursor.Current = Cursors.WaitCursor;
                        Program.export2Excel(this.dgTransW, "ZWB", "I_RECORD_W_" + DateTime.Now.ToString("ddMMyyyy_HHmmss"), false);
                        Cursor.Current = Cursors.Default;
                        MessageBox.Show(this.dgTransC.Rows.Count + " data of I_RECORD_W have been extracted.", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    if (this.dgTransBC.Rows.Count > 0)
                    {
                        Cursor.Current = Cursors.WaitCursor;
                        Program.export2Excel(this.dgTransBC, "ZWB", "I_RECORD_BC_" + DateTime.Now.ToString("ddMMyyyy_HHmmss"), false);
                        Cursor.Current = Cursors.Default;
                        MessageBox.Show(this.dgTransBC.Rows.Count + " data of I_RECORD_BC have been extracted.", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    this.get_important_field();
                    if (this.tblField.Rows.Count > 0)
                    {
                        Cursor.Current = Cursors.WaitCursor;
                        Program.export2Excel(this.tblField, "ZWB", "I_RECORD_F_" + DateTime.Now.ToString("ddMMyyyy_HHmmss"));
                        Cursor.Current = Cursors.Default;
                        MessageBox.Show(this.tblField.Rows.Count + " data of I_RECORD_F have been extracted.", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
            }
            catch
            {
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void f_load()
        {
            Cursor.Current = Cursors.WaitCursor;
            if (Convert.ToInt16(WBUser.UserLevel) > 2)
            {
                this.mnUpd.Enabled = false;
                this.excelToolStripMenuItem.Enabled = false;
                this.repostMutuToolStripMenuItem.Enabled = false;
                if (WBUser.CheckTrustee("TRANS_QC", "V"))
                {
                    this.mnUpd.Enabled = false;
                    this.excelToolStripMenuItem.Enabled = true;
                    this.repostMutuToolStripMenuItem.Enabled = true;
                }
                if (WBUser.CheckTrustee("MD_SYNCH", "A"))
                {
                    this.mnUpd.Enabled = true;
                    this.excelToolStripMenuItem.Enabled = true;
                    this.repostMutuToolStripMenuItem.Enabled = true;
                }
            }
            this.initTransFlag();
            this.initTable();
            if (!WBSetting.activeMulesoftIntegration)
            {
                this.panelMulesoft.Visible = false;
            }
            else
            {
                this.labelMulesoft1.Text = "Upload data per cycle: " + Constant.TRANSACTION_UPLOADED_PER_BATCH.ToString();
                this.labelMulesoft1.Refresh();
                this.setMainTrans(0);
                this.setCycle(0, 0);
                this.setData(0, Convert.ToInt32(this.labelTotalRecord2.Text));
                this.panelMulesoft.Visible = true;
            }
            Cursor.Current = Cursors.Default;
        }

        private string fill_BCCount(string ref_no)
        {
            string str = "0";
            WBTable table = new WBTable();
            table.OpenTable("WB_LOCATION", "select Count(*) as BC_Count from wb_transBC where (deleted is null or deleted = 'N') and ref = '" + ref_no + "'", WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                str = table.DT.Rows[0]["BC_Count"].ToString();
            }
            return str;
        }

        private void fillBC()
        {
            int num = 0;
            int crRow = 0;
            int count = 0;
            count = this.tblTransBC.Columns.Count;
            string sqltext = "";
            string str2 = "";
            WBTable table = new WBTable();
            num = this.dgTrans.Rows.Count;
            this.dgTransBC.Rows.Clear();
            str2 = " Ref = '" + this.dgTrans.Rows[0].Cells["WREF"].Value.ToString().Trim() + "'";
            int num4 = 0;
            while (true)
            {
                if (num4 >= num)
                {
                    sqltext = "Select * from wb_transBC where (Deleted is null and Deleted = 'N') AND (" + str2 + ")";
                    table.OpenTable("wb_transBC", sqltext, WBData.conn);
                    this.BCCount = table.DT.Rows.Count;
                    if (this.BCCount > 0)
                    {
                        this.dgTransBC.Rows.Add(this.BCCount);
                    }
                    crRow = 0;
                    string tolLoc = "";
                    int num5 = 0;
                    while (num5 < this.BCCount)
                    {
                        table.DR = table.DT.Rows[num5];
                        tolLoc = "";
                        int num6 = 0;
                        while (true)
                        {
                            if (num6 >= num)
                            {
                                this.fillBCRow(table.DR, tolLoc, crRow);
                                crRow++;
                                num5++;
                                break;
                            }
                            if (table.DR["Ref"].ToString() == this.dgTrans.Rows[num6].Cells["WREF"].Value.ToString().Trim())
                            {
                                tolLoc = this.dgTrans.Rows[num6].Cells["Zwb_Loc"].Value.ToString();
                            }
                            num6++;
                        }
                    }
                    return;
                }
                str2 = str2 + " Or Ref = '" + this.dgTrans.Rows[num4].Cells["WREF"].Value.ToString().Trim() + "'";
                num4++;
            }
        }

        private bool fillBCRow(DataRow zRowBC, string tolLoc, int crRow)
        {
            WBTable table = new WBTable();
            string str7 = zRowBC["ref"].ToString();
            int count = this.tbl_templateTransBC.DT.Rows.Count;
            string[] strArray = new string[count];
            int index = 0;
            while (true)
            {
                string str5;
                string str6;
                while (true)
                {
                    if (index >= count)
                    {
                        return true;
                    }
                    this.tbl_templateTransBC.DR = this.tbl_templateTransBC.DT.Rows[index];
                    string tablename = this.tbl_templateTransBC.DR["table_name"].ToString().Trim();
                    str6 = this.tbl_templateTransBC.DR["title_excel"].ToString().Trim();
                    string str3 = this.tbl_templateTransBC.DR["Key_Field"].ToString().Trim();
                    string str4 = this.tbl_templateTransBC.DR["Key_Field2"].ToString().Trim();
                    string str2 = this.tbl_templateTransBC.DR["Field_WB"].ToString().Trim();
                    str5 = this.tbl_templateTransBC.DR["data_type"].ToString();
                    int num2 = Convert.ToInt16(this.tbl_templateTransBC.DR["fixed"].ToString());
                    if (num2 != 0)
                    {
                        strArray[index] = this.tbl_templateTransBC.DR["value"].ToString();
                    }
                    else
                    {
                        try
                        {
                            if (tablename.Trim().ToUpper() == "wb_transBC".ToUpper())
                            {
                                strArray[index] = (str2.Trim() != "") ? zRowBC[str2].ToString() : "";
                            }
                            else
                            {
                                string[] textArray1 = new string[] { "select ", str2, " from ", tablename, " where " };
                                string[] textArray2 = new string[] { " AND ", str3, "= '", zRowBC[str4].ToString(), "' " };
                                table.OpenTable(tablename, string.Concat(textArray1) + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
                                table.DR = table.DT.Rows[0];
                                strArray[index] = table.DR[str2].ToString();
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                    break;
                }
                if (str6.ToUpper() == "ZWB_LOC".ToUpper())
                {
                    strArray[index] = tolLoc;
                }
                if (strArray[index] != "")
                {
                    DateTime time;
                    if (str5.ToUpper() == "DATE".ToUpper())
                    {
                        time = Convert.ToDateTime(strArray[index]);
                        strArray[index] = time.ToString("dd.MM.yyyy");
                    }
                    else if (str5.ToUpper() == "TIME".ToUpper())
                    {
                        try
                        {
                            time = Convert.ToDateTime(strArray[index]);
                            strArray[index] = time.ToString("HH:mm");
                            if (strArray[index] == "00:00")
                            {
                                strArray[index] = "00:01";
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                    else if (str5.ToUpper() != "TIMES".ToUpper())
                    {
                        if (str5.ToUpper() == "Boolean".ToUpper())
                        {
                            strArray[index] = (strArray[index] != "Y") ? "" : "X";
                        }
                    }
                    else
                    {
                        try
                        {
                            strArray[index] = Convert.ToDateTime(strArray[index]).ToString("HH:mm:ss");
                            if (strArray[index] == "00:00:00")
                            {
                                strArray[index] = "00:00:01";
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                }
                if ((str5.ToUpper() == "Number".ToUpper()) && ((strArray[index] == null) || (strArray[index].Trim() == "")))
                {
                    strArray[index] = "0";
                }
                if (str6 != "")
                {
                    this.dgTransBC.Rows[crRow].Cells[str6].Value = strArray[index];
                }
                index++;
            }
        }

        private void fillDG(DataGridView zDgv, DataTable zTable, WBTable ztemplate)
        {
            this.rCount = this.tbl_transaction.DT.Rows.Count;
            this.prgBar.Maximum = this.rCount;
            this.prgBar.Value = 0;
            this.zwbRef = "";
            this.zwbRefDo = "";
            zDgv.Rows.Clear();
            for (int i = 0; i < this.rCount; i++)
            {
                zDgv.Rows.Add();
                this.tbl_transaction.DR = this.tbl_transaction.DT.Rows[i];
                int crRow = zDgv.Rows.Count - 1;
                if (this.fillDGRow(this.tbl_transaction.DR, zDgv, crRow, ztemplate))
                {
                    this.prgBar.Value++;
                    this.labelTotalRecord2.Text = this.prgBar.Value.ToString();
                }
            }
        }

        private void fillDG_TransW(DataGridView zDgv, DataTable zTable, WBTable ztemplate)
        {
            this.rCount = this.tbl_transaction.DT.Rows.Count;
            this.prgBar.Maximum = this.rCount;
            this.prgBar.Value = 0;
            this.zwbRef = "";
            this.zwbRefDo = "";
            for (int i = 0; i < this.rCount; i++)
            {
                if (this.tbl_transaction.DT.Rows[i]["wx"].ToString() == "4X")
                {
                    zDgv.Rows.Add();
                    this.tbl_transaction.DR = this.tbl_transaction.DT.Rows[i];
                    int crRow = zDgv.Rows.Count - 1;
                    if (this.fillDGRow(this.tbl_transaction.DR, zDgv, crRow, ztemplate))
                    {
                        this.prgBar.Value++;
                    }
                }
            }
        }

        private bool fillDGRow(DataRow aRow, DataGridView fDgv, int crRow, WBTable zTemplate)
        {
            bool flag = false;
            string str = "";
            string str3 = "N";
            string str4 = "";
            string str5 = "";
            string str6 = "";
            string str7 = "";
            int index = 0;
            this.dataUploadIDSYS = new Dictionary<string, object>();
            WBTable table = new WBTable();
            int count = zTemplate.DT.Rows.Count;
            this.jlhkolom = count;
            string[] values = new string[count];
            string str18 = "";
            string str16 = aRow["ref"].ToString();
            if (str16.Length > 0)
            {
                string str17;
                if (str16.Substring(str16.Length - 1, 1) == Constant.TITIP_TIMBUN_POSTFIX)
                {
                    str17 = aRow["DO_NO"].ToString();
                    str17 = str17.Substring(0, str17.Length - 1);
                    str18 = Program.getFieldValue("wb_Contract", "coy_Tolling", "DO_NO", str17);
                }
                if (str16.Substring(str16.Length - 2, 1) == Constant.TITIP_TIMBUN_POSTFIX)
                {
                    str17 = aRow["DO_NO"].ToString();
                    str17 = str17.Substring(0, str17.Length - 1);
                    str18 = Program.getFieldValue("wb_Contract", "coy_Tolling", "DO_NO", str17);
                }
                if (str16.Substring(str16.Length - 1, 1) == "T")
                {
                    str17 = aRow["DO_NO"].ToString();
                    str17 = str17.Substring(0, str17.Length - 1);
                    str18 = Program.getFieldValue("wb_Contract", "coy_Tolling", "DO_NO", str17);
                }
                if (str16.Substring(str16.Length - 2, 1) == "T")
                {
                    str17 = aRow["DO_NO"].ToString();
                    str17 = str17.Substring(0, str17.Length - 1);
                    str18 = Program.getFieldValue("wb_Contract", "coy_Tolling", "DO_NO", str17);
                }
            }
            str3 = aRow["Posted"].ToString();
            int num4 = 0;
            while (true)
            {
                string str9;
                string str12;
                string str13;
                string str14;
                while (true)
                {
                    if (num4 >= count)
                    {
                        bool flag88;
                        fDgv.Rows[crRow].Cells["posted"].Value = str3;
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_transaction", "Select uniq From wb_transaction where " + WBData.CompanyLocation(" and Ref='" + aRow["ref"].ToString() + "'"), WBData.conn);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            this.locked = false;
                        }
                        else
                        {
                            table2.DR = table2.DT.Rows[0];
                            this.locked = table2.Locked(table2.DR["uniq"].ToString(), '0');
                        }
                        if ((this.type == "1") && (this.zwbRef.Trim() != aRow["ref"].ToString().Trim()))
                        {
                            this.zwbRef = aRow["ref"].ToString();
                            string[] textArray3 = new string[] { aRow["Ref"].ToString(), this.estateDiff };
                            this.dgTransFlag.Rows.Add(textArray3);
                            if (this.estateDiff == "Y")
                            {
                                DataGridViewCellStyle style = new DataGridViewCellStyle {
                                    BackColor = Color.Red,
                                    SelectionBackColor = Color.HotPink
                                };
                                this.dgTrans.Rows[this.dgTrans.Rows.Count - 1].DefaultCellStyle = style;
                            }
                        }
                        if (this.locked)
                        {
                            flag88 = false;
                        }
                        else
                        {
                            if (!this.cekFlag(aRow["Ref"].ToString()) && flag)
                            {
                                values[index] = str;
                                fDgv.Rows.Add(values);
                            }
                            flag88 = true;
                        }
                        return flag88;
                    }
                    zTemplate.DR = zTemplate.DT.Rows[num4];
                    string tablename = zTemplate.DR["table_name"].ToString().Trim();
                    str12 = zTemplate.DR["title_excel"].ToString().Trim();
                    string str10 = zTemplate.DR["Key_Field"].ToString().Trim();
                    string str11 = zTemplate.DR["Key_Field2"].ToString().Trim();
                    str9 = zTemplate.DR["Field_WB"].ToString().Trim();
                    str13 = zTemplate.DR["data_type"].ToString();
                    int num2 = Convert.ToInt16(zTemplate.DR["fixed"].ToString());
                    str14 = zTemplate.DR["type"].ToString();
                    if (str12.ToUpper() == "ZWB_LOC".ToUpper())
                    {
                        index = num4;
                    }
                    if (num2 != 0)
                    {
                        values[num4] = zTemplate.DR["value"].ToString();
                    }
                    else if (((tablename.ToUpper() != "wb_transaction".ToUpper()) && ((tablename != "") && ((tablename.ToUpper() != "wb_transactiond".ToUpper()) && (tablename.ToUpper() != "wb_transQC".ToUpper())))) && (tablename.ToUpper() != "wb_transbatch".ToUpper()))
                    {
                        try
                        {
                            if ((WBSetting.integrationIDSYS && (str12.ToUpper() == "ITEM_NO")) && (str9 == ""))
                            {
                                str9 = (str4 == "") ? ((str5 == "") ? ((str6 == "") ? "*" : "sto_item") : "po_item") : "so_item";
                            }
                            if ((WBSetting.integrationIDSYS && (str12.ToUpper() == "QTY")) && (str9 == ""))
                            {
                                str9 = (str7.ToUpper() != "BAG") ? "netto" : "loading_qty";
                            }
                            string[] textArray1 = new string[] { "select ", str9, " from ", tablename, " where " };
                            string[] textArray2 = new string[] { " And ", str10, "= '", aRow[str11].ToString(), "' " };
                            table.OpenTable(tablename, string.Concat(textArray1) + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
                            table.DR = table.DT.Rows[0];
                            if (WBSetting.integrationIDSYS)
                            {
                                if (str9.ToUpper() == "SO")
                                {
                                    str4 = table.DR[str9].ToString();
                                }
                                if (str9.ToUpper() == "PO")
                                {
                                    str5 = table.DR[str9].ToString();
                                }
                                if (str9.ToUpper() == "STO")
                                {
                                    str6 = table.DR[str9].ToString();
                                }
                                if (str9.ToUpper() == "UNIT")
                                {
                                    str7 = table.DR[str9].ToString();
                                }
                            }
                            values[num4] = table.DR[str9].ToString();
                            if (WBSetting.integrationIDSYS)
                            {
                                this.dataUploadIDSYS.Add(str12, table.DR[str9].ToString());
                            }
                            if (!WBSetting.Cut_Off_Location)
                            {
                                values[num4] = table.DR[str9].ToString();
                            }
                            else if (str9.ToUpper() == "COYSAP")
                            {
                                values[num4] = (cutOff(str16) != "") ? cutOff(str16) : table.DR[str9].ToString();
                            }
                        }
                        catch
                        {
                            values[num4] = "";
                        }
                        if (tablename.ToUpper() == "wb_contract".ToUpper())
                        {
                            this.adopt = aRow["zadp"].ToString();
                        }
                        if ((str12.ToUpper() == "WJLHGONI".ToUpper()) && ((values[num4] == "0") && (Program.StrToDouble(aRow["TotalBunch"].ToString(), 0) > 0.0)))
                        {
                            values[num4] = aRow["totalbunch"].ToString();
                        }
                        if ((str12.ToUpper() == "WQTY_KB") && (aRow["NOPW"].ToString() == "Y"))
                        {
                            values[num4] = aRow["loading_qty"].ToString();
                        }
                    }
                    else if (tablename.ToUpper() != "wb_transaction".ToUpper())
                    {
                        try
                        {
                            values[num4] = aRow[str9].ToString();
                        }
                        catch
                        {
                            values[num4] = "";
                        }
                    }
                    else
                    {
                        try
                        {
                            values[num4] = aRow[str9].ToString();
                            if (str9.ToUpper() == "Deleted".ToUpper())
                            {
                                values[num4] = aRow[str9].ToString();
                                if (values[num4] == "Y")
                                {
                                    values[num4] = "1";
                                }
                                if (aRow["mark_accident"].ToString() == "X")
                                {
                                    values[num4] = "A";
                                }
                            }
                            if (aRow["tolling"].ToString() == "Y")
                            {
                                flag = true;
                                str = aRow["Coy_Tolling"].ToString();
                            }
                            if (str9.ToUpper() == "IO".ToUpper())
                            {
                                values[num4] = (values[num4] != "I") ? "S" : "P";
                            }
                            if ((str12.ToUpper() == "Kirim".ToUpper()) && (values[num4] == "0"))
                            {
                                values[num4] = aRow["received"].ToString();
                            }
                            if (str12.ToUpper() == "MAINTICKET")
                            {
                                values[num4] = "";
                            }
                            if (str12.ToUpper() == "STORAGE_CODE".ToUpper())
                            {
                                this.aTable.OpenTable("wb_transaction", "select ref, Source_code from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + str16 + "'"), WBData.conn);
                                if (this.aTable.DT.Rows.Count > 0)
                                {
                                    this.aTable.DR = this.aTable.DT.Rows[0];
                                    if (this.aTable.DR["source_code"].ToString().Trim() != "")
                                    {
                                        this.bTable.OpenTable("wb_source", "select * from wb_source where " + WBData.CompanyLocation(" and source_code = '" + this.aTable.DR["source_code"].ToString() + "'"), WBData.conn);
                                        if (this.bTable.DT.Rows.Count <= 0)
                                        {
                                            values[num4] = this.aTable.DR["source_code"].ToString();
                                        }
                                        else
                                        {
                                            this.bTable.DR = this.bTable.DT.Rows[0];
                                            values[num4] = this.bTable.DR["storage_loc"].ToString();
                                        }
                                    }
                                }
                            }
                            if ((str9.ToUpper() == "GROSS_ESTATE".ToUpper()) && (aRow["NOPW"].ToString() == "Y"))
                            {
                                values[num4] = aRow["NETTO"].ToString();
                            }
                            if ((str9.ToUpper() == "NET_ESTATE".ToUpper()) && (aRow["NOPW"].ToString() == "Y"))
                            {
                                values[num4] = aRow["NETTO"].ToString();
                            }
                            if ((str9.ToUpper() == "estate_qty".ToUpper()) && (aRow["NOPW"].ToString() == "Y"))
                            {
                                values[num4] = aRow["NETTO"].ToString();
                            }
                            if ((str12.ToUpper() == "WREF".ToUpper()) && (this.module.ToUpper().Trim() == "TRANSPORT".ToUpper().Trim()))
                            {
                                int num5 = WBData.sCoyCode.Length + WBData.sLocCode.Length;
                                int num6 = 7;
                                if (WBSetting.Field("Ref6").ToString() == "Y")
                                {
                                    num6 = 6;
                                }
                                values[num4] = values[num4].Substring(0, num5 + num6);
                            }
                        }
                        catch
                        {
                            values[num4] = "";
                            values[num4] = "";
                        }
                        this.estateDiff = aRow["estateDiff"].ToString();
                        if (str12.ToUpper() == "RETTICKET2".ToUpper())
                        {
                            string sqltext = "";
                            sqltext = (("Select ref from wb_transaction where " + WBData.CompanyLocation("") + " and (deleted is null or deleted = 'N') ") + " and (report_Date is not null) " + " and (mark_return = 'X') ") + " and (return_ref = '" + aRow["REF"].ToString() + "') ";
                            WBTable table3 = new WBTable();
                            table3.OpenTable("wb_findRetur", sqltext, WBData.conn);
                            if (table3.DT.Rows.Count > 0)
                            {
                                values[num4] = table3.DT.Rows[0]["Ref"].ToString();
                            }
                            table3.Dispose();
                        }
                    }
                    break;
                }
                if ((str12.ToUpper() == "BC_COUNT") && (!string.IsNullOrEmpty(str14) && (str14 == "1")))
                {
                    values[num4] = this.fill_BCCount(aRow["ref"].ToString().Trim());
                }
                if (((str12 == "ZWB_LOC") || (str12 == "WLOKASI")) && (str18 != ""))
                {
                    values[num4] = str18;
                }
                if (str12.ToUpper() == "WUNIQ".ToUpper())
                {
                    if (this.zwbRefDo.Trim() == aRow["ref"].ToString().Trim())
                    {
                        this.countRef++;
                    }
                    else
                    {
                        this.countRef = 0;
                        this.zwbRefDo = aRow["ref"].ToString().Trim();
                    }
                    values[num4] = this.countRef.ToString().PadLeft(2, '0');
                }
                if ((str9.ToUpper() == "DO_NO") && (Program.getFieldValue("wb_Contract", "zAuto", "DO_NO", values[num4]) == "Y"))
                {
                    values[num4] = values[num4].Substring(0, values[num4].Length - 1);
                }
                if ((((str12.ToUpper() == "WSTO") || ((str12.ToUpper() == "LANGSIR") || ((str12.ToUpper() == "WGIDO") || (str12.ToUpper() == "WSTO2")))) || (str12.ToUpper() == "WGIDO2")) && (Program.getFieldValue("wb_contract", "STO1DO", "Do_No", aRow["Do_NO"].ToString()) == "Y"))
                {
                    if (str12.ToUpper() == "WSTO")
                    {
                        values[num4] = aRow["STO1X"].ToString();
                    }
                    else if (str12.ToUpper() == "WGIDO")
                    {
                        values[num4] = aRow["DO1X"].ToString();
                    }
                    else if (str12.ToUpper() == "LANGSIR")
                    {
                        values[num4] = "1";
                    }
                    else if (str12.ToUpper() == "WSTO2")
                    {
                        values[num4] = aRow["STO1X"].ToString();
                    }
                    else if (str12.ToUpper() == "WGIDO2")
                    {
                        values[num4] = aRow["DO1X"].ToString();
                    }
                }
                if (values[num4] != "")
                {
                    DateTime time;
                    if (str13.ToUpper() == "DATE".ToUpper())
                    {
                        time = Convert.ToDateTime(values[num4]);
                        values[num4] = time.ToString("dd.MM.yyyy");
                    }
                    else if (str13.ToUpper() == "TIME".ToUpper())
                    {
                        try
                        {
                            time = Convert.ToDateTime(values[num4]);
                            values[num4] = time.ToString("HH:mm");
                            if (values[num4] == "00:00")
                            {
                                values[num4] = "00:01";
                            }
                        }
                        catch
                        {
                            values[num4] = "";
                        }
                    }
                    else if (str13.ToUpper() != "TIMES".ToUpper())
                    {
                        if (str13.ToUpper() == "Formula".ToUpper())
                        {
                            double num7 = Convert.ToDouble(values[num4]);
                            this.owner.NET = num7;
                            num7 = Program.eval(zTemplate.DR["value"].ToString().Replace("VAL", values[num4]), this.owner);
                            values[num4] = (num7 >= 1.0) ? Convert.ToString(num7) : "";
                        }
                    }
                    else
                    {
                        try
                        {
                            values[num4] = Convert.ToDateTime(values[num4]).ToString("HH:mm:ss");
                            if (values[num4] == "00:00:00")
                            {
                                values[num4] = "00:00:01";
                            }
                        }
                        catch
                        {
                            values[num4] = "";
                        }
                    }
                }
                if (str13.ToUpper() != "Number".ToUpper())
                {
                    if (str13.ToUpper() == "Boolean".ToUpper())
                    {
                        values[num4] = (values[num4] != "Y") ? "" : "X";
                    }
                }
                else
                {
                    if (ReferenceEquals(values[num4], null))
                    {
                        values[num4] = "0";
                    }
                    if (values[num4].Trim() == "")
                    {
                        values[num4] = "0";
                    }
                }
                if (str12 != "")
                {
                    fDgv.Rows[crRow].Cells[str12].Value = values[num4];
                }
                num4++;
            }
        }

        private void fillQC()
        {
            int num = 0;
            int crRow = 0;
            int count = 0;
            count = this.tblTransQC.Columns.Count;
            string sqltext = "";
            string str2 = "";
            WBTable table = new WBTable();
            num = this.dgTrans.Rows.Count;
            this.dgTransQC.Rows.Clear();
            str2 = " Ref = '" + this.dgTrans.Rows[0].Cells["WREF"].Value.ToString().Trim() + "'";
            int num4 = 0;
            while (true)
            {
                if (num4 >= num)
                {
                    sqltext = "Select * from wb_transQC where " + str2;
                    table.OpenTable("wb_transQC", sqltext, WBData.conn);
                    this.QCCount = table.DT.Rows.Count;
                    if (this.QCCount > 0)
                    {
                        this.dgTransQC.Rows.Add(this.QCCount);
                    }
                    crRow = 0;
                    string tolLoc = "";
                    int num5 = 0;
                    while (num5 < this.QCCount)
                    {
                        table.DR = table.DT.Rows[num5];
                        tolLoc = "";
                        int num6 = 0;
                        while (true)
                        {
                            if (num6 >= num)
                            {
                                this.fillQCRow(table.DR, tolLoc, crRow);
                                crRow++;
                                num5++;
                                break;
                            }
                            if (table.DR["Ref"].ToString() == this.dgTrans.Rows[num6].Cells["WREF"].Value.ToString().Trim())
                            {
                                tolLoc = this.dgTrans.Rows[num6].Cells["Zwb_Loc"].Value.ToString();
                            }
                            num6++;
                        }
                    }
                    return;
                }
                str2 = str2 + " Or Ref = '" + this.dgTrans.Rows[num4].Cells["WREF"].Value.ToString().Trim() + "'";
                num4++;
            }
        }

        private bool fillQCRow(DataRow zRowQC, string tolLoc, int crRow)
        {
            WBTable table = new WBTable();
            string str7 = zRowQC["ref"].ToString();
            int count = this.tbl_templateTransQC.DT.Rows.Count;
            string[] strArray = new string[count];
            int index = 0;
            while (true)
            {
                string str5;
                string str6;
                while (true)
                {
                    if (index >= count)
                    {
                        return true;
                    }
                    this.tbl_templateTransQC.DR = this.tbl_templateTransQC.DT.Rows[index];
                    string tablename = this.tbl_templateTransQC.DR["table_name"].ToString().Trim();
                    str6 = this.tbl_templateTransQC.DR["title_excel"].ToString().Trim();
                    string str3 = this.tbl_templateTransQC.DR["Key_Field"].ToString().Trim();
                    string str4 = this.tbl_templateTransQC.DR["Key_Field2"].ToString().Trim();
                    string str2 = this.tbl_templateTransQC.DR["Field_WB"].ToString().Trim();
                    str5 = this.tbl_templateTransQC.DR["data_type"].ToString();
                    int num2 = Convert.ToInt16(this.tbl_templateTransQC.DR["fixed"].ToString());
                    if (num2 != 0)
                    {
                        strArray[index] = this.tbl_templateTransQC.DR["value"].ToString();
                    }
                    else
                    {
                        try
                        {
                            if (tablename.Trim().ToUpper() == "wb_transQC".ToUpper())
                            {
                                strArray[index] = (str2.Trim() != "") ? zRowQC[str2].ToString() : "";
                            }
                            else
                            {
                                string[] textArray1 = new string[] { "select ", str2, " from ", tablename, " where " };
                                string[] textArray2 = new string[] { " AND ", str3, "= '", zRowQC[str4].ToString(), "' " };
                                table.OpenTable(tablename, string.Concat(textArray1) + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
                                table.DR = table.DT.Rows[0];
                                strArray[index] = table.DR[str2].ToString();
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                    break;
                }
                if (str6.ToUpper() == "ZWB_LOC".ToUpper())
                {
                    strArray[index] = tolLoc;
                }
                if (strArray[index] != "")
                {
                    DateTime time;
                    if (str5.ToUpper() == "DATE".ToUpper())
                    {
                        time = Convert.ToDateTime(strArray[index]);
                        strArray[index] = time.ToString("dd.MM.yyyy");
                    }
                    else if (str5.ToUpper() == "TIME".ToUpper())
                    {
                        try
                        {
                            time = Convert.ToDateTime(strArray[index]);
                            strArray[index] = time.ToString("HH:mm");
                            if (strArray[index] == "00:00")
                            {
                                strArray[index] = "00:01";
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                    else if (str5.ToUpper() != "TIMES".ToUpper())
                    {
                        if (str5.ToUpper() == "Boolean".ToUpper())
                        {
                            strArray[index] = (strArray[index] != "Y") ? "" : "X";
                        }
                    }
                    else
                    {
                        try
                        {
                            strArray[index] = Convert.ToDateTime(strArray[index]).ToString("HH:mm:ss");
                            if (strArray[index] == "00:00:00")
                            {
                                strArray[index] = "00:00:01";
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                }
                if ((str5.ToUpper() == "Number".ToUpper()) && ((strArray[index] == null) || (strArray[index].Trim() == "")))
                {
                    strArray[index] = "0";
                }
                if (str6 != "")
                {
                    this.dgTransQC.Rows[crRow].Cells[str6].Value = strArray[index];
                }
                index++;
            }
        }

        public void fillTable()
        {
            if (this.auto == 'N')
            {
                this.date1 = Program.DTOC(this.dateFrom) + " 00:00:00";
                this.date2 = Program.DTOC(this.dateTo) + " 00:00:00";
            }
            if (this.cTrans)
            {
                this.sqlText = (this.auto != 'N') ? ("select * from vw_trans where " + WBData.CompanyLocation("")) : ("select * from vw_trans where " + WBData.CompanyLocation(""));
                this.sqlText = this.sqlText + " and ((posted is null or posted ='N') or (reposted ='N'))";
                this.sqlText = this.sqlText + " and report_date IS NOT NULL ";
                if (WBSetting.integrationIDSYS)
                {
                    this.sqlText = this.sqlText + " and (deleted is null or deleted ='N') and (po <> '' or po is not null or sto <> '' or sto is not null or so <> '' or so is not null)";
                }
                this.sqlText = this.sqlText + " order by Ref desc";
            }
            else
            {
                if (this.auto != 'N')
                {
                    this.sqlText = "select * from vw_trans where " + WBData.CompanyLocation("");
                }
                else
                {
                    string[] textArray1 = new string[] { " and report_date >= '", this.date1, "' and report_Date <= '", this.date2, "' " };
                    this.sqlText = "select * from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray1));
                }
                this.sqlText = this.sqlText + " and report_date IS NOT NULL ";
                if (this.auto == 'N')
                {
                    if (this.tipeTrans.Length > 0)
                    {
                        this.sqlText = this.sqlText + " and IO = '" + this.tipeTrans + "' ";
                    }
                    if (this.comm.Length > 0)
                    {
                        this.sqlText = this.sqlText + " and (Comm_code = '" + this.comm + "') ";
                    }
                    if (this.transpt.Length > 0)
                    {
                        this.sqlText = this.sqlText + " and (Transporter_code = '" + this.comm + "') ";
                    }
                    if (this.Do_No.Length > 0)
                    {
                        this.sqlText = this.sqlText + " and (Do_No = '" + this.Do_No + "') ";
                    }
                    if (this.refNo.Length > 0)
                    {
                        this.sqlText = this.sqlText + " and (Ref = '" + this.refNo + "') ";
                    }
                }
                if (!this.showAll)
                {
                    this.sqlText = this.sqlText + " and ((posted is null or posted ='N') or (reposted ='N'))";
                }
                if (WBSetting.integrationIDSYS)
                {
                    this.sqlText = this.sqlText + " and (deleted is null or deleted ='N') and ((po <> '' and po is not null) or (sto <> '' and sto is not null) or (so <> '' and so is not null))";
                }
                this.sqlText = this.sqlText + " order by Ref desc";
            }
            this.tbl_transaction.OpenTable("vw_trans", this.sqlText, WBData.conn);
            this.labelTotalRecord2.Text = this.tbl_transaction.DT.Rows.Count.ToString();
            this.labelTotalRecord2.Refresh();
            this.setMainTrans(0);
            this.setCycle(0, 0);
            this.setData(0, Convert.ToInt32(this.labelTotalRecord2.Text));
            if (this.tbl_transaction.DT.Rows.Count <= 0)
            {
                if ((this.auto == 'Y') && !base.Visible)
                {
                    this.exitToolStripMenuItem.PerformClick();
                }
                else
                {
                    this.dgTrans.DataSource = null;
                    this.dgTrans.Rows.Clear();
                    this.dgTrans.Refresh();
                    this.dgTransC.DataSource = null;
                    this.dgTransC.Rows.Clear();
                    this.dgTransC.Refresh();
                    this.dgTransW.DataSource = null;
                    this.dgTransW.Rows.Clear();
                    this.dgTransW.Refresh();
                    this.dgTransD.DataSource = null;
                    this.dgTransD.Rows.Clear();
                    this.dgTransD.Refresh();
                    this.dgTransQC.DataSource = null;
                    this.dgTransQC.Rows.Clear();
                    this.dgTransQC.Refresh();
                    this.dgTransFlag.DataSource = null;
                    this.dgTransFlag.Rows.Clear();
                    this.dgTransFlag.Refresh();
                    this.dgTransBC.DataSource = null;
                    this.dgTransBC.Rows.Clear();
                    this.dgTransBC.Refresh();
                    MessageBox.Show("No data found!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            else
            {
                this.dgTrans.Refresh();
                this.dgTransC.Refresh();
                this.dgTransW.Refresh();
                this.dgTransD.Refresh();
                this.dgTransQC.Refresh();
                this.dgTransFlag.Refresh();
                this.dgTransBC.Refresh();
                this.dgTransFlag.Rows.Clear();
                this.type = "1";
                this.fillDG(this.dgTrans, this.tblTrans, this.tbl_templateTrans);
                this.uploadtrx = this.tblTrans.Rows.Count;
                if (!WBSetting.integrationIDSYS)
                {
                    this.type = "2";
                    this.fillDG(this.dgTransD, this.tblTransD, this.tbl_templateTransD);
                    this.type = "3";
                    this.fillQC();
                    this.type = "4";
                    this.fillDG(this.dgTransC, this.tblTransC, this.tbl_templateTransC);
                }
                if (this.count_trans_w_template > 0)
                {
                    this.type = "5.1";
                    this.fillDG(this.dgTransW, this.tblTransW, this.tbl_templateTransW_1);
                    this.type = "5.2";
                    this.fillDG_TransW(this.dgTransW, this.tblTransW, this.tbl_templateTransW_2);
                    this.type = "5.3";
                    this.fillDG_TransW(this.dgTransW, this.tblTransW, this.tbl_templateTransW_3);
                }
                this.type = "6";
                this.tbl_templateTransBC = this.getTemplate(this.type);
                this.fillBC();
                this.setReturnTable();
                this.labelTotalRecord.Refresh();
                this.labelTotalRecord2.Refresh();
                this.labelTotalRecord3.Refresh();
                this.prgBar.Value = 0;
                if (this.auto == 'N')
                {
                    if (this.dgTrans.Rows.Count <= 0)
                    {
                        MessageBox.Show("No data found!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        MessageBox.Show("Data is ready. Please click Upload button to proceed.", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        this.selectAll();
                    }
                }
            }
        }

        private void formatDG(DataGridView zDgv, DataTable zTable, WBTable zTemplate)
        {
            this.rCount = zTemplate.DT.Rows.Count;
            this.jlhkolom = this.rCount;
            zTable.Columns.Clear();
            zDgv.Columns.Clear();
            if (zDgv.Name.ToUpper().Trim() == "DGTRANS")
            {
                DataGridViewCheckBoxColumn dataGridViewColumn = new DataGridViewCheckBoxColumn {
                    Name = "Select",
                    HeaderText = "Select",
                    ReadOnly = true,
                    Visible = false
                };
                zDgv.Columns.Add(dataGridViewColumn);
            }
            int num = 0;
            while (true)
            {
                DataGridViewTextBoxColumn column;
                if (num >= this.rCount)
                {
                    column = new DataGridViewTextBoxColumn {
                        Name = "Posted",
                        HeaderText = "Posted",
                        ReadOnly = true
                    };
                    zDgv.Columns.Add(column);
                    return;
                }
                zTemplate.DR = zTemplate.DT.Rows[num];
                column = new DataGridViewTextBoxColumn();
                DataColumn column3 = new DataColumn();
                bool flag2 = zTemplate.DR["Title_Excel"].ToString().Trim() != "";
                column.Name = !flag2 ? ("Column_" + num.ToString()) : zTemplate.DR["Title_Excel"].ToString().Trim();
                column.HeaderText = zTemplate.DR["Title_Excel"].ToString();
                column.ReadOnly = true;
                column3.ColumnName = column.Name;
                zDgv.Columns.Add(column);
                zTable.Columns.Add(column3);
                num++;
            }
        }

        private void FormUploadZWB_Load(object sender, EventArgs e)
        {
            try
            {
                this.Refresh();
                if (WBUser.UserLevel == "1")
                {
                    this.panelDetail.Visible = true;
                    this.panel4X.Visible = true;
                    this.dgTransFlag.Visible = true;
                    this.dgTransW.Visible = true;
                }
                else
                {
                    this.panelDetail.Visible = false;
                    this.dgTransFlag.Visible = false;
                    this.panel4X.Visible = false;
                    this.dgTransW.Visible = false;
                }
                this.f_load();
                this.selectAll();
            }
            catch (Exception exception)
            {
                if (this.auto != 'Y')
                {
                    MessageBox.Show(exception.Message);
                }
            }
        }

        private void get_important_field()
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_templateSAP", "SELECT type, Column_Numbering, Title_Excel, important FROM wb_templateSAP WHERE " + WBData.CompanyLocation(" and modul = 'ZWB' and (important is null or important = '' or important = 'Y') and Field_Wb is not null"), WBData.conn);
            this.tblField.Columns.Clear();
            DataColumn column = new DataColumn {
                ColumnName = "TABNAME"
            };
            this.tblField.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "FIELDNAME"
            };
            this.tblField.Columns.Add(column);
            this.tblField.Rows.Clear();
            foreach (DataRow row2 in table.DT.Rows)
            {
                DataRow row = this.tblField.NewRow();
                if (row2["type"].ToString() == "1")
                {
                    row[0] = "I_RECORD";
                }
                else if (row2["type"].ToString() == "2")
                {
                    row[0] = "I_RECORD_D";
                }
                else if (row2["type"].ToString() == "3")
                {
                    row[0] = "I_RECORD_QUALITY";
                }
                else if (row2["type"].ToString() == "4")
                {
                    row[0] = "I_SORT_COPRA";
                }
                else if (((row2["type"].ToString() == "5.1") || (row2["type"].ToString() == "5.2")) || (row2["type"].ToString() == "5.3"))
                {
                    row[0] = "I_RECORD_W";
                }
                else if (row2["type"].ToString() == "6")
                {
                    row[0] = "I_RECORD_BC";
                }
                row[1] = row2["Title_Excel"].ToString().ToUpper();
                this.tblField.Rows.Add(row);
            }
            table.Dispose();
        }

        private WBTable getTemplate(string ztype)
        {
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { " AND modul = '", this.module, "'  and type ='", ztype, "' " };
            this.sqlText = "Select * from wb_templateSAP where " + WBData.CompanyLocation(string.Concat(textArray1)) + " order by column_Numbering";
            table.OpenTable("wb_templateSAP", this.sqlText, WBData.conn);
            if (ztype == "5.1")
            {
                this.count_trans_w_template = table.DT.Rows.Count;
            }
            return table;
        }

        public static string GetTimestamp(DateTime value) => 
            value.ToString("yyyyMMddHH");

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            DataGridViewCellStyle style4 = new DataGridViewCellStyle();
            DataGridViewCellStyle style5 = new DataGridViewCellStyle();
            DataGridViewCellStyle style6 = new DataGridViewCellStyle();
            DataGridViewCellStyle style7 = new DataGridViewCellStyle();
            DataGridViewCellStyle style8 = new DataGridViewCellStyle();
            DataGridViewCellStyle style9 = new DataGridViewCellStyle();
            this.menuStrip1 = new MenuStrip();
            this.mnUpd = new ToolStripMenuItem();
            this.excelToolStripMenuItem = new ToolStripMenuItem();
            this.repostMutuToolStripMenuItem = new ToolStripMenuItem();
            this.exitToolStripMenuItem = new ToolStripMenuItem();
            this.helpToolStripMenuItem = new ToolStripMenuItem();
            this.panel1 = new Panel();
            this.panelMulesoft = new GroupBox();
            this.labelMulesoft5 = new Label();
            this.labelMulesoftData = new Label();
            this.labelMulesoft1 = new Label();
            this.labelMulesoft4 = new Label();
            this.labelMulesoftCycle = new Label();
            this.labelMulesoft3 = new Label();
            this.buttonUnSelect = new Button();
            this.buttonSelectAll = new Button();
            this.labelTotalRecord3 = new Label();
            this.labelTotalRecord2 = new Label();
            this.labelTotalRecord = new Label();
            this.prgBar = new ProgressBar();
            this.panel2 = new Panel();
            this.dgTrans = new DataGridView();
            this.panel4X = new Panel();
            this.dgTransW = new DataGridView();
            this.dgTransFlag = new DataGridView();
            this.dgTransBC = new DataGridView();
            this.dgTransC = new DataGridView();
            this.dgTransQC = new DataGridView();
            this.dgTransD = new DataGridView();
            this.panelDetail = new Panel();
            this.panel6 = new Panel();
            this.panel5 = new Panel();
            this.panel4 = new Panel();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelMulesoft.SuspendLayout();
            this.panel2.SuspendLayout();
            ((ISupportInitialize) this.dgTrans).BeginInit();
            this.panel4X.SuspendLayout();
            ((ISupportInitialize) this.dgTransW).BeginInit();
            ((ISupportInitialize) this.dgTransFlag).BeginInit();
            ((ISupportInitialize) this.dgTransBC).BeginInit();
            ((ISupportInitialize) this.dgTransC).BeginInit();
            ((ISupportInitialize) this.dgTransQC).BeginInit();
            ((ISupportInitialize) this.dgTransD).BeginInit();
            this.panelDetail.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            base.SuspendLayout();
            this.menuStrip1.ImageScalingSize = new Size(20, 20);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.mnUpd, this.excelToolStripMenuItem, this.repostMutuToolStripMenuItem, this.exitToolStripMenuItem, this.helpToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new Size(0x4fb, 0x1c);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            this.mnUpd.Name = "mnUpd";
            this.mnUpd.Size = new Size(70, 0x18);
            this.mnUpd.Text = "Upload";
            this.mnUpd.Click += new EventHandler(this.mnUpd_Click);
            this.excelToolStripMenuItem.Name = "excelToolStripMenuItem";
            this.excelToolStripMenuItem.Size = new Size(0x37, 0x18);
            this.excelToolStripMenuItem.Text = "Excel";
            this.excelToolStripMenuItem.Click += new EventHandler(this.excelToolStripMenuItem_Click);
            this.repostMutuToolStripMenuItem.Name = "repostMutuToolStripMenuItem";
            this.repostMutuToolStripMenuItem.Size = new Size(0x69, 0x18);
            this.repostMutuToolStripMenuItem.Text = "Repost Mutu";
            this.repostMutuToolStripMenuItem.Visible = false;
            this.repostMutuToolStripMenuItem.Click += new EventHandler(this.repostMutuToolStripMenuItem_Click);
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new Size(0x2d, 0x18);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new EventHandler(this.exitToolStripMenuItem_Click);
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new Size(0x35, 0x18);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Visible = false;
            this.helpToolStripMenuItem.Click += new EventHandler(this.helpToolStripMenuItem_Click);
            this.panel1.Controls.Add(this.panelMulesoft);
            this.panel1.Controls.Add(this.buttonUnSelect);
            this.panel1.Controls.Add(this.buttonSelectAll);
            this.panel1.Controls.Add(this.labelTotalRecord3);
            this.panel1.Controls.Add(this.labelTotalRecord2);
            this.panel1.Controls.Add(this.labelTotalRecord);
            this.panel1.Controls.Add(this.prgBar);
            this.panel1.Dock = DockStyle.Top;
            this.panel1.Location = new Point(0, 0x1c);
            this.panel1.Margin = new Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x4fb, 0x37);
            this.panel1.TabIndex = 6;
            this.panelMulesoft.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.panelMulesoft.Controls.Add(this.labelMulesoft5);
            this.panelMulesoft.Controls.Add(this.labelMulesoftData);
            this.panelMulesoft.Controls.Add(this.labelMulesoft1);
            this.panelMulesoft.Controls.Add(this.labelMulesoft4);
            this.panelMulesoft.Controls.Add(this.labelMulesoftCycle);
            this.panelMulesoft.Controls.Add(this.labelMulesoft3);
            this.panelMulesoft.Location = new Point(0x198, -4);
            this.panelMulesoft.Margin = new Padding(4);
            this.panelMulesoft.Name = "panelMulesoft";
            this.panelMulesoft.Padding = new Padding(4);
            this.panelMulesoft.Size = new Size(0x213, 0x37);
            this.panelMulesoft.TabIndex = 0x17;
            this.panelMulesoft.TabStop = false;
            this.panelMulesoft.Visible = false;
            this.labelMulesoft5.AutoSize = true;
            this.labelMulesoft5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelMulesoft5.Location = new Point(0xf8, 14);
            this.labelMulesoft5.Margin = new Padding(4, 0, 4, 0);
            this.labelMulesoft5.Name = "labelMulesoft5";
            this.labelMulesoft5.Size = new Size(0xd0, 0x11);
            this.labelMulesoft5.TabIndex = 7;
            this.labelMulesoft5.Text = "Total of main transaction: 0";
            this.labelMulesoftData.AutoSize = true;
            this.labelMulesoftData.Location = new Point(0x18f, 0x20);
            this.labelMulesoftData.Margin = new Padding(4, 0, 4, 0);
            this.labelMulesoftData.Name = "labelMulesoftData";
            this.labelMulesoftData.Size = new Size(0x54, 0x11);
            this.labelMulesoftData.TabIndex = 6;
            this.labelMulesoftData.Text = "XXXX/XXXX";
            this.labelMulesoft1.AutoSize = true;
            this.labelMulesoft1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelMulesoft1.Location = new Point(8, 14);
            this.labelMulesoft1.Margin = new Padding(4, 0, 4, 0);
            this.labelMulesoft1.Name = "labelMulesoft1";
            this.labelMulesoft1.Size = new Size(0xac, 0x11);
            this.labelMulesoft1.TabIndex = 0;
            this.labelMulesoft1.Text = "Upload data per cycle:";
            this.labelMulesoft4.AutoSize = true;
            this.labelMulesoft4.Location = new Point(0xf8, 0x20);
            this.labelMulesoft4.Margin = new Padding(4, 0, 4, 0);
            this.labelMulesoft4.Name = "labelMulesoft4";
            this.labelMulesoft4.Size = new Size(0x99, 0x11);
            this.labelMulesoft4.TabIndex = 5;
            this.labelMulesoft4.Text = "Processed transaction:";
            this.labelMulesoftCycle.AutoSize = true;
            this.labelMulesoftCycle.Location = new Point(0x7b, 0x20);
            this.labelMulesoftCycle.Margin = new Padding(4, 0, 4, 0);
            this.labelMulesoftCycle.Name = "labelMulesoftCycle";
            this.labelMulesoftCycle.Size = new Size(0x54, 0x11);
            this.labelMulesoftCycle.TabIndex = 4;
            this.labelMulesoftCycle.Text = "XXXX/XXXX";
            this.labelMulesoft3.AutoSize = true;
            this.labelMulesoft3.Location = new Point(9, 0x20);
            this.labelMulesoft3.Margin = new Padding(4, 0, 4, 0);
            this.labelMulesoft3.Name = "labelMulesoft3";
            this.labelMulesoft3.Size = new Size(0x73, 0x11);
            this.labelMulesoft3.TabIndex = 3;
            this.labelMulesoft3.Text = "Processed cycle:";
            this.buttonUnSelect.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.buttonUnSelect.Location = new Point(0x8b, 15);
            this.buttonUnSelect.Margin = new Padding(4);
            this.buttonUnSelect.Name = "buttonUnSelect";
            this.buttonUnSelect.Size = new Size(100, 0x1c);
            this.buttonUnSelect.TabIndex = 0x15;
            this.buttonUnSelect.Text = "Unselect All";
            this.buttonUnSelect.UseVisualStyleBackColor = true;
            this.buttonUnSelect.Visible = false;
            this.buttonUnSelect.Click += new EventHandler(this.buttonUnSelect_Click);
            this.buttonSelectAll.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.buttonSelectAll.Location = new Point(0x10, 15);
            this.buttonSelectAll.Margin = new Padding(4);
            this.buttonSelectAll.Name = "buttonSelectAll";
            this.buttonSelectAll.Size = new Size(100, 0x1c);
            this.buttonSelectAll.TabIndex = 20;
            this.buttonSelectAll.Text = "Select All";
            this.buttonSelectAll.UseVisualStyleBackColor = true;
            this.buttonSelectAll.Visible = false;
            this.buttonSelectAll.Click += new EventHandler(this.buttonSelectAll_Click);
            this.labelTotalRecord3.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.labelTotalRecord3.AutoSize = true;
            this.labelTotalRecord3.Location = new Point(0x4ac, 11);
            this.labelTotalRecord3.Margin = new Padding(4, 0, 4, 0);
            this.labelTotalRecord3.Name = "labelTotalRecord3";
            this.labelTotalRecord3.Size = new Size(0x42, 0x11);
            this.labelTotalRecord3.TabIndex = 0x13;
            this.labelTotalRecord3.Text = "record(s)";
            this.labelTotalRecord3.TextAlign = ContentAlignment.MiddleRight;
            this.labelTotalRecord2.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.labelTotalRecord2.Location = new Point(0x447, 11);
            this.labelTotalRecord2.Margin = new Padding(4, 0, 4, 0);
            this.labelTotalRecord2.Name = "labelTotalRecord2";
            this.labelTotalRecord2.Size = new Size(0x5d, 0x10);
            this.labelTotalRecord2.TabIndex = 0x12;
            this.labelTotalRecord2.Text = "0";
            this.labelTotalRecord2.TextAlign = ContentAlignment.MiddleRight;
            this.labelTotalRecord.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.labelTotalRecord.AutoSize = true;
            this.labelTotalRecord.Location = new Point(0x3cd, 11);
            this.labelTotalRecord.Margin = new Padding(4, 0, 4, 0);
            this.labelTotalRecord.Name = "labelTotalRecord";
            this.labelTotalRecord.Size = new Size(0x71, 0x11);
            this.labelTotalRecord.TabIndex = 0x11;
            this.labelTotalRecord.Text = "Total of record : ";
            this.prgBar.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.prgBar.Location = new Point(0x3d1, 0x1f);
            this.prgBar.Margin = new Padding(4);
            this.prgBar.Name = "prgBar";
            this.prgBar.Size = new Size(0x119, 14);
            this.prgBar.TabIndex = 0x10;
            this.panel2.Controls.Add(this.dgTrans);
            this.panel2.Controls.Add(this.panel4X);
            this.panel2.Dock = DockStyle.Fill;
            this.panel2.Location = new Point(0, 0x53);
            this.panel2.Margin = new Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x4fb, 0x17b);
            this.panel2.TabIndex = 7;
            this.dgTrans.AllowUserToAddRows = false;
            this.dgTrans.AllowUserToDeleteRows = false;
            this.dgTrans.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgTrans.ColumnHeadersDefaultCellStyle = style;
            this.dgTrans.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgTrans.DefaultCellStyle = style2;
            this.dgTrans.Dock = DockStyle.Fill;
            this.dgTrans.Location = new Point(0, 0);
            this.dgTrans.Margin = new Padding(4);
            this.dgTrans.MultiSelect = false;
            this.dgTrans.Name = "dgTrans";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgTrans.RowHeadersDefaultCellStyle = style3;
            this.dgTrans.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgTrans.Size = new Size(0x4fb, 0x100);
            this.dgTrans.TabIndex = 8;
            this.dgTrans.CellClick += new DataGridViewCellEventHandler(this.dgTrans_CellClick_1);
            this.dgTrans.CellDoubleClick += new DataGridViewCellEventHandler(this.dgTrans_CellDoubleClick);
            this.dgTrans.CellValueChanged += new DataGridViewCellEventHandler(this.dgTrans_CellValueChanged);
            this.panel4X.Controls.Add(this.dgTransW);
            this.panel4X.Controls.Add(this.dgTransFlag);
            this.panel4X.Controls.Add(this.dgTransBC);
            this.panel4X.Dock = DockStyle.Bottom;
            this.panel4X.Location = new Point(0, 0x100);
            this.panel4X.Margin = new Padding(4);
            this.panel4X.Name = "panel4X";
            this.panel4X.Size = new Size(0x4fb, 0x7b);
            this.panel4X.TabIndex = 20;
            this.dgTransW.AllowUserToAddRows = false;
            this.dgTransW.AllowUserToDeleteRows = false;
            this.dgTransW.AllowUserToResizeColumns = false;
            this.dgTransW.AllowUserToResizeRows = false;
            this.dgTransW.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTransW.Dock = DockStyle.Fill;
            this.dgTransW.Location = new Point(0x120, 0);
            this.dgTransW.Margin = new Padding(4);
            this.dgTransW.Name = "dgTransW";
            this.dgTransW.Size = new Size(0x1ec, 0x7b);
            this.dgTransW.TabIndex = 0x13;
            this.dgTransFlag.AllowUserToAddRows = false;
            this.dgTransFlag.AllowUserToDeleteRows = false;
            this.dgTransFlag.AllowUserToResizeColumns = false;
            this.dgTransFlag.AllowUserToResizeRows = false;
            this.dgTransFlag.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTransFlag.Dock = DockStyle.Left;
            this.dgTransFlag.Location = new Point(0, 0);
            this.dgTransFlag.Margin = new Padding(4);
            this.dgTransFlag.Name = "dgTransFlag";
            this.dgTransFlag.Size = new Size(0x120, 0x7b);
            this.dgTransFlag.TabIndex = 0x12;
            this.dgTransFlag.CellContentClick += new DataGridViewCellEventHandler(this.dgTransFlag_CellContentClick);
            this.dgTransBC.AllowUserToAddRows = false;
            this.dgTransBC.AllowUserToDeleteRows = false;
            this.dgTransBC.AllowUserToResizeColumns = false;
            this.dgTransBC.AllowUserToResizeRows = false;
            this.dgTransBC.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTransBC.Dock = DockStyle.Right;
            this.dgTransBC.Location = new Point(780, 0);
            this.dgTransBC.Margin = new Padding(4);
            this.dgTransBC.Name = "dgTransBC";
            this.dgTransBC.Size = new Size(0x1ef, 0x7b);
            this.dgTransBC.TabIndex = 20;
            this.dgTransC.AllowUserToAddRows = false;
            this.dgTransC.AllowUserToDeleteRows = false;
            this.dgTransC.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTransC.Dock = DockStyle.Fill;
            this.dgTransC.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgTransC.Location = new Point(0, 0);
            this.dgTransC.Margin = new Padding(4);
            this.dgTransC.Name = "dgTransC";
            this.dgTransC.Size = new Size(0x1c1, 0x7b);
            this.dgTransC.TabIndex = 0x11;
            this.dgTransQC.AllowUserToAddRows = false;
            this.dgTransQC.AllowUserToDeleteRows = false;
            style4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style4.BackColor = SystemColors.Control;
            style4.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style4.ForeColor = SystemColors.WindowText;
            style4.SelectionBackColor = SystemColors.Highlight;
            style4.SelectionForeColor = SystemColors.HighlightText;
            style4.WrapMode = DataGridViewTriState.True;
            this.dgTransQC.ColumnHeadersDefaultCellStyle = style4;
            this.dgTransQC.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style5.BackColor = SystemColors.Window;
            style5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style5.ForeColor = SystemColors.ControlText;
            style5.SelectionBackColor = SystemColors.Highlight;
            style5.SelectionForeColor = SystemColors.HighlightText;
            style5.WrapMode = DataGridViewTriState.False;
            this.dgTransQC.DefaultCellStyle = style5;
            this.dgTransQC.Dock = DockStyle.Fill;
            this.dgTransQC.Location = new Point(0, 0);
            this.dgTransQC.Margin = new Padding(4);
            this.dgTransQC.Name = "dgTransQC";
            style6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style6.BackColor = SystemColors.Control;
            style6.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style6.ForeColor = SystemColors.WindowText;
            style6.SelectionBackColor = SystemColors.Highlight;
            style6.SelectionForeColor = SystemColors.HighlightText;
            style6.WrapMode = DataGridViewTriState.True;
            this.dgTransQC.RowHeadersDefaultCellStyle = style6;
            this.dgTransQC.Size = new Size(350, 0x7b);
            this.dgTransQC.TabIndex = 0x10;
            this.dgTransD.AllowUserToAddRows = false;
            this.dgTransD.AllowUserToDeleteRows = false;
            style7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style7.BackColor = SystemColors.Control;
            style7.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style7.ForeColor = SystemColors.WindowText;
            style7.SelectionBackColor = SystemColors.Highlight;
            style7.SelectionForeColor = SystemColors.HighlightText;
            style7.WrapMode = DataGridViewTriState.True;
            this.dgTransD.ColumnHeadersDefaultCellStyle = style7;
            this.dgTransD.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style8.BackColor = SystemColors.Window;
            style8.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style8.ForeColor = SystemColors.ControlText;
            style8.SelectionBackColor = SystemColors.Highlight;
            style8.SelectionForeColor = SystemColors.HighlightText;
            style8.WrapMode = DataGridViewTriState.False;
            this.dgTransD.DefaultCellStyle = style8;
            this.dgTransD.Dock = DockStyle.Fill;
            this.dgTransD.Location = new Point(0, 0);
            this.dgTransD.Margin = new Padding(4);
            this.dgTransD.Name = "dgTransD";
            style9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style9.BackColor = SystemColors.Control;
            style9.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style9.ForeColor = SystemColors.WindowText;
            style9.SelectionBackColor = SystemColors.Highlight;
            style9.SelectionForeColor = SystemColors.HighlightText;
            style9.WrapMode = DataGridViewTriState.True;
            this.dgTransD.RowHeadersDefaultCellStyle = style9;
            this.dgTransD.Size = new Size(0x1dc, 0x7b);
            this.dgTransD.TabIndex = 15;
            this.panelDetail.Controls.Add(this.panel6);
            this.panelDetail.Controls.Add(this.panel5);
            this.panelDetail.Controls.Add(this.panel4);
            this.panelDetail.Dock = DockStyle.Bottom;
            this.panelDetail.Location = new Point(0, 0x1ce);
            this.panelDetail.Margin = new Padding(4);
            this.panelDetail.Name = "panelDetail";
            this.panelDetail.Size = new Size(0x4fb, 0x7b);
            this.panelDetail.TabIndex = 0x13;
            this.panel6.Controls.Add(this.dgTransQC);
            this.panel6.Dock = DockStyle.Fill;
            this.panel6.Location = new Point(0x1dc, 0);
            this.panel6.Margin = new Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new Size(350, 0x7b);
            this.panel6.TabIndex = 2;
            this.panel5.Controls.Add(this.dgTransC);
            this.panel5.Dock = DockStyle.Right;
            this.panel5.Location = new Point(0x33a, 0);
            this.panel5.Margin = new Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new Size(0x1c1, 0x7b);
            this.panel5.TabIndex = 1;
            this.panel4.Controls.Add(this.dgTransD);
            this.panel4.Dock = DockStyle.Left;
            this.panel4.Location = new Point(0, 0);
            this.panel4.Margin = new Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new Size(0x1dc, 0x7b);
            this.panel4.TabIndex = 0;
            base.AutoScaleDimensions = new SizeF(8f, 16f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x4fb, 0x249);
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.panelDetail);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.Margin = new Padding(4);
            base.Name = "FormUploadZWB";
            base.ShowIcon = false;
            this.Text = "Form Upload";
            base.WindowState = FormWindowState.Maximized;
            base.Load += new EventHandler(this.FormUploadZWB_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelMulesoft.ResumeLayout(false);
            this.panelMulesoft.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((ISupportInitialize) this.dgTrans).EndInit();
            this.panel4X.ResumeLayout(false);
            ((ISupportInitialize) this.dgTransW).EndInit();
            ((ISupportInitialize) this.dgTransFlag).EndInit();
            ((ISupportInitialize) this.dgTransBC).EndInit();
            ((ISupportInitialize) this.dgTransC).EndInit();
            ((ISupportInitialize) this.dgTransQC).EndInit();
            ((ISupportInitialize) this.dgTransD).EndInit();
            this.panelDetail.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        public void initTable()
        {
            this.module = this.sapDest;
            this.type = "1";
            this.tbl_templateTrans = this.getTemplate(this.type);
            this.formatDG(this.dgTrans, this.tblTrans, this.tbl_templateTrans);
            this.type = "2";
            this.tbl_templateTransD = this.getTemplate(this.type);
            this.formatDG(this.dgTransD, this.tblTransD, this.tbl_templateTransD);
            this.type = "3";
            this.tbl_templateTransQC = this.getTemplate(this.type);
            this.formatDG(this.dgTransQC, this.tblTransQC, this.tbl_templateTransQC);
            this.type = "4";
            this.tbl_templateTransC = this.getTemplate(this.type);
            this.formatDG(this.dgTransC, this.tblTransC, this.tbl_templateTransC);
            this.type = "5";
            this.tbl_templateTransW_1 = this.getTemplate("5.1");
            this.tbl_templateTransW_2 = this.getTemplate("5.2");
            this.tbl_templateTransW_3 = this.getTemplate("5.3");
            this.formatDG(this.dgTransW, this.tblTransW, this.tbl_templateTransW_1);
            this.formatDG(this.dgTransW, this.tblTransW, this.tbl_templateTransW_2);
            this.formatDG(this.dgTransW, this.tblTransW, this.tbl_templateTransW_3);
            this.type = "6";
            this.tbl_templateTransBC = this.getTemplate(this.type);
            this.formatDG(this.dgTransBC, this.tblTransBC, this.tbl_templateTransBC);
            this.setReturnTable();
            this.fillTable();
            this.prgBar.Value = 0;
        }

        public void initTransFlag()
        {
            this.dgTransFlag.Columns.Clear();
            this.dgTransFlag.Rows.Clear();
            DataGridViewTextBoxColumn dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "WREF",
                HeaderText = "WREF"
            };
            this.dgTransFlag.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "EstateDiff",
                HeaderText = "EstateDiff"
            };
            this.dgTransFlag.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void mnUpd_Click(object sender, EventArgs e)
        {
            this.btnUpload();
        }

        private void repostMutuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (WBSAP.connect())
            {
                try
                {
                    this.dgvToTable(this.dgTrans, this.tblTrans);
                    this.dgvDetailToTable(this.dgTransQC, this.tblTrans, this.tblTransQC, "WREF", "TableQC");
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_TRX_QUALITY");
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD_Quality");
                    WBSAP.sendTable(this.tblTransQC);
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                    WBSAP.sendTable(this.tblTrans);
                    WBSAP.setImportReturn();
                    WBSAP.sendZWB();
                    string[] strArray = new string[3];
                    WBSAP.getAllResult(this.tblTrans, this.retTable, "WREF");
                    WBSAP.showReturn();
                    WBTable table = new WBTable();
                    int num = 0;
                    while (true)
                    {
                        if (num >= this.retTable.Rows.Count)
                        {
                            table.Dispose();
                            break;
                        }
                        DataRow row = this.retTable.Rows[num];
                        string str = row[0].ToString().Trim();
                        if (row[1].ToString() == "Y")
                        {
                            table.OpenTable("wb_transaction", "select uniq, posted, checksum from wb_transaction where ref ='" + str + "'", WBData.conn);
                            table.DR = table.DT.Rows[0];
                            this.logKey = table.DR["uniq"].ToString();
                            table.DR.BeginEdit();
                            table.DR["posted"] = "Y";
                            table.DR["checksum"] = table.Checksum(table.DR);
                            table.DR.EndEdit();
                            table.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload quality to " + this.zwbIDSYS };
                            Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                        }
                        num++;
                    }
                }
                catch (RfcInvalidParameterException exception)
                {
                    if (this.auto != 'Y')
                    {
                        MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (RfcCommunicationException exception2)
                {
                    if (this.auto != 'Y')
                    {
                        if (WBUser.UserLevel == "1")
                        {
                            MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                }
                catch (RfcBaseException exception3)
                {
                    if (this.auto != 'Y')
                    {
                        if (WBUser.UserLevel == "1")
                        {
                            MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                }
                catch (Exception exception4)
                {
                    if (this.auto != 'Y')
                    {
                        MessageBox.Show("Error " + exception4.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
        }

        public void selectAll()
        {
            if (this.dgTrans.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgTrans.Rows)
                {
                    row.Cells["select"].Value = true;
                }
            }
        }

        private void setCycle(int progress, int total)
        {
            this.labelMulesoftCycle.Text = progress + "/" + total;
            this.labelMulesoftCycle.Refresh();
            this.panelMulesoft.Refresh();
            this.panel1.Refresh();
        }

        private void setData(int progress, int total)
        {
            this.labelMulesoftData.Text = progress + "/" + total;
            this.labelMulesoftData.Refresh();
            this.panelMulesoft.Refresh();
            this.panel1.Refresh();
        }

        private void setMainTrans(int total)
        {
            this.labelMulesoft5.Text = "Total of main transaction: " + total;
            this.labelMulesoft5.Refresh();
            this.panelMulesoft.Refresh();
            this.panel1.Refresh();
        }

        private void setReturnTable()
        {
            this.retTable.Columns.Clear();
            DataColumn column = new DataColumn {
                ColumnName = "Ref1"
            };
            this.retTable.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Stts2"
            };
            this.retTable.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Rmrk3"
            };
            this.retTable.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Rpst3"
            };
            this.retTable.Columns.Add(column);
            column.Dispose();
        }

        private void uploadIDSYS()
        {
            bool flag = false;
            if (this.auto == 'Y')
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgTrans.Rows)
                {
                    row.Cells["select"].Value = true;
                }
            }
            try
            {
                WBIDSYSIntegrator integrator = new WBIDSYSIntegrator();
                string url = integrator.getURL("IDSYS_UPLOAD");
                if (url != "")
                {
                    bool err = false;
                    this.dgvToTable(this.dgTrans, this.tblTrans);
                    string str2 = this.AddToList(this.tblTrans);
                    this.retTable.Clear();
                    string timestamp = GetTimestamp(DateTime.Now);
                    string[] textArray1 = new string[] { "{authKey : '", WBEncryption.Encrypt(timestamp), "',data: [", str2, "]}" };
                    Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                    string str5 = WBEncryption.Decrypt("Sy3UNByCgqldxZbrIyyidA==");
                    dictionary = integrator.uploadDataIDSYS(url, string.Concat(textArray1), out err);
                    List<string> list = new List<string>();
                    string str6 = "";
                    if (!err)
                    {
                        if (dictionary.Count <= 0)
                        {
                            MessageBox.Show(Resource.IDSY_Adopt_Failled, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            int num = 0;
                            WBTable table = new WBTable();
                            flag = false;
                            foreach (Dictionary<string, string> dictionary2 in dictionary["data"])
                            {
                                string str7 = dictionary2["Ref"].ToString().Trim();
                                if (dictionary2.Count > 0)
                                {
                                    if (dictionary2["Status"].ToString() != "ERROR")
                                    {
                                        num++;
                                        flag = true;
                                        str6 = "Y";
                                        table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str7 + "'", WBData.conn);
                                        table.DR = table.DT.Rows[0];
                                        this.logKey = table.DR["uniq"].ToString();
                                        table.DR.BeginEdit();
                                        table.DR["posted"] = "Y";
                                        table.DR["reposted"] = (dictionary2["Posted"].ToString() != "Y") ? "N" : "Y";
                                        table.DR["sync_return"] = "";
                                        table.DR["lastUpload"] = DateTime.Now;
                                        table.DR["lastMulesoftReturnID"] = DBNull.Value;
                                        table.DR["checksum"] = table.Checksum(table.DR);
                                        table.DR.EndEdit();
                                        table.Save();
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to " + this.zwbIDSYS };
                                        Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                    }
                                    else
                                    {
                                        str6 = "X";
                                        flag = true;
                                        if (str7 != "")
                                        {
                                            table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str7 + "'", WBData.conn);
                                            table.DR = table.DT.Rows[0];
                                            if ((table.DR["posted"].ToString() != "Y") || (table.DR["reposted"].ToString() != "Y"))
                                            {
                                                this.logKey = table.DR["uniq"].ToString();
                                                table.DR.BeginEdit();
                                                table.DR["posted"] = "N";
                                                table.DR["reposted"] = (dictionary2["Posted"].ToString() != "Y") ? "N" : "Y";
                                                table.DR["sync_return"] = dictionary2["Remarks"].ToString();
                                                table.DR["lastUpload"] = DateTime.Now;
                                                table.DR["lastMulesoftReturnID"] = DBNull.Value;
                                                table.DR["checksum"] = table.Checksum(table.DR);
                                                table.DR.EndEdit();
                                                table.Save();
                                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to " + this.zwbIDSYS };
                                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                            }
                                        }
                                    }
                                    object[] values = new object[] { dictionary2["Ref"].ToString(), str6, dictionary2["Remarks"].ToString(), dictionary2["Posted"].ToString() };
                                    this.retTable.Rows.Add(values);
                                }
                            }
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    return;
                }
                FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                    aTable = this.retTable
                };
                return2.ShowDialog();
                return2.Dispose();
                Cursor.Current = Cursors.Default;
                if (flag)
                {
                    this.fillTable();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error " + exception.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void uploadWithMulesoft()
        {
            WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
            List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
            int num3 = 0;
            while (true)
            {
                if (num3 >= this.dgTrans.RowCount)
                {
                    if (sentTable.Count < 1)
                    {
                        sentTable.Add(new Dictionary<string, string>());
                    }
                    List<Dictionary<string, string>> list2 = new List<Dictionary<string, string>>();
                    int num5 = 0;
                    while (true)
                    {
                        if (num5 >= this.dgTransD.RowCount)
                        {
                            if (list2.Count < 1)
                            {
                                list2.Add(new Dictionary<string, string>());
                            }
                            List<Dictionary<string, string>> list3 = new List<Dictionary<string, string>>();
                            int num7 = 0;
                            while (true)
                            {
                                if (num7 >= this.dgTransQC.RowCount)
                                {
                                    if (list3.Count < 1)
                                    {
                                        list3.Add(new Dictionary<string, string>());
                                    }
                                    List<Dictionary<string, string>> list4 = new List<Dictionary<string, string>>();
                                    int num9 = 0;
                                    while (true)
                                    {
                                        if (num9 >= this.dgTransC.RowCount)
                                        {
                                            if (list4.Count < 1)
                                            {
                                                list4.Add(new Dictionary<string, string>());
                                            }
                                            List<Dictionary<string, string>> list5 = new List<Dictionary<string, string>>();
                                            int num11 = 0;
                                            while (true)
                                            {
                                                if (num11 >= this.dgTransW.RowCount)
                                                {
                                                    if (list5.Count < 1)
                                                    {
                                                        list5.Add(new Dictionary<string, string>());
                                                    }
                                                    this.get_important_field();
                                                    List<Dictionary<string, string>> list6 = new List<Dictionary<string, string>>();
                                                    int num13 = 0;
                                                    while (true)
                                                    {
                                                        if (num13 >= this.tblField.Rows.Count)
                                                        {
                                                            if (list6.Count < 1)
                                                            {
                                                                list6.Add(new Dictionary<string, string>());
                                                            }
                                                            List<Dictionary<string, string>> list7 = new List<Dictionary<string, string>>();
                                                            int num15 = 0;
                                                            while (true)
                                                            {
                                                                if (num15 >= this.dgTransBC.RowCount)
                                                                {
                                                                    if (list7.Count < 1)
                                                                    {
                                                                        list7.Add(new Dictionary<string, string>());
                                                                    }
                                                                    integrator.prepareTable();
                                                                    integrator.addTable(sentTable, "I_RECORD");
                                                                    integrator.addTable(list2, "I_RECORD_D");
                                                                    integrator.addTable(list3, "I_RECORD_QUALITY");
                                                                    integrator.addTable(list4, "I_SORT_COPRA");
                                                                    integrator.addTable(list5, "I_RECORD_W");
                                                                    integrator.addTable(list6, "I_RECORD_F");
                                                                    integrator.addTable(list7, "I_RECORD_BC");
                                                                    string url = integrator.getURL("ZRFC_DNET_WB_TRX");
                                                                    if (url != "")
                                                                    {
                                                                        bool err = false;
                                                                        string[] resultHeaderName = new string[] { "I_RECORD" };
                                                                        Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                                                                        this.retTable.Clear();
                                                                        foreach (Dictionary<string, string> dictionary9 in dictionary["I_RECORD"])
                                                                        {
                                                                            object[] values = new object[] { dictionary9["WREF"].ToString(), dictionary9["STAT"].ToString(), dictionary9["RFC_TEXT"].ToString(), dictionary9["RESTAT"].ToString() };
                                                                            this.retTable.Rows.Add(values);
                                                                        }
                                                                        int num = 0;
                                                                        int num2 = 0;
                                                                        WBTable table = new WBTable();
                                                                        bool flag2 = false;
                                                                        int num17 = 0;
                                                                        while (true)
                                                                        {
                                                                            if (num17 >= this.retTable.Rows.Count)
                                                                            {
                                                                                table.Dispose();
                                                                                this.UpdateStart = DateTime.Now;
                                                                                FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                                                                    aTable = this.retTable
                                                                                };
                                                                                return2.ShowDialog();
                                                                                return2.Dispose();
                                                                                Cursor.Current = Cursors.Default;
                                                                                if (flag2)
                                                                                {
                                                                                    this.fillTable();
                                                                                }
                                                                                break;
                                                                            }
                                                                            DataRow row = this.retTable.Rows[num17];
                                                                            string str2 = row[0].ToString().Trim();
                                                                            if (row[1].ToString() == "Y")
                                                                            {
                                                                                num++;
                                                                                flag2 = true;
                                                                                table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str2 + "'", WBData.conn);
                                                                                table.DR = table.DT.Rows[0];
                                                                                this.logKey = table.DR["uniq"].ToString();
                                                                                table.DR.BeginEdit();
                                                                                table.DR["posted"] = "Y";
                                                                                table.DR["reposted"] = (row[3].ToString() != "Y") ? "N" : "Y";
                                                                                table.DR["sync_return"] = "";
                                                                                table.DR["lastUpload"] = DateTime.Now;
                                                                                table.DR["lastMulesoftReturnID"] = DBNull.Value;
                                                                                table.DR["checksum"] = table.Checksum(table.DR);
                                                                                table.DR.EndEdit();
                                                                                table.Save();
                                                                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to " + this.zwbIDSYS };
                                                                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                                                            }
                                                                            else
                                                                            {
                                                                                flag2 = true;
                                                                                table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str2 + "'", WBData.conn);
                                                                                table.DR = table.DT.Rows[0];
                                                                                if ((table.DR["posted"].ToString() != "Y") || (table.DR["reposted"].ToString() != "Y"))
                                                                                {
                                                                                    this.logKey = table.DR["uniq"].ToString();
                                                                                    table.DR.BeginEdit();
                                                                                    table.DR["posted"] = "N";
                                                                                    table.DR["reposted"] = (row[3].ToString() != "Y") ? "N" : "Y";
                                                                                    table.DR["sync_return"] = row[2].ToString();
                                                                                    table.DR["lastUpload"] = DateTime.Now;
                                                                                    table.DR["lastMulesoftReturnID"] = DBNull.Value;
                                                                                    table.DR["checksum"] = table.Checksum(table.DR);
                                                                                    table.DR.EndEdit();
                                                                                    table.Save();
                                                                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to " + this.zwbIDSYS };
                                                                                    Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                                                                }
                                                                            }
                                                                            num2++;
                                                                            flag2 = true;
                                                                            table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str2 + "'", WBData.conn);
                                                                            table.DR = table.DT.Rows[0];
                                                                            num17++;
                                                                        }
                                                                    }
                                                                    return;
                                                                }
                                                                Dictionary<string, string> dictionary8 = new Dictionary<string, string>();
                                                                int num16 = 0;
                                                                while (true)
                                                                {
                                                                    if (num16 >= (this.dgTransBC.ColumnCount - 1))
                                                                    {
                                                                        if (dictionary8.Count > 0)
                                                                        {
                                                                            list7.Add(dictionary8);
                                                                        }
                                                                        num15++;
                                                                        break;
                                                                    }
                                                                    dictionary8.Add(this.dgTransBC.Columns[num16].HeaderText, this.dgTransBC.Rows[num15].Cells[num16].Value.ToString());
                                                                    num16++;
                                                                }
                                                            }
                                                        }
                                                        Dictionary<string, string> dictionary7 = new Dictionary<string, string>();
                                                        int index = 0;
                                                        while (true)
                                                        {
                                                            if (index >= this.tblField.Columns.Count)
                                                            {
                                                                list6.Add(dictionary7);
                                                                num13++;
                                                                break;
                                                            }
                                                            dictionary7.Add(this.tblField.Columns[index].ColumnName, this.tblField.Rows[num13].ItemArray[index].ToString());
                                                            index++;
                                                        }
                                                    }
                                                }
                                                Dictionary<string, string> dictionary6 = new Dictionary<string, string>();
                                                int num12 = 1;
                                                while (true)
                                                {
                                                    if (num12 >= this.dgTransW.ColumnCount)
                                                    {
                                                        if (dictionary6.Count > 0)
                                                        {
                                                            list5.Add(dictionary6);
                                                        }
                                                        num11++;
                                                        break;
                                                    }
                                                    dictionary6.Add(this.dgTransW.Columns[num12].HeaderText, this.dgTransW.Rows[num11].Cells[num12].Value.ToString());
                                                    num12++;
                                                }
                                            }
                                        }
                                        Dictionary<string, string> dictionary5 = new Dictionary<string, string>();
                                        int num10 = 1;
                                        while (true)
                                        {
                                            if (num10 >= this.dgTransC.ColumnCount)
                                            {
                                                if (dictionary5.Count > 0)
                                                {
                                                    list4.Add(dictionary5);
                                                }
                                                num9++;
                                                break;
                                            }
                                            dictionary5.Add(this.dgTransC.Columns[num10].HeaderText, this.dgTransC.Rows[num9].Cells[num10].Value.ToString());
                                            num10++;
                                        }
                                    }
                                }
                                Dictionary<string, string> dictionary4 = new Dictionary<string, string>();
                                int num8 = 0;
                                while (true)
                                {
                                    if (num8 >= (this.dgTransQC.ColumnCount - 1))
                                    {
                                        if (dictionary4.Count > 0)
                                        {
                                            list3.Add(dictionary4);
                                        }
                                        num7++;
                                        break;
                                    }
                                    dictionary4.Add(this.dgTransQC.Columns[num8].HeaderText, this.dgTransQC.Rows[num7].Cells[num8].Value.ToString());
                                    num8++;
                                }
                            }
                        }
                        Dictionary<string, string> dictionary3 = new Dictionary<string, string>();
                        int num6 = 0;
                        while (true)
                        {
                            if (num6 >= (this.dgTransD.ColumnCount - 1))
                            {
                                if (dictionary3.Count > 0)
                                {
                                    list2.Add(dictionary3);
                                }
                                num5++;
                                break;
                            }
                            dictionary3.Add(this.dgTransD.Columns[num6].HeaderText, this.dgTransD.Rows[num5].Cells[num6].Value.ToString());
                            num6++;
                        }
                    }
                }
                Dictionary<string, string> item = new Dictionary<string, string>();
                int num4 = 1;
                while (true)
                {
                    if (num4 >= (this.dgTrans.ColumnCount - 1))
                    {
                        if (item.Count > 0)
                        {
                            sentTable.Add(item);
                        }
                        num3++;
                        break;
                    }
                    item.Add(this.dgTrans.Columns[num4].HeaderText, this.dgTrans.Rows[num3].Cells[num4].Value.ToString());
                    num4++;
                }
            }
        }

        private void uploadWithMulesoftperBatch()
        {
            DataRow[] rowArray = this.tbl_transaction.DT.Select(" (split IS NULL OR split = 'Y' OR split = 'N') AND zAuto = 'N'");
            string[] refNo = new string[Constant.TRANSACTION_UPLOADED_PER_BATCH];
            WBTable table = new WBTable();
            bool flag = false;
            bool err = false;
            int num = 0;
            string str2 = "";
            DataTable table2 = new DataTable();
            table2.Columns.Clear();
            DataColumn column = new DataColumn {
                ColumnName = "Ref1"
            };
            table2.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Stts2"
            };
            table2.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Rmrk3"
            };
            table2.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Rpst3"
            };
            table2.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "MsgID"
            };
            table2.Columns.Add(column);
            column.Dispose();
            int total = Convert.ToInt32(Math.Ceiling((double) ((rowArray.Length * 1.0) / ((double) Constant.TRANSACTION_UPLOADED_PER_BATCH))));
            this.setMainTrans((rowArray == null) ? 0 : rowArray.Length);
            this.setCycle(0, total);
            int progress = 0;
            int num4 = 0;
            int num5 = 0;
            int index = 0;
            while (true)
            {
                if (index >= rowArray.Length)
                {
                    break;
                }
                refNo[index % Constant.TRANSACTION_UPLOADED_PER_BATCH] = rowArray[index]["REF"].ToString();
                if (((index % Constant.TRANSACTION_UPLOADED_PER_BATCH) == (Constant.TRANSACTION_UPLOADED_PER_BATCH - 1)) || ((index == (rowArray.Length - 1)) && ((index % Constant.TRANSACTION_UPLOADED_PER_BATCH) != (Constant.TRANSACTION_UPLOADED_PER_BATCH - 1))))
                {
                    progress++;
                    this.setCycle(progress, total);
                    WBMulesoftIntegrator integrator = new WBMulesoftIntegrator {
                        auto = (this.auto == 'Y') ? "Y" : "N"
                    };
                    DataTable dt = new DataTable();
                    dt = this.dgvToPartialDataTable(this.dgTrans, dt, refNo);
                    List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
                    int num8 = 0;
                    while (true)
                    {
                        if (num8 < dt.Rows.Count)
                        {
                            Dictionary<string, string> item = new Dictionary<string, string>();
                            int num9 = 1;
                            while (true)
                            {
                                if (num9 >= (dt.Columns.Count - 1))
                                {
                                    if (item.Count > 0)
                                    {
                                        sentTable.Add(item);
                                    }
                                    num8++;
                                    break;
                                }
                                item.Add(dt.Columns[num9].ColumnName, dt.Rows[num8][num9].ToString());
                                num9++;
                            }
                            continue;
                        }
                        if (sentTable.Count < 1)
                        {
                            sentTable.Add(new Dictionary<string, string>());
                        }
                        DataTable table4 = new DataTable();
                        table4 = this.dgvToPartialDataTable(this.dgTransD, table4, refNo);
                        List<Dictionary<string, string>> list2 = new List<Dictionary<string, string>>();
                        int num10 = 0;
                        while (true)
                        {
                            if (num10 < table4.Rows.Count)
                            {
                                Dictionary<string, string> item = new Dictionary<string, string>();
                                int num11 = 0;
                                while (true)
                                {
                                    if (num11 >= (table4.Columns.Count - 1))
                                    {
                                        if (item.Count > 0)
                                        {
                                            list2.Add(item);
                                            num4++;
                                            num5++;
                                            this.setData(num4, Convert.ToInt32(this.labelTotalRecord2.Text));
                                        }
                                        num10++;
                                        break;
                                    }
                                    item.Add(table4.Columns[num11].ColumnName, table4.Rows[num10][num11].ToString());
                                    num11++;
                                }
                                continue;
                            }
                            if (list2.Count < 1)
                            {
                                list2.Add(new Dictionary<string, string>());
                            }
                            DataTable table5 = new DataTable();
                            table5 = this.dgvToPartialDataTable(this.dgTransQC, table5, refNo);
                            List<Dictionary<string, string>> list3 = new List<Dictionary<string, string>>();
                            int num12 = 0;
                            while (true)
                            {
                                if (num12 < table5.Rows.Count)
                                {
                                    Dictionary<string, string> item = new Dictionary<string, string>();
                                    int num13 = 0;
                                    while (true)
                                    {
                                        if (num13 >= (table5.Columns.Count - 1))
                                        {
                                            if (item.Count > 0)
                                            {
                                                list3.Add(item);
                                            }
                                            num12++;
                                            break;
                                        }
                                        item.Add(table5.Columns[num13].ColumnName, table5.Rows[num12][num13].ToString());
                                        num13++;
                                    }
                                    continue;
                                }
                                if (list3.Count < 1)
                                {
                                    list3.Add(new Dictionary<string, string>());
                                }
                                DataTable table6 = new DataTable();
                                table6 = this.dgvToPartialDataTable(this.dgTransC, table6, refNo);
                                List<Dictionary<string, string>> list4 = new List<Dictionary<string, string>>();
                                int num14 = 0;
                                while (true)
                                {
                                    if (num14 < table6.Rows.Count)
                                    {
                                        Dictionary<string, string> item = new Dictionary<string, string>();
                                        int num15 = 1;
                                        while (true)
                                        {
                                            if (num15 >= table6.Columns.Count)
                                            {
                                                if (item.Count > 0)
                                                {
                                                    list4.Add(item);
                                                }
                                                num14++;
                                                break;
                                            }
                                            item.Add(table6.Columns[num15].ColumnName, table6.Rows[num14][num15].ToString());
                                            num15++;
                                        }
                                        continue;
                                    }
                                    if (list4.Count < 1)
                                    {
                                        list4.Add(new Dictionary<string, string>());
                                    }
                                    DataTable table7 = new DataTable();
                                    table7 = this.dgvToPartialDataTable(this.dgTransW, table7, refNo);
                                    List<Dictionary<string, string>> list5 = new List<Dictionary<string, string>>();
                                    int num16 = 0;
                                    while (true)
                                    {
                                        if (num16 < table7.Rows.Count)
                                        {
                                            Dictionary<string, string> item = new Dictionary<string, string>();
                                            int num17 = 1;
                                            while (true)
                                            {
                                                if (num17 >= table7.Columns.Count)
                                                {
                                                    if (item.Count > 0)
                                                    {
                                                        list5.Add(item);
                                                    }
                                                    num16++;
                                                    break;
                                                }
                                                item.Add(table7.Columns[num17].ColumnName, table7.Rows[num16][num17].ToString());
                                                num17++;
                                            }
                                            continue;
                                        }
                                        if (list5.Count < 1)
                                        {
                                            list5.Add(new Dictionary<string, string>());
                                        }
                                        this.get_important_field();
                                        List<Dictionary<string, string>> list6 = new List<Dictionary<string, string>>();
                                        int num18 = 0;
                                        while (true)
                                        {
                                            if (num18 < this.tblField.Rows.Count)
                                            {
                                                Dictionary<string, string> item = new Dictionary<string, string>();
                                                int num19 = 0;
                                                while (true)
                                                {
                                                    if (num19 >= this.tblField.Columns.Count)
                                                    {
                                                        list6.Add(item);
                                                        num18++;
                                                        break;
                                                    }
                                                    item.Add(this.tblField.Columns[num19].ColumnName, this.tblField.Rows[num18].ItemArray[num19].ToString());
                                                    num19++;
                                                }
                                                continue;
                                            }
                                            if (list6.Count < 1)
                                            {
                                                list6.Add(new Dictionary<string, string>());
                                            }
                                            DataTable table8 = new DataTable();
                                            table8 = this.dgvToPartialDataTable(this.dgTransBC, table8, refNo);
                                            List<Dictionary<string, string>> list7 = new List<Dictionary<string, string>>();
                                            int num20 = 0;
                                            while (true)
                                            {
                                                if (num20 < table8.Rows.Count)
                                                {
                                                    Dictionary<string, string> item = new Dictionary<string, string>();
                                                    int num21 = 0;
                                                    while (true)
                                                    {
                                                        if (num21 >= (table8.Columns.Count - 1))
                                                        {
                                                            if (item.Count > 0)
                                                            {
                                                                list3.Add(item);
                                                            }
                                                            num20++;
                                                            break;
                                                        }
                                                        item.Add(table5.Columns[num21].ColumnName, table5.Rows[num20][num21].ToString());
                                                        num21++;
                                                    }
                                                    continue;
                                                }
                                                if (list7.Count < 1)
                                                {
                                                    list7.Add(new Dictionary<string, string>());
                                                }
                                                integrator.prepareTable();
                                                integrator.addTable(sentTable, "I_RECORD");
                                                integrator.addTable(list2, "I_RECORD_D");
                                                integrator.addTable(list3, "I_RECORD_QUALITY");
                                                integrator.addTable(list4, "I_SORT_COPRA");
                                                integrator.addTable(list5, "I_RECORD_W");
                                                integrator.addTable(list6, "I_RECORD_F");
                                                integrator.addTable(list3, "I_RECORD_BC");
                                                Stopwatch stopwatch = Stopwatch.StartNew();
                                                string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                                                Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(integrator.getURL("ZRFC_DNET_WB_TRX"), resultHeaderName, out err);
                                                stopwatch.Stop();
                                                long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                                                object[] objArray1 = new object[12];
                                                objArray1[0] = str2;
                                                objArray1[1] = "BATCH ";
                                                objArray1[2] = progress;
                                                objArray1[3] = "<br>Total of uploaded transaction:  ";
                                                objArray1[4] = num5;
                                                objArray1[5] = " transactions.<br>Time for sending data and waiting for response:  ";
                                                objArray1[6] = elapsedMilliseconds;
                                                objArray1[7] = " miliseconds.<br>Sent status: ";
                                                objArray1[8] = err ? "ERROR" : ((dictionary["ERRORS"].Count > 0) ? "ERROR" : "SUCCESS");
                                                object[] local1 = objArray1;
                                                local1[9] = "<br>Error message: ";
                                                local1[10] = err ? integrator.mulesoftErr : ((dictionary["ERRORS"].Count > 0) ? ("Error from SAP : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString()) : "-");
                                                object[] local2 = local1;
                                                local2[11] = "<br><br>";
                                                str2 = string.Concat(local2);
                                                if (err)
                                                {
                                                    flag = table2.Rows.Count > 0;
                                                }
                                                else
                                                {
                                                    if (dictionary["ERRORS"].Count <= 0)
                                                    {
                                                        int num22 = 0;
                                                        string str4 = dictionary["MESSAGE_ID"][0]["VALUE"].ToString();
                                                        foreach (Dictionary<string, string> dictionary9 in dictionary["I_RECORD"])
                                                        {
                                                            object[] values = new object[] { dictionary9["WREF"].ToString(), dictionary9["STAT"].ToString(), dictionary9["RFC_TEXT"].ToString(), dictionary9["RESTAT"].ToString(), str4 };
                                                            table2.Rows.Add(values);
                                                            num22++;
                                                        }
                                                        int num23 = num;
                                                        while (true)
                                                        {
                                                            if (num23 >= table2.Rows.Count)
                                                            {
                                                                num += num22;
                                                                int num24 = 0;
                                                                while (true)
                                                                {
                                                                    if (num24 >= refNo.Length)
                                                                    {
                                                                        num5 = 0;
                                                                        break;
                                                                    }
                                                                    refNo[num24] = null;
                                                                    num24++;
                                                                }
                                                                break;
                                                            }
                                                            DataRow row = table2.Rows[num23];
                                                            string str = row[0].ToString().Trim();
                                                            if (row[1].ToString() == "Y")
                                                            {
                                                                flag = true;
                                                                table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                                                table.DR = table.DT.Rows[0];
                                                                this.logKey = table.DR["uniq"].ToString();
                                                                table.DR.BeginEdit();
                                                                table.DR["posted"] = "Y";
                                                                table.DR["reposted"] = (row[3].ToString() != "Y") ? "N" : "Y";
                                                                table.DR["sync_return"] = "";
                                                                table.DR["lastUpload"] = DateTime.Now;
                                                                table.DR["lastMulesoftReturnID"] = row[4].ToString();
                                                                table.DR["checksum"] = table.Checksum(table.DR);
                                                                table.DR.EndEdit();
                                                                table.Save();
                                                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to " + this.zwbIDSYS };
                                                                Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                                            }
                                                            else
                                                            {
                                                                flag = true;
                                                                table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                                                table.DR = table.DT.Rows[0];
                                                                if ((table.DR["posted"].ToString() != "Y") || (table.DR["reposted"].ToString() != "Y"))
                                                                {
                                                                    this.logKey = table.DR["uniq"].ToString();
                                                                    table.DR.BeginEdit();
                                                                    table.DR["posted"] = "N";
                                                                    table.DR["reposted"] = (row[3].ToString() != "Y") ? "N" : "Y";
                                                                    table.DR["sync_return"] = row[2].ToString();
                                                                    table.DR["lastUpload"] = DateTime.Now;
                                                                    table.DR["lastMulesoftReturnID"] = row[4].ToString();
                                                                    table.DR["checksum"] = table.Checksum(table.DR);
                                                                    table.DR.EndEdit();
                                                                    table.Save();
                                                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to " + this.zwbIDSYS };
                                                                    Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                                                }
                                                            }
                                                            flag = true;
                                                            num23++;
                                                        }
                                                        break;
                                                    }
                                                    if (this.auto != 'Y')
                                                    {
                                                        MessageBox.Show("Error from " + this.sapIDSYS + " : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                    }
                                                    flag = table2.Rows.Count > 0;
                                                }
                                                break;
                                            }
                                            break;
                                        }
                                        break;
                                    }
                                    break;
                                }
                                break;
                            }
                            break;
                        }
                        break;
                    }
                }
                index++;
            }
            WBMail mail = new WBMail();
            string[] textArray6 = new string[] { "UPLOAD TO ", this.zwbIDSYS, " WITH MULESOFT FOR ", WBData.sCoyCode, "  ", WBData.sLocCode };
            mail.Subject = string.Concat(textArray6);
            mail.To = "amelia.febriani@id.wilmar-intl.com";
            mail.CC = "jefi.sun@id.wilmar-intl.com";
            object[] objArray3 = new object[11];
            object[] objArray4 = new object[11];
            objArray4[0] = (this.auto == 'Y') ? "UPLOAD AUTOMATICALLY BY SYSTEM" : "UPLOAD MANUALLY";
            object[] local3 = objArray4;
            local3[1] = "<br><br>Total of all transactions: ";
            local3[2] = this.labelTotalRecord2.Text;
            local3[3] = "<br>Total of main transactions: ";
            local3[4] = rowArray.Length;
            local3[5] = "<br><br>Total of transactions per batch: ";
            local3[6] = Constant.TRANSACTION_UPLOADED_PER_BATCH;
            local3[7] = "<br>Total of batch: ";
            local3[8] = total;
            local3[9] = "<br><br>";
            local3[10] = str2;
            mail.Body = string.Concat(local3);
            mail.SendMail();
            mail.Dispose();
            if (table2.Rows.Count > 0)
            {
                FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                    aTable = table2,
                    sortBy = "DESC"
                };
                if (this.auto != 'Y')
                {
                    return2.ShowDialog();
                }
                return2.Dispose();
            }
            Cursor.Current = Cursors.Default;
            if (flag)
            {
                this.fillTable();
            }
        }

        private void uploadZWB()
        {
            if (this.auto == 'Y')
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgTrans.Rows)
                {
                    row.Cells["select"].Value = true;
                }
            }
            if (WBSAP.connect())
            {
                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    if (WBSetting.activeMulesoftIntegration)
                    {
                        this.uploadWithMulesoftperBatch();
                    }
                    else
                    {
                        this.dgvToTable(this.dgTrans, this.tblTrans);
                        this.dgvDetailToTable(this.dgTransD, this.tblTrans, this.tblTransD, "WREF", "TableD");
                        this.dgvDetailToTable(this.dgTransQC, this.tblTrans, this.tblTransQC, "WREF", "TableQC");
                        this.dgvDetailToTable(this.dgTransC, this.tblTrans, this.tblTransC, "WREF", "TableC");
                        this.dgvDetailToTable(this.dgTransW, this.tblTrans, this.tblTransW, "WREF", "TableW");
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_TRX ");
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD_D");
                        WBSAP.sendTable(this.tblTransD);
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD_QUALITY");
                        WBSAP.sendTable(this.tblTransQC);
                        if (WBSAP.rfcTable.RowCount != this.QCCount)
                        {
                            object[] objArray1 = new object[] { "jumlah Row yang diterima  ", this.sapIDSYS, WBSAP.rfcTable.RowCount, " with capacity ", WBSAP.rfcTable.Capacity, " different from table row ", this.QCCount };
                            MessageBox.Show(string.Concat(objArray1) ?? "");
                        }
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_SORT_COPRA");
                        WBSAP.sendTable(this.tblTransC);
                        if (this.count_trans_w_template > 0)
                        {
                            WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD_W");
                            WBSAP.sendTable(this.tblTransW);
                        }
                        this.get_important_field();
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD_F");
                        WBSAP.sendTable(this.tblField);
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                        WBSAP.sendTable(this.tblTrans);
                        this.uploadstart = DateTime.Now;
                        WBSAP.sendZWB();
                        this.uploadFinish = DateTime.Now;
                        TimeSpan span = this.uploadFinish.Subtract(this.uploadstart);
                        string[] strArray = new string[3];
                        WBSAP.setImportReturn();
                        int num3 = 0;
                        while (true)
                        {
                            if (num3 >= this.dgTransFlag.Rows.Count)
                            {
                                WBSAP.getTransResult(this.tblTrans, this.retTable, "WREF");
                                int num = 0;
                                int num2 = 0;
                                WBTable table = new WBTable();
                                bool flag4 = false;
                                string str2 = "";
                                str2 = ((("<table border=1 rules=all cellpadding=3 cellspacing=-1>" + "<tr class='bd'>") + "<td nowrap>No</td>" + "<td nowrap>Ref</td>") + "<td nowrap>Posted</td>" + "<td nowrap>Reposted</td>") + "<td nowrap>Result</td>" + "</tr'>";
                                int num4 = 0;
                                while (true)
                                {
                                    if (num4 >= this.retTable.Rows.Count)
                                    {
                                        str2 = str2 + "</table>" + "<br><br>";
                                        table.Dispose();
                                        this.UpdateFinish = DateTime.Now;
                                        TimeSpan span2 = this.UpdateFinish.Subtract(this.UpdateStart);
                                        if (this.auto != 'Y')
                                        {
                                            WBSAP.showReturn();
                                        }
                                        if (flag4)
                                        {
                                            this.fillTable();
                                        }
                                        if (((this.auto == 'Y') && (num2 > 0)) && (num2 == this.uploadtrx))
                                        {
                                            WBMail mail = new WBMail();
                                            string[] textArray6 = new string[9];
                                            textArray6[0] = "FAIL UPLOAD TO ";
                                            textArray6[1] = this.sapIDSYS;
                                            textArray6[2] = this.sapDest;
                                            textArray6[3] = " ";
                                            textArray6[4] = WBData.sCoyCode;
                                            textArray6[5] = "  ";
                                            textArray6[6] = WBData.sLocCode;
                                            textArray6[7] = "/";
                                            textArray6[8] = WBData.sLocName;
                                            mail.Subject = string.Concat(textArray6);
                                            mail.To = "Juliana.susanto@ID.wilmar-intl.com";
                                            mail.CC = "Jefi.Sun@id.wilmar-intl.com";
                                            object[] objArray2 = new object[0x13];
                                            objArray2[0] = this.sapIDSYS;
                                            objArray2[1] = " UPLOAD TIME ";
                                            objArray2[2] = this.uploadtrx;
                                            objArray2[3] = " TRX      = ";
                                            objArray2[4] = span.TotalMinutes;
                                            objArray2[5] = " Minute(s)<br>WB.NET UPDATE TIME ";
                                            objArray2[6] = this.uploadtrx;
                                            objArray2[7] = " TRX   = ";
                                            objArray2[8] = span2.TotalMinutes;
                                            objArray2[9] = " Minute(s)<br>TOTAL TIME REQUIRED ";
                                            objArray2[10] = this.uploadtrx;
                                            objArray2[11] = "TRX  = ";
                                            objArray2[12] = (span + span2).TotalMinutes;
                                            objArray2[13] = " Minute(s)<br><br> SUCCESS TRX = ";
                                            objArray2[14] = num;
                                            objArray2[15] = "<br> FAIL TRX    = ";
                                            objArray2[0x10] = num2;
                                            objArray2[0x11] = "<br><br><br>";
                                            objArray2[0x12] = str2;
                                            mail.Body = string.Concat(objArray2);
                                            mail.SendMail();
                                            mail.Dispose();
                                        }
                                        break;
                                    }
                                    DataRow row2 = this.retTable.Rows[num4];
                                    str2 = ((((((str2 + "<tr class='bd'>") + "<td nowrap>" + (num4 + 1).ToString() + "</td>") + "<td nowrap>" + row2[0].ToString() + "</td>") + "<td nowrap>" + row2[1].ToString() + "</td>") + "<td nowrap>" + row2[3].ToString() + "</td>") + "<td nowrap>" + row2[2].ToString() + "</td>") + "</tr'>";
                                    string str = row2[0].ToString().Trim();
                                    if (row2[1].ToString() == "Y")
                                    {
                                        num++;
                                        flag4 = true;
                                        table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                        table.DR = table.DT.Rows[0];
                                        this.logKey = table.DR["uniq"].ToString();
                                        table.DR.BeginEdit();
                                        table.DR["posted"] = "Y";
                                        table.DR["reposted"] = (row2[3].ToString() != "Y") ? "N" : "Y";
                                        table.DR["sync_return"] = "";
                                        table.DR["lastUpload"] = DateTime.Now;
                                        table.DR["lastMulesoftReturnID"] = DBNull.Value;
                                        table.DR["checksum"] = table.Checksum(table.DR);
                                        table.DR.EndEdit();
                                        table.Save();
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to " + this.zwbIDSYS };
                                        Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                    }
                                    else
                                    {
                                        flag4 = true;
                                        table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                        table.DR = table.DT.Rows[0];
                                        if ((table.DR["posted"].ToString() != "Y") || (table.DR["reposted"].ToString() != "Y"))
                                        {
                                            this.logKey = table.DR["uniq"].ToString();
                                            table.DR.BeginEdit();
                                            table.DR["posted"] = "N";
                                            table.DR["reposted"] = (row2[3].ToString() != "Y") ? "N" : "Y";
                                            table.DR["sync_return"] = row2[2].ToString();
                                            table.DR["lastUpload"] = DateTime.Now;
                                            table.DR["lastMulesoftReturnID"] = DBNull.Value;
                                            table.DR["checksum"] = table.Checksum(table.DR);
                                            table.DR.EndEdit();
                                            table.Save();
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload transaction to " + this.zwbIDSYS };
                                            Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                                        }
                                    }
                                    num2++;
                                    flag4 = true;
                                    table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                                    table.DR = table.DT.Rows[0];
                                    num4++;
                                }
                                break;
                            }
                            if (this.dgTransFlag.Rows[num3].Cells["estateDiff"].Value.ToString() == "Y")
                            {
                                string[] result = new string[] { this.dgTransFlag.Rows[num3].Cells["WREF"].Value.ToString(), "X", "Estate is Different" };
                                WBSAP.importResult(result);
                            }
                            num3++;
                        }
                    }
                }
                catch (RfcInvalidParameterException exception)
                {
                    if (this.auto != 'Y')
                    {
                        MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (RfcCommunicationException exception2)
                {
                    if (this.auto != 'Y')
                    {
                        if (WBUser.UserLevel == "1")
                        {
                            MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                }
                catch (RfcBaseException exception3)
                {
                    if (this.auto != 'Y')
                    {
                        if (WBUser.UserLevel == "1")
                        {
                            MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                }
                catch (Exception exception4)
                {
                    if (this.auto != 'Y')
                    {
                        MessageBox.Show("Error " + exception4.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
        }

        private void ViewTimbang()
        {
            try
            {
                WBTable table = new WBTable();
                string str4 = "REF";
                string zValue = this.dgTrans.CurrentRow.Cells[str4].Value.ToString();
                table.OpenTable("wb_transaction", "select * from wb_transaction where uniq ='" + Program.getFieldValue("wb_transaction", "uniq", "Ref", zValue) + "'", WBData.conn);
                FormTransaction transaction = new FormTransaction {
                    tblTrans = table,
                    tambahRecord = false,
                    pMode = "VIEW"
                };
                transaction.ShowDialog();
                Cursor.Current = Cursors.Default;
                transaction.Dispose();
                table.Dispose();
            }
            catch
            {
            }
        }
    }
}

