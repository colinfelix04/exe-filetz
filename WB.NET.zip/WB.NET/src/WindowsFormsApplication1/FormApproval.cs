﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormApproval : Form
    {
        public bool berhasil = false;
        public WBTable tbl = new WBTable();
        public string approve;
        public string approveBy1;
        public string approveBy2;
        public string appReason;
        public string otoObj;
        public string otoAct;
        private IContainer components = null;
        private Button btnApprove;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label2;
        private Label label1;
        private Button button1;
        private Label lblReason;
        private TextBox txtReason;

        public FormApproval()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.txtReason.Text == "")
            {
                MessageBox.Show("Please fill in reason ! ", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                if (this.txtReason.Text.Length > 50)
                {
                    MessageBox.Show("Reason is too long ! ", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                string[] textArray1 = new string[] { "Select * from wb_user where (Coy='", WBData.sCoyCode, "') and (Location_Code='", WBData.sLocCode, "') and user_id = '", this.textBox1.Text.Trim(), "'" };
                this.tbl.OpenTable("wb_user", string.Concat(textArray1), WBData.conn);
                if (this.tbl.DT.Rows.Count <= 0)
                {
                    MessageBox.Show(Resource.Mes_004, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textBox1.Focus();
                }
                else
                {
                    this.tbl.DR = this.tbl.DT.Rows[0];
                    if (!this.tbl.ValidChecksum(this.tbl.DR))
                    {
                        MessageBox.Show(Resource.Mes_002, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        this.textBox1.Focus();
                    }
                    else if (Program.shoot(this.tbl.DR["User_Pass"].ToString().Trim(), false) != this.textBox2.Text)
                    {
                        MessageBox.Show(Resource.Mes_005, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        this.textBox2.Text = "";
                        this.textBox2.Focus();
                    }
                    else
                    {
                        this.berhasil = true;
                        if (!this.berhasil)
                        {
                            MessageBox.Show(Resource.Mes_003, Resource.Title_006);
                        }
                        else if ((this.otoObj == "") || (this.otoObj == null))
                        {
                            if (Convert.ToByte(this.tbl.DR["User_Level"].ToString().Trim()) <= 2)
                            {
                                this.approve = "Y";
                                this.approveBy1 = this.textBox1.Text.Trim();
                                this.appReason = this.txtReason.Text.Trim();
                                MessageBox.Show(Resource.Mes_001);
                                base.Close();
                            }
                        }
                        else
                        {
                            WBTable table = new WBTable();
                            WBTable table2 = new WBTable();
                            if (this.otoObj == "EDIT_DELETE_MD_DN")
                            {
                                this.otoObj = "MD_DN";
                            }
                            string[] textArray2 = new string[9];
                            textArray2[0] = "Select * from wb_authorization as autho inner join wb_user as users on users.user_group = autho.autho_group where (autho.Coy='";
                            textArray2[1] = WBData.sCoyCode;
                            textArray2[2] = "') and (autho.Location_Code='";
                            textArray2[3] = WBData.sLocCode;
                            textArray2[4] = "') and users.user_id = '";
                            textArray2[5] = this.textBox1.Text.Trim();
                            textArray2[6] = "' and autho.autho_menu = '";
                            textArray2[7] = this.otoObj;
                            textArray2[8] = "' ";
                            table.OpenTable("wb_user", string.Concat(textArray2), WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                table.DR = table.DT.Rows[0];
                                string[] textArray3 = new string[9];
                                textArray3[0] = "Select * from wb_authorization where (Coy='";
                                textArray3[1] = WBData.sCoyCode;
                                textArray3[2] = "') and (Location_Code='";
                                textArray3[3] = WBData.sLocCode;
                                textArray3[4] = "') and autho_menu = '";
                                textArray3[5] = this.otoObj;
                                textArray3[6] = "' and autho_group = '";
                                textArray3[7] = table.DR["user_group"].ToString();
                                textArray3[8] = "'";
                                table2.OpenTable("wb_authorization", string.Concat(textArray3), WBData.conn);
                                if (table2.DT.Rows.Count > 0)
                                {
                                    table2.DR = table2.DT.Rows[0];
                                    if (!table2.ValidChecksum(table2.DR))
                                    {
                                        MessageBox.Show("Checksum not valid", "N O T I C E");
                                    }
                                    else
                                    {
                                        this.berhasil = table.DR["Autho_Trustee"].ToString().Contains(this.otoAct);
                                        if (!this.berhasil)
                                        {
                                            MessageBox.Show(Resource.Mes_003, Resource.Title_006);
                                        }
                                        else
                                        {
                                            this.approve = "Y";
                                            this.approveBy1 = this.textBox1.Text.Trim();
                                            this.appReason = this.txtReason.Text.Trim();
                                            MessageBox.Show(Resource.Mes_001);
                                            base.Close();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.approve = "N";
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormApproval_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.approve = "N";
                base.Close();
            }
        }

        private void FormApproval_Load(object sender, EventArgs e)
        {
        }

        private void InitializeComponent()
        {
            this.btnApprove = new Button();
            this.textBox2 = new TextBox();
            this.textBox1 = new TextBox();
            this.label2 = new Label();
            this.label1 = new Label();
            this.button1 = new Button();
            this.lblReason = new Label();
            this.txtReason = new TextBox();
            base.SuspendLayout();
            this.btnApprove.Location = new Point(0x4c, 0x66);
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Size = new Size(0x4b, 0x17);
            this.btnApprove.TabIndex = 9;
            this.btnApprove.Text = "&Approve";
            this.btnApprove.UseVisualStyleBackColor = true;
            this.btnApprove.Click += new EventHandler(this.button1_Click);
            this.textBox2.Location = new Point(70, 0x29);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x8f, 20);
            this.textBox2.TabIndex = 8;
            this.textBox2.UseSystemPasswordChar = true;
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(70, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0x8f, 20);
            this.textBox1.TabIndex = 7;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(13, 0x2c);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x35, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Password";
            this.label1.AutoSize = true;
            this.label1.Location = new Point(13, 15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x2b, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "User ID";
            this.button1.Location = new Point(0xac, 0x66);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 10;
            this.button1.Text = "&Cancel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click_1);
            this.lblReason.AutoSize = true;
            this.lblReason.Location = new Point(13, 70);
            this.lblReason.Name = "lblReason";
            this.lblReason.Size = new Size(0x2c, 13);
            this.lblReason.TabIndex = 11;
            this.lblReason.Text = "Reason";
            this.txtReason.Location = new Point(70, 0x43);
            this.txtReason.MaxLength = 50;
            this.txtReason.Name = "txtReason";
            this.txtReason.Size = new Size(0x133, 20);
            this.txtReason.TabIndex = 12;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x185, 140);
            base.ControlBox = false;
            base.Controls.Add(this.txtReason);
            base.Controls.Add(this.lblReason);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.btnApprove);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.KeyPreview = true;
            base.Name = "FormApproval";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Approval Entry";
            base.Load += new EventHandler(this.FormApproval_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormApproval_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

