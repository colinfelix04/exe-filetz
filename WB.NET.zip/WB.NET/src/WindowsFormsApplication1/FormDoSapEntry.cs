﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormDoSapEntry : Form
    {
        public string mode = "";
        public string uniq_contract = "";
        private WBTable t_do = new WBTable();
        private WBTable t_do_sap = new WBTable();
        private WBTable t_comm = new WBTable();
        private IContainer components = null;
        private Label label1;
        private TextBox text_do_sap;
        private TextBox text_do_sap_item;
        private Label label2;
        private TextBox text_qty;
        private Label label3;
        private TextBox text_uom;
        private Button btn_save;
        private Button btn_cancel;
        private GroupBox groupBox1;
        private TextBox text_comm;
        private Label label8;
        private TextBox text_so_item;
        private Label label7;
        private TextBox text_so;
        private Label label6;
        private TextBox text_contract;
        private Label label5;
        private TextBox text_qty_kg;
        private Label label4;
        private Label label9;

        public FormDoSapEntry()
        {
            this.InitializeComponent();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (this.text_do_sap.Text.Trim() == "")
            {
                MessageBox.Show("Please fill in DO SAP", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.text_do_sap_item.Text.Trim() == "")
            {
                MessageBox.Show("Please fill in DO SAP Item", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.text_qty.Text.Trim() == "")
            {
                MessageBox.Show("Please fill in Qty", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.text_qty_kg.Text.Trim() == "")
            {
                MessageBox.Show("Please fill in Qty in KG", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                string[] textArray1 = new string[] { "SELECT * FROM wb_do_sap WHERE uniq = '", this.uniq_contract, "' AND do_sap = '", this.text_do_sap.Text.Trim(), "' AND do_sap_item = '", this.text_do_sap_item.Text.Trim(), "'" };
                this.t_do_sap.OpenTable("wb_do_sap", string.Concat(textArray1), WBData.conn);
                if ((this.t_do_sap.DT.Rows.Count > 0) && (this.mode == "ADD"))
                {
                    MessageBox.Show("Duplicate DO SAP.\nPlease check again.\nThank you.", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    string[] strArray = new string[3];
                    if (this.t_do_sap.tokenOrApp(this.text_do_sap.Text.Trim(), this.text_do_sap_item.Text.Trim(), "DO_SAP", "TOKEN_DO_SAP", "", "", "", null)[0] != "cancel")
                    {
                        if (this.mode == "ADD")
                        {
                            this.t_do_sap.DR = this.t_do_sap.DT.NewRow();
                        }
                        else if (this.mode == "EDIT")
                        {
                            this.t_do_sap.DR = this.t_do_sap.DT.Rows[0];
                            this.t_do_sap.DR.BeginEdit();
                        }
                        this.t_do_sap.DR["uniq_contract"] = this.uniq_contract;
                        this.t_do_sap.DR["do_sap"] = this.text_do_sap.Text.Trim();
                        this.t_do_sap.DR["do_sap_item"] = this.text_do_sap_item.Text.Trim();
                        this.t_do_sap.DR["comm_code"] = this.text_comm.Text.Trim();
                        this.t_do_sap.DR["quantity"] = this.text_qty.Text.Trim();
                        this.t_do_sap.DR["unit"] = this.text_uom.Text.Trim();
                        this.t_do_sap.DR["quantity_kg"] = this.text_qty_kg.Text.Trim();
                        if (this.mode == "ADD")
                        {
                            this.t_do_sap.DT.Rows.Add(this.t_do_sap.DR);
                            this.t_do_sap.Save();
                        }
                        else if (this.mode == "EDIT")
                        {
                            this.t_do_sap.DR.EndEdit();
                            this.t_do_sap.Save();
                        }
                    }
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormDoSapEntry_Load(object sender, EventArgs e)
        {
            this.t_do.OpenTable("wb_contract", "SELECT * FROM wb_contract WHERE uniq = '" + this.uniq_contract + "'", WBData.conn);
            if (this.t_do.DT.Rows.Count == 1)
            {
                this.text_contract.Text = this.t_do.DT.Rows[0]["do_no"].ToString();
                this.text_so.Text = this.t_do.DT.Rows[0]["so"].ToString();
                this.text_so_item.Text = this.t_do.DT.Rows[0]["so_item"].ToString();
                this.text_comm.Text = this.t_do.DT.Rows[0]["comm_code"].ToString();
                this.t_comm.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.text_comm.Text + "'"), WBData.conn);
                if (this.t_comm.DT.Rows.Count == 1)
                {
                    this.text_uom.Text = this.t_comm.DT.Rows[0]["unit"].ToString();
                }
            }
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.text_do_sap = new TextBox();
            this.text_do_sap_item = new TextBox();
            this.label2 = new Label();
            this.text_qty = new TextBox();
            this.label3 = new Label();
            this.text_uom = new TextBox();
            this.btn_save = new Button();
            this.btn_cancel = new Button();
            this.groupBox1 = new GroupBox();
            this.text_comm = new TextBox();
            this.label8 = new Label();
            this.text_so_item = new TextBox();
            this.label7 = new Label();
            this.text_so = new TextBox();
            this.label6 = new Label();
            this.text_contract = new TextBox();
            this.label5 = new Label();
            this.text_qty_kg = new TextBox();
            this.label4 = new Label();
            this.label9 = new Label();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x12, 0x98);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x2f, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "DO SAP";
            this.text_do_sap.Location = new Point(0x58, 0x95);
            this.text_do_sap.Name = "text_do_sap";
            this.text_do_sap.Size = new Size(100, 20);
            this.text_do_sap.TabIndex = 1;
            this.text_do_sap_item.Location = new Point(0x58, 0xaf);
            this.text_do_sap_item.Name = "text_do_sap_item";
            this.text_do_sap_item.Size = new Size(0x2f, 20);
            this.text_do_sap_item.TabIndex = 3;
            this.text_do_sap_item.Text = "000010";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x12, 0xb2);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x1b, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Item";
            this.text_qty.Location = new Point(0x58, 0xc9);
            this.text_qty.Name = "text_qty";
            this.text_qty.Size = new Size(100, 20);
            this.text_qty.TabIndex = 5;
            this.text_qty.KeyPress += new KeyPressEventHandler(this.text_qty_KeyPress);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x12, 0xcc);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x17, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Qty";
            this.text_uom.Location = new Point(0xc2, 0xc9);
            this.text_uom.Name = "text_uom";
            this.text_uom.ReadOnly = true;
            this.text_uom.Size = new Size(0x2f, 20);
            this.text_uom.TabIndex = 7;
            this.btn_save.Location = new Point(0xd5, 0x10a);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new Size(0x4b, 0x17);
            this.btn_save.TabIndex = 8;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new EventHandler(this.btn_save_Click);
            this.btn_cancel.Location = new Point(0x126, 0x10a);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new Size(0x4b, 0x17);
            this.btn_cancel.TabIndex = 9;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new EventHandler(this.btn_cancel_Click);
            this.groupBox1.Controls.Add(this.text_comm);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.text_so_item);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.text_so);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.text_contract);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x165, 0x83);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SO Details";
            this.text_comm.Location = new Point(0x4c, 0x61);
            this.text_comm.Name = "text_comm";
            this.text_comm.ReadOnly = true;
            this.text_comm.Size = new Size(0xa5, 20);
            this.text_comm.TabIndex = 9;
            this.label8.AutoSize = true;
            this.label8.Location = new Point(6, 100);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x3a, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Commodity";
            this.text_so_item.Location = new Point(0x4c, 0x47);
            this.text_so_item.Name = "text_so_item";
            this.text_so_item.ReadOnly = true;
            this.text_so_item.Size = new Size(0x2c, 20);
            this.text_so_item.TabIndex = 7;
            this.label7.AutoSize = true;
            this.label7.Location = new Point(6, 0x4a);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x2d, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "SO Item";
            this.text_so.Location = new Point(0x4c, 0x2d);
            this.text_so.Name = "text_so";
            this.text_so.ReadOnly = true;
            this.text_so.Size = new Size(100, 20);
            this.text_so.TabIndex = 5;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(6, 0x30);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x27, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "SO No";
            this.text_contract.Location = new Point(0x4c, 0x13);
            this.text_contract.Name = "text_contract";
            this.text_contract.ReadOnly = true;
            this.text_contract.Size = new Size(0xa5, 20);
            this.text_contract.TabIndex = 3;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(6, 0x16);
            this.label5.Name = "label5";
            this.label5.Size = new Size(40, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "DO No";
            this.text_qty_kg.Location = new Point(0x58, 0xe3);
            this.text_qty_kg.Name = "text_qty_kg";
            this.text_qty_kg.Size = new Size(100, 20);
            this.text_qty_kg.TabIndex = 12;
            this.text_qty_kg.KeyPress += new KeyPressEventHandler(this.text_qty_kg_KeyPress);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x12, 230);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x34, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Qty in KG";
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0xc2, 230);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x16, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "KG";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x17d, 0x12e);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.text_qty_kg);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.btn_cancel);
            base.Controls.Add(this.btn_save);
            base.Controls.Add(this.text_uom);
            base.Controls.Add(this.text_qty);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.text_do_sap_item);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.text_do_sap);
            base.Controls.Add(this.label1);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormDoSapEntry";
            base.ShowIcon = false;
            base.ShowInTaskbar = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Manual Entry DO SAP";
            base.Load += new EventHandler(this.FormDoSapEntry_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void text_qty_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void text_qty_kg_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}

