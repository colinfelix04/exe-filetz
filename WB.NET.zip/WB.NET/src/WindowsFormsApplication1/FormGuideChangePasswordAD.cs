﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Drawing;
    using System.Runtime.CompilerServices;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Properties;

    public class FormGuideChangePasswordAD : Form
    {
        private int counter = 1;
        private int totalPic = 2;
        private List<string> listStep = new List<string>();
        private List<string> listStepDetail = new List<string>();
        private IContainer components = null;
        private PictureBox panelGuide;
        private Button btnNext;
        private Button btnPrevious;
        private Panel panelMenu;
        private Label lblPage;
        private Label lblStep;
        private TextBox txtMessages;

        public FormGuideChangePasswordAD()
        {
            this.InitializeComponent();
        }

        public void AppendMessage(string text)
        {
            if (this.txtMessages.InvokeRequired)
            {
                SetTextCallback method = new SetTextCallback(this.AppendMessage);
                object[] args = new object[] { text };
                base.Invoke(method, args);
            }
            else if (text == "CLEAR")
            {
                this.txtMessages.Clear();
            }
            else
            {
                this.txtMessages.AppendText(text);
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (this.counter == 1)
            {
                this.btnPrevious.Visible = true;
                this.panelGuide.Image = Resources.ChangePasswordAD2;
                this.panelGuide.BackgroundImageLayout = ImageLayout.Stretch;
                this.panelGuide.Refresh();
                this.btnNext.Text = Resource.btn_ad_ok;
            }
            if (this.counter == 2)
            {
                Process.Start(string.IsNullOrEmpty(WBSetting.ADChangePasswordLink) ? "https://adpass.wilmar.co.id/RDWeb/Pages/en-US/password.aspx" : WBSetting.ADChangePasswordLink);
                base.Close();
            }
            this.counter++;
            this.setPage();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            this.counter = 1;
            this.panelGuide.Image = Resources.ChangePasswordAD1;
            this.panelGuide.BackgroundImageLayout = ImageLayout.Stretch;
            this.btnPrevious.Visible = false;
            this.btnNext.Text = Resource.btn_ad_next;
            this.setPage();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormGuideChangePasswordAD_Load(object sender, EventArgs e)
        {
            string item = "";
            this.listStep.Add(Resource.ad_step1);
            this.listStepDetail.Add(Resource.ad_step1_1);
            this.listStep.Add(Resource.ad_step2);
            string[] textArray1 = new string[13];
            textArray1[0] = Resource.ad_step2_1;
            textArray1[1] = Environment.NewLine;
            textArray1[2] = Environment.NewLine;
            textArray1[3] = Resource.ad_step2_2;
            textArray1[4] = Environment.NewLine;
            textArray1[5] = Environment.NewLine;
            textArray1[6] = Resource.ad_step2_3;
            textArray1[7] = Environment.NewLine;
            textArray1[8] = Environment.NewLine;
            textArray1[9] = Resource.ad_step2_4;
            textArray1[10] = Environment.NewLine;
            textArray1[11] = Environment.NewLine;
            textArray1[12] = Resource.ad_step2_5;
            item = string.Concat(textArray1);
            this.listStepDetail.Add(item);
            WBSetting.GetADChangePasswordLink();
            this.setPage();
        }

        private void InitializeComponent()
        {
            this.btnNext = new Button();
            this.btnPrevious = new Button();
            this.panelMenu = new Panel();
            this.lblPage = new Label();
            this.lblStep = new Label();
            this.txtMessages = new TextBox();
            this.panelGuide = new PictureBox();
            this.panelMenu.SuspendLayout();
            ((ISupportInitialize) this.panelGuide).BeginInit();
            base.SuspendLayout();
            this.btnNext.Location = new Point(0x3c1, 11);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new Size(0x81, 30);
            this.btnNext.TabIndex = 1;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new EventHandler(this.btnOK_Click);
            this.btnPrevious.Location = new Point(0x33a, 11);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new Size(0x81, 30);
            this.btnPrevious.TabIndex = 2;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Visible = false;
            this.btnPrevious.Click += new EventHandler(this.btnPrevious_Click);
            this.panelMenu.BackColor = SystemColors.ActiveCaption;
            this.panelMenu.Controls.Add(this.lblPage);
            this.panelMenu.Controls.Add(this.btnPrevious);
            this.panelMenu.Controls.Add(this.btnNext);
            this.panelMenu.Location = new Point(0, 0x1cd);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new Size(0x4f8, 0x4b);
            this.panelMenu.TabIndex = 3;
            this.lblPage.AutoSize = true;
            this.lblPage.Location = new Point(12, 20);
            this.lblPage.Name = "lblPage";
            this.lblPage.Size = new Size(0x18, 13);
            this.lblPage.TabIndex = 3;
            this.lblPage.Text = @"n\n";
            this.lblStep.AutoSize = true;
            this.lblStep.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.lblStep.Location = new Point(12, 0x1d);
            this.lblStep.Name = "lblStep";
            this.lblStep.Size = new Size(0x30, 0x18);
            this.lblStep.TabIndex = 4;
            this.lblStep.Text = "Step";
            this.txtMessages.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtMessages.Location = new Point(12, 0x49);
            this.txtMessages.Multiline = true;
            this.txtMessages.Name = "txtMessages";
            this.txtMessages.ReadOnly = true;
            this.txtMessages.Size = new Size(340, 0x173);
            this.txtMessages.TabIndex = 15;
            this.panelGuide.BackgroundImage = Resources.ChangePasswordAD1;
            this.panelGuide.BackgroundImageLayout = ImageLayout.Stretch;
            this.panelGuide.Location = new Point(0x16e, 0x1d);
            this.panelGuide.Name = "panelGuide";
            this.panelGuide.Size = new Size(0x2d3, 0x19f);
            this.panelGuide.TabIndex = 0;
            this.panelGuide.TabStop = false;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x44f, 0x1fc);
            base.ControlBox = false;
            base.Controls.Add(this.txtMessages);
            base.Controls.Add(this.lblStep);
            base.Controls.Add(this.panelMenu);
            base.Controls.Add(this.panelGuide);
            base.Name = "FormGuideChangePasswordAD";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "How to change your password";
            base.Load += new EventHandler(this.FormGuideChangePasswordAD_Load);
            this.panelMenu.ResumeLayout(false);
            this.panelMenu.PerformLayout();
            ((ISupportInitialize) this.panelGuide).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void setPage()
        {
            this.AppendMessage("CLEAR");
            try
            {
                this.lblStep.Text = this.listStep[this.counter - 1];
                this.AppendMessage(this.listStepDetail[this.counter - 1]);
            }
            catch
            {
                this.lblStep.Text = "";
                this.AppendMessage("CLEAR");
            }
            string str = this.counter + @" \ " + this.totalPic;
            this.lblPage.Text = str;
        }

        private void translate()
        {
            this.btnPrevious.Text = Resource.btn_ad_previous;
            this.btnNext.Text = Resource.btn_ad_next;
        }

        private delegate void SetTextCallback(string text);
    }
}

