﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCompany : Form
    {
        private int idxFind = 0;
        public WBTable ztable = new WBTable();
        public string pMode;
        public string pFind;
        public int nCurrRow;
        public DataRow ReturnRow;
        private IContainer components = null;
        public ToolStripMenuItem closeToolStripMenuItem;
        public MenuStrip menuStrip1;
        private ToolStripMenuItem toolStripMenuItem1;
        private DataGridView dataGridView1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addToolStripMenuItem;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        public Panel panel1;
        private ProgressBar progressBar1;
        private Label Garis1;
        public TextBox TextFind;
        public Button buttonFind;

        public FormCompany()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.toolStripMenuItem1.PerformClick();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.toolStripMenuItem1.PerformClick();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void FormCompany_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormCompany_Load(object sender, EventArgs e)
        {
            string sqltext = "SELECT * FROM wb_company where 1 = 1";
            this.ztable.OpenTable("wb_company", sqltext, WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Coy_Code"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["Uniq"].Visible = false;
            this.dataGridView1.Columns["Coy_Code"].HeaderText = Resource.Setting_003;
            this.dataGridView1.Columns["Coy_Name"].HeaderText = Resource.Setting_002;
            this.dataGridView1.Columns["coy_location_code"].Visible = false;
            this.dataGridView1.Columns["relation_code"].Visible = false;
            this.toolStripMenuItem1.Visible = this.pMode == "CHOOSE";
            this.dataGridView1.ReadOnly = this.pMode == "CHOOSE";
            base.KeyPreview = true;
            if (this.dataGridView1.RowCount == 0)
            {
                this.editToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
                this.toolStripMenuItem1.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addToolStripMenuItem = new ToolStripMenuItem();
            this.editToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.Garis1 = new Label();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(40, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.toolStripMenuItem1, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x1ed, 0x18);
            this.menuStrip1.TabIndex = 0x17;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addToolStripMenuItem, this.editToolStripMenuItem, this.deleteToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x36, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new Size(0x61, 0x16);
            this.addToolStripMenuItem.Text = "&Add";
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new Size(0x61, 0x16);
            this.editToolStripMenuItem.Text = "&Edit";
            this.editToolStripMenuItem.Click += new EventHandler(this.editToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0x61, 0x16);
            this.deleteToolStripMenuItem.Text = "&Delete";
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(50, 20);
            this.toolStripMenuItem1.Text = "Choose";
            this.toolStripMenuItem1.Click += new EventHandler(this.toolStripMenuItem1_Click_1);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x1ed, 0x139);
            this.dataGridView1.TabIndex = 0x18;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.Garis1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x12b);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x1ed, 0x26);
            this.panel1.TabIndex = 0x19;
            this.progressBar1.Location = new Point(0x2bb, 10);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xe0, 0x11);
            this.progressBar1.TabIndex = 20;
            this.Garis1.BorderStyle = BorderStyle.Fixed3D;
            this.Garis1.Location = new Point(0x112, -8);
            this.Garis1.Margin = new Padding(1, 0, 1, 0);
            this.Garis1.Name = "Garis1";
            this.Garis1.Size = new Size(10, 0x2d);
            this.Garis1.TabIndex = 5;
            this.TextFind.Location = new Point(5, 7);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 0;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.buttonFind.Location = new Point(0xc3, 7);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 1;
            this.buttonFind.Text = "&Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1ed, 0x151);
            base.ControlBox = false;
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.Name = "FormCompany";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Form Company";
            base.Load += new EventHandler(this.FormCompany_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormCompany_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
        }

        private void toolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addToolStripMenuItem.Text = Resource.Menu_Add;
            this.editToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
            this.toolStripMenuItem1.Text = Resource.Menu_Choose;
            this.Text = Resource.Title_Company;
        }
    }
}

