﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormDivideBlock : Form
    {
        private WBTable tbl_divBlokH = new WBTable();
        private WBTable tbl_divBlokD = new WBTable();
        private WBTable tbl_Blok = new WBTable();
        private WBTable tbl_ABW = new WBTable();
        private WBTable tbl_TransDiv = new WBTable();
        private string sField = "";
        private string blockCode = "";
        private string logKey = "";
        private double totalBunch = 0.0;
        private double totalBunchKG = 0.0;
        private double totalBlokBunchKG = 0.0;
        private double totalLFKG = 0.0;
        private double totalBunchLF = 0.0;
        private bool LFMode = false;
        private IContainer components = null;
        private StatusStrip statusStrip1;
        private Panel panelMainInfo;
        private Panel panelAction;
        private Panel panelTotal;
        private Panel panelBlok;
        private Label labelRef;
        private DataGridView dgDivBlok;
        private TextBox textBunchWeight;
        private Label label2;
        private Label label1;
        private Button buttonDelete;
        private Button buttonAdd;
        private TextBox textTotalLFKG;
        private TextBox textTotalBlokBunchKG;
        private TextBox textTotalActBunchKG;
        private TextBox textTotalBunch;
        private Button buttonCancel;
        private Button buttonSave;
        internal TextBox textNet;
        public TextBox textRef;
        private Label labelTotalBunch;
        public TextBox textTransBunch;
        private TextBox textBoxTotalBunchLF;
        private Label label3;
        private Label label5;
        private Label label4;
        private Label label6;
        public TextBox labelEstateCode;
        public Label labelEstateName;

        public FormDivideBlock()
        {
            this.InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            int count = 0;
            count = this.dgDivBlok.Rows.Count;
            if ((count <= 1) || (this.dgDivBlok.Rows[count - 1].Cells["block_code"].ToString().Trim() != ""))
            {
                this.dgDivBlok.Rows.Add(1);
                this.dgDivBlok.Refresh();
                this.dgDivBlok.Rows[count].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgDivBlok.Rows[count].Cells["location_code"].Value = WBData.sLocCode;
                this.dgDivBlok.Rows[count].Cells["Estate_code"].Value = this.labelEstateCode.Text.Trim();
                this.dgDivBlok.Rows[count].Cells["block_code"].Value = "";
                this.dgDivBlok.Rows[count].Cells["ref"].Value = this.textRef.Text;
                this.dgDivBlok.Rows[count].Cells["ABW"].Value = "0";
                this.dgDivBlok.Rows[count].Cells["LF"].Value = "0";
                this.dgDivBlok.Rows[count].Cells["BUnch"].Value = "0";
                this.dgDivBlok.Rows[count].Cells["Act_BunchKG"].Value = "0";
                this.dgDivBlok.Rows[count].Cells["Block_BunchKG"].Value = "0";
                this.dgDivBlok.Rows[count].Cells["LFKG"].Value = "0";
                this.dgDivBlok.Refresh();
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            int index = 0;
            index = this.dgDivBlok.CurrentRow.Index;
            if (index >= 0)
            {
                this.tbl_divBlokD.DR = this.tbl_divBlokD.DT.Rows[index];
                this.tbl_divBlokD.DR.Delete();
                this.tbl_divBlokD.Save();
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { "DELETE", WBUser.UserID, "Divide block" };
                Program.updateLogHeader("wb_divide_blockD", this.logKey, logField, logValue);
                this.dgDivBlok.Rows.Remove(this.dgDivBlok.Rows[index]);
                this.dgDivBlok.Refresh();
                if (this.tbl_divBlokD.DT.Rows.Count > 0)
                {
                    this.tbl_divBlokD.SetCursor(this.dgDivBlok, index - 1);
                }
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            string str = "";
            string str2 = "";
            string str3 = "";
            double num = 0.0;
            foreach (DataGridViewRow row in (IEnumerable) this.dgDivBlok.Rows)
            {
                num += Program.StrToDouble(row.Cells["BUNCH"].Value.ToString().Trim(), 0);
            }
            if (!(num == Program.StrToDouble(this.textTransBunch.Text, 0)))
            {
                object[] objArray1 = new object[] { "Total Bunch Divide Block (", num, ") not Equal to Total Bunch in Transaction (", this.textTotalBunch.Text, ") \nVariance by ", Math.Round((double) (num - Program.StrToDouble(this.textTransBunch.Text, 0)), 0).ToString() };
                MessageBox.Show(string.Concat(objArray1));
            }
            else
            {
                string[] strArray = new string[this.dgDivBlok.Rows.Count];
                foreach (DataGridViewRow row2 in (IEnumerable) this.dgDivBlok.Rows)
                {
                    if (row2.Cells["block_code"].Value.ToString() != "")
                    {
                        string[] textArray1 = new string[] { "block_code" };
                        string[] textArray2 = new string[] { row2.Cells["block_code"].Value.ToString().Trim() };
                        this.tbl_divBlokD.DR = this.tbl_divBlokD.GetData(textArray1, textArray2);
                        str2 = !ReferenceEquals(this.tbl_divBlokD.DR, null) ? "EDIT" : "ADD";
                        if (str2 == "ADD")
                        {
                            this.tbl_divBlokD.DR = this.tbl_divBlokD.DT.NewRow();
                        }
                        else
                        {
                            this.tbl_divBlokD.DR.BeginEdit();
                        }
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= this.tbl_divBlokD.DT.Columns.Count)
                            {
                                if (str2 != "ADD")
                                {
                                    this.logKey = this.tbl_divBlokD.DR["uniq"].ToString();
                                    this.tbl_divBlokD.DR.EndEdit();
                                    this.tbl_divBlokD.Save();
                                    string[] textArray5 = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] textArray6 = new string[] { "EDIT", WBUser.UserID, "Divide block" };
                                    Program.updateLogHeader("wb_divide_blockD", this.logKey, textArray5, textArray6);
                                }
                                else
                                {
                                    this.tbl_divBlokD.DT.Rows.Add(this.tbl_divBlokD.DR);
                                    this.tbl_divBlokD.Save();
                                    string sqltext = (("SELECT uniq FROM wb_divide_blockD WHERE " + WBData.CompanyLocation("")) + " AND ref = '" + row2.Cells["ref"].Value.ToString().Trim() + "' ") + " AND block_code = '" + row2.Cells["block_code"].Value.ToString().Trim() + "'";
                                    WBTable table = new WBTable();
                                    table.OpenTable("wb_divide_blockD", sqltext, WBData.conn);
                                    this.logKey = table.DT.Rows[0]["uniq"].ToString();
                                    table.Dispose();
                                    string[] textArray3 = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] textArray4 = new string[] { "ADD", WBUser.UserID, "Divide block" };
                                    Program.updateLogHeader("wb_divide_blockD", this.logKey, textArray3, textArray4);
                                }
                                break;
                            }
                            str3 = this.tbl_divBlokD.DT.Columns[num4].ColumnName.ToString();
                            bool flag5 = str3.ToUpper() != "UNIQ".ToUpper();
                            if (flag5 && ((row2.Cells[str3].Value != null) && (row2.Cells[str3].Value.ToString().Trim() != "")))
                            {
                                this.tbl_divBlokD.DR[str3] = row2.Cells[str3].Value;
                            }
                            num4++;
                        }
                    }
                }
                this.tbl_divBlokD.Save();
                this.tbl_divBlokH.ReOpen();
                string[] aField = new string[] { "ref" };
                string[] aFind = new string[] { this.textRef.Text };
                this.tbl_divBlokH.DR = this.tbl_divBlokH.GetData(aField, aFind);
                if (ReferenceEquals(this.tbl_divBlokH.DR, null))
                {
                    str = "ADD";
                    this.tbl_divBlokH.DR = this.tbl_divBlokH.DT.NewRow();
                }
                else
                {
                    str = "EDIT";
                    this.logKey = this.tbl_divBlokH.DR["uniq"].ToString();
                    this.tbl_divBlokH.DR.BeginEdit();
                }
                this.tbl_divBlokH.DR["Coy"] = WBData.sCoyCode;
                this.tbl_divBlokH.DR["location_code"] = WBData.sLocCode;
                this.tbl_divBlokH.DR["Ref"] = this.textRef.Text;
                this.tbl_divBlokH.DR["Total_bunch"] = this.textTotalBunch.Text;
                this.tbl_divBlokH.DR["Act_Bunch_weight"] = this.textTotalActBunchKG.Text;
                this.tbl_divBlokH.DR["Block_bunch_Weight"] = this.textTotalBlokBunchKG.Text;
                this.tbl_divBlokH.DR["Total_BunchLF"] = this.textBoxTotalBunchLF.Text;
                this.tbl_divBlokH.DR["LF_Weight"] = this.textTotalLFKG.Text;
                if (str != "ADD")
                {
                    this.tbl_divBlokH.DR.EndEdit();
                    this.tbl_divBlokH.Save();
                }
                else
                {
                    this.tbl_divBlokH.DT.Rows.Add(this.tbl_divBlokH.DR);
                    this.tbl_divBlokH.Save();
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_divide_blockH", "SELECT uniq FROM wb_divide_blockH WHERE " + WBData.CompanyLocation(" AND Ref = '" + this.textRef.Text + "'"), WBData.conn);
                    this.logKey = table2.DT.Rows[0]["uniq"].ToString();
                    table2.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { str, WBUser.UserID, "Divide block" };
                Program.updateLogHeader("wb_divide_blockH", this.logKey, logField, logValue);
                this.tbl_TransDiv.OpenTable("wb_transDiv", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + this.textRef.Text + "'"), WBData.conn);
                if (this.tbl_TransDiv.DT.Rows.Count > 0)
                {
                    this.tbl_TransDiv.DR = this.tbl_TransDiv.DT.Rows[0];
                    if (this.tbl_TransDiv.DR["ref"].ToString() == this.textRef.Text)
                    {
                        this.logKey = this.tbl_TransDiv.DR["uniq"].ToString();
                        this.tbl_TransDiv.DR.BeginEdit();
                        this.tbl_TransDiv.DR["divBlock"] = "1";
                        this.tbl_TransDiv.DR.EndEdit();
                        this.tbl_TransDiv.Save();
                        string[] textArray11 = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] textArray12 = new string[] { "EDIT", WBUser.UserID, "Divide block" };
                        Program.updateLogHeader("wb_transaction", this.logKey, textArray11, textArray12);
                    }
                }
                base.Close();
            }
        }

        private void dgDivBlok_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            int columnIndex = 0;
            columnIndex = this.dgDivBlok.CurrentCell.ColumnIndex;
            if ((this.dgDivBlok.Columns[columnIndex].Name.ToString().ToUpper().Trim() == "BLOCK_CODE") && (this.dgDivBlok.CurrentCell.Value.ToString().Trim() != ""))
            {
                this.blockCode = this.dgDivBlok.CurrentCell.Value.ToString();
            }
        }

        private void dgDivBlok_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dgDivBlok_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            int columnIndex = 0;
            columnIndex = this.dgDivBlok.CurrentCell.ColumnIndex;
            if ((this.dgDivBlok.Columns[columnIndex].Name.ToString().ToUpper().Trim() != "LF") && (this.dgDivBlok.Columns[columnIndex].Name.ToString().ToUpper().Trim() != "BUNCH"))
            {
                goto TR_0015;
            }
            else
            {
                try
                {
                    float num3 = (float) Convert.ToDouble(this.dgDivBlok.CurrentCell.Value.ToString());
                    if (this.dgDivBlok.CurrentCell.Value.ToString() == "")
                    {
                        this.dgDivBlok.CurrentCell.Value = "0";
                    }
                    goto TR_0015;
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_018);
                    this.dgDivBlok.CurrentCell.Value = "0";
                }
            }
            return;
        TR_0015:
            if (this.dgDivBlok.Columns[columnIndex].Name.ToString().ToUpper().Trim() == "BLOCK_CODE")
            {
                if (this.dgDivBlok.CurrentCell.Value.ToString().Trim().ToUpper() != "LF")
                {
                    if (this.dgDivBlok.CurrentCell.Value.ToString().Trim() != "")
                    {
                        this.dgDivBlok.CurrentCell.Value = this.dgDivBlok.CurrentCell.Value.ToString().ToUpper();
                        string[] aField = new string[] { "block_code" };
                        string[] aFind = new string[] { this.dgDivBlok.CurrentCell.Value.ToString() };
                        this.tbl_Blok.DR = this.tbl_Blok.GetData(aField, aFind);
                        if (!ReferenceEquals(this.tbl_Blok.DR, null))
                        {
                            using (IEnumerator enumerator = ((IEnumerable) this.dgDivBlok.Rows).GetEnumerator())
                            {
                                while (true)
                                {
                                    if (!enumerator.MoveNext())
                                    {
                                        break;
                                    }
                                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                                    bool flag7 = current.Index != this.dgDivBlok.CurrentRow.Index;
                                    if (flag7 && (current.Cells["block_code"].Value.ToString().Trim().ToUpper() == this.dgDivBlok.CurrentCell.Value.ToString().Trim().ToUpper()))
                                    {
                                        MessageBox.Show(Resource.Mes_122);
                                        this.dgDivBlok.CurrentCell.Value = this.blockCode;
                                        return;
                                    }
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_123);
                            this.dgDivBlok.CurrentCell.Value = this.blockCode;
                            return;
                        }
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_124);
                    this.dgDivBlok.CurrentCell.Value = this.blockCode;
                    return;
                }
            }
            if (((this.dgDivBlok.Columns[columnIndex].Name.ToString().ToUpper().Trim() == "BLOCK_CODE") || (this.dgDivBlok.Columns[columnIndex].Name.ToString().ToUpper().Trim() == "LF")) || (this.dgDivBlok.Columns[columnIndex].Name.ToString().ToUpper().Trim() == "BUNCH"))
            {
                this.dgDivBlok.CurrentRow.Cells["ABW"].Value = this.getAbw(this.labelEstateCode.Text.Trim(), this.dgDivBlok.CurrentRow.Cells["block_code"].Value.ToString().Trim()).ToString();
                this.hitung();
            }
        }

        private void dgDivBlok_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dgDivBlok_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (this.dgDivBlok.Rows.Count > 0)
            {
                int index = 0;
                double aBW = 0.0;
                index = this.dgDivBlok.CurrentRow.Index;
                if (e.KeyChar == '\r')
                {
                    aBW = this.getAbw(this.labelEstateCode.Text.Trim(), this.dgDivBlok.CurrentRow.Cells["block_code"].Value.ToString());
                    this.dgDivBlok.CurrentRow.Cells["ABW"].Value = aBW.ToString();
                    this.hitungBunch(aBW);
                    aBW = this.getAbw(this.labelEstateCode.Text.Trim(), "LF");
                    this.hitungLF(aBW);
                    this.hitungTotal();
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormDivideBlock_Load(object sender, EventArgs e)
        {
            this.tbl_Blok.OpenTable("wb_block", "select * from wb_block where" + WBData.CompanyLocation(""), WBData.conn);
            this.tbl_divBlokH.OpenTable("wb_div_blok", "select * from wb_divide_blockH where " + WBData.CompanyLocation(" and ref = '" + this.textRef.Text + "'"), WBData.conn);
            if (this.tbl_divBlokH.DT.Rows.Count > 0)
            {
                this.tbl_divBlokH.DR = this.tbl_divBlokH.DT.Rows[0];
                this.textTotalBunch.Text = $"{Program.StrToDouble(this.tbl_divBlokH.DR["Total_bunch"].ToString(), 0):N0}";
                this.textTotalActBunchKG.Text = $"{Program.StrToDouble(this.tbl_divBlokH.DR["Act_Bunch_weight"].ToString(), 2):N0}";
                this.textTotalBlokBunchKG.Text = $"{Program.StrToDouble(this.tbl_divBlokH.DR["Block_bunch_Weight"].ToString(), 2):N0}";
                this.textTotalLFKG.Text = $"{Program.StrToDouble(this.tbl_divBlokH.DR["LF_Weight"].ToString(), 2):N0}";
            }
            object[] objArray1 = new object[] { " and  Estate_code = '", this.labelEstateCode.Text, "' and (Year = '", DateTime.Now.Date.ToString("yyyy"), "' and Month = '", Convert.ToInt16(DateTime.Now.Date.ToString("MM")), "')" };
            this.tbl_ABW.OpenTable("wb_blokAbw", "Select * from WB_Block_Abw where " + WBData.CompanyLocation(string.Concat(objArray1)), WBData.conn);
            if (this.getAbw(this.labelEstateCode.Text.Trim(), "LF") == 0.0)
            {
                string[] textArray1 = new string[] { "LF For YEAR ", DateTime.Now.Date.ToString("yyyy"), " MONTH ", DateTime.Now.Date.ToString("MM"), " not yet maintain. \nCannot Divide Block. Please Maintain LF first" };
                MessageBox.Show(string.Concat(textArray1), "WARNING...");
                base.Close();
            }
            this.sField = "coy, location_code, Ref, Estate_code, Block_code, ABW, LF, Bunch, Block_BunchKG, Act_bunchKG,  LFKG,uniq";
            this.tbl_divBlokD.OpenTable("wb_div_block", "select " + this.sField + " from wb_divide_blockD where " + WBData.CompanyLocation(" and ref = '" + this.textRef.Text + "'"), WBData.conn);
            this.dgDivBlok.ColumnCount = this.tbl_divBlokD.DT.Columns.Count;
            int num = 0;
            while (true)
            {
                if (num >= this.tbl_divBlokD.DT.Columns.Count)
                {
                    this.dgDivBlok.Columns["coy"].Visible = false;
                    this.dgDivBlok.Columns["location_code"].Visible = false;
                    this.dgDivBlok.Columns["uniq"].Visible = false;
                    this.dgDivBlok.Columns["Ref"].Visible = false;
                    this.dgDivBlok.Columns["Estate_code"].Visible = false;
                    this.dgDivBlok = this.tbl_divBlokD.ToDGV(this.dgDivBlok);
                    foreach (DataGridViewColumn column in this.dgDivBlok.Columns)
                    {
                        column.ReadOnly = true;
                        if (((column.Name.ToUpper() == "BLOCK_CODE") || (column.Name.ToUpper() == "LF")) || (column.Name.ToUpper() == "BUNCH"))
                        {
                            column.ReadOnly = false;
                        }
                        else
                        {
                            column.DefaultCellStyle.BackColor = Color.Gray;
                            column.ReadOnly = true;
                        }
                        column.Width = 0x74;
                    }
                    this.dgDivBlok.Columns["ABW"].Width = 0x7b;
                    this.dgDivBlok.Columns["LF"].Width = 0x7b;
                    this.dgDivBlok.Columns["BUnch"].Width = 0x7b;
                    this.dgDivBlok.Columns["Act_BunchKG"].Width = 0x7b;
                    this.dgDivBlok.Columns["Block_BunchKG"].Width = 0x7b;
                    this.dgDivBlok.Columns["LFKG"].Width = 130;
                    this.dgDivBlok.Columns["ABW"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgDivBlok.Columns["LF"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgDivBlok.Columns["BUnch"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgDivBlok.Columns["Act_BunchKG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgDivBlok.Columns["Block_BunchKG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgDivBlok.Columns["LFKG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgDivBlok.Columns["ABW"].DefaultCellStyle.Format = "N2";
                    this.dgDivBlok.Columns["LF"].DefaultCellStyle.Format = "N0";
                    this.dgDivBlok.Columns["BUnch"].DefaultCellStyle.Format = "N0";
                    this.dgDivBlok.Columns["Act_BunchKG"].DefaultCellStyle.Format = "N0";
                    this.dgDivBlok.Columns["Block_BunchKG"].DefaultCellStyle.Format = "N0";
                    this.dgDivBlok.Columns["LFKG"].DefaultCellStyle.Format = "N0";
                    this.dgDivBlok.Columns["ABW"].HeaderText = "ABW";
                    this.dgDivBlok.Columns["LF"].HeaderText = "LF";
                    this.dgDivBlok.Columns["BUnch"].HeaderText = "Bunch";
                    this.dgDivBlok.Columns["Act_BunchKG"].HeaderText = "Actual Bunch (KG)";
                    this.dgDivBlok.Columns["Block_BunchKG"].HeaderText = "Tonnage Bunch (KG)";
                    this.dgDivBlok.Columns["LFKG"].HeaderText = "LF KG";
                    if (this.textTransBunch.Text != "0")
                    {
                        this.textBunchWeight.Text = Program.StrToDouble((Program.StrToDouble(this.textNet.Text, 2) / Program.StrToDouble(this.textTransBunch.Text, 2)).ToString(), 0).ToString();
                        this.LFMode = false;
                    }
                    else
                    {
                        this.LFMode = true;
                        this.textBunchWeight.Text = "0";
                        this.dgDivBlok.Columns["BUNCH"].DefaultCellStyle.BackColor = Color.Gray;
                        this.dgDivBlok.Columns["BUNCH"].ReadOnly = true;
                    }
                    this.hitungTotal();
                    return;
                }
                this.dgDivBlok.Columns[num].Name = this.tbl_divBlokD.DT.Columns[num].ColumnName;
                num++;
            }
        }

        private double getAbw(string pEstate, string pCode)
        {
            string[] aField = new string[] { "estate_code", "block_code" };
            string[] aFind = new string[] { pEstate, pCode };
            this.tbl_ABW.DR = this.tbl_ABW.GetData(aField, aFind);
            return (!ReferenceEquals(this.tbl_ABW.DR, null) ? Program.StrToDouble(this.tbl_ABW.DR["ABW"].ToString(), 2) : 0.0);
        }

        private void hitung()
        {
            double num = 0.0;
            double num2 = 0.0;
            double num3 = 0.0;
            double num4 = 0.0;
            double num5 = 0.0;
            double num6 = 0.0;
            num6 = this.getAbw(this.labelEstateCode.Text.Trim(), "LF");
            foreach (DataGridViewRow row in (IEnumerable) this.dgDivBlok.Rows)
            {
                row.Cells["LFKG"].Value = Math.Round((double) (Program.StrToDouble(row.Cells["LF"].Value.ToString(), 0) * num6), 0);
                row.Cells["Block_BunchKG"].Value = Math.Round((double) (Program.StrToDouble(row.Cells["Bunch"].Value.ToString(), 0) * Program.StrToDouble(row.Cells["ABW"].Value.ToString(), 2)), 0);
                num3 += Program.StrToDouble(row.Cells["Bunch"].Value.ToString(), 0);
                num += Program.StrToDouble(row.Cells["LF"].Value.ToString(), 0);
                num2 += Math.Round(Program.StrToDouble(row.Cells["LFKG"].Value.ToString(), 0), 0);
                num4 += Math.Round(Program.StrToDouble(row.Cells["Block_BunchKG"].Value.ToString(), 0), 0);
            }
            if (this.LFMode)
            {
                num2 = 0.0;
                foreach (DataGridViewRow row2 in (IEnumerable) this.dgDivBlok.Rows)
                {
                    if (num > 0.0)
                    {
                        row2.Cells["LFKG"].Value = Math.Round((double) ((Program.StrToDouble(row2.Cells["LF"].Value.ToString(), 0) / num) * Program.StrToDouble(this.textNet.Text, 0)), 0);
                        num2 += Math.Round(Program.StrToDouble(row2.Cells["LFKG"].Value.ToString(), 0), 0);
                    }
                }
            }
            this.textTotalBunch.Text = $"{num3:N0}".ToString();
            this.textTotalLFKG.Text = $"{num2:N0}".ToString();
            this.textBoxTotalBunchLF.Text = $"{num:N0}".ToString();
            this.textTotalBlokBunchKG.Text = $"{num4:N0}".ToString();
            if (this.LFMode)
            {
                foreach (DataGridViewRow row4 in (IEnumerable) this.dgDivBlok.Rows)
                {
                    row4.Cells["Act_BunchKG"].Value = 0;
                    num5 += Program.StrToDouble(row4.Cells["Act_BunchKG"].Value.ToString(), 0);
                }
                this.textTotalActBunchKG.Text = $"{num5:N0}".ToString();
            }
            else
            {
                foreach (DataGridViewRow row3 in (IEnumerable) this.dgDivBlok.Rows)
                {
                    if (Program.StrToDouble(this.textTotalBlokBunchKG.Text, 0) > 0.0)
                    {
                        row3.Cells["Act_BunchKG"].Value = Math.Round((double) ((Program.StrToDouble(row3.Cells["Block_BunchKG"].Value.ToString(), 0) / Program.StrToDouble(this.textTotalBlokBunchKG.Text, 0)) * (Program.StrToDouble(this.textNet.Text, 0) - Program.StrToDouble(this.textTotalLFKG.Text.ToString().ToString(), 0))), 0);
                    }
                    num5 += Program.StrToDouble(row3.Cells["Act_BunchKG"].Value.ToString(), 0);
                }
                int count = this.dgDivBlok.Rows.Count;
                num5 = 0.0;
                if (Program.StrToDouble(this.textTotalBunch.Text, 0) == Program.StrToDouble(this.textTransBunch.Text, 0))
                {
                    if (count == 1)
                    {
                        this.dgDivBlok.Rows[0].Cells["Act_bunchKG"].Value = Program.StrToDouble(this.textNet.Text, 0) - num2;
                        num5 += Program.StrToDouble(this.dgDivBlok.Rows[0].Cells["Act_bunchKG"].Value.ToString(), 0);
                    }
                    else
                    {
                        int num8 = 0;
                        while (true)
                        {
                            if (num8 >= (count - 1))
                            {
                                this.dgDivBlok.Rows[count - 1].Cells["Act_bunchKG"].Value = Program.StrToDouble(this.textNet.Text, 0) - (num5 + num2);
                                num5 += Program.StrToDouble(this.dgDivBlok.Rows[count - 1].Cells["Act_bunchKG"].Value.ToString(), 0);
                                break;
                            }
                            num5 += Program.StrToDouble(this.dgDivBlok.Rows[num8].Cells["Act_BunchKG"].Value.ToString(), 0);
                            num8++;
                        }
                    }
                }
                this.textTotalActBunchKG.Text = $"{num5:N0}".ToString();
            }
        }

        private void hitungBunch(double ABW)
        {
            this.dgDivBlok.CurrentRow.Cells["Act_BunchKG"].Value = Program.StrToDouble(this.textBunchWeight.Text, 2) * Program.StrToDouble(this.dgDivBlok.CurrentRow.Cells["Bunch"].Value.ToString(), 2);
            this.dgDivBlok.CurrentRow.Cells["Block_BunchKG"].Value = ABW * Program.StrToDouble(this.dgDivBlok.CurrentRow.Cells["Bunch"].Value.ToString(), 2);
        }

        private void hitungLF(double ABW)
        {
            this.dgDivBlok.CurrentRow.Cells["LFKG"].Value = ABW * Program.StrToDouble(this.dgDivBlok.CurrentRow.Cells["LF"].Value.ToString(), 2);
        }

        private void hitungTotal()
        {
            this.totalBunch = 0.0;
            this.totalBunchKG = 0.0;
            this.totalBlokBunchKG = 0.0;
            this.totalLFKG = 0.0;
            this.totalBunchLF = 0.0;
            foreach (DataGridViewRow row in (IEnumerable) this.dgDivBlok.Rows)
            {
                this.totalBunch += Program.StrToDouble(row.Cells["Bunch"].Value.ToString(), 0);
                this.totalBunchKG += Program.StrToDouble(row.Cells["Act_BunchKG"].Value.ToString(), 0);
                this.totalBlokBunchKG += Program.StrToDouble(row.Cells["Block_BunchKG"].Value.ToString(), 0);
                this.totalLFKG += Program.StrToDouble(row.Cells["LFKG"].Value.ToString(), 0);
                this.totalBunchLF += Program.StrToDouble(row.Cells["LF"].Value.ToString(), 0);
            }
            this.textTotalBunch.Text = $"{this.totalBunch:N0}".ToString();
            this.textTotalActBunchKG.Text = $"{this.totalBunchKG:N0}".ToString();
            this.textTotalBlokBunchKG.Text = $"{this.totalBlokBunchKG:N0}".ToString();
            this.textTotalLFKG.Text = $"{this.totalLFKG:N0}".ToString();
            this.textBoxTotalBunchLF.Text = $"{this.totalBunchLF:N0}".ToString();
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.statusStrip1 = new StatusStrip();
            this.panelMainInfo = new Panel();
            this.label5 = new Label();
            this.label4 = new Label();
            this.label3 = new Label();
            this.textTransBunch = new TextBox();
            this.labelTotalBunch = new Label();
            this.buttonDelete = new Button();
            this.buttonAdd = new Button();
            this.textBunchWeight = new TextBox();
            this.label2 = new Label();
            this.textNet = new TextBox();
            this.label1 = new Label();
            this.textRef = new TextBox();
            this.labelRef = new Label();
            this.panelAction = new Panel();
            this.buttonCancel = new Button();
            this.buttonSave = new Button();
            this.panelTotal = new Panel();
            this.textBoxTotalBunchLF = new TextBox();
            this.textTotalLFKG = new TextBox();
            this.textTotalBlokBunchKG = new TextBox();
            this.textTotalActBunchKG = new TextBox();
            this.textTotalBunch = new TextBox();
            this.panelBlok = new Panel();
            this.dgDivBlok = new DataGridView();
            this.labelEstateCode = new TextBox();
            this.label6 = new Label();
            this.labelEstateName = new Label();
            this.panelMainInfo.SuspendLayout();
            this.panelAction.SuspendLayout();
            this.panelTotal.SuspendLayout();
            this.panelBlok.SuspendLayout();
            ((ISupportInitialize) this.dgDivBlok).BeginInit();
            base.SuspendLayout();
            this.statusStrip1.ImageScalingSize = new Size(20, 20);
            this.statusStrip1.Location = new Point(0, 0x21e);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new Padding(1, 0, 0x13, 0);
            this.statusStrip1.Size = new Size(0x4eb, 0x16);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            this.panelMainInfo.Controls.Add(this.labelEstateName);
            this.panelMainInfo.Controls.Add(this.labelEstateCode);
            this.panelMainInfo.Controls.Add(this.label6);
            this.panelMainInfo.Controls.Add(this.label5);
            this.panelMainInfo.Controls.Add(this.label4);
            this.panelMainInfo.Controls.Add(this.label3);
            this.panelMainInfo.Controls.Add(this.textTransBunch);
            this.panelMainInfo.Controls.Add(this.labelTotalBunch);
            this.panelMainInfo.Controls.Add(this.buttonDelete);
            this.panelMainInfo.Controls.Add(this.buttonAdd);
            this.panelMainInfo.Controls.Add(this.textBunchWeight);
            this.panelMainInfo.Controls.Add(this.label2);
            this.panelMainInfo.Controls.Add(this.textNet);
            this.panelMainInfo.Controls.Add(this.label1);
            this.panelMainInfo.Controls.Add(this.textRef);
            this.panelMainInfo.Controls.Add(this.labelRef);
            this.panelMainInfo.Dock = DockStyle.Top;
            this.panelMainInfo.Location = new Point(0, 0);
            this.panelMainInfo.Margin = new Padding(4, 4, 4, 4);
            this.panelMainInfo.Name = "panelMainInfo";
            this.panelMainInfo.Size = new Size(0x4eb, 0x97);
            this.panelMainInfo.TabIndex = 1;
            this.panelMainInfo.Paint += new PaintEventHandler(this.panelMainInfo_Paint);
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x110, 0x54);
            this.label5.Margin = new Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x30, 0x11);
            this.label5.TabIndex = 11;
            this.label5.Text = "Bunch";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x110, 0x74);
            this.label4.Margin = new Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x19, 0x11);
            this.label4.TabIndex = 10;
            this.label4.Text = "Kg";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x110, 0x34);
            this.label3.Margin = new Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x19, 0x11);
            this.label3.TabIndex = 9;
            this.label3.Text = "Kg";
            this.textTransBunch.Location = new Point(0x80, 80);
            this.textTransBunch.Margin = new Padding(4, 4, 4, 4);
            this.textTransBunch.Name = "textTransBunch";
            this.textTransBunch.ReadOnly = true;
            this.textTransBunch.Size = new Size(0x87, 0x16);
            this.textTransBunch.TabIndex = 8;
            this.textTransBunch.TextAlign = HorizontalAlignment.Right;
            this.labelTotalBunch.AutoSize = true;
            this.labelTotalBunch.Location = new Point(0x13, 0x54);
            this.labelTotalBunch.Margin = new Padding(4, 0, 4, 0);
            this.labelTotalBunch.Name = "labelTotalBunch";
            this.labelTotalBunch.Size = new Size(0x54, 0x11);
            this.labelTotalBunch.TabIndex = 7;
            this.labelTotalBunch.Text = "Total Bunch";
            this.buttonDelete.Font = new Font("Microsoft Sans Serif", 14f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonDelete.Location = new Point(0x444, 0x39);
            this.buttonDelete.Margin = new Padding(4, 4, 4, 4);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new Size(0x8d, 0x2b);
            this.buttonDelete.TabIndex = 6;
            this.buttonDelete.Text = "-";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new EventHandler(this.buttonDelete_Click);
            this.buttonAdd.Font = new Font("Microsoft Sans Serif", 14f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonAdd.Location = new Point(0x3af, 0x39);
            this.buttonAdd.Margin = new Padding(4, 4, 4, 4);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new Size(0x8d, 0x2b);
            this.buttonAdd.TabIndex = 3;
            this.buttonAdd.Text = "+";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new EventHandler(this.buttonAdd_Click);
            this.textBunchWeight.Location = new Point(0x80, 0x70);
            this.textBunchWeight.Margin = new Padding(4, 4, 4, 4);
            this.textBunchWeight.Name = "textBunchWeight";
            this.textBunchWeight.ReadOnly = true;
            this.textBunchWeight.Size = new Size(0x87, 0x16);
            this.textBunchWeight.TabIndex = 5;
            this.textBunchWeight.TextAlign = HorizontalAlignment.Right;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x13, 0x74);
            this.label2.Margin = new Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x60, 0x11);
            this.label2.TabIndex = 4;
            this.label2.Text = "Bunch Weight";
            this.textNet.Location = new Point(0x80, 0x30);
            this.textNet.Margin = new Padding(4, 4, 4, 4);
            this.textNet.Name = "textNet";
            this.textNet.ReadOnly = true;
            this.textNet.Size = new Size(0x87, 0x16);
            this.textNet.TabIndex = 3;
            this.textNet.TextAlign = HorizontalAlignment.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x13, 0x34);
            this.label1.Margin = new Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x4e, 0x11);
            this.label1.TabIndex = 2;
            this.label1.Text = "Net Weight";
            this.textRef.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.textRef.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textRef.Location = new Point(0x3f5, 7);
            this.textRef.Margin = new Padding(4, 4, 4, 4);
            this.textRef.Name = "textRef";
            this.textRef.ReadOnly = true;
            this.textRef.Size = new Size(0xe4, 30);
            this.textRef.TabIndex = 1;
            this.labelRef.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.labelRef.AutoSize = true;
            this.labelRef.Location = new Point(0x3cd, 0x11);
            this.labelRef.Margin = new Padding(4, 0, 4, 0);
            this.labelRef.Name = "labelRef";
            this.labelRef.Size = new Size(30, 0x11);
            this.labelRef.TabIndex = 0;
            this.labelRef.Text = "Ref";
            this.panelAction.Controls.Add(this.buttonCancel);
            this.panelAction.Controls.Add(this.buttonSave);
            this.panelAction.Dock = DockStyle.Bottom;
            this.panelAction.Location = new Point(0, 0x1da);
            this.panelAction.Margin = new Padding(4, 4, 4, 4);
            this.panelAction.Name = "panelAction";
            this.panelAction.Size = new Size(0x4eb, 0x44);
            this.panelAction.TabIndex = 2;
            this.buttonCancel.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.buttonCancel.Location = new Point(0x444, 7);
            this.buttonCancel.Margin = new Padding(4, 4, 4, 4);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x97, 50);
            this.buttonCancel.TabIndex = 8;
            this.buttonCancel.Text = "&Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.buttonSave.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.buttonSave.Location = new Point(0x3a4, 7);
            this.buttonSave.Margin = new Padding(4, 4, 4, 4);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x98, 50);
            this.buttonSave.TabIndex = 7;
            this.buttonSave.Text = "&Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.panelTotal.Controls.Add(this.textBoxTotalBunchLF);
            this.panelTotal.Controls.Add(this.textTotalLFKG);
            this.panelTotal.Controls.Add(this.textTotalBlokBunchKG);
            this.panelTotal.Controls.Add(this.textTotalActBunchKG);
            this.panelTotal.Controls.Add(this.textTotalBunch);
            this.panelTotal.Dock = DockStyle.Bottom;
            this.panelTotal.Location = new Point(0, 0x1ab);
            this.panelTotal.Margin = new Padding(4, 4, 4, 4);
            this.panelTotal.Name = "panelTotal";
            this.panelTotal.Size = new Size(0x4eb, 0x2f);
            this.panelTotal.TabIndex = 3;
            this.textBoxTotalBunchLF.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textBoxTotalBunchLF.Location = new Point(0x17d, 12);
            this.textBoxTotalBunchLF.Margin = new Padding(4, 4, 4, 4);
            this.textBoxTotalBunchLF.Name = "textBoxTotalBunchLF";
            this.textBoxTotalBunchLF.ReadOnly = true;
            this.textBoxTotalBunchLF.Size = new Size(0x99, 0x17);
            this.textBoxTotalBunchLF.TabIndex = 0x12;
            this.textBoxTotalBunchLF.TextAlign = HorizontalAlignment.Right;
            this.textTotalLFKG.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textTotalLFKG.Location = new Point(0x405, 12);
            this.textTotalLFKG.Margin = new Padding(4, 4, 4, 4);
            this.textTotalLFKG.Name = "textTotalLFKG";
            this.textTotalLFKG.ReadOnly = true;
            this.textTotalLFKG.Size = new Size(0x99, 0x17);
            this.textTotalLFKG.TabIndex = 0x11;
            this.textTotalLFKG.TextAlign = HorizontalAlignment.Right;
            this.textTotalBlokBunchKG.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textTotalBlokBunchKG.Location = new Point(0x2c3, 12);
            this.textTotalBlokBunchKG.Margin = new Padding(4, 4, 4, 4);
            this.textTotalBlokBunchKG.Name = "textTotalBlokBunchKG";
            this.textTotalBlokBunchKG.ReadOnly = true;
            this.textTotalBlokBunchKG.Size = new Size(0x99, 0x17);
            this.textTotalBlokBunchKG.TabIndex = 0x10;
            this.textTotalBlokBunchKG.TextAlign = HorizontalAlignment.Right;
            this.textTotalActBunchKG.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textTotalActBunchKG.Location = new Point(0x363, 12);
            this.textTotalActBunchKG.Margin = new Padding(4, 4, 4, 4);
            this.textTotalActBunchKG.Name = "textTotalActBunchKG";
            this.textTotalActBunchKG.ReadOnly = true;
            this.textTotalActBunchKG.Size = new Size(0x99, 0x17);
            this.textTotalActBunchKG.TabIndex = 15;
            this.textTotalActBunchKG.TextAlign = HorizontalAlignment.Right;
            this.textTotalBunch.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textTotalBunch.Location = new Point(0x220, 12);
            this.textTotalBunch.Margin = new Padding(4, 4, 4, 4);
            this.textTotalBunch.Name = "textTotalBunch";
            this.textTotalBunch.ReadOnly = true;
            this.textTotalBunch.Size = new Size(0x99, 0x17);
            this.textTotalBunch.TabIndex = 14;
            this.textTotalBunch.TextAlign = HorizontalAlignment.Right;
            this.panelBlok.Controls.Add(this.dgDivBlok);
            this.panelBlok.Dock = DockStyle.Fill;
            this.panelBlok.Location = new Point(0, 0x97);
            this.panelBlok.Margin = new Padding(4, 4, 4, 4);
            this.panelBlok.Name = "panelBlok";
            this.panelBlok.Size = new Size(0x4eb, 0x114);
            this.panelBlok.TabIndex = 0;
            this.dgDivBlok.AllowDrop = true;
            this.dgDivBlok.AllowUserToAddRows = false;
            this.dgDivBlok.AllowUserToDeleteRows = false;
            this.dgDivBlok.AllowUserToResizeRows = false;
            this.dgDivBlok.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgDivBlok.ColumnHeadersDefaultCellStyle = style;
            this.dgDivBlok.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgDivBlok.DefaultCellStyle = style2;
            this.dgDivBlok.Dock = DockStyle.Fill;
            this.dgDivBlok.Location = new Point(0, 0);
            this.dgDivBlok.Margin = new Padding(4, 4, 4, 4);
            this.dgDivBlok.MultiSelect = false;
            this.dgDivBlok.Name = "dgDivBlok";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgDivBlok.RowHeadersDefaultCellStyle = style3;
            this.dgDivBlok.SelectionMode = DataGridViewSelectionMode.CellSelect;
            this.dgDivBlok.Size = new Size(0x4eb, 0x114);
            this.dgDivBlok.TabIndex = 2;
            this.dgDivBlok.CellBeginEdit += new DataGridViewCellCancelEventHandler(this.dgDivBlok_CellBeginEdit);
            this.dgDivBlok.CellContentClick += new DataGridViewCellEventHandler(this.dgDivBlok_CellContentClick);
            this.dgDivBlok.CellEndEdit += new DataGridViewCellEventHandler(this.dgDivBlok_CellEndEdit);
            this.dgDivBlok.CellLeave += new DataGridViewCellEventHandler(this.dgDivBlok_CellLeave);
            this.dgDivBlok.KeyPress += new KeyPressEventHandler(this.dgDivBlok_KeyPress);
            this.labelEstateCode.Location = new Point(0x80, 15);
            this.labelEstateCode.Margin = new Padding(4);
            this.labelEstateCode.Name = "labelEstateCode";
            this.labelEstateCode.ReadOnly = true;
            this.labelEstateCode.Size = new Size(0x87, 0x16);
            this.labelEstateCode.TabIndex = 13;
            this.labelEstateCode.TextAlign = HorizontalAlignment.Right;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x13, 0x13);
            this.label6.Margin = new Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x30, 0x11);
            this.label6.TabIndex = 12;
            this.label6.Text = "Estate";
            this.labelEstateName.AutoSize = true;
            this.labelEstateName.Location = new Point(0x110, 0x11);
            this.labelEstateName.Margin = new Padding(4, 0, 4, 0);
            this.labelEstateName.Name = "labelEstateName";
            this.labelEstateName.Size = new Size(0x59, 0x11);
            this.labelEstateName.TabIndex = 14;
            this.labelEstateName.Text = "Estate Name";
            base.AutoScaleDimensions = new SizeF(8f, 16f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x4eb, 0x234);
            base.ControlBox = false;
            base.Controls.Add(this.panelBlok);
            base.Controls.Add(this.panelTotal);
            base.Controls.Add(this.panelAction);
            base.Controls.Add(this.panelMainInfo);
            base.Controls.Add(this.statusStrip1);
            base.Margin = new Padding(4, 4, 4, 4);
            base.Name = "FormDivideBlock";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Divide Block";
            base.Load += new EventHandler(this.FormDivideBlock_Load);
            this.panelMainInfo.ResumeLayout(false);
            this.panelMainInfo.PerformLayout();
            this.panelAction.ResumeLayout(false);
            this.panelTotal.ResumeLayout(false);
            this.panelTotal.PerformLayout();
            this.panelBlok.ResumeLayout(false);
            ((ISupportInitialize) this.dgDivBlok).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void panelMainInfo_Paint(object sender, PaintEventArgs e)
        {
        }
    }
}

