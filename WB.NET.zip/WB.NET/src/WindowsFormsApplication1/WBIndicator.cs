﻿namespace WindowsFormsApplication1
{
    using Microsoft.Win32;
    using System;
    using System.ComponentModel;

    public class WBIndicator : Component
    {
        private string wbCheck0 = "N";
        private string wbStatus = "N";
        public string msgStatus = "";
        private string zwbValue = "0";
        public string wbValue = "";
        public string wbValueTmp = "";
        private string gatsby = "0";
        private double gatsVal = -26.0;
        private static string regWbCheck0 = "WbCheck0";
        private static string regWbStatus = "WbStatus";
        private static string regWbValue = "WbValue";
        private static string regGatsby = "Gatsby";
        private static RegistryKey parentKey = Registry.ClassesRoot;
        private static RegistryKey subKey;
        private static RegistryKey subKeyCheck0;
        private static RegistryKey subKeyStatus;
        private static RegistryKey subKeyValue;
        private static RegistryKey subKeyGatsby;

        public bool check0()
        {
            bool flag = false;
            if (this.wbStatus != "13")
            {
                flag = false;
            }
            else
            {
                this.wbCheck0 = (string) subKeyCheck0.GetValue("");
                flag = this.wbCheck0 != "X";
            }
            return flag;
        }

        public void checkStatus()
        {
            try
            {
                this.wbStatus = (string) subKeyStatus.GetValue("");
                this.msgStatus = (this.wbStatus != "13") ? ((this.wbStatus != "33") ? "Unavailable" : "Setting Error") : "Connected";
            }
            catch (Exception)
            {
                this.msgStatus = "Unavailable";
            }
        }

        public string decrypt(string regwbVal)
        {
            string str = "zZvVwWxXyY";
            string str2 = "";
            foreach (char ch in regwbVal)
            {
                str2 = str2 + str.IndexOf(ch).ToString();
            }
            return str2;
        }

        public void Init()
        {
            subKey = parentKey.OpenSubKey("Applications", true);
            subKeyStatus = subKey.OpenSubKey(regWbStatus, true);
            subKeyCheck0 = subKey.OpenSubKey(regWbCheck0, true);
            subKeyGatsby = subKey.OpenSubKey(regGatsby, true);
            subKeyValue = subKey.OpenSubKey(regWbValue, true);
        }

        public void readValue()
        {
            if (this.wbStatus != "13")
            {
                this.wbValue = "0";
            }
            else
            {
                this.zwbValue = (string) subKeyValue.GetValue("");
                this.gatsby = (string) subKeyGatsby.GetValue("");
                this.wbValue = this.decrypt(this.zwbValue);
                if (!(Program.StrToDouble(this.decrypt(this.gatsby), 0) != 0.0))
                {
                    if (!((Program.StrToDouble(this.decrypt(this.gatsby), 0) + this.gatsVal) == (Program.StrToDouble(this.wbValue, 0) + this.gatsVal)))
                    {
                        this.wbValue = this.wbValueTmp;
                    }
                    else
                    {
                        this.wbValueTmp = this.wbValue;
                    }
                }
                else if (!(Program.StrToDouble(this.decrypt(this.gatsby), 0) == (Program.StrToDouble(this.wbValue, 0) + this.gatsVal)))
                {
                    this.wbValue = this.wbValueTmp;
                }
                else
                {
                    this.wbValueTmp = this.wbValue;
                }
            }
        }

        public void updateCheck0()
        {
            subKeyCheck0.SetValue("", "X", RegistryValueKind.String);
        }
    }
}

