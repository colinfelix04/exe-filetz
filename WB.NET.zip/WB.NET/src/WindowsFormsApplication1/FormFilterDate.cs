﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormFilterDate : Form
    {
        public static bool byDelete = false;
        public static DateTime dFrom;
        public static DateTime dTo;
        public bool ConfirmOk = false;
        private IContainer components = null;
        private Label label1;
        private Label label2;
        private DateTimePicker dateTimePicker1;
        private DateTimePicker dateTimePicker2;
        private CheckBox checkBox1;
        private Button button1;
        private Button button2;

        public FormFilterDate()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            byDelete = this.checkBox1.Checked;
            dFrom = this.dateTimePicker1.Value;
            dTo = this.dateTimePicker2.Value;
            this.ConfirmOk = true;
            base.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.ConfirmOk = false;
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormFilterDate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormFilterDate_Load(object sender, EventArgs e)
        {
            this.dateTimePicker1.Value = dFrom;
            this.dateTimePicker2.Value = dTo;
            this.checkBox1.Checked = byDelete;
            base.KeyPreview = true;
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.label2 = new Label();
            this.dateTimePicker1 = new DateTimePicker();
            this.dateTimePicker2 = new DateTimePicker();
            this.checkBox1 = new CheckBox();
            this.button1 = new Button();
            this.button2 = new Button();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x13, 0x24);
            this.label1.Name = "label1";
            this.label1.Size = new Size(30, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "From";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0xe3, 0x24);
            this.label2.Name = "label2";
            this.label2.Size = new Size(20, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "To";
            this.dateTimePicker1.Location = new Point(0x42, 0x24);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new Size(0x89, 20);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker2.Location = new Point(0xfd, 0x24);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new Size(0x89, 20);
            this.dateTimePicker2.TabIndex = 3;
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new Point(0x42, 0x43);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new Size(0xa8, 0x11);
            this.checkBox1.TabIndex = 4;
            this.checkBox1.Text = "Show deleted transaction only";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.button1.Location = new Point(0x75, 100);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 5;
            this.button1.Text = "Ok";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0xef, 100);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 6;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1a2, 0x8f);
            base.ControlBox = false;
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.checkBox1);
            base.Controls.Add(this.dateTimePicker2);
            base.Controls.Add(this.dateTimePicker1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Name = "FormFilterDate";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Filter Transaction by Date";
            base.Load += new EventHandler(this.FormFilterDate_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormFilterDate_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

