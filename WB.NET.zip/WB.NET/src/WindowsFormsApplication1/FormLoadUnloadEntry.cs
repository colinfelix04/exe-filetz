﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormLoadUnloadEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public string OldCode;
        private IContainer components = null;
        public TextBox textLoadUnloadCode;
        private Label label1;
        private Button button2;
        private Button button1;
        private TextBox textDesc;
        private Label label2;
        public TextBox textStorage;
        private Label label3;
        private GroupBox groupBox2;
        private RadioButton radioUnload;
        private RadioButton radioLoad;

        public FormLoadUnloadEntry()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            TextBox[] aText = new TextBox[] { this.textLoadUnloadCode };
            if (!Program.CheckEmpty(aText))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_LoadUnload", "Select Uniq From wb_Load_Unload Where " + WBData.CompanyLocation(" and ( load_Unload ='" + this.textLoadUnloadCode.Text.Trim() + "')"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    Cursor.Current = Cursors.WaitCursor;
                    if ((this.pMode != "EDIT") || (this.textLoadUnloadCode.Text.Trim() == this.OldCode.Trim()))
                    {
                        goto TR_0016;
                    }
                    else
                    {
                        table2 = new WBTable();
                        table2.OpenTable("wb_transaction", "Select uniq From wb_transaction where " + WBData.CompanyLocation(" and ( Load_Unload='" + this.zTable.DT.Rows[this.nCurrRow]["Load_Unload"].ToString() + "')"), WBData.conn);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            goto TR_0017;
                        }
                        else
                        {
                            Cursor.Current = Cursors.Default;
                            string[] textArray1 = new string[11];
                            textArray1[0] = Resource.Mes_178;
                            textArray1[1] = " ";
                            textArray1[2] = this.OldCode;
                            textArray1[3] = " -> ";
                            textArray1[4] = this.textLoadUnloadCode.Text;
                            textArray1[5] = "\n\n";
                            textArray1[6] = Resource.Msg_Replace_Warning;
                            textArray1[7] = "  - ";
                            textArray1[8] = table2.DT.Rows.Count.ToString();
                            textArray1[9] = " records in transactions\n";
                            textArray1[10] = Resource.Msg_Continue;
                            if (MessageBox.Show(string.Concat(textArray1), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.ReplaceAll = true;
                                goto TR_0017;
                            }
                            else
                            {
                                this.ReplaceAll = false;
                                this.textLoadUnloadCode.Focus();
                            }
                        }
                    }
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_044, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textLoadUnloadCode.Focus();
                }
            }
            return;
        TR_0016:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "Load Unload Code" },
                    textRefNo = { Text = this.textLoadUnloadCode.Text },
                    Text = "CHANGE REASON",
                    label2 = { Text = "Change Reason : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Load_Unload"] = this.textLoadUnloadCode.Text;
            this.zTable.DR["Load_Desc"] = this.textDesc.Text;
            this.zTable.DR["Storage_loc"] = this.textStorage.Text;
            this.zTable.DR["type"] = this.radioLoad.Checked ? "0" : (this.radioUnload.Checked ? "1" : "1");
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_load_unload", "SELECT uniq FROM wb_load_unload WHERE " + WBData.CompanyLocation(" AND load_unload = '" + this.textLoadUnloadCode.Text + "'"), WBData.conn);
                    this.logKey = table3.DT.Rows[0]["uniq"].ToString();
                    table3.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_load_unload", this.logKey, logField, logValue);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string[] aField = new string[] { "Load_Unload" };
                string[] aNewValue = new string[] { this.textLoadUnloadCode.Text };
                Program.ReplaceAll("wb_transaction", aField, aNewValue, " Load_Unload='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit load/unload master data)");
            }
            this.saved = true;
            base.Close();
            Cursor.Current = Cursors.Default;
            return;
        TR_0017:
            table2.Dispose();
            goto TR_0016;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormLoadUnloadEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormLoadUnloadEntry_Load(object sender, EventArgs e)
        {
            this.translate();
            base.KeyPreview = true;
            if (this.pMode != "ADD")
            {
                this.textLoadUnloadCode.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Load_Unload"].Value.ToString();
                this.OldCode = this.textLoadUnloadCode.Text;
                this.textDesc.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Load_Desc"].Value.ToString();
                this.textStorage.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Storage_loc"].Value.ToString();
                if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["type"].Value.ToString() == "0")
                {
                    this.radioLoad.Checked = true;
                }
                else if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["type"].Value.ToString() == "1")
                {
                    this.radioUnload.Checked = true;
                }
            }
        }

        private void InitializeComponent()
        {
            this.textLoadUnloadCode = new TextBox();
            this.label1 = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.textDesc = new TextBox();
            this.label2 = new Label();
            this.textStorage = new TextBox();
            this.label3 = new Label();
            this.groupBox2 = new GroupBox();
            this.radioUnload = new RadioButton();
            this.radioLoad = new RadioButton();
            this.groupBox2.SuspendLayout();
            base.SuspendLayout();
            this.textLoadUnloadCode.CharacterCasing = CharacterCasing.Upper;
            this.textLoadUnloadCode.Location = new Point(0x7f, 12);
            this.textLoadUnloadCode.Name = "textLoadUnloadCode";
            this.textLoadUnloadCode.Size = new Size(0xa5, 20);
            this.textLoadUnloadCode.TabIndex = 2;
            this.textLoadUnloadCode.KeyPress += new KeyPressEventHandler(this.textLoadUnloadCode_KeyPress);
            this.label1.Location = new Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x6d, 0x11);
            this.label1.TabIndex = 1;
            this.label1.Text = "LoadUnload Code";
            this.label1.TextAlign = ContentAlignment.TopRight;
            this.button2.Location = new Point(0x18b, 0x9c);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x63, 30);
            this.button2.TabIndex = 14;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(290, 0x9c);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x63, 30);
            this.button1.TabIndex = 13;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textDesc.Location = new Point(0x7f, 0x26);
            this.textDesc.Name = "textDesc";
            this.textDesc.Size = new Size(0x180, 20);
            this.textDesc.TabIndex = 0x10;
            this.label2.Location = new Point(12, 0x29);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x6d, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Description";
            this.label2.TextAlign = ContentAlignment.TopRight;
            this.textStorage.CharacterCasing = CharacterCasing.Upper;
            this.textStorage.Location = new Point(0x7f, 0x40);
            this.textStorage.Name = "textStorage";
            this.textStorage.Size = new Size(0xa5, 20);
            this.textStorage.TabIndex = 0x12;
            this.textStorage.KeyPress += new KeyPressEventHandler(this.textStorage_KeyPress);
            this.label3.Location = new Point(12, 0x43);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x6d, 13);
            this.label3.TabIndex = 0x11;
            this.label3.Text = "Storage Loc";
            this.label3.TextAlign = ContentAlignment.TopRight;
            this.groupBox2.Controls.Add(this.radioUnload);
            this.groupBox2.Controls.Add(this.radioLoad);
            this.groupBox2.Location = new Point(0x7f, 90);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0xb7, 60);
            this.groupBox2.TabIndex = 0x1d;
            this.groupBox2.TabStop = false;
            this.radioUnload.AutoSize = true;
            this.radioUnload.Location = new Point(6, 0x25);
            this.radioUnload.Name = "radioUnload";
            this.radioUnload.Size = new Size(0x49, 0x11);
            this.radioUnload.TabIndex = 1;
            this.radioUnload.TabStop = true;
            this.radioUnload.Text = "Unloading";
            this.radioUnload.UseVisualStyleBackColor = true;
            this.radioLoad.AutoSize = true;
            this.radioLoad.Checked = true;
            this.radioLoad.Location = new Point(6, 14);
            this.radioLoad.Name = "radioLoad";
            this.radioLoad.Size = new Size(0x3f, 0x11);
            this.radioLoad.TabIndex = 0;
            this.radioLoad.TabStop = true;
            this.radioLoad.Text = "Loading";
            this.radioLoad.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x214, 0xc6);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.textStorage);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textDesc);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textLoadUnloadCode);
            base.Controls.Add(this.label1);
            base.Name = "FormLoadUnloadEntry";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Load Unload Entry";
            base.Load += new EventHandler(this.FormLoadUnloadEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormLoadUnloadEntry_KeyPress);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void textEstate_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textGroup_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textLoadUnloadCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textMM_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textSD_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textStorage_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.label1.Text = Resource.Load_001;
            this.label2.Text = Resource.Load_002;
            this.label3.Text = Resource.Load_003;
            this.radioLoad.Text = Resource.Load_004;
            this.radioUnload.Text = Resource.Load_005;
            this.button1.Text = Resource.Save;
            this.button2.Text = Resource.Menu_Cancel;
        }
    }
}

