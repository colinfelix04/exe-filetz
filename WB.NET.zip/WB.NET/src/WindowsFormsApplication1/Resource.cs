﻿namespace WindowsFormsApplication1
{
    using System;
    using System.CodeDom.Compiler;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Globalization;
    using System.Resources;
    using System.Runtime.CompilerServices;

    [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0"), DebuggerNonUserCode, CompilerGenerated]
    internal class Resource
    {
        private static System.Resources.ResourceManager resourceMan;
        private static CultureInfo resourceCulture;

        internal Resource()
        {
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        internal static System.Resources.ResourceManager ResourceManager
        {
            get
            {
                if (ReferenceEquals(resourceMan, null))
                {
                    resourceMan = new System.Resources.ResourceManager("WindowsFormsApplication1.Resource", typeof(Resource).Assembly);
                }
                return resourceMan;
            }
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        internal static CultureInfo Culture
        {
            get => 
                resourceCulture;
            set => 
                resourceCulture = value;
        }

        internal static string _1stWeight =>
            ResourceManager.GetString("_1stWeight", resourceCulture);

        internal static string _2ndWeight =>
            ResourceManager.GetString("_2ndWeight", resourceCulture);

        internal static string _3rdWeight =>
            ResourceManager.GetString("_3rdWeight", resourceCulture);

        internal static string _4thWeight =>
            ResourceManager.GetString("_4thWeight", resourceCulture);

        internal static string ABW_001 =>
            ResourceManager.GetString("ABW_001", resourceCulture);

        internal static string ABW_002 =>
            ResourceManager.GetString("ABW_002", resourceCulture);

        internal static string ABW_003 =>
            ResourceManager.GetString("ABW_003", resourceCulture);

        internal static string ABW_004 =>
            ResourceManager.GetString("ABW_004", resourceCulture);

        internal static string ABW_005 =>
            ResourceManager.GetString("ABW_005", resourceCulture);

        internal static string ABW_006 =>
            ResourceManager.GetString("ABW_006", resourceCulture);

        internal static string ABW_007 =>
            ResourceManager.GetString("ABW_007", resourceCulture);

        internal static string ABW_008 =>
            ResourceManager.GetString("ABW_008", resourceCulture);

        internal static string ABW_009 =>
            ResourceManager.GetString("ABW_009", resourceCulture);

        internal static string ABW_010 =>
            ResourceManager.GetString("ABW_010", resourceCulture);

        internal static string ABW_011 =>
            ResourceManager.GetString("ABW_011", resourceCulture);

        internal static string ad_step1 =>
            ResourceManager.GetString("ad_step1", resourceCulture);

        internal static string ad_step1_1 =>
            ResourceManager.GetString("ad_step1_1", resourceCulture);

        internal static string ad_step2 =>
            ResourceManager.GetString("ad_step2", resourceCulture);

        internal static string ad_step2_1 =>
            ResourceManager.GetString("ad_step2_1", resourceCulture);

        internal static string ad_step2_2 =>
            ResourceManager.GetString("ad_step2_2", resourceCulture);

        internal static string ad_step2_3 =>
            ResourceManager.GetString("ad_step2_3", resourceCulture);

        internal static string ad_step2_4 =>
            ResourceManager.GetString("ad_step2_4", resourceCulture);

        internal static string ad_step2_5 =>
            ResourceManager.GetString("ad_step2_5", resourceCulture);

        internal static string ADPATH_ERR01 =>
            ResourceManager.GetString("ADPATH_ERR01", resourceCulture);

        internal static string ADPATHERR02 =>
            ResourceManager.GetString("ADPATHERR02", resourceCulture);

        internal static string Block_001 =>
            ResourceManager.GetString("Block_001", resourceCulture);

        internal static string Block_002 =>
            ResourceManager.GetString("Block_002", resourceCulture);

        internal static string Block_003 =>
            ResourceManager.GetString("Block_003", resourceCulture);

        internal static string Block_004 =>
            ResourceManager.GetString("Block_004", resourceCulture);

        internal static string Block_005 =>
            ResourceManager.GetString("Block_005", resourceCulture);

        internal static string Block_006 =>
            ResourceManager.GetString("Block_006", resourceCulture);

        internal static string Block_007 =>
            ResourceManager.GetString("Block_007", resourceCulture);

        internal static string Block_008 =>
            ResourceManager.GetString("Block_008", resourceCulture);

        internal static string btn_ad_next =>
            ResourceManager.GetString("btn_ad_next", resourceCulture);

        internal static string btn_ad_ok =>
            ResourceManager.GetString("btn_ad_ok", resourceCulture);

        internal static string btn_ad_previous =>
            ResourceManager.GetString("btn_ad_previous", resourceCulture);

        internal static string Btn_Add_Item =>
            ResourceManager.GetString("Btn_Add_Item", resourceCulture);

        internal static string Btn_Adopt =>
            ResourceManager.GetString("Btn_Adopt", resourceCulture);

        internal static string Btn_Adopt_SAP =>
            ResourceManager.GetString("Btn_Adopt_SAP", resourceCulture);

        internal static string Btn_Automate_Form =>
            ResourceManager.GetString("Btn_Automate_Form", resourceCulture);

        internal static string Btn_Back =>
            ResourceManager.GetString("Btn_Back", resourceCulture);

        internal static string Btn_Cancel =>
            ResourceManager.GetString("Btn_Cancel", resourceCulture);

        internal static string Btn_Check_OS =>
            ResourceManager.GetString("Btn_Check_OS", resourceCulture);

        internal static string Btn_Close =>
            ResourceManager.GetString("Btn_Close", resourceCulture);

        internal static string Btn_Done =>
            ResourceManager.GetString("Btn_Done", resourceCulture);

        internal static string Btn_Down =>
            ResourceManager.GetString("Btn_Down", resourceCulture);

        internal static string Btn_Edit =>
            ResourceManager.GetString("Btn_Edit", resourceCulture);

        internal static string Btn_Grading_Control =>
            ResourceManager.GetString("Btn_Grading_Control", resourceCulture);

        internal static string Btn_Process =>
            ResourceManager.GetString("Btn_Process", resourceCulture);

        internal static string Btn_Quality_Control =>
            ResourceManager.GetString("Btn_Quality_Control", resourceCulture);

        internal static string Btn_Remove =>
            ResourceManager.GetString("Btn_Remove", resourceCulture);

        internal static string Btn_Request_PIN =>
            ResourceManager.GetString("Btn_Request_PIN", resourceCulture);

        internal static string Btn_Reversed =>
            ResourceManager.GetString("Btn_Reversed", resourceCulture);

        internal static string Btn_Save =>
            ResourceManager.GetString("Btn_Save", resourceCulture);

        internal static string Btn_Select_All =>
            ResourceManager.GetString("Btn_Select_All", resourceCulture);

        internal static string Btn_Test_Capture =>
            ResourceManager.GetString("Btn_Test_Capture", resourceCulture);

        internal static string Btn_Test_Formula =>
            ResourceManager.GetString("Btn_Test_Formula", resourceCulture);

        internal static string Btn_Test_Send =>
            ResourceManager.GetString("Btn_Test_Send", resourceCulture);

        internal static string Btn_Unselect_All =>
            ResourceManager.GetString("Btn_Unselect_All", resourceCulture);

        internal static string Btn_Up =>
            ResourceManager.GetString("Btn_Up", resourceCulture);

        internal static string Camera_001 =>
            ResourceManager.GetString("Camera_001", resourceCulture);

        internal static string Camera_002 =>
            ResourceManager.GetString("Camera_002", resourceCulture);

        internal static string Camera_003 =>
            ResourceManager.GetString("Camera_003", resourceCulture);

        internal static string Camera_004 =>
            ResourceManager.GetString("Camera_004", resourceCulture);

        internal static string CameraCapt_001 =>
            ResourceManager.GetString("CameraCapt_001", resourceCulture);

        internal static string CHECKRETURN001 =>
            ResourceManager.GetString("CHECKRETURN001", resourceCulture);

        internal static string CHECKRETURN002 =>
            ResourceManager.GetString("CHECKRETURN002", resourceCulture);

        internal static string Chk_Adopt_SAP =>
            ResourceManager.GetString("Chk_Adopt_SAP", resourceCulture);

        internal static string Chk_All_DO =>
            ResourceManager.GetString("Chk_All_DO", resourceCulture);

        internal static string Chk_Berikat =>
            ResourceManager.GetString("Chk_Berikat", resourceCulture);

        internal static string Chk_calculate_loading_qty =>
            ResourceManager.GetString("Chk_calculate_loading_qty", resourceCulture);

        internal static string Chk_Deduct_Receive =>
            ResourceManager.GetString("Chk_Deduct_Receive", resourceCulture);

        internal static string Chk_Deleted_Certification =>
            ResourceManager.GetString("Chk_Deleted_Certification", resourceCulture);

        internal static string Chk_DO_Vessel_Completed =>
            ResourceManager.GetString("Chk_DO_Vessel_Completed", resourceCulture);

        internal static string Chk_Fixed_Value =>
            ResourceManager.GetString("Chk_Fixed_Value", resourceCulture);

        internal static string Chk_Gain_Loss =>
            ResourceManager.GetString("Chk_Gain_Loss", resourceCulture);

        internal static string Chk_Is_Return =>
            ResourceManager.GetString("Chk_Is_Return", resourceCulture);

        internal static string Chk_Is_Vessel =>
            ResourceManager.GetString("Chk_Is_Vessel", resourceCulture);

        internal static string Chk_ISCC_Cert =>
            ResourceManager.GetString("Chk_ISCC_Cert", resourceCulture);

        internal static string Chk_ISSC_Certified =>
            ResourceManager.GetString("Chk_ISSC_Certified", resourceCulture);

        internal static string Chk_MS_In_Trx =>
            ResourceManager.GetString("Chk_MS_In_Trx", resourceCulture);

        internal static string Chk_Req_Internal_No =>
            ResourceManager.GetString("Chk_Req_Internal_No", resourceCulture);

        internal static string Chk_Req_Internal_No_IDSYS =>
            ResourceManager.GetString("Chk_Req_Internal_No_IDSYS", resourceCulture);

        internal static string Chk_Show_All_DO =>
            ResourceManager.GetString("Chk_Show_All_DO", resourceCulture);

        internal static string Chk_Show_Closed =>
            ResourceManager.GetString("Chk_Show_Closed", resourceCulture);

        internal static string Chk_Show_Password =>
            ResourceManager.GetString("Chk_Show_Password", resourceCulture);

        internal static string Chk_STO_1_DO =>
            ResourceManager.GetString("Chk_STO_1_DO", resourceCulture);

        internal static string Col_Adopt_SAP =>
            ResourceManager.GetString("Col_Adopt_SAP", resourceCulture);

        internal static string Col_Automatic_Interval =>
            ResourceManager.GetString("Col_Automatic_Interval", resourceCulture);

        internal static string Col_Automatic_Time =>
            ResourceManager.GetString("Col_Automatic_Time", resourceCulture);

        internal static string Col_Automatic_Upload =>
            ResourceManager.GetString("Col_Automatic_Upload", resourceCulture);

        internal static string Col_BC_Item =>
            ResourceManager.GetString("Col_BC_Item", resourceCulture);

        internal static string Col_BC_Qty =>
            ResourceManager.GetString("Col_BC_Qty", resourceCulture);

        internal static string Col_BC_Type =>
            ResourceManager.GetString("Col_BC_Type", resourceCulture);

        internal static string Col_BC_UoM =>
            ResourceManager.GetString("Col_BC_UoM", resourceCulture);

        internal static string Col_Calibration_Date =>
            ResourceManager.GetString("Col_Calibration_Date", resourceCulture);

        internal static string Col_Camera_Code =>
            ResourceManager.GetString("Col_Camera_Code", resourceCulture);

        internal static string Col_Certification_No =>
            ResourceManager.GetString("Col_Certification_No", resourceCulture);

        internal static string Col_Coy =>
            ResourceManager.GetString("Col_Coy", resourceCulture);

        internal static string Col_Deduct_Net =>
            ResourceManager.GetString("Col_Deduct_Net", resourceCulture);

        internal static string Col_Delete_By =>
            ResourceManager.GetString("Col_Delete_By", resourceCulture);

        internal static string Col_Delete_Date =>
            ResourceManager.GetString("Col_Delete_Date", resourceCulture);

        internal static string Col_Department =>
            ResourceManager.GetString("Col_Department", resourceCulture);

        internal static string Col_DO_Qty =>
            ResourceManager.GetString("Col_DO_Qty", resourceCulture);

        internal static string Col_Edit_By =>
            ResourceManager.GetString("Col_Edit_By", resourceCulture);

        internal static string Col_Edit_Date =>
            ResourceManager.GetString("Col_Edit_Date", resourceCulture);

        internal static string Col_Email_Code =>
            ResourceManager.GetString("Col_Email_Code", resourceCulture);

        internal static string Col_Grading_Description =>
            ResourceManager.GetString("Col_Grading_Description", resourceCulture);

        internal static string Col_Incoterm_Code =>
            ResourceManager.GetString("Col_Incoterm_Code", resourceCulture);

        internal static string Col_IP_Address =>
            ResourceManager.GetString("Col_IP_Address", resourceCulture);

        internal static string Col_Loc_Code =>
            ResourceManager.GetString("Col_Loc_Code", resourceCulture);

        internal static string Col_Location_Name =>
            ResourceManager.GetString("Col_Location_Name", resourceCulture);

        internal static string Col_Lock_Weighing =>
            ResourceManager.GetString("Col_Lock_Weighing", resourceCulture);

        internal static string Col_Material =>
            ResourceManager.GetString("Col_Material", resourceCulture);

        internal static string Col_Netto_Weight =>
            ResourceManager.GetString("Col_Netto_Weight", resourceCulture);

        internal static string Col_Owner_Batch =>
            ResourceManager.GetString("Col_Owner_Batch", resourceCulture);

        internal static string Col_Owner_Code =>
            ResourceManager.GetString("Col_Owner_Code", resourceCulture);

        internal static string Col_Protect_Excel =>
            ResourceManager.GetString("Col_Protect_Excel", resourceCulture);

        internal static string Col_QC_Description =>
            ResourceManager.GetString("Col_QC_Description", resourceCulture);

        internal static string Col_Qty_Used =>
            ResourceManager.GetString("Col_Qty_Used", resourceCulture);

        internal static string Col_Quantity_KG =>
            ResourceManager.GetString("Col_Quantity_KG", resourceCulture);

        internal static string Col_Quantity_UOM =>
            ResourceManager.GetString("Col_Quantity_UOM", resourceCulture);

        internal static string Col_Remark_Division =>
            ResourceManager.GetString("Col_Remark_Division", resourceCulture);

        internal static string Col_Return_Type =>
            ResourceManager.GetString("Col_Return_Type", resourceCulture);

        internal static string Col_SO_No =>
            ResourceManager.GetString("Col_SO_No", resourceCulture);

        internal static string Col_Timbun_Code =>
            ResourceManager.GetString("Col_Timbun_Code", resourceCulture);

        internal static string Col_Timbun_Location_Code =>
            ResourceManager.GetString("Col_Timbun_Location_Code", resourceCulture);

        internal static string Col_Tracking_Item =>
            ResourceManager.GetString("Col_Tracking_Item", resourceCulture);

        internal static string Col_Tracking_No =>
            ResourceManager.GetString("Col_Tracking_No", resourceCulture);

        internal static string Col_Vessel_Transaction =>
            ResourceManager.GetString("Col_Vessel_Transaction", resourceCulture);

        internal static string Col_Warn_If_Outspec =>
            ResourceManager.GetString("Col_Warn_If_Outspec", resourceCulture);

        internal static string Col_WB_Location =>
            ResourceManager.GetString("Col_WB_Location", resourceCulture);

        internal static string Col_Web_Url =>
            ResourceManager.GetString("Col_Web_Url", resourceCulture);

        internal static string CommE_001 =>
            ResourceManager.GetString("CommE_001", resourceCulture);

        internal static string CommE_002 =>
            ResourceManager.GetString("CommE_002", resourceCulture);

        internal static string CommE_003 =>
            ResourceManager.GetString("CommE_003", resourceCulture);

        internal static string CommE_004 =>
            ResourceManager.GetString("CommE_004", resourceCulture);

        internal static string CommE_005 =>
            ResourceManager.GetString("CommE_005", resourceCulture);

        internal static string CommE_006 =>
            ResourceManager.GetString("CommE_006", resourceCulture);

        internal static string CommE_007 =>
            ResourceManager.GetString("CommE_007", resourceCulture);

        internal static string CommE_008 =>
            ResourceManager.GetString("CommE_008", resourceCulture);

        internal static string CommE_009 =>
            ResourceManager.GetString("CommE_009", resourceCulture);

        internal static string CommE_010 =>
            ResourceManager.GetString("CommE_010", resourceCulture);

        internal static string CommE_011 =>
            ResourceManager.GetString("CommE_011", resourceCulture);

        internal static string CommE_012 =>
            ResourceManager.GetString("CommE_012", resourceCulture);

        internal static string CommE_013 =>
            ResourceManager.GetString("CommE_013", resourceCulture);

        internal static string CommE_014 =>
            ResourceManager.GetString("CommE_014", resourceCulture);

        internal static string CommE_015 =>
            ResourceManager.GetString("CommE_015", resourceCulture);

        internal static string CommE_016 =>
            ResourceManager.GetString("CommE_016", resourceCulture);

        internal static string CommE_017 =>
            ResourceManager.GetString("CommE_017", resourceCulture);

        internal static string CommE_018 =>
            ResourceManager.GetString("CommE_018", resourceCulture);

        internal static string CommE_019 =>
            ResourceManager.GetString("CommE_019", resourceCulture);

        internal static string CommE_020 =>
            ResourceManager.GetString("CommE_020", resourceCulture);

        internal static string CommE_021 =>
            ResourceManager.GetString("CommE_021", resourceCulture);

        internal static string CommE_022 =>
            ResourceManager.GetString("CommE_022", resourceCulture);

        internal static string Composite_001 =>
            ResourceManager.GetString("Composite_001", resourceCulture);

        internal static string Composite_002 =>
            ResourceManager.GetString("Composite_002", resourceCulture);

        internal static string Composite_003 =>
            ResourceManager.GetString("Composite_003", resourceCulture);

        internal static string Composite_004 =>
            ResourceManager.GetString("Composite_004", resourceCulture);

        internal static string Composite_005 =>
            ResourceManager.GetString("Composite_005", resourceCulture);

        internal static string Composite_006 =>
            ResourceManager.GetString("Composite_006", resourceCulture);

        internal static string Composite_007 =>
            ResourceManager.GetString("Composite_007", resourceCulture);

        internal static string Condition_001 =>
            ResourceManager.GetString("Condition_001", resourceCulture);

        internal static string Condition_002 =>
            ResourceManager.GetString("Condition_002", resourceCulture);

        internal static string Condition_003 =>
            ResourceManager.GetString("Condition_003", resourceCulture);

        internal static string Condition_004 =>
            ResourceManager.GetString("Condition_004", resourceCulture);

        internal static string Condition_005 =>
            ResourceManager.GetString("Condition_005", resourceCulture);

        internal static string Condition_N =>
            ResourceManager.GetString("Condition_N", resourceCulture);

        internal static string Condition_Y =>
            ResourceManager.GetString("Condition_Y", resourceCulture);

        internal static string ContainerOut_001 =>
            ResourceManager.GetString("ContainerOut_001", resourceCulture);

        internal static string ContainerOut_002 =>
            ResourceManager.GetString("ContainerOut_002", resourceCulture);

        internal static string ContainerOut_003 =>
            ResourceManager.GetString("ContainerOut_003", resourceCulture);

        internal static string ContainerOut_004 =>
            ResourceManager.GetString("ContainerOut_004", resourceCulture);

        internal static string ContainerOut_005 =>
            ResourceManager.GetString("ContainerOut_005", resourceCulture);

        internal static string ContainerOut_006 =>
            ResourceManager.GetString("ContainerOut_006", resourceCulture);

        internal static string ContainerOut_007 =>
            ResourceManager.GetString("ContainerOut_007", resourceCulture);

        internal static string ContainerOut_008 =>
            ResourceManager.GetString("ContainerOut_008", resourceCulture);

        internal static string ContainerOut_009 =>
            ResourceManager.GetString("ContainerOut_009", resourceCulture);

        internal static string ContainerOut_010 =>
            ResourceManager.GetString("ContainerOut_010", resourceCulture);

        internal static string ContainerOut_011 =>
            ResourceManager.GetString("ContainerOut_011", resourceCulture);

        internal static string ContainerOut_012 =>
            ResourceManager.GetString("ContainerOut_012", resourceCulture);

        internal static string ContainerOut_013 =>
            ResourceManager.GetString("ContainerOut_013", resourceCulture);

        internal static string ContainerOut_014 =>
            ResourceManager.GetString("ContainerOut_014", resourceCulture);

        internal static string ContainerOut_015 =>
            ResourceManager.GetString("ContainerOut_015", resourceCulture);

        internal static string ContainerOut_016 =>
            ResourceManager.GetString("ContainerOut_016", resourceCulture);

        internal static string ContainerOut_017 =>
            ResourceManager.GetString("ContainerOut_017", resourceCulture);

        internal static string ContainerOut_018 =>
            ResourceManager.GetString("ContainerOut_018", resourceCulture);

        internal static string ContainerOut_019 =>
            ResourceManager.GetString("ContainerOut_019", resourceCulture);

        internal static string ContainerOut_020 =>
            ResourceManager.GetString("ContainerOut_020", resourceCulture);

        internal static string ContainerOut_021 =>
            ResourceManager.GetString("ContainerOut_021", resourceCulture);

        internal static string ContainerOut_022 =>
            ResourceManager.GetString("ContainerOut_022", resourceCulture);

        internal static string ContainerOut_023 =>
            ResourceManager.GetString("ContainerOut_023", resourceCulture);

        internal static string ContainerOut_024 =>
            ResourceManager.GetString("ContainerOut_024", resourceCulture);

        internal static string ContainerOut_025 =>
            ResourceManager.GetString("ContainerOut_025", resourceCulture);

        internal static string ContainerOut_026 =>
            ResourceManager.GetString("ContainerOut_026", resourceCulture);

        internal static string ContainerOut_027 =>
            ResourceManager.GetString("ContainerOut_027", resourceCulture);

        internal static string ContainerOut_028 =>
            ResourceManager.GetString("ContainerOut_028", resourceCulture);

        internal static string ContainerOut_029 =>
            ResourceManager.GetString("ContainerOut_029", resourceCulture);

        internal static string ContainerOut_030 =>
            ResourceManager.GetString("ContainerOut_030", resourceCulture);

        internal static string ContainerOut_031 =>
            ResourceManager.GetString("ContainerOut_031", resourceCulture);

        internal static string ContainerOut_032 =>
            ResourceManager.GetString("ContainerOut_032", resourceCulture);

        internal static string ContainerOut_033 =>
            ResourceManager.GetString("ContainerOut_033", resourceCulture);

        internal static string ContainerOut_034 =>
            ResourceManager.GetString("ContainerOut_034", resourceCulture);

        internal static string ContainerOut_035 =>
            ResourceManager.GetString("ContainerOut_035", resourceCulture);

        internal static string ContainerOut_036 =>
            ResourceManager.GetString("ContainerOut_036", resourceCulture);

        internal static string ContainerOut_037 =>
            ResourceManager.GetString("ContainerOut_037", resourceCulture);

        internal static string ContainerOut_038 =>
            ResourceManager.GetString("ContainerOut_038", resourceCulture);

        internal static string ContainerOut_039 =>
            ResourceManager.GetString("ContainerOut_039", resourceCulture);

        internal static string ContainerOut_040 =>
            ResourceManager.GetString("ContainerOut_040", resourceCulture);

        internal static string ContainerOut_041 =>
            ResourceManager.GetString("ContainerOut_041", resourceCulture);

        internal static string ContainerOut_042 =>
            ResourceManager.GetString("ContainerOut_042", resourceCulture);

        internal static string Contract_001 =>
            ResourceManager.GetString("Contract_001", resourceCulture);

        internal static string Contract_002 =>
            ResourceManager.GetString("Contract_002", resourceCulture);

        internal static string Contract_003 =>
            ResourceManager.GetString("Contract_003", resourceCulture);

        internal static string Contract_004 =>
            ResourceManager.GetString("Contract_004", resourceCulture);

        internal static string Contract_005 =>
            ResourceManager.GetString("Contract_005", resourceCulture);

        internal static string Contract_006 =>
            ResourceManager.GetString("Contract_006", resourceCulture);

        internal static string Contract_007 =>
            ResourceManager.GetString("Contract_007", resourceCulture);

        internal static string Contract_008 =>
            ResourceManager.GetString("Contract_008", resourceCulture);

        internal static string Contract_009 =>
            ResourceManager.GetString("Contract_009", resourceCulture);

        internal static string Contract_010 =>
            ResourceManager.GetString("Contract_010", resourceCulture);

        internal static string Contract_011 =>
            ResourceManager.GetString("Contract_011", resourceCulture);

        internal static string Contract_012 =>
            ResourceManager.GetString("Contract_012", resourceCulture);

        internal static string Contract_013 =>
            ResourceManager.GetString("Contract_013", resourceCulture);

        internal static string Contract_014 =>
            ResourceManager.GetString("Contract_014", resourceCulture);

        internal static string Contract_015 =>
            ResourceManager.GetString("Contract_015", resourceCulture);

        internal static string Contract_016 =>
            ResourceManager.GetString("Contract_016", resourceCulture);

        internal static string Contract_017 =>
            ResourceManager.GetString("Contract_017", resourceCulture);

        internal static string Contract_018 =>
            ResourceManager.GetString("Contract_018", resourceCulture);

        internal static string Contract_019 =>
            ResourceManager.GetString("Contract_019", resourceCulture);

        internal static string Contract_020 =>
            ResourceManager.GetString("Contract_020", resourceCulture);

        internal static string Contract_021 =>
            ResourceManager.GetString("Contract_021", resourceCulture);

        internal static string Contract_022 =>
            ResourceManager.GetString("Contract_022", resourceCulture);

        internal static string Contract_023 =>
            ResourceManager.GetString("Contract_023", resourceCulture);

        internal static string Contract_024 =>
            ResourceManager.GetString("Contract_024", resourceCulture);

        internal static string Contract_025 =>
            ResourceManager.GetString("Contract_025", resourceCulture);

        internal static string Contract_026 =>
            ResourceManager.GetString("Contract_026", resourceCulture);

        internal static string Contract_027 =>
            ResourceManager.GetString("Contract_027", resourceCulture);

        internal static string Contract_028 =>
            ResourceManager.GetString("Contract_028", resourceCulture);

        internal static string Contract_029 =>
            ResourceManager.GetString("Contract_029", resourceCulture);

        internal static string Contract_030 =>
            ResourceManager.GetString("Contract_030", resourceCulture);

        internal static string Contract_031 =>
            ResourceManager.GetString("Contract_031", resourceCulture);

        internal static string Contract_032 =>
            ResourceManager.GetString("Contract_032", resourceCulture);

        internal static string Contract_033 =>
            ResourceManager.GetString("Contract_033", resourceCulture);

        internal static string Contract_034 =>
            ResourceManager.GetString("Contract_034", resourceCulture);

        internal static string Contract_035 =>
            ResourceManager.GetString("Contract_035", resourceCulture);

        internal static string Contract_036 =>
            ResourceManager.GetString("Contract_036", resourceCulture);

        internal static string Contract_037 =>
            ResourceManager.GetString("Contract_037", resourceCulture);

        internal static string Contract_038 =>
            ResourceManager.GetString("Contract_038", resourceCulture);

        internal static string Contract_039 =>
            ResourceManager.GetString("Contract_039", resourceCulture);

        internal static string Contract_040 =>
            ResourceManager.GetString("Contract_040", resourceCulture);

        internal static string Contract_041 =>
            ResourceManager.GetString("Contract_041", resourceCulture);

        internal static string Contract_042 =>
            ResourceManager.GetString("Contract_042", resourceCulture);

        internal static string Contract_043 =>
            ResourceManager.GetString("Contract_043", resourceCulture);

        internal static string Contract_044 =>
            ResourceManager.GetString("Contract_044", resourceCulture);

        internal static string Contract_045 =>
            ResourceManager.GetString("Contract_045", resourceCulture);

        internal static string Contract_046 =>
            ResourceManager.GetString("Contract_046", resourceCulture);

        internal static string Contract_047 =>
            ResourceManager.GetString("Contract_047", resourceCulture);

        internal static string Contract_048 =>
            ResourceManager.GetString("Contract_048", resourceCulture);

        internal static string Contract_049 =>
            ResourceManager.GetString("Contract_049", resourceCulture);

        internal static string Contract_050 =>
            ResourceManager.GetString("Contract_050", resourceCulture);

        internal static string Contract_051 =>
            ResourceManager.GetString("Contract_051", resourceCulture);

        internal static string Contract_052 =>
            ResourceManager.GetString("Contract_052", resourceCulture);

        internal static string Contract_053 =>
            ResourceManager.GetString("Contract_053", resourceCulture);

        internal static string Contract_054 =>
            ResourceManager.GetString("Contract_054", resourceCulture);

        internal static string Contract_055 =>
            ResourceManager.GetString("Contract_055", resourceCulture);

        internal static string Contract_056 =>
            ResourceManager.GetString("Contract_056", resourceCulture);

        internal static string Contract_057 =>
            ResourceManager.GetString("Contract_057", resourceCulture);

        internal static string Contract_058 =>
            ResourceManager.GetString("Contract_058", resourceCulture);

        internal static string Contract_059 =>
            ResourceManager.GetString("Contract_059", resourceCulture);

        internal static string Contract_060 =>
            ResourceManager.GetString("Contract_060", resourceCulture);

        internal static string Contract_061 =>
            ResourceManager.GetString("Contract_061", resourceCulture);

        internal static string Contract_062 =>
            ResourceManager.GetString("Contract_062", resourceCulture);

        internal static string Contract_063 =>
            ResourceManager.GetString("Contract_063", resourceCulture);

        internal static string Contract_064 =>
            ResourceManager.GetString("Contract_064", resourceCulture);

        internal static string Contract_065 =>
            ResourceManager.GetString("Contract_065", resourceCulture);

        internal static string Contract_066 =>
            ResourceManager.GetString("Contract_066", resourceCulture);

        internal static string Contract_067 =>
            ResourceManager.GetString("Contract_067", resourceCulture);

        internal static string Contract_068 =>
            ResourceManager.GetString("Contract_068", resourceCulture);

        internal static string Contract_069 =>
            ResourceManager.GetString("Contract_069", resourceCulture);

        internal static string Contract_070 =>
            ResourceManager.GetString("Contract_070", resourceCulture);

        internal static string Contract_071 =>
            ResourceManager.GetString("Contract_071", resourceCulture);

        internal static string Contract_072 =>
            ResourceManager.GetString("Contract_072", resourceCulture);

        internal static string Contract_Berikat_ToolTip =>
            ResourceManager.GetString("Contract_Berikat_ToolTip", resourceCulture);

        internal static string Contract_Closed =>
            ResourceManager.GetString("Contract_Closed", resourceCulture);

        internal static string Contract_Confirmation_No =>
            ResourceManager.GetString("Contract_Confirmation_No", resourceCulture);

        internal static string Contract_DO_SO_Date =>
            ResourceManager.GetString("Contract_DO_SO_Date", resourceCulture);

        internal static string Contract_DO_SO_No =>
            ResourceManager.GetString("Contract_DO_SO_No", resourceCulture);

        internal static string Contract_Estate_ADM =>
            ResourceManager.GetString("Contract_Estate_ADM", resourceCulture);

        internal static string Contract_Estate_LAB =>
            ResourceManager.GetString("Contract_Estate_LAB", resourceCulture);

        internal static string Contract_Incoterm =>
            ResourceManager.GetString("Contract_Incoterm", resourceCulture);

        internal static string Contract_No =>
            ResourceManager.GetString("Contract_No", resourceCulture);

        internal static string Contract_PI_SI_No =>
            ResourceManager.GetString("Contract_PI_SI_No", resourceCulture);

        internal static string Contract_SAP_Mov_Type =>
            ResourceManager.GetString("Contract_SAP_Mov_Type", resourceCulture);

        internal static string Contract_Tolling_Company =>
            ResourceManager.GetString("Contract_Tolling_Company", resourceCulture);

        internal static string Contract_Transaction_Code_ToolTip =>
            ResourceManager.GetString("Contract_Transaction_Code_ToolTip", resourceCulture);

        internal static string ContractE_001 =>
            ResourceManager.GetString("ContractE_001", resourceCulture);

        internal static string ContractE_002 =>
            ResourceManager.GetString("ContractE_002", resourceCulture);

        internal static string ContractE_003 =>
            ResourceManager.GetString("ContractE_003", resourceCulture);

        internal static string ContractE_004 =>
            ResourceManager.GetString("ContractE_004", resourceCulture);

        internal static string ContractE_005 =>
            ResourceManager.GetString("ContractE_005", resourceCulture);

        internal static string ContractE_006 =>
            ResourceManager.GetString("ContractE_006", resourceCulture);

        internal static string ContractE_007 =>
            ResourceManager.GetString("ContractE_007", resourceCulture);

        internal static string ContractE_008 =>
            ResourceManager.GetString("ContractE_008", resourceCulture);

        internal static string ContractE_009 =>
            ResourceManager.GetString("ContractE_009", resourceCulture);

        internal static string ContractE_010 =>
            ResourceManager.GetString("ContractE_010", resourceCulture);

        internal static string ContractE_011 =>
            ResourceManager.GetString("ContractE_011", resourceCulture);

        internal static string ContractE_012 =>
            ResourceManager.GetString("ContractE_012", resourceCulture);

        internal static string ContractE_013 =>
            ResourceManager.GetString("ContractE_013", resourceCulture);

        internal static string ContractE_014 =>
            ResourceManager.GetString("ContractE_014", resourceCulture);

        internal static string ContractE_015 =>
            ResourceManager.GetString("ContractE_015", resourceCulture);

        internal static string ContractE_016 =>
            ResourceManager.GetString("ContractE_016", resourceCulture);

        internal static string ContractE_017 =>
            ResourceManager.GetString("ContractE_017", resourceCulture);

        internal static string ContractE_018 =>
            ResourceManager.GetString("ContractE_018", resourceCulture);

        internal static string ContractE_019 =>
            ResourceManager.GetString("ContractE_019", resourceCulture);

        internal static string ContractE_020 =>
            ResourceManager.GetString("ContractE_020", resourceCulture);

        internal static string ContractE_021 =>
            ResourceManager.GetString("ContractE_021", resourceCulture);

        internal static string ContractE_022 =>
            ResourceManager.GetString("ContractE_022", resourceCulture);

        internal static string ContractE_023 =>
            ResourceManager.GetString("ContractE_023", resourceCulture);

        internal static string ContractE_024 =>
            ResourceManager.GetString("ContractE_024", resourceCulture);

        internal static string ContractE_025 =>
            ResourceManager.GetString("ContractE_025", resourceCulture);

        internal static string ContractE_026 =>
            ResourceManager.GetString("ContractE_026", resourceCulture);

        internal static string ContractE_027 =>
            ResourceManager.GetString("ContractE_027", resourceCulture);

        internal static string ContractE_028 =>
            ResourceManager.GetString("ContractE_028", resourceCulture);

        internal static string ContractE_029 =>
            ResourceManager.GetString("ContractE_029", resourceCulture);

        internal static string ContractE_030 =>
            ResourceManager.GetString("ContractE_030", resourceCulture);

        internal static string ContractE_031 =>
            ResourceManager.GetString("ContractE_031", resourceCulture);

        internal static string ContractE_032 =>
            ResourceManager.GetString("ContractE_032", resourceCulture);

        internal static string ContractE_033 =>
            ResourceManager.GetString("ContractE_033", resourceCulture);

        internal static string ContractE_034 =>
            ResourceManager.GetString("ContractE_034", resourceCulture);

        internal static string ContractE_035 =>
            ResourceManager.GetString("ContractE_035", resourceCulture);

        internal static string ContractE_036 =>
            ResourceManager.GetString("ContractE_036", resourceCulture);

        internal static string ContractE_037 =>
            ResourceManager.GetString("ContractE_037", resourceCulture);

        internal static string ContractE_038 =>
            ResourceManager.GetString("ContractE_038", resourceCulture);

        internal static string ContractE_039 =>
            ResourceManager.GetString("ContractE_039", resourceCulture);

        internal static string ContractE_040 =>
            ResourceManager.GetString("ContractE_040", resourceCulture);

        internal static string ContractE_041 =>
            ResourceManager.GetString("ContractE_041", resourceCulture);

        internal static string ContractE_042 =>
            ResourceManager.GetString("ContractE_042", resourceCulture);

        internal static string DbConn_001 =>
            ResourceManager.GetString("DbConn_001", resourceCulture);

        internal static string DbConn_002 =>
            ResourceManager.GetString("DbConn_002", resourceCulture);

        internal static string DbConn_003 =>
            ResourceManager.GetString("DbConn_003", resourceCulture);

        internal static string DbConn_004 =>
            ResourceManager.GetString("DbConn_004", resourceCulture);

        internal static string DbConn_005 =>
            ResourceManager.GetString("DbConn_005", resourceCulture);

        internal static string DbConn_006 =>
            ResourceManager.GetString("DbConn_006", resourceCulture);

        internal static string DbConn_007 =>
            ResourceManager.GetString("DbConn_007", resourceCulture);

        internal static string DbConn_008 =>
            ResourceManager.GetString("DbConn_008", resourceCulture);

        internal static string DbConn_009 =>
            ResourceManager.GetString("DbConn_009", resourceCulture);

        internal static string DbConn_010 =>
            ResourceManager.GetString("DbConn_010", resourceCulture);

        internal static string DeductionPerUnit_001 =>
            ResourceManager.GetString("DeductionPerUnit_001", resourceCulture);

        internal static string DeductionPerUnit_002 =>
            ResourceManager.GetString("DeductionPerUnit_002", resourceCulture);

        internal static string DeductionPerUnit_003 =>
            ResourceManager.GetString("DeductionPerUnit_003", resourceCulture);

        internal static string DeductionPerUnit_004 =>
            ResourceManager.GetString("DeductionPerUnit_004", resourceCulture);

        internal static string DeductionPerUnit_005 =>
            ResourceManager.GetString("DeductionPerUnit_005", resourceCulture);

        internal static string DeductionPerUnit_006 =>
            ResourceManager.GetString("DeductionPerUnit_006", resourceCulture);

        internal static string DeductionPerUnit_007 =>
            ResourceManager.GetString("DeductionPerUnit_007", resourceCulture);

        internal static string DeliveryNote_001 =>
            ResourceManager.GetString("DeliveryNote_001", resourceCulture);

        internal static string DeliveryNote_002 =>
            ResourceManager.GetString("DeliveryNote_002", resourceCulture);

        internal static string DeliveryNote_003 =>
            ResourceManager.GetString("DeliveryNote_003", resourceCulture);

        internal static string DeliveryNote_004 =>
            ResourceManager.GetString("DeliveryNote_004", resourceCulture);

        internal static string DeliveryNote_005 =>
            ResourceManager.GetString("DeliveryNote_005", resourceCulture);

        internal static string DeliveryNote_006 =>
            ResourceManager.GetString("DeliveryNote_006", resourceCulture);

        internal static string DeliveryNote_007 =>
            ResourceManager.GetString("DeliveryNote_007", resourceCulture);

        internal static string DeliveryNote_008 =>
            ResourceManager.GetString("DeliveryNote_008", resourceCulture);

        internal static string DeliveryNote_009 =>
            ResourceManager.GetString("DeliveryNote_009", resourceCulture);

        internal static string DeliveryNote_010 =>
            ResourceManager.GetString("DeliveryNote_010", resourceCulture);

        internal static string DivBlock_001 =>
            ResourceManager.GetString("DivBlock_001", resourceCulture);

        internal static string DivBlock_002 =>
            ResourceManager.GetString("DivBlock_002", resourceCulture);

        internal static string DivBlock_003 =>
            ResourceManager.GetString("DivBlock_003", resourceCulture);

        internal static string DivBlock_004 =>
            ResourceManager.GetString("DivBlock_004", resourceCulture);

        internal static string DivBlock_005 =>
            ResourceManager.GetString("DivBlock_005", resourceCulture);

        internal static string DivBlock_006 =>
            ResourceManager.GetString("DivBlock_006", resourceCulture);

        internal static string DivBlock_007 =>
            ResourceManager.GetString("DivBlock_007", resourceCulture);

        internal static string DivBlock_008 =>
            ResourceManager.GetString("DivBlock_008", resourceCulture);

        internal static string DivBlock_009 =>
            ResourceManager.GetString("DivBlock_009", resourceCulture);

        internal static string Division_001 =>
            ResourceManager.GetString("Division_001", resourceCulture);

        internal static string Division_002 =>
            ResourceManager.GetString("Division_002", resourceCulture);

        internal static string Division_003 =>
            ResourceManager.GetString("Division_003", resourceCulture);

        internal static string Division_004 =>
            ResourceManager.GetString("Division_004", resourceCulture);

        internal static string DoE_001 =>
            ResourceManager.GetString("DoE_001", resourceCulture);

        internal static string DoE_002 =>
            ResourceManager.GetString("DoE_002", resourceCulture);

        internal static string DoE_003 =>
            ResourceManager.GetString("DoE_003", resourceCulture);

        internal static string DoE_004 =>
            ResourceManager.GetString("DoE_004", resourceCulture);

        internal static string DoE_005 =>
            ResourceManager.GetString("DoE_005", resourceCulture);

        internal static string DoE_006 =>
            ResourceManager.GetString("DoE_006", resourceCulture);

        internal static string DoE_007 =>
            ResourceManager.GetString("DoE_007", resourceCulture);

        internal static string DoE_008 =>
            ResourceManager.GetString("DoE_008", resourceCulture);

        internal static string DoE_009 =>
            ResourceManager.GetString("DoE_009", resourceCulture);

        internal static string DoE_010 =>
            ResourceManager.GetString("DoE_010", resourceCulture);

        internal static string DoE_011 =>
            ResourceManager.GetString("DoE_011", resourceCulture);

        internal static string DoE_012 =>
            ResourceManager.GetString("DoE_012", resourceCulture);

        internal static string DoE_013 =>
            ResourceManager.GetString("DoE_013", resourceCulture);

        internal static string DOMapVessel_001 =>
            ResourceManager.GetString("DOMapVessel_001", resourceCulture);

        internal static string DOMapVessel_002 =>
            ResourceManager.GetString("DOMapVessel_002", resourceCulture);

        internal static string DOMapVessel_003 =>
            ResourceManager.GetString("DOMapVessel_003", resourceCulture);

        internal static string DOMapVessel_004 =>
            ResourceManager.GetString("DOMapVessel_004", resourceCulture);

        internal static string DriverE_001 =>
            ResourceManager.GetString("DriverE_001", resourceCulture);

        internal static string DriverE_002 =>
            ResourceManager.GetString("DriverE_002", resourceCulture);

        internal static string DriverE_003 =>
            ResourceManager.GetString("DriverE_003", resourceCulture);

        internal static string DriverE_004 =>
            ResourceManager.GetString("DriverE_004", resourceCulture);

        internal static string DriverE_005 =>
            ResourceManager.GetString("DriverE_005", resourceCulture);

        internal static string DriverE_006 =>
            ResourceManager.GetString("DriverE_006", resourceCulture);

        internal static string DriverE_007 =>
            ResourceManager.GetString("DriverE_007", resourceCulture);

        internal static string DriverE_008 =>
            ResourceManager.GetString("DriverE_008", resourceCulture);

        internal static string DriverE_009 =>
            ResourceManager.GetString("DriverE_009", resourceCulture);

        internal static string DriverE_010 =>
            ResourceManager.GetString("DriverE_010", resourceCulture);

        internal static string DriverE_011 =>
            ResourceManager.GetString("DriverE_011", resourceCulture);

        internal static string Error_Conversion_DOSAP =>
            ResourceManager.GetString("Error_Conversion_DOSAP", resourceCulture);

        internal static string Estate_001 =>
            ResourceManager.GetString("Estate_001", resourceCulture);

        internal static string Estate_002 =>
            ResourceManager.GetString("Estate_002", resourceCulture);

        internal static string Estate_003 =>
            ResourceManager.GetString("Estate_003", resourceCulture);

        internal static string Estate_004 =>
            ResourceManager.GetString("Estate_004", resourceCulture);

        internal static string Estate_005 =>
            ResourceManager.GetString("Estate_005", resourceCulture);

        internal static string Estate_006 =>
            ResourceManager.GetString("Estate_006", resourceCulture);

        internal static string Estate_007 =>
            ResourceManager.GetString("Estate_007", resourceCulture);

        internal static string Estate_008 =>
            ResourceManager.GetString("Estate_008", resourceCulture);

        internal static string Estate_009 =>
            ResourceManager.GetString("Estate_009", resourceCulture);

        internal static string Filter_001 =>
            ResourceManager.GetString("Filter_001", resourceCulture);

        internal static string Filter_002 =>
            ResourceManager.GetString("Filter_002", resourceCulture);

        internal static string Filter_003 =>
            ResourceManager.GetString("Filter_003", resourceCulture);

        internal static string Filter_004 =>
            ResourceManager.GetString("Filter_004", resourceCulture);

        internal static string Filter_005 =>
            ResourceManager.GetString("Filter_005", resourceCulture);

        internal static string Form_Blacklist_Reason =>
            ResourceManager.GetString("Form_Blacklist_Reason", resourceCulture);

        internal static string Form_Delete_Reason =>
            ResourceManager.GetString("Form_Delete_Reason", resourceCulture);

        internal static string Form_Edit_DO =>
            ResourceManager.GetString("Form_Edit_DO", resourceCulture);

        internal static string Form_Mark_Delete_Reason =>
            ResourceManager.GetString("Form_Mark_Delete_Reason", resourceCulture);

        internal static string Form_Range_Delivery_Note =>
            ResourceManager.GetString("Form_Range_Delivery_Note", resourceCulture);

        internal static string Form_Unblacklist_Reason =>
            ResourceManager.GetString("Form_Unblacklist_Reason", resourceCulture);

        internal static string Form_Unmark_Delete_Reason =>
            ResourceManager.GetString("Form_Unmark_Delete_Reason", resourceCulture);

        internal static string FormLoadingInfo_001 =>
            ResourceManager.GetString("FormLoadingInfo_001", resourceCulture);

        internal static string FormLoadingInfo_002 =>
            ResourceManager.GetString("FormLoadingInfo_002", resourceCulture);

        internal static string FormLoadingInfo_003 =>
            ResourceManager.GetString("FormLoadingInfo_003", resourceCulture);

        internal static string FormLoadingInfo_004 =>
            ResourceManager.GetString("FormLoadingInfo_004", resourceCulture);

        internal static string FormLoadingInfo_005 =>
            ResourceManager.GetString("FormLoadingInfo_005", resourceCulture);

        internal static string Gatepass_001 =>
            ResourceManager.GetString("Gatepass_001", resourceCulture);

        internal static string Gatepass_002 =>
            ResourceManager.GetString("Gatepass_002", resourceCulture);

        internal static string Gatepass_003 =>
            ResourceManager.GetString("Gatepass_003", resourceCulture);

        internal static string Gatepass_004 =>
            ResourceManager.GetString("Gatepass_004", resourceCulture);

        internal static string Gatepass_005 =>
            ResourceManager.GetString("Gatepass_005", resourceCulture);

        internal static string Gatepass_006 =>
            ResourceManager.GetString("Gatepass_006", resourceCulture);

        internal static string Gatepass_007 =>
            ResourceManager.GetString("Gatepass_007", resourceCulture);

        internal static string Gatepass_008 =>
            ResourceManager.GetString("Gatepass_008", resourceCulture);

        internal static string Gatepass_009 =>
            ResourceManager.GetString("Gatepass_009", resourceCulture);

        internal static string Gatepass_010 =>
            ResourceManager.GetString("Gatepass_010", resourceCulture);

        internal static string Gatepass_011 =>
            ResourceManager.GetString("Gatepass_011", resourceCulture);

        internal static string Gatepass_012 =>
            ResourceManager.GetString("Gatepass_012", resourceCulture);

        internal static string Gatepass_013 =>
            ResourceManager.GetString("Gatepass_013", resourceCulture);

        internal static string Gatepass_014 =>
            ResourceManager.GetString("Gatepass_014", resourceCulture);

        internal static string Gatepass_015 =>
            ResourceManager.GetString("Gatepass_015", resourceCulture);

        internal static string Gatepass_016 =>
            ResourceManager.GetString("Gatepass_016", resourceCulture);

        internal static string Gatepass_017 =>
            ResourceManager.GetString("Gatepass_017", resourceCulture);

        internal static string Gatepass_018 =>
            ResourceManager.GetString("Gatepass_018", resourceCulture);

        internal static string Gatepass_019 =>
            ResourceManager.GetString("Gatepass_019", resourceCulture);

        internal static string Gatepass_020 =>
            ResourceManager.GetString("Gatepass_020", resourceCulture);

        internal static string Gatepass_021 =>
            ResourceManager.GetString("Gatepass_021", resourceCulture);

        internal static string Gatepass_022 =>
            ResourceManager.GetString("Gatepass_022", resourceCulture);

        internal static string Gatepass_023 =>
            ResourceManager.GetString("Gatepass_023", resourceCulture);

        internal static string Gatepass_024 =>
            ResourceManager.GetString("Gatepass_024", resourceCulture);

        internal static string Gatepass_025 =>
            ResourceManager.GetString("Gatepass_025", resourceCulture);

        internal static string Gatepass_026 =>
            ResourceManager.GetString("Gatepass_026", resourceCulture);

        internal static string Gatepass_027 =>
            ResourceManager.GetString("Gatepass_027", resourceCulture);

        internal static string Gatepass_028 =>
            ResourceManager.GetString("Gatepass_028", resourceCulture);

        internal static string Gatepass_029 =>
            ResourceManager.GetString("Gatepass_029", resourceCulture);

        internal static string Gatepass_030 =>
            ResourceManager.GetString("Gatepass_030", resourceCulture);

        internal static string Gatepass_031 =>
            ResourceManager.GetString("Gatepass_031", resourceCulture);

        internal static string Gatepass_032 =>
            ResourceManager.GetString("Gatepass_032", resourceCulture);

        internal static string Gatepass_033 =>
            ResourceManager.GetString("Gatepass_033", resourceCulture);

        internal static string Gatepass_034 =>
            ResourceManager.GetString("Gatepass_034", resourceCulture);

        internal static string Gatepass_035 =>
            ResourceManager.GetString("Gatepass_035", resourceCulture);

        internal static string Gatepass_036 =>
            ResourceManager.GetString("Gatepass_036", resourceCulture);

        internal static string Gatepass_037 =>
            ResourceManager.GetString("Gatepass_037", resourceCulture);

        internal static string Gatepass_038 =>
            ResourceManager.GetString("Gatepass_038", resourceCulture);

        internal static string Gatepass_039 =>
            ResourceManager.GetString("Gatepass_039", resourceCulture);

        internal static string Gatepass_040 =>
            ResourceManager.GetString("Gatepass_040", resourceCulture);

        internal static string Gatepass_041 =>
            ResourceManager.GetString("Gatepass_041", resourceCulture);

        internal static string Gatepass_042 =>
            ResourceManager.GetString("Gatepass_042", resourceCulture);

        internal static string Gatepass_043 =>
            ResourceManager.GetString("Gatepass_043", resourceCulture);

        internal static string Gatepass_044 =>
            ResourceManager.GetString("Gatepass_044", resourceCulture);

        internal static string Gatepass_045 =>
            ResourceManager.GetString("Gatepass_045", resourceCulture);

        internal static string Gatepass_046 =>
            ResourceManager.GetString("Gatepass_046", resourceCulture);

        internal static string Gatepass_047 =>
            ResourceManager.GetString("Gatepass_047", resourceCulture);

        internal static string Gatepass_048 =>
            ResourceManager.GetString("Gatepass_048", resourceCulture);

        internal static string Gatepass_049 =>
            ResourceManager.GetString("Gatepass_049", resourceCulture);

        internal static string Gatepass_050 =>
            ResourceManager.GetString("Gatepass_050", resourceCulture);

        internal static string Gatepass_051 =>
            ResourceManager.GetString("Gatepass_051", resourceCulture);

        internal static string Gatepass_052 =>
            ResourceManager.GetString("Gatepass_052", resourceCulture);

        internal static string Gatepass_053 =>
            ResourceManager.GetString("Gatepass_053", resourceCulture);

        internal static string Gatepass_054 =>
            ResourceManager.GetString("Gatepass_054", resourceCulture);

        internal static string Gatepass_055 =>
            ResourceManager.GetString("Gatepass_055", resourceCulture);

        internal static string Gatepass_056 =>
            ResourceManager.GetString("Gatepass_056", resourceCulture);

        internal static string Gatepass_057 =>
            ResourceManager.GetString("Gatepass_057", resourceCulture);

        internal static string Gatepass_058 =>
            ResourceManager.GetString("Gatepass_058", resourceCulture);

        internal static string Gatepass_059 =>
            ResourceManager.GetString("Gatepass_059", resourceCulture);

        internal static string Gatepass_060 =>
            ResourceManager.GetString("Gatepass_060", resourceCulture);

        internal static string Gatepass_061 =>
            ResourceManager.GetString("Gatepass_061", resourceCulture);

        internal static string Gatepass_062 =>
            ResourceManager.GetString("Gatepass_062", resourceCulture);

        internal static string Gatepass_063 =>
            ResourceManager.GetString("Gatepass_063", resourceCulture);

        internal static string Gatepass_064 =>
            ResourceManager.GetString("Gatepass_064", resourceCulture);

        internal static string Gatepass_065 =>
            ResourceManager.GetString("Gatepass_065", resourceCulture);

        internal static string Gatepass_066 =>
            ResourceManager.GetString("Gatepass_066", resourceCulture);

        internal static string Gatepass_067 =>
            ResourceManager.GetString("Gatepass_067", resourceCulture);

        internal static string Gatepass_068 =>
            ResourceManager.GetString("Gatepass_068", resourceCulture);

        internal static string Gatepass_069 =>
            ResourceManager.GetString("Gatepass_069", resourceCulture);

        internal static string Gatepass_070 =>
            ResourceManager.GetString("Gatepass_070", resourceCulture);

        internal static string Gatepass_071 =>
            ResourceManager.GetString("Gatepass_071", resourceCulture);

        internal static string Gatepass_072 =>
            ResourceManager.GetString("Gatepass_072", resourceCulture);

        internal static string Gatepass_073 =>
            ResourceManager.GetString("Gatepass_073", resourceCulture);

        internal static string Gatepass_074 =>
            ResourceManager.GetString("Gatepass_074", resourceCulture);

        internal static string Gatepass_075 =>
            ResourceManager.GetString("Gatepass_075", resourceCulture);

        internal static string Gatepass_076 =>
            ResourceManager.GetString("Gatepass_076", resourceCulture);

        internal static string Gatepass_077 =>
            ResourceManager.GetString("Gatepass_077", resourceCulture);

        internal static string Gbx_Account =>
            ResourceManager.GetString("Gbx_Account", resourceCulture);

        internal static string Gbx_Auto_Upload_Config =>
            ResourceManager.GetString("Gbx_Auto_Upload_Config", resourceCulture);

        internal static string Gbx_BJR_Per_Month =>
            ResourceManager.GetString("Gbx_BJR_Per_Month", resourceCulture);

        internal static string Gbx_Excel_Config =>
            ResourceManager.GetString("Gbx_Excel_Config", resourceCulture);

        internal static string Gbx_From_Value =>
            ResourceManager.GetString("Gbx_From_Value", resourceCulture);

        internal static string Gbx_Fruit_Types =>
            ResourceManager.GetString("Gbx_Fruit_Types", resourceCulture);

        internal static string Gbx_Gunny_Bale =>
            ResourceManager.GetString("Gbx_Gunny_Bale", resourceCulture);

        internal static string Gbx_Langsir_Type =>
            ResourceManager.GetString("Gbx_Langsir_Type", resourceCulture);

        internal static string Gbx_Lock_Weighing =>
            ResourceManager.GetString("Gbx_Lock_Weighing", resourceCulture);

        internal static string Gbx_Mapping =>
            ResourceManager.GetString("Gbx_Mapping", resourceCulture);

        internal static string Gbx_SAP_Reference =>
            ResourceManager.GetString("Gbx_SAP_Reference", resourceCulture);

        internal static string Gbx_Trade_Non_Trade =>
            ResourceManager.GetString("Gbx_Trade_Non_Trade", resourceCulture);

        internal static string Gbx_Vessel_Info =>
            ResourceManager.GetString("Gbx_Vessel_Info", resourceCulture);

        internal static string Grade_001 =>
            ResourceManager.GetString("Grade_001", resourceCulture);

        internal static string Grade_002 =>
            ResourceManager.GetString("Grade_002", resourceCulture);

        internal static string Grade_003 =>
            ResourceManager.GetString("Grade_003", resourceCulture);

        internal static string Grade_004 =>
            ResourceManager.GetString("Grade_004", resourceCulture);

        internal static string Grade_005 =>
            ResourceManager.GetString("Grade_005", resourceCulture);

        internal static string Grade_006 =>
            ResourceManager.GetString("Grade_006", resourceCulture);

        internal static string IDSY_Adopt_Failled =>
            ResourceManager.GetString("IDSY_Adopt_Failled", resourceCulture);

        internal static string IDSYS =>
            ResourceManager.GetString("IDSYS", resourceCulture);

        internal static string IDSYS_Adopt_PO_Multiline =>
            ResourceManager.GetString("IDSYS_Adopt_PO_Multiline", resourceCulture);

        internal static string Lab_001 =>
            ResourceManager.GetString("Lab_001", resourceCulture);

        internal static string Lab_002 =>
            ResourceManager.GetString("Lab_002", resourceCulture);

        internal static string Lab_003 =>
            ResourceManager.GetString("Lab_003", resourceCulture);

        internal static string Lab_004 =>
            ResourceManager.GetString("Lab_004", resourceCulture);

        internal static string Lab_005 =>
            ResourceManager.GetString("Lab_005", resourceCulture);

        internal static string Lab_006 =>
            ResourceManager.GetString("Lab_006", resourceCulture);

        internal static string Lab_007 =>
            ResourceManager.GetString("Lab_007", resourceCulture);

        internal static string Lab_008 =>
            ResourceManager.GetString("Lab_008", resourceCulture);

        internal static string Lab_009 =>
            ResourceManager.GetString("Lab_009", resourceCulture);

        internal static string Lab_010 =>
            ResourceManager.GetString("Lab_010", resourceCulture);

        internal static string Lab_011 =>
            ResourceManager.GetString("Lab_011", resourceCulture);

        internal static string Lab_012 =>
            ResourceManager.GetString("Lab_012", resourceCulture);

        internal static string Lab_013 =>
            ResourceManager.GetString("Lab_013", resourceCulture);

        internal static string Lab_014 =>
            ResourceManager.GetString("Lab_014", resourceCulture);

        internal static string Lab_015 =>
            ResourceManager.GetString("Lab_015", resourceCulture);

        internal static string Lab_016 =>
            ResourceManager.GetString("Lab_016", resourceCulture);

        internal static string Lab_017 =>
            ResourceManager.GetString("Lab_017", resourceCulture);

        internal static string Lab_018 =>
            ResourceManager.GetString("Lab_018", resourceCulture);

        internal static string Lab_019 =>
            ResourceManager.GetString("Lab_019", resourceCulture);

        internal static string Lab_020 =>
            ResourceManager.GetString("Lab_020", resourceCulture);

        internal static string Lab_021 =>
            ResourceManager.GetString("Lab_021", resourceCulture);

        internal static string Lab_022 =>
            ResourceManager.GetString("Lab_022", resourceCulture);

        internal static string Lab_023 =>
            ResourceManager.GetString("Lab_023", resourceCulture);

        internal static string Lab_024 =>
            ResourceManager.GetString("Lab_024", resourceCulture);

        internal static string Lab_025 =>
            ResourceManager.GetString("Lab_025", resourceCulture);

        internal static string Lab_026 =>
            ResourceManager.GetString("Lab_026", resourceCulture);

        internal static string Lab_027 =>
            ResourceManager.GetString("Lab_027", resourceCulture);

        internal static string Lab_028 =>
            ResourceManager.GetString("Lab_028", resourceCulture);

        internal static string Lab_029 =>
            ResourceManager.GetString("Lab_029", resourceCulture);

        internal static string Lab_030 =>
            ResourceManager.GetString("Lab_030", resourceCulture);

        internal static string Lab_031 =>
            ResourceManager.GetString("Lab_031", resourceCulture);

        internal static string Lab_032 =>
            ResourceManager.GetString("Lab_032", resourceCulture);

        internal static string Lab_033 =>
            ResourceManager.GetString("Lab_033", resourceCulture);

        internal static string Lbl_Add_Mov_Type =>
            ResourceManager.GetString("Lbl_Add_Mov_Type", resourceCulture);

        internal static string Lbl_All_Trx =>
            ResourceManager.GetString("Lbl_All_Trx", resourceCulture);

        internal static string Lbl_Arithmetic =>
            ResourceManager.GetString("Lbl_Arithmetic", resourceCulture);

        internal static string Lbl_Auto_Upload =>
            ResourceManager.GetString("Lbl_Auto_Upload", resourceCulture);

        internal static string Lbl_BC_Date =>
            ResourceManager.GetString("Lbl_BC_Date", resourceCulture);

        internal static string Lbl_BC_Exp_Date =>
            ResourceManager.GetString("Lbl_BC_Exp_Date", resourceCulture);

        internal static string Lbl_BC_Quantity =>
            ResourceManager.GetString("Lbl_BC_Quantity", resourceCulture);

        internal static string Lbl_BJR_Full =>
            ResourceManager.GetString("Lbl_BJR_Full", resourceCulture);

        internal static string Lbl_BJR_Round_Down =>
            ResourceManager.GetString("Lbl_BJR_Round_Down", resourceCulture);

        internal static string Lbl_BJR_Round_Up =>
            ResourceManager.GetString("Lbl_BJR_Round_Up", resourceCulture);

        internal static string Lbl_BL_Quantity =>
            ResourceManager.GetString("Lbl_BL_Quantity", resourceCulture);

        internal static string Lbl_Blacklist_Reason =>
            ResourceManager.GetString("Lbl_Blacklist_Reason", resourceCulture);

        internal static string Lbl_Btn_Delete =>
            ResourceManager.GetString("Lbl_Btn_Delete", resourceCulture);

        internal static string Lbl_Btn_Duplicate =>
            ResourceManager.GetString("Lbl_Btn_Duplicate", resourceCulture);

        internal static string Lbl_Btn_Find =>
            ResourceManager.GetString("Lbl_Btn_Find", resourceCulture);

        internal static string Lbl_btn_search =>
            ResourceManager.GetString("Lbl_btn_search", resourceCulture);

        internal static string Lbl_Cancelled_Reason =>
            ResourceManager.GetString("Lbl_Cancelled_Reason", resourceCulture);

        internal static string Lbl_Change_Reason =>
            ResourceManager.GetString("Lbl_Change_Reason", resourceCulture);

        internal static string Lbl_Check_Tanker =>
            ResourceManager.GetString("Lbl_Check_Tanker", resourceCulture);

        internal static string Lbl_Chk_Enable_Filtering =>
            ResourceManager.GetString("Lbl_Chk_Enable_Filtering", resourceCulture);

        internal static string Lbl_Chk_Req_BC =>
            ResourceManager.GetString("Lbl_Chk_Req_BC", resourceCulture);

        internal static string Lbl_Close_Date =>
            ResourceManager.GetString("Lbl_Close_Date", resourceCulture);

        internal static string Lbl_Comm_Code =>
            ResourceManager.GetString("Lbl_Comm_Code", resourceCulture);

        internal static string Lbl_Comm_Code_02 =>
            ResourceManager.GetString("Lbl_Comm_Code_02", resourceCulture);

        internal static string Lbl_Comm_Name =>
            ResourceManager.GetString("Lbl_Comm_Name", resourceCulture);

        internal static string Lbl_Comm_Tol =>
            ResourceManager.GetString("Lbl_Comm_Tol", resourceCulture);

        internal static string Lbl_Commodity_Name =>
            ResourceManager.GetString("Lbl_Commodity_Name", resourceCulture);

        internal static string Lbl_Contract_Quality =>
            ResourceManager.GetString("Lbl_Contract_Quality", resourceCulture);

        internal static string Lbl_Conv_Tolerance =>
            ResourceManager.GetString("Lbl_Conv_Tolerance", resourceCulture);

        internal static string Lbl_CPO =>
            ResourceManager.GetString("Lbl_CPO", resourceCulture);

        internal static string Lbl_Data_Type =>
            ResourceManager.GetString("Lbl_Data_Type", resourceCulture);

        internal static string Lbl_Date =>
            ResourceManager.GetString("Lbl_Date", resourceCulture);

        internal static string Lbl_Date_Format =>
            ResourceManager.GetString("Lbl_Date_Format", resourceCulture);

        internal static string Lbl_Date_From =>
            ResourceManager.GetString("Lbl_Date_From", resourceCulture);

        internal static string Lbl_Deduction_By =>
            ResourceManager.GetString("Lbl_Deduction_By", resourceCulture);

        internal static string Lbl_Deduction_Code =>
            ResourceManager.GetString("Lbl_Deduction_Code", resourceCulture);

        internal static string Lbl_Deduction_Description =>
            ResourceManager.GetString("Lbl_Deduction_Description", resourceCulture);

        internal static string Lbl_Deduction_Description_3 =>
            ResourceManager.GetString("Lbl_Deduction_Description_3", resourceCulture);

        internal static string Lbl_Deduction_Description_4 =>
            ResourceManager.GetString("Lbl_Deduction_Description_4", resourceCulture);

        internal static string Lbl_Delete_Reason =>
            ResourceManager.GetString("Lbl_Delete_Reason", resourceCulture);

        internal static string Lbl_DO_Delivery_Note =>
            ResourceManager.GetString("Lbl_DO_Delivery_Note", resourceCulture);

        internal static string Lbl_DO_No =>
            ResourceManager.GetString("Lbl_DO_No", resourceCulture);

        internal static string Lbl_DO_Process =>
            ResourceManager.GetString("Lbl_DO_Process", resourceCulture);

        internal static string Lbl_Driver_ID =>
            ResourceManager.GetString("Lbl_Driver_ID", resourceCulture);

        internal static string Lbl_Edit_No =>
            ResourceManager.GetString("Lbl_Edit_No", resourceCulture);

        internal static string Lbl_Editing_Reason =>
            ResourceManager.GetString("Lbl_Editing_Reason", resourceCulture);

        internal static string Lbl_Entry_Date =>
            ResourceManager.GetString("Lbl_Entry_Date", resourceCulture);

        internal static string Lbl_Estate_Name =>
            ResourceManager.GetString("Lbl_Estate_Name", resourceCulture);

        internal static string Lbl_Field_Name =>
            ResourceManager.GetString("Lbl_Field_Name", resourceCulture);

        internal static string Lbl_For_Net_Weight =>
            ResourceManager.GetString("Lbl_For_Net_Weight", resourceCulture);

        internal static string Lbl_From_DO =>
            ResourceManager.GetString("Lbl_From_DO", resourceCulture);

        internal static string Lbl_Functions_Variables =>
            ResourceManager.GetString("Lbl_Functions_Variables", resourceCulture);

        internal static string Lbl_GI_Batch =>
            ResourceManager.GetString("Lbl_GI_Batch", resourceCulture);

        internal static string Lbl_GR_Custom =>
            ResourceManager.GetString("Lbl_GR_Custom", resourceCulture);

        internal static string Lbl_GR_PO =>
            ResourceManager.GetString("Lbl_GR_PO", resourceCulture);

        internal static string Lbl_In =>
            ResourceManager.GetString("Lbl_In", resourceCulture);

        internal static string Lbl_Key_Field =>
            ResourceManager.GetString("Lbl_Key_Field", resourceCulture);

        internal static string Lbl_Line =>
            ResourceManager.GetString("Lbl_Line", resourceCulture);

        internal static string Lbl_Logical =>
            ResourceManager.GetString("Lbl_Logical", resourceCulture);

        internal static string Lbl_Mark_Delete_Reason =>
            ResourceManager.GetString("Lbl_Mark_Delete_Reason", resourceCulture);

        internal static string Lbl_Message =>
            ResourceManager.GetString("Lbl_Message", resourceCulture);

        internal static string Lbl_Module =>
            ResourceManager.GetString("Lbl_Module", resourceCulture);

        internal static string Lbl_NEGO =>
            ResourceManager.GetString("Lbl_NEGO", resourceCulture);

        internal static string Lbl_Nego_No =>
            ResourceManager.GetString("Lbl_Nego_No", resourceCulture);

        internal static string Lbl_No_BC =>
            ResourceManager.GetString("Lbl_No_BC", resourceCulture);

        internal static string Lbl_Operators =>
            ResourceManager.GetString("Lbl_Operators", resourceCulture);

        internal static string Lbl_Percentage =>
            ResourceManager.GetString("Lbl_Percentage", resourceCulture);

        internal static string Lbl_PI_SI_No =>
            ResourceManager.GetString("Lbl_PI_SI_No", resourceCulture);

        internal static string Lbl_PIN_Code =>
            ResourceManager.GetString("Lbl_PIN_Code", resourceCulture);

        internal static string Lbl_PK =>
            ResourceManager.GetString("Lbl_PK", resourceCulture);

        internal static string Lbl_POSTO =>
            ResourceManager.GetString("Lbl_POSTO", resourceCulture);

        internal static string Lbl_POSTO_Item =>
            ResourceManager.GetString("Lbl_POSTO_Item", resourceCulture);

        internal static string Lbl_POSTO_Qty =>
            ResourceManager.GetString("Lbl_POSTO_Qty", resourceCulture);

        internal static string Lbl_POSTO_UoM =>
            ResourceManager.GetString("Lbl_POSTO_UoM", resourceCulture);

        internal static string Lbl_Q_Standard =>
            ResourceManager.GetString("Lbl_Q_Standard", resourceCulture);

        internal static string Lbl_Ref_Date =>
            ResourceManager.GetString("Lbl_Ref_Date", resourceCulture);

        internal static string Lbl_Ref_No =>
            ResourceManager.GetString("Lbl_Ref_No", resourceCulture);

        internal static string Lbl_Ref_No_02 =>
            ResourceManager.GetString("Lbl_Ref_No_02", resourceCulture);

        internal static string Lbl_Relation_Name =>
            ResourceManager.GetString("Lbl_Relation_Name", resourceCulture);

        internal static string Lbl_Req_BC =>
            ResourceManager.GetString("Lbl_Req_BC", resourceCulture);

        internal static string Lbl_Require_BC =>
            ResourceManager.GetString("Lbl_Require_BC", resourceCulture);

        internal static string Lbl_SAP_Field =>
            ResourceManager.GetString("Lbl_SAP_Field", resourceCulture);

        internal static string Lbl_Set_Vessel_Max_Tolerance_for_Split1 =>
            ResourceManager.GetString("Lbl_Set_Vessel_Max_Tolerance_for_Split1", resourceCulture);

        internal static string Lbl_Short_Description =>
            ResourceManager.GetString("Lbl_Short_Description", resourceCulture);

        internal static string Lbl_SO =>
            ResourceManager.GetString("Lbl_SO", resourceCulture);

        internal static string Lbl_SO_Item =>
            ResourceManager.GetString("Lbl_SO_Item", resourceCulture);

        internal static string Lbl_SO_No =>
            ResourceManager.GetString("Lbl_SO_No", resourceCulture);

        internal static string Lbl_SO_Qty =>
            ResourceManager.GetString("Lbl_SO_Qty", resourceCulture);

        internal static string Lbl_SO_UoM =>
            ResourceManager.GetString("Lbl_SO_UoM", resourceCulture);

        internal static string Lbl_SO1 =>
            ResourceManager.GetString("Lbl_SO1", resourceCulture);

        internal static string Lbl_Status =>
            ResourceManager.GetString("Lbl_Status", resourceCulture);

        internal static string Lbl_STO =>
            ResourceManager.GetString("Lbl_STO", resourceCulture);

        internal static string Lbl_STO_Item =>
            ResourceManager.GetString("Lbl_STO_Item", resourceCulture);

        internal static string Lbl_STO_Qty =>
            ResourceManager.GetString("Lbl_STO_Qty", resourceCulture);

        internal static string Lbl_STO_Quantity =>
            ResourceManager.GetString("Lbl_STO_Quantity", resourceCulture);

        internal static string Lbl_STO_UoM =>
            ResourceManager.GetString("Lbl_STO_UoM", resourceCulture);

        internal static string Lbl_Supply_Batch =>
            ResourceManager.GetString("Lbl_Supply_Batch", resourceCulture);

        internal static string Lbl_Table_Name =>
            ResourceManager.GetString("Lbl_Table_Name", resourceCulture);

        internal static string Lbl_Table_STO =>
            ResourceManager.GetString("Lbl_Table_STO", resourceCulture);

        internal static string Lbl_Tanker_No =>
            ResourceManager.GetString("Lbl_Tanker_No", resourceCulture);

        internal static string Lbl_Target =>
            ResourceManager.GetString("Lbl_Target", resourceCulture);

        internal static string Lbl_Token_Code =>
            ResourceManager.GetString("Lbl_Token_Code", resourceCulture);

        internal static string Lbl_Tolerance_Is =>
            ResourceManager.GetString("Lbl_Tolerance_Is", resourceCulture);

        internal static string Lbl_Tolerance_UOM =>
            ResourceManager.GetString("Lbl_Tolerance_UOM", resourceCulture);

        internal static string Lbl_Total_Record =>
            ResourceManager.GetString("Lbl_Total_Record", resourceCulture);

        internal static string Lbl_TP_Desc =>
            ResourceManager.GetString("Lbl_TP_Desc", resourceCulture);

        internal static string Lbl_Transporter_Name =>
            ResourceManager.GetString("Lbl_Transporter_Name", resourceCulture);

        internal static string Lbl_Truck_No =>
            ResourceManager.GetString("Lbl_Truck_No", resourceCulture);

        internal static string Lbl_Unblacklist_Reason =>
            ResourceManager.GetString("Lbl_Unblacklist_Reason", resourceCulture);

        internal static string Lbl_Unit_Quantity =>
            ResourceManager.GetString("Lbl_Unit_Quantity", resourceCulture);

        internal static string Lbl_Unmark_Delete_Reason =>
            ResourceManager.GetString("Lbl_Unmark_Delete_Reason", resourceCulture);

        internal static string Lbl_Vehicle_No =>
            ResourceManager.GetString("Lbl_Vehicle_No", resourceCulture);

        internal static string Lbl_Vendor_Customer =>
            ResourceManager.GetString("Lbl_Vendor_Customer", resourceCulture);

        internal static string Lbl_Vessel_Max_Tolerance_for_Split =>
            ResourceManager.GetString("Lbl_Vessel_Max_Tolerance_for_Split", resourceCulture);

        internal static string Lbl_Vessel_Name_BL_No =>
            ResourceManager.GetString("Lbl_Vessel_Name_BL_No", resourceCulture);

        internal static string Lbl_WB_Calibration =>
            ResourceManager.GetString("Lbl_WB_Calibration", resourceCulture);

        internal static string LBL_WB_Ref =>
            ResourceManager.GetString("LBL_WB_Ref", resourceCulture);

        internal static string Lbl_With_Interval =>
            ResourceManager.GetString("Lbl_With_Interval", resourceCulture);

        internal static string Lbl_Yield_Code =>
            ResourceManager.GetString("Lbl_Yield_Code", resourceCulture);

        internal static string link_change_password_ad =>
            ResourceManager.GetString("link_change_password_ad", resourceCulture);

        internal static string Load_001 =>
            ResourceManager.GetString("Load_001", resourceCulture);

        internal static string Load_002 =>
            ResourceManager.GetString("Load_002", resourceCulture);

        internal static string Load_003 =>
            ResourceManager.GetString("Load_003", resourceCulture);

        internal static string Load_004 =>
            ResourceManager.GetString("Load_004", resourceCulture);

        internal static string Load_005 =>
            ResourceManager.GetString("Load_005", resourceCulture);

        internal static string Login_001 =>
            ResourceManager.GetString("Login_001", resourceCulture);

        internal static string Login_002 =>
            ResourceManager.GetString("Login_002", resourceCulture);

        internal static string Login_003 =>
            ResourceManager.GetString("Login_003", resourceCulture);

        internal static string Login_004 =>
            ResourceManager.GetString("Login_004", resourceCulture);

        internal static string Login_005 =>
            ResourceManager.GetString("Login_005", resourceCulture);

        internal static string Login_006 =>
            ResourceManager.GetString("Login_006", resourceCulture);

        internal static string Login_007 =>
            ResourceManager.GetString("Login_007", resourceCulture);

        internal static string Login_008 =>
            ResourceManager.GetString("Login_008", resourceCulture);

        internal static string Login_009 =>
            ResourceManager.GetString("Login_009", resourceCulture);

        internal static string loginAD_001 =>
            ResourceManager.GetString("loginAD_001", resourceCulture);

        internal static string loginAD_002 =>
            ResourceManager.GetString("loginAD_002", resourceCulture);

        internal static string loginAD_003 =>
            ResourceManager.GetString("loginAD_003", resourceCulture);

        internal static string loginAD_004 =>
            ResourceManager.GetString("loginAD_004", resourceCulture);

        internal static string loginAD_005 =>
            ResourceManager.GetString("loginAD_005", resourceCulture);

        internal static string loginAD_006 =>
            ResourceManager.GetString("loginAD_006", resourceCulture);

        internal static string loginAD_007 =>
            ResourceManager.GetString("loginAD_007", resourceCulture);

        internal static string loginAD_008 =>
            ResourceManager.GetString("loginAD_008", resourceCulture);

        internal static string loginAD_009 =>
            ResourceManager.GetString("loginAD_009", resourceCulture);

        internal static string loginAD_010 =>
            ResourceManager.GetString("loginAD_010", resourceCulture);

        internal static string loginAD_011 =>
            ResourceManager.GetString("loginAD_011", resourceCulture);

        internal static string loginAD_012 =>
            ResourceManager.GetString("loginAD_012", resourceCulture);

        internal static string loginAD_013 =>
            ResourceManager.GetString("loginAD_013", resourceCulture);

        internal static string LoginAD_014 =>
            ResourceManager.GetString("LoginAD_014", resourceCulture);

        internal static string LoginADChangeConnection =>
            ResourceManager.GetString("LoginADChangeConnection", resourceCulture);

        internal static string Main_001 =>
            ResourceManager.GetString("Main_001", resourceCulture);

        internal static string Main_002 =>
            ResourceManager.GetString("Main_002", resourceCulture);

        internal static string Main_003 =>
            ResourceManager.GetString("Main_003", resourceCulture);

        internal static string Main_004 =>
            ResourceManager.GetString("Main_004", resourceCulture);

        internal static string Main_005 =>
            ResourceManager.GetString("Main_005", resourceCulture);

        internal static string Main_006 =>
            ResourceManager.GetString("Main_006", resourceCulture);

        internal static string Main_007 =>
            ResourceManager.GetString("Main_007", resourceCulture);

        internal static string Main_008 =>
            ResourceManager.GetString("Main_008", resourceCulture);

        internal static string Main_009 =>
            ResourceManager.GetString("Main_009", resourceCulture);

        internal static string Main_010 =>
            ResourceManager.GetString("Main_010", resourceCulture);

        internal static string Main_011 =>
            ResourceManager.GetString("Main_011", resourceCulture);

        internal static string Main_012 =>
            ResourceManager.GetString("Main_012", resourceCulture);

        internal static string Main_013 =>
            ResourceManager.GetString("Main_013", resourceCulture);

        internal static string Main_014 =>
            ResourceManager.GetString("Main_014", resourceCulture);

        internal static string Main_015 =>
            ResourceManager.GetString("Main_015", resourceCulture);

        internal static string Main_016 =>
            ResourceManager.GetString("Main_016", resourceCulture);

        internal static string Main_017 =>
            ResourceManager.GetString("Main_017", resourceCulture);

        internal static string Main_018 =>
            ResourceManager.GetString("Main_018", resourceCulture);

        internal static string Main_019 =>
            ResourceManager.GetString("Main_019", resourceCulture);

        internal static string Main_020 =>
            ResourceManager.GetString("Main_020", resourceCulture);

        internal static string Main_021 =>
            ResourceManager.GetString("Main_021", resourceCulture);

        internal static string Main_022 =>
            ResourceManager.GetString("Main_022", resourceCulture);

        internal static string Main_023 =>
            ResourceManager.GetString("Main_023", resourceCulture);

        internal static string Main_024 =>
            ResourceManager.GetString("Main_024", resourceCulture);

        internal static string Main_025 =>
            ResourceManager.GetString("Main_025", resourceCulture);

        internal static string Main_026 =>
            ResourceManager.GetString("Main_026", resourceCulture);

        internal static string Main_027 =>
            ResourceManager.GetString("Main_027", resourceCulture);

        internal static string Main_028 =>
            ResourceManager.GetString("Main_028", resourceCulture);

        internal static string Main_029 =>
            ResourceManager.GetString("Main_029", resourceCulture);

        internal static string Main_030 =>
            ResourceManager.GetString("Main_030", resourceCulture);

        internal static string Main_031 =>
            ResourceManager.GetString("Main_031", resourceCulture);

        internal static string Main_032 =>
            ResourceManager.GetString("Main_032", resourceCulture);

        internal static string Main_033 =>
            ResourceManager.GetString("Main_033", resourceCulture);

        internal static string Main_034 =>
            ResourceManager.GetString("Main_034", resourceCulture);

        internal static string Main_035 =>
            ResourceManager.GetString("Main_035", resourceCulture);

        internal static string Main_036 =>
            ResourceManager.GetString("Main_036", resourceCulture);

        internal static string Main_036a =>
            ResourceManager.GetString("Main_036a", resourceCulture);

        internal static string Main_037 =>
            ResourceManager.GetString("Main_037", resourceCulture);

        internal static string Main_038 =>
            ResourceManager.GetString("Main_038", resourceCulture);

        internal static string Main_039 =>
            ResourceManager.GetString("Main_039", resourceCulture);

        internal static string Main_040 =>
            ResourceManager.GetString("Main_040", resourceCulture);

        internal static string Main_041 =>
            ResourceManager.GetString("Main_041", resourceCulture);

        internal static string Main_042 =>
            ResourceManager.GetString("Main_042", resourceCulture);

        internal static string Main_043 =>
            ResourceManager.GetString("Main_043", resourceCulture);

        internal static string Main_044 =>
            ResourceManager.GetString("Main_044", resourceCulture);

        internal static string Main_045 =>
            ResourceManager.GetString("Main_045", resourceCulture);

        internal static string Main_046 =>
            ResourceManager.GetString("Main_046", resourceCulture);

        internal static string Main_047 =>
            ResourceManager.GetString("Main_047", resourceCulture);

        internal static string Main_048 =>
            ResourceManager.GetString("Main_048", resourceCulture);

        internal static string Main_049 =>
            ResourceManager.GetString("Main_049", resourceCulture);

        internal static string Main_050 =>
            ResourceManager.GetString("Main_050", resourceCulture);

        internal static string Main_051 =>
            ResourceManager.GetString("Main_051", resourceCulture);

        internal static string Main_052 =>
            ResourceManager.GetString("Main_052", resourceCulture);

        internal static string Main_053 =>
            ResourceManager.GetString("Main_053", resourceCulture);

        internal static string Main_054 =>
            ResourceManager.GetString("Main_054", resourceCulture);

        internal static string Main_055 =>
            ResourceManager.GetString("Main_055", resourceCulture);

        internal static string Main_056 =>
            ResourceManager.GetString("Main_056", resourceCulture);

        internal static string Main_057 =>
            ResourceManager.GetString("Main_057", resourceCulture);

        internal static string Main_058 =>
            ResourceManager.GetString("Main_058", resourceCulture);

        internal static string Main_059 =>
            ResourceManager.GetString("Main_059", resourceCulture);

        internal static string Main_060 =>
            ResourceManager.GetString("Main_060", resourceCulture);

        internal static string Main_061 =>
            ResourceManager.GetString("Main_061", resourceCulture);

        internal static string Main_062 =>
            ResourceManager.GetString("Main_062", resourceCulture);

        internal static string Main_063 =>
            ResourceManager.GetString("Main_063", resourceCulture);

        internal static string Main_064 =>
            ResourceManager.GetString("Main_064", resourceCulture);

        internal static string Main_065 =>
            ResourceManager.GetString("Main_065", resourceCulture);

        internal static string Main_066 =>
            ResourceManager.GetString("Main_066", resourceCulture);

        internal static string Main_067 =>
            ResourceManager.GetString("Main_067", resourceCulture);

        internal static string Main_068 =>
            ResourceManager.GetString("Main_068", resourceCulture);

        internal static string Main_069 =>
            ResourceManager.GetString("Main_069", resourceCulture);

        internal static string Main_070 =>
            ResourceManager.GetString("Main_070", resourceCulture);

        internal static string Main_071 =>
            ResourceManager.GetString("Main_071", resourceCulture);

        internal static string Main_072 =>
            ResourceManager.GetString("Main_072", resourceCulture);

        internal static string Main_073 =>
            ResourceManager.GetString("Main_073", resourceCulture);

        internal static string Main_074 =>
            ResourceManager.GetString("Main_074", resourceCulture);

        internal static string Main_075 =>
            ResourceManager.GetString("Main_075", resourceCulture);

        internal static string Main_076 =>
            ResourceManager.GetString("Main_076", resourceCulture);

        internal static string Main_077 =>
            ResourceManager.GetString("Main_077", resourceCulture);

        internal static string Main_078 =>
            ResourceManager.GetString("Main_078", resourceCulture);

        internal static string Main_079 =>
            ResourceManager.GetString("Main_079", resourceCulture);

        internal static string Main_080 =>
            ResourceManager.GetString("Main_080", resourceCulture);

        internal static string Main_081 =>
            ResourceManager.GetString("Main_081", resourceCulture);

        internal static string Main_082 =>
            ResourceManager.GetString("Main_082", resourceCulture);

        internal static string Main_083 =>
            ResourceManager.GetString("Main_083", resourceCulture);

        internal static string Main_084 =>
            ResourceManager.GetString("Main_084", resourceCulture);

        internal static string Main_085 =>
            ResourceManager.GetString("Main_085", resourceCulture);

        internal static string Main_086 =>
            ResourceManager.GetString("Main_086", resourceCulture);

        internal static string Main_087 =>
            ResourceManager.GetString("Main_087", resourceCulture);

        internal static string Main_088 =>
            ResourceManager.GetString("Main_088", resourceCulture);

        internal static string Main_089 =>
            ResourceManager.GetString("Main_089", resourceCulture);

        internal static string Main_090 =>
            ResourceManager.GetString("Main_090", resourceCulture);

        internal static string Main_091 =>
            ResourceManager.GetString("Main_091", resourceCulture);

        internal static string Main_092 =>
            ResourceManager.GetString("Main_092", resourceCulture);

        internal static string Main_093 =>
            ResourceManager.GetString("Main_093", resourceCulture);

        internal static string Main_094 =>
            ResourceManager.GetString("Main_094", resourceCulture);

        internal static string Main_095 =>
            ResourceManager.GetString("Main_095", resourceCulture);

        internal static string Main_096 =>
            ResourceManager.GetString("Main_096", resourceCulture);

        internal static string Main_097 =>
            ResourceManager.GetString("Main_097", resourceCulture);

        internal static string Main_098 =>
            ResourceManager.GetString("Main_098", resourceCulture);

        internal static string Main_099 =>
            ResourceManager.GetString("Main_099", resourceCulture);

        internal static string Main_100 =>
            ResourceManager.GetString("Main_100", resourceCulture);

        internal static string Main_101 =>
            ResourceManager.GetString("Main_101", resourceCulture);

        internal static string Main_102 =>
            ResourceManager.GetString("Main_102", resourceCulture);

        internal static string Main_103 =>
            ResourceManager.GetString("Main_103", resourceCulture);

        internal static string Main_104 =>
            ResourceManager.GetString("Main_104", resourceCulture);

        internal static string Main_105 =>
            ResourceManager.GetString("Main_105", resourceCulture);

        internal static string Main_106 =>
            ResourceManager.GetString("Main_106", resourceCulture);

        internal static string Main_107 =>
            ResourceManager.GetString("Main_107", resourceCulture);

        internal static string Main_108 =>
            ResourceManager.GetString("Main_108", resourceCulture);

        internal static string Main_108a =>
            ResourceManager.GetString("Main_108a", resourceCulture);

        internal static string Main_108b =>
            ResourceManager.GetString("Main_108b", resourceCulture);

        internal static string Main_108c =>
            ResourceManager.GetString("Main_108c", resourceCulture);

        internal static string Mainform_001 =>
            ResourceManager.GetString("Mainform_001", resourceCulture);

        internal static string Mainform_002 =>
            ResourceManager.GetString("Mainform_002", resourceCulture);

        internal static string Mainform_003 =>
            ResourceManager.GetString("Mainform_003", resourceCulture);

        internal static string Mainform_004 =>
            ResourceManager.GetString("Mainform_004", resourceCulture);

        internal static string Mainform_005 =>
            ResourceManager.GetString("Mainform_005", resourceCulture);

        internal static string Mainform_006 =>
            ResourceManager.GetString("Mainform_006", resourceCulture);

        internal static string Mainform_007 =>
            ResourceManager.GetString("Mainform_007", resourceCulture);

        internal static string Mainform_008 =>
            ResourceManager.GetString("Mainform_008", resourceCulture);

        internal static string Mainform_009 =>
            ResourceManager.GetString("Mainform_009", resourceCulture);

        internal static string Mainform_010 =>
            ResourceManager.GetString("Mainform_010", resourceCulture);

        internal static string Mainform_011 =>
            ResourceManager.GetString("Mainform_011", resourceCulture);

        internal static string Mainform_012 =>
            ResourceManager.GetString("Mainform_012", resourceCulture);

        internal static string Mainform_013 =>
            ResourceManager.GetString("Mainform_013", resourceCulture);

        internal static string Mainform_014 =>
            ResourceManager.GetString("Mainform_014", resourceCulture);

        internal static string Mainform_015 =>
            ResourceManager.GetString("Mainform_015", resourceCulture);

        internal static string Mainform_016 =>
            ResourceManager.GetString("Mainform_016", resourceCulture);

        internal static string Mainform_017 =>
            ResourceManager.GetString("Mainform_017", resourceCulture);

        internal static string Mainform_018 =>
            ResourceManager.GetString("Mainform_018", resourceCulture);

        internal static string Mainform_019 =>
            ResourceManager.GetString("Mainform_019", resourceCulture);

        internal static string Mainform_020 =>
            ResourceManager.GetString("Mainform_020", resourceCulture);

        internal static string Mainform_021 =>
            ResourceManager.GetString("Mainform_021", resourceCulture);

        internal static string Mainform_022 =>
            ResourceManager.GetString("Mainform_022", resourceCulture);

        internal static string Mainform_023 =>
            ResourceManager.GetString("Mainform_023", resourceCulture);

        internal static string Mainform_024 =>
            ResourceManager.GetString("Mainform_024", resourceCulture);

        internal static string Mainform_025 =>
            ResourceManager.GetString("Mainform_025", resourceCulture);

        internal static string Mainform_026 =>
            ResourceManager.GetString("Mainform_026", resourceCulture);

        internal static string Mainform_027 =>
            ResourceManager.GetString("Mainform_027", resourceCulture);

        internal static string Mainform_028 =>
            ResourceManager.GetString("Mainform_028", resourceCulture);

        internal static string Mainform_029 =>
            ResourceManager.GetString("Mainform_029", resourceCulture);

        internal static string Mainform_030 =>
            ResourceManager.GetString("Mainform_030", resourceCulture);

        internal static string Mainform_031 =>
            ResourceManager.GetString("Mainform_031", resourceCulture);

        internal static string Mainform_032 =>
            ResourceManager.GetString("Mainform_032", resourceCulture);

        internal static string Mainform_033 =>
            ResourceManager.GetString("Mainform_033", resourceCulture);

        internal static string Mainform_034 =>
            ResourceManager.GetString("Mainform_034", resourceCulture);

        internal static string Mainform_035 =>
            ResourceManager.GetString("Mainform_035", resourceCulture);

        internal static string Mainform_036 =>
            ResourceManager.GetString("Mainform_036", resourceCulture);

        internal static string Mainform_037 =>
            ResourceManager.GetString("Mainform_037", resourceCulture);

        internal static string Mainform_038 =>
            ResourceManager.GetString("Mainform_038", resourceCulture);

        internal static string Mainform_039 =>
            ResourceManager.GetString("Mainform_039", resourceCulture);

        internal static string Mainform_040 =>
            ResourceManager.GetString("Mainform_040", resourceCulture);

        internal static string Mainform_041 =>
            ResourceManager.GetString("Mainform_041", resourceCulture);

        internal static string Mainform_042 =>
            ResourceManager.GetString("Mainform_042", resourceCulture);

        internal static string Mainform_043 =>
            ResourceManager.GetString("Mainform_043", resourceCulture);

        internal static string Mainform_044 =>
            ResourceManager.GetString("Mainform_044", resourceCulture);

        internal static string Mainform_045 =>
            ResourceManager.GetString("Mainform_045", resourceCulture);

        internal static string Mainform_046 =>
            ResourceManager.GetString("Mainform_046", resourceCulture);

        internal static string Mainform_047 =>
            ResourceManager.GetString("Mainform_047", resourceCulture);

        internal static string Mainform_048 =>
            ResourceManager.GetString("Mainform_048", resourceCulture);

        internal static string Mainform_049 =>
            ResourceManager.GetString("Mainform_049", resourceCulture);

        internal static string Mainform_050 =>
            ResourceManager.GetString("Mainform_050", resourceCulture);

        internal static string Mainform_051 =>
            ResourceManager.GetString("Mainform_051", resourceCulture);

        internal static string Mainform_052 =>
            ResourceManager.GetString("Mainform_052", resourceCulture);

        internal static string Mainform_053 =>
            ResourceManager.GetString("Mainform_053", resourceCulture);

        internal static string Mainform_054 =>
            ResourceManager.GetString("Mainform_054", resourceCulture);

        internal static string Mainform_055 =>
            ResourceManager.GetString("Mainform_055", resourceCulture);

        internal static string Mainform_056 =>
            ResourceManager.GetString("Mainform_056", resourceCulture);

        internal static string Mainform_057 =>
            ResourceManager.GetString("Mainform_057", resourceCulture);

        internal static string Mainform_058 =>
            ResourceManager.GetString("Mainform_058", resourceCulture);

        internal static string Mainform_059 =>
            ResourceManager.GetString("Mainform_059", resourceCulture);

        internal static string Mainform_060 =>
            ResourceManager.GetString("Mainform_060", resourceCulture);

        internal static string Mainform_061 =>
            ResourceManager.GetString("Mainform_061", resourceCulture);

        internal static string Mainform_062 =>
            ResourceManager.GetString("Mainform_062", resourceCulture);

        internal static string Mainform_063 =>
            ResourceManager.GetString("Mainform_063", resourceCulture);

        internal static string Mainform_064 =>
            ResourceManager.GetString("Mainform_064", resourceCulture);

        internal static string Mainform_065 =>
            ResourceManager.GetString("Mainform_065", resourceCulture);

        internal static string Mainform_066 =>
            ResourceManager.GetString("Mainform_066", resourceCulture);

        internal static string Mainform_067 =>
            ResourceManager.GetString("Mainform_067", resourceCulture);

        internal static string Mainform_068 =>
            ResourceManager.GetString("Mainform_068", resourceCulture);

        internal static string Mainform_069 =>
            ResourceManager.GetString("Mainform_069", resourceCulture);

        internal static string Mainform_070 =>
            ResourceManager.GetString("Mainform_070", resourceCulture);

        internal static string Mainform_071 =>
            ResourceManager.GetString("Mainform_071", resourceCulture);

        internal static string Mainform_072 =>
            ResourceManager.GetString("Mainform_072", resourceCulture);

        internal static string Mainform_073 =>
            ResourceManager.GetString("Mainform_073", resourceCulture);

        internal static string Mainform_074 =>
            ResourceManager.GetString("Mainform_074", resourceCulture);

        internal static string Mainform_075 =>
            ResourceManager.GetString("Mainform_075", resourceCulture);

        internal static string Mainform_076 =>
            ResourceManager.GetString("Mainform_076", resourceCulture);

        internal static string Mainform_077 =>
            ResourceManager.GetString("Mainform_077", resourceCulture);

        internal static string Mainform_078 =>
            ResourceManager.GetString("Mainform_078", resourceCulture);

        internal static string Mainform_079 =>
            ResourceManager.GetString("Mainform_079", resourceCulture);

        internal static string Mainform_080 =>
            ResourceManager.GetString("Mainform_080", resourceCulture);

        internal static string Mainform_081 =>
            ResourceManager.GetString("Mainform_081", resourceCulture);

        internal static string Mainform_082 =>
            ResourceManager.GetString("Mainform_082", resourceCulture);

        internal static string Mainform_083 =>
            ResourceManager.GetString("Mainform_083", resourceCulture);

        internal static string Mainform_084 =>
            ResourceManager.GetString("Mainform_084", resourceCulture);

        internal static string Mainform_085 =>
            ResourceManager.GetString("Mainform_085", resourceCulture);

        internal static string Mainform_086 =>
            ResourceManager.GetString("Mainform_086", resourceCulture);

        internal static string Mainform_087 =>
            ResourceManager.GetString("Mainform_087", resourceCulture);

        internal static string Mainform_088 =>
            ResourceManager.GetString("Mainform_088", resourceCulture);

        internal static string Mainform_089 =>
            ResourceManager.GetString("Mainform_089", resourceCulture);

        internal static string Mainform_090 =>
            ResourceManager.GetString("Mainform_090", resourceCulture);

        internal static string Mainform_091 =>
            ResourceManager.GetString("Mainform_091", resourceCulture);

        internal static string Mainform_092 =>
            ResourceManager.GetString("Mainform_092", resourceCulture);

        internal static string Mainform_093 =>
            ResourceManager.GetString("Mainform_093", resourceCulture);

        internal static string Mainform_095 =>
            ResourceManager.GetString("Mainform_095", resourceCulture);

        internal static string Mainform_096 =>
            ResourceManager.GetString("Mainform_096", resourceCulture);

        internal static string Mainform_097 =>
            ResourceManager.GetString("Mainform_097", resourceCulture);

        internal static string Mainform_098 =>
            ResourceManager.GetString("Mainform_098", resourceCulture);

        internal static string MD_Delivery_Note_001 =>
            ResourceManager.GetString("MD_Delivery_Note_001", resourceCulture);

        internal static string MD_Delivery_Note_002 =>
            ResourceManager.GetString("MD_Delivery_Note_002", resourceCulture);

        internal static string MD_Delivery_Note_003 =>
            ResourceManager.GetString("MD_Delivery_Note_003", resourceCulture);

        internal static string MD_Delivery_Note_004 =>
            ResourceManager.GetString("MD_Delivery_Note_004", resourceCulture);

        internal static string MD_Delivery_Note_005 =>
            ResourceManager.GetString("MD_Delivery_Note_005", resourceCulture);

        internal static string MD_Delivery_Note_006 =>
            ResourceManager.GetString("MD_Delivery_Note_006", resourceCulture);

        internal static string Menu =>
            ResourceManager.GetString("Menu", resourceCulture);

        internal static string Menu_001 =>
            ResourceManager.GetString("Menu_001", resourceCulture);

        internal static string Menu_002 =>
            ResourceManager.GetString("Menu_002", resourceCulture);

        internal static string Menu_003 =>
            ResourceManager.GetString("Menu_003", resourceCulture);

        internal static string Menu_004 =>
            ResourceManager.GetString("Menu_004", resourceCulture);

        internal static string Menu_005 =>
            ResourceManager.GetString("Menu_005", resourceCulture);

        internal static string Menu_006 =>
            ResourceManager.GetString("Menu_006", resourceCulture);

        internal static string Menu_007 =>
            ResourceManager.GetString("Menu_007", resourceCulture);

        internal static string Menu_008 =>
            ResourceManager.GetString("Menu_008", resourceCulture);

        internal static string Menu_009 =>
            ResourceManager.GetString("Menu_009", resourceCulture);

        internal static string Menu_010 =>
            ResourceManager.GetString("Menu_010", resourceCulture);

        internal static string Menu_011 =>
            ResourceManager.GetString("Menu_011", resourceCulture);

        internal static string Menu_012 =>
            ResourceManager.GetString("Menu_012", resourceCulture);

        internal static string Menu_013 =>
            ResourceManager.GetString("Menu_013", resourceCulture);

        internal static string Menu_013a =>
            ResourceManager.GetString("Menu_013a", resourceCulture);

        internal static string Menu_013b =>
            ResourceManager.GetString("Menu_013b", resourceCulture);

        internal static string Menu_014 =>
            ResourceManager.GetString("Menu_014", resourceCulture);

        internal static string Menu_015 =>
            ResourceManager.GetString("Menu_015", resourceCulture);

        internal static string Menu_016 =>
            ResourceManager.GetString("Menu_016", resourceCulture);

        internal static string Menu_017 =>
            ResourceManager.GetString("Menu_017", resourceCulture);

        internal static string Menu_018 =>
            ResourceManager.GetString("Menu_018", resourceCulture);

        internal static string Menu_019 =>
            ResourceManager.GetString("Menu_019", resourceCulture);

        internal static string Menu_020 =>
            ResourceManager.GetString("Menu_020", resourceCulture);

        internal static string Menu_021 =>
            ResourceManager.GetString("Menu_021", resourceCulture);

        internal static string Menu_022 =>
            ResourceManager.GetString("Menu_022", resourceCulture);

        internal static string Menu_023 =>
            ResourceManager.GetString("Menu_023", resourceCulture);

        internal static string Menu_024 =>
            ResourceManager.GetString("Menu_024", resourceCulture);

        internal static string Menu_025 =>
            ResourceManager.GetString("Menu_025", resourceCulture);

        internal static string Menu_026 =>
            ResourceManager.GetString("Menu_026", resourceCulture);

        internal static string Menu_027 =>
            ResourceManager.GetString("Menu_027", resourceCulture);

        internal static string Menu_028 =>
            ResourceManager.GetString("Menu_028", resourceCulture);

        internal static string Menu_029 =>
            ResourceManager.GetString("Menu_029", resourceCulture);

        internal static string Menu_030 =>
            ResourceManager.GetString("Menu_030", resourceCulture);

        internal static string Menu_031 =>
            ResourceManager.GetString("Menu_031", resourceCulture);

        internal static string Menu_032 =>
            ResourceManager.GetString("Menu_032", resourceCulture);

        internal static string Menu_033 =>
            ResourceManager.GetString("Menu_033", resourceCulture);

        internal static string Menu_034 =>
            ResourceManager.GetString("Menu_034", resourceCulture);

        internal static string Menu_035 =>
            ResourceManager.GetString("Menu_035", resourceCulture);

        internal static string Menu_036 =>
            ResourceManager.GetString("Menu_036", resourceCulture);

        internal static string Menu_037 =>
            ResourceManager.GetString("Menu_037", resourceCulture);

        internal static string Menu_038 =>
            ResourceManager.GetString("Menu_038", resourceCulture);

        internal static string Menu_039 =>
            ResourceManager.GetString("Menu_039", resourceCulture);

        internal static string Menu_040 =>
            ResourceManager.GetString("Menu_040", resourceCulture);

        internal static string Menu_041 =>
            ResourceManager.GetString("Menu_041", resourceCulture);

        internal static string Menu_042 =>
            ResourceManager.GetString("Menu_042", resourceCulture);

        internal static string Menu_043 =>
            ResourceManager.GetString("Menu_043", resourceCulture);

        internal static string Menu_044 =>
            ResourceManager.GetString("Menu_044", resourceCulture);

        internal static string Menu_045 =>
            ResourceManager.GetString("Menu_045", resourceCulture);

        internal static string Menu_046 =>
            ResourceManager.GetString("Menu_046", resourceCulture);

        internal static string Menu_047 =>
            ResourceManager.GetString("Menu_047", resourceCulture);

        internal static string Menu_048 =>
            ResourceManager.GetString("Menu_048", resourceCulture);

        internal static string Menu_049 =>
            ResourceManager.GetString("Menu_049", resourceCulture);

        internal static string Menu_050 =>
            ResourceManager.GetString("Menu_050", resourceCulture);

        internal static string Menu_051 =>
            ResourceManager.GetString("Menu_051", resourceCulture);

        internal static string Menu_052 =>
            ResourceManager.GetString("Menu_052", resourceCulture);

        internal static string Menu_053 =>
            ResourceManager.GetString("Menu_053", resourceCulture);

        internal static string Menu_054 =>
            ResourceManager.GetString("Menu_054", resourceCulture);

        internal static string Menu_055 =>
            ResourceManager.GetString("Menu_055", resourceCulture);

        internal static string Menu_056 =>
            ResourceManager.GetString("Menu_056", resourceCulture);

        internal static string Menu_057 =>
            ResourceManager.GetString("Menu_057", resourceCulture);

        internal static string Menu_058 =>
            ResourceManager.GetString("Menu_058", resourceCulture);

        internal static string Menu_059 =>
            ResourceManager.GetString("Menu_059", resourceCulture);

        internal static string Menu_060 =>
            ResourceManager.GetString("Menu_060", resourceCulture);

        internal static string Menu_061 =>
            ResourceManager.GetString("Menu_061", resourceCulture);

        internal static string Menu_062 =>
            ResourceManager.GetString("Menu_062", resourceCulture);

        internal static string Menu_063 =>
            ResourceManager.GetString("Menu_063", resourceCulture);

        internal static string Menu_064 =>
            ResourceManager.GetString("Menu_064", resourceCulture);

        internal static string Menu_065 =>
            ResourceManager.GetString("Menu_065", resourceCulture);

        internal static string Menu_066 =>
            ResourceManager.GetString("Menu_066", resourceCulture);

        internal static string Menu_067 =>
            ResourceManager.GetString("Menu_067", resourceCulture);

        internal static string Menu_068 =>
            ResourceManager.GetString("Menu_068", resourceCulture);

        internal static string Menu_069 =>
            ResourceManager.GetString("Menu_069", resourceCulture);

        internal static string Menu_070 =>
            ResourceManager.GetString("Menu_070", resourceCulture);

        internal static string Menu_071 =>
            ResourceManager.GetString("Menu_071", resourceCulture);

        internal static string Menu_072 =>
            ResourceManager.GetString("Menu_072", resourceCulture);

        internal static string Menu_073 =>
            ResourceManager.GetString("Menu_073", resourceCulture);

        internal static string Menu_074 =>
            ResourceManager.GetString("Menu_074", resourceCulture);

        internal static string Menu_075 =>
            ResourceManager.GetString("Menu_075", resourceCulture);

        internal static string Menu_076 =>
            ResourceManager.GetString("Menu_076", resourceCulture);

        internal static string Menu_077 =>
            ResourceManager.GetString("Menu_077", resourceCulture);

        internal static string Menu_078 =>
            ResourceManager.GetString("Menu_078", resourceCulture);

        internal static string Menu_079 =>
            ResourceManager.GetString("Menu_079", resourceCulture);

        internal static string Menu_080 =>
            ResourceManager.GetString("Menu_080", resourceCulture);

        internal static string Menu_081 =>
            ResourceManager.GetString("Menu_081", resourceCulture);

        internal static string Menu_082 =>
            ResourceManager.GetString("Menu_082", resourceCulture);

        internal static string Menu_083 =>
            ResourceManager.GetString("Menu_083", resourceCulture);

        internal static string Menu_084 =>
            ResourceManager.GetString("Menu_084", resourceCulture);

        internal static string Menu_085 =>
            ResourceManager.GetString("Menu_085", resourceCulture);

        internal static string Menu_086 =>
            ResourceManager.GetString("Menu_086", resourceCulture);

        internal static string Menu_087 =>
            ResourceManager.GetString("Menu_087", resourceCulture);

        internal static string Menu_088 =>
            ResourceManager.GetString("Menu_088", resourceCulture);

        internal static string Menu_089 =>
            ResourceManager.GetString("Menu_089", resourceCulture);

        internal static string Menu_090 =>
            ResourceManager.GetString("Menu_090", resourceCulture);

        internal static string Menu_091 =>
            ResourceManager.GetString("Menu_091", resourceCulture);

        internal static string Menu_092 =>
            ResourceManager.GetString("Menu_092", resourceCulture);

        internal static string Menu_093 =>
            ResourceManager.GetString("Menu_093", resourceCulture);

        internal static string Menu_094 =>
            ResourceManager.GetString("Menu_094", resourceCulture);

        internal static string Menu_095 =>
            ResourceManager.GetString("Menu_095", resourceCulture);

        internal static string Menu_096 =>
            ResourceManager.GetString("Menu_096", resourceCulture);

        internal static string Menu_097 =>
            ResourceManager.GetString("Menu_097", resourceCulture);

        internal static string Menu_098 =>
            ResourceManager.GetString("Menu_098", resourceCulture);

        internal static string Menu_099 =>
            ResourceManager.GetString("Menu_099", resourceCulture);

        internal static string Menu_100 =>
            ResourceManager.GetString("Menu_100", resourceCulture);

        internal static string Menu_101 =>
            ResourceManager.GetString("Menu_101", resourceCulture);

        internal static string Menu_101_IDSYS =>
            ResourceManager.GetString("Menu_101_IDSYS", resourceCulture);

        internal static string Menu_102 =>
            ResourceManager.GetString("Menu_102", resourceCulture);

        internal static string Menu_103 =>
            ResourceManager.GetString("Menu_103", resourceCulture);

        internal static string Menu_104 =>
            ResourceManager.GetString("Menu_104", resourceCulture);

        internal static string Menu_105 =>
            ResourceManager.GetString("Menu_105", resourceCulture);

        internal static string Menu_106 =>
            ResourceManager.GetString("Menu_106", resourceCulture);

        internal static string Menu_107 =>
            ResourceManager.GetString("Menu_107", resourceCulture);

        internal static string Menu_108 =>
            ResourceManager.GetString("Menu_108", resourceCulture);

        internal static string Menu_109 =>
            ResourceManager.GetString("Menu_109", resourceCulture);

        internal static string Menu_110 =>
            ResourceManager.GetString("Menu_110", resourceCulture);

        internal static string Menu_111 =>
            ResourceManager.GetString("Menu_111", resourceCulture);

        internal static string Menu_112 =>
            ResourceManager.GetString("Menu_112", resourceCulture);

        internal static string Menu_113 =>
            ResourceManager.GetString("Menu_113", resourceCulture);

        internal static string Menu_114 =>
            ResourceManager.GetString("Menu_114", resourceCulture);

        internal static string Menu_115 =>
            ResourceManager.GetString("Menu_115", resourceCulture);

        internal static string Menu_116 =>
            ResourceManager.GetString("Menu_116", resourceCulture);

        internal static string Menu_117 =>
            ResourceManager.GetString("Menu_117", resourceCulture);

        internal static string Menu_118 =>
            ResourceManager.GetString("Menu_118", resourceCulture);

        internal static string Menu_119 =>
            ResourceManager.GetString("Menu_119", resourceCulture);

        internal static string Menu_120 =>
            ResourceManager.GetString("Menu_120", resourceCulture);

        internal static string Menu_Activities =>
            ResourceManager.GetString("Menu_Activities", resourceCulture);

        internal static string Menu_Add =>
            ResourceManager.GetString("Menu_Add", resourceCulture);

        internal static string Menu_Add_Transaction_Type =>
            ResourceManager.GetString("Menu_Add_Transaction_Type", resourceCulture);

        internal static string Menu_Analyze_All_Truck =>
            ResourceManager.GetString("Menu_Analyze_All_Truck", resourceCulture);

        internal static string Menu_Analyze_Truck =>
            ResourceManager.GetString("Menu_Analyze_Truck", resourceCulture);

        internal static string Menu_Analyze_Truck_Tare =>
            ResourceManager.GetString("Menu_Analyze_Truck_Tare", resourceCulture);

        internal static string Menu_Back =>
            ResourceManager.GetString("Menu_Back", resourceCulture);

        internal static string Menu_Blacklist =>
            ResourceManager.GetString("Menu_Blacklist", resourceCulture);

        internal static string Menu_Cancel =>
            ResourceManager.GetString("Menu_Cancel", resourceCulture);

        internal static string Menu_Capture_Driver_License_ID_Photo =>
            ResourceManager.GetString("Menu_Capture_Driver_License_ID_Photo", resourceCulture);

        internal static string Menu_Checked_By =>
            ResourceManager.GetString("Menu_Checked_By", resourceCulture);

        internal static string Menu_Choose =>
            ResourceManager.GetString("Menu_Choose", resourceCulture);

        internal static string Menu_Clear_Token_Disable_Feature =>
            ResourceManager.GetString("Menu_Clear_Token_Disable_Feature", resourceCulture);

        internal static string Menu_Close =>
            ResourceManager.GetString("Menu_Close", resourceCulture);

        internal static string Menu_Close_DO =>
            ResourceManager.GetString("Menu_Close_DO", resourceCulture);

        internal static string Menu_Compare_All_Commodity_ZWB =>
            ResourceManager.GetString("Menu_Compare_All_Commodity_ZWB", resourceCulture);

        internal static string Menu_Compare_All_Commodity_ZWB_IDSYS =>
            ResourceManager.GetString("Menu_Compare_All_Commodity_ZWB_IDSYS", resourceCulture);

        internal static string Menu_Copy =>
            ResourceManager.GetString("Menu_Copy", resourceCulture);

        internal static string Menu_Copy_All_Commodity =>
            ResourceManager.GetString("Menu_Copy_All_Commodity", resourceCulture);

        internal static string Menu_Copy_All_Driver =>
            ResourceManager.GetString("Menu_Copy_All_Driver", resourceCulture);

        internal static string Menu_Copy_All_Estate =>
            ResourceManager.GetString("Menu_Copy_All_Estate", resourceCulture);

        internal static string Menu_Copy_All_Transporter =>
            ResourceManager.GetString("Menu_Copy_All_Transporter", resourceCulture);

        internal static string Menu_Copy_All_Truck =>
            ResourceManager.GetString("Menu_Copy_All_Truck", resourceCulture);

        internal static string Menu_Copy_All_Types =>
            ResourceManager.GetString("Menu_Copy_All_Types", resourceCulture);

        internal static string Menu_Copy_All_Vendor =>
            ResourceManager.GetString("Menu_Copy_All_Vendor", resourceCulture);

        internal static string Menu_Copy_Commodity =>
            ResourceManager.GetString("Menu_Copy_Commodity", resourceCulture);

        internal static string Menu_Copy_Driver =>
            ResourceManager.GetString("Menu_Copy_Driver", resourceCulture);

        internal static string Menu_Copy_Estate =>
            ResourceManager.GetString("Menu_Copy_Estate", resourceCulture);

        internal static string Menu_Copy_To_All_Locations =>
            ResourceManager.GetString("Menu_Copy_To_All_Locations", resourceCulture);

        internal static string Menu_Copy_Transporter =>
            ResourceManager.GetString("Menu_Copy_Transporter", resourceCulture);

        internal static string Menu_Copy_Truck =>
            ResourceManager.GetString("Menu_Copy_Truck", resourceCulture);

        internal static string Menu_Copy_Type =>
            ResourceManager.GetString("Menu_Copy_Type", resourceCulture);

        internal static string Menu_Copy_Vendor =>
            ResourceManager.GetString("Menu_Copy_Vendor", resourceCulture);

        internal static string Menu_Created_By =>
            ResourceManager.GetString("Menu_Created_By", resourceCulture);

        internal static string Menu_Delete =>
            ResourceManager.GetString("Menu_Delete", resourceCulture);

        internal static string Menu_Diagnostic =>
            ResourceManager.GetString("Menu_Diagnostic", resourceCulture);

        internal static string Menu_Disable_Feature =>
            ResourceManager.GetString("Menu_Disable_Feature", resourceCulture);

        internal static string Menu_Edit =>
            ResourceManager.GetString("Menu_Edit", resourceCulture);

        internal static string Menu_Edit_Lock =>
            ResourceManager.GetString("Menu_Edit_Lock", resourceCulture);

        internal static string Menu_Edit_Transaction_Type =>
            ResourceManager.GetString("Menu_Edit_Transaction_Type", resourceCulture);

        internal static string Menu_Entry_PIN =>
            ResourceManager.GetString("Menu_Entry_PIN", resourceCulture);

        internal static string MENU_ENTRY_SPAREPART_QTY =>
            ResourceManager.GetString("MENU_ENTRY_SPAREPART_QTY", resourceCulture);

        internal static string Menu_Exit =>
            ResourceManager.GetString("Menu_Exit", resourceCulture);

        internal static string Menu_Filter =>
            ResourceManager.GetString("Menu_Filter", resourceCulture);

        internal static string Menu_Find =>
            ResourceManager.GetString("Menu_Find", resourceCulture);

        internal static string Menu_Get_Commodity_ZWB =>
            ResourceManager.GetString("Menu_Get_Commodity_ZWB", resourceCulture);

        internal static string Menu_Get_Contract_Spec =>
            ResourceManager.GetString("Menu_Get_Contract_Spec", resourceCulture);

        internal static string Menu_Map_Vessel_DO =>
            ResourceManager.GetString("Menu_Map_Vessel_DO", resourceCulture);

        internal static string Menu_Mapping_Destination =>
            ResourceManager.GetString("Menu_Mapping_Destination", resourceCulture);

        internal static string Menu_Mark_Delete =>
            ResourceManager.GetString("Menu_Mark_Delete", resourceCulture);

        internal static string Menu_Nego_No =>
            ResourceManager.GetString("Menu_Nego_No", resourceCulture);

        internal static string Menu_Open_DO =>
            ResourceManager.GetString("Menu_Open_DO", resourceCulture);

        internal static string Menu_Print_Preview =>
            ResourceManager.GetString("Menu_Print_Preview", resourceCulture);

        internal static string Menu_Readopt_SAP =>
            ResourceManager.GetString("Menu_Readopt_SAP", resourceCulture);

        internal static string Menu_Readopt_SAP_IDSYS =>
            ResourceManager.GetString("Menu_Readopt_SAP_IDSYS", resourceCulture);

        internal static string Menu_Request_Edit_SAP =>
            ResourceManager.GetString("Menu_Request_Edit_SAP", resourceCulture);

        internal static string Menu_Request_Edit_SAP_IDSYS =>
            ResourceManager.GetString("Menu_Request_Edit_SAP_IDSYS", resourceCulture);

        internal static string Menu_Save =>
            ResourceManager.GetString("Menu_Save", resourceCulture);

        internal static string Menu_Save_As =>
            ResourceManager.GetString("Menu_Save_As", resourceCulture);

        internal static string Menu_Send_All_Commodity_ZWB =>
            ResourceManager.GetString("Menu_Send_All_Commodity_ZWB", resourceCulture);

        internal static string Menu_Send_All_Commodity_ZWB_IDSYS =>
            ResourceManager.GetString("Menu_Send_All_Commodity_ZWB_IDSYS", resourceCulture);

        internal static string Menu_Send_Commodity_ZWB =>
            ResourceManager.GetString("Menu_Send_Commodity_ZWB", resourceCulture);

        internal static string Menu_Set_Comm_Tolerance =>
            ResourceManager.GetString("Menu_Set_Comm_Tolerance", resourceCulture);

        internal static string Menu_Set_Quality =>
            ResourceManager.GetString("Menu_Set_Quality", resourceCulture);

        internal static string Menu_Set_Tolerance =>
            ResourceManager.GetString("Menu_Set_Tolerance", resourceCulture);

        internal static string Menu_Subtotal =>
            ResourceManager.GetString("Menu_Subtotal", resourceCulture);

        internal static string Menu_Synch =>
            ResourceManager.GetString("Menu_Synch", resourceCulture);

        internal static string Menu_Synchronize =>
            ResourceManager.GetString("Menu_Synchronize", resourceCulture);

        internal static string Menu_Synchronize_All =>
            ResourceManager.GetString("Menu_Synchronize_All", resourceCulture);

        internal static string Menu_Toggle_DO =>
            ResourceManager.GetString("Menu_Toggle_DO", resourceCulture);

        internal static string Menu_Total =>
            ResourceManager.GetString("Menu_Total", resourceCulture);

        internal static string Menu_Unblacklist =>
            ResourceManager.GetString("Menu_Unblacklist", resourceCulture);

        internal static string Menu_Unfilter =>
            ResourceManager.GetString("Menu_Unfilter", resourceCulture);

        internal static string Menu_Unmark_Delete =>
            ResourceManager.GetString("Menu_Unmark_Delete", resourceCulture);

        internal static string Menu_View =>
            ResourceManager.GetString("Menu_View", resourceCulture);

        internal static string Menu_ZWB =>
            ResourceManager.GetString("Menu_ZWB", resourceCulture);

        internal static string Mes_001 =>
            ResourceManager.GetString("Mes_001", resourceCulture);

        internal static string Mes_002 =>
            ResourceManager.GetString("Mes_002", resourceCulture);

        internal static string Mes_003 =>
            ResourceManager.GetString("Mes_003", resourceCulture);

        internal static string Mes_004 =>
            ResourceManager.GetString("Mes_004", resourceCulture);

        internal static string Mes_004a =>
            ResourceManager.GetString("Mes_004a", resourceCulture);

        internal static string Mes_004b =>
            ResourceManager.GetString("Mes_004b", resourceCulture);

        internal static string Mes_005 =>
            ResourceManager.GetString("Mes_005", resourceCulture);

        internal static string Mes_006 =>
            ResourceManager.GetString("Mes_006", resourceCulture);

        internal static string Mes_006A =>
            ResourceManager.GetString("Mes_006A", resourceCulture);

        internal static string Mes_009 =>
            ResourceManager.GetString("Mes_009", resourceCulture);

        internal static string Mes_011 =>
            ResourceManager.GetString("Mes_011", resourceCulture);

        internal static string Mes_013 =>
            ResourceManager.GetString("Mes_013", resourceCulture);

        internal static string Mes_014 =>
            ResourceManager.GetString("Mes_014", resourceCulture);

        internal static string Mes_015 =>
            ResourceManager.GetString("Mes_015", resourceCulture);

        internal static string Mes_016 =>
            ResourceManager.GetString("Mes_016", resourceCulture);

        internal static string Mes_017 =>
            ResourceManager.GetString("Mes_017", resourceCulture);

        internal static string Mes_018 =>
            ResourceManager.GetString("Mes_018", resourceCulture);

        internal static string Mes_020 =>
            ResourceManager.GetString("Mes_020", resourceCulture);

        internal static string Mes_021 =>
            ResourceManager.GetString("Mes_021", resourceCulture);

        internal static string Mes_023 =>
            ResourceManager.GetString("Mes_023", resourceCulture);

        internal static string Mes_024 =>
            ResourceManager.GetString("Mes_024", resourceCulture);

        internal static string Mes_024a =>
            ResourceManager.GetString("Mes_024a", resourceCulture);

        internal static string Mes_025 =>
            ResourceManager.GetString("Mes_025", resourceCulture);

        internal static string Mes_026 =>
            ResourceManager.GetString("Mes_026", resourceCulture);

        internal static string Mes_026a =>
            ResourceManager.GetString("Mes_026a", resourceCulture);

        internal static string Mes_027 =>
            ResourceManager.GetString("Mes_027", resourceCulture);

        internal static string Mes_028 =>
            ResourceManager.GetString("Mes_028", resourceCulture);

        internal static string Mes_028_IDSYS =>
            ResourceManager.GetString("Mes_028_IDSYS", resourceCulture);

        internal static string Mes_032 =>
            ResourceManager.GetString("Mes_032", resourceCulture);

        internal static string Mes_034 =>
            ResourceManager.GetString("Mes_034", resourceCulture);

        internal static string Mes_034_IDSYS =>
            ResourceManager.GetString("Mes_034_IDSYS", resourceCulture);

        internal static string Mes_035 =>
            ResourceManager.GetString("Mes_035", resourceCulture);

        internal static string Mes_035_IDSYS =>
            ResourceManager.GetString("Mes_035_IDSYS", resourceCulture);

        internal static string Mes_037 =>
            ResourceManager.GetString("Mes_037", resourceCulture);

        internal static string Mes_038 =>
            ResourceManager.GetString("Mes_038", resourceCulture);

        internal static string Mes_044 =>
            ResourceManager.GetString("Mes_044", resourceCulture);

        internal static string Mes_047A =>
            ResourceManager.GetString("Mes_047A", resourceCulture);

        internal static string Mes_047B =>
            ResourceManager.GetString("Mes_047B", resourceCulture);

        internal static string Mes_048 =>
            ResourceManager.GetString("Mes_048", resourceCulture);

        internal static string Mes_051 =>
            ResourceManager.GetString("Mes_051", resourceCulture);

        internal static string Mes_053 =>
            ResourceManager.GetString("Mes_053", resourceCulture);

        internal static string Mes_054 =>
            ResourceManager.GetString("Mes_054", resourceCulture);

        internal static string Mes_057 =>
            ResourceManager.GetString("Mes_057", resourceCulture);

        internal static string Mes_058 =>
            ResourceManager.GetString("Mes_058", resourceCulture);

        internal static string Mes_059 =>
            ResourceManager.GetString("Mes_059", resourceCulture);

        internal static string Mes_060 =>
            ResourceManager.GetString("Mes_060", resourceCulture);

        internal static string Mes_061 =>
            ResourceManager.GetString("Mes_061", resourceCulture);

        internal static string Mes_062 =>
            ResourceManager.GetString("Mes_062", resourceCulture);

        internal static string Mes_063 =>
            ResourceManager.GetString("Mes_063", resourceCulture);

        internal static string Mes_064 =>
            ResourceManager.GetString("Mes_064", resourceCulture);

        internal static string Mes_065 =>
            ResourceManager.GetString("Mes_065", resourceCulture);

        internal static string Mes_066 =>
            ResourceManager.GetString("Mes_066", resourceCulture);

        internal static string Mes_067 =>
            ResourceManager.GetString("Mes_067", resourceCulture);

        internal static string Mes_068 =>
            ResourceManager.GetString("Mes_068", resourceCulture);

        internal static string Mes_069 =>
            ResourceManager.GetString("Mes_069", resourceCulture);

        internal static string Mes_070 =>
            ResourceManager.GetString("Mes_070", resourceCulture);

        internal static string Mes_072 =>
            ResourceManager.GetString("Mes_072", resourceCulture);

        internal static string Mes_073 =>
            ResourceManager.GetString("Mes_073", resourceCulture);

        internal static string Mes_077 =>
            ResourceManager.GetString("Mes_077", resourceCulture);

        internal static string Mes_078 =>
            ResourceManager.GetString("Mes_078", resourceCulture);

        internal static string Mes_080 =>
            ResourceManager.GetString("Mes_080", resourceCulture);

        internal static string Mes_084 =>
            ResourceManager.GetString("Mes_084", resourceCulture);

        internal static string Mes_084_IDSYS =>
            ResourceManager.GetString("Mes_084_IDSYS", resourceCulture);

        internal static string Mes_086 =>
            ResourceManager.GetString("Mes_086", resourceCulture);

        internal static string Mes_087 =>
            ResourceManager.GetString("Mes_087", resourceCulture);

        internal static string Mes_088 =>
            ResourceManager.GetString("Mes_088", resourceCulture);

        internal static string Mes_090 =>
            ResourceManager.GetString("Mes_090", resourceCulture);

        internal static string Mes_091 =>
            ResourceManager.GetString("Mes_091", resourceCulture);

        internal static string Mes_092 =>
            ResourceManager.GetString("Mes_092", resourceCulture);

        internal static string Mes_093 =>
            ResourceManager.GetString("Mes_093", resourceCulture);

        internal static string Mes_094 =>
            ResourceManager.GetString("Mes_094", resourceCulture);

        internal static string Mes_096 =>
            ResourceManager.GetString("Mes_096", resourceCulture);

        internal static string Mes_097 =>
            ResourceManager.GetString("Mes_097", resourceCulture);

        internal static string Mes_098 =>
            ResourceManager.GetString("Mes_098", resourceCulture);

        internal static string Mes_099 =>
            ResourceManager.GetString("Mes_099", resourceCulture);

        internal static string Mes_100 =>
            ResourceManager.GetString("Mes_100", resourceCulture);

        internal static string Mes_101 =>
            ResourceManager.GetString("Mes_101", resourceCulture);

        internal static string Mes_103 =>
            ResourceManager.GetString("Mes_103", resourceCulture);

        internal static string Mes_104 =>
            ResourceManager.GetString("Mes_104", resourceCulture);

        internal static string Mes_105 =>
            ResourceManager.GetString("Mes_105", resourceCulture);

        internal static string Mes_107 =>
            ResourceManager.GetString("Mes_107", resourceCulture);

        internal static string Mes_108 =>
            ResourceManager.GetString("Mes_108", resourceCulture);

        internal static string Mes_109 =>
            ResourceManager.GetString("Mes_109", resourceCulture);

        internal static string Mes_110 =>
            ResourceManager.GetString("Mes_110", resourceCulture);

        internal static string Mes_114 =>
            ResourceManager.GetString("Mes_114", resourceCulture);

        internal static string Mes_116 =>
            ResourceManager.GetString("Mes_116", resourceCulture);

        internal static string Mes_118 =>
            ResourceManager.GetString("Mes_118", resourceCulture);

        internal static string Mes_120 =>
            ResourceManager.GetString("Mes_120", resourceCulture);

        internal static string Mes_121A =>
            ResourceManager.GetString("Mes_121A", resourceCulture);

        internal static string Mes_121B =>
            ResourceManager.GetString("Mes_121B", resourceCulture);

        internal static string Mes_121C =>
            ResourceManager.GetString("Mes_121C", resourceCulture);

        internal static string Mes_121D =>
            ResourceManager.GetString("Mes_121D", resourceCulture);

        internal static string Mes_121E =>
            ResourceManager.GetString("Mes_121E", resourceCulture);

        internal static string Mes_121F =>
            ResourceManager.GetString("Mes_121F", resourceCulture);

        internal static string Mes_122 =>
            ResourceManager.GetString("Mes_122", resourceCulture);

        internal static string Mes_123 =>
            ResourceManager.GetString("Mes_123", resourceCulture);

        internal static string Mes_124 =>
            ResourceManager.GetString("Mes_124", resourceCulture);

        internal static string Mes_127 =>
            ResourceManager.GetString("Mes_127", resourceCulture);

        internal static string Mes_129 =>
            ResourceManager.GetString("Mes_129", resourceCulture);

        internal static string Mes_130 =>
            ResourceManager.GetString("Mes_130", resourceCulture);

        internal static string Mes_140 =>
            ResourceManager.GetString("Mes_140", resourceCulture);

        internal static string Mes_142 =>
            ResourceManager.GetString("Mes_142", resourceCulture);

        internal static string Mes_143 =>
            ResourceManager.GetString("Mes_143", resourceCulture);

        internal static string Mes_150 =>
            ResourceManager.GetString("Mes_150", resourceCulture);

        internal static string Mes_152 =>
            ResourceManager.GetString("Mes_152", resourceCulture);

        internal static string Mes_153 =>
            ResourceManager.GetString("Mes_153", resourceCulture);

        internal static string Mes_154 =>
            ResourceManager.GetString("Mes_154", resourceCulture);

        internal static string Mes_156 =>
            ResourceManager.GetString("Mes_156", resourceCulture);

        internal static string Mes_157 =>
            ResourceManager.GetString("Mes_157", resourceCulture);

        internal static string Mes_158 =>
            ResourceManager.GetString("Mes_158", resourceCulture);

        internal static string Mes_159 =>
            ResourceManager.GetString("Mes_159", resourceCulture);

        internal static string Mes_162 =>
            ResourceManager.GetString("Mes_162", resourceCulture);

        internal static string Mes_163 =>
            ResourceManager.GetString("Mes_163", resourceCulture);

        internal static string Mes_164 =>
            ResourceManager.GetString("Mes_164", resourceCulture);

        internal static string Mes_165 =>
            ResourceManager.GetString("Mes_165", resourceCulture);

        internal static string Mes_167 =>
            ResourceManager.GetString("Mes_167", resourceCulture);

        internal static string Mes_170 =>
            ResourceManager.GetString("Mes_170", resourceCulture);

        internal static string Mes_171 =>
            ResourceManager.GetString("Mes_171", resourceCulture);

        internal static string Mes_172 =>
            ResourceManager.GetString("Mes_172", resourceCulture);

        internal static string Mes_173 =>
            ResourceManager.GetString("Mes_173", resourceCulture);

        internal static string Mes_174 =>
            ResourceManager.GetString("Mes_174", resourceCulture);

        internal static string Mes_178 =>
            ResourceManager.GetString("Mes_178", resourceCulture);

        internal static string Mes_179 =>
            ResourceManager.GetString("Mes_179", resourceCulture);

        internal static string Mes_180 =>
            ResourceManager.GetString("Mes_180", resourceCulture);

        internal static string Mes_182 =>
            ResourceManager.GetString("Mes_182", resourceCulture);

        internal static string Mes_184 =>
            ResourceManager.GetString("Mes_184", resourceCulture);

        internal static string Mes_185 =>
            ResourceManager.GetString("Mes_185", resourceCulture);

        internal static string Mes_189 =>
            ResourceManager.GetString("Mes_189", resourceCulture);

        internal static string Mes_190 =>
            ResourceManager.GetString("Mes_190", resourceCulture);

        internal static string Mes_192 =>
            ResourceManager.GetString("Mes_192", resourceCulture);

        internal static string Mes_196 =>
            ResourceManager.GetString("Mes_196", resourceCulture);

        internal static string Mes_197 =>
            ResourceManager.GetString("Mes_197", resourceCulture);

        internal static string Mes_198 =>
            ResourceManager.GetString("Mes_198", resourceCulture);

        internal static string Mes_199 =>
            ResourceManager.GetString("Mes_199", resourceCulture);

        internal static string Mes_201 =>
            ResourceManager.GetString("Mes_201", resourceCulture);

        internal static string Mes_202 =>
            ResourceManager.GetString("Mes_202", resourceCulture);

        internal static string Mes_203 =>
            ResourceManager.GetString("Mes_203", resourceCulture);

        internal static string Mes_205 =>
            ResourceManager.GetString("Mes_205", resourceCulture);

        internal static string Mes_206 =>
            ResourceManager.GetString("Mes_206", resourceCulture);

        internal static string Mes_207 =>
            ResourceManager.GetString("Mes_207", resourceCulture);

        internal static string Mes_208 =>
            ResourceManager.GetString("Mes_208", resourceCulture);

        internal static string Mes_209 =>
            ResourceManager.GetString("Mes_209", resourceCulture);

        internal static string Mes_211 =>
            ResourceManager.GetString("Mes_211", resourceCulture);

        internal static string Mes_213A =>
            ResourceManager.GetString("Mes_213A", resourceCulture);

        internal static string Mes_213B =>
            ResourceManager.GetString("Mes_213B", resourceCulture);

        internal static string Mes_215 =>
            ResourceManager.GetString("Mes_215", resourceCulture);

        internal static string Mes_216 =>
            ResourceManager.GetString("Mes_216", resourceCulture);

        internal static string Mes_218 =>
            ResourceManager.GetString("Mes_218", resourceCulture);

        internal static string Mes_219 =>
            ResourceManager.GetString("Mes_219", resourceCulture);

        internal static string Mes_220 =>
            ResourceManager.GetString("Mes_220", resourceCulture);

        internal static string Mes_221 =>
            ResourceManager.GetString("Mes_221", resourceCulture);

        internal static string Mes_223 =>
            ResourceManager.GetString("Mes_223", resourceCulture);

        internal static string Mes_224 =>
            ResourceManager.GetString("Mes_224", resourceCulture);

        internal static string Mes_225 =>
            ResourceManager.GetString("Mes_225", resourceCulture);

        internal static string Mes_233 =>
            ResourceManager.GetString("Mes_233", resourceCulture);

        internal static string Mes_236 =>
            ResourceManager.GetString("Mes_236", resourceCulture);

        internal static string Mes_239 =>
            ResourceManager.GetString("Mes_239", resourceCulture);

        internal static string Mes_240 =>
            ResourceManager.GetString("Mes_240", resourceCulture);

        internal static string Mes_243 =>
            ResourceManager.GetString("Mes_243", resourceCulture);

        internal static string Mes_244 =>
            ResourceManager.GetString("Mes_244", resourceCulture);

        internal static string Mes_248 =>
            ResourceManager.GetString("Mes_248", resourceCulture);

        internal static string Mes_249 =>
            ResourceManager.GetString("Mes_249", resourceCulture);

        internal static string Mes_250 =>
            ResourceManager.GetString("Mes_250", resourceCulture);

        internal static string Mes_255 =>
            ResourceManager.GetString("Mes_255", resourceCulture);

        internal static string Mes_256 =>
            ResourceManager.GetString("Mes_256", resourceCulture);

        internal static string Mes_257 =>
            ResourceManager.GetString("Mes_257", resourceCulture);

        internal static string Mes_258 =>
            ResourceManager.GetString("Mes_258", resourceCulture);

        internal static string Mes_261 =>
            ResourceManager.GetString("Mes_261", resourceCulture);

        internal static string Mes_262 =>
            ResourceManager.GetString("Mes_262", resourceCulture);

        internal static string Mes_263 =>
            ResourceManager.GetString("Mes_263", resourceCulture);

        internal static string Mes_264 =>
            ResourceManager.GetString("Mes_264", resourceCulture);

        internal static string Mes_265 =>
            ResourceManager.GetString("Mes_265", resourceCulture);

        internal static string Mes_266 =>
            ResourceManager.GetString("Mes_266", resourceCulture);

        internal static string Mes_274 =>
            ResourceManager.GetString("Mes_274", resourceCulture);

        internal static string Mes_277 =>
            ResourceManager.GetString("Mes_277", resourceCulture);

        internal static string Mes_282 =>
            ResourceManager.GetString("Mes_282", resourceCulture);

        internal static string Mes_285 =>
            ResourceManager.GetString("Mes_285", resourceCulture);

        internal static string Mes_286 =>
            ResourceManager.GetString("Mes_286", resourceCulture);

        internal static string Mes_287 =>
            ResourceManager.GetString("Mes_287", resourceCulture);

        internal static string Mes_288 =>
            ResourceManager.GetString("Mes_288", resourceCulture);

        internal static string Mes_289 =>
            ResourceManager.GetString("Mes_289", resourceCulture);

        internal static string Mes_290 =>
            ResourceManager.GetString("Mes_290", resourceCulture);

        internal static string Mes_291 =>
            ResourceManager.GetString("Mes_291", resourceCulture);

        internal static string Mes_292 =>
            ResourceManager.GetString("Mes_292", resourceCulture);

        internal static string Mes_293 =>
            ResourceManager.GetString("Mes_293", resourceCulture);

        internal static string Mes_294 =>
            ResourceManager.GetString("Mes_294", resourceCulture);

        internal static string Mes_295 =>
            ResourceManager.GetString("Mes_295", resourceCulture);

        internal static string Mes_296 =>
            ResourceManager.GetString("Mes_296", resourceCulture);

        internal static string Mes_297 =>
            ResourceManager.GetString("Mes_297", resourceCulture);

        internal static string Mes_298 =>
            ResourceManager.GetString("Mes_298", resourceCulture);

        internal static string Mes_299 =>
            ResourceManager.GetString("Mes_299", resourceCulture);

        internal static string Mes_300 =>
            ResourceManager.GetString("Mes_300", resourceCulture);

        internal static string Mes_301 =>
            ResourceManager.GetString("Mes_301", resourceCulture);

        internal static string Mes_302 =>
            ResourceManager.GetString("Mes_302", resourceCulture);

        internal static string Mes_303 =>
            ResourceManager.GetString("Mes_303", resourceCulture);

        internal static string Mes_305 =>
            ResourceManager.GetString("Mes_305", resourceCulture);

        internal static string Mes_306 =>
            ResourceManager.GetString("Mes_306", resourceCulture);

        internal static string Mes_307 =>
            ResourceManager.GetString("Mes_307", resourceCulture);

        internal static string Mes_308 =>
            ResourceManager.GetString("Mes_308", resourceCulture);

        internal static string Mes_309 =>
            ResourceManager.GetString("Mes_309", resourceCulture);

        internal static string Mes_310 =>
            ResourceManager.GetString("Mes_310", resourceCulture);

        internal static string Mes_311 =>
            ResourceManager.GetString("Mes_311", resourceCulture);

        internal static string Mes_312 =>
            ResourceManager.GetString("Mes_312", resourceCulture);

        internal static string Mes_313 =>
            ResourceManager.GetString("Mes_313", resourceCulture);

        internal static string Mes_314 =>
            ResourceManager.GetString("Mes_314", resourceCulture);

        internal static string Mes_316 =>
            ResourceManager.GetString("Mes_316", resourceCulture);

        internal static string Mes_317 =>
            ResourceManager.GetString("Mes_317", resourceCulture);

        internal static string Mes_321A =>
            ResourceManager.GetString("Mes_321A", resourceCulture);

        internal static string Mes_321B =>
            ResourceManager.GetString("Mes_321B", resourceCulture);

        internal static string Mes_323 =>
            ResourceManager.GetString("Mes_323", resourceCulture);

        internal static string Mes_326 =>
            ResourceManager.GetString("Mes_326", resourceCulture);

        internal static string Mes_327 =>
            ResourceManager.GetString("Mes_327", resourceCulture);

        internal static string Mes_328 =>
            ResourceManager.GetString("Mes_328", resourceCulture);

        internal static string Mes_329 =>
            ResourceManager.GetString("Mes_329", resourceCulture);

        internal static string Mes_330 =>
            ResourceManager.GetString("Mes_330", resourceCulture);

        internal static string Mes_331 =>
            ResourceManager.GetString("Mes_331", resourceCulture);

        internal static string Mes_335 =>
            ResourceManager.GetString("Mes_335", resourceCulture);

        internal static string Mes_337 =>
            ResourceManager.GetString("Mes_337", resourceCulture);

        internal static string Mes_338 =>
            ResourceManager.GetString("Mes_338", resourceCulture);

        internal static string Mes_339 =>
            ResourceManager.GetString("Mes_339", resourceCulture);

        internal static string Mes_340 =>
            ResourceManager.GetString("Mes_340", resourceCulture);

        internal static string Mes_341 =>
            ResourceManager.GetString("Mes_341", resourceCulture);

        internal static string Mes_342 =>
            ResourceManager.GetString("Mes_342", resourceCulture);

        internal static string Mes_343 =>
            ResourceManager.GetString("Mes_343", resourceCulture);

        internal static string Mes_344 =>
            ResourceManager.GetString("Mes_344", resourceCulture);

        internal static string Mes_345 =>
            ResourceManager.GetString("Mes_345", resourceCulture);

        internal static string Mes_346 =>
            ResourceManager.GetString("Mes_346", resourceCulture);

        internal static string Mes_347 =>
            ResourceManager.GetString("Mes_347", resourceCulture);

        internal static string Mes_348 =>
            ResourceManager.GetString("Mes_348", resourceCulture);

        internal static string Mes_349 =>
            ResourceManager.GetString("Mes_349", resourceCulture);

        internal static string Mes_350 =>
            ResourceManager.GetString("Mes_350", resourceCulture);

        internal static string Mes_351 =>
            ResourceManager.GetString("Mes_351", resourceCulture);

        internal static string Mes_352 =>
            ResourceManager.GetString("Mes_352", resourceCulture);

        internal static string Mes_354 =>
            ResourceManager.GetString("Mes_354", resourceCulture);

        internal static string Mes_355 =>
            ResourceManager.GetString("Mes_355", resourceCulture);

        internal static string Mes_358 =>
            ResourceManager.GetString("Mes_358", resourceCulture);

        internal static string Mes_359 =>
            ResourceManager.GetString("Mes_359", resourceCulture);

        internal static string Mes_361 =>
            ResourceManager.GetString("Mes_361", resourceCulture);

        internal static string Mes_362 =>
            ResourceManager.GetString("Mes_362", resourceCulture);

        internal static string Mes_363 =>
            ResourceManager.GetString("Mes_363", resourceCulture);

        internal static string Mes_364 =>
            ResourceManager.GetString("Mes_364", resourceCulture);

        internal static string Mes_365 =>
            ResourceManager.GetString("Mes_365", resourceCulture);

        internal static string Mes_366 =>
            ResourceManager.GetString("Mes_366", resourceCulture);

        internal static string Mes_376 =>
            ResourceManager.GetString("Mes_376", resourceCulture);

        internal static string Mes_379 =>
            ResourceManager.GetString("Mes_379", resourceCulture);

        internal static string Mes_381 =>
            ResourceManager.GetString("Mes_381", resourceCulture);

        internal static string Mes_382 =>
            ResourceManager.GetString("Mes_382", resourceCulture);

        internal static string Mes_383 =>
            ResourceManager.GetString("Mes_383", resourceCulture);

        internal static string Mes_384 =>
            ResourceManager.GetString("Mes_384", resourceCulture);

        internal static string Mes_385 =>
            ResourceManager.GetString("Mes_385", resourceCulture);

        internal static string Mes_386 =>
            ResourceManager.GetString("Mes_386", resourceCulture);

        internal static string Mes_388 =>
            ResourceManager.GetString("Mes_388", resourceCulture);

        internal static string Mes_389 =>
            ResourceManager.GetString("Mes_389", resourceCulture);

        internal static string Mes_390 =>
            ResourceManager.GetString("Mes_390", resourceCulture);

        internal static string Mes_391 =>
            ResourceManager.GetString("Mes_391", resourceCulture);

        internal static string Mes_393 =>
            ResourceManager.GetString("Mes_393", resourceCulture);

        internal static string Mes_401 =>
            ResourceManager.GetString("Mes_401", resourceCulture);

        internal static string Mes_403 =>
            ResourceManager.GetString("Mes_403", resourceCulture);

        internal static string Mes_411 =>
            ResourceManager.GetString("Mes_411", resourceCulture);

        internal static string Mes_413 =>
            ResourceManager.GetString("Mes_413", resourceCulture);

        internal static string Mes_415 =>
            ResourceManager.GetString("Mes_415", resourceCulture);

        internal static string Mes_421 =>
            ResourceManager.GetString("Mes_421", resourceCulture);

        internal static string Mes_426 =>
            ResourceManager.GetString("Mes_426", resourceCulture);

        internal static string Mes_429 =>
            ResourceManager.GetString("Mes_429", resourceCulture);

        internal static string Mes_430 =>
            ResourceManager.GetString("Mes_430", resourceCulture);

        internal static string Mes_431 =>
            ResourceManager.GetString("Mes_431", resourceCulture);

        internal static string Mes_432 =>
            ResourceManager.GetString("Mes_432", resourceCulture);

        internal static string Mes_433 =>
            ResourceManager.GetString("Mes_433", resourceCulture);

        internal static string Mes_434 =>
            ResourceManager.GetString("Mes_434", resourceCulture);

        internal static string Mes_435 =>
            ResourceManager.GetString("Mes_435", resourceCulture);

        internal static string Mes_436 =>
            ResourceManager.GetString("Mes_436", resourceCulture);

        internal static string Mes_440 =>
            ResourceManager.GetString("Mes_440", resourceCulture);

        internal static string Mes_452 =>
            ResourceManager.GetString("Mes_452", resourceCulture);

        internal static string Mes_453 =>
            ResourceManager.GetString("Mes_453", resourceCulture);

        internal static string Mes_454 =>
            ResourceManager.GetString("Mes_454", resourceCulture);

        internal static string Mes_455 =>
            ResourceManager.GetString("Mes_455", resourceCulture);

        internal static string Mes_456 =>
            ResourceManager.GetString("Mes_456", resourceCulture);

        internal static string Mes_457 =>
            ResourceManager.GetString("Mes_457", resourceCulture);

        internal static string Mes_458 =>
            ResourceManager.GetString("Mes_458", resourceCulture);

        internal static string Mes_459 =>
            ResourceManager.GetString("Mes_459", resourceCulture);

        internal static string Mes_460 =>
            ResourceManager.GetString("Mes_460", resourceCulture);

        internal static string Mes_460a =>
            ResourceManager.GetString("Mes_460a", resourceCulture);

        internal static string Mes_461 =>
            ResourceManager.GetString("Mes_461", resourceCulture);

        internal static string Mes_462 =>
            ResourceManager.GetString("Mes_462", resourceCulture);

        internal static string Mes_463 =>
            ResourceManager.GetString("Mes_463", resourceCulture);

        internal static string Mes_464 =>
            ResourceManager.GetString("Mes_464", resourceCulture);

        internal static string Mes_465 =>
            ResourceManager.GetString("Mes_465", resourceCulture);

        internal static string Mes_466 =>
            ResourceManager.GetString("Mes_466", resourceCulture);

        internal static string Mes_469 =>
            ResourceManager.GetString("Mes_469", resourceCulture);

        internal static string Mes_479 =>
            ResourceManager.GetString("Mes_479", resourceCulture);

        internal static string Mes_481 =>
            ResourceManager.GetString("Mes_481", resourceCulture);

        internal static string Mes_483 =>
            ResourceManager.GetString("Mes_483", resourceCulture);

        internal static string Mes_484 =>
            ResourceManager.GetString("Mes_484", resourceCulture);

        internal static string Mes_486 =>
            ResourceManager.GetString("Mes_486", resourceCulture);

        internal static string Mes_489 =>
            ResourceManager.GetString("Mes_489", resourceCulture);

        internal static string Mes_492 =>
            ResourceManager.GetString("Mes_492", resourceCulture);

        internal static string Mes_493 =>
            ResourceManager.GetString("Mes_493", resourceCulture);

        internal static string Mes_494 =>
            ResourceManager.GetString("Mes_494", resourceCulture);

        internal static string Mes_495 =>
            ResourceManager.GetString("Mes_495", resourceCulture);

        internal static string Mes_496 =>
            ResourceManager.GetString("Mes_496", resourceCulture);

        internal static string Mes_497 =>
            ResourceManager.GetString("Mes_497", resourceCulture);

        internal static string Mes_498 =>
            ResourceManager.GetString("Mes_498", resourceCulture);

        internal static string Mes_499 =>
            ResourceManager.GetString("Mes_499", resourceCulture);

        internal static string Mes_500 =>
            ResourceManager.GetString("Mes_500", resourceCulture);

        internal static string Mes_501 =>
            ResourceManager.GetString("Mes_501", resourceCulture);

        internal static string Mes_502 =>
            ResourceManager.GetString("Mes_502", resourceCulture);

        internal static string Mes_503 =>
            ResourceManager.GetString("Mes_503", resourceCulture);

        internal static string Mes_504 =>
            ResourceManager.GetString("Mes_504", resourceCulture);

        internal static string Mes_505 =>
            ResourceManager.GetString("Mes_505", resourceCulture);

        internal static string Mes_506 =>
            ResourceManager.GetString("Mes_506", resourceCulture);

        internal static string Mes_507 =>
            ResourceManager.GetString("Mes_507", resourceCulture);

        internal static string Mes_510 =>
            ResourceManager.GetString("Mes_510", resourceCulture);

        internal static string Mes_511 =>
            ResourceManager.GetString("Mes_511", resourceCulture);

        internal static string Mes_512 =>
            ResourceManager.GetString("Mes_512", resourceCulture);

        internal static string Mes_513 =>
            ResourceManager.GetString("Mes_513", resourceCulture);

        internal static string Mes_514 =>
            ResourceManager.GetString("Mes_514", resourceCulture);

        internal static string Mes_515 =>
            ResourceManager.GetString("Mes_515", resourceCulture);

        internal static string Mes_516 =>
            ResourceManager.GetString("Mes_516", resourceCulture);

        internal static string Mes_517 =>
            ResourceManager.GetString("Mes_517", resourceCulture);

        internal static string Mes_518 =>
            ResourceManager.GetString("Mes_518", resourceCulture);

        internal static string Mes_519 =>
            ResourceManager.GetString("Mes_519", resourceCulture);

        internal static string Mes_520 =>
            ResourceManager.GetString("Mes_520", resourceCulture);

        internal static string Mes_521 =>
            ResourceManager.GetString("Mes_521", resourceCulture);

        internal static string Mes_523 =>
            ResourceManager.GetString("Mes_523", resourceCulture);

        internal static string Mes_524 =>
            ResourceManager.GetString("Mes_524", resourceCulture);

        internal static string Mes_525 =>
            ResourceManager.GetString("Mes_525", resourceCulture);

        internal static string Mes_526 =>
            ResourceManager.GetString("Mes_526", resourceCulture);

        internal static string Mes_527 =>
            ResourceManager.GetString("Mes_527", resourceCulture);

        internal static string Mes_528 =>
            ResourceManager.GetString("Mes_528", resourceCulture);

        internal static string Mes_531 =>
            ResourceManager.GetString("Mes_531", resourceCulture);

        internal static string Mes_532 =>
            ResourceManager.GetString("Mes_532", resourceCulture);

        internal static string Mes_533 =>
            ResourceManager.GetString("Mes_533", resourceCulture);

        internal static string Mes_534 =>
            ResourceManager.GetString("Mes_534", resourceCulture);

        internal static string Mes_535A =>
            ResourceManager.GetString("Mes_535A", resourceCulture);

        internal static string Mes_535B =>
            ResourceManager.GetString("Mes_535B", resourceCulture);

        internal static string Mes_536 =>
            ResourceManager.GetString("Mes_536", resourceCulture);

        internal static string Mes_537 =>
            ResourceManager.GetString("Mes_537", resourceCulture);

        internal static string Mes_539 =>
            ResourceManager.GetString("Mes_539", resourceCulture);

        internal static string Mes_545 =>
            ResourceManager.GetString("Mes_545", resourceCulture);

        internal static string Mes_548 =>
            ResourceManager.GetString("Mes_548", resourceCulture);

        internal static string Mes_549 =>
            ResourceManager.GetString("Mes_549", resourceCulture);

        internal static string Mes_559 =>
            ResourceManager.GetString("Mes_559", resourceCulture);

        internal static string Mes_561 =>
            ResourceManager.GetString("Mes_561", resourceCulture);

        internal static string Mes_562 =>
            ResourceManager.GetString("Mes_562", resourceCulture);

        internal static string Mes_564 =>
            ResourceManager.GetString("Mes_564", resourceCulture);

        internal static string Mes_565 =>
            ResourceManager.GetString("Mes_565", resourceCulture);

        internal static string Mes_566 =>
            ResourceManager.GetString("Mes_566", resourceCulture);

        internal static string Mes_573 =>
            ResourceManager.GetString("Mes_573", resourceCulture);

        internal static string Mes_575 =>
            ResourceManager.GetString("Mes_575", resourceCulture);

        internal static string Mes_576 =>
            ResourceManager.GetString("Mes_576", resourceCulture);

        internal static string Mes_582 =>
            ResourceManager.GetString("Mes_582", resourceCulture);

        internal static string Mes_584 =>
            ResourceManager.GetString("Mes_584", resourceCulture);

        internal static string Mes_585 =>
            ResourceManager.GetString("Mes_585", resourceCulture);

        internal static string Mes_586 =>
            ResourceManager.GetString("Mes_586", resourceCulture);

        internal static string Mes_587 =>
            ResourceManager.GetString("Mes_587", resourceCulture);

        internal static string Mes_588 =>
            ResourceManager.GetString("Mes_588", resourceCulture);

        internal static string Mes_589 =>
            ResourceManager.GetString("Mes_589", resourceCulture);

        internal static string Mes_592 =>
            ResourceManager.GetString("Mes_592", resourceCulture);

        internal static string Mes_595 =>
            ResourceManager.GetString("Mes_595", resourceCulture);

        internal static string Mes_596 =>
            ResourceManager.GetString("Mes_596", resourceCulture);

        internal static string Mes_599 =>
            ResourceManager.GetString("Mes_599", resourceCulture);

        internal static string Mes_602 =>
            ResourceManager.GetString("Mes_602", resourceCulture);

        internal static string Mes_603 =>
            ResourceManager.GetString("Mes_603", resourceCulture);

        internal static string Mes_604 =>
            ResourceManager.GetString("Mes_604", resourceCulture);

        internal static string Mes_605 =>
            ResourceManager.GetString("Mes_605", resourceCulture);

        internal static string Mes_606 =>
            ResourceManager.GetString("Mes_606", resourceCulture);

        internal static string Mes_607 =>
            ResourceManager.GetString("Mes_607", resourceCulture);

        internal static string Mes_608 =>
            ResourceManager.GetString("Mes_608", resourceCulture);

        internal static string Mes_609 =>
            ResourceManager.GetString("Mes_609", resourceCulture);

        internal static string Mes_610 =>
            ResourceManager.GetString("Mes_610", resourceCulture);

        internal static string Mes_611 =>
            ResourceManager.GetString("Mes_611", resourceCulture);

        internal static string Mes_612 =>
            ResourceManager.GetString("Mes_612", resourceCulture);

        internal static string Mes_613 =>
            ResourceManager.GetString("Mes_613", resourceCulture);

        internal static string Mes_614 =>
            ResourceManager.GetString("Mes_614", resourceCulture);

        internal static string Mes_615 =>
            ResourceManager.GetString("Mes_615", resourceCulture);

        internal static string Mes_616 =>
            ResourceManager.GetString("Mes_616", resourceCulture);

        internal static string Mes_617 =>
            ResourceManager.GetString("Mes_617", resourceCulture);

        internal static string Mes_618_01 =>
            ResourceManager.GetString("Mes_618_01", resourceCulture);

        internal static string Mes_618_02 =>
            ResourceManager.GetString("Mes_618_02", resourceCulture);

        internal static string Mes_619 =>
            ResourceManager.GetString("Mes_619", resourceCulture);

        internal static string Mes_620 =>
            ResourceManager.GetString("Mes_620", resourceCulture);

        internal static string Mes_621 =>
            ResourceManager.GetString("Mes_621", resourceCulture);

        internal static string Mes_622 =>
            ResourceManager.GetString("Mes_622", resourceCulture);

        internal static string Mes_623 =>
            ResourceManager.GetString("Mes_623", resourceCulture);

        internal static string Mes_624 =>
            ResourceManager.GetString("Mes_624", resourceCulture);

        internal static string Mes_625 =>
            ResourceManager.GetString("Mes_625", resourceCulture);

        internal static string Mes_626 =>
            ResourceManager.GetString("Mes_626", resourceCulture);

        internal static string Mes_627 =>
            ResourceManager.GetString("Mes_627", resourceCulture);

        internal static string Mes_628 =>
            ResourceManager.GetString("Mes_628", resourceCulture);

        internal static string Mes_629 =>
            ResourceManager.GetString("Mes_629", resourceCulture);

        internal static string Mes_630 =>
            ResourceManager.GetString("Mes_630", resourceCulture);

        internal static string Mes_Adopt_Data_Finish =>
            ResourceManager.GetString("Mes_Adopt_Data_Finish", resourceCulture);

        internal static string Mes_Adopt_Failed =>
            ResourceManager.GetString("Mes_Adopt_Failed", resourceCulture);

        internal static string Mes_Adopt_Finish =>
            ResourceManager.GetString("Mes_Adopt_Finish", resourceCulture);

        internal static string Mes_Adopt_First =>
            ResourceManager.GetString("Mes_Adopt_First", resourceCulture);

        internal static string Mes_Are_you_sure_want_to_disable_feature =>
            ResourceManager.GetString("Mes_Are_you_sure_want_to_disable_feature", resourceCulture);

        internal static string Mes_Are_you_sure_want_to_reset_password =>
            ResourceManager.GetString("Mes_Are_you_sure_want_to_reset_password", resourceCulture);

        internal static string Mes_Blacklist_Reason =>
            ResourceManager.GetString("Mes_Blacklist_Reason", resourceCulture);

        internal static string Mes_Block_List =>
            ResourceManager.GetString("Mes_Block_List", resourceCulture);

        internal static string Mes_Calibration_Valid_Date_Intersect =>
            ResourceManager.GetString("Mes_Calibration_Valid_Date_Intersect", resourceCulture);

        internal static string Mes_Calibration_Valid_Date_Intersect_2 =>
            ResourceManager.GetString("Mes_Calibration_Valid_Date_Intersect_2", resourceCulture);

        internal static string Mes_Camera_Code_Exist =>
            ResourceManager.GetString("Mes_Camera_Code_Exist", resourceCulture);

        internal static string Mes_Certification_No_Empty =>
            ResourceManager.GetString("Mes_Certification_No_Empty", resourceCulture);

        internal static string Mes_Check_OS =>
            ResourceManager.GetString("Mes_Check_OS", resourceCulture);

        internal static string Mes_Clear_Token_Disable_Feature_Success =>
            ResourceManager.GetString("Mes_Clear_Token_Disable_Feature_Success", resourceCulture);

        internal static string Mes_Close =>
            ResourceManager.GetString("Mes_Close", resourceCulture);

        internal static string Mes_Commodity_Convertion =>
            ResourceManager.GetString("Mes_Commodity_Convertion", resourceCulture);

        internal static string Mes_Commodity_Copied =>
            ResourceManager.GetString("Mes_Commodity_Copied", resourceCulture);

        internal static string Mes_Commodity_Type =>
            ResourceManager.GetString("Mes_Commodity_Type", resourceCulture);

        internal static string Mes_Commodity_Unit =>
            ResourceManager.GetString("Mes_Commodity_Unit", resourceCulture);

        internal static string Mes_Confirm =>
            ResourceManager.GetString("Mes_Confirm", resourceCulture);

        internal static string Mes_Confirm_Caps =>
            ResourceManager.GetString("Mes_Confirm_Caps", resourceCulture);

        internal static string Mes_Confirm_Code_Change =>
            ResourceManager.GetString("Mes_Confirm_Code_Change", resourceCulture);

        internal static string Mes_Confirm_Continue =>
            ResourceManager.GetString("Mes_Confirm_Continue", resourceCulture);

        internal static string Mes_Confirm_Copy =>
            ResourceManager.GetString("Mes_Confirm_Copy", resourceCulture);

        internal static string Mes_Confirm_Copy_All_Company_Location =>
            ResourceManager.GetString("Mes_Confirm_Copy_All_Company_Location", resourceCulture);

        internal static string Mes_Confirm_Copy_All_Truck =>
            ResourceManager.GetString("Mes_Confirm_Copy_All_Truck", resourceCulture);

        internal static string Mes_Confirm_Copy_Commodity =>
            ResourceManager.GetString("Mes_Confirm_Copy_Commodity", resourceCulture);

        internal static string Mes_Confirm_Copy_Driver =>
            ResourceManager.GetString("Mes_Confirm_Copy_Driver", resourceCulture);

        internal static string Mes_Confirm_Copy_Estate =>
            ResourceManager.GetString("Mes_Confirm_Copy_Estate", resourceCulture);

        internal static string Mes_Confirm_Copy_Relation =>
            ResourceManager.GetString("Mes_Confirm_Copy_Relation", resourceCulture);

        internal static string Mes_Confirm_Copy_Transporter =>
            ResourceManager.GetString("Mes_Confirm_Copy_Transporter", resourceCulture);

        internal static string Mes_Confirm_Copy_Types =>
            ResourceManager.GetString("Mes_Confirm_Copy_Types", resourceCulture);

        internal static string Mes_Confirm_Delete_SAP_Destination =>
            ResourceManager.GetString("Mes_Confirm_Delete_SAP_Destination", resourceCulture);

        internal static string Mes_Confirm_Delete_SAP_Destination_IDSYS =>
            ResourceManager.GetString("Mes_Confirm_Delete_SAP_Destination_IDSYS", resourceCulture);

        internal static string Mes_Confirm_Edit_DO_No =>
            ResourceManager.GetString("Mes_Confirm_Edit_DO_No", resourceCulture);

        internal static string Mes_Confirm_Edit_DO_No_Replace_New =>
            ResourceManager.GetString("Mes_Confirm_Edit_DO_No_Replace_New", resourceCulture);

        internal static string Mes_Confirm_Edit_DO_No_Trigger =>
            ResourceManager.GetString("Mes_Confirm_Edit_DO_No_Trigger", resourceCulture);

        internal static string Mes_Confirm_Edit_Transaction_Type =>
            ResourceManager.GetString("Mes_Confirm_Edit_Transaction_Type", resourceCulture);

        internal static string Mes_Confirm_Older_Token =>
            ResourceManager.GetString("Mes_Confirm_Older_Token", resourceCulture);

        internal static string Mes_Confirm_Older_Token_2 =>
            ResourceManager.GetString("Mes_Confirm_Older_Token_2", resourceCulture);

        internal static string Mes_Confirm_Replace_Block =>
            ResourceManager.GetString("Mes_Confirm_Replace_Block", resourceCulture);

        internal static string Mes_Confirm_Replace_Tanker =>
            ResourceManager.GetString("Mes_Confirm_Replace_Tanker", resourceCulture);

        internal static string Mes_Confirm_Save_PIN =>
            ResourceManager.GetString("Mes_Confirm_Save_PIN", resourceCulture);

        internal static string Mes_Confirm_Weigh_Form_Closed =>
            ResourceManager.GetString("Mes_Confirm_Weigh_Form_Closed", resourceCulture);

        internal static string Mes_Confirm_Without_Token =>
            ResourceManager.GetString("Mes_Confirm_Without_Token", resourceCulture);

        internal static string Mes_Confirmation =>
            ResourceManager.GetString("Mes_Confirmation", resourceCulture);

        internal static string Mes_Connecting_to_Camera =>
            ResourceManager.GetString("Mes_Connecting_to_Camera", resourceCulture);

        internal static string Mes_Conversion_Weight =>
            ResourceManager.GetString("Mes_Conversion_Weight", resourceCulture);

        internal static string Mes_Conversion_Weight_2 =>
            ResourceManager.GetString("Mes_Conversion_Weight_2", resourceCulture);

        internal static string Mes_Conversion_Weight_3 =>
            ResourceManager.GetString("Mes_Conversion_Weight_3", resourceCulture);

        internal static string Mes_Conversion_Weight_4 =>
            ResourceManager.GetString("Mes_Conversion_Weight_4", resourceCulture);

        internal static string Mes_Conversion_Weight_5 =>
            ResourceManager.GetString("Mes_Conversion_Weight_5", resourceCulture);

        internal static string Mes_Copied_All_Location =>
            ResourceManager.GetString("Mes_Copied_All_Location", resourceCulture);

        internal static string Mes_Copy_From =>
            ResourceManager.GetString("Mes_Copy_From", resourceCulture);

        internal static string Mes_Delete_Container =>
            ResourceManager.GetString("Mes_Delete_Container", resourceCulture);

        internal static string Mes_Delete_Container_2 =>
            ResourceManager.GetString("Mes_Delete_Container_2", resourceCulture);

        internal static string Mes_Destination_Mapping_Success =>
            ResourceManager.GetString("Mes_Destination_Mapping_Success", resourceCulture);

        internal static string Mes_Div_List =>
            ResourceManager.GetString("Mes_Div_List", resourceCulture);

        internal static string Mes_DO_Contract =>
            ResourceManager.GetString("Mes_DO_Contract", resourceCulture);

        internal static string Mes_DO_has_been_used_by_Vessel =>
            ResourceManager.GetString("Mes_DO_has_been_used_by_Vessel", resourceCulture);

        internal static string Mes_Driver_Copied =>
            ResourceManager.GetString("Mes_Driver_Copied", resourceCulture);

        internal static string Mes_Edit_Container_No =>
            ResourceManager.GetString("Mes_Edit_Container_No", resourceCulture);

        internal static string Mes_Entry_Commodity_Code =>
            ResourceManager.GetString("Mes_Entry_Commodity_Code", resourceCulture);

        internal static string Mes_Error_Caps =>
            ResourceManager.GetString("Mes_Error_Caps", resourceCulture);

        internal static string Mes_Error_Check_Tanker_Empty =>
            ResourceManager.GetString("Mes_Error_Check_Tanker_Empty", resourceCulture);

        internal static string Mes_Error_Close_Reserved_DO =>
            ResourceManager.GetString("Mes_Error_Close_Reserved_DO", resourceCulture);

        internal static string Mes_Error_Connect_SAP =>
            ResourceManager.GetString("Mes_Error_Connect_SAP", resourceCulture);

        internal static string Mes_Error_Delete_Reserved_DO =>
            ResourceManager.GetString("Mes_Error_Delete_Reserved_DO", resourceCulture);

        internal static string Mes_Error_Delete_Temp_DO =>
            ResourceManager.GetString("Mes_Error_Delete_Temp_DO", resourceCulture);

        internal static string Mes_Error_Delete_Transaction_Exists =>
            ResourceManager.GetString("Mes_Error_Delete_Transaction_Exists", resourceCulture);

        internal static string Mes_Error_Delete_Used_In_Setting =>
            ResourceManager.GetString("Mes_Error_Delete_Used_In_Setting", resourceCulture);

        internal static string Mes_Error_Delete_Used_Tanker =>
            ResourceManager.GetString("Mes_Error_Delete_Used_Tanker", resourceCulture);

        internal static string Mes_Error_DO_Check_Max_Qty =>
            ResourceManager.GetString("Mes_Error_DO_Check_Max_Qty", resourceCulture);

        internal static string Mes_Error_DO_Check_Max_Qty_2 =>
            ResourceManager.GetString("Mes_Error_DO_Check_Max_Qty_2", resourceCulture);

        internal static string MES_Error_DO_Not_Adopt_SAP =>
            ResourceManager.GetString("MES_Error_DO_Not_Adopt_SAP", resourceCulture);

        internal static string MES_Error_DO_Not_Adopt_SAP_IDSYS =>
            ResourceManager.GetString("MES_Error_DO_Not_Adopt_SAP_IDSYS", resourceCulture);

        internal static string Mes_Error_Duplicate_Item =>
            ResourceManager.GetString("Mes_Error_Duplicate_Item", resourceCulture);

        internal static string Mes_Error_Edit_Reserved_DO =>
            ResourceManager.GetString("Mes_Error_Edit_Reserved_DO", resourceCulture);

        internal static string Mes_Error_Edit_Temp_DO =>
            ResourceManager.GetString("Mes_Error_Edit_Temp_DO", resourceCulture);

        internal static string Mes_Error_Empty_Commodity =>
            ResourceManager.GetString("Mes_Error_Empty_Commodity", resourceCulture);

        internal static string Mes_Error_Empty_Qty =>
            ResourceManager.GetString("Mes_Error_Empty_Qty", resourceCulture);

        internal static string Mes_Error_Empty_SO_Item =>
            ResourceManager.GetString("Mes_Error_Empty_SO_Item", resourceCulture);

        internal static string Mes_Error_Empty_Tolerance =>
            ResourceManager.GetString("Mes_Error_Empty_Tolerance", resourceCulture);

        internal static string Mes_Error_Estate_Code =>
            ResourceManager.GetString("Mes_Error_Estate_Code", resourceCulture);

        internal static string Mes_Error_Location_Code =>
            ResourceManager.GetString("Mes_Error_Location_Code", resourceCulture);

        internal static string Mes_Error_Maintain_Gross_Weight =>
            ResourceManager.GetString("Mes_Error_Maintain_Gross_Weight", resourceCulture);

        internal static string Mes_Error_Max_Capacity_Zero =>
            ResourceManager.GetString("Mes_Error_Max_Capacity_Zero", resourceCulture);

        internal static string Mes_Error_Qty_Vessel_Not_Equal =>
            ResourceManager.GetString("Mes_Error_Qty_Vessel_Not_Equal", resourceCulture);

        internal static string Mes_Error_Relation_Code_Length =>
            ResourceManager.GetString("Mes_Error_Relation_Code_Length", resourceCulture);

        internal static string Mes_Error_SO_Item =>
            ResourceManager.GetString("Mes_Error_SO_Item", resourceCulture);

        internal static string Mes_Error_SO_No =>
            ResourceManager.GetString("Mes_Error_SO_No", resourceCulture);

        internal static string Mes_Error_Transporter_Code_Length =>
            ResourceManager.GetString("Mes_Error_Transporter_Code_Length", resourceCulture);

        internal static string Mes_Error_Vessel_DO_Empty =>
            ResourceManager.GetString("Mes_Error_Vessel_DO_Empty", resourceCulture);

        internal static string Mes_Error_With_Spaces =>
            ResourceManager.GetString("Mes_Error_With_Spaces", resourceCulture);

        internal static string Mes_Estate_Copied =>
            ResourceManager.GetString("Mes_Estate_Copied", resourceCulture);

        internal static string Mes_Fail =>
            ResourceManager.GetString("Mes_Fail", resourceCulture);

        internal static string Mes_Fail_Caps =>
            ResourceManager.GetString("Mes_Fail_Caps", resourceCulture);

        internal static string Mes_Fail_Send_Email =>
            ResourceManager.GetString("Mes_Fail_Send_Email", resourceCulture);

        internal static string Mes_Fail_Send_Token =>
            ResourceManager.GetString("Mes_Fail_Send_Token", resourceCulture);

        internal static string Mes_Fail_Send_Token_2 =>
            ResourceManager.GetString("Mes_Fail_Send_Token_2", resourceCulture);

        internal static string Mes_Fail_Send_Token_3 =>
            ResourceManager.GetString("Mes_Fail_Send_Token_3", resourceCulture);

        internal static string Mes_Fail_Send_Token_Caps =>
            ResourceManager.GetString("Mes_Fail_Send_Token_Caps", resourceCulture);

        internal static string Mes_Fail_to_Save_Photo_01 =>
            ResourceManager.GetString("Mes_Fail_to_Save_Photo_01", resourceCulture);

        internal static string Mes_Fail_to_Save_Photo_02 =>
            ResourceManager.GetString("Mes_Fail_to_Save_Photo_02", resourceCulture);

        internal static string Mes_Fail_Transaction_Locked =>
            ResourceManager.GetString("Mes_Fail_Transaction_Locked", resourceCulture);

        internal static string Mes_Fail_Transaction_Locked_2 =>
            ResourceManager.GetString("Mes_Fail_Transaction_Locked_2", resourceCulture);

        internal static string Mes_Fail_Transaction_Locked_3 =>
            ResourceManager.GetString("Mes_Fail_Transaction_Locked_3", resourceCulture);

        internal static string Mes_Failed_Sync =>
            ResourceManager.GetString("Mes_Failed_Sync", resourceCulture);

        internal static string Mes_Failed_To_Connect_SAP_Network =>
            ResourceManager.GetString("Mes_Failed_To_Connect_SAP_Network", resourceCulture);

        internal static string Mes_Failed_To_Connect_SAP_Technical =>
            ResourceManager.GetString("Mes_Failed_To_Connect_SAP_Technical", resourceCulture);

        internal static string Mes_Fill_All =>
            ResourceManager.GetString("Mes_Fill_All", resourceCulture);

        internal static string Mes_Fill_Message =>
            ResourceManager.GetString("Mes_Fill_Message", resourceCulture);

        internal static string Mes_Fill_Tolerance =>
            ResourceManager.GetString("Mes_Fill_Tolerance", resourceCulture);

        internal static string Mes_Fill_Tolerance_KG =>
            ResourceManager.GetString("Mes_Fill_Tolerance_KG", resourceCulture);

        internal static string Mes_Fill_Tolerance_Percent =>
            ResourceManager.GetString("Mes_Fill_Tolerance_Percent", resourceCulture);

        internal static string Mes_Finish =>
            ResourceManager.GetString("Mes_Finish", resourceCulture);

        internal static string Mes_Get_Data_ZWB =>
            ResourceManager.GetString("Mes_Get_Data_ZWB", resourceCulture);

        internal static string Mes_GRCustNoSyncAuto =>
            ResourceManager.GetString("Mes_GRCustNoSyncAuto", resourceCulture);

        internal static string Mes_Gross_Mandatory =>
            ResourceManager.GetString("Mes_Gross_Mandatory", resourceCulture);

        internal static string Mes_Gross_Weight =>
            ResourceManager.GetString("Mes_Gross_Weight", resourceCulture);

        internal static string Mes_Info_Full_Map_DO_Vessel =>
            ResourceManager.GetString("Mes_Info_Full_Map_DO_Vessel", resourceCulture);

        internal static string Mes_Info_Full_Map_DO_Vessel_2 =>
            ResourceManager.GetString("Mes_Info_Full_Map_DO_Vessel_2", resourceCulture);

        internal static string Mes_Info_Map_DO_Vessel =>
            ResourceManager.GetString("Mes_Info_Map_DO_Vessel", resourceCulture);

        internal static string Mes_Info_Map_DO_Vessel_2 =>
            ResourceManager.GetString("Mes_Info_Map_DO_Vessel_2", resourceCulture);

        internal static string Mes_Info_Map_DO_Vessel_3 =>
            ResourceManager.GetString("Mes_Info_Map_DO_Vessel_3", resourceCulture);

        internal static string Mes_Info_SPBNO_Used =>
            ResourceManager.GetString("Mes_Info_SPBNO_Used", resourceCulture);

        internal static string Mes_Inserted =>
            ResourceManager.GetString("Mes_Inserted", resourceCulture);

        internal static string Mes_Inserted_Rows =>
            ResourceManager.GetString("Mes_Inserted_Rows", resourceCulture);

        internal static string Mes_Invalid_Calibration_Valid_Date =>
            ResourceManager.GetString("Mes_Invalid_Calibration_Valid_Date", resourceCulture);

        internal static string Mes_Invalid_Valid_Date =>
            ResourceManager.GetString("Mes_Invalid_Valid_Date", resourceCulture);

        internal static string Mes_Max_Capacity =>
            ResourceManager.GetString("Mes_Max_Capacity", resourceCulture);

        internal static string Mes_Max_Transaction =>
            ResourceManager.GetString("Mes_Max_Transaction", resourceCulture);

        internal static string Mes_Need_Approvel =>
            ResourceManager.GetString("Mes_Need_Approvel", resourceCulture);

        internal static string Mes_Nett_Greater_Than_Gross =>
            ResourceManager.GetString("Mes_Nett_Greater_Than_Gross", resourceCulture);

        internal static string Mes_Nett_Mandatory =>
            ResourceManager.GetString("Mes_Nett_Mandatory", resourceCulture);

        internal static string Mes_No_Allowed_to_be_disabled_condition_found =>
            ResourceManager.GetString("Mes_No_Allowed_to_be_disabled_condition_found", resourceCulture);

        internal static string Mes_No_Token_data_found =>
            ResourceManager.GetString("Mes_No_Token_data_found", resourceCulture);

        internal static string Mes_Not_Found =>
            ResourceManager.GetString("Mes_Not_Found", resourceCulture);

        internal static string Mes_Notice =>
            ResourceManager.GetString("Mes_Notice", resourceCulture);

        internal static string Mes_Notice_Use_Token =>
            ResourceManager.GetString("Mes_Notice_Use_Token", resourceCulture);

        internal static string Mes_Notice_Use_Token_IDSYS =>
            ResourceManager.GetString("Mes_Notice_Use_Token_IDSYS", resourceCulture);

        internal static string Mes_Only_Pack_Commodity =>
            ResourceManager.GetString("Mes_Only_Pack_Commodity", resourceCulture);

        internal static string Mes_Open =>
            ResourceManager.GetString("Mes_Open", resourceCulture);

        internal static string Mes_Over_Tare_For_NX_Transaction =>
            ResourceManager.GetString("Mes_Over_Tare_For_NX_Transaction", resourceCulture);

        internal static string Mes_Pin_Accepted =>
            ResourceManager.GetString("Mes_Pin_Accepted", resourceCulture);

        internal static string Mes_Pin_Rejected =>
            ResourceManager.GetString("Mes_Pin_Rejected", resourceCulture);

        internal static string Mes_Please_Maintain_Web_Camera =>
            ResourceManager.GetString("Mes_Please_Maintain_Web_Camera", resourceCulture);

        internal static string Mes_Qcode_Not_Number =>
            ResourceManager.GetString("Mes_Qcode_Not_Number", resourceCulture);

        internal static string Mes_Record_Copied =>
            ResourceManager.GetString("Mes_Record_Copied", resourceCulture);

        internal static string Mes_Records =>
            ResourceManager.GetString("Mes_Records", resourceCulture);

        internal static string Mes_Records_Copied =>
            ResourceManager.GetString("Mes_Records_Copied", resourceCulture);

        internal static string Mes_Records_In_Block =>
            ResourceManager.GetString("Mes_Records_In_Block", resourceCulture);

        internal static string Mes_Records_In_Contract =>
            ResourceManager.GetString("Mes_Records_In_Contract", resourceCulture);

        internal static string Mes_Records_In_DO =>
            ResourceManager.GetString("Mes_Records_In_DO", resourceCulture);

        internal static string Mes_Records_In_Master =>
            ResourceManager.GetString("Mes_Records_In_Master", resourceCulture);

        internal static string Mes_Records_In_Transaction =>
            ResourceManager.GetString("Mes_Records_In_Transaction", resourceCulture);

        internal static string Mes_Records_In_Transactions =>
            ResourceManager.GetString("Mes_Records_In_Transactions", resourceCulture);

        internal static string Mes_Relation_Copied =>
            ResourceManager.GetString("Mes_Relation_Copied", resourceCulture);

        internal static string Mes_Replace_License_No =>
            ResourceManager.GetString("Mes_Replace_License_No", resourceCulture);

        internal static string Mes_Reset_Password_Success =>
            ResourceManager.GetString("Mes_Reset_Password_Success", resourceCulture);

        internal static string Mes_Return_Transaction_Type_Exist =>
            ResourceManager.GetString("Mes_Return_Transaction_Type_Exist", resourceCulture);

        internal static string Mes_Rows =>
            ResourceManager.GetString("Mes_Rows", resourceCulture);

        internal static string Mes_Rows_To_ZWB =>
            ResourceManager.GetString("Mes_Rows_To_ZWB", resourceCulture);

        internal static string Mes_Send_Allow_Edit =>
            ResourceManager.GetString("Mes_Send_Allow_Edit", resourceCulture);

        internal static string Mes_STO_Found =>
            ResourceManager.GetString("Mes_STO_Found", resourceCulture);

        internal static string Mes_Success =>
            ResourceManager.GetString("Mes_Success", resourceCulture);

        internal static string Mes_Success_Request_Edit_DO =>
            ResourceManager.GetString("Mes_Success_Request_Edit_DO", resourceCulture);

        internal static string Mes_Success_Send_Token =>
            ResourceManager.GetString("Mes_Success_Send_Token", resourceCulture);

        internal static string Mes_Success_Sync =>
            ResourceManager.GetString("Mes_Success_Sync", resourceCulture);

        internal static string Mes_Success_to_Save_Photo =>
            ResourceManager.GetString("Mes_Success_to_Save_Photo", resourceCulture);

        internal static string Mes_Success_With_Spaces =>
            ResourceManager.GetString("Mes_Success_With_Spaces", resourceCulture);

        internal static string Mes_Thank_You =>
            ResourceManager.GetString("Mes_Thank_You", resourceCulture);

        internal static string Mes_To_ZWB =>
            ResourceManager.GetString("Mes_To_ZWB", resourceCulture);

        internal static string Mes_Trans_Detail =>
            ResourceManager.GetString("Mes_Trans_Detail", resourceCulture);

        internal static string Mes_Transaction =>
            ResourceManager.GetString("Mes_Transaction", resourceCulture);

        internal static string Mes_Transaction_Incoterm_Exist =>
            ResourceManager.GetString("Mes_Transaction_Incoterm_Exist", resourceCulture);

        internal static string Mes_Transporter_Code_Change =>
            ResourceManager.GetString("Mes_Transporter_Code_Change", resourceCulture);

        internal static string Mes_Transporter_Copied =>
            ResourceManager.GetString("Mes_Transporter_Copied", resourceCulture);

        internal static string Mes_Truck_Tare_Bigger_Than =>
            ResourceManager.GetString("Mes_Truck_Tare_Bigger_Than", resourceCulture);

        internal static string Mes_Type_Copied =>
            ResourceManager.GetString("Mes_Type_Copied", resourceCulture);

        internal static string Mes_Updated =>
            ResourceManager.GetString("Mes_Updated", resourceCulture);

        internal static string Mes_Use_Token =>
            ResourceManager.GetString("Mes_Use_Token", resourceCulture);

        internal static string Mes_Use_Token_IDSYS =>
            ResourceManager.GetString("Mes_Use_Token_IDSYS", resourceCulture);

        internal static string Mes_Vessel_Please_Merge_All_Transaction =>
            ResourceManager.GetString("Mes_Vessel_Please_Merge_All_Transaction", resourceCulture);

        internal static string Mes_View_Transaction_Type =>
            ResourceManager.GetString("Mes_View_Transaction_Type", resourceCulture);

        internal static string Mes_Wait_For_Pin =>
            ResourceManager.GetString("Mes_Wait_For_Pin", resourceCulture);

        internal static string Mes_Warning =>
            ResourceManager.GetString("Mes_Warning", resourceCulture);

        internal static string Mes_Warning_Adopt =>
            ResourceManager.GetString("Mes_Warning_Adopt", resourceCulture);

        internal static string Mes_Warning_Adopt_IDSYS =>
            ResourceManager.GetString("Mes_Warning_Adopt_IDSYS", resourceCulture);

        internal static string Mes_Warning_BC_Date =>
            ResourceManager.GetString("Mes_Warning_BC_Date", resourceCulture);

        internal static string Mes_Warning_Caps =>
            ResourceManager.GetString("Mes_Warning_Caps", resourceCulture);

        internal static string Mes_Warning_Commodity_Not_Found =>
            ResourceManager.GetString("Mes_Warning_Commodity_Not_Found", resourceCulture);

        internal static string Mes_Warning_Commodity_SAP =>
            ResourceManager.GetString("Mes_Warning_Commodity_SAP", resourceCulture);

        internal static string Mes_Warning_Commodity_SAP_IDSYS =>
            ResourceManager.GetString("Mes_Warning_Commodity_SAP_IDSYS", resourceCulture);

        internal static string Mes_Warning_Deducted =>
            ResourceManager.GetString("Mes_Warning_Deducted", resourceCulture);

        internal static string Mes_Warning_Deleted_Commodity =>
            ResourceManager.GetString("Mes_Warning_Deleted_Commodity", resourceCulture);

        internal static string Mes_Warning_Different_Transporter_Code =>
            ResourceManager.GetString("Mes_Warning_Different_Transporter_Code", resourceCulture);

        internal static string Mes_Warning_DO_Already_Adopt =>
            ResourceManager.GetString("Mes_Warning_DO_Already_Adopt", resourceCulture);

        internal static string Mes_Warning_DO_Already_Adopt_IDSYS =>
            ResourceManager.GetString("Mes_Warning_DO_Already_Adopt_IDSYS", resourceCulture);

        internal static string Mes_Warning_DO_Exist =>
            ResourceManager.GetString("Mes_Warning_DO_Exist", resourceCulture);

        internal static string Mes_Warning_DO_Timbun =>
            ResourceManager.GetString("Mes_Warning_DO_Timbun", resourceCulture);

        internal static string Mes_Warning_Error_Cannot_Add_Vessel_Map =>
            ResourceManager.GetString("Mes_Warning_Error_Cannot_Add_Vessel_Map", resourceCulture);

        internal static string Mes_Warning_Error_Cannot_Delete_Vessel_Map =>
            ResourceManager.GetString("Mes_Warning_Error_Cannot_Delete_Vessel_Map", resourceCulture);

        internal static string Mes_Warning_Error_Please_Check_Remark =>
            ResourceManager.GetString("Mes_Warning_Error_Please_Check_Remark", resourceCulture);

        internal static string Mes_Warning_Estate_SAP =>
            ResourceManager.GetString("Mes_Warning_Estate_SAP", resourceCulture);

        internal static string Mes_Warning_Estate_SAP_IDSYS =>
            ResourceManager.GetString("Mes_Warning_Estate_SAP_IDSYS", resourceCulture);

        internal static string Mes_Warning_Fill_Company =>
            ResourceManager.GetString("Mes_Warning_Fill_Company", resourceCulture);

        internal static string Mes_Warning_Fill_Estate =>
            ResourceManager.GetString("Mes_Warning_Fill_Estate", resourceCulture);

        internal static string Mes_Warning_Fill_Item =>
            ResourceManager.GetString("Mes_Warning_Fill_Item", resourceCulture);

        internal static string Mes_Warning_Fill_Itemv2 =>
            ResourceManager.GetString("Mes_Warning_Fill_Itemv2", resourceCulture);

        internal static string Mes_Warning_Fill_Quantity_Manual =>
            ResourceManager.GetString("Mes_Warning_Fill_Quantity_Manual", resourceCulture);

        internal static string Mes_Warning_Fill_STO =>
            ResourceManager.GetString("Mes_Warning_Fill_STO", resourceCulture);

        internal static string Mes_Warning_Fill_STO_No =>
            ResourceManager.GetString("Mes_Warning_Fill_STO_No", resourceCulture);

        internal static string Mes_Warning_Fill_Transporter =>
            ResourceManager.GetString("Mes_Warning_Fill_Transporter", resourceCulture);

        internal static string Mes_Warning_GRCust_Exist =>
            ResourceManager.GetString("Mes_Warning_GRCust_Exist", resourceCulture);

        internal static string Mes_Warning_Incoterm =>
            ResourceManager.GetString("Mes_Warning_Incoterm", resourceCulture);

        internal static string Mes_Warning_Invalid_PIN =>
            ResourceManager.GetString("Mes_Warning_Invalid_PIN", resourceCulture);

        internal static string Mes_Warning_Not_Temp_DO =>
            ResourceManager.GetString("Mes_Warning_Not_Temp_DO", resourceCulture);

        internal static string Mes_Warning_Not_Vessel_DO =>
            ResourceManager.GetString("Mes_Warning_Not_Vessel_DO", resourceCulture);

        internal static string Mes_Warning_Plasma =>
            ResourceManager.GetString("Mes_Warning_Plasma", resourceCulture);

        internal static string Mes_Warning_PO_Exist =>
            ResourceManager.GetString("Mes_Warning_PO_Exist", resourceCulture);

        internal static string Mes_Warning_POItem_Exist =>
            ResourceManager.GetString("Mes_Warning_POItem_Exist", resourceCulture);

        internal static string Mes_Warning_Protect_Excel =>
            ResourceManager.GetString("Mes_Warning_Protect_Excel", resourceCulture);

        internal static string Mes_Warning_Relation_SAP =>
            ResourceManager.GetString("Mes_Warning_Relation_SAP", resourceCulture);

        internal static string Mes_Warning_Relation_SAP_IDSYS =>
            ResourceManager.GetString("Mes_Warning_Relation_SAP_IDSYS", resourceCulture);

        internal static string Mes_Warning_Reset_Token =>
            ResourceManager.GetString("Mes_Warning_Reset_Token", resourceCulture);

        internal static string Mes_Warning_Reset_Token_2 =>
            ResourceManager.GetString("Mes_Warning_Reset_Token_2", resourceCulture);

        internal static string Mes_Warning_SAP_Destination =>
            ResourceManager.GetString("Mes_Warning_SAP_Destination", resourceCulture);

        internal static string Mes_Warning_SAP_Destination_IDSYS =>
            ResourceManager.GetString("Mes_Warning_SAP_Destination_IDSYS", resourceCulture);

        internal static string Mes_Warning_Save_Closed_DO =>
            ResourceManager.GetString("Mes_Warning_Save_Closed_DO", resourceCulture);

        internal static string Mes_Warning_Small_Qty =>
            ResourceManager.GetString("Mes_Warning_Small_Qty", resourceCulture);

        internal static string Mes_Warning_SO_Exist =>
            ResourceManager.GetString("Mes_Warning_SO_Exist", resourceCulture);

        internal static string Mes_Warning_SOItem_Exist =>
            ResourceManager.GetString("Mes_Warning_SOItem_Exist", resourceCulture);

        internal static string Mes_Warning_SPB_Exist =>
            ResourceManager.GetString("Mes_Warning_SPB_Exist", resourceCulture);

        internal static string Mes_Warning_Start_Time =>
            ResourceManager.GetString("Mes_Warning_Start_Time", resourceCulture);

        internal static string Mes_Warning_STO_Exist =>
            ResourceManager.GetString("Mes_Warning_STO_Exist", resourceCulture);

        internal static string Mes_Warning_STOItem_Exist =>
            ResourceManager.GetString("Mes_Warning_STOItem_Exist", resourceCulture);

        internal static string Mes_Warning_Token_Changed =>
            ResourceManager.GetString("Mes_Warning_Token_Changed", resourceCulture);

        internal static string Mes_Warning_Tolerance =>
            ResourceManager.GetString("Mes_Warning_Tolerance", resourceCulture);

        internal static string Mes_Warning_Tolerance_All =>
            ResourceManager.GetString("Mes_Warning_Tolerance_All", resourceCulture);

        internal static string Mes_Warning_Tolerance_Range =>
            ResourceManager.GetString("Mes_Warning_Tolerance_Range", resourceCulture);

        internal static string Mes_Warning_Tolerance_Range_2 =>
            ResourceManager.GetString("Mes_Warning_Tolerance_Range_2", resourceCulture);

        internal static string Mes_Warning_Transporter =>
            ResourceManager.GetString("Mes_Warning_Transporter", resourceCulture);

        internal static string Mes_Warning_Transporter_SAP =>
            ResourceManager.GetString("Mes_Warning_Transporter_SAP", resourceCulture);

        internal static string Mes_Warning_Transporter_SAP_IDSYS =>
            ResourceManager.GetString("Mes_Warning_Transporter_SAP_IDSYS", resourceCulture);

        internal static string Mes_Warning_Upload_Interval =>
            ResourceManager.GetString("Mes_Warning_Upload_Interval", resourceCulture);

        internal static string Mes_Warning_With_Spaces =>
            ResourceManager.GetString("Mes_Warning_With_Spaces", resourceCulture);

        internal static string Mes_WB_Code_Empty =>
            ResourceManager.GetString("Mes_WB_Code_Empty", resourceCulture);

        internal static string Mnu_Change_Position =>
            ResourceManager.GetString("Mnu_Change_Position", resourceCulture);

        internal static string Msg_Continue =>
            ResourceManager.GetString("Msg_Continue", resourceCulture);

        internal static string Msg_Replace_Warning =>
            ResourceManager.GetString("Msg_Replace_Warning", resourceCulture);

        internal static string No_DataIDSYS =>
            ResourceManager.GetString("No_DataIDSYS", resourceCulture);

        internal static string RangeDeduction_001 =>
            ResourceManager.GetString("RangeDeduction_001", resourceCulture);

        internal static string RangeDeduction_002 =>
            ResourceManager.GetString("RangeDeduction_002", resourceCulture);

        internal static string RangeDeduction_003 =>
            ResourceManager.GetString("RangeDeduction_003", resourceCulture);

        internal static string RangeDeduction_004 =>
            ResourceManager.GetString("RangeDeduction_004", resourceCulture);

        internal static string RangeDeduction_005 =>
            ResourceManager.GetString("RangeDeduction_005", resourceCulture);

        internal static string RangeDeduction_006 =>
            ResourceManager.GetString("RangeDeduction_006", resourceCulture);

        internal static string Rdb_Bulk =>
            ResourceManager.GetString("Rdb_Bulk", resourceCulture);

        internal static string Rdb_Close =>
            ResourceManager.GetString("Rdb_Close", resourceCulture);

        internal static string Rdb_Copra =>
            ResourceManager.GetString("Rdb_Copra", resourceCulture);

        internal static string Rdb_GR_Only =>
            ResourceManager.GetString("Rdb_GR_Only", resourceCulture);

        internal static string Rdb_Group_Estate =>
            ResourceManager.GetString("Rdb_Group_Estate", resourceCulture);

        internal static string Rdb_Langsir =>
            ResourceManager.GetString("Rdb_Langsir", resourceCulture);

        internal static string Rdb_Liquid =>
            ResourceManager.GetString("Rdb_Liquid", resourceCulture);

        internal static string Rdb_NKB =>
            ResourceManager.GetString("Rdb_NKB", resourceCulture);

        internal static string Rdb_None =>
            ResourceManager.GetString("Rdb_None", resourceCulture);

        internal static string Rdb_Not_Check =>
            ResourceManager.GetString("Rdb_Not_Check", resourceCulture);

        internal static string Rdb_Open =>
            ResourceManager.GetString("Rdb_Open", resourceCulture);

        internal static string Rdb_Pack =>
            ResourceManager.GetString("Rdb_Pack", resourceCulture);

        internal static string Rdb_Ramp =>
            ResourceManager.GetString("Rdb_Ramp", resourceCulture);

        internal static string Rdb_Solid =>
            ResourceManager.GetString("Rdb_Solid", resourceCulture);

        internal static string Rdb_Sugar =>
            ResourceManager.GetString("Rdb_Sugar", resourceCulture);

        internal static string Rdb_Titip_Timbun =>
            ResourceManager.GetString("Rdb_Titip_Timbun", resourceCulture);

        internal static string Rdb_Tolerance_Kg =>
            ResourceManager.GetString("Rdb_Tolerance_Kg", resourceCulture);

        internal static string Rdb_Tolerance_Percent =>
            ResourceManager.GetString("Rdb_Tolerance_Percent", resourceCulture);

        internal static string Rdb_Transfer_Posting =>
            ResourceManager.GetString("Rdb_Transfer_Posting", resourceCulture);

        internal static string RegisDOEntry_001 =>
            ResourceManager.GetString("RegisDOEntry_001", resourceCulture);

        internal static string RegisDOEntry_002 =>
            ResourceManager.GetString("RegisDOEntry_002", resourceCulture);

        internal static string RegisDOEntry_003 =>
            ResourceManager.GetString("RegisDOEntry_003", resourceCulture);

        internal static string RegisDOEntry_004 =>
            ResourceManager.GetString("RegisDOEntry_004", resourceCulture);

        internal static string RegisDOEntry_005 =>
            ResourceManager.GetString("RegisDOEntry_005", resourceCulture);

        internal static string RegisGatepassEntry_001 =>
            ResourceManager.GetString("RegisGatepassEntry_001", resourceCulture);

        internal static string RegisGatepassEntry_002 =>
            ResourceManager.GetString("RegisGatepassEntry_002", resourceCulture);

        internal static string RegisGatepassEntry_003 =>
            ResourceManager.GetString("RegisGatepassEntry_003", resourceCulture);

        internal static string RegisGatepassEntry_004 =>
            ResourceManager.GetString("RegisGatepassEntry_004", resourceCulture);

        internal static string RegisGatepassEntry_005 =>
            ResourceManager.GetString("RegisGatepassEntry_005", resourceCulture);

        internal static string RegisGatepassEntry_006 =>
            ResourceManager.GetString("RegisGatepassEntry_006", resourceCulture);

        internal static string RegisGatepassEntry_007 =>
            ResourceManager.GetString("RegisGatepassEntry_007", resourceCulture);

        internal static string RegisGatepassEntry_008 =>
            ResourceManager.GetString("RegisGatepassEntry_008", resourceCulture);

        internal static string RegisGatepassEntry_009 =>
            ResourceManager.GetString("RegisGatepassEntry_009", resourceCulture);

        internal static string RegisGatepassEntry_010 =>
            ResourceManager.GetString("RegisGatepassEntry_010", resourceCulture);

        internal static string RegisGatepassEntry_011 =>
            ResourceManager.GetString("RegisGatepassEntry_011", resourceCulture);

        internal static string RegisGatepassEntry_012 =>
            ResourceManager.GetString("RegisGatepassEntry_012", resourceCulture);

        internal static string RegisGatepassEntry_013 =>
            ResourceManager.GetString("RegisGatepassEntry_013", resourceCulture);

        internal static string RegisGatepassEntry_014 =>
            ResourceManager.GetString("RegisGatepassEntry_014", resourceCulture);

        internal static string RegisGatepassEntry_015 =>
            ResourceManager.GetString("RegisGatepassEntry_015", resourceCulture);

        internal static string RegisGatepassEntry_016 =>
            ResourceManager.GetString("RegisGatepassEntry_016", resourceCulture);

        internal static string RegisGatepassEntry_017 =>
            ResourceManager.GetString("RegisGatepassEntry_017", resourceCulture);

        internal static string RegisGatepassEntry_018 =>
            ResourceManager.GetString("RegisGatepassEntry_018", resourceCulture);

        internal static string RegisGatepassEntry_019 =>
            ResourceManager.GetString("RegisGatepassEntry_019", resourceCulture);

        internal static string RegisGatepassEntry_020 =>
            ResourceManager.GetString("RegisGatepassEntry_020", resourceCulture);

        internal static string RegisGatepassEntry_021 =>
            ResourceManager.GetString("RegisGatepassEntry_021", resourceCulture);

        internal static string RegisGatepassEntry_022 =>
            ResourceManager.GetString("RegisGatepassEntry_022", resourceCulture);

        internal static string RegisGatepassEntry_023 =>
            ResourceManager.GetString("RegisGatepassEntry_023", resourceCulture);

        internal static string RegisGatepassEntry_024 =>
            ResourceManager.GetString("RegisGatepassEntry_024", resourceCulture);

        internal static string RegisGatepassEntry_025 =>
            ResourceManager.GetString("RegisGatepassEntry_025", resourceCulture);

        internal static string RegisGatepassEntry_026 =>
            ResourceManager.GetString("RegisGatepassEntry_026", resourceCulture);

        internal static string RegisGatepassEntry_027 =>
            ResourceManager.GetString("RegisGatepassEntry_027", resourceCulture);

        internal static string RegisGatepassEntry_028 =>
            ResourceManager.GetString("RegisGatepassEntry_028", resourceCulture);

        internal static string RegisGatepassEntry_029 =>
            ResourceManager.GetString("RegisGatepassEntry_029", resourceCulture);

        internal static string RegisGatepassEntry_030 =>
            ResourceManager.GetString("RegisGatepassEntry_030", resourceCulture);

        internal static string RegisGatepassEntry_031 =>
            ResourceManager.GetString("RegisGatepassEntry_031", resourceCulture);

        internal static string RegisGatepassEntry_032 =>
            ResourceManager.GetString("RegisGatepassEntry_032", resourceCulture);

        internal static string RegisGatepassEntry_033 =>
            ResourceManager.GetString("RegisGatepassEntry_033", resourceCulture);

        internal static string RegisGatepassMess_001 =>
            ResourceManager.GetString("RegisGatepassMess_001", resourceCulture);

        internal static string RegisGatepassMess_002 =>
            ResourceManager.GetString("RegisGatepassMess_002", resourceCulture);

        internal static string RegisGatepassMess_003 =>
            ResourceManager.GetString("RegisGatepassMess_003", resourceCulture);

        internal static string RegisGatepassMess_004 =>
            ResourceManager.GetString("RegisGatepassMess_004", resourceCulture);

        internal static string RegisGatepassMess_005 =>
            ResourceManager.GetString("RegisGatepassMess_005", resourceCulture);

        internal static string RegisGatepassMess_006 =>
            ResourceManager.GetString("RegisGatepassMess_006", resourceCulture);

        internal static string RegisGatepassMess_007 =>
            ResourceManager.GetString("RegisGatepassMess_007", resourceCulture);

        internal static string RegisGatepassMess_008 =>
            ResourceManager.GetString("RegisGatepassMess_008", resourceCulture);

        internal static string RegisGatepassMess_009 =>
            ResourceManager.GetString("RegisGatepassMess_009", resourceCulture);

        internal static string RegisGatepassMess_010 =>
            ResourceManager.GetString("RegisGatepassMess_010", resourceCulture);

        internal static string RegisGatepassMess_011 =>
            ResourceManager.GetString("RegisGatepassMess_011", resourceCulture);

        internal static string RegisGatepassMess_012 =>
            ResourceManager.GetString("RegisGatepassMess_012", resourceCulture);

        internal static string RegisGatepassMess_013 =>
            ResourceManager.GetString("RegisGatepassMess_013", resourceCulture);

        internal static string RegisGatepassMess_014 =>
            ResourceManager.GetString("RegisGatepassMess_014", resourceCulture);

        internal static string RegisGatepassMess_015 =>
            ResourceManager.GetString("RegisGatepassMess_015", resourceCulture);

        internal static string RegisGatepassMess_016 =>
            ResourceManager.GetString("RegisGatepassMess_016", resourceCulture);

        internal static string RegisGatepassMess_017 =>
            ResourceManager.GetString("RegisGatepassMess_017", resourceCulture);

        internal static string RegisGatepassMess_018 =>
            ResourceManager.GetString("RegisGatepassMess_018", resourceCulture);

        internal static string RegisGatepassMess_020 =>
            ResourceManager.GetString("RegisGatepassMess_020", resourceCulture);

        internal static string RegisGatepassMess_021 =>
            ResourceManager.GetString("RegisGatepassMess_021", resourceCulture);

        internal static string RegisGatepassMess_021_IDSYS =>
            ResourceManager.GetString("RegisGatepassMess_021_IDSYS", resourceCulture);

        internal static string RegisGatepassMess_022 =>
            ResourceManager.GetString("RegisGatepassMess_022", resourceCulture);

        internal static string RegisGatepassMess_023 =>
            ResourceManager.GetString("RegisGatepassMess_023", resourceCulture);

        internal static string RegisGatepassMess_024 =>
            ResourceManager.GetString("RegisGatepassMess_024", resourceCulture);

        internal static string RegisGatepassMess_025 =>
            ResourceManager.GetString("RegisGatepassMess_025", resourceCulture);

        internal static string RegisGatepassMess_026 =>
            ResourceManager.GetString("RegisGatepassMess_026", resourceCulture);

        internal static string RegisGatepassMess_027 =>
            ResourceManager.GetString("RegisGatepassMess_027", resourceCulture);

        internal static string RegisGatepassMess_028 =>
            ResourceManager.GetString("RegisGatepassMess_028", resourceCulture);

        internal static string RegisGatepassMess_029 =>
            ResourceManager.GetString("RegisGatepassMess_029", resourceCulture);

        internal static string RegisGatepassMess_030 =>
            ResourceManager.GetString("RegisGatepassMess_030", resourceCulture);

        internal static string RegisGatepassMess_031 =>
            ResourceManager.GetString("RegisGatepassMess_031", resourceCulture);

        internal static string RegisGatepassMess_032 =>
            ResourceManager.GetString("RegisGatepassMess_032", resourceCulture);

        internal static string RegisGatepassMess_033 =>
            ResourceManager.GetString("RegisGatepassMess_033", resourceCulture);

        internal static string RegisGatepassMess_034 =>
            ResourceManager.GetString("RegisGatepassMess_034", resourceCulture);

        internal static string RegisGatepassMess_035 =>
            ResourceManager.GetString("RegisGatepassMess_035", resourceCulture);

        internal static string RegisGatepassMess_036 =>
            ResourceManager.GetString("RegisGatepassMess_036", resourceCulture);

        internal static string RegisGatepassMess_037 =>
            ResourceManager.GetString("RegisGatepassMess_037", resourceCulture);

        internal static string RegisGatepassMess_038 =>
            ResourceManager.GetString("RegisGatepassMess_038", resourceCulture);

        internal static string RegisGatepassMess_039 =>
            ResourceManager.GetString("RegisGatepassMess_039", resourceCulture);

        internal static string RegisGatepassMess_040 =>
            ResourceManager.GetString("RegisGatepassMess_040", resourceCulture);

        internal static string RegisGatepassMess_041 =>
            ResourceManager.GetString("RegisGatepassMess_041", resourceCulture);

        internal static string RegisGatepassMess_042 =>
            ResourceManager.GetString("RegisGatepassMess_042", resourceCulture);

        internal static string RegisGatepassMess_043 =>
            ResourceManager.GetString("RegisGatepassMess_043", resourceCulture);

        internal static string RegisGatepassMess_044 =>
            ResourceManager.GetString("RegisGatepassMess_044", resourceCulture);

        internal static string RegisGatepassMess_045 =>
            ResourceManager.GetString("RegisGatepassMess_045", resourceCulture);

        internal static string RegisGatepassMess_046 =>
            ResourceManager.GetString("RegisGatepassMess_046", resourceCulture);

        internal static string RegisGatepassMess_047 =>
            ResourceManager.GetString("RegisGatepassMess_047", resourceCulture);

        internal static string RegisGatepassMess_048 =>
            ResourceManager.GetString("RegisGatepassMess_048", resourceCulture);

        internal static string RegisGatepassMess_049 =>
            ResourceManager.GetString("RegisGatepassMess_049", resourceCulture);

        internal static string RegisGatepassMess_050 =>
            ResourceManager.GetString("RegisGatepassMess_050", resourceCulture);

        internal static string RegisGatepassMess_051 =>
            ResourceManager.GetString("RegisGatepassMess_051", resourceCulture);

        internal static string RegisGatepassMess_051_IDSYS =>
            ResourceManager.GetString("RegisGatepassMess_051_IDSYS", resourceCulture);

        internal static string RegisGatepassMess_052 =>
            ResourceManager.GetString("RegisGatepassMess_052", resourceCulture);

        internal static string RegisGatepassMess_053 =>
            ResourceManager.GetString("RegisGatepassMess_053", resourceCulture);

        internal static string RegisGatepassMess_054 =>
            ResourceManager.GetString("RegisGatepassMess_054", resourceCulture);

        internal static string RegisGatepassMess_055 =>
            ResourceManager.GetString("RegisGatepassMess_055", resourceCulture);

        internal static string RegisGatepassMess_056 =>
            ResourceManager.GetString("RegisGatepassMess_056", resourceCulture);

        internal static string RegisGatepassMess_057 =>
            ResourceManager.GetString("RegisGatepassMess_057", resourceCulture);

        internal static string RegisGatepassMess_058 =>
            ResourceManager.GetString("RegisGatepassMess_058", resourceCulture);

        internal static string RegisGatepassMess_059 =>
            ResourceManager.GetString("RegisGatepassMess_059", resourceCulture);

        internal static string RegisGatepassMess_060 =>
            ResourceManager.GetString("RegisGatepassMess_060", resourceCulture);

        internal static string RegisGatepassMess_061 =>
            ResourceManager.GetString("RegisGatepassMess_061", resourceCulture);

        internal static string RegisGatepassMess_062 =>
            ResourceManager.GetString("RegisGatepassMess_062", resourceCulture);

        internal static string RegisGatepassMess_063 =>
            ResourceManager.GetString("RegisGatepassMess_063", resourceCulture);

        internal static string RegisGatepassMess_064 =>
            ResourceManager.GetString("RegisGatepassMess_064", resourceCulture);

        internal static string RegisGatepassMess_065 =>
            ResourceManager.GetString("RegisGatepassMess_065", resourceCulture);

        internal static string RegisGatepassMess_066 =>
            ResourceManager.GetString("RegisGatepassMess_066", resourceCulture);

        internal static string RegisGatepassMess_067 =>
            ResourceManager.GetString("RegisGatepassMess_067", resourceCulture);

        internal static string RegisGatepassMess_068 =>
            ResourceManager.GetString("RegisGatepassMess_068", resourceCulture);

        internal static string RegisGatepassMess_069 =>
            ResourceManager.GetString("RegisGatepassMess_069", resourceCulture);

        internal static string RegisGatepassMess_070 =>
            ResourceManager.GetString("RegisGatepassMess_070", resourceCulture);

        internal static string RegisGatepassMess_071 =>
            ResourceManager.GetString("RegisGatepassMess_071", resourceCulture);

        internal static string RegisGatepassMess_072 =>
            ResourceManager.GetString("RegisGatepassMess_072", resourceCulture);

        internal static string RegisGatepassMess_073 =>
            ResourceManager.GetString("RegisGatepassMess_073", resourceCulture);

        internal static string RegisGatepassMess_074 =>
            ResourceManager.GetString("RegisGatepassMess_074", resourceCulture);

        internal static string RegisGatepassMess_075 =>
            ResourceManager.GetString("RegisGatepassMess_075", resourceCulture);

        internal static string RegisGatepassMess_076 =>
            ResourceManager.GetString("RegisGatepassMess_076", resourceCulture);

        internal static string Rep01_001 =>
            ResourceManager.GetString("Rep01_001", resourceCulture);

        internal static string Rep01_002 =>
            ResourceManager.GetString("Rep01_002", resourceCulture);

        internal static string Rep01_003 =>
            ResourceManager.GetString("Rep01_003", resourceCulture);

        internal static string Rep01_004 =>
            ResourceManager.GetString("Rep01_004", resourceCulture);

        internal static string Rep01_005 =>
            ResourceManager.GetString("Rep01_005", resourceCulture);

        internal static string Rep01_006 =>
            ResourceManager.GetString("Rep01_006", resourceCulture);

        internal static string Rep01_007 =>
            ResourceManager.GetString("Rep01_007", resourceCulture);

        internal static string Rep01_008 =>
            ResourceManager.GetString("Rep01_008", resourceCulture);

        internal static string Rep01_009 =>
            ResourceManager.GetString("Rep01_009", resourceCulture);

        internal static string Rep01_010 =>
            ResourceManager.GetString("Rep01_010", resourceCulture);

        internal static string Rep01_011 =>
            ResourceManager.GetString("Rep01_011", resourceCulture);

        internal static string Rep01_012 =>
            ResourceManager.GetString("Rep01_012", resourceCulture);

        internal static string Rep01_013 =>
            ResourceManager.GetString("Rep01_013", resourceCulture);

        internal static string Rep01_014 =>
            ResourceManager.GetString("Rep01_014", resourceCulture);

        internal static string Rep01_015 =>
            ResourceManager.GetString("Rep01_015", resourceCulture);

        internal static string Rep01_016 =>
            ResourceManager.GetString("Rep01_016", resourceCulture);

        internal static string Rep01_017 =>
            ResourceManager.GetString("Rep01_017", resourceCulture);

        internal static string Rep01_018 =>
            ResourceManager.GetString("Rep01_018", resourceCulture);

        internal static string Rep01_019 =>
            ResourceManager.GetString("Rep01_019", resourceCulture);

        internal static string Rep01_020 =>
            ResourceManager.GetString("Rep01_020", resourceCulture);

        internal static string Rep01_021 =>
            ResourceManager.GetString("Rep01_021", resourceCulture);

        internal static string Rep01_022 =>
            ResourceManager.GetString("Rep01_022", resourceCulture);

        internal static string Rep01_023 =>
            ResourceManager.GetString("Rep01_023", resourceCulture);

        internal static string Rep01_024 =>
            ResourceManager.GetString("Rep01_024", resourceCulture);

        internal static string Rep01_025 =>
            ResourceManager.GetString("Rep01_025", resourceCulture);

        internal static string Rep01_026 =>
            ResourceManager.GetString("Rep01_026", resourceCulture);

        internal static string Rep01_027 =>
            ResourceManager.GetString("Rep01_027", resourceCulture);

        internal static string Rep01_028 =>
            ResourceManager.GetString("Rep01_028", resourceCulture);

        internal static string Rep01_029 =>
            ResourceManager.GetString("Rep01_029", resourceCulture);

        internal static string Rep01_030 =>
            ResourceManager.GetString("Rep01_030", resourceCulture);

        internal static string Rep01_031 =>
            ResourceManager.GetString("Rep01_031", resourceCulture);

        internal static string Rep01_032 =>
            ResourceManager.GetString("Rep01_032", resourceCulture);

        internal static string Rep01_033 =>
            ResourceManager.GetString("Rep01_033", resourceCulture);

        internal static string Rep01_034 =>
            ResourceManager.GetString("Rep01_034", resourceCulture);

        internal static string Rep01_035 =>
            ResourceManager.GetString("Rep01_035", resourceCulture);

        internal static string Rep01_036 =>
            ResourceManager.GetString("Rep01_036", resourceCulture);

        internal static string Rep01_037 =>
            ResourceManager.GetString("Rep01_037", resourceCulture);

        internal static string Rep01_038 =>
            ResourceManager.GetString("Rep01_038", resourceCulture);

        internal static string Rep01_039 =>
            ResourceManager.GetString("Rep01_039", resourceCulture);

        internal static string Rep01_040 =>
            ResourceManager.GetString("Rep01_040", resourceCulture);

        internal static string Rep01_041 =>
            ResourceManager.GetString("Rep01_041", resourceCulture);

        internal static string Rep01_042 =>
            ResourceManager.GetString("Rep01_042", resourceCulture);

        internal static string Rep01_043 =>
            ResourceManager.GetString("Rep01_043", resourceCulture);

        internal static string Rep01_044 =>
            ResourceManager.GetString("Rep01_044", resourceCulture);

        internal static string Report02_001 =>
            ResourceManager.GetString("Report02_001", resourceCulture);

        internal static string Report02_002 =>
            ResourceManager.GetString("Report02_002", resourceCulture);

        internal static string Report02_003 =>
            ResourceManager.GetString("Report02_003", resourceCulture);

        internal static string Report02_004 =>
            ResourceManager.GetString("Report02_004", resourceCulture);

        internal static string Report02_005 =>
            ResourceManager.GetString("Report02_005", resourceCulture);

        internal static string Report02_006 =>
            ResourceManager.GetString("Report02_006", resourceCulture);

        internal static string Report02_007 =>
            ResourceManager.GetString("Report02_007", resourceCulture);

        internal static string Report02_008 =>
            ResourceManager.GetString("Report02_008", resourceCulture);

        internal static string Report02_009 =>
            ResourceManager.GetString("Report02_009", resourceCulture);

        internal static string Report02_010 =>
            ResourceManager.GetString("Report02_010", resourceCulture);

        internal static string Report02_011 =>
            ResourceManager.GetString("Report02_011", resourceCulture);

        internal static string Report03_001 =>
            ResourceManager.GetString("Report03_001", resourceCulture);

        internal static string Report03_002 =>
            ResourceManager.GetString("Report03_002", resourceCulture);

        internal static string Report03_003 =>
            ResourceManager.GetString("Report03_003", resourceCulture);

        internal static string Report03_004 =>
            ResourceManager.GetString("Report03_004", resourceCulture);

        internal static string Report03_005 =>
            ResourceManager.GetString("Report03_005", resourceCulture);

        internal static string Report03_006 =>
            ResourceManager.GetString("Report03_006", resourceCulture);

        internal static string Report03_007 =>
            ResourceManager.GetString("Report03_007", resourceCulture);

        internal static string Report03_008 =>
            ResourceManager.GetString("Report03_008", resourceCulture);

        internal static string Report04_001 =>
            ResourceManager.GetString("Report04_001", resourceCulture);

        internal static string Report04_002 =>
            ResourceManager.GetString("Report04_002", resourceCulture);

        internal static string Report04_003 =>
            ResourceManager.GetString("Report04_003", resourceCulture);

        internal static string Report04_004 =>
            ResourceManager.GetString("Report04_004", resourceCulture);

        internal static string Report04_005 =>
            ResourceManager.GetString("Report04_005", resourceCulture);

        internal static string Report04_006 =>
            ResourceManager.GetString("Report04_006", resourceCulture);

        internal static string Report04_007 =>
            ResourceManager.GetString("Report04_007", resourceCulture);

        internal static string Report04_008 =>
            ResourceManager.GetString("Report04_008", resourceCulture);

        internal static string Report05_001 =>
            ResourceManager.GetString("Report05_001", resourceCulture);

        internal static string Report05_002 =>
            ResourceManager.GetString("Report05_002", resourceCulture);

        internal static string Report05_003 =>
            ResourceManager.GetString("Report05_003", resourceCulture);

        internal static string Report05_004 =>
            ResourceManager.GetString("Report05_004", resourceCulture);

        internal static string Report05_005 =>
            ResourceManager.GetString("Report05_005", resourceCulture);

        internal static string Report05_006 =>
            ResourceManager.GetString("Report05_006", resourceCulture);

        internal static string Report05_007 =>
            ResourceManager.GetString("Report05_007", resourceCulture);

        internal static string Report05_008 =>
            ResourceManager.GetString("Report05_008", resourceCulture);

        internal static string Report05_009 =>
            ResourceManager.GetString("Report05_009", resourceCulture);

        internal static string Report05_010 =>
            ResourceManager.GetString("Report05_010", resourceCulture);

        internal static string Report05_011 =>
            ResourceManager.GetString("Report05_011", resourceCulture);

        internal static string Report05_012 =>
            ResourceManager.GetString("Report05_012", resourceCulture);

        internal static string Report05_013 =>
            ResourceManager.GetString("Report05_013", resourceCulture);

        internal static string Report05_014 =>
            ResourceManager.GetString("Report05_014", resourceCulture);

        internal static string Report05_015 =>
            ResourceManager.GetString("Report05_015", resourceCulture);

        internal static string Report05_016 =>
            ResourceManager.GetString("Report05_016", resourceCulture);

        internal static string Report05_017 =>
            ResourceManager.GetString("Report05_017", resourceCulture);

        internal static string Report05_018 =>
            ResourceManager.GetString("Report05_018", resourceCulture);

        internal static string Report05_019 =>
            ResourceManager.GetString("Report05_019", resourceCulture);

        internal static string Report05_020 =>
            ResourceManager.GetString("Report05_020", resourceCulture);

        internal static string Report05_021 =>
            ResourceManager.GetString("Report05_021", resourceCulture);

        internal static string Report05_022 =>
            ResourceManager.GetString("Report05_022", resourceCulture);

        internal static string Report05_023 =>
            ResourceManager.GetString("Report05_023", resourceCulture);

        internal static string Report05_024 =>
            ResourceManager.GetString("Report05_024", resourceCulture);

        internal static string Report05_025 =>
            ResourceManager.GetString("Report05_025", resourceCulture);

        internal static string Report05_026 =>
            ResourceManager.GetString("Report05_026", resourceCulture);

        internal static string Report05_027 =>
            ResourceManager.GetString("Report05_027", resourceCulture);

        internal static string Report05_028 =>
            ResourceManager.GetString("Report05_028", resourceCulture);

        internal static string Report05_029 =>
            ResourceManager.GetString("Report05_029", resourceCulture);

        internal static string Report05_030 =>
            ResourceManager.GetString("Report05_030", resourceCulture);

        internal static string Report05_031 =>
            ResourceManager.GetString("Report05_031", resourceCulture);

        internal static string Report05_032 =>
            ResourceManager.GetString("Report05_032", resourceCulture);

        internal static string Report05_033 =>
            ResourceManager.GetString("Report05_033", resourceCulture);

        internal static string Report05_034 =>
            ResourceManager.GetString("Report05_034", resourceCulture);

        internal static string Report05_035 =>
            ResourceManager.GetString("Report05_035", resourceCulture);

        internal static string Report05_036 =>
            ResourceManager.GetString("Report05_036", resourceCulture);

        internal static string Report05_037 =>
            ResourceManager.GetString("Report05_037", resourceCulture);

        internal static string Report05_038 =>
            ResourceManager.GetString("Report05_038", resourceCulture);

        internal static string Report05_039 =>
            ResourceManager.GetString("Report05_039", resourceCulture);

        internal static string Report05_040 =>
            ResourceManager.GetString("Report05_040", resourceCulture);

        internal static string Report05_041 =>
            ResourceManager.GetString("Report05_041", resourceCulture);

        internal static string Report05_042 =>
            ResourceManager.GetString("Report05_042", resourceCulture);

        internal static string Report05_043 =>
            ResourceManager.GetString("Report05_043", resourceCulture);

        internal static string Report05_044 =>
            ResourceManager.GetString("Report05_044", resourceCulture);

        internal static string Report05_045 =>
            ResourceManager.GetString("Report05_045", resourceCulture);

        internal static string Report05_046 =>
            ResourceManager.GetString("Report05_046", resourceCulture);

        internal static string Report05_047 =>
            ResourceManager.GetString("Report05_047", resourceCulture);

        internal static string Report05_048 =>
            ResourceManager.GetString("Report05_048", resourceCulture);

        internal static string Report05_049 =>
            ResourceManager.GetString("Report05_049", resourceCulture);

        internal static string Report06_001 =>
            ResourceManager.GetString("Report06_001", resourceCulture);

        internal static string Report06_002 =>
            ResourceManager.GetString("Report06_002", resourceCulture);

        internal static string Report06_003 =>
            ResourceManager.GetString("Report06_003", resourceCulture);

        internal static string Report06_004 =>
            ResourceManager.GetString("Report06_004", resourceCulture);

        internal static string Report06_005 =>
            ResourceManager.GetString("Report06_005", resourceCulture);

        internal static string Report06_006 =>
            ResourceManager.GetString("Report06_006", resourceCulture);

        internal static string Report06_007 =>
            ResourceManager.GetString("Report06_007", resourceCulture);

        internal static string Report06_008 =>
            ResourceManager.GetString("Report06_008", resourceCulture);

        internal static string Report06_009 =>
            ResourceManager.GetString("Report06_009", resourceCulture);

        internal static string Report06_010 =>
            ResourceManager.GetString("Report06_010", resourceCulture);

        internal static string Report07_001 =>
            ResourceManager.GetString("Report07_001", resourceCulture);

        internal static string Report07_002 =>
            ResourceManager.GetString("Report07_002", resourceCulture);

        internal static string Report07_003 =>
            ResourceManager.GetString("Report07_003", resourceCulture);

        internal static string Report07_004 =>
            ResourceManager.GetString("Report07_004", resourceCulture);

        internal static string Report07_005 =>
            ResourceManager.GetString("Report07_005", resourceCulture);

        internal static string Report07_006 =>
            ResourceManager.GetString("Report07_006", resourceCulture);

        internal static string Report07_007 =>
            ResourceManager.GetString("Report07_007", resourceCulture);

        internal static string Report07_008 =>
            ResourceManager.GetString("Report07_008", resourceCulture);

        internal static string Report07_009 =>
            ResourceManager.GetString("Report07_009", resourceCulture);

        internal static string Report07_010 =>
            ResourceManager.GetString("Report07_010", resourceCulture);

        internal static string Report07_011 =>
            ResourceManager.GetString("Report07_011", resourceCulture);

        internal static string Report08_001 =>
            ResourceManager.GetString("Report08_001", resourceCulture);

        internal static string Report08_002 =>
            ResourceManager.GetString("Report08_002", resourceCulture);

        internal static string Report08_003 =>
            ResourceManager.GetString("Report08_003", resourceCulture);

        internal static string Report08_004 =>
            ResourceManager.GetString("Report08_004", resourceCulture);

        internal static string Report08_005 =>
            ResourceManager.GetString("Report08_005", resourceCulture);

        internal static string Report08_006 =>
            ResourceManager.GetString("Report08_006", resourceCulture);

        internal static string Report08_007 =>
            ResourceManager.GetString("Report08_007", resourceCulture);

        internal static string Report08_008 =>
            ResourceManager.GetString("Report08_008", resourceCulture);

        internal static string Report08_009 =>
            ResourceManager.GetString("Report08_009", resourceCulture);

        internal static string Report08_010 =>
            ResourceManager.GetString("Report08_010", resourceCulture);

        internal static string Report08_011 =>
            ResourceManager.GetString("Report08_011", resourceCulture);

        internal static string Report09_001 =>
            ResourceManager.GetString("Report09_001", resourceCulture);

        internal static string Report09_002 =>
            ResourceManager.GetString("Report09_002", resourceCulture);

        internal static string Report09_003 =>
            ResourceManager.GetString("Report09_003", resourceCulture);

        internal static string Report09_004 =>
            ResourceManager.GetString("Report09_004", resourceCulture);

        internal static string Report09_005 =>
            ResourceManager.GetString("Report09_005", resourceCulture);

        internal static string Report09_006 =>
            ResourceManager.GetString("Report09_006", resourceCulture);

        internal static string Report10_001 =>
            ResourceManager.GetString("Report10_001", resourceCulture);

        internal static string Report10_002 =>
            ResourceManager.GetString("Report10_002", resourceCulture);

        internal static string Report10_003 =>
            ResourceManager.GetString("Report10_003", resourceCulture);

        internal static string Report10_004 =>
            ResourceManager.GetString("Report10_004", resourceCulture);

        internal static string Report10_005 =>
            ResourceManager.GetString("Report10_005", resourceCulture);

        internal static string Report10_006 =>
            ResourceManager.GetString("Report10_006", resourceCulture);

        internal static string Report11_001 =>
            ResourceManager.GetString("Report11_001", resourceCulture);

        internal static string Report11_002 =>
            ResourceManager.GetString("Report11_002", resourceCulture);

        internal static string Report11_003 =>
            ResourceManager.GetString("Report11_003", resourceCulture);

        internal static string Report11_004 =>
            ResourceManager.GetString("Report11_004", resourceCulture);

        internal static string Report11_005 =>
            ResourceManager.GetString("Report11_005", resourceCulture);

        internal static string Report11_006 =>
            ResourceManager.GetString("Report11_006", resourceCulture);

        internal static string Report11_007 =>
            ResourceManager.GetString("Report11_007", resourceCulture);

        internal static string Report11_008 =>
            ResourceManager.GetString("Report11_008", resourceCulture);

        internal static string Report11_009 =>
            ResourceManager.GetString("Report11_009", resourceCulture);

        internal static string Report11_010 =>
            ResourceManager.GetString("Report11_010", resourceCulture);

        internal static string Report11_011 =>
            ResourceManager.GetString("Report11_011", resourceCulture);

        internal static string Report11_012 =>
            ResourceManager.GetString("Report11_012", resourceCulture);

        internal static string Report11_013 =>
            ResourceManager.GetString("Report11_013", resourceCulture);

        internal static string Report11_014 =>
            ResourceManager.GetString("Report11_014", resourceCulture);

        internal static string Report11_015 =>
            ResourceManager.GetString("Report11_015", resourceCulture);

        internal static string Report11_016 =>
            ResourceManager.GetString("Report11_016", resourceCulture);

        internal static string Report11_017 =>
            ResourceManager.GetString("Report11_017", resourceCulture);

        internal static string Report11_018 =>
            ResourceManager.GetString("Report11_018", resourceCulture);

        internal static string Report11_019 =>
            ResourceManager.GetString("Report11_019", resourceCulture);

        internal static string Report11_020 =>
            ResourceManager.GetString("Report11_020", resourceCulture);

        internal static string Report11_021 =>
            ResourceManager.GetString("Report11_021", resourceCulture);

        internal static string Report11_022 =>
            ResourceManager.GetString("Report11_022", resourceCulture);

        internal static string Report11_023 =>
            ResourceManager.GetString("Report11_023", resourceCulture);

        internal static string Report11_024 =>
            ResourceManager.GetString("Report11_024", resourceCulture);

        internal static string Report11_025 =>
            ResourceManager.GetString("Report11_025", resourceCulture);

        internal static string Report11_026 =>
            ResourceManager.GetString("Report11_026", resourceCulture);

        internal static string Report11_027 =>
            ResourceManager.GetString("Report11_027", resourceCulture);

        internal static string Report11_028 =>
            ResourceManager.GetString("Report11_028", resourceCulture);

        internal static string Report11_029 =>
            ResourceManager.GetString("Report11_029", resourceCulture);

        internal static string Report11_030 =>
            ResourceManager.GetString("Report11_030", resourceCulture);

        internal static string Report11_031 =>
            ResourceManager.GetString("Report11_031", resourceCulture);

        internal static string Report11_032 =>
            ResourceManager.GetString("Report11_032", resourceCulture);

        internal static string Report11_033 =>
            ResourceManager.GetString("Report11_033", resourceCulture);

        internal static string Report11_034 =>
            ResourceManager.GetString("Report11_034", resourceCulture);

        internal static string Report11_035 =>
            ResourceManager.GetString("Report11_035", resourceCulture);

        internal static string Report11_036 =>
            ResourceManager.GetString("Report11_036", resourceCulture);

        internal static string Report11_037 =>
            ResourceManager.GetString("Report11_037", resourceCulture);

        internal static string Report11_038 =>
            ResourceManager.GetString("Report11_038", resourceCulture);

        internal static string Report11_039 =>
            ResourceManager.GetString("Report11_039", resourceCulture);

        internal static string Report11_040 =>
            ResourceManager.GetString("Report11_040", resourceCulture);

        internal static string Report11_041 =>
            ResourceManager.GetString("Report11_041", resourceCulture);

        internal static string Report11_042 =>
            ResourceManager.GetString("Report11_042", resourceCulture);

        internal static string SAP =>
            ResourceManager.GetString("SAP", resourceCulture);

        internal static string Save =>
            ResourceManager.GetString("Save", resourceCulture);

        internal static string Setting_001 =>
            ResourceManager.GetString("Setting_001", resourceCulture);

        internal static string Setting_002 =>
            ResourceManager.GetString("Setting_002", resourceCulture);

        internal static string Setting_003 =>
            ResourceManager.GetString("Setting_003", resourceCulture);

        internal static string Setting_004 =>
            ResourceManager.GetString("Setting_004", resourceCulture);

        internal static string Setting_005 =>
            ResourceManager.GetString("Setting_005", resourceCulture);

        internal static string Setting_006 =>
            ResourceManager.GetString("Setting_006", resourceCulture);

        internal static string Setting_007 =>
            ResourceManager.GetString("Setting_007", resourceCulture);

        internal static string Setting_008 =>
            ResourceManager.GetString("Setting_008", resourceCulture);

        internal static string Setting_009 =>
            ResourceManager.GetString("Setting_009", resourceCulture);

        internal static string Setting_010 =>
            ResourceManager.GetString("Setting_010", resourceCulture);

        internal static string Setting_011 =>
            ResourceManager.GetString("Setting_011", resourceCulture);

        internal static string Setting_012 =>
            ResourceManager.GetString("Setting_012", resourceCulture);

        internal static string Setting_013 =>
            ResourceManager.GetString("Setting_013", resourceCulture);

        internal static string Setting_014 =>
            ResourceManager.GetString("Setting_014", resourceCulture);

        internal static string Setting_015 =>
            ResourceManager.GetString("Setting_015", resourceCulture);

        internal static string Setting_016 =>
            ResourceManager.GetString("Setting_016", resourceCulture);

        internal static string Setting_017 =>
            ResourceManager.GetString("Setting_017", resourceCulture);

        internal static string Setting_018 =>
            ResourceManager.GetString("Setting_018", resourceCulture);

        internal static string Setting_019 =>
            ResourceManager.GetString("Setting_019", resourceCulture);

        internal static string Setting_020 =>
            ResourceManager.GetString("Setting_020", resourceCulture);

        internal static string Setting_021 =>
            ResourceManager.GetString("Setting_021", resourceCulture);

        internal static string Setting_022 =>
            ResourceManager.GetString("Setting_022", resourceCulture);

        internal static string Setting_023 =>
            ResourceManager.GetString("Setting_023", resourceCulture);

        internal static string Setting_024 =>
            ResourceManager.GetString("Setting_024", resourceCulture);

        internal static string Setting_025 =>
            ResourceManager.GetString("Setting_025", resourceCulture);

        internal static string Setting_026 =>
            ResourceManager.GetString("Setting_026", resourceCulture);

        internal static string Setting_027 =>
            ResourceManager.GetString("Setting_027", resourceCulture);

        internal static string Setting_028 =>
            ResourceManager.GetString("Setting_028", resourceCulture);

        internal static string Setting_029 =>
            ResourceManager.GetString("Setting_029", resourceCulture);

        internal static string Setting_030 =>
            ResourceManager.GetString("Setting_030", resourceCulture);

        internal static string Setting_031 =>
            ResourceManager.GetString("Setting_031", resourceCulture);

        internal static string Setting_032 =>
            ResourceManager.GetString("Setting_032", resourceCulture);

        internal static string Setting_033 =>
            ResourceManager.GetString("Setting_033", resourceCulture);

        internal static string Setting_034 =>
            ResourceManager.GetString("Setting_034", resourceCulture);

        internal static string Setting_035 =>
            ResourceManager.GetString("Setting_035", resourceCulture);

        internal static string Setting_036 =>
            ResourceManager.GetString("Setting_036", resourceCulture);

        internal static string Setting_037 =>
            ResourceManager.GetString("Setting_037", resourceCulture);

        internal static string Setting_038 =>
            ResourceManager.GetString("Setting_038", resourceCulture);

        internal static string Setting_039 =>
            ResourceManager.GetString("Setting_039", resourceCulture);

        internal static string Setting_040 =>
            ResourceManager.GetString("Setting_040", resourceCulture);

        internal static string Setting_041 =>
            ResourceManager.GetString("Setting_041", resourceCulture);

        internal static string Setting_042 =>
            ResourceManager.GetString("Setting_042", resourceCulture);

        internal static string Setting_043 =>
            ResourceManager.GetString("Setting_043", resourceCulture);

        internal static string Setting_044 =>
            ResourceManager.GetString("Setting_044", resourceCulture);

        internal static string Setting_045 =>
            ResourceManager.GetString("Setting_045", resourceCulture);

        internal static string Setting_046 =>
            ResourceManager.GetString("Setting_046", resourceCulture);

        internal static string Setting_047 =>
            ResourceManager.GetString("Setting_047", resourceCulture);

        internal static string Setting_048 =>
            ResourceManager.GetString("Setting_048", resourceCulture);

        internal static string Setting_049 =>
            ResourceManager.GetString("Setting_049", resourceCulture);

        internal static string Setting_050 =>
            ResourceManager.GetString("Setting_050", resourceCulture);

        internal static string Setting_051 =>
            ResourceManager.GetString("Setting_051", resourceCulture);

        internal static string Setting_052 =>
            ResourceManager.GetString("Setting_052", resourceCulture);

        internal static string Setting_053 =>
            ResourceManager.GetString("Setting_053", resourceCulture);

        internal static string Setting_054 =>
            ResourceManager.GetString("Setting_054", resourceCulture);

        internal static string Setting_055 =>
            ResourceManager.GetString("Setting_055", resourceCulture);

        internal static string Setting_056 =>
            ResourceManager.GetString("Setting_056", resourceCulture);

        internal static string Setting_057 =>
            ResourceManager.GetString("Setting_057", resourceCulture);

        internal static string Setting_058 =>
            ResourceManager.GetString("Setting_058", resourceCulture);

        internal static string Setting_059 =>
            ResourceManager.GetString("Setting_059", resourceCulture);

        internal static string Setting_060 =>
            ResourceManager.GetString("Setting_060", resourceCulture);

        internal static string Setting_061 =>
            ResourceManager.GetString("Setting_061", resourceCulture);

        internal static string Setting_062 =>
            ResourceManager.GetString("Setting_062", resourceCulture);

        internal static string Setting_063 =>
            ResourceManager.GetString("Setting_063", resourceCulture);

        internal static string Setting_064 =>
            ResourceManager.GetString("Setting_064", resourceCulture);

        internal static string Setting_065 =>
            ResourceManager.GetString("Setting_065", resourceCulture);

        internal static string Setting_066 =>
            ResourceManager.GetString("Setting_066", resourceCulture);

        internal static string Setting_067 =>
            ResourceManager.GetString("Setting_067", resourceCulture);

        internal static string Setting_068 =>
            ResourceManager.GetString("Setting_068", resourceCulture);

        internal static string Setting_069 =>
            ResourceManager.GetString("Setting_069", resourceCulture);

        internal static string Setting_070 =>
            ResourceManager.GetString("Setting_070", resourceCulture);

        internal static string Setting_071 =>
            ResourceManager.GetString("Setting_071", resourceCulture);

        internal static string Setting_072 =>
            ResourceManager.GetString("Setting_072", resourceCulture);

        internal static string Setting_073 =>
            ResourceManager.GetString("Setting_073", resourceCulture);

        internal static string Setting_074 =>
            ResourceManager.GetString("Setting_074", resourceCulture);

        internal static string Setting_075 =>
            ResourceManager.GetString("Setting_075", resourceCulture);

        internal static string Setting_076 =>
            ResourceManager.GetString("Setting_076", resourceCulture);

        internal static string Setting_077 =>
            ResourceManager.GetString("Setting_077", resourceCulture);

        internal static string Setting_078 =>
            ResourceManager.GetString("Setting_078", resourceCulture);

        internal static string Setting_079 =>
            ResourceManager.GetString("Setting_079", resourceCulture);

        internal static string Setting_080 =>
            ResourceManager.GetString("Setting_080", resourceCulture);

        internal static string Setting_081 =>
            ResourceManager.GetString("Setting_081", resourceCulture);

        internal static string Setting_082 =>
            ResourceManager.GetString("Setting_082", resourceCulture);

        internal static string Setting_083 =>
            ResourceManager.GetString("Setting_083", resourceCulture);

        internal static string Setting_084 =>
            ResourceManager.GetString("Setting_084", resourceCulture);

        internal static string Setting_085 =>
            ResourceManager.GetString("Setting_085", resourceCulture);

        internal static string Setting_086 =>
            ResourceManager.GetString("Setting_086", resourceCulture);

        internal static string Setting_087 =>
            ResourceManager.GetString("Setting_087", resourceCulture);

        internal static string Setting_088 =>
            ResourceManager.GetString("Setting_088", resourceCulture);

        internal static string Setting_089 =>
            ResourceManager.GetString("Setting_089", resourceCulture);

        internal static string Setting_090 =>
            ResourceManager.GetString("Setting_090", resourceCulture);

        internal static string Setting_091 =>
            ResourceManager.GetString("Setting_091", resourceCulture);

        internal static string Setting_092 =>
            ResourceManager.GetString("Setting_092", resourceCulture);

        internal static string Setting_093 =>
            ResourceManager.GetString("Setting_093", resourceCulture);

        internal static string Setting_094 =>
            ResourceManager.GetString("Setting_094", resourceCulture);

        internal static string Setting_095 =>
            ResourceManager.GetString("Setting_095", resourceCulture);

        internal static string Setting_096 =>
            ResourceManager.GetString("Setting_096", resourceCulture);

        internal static string Setting_097 =>
            ResourceManager.GetString("Setting_097", resourceCulture);

        internal static string Setting_098 =>
            ResourceManager.GetString("Setting_098", resourceCulture);

        internal static string Setting_099 =>
            ResourceManager.GetString("Setting_099", resourceCulture);

        internal static string Setting_100 =>
            ResourceManager.GetString("Setting_100", resourceCulture);

        internal static string Setting_101 =>
            ResourceManager.GetString("Setting_101", resourceCulture);

        internal static string Setting_102 =>
            ResourceManager.GetString("Setting_102", resourceCulture);

        internal static string Setting_103 =>
            ResourceManager.GetString("Setting_103", resourceCulture);

        internal static string Setting_104 =>
            ResourceManager.GetString("Setting_104", resourceCulture);

        internal static string Setting_105 =>
            ResourceManager.GetString("Setting_105", resourceCulture);

        internal static string Setting_106 =>
            ResourceManager.GetString("Setting_106", resourceCulture);

        internal static string Setting_107 =>
            ResourceManager.GetString("Setting_107", resourceCulture);

        internal static string Setting_108 =>
            ResourceManager.GetString("Setting_108", resourceCulture);

        internal static string Setting_109 =>
            ResourceManager.GetString("Setting_109", resourceCulture);

        internal static string Setting_110 =>
            ResourceManager.GetString("Setting_110", resourceCulture);

        internal static string Setting_111 =>
            ResourceManager.GetString("Setting_111", resourceCulture);

        internal static string Setting_112 =>
            ResourceManager.GetString("Setting_112", resourceCulture);

        internal static string Setting_113 =>
            ResourceManager.GetString("Setting_113", resourceCulture);

        internal static string Setting_114 =>
            ResourceManager.GetString("Setting_114", resourceCulture);

        internal static string Setting_115 =>
            ResourceManager.GetString("Setting_115", resourceCulture);

        internal static string Setting_116 =>
            ResourceManager.GetString("Setting_116", resourceCulture);

        internal static string Setting_117 =>
            ResourceManager.GetString("Setting_117", resourceCulture);

        internal static string Setting_118 =>
            ResourceManager.GetString("Setting_118", resourceCulture);

        internal static string Setting_119 =>
            ResourceManager.GetString("Setting_119", resourceCulture);

        internal static string Setting_120 =>
            ResourceManager.GetString("Setting_120", resourceCulture);

        internal static string Setting_121 =>
            ResourceManager.GetString("Setting_121", resourceCulture);

        internal static string Setting_122 =>
            ResourceManager.GetString("Setting_122", resourceCulture);

        internal static string Setting_123 =>
            ResourceManager.GetString("Setting_123", resourceCulture);

        internal static string Setting_124 =>
            ResourceManager.GetString("Setting_124", resourceCulture);

        internal static string Setting_125 =>
            ResourceManager.GetString("Setting_125", resourceCulture);

        internal static string Setting_126 =>
            ResourceManager.GetString("Setting_126", resourceCulture);

        internal static string Setting_127 =>
            ResourceManager.GetString("Setting_127", resourceCulture);

        internal static string Setting_128 =>
            ResourceManager.GetString("Setting_128", resourceCulture);

        internal static string Setting_129 =>
            ResourceManager.GetString("Setting_129", resourceCulture);

        internal static string Setting_130 =>
            ResourceManager.GetString("Setting_130", resourceCulture);

        internal static string Setting_131 =>
            ResourceManager.GetString("Setting_131", resourceCulture);

        internal static string Setting_132 =>
            ResourceManager.GetString("Setting_132", resourceCulture);

        internal static string Setting_133 =>
            ResourceManager.GetString("Setting_133", resourceCulture);

        internal static string Setting_134 =>
            ResourceManager.GetString("Setting_134", resourceCulture);

        internal static string Setting_135 =>
            ResourceManager.GetString("Setting_135", resourceCulture);

        internal static string Setting_136 =>
            ResourceManager.GetString("Setting_136", resourceCulture);

        internal static string Setting_137 =>
            ResourceManager.GetString("Setting_137", resourceCulture);

        internal static string Setting_138 =>
            ResourceManager.GetString("Setting_138", resourceCulture);

        internal static string Setting_139 =>
            ResourceManager.GetString("Setting_139", resourceCulture);

        internal static string Setting_140 =>
            ResourceManager.GetString("Setting_140", resourceCulture);

        internal static string Setting_141 =>
            ResourceManager.GetString("Setting_141", resourceCulture);

        internal static string Setting_142 =>
            ResourceManager.GetString("Setting_142", resourceCulture);

        internal static string Setting_143 =>
            ResourceManager.GetString("Setting_143", resourceCulture);

        internal static string Setting_144 =>
            ResourceManager.GetString("Setting_144", resourceCulture);

        internal static string Setting_145 =>
            ResourceManager.GetString("Setting_145", resourceCulture);

        internal static string Setting_146 =>
            ResourceManager.GetString("Setting_146", resourceCulture);

        internal static string Setting_147 =>
            ResourceManager.GetString("Setting_147", resourceCulture);

        internal static string Setting_148 =>
            ResourceManager.GetString("Setting_148", resourceCulture);

        internal static string Setting_149 =>
            ResourceManager.GetString("Setting_149", resourceCulture);

        internal static string Setting_150 =>
            ResourceManager.GetString("Setting_150", resourceCulture);

        internal static string Setting_151 =>
            ResourceManager.GetString("Setting_151", resourceCulture);

        internal static string Setting_152 =>
            ResourceManager.GetString("Setting_152", resourceCulture);

        internal static string Setting_153 =>
            ResourceManager.GetString("Setting_153", resourceCulture);

        internal static string Setting_154 =>
            ResourceManager.GetString("Setting_154", resourceCulture);

        internal static string Setting_155 =>
            ResourceManager.GetString("Setting_155", resourceCulture);

        internal static string Setting_156 =>
            ResourceManager.GetString("Setting_156", resourceCulture);

        internal static string Setting_157 =>
            ResourceManager.GetString("Setting_157", resourceCulture);

        internal static string Setting_158 =>
            ResourceManager.GetString("Setting_158", resourceCulture);

        internal static string Setting_159 =>
            ResourceManager.GetString("Setting_159", resourceCulture);

        internal static string Source_001 =>
            ResourceManager.GetString("Source_001", resourceCulture);

        internal static string Source_002 =>
            ResourceManager.GetString("Source_002", resourceCulture);

        internal static string Source_003 =>
            ResourceManager.GetString("Source_003", resourceCulture);

        internal static string Source_004 =>
            ResourceManager.GetString("Source_004", resourceCulture);

        internal static string Source_005 =>
            ResourceManager.GetString("Source_005", resourceCulture);

        internal static string Source_006 =>
            ResourceManager.GetString("Source_006", resourceCulture);

        internal static string Source_007 =>
            ResourceManager.GetString("Source_007", resourceCulture);

        internal static string Source_008 =>
            ResourceManager.GetString("Source_008", resourceCulture);

        internal static string Source_009 =>
            ResourceManager.GetString("Source_009", resourceCulture);

        internal static string Source_010 =>
            ResourceManager.GetString("Source_010", resourceCulture);

        internal static string Source_011 =>
            ResourceManager.GetString("Source_011", resourceCulture);

        internal static string Source_012 =>
            ResourceManager.GetString("Source_012", resourceCulture);

        internal static string Source_013 =>
            ResourceManager.GetString("Source_013", resourceCulture);

        internal static string Source_014 =>
            ResourceManager.GetString("Source_014", resourceCulture);

        internal static string Source_015 =>
            ResourceManager.GetString("Source_015", resourceCulture);

        internal static string Source_016 =>
            ResourceManager.GetString("Source_016", resourceCulture);

        internal static string Source_017 =>
            ResourceManager.GetString("Source_017", resourceCulture);

        internal static string Source_018 =>
            ResourceManager.GetString("Source_018", resourceCulture);

        internal static string Source_019 =>
            ResourceManager.GetString("Source_019", resourceCulture);

        internal static string SPRI_Mes_001 =>
            ResourceManager.GetString("SPRI_Mes_001", resourceCulture);

        internal static string SPRI_Mes_002 =>
            ResourceManager.GetString("SPRI_Mes_002", resourceCulture);

        internal static string SPRI_Mes_003 =>
            ResourceManager.GetString("SPRI_Mes_003", resourceCulture);

        internal static string SPRI_Mes_004 =>
            ResourceManager.GetString("SPRI_Mes_004", resourceCulture);

        internal static string SPRI_Mes_005 =>
            ResourceManager.GetString("SPRI_Mes_005", resourceCulture);

        internal static string SPRI_Mes_006 =>
            ResourceManager.GetString("SPRI_Mes_006", resourceCulture);

        internal static string SPRI_Mes_007 =>
            ResourceManager.GetString("SPRI_Mes_007", resourceCulture);

        internal static string SPRI_Mes_008 =>
            ResourceManager.GetString("SPRI_Mes_008", resourceCulture);

        internal static string SPRI_Mes_008_01 =>
            ResourceManager.GetString("SPRI_Mes_008_01", resourceCulture);

        internal static string SPRI_Mes_008_02 =>
            ResourceManager.GetString("SPRI_Mes_008_02", resourceCulture);

        internal static string SPRI_Mes_008_03 =>
            ResourceManager.GetString("SPRI_Mes_008_03", resourceCulture);

        internal static string SPRI_Mes_009_01 =>
            ResourceManager.GetString("SPRI_Mes_009_01", resourceCulture);

        internal static string SPRI_Mes_009_02 =>
            ResourceManager.GetString("SPRI_Mes_009_02", resourceCulture);

        internal static string SPRI_Mes_010 =>
            ResourceManager.GetString("SPRI_Mes_010", resourceCulture);

        internal static string SPRI_Mes_011 =>
            ResourceManager.GetString("SPRI_Mes_011", resourceCulture);

        internal static string SPRI_Mes_012 =>
            ResourceManager.GetString("SPRI_Mes_012", resourceCulture);

        internal static string SPRI_Mes_013 =>
            ResourceManager.GetString("SPRI_Mes_013", resourceCulture);

        internal static string SPRI_Mes_014 =>
            ResourceManager.GetString("SPRI_Mes_014", resourceCulture);

        internal static string SPRI_Mes_015 =>
            ResourceManager.GetString("SPRI_Mes_015", resourceCulture);

        internal static string SPRI_Mes_016 =>
            ResourceManager.GetString("SPRI_Mes_016", resourceCulture);

        internal static string SPRI_Mes_017 =>
            ResourceManager.GetString("SPRI_Mes_017", resourceCulture);

        internal static string SPRI_Mes_018 =>
            ResourceManager.GetString("SPRI_Mes_018", resourceCulture);

        internal static string Storage_001 =>
            ResourceManager.GetString("Storage_001", resourceCulture);

        internal static string Storage_002 =>
            ResourceManager.GetString("Storage_002", resourceCulture);

        internal static string Support_01 =>
            ResourceManager.GetString("Support_01", resourceCulture);

        internal static string Tab_Grading_Control =>
            ResourceManager.GetString("Tab_Grading_Control", resourceCulture);

        internal static string Tab_SAP =>
            ResourceManager.GetString("Tab_SAP", resourceCulture);

        internal static string Tab_SAP_Detail =>
            ResourceManager.GetString("Tab_SAP_Detail", resourceCulture);

        internal static string Tab_UOM_Conversion =>
            ResourceManager.GetString("Tab_UOM_Conversion", resourceCulture);

        internal static string Tanker_001 =>
            ResourceManager.GetString("Tanker_001", resourceCulture);

        internal static string Tanker_002 =>
            ResourceManager.GetString("Tanker_002", resourceCulture);

        internal static string Tanker_003 =>
            ResourceManager.GetString("Tanker_003", resourceCulture);

        internal static string Tanker_004 =>
            ResourceManager.GetString("Tanker_004", resourceCulture);

        internal static string TCS_Scan001 =>
            ResourceManager.GetString("TCS_Scan001", resourceCulture);

        internal static string TCS_Scan002 =>
            ResourceManager.GetString("TCS_Scan002", resourceCulture);

        internal static string TCS_Scan003 =>
            ResourceManager.GetString("TCS_Scan003", resourceCulture);

        internal static string TCS_Scan004 =>
            ResourceManager.GetString("TCS_Scan004", resourceCulture);

        internal static string TCS_Scan005 =>
            ResourceManager.GetString("TCS_Scan005", resourceCulture);

        internal static string TCS_Scan006 =>
            ResourceManager.GetString("TCS_Scan006", resourceCulture);

        internal static string TCS_Scan007 =>
            ResourceManager.GetString("TCS_Scan007", resourceCulture);

        internal static string Title_001 =>
            ResourceManager.GetString("Title_001", resourceCulture);

        internal static string Title_002 =>
            ResourceManager.GetString("Title_002", resourceCulture);

        internal static string Title_003 =>
            ResourceManager.GetString("Title_003", resourceCulture);

        internal static string Title_005 =>
            ResourceManager.GetString("Title_005", resourceCulture);

        internal static string Title_006 =>
            ResourceManager.GetString("Title_006", resourceCulture);

        internal static string Title_007 =>
            ResourceManager.GetString("Title_007", resourceCulture);

        internal static string Title_008 =>
            ResourceManager.GetString("Title_008", resourceCulture);

        internal static string Title_Add_Block =>
            ResourceManager.GetString("Title_Add_Block", resourceCulture);

        internal static string Title_Add_Camera =>
            ResourceManager.GetString("Title_Add_Camera", resourceCulture);

        internal static string Title_Add_Commodity =>
            ResourceManager.GetString("Title_Add_Commodity", resourceCulture);

        internal static string Title_Add_Composite =>
            ResourceManager.GetString("Title_Add_Composite", resourceCulture);

        internal static string Title_Add_Deducted_By =>
            ResourceManager.GetString("Title_Add_Deducted_By", resourceCulture);

        internal static string Title_Add_Deduction =>
            ResourceManager.GetString("Title_Add_Deduction", resourceCulture);

        internal static string Title_Add_Division =>
            ResourceManager.GetString("Title_Add_Division", resourceCulture);

        internal static string Title_Add_DO =>
            ResourceManager.GetString("Title_Add_DO", resourceCulture);

        internal static string Title_Add_Driver =>
            ResourceManager.GetString("Title_Add_Driver", resourceCulture);

        internal static string Title_Add_Edit_Relation =>
            ResourceManager.GetString("Title_Add_Edit_Relation", resourceCulture);

        internal static string Title_Add_Email =>
            ResourceManager.GetString("Title_Add_Email", resourceCulture);

        internal static string Title_Add_Estate =>
            ResourceManager.GetString("Title_Add_Estate", resourceCulture);

        internal static string Title_Add_Grading =>
            ResourceManager.GetString("Title_Add_Grading", resourceCulture);

        internal static string Title_Add_Location =>
            ResourceManager.GetString("Title_Add_Location", resourceCulture);

        internal static string Title_Add_Reason =>
            ResourceManager.GetString("Title_Add_Reason", resourceCulture);

        internal static string Title_Add_Relation =>
            ResourceManager.GetString("Title_Add_Relation", resourceCulture);

        internal static string Title_Add_SAP_Destination =>
            ResourceManager.GetString("Title_Add_SAP_Destination", resourceCulture);

        internal static string Title_Add_SAP_Destination_IDSYS =>
            ResourceManager.GetString("Title_Add_SAP_Destination_IDSYS", resourceCulture);

        internal static string Title_Add_SO_Item =>
            ResourceManager.GetString("Title_Add_SO_Item", resourceCulture);

        internal static string Title_Add_Source =>
            ResourceManager.GetString("Title_Add_Source", resourceCulture);

        internal static string Title_Add_Storage =>
            ResourceManager.GetString("Title_Add_Storage", resourceCulture);

        internal static string Title_Add_Tanker =>
            ResourceManager.GetString("Title_Add_Tanker", resourceCulture);

        internal static string Title_Add_Transporter =>
            ResourceManager.GetString("Title_Add_Transporter", resourceCulture);

        internal static string Title_Add_Truck =>
            ResourceManager.GetString("Title_Add_Truck", resourceCulture);

        internal static string Title_Add_Upload =>
            ResourceManager.GetString("Title_Add_Upload", resourceCulture);

        internal static string Title_Add_WB_Calibration =>
            ResourceManager.GetString("Title_Add_WB_Calibration", resourceCulture);

        internal static string Title_Add_Yield =>
            ResourceManager.GetString("Title_Add_Yield", resourceCulture);

        internal static string Title_Block =>
            ResourceManager.GetString("Title_Block", resourceCulture);

        internal static string Title_Block_Entry =>
            ResourceManager.GetString("Title_Block_Entry", resourceCulture);

        internal static string Title_Camera =>
            ResourceManager.GetString("Title_Camera", resourceCulture);

        internal static string Title_Camera_Capture =>
            ResourceManager.GetString("Title_Camera_Capture", resourceCulture);

        internal static string Title_Camera_Preview =>
            ResourceManager.GetString("Title_Camera_Preview", resourceCulture);

        internal static string Title_Cancel_Record =>
            ResourceManager.GetString("Title_Cancel_Record", resourceCulture);

        internal static string Title_Change_Reason =>
            ResourceManager.GetString("Title_Change_Reason", resourceCulture);

        internal static string Title_Comm_Trx =>
            ResourceManager.GetString("Title_Comm_Trx", resourceCulture);

        internal static string Title_Commodity_Compare =>
            ResourceManager.GetString("Title_Commodity_Compare", resourceCulture);

        internal static string Title_Commodity_Entry =>
            ResourceManager.GetString("Title_Commodity_Entry", resourceCulture);

        internal static string Title_Commodity_Entry_Advanced =>
            ResourceManager.GetString("Title_Commodity_Entry_Advanced", resourceCulture);

        internal static string Title_Commodity_Entry_Advanced_Add_Item =>
            ResourceManager.GetString("Title_Commodity_Entry_Advanced_Add_Item", resourceCulture);

        internal static string Title_Commodity_Entry_Grading =>
            ResourceManager.GetString("Title_Commodity_Entry_Grading", resourceCulture);

        internal static string Title_Commodity_List =>
            ResourceManager.GetString("Title_Commodity_List", resourceCulture);

        internal static string Title_Company =>
            ResourceManager.GetString("Title_Company", resourceCulture);

        internal static string Title_Composite =>
            ResourceManager.GetString("Title_Composite", resourceCulture);

        internal static string Title_Composite_Entry =>
            ResourceManager.GetString("Title_Composite_Entry", resourceCulture);

        internal static string Title_Confirm_Delete_WB_Calibration =>
            ResourceManager.GetString("Title_Confirm_Delete_WB_Calibration", resourceCulture);

        internal static string Title_Contract_Filter =>
            ResourceManager.GetString("Title_Contract_Filter", resourceCulture);

        internal static string Title_Contract_List =>
            ResourceManager.GetString("Title_Contract_List", resourceCulture);

        internal static string Title_Contract_Status =>
            ResourceManager.GetString("Title_Contract_Status", resourceCulture);

        internal static string Title_Copy_Composite =>
            ResourceManager.GetString("Title_Copy_Composite", resourceCulture);

        internal static string Title_Deducted_By =>
            ResourceManager.GetString("Title_Deducted_By", resourceCulture);

        internal static string Title_Deducted_By_Entry =>
            ResourceManager.GetString("Title_Deducted_By_Entry", resourceCulture);

        internal static string Title_Deduction_Entry =>
            ResourceManager.GetString("Title_Deduction_Entry", resourceCulture);

        internal static string Title_Division =>
            ResourceManager.GetString("Title_Division", resourceCulture);

        internal static string Title_Division_Entry =>
            ResourceManager.GetString("Title_Division_Entry", resourceCulture);

        internal static string Title_Driver =>
            ResourceManager.GetString("Title_Driver", resourceCulture);

        internal static string Title_Driver_Entry =>
            ResourceManager.GetString("Title_Driver_Entry", resourceCulture);

        internal static string Title_Driver_Filter =>
            ResourceManager.GetString("Title_Driver_Filter", resourceCulture);

        internal static string Title_Edit_Block =>
            ResourceManager.GetString("Title_Edit_Block", resourceCulture);

        internal static string Title_Edit_Camera =>
            ResourceManager.GetString("Title_Edit_Camera", resourceCulture);

        internal static string Title_Edit_Commodity =>
            ResourceManager.GetString("Title_Edit_Commodity", resourceCulture);

        internal static string Title_Edit_Commodity_Tolerance =>
            ResourceManager.GetString("Title_Edit_Commodity_Tolerance", resourceCulture);

        internal static string Title_Edit_Composite =>
            ResourceManager.GetString("Title_Edit_Composite", resourceCulture);

        internal static string Title_Edit_Deducted_By =>
            ResourceManager.GetString("Title_Edit_Deducted_By", resourceCulture);

        internal static string Title_Edit_Deduction =>
            ResourceManager.GetString("Title_Edit_Deduction", resourceCulture);

        internal static string Title_Edit_Division =>
            ResourceManager.GetString("Title_Edit_Division", resourceCulture);

        internal static string Title_Edit_Driver =>
            ResourceManager.GetString("Title_Edit_Driver", resourceCulture);

        internal static string Title_Edit_Email =>
            ResourceManager.GetString("Title_Edit_Email", resourceCulture);

        internal static string Title_Edit_Estate =>
            ResourceManager.GetString("Title_Edit_Estate", resourceCulture);

        internal static string Title_Edit_Grading =>
            ResourceManager.GetString("Title_Edit_Grading", resourceCulture);

        internal static string Title_Edit_Location =>
            ResourceManager.GetString("Title_Edit_Location", resourceCulture);

        internal static string Title_Edit_Nego =>
            ResourceManager.GetString("Title_Edit_Nego", resourceCulture);

        internal static string Title_Edit_Reason =>
            ResourceManager.GetString("Title_Edit_Reason", resourceCulture);

        internal static string Title_Edit_Relation =>
            ResourceManager.GetString("Title_Edit_Relation", resourceCulture);

        internal static string Title_Edit_SAP_Destination =>
            ResourceManager.GetString("Title_Edit_SAP_Destination", resourceCulture);

        internal static string Title_Edit_SAP_Destination_IDSYS =>
            ResourceManager.GetString("Title_Edit_SAP_Destination_IDSYS", resourceCulture);

        internal static string Title_Edit_SO_Item =>
            ResourceManager.GetString("Title_Edit_SO_Item", resourceCulture);

        internal static string Title_Edit_Source =>
            ResourceManager.GetString("Title_Edit_Source", resourceCulture);

        internal static string Title_Edit_Storage =>
            ResourceManager.GetString("Title_Edit_Storage", resourceCulture);

        internal static string Title_Edit_Tanker =>
            ResourceManager.GetString("Title_Edit_Tanker", resourceCulture);

        internal static string Title_Edit_Transporter =>
            ResourceManager.GetString("Title_Edit_Transporter", resourceCulture);

        internal static string Title_Edit_Truck =>
            ResourceManager.GetString("Title_Edit_Truck", resourceCulture);

        internal static string Title_Edit_Upload =>
            ResourceManager.GetString("Title_Edit_Upload", resourceCulture);

        internal static string Title_Edit_WB_Calibration =>
            ResourceManager.GetString("Title_Edit_WB_Calibration", resourceCulture);

        internal static string Title_Edit_Yield =>
            ResourceManager.GetString("Title_Edit_Yield", resourceCulture);

        internal static string Title_Email =>
            ResourceManager.GetString("Title_Email", resourceCulture);

        internal static string Title_Enter_Commodity_Quality =>
            ResourceManager.GetString("Title_Enter_Commodity_Quality", resourceCulture);

        internal static string Title_Entry_Estate =>
            ResourceManager.GetString("Title_Entry_Estate", resourceCulture);

        internal static string Title_Entry_Nego =>
            ResourceManager.GetString("Title_Entry_Nego", resourceCulture);

        internal static string Title_Entry_Titip_Timbun =>
            ResourceManager.GetString("Title_Entry_Titip_Timbun", resourceCulture);

        internal static string Title_Error_Delete_Used_In_Commodity =>
            ResourceManager.GetString("Title_Error_Delete_Used_In_Commodity", resourceCulture);

        internal static string Title_Error_Delete_Used_SAP_Destination =>
            ResourceManager.GetString("Title_Error_Delete_Used_SAP_Destination", resourceCulture);

        internal static string Title_Error_Delete_Used_SAP_Destination_IDSYS =>
            ResourceManager.GetString("Title_Error_Delete_Used_SAP_Destination_IDSYS", resourceCulture);

        internal static string Title_Estate =>
            ResourceManager.GetString("Title_Estate", resourceCulture);

        internal static string Title_Feature =>
            ResourceManager.GetString("Title_Feature", resourceCulture);

        internal static string Title_Form_Contract_Entry =>
            ResourceManager.GetString("Title_Form_Contract_Entry", resourceCulture);

        internal static string Title_Form_SPB =>
            ResourceManager.GetString("Title_Form_SPB", resourceCulture);

        internal static string Title_Form_SPB_Entry =>
            ResourceManager.GetString("Title_Form_SPB_Entry", resourceCulture);

        internal static string Title_Grading =>
            ResourceManager.GetString("Title_Grading", resourceCulture);

        internal static string Title_Location =>
            ResourceManager.GetString("Title_Location", resourceCulture);

        internal static string Title_Location_Entry =>
            ResourceManager.GetString("Title_Location_Entry", resourceCulture);

        internal static string Title_Location_Timbun =>
            ResourceManager.GetString("Title_Location_Timbun", resourceCulture);

        internal static string Title_Map_Vessel =>
            ResourceManager.GetString("Title_Map_Vessel", resourceCulture);

        internal static string Title_Nego_Number =>
            ResourceManager.GetString("Title_Nego_Number", resourceCulture);

        internal static string Title_Nego_Number_Entry =>
            ResourceManager.GetString("Title_Nego_Number_Entry", resourceCulture);

        internal static string Title_Readopt_DO =>
            ResourceManager.GetString("Title_Readopt_DO", resourceCulture);

        internal static string Title_Relation =>
            ResourceManager.GetString("Title_Relation", resourceCulture);

        internal static string Title_Replace_Temp_Do =>
            ResourceManager.GetString("Title_Replace_Temp_Do", resourceCulture);

        internal static string Title_Replace_Temp_Do_2 =>
            ResourceManager.GetString("Title_Replace_Temp_Do_2", resourceCulture);

        internal static string Title_SAP_Destination =>
            ResourceManager.GetString("Title_SAP_Destination", resourceCulture);

        internal static string Title_SAP_Destination_Entry =>
            ResourceManager.GetString("Title_SAP_Destination_Entry", resourceCulture);

        internal static string Title_SAP_Destination_Entry_IDSYS =>
            ResourceManager.GetString("Title_SAP_Destination_Entry_IDSYS", resourceCulture);

        internal static string Title_SAP_Destination_IDSYS =>
            ResourceManager.GetString("Title_SAP_Destination_IDSYS", resourceCulture);

        internal static string Title_SO_Item_Detail =>
            ResourceManager.GetString("Title_SO_Item_Detail", resourceCulture);

        internal static string Title_Source =>
            ResourceManager.GetString("Title_Source", resourceCulture);

        internal static string Title_Storage =>
            ResourceManager.GetString("Title_Storage", resourceCulture);

        internal static string Title_Tanker =>
            ResourceManager.GetString("Title_Tanker", resourceCulture);

        internal static string Title_Template_SAP =>
            ResourceManager.GetString("Title_Template_SAP", resourceCulture);

        internal static string Title_Template_SAP_Entry =>
            ResourceManager.GetString("Title_Template_SAP_Entry", resourceCulture);

        internal static string Title_Template_SAP_Entry_IDSYS =>
            ResourceManager.GetString("Title_Template_SAP_Entry_IDSYS", resourceCulture);

        internal static string Title_Template_SAP_IDSYS =>
            ResourceManager.GetString("Title_Template_SAP_IDSYS", resourceCulture);

        internal static string Title_Template_SAP_Position =>
            ResourceManager.GetString("Title_Template_SAP_Position", resourceCulture);

        internal static string Title_Template_SAP_Position_IDSYS =>
            ResourceManager.GetString("Title_Template_SAP_Position_IDSYS", resourceCulture);

        internal static string Title_Token =>
            ResourceManager.GetString("Title_Token", resourceCulture);

        internal static string Title_Token_CMD =>
            ResourceManager.GetString("Title_Token_CMD", resourceCulture);

        internal static string Title_Transporter =>
            ResourceManager.GetString("Title_Transporter", resourceCulture);

        internal static string Title_Transporter_Entry =>
            ResourceManager.GetString("Title_Transporter_Entry", resourceCulture);

        internal static string Title_TransTypeEntry =>
            ResourceManager.GetString("Title_TransTypeEntry", resourceCulture);

        internal static string Title_Truck =>
            ResourceManager.GetString("Title_Truck", resourceCulture);

        internal static string Title_Upload_Type =>
            ResourceManager.GetString("Title_Upload_Type", resourceCulture);

        internal static string Title_Upload_Type_Entry =>
            ResourceManager.GetString("Title_Upload_Type_Entry", resourceCulture);

        internal static string Title_View_Block =>
            ResourceManager.GetString("Title_View_Block", resourceCulture);

        internal static string Title_View_Camera =>
            ResourceManager.GetString("Title_View_Camera", resourceCulture);

        internal static string Title_View_Commodity =>
            ResourceManager.GetString("Title_View_Commodity", resourceCulture);

        internal static string Title_View_Composite =>
            ResourceManager.GetString("Title_View_Composite", resourceCulture);

        internal static string Title_View_Deducted_By =>
            ResourceManager.GetString("Title_View_Deducted_By", resourceCulture);

        internal static string Title_View_Division =>
            ResourceManager.GetString("Title_View_Division", resourceCulture);

        internal static string Title_View_DO =>
            ResourceManager.GetString("Title_View_DO", resourceCulture);

        internal static string Title_View_Driver =>
            ResourceManager.GetString("Title_View_Driver", resourceCulture);

        internal static string Title_View_Email =>
            ResourceManager.GetString("Title_View_Email", resourceCulture);

        internal static string Title_View_Estate =>
            ResourceManager.GetString("Title_View_Estate", resourceCulture);

        internal static string Title_View_Grading =>
            ResourceManager.GetString("Title_View_Grading", resourceCulture);

        internal static string Title_View_Location =>
            ResourceManager.GetString("Title_View_Location", resourceCulture);

        internal static string Title_View_Reason =>
            ResourceManager.GetString("Title_View_Reason", resourceCulture);

        internal static string Title_View_Relation =>
            ResourceManager.GetString("Title_View_Relation", resourceCulture);

        internal static string Title_View_SAP_Destination =>
            ResourceManager.GetString("Title_View_SAP_Destination", resourceCulture);

        internal static string Title_View_SAP_Destination_IDSYS =>
            ResourceManager.GetString("Title_View_SAP_Destination_IDSYS", resourceCulture);

        internal static string Title_View_Storage =>
            ResourceManager.GetString("Title_View_Storage", resourceCulture);

        internal static string Title_View_Tanker =>
            ResourceManager.GetString("Title_View_Tanker", resourceCulture);

        internal static string Title_View_Transporter =>
            ResourceManager.GetString("Title_View_Transporter", resourceCulture);

        internal static string Title_View_Truck =>
            ResourceManager.GetString("Title_View_Truck", resourceCulture);

        internal static string Title_View_Upload_Type =>
            ResourceManager.GetString("Title_View_Upload_Type", resourceCulture);

        internal static string Title_View_WB_Calibration =>
            ResourceManager.GetString("Title_View_WB_Calibration", resourceCulture);

        internal static string Title_View_Yield =>
            ResourceManager.GetString("Title_View_Yield", resourceCulture);

        internal static string Title_WB_Calibration =>
            ResourceManager.GetString("Title_WB_Calibration", resourceCulture);

        internal static string Title_WB_Calibration_Entry =>
            ResourceManager.GetString("Title_WB_Calibration_Entry", resourceCulture);

        internal static string Title_Yield =>
            ResourceManager.GetString("Title_Yield", resourceCulture);

        internal static string Token_001 =>
            ResourceManager.GetString("Token_001", resourceCulture);

        internal static string Token_002 =>
            ResourceManager.GetString("Token_002", resourceCulture);

        internal static string Token_003 =>
            ResourceManager.GetString("Token_003", resourceCulture);

        internal static string Token_004 =>
            ResourceManager.GetString("Token_004", resourceCulture);

        internal static string Token_005 =>
            ResourceManager.GetString("Token_005", resourceCulture);

        internal static string Token_006 =>
            ResourceManager.GetString("Token_006", resourceCulture);

        internal static string Token_007 =>
            ResourceManager.GetString("Token_007", resourceCulture);

        internal static string Token_008 =>
            ResourceManager.GetString("Token_008", resourceCulture);

        internal static string Token_009 =>
            ResourceManager.GetString("Token_009", resourceCulture);

        internal static string Token_010 =>
            ResourceManager.GetString("Token_010", resourceCulture);

        internal static string Token_011 =>
            ResourceManager.GetString("Token_011", resourceCulture);

        internal static string Token_012 =>
            ResourceManager.GetString("Token_012", resourceCulture);

        internal static string Token_013 =>
            ResourceManager.GetString("Token_013", resourceCulture);

        internal static string Token_014 =>
            ResourceManager.GetString("Token_014", resourceCulture);

        internal static string Token_015 =>
            ResourceManager.GetString("Token_015", resourceCulture);

        internal static string Token_016 =>
            ResourceManager.GetString("Token_016", resourceCulture);

        internal static string Token_017 =>
            ResourceManager.GetString("Token_017", resourceCulture);

        internal static string Token_018 =>
            ResourceManager.GetString("Token_018", resourceCulture);

        internal static string Token_019 =>
            ResourceManager.GetString("Token_019", resourceCulture);

        internal static string Tolerance =>
            ResourceManager.GetString("Tolerance", resourceCulture);

        internal static string Trans_001 =>
            ResourceManager.GetString("Trans_001", resourceCulture);

        internal static string Trans_002 =>
            ResourceManager.GetString("Trans_002", resourceCulture);

        internal static string Trans_003 =>
            ResourceManager.GetString("Trans_003", resourceCulture);

        internal static string Trans_004 =>
            ResourceManager.GetString("Trans_004", resourceCulture);

        internal static string Trans_005 =>
            ResourceManager.GetString("Trans_005", resourceCulture);

        internal static string Trans_006 =>
            ResourceManager.GetString("Trans_006", resourceCulture);

        internal static string Trans_007 =>
            ResourceManager.GetString("Trans_007", resourceCulture);

        internal static string Trans_008 =>
            ResourceManager.GetString("Trans_008", resourceCulture);

        internal static string Trans_009 =>
            ResourceManager.GetString("Trans_009", resourceCulture);

        internal static string Trans_010 =>
            ResourceManager.GetString("Trans_010", resourceCulture);

        internal static string Trans_011 =>
            ResourceManager.GetString("Trans_011", resourceCulture);

        internal static string Trans_012 =>
            ResourceManager.GetString("Trans_012", resourceCulture);

        internal static string Trans_013 =>
            ResourceManager.GetString("Trans_013", resourceCulture);

        internal static string Trans_014 =>
            ResourceManager.GetString("Trans_014", resourceCulture);

        internal static string Trans_015 =>
            ResourceManager.GetString("Trans_015", resourceCulture);

        internal static string Trans_016 =>
            ResourceManager.GetString("Trans_016", resourceCulture);

        internal static string Trans_017 =>
            ResourceManager.GetString("Trans_017", resourceCulture);

        internal static string Trans_018 =>
            ResourceManager.GetString("Trans_018", resourceCulture);

        internal static string Trans_019 =>
            ResourceManager.GetString("Trans_019", resourceCulture);

        internal static string Trans_020 =>
            ResourceManager.GetString("Trans_020", resourceCulture);

        internal static string Trans_021 =>
            ResourceManager.GetString("Trans_021", resourceCulture);

        internal static string Trans_022 =>
            ResourceManager.GetString("Trans_022", resourceCulture);

        internal static string Trans_023 =>
            ResourceManager.GetString("Trans_023", resourceCulture);

        internal static string Trans_024 =>
            ResourceManager.GetString("Trans_024", resourceCulture);

        internal static string Trans_025 =>
            ResourceManager.GetString("Trans_025", resourceCulture);

        internal static string Trans_026 =>
            ResourceManager.GetString("Trans_026", resourceCulture);

        internal static string Trans_027 =>
            ResourceManager.GetString("Trans_027", resourceCulture);

        internal static string Trans_028 =>
            ResourceManager.GetString("Trans_028", resourceCulture);

        internal static string Trans_029 =>
            ResourceManager.GetString("Trans_029", resourceCulture);

        internal static string Trans_030 =>
            ResourceManager.GetString("Trans_030", resourceCulture);

        internal static string Trans_031 =>
            ResourceManager.GetString("Trans_031", resourceCulture);

        internal static string Trans_032 =>
            ResourceManager.GetString("Trans_032", resourceCulture);

        internal static string Trans_033 =>
            ResourceManager.GetString("Trans_033", resourceCulture);

        internal static string Trans_034 =>
            ResourceManager.GetString("Trans_034", resourceCulture);

        internal static string Trans_035 =>
            ResourceManager.GetString("Trans_035", resourceCulture);

        internal static string Trans_036 =>
            ResourceManager.GetString("Trans_036", resourceCulture);

        internal static string Trans_037 =>
            ResourceManager.GetString("Trans_037", resourceCulture);

        internal static string Trans_038 =>
            ResourceManager.GetString("Trans_038", resourceCulture);

        internal static string Trans_039 =>
            ResourceManager.GetString("Trans_039", resourceCulture);

        internal static string Trans_040 =>
            ResourceManager.GetString("Trans_040", resourceCulture);

        internal static string Trans_041 =>
            ResourceManager.GetString("Trans_041", resourceCulture);

        internal static string Trans_042 =>
            ResourceManager.GetString("Trans_042", resourceCulture);

        internal static string Trans_043 =>
            ResourceManager.GetString("Trans_043", resourceCulture);

        internal static string Trans_044 =>
            ResourceManager.GetString("Trans_044", resourceCulture);

        internal static string Trans_045 =>
            ResourceManager.GetString("Trans_045", resourceCulture);

        internal static string Trans_046 =>
            ResourceManager.GetString("Trans_046", resourceCulture);

        internal static string Trans_047 =>
            ResourceManager.GetString("Trans_047", resourceCulture);

        internal static string Trans_048 =>
            ResourceManager.GetString("Trans_048", resourceCulture);

        internal static string Trans_049 =>
            ResourceManager.GetString("Trans_049", resourceCulture);

        internal static string Trans_050 =>
            ResourceManager.GetString("Trans_050", resourceCulture);

        internal static string Trans_051 =>
            ResourceManager.GetString("Trans_051", resourceCulture);

        internal static string Trans_052 =>
            ResourceManager.GetString("Trans_052", resourceCulture);

        internal static string Trans_053 =>
            ResourceManager.GetString("Trans_053", resourceCulture);

        internal static string Trans_054 =>
            ResourceManager.GetString("Trans_054", resourceCulture);

        internal static string Trans_055 =>
            ResourceManager.GetString("Trans_055", resourceCulture);

        internal static string Trans_056 =>
            ResourceManager.GetString("Trans_056", resourceCulture);

        internal static string Trans_057 =>
            ResourceManager.GetString("Trans_057", resourceCulture);

        internal static string Trans_058 =>
            ResourceManager.GetString("Trans_058", resourceCulture);

        internal static string Trans_059 =>
            ResourceManager.GetString("Trans_059", resourceCulture);

        internal static string Trans_060 =>
            ResourceManager.GetString("Trans_060", resourceCulture);

        internal static string Trans_061 =>
            ResourceManager.GetString("Trans_061", resourceCulture);

        internal static string Trans_062 =>
            ResourceManager.GetString("Trans_062", resourceCulture);

        internal static string Trans_063 =>
            ResourceManager.GetString("Trans_063", resourceCulture);

        internal static string Trans_064 =>
            ResourceManager.GetString("Trans_064", resourceCulture);

        internal static string Trans_065 =>
            ResourceManager.GetString("Trans_065", resourceCulture);

        internal static string Trans_066 =>
            ResourceManager.GetString("Trans_066", resourceCulture);

        internal static string Trans_067 =>
            ResourceManager.GetString("Trans_067", resourceCulture);

        internal static string Trans_068 =>
            ResourceManager.GetString("Trans_068", resourceCulture);

        internal static string Trans_069 =>
            ResourceManager.GetString("Trans_069", resourceCulture);

        internal static string Trans_070 =>
            ResourceManager.GetString("Trans_070", resourceCulture);

        internal static string Trans_071 =>
            ResourceManager.GetString("Trans_071", resourceCulture);

        internal static string Trans_072 =>
            ResourceManager.GetString("Trans_072", resourceCulture);

        internal static string Trans_073 =>
            ResourceManager.GetString("Trans_073", resourceCulture);

        internal static string Trans_074 =>
            ResourceManager.GetString("Trans_074", resourceCulture);

        internal static string Trans_075 =>
            ResourceManager.GetString("Trans_075", resourceCulture);

        internal static string Trans_076 =>
            ResourceManager.GetString("Trans_076", resourceCulture);

        internal static string Trans_077 =>
            ResourceManager.GetString("Trans_077", resourceCulture);

        internal static string Trans_078 =>
            ResourceManager.GetString("Trans_078", resourceCulture);

        internal static string Trans_079 =>
            ResourceManager.GetString("Trans_079", resourceCulture);

        internal static string Trans_080 =>
            ResourceManager.GetString("Trans_080", resourceCulture);

        internal static string Trans_081 =>
            ResourceManager.GetString("Trans_081", resourceCulture);

        internal static string Trans_082 =>
            ResourceManager.GetString("Trans_082", resourceCulture);

        internal static string Trans_083 =>
            ResourceManager.GetString("Trans_083", resourceCulture);

        internal static string Trans_084 =>
            ResourceManager.GetString("Trans_084", resourceCulture);

        internal static string Trans_085 =>
            ResourceManager.GetString("Trans_085", resourceCulture);

        internal static string Trans_086 =>
            ResourceManager.GetString("Trans_086", resourceCulture);

        internal static string Trans_087 =>
            ResourceManager.GetString("Trans_087", resourceCulture);

        internal static string Trans_088 =>
            ResourceManager.GetString("Trans_088", resourceCulture);

        internal static string Trans_089 =>
            ResourceManager.GetString("Trans_089", resourceCulture);

        internal static string Trans_090 =>
            ResourceManager.GetString("Trans_090", resourceCulture);

        internal static string Trans_091 =>
            ResourceManager.GetString("Trans_091", resourceCulture);

        internal static string Trans_092 =>
            ResourceManager.GetString("Trans_092", resourceCulture);

        internal static string Trans_093 =>
            ResourceManager.GetString("Trans_093", resourceCulture);

        internal static string Trans_094 =>
            ResourceManager.GetString("Trans_094", resourceCulture);

        internal static string Trans_095 =>
            ResourceManager.GetString("Trans_095", resourceCulture);

        internal static string Trans_096 =>
            ResourceManager.GetString("Trans_096", resourceCulture);

        internal static string Trans_097 =>
            ResourceManager.GetString("Trans_097", resourceCulture);

        internal static string Trans_098 =>
            ResourceManager.GetString("Trans_098", resourceCulture);

        internal static string Trans_099 =>
            ResourceManager.GetString("Trans_099", resourceCulture);

        internal static string Trans_100 =>
            ResourceManager.GetString("Trans_100", resourceCulture);

        internal static string Trans_101 =>
            ResourceManager.GetString("Trans_101", resourceCulture);

        internal static string Trans_102 =>
            ResourceManager.GetString("Trans_102", resourceCulture);

        internal static string Trans_103 =>
            ResourceManager.GetString("Trans_103", resourceCulture);

        internal static string Trans_104 =>
            ResourceManager.GetString("Trans_104", resourceCulture);

        internal static string Trans_105 =>
            ResourceManager.GetString("Trans_105", resourceCulture);

        internal static string Trans_106 =>
            ResourceManager.GetString("Trans_106", resourceCulture);

        internal static string Trans_107 =>
            ResourceManager.GetString("Trans_107", resourceCulture);

        internal static string Trans_108 =>
            ResourceManager.GetString("Trans_108", resourceCulture);

        internal static string Trans_109 =>
            ResourceManager.GetString("Trans_109", resourceCulture);

        internal static string Trans_110 =>
            ResourceManager.GetString("Trans_110", resourceCulture);

        internal static string Trans_111 =>
            ResourceManager.GetString("Trans_111", resourceCulture);

        internal static string Trans_112 =>
            ResourceManager.GetString("Trans_112", resourceCulture);

        internal static string Trans_113 =>
            ResourceManager.GetString("Trans_113", resourceCulture);

        internal static string Trans_114 =>
            ResourceManager.GetString("Trans_114", resourceCulture);

        internal static string Trans_115 =>
            ResourceManager.GetString("Trans_115", resourceCulture);

        internal static string TransDOContainer_001 =>
            ResourceManager.GetString("TransDOContainer_001", resourceCulture);

        internal static string TransDOContainer_002 =>
            ResourceManager.GetString("TransDOContainer_002", resourceCulture);

        internal static string TransDOContainer_003 =>
            ResourceManager.GetString("TransDOContainer_003", resourceCulture);

        internal static string TransDOContainer_004 =>
            ResourceManager.GetString("TransDOContainer_004", resourceCulture);

        internal static string Transporter_001 =>
            ResourceManager.GetString("Transporter_001", resourceCulture);

        internal static string Transporter_002 =>
            ResourceManager.GetString("Transporter_002", resourceCulture);

        internal static string Transporter_003 =>
            ResourceManager.GetString("Transporter_003", resourceCulture);

        internal static string Transporter_004 =>
            ResourceManager.GetString("Transporter_004", resourceCulture);

        internal static string Transporter_005 =>
            ResourceManager.GetString("Transporter_005", resourceCulture);

        internal static string Transporter_006 =>
            ResourceManager.GetString("Transporter_006", resourceCulture);

        internal static string Transporter_007 =>
            ResourceManager.GetString("Transporter_007", resourceCulture);

        internal static string Transporter_008 =>
            ResourceManager.GetString("Transporter_008", resourceCulture);

        internal static string Transporter_009 =>
            ResourceManager.GetString("Transporter_009", resourceCulture);

        internal static string Transporter_010 =>
            ResourceManager.GetString("Transporter_010", resourceCulture);

        internal static string TransType_001 =>
            ResourceManager.GetString("TransType_001", resourceCulture);

        internal static string TransType_002 =>
            ResourceManager.GetString("TransType_002", resourceCulture);

        internal static string TransType_003 =>
            ResourceManager.GetString("TransType_003", resourceCulture);

        internal static string TransType_004 =>
            ResourceManager.GetString("TransType_004", resourceCulture);

        internal static string TransType_005 =>
            ResourceManager.GetString("TransType_005", resourceCulture);

        internal static string TransType_006 =>
            ResourceManager.GetString("TransType_006", resourceCulture);

        internal static string Truck_001 =>
            ResourceManager.GetString("Truck_001", resourceCulture);

        internal static string Truck_002 =>
            ResourceManager.GetString("Truck_002", resourceCulture);

        internal static string Truck_003 =>
            ResourceManager.GetString("Truck_003", resourceCulture);

        internal static string Truck_004 =>
            ResourceManager.GetString("Truck_004", resourceCulture);

        internal static string Truck_005 =>
            ResourceManager.GetString("Truck_005", resourceCulture);

        internal static string Truck_006 =>
            ResourceManager.GetString("Truck_006", resourceCulture);

        internal static string Truck_007 =>
            ResourceManager.GetString("Truck_007", resourceCulture);

        internal static string Truck_008 =>
            ResourceManager.GetString("Truck_008", resourceCulture);

        internal static string Truck_009 =>
            ResourceManager.GetString("Truck_009", resourceCulture);

        internal static string Truck_010 =>
            ResourceManager.GetString("Truck_010", resourceCulture);

        internal static string Truck_011 =>
            ResourceManager.GetString("Truck_011", resourceCulture);

        internal static string Truck_012 =>
            ResourceManager.GetString("Truck_012", resourceCulture);

        internal static string Truck_013 =>
            ResourceManager.GetString("Truck_013", resourceCulture);

        internal static string Truck_014 =>
            ResourceManager.GetString("Truck_014", resourceCulture);

        internal static string Truck_015 =>
            ResourceManager.GetString("Truck_015", resourceCulture);

        internal static string Truck_016 =>
            ResourceManager.GetString("Truck_016", resourceCulture);

        internal static string Truck_017 =>
            ResourceManager.GetString("Truck_017", resourceCulture);

        internal static string Truck_018 =>
            ResourceManager.GetString("Truck_018", resourceCulture);

        internal static string Truck_019 =>
            ResourceManager.GetString("Truck_019", resourceCulture);

        internal static string Truck_020 =>
            ResourceManager.GetString("Truck_020", resourceCulture);

        internal static string Truck_021 =>
            ResourceManager.GetString("Truck_021", resourceCulture);

        internal static string Truck_022 =>
            ResourceManager.GetString("Truck_022", resourceCulture);

        internal static string Truck_023 =>
            ResourceManager.GetString("Truck_023", resourceCulture);

        internal static string Truck_Tare =>
            ResourceManager.GetString("Truck_Tare", resourceCulture);

        internal static string TruckE_001 =>
            ResourceManager.GetString("TruckE_001", resourceCulture);

        internal static string TruckE_002 =>
            ResourceManager.GetString("TruckE_002", resourceCulture);

        internal static string TruckE_003 =>
            ResourceManager.GetString("TruckE_003", resourceCulture);

        internal static string TruckE_004 =>
            ResourceManager.GetString("TruckE_004", resourceCulture);

        internal static string TruckE_005 =>
            ResourceManager.GetString("TruckE_005", resourceCulture);

        internal static string TruckE_006 =>
            ResourceManager.GetString("TruckE_006", resourceCulture);

        internal static string TruckE_007 =>
            ResourceManager.GetString("TruckE_007", resourceCulture);

        internal static string TruckE_008 =>
            ResourceManager.GetString("TruckE_008", resourceCulture);

        internal static string TruckE_009 =>
            ResourceManager.GetString("TruckE_009", resourceCulture);

        internal static string TruckE_010 =>
            ResourceManager.GetString("TruckE_010", resourceCulture);

        internal static string TruckE_011 =>
            ResourceManager.GetString("TruckE_011", resourceCulture);

        internal static string TruckE_012 =>
            ResourceManager.GetString("TruckE_012", resourceCulture);

        internal static string TruckE_013 =>
            ResourceManager.GetString("TruckE_013", resourceCulture);

        internal static string TruckE_014 =>
            ResourceManager.GetString("TruckE_014", resourceCulture);

        internal static string TruckE_015 =>
            ResourceManager.GetString("TruckE_015", resourceCulture);

        internal static string TruckE_016 =>
            ResourceManager.GetString("TruckE_016", resourceCulture);

        internal static string TruckE_017 =>
            ResourceManager.GetString("TruckE_017", resourceCulture);

        internal static string TruckE_018 =>
            ResourceManager.GetString("TruckE_018", resourceCulture);

        internal static string TruckE_019 =>
            ResourceManager.GetString("TruckE_019", resourceCulture);

        internal static string TruckE_020 =>
            ResourceManager.GetString("TruckE_020", resourceCulture);

        internal static string TruckE_021 =>
            ResourceManager.GetString("TruckE_021", resourceCulture);

        internal static string TruckE_022 =>
            ResourceManager.GetString("TruckE_022", resourceCulture);

        internal static string TruckE_023 =>
            ResourceManager.GetString("TruckE_023", resourceCulture);

        internal static string TruckE_024 =>
            ResourceManager.GetString("TruckE_024", resourceCulture);

        internal static string TruckEntry_001 =>
            ResourceManager.GetString("TruckEntry_001", resourceCulture);

        internal static string TruckEntry_002 =>
            ResourceManager.GetString("TruckEntry_002", resourceCulture);

        internal static string TruckEntry_003 =>
            ResourceManager.GetString("TruckEntry_003", resourceCulture);

        internal static string TruckEntry_004 =>
            ResourceManager.GetString("TruckEntry_004", resourceCulture);

        internal static string TruckEntry_005 =>
            ResourceManager.GetString("TruckEntry_005", resourceCulture);

        internal static string TruckEntry_006 =>
            ResourceManager.GetString("TruckEntry_006", resourceCulture);

        internal static string TruckEntry_007 =>
            ResourceManager.GetString("TruckEntry_007", resourceCulture);

        internal static string TruckEntry_008 =>
            ResourceManager.GetString("TruckEntry_008", resourceCulture);

        internal static string TruckEntry_009 =>
            ResourceManager.GetString("TruckEntry_009", resourceCulture);

        internal static string TruckEntry_010 =>
            ResourceManager.GetString("TruckEntry_010", resourceCulture);

        internal static string TruckEntry_011 =>
            ResourceManager.GetString("TruckEntry_011", resourceCulture);

        internal static string Ttp_Btn_Adopt =>
            ResourceManager.GetString("Ttp_Btn_Adopt", resourceCulture);

        internal static string Ttp_Btn_Adopt_2 =>
            ResourceManager.GetString("Ttp_Btn_Adopt_2", resourceCulture);

        internal static string Ttp_Btn_Commodity =>
            ResourceManager.GetString("Ttp_Btn_Commodity", resourceCulture);

        internal static string Ttp_Btn_Estate =>
            ResourceManager.GetString("Ttp_Btn_Estate", resourceCulture);

        internal static string Ttp_Btn_Grading =>
            ResourceManager.GetString("Ttp_Btn_Grading", resourceCulture);

        internal static string Ttp_Btn_Save =>
            ResourceManager.GetString("Ttp_Btn_Save", resourceCulture);

        internal static string Ttp_Btn_Transporter =>
            ResourceManager.GetString("Ttp_Btn_Transporter", resourceCulture);

        internal static string Ttp_Btn_Type =>
            ResourceManager.GetString("Ttp_Btn_Type", resourceCulture);

        internal static string Ttp_Btn_Vendor =>
            ResourceManager.GetString("Ttp_Btn_Vendor", resourceCulture);

        internal static string Ttp_Chk_Adopt_SAP =>
            ResourceManager.GetString("Ttp_Chk_Adopt_SAP", resourceCulture);

        internal static string Ttp_Chk_Is_Vessel =>
            ResourceManager.GetString("Ttp_Chk_Is_Vessel", resourceCulture);

        internal static string Ttp_Chk_ISSC =>
            ResourceManager.GetString("Ttp_Chk_ISSC", resourceCulture);

        internal static string Ttp_Chk_Period =>
            ResourceManager.GetString("Ttp_Chk_Period", resourceCulture);

        internal static string Ttp_Deduc_By =>
            ResourceManager.GetString("Ttp_Deduc_By", resourceCulture);

        internal static string Ttp_Deduc_By_2 =>
            ResourceManager.GetString("Ttp_Deduc_By_2", resourceCulture);

        internal static string Ttp_Deduc_By_3 =>
            ResourceManager.GetString("Ttp_Deduc_By_3", resourceCulture);

        internal static string Ttp_DO_Mapped_Details =>
            ResourceManager.GetString("Ttp_DO_Mapped_Details", resourceCulture);

        internal static string Ttp_Dtp_DO_Period =>
            ResourceManager.GetString("Ttp_Dtp_DO_Period", resourceCulture);

        internal static string Ttp_Gbx_Deducted =>
            ResourceManager.GetString("Ttp_Gbx_Deducted", resourceCulture);

        internal static string Ttp_Gbx_Deducted_2 =>
            ResourceManager.GetString("Ttp_Gbx_Deducted_2", resourceCulture);

        internal static string Ttp_Gbx_Entry =>
            ResourceManager.GetString("Ttp_Gbx_Entry", resourceCulture);

        internal static string Ttp_Gbx_Fruit =>
            ResourceManager.GetString("Ttp_Gbx_Fruit", resourceCulture);

        internal static string Ttp_IOX =>
            ResourceManager.GetString("Ttp_IOX", resourceCulture);

        internal static string Ttp_Must_Adopt =>
            ResourceManager.GetString("Ttp_Must_Adopt", resourceCulture);

        internal static string Ttp_Tab_Sugar =>
            ResourceManager.GetString("Ttp_Tab_Sugar", resourceCulture);

        internal static string Ttp_Txt_Remark =>
            ResourceManager.GetString("Ttp_Txt_Remark", resourceCulture);

        internal static string Ttp_Txt_Tolerance =>
            ResourceManager.GetString("Ttp_Txt_Tolerance", resourceCulture);

        internal static string Ttp_Txt_Unit =>
            ResourceManager.GetString("Ttp_Txt_Unit", resourceCulture);

        internal static string Txt_Token_No =>
            ResourceManager.GetString("Txt_Token_No", resourceCulture);

        internal static string Txt_Unit_Name_Bunch =>
            ResourceManager.GetString("Txt_Unit_Name_Bunch", resourceCulture);

        internal static string Txt_Warning_Max_Edit =>
            ResourceManager.GetString("Txt_Warning_Max_Edit", resourceCulture);

        internal static string Upload_001 =>
            ResourceManager.GetString("Upload_001", resourceCulture);

        internal static string Upload_002 =>
            ResourceManager.GetString("Upload_002", resourceCulture);

        internal static string Upload_003 =>
            ResourceManager.GetString("Upload_003", resourceCulture);

        internal static string Upload_004 =>
            ResourceManager.GetString("Upload_004", resourceCulture);

        internal static string Upload_005 =>
            ResourceManager.GetString("Upload_005", resourceCulture);

        internal static string Upload_006 =>
            ResourceManager.GetString("Upload_006", resourceCulture);

        internal static string Upload_007 =>
            ResourceManager.GetString("Upload_007", resourceCulture);

        internal static string Upload_008 =>
            ResourceManager.GetString("Upload_008", resourceCulture);

        internal static string Upload_009 =>
            ResourceManager.GetString("Upload_009", resourceCulture);

        internal static string Upload_010 =>
            ResourceManager.GetString("Upload_010", resourceCulture);

        internal static string Upload_011 =>
            ResourceManager.GetString("Upload_011", resourceCulture);

        internal static string UploadType_001 =>
            ResourceManager.GetString("UploadType_001", resourceCulture);

        internal static string UploadType_002 =>
            ResourceManager.GetString("UploadType_002", resourceCulture);

        internal static string UploadType_003 =>
            ResourceManager.GetString("UploadType_003", resourceCulture);

        internal static string UploadType_004 =>
            ResourceManager.GetString("UploadType_004", resourceCulture);

        internal static string User_001 =>
            ResourceManager.GetString("User_001", resourceCulture);

        internal static string User_002 =>
            ResourceManager.GetString("User_002", resourceCulture);

        internal static string User_003 =>
            ResourceManager.GetString("User_003", resourceCulture);

        internal static string User_004 =>
            ResourceManager.GetString("User_004", resourceCulture);

        internal static string User_005 =>
            ResourceManager.GetString("User_005", resourceCulture);

        internal static string User_006 =>
            ResourceManager.GetString("User_006", resourceCulture);

        internal static string User_007 =>
            ResourceManager.GetString("User_007", resourceCulture);

        internal static string User_008 =>
            ResourceManager.GetString("User_008", resourceCulture);

        internal static string User_009 =>
            ResourceManager.GetString("User_009", resourceCulture);

        internal static string User_010 =>
            ResourceManager.GetString("User_010", resourceCulture);

        internal static string User_011 =>
            ResourceManager.GetString("User_011", resourceCulture);

        internal static string User_012 =>
            ResourceManager.GetString("User_012", resourceCulture);

        internal static string UserGroup_001 =>
            ResourceManager.GetString("UserGroup_001", resourceCulture);

        internal static string UserGroup_002 =>
            ResourceManager.GetString("UserGroup_002", resourceCulture);

        internal static string UserGroup_003 =>
            ResourceManager.GetString("UserGroup_003", resourceCulture);

        internal static string UserGroup_004 =>
            ResourceManager.GetString("UserGroup_004", resourceCulture);

        internal static string UserGroup_005 =>
            ResourceManager.GetString("UserGroup_005", resourceCulture);

        internal static string UserGroup_006 =>
            ResourceManager.GetString("UserGroup_006", resourceCulture);

        internal static string UserGroup_007 =>
            ResourceManager.GetString("UserGroup_007", resourceCulture);

        internal static string UserGroup_008 =>
            ResourceManager.GetString("UserGroup_008", resourceCulture);

        internal static string UserGroup_009 =>
            ResourceManager.GetString("UserGroup_009", resourceCulture);

        internal static string UserGroup_010 =>
            ResourceManager.GetString("UserGroup_010", resourceCulture);

        internal static string UserGroup_011 =>
            ResourceManager.GetString("UserGroup_011", resourceCulture);

        internal static string UserGroup_012 =>
            ResourceManager.GetString("UserGroup_012", resourceCulture);

        internal static string UserGroup_013 =>
            ResourceManager.GetString("UserGroup_013", resourceCulture);

        internal static string UserGroup_014 =>
            ResourceManager.GetString("UserGroup_014", resourceCulture);

        internal static string VendorE_001 =>
            ResourceManager.GetString("VendorE_001", resourceCulture);

        internal static string VendorE_002 =>
            ResourceManager.GetString("VendorE_002", resourceCulture);

        internal static string VendorE_003 =>
            ResourceManager.GetString("VendorE_003", resourceCulture);

        internal static string VendorE_004 =>
            ResourceManager.GetString("VendorE_004", resourceCulture);

        internal static string VendorE_005 =>
            ResourceManager.GetString("VendorE_005", resourceCulture);

        internal static string VendorE_006 =>
            ResourceManager.GetString("VendorE_006", resourceCulture);

        internal static string VendorE_007 =>
            ResourceManager.GetString("VendorE_007", resourceCulture);

        internal static string VendorE_008 =>
            ResourceManager.GetString("VendorE_008", resourceCulture);

        internal static string VendorE_009 =>
            ResourceManager.GetString("VendorE_009", resourceCulture);

        internal static string VendorE_010 =>
            ResourceManager.GetString("VendorE_010", resourceCulture);

        internal static string VendorE_011 =>
            ResourceManager.GetString("VendorE_011", resourceCulture);

        internal static string VendorE_012 =>
            ResourceManager.GetString("VendorE_012", resourceCulture);

        internal static string VendorE_013 =>
            ResourceManager.GetString("VendorE_013", resourceCulture);

        internal static string VendorE_014 =>
            ResourceManager.GetString("VendorE_014", resourceCulture);

        internal static string VendorE_015 =>
            ResourceManager.GetString("VendorE_015", resourceCulture);

        internal static string WBMANUAL_MANUAL_CODE_NOT_MAINTAINED =>
            ResourceManager.GetString("WBMANUAL_MANUAL_CODE_NOT_MAINTAINED", resourceCulture);

        internal static string WBMANUAL_MANUAL_DOCUMENT_NOT_FOUND =>
            ResourceManager.GetString("WBMANUAL_MANUAL_DOCUMENT_NOT_FOUND", resourceCulture);

        internal static string Yield_001 =>
            ResourceManager.GetString("Yield_001", resourceCulture);

        internal static string Yield_002 =>
            ResourceManager.GetString("Yield_002", resourceCulture);

        internal static string Yield_003 =>
            ResourceManager.GetString("Yield_003", resourceCulture);

        internal static string Yield_004 =>
            ResourceManager.GetString("Yield_004", resourceCulture);

        internal static string Yield_005 =>
            ResourceManager.GetString("Yield_005", resourceCulture);
    }
}

