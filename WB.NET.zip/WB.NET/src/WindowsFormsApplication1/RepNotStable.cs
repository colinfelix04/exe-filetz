﻿namespace WindowsFormsApplication1
{
    using CrystalDecisions.CrystalReports.Engine;
    using CrystalDecisions.Shared;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class RepNotStable : Form
    {
        public string zAuto = "0";
        private IContainer components = null;
        public GroupBox groupBox1;
        public DateTimePicker monthCalendar1;
        public Label label5;
        public Label label6;
        public DateTimePicker monthCalendar2;
        public Button button2;
        public Button button1;

        public RepNotStable()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.monthCalendar2.Value <= this.monthCalendar1.Value)
            {
                MessageBox.Show("Date To Must be Greater than Date From.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                this.initTable(this.monthCalendar1.Value, this.monthCalendar2.Value, "0");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.groupBox1 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label5 = new Label();
            this.label6 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.button2 = new Button();
            this.button1 = new Button();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.groupBox1.Controls.Add(this.monthCalendar1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.monthCalendar2);
            this.groupBox1.Location = new Point(10, 0x20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x178, 0x2d);
            this.groupBox1.TabIndex = 0x59;
            this.groupBox1.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(80, 0x10);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(8, 0x13);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x3e, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "From Date :";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xc6, 0x13);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x34, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x100, 0x10);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1ca, 0x4c);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x22);
            this.button2.TabIndex = 0x58;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x1ca, 0x1d);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x22);
            this.button1.TabIndex = 0x57;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(590, 0x8f);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Name = "RepNotStable";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Indicator Not Stable Report";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
        }

        public void initTable(DateTime dateFrom, DateTime dateTo, string zAuto)
        {
            DateTime time;
            WBTable table = new WBTable();
            string sqltext = "select WX, date1, date2, date3, date4, wbcode1, wbcode2, wbcode3, wbcode4, left(transwarning,1) as [T1], substring(transwarning,2,1) as [T2], case(wx)when '2X' then '' else substring(transwarning, 3, 1) end as [T3], case(wx)when '2X' then '' else substring(transwarning, 4, 1) end as [T4] from wb_transaction where transwarning is not null ";
            string[] textArray1 = new string[] { sqltext, " AND report_date >= '", dateFrom.ToString("yyyy-MM-dd"), "' AND report_date <= '", dateTo.ToString("yyyy-MM-dd"), "'" };
            sqltext = string.Concat(textArray1);
            table.OpenTable("wb_transaction", sqltext, WBData.conn);
            WBTable table2 = new WBTable();
            sqltext = "select WX, date1, date2, date3, date4, wbcode1, wbcode2, wbcode3, wbcode4, left(transwarning,1) as [T1], substring(transwarning,2,1) as [T2], case(wx)when '2X' then '' else substring(transwarning, 3, 1) end as [T3], case(wx)when '2X' then '' else substring(transwarning, 4, 1) end as [T4] from wb_transaction where transwarning is not null ";
            string[] textArray2 = new string[] { sqltext, " AND (report_date is null or report_date > '", dateTo.ToString("yyyy-MM-dd"), "') and ((date1 >= '", dateFrom.ToString("yyyy-MM-dd"), "' AND date1 <= '", dateTo.ToString("yyyy-MM-dd"), "') OR " };
            sqltext = string.Concat(textArray2);
            string[] textArray3 = new string[14];
            textArray3[0] = sqltext;
            textArray3[1] = "(date2 >= '";
            textArray3[2] = dateFrom.ToString("yyyy-MM-dd");
            textArray3[3] = "' AND date2 <= '";
            textArray3[4] = dateTo.ToString("yyyy-MM-dd");
            textArray3[5] = "') OR (date3 >= '";
            textArray3[6] = dateFrom.ToString("yyyy-MM-dd");
            textArray3[7] = "' AND date3 <= '";
            textArray3[8] = dateTo.ToString("yyyy-MM-dd");
            textArray3[9] = "') OR (date4 >= '";
            textArray3[10] = dateFrom.ToString("yyyy-MM-dd");
            textArray3[11] = "' AND date4 <= '";
            textArray3[12] = dateTo.ToString("yyyy-MM-dd");
            textArray3[13] = "'))";
            sqltext = string.Concat(textArray3);
            table2.OpenTable("wb_transaction", sqltext, WBData.conn);
            WBTable table3 = new WBTable();
            table3.OpenTable("wb_setting", "SELECT DISTINCT(wbcode) AS wbcode FROM wb_setting WHERE UsedforWeighing = 'Y'", WBData.conn);
            string[,] strArray = new string[table3.DT.Rows.Count * Convert.ToInt16((double) ((dateTo - dateFrom).TotalDays + 1.0)), 4];
            int num = 0;
            foreach (DataRow row in table3.DT.Rows)
            {
                DateTime time2 = dateFrom;
                while (true)
                {
                    if (time2 > dateTo)
                    {
                        break;
                    }
                    strArray[num, 0] = row["wbcode"].ToString();
                    strArray[num, 1] = time2.ToString("yyyy-MM-dd");
                    strArray[num, 2] = "0";
                    strArray[num, 3] = "0";
                    num++;
                    time2 = time2.AddDays(1.0);
                }
            }
            table3.Dispose();
            if (table.DT.Rows.Count != 0)
            {
                foreach (DataRow row2 in table.DT.Rows)
                {
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 > 4)
                        {
                            break;
                        }
                        if (row2["Date" + num2].ToString() != "")
                        {
                            time = Convert.ToDateTime(row2["Date" + num2].ToString());
                            if ((time >= dateFrom) || (time <= dateTo))
                            {
                                long num3 = 0L;
                                while (true)
                                {
                                    if (num3 < strArray.GetLength(0))
                                    {
                                        if ((strArray[(int) ((IntPtr) num3), 0] != row2["wbcode" + num2].ToString()) || (strArray[(int) ((IntPtr) num3), 1] != time.ToString("yyyy-MM-dd")))
                                        {
                                            num3 += 1L;
                                            continue;
                                        }
                                        if (row2["T" + num2].ToString() == "1")
                                        {
                                            strArray[(int) ((IntPtr) num3), 2] = (Program.StrToDouble(strArray[(int) ((IntPtr) num3), 2], 0) + 1.0).ToString();
                                        }
                                        strArray[(int) ((IntPtr) num3), 3] = (Program.StrToDouble(strArray[(int) ((IntPtr) num3), 3], 0) + 1.0).ToString();
                                    }
                                    break;
                                }
                            }
                        }
                        num2++;
                    }
                }
            }
            if (table2.DT.Rows.Count != 0)
            {
                foreach (DataRow row3 in table2.DT.Rows)
                {
                    int num5 = 1;
                    while (true)
                    {
                        if (num5 > 4)
                        {
                            break;
                        }
                        if (row3["Date" + num5].ToString() != "")
                        {
                            time = Convert.ToDateTime(row3["Date" + num5].ToString());
                            if ((time >= dateFrom) || (time <= dateTo))
                            {
                                long num6 = 0L;
                                while (true)
                                {
                                    if (num6 < strArray.GetLength(0))
                                    {
                                        if ((strArray[(int) ((IntPtr) num6), 0] != row3["wbcode" + num5].ToString()) || (strArray[(int) ((IntPtr) num6), 1] != time.ToString("yyyy-MM-dd")))
                                        {
                                            num6 += 1L;
                                            continue;
                                        }
                                        if (row3["T" + num5].ToString() == "1")
                                        {
                                            strArray[(int) ((IntPtr) num6), 2] = (Program.StrToDouble(strArray[(int) ((IntPtr) num6), 2], 0) + 1.0).ToString();
                                        }
                                        strArray[(int) ((IntPtr) num6), 3] = (Program.StrToDouble(strArray[(int) ((IntPtr) num6), 3], 0) + 1.0).ToString();
                                    }
                                    break;
                                }
                            }
                        }
                        num5++;
                    }
                }
            }
            table.Dispose();
            table2.Dispose();
            DataSet1 set = new DataSet1();
            DataTable table4 = set.Tables[0];
            int num7 = 0;
            while (true)
            {
                if (num7 >= strArray.GetLength(0))
                {
                    if (zAuto == "0")
                    {
                        NotStable stable = new NotStable();
                        stable.DataSourceConnections.Clear();
                        stable.SetDataSource((DataSet) set);
                        FormRpt rpt = new FormRpt {
                            crystalReportViewer1 = { ReportSource = stable }
                        };
                        rpt.ShowDialog();
                        rpt.Dispose();
                    }
                    else if (zAuto == "1")
                    {
                        ReportDocument document = new ReportDocument();
                        document.Load(Application.StartupPath + @"\NotStable.rpt");
                        document.SetDataSource((DataSet) set);
                        string[] textArray4 = new string[] { Application.UserAppDataPath, @"\LogReport\INDICATOR_STABILITY_GRAPH_", dateFrom.ToString("ddMMyyyy"), "_", dateTo.ToString("ddMMyyyy"), ".pdf" };
                        document.ExportToDisk(ExportFormatType.PortableDocFormat, string.Concat(textArray4));
                        document.Dispose();
                    }
                    return;
                }
                DataRow row4 = table4.NewRow();
                row4["WBCODE"] = strArray[num7, 0];
                row4["Date"] = strArray[num7, 1];
                row4["Not Stable"] = strArray[num7, 2];
                row4["Weighing"] = strArray[num7, 3];
                table4.Rows.Add(row4);
                num7++;
            }
        }
    }
}

