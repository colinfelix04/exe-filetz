﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class RepTolerance : Form
    {
        public string tipe;
        public string kb;
        private WBTable tbl_Do;
        private WBTable tbl_Transport;
        private WBTable tbl_TransType;
        private WBTable tbl_Driver;
        private WBTable tbl_Comm;
        private WBTable tblTruck;
        private DataRow DRComm;
        private IContainer components = null;
        public Label labelRecNo;
        public Label labelProcess;
        public Button btnClose;
        public Button btnProcess;
        private ComboBox ComboComm;
        public Button buttonDoNo;
        public Label labelDoNo;
        public TextBox textDoNo;
        public Button buttonComm;
        public Label labelCommName;
        public TextBox textCommodity;
        public Label labelcommodity;
        private ComboBox comboDO;
        public GroupBox grKB;
        public RadioButton rboNonKB;
        public RadioButton rboKB;
        public GroupBox groupDate;
        public DateTimePicker monthCalendar1;
        public Label label1;
        public Label label2;
        public DateTimePicker monthCalendar2;
        public Button buttonDriver;
        public Label label5;
        public TextBox textDriver;
        public Button buttonTruck;
        public TextBox textTruck;
        public Label label7;
        public Button buttonTransporter;
        public Label label4;
        public TextBox textTransport;
        private Label labelTransTypeName;
        private Button buttonType;
        private TextBox textType;
        private Label label9;
        public Label label3;
        private Panel panel1;
        private CheckBox cBoxPISI;
        private CheckBox checkRmkTicket;
        private CheckBox cbAddInfo;
        private CheckBox cBoxDate;
        private CheckBox cBoxRef;

        public RepTolerance()
        {
            this.InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                WBTable table = new WBTable();
                string sqltext = ((("Select * From vw_trans where " + WBData.CompanyLocation("")) + " and ((report_Date>='" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00'") + " and report_Date<='" + this.monthCalendar2.Value.ToString("yyyy-MM-dd") + " 00:00:00'))") + " and IO = 'O' and bulkPack = 'P' ";
                if (this.textCommodity.Text.Trim() != "")
                {
                    sqltext = sqltext + " and (Comm_Code='" + this.textCommodity.Text.Trim() + "'";
                    int num3 = 1;
                    while (true)
                    {
                        if (num3 >= this.ComboComm.Items.Count)
                        {
                            sqltext = sqltext + ") ";
                            break;
                        }
                        sqltext = sqltext + " or comm_code = '" + this.ComboComm.Items[num3].ToString() + "' ";
                        num3++;
                    }
                }
                sqltext = !this.rboKB.Checked ? (sqltext + " and berikat='N' ") : (sqltext + " and berikat='Y' ");
                if (this.textTransport.Text.Trim() != "")
                {
                    sqltext = sqltext + " and Transporter_Code='" + this.textTransport.Text.Trim() + "'";
                }
                if (this.textDoNo.Text.Trim() != "")
                {
                    sqltext = sqltext + " and Do_No='" + this.textDoNo.Text.Trim() + "'";
                }
                if (this.textType.Text.Trim() != "")
                {
                    sqltext = sqltext + " and transaction_code = '" + this.textType.Text + "' ";
                }
                if (this.textTruck.Text.Trim() != "")
                {
                    sqltext = sqltext + " and Truck_NUmber='" + this.textTruck.Text.Trim() + "'";
                }
                sqltext = sqltext + " and (deleted is null or deleted = 'N') Order By Comm_Code,Ref Asc";
                table.OpenTable("view", sqltext, WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    HTML html = new HTML();
                    html.File = html.File + @"\" + WBUser.UserID + "_ToleranceProduct.htm";
                    html.Title = "Tolerance Product";
                    html.Open();
                    html.Write(html.Style());
                    html.Write("<br><font size=5><b>TOLERANCE PRODUCT</b></font><br>");
                    string[] textArray1 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                    html.Write(string.Concat(textArray1));
                    string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                    html.Write(string.Concat(textArray2));
                    if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                    {
                        html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                    }
                    if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                    {
                        html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                    }
                    if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                    {
                        html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                    }
                    html.Write("<br><br>");
                    html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                    html.Write("<tr class=bd>");
                    html.Write("<td>Selected Date</td>");
                    string[] textArray3 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                    html.Write(string.Concat(textArray3));
                    html.Write("</tr>");
                    html.Write("<tr class=bd>");
                    html.Write("<td>Report Date</td>");
                    html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                    html.Write("</tr>");
                    html.Write("</table>");
                    html.Write("<br/><br/><br/>");
                    html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                    html.Write("<tr class='bd'>");
                    html.Write("<td nowrap>No.</td>");
                    html.Write("<td nowrap>SO</td>");
                    if (this.cBoxRef.Checked)
                    {
                        html.Write("<td nowrap>REF NO.</td>");
                    }
                    if (this.cBoxDate.Checked)
                    {
                        html.Write("<td nowrap>REPORT DATE</td>");
                    }
                    html.Write("<td nowrap>PLAT NO.</td>");
                    html.Write("<td nowrap>COMMODITY NAME</td>");
                    if (this.cbAddInfo.Checked)
                    {
                        html.Write("<td nowrap>ADDITIONAL INFO</td>");
                    }
                    if (this.cBoxPISI.Checked)
                    {
                        html.Write("<td nowrap>PI/SI</td>");
                    }
                    html.Write("<td nowrap>GROSS WEIGHT</td>");
                    html.Write("<td nowrap>NETTO WB</td>");
                    html.Write("<td nowrap>DIFF (+/-)</td>");
                    html.Write("<td nowrap>DIFF (%)</td>");
                    if (this.checkRmkTicket.Checked)
                    {
                        html.Write("<td nowrap>REMARK</td>");
                    }
                    html.Write("</tr>");
                    int num2 = 1;
                    foreach (DataRow row in table.DT.Rows)
                    {
                        double num5;
                        this.labelRecNo.Text = num2.ToString() + "/" + table.DT.Rows.Count;
                        this.labelProcess.Refresh();
                        html.Write("<tr class='bd'>");
                        html.Write("<td nowrap>" + html.strq(num2.ToString()) + "</td>");
                        html.Write("<td nowrap>" + html.strq(row["do_no"].ToString()) + "</td>");
                        if (this.cBoxRef.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(row["ref"].ToString()) + "</td>");
                        }
                        if (this.cBoxDate.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(row["report_date"].ToString()) + "</td>");
                        }
                        html.Write("<td nowrap>" + html.strq(row["truck_number"].ToString()) + "</td>");
                        html.Write("<td nowrap>" + html.strq(row["comm_name"].ToString()) + "</td>");
                        if (this.cbAddInfo.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(row["Addi_info"].ToString()) + "</td>");
                        }
                        if (this.cBoxPISI.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(row["PI_No"].ToString()) + "</td>");
                        }
                        try
                        {
                            num5 = Convert.ToDouble(row["gross_weight"].ToString()) * Convert.ToDouble(row["loading_Qty"].ToString());
                        }
                        catch
                        {
                            num5 = 0.0;
                        }
                        html.Write("<td nowrap>" + num5 + "</td>");
                        html.Write("<td nowrap>" + html.strq(row["netto"].ToString()) + "</td>");
                        num5 = Convert.ToDouble(row["netto"].ToString()) - num5;
                        html.Write("<td nowrap>" + Math.Round(num5, 2) + "</td>");
                        if (num5 < 0.0)
                        {
                            num5 *= -1.0;
                        }
                        double num6 = (num5 / Convert.ToDouble(row["netto"].ToString())) * 100.0;
                        html.Write("<td nowrap>" + Math.Round(num6, 2) + "</td>");
                        if (this.checkRmkTicket.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(row["remark_ticket"].ToString()) + "</td>");
                        }
                        html.Write("</tr>");
                        num2++;
                    }
                    html.Write("</table>");
                    html.Write("<br>");
                    html.Write("<br>");
                    html.writeSign();
                    html.Close();
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + html.File) }
                    };
                    report.ShowDialog();
                    html.Dispose();
                    report.Dispose();
                }
            }
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
                this.textCommodity.Focus();
            }
            commodity.Dispose();
        }

        private void buttonDoNo_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFind = this.textDoNo.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDoNo.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        private void buttonDriver_Click(object sender, EventArgs e)
        {
            FormDriver driver = new FormDriver {
                pMode = "CHOOSE"
            };
            driver.ShowDialog();
            if (driver.ReturnRow != null)
            {
                this.textDriver.Text = driver.ReturnRow["License_No"].ToString();
                this.textDriver.Focus();
            }
            driver.Dispose();
        }

        private void buttonTransporter_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransport.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.textTransport.Focus();
            }
            transporter.Dispose();
        }

        private void buttonTruck_Click(object sender, EventArgs e)
        {
            FormTruck truck = new FormTruck {
                pMode = "CHOOSE",
                pFind = this.textTruck.Text
            };
            truck.ShowDialog();
            this.textTruck.Text = truck.ReturnRow["Truck_Number"].ToString();
            truck.Dispose();
        }

        private void buttonType_Click(object sender, EventArgs e)
        {
            FormTransType type = new FormTransType {
                pMode = "CHOOSE"
            };
            type.ShowDialog();
            if (type.ReturnRow != null)
            {
                this.textType.Text = type.ReturnRow["Transaction_Code"].ToString();
                this.labelTransTypeName.Text = type.ReturnRow["Transaction_Name"].ToString();
            }
            type.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.btnClose = new Button();
            this.btnProcess = new Button();
            this.ComboComm = new ComboBox();
            this.buttonDoNo = new Button();
            this.labelDoNo = new Label();
            this.textDoNo = new TextBox();
            this.buttonComm = new Button();
            this.labelCommName = new Label();
            this.textCommodity = new TextBox();
            this.labelcommodity = new Label();
            this.comboDO = new ComboBox();
            this.grKB = new GroupBox();
            this.rboNonKB = new RadioButton();
            this.rboKB = new RadioButton();
            this.groupDate = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label1 = new Label();
            this.label2 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.buttonDriver = new Button();
            this.label5 = new Label();
            this.textDriver = new TextBox();
            this.buttonTruck = new Button();
            this.textTruck = new TextBox();
            this.label7 = new Label();
            this.buttonTransporter = new Button();
            this.label4 = new Label();
            this.textTransport = new TextBox();
            this.labelTransTypeName = new Label();
            this.buttonType = new Button();
            this.textType = new TextBox();
            this.label9 = new Label();
            this.label3 = new Label();
            this.panel1 = new Panel();
            this.cbAddInfo = new CheckBox();
            this.cBoxPISI = new CheckBox();
            this.checkRmkTicket = new CheckBox();
            this.cBoxRef = new CheckBox();
            this.cBoxDate = new CheckBox();
            this.grKB.SuspendLayout();
            this.groupDate.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x272, 0x12);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 90;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x1da, 0x12);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 0x59;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.btnClose.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btnClose.Location = new Point(0x22a, 0x81);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new Size(110, 0x37);
            this.btnClose.TabIndex = 0x58;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new EventHandler(this.btnClose_Click);
            this.btnProcess.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btnProcess.Location = new Point(0x22a, 60);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new Size(110, 0x38);
            this.btnProcess.TabIndex = 0x57;
            this.btnProcess.Text = "Process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new EventHandler(this.btnProcess_Click);
            this.ComboComm.FormattingEnabled = true;
            this.ComboComm.Location = new Point(0x166, 0xa9);
            this.ComboComm.Name = "ComboComm";
            this.ComboComm.Size = new Size(0xbf, 0x15);
            this.ComboComm.TabIndex = 0x65;
            this.ComboComm.Visible = false;
            this.buttonDoNo.Location = new Point(0x113, 0xc1);
            this.buttonDoNo.Margin = new Padding(0);
            this.buttonDoNo.Name = "buttonDoNo";
            this.buttonDoNo.Size = new Size(0x17, 0x17);
            this.buttonDoNo.TabIndex = 0x5f;
            this.buttonDoNo.Text = "...";
            this.buttonDoNo.UseVisualStyleBackColor = true;
            this.buttonDoNo.Click += new EventHandler(this.buttonDoNo_Click);
            this.labelDoNo.AutoSize = true;
            this.labelDoNo.Location = new Point(40, 0xc6);
            this.labelDoNo.Name = "labelDoNo";
            this.labelDoNo.Size = new Size(40, 13);
            this.labelDoNo.TabIndex = 0x62;
            this.labelDoNo.Text = "DO No";
            this.textDoNo.CharacterCasing = CharacterCasing.Upper;
            this.textDoNo.Location = new Point(0x51, 0xc2);
            this.textDoNo.Name = "textDoNo";
            this.textDoNo.Size = new Size(0xbf, 20);
            this.textDoNo.TabIndex = 0x5d;
            this.textDoNo.Leave += new EventHandler(this.textDoNo_Leave);
            this.textDoNo.MouseDoubleClick += new MouseEventHandler(this.textDoNo_MouseDoubleClick);
            this.buttonComm.Location = new Point(0x113, 0xa7);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 0x5e;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.labelCommName.AutoSize = true;
            this.labelCommName.Location = new Point(0x12d, 0xac);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x3a, 13);
            this.labelCommName.TabIndex = 0x61;
            this.labelCommName.Text = "Commodity";
            this.textCommodity.CharacterCasing = CharacterCasing.Upper;
            this.textCommodity.Location = new Point(0x51, 0xa9);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0xbf, 20);
            this.textCommodity.TabIndex = 0x5c;
            this.textCommodity.Leave += new EventHandler(this.textCommodity_Leave);
            this.textCommodity.MouseDoubleClick += new MouseEventHandler(this.textCommodity_MouseDoubleClick);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(20, 0xab);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3a, 13);
            this.labelcommodity.TabIndex = 0x60;
            this.labelcommodity.Text = "Commodity";
            this.comboDO.FormattingEnabled = true;
            this.comboDO.Location = new Point(0x130, 0xc5);
            this.comboDO.Name = "comboDO";
            this.comboDO.Size = new Size(0xbf, 0x15);
            this.comboDO.TabIndex = 0x66;
            this.comboDO.Visible = false;
            this.grKB.Controls.Add(this.rboNonKB);
            this.grKB.Controls.Add(this.rboKB);
            this.grKB.Location = new Point(15, 0x12);
            this.grKB.Name = "grKB";
            this.grKB.Size = new Size(0x94, 0x2d);
            this.grKB.TabIndex = 0x67;
            this.grKB.TabStop = false;
            this.rboNonKB.AutoSize = true;
            this.rboNonKB.Location = new Point(0x47, 0x12);
            this.rboNonKB.Name = "rboNonKB";
            this.rboNonKB.Size = new Size(60, 0x11);
            this.rboNonKB.TabIndex = 0x11;
            this.rboNonKB.TabStop = true;
            this.rboNonKB.Text = "non KB";
            this.rboNonKB.UseVisualStyleBackColor = true;
            this.rboKB.AutoSize = true;
            this.rboKB.Location = new Point(15, 0x12);
            this.rboKB.Name = "rboKB";
            this.rboKB.Size = new Size(0x27, 0x11);
            this.rboKB.TabIndex = 0x10;
            this.rboKB.TabStop = true;
            this.rboKB.Text = "KB";
            this.rboKB.UseVisualStyleBackColor = true;
            this.groupDate.Controls.Add(this.monthCalendar1);
            this.groupDate.Controls.Add(this.label1);
            this.groupDate.Controls.Add(this.label2);
            this.groupDate.Controls.Add(this.monthCalendar2);
            this.groupDate.Location = new Point(12, 0x45);
            this.groupDate.Name = "groupDate";
            this.groupDate.Size = new Size(0x19e, 0x2d);
            this.groupDate.TabIndex = 0x68;
            this.groupDate.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x54, 15);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(12, 0x13);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3e, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "From Date :";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0xd7, 0x13);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x34, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x111, 15);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.buttonDriver.Location = new Point(0x113, 0xf5);
            this.buttonDriver.Margin = new Padding(0);
            this.buttonDriver.Name = "buttonDriver";
            this.buttonDriver.Size = new Size(0x17, 0x17);
            this.buttonDriver.TabIndex = 0x70;
            this.buttonDriver.Text = "...";
            this.buttonDriver.UseVisualStyleBackColor = true;
            this.buttonDriver.Click += new EventHandler(this.buttonDriver_Click);
            this.label5.AutoSize = true;
            this.label5.Location = new Point(13, 0xfb);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x40, 13);
            this.label5.TabIndex = 0x71;
            this.label5.Text = "License No.";
            this.textDriver.CharacterCasing = CharacterCasing.Upper;
            this.textDriver.Location = new Point(0x51, 0xf7);
            this.textDriver.Name = "textDriver";
            this.textDriver.Size = new Size(0xbd, 20);
            this.textDriver.TabIndex = 0x6f;
            this.textDriver.KeyPress += new KeyPressEventHandler(this.textDriver_KeyPress);
            this.textDriver.Leave += new EventHandler(this.textDriver_Leave);
            this.buttonTruck.Location = new Point(0xcf, 0x8f);
            this.buttonTruck.Margin = new Padding(0);
            this.buttonTruck.Name = "buttonTruck";
            this.buttonTruck.Size = new Size(0x17, 0x17);
            this.buttonTruck.TabIndex = 110;
            this.buttonTruck.Text = "...";
            this.buttonTruck.UseVisualStyleBackColor = true;
            this.buttonTruck.Click += new EventHandler(this.buttonTruck_Click);
            this.textTruck.CharacterCasing = CharacterCasing.Upper;
            this.textTruck.Location = new Point(110, 0x90);
            this.textTruck.Name = "textTruck";
            this.textTruck.Size = new Size(90, 20);
            this.textTruck.TabIndex = 0x6d;
            this.textTruck.KeyPress += new KeyPressEventHandler(this.textTruck_KeyPress);
            this.textTruck.Leave += new EventHandler(this.textTruck_Leave);
            this.label7.AutoSize = true;
            this.label7.Location = new Point(30, 0x94);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x4b, 13);
            this.label7.TabIndex = 0x6c;
            this.label7.Text = "Truck Number";
            this.buttonTransporter.Location = new Point(0x113, 0xda);
            this.buttonTransporter.Margin = new Padding(0);
            this.buttonTransporter.Name = "buttonTransporter";
            this.buttonTransporter.Size = new Size(0x17, 0x17);
            this.buttonTransporter.TabIndex = 0x6a;
            this.buttonTransporter.Text = "...";
            this.buttonTransporter.UseVisualStyleBackColor = true;
            this.buttonTransporter.Click += new EventHandler(this.buttonTransporter_Click);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(12, 0xe0);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x3d, 13);
            this.label4.TabIndex = 0x6b;
            this.label4.Text = "Transporter";
            this.textTransport.CharacterCasing = CharacterCasing.Upper;
            this.textTransport.Location = new Point(0x51, 220);
            this.textTransport.Name = "textTransport";
            this.textTransport.Size = new Size(0xbd, 20);
            this.textTransport.TabIndex = 0x69;
            this.textTransport.KeyPress += new KeyPressEventHandler(this.textTransport_KeyPress);
            this.textTransport.Leave += new EventHandler(this.textTransport_Leave);
            this.labelTransTypeName.AutoSize = true;
            this.labelTransTypeName.Location = new Point(0xcc, 0x7a);
            this.labelTransTypeName.Name = "labelTransTypeName";
            this.labelTransTypeName.Size = new Size(0x56, 13);
            this.labelTransTypeName.TabIndex = 0x75;
            this.labelTransTypeName.Text = "TransTypeName";
            this.buttonType.Location = new Point(0xb2, 0x75);
            this.buttonType.Margin = new Padding(0);
            this.buttonType.Name = "buttonType";
            this.buttonType.Size = new Size(0x17, 0x17);
            this.buttonType.TabIndex = 0x73;
            this.buttonType.Text = "...";
            this.buttonType.UseVisualStyleBackColor = true;
            this.buttonType.Click += new EventHandler(this.buttonType_Click);
            this.textType.CharacterCasing = CharacterCasing.Upper;
            this.textType.Location = new Point(110, 0x77);
            this.textType.MaxLength = 20;
            this.textType.Name = "textType";
            this.textType.Size = new Size(0x41, 20);
            this.textType.TabIndex = 0x72;
            this.textType.TextChanged += new EventHandler(this.textType_Changed);
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x11, 0x7a);
            this.label9.Name = "label9";
            this.label9.Size = new Size(90, 13);
            this.label9.TabIndex = 0x74;
            this.label9.Text = "Transaction Type";
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(0x11, 0x11c);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x5d, 13);
            this.label3.TabIndex = 0x76;
            this.label3.Text = "Display Column";
            this.panel1.BorderStyle = BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cBoxDate);
            this.panel1.Controls.Add(this.cBoxRef);
            this.panel1.Controls.Add(this.cbAddInfo);
            this.panel1.Controls.Add(this.cBoxPISI);
            this.panel1.Controls.Add(this.checkRmkTicket);
            this.panel1.Location = new Point(8, 300);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x2a7, 0x4f);
            this.panel1.TabIndex = 0x77;
            this.cbAddInfo.AutoSize = true;
            this.cbAddInfo.Location = new Point(7, 10);
            this.cbAddInfo.Name = "cbAddInfo";
            this.cbAddInfo.Size = new Size(0x5d, 0x11);
            this.cbAddInfo.TabIndex = 0x20;
            this.cbAddInfo.Text = "Additional Info";
            this.cbAddInfo.UseVisualStyleBackColor = true;
            this.cBoxPISI.AutoSize = true;
            this.cBoxPISI.Location = new Point(6, 0x38);
            this.cBoxPISI.Name = "cBoxPISI";
            this.cBoxPISI.Size = new Size(0x4a, 0x11);
            this.cBoxPISI.TabIndex = 0x1f;
            this.cBoxPISI.Text = "PI / SI No";
            this.cBoxPISI.UseVisualStyleBackColor = true;
            this.checkRmkTicket.AutoSize = true;
            this.checkRmkTicket.Checked = true;
            this.checkRmkTicket.CheckState = CheckState.Checked;
            this.checkRmkTicket.Location = new Point(7, 0x21);
            this.checkRmkTicket.Name = "checkRmkTicket";
            this.checkRmkTicket.Size = new Size(0x6f, 0x11);
            this.checkRmkTicket.TabIndex = 15;
            this.checkRmkTicket.Text = "Remark for Ticket";
            this.checkRmkTicket.UseVisualStyleBackColor = true;
            this.cBoxRef.AutoSize = true;
            this.cBoxRef.Location = new Point(0x95, 10);
            this.cBoxRef.Name = "cBoxRef";
            this.cBoxRef.Size = new Size(0x3f, 0x11);
            this.cBoxRef.TabIndex = 0x21;
            this.cBoxRef.Text = "Ref No.";
            this.cBoxRef.UseVisualStyleBackColor = true;
            this.cBoxDate.AutoSize = true;
            this.cBoxDate.Location = new Point(0x95, 0x21);
            this.cBoxDate.Name = "cBoxDate";
            this.cBoxDate.Size = new Size(0x54, 0x11);
            this.cBoxDate.TabIndex = 0x22;
            this.cBoxDate.Text = "Report Date";
            this.cBoxDate.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x2b6, 390);
            base.ControlBox = false;
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.labelTransTypeName);
            base.Controls.Add(this.buttonType);
            base.Controls.Add(this.textType);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.buttonDriver);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.textDriver);
            base.Controls.Add(this.buttonTruck);
            base.Controls.Add(this.textTruck);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.buttonTransporter);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textTransport);
            base.Controls.Add(this.groupDate);
            base.Controls.Add(this.grKB);
            base.Controls.Add(this.comboDO);
            base.Controls.Add(this.ComboComm);
            base.Controls.Add(this.buttonDoNo);
            base.Controls.Add(this.labelDoNo);
            base.Controls.Add(this.textDoNo);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.btnClose);
            base.Controls.Add(this.btnProcess);
            base.Name = "RepTolerance";
            base.ShowIcon = false;
            this.Text = "Tolerance Product";
            base.Load += new EventHandler(this.RepTolerance_Load);
            this.grKB.ResumeLayout(false);
            this.grKB.PerformLayout();
            this.groupDate.ResumeLayout(false);
            this.groupDate.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void initTable()
        {
            this.tbl_Comm = new WBTable();
            this.tbl_Comm.OpenTable("wb_commodity", "Select * from wb_commodity", WBData.conn);
            Program.AutoComp(this.tbl_Comm, "Comm_code", this.textCommodity);
            this.tbl_Transport = new WBTable();
            this.tbl_Transport.OpenTable("wb_Transport", "Select * from wb_Transporter", WBData.conn);
            Program.AutoComp(this.tbl_Transport, "Transporter_code", this.textTransport);
            this.tbl_Driver = new WBTable();
            this.tbl_Driver.OpenTable("wb_Driver", "Select * from wb_Driver", WBData.conn);
            Program.AutoComp(this.tbl_Driver, "License_No", this.textDriver);
            this.tbl_Do = new WBTable();
            this.tbl_Do.OpenTable("wb_contract", "Select * from wb_contract", WBData.conn);
            Program.AutoComp(this.tbl_Do, "Do_No", this.textDoNo);
            this.tblTruck = new WBTable();
            this.tblTruck.OpenTable("wb_truck", "Select * from wb_truck", WBData.conn);
            Program.AutoComp(this.tblTruck, "Truck_NUmber", this.textTruck);
            this.tbl_TransType = new WBTable();
            this.tbl_TransType.OpenTable("wb_transaction_type", "Select * from wb_transaction_type", WBData.conn);
            Program.AutoComp(this.tbl_TransType, "Transaction_code", this.textType);
        }

        private void RepTolerance_Load(object sender, EventArgs e)
        {
            this.labelCommName.Text = "";
            this.initTable();
            if (WBSetting.Field("KB").ToString() == "N")
            {
                this.kb = "N";
                this.rboNonKB.Checked = true;
            }
            else
            {
                this.kb = "Y";
                this.rboKB.Checked = true;
            }
        }

        private void textCommodity_Leave(object sender, EventArgs e)
        {
            this.labelCommName.Text = "";
            if (this.textCommodity.Text.Trim() != "")
            {
                this.tbl_Comm.ReOpen();
                string[] aField = new string[] { "Comm_code" };
                string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                int recNo = this.tbl_Comm.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.buttonComm.PerformClick();
                    this.textCommodity.Focus();
                }
                else
                {
                    this.labelCommName.Text = this.tbl_Comm.DT.Rows[recNo]["Comm_name"].ToString().Trim();
                    if (this.ComboComm.Items.IndexOf(this.textCommodity.Text) < 0)
                    {
                        this.ComboComm.Items.Add(this.textCommodity.Text);
                    }
                }
            }
        }

        private void textCommodity_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FormPickList list = new FormPickList();
            this.tbl_Comm.ReOpen();
            list.tempTable = this.tbl_Comm;
            list.dgView.Rows.Clear();
            list.autoField = "Comm_Code";
            int num = 0;
            while (true)
            {
                if (num >= this.ComboComm.Items.Count)
                {
                    list.ShowDialog();
                    this.ComboComm.Items.Clear();
                    num = 0;
                    while (true)
                    {
                        if (num >= (list.dgView.Rows.Count - 1))
                        {
                            this.textCommodity.Text = (this.ComboComm.Items.Count <= 0) ? "" : this.ComboComm.Items[0].ToString();
                            return;
                        }
                        this.ComboComm.Items.Add(list.dgView.Rows[num].Cells[0].Value.ToString());
                        num++;
                    }
                }
                object[] values = new object[] { this.ComboComm.Items[num].ToString() };
                list.dgView.Rows.Add(values);
                num++;
            }
        }

        private void textDoNo_Leave(object sender, EventArgs e)
        {
            if (this.textDoNo.Text.Trim() != "")
            {
                this.tbl_Do.ReOpen();
                string[] aField = new string[] { "Do_NO" };
                string[] aFind = new string[] { this.textDoNo.Text.Trim() };
                if (this.tbl_Do.GetRecNo(aField, aFind) < 0)
                {
                    this.buttonDoNo.PerformClick();
                    this.textDoNo.Focus();
                }
                else if (this.comboDO.Items.IndexOf(this.textDoNo.Text) < 0)
                {
                    this.comboDO.Items.Add(this.textDoNo.Text);
                }
            }
        }

        private void textDoNo_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FormPickList list = new FormPickList();
            this.tbl_Do.ReOpen();
            list.tempTable = this.tbl_Do;
            list.dgView.Rows.Clear();
            list.autoField = "DO_No";
            int num = 0;
            while (true)
            {
                if (num >= this.comboDO.Items.Count)
                {
                    list.ShowDialog();
                    this.comboDO.Items.Clear();
                    num = 0;
                    while (true)
                    {
                        if (num >= (list.dgView.Rows.Count - 1))
                        {
                            this.textDoNo.Text = (this.comboDO.Items.Count <= 0) ? "" : this.comboDO.Items[0].ToString();
                            return;
                        }
                        this.comboDO.Items.Add(list.dgView.Rows[num].Cells[0].Value.ToString());
                        num++;
                    }
                }
                object[] values = new object[] { this.comboDO.Items[num].ToString() };
                list.dgView.Rows.Add(values);
                num++;
            }
        }

        private void textDriver_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDriver_Leave(object sender, EventArgs e)
        {
            if (this.textDriver.Text.Trim() != "")
            {
                this.tbl_Driver.ReOpen();
                string[] aField = new string[] { "License_no" };
                string[] aFind = new string[] { this.textDriver.Text.Trim() };
                if (this.tbl_Driver.GetRecNo(aField, aFind) < -1)
                {
                    this.buttonDriver.PerformClick();
                    this.textDriver.Focus();
                }
            }
        }

        private void textTransport_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransport_Leave(object sender, EventArgs e)
        {
            if (this.textTransport.Text.Trim() != "")
            {
                this.tbl_Transport.ReOpen();
                string[] aField = new string[] { "Transporter_code" };
                string[] aFind = new string[] { this.textDriver.Text.Trim() };
                if (this.tbl_Transport.GetRecNo(aField, aFind) < -1)
                {
                    this.buttonTransporter.PerformClick();
                    this.textTransport.Focus();
                }
            }
        }

        private void textTruck_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTruck_Leave(object sender, EventArgs e)
        {
            this.tblTruck.ReOpen();
            string[] aField = new string[] { "Truck_Number" };
            string[] aFind = new string[] { this.textTruck.Text.Trim() };
            int recNo = this.tblTruck.GetRecNo(aField, aFind);
            if (recNo > -1)
            {
                this.textTruck.Text = this.tblTruck.DT.Rows[recNo]["Truck_Number"].ToString().Trim();
            }
            else
            {
                this.buttonTruck.PerformClick();
                this.textTruck.Focus();
            }
        }

        private void textType_Changed(object sender, EventArgs e)
        {
            this.labelTransTypeName.Text = "";
            if (this.textType.Text.Trim() != "")
            {
                this.tbl_TransType.ReOpen();
                string[] aField = new string[] { "Transaction_code" };
                string[] aFind = new string[] { this.textType.Text.Trim() };
                int recNo = this.tbl_TransType.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelTransTypeName.Text = this.tbl_TransType.DT.Rows[recNo]["Transaction_name"].ToString().Trim();
                }
                else
                {
                    this.buttonType.PerformClick();
                    this.textType.Focus();
                }
            }
        }
    }
}

