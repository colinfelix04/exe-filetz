﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCancelTypeEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private Button button2;
        private Button button1;
        private TextBox textBox1;
        private Label label2;
        private Label label1;
        private CheckBox cBoxRequireToken;
        private ToolTip toolTipInfo;
        private TextBox textBox2;

        public FormCancelTypeEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            TextBox[] aText = new TextBox[] { this.textBox1, this.textBox2 };
            if (!Program.CheckEmpty(aText))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_cancel_type", "Select Uniq From wb_cancel_type Where cancel_type='" + this.textBox1.Text.Trim() + "'", WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    Cursor.Current = Cursors.WaitCursor;
                    this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                    if ((this.pMode != "EDIT") || (this.textBox1.Text.Trim() == this.OldCode.Trim()))
                    {
                        goto TR_0014;
                    }
                    else
                    {
                        table2 = new WBTable();
                        table2.OpenTable("wb_transaction", "Select uniq From wb_transaction where cancel_type ='" + this.OldCode.Trim() + "'", WBData.conn);
                        Cursor.Current = Cursors.Default;
                        if (table2.DT.Rows.Count <= 0)
                        {
                            goto TR_0015;
                        }
                        else
                        {
                            string[] textArray1 = new string[] { "The Cancel Type will be change, from ", this.OldCode, " -> ", this.textBox1.Text, "\n\nSystem will replace all the transaction with the new code, it takes a longer time.\n - ", table2.DT.Rows.Count.ToString(), " records in transaction.\n\nAre you want to continue . . ?" };
                            if (MessageBox.Show(string.Concat(textArray1), "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.ReplaceAll = true;
                                goto TR_0015;
                            }
                            else
                            {
                                this.ReplaceAll = false;
                                this.textBox1.Focus();
                            }
                        }
                    }
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_240);
                    this.textBox1.Focus();
                }
            }
            return;
        TR_0014:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "Cancel Type" },
                    textRefNo = { Text = this.textBox1.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["require_token"] = this.cBoxRequireToken.Checked ? "Y" : "N";
            this.zTable.DR["cancel_type"] = this.textBox1.Text;
            this.zTable.DR["description"] = this.textBox2.Text;
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Edit_By"] = WBUser.UserID;
                this.zTable.DR["Edit_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_cancel_type", "SELECT uniq FROM wb_cancel_type WHERE cancel_type = '" + this.textBox1.Text + "'", WBData.conn);
                    this.logKey = table3.DT.Rows[0]["uniq"].ToString();
                    table3.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_cancel_type", this.logKey, logField, logValue);
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            base.Close();
            return;
        TR_0015:
            table2.Dispose();
            goto TR_0014;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransTypeEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTransTypeEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.pMode != "ADD")
            {
                this.textBox1.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["cancel_type"].Value.ToString();
                this.OldCode = this.textBox1.Text;
                this.textBox2.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["description"].Value.ToString();
                this.cBoxRequireToken.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["require_token"].Value.ToString() == "Y";
            }
            if (this.pMode == "VIEW")
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.button2.Text = Resource.Btn_Close;
                this.button2.Enabled = true;
            }
            this.toolTipInfo.SetToolTip(this.cBoxRequireToken, "DO with this Transaction type must Adopt from " + this.sapIDSYS);
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.button2 = new Button();
            this.button1 = new Button();
            this.textBox1 = new TextBox();
            this.label2 = new Label();
            this.label1 = new Label();
            this.cBoxRequireToken = new CheckBox();
            this.toolTipInfo = new ToolTip(this.components);
            this.textBox2 = new TextBox();
            base.SuspendLayout();
            this.button2.Location = new Point(0xf4, 0x66);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 4;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x85, 0x66);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 3;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(0x55, 0x17);
            this.textBox1.MaxLength = 1;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0x1a, 20);
            this.textBox1.TabIndex = 0;
            this.label2.Location = new Point(14, 0x34);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x41, 13);
            this.label2.TabIndex = 0x4e;
            this.label2.Text = "Description";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.label1.Location = new Point(11, 0x19);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x44, 13);
            this.label1.TabIndex = 0x4d;
            this.label1.Text = "Cancel Type";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.cBoxRequireToken.AutoSize = true;
            this.cBoxRequireToken.Location = new Point(0xf6, 0x18);
            this.cBoxRequireToken.Name = "cBoxRequireToken";
            this.cBoxRequireToken.Size = new Size(0x61, 0x11);
            this.cBoxRequireToken.TabIndex = 0x54;
            this.cBoxRequireToken.Text = "Require Token";
            this.toolTipInfo.SetToolTip(this.cBoxRequireToken, "DO with this Transaction type must Adopt from SAP");
            this.cBoxRequireToken.UseVisualStyleBackColor = true;
            this.textBox2.Location = new Point(0x55, 0x31);
            this.textBox2.MaxLength = 100;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x166, 20);
            this.textBox2.TabIndex = 1;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1cb, 0x8e);
            base.ControlBox = false;
            base.Controls.Add(this.cBoxRequireToken);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Name = "FormCancelTypeEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormCancelTypeEntry";
            base.Load += new EventHandler(this.FormTransTypeEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransTypeEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
        }
    }
}

