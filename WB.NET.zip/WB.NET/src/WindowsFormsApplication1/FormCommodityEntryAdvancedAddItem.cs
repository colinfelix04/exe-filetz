﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCommodityEntryAdvancedAddItem : Form
    {
        public DataTable ztable = new DataTable();
        public WBTable tblQC;
        public WBTable tblCommDetail;
        public string CommCode;
        private IContainer components = null;
        private Panel panel1;
        private DataGridView dataGridView1;
        private Panel panel2;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;

        public FormCommodityEntryAdvancedAddItem()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.select(1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.select(2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.select(3);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in (IEnumerable) this.dataGridView1.Rows)
            {
                if (row.Cells[0].Value.ToString() == "True")
                {
                    string[] aField = new string[] { "Yield_Code" };
                    string[] aFind = new string[] { row.Cells[1].Value.ToString() };
                    int recNo = this.tblQC.GetRecNo(aField, aFind);
                    this.tblCommDetail.DR = this.tblCommDetail.DT.NewRow();
                    this.tblCommDetail.DR.BeginEdit();
                    this.tblCommDetail.DR["Coy"] = WBData.sCoyCode;
                    this.tblCommDetail.DR["Location_Code"] = WBData.sLocCode;
                    this.tblCommDetail.DR["Comm_Code"] = this.CommCode;
                    this.tblCommDetail.DR["QCode"] = this.tblQC.DT.Rows[recNo]["Yield_Code"].ToString();
                    this.tblCommDetail.DR["QName"] = this.tblQC.DT.Rows[recNo]["Yield_Name"].ToString();
                    this.tblCommDetail.DR["checked"] = 0;
                    this.tblCommDetail.DR.EndEdit();
                    this.tblCommDetail.DT.Rows.Add(this.tblCommDetail.DR);
                    this.tblQC.DT.Rows.RemoveAt(recNo);
                }
            }
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormCommodityEntryAdvancedAddItem_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormCommodityEntryAdvancedAddItem_Load(object sender, EventArgs e)
        {
            DataGridViewCheckBoxColumn dataGridViewColumn = new DataGridViewCheckBoxColumn {
                HeaderText = Resource.Setting_059,
                Name = "Selected",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells,
                FlatStyle = FlatStyle.Standard,
                ThreeState = false,
                CellTemplate = new DataGridViewCheckBoxCell()
            };
            dataGridViewColumn.CellTemplate.Style.BackColor = Color.Beige;
            this.dataGridView1.ColumnCount = 2;
            this.dataGridView1.Columns.Insert(0, dataGridViewColumn);
            this.dataGridView1.Columns[0].HeaderText = "X";
            this.dataGridView1.Columns[1].HeaderText = Resource.Composite_005;
            this.dataGridView1.Columns[1].Width = 150;
            this.dataGridView1.Columns[1].ReadOnly = true;
            this.dataGridView1.Columns[2].HeaderText = Resource.Col_QC_Description;
            this.dataGridView1.Columns[2].Width = 400;
            this.dataGridView1.Columns[2].ReadOnly = true;
            foreach (DataRow row in this.tblQC.DT.Rows)
            {
                DataRowState rowState = row.RowState;
                if (rowState.ToString() != "Deleted")
                {
                    string[] values = new string[] { "false", row["Yield_Code"].ToString(), row["Yield_Name"].ToString() };
                    this.dataGridView1.Rows.Add(values);
                }
            }
        }

        private void InitializeComponent()
        {
            this.panel1 = new Panel();
            this.dataGridView1 = new DataGridView();
            this.panel2 = new Panel();
            this.button4 = new Button();
            this.button3 = new Button();
            this.button2 = new Button();
            this.button1 = new Button();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.panel2.SuspendLayout();
            base.SuspendLayout();
            this.panel1.BorderStyle = BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Dock = DockStyle.Top;
            this.panel1.Location = new Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x279, 0x14c);
            this.panel1.TabIndex = 0;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.Location = new Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x275, 0x148);
            this.dataGridView1.TabIndex = 0;
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Dock = DockStyle.Bottom;
            this.panel2.Location = new Point(0, 0x152);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x279, 0x21);
            this.panel2.TabIndex = 1;
            this.button4.Location = new Point(0x222, 0);
            this.button4.Name = "button4";
            this.button4.Size = new Size(0x4b, 30);
            this.button4.TabIndex = 3;
            this.button4.Text = "Done";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new EventHandler(this.button4_Click);
            this.button3.Location = new Point(0xae, 0);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x4b, 30);
            this.button3.TabIndex = 2;
            this.button3.Text = "Reversed";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.button2.Location = new Point(0x5d, 0);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 30);
            this.button2.TabIndex = 1;
            this.button2.Text = "Unselect All";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(12, 0);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 30);
            this.button1.TabIndex = 0;
            this.button1.Text = "Select All";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x279, 0x173);
            base.ControlBox = false;
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.panel1);
            base.FormBorderStyle = FormBorderStyle.Fixed3D;
            base.KeyPreview = true;
            base.Name = "FormCommodityEntryAdvancedAddItem";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormCommodityEntryAdvancedAddItem";
            base.Load += new EventHandler(this.FormCommodityEntryAdvancedAddItem_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormCommodityEntryAdvancedAddItem_KeyPress);
            this.panel1.ResumeLayout(false);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.panel2.ResumeLayout(false);
            base.ResumeLayout(false);
        }

        private void select(int mode)
        {
            for (int i = 0; i < this.dataGridView1.Rows.Count; i++)
            {
                bool flag = mode == 1;
                this.dataGridView1.Rows[i].Cells[0].Value = !flag ? ((mode != 2) ? (this.dataGridView1.Rows[i].Cells[0].Value.ToString() != "True") : false) : true;
            }
        }

        private void translate()
        {
            this.button4.Text = Resource.Btn_Done;
            this.button3.Text = Resource.Btn_Reversed;
            this.button2.Text = Resource.Btn_Unselect_All;
            this.button1.Text = Resource.Btn_Select_All;
            this.Text = Resource.Title_Commodity_Entry_Advanced_Add_Item;
        }
    }
}

