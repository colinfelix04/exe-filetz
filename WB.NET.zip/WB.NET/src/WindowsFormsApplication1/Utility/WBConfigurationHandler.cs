﻿namespace WindowsFormsApplication1.Utility
{
    using Encryption.Utility;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Threading;

    internal class WBConfigurationHandler
    {
        public static string configurationDirectory = (Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\UWB\CONFIGURATION");
        public static string configurationFile = (configurationDirectory + @"\DATABASE");
        public static string registryFile = (configurationDirectory + @"\REGISTRY");

        public static void createDirectory()
        {
            if (!Directory.Exists(configurationDirectory))
            {
                Directory.CreateDirectory(configurationDirectory);
            }
        }

        public static void createTxtFile(string file)
        {
            if (!File.Exists(file))
            {
                File.Create(file).Dispose();
            }
        }

        public static string dictionaryToString(Dictionary<string, string> dict)
        {
            string str = "";
            int num = 0;
            foreach (KeyValuePair<string, string> pair in dict)
            {
                if (pair.Value != null)
                {
                    str = str + pair.Key.ToString().ToUpper().Trim() + "=" + pair.Value.ToString().Trim();
                }
                if ((num + 1) < dict.Count)
                {
                    str = str + Environment.NewLine;
                }
            }
            return str;
        }

        public static Dictionary<string, string> readFromTxt(string file)
        {
            string str = "";
            using (FileStream stream = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (StreamReader reader = new StreamReader(stream))
                {
                    str = WBEncryption.Decrypt(reader.ReadToEnd());
                }
            }
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            return (!str.Contains("Wrong Input") ? stringToDictionary(str) : dictionary);
        }

        public static Dictionary<string, string> stringToDictionary(string str)
        {
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            char[] separator = new char[] { '\n' };
            string[] strArray = str.Split(separator);
            for (int i = 0; i < strArray.Length; i++)
            {
                if (strArray[i].Trim() != "")
                {
                    char[] chArray2 = new char[] { '=' };
                    string[] strArray2 = strArray[i].Split(chArray2);
                    dictionary.Add(strArray2[0].Trim(), strArray2[1].Trim());
                }
            }
            return dictionary;
        }

        public static void writeToTxt(string file, Dictionary<string, string> dictToTxt)
        {
            Dictionary<string, string> dictionary;
            int num;
            if (!File.Exists(file))
            {
                createDirectory();
                createTxtFile(file);
                writeToTxt(file, dictToTxt);
                dictToTxt.Clear();
                return;
            }
            else
            {
                dictionary = readFromTxt(file);
                foreach (KeyValuePair<string, string> pair in dictToTxt)
                {
                    if (dictionary.ContainsKey(pair.Key))
                    {
                        dictionary[pair.Key] = pair.Value;
                        continue;
                    }
                    dictionary.Add(pair.Key, pair.Value);
                }
                num = 0;
            }
            while (true)
            {
                try
                {
                    StreamWriter writer = new StreamWriter(file);
                    writer.Write(WBEncryption.Encrypt(dictionaryToString(dictionary)));
                    writer.Dispose();
                }
                catch (Exception)
                {
                    if ((num + 1) != 5)
                    {
                        Thread.Sleep(100);
                        continue;
                    }
                }
                break;
            }
        }
    }
}

