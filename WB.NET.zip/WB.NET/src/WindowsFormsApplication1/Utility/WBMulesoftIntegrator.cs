﻿namespace WindowsFormsApplication1.Utility
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Net;
    using System.Net.Security;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Security.Cryptography.X509Certificates;
    using System.Windows.Forms;
    using WindowsFormsApplication1;

    internal class WBMulesoftIntegrator
    {
        private Dictionary<string, List<Dictionary<string, string>>> syncTable;
        public string auto = "N";
        public string mulesoftErr = "";

        public void addTable(List<Dictionary<string, string>> sentTable, string sentTableHeader)
        {
            try
            {
                this.syncTable.Add(sentTableHeader, sentTable);
            }
            catch (Exception exception)
            {
                if (this.auto == "N")
                {
                    MessageBox.Show("Error adding table : \n\n" + ((Convert.ToInt16(WBUser.UserLevel) > 1) ? exception.Message : exception.ToString()), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.mulesoftErr = "Error adding table : \n\n" + exception.ToString();
            }
        }

        private List<Dictionary<string, string>> convertJSONToStr(string JSON, string resultHeaderName)
        {
            List<Dictionary<string, string>> list2;
            try
            {
                List<Dictionary<string, string>> list = null;
                bool flag = false;
                foreach (KeyValuePair<string, object> pair in JsonConvert.DeserializeObject<Dictionary<string, object>>(JSON))
                {
                    if (pair.Key.ToString().ToUpper() == resultHeaderName.ToUpper())
                    {
                        flag = true;
                        list = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(pair.Value.ToString());
                        break;
                    }
                }
                if (flag)
                {
                    list2 = list;
                }
                else
                {
                    if (this.auto == "N")
                    {
                        MessageBox.Show(resultHeaderName + " is not found in Mulesoft.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    this.mulesoftErr = resultHeaderName + " is not found in Mulesoft.";
                    list2 = new List<Dictionary<string, string>>();
                }
            }
            catch (Exception exception)
            {
                if (this.auto == "N")
                {
                    MessageBox.Show("Error converting JSON from Mulesoft when synching data : \n\n" + ((Convert.ToInt16(WBUser.UserLevel) > 1) ? exception.Message : exception.ToString()), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.mulesoftErr = "Error converting JSON from Mulesoft when synching data : \n\n" + exception.ToString();
                list2 = new List<Dictionary<string, string>>();
            }
            return list2;
        }

        public Dictionary<string, List<Dictionary<string, string>>> getDataFromMulesoft(string url, string[] resultHeaderName, out bool err)
        {
            Dictionary<string, List<Dictionary<string, string>>> dictionary3;
            Stopwatch stopwatch = Stopwatch.StartNew();
            ServicePointManager.ServerCertificateValidationCallback = <>c.<>9__4_0 ??= (<sender>, <certificate>, <chain>, <sslPolicyErrors>) => true;
            try
            {
                Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                List<Dictionary<string, string>> list = null;
                bool flag = false;
                HttpWebRequest request = (HttpWebRequest) WebRequest.Create(url);
                request.ContentType = "application/json";
                request.Method = "GET";
                request.ServicePoint.Expect100Continue = false;
                request.KeepAlive = false;
                request.Headers.Add("client_id", WBSetting.mulesoft_ID);
                request.Headers.Add("client_secret", WBSetting.mulesoft_Key);
                WebResponse response = request.GetResponse();
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    Dictionary<string, object> dictionary2 = JsonConvert.DeserializeObject<Dictionary<string, object>>(reader.ReadToEnd());
                    int index = 0;
                    while (true)
                    {
                        if (index >= resultHeaderName.Length)
                        {
                            break;
                        }
                        foreach (KeyValuePair<string, object> pair in dictionary2)
                        {
                            if (pair.Key.ToString().ToUpper() == resultHeaderName[index].ToUpper())
                            {
                                flag = true;
                                list = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(pair.Value.ToString());
                                dictionary.Add(resultHeaderName[index].ToUpper(), list);
                                break;
                            }
                        }
                        index++;
                    }
                }
                response.Close();
                stopwatch.Stop();
                long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                if (flag)
                {
                    err = false;
                    this.mulesoftErr = "";
                    dictionary3 = dictionary;
                }
                else
                {
                    if (this.auto == "N")
                    {
                        MessageBox.Show(resultHeaderName + " is not found in Mulesoft!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    this.mulesoftErr = resultHeaderName + " is not found in Mulesoft!";
                    err = true;
                    dictionary3 = new Dictionary<string, List<Dictionary<string, string>>>();
                }
            }
            catch (Exception exception)
            {
                stopwatch.Stop();
                long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                if (this.auto == "N")
                {
                    object[] objArray1 = new object[5];
                    objArray1[0] = "Error adopting data from Mulesoft : \n\n";
                    objArray1[1] = (Convert.ToInt16(WBUser.UserLevel) > 1) ? exception.Message : exception.ToString();
                    object[] local2 = objArray1;
                    local2[2] = "\n\nProcess time: ";
                    local2[3] = elapsedMilliseconds;
                    local2[4] = " ms";
                    MessageBox.Show(string.Concat(local2), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.mulesoftErr = "Error adopting data from Mulesoft : \n\n" + exception.ToString();
                err = true;
                dictionary3 = new Dictionary<string, List<Dictionary<string, string>>>();
            }
            return dictionary3;
        }

        public string getURL(string rfcName)
        {
            string str = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_table", "SELECT RFC_URL FROM wb_mulesoftURL WHERE " + WBData.CompanyLocation(" AND RFC_NAME = '" + rfcName + "'"), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                if (this.auto == "N")
                {
                    MessageBox.Show("URL for RFC " + rfcName + " has not been maintained yet!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                str = table.DT.Rows[0]["RFC_URL"].ToString();
                if ((str == "") && (this.auto == "N"))
                {
                    MessageBox.Show("URL for RFC " + rfcName + " has not been maintained yet!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            table.Dispose();
            return str;
        }

        public void prepareTable()
        {
            this.syncTable = new Dictionary<string, List<Dictionary<string, string>>>();
        }

        public Dictionary<string, List<Dictionary<string, string>>> sendDataToMulesoft(string url, string[] resultHeaderName, out bool err)
        {
            Dictionary<string, List<Dictionary<string, string>>> dictionary3;
            Stopwatch stopwatch = Stopwatch.StartNew();
            ServicePointManager.ServerCertificateValidationCallback = <>c.<>9__7_0 ??= (<sender>, <certificate>, <chain>, <sslPolicyErrors>) => true;
            try
            {
                int num = 0x36ee80;
                Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                List<Dictionary<string, string>> list = null;
                bool flag = false;
                string str = JsonConvert.SerializeObject(this.syncTable);
                HttpWebRequest request = (HttpWebRequest) WebRequest.Create(url);
                request.Timeout = num;
                request.ReadWriteTimeout = num;
                request.ContentType = "application/json";
                request.Method = "POST";
                request.ServicePoint.Expect100Continue = false;
                request.KeepAlive = false;
                request.Headers.Add("client_id", WBSetting.mulesoft_ID);
                request.Headers.Add("client_secret", WBSetting.mulesoft_Key);
                using (StreamWriter writer = new StreamWriter(request.GetRequestStream()))
                {
                    writer.Write(str);
                    writer.Flush();
                    writer.Close();
                }
                HttpWebResponse response = (HttpWebResponse) request.GetResponse();
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    Dictionary<string, object> dictionary2 = JsonConvert.DeserializeObject<Dictionary<string, object>>(reader.ReadToEnd());
                    int index = 0;
                    while (true)
                    {
                        if (index >= resultHeaderName.Length)
                        {
                            break;
                        }
                        foreach (KeyValuePair<string, object> pair in dictionary2)
                        {
                            if (pair.Key.ToString().ToUpper() == resultHeaderName[index].ToUpper())
                            {
                                flag = true;
                                list = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(pair.Value.ToString());
                                dictionary.Add(resultHeaderName[index].ToUpper(), list);
                                break;
                            }
                        }
                        index++;
                    }
                }
                response.Close();
                stopwatch.Stop();
                long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                if (flag)
                {
                    err = false;
                    this.mulesoftErr = "";
                    dictionary3 = dictionary;
                }
                else
                {
                    if (this.auto == "N")
                    {
                        MessageBox.Show(resultHeaderName + " is not found in Mulesoft.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    err = true;
                    this.mulesoftErr = resultHeaderName + " is not found in Mulesoft.";
                    dictionary3 = new Dictionary<string, List<Dictionary<string, string>>>();
                }
            }
            catch (Exception exception)
            {
                stopwatch.Stop();
                long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                if (this.auto == "N")
                {
                    object[] objArray1 = new object[4];
                    objArray1[0] = "Error synching data to Mulesoft : \n\n";
                    objArray1[1] = (Convert.ToInt16(WBUser.UserLevel) > 1) ? exception.Message : exception.ToString();
                    object[] local2 = objArray1;
                    local2[2] = "\n\nProcess time: ";
                    local2[3] = elapsedMilliseconds;
                    MessageBox.Show(string.Concat(local2), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                err = true;
                this.mulesoftErr = "Error synching data to Mulesoft : \n\n" + exception.ToString();
                dictionary3 = new Dictionary<string, List<Dictionary<string, string>>>();
            }
            return dictionary3;
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly WBMulesoftIntegrator.<>c <>9 = new WBMulesoftIntegrator.<>c();
            public static RemoteCertificateValidationCallback <>9__4_0;
            public static RemoteCertificateValidationCallback <>9__7_0;

            internal bool <getDataFromMulesoft>b__4_0(object <sender>, X509Certificate <certificate>, X509Chain <chain>, SslPolicyErrors <sslPolicyErrors>) => 
                true;

            internal bool <sendDataToMulesoft>b__7_0(object <sender>, X509Certificate <certificate>, X509Chain <chain>, SslPolicyErrors <sslPolicyErrors>) => 
                true;
        }
    }
}

