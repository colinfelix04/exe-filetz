﻿namespace WindowsFormsApplication1.Utility
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Net;
    using System.Net.Security;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Security.Cryptography.X509Certificates;
    using System.Windows.Forms;
    using System.Xml;
    using WindowsFormsApplication1;

    internal class WBIDSYSIntegrator
    {
        private Dictionary<string, List<Dictionary<string, string>>> syncTable;
        public string auto = "N";
        public string IDSYSErr = "";

        public void addTable(List<Dictionary<string, string>> sentTable, string sentTableHeader)
        {
            try
            {
                this.syncTable.Add(sentTableHeader, sentTable);
            }
            catch (Exception exception)
            {
                if (this.auto == "N")
                {
                    MessageBox.Show("Error adding table : \n\n" + ((Convert.ToInt16(WBUser.UserLevel) > 1) ? exception.Message : exception.ToString()), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.IDSYSErr = "Error adding table : \n\n" + exception.ToString();
            }
        }

        private List<Dictionary<string, string>> convertJSONToStr(string JSON, string resultHeaderName)
        {
            List<Dictionary<string, string>> list2;
            try
            {
                List<Dictionary<string, string>> list = null;
                bool flag = false;
                foreach (KeyValuePair<string, object> pair in JsonConvert.DeserializeObject<Dictionary<string, object>>(JSON))
                {
                    if (pair.Key.ToString().ToUpper() == resultHeaderName.ToUpper())
                    {
                        flag = true;
                        list = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(pair.Value.ToString());
                        break;
                    }
                }
                if (flag)
                {
                    list2 = list;
                }
                else
                {
                    if (this.auto == "N")
                    {
                        MessageBox.Show(resultHeaderName + " is not found in IDSYS.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    this.IDSYSErr = resultHeaderName + " is not found in IDSYS.";
                    list2 = new List<Dictionary<string, string>>();
                }
            }
            catch (Exception exception)
            {
                if (this.auto == "N")
                {
                    MessageBox.Show("Error converting JSON from IDSYS when synching data : \n\n" + ((Convert.ToInt16(WBUser.UserLevel) > 1) ? exception.Message : exception.ToString()), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.IDSYSErr = "Error converting JSON from IDSYS when synching data : \n\n" + exception.ToString();
                list2 = new List<Dictionary<string, string>>();
            }
            return list2;
        }

        public Dictionary<string, List<Dictionary<string, string>>> getDataFromIDSYS(string url, string postData, out bool err)
        {
            Dictionary<string, List<Dictionary<string, string>>> dictionary3;
            Stopwatch stopwatch = Stopwatch.StartNew();
            ServicePointManager.ServerCertificateValidationCallback = <>c.<>9__4_0 ??= (<sender>, <certificate>, <chain>, <sslPolicyErrors>) => true;
            try
            {
                Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                bool flag = false;
                HttpWebRequest request = (HttpWebRequest) WebRequest.Create(url);
                request.ContentType = "application/json";
                request.Method = "POST";
                using (StreamWriter writer = new StreamWriter(request.GetRequestStream()))
                {
                    writer.Write(postData);
                    writer.Flush();
                    writer.Close();
                }
                using (StreamReader reader = new StreamReader(((HttpWebResponse) request.GetResponse()).GetResponseStream()))
                {
                    flag = true;
                    List<Dictionary<string, string>> list2 = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(JsonConvert.DeserializeObject<Dictionary<string, string>>(reader.ReadToEnd())["d"]);
                    dictionary.Add("data", list2);
                }
                if (flag)
                {
                    err = false;
                    this.IDSYSErr = "";
                    dictionary3 = dictionary;
                }
                else
                {
                    if (this.auto == "N")
                    {
                        MessageBox.Show("Data is not found in IDSYS!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    this.IDSYSErr = "Data is not found in IDSYS!";
                    err = true;
                    dictionary3 = new Dictionary<string, List<Dictionary<string, string>>>();
                }
            }
            catch (Exception exception)
            {
                stopwatch.Stop();
                long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                if (this.auto == "N")
                {
                    object[] objArray1 = new object[5];
                    objArray1[0] = "Error adopting data from IDSYS : \n\n";
                    objArray1[1] = (Convert.ToInt16(WBUser.UserLevel) > 1) ? exception.Message : exception.ToString();
                    object[] local2 = objArray1;
                    local2[2] = "\n\nProcess time: ";
                    local2[3] = elapsedMilliseconds;
                    local2[4] = " ms";
                    MessageBox.Show(string.Concat(local2), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.IDSYSErr = "Error adopting data from IDSYS : \n\n" + exception.ToString();
                err = true;
                dictionary3 = new Dictionary<string, List<Dictionary<string, string>>>();
            }
            return dictionary3;
        }

        public Dictionary<string, List<Dictionary<string, string>>> getDataFromIDSYSContract(string url, string postData, out bool err)
        {
            Dictionary<string, List<Dictionary<string, string>>> dictionary4;
            Stopwatch stopwatch = Stopwatch.StartNew();
            ServicePointManager.ServerCertificateValidationCallback = <>c.<>9__5_0 ??= (<sender>, <certificate>, <chain>, <sslPolicyErrors>) => true;
            try
            {
                Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                bool flag = false;
                HttpWebRequest request = (HttpWebRequest) WebRequest.Create(url);
                request.ContentType = "application/json";
                request.Method = "POST";
                using (StreamWriter writer = new StreamWriter(request.GetRequestStream()))
                {
                    writer.Write(postData);
                    writer.Flush();
                    writer.Close();
                }
                using (StreamReader reader = new StreamReader(((HttpWebResponse) request.GetResponse()).GetResponseStream()))
                {
                    flag = true;
                    List<Dictionary<string, object>> list2 = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(JsonConvert.DeserializeObject<Dictionary<string, object>>(reader.ReadToEnd())["d"].ToString());
                    List<Dictionary<string, string>> list3 = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(list2[0]["detail"].ToString());
                    List<Dictionary<string, string>> list4 = new List<Dictionary<string, string>> {
                        JsonConvert.DeserializeObject<Dictionary<string, string>>(list2[0]["header"].ToString())
                    };
                    dictionary.Add("header", list4);
                    dictionary.Add("detail", list3);
                }
                if (flag)
                {
                    err = false;
                    this.IDSYSErr = "";
                    dictionary4 = dictionary;
                }
                else
                {
                    if (this.auto == "N")
                    {
                        MessageBox.Show("Data is not found in IDSYS!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    this.IDSYSErr = "Data is not found in IDSYS!";
                    err = true;
                    dictionary4 = new Dictionary<string, List<Dictionary<string, string>>>();
                }
            }
            catch (WebException exception)
            {
                stopwatch.Stop();
                long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                if (this.auto == "N")
                {
                    object[] objArray1 = new object[5];
                    objArray1[0] = "Error adopting data from IDSYS : \n\n";
                    objArray1[1] = (Convert.ToInt16(WBUser.UserLevel) > 1) ? exception.Message : exception.ToString();
                    object[] local2 = objArray1;
                    local2[2] = "\n\nProcess time: ";
                    local2[3] = elapsedMilliseconds;
                    local2[4] = " ms";
                    MessageBox.Show(string.Concat(local2), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.IDSYSErr = "Error adopting data from IDSYS : \n\n" + exception.ToString();
                string str3 = new StreamReader(exception.Response.GetResponseStream()).ReadToEnd();
                err = true;
                dictionary4 = new Dictionary<string, List<Dictionary<string, string>>>();
            }
            return dictionary4;
        }

        public string getURL(string rfcName)
        {
            string str = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_table", "SELECT RFC_URL FROM wb_mulesoftURL WHERE " + WBData.CompanyLocation(" AND RFC_NAME = '" + rfcName + "'"), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                if (this.auto == "N")
                {
                    MessageBox.Show("URL for RFC " + rfcName + " has not been maintained yet!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                str = table.DT.Rows[0]["RFC_URL"].ToString();
                if ((str == "") && (this.auto == "N"))
                {
                    MessageBox.Show("URL for RFC " + rfcName + " has not been maintained yet!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            table.Dispose();
            return str;
        }

        public void prepareTable()
        {
            this.syncTable = new Dictionary<string, List<Dictionary<string, string>>>();
        }

        public Dictionary<string, List<Dictionary<string, string>>> sendDataToIDSYS(string url, string[] resultHeaderName, out bool err)
        {
            Dictionary<string, List<Dictionary<string, string>>> dictionary3;
            Stopwatch stopwatch = Stopwatch.StartNew();
            ServicePointManager.ServerCertificateValidationCallback = <>c.<>9__9_0 ??= (<sender>, <certificate>, <chain>, <sslPolicyErrors>) => true;
            try
            {
                int num = 0x36ee80;
                Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                List<Dictionary<string, string>> list = null;
                bool flag = false;
                string str = JsonConvert.SerializeObject(this.syncTable);
                HttpWebRequest request = (HttpWebRequest) WebRequest.Create(url);
                request.Timeout = num;
                request.ReadWriteTimeout = num;
                request.ContentType = "application/json";
                request.Method = "POST";
                request.ServicePoint.Expect100Continue = false;
                request.KeepAlive = false;
                request.Headers.Add("client_id", WBSetting.mulesoft_ID);
                request.Headers.Add("client_secret", WBSetting.mulesoft_Key);
                using (StreamWriter writer = new StreamWriter(request.GetRequestStream()))
                {
                    writer.Write(str);
                    writer.Flush();
                    writer.Close();
                }
                HttpWebResponse response = (HttpWebResponse) request.GetResponse();
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    Dictionary<string, object> dictionary2 = JsonConvert.DeserializeObject<Dictionary<string, object>>(reader.ReadToEnd());
                    int index = 0;
                    while (true)
                    {
                        if (index >= resultHeaderName.Length)
                        {
                            break;
                        }
                        foreach (KeyValuePair<string, object> pair in dictionary2)
                        {
                            if (pair.Key.ToString().ToUpper() == resultHeaderName[index].ToUpper())
                            {
                                flag = true;
                                list = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(pair.Value.ToString());
                                dictionary.Add(resultHeaderName[index].ToUpper(), list);
                                break;
                            }
                        }
                        index++;
                    }
                }
                response.Close();
                stopwatch.Stop();
                long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                if (flag)
                {
                    err = false;
                    this.IDSYSErr = "";
                    dictionary3 = dictionary;
                }
                else
                {
                    if (this.auto == "N")
                    {
                        MessageBox.Show(resultHeaderName + " is not found in IDSYS.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    err = true;
                    this.IDSYSErr = resultHeaderName + " is not found in IDSYS.";
                    dictionary3 = new Dictionary<string, List<Dictionary<string, string>>>();
                }
            }
            catch (Exception exception)
            {
                stopwatch.Stop();
                long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                if (this.auto == "N")
                {
                    object[] objArray1 = new object[4];
                    objArray1[0] = "Error synching data to IDSYS : \n\n";
                    objArray1[1] = (Convert.ToInt16(WBUser.UserLevel) > 1) ? exception.Message : exception.ToString();
                    object[] local2 = objArray1;
                    local2[2] = "\n\nProcess time: ";
                    local2[3] = elapsedMilliseconds;
                    MessageBox.Show(string.Concat(local2), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                err = true;
                this.IDSYSErr = "Error synching data to IDSYS : \n\n" + exception.ToString();
                dictionary3 = new Dictionary<string, List<Dictionary<string, string>>>();
            }
            return dictionary3;
        }

        public Dictionary<string, List<Dictionary<string, string>>> uploadDataIDSYS(string url, string postData, out bool err)
        {
            Dictionary<string, List<Dictionary<string, string>>> dictionary3;
            Stopwatch stopwatch = Stopwatch.StartNew();
            ServicePointManager.ServerCertificateValidationCallback = <>c.<>9__6_0 ??= (<sender>, <certificate>, <chain>, <sslPolicyErrors>) => true;
            try
            {
                Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                bool flag = false;
                HttpWebRequest request = (HttpWebRequest) WebRequest.Create(url);
                request.ContentType = "application/x-www-form-urlencoded";
                request.Accept = "application/json";
                request.Method = "POST";
                using (StreamWriter writer = new StreamWriter(request.GetRequestStream()))
                {
                    writer.Write(postData);
                    writer.Flush();
                    writer.Close();
                }
                using (StreamReader reader = new StreamReader(((HttpWebResponse) request.GetResponse()).GetResponseStream()))
                {
                    flag = true;
                    XmlDocument document = new XmlDocument();
                    document.LoadXml(reader.ReadToEnd());
                    List<Dictionary<string, string>> list3 = new List<Dictionary<string, string>>();
                    foreach (JToken token in JObject.Parse(document.GetElementsByTagName("string")[0].InnerText).get_Item("Message"))
                    {
                        Dictionary<string, string> item = new Dictionary<string, string> {
                            { 
                                "Status",
                                token.get_Item("Status").ToString()
                            },
                            { 
                                "Ref",
                                token.get_Item("Ref").ToString()
                            },
                            { 
                                "Remarks",
                                token.get_Item("Remarks").ToString()
                            },
                            { 
                                "Posted",
                                token.get_Item("Posted").ToString()
                            }
                        };
                        list3.Add(item);
                    }
                    dictionary.Add("data", list3);
                }
                if (flag)
                {
                    err = false;
                    this.IDSYSErr = "";
                    dictionary3 = dictionary;
                }
                else
                {
                    if (this.auto == "N")
                    {
                        MessageBox.Show("Data is not found in IDSYS!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    this.IDSYSErr = "Data is not found in IDSYS!";
                    err = true;
                    dictionary3 = new Dictionary<string, List<Dictionary<string, string>>>();
                }
            }
            catch (Exception exception)
            {
                stopwatch.Stop();
                long elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                if (this.auto == "N")
                {
                    object[] objArray1 = new object[5];
                    objArray1[0] = "Error adopting data from IDSYS : \n\n";
                    objArray1[1] = (Convert.ToInt16(WBUser.UserLevel) > 1) ? exception.Message : exception.ToString();
                    object[] local2 = objArray1;
                    local2[2] = "\n\nProcess time: ";
                    local2[3] = elapsedMilliseconds;
                    local2[4] = " ms";
                    MessageBox.Show(string.Concat(local2), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.IDSYSErr = "Error adopting data from IDSYS : \n\n" + exception.ToString();
                err = true;
                dictionary3 = new Dictionary<string, List<Dictionary<string, string>>>();
            }
            return dictionary3;
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly WBIDSYSIntegrator.<>c <>9 = new WBIDSYSIntegrator.<>c();
            public static RemoteCertificateValidationCallback <>9__4_0;
            public static RemoteCertificateValidationCallback <>9__5_0;
            public static RemoteCertificateValidationCallback <>9__6_0;
            public static RemoteCertificateValidationCallback <>9__9_0;

            internal bool <getDataFromIDSYS>b__4_0(object <sender>, X509Certificate <certificate>, X509Chain <chain>, SslPolicyErrors <sslPolicyErrors>) => 
                true;

            internal bool <getDataFromIDSYSContract>b__5_0(object <sender>, X509Certificate <certificate>, X509Chain <chain>, SslPolicyErrors <sslPolicyErrors>) => 
                true;

            internal bool <sendDataToIDSYS>b__9_0(object <sender>, X509Certificate <certificate>, X509Chain <chain>, SslPolicyErrors <sslPolicyErrors>) => 
                true;

            internal bool <uploadDataIDSYS>b__6_0(object <sender>, X509Certificate <certificate>, X509Chain <chain>, SslPolicyErrors <sslPolicyErrors>) => 
                true;
        }
    }
}

