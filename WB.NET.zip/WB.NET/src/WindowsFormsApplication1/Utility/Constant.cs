﻿namespace WindowsFormsApplication1.Utility
{
    using System;

    internal class Constant
    {
        public static string TITIP_TIMBUN_POSTFIX = "#";
        public static string DEFAULT_RESET_PASSWORD = "wilmar2018";
        public const double OS_TOLERANCE = 0.99;
        public static string UWB_DIRECTORY = (Path.GetTempPath() + @"\UWB");
        public static string GATE_DIRECTORY = (UWB_DIRECTORY + @"\BARRIERGATE");
        public static string GATE_COMMAND_FILE = (GATE_DIRECTORY + @"\OPENCOMMAND");
        public static string CHECKPOINT_CONTAINER_CHECK = "CONTAINER_CHECK";
        public static int TOLERANCE_FOR_WRITING_TXT = 10;
        public static int TRANSACTION_UPLOADED_PER_BATCH = 50;
    }
}

