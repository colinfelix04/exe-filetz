﻿namespace WindowsFormsApplication1.Utility
{
    using System;
    using System.Collections;
    using System.Data;
    using System.Windows.Forms;
    using WindowsFormsApplication1;

    internal class WBCard
    {
        public static void checkAndDeleteCardLogforContainerCheck(DataGridView dgvGPDest, string gatepass)
        {
            foreach (DataGridViewRow row in (IEnumerable) dgvGPDest.Rows)
            {
                string sqltext = "";
                bool flag = false;
                WBTable table = new WBTable();
                sqltext = "SELECT checkpoint_code FROM wb_destination_checkpoint WHERE destination_code = '" + row.Cells["source_code"].Value.ToString() + "'";
                table.OpenTable("wb_destination_checkpoint", sqltext, WBData.conn);
                foreach (DataRow row2 in table.DT.Rows)
                {
                    if (row2["checkpoint_code"].ToString() == "CONTAINER_CHECK")
                    {
                        flag = true;
                        break;
                    }
                }
                table.Dispose();
                if (!flag)
                {
                    deleteCardLogforContainerCheck(gatepass, "|reason:EDIT DESTINATION");
                }
            }
        }

        public static void deleteCardLogforContainerCheck(string gatepass, string reason)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_card_log", "SELECT * FROM wb_card_log  WHERE Checkpoint_Code = 'CONTAINER_CHECK'  AND Gatepass_Number = '" + gatepass + "' ", WBData.conn);
            int num = 0;
            while (true)
            {
                if (num >= table.DT.Rows.Count)
                {
                    table.Save();
                    table.Dispose();
                    return;
                }
                table.DR = table.DT.Rows[num];
                table.DR.BeginEdit();
                table.DR["gatepass_number"] = "x" + table.DR["gatepass_number"].ToString();
                table.DR["description"] = table.DR["description"].ToString() + reason;
                table.DR.EndEdit();
                num++;
            }
        }

        public static string getCardNo(string uniqCard)
        {
            string str = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_card", "SELECT card_no FROM wb_card WHERE uniq_card = '" + uniqCard + "'", WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                str = table.DT.Rows[0]["card_no"].ToString();
            }
            table.Dispose();
            return str;
        }

        public static bool getQCStatus(string gatepass_no)
        {
            bool flag = false;
            WBTable table = new WBTable();
            table.OpenTable("wb_card", "SELECT qc_status FROM wb_gatepass WHERE gatepass_number = '" + gatepass_no + "'", WBData.conn);
            flag = (table.DT.Rows.Count > 0) && ((table.DT.Rows[0]["qc_status"].ToString().ToUpper() == "P") || (table.DT.Rows[0]["qc_status"].ToString().ToUpper() == "R"));
            table.Dispose();
            return flag;
        }

        public static string getUniqCardNo(string cardReg)
        {
            string str = "NOCARDFOUND";
            if (cardReg != "")
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_card", "SELECT uniq_card FROM wb_card WHERE card_no = '" + cardReg + "'", WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    str = table.DT.Rows[0]["uniq_card"].ToString();
                }
                table.Dispose();
            }
            return str;
        }

        public static void insertToCardLogforContainerCheck(DataGridView dgvGPDest, string gatepass, string uniqCard)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_card_log", "SELECT * FROM wb_card_log WHERE 1=2", WBData.conn);
            table.DR = table.DT.NewRow();
            table.DR["Type"] = "2";
            table.DR["Checkpoint_Code"] = "CONTAINER_CHECK";
            table.DR["Gatepass_Number"] = gatepass;
            table.DR["Uniq_Card"] = uniqCard;
            table.DR["Description"] = "NO NEED CONTAINER CHECK";
            table.DR["Time"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
            table.DT.Rows.Add(table.DR);
            table.Save();
            table.Dispose();
        }

        public static void insertToCardLogforContainerCheck(DataGridView dgvGPDest, int totalOfContainer, string gatepass, string uniqCard)
        {
            foreach (DataGridViewRow row in (IEnumerable) dgvGPDest.Rows)
            {
                string sqltext = "";
                bool flag = false;
                WBTable table = new WBTable();
                sqltext = "SELECT checkpoint_code FROM wb_destination_checkpoint WHERE destination_code = '" + row.Cells["source_code"].Value.ToString() + "'";
                table.OpenTable("wb_destination_checkpoint", sqltext, WBData.conn);
                foreach (DataRow row2 in table.DT.Rows)
                {
                    if (row2["checkpoint_code"].ToString() == "CONTAINER_CHECK")
                    {
                        flag = true;
                        break;
                    }
                }
                table.Dispose();
                if (!flag)
                {
                    WBTable table4 = new WBTable();
                    string[] textArray3 = new string[] { "SELECT * FROM wb_card_log  WHERE Type = '2'  AND Checkpoint_Code = 'CONTAINER_CHECK'  AND Gatepass_Number = '", gatepass, "'  AND uniq_card = '", uniqCard, "'  AND Description = 'INSERT FROM WB REGISTRATION: NO CONTAINER ENTERED' " };
                    table4.OpenTable("wb_card_log", string.Concat(textArray3), WBData.conn);
                    foreach (DataRow row4 in table4.DT.Rows)
                    {
                        row4.Delete();
                    }
                    table4.Save();
                    table4.Dispose();
                }
                else if (totalOfContainer <= 0)
                {
                    WBTable table2 = new WBTable();
                    string[] textArray1 = new string[] { "SELECT * FROM wb_card_log  WHERE Type = '2'  AND Checkpoint_Code = 'CONTAINER_CHECK'  AND Gatepass_Number = '", gatepass, "'  AND uniq_card = '", uniqCard, "'  AND Description = 'INSERT FROM WB REGISTRATION: NO CONTAINER ENTERED' " };
                    table2.OpenTable("wb_card_log", string.Concat(textArray1), WBData.conn);
                    if (table2.DT.Rows.Count <= 0)
                    {
                        table2.DR = table2.DT.NewRow();
                        table2.DR["Type"] = "2";
                        table2.DR["Checkpoint_Code"] = "CONTAINER_CHECK";
                        table2.DR["Gatepass_Number"] = gatepass;
                        table2.DR["Uniq_Card"] = uniqCard;
                        table2.DR["Description"] = "INSERT FROM WB REGISTRATION: NO CONTAINER ENTERED";
                        table2.DR["Time"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                        table2.DT.Rows.Add(table2.DR);
                        table2.Save();
                    }
                    table2.Dispose();
                }
                else
                {
                    WBTable table3 = new WBTable();
                    string[] textArray2 = new string[] { "SELECT * FROM wb_card_log  WHERE Type = '2'  AND Checkpoint_Code = 'CONTAINER_CHECK'  AND Gatepass_Number = '", gatepass, "'  AND uniq_card = '", uniqCard, "'  AND Description = 'INSERT FROM WB REGISTRATION: NO CONTAINER ENTERED' " };
                    table3.OpenTable("wb_card_log", string.Concat(textArray2), WBData.conn);
                    foreach (DataRow row3 in table3.DT.Rows)
                    {
                        row3.Delete();
                    }
                    table3.Save();
                    table3.Dispose();
                }
            }
        }

        public static void insertToCardLogforRegistration(DataGridView dgvGPDest, string gatepass, string uniqCard, bool needContainerCheck, bool routeHaveCC)
        {
            bool flag = false;
            foreach (DataGridViewRow row in (IEnumerable) dgvGPDest.Rows)
            {
                WBCondition condition = new WBCondition();
                if (condition.getConditionTCS("CC_BEFORE_REG", "destination_code", row.Cells["source_code"].Value.ToString()))
                {
                    flag = true;
                    break;
                }
            }
            WBTable table = new WBTable();
            if (flag)
            {
                if (!needContainerCheck && routeHaveCC)
                {
                    table.OpenTable("wb_card_log", "SELECT * FROM wb_card_log WHERE 1=2", WBData.conn);
                    table.DR = table.DT.NewRow();
                    table.DR["Type"] = "2";
                    table.DR["Checkpoint_Code"] = "CONTAINER_CHECK";
                    table.DR["Gatepass_Number"] = gatepass;
                    table.DR["Uniq_Card"] = uniqCard;
                    table.DR["Description"] = "NO NEED CONTAINER CHECK";
                    table.DR["Time"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                    table.DT.Rows.Add(table.DR);
                    table.Save();
                    table.Dispose();
                }
            }
            else if (!needContainerCheck && routeHaveCC)
            {
                table.OpenTable("wb_card_log", "SELECT * FROM wb_card_log WHERE 1=2", WBData.conn);
                table.DR = table.DT.NewRow();
                table.DR["Type"] = "2";
                table.DR["Checkpoint_Code"] = "CONTAINER_CHECK";
                table.DR["Gatepass_Number"] = gatepass;
                table.DR["Uniq_Card"] = uniqCard;
                table.DR["Description"] = "NO NEED CONTAINER CHECK";
                table.DR["Time"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                table.DT.Rows.Add(table.DR);
                table.Save();
                table.Dispose();
            }
        }

        public static void insertToCardLogforWB(string gatepass, string uniqCard, string refNo, string pMode)
        {
            string sqltext = "SELECT TOP 1 checkpoint_code FROM wb_checkpoint WHERE WB = 'Y' AND deleted = 'N'";
            WBTable table = new WBTable();
            table.OpenTable("wb_terminal", sqltext, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                try
                {
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_card_log", "SELECT * FROM wb_card_log WHERE 1 = 2", WBData.conn);
                    table2.DR = table2.DT.NewRow();
                    table2.DR["Type"] = "2";
                    table2.DR["Checkpoint_Code"] = table.DT.Rows[0]["checkpoint_code"].ToString();
                    table2.DR["Gatepass_Number"] = gatepass;
                    table2.DR["Uniq_Card"] = uniqCard;
                    table2.DR["Description"] = "OK";
                    table2.DR["pmode"] = pMode;
                    table2.DR["ref"] = refNo;
                    table2.DR["Time"] = DateTime.Now;
                    table2.DT.Rows.Add(table2.DR);
                    table2.Save();
                    table2.Dispose();
                }
                catch (Exception)
                {
                }
            }
            table.Dispose();
        }

        public static Tuple<bool, string, string, string, string, string, string> scanCard(string inputNo, string mode, string gatepass)
        {
            string str = "";
            string str2 = "";
            string str3 = "";
            string str4 = "";
            string str5 = "";
            string str6 = "";
            bool flag = false;
            WBTable table = new WBTable();
            str6 = inputNo;
            string[] textArray1 = new string[] { "SELECT * FROM wb_card WHERE uniq_card = '", inputNo, "' or card_no = '", inputNo, "'" };
            table.OpenTable("wb_card", string.Concat(textArray1), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                str = Resource.TCS_Scan005 + "!";
            }
            else
            {
                str6 = table.DT.Rows[0]["card_no"].ToString();
                if (table.DT.Rows[0]["type"].ToString() != "T")
                {
                    str = Resource.TCS_Scan004 + "!";
                }
                else if (mode.ToUpper() == "ADD")
                {
                    WBTable table2 = new WBTable();
                    string[] textArray2 = new string[9];
                    textArray2[0] = "SELECT gatepass_number FROM wb_gatepass WHERE ";
                    textArray2[1] = WBData.CompanyLocation("");
                    textArray2[2] = " AND (Card_No = '";
                    textArray2[3] = inputNo;
                    textArray2[4] = "' OR Card_No = '";
                    textArray2[5] = getUniqCardNo(inputNo);
                    textArray2[6] = "')  AND gatepass_number != '";
                    textArray2[7] = gatepass;
                    textArray2[8] = "' AND (submit_gatepass <> 'Y' or submit_gatepass is null or submit_gatepass= 'N')  AND (Deleted IS NULL OR Deleted = 'N' or Deleted = '')";
                    table2.OpenTable("wb_gatepass", string.Concat(textArray2), WBData.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        str = Resource.TCS_Scan001 + " " + table2.DT.Rows[0]["gatepass_number"].ToString() + "!";
                    }
                    else if ((table.DT.Rows[0]["status"].ToString() == "I") || (table.DT.Rows[0]["status"].ToString() == "F"))
                    {
                        flag = true;
                    }
                    else
                    {
                        str = (table.DT.Rows[0]["status"].ToString() != "A") ? ((table.DT.Rows[0]["block_reason"].ToString() != "") ? (Resource.TCS_Scan003 + " (" + table.DT.Rows[0]["block_reason"].ToString() + ")!") : (Resource.TCS_Scan003 + "!")) : Resource.TCS_Scan006;
                    }
                    table2.Dispose();
                }
                else if (mode.ToUpper() != "EDIT")
                {
                    if (((mode.ToUpper() == "SUBMIT") || (mode.ToUpper() == "TIMBANG")) || (mode.ToUpper() == "DELIVERY"))
                    {
                        WBTable table4 = new WBTable();
                        string[] textArray5 = new string[] { "SELECT * FROM wb_gatepass WHERE ", WBData.CompanyLocation(""), " AND (Card_No = '", inputNo, "' OR Card_No = '", getUniqCardNo(inputNo), "')  AND (submit_gatepass != 'Y' OR submit_gatepass IS NULL or submit_gatepass = 'N')  AND (Deleted IS NULL OR Deleted = 'N' or Deleted = '')" };
                        table4.OpenTable("wb_gatepass", string.Concat(textArray5), WBData.conn);
                        if (table4.DT.Rows.Count <= 0)
                        {
                            str = Resource.TCS_Scan002 + "!";
                        }
                        else if (table.DT.Rows[0]["status"].ToString() != "A")
                        {
                            str = ((table.DT.Rows[0]["status"].ToString() != "I") && (table.DT.Rows[0]["status"].ToString() != "F")) ? ((table.DT.Rows[0]["block_reason"].ToString() != "") ? (Resource.TCS_Scan003 + " (" + table.DT.Rows[0]["block_reason"].ToString() + ")!") : (Resource.TCS_Scan003 + "!")) : "Card status is inactive! Please check the card!";
                        }
                        else
                        {
                            str2 = table4.DT.Rows[0]["gatepass_number"].ToString();
                            str3 = table4.DT.Rows[0]["Ref"].ToString();
                            str4 = table4.DT.Rows[0]["WX"].ToString();
                            str5 = table4.DT.Rows[0]["uniq"].ToString();
                            flag = true;
                        }
                        table4.Dispose();
                    }
                }
                else
                {
                    WBTable table3 = new WBTable();
                    string[] textArray3 = new string[9];
                    textArray3[0] = "SELECT * FROM wb_gatepass WHERE ";
                    textArray3[1] = WBData.CompanyLocation("");
                    textArray3[2] = " AND (Card_No = '";
                    textArray3[3] = inputNo;
                    textArray3[4] = "' OR Card_No = '";
                    textArray3[5] = getUniqCardNo(inputNo);
                    textArray3[6] = "')  AND gatepass_number != '";
                    textArray3[7] = gatepass;
                    textArray3[8] = "' AND (submit_gatepass <> 'Y' or submit_gatepass is null or submit_gatepass='N')  AND (Deleted IS NULL OR Deleted = 'N' or Deleted = '')";
                    table3.OpenTable("wb_gatepass", string.Concat(textArray3), WBData.conn);
                    if (table3.DT.Rows.Count > 0)
                    {
                        str = Resource.TCS_Scan001 + " " + table3.DT.Rows[0]["gatepass_number"].ToString() + "!";
                    }
                    else
                    {
                        string[] textArray4 = new string[] { "SELECT card_no, regCard_no FROM wb_gatepass WHERE ", WBData.CompanyLocation(""), " AND gatepass_number = '", gatepass, "'" };
                        table3.OpenTable("wb_gatepass", string.Concat(textArray4), WBData.conn);
                        if ((table3.DT.Rows[0]["card_no"].ToString() == inputNo) || (table3.DT.Rows[0]["regCard_no"].ToString() == inputNo))
                        {
                            if (table.DT.Rows[0]["status"].ToString() == "A")
                            {
                                flag = true;
                            }
                            else
                            {
                                str = ((table.DT.Rows[0]["status"].ToString() != "I") && (table.DT.Rows[0]["status"].ToString() != "F")) ? ((table.DT.Rows[0]["block_reason"].ToString() != "") ? (Resource.TCS_Scan003 + " (" + table.DT.Rows[0]["block_reason"].ToString() + ")!") : (Resource.TCS_Scan003 + "!")) : Resource.TCS_Scan007;
                            }
                        }
                        else if (table.DT.Rows[0]["status"].ToString() == "A")
                        {
                            str = Resource.TCS_Scan006;
                        }
                        else if ((table.DT.Rows[0]["status"].ToString() == "I") || (table.DT.Rows[0]["status"].ToString() == "F"))
                        {
                            flag = true;
                        }
                        else
                        {
                            str = (table.DT.Rows[0]["block_reason"].ToString() != "") ? (Resource.TCS_Scan003 + " (" + table.DT.Rows[0]["block_reason"].ToString() + ")!") : (Resource.TCS_Scan003 + "!");
                        }
                    }
                    table3.Dispose();
                }
            }
            table.Dispose();
            return new Tuple<bool, string, string, string, string, string, string>(flag, str, str3, str2, str4, str5, str6);
        }

        public static void updateCardLogIfCardIsChanged(string gatepass, string uniqCard)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_card_log", "SELECT * FROM wb_card_log WHERE gatepass_number = '" + gatepass + "'", WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                row.BeginEdit();
                row["Uniq_Card"] = uniqCard;
                row.EndEdit();
            }
            table.Save();
        }

        public static bool updateCardToActive(string regNo)
        {
            bool flag2;
            WBTable table = new WBTable();
            table.OpenTable("wb_card", "SELECT * FROM wb_card WHERE card_no = '" + regNo + "'", WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                table.Dispose();
                flag2 = false;
            }
            else
            {
                table.DR = table.DT.Rows[0];
                table.DR.BeginEdit();
                table.DR["status"] = "A";
                table.DR.EndEdit();
                table.Save();
                table.Dispose();
                flag2 = true;
            }
            return flag2;
        }

        public static bool updateCardToFree(string regNo)
        {
            bool flag2;
            WBTable table = new WBTable();
            table.OpenTable("wb_card", "SELECT * FROM wb_card WHERE card_no = '" + regNo + "'", WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                table.Dispose();
                flag2 = false;
            }
            else
            {
                table.DR = table.DT.Rows[0];
                table.DR.BeginEdit();
                table.DR["status"] = "F";
                table.DR.EndEdit();
                table.Save();
                table.Dispose();
                flag2 = true;
            }
            return flag2;
        }
    }
}

