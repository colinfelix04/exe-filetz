﻿namespace WindowsFormsApplication1.Utility
{
    using System;
    using WindowsFormsApplication1;

    internal class WBSync
    {
        private static WBTable tblAutoSync;
        public static string AutoSyncCode = "";
        public string[] status;

        public void DoAutoSync(string pAutoSyncCode, string pCol, bool unshowWindow)
        {
            AutoSyncCode = pAutoSyncCode;
            tblAutoSync = new WBTable();
            if (pAutoSyncCode == "")
            {
                tblAutoSync.OpenTable("wb_auto_sync", "Select * from wb_auto_sync where " + WBData.CompanyLocation(""), WBData.conn);
            }
            else
            {
                tblAutoSync.OpenTable("wb_auto_sync", "Select * from wb_auto_sync where " + WBData.CompanyLocation(" and sync_code = '" + AutoSyncCode + "'"), WBData.conn);
            }
            if (tblAutoSync.DT.Rows.Count > 0)
            {
                string[] newStatus = new string[tblAutoSync.DT.Rows.Count];
                int index = 0;
                while (true)
                {
                    if (index >= tblAutoSync.DT.Rows.Count)
                    {
                        this.status = this.f_loadStatus(newStatus);
                        break;
                    }
                    string name = tblAutoSync.DT.Rows[index]["FC_Name"].ToString();
                    if (name != "")
                    {
                        newStatus[index] = name;
                        Sync sync = new Sync();
                        object[] parameters = new object[] { "", unshowWindow };
                        string str2 = sync.GetType().GetMethod(name).Invoke(sync, parameters).ToString();
                    }
                    index++;
                }
            }
        }

        public string[] f_loadStatus(string[] newStatus)
        {
            int index = 0;
            int num2 = 0;
            string[] strArray = null;
            if (newStatus != null)
            {
                if (this.status == null)
                {
                    strArray = new string[newStatus.Length];
                }
                else
                {
                    strArray = new string[this.status.Length + newStatus.Length];
                    foreach (string str in this.status)
                    {
                        strArray[index] = str;
                        index++;
                    }
                }
                foreach (string str2 in newStatus)
                {
                    strArray[num2] = str2;
                    num2++;
                }
            }
            return strArray;
        }

        private string getAutoSyncValue(string pAutoSyncCode, string pCol)
        {
            string str = "";
            AutoSyncCode = pAutoSyncCode;
            tblAutoSync = new WBTable();
            tblAutoSync.OpenTable("wb_auto_sync", "Select " + pCol + " from wb_auto_sync where " + WBData.CompanyLocation(" and sync_code = '" + AutoSyncCode + "'"), WBData.conn);
            if (tblAutoSync.DT.Rows.Count == 1)
            {
                str = tblAutoSync.DT.Rows[0][pCol].ToString();
            }
            return str;
        }

        public bool getSettingAutoSync(string pAutoSyncCode)
        {
            bool flag = false;
            AutoSyncCode = pAutoSyncCode;
            tblAutoSync = new WBTable();
            if (pAutoSyncCode == "")
            {
                tblAutoSync.OpenTable("wb_auto_sync", "Select * from wb_auto_sync where " + WBData.CompanyLocation(""), WBData.conn);
            }
            else
            {
                tblAutoSync.OpenTable("wb_auto_sync", "Select * from wb_auto_sync where " + WBData.CompanyLocation(" and sync_code = '" + AutoSyncCode + "'"), WBData.conn);
            }
            if (tblAutoSync.DT.Rows.Count > 0)
            {
                flag = true;
            }
            return flag;
        }
    }
}

