﻿namespace WindowsFormsApplication1.Utility
{
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Windows.Forms;
    using WindowsFormsApplication1;

    public class WBManual
    {
        public static void LoadManual(string MANUAL_CODE)
        {
            string str = "";
            string str2 = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_user_manual", "select * from wb_user_manual where manual_code = '" + MANUAL_CODE + "'", WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                MessageBox.Show(string.Format(Resource.WBMANUAL_MANUAL_CODE_NOT_MAINTAINED, MANUAL_CODE), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                str = table.DT.Rows[0]["filename"].ToString();
                if (File.Exists(Application.StartupPath.ToString() + @"\Manual\" + str))
                {
                    Process.Start(new ProcessStartInfo(Application.StartupPath.ToString() + @"\Manual\" + str));
                }
                else
                {
                    str2 = table.DT.Rows[0]["description"].ToString();
                    if (!string.IsNullOrEmpty(str))
                    {
                        str = str + "(" + str2 + ")";
                    }
                    MessageBox.Show(string.Format(Resource.WBMANUAL_MANUAL_DOCUMENT_NOT_FOUND, str), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }
    }
}

