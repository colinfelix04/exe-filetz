﻿namespace WindowsFormsApplication1.Utility
{
    using CrystalDecisions.CrystalReports.Engine;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Windows.Forms;
    using WindowsFormsApplication1;

    internal class WBUtility
    {
        public ReportDocument cryRpt = new ReportDocument();
        public static bool expiredSPB;
        public static bool diffWBDO;
        public static bool diffRelCode;

        public static void AlphabetDotSpace(KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "ABCDEFGHIJKLMNOPQRSTUVWXYZ. ".IndexOfAny(anyOf) <= -1;
            }
        }

        public static void AlphabetNumber(KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".IndexOfAny(anyOf) <= -1;
            }
        }

        public static void AlphabetNumber_(KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_".IndexOfAny(anyOf) <= -1;
            }
        }

        public static void AlphabetNumberDotSpace(KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789. ".IndexOfAny(anyOf) <= -1;
            }
        }

        public static void AlphabetOnly(KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".IndexOfAny(anyOf) <= -1;
            }
        }

        public static void AlphabetSpace(KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ".IndexOfAny(anyOf) <= -1;
            }
        }

        public static void BlacklistData(string Table_Name, int nCurrRow, string Reason, WBTable ztable)
        {
            string keyField = "";
            Cursor.Current = Cursors.WaitCursor;
            ztable.ReOpen();
            nCurrRow = ztable.GetPosRec(ztable.uniq);
            keyField = ztable.DT.Rows[nCurrRow]["uniq"].ToString();
            ztable.DR = ztable.DT.Rows[nCurrRow];
            ztable.DR.BeginEdit();
            ztable.DR["Coy"] = WBData.sCoyCode;
            ztable.DR["Location_Code"] = WBData.sLocCode;
            ztable.DR["Reason"] = Reason;
            ztable.DR["Black_list"] = "Y";
            ztable.DR["Change_By"] = WBUser.UserID;
            ztable.DR["Change_Date"] = DateTime.Now;
            ztable.DR.EndEdit();
            ztable.Save();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { "DELETE", WBUser.UserID, Reason };
            Program.updateLogHeader(Table_Name, keyField, logField, logValue);
            ztable.ReOpen();
            Cursor.Current = Cursors.Default;
        }

        public static void CheckInput(KeyPressEventArgs e, string type)
        {
            bool flag = true;
            char[] separator = new char[] { '|' };
            string[] strArray = type.Split(separator);
            int index = 0;
            while (true)
            {
                if (index >= strArray.Length)
                {
                    break;
                }
                string str = strArray[index].ToString();
                if (str == "A")
                {
                    flag = !(((e.KeyChar < 'A') || (e.KeyChar > 'Z')) ? ((e.KeyChar >= 'a') && (e.KeyChar <= 'z')) : true);
                }
                else if (str == "N")
                {
                    flag = (e.KeyChar < '0') || (e.KeyChar > '9');
                }
                else if (str == "S")
                {
                    flag = e.KeyChar != ' ';
                }
                else if (str == "U")
                {
                    flag = e.KeyChar != '_';
                }
                else if (str == "D")
                {
                    flag = e.KeyChar != '.';
                }
                else if (str == "GM")
                {
                    flag = e.KeyChar != '/';
                }
                if (!flag)
                {
                    break;
                }
                index++;
            }
            if (((e.KeyChar == '\x0001') || ((e.KeyChar == '\x0003') || ((e.KeyChar == '\b') || (e.KeyChar == '\x0016')))) || (e.KeyChar == '\x0018'))
            {
                flag = false;
            }
            e.Handled = flag;
        }

        public static bool CheckLeave(string text, string type)
        {
            bool flag3;
            bool flag = false;
            if (string.IsNullOrEmpty(text))
            {
                flag3 = false;
            }
            else
            {
                char[] separator = new char[] { '|' };
                string[] strArray = type.Split(separator);
                string str = "";
                int index = 0;
                while (true)
                {
                    if (index >= strArray.Length)
                    {
                        flag = Regex.IsMatch(text, "[^" + str + "]");
                        flag3 = flag;
                        break;
                    }
                    string str2 = strArray[index].ToString();
                    str = (str2 == "A") ? (str + "A-Z") : ((str2 == "N") ? (str + "0-9") : ((str2 == "S") ? (str + " ") : ((str2 == "U") ? (str + "_") : ((str2 == "D") ? (str + ".") : ((str2 == "GM") ? (str + "/") : "")))));
                    index++;
                }
            }
            return flag3;
        }

        private static bool checkRelCode(DataGridView dgvDO)
        {
            bool diffRelCode;
            int count = dgvDO.Rows.Count;
            WBUtility.diffRelCode = false;
            int num2 = 0;
            while (true)
            {
                if (num2 < dgvDO.Rows.Count)
                {
                    DataGridViewRow row = dgvDO.Rows[num2];
                    if ((num2 + 1) != count)
                    {
                        DataGridViewRow row2 = dgvDO.Rows[num2 + 1];
                        if (row.Cells["relation_code"].Value.ToString().Trim() != row2.Cells["relation_code"].Value.ToString().Trim())
                        {
                            WBUtility.diffRelCode = true;
                            diffRelCode = WBUtility.diffRelCode;
                            break;
                        }
                        num2++;
                        continue;
                    }
                }
                diffRelCode = WBUtility.diffRelCode;
                break;
            }
            return diffRelCode;
        }

        public static bool CheckSPB(string nDN, DataGridView dgvDO)
        {
            bool flag5;
            string str = Convert_to_Regex(nDN);
            WBTable table = new WBTable();
            int num = 0;
            while (true)
            {
                if (num < dgvDO.Rows.Count)
                {
                    DataGridViewRow row = dgvDO.Rows[num];
                    string[] textArray1 = new string[] { "Select delivery_note_from,delivery_note_to From wb_delivery_note with (nolock) where Do_No='", row.Cells["DO_No"].Value.ToString().Trim(), "' and Delivery_Note_From like '", str, "' and Delivery_Note_to like '", str, "'" };
                    table.OpenTable("wb_delivery_note", string.Concat(textArray1), WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= table.DT.Rows.Count)
                            {
                                break;
                            }
                            table.DR = table.DT.Rows[num2];
                            bool flag2 = nDN.Length != table.DR["delivery_note_from"].ToString().Length;
                            if (flag2 || ((string.Compare(nDN, table.DR["Delivery_Note_From"].ToString()) < 0) || (string.Compare(nDN, table.DR["Delivery_Note_to"].ToString()) > 0)))
                            {
                                num2++;
                                continue;
                            }
                            if (!checkWBDO(dgvDO))
                            {
                                table.Dispose();
                                flag5 = true;
                            }
                            else
                            {
                                table.Dispose();
                                flag5 = false;
                            }
                            return flag5;
                        }
                    }
                    num++;
                    continue;
                }
                else
                {
                    table.Dispose();
                    flag5 = false;
                }
                break;
            }
            return flag5;
        }

        public static bool CheckSPBv2(string nDN, DataGridView dgvDO)
        {
            bool flag6;
            string str = Convert_to_Regex(nDN);
            WBTable table = new WBTable();
            expiredSPB = false;
            int num = 0;
            while (true)
            {
                if (num < dgvDO.Rows.Count)
                {
                    DataGridViewRow row = dgvDO.Rows[num];
                    string[] textArray1 = new string[] { "Select delivery_note_from,delivery_note_to,expired_date From wb_delivery_note with (nolock) where relation_code='", row.Cells["relation_code"].Value.ToString().Trim(), "' and Delivery_Note_From like '", str, "' and Delivery_Note_to like '", str, "'" };
                    table.OpenTable("wb_delivery_note", string.Concat(textArray1), WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= table.DT.Rows.Count)
                            {
                                break;
                            }
                            table.DR = table.DT.Rows[num2];
                            bool flag2 = nDN.Length != table.DR["delivery_note_from"].ToString().Length;
                            if (!flag2 && ((string.Compare(nDN, table.DR["Delivery_Note_From"].ToString()) >= 0) && (string.Compare(nDN, table.DR["Delivery_Note_to"].ToString()) <= 0)))
                            {
                                if (Convert.ToDateTime(GetServerDatetime().ToShortDateString()) > Convert.ToDateTime(table.DR["expired_date"].ToString()))
                                {
                                    expiredSPB = true;
                                }
                                else
                                {
                                    if (!checkRelCode(dgvDO))
                                    {
                                        table.Dispose();
                                        flag6 = true;
                                    }
                                    else
                                    {
                                        table.Dispose();
                                        flag6 = false;
                                    }
                                    return flag6;
                                }
                            }
                            num2++;
                        }
                    }
                    num++;
                    continue;
                }
                else
                {
                    table.Dispose();
                    flag6 = false;
                }
                break;
            }
            return flag6;
        }

        public static bool CheckValidSPB(string nDN, DataGridView dgvDO)
        {
            bool flag4;
            expiredSPB = false;
            diffWBDO = false;
            diffRelCode = false;
            if (CheckSPBv2(nDN, dgvDO) || (WBSetting.checkCutOffDeliveryNote() && CheckSPB(nDN, dgvDO)))
            {
                flag4 = true;
            }
            else if (!WBSetting.checkCutOffDeliveryNote() && CheckSPB(nDN, dgvDO))
            {
                MessageBox.Show(string.Format(Resource.DeliveryNote_009, WBSetting.DeliveryNoteCutOffDate.ToShortDateString().ToString()), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                flag4 = false;
            }
            else if (expiredSPB)
            {
                MessageBox.Show(Resource.DeliveryNote_005, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                flag4 = false;
            }
            else if (diffWBDO)
            {
                MessageBox.Show(Resource.DeliveryNote_006, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                flag4 = false;
            }
            else if (diffRelCode)
            {
                MessageBox.Show(Resource.DeliveryNote_007, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                flag4 = false;
            }
            else
            {
                MessageBox.Show(Resource.DeliveryNote_008, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                flag4 = false;
            }
            return flag4;
        }

        private static bool checkWBDO(DataGridView dgvDO)
        {
            bool flag3;
            int count = dgvDO.Rows.Count;
            diffWBDO = false;
            int num2 = 0;
            while (true)
            {
                if (num2 < dgvDO.Rows.Count)
                {
                    DataGridViewRow row = dgvDO.Rows[num2];
                    if ((num2 + 1) != count)
                    {
                        DataGridViewRow row2 = dgvDO.Rows[num2 + 1];
                        if (row.Cells["do_no"].Value.ToString().Trim() != row2.Cells["do_no"].Value.ToString().Trim())
                        {
                            diffWBDO = true;
                            flag3 = true;
                            break;
                        }
                        num2++;
                        continue;
                    }
                }
                flag3 = false;
                break;
            }
            return flag3;
        }

        private static string Convert_to_Regex(string s)
        {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
            {
                bool flag1;
                if (s[i].Equals('0') || (s[i].Equals('1') || (s[i].Equals('2') || (s[i].Equals('3') || (s[i].Equals('4') || (s[i].Equals('5') || (s[i].Equals('6') || (s[i].Equals('7') || s[i].Equals('8')))))))))
                {
                    flag1 = true;
                }
                else
                {
                    flag1 = s[i].Equals('9');
                }
                if (flag1)
                {
                    builder.Append("[0-9]");
                }
                else
                {
                    builder.Append(s[i]);
                }
            }
            return builder.ToString();
        }

        public static DateTime GetServerDatetime()
        {
            string sqltext = "select getdate() as date";
            WBTable table = new WBTable();
            table.OpenTable("WB_COMPANY", sqltext, WBData.conn);
            DateTime time = Convert.ToDateTime(table.DT.Rows[0]["date"].ToString());
            table.Dispose();
            return time;
        }

        public static string getSplitV2Ext(int extPlus65)
        {
            List<string> list = new List<string>();
            char ch = 'A';
            while (ch <= 'Z')
            {
                char ch2 = 'A';
                while (true)
                {
                    if (ch2 > 'Z')
                    {
                        ch = (char) (ch + '\x0001');
                        break;
                    }
                    list.Add(ch.ToString() + ch2.ToString());
                    ch2 = (char) (ch2 + '\x0001');
                }
            }
            return list[extPlus65 - 0x41];
        }

        public static void MarkDeleteData(string Table_Name, int nCurrRow, string Reason, WBTable ztable)
        {
            string keyField = "";
            Cursor.Current = Cursors.WaitCursor;
            ztable.ReOpen();
            nCurrRow = ztable.GetPosRec(ztable.uniq);
            keyField = ztable.DT.Rows[nCurrRow]["uniq"].ToString();
            ztable.DR = ztable.DT.Rows[nCurrRow];
            ztable.DR.BeginEdit();
            ztable.DR["Coy"] = WBData.sCoyCode;
            ztable.DR["Location_Code"] = WBData.sLocCode;
            ztable.DR["Reason"] = Reason;
            ztable.DR["Deleted"] = "Y";
            ztable.DR["Delete_By"] = WBUser.UserID;
            ztable.DR["Delete_Date"] = DateTime.Now;
            ztable.DR.EndEdit();
            ztable.Save();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { "DELETE", WBUser.UserID, Reason };
            Program.updateLogHeader(Table_Name, keyField, logField, logValue);
            ztable.ReOpen();
            Cursor.Current = Cursors.Default;
        }

        public static void MarkDeleteDataNoCoyLoc(string Table_Name, int nCurrRow, string Reason, WBTable ztable)
        {
            string keyField = "";
            Cursor.Current = Cursors.WaitCursor;
            ztable.ReOpen();
            nCurrRow = ztable.GetPosRec(ztable.uniq);
            keyField = ztable.DT.Rows[nCurrRow]["uniq"].ToString();
            ztable.DR = ztable.DT.Rows[nCurrRow];
            ztable.DR.BeginEdit();
            ztable.DR["Reason"] = Reason;
            ztable.DR["Deleted"] = "Y";
            ztable.DR["Delete_By"] = WBUser.UserID;
            ztable.DR["Delete_Date"] = DateTime.Now;
            ztable.DR.EndEdit();
            ztable.Save();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { "DELETE", WBUser.UserID, Reason };
            Program.updateLogHeader(Table_Name, keyField, logField, logValue);
            ztable.ReOpen();
            Cursor.Current = Cursors.Default;
        }

        public static string MergeDNNumber(string from, string to)
        {
            List<string> list = new List<string>();
            string str = "";
            string str2 = from.Substring(0, 2);
            int num = Convert.ToInt32(from.Substring(2, 8));
            int num2 = Convert.ToInt32(to.Substring(2, 8));
            for (int i = num; i <= num2; i++)
            {
                if (i == num)
                {
                    str = "'" + str2 + i.ToString("D8") + "'";
                }
                else
                {
                    string[] textArray1 = new string[] { str, ", '", str2, i.ToString("D8"), "'" };
                    str = string.Concat(textArray1);
                }
            }
            return str;
        }

        public static void NumberDecimalSeparator(KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "1234567890.".IndexOfAny(anyOf) <= -1;
            }
        }

        public static void NumberOnly(KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "0123456789".IndexOfAny(anyOf) <= -1;
            }
        }

        public static void ReloadTicket(ReportDocument cryRpt)
        {
            if (cryRpt.FileName.ToLower().Contains("ticketrefinery_multiline1.rpt"))
            {
                cryRpt.Load(WBSetting.ticket_MultiLine1);
            }
            else if (cryRpt.FileName.ToLower().Contains("ticketrefinery_multiline2.rpt"))
            {
                cryRpt.Load(WBSetting.ticket_MultiLine2);
            }
            else if (cryRpt.FileName.ToLower().Contains("ticketlangsir.rpt"))
            {
                cryRpt.Load(WBSetting.ticketLangsir);
            }
            else if (cryRpt.FileName.ToLower().Contains("ticketlangsir2.rpt"))
            {
                cryRpt.Load(WBSetting.ticketLangsir2);
            }
            else
            {
                cryRpt.Load(WBSetting.ticket);
            }
            cryRpt = Program.rptLogon(cryRpt);
            cryRpt.Refresh();
        }

        public static void UnblacklistData(string Table_Name, int nCurrRow, string Reason, WBTable ztable)
        {
            string keyField = "";
            Cursor.Current = Cursors.WaitCursor;
            ztable.ReOpen();
            nCurrRow = ztable.GetPosRec(ztable.uniq);
            keyField = ztable.DT.Rows[nCurrRow]["uniq"].ToString();
            ztable.DR = ztable.DT.Rows[nCurrRow];
            ztable.DR.BeginEdit();
            ztable.DR["Coy"] = WBData.sCoyCode;
            ztable.DR["Location_Code"] = WBData.sLocCode;
            ztable.DR["Reason"] = Reason;
            ztable.DR["Black_list"] = "N";
            ztable.DR["Change_By"] = WBUser.UserID;
            ztable.DR["Change_Date"] = DateTime.Now;
            ztable.DR.EndEdit();
            ztable.Save();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { "UNDELETE", WBUser.UserID, Reason };
            Program.updateLogHeader(Table_Name, keyField, logField, logValue);
            ztable.ReOpen();
            Cursor.Current = Cursors.Default;
        }

        public static void UnMarkDeleteData(string Table_Name, int nCurrRow, string Reason, WBTable ztable)
        {
            string keyField = "";
            Cursor.Current = Cursors.WaitCursor;
            ztable.ReOpen();
            nCurrRow = ztable.GetPosRec(ztable.uniq);
            keyField = ztable.DT.Rows[nCurrRow]["uniq"].ToString();
            ztable.DR = ztable.DT.Rows[nCurrRow];
            ztable.DR.BeginEdit();
            ztable.DR["Coy"] = WBData.sCoyCode;
            ztable.DR["Location_Code"] = WBData.sLocCode;
            ztable.DR["Reason"] = Reason;
            ztable.DR["Deleted"] = "N";
            ztable.DR["Delete_By"] = WBUser.UserID;
            ztable.DR["Delete_Date"] = DateTime.Now;
            ztable.DR.EndEdit();
            ztable.Save();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { "UNDELETE", WBUser.UserID, Reason };
            Program.updateLogHeader(Table_Name, keyField, logField, logValue);
            ztable.ReOpen();
            Cursor.Current = Cursors.Default;
        }

        public static void UnMarkDeleteDataNoCoyLoc(string Table_Name, int nCurrRow, string Reason, WBTable ztable)
        {
            string keyField = "";
            Cursor.Current = Cursors.WaitCursor;
            ztable.ReOpen();
            nCurrRow = ztable.GetPosRec(ztable.uniq);
            keyField = ztable.DT.Rows[nCurrRow]["uniq"].ToString();
            ztable.DR = ztable.DT.Rows[nCurrRow];
            ztable.DR.BeginEdit();
            ztable.DR["Reason"] = Reason;
            ztable.DR["Deleted"] = "N";
            ztable.DR["Delete_By"] = WBUser.UserID;
            ztable.DR["Delete_Date"] = DateTime.Now;
            ztable.DR.EndEdit();
            ztable.Save();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { "UNDELETE", WBUser.UserID, Reason };
            Program.updateLogHeader(Table_Name, keyField, logField, logValue);
            ztable.ReOpen();
            Cursor.Current = Cursors.Default;
        }

        public static DataTable WBTableToDataTable(WBTable sourceTable, DataTable destinationTable)
        {
            DataRow row = null;
            destinationTable = sourceTable.DT.Clone();
            for (int i = 0; i < sourceTable.DT.Rows.Count; i++)
            {
                row = destinationTable.NewRow();
                sourceTable.DR = sourceTable.DT.Rows[i];
                row.ItemArray = sourceTable.DR.ItemArray;
                destinationTable.Rows.Add(row);
            }
            return destinationTable;
        }
    }
}

