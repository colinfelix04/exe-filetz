﻿namespace WindowsFormsApplication1.Utility
{
    using System;
    using System.Data;
    using WindowsFormsApplication1;

    internal class WBQueue
    {
        public const int TOLERANCE_TO_DELETE_QUEUE = 3;

        public static void deleteFromQueue(string gatepass, string destination)
        {
            int num;
            string sqltext = "";
            string str2 = "";
            WBTable table = new WBTable();
            sqltext = "SELECT checkpoint_code FROM wb_destination_checkpoint WHERE destination_code = '" + destination + "'";
            table.OpenTable("wb_destination_checkpoint", sqltext, WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                WBTable table2 = new WBTable();
                sqltext = "SELECT Type FROM wb_checkpoint WHERE checkpoint_code = '" + row["checkpoint_code"].ToString() + "'";
                table2.OpenTable("wb_checkpoint", sqltext, WBData.conn);
                bool flag = table2.DT.Rows.Count > 0;
                if (flag && (table2.DT.Rows[0]["Type"].ToString() == "D"))
                {
                    str2 = row["checkpoint_code"].ToString();
                }
                table2.Dispose();
            }
            if (str2 == "")
            {
                goto TR_0004;
            }
            else
            {
                num = 0;
            }
            while (num < 3)
            {
                try
                {
                    WBTable table3 = new WBTable();
                    string[] textArray1 = new string[] { "SELECT * FROM wb_queuing WHERE gatepass_number = '", gatepass, "' AND destination_code = '", str2, "'" };
                    sqltext = string.Concat(textArray1);
                    table3.OpenTable("wb_queuing", sqltext, WBData.conn);
                    if (table3.DT.Rows.Count > 0)
                    {
                        table3.DT.Rows[0].Delete();
                        table3.Save();
                    }
                    table3.Dispose();
                }
                catch
                {
                    num++;
                    continue;
                }
                break;
            }
        TR_0004:
            table.Dispose();
        }

        public static void insertToQueue(string gatepass, string destination)
        {
            string sqltext = "";
            string str2 = "";
            WBTable table = new WBTable();
            sqltext = "SELECT checkpoint_code FROM wb_destination_checkpoint WHERE destination_code = '" + destination + "'";
            table.OpenTable("wb_destination_checkpoint", sqltext, WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                WBTable table3 = new WBTable();
                sqltext = "SELECT Type FROM wb_checkpoint WHERE checkpoint_code = '" + row["checkpoint_code"].ToString() + "'";
                table3.OpenTable("wb_checkpoint", sqltext, WBData.conn);
                bool flag = table3.DT.Rows.Count > 0;
                if (flag && (table3.DT.Rows[0]["Type"].ToString() == "D"))
                {
                    str2 = row["checkpoint_code"].ToString();
                }
                table3.Dispose();
            }
            WBTable table2 = new WBTable();
            sqltext = "SELECT queue_list_via_wilpas FROM wb_checkpoint WHERE checkpoint_code = '" + destination + "' AND type='D' AND deleted = 'N'";
            table2.OpenTable("wb_checkpoint get autocalling by wilpas", sqltext, WBData.conn);
            string str3 = table2.DT.Rows[0]["queue_list_via_wilpas"].ToString();
            if ((str2 != "") && (str3 == "N"))
            {
                WBTable table4 = new WBTable();
                sqltext = "SELECT * FROM wb_queuing WHERE 1 = 2";
                table4.OpenTable("wb_queuing", sqltext, WBData.conn);
                table4.DR = table4.DT.NewRow();
                table4.DR["Gatepass_number"] = gatepass;
                table4.DR["Queue_Time"] = DateTime.Now;
                table4.DR["Destination_Code"] = str2;
                table4.DR["Priority"] = "N";
                table4.DT.Rows.Add(table4.DR);
                table4.Save();
                table4.Dispose();
            }
            table.Dispose();
        }
    }
}

