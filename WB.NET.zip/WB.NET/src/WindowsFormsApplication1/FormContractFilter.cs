﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormContractFilter : Form
    {
        public string pFilter = "";
        public bool saved = false;
        public string[] pField = new string[20];
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private TextBox textVend;
        private TextBox textCommodity;
        private TextBox textType;
        private TextBox textTransporter;
        private Label label1;
        private Label label46;
        private Label label9;
        private TextBox textConf;
        private TextBox textContract;
        private Label label4;
        private Label label8;
        private Label label6;
        private Label label7;
        public TextBox textDO;
        private Label label12;
        private TextBox textEstate;
        private GroupBox groupBox7;
        private Label label11;
        private TextBox textPO;
        private Label label23;
        private TextBox textNEGO;
        private Label label22;
        private TextBox textSO;
        private Label label21;
        private TextBox textGRPO;
        private Label label20;
        private TextBox textSTO;
        private Label label2;
        private Button btnFilter;
        private Button button3;
        private Button button2;
        private Button button4;
        private Button btnEstate;
        private Button buttonType;
        private Label label3;
        private Button button1;
        private RadioButton rdoKB;
        private RadioButton rdoNKB;
        private TextBox dateDoTo;
        private TextBox dateDoFrom;
        private TextBox DateEntryTo;
        private TextBox DateEntryFrom;
        private Label label5;
        private Label label10;
        private Label label13;

        public FormContractFilter()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void btnEstate_Click(object sender, EventArgs e)
        {
            FormEstate estate = new FormEstate {
                pMode = "CHOOSE"
            };
            estate.ShowDialog();
            if (estate.ReturnRow != null)
            {
                this.textEstate.Text = estate.ReturnRow["Estate_Code"].ToString();
            }
            estate.Dispose();
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            DateTime time;
            DateTime time2;
            int index = 0;
            string str = " = ";
            string text = "";
            if (this.rdoKB.Checked)
            {
                this.pField[index] = " berikat = 'Y' ";
                index++;
            }
            else if (this.rdoKB.Checked)
            {
                this.pField[index] = " berikat = 'N' ";
                index++;
            }
            else if (this.rdoKB.Checked && this.rdoNKB.Checked)
            {
                this.pField[index] = " berikat = 'Y' And berikat = 'N' ";
                index++;
            }
            if (this.textType.Text != "")
            {
                if (this.checkFind(this.textType.Text))
                {
                    str = " like ";
                    text = this.replaceFind(this.textType.Text);
                }
                else
                {
                    str = " = ";
                    text = this.textType.Text;
                }
                string[] textArray1 = new string[] { " transaction_code ", str, "'", text, "'" };
                this.pField[index] = string.Concat(textArray1);
                index++;
            }
            if (this.textDO.Text != "")
            {
                if (this.checkFind(this.textDO.Text))
                {
                    str = " like ";
                    text = this.replaceFind(this.textDO.Text);
                }
                else
                {
                    str = " = ";
                    text = this.textDO.Text;
                }
                string[] textArray2 = new string[] { " Do_No ", str, "'", text, "'" };
                this.pField[index] = string.Concat(textArray2);
                index++;
            }
            if (!((this.dateDoFrom.Text != "") & (this.dateDoTo.Text == "")))
            {
                if (!((this.dateDoFrom.Text != "") & (this.dateDoTo.Text != "")))
                {
                    if ((this.dateDoFrom.Text == "") & (this.dateDoTo.Text != ""))
                    {
                        time2 = Convert.ToDateTime(this.dateDoTo.Text);
                        string[] textArray5 = new string[] { " Day(Do_Date) <= '", time2.Day.ToString(), "' and Month(Do_Date) <= '", time2.Month.ToString(), "' and Year(Do_Date) <= '", time2.Year.ToString(), "'" };
                        this.pField[index] = string.Concat(textArray5);
                        index++;
                    }
                }
                else
                {
                    time = Convert.ToDateTime(this.dateDoFrom.Text);
                    time2 = Convert.ToDateTime(this.dateDoTo.Text);
                    if (time2 >= time)
                    {
                        string[] textArray4 = new string[13];
                        textArray4[0] = " ((Day(Do_Date) >= '";
                        textArray4[1] = time.Day.ToString();
                        textArray4[2] = "' and Month(Do_Date) >= '";
                        textArray4[3] = time.Month.ToString();
                        textArray4[4] = "' and Year(Do_Date) >= '";
                        textArray4[5] = time.Year.ToString();
                        textArray4[6] = "')  and (Day(Do_Date) <= '";
                        textArray4[7] = time2.Day.ToString();
                        textArray4[8] = "' and Month(Do_Date) <= '";
                        textArray4[9] = time2.Month.ToString();
                        textArray4[10] = "' and Year(Do_Date) <= '";
                        textArray4[11] = time2.Year.ToString();
                        textArray4[12] = "')) ";
                        this.pField[index] = string.Concat(textArray4);
                        index++;
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_114, Resource.Title_003);
                        this.dateDoFrom.Focus();
                        return;
                    }
                }
            }
            else
            {
                time = Convert.ToDateTime(this.dateDoFrom.Text);
                string[] textArray3 = new string[] { " Day(Do_Date) = '", time.Day.ToString(), "' and Month(Do_Date) = '", time.Month.ToString(), "' and Year(Do_Date) = '", time.Year.ToString(), "'" };
                this.pField[index] = string.Concat(textArray3);
                index++;
            }
            if (!((this.DateEntryFrom.Text != "") & (this.DateEntryTo.Text == "")))
            {
                if (!((this.DateEntryFrom.Text != "") & (this.DateEntryTo.Text != "")))
                {
                    if ((this.DateEntryFrom.Text == "") & (this.DateEntryTo.Text != ""))
                    {
                        time2 = Convert.ToDateTime(this.DateEntryTo.Text);
                        string[] textArray8 = new string[] { " Day(Create_Date) <= '", time2.Day.ToString(), "' and Month(Create_Date) <= '", time2.Month.ToString(), "' and Year(Create_Date) <= '", time2.Year.ToString(), "'" };
                        this.pField[index] = string.Concat(textArray8);
                        index++;
                    }
                }
                else
                {
                    time = Convert.ToDateTime(this.DateEntryFrom.Text);
                    time2 = Convert.ToDateTime(this.DateEntryTo.Text);
                    if (time2 >= time)
                    {
                        string[] textArray7 = new string[13];
                        textArray7[0] = " ((Day(Create_Date) >= '";
                        textArray7[1] = time.Day.ToString();
                        textArray7[2] = "' and Month(Create_Date) >= '";
                        textArray7[3] = time.Month.ToString();
                        textArray7[4] = "' and Year(Create_Date) >= '";
                        textArray7[5] = time.Year.ToString();
                        textArray7[6] = "')  and (Day(Create_Date) <= '";
                        textArray7[7] = time2.Day.ToString();
                        textArray7[8] = "' and Month(Create_Date) <= '";
                        textArray7[9] = time2.Month.ToString();
                        textArray7[10] = "' and Year(Create_Date) <= '";
                        textArray7[11] = time2.Year.ToString();
                        textArray7[12] = "')) ";
                        this.pField[index] = string.Concat(textArray7);
                        index++;
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_114, Resource.Title_003);
                        this.DateEntryFrom.Focus();
                        return;
                    }
                }
            }
            else
            {
                time = Convert.ToDateTime(this.DateEntryFrom.Text);
                string[] textArray6 = new string[] { " Day(Create_Date) = '", time.Day.ToString(), "' and Month(Create_Date) = '", time.Month.ToString(), "' and Year(Create_Date) = '", time.Year.ToString(), "'" };
                this.pField[index] = string.Concat(textArray6);
                index++;
            }
            if (this.textContract.Text != "")
            {
                if (this.checkFind(this.textContract.Text))
                {
                    str = " like ";
                    text = this.replaceFind(this.textContract.Text);
                }
                else
                {
                    str = " = ";
                    text = this.textContract.Text;
                }
                string[] textArray9 = new string[] { " Contract ", str, "'", text, "'" };
                this.pField[index] = string.Concat(textArray9);
                index++;
            }
            if (this.textConf.Text != "")
            {
                if (this.checkFind(this.textConf.Text))
                {
                    str = " like ";
                    text = this.replaceFind(this.textConf.Text);
                }
                else
                {
                    str = " = ";
                    text = this.textConf.Text;
                }
                string[] textArray10 = new string[] { " Confirmation ", str, "'", text, "'" };
                this.pField[index] = string.Concat(textArray10);
                index++;
            }
            if (this.textCommodity.Text != "")
            {
                if (this.checkFind(this.textCommodity.Text))
                {
                    str = " like ";
                    text = this.replaceFind(this.textCommodity.Text);
                }
                else
                {
                    str = " = ";
                    text = this.textCommodity.Text;
                }
                string[] textArray11 = new string[] { " Comm_code ", str, "'", text, "'" };
                this.pField[index] = string.Concat(textArray11);
                index++;
            }
            if (this.textVend.Text != "")
            {
                if (this.checkFind(this.textVend.Text))
                {
                    str = " like ";
                    text = this.replaceFind(this.textVend.Text);
                }
                else
                {
                    str = " = ";
                    text = this.textVend.Text;
                }
                string[] textArray12 = new string[] { " Relation_code ", str, "'", text, "'" };
                this.pField[index] = string.Concat(textArray12);
                index++;
            }
            if (this.textTransporter.Text != "")
            {
                if (this.checkFind(this.textTransporter.Text))
                {
                    str = " like ";
                    text = this.replaceFind(this.textTransporter.Text);
                }
                else
                {
                    str = " = ";
                    text = this.textTransporter.Text;
                }
                string[] textArray13 = new string[] { " Transporter_code ", str, "'", text, "'" };
                this.pField[index] = string.Concat(textArray13);
                index++;
            }
            if (this.textEstate.Text != "")
            {
                if (this.checkFind(this.textEstate.Text))
                {
                    str = " like ";
                    text = this.replaceFind(this.textEstate.Text);
                }
                else
                {
                    str = " = ";
                    text = this.textEstate.Text;
                }
                string[] textArray14 = new string[] { " Estate_ADM ", str, "'", text, "'" };
                this.pField[index] = string.Concat(textArray14);
                index++;
            }
            if (this.textPO.Text != "")
            {
                if (this.checkFind(this.textPO.Text))
                {
                    str = " like ";
                    text = this.replaceFind(this.textPO.Text);
                }
                else
                {
                    str = " = ";
                    text = this.textPO.Text;
                }
                string[] textArray15 = new string[] { " PO ", str, "'", text, "'" };
                this.pField[index] = string.Concat(textArray15);
                index++;
            }
            if (this.textGRPO.Text != "")
            {
                if (this.checkFind(this.textGRPO.Text))
                {
                    str = " like ";
                    text = this.replaceFind(this.textGRPO.Text);
                }
                else
                {
                    str = " = ";
                    text = this.textGRPO.Text;
                }
                string[] textArray16 = new string[] { " GR ", str, "'", text, "'" };
                this.pField[index] = string.Concat(textArray16);
                index++;
            }
            if (this.textSTO.Text != "")
            {
                if (this.checkFind(this.textSTO.Text))
                {
                    str = " like ";
                    text = this.replaceFind(this.textSTO.Text);
                }
                else
                {
                    str = " = ";
                    text = this.textSTO.Text;
                }
                string[] textArray17 = new string[] { " STO ", str, "'", text, "'" };
                this.pField[index] = string.Concat(textArray17);
                index++;
            }
            if (this.textSO.Text != "")
            {
                if (this.checkFind(this.textSO.Text))
                {
                    str = " like ";
                    text = this.replaceFind(this.textSO.Text);
                }
                else
                {
                    str = " = ";
                    text = this.textSO.Text;
                }
                string[] textArray18 = new string[] { " SO ", str, "'", text, "'" };
                this.pField[index] = string.Concat(textArray18);
                index++;
            }
            if (this.textNEGO.Text != "")
            {
                if (this.checkFind(this.textNEGO.Text))
                {
                    str = " like ";
                    text = this.replaceFind(this.textNEGO.Text);
                }
                else
                {
                    str = " = ";
                    text = this.textNEGO.Text;
                }
                string[] textArray19 = new string[] { " Nego ", str, "'", text, "'" };
                this.pField[index] = string.Concat(textArray19);
                index++;
            }
            this.pFilter = this.mergeFilter(this.pField, index);
            this.saved = true;
            base.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.saved = false;
            base.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textVend.Text = vendor.ReturnRow["relation_code"].ToString();
            }
            vendor.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransporter.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.textTransporter.Focus();
            }
            transporter.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
            }
            commodity.Dispose();
        }

        private void buttonType_Click(object sender, EventArgs e)
        {
            FormTransType type = new FormTransType {
                pMode = "CHOOSE"
            };
            type.ShowDialog();
            if (type.ReturnRow != null)
            {
                this.textType.Text = type.ReturnRow["Transaction_Code"].ToString();
            }
            type.Dispose();
        }

        private bool checkFind(string pFind)
        {
            int num = 0;
            while (true)
            {
                bool flag2;
                if (num >= pFind.Length)
                {
                    flag2 = false;
                }
                else
                {
                    if (pFind[num] != '*')
                    {
                        num++;
                        continue;
                    }
                    flag2 = true;
                }
                return flag2;
            }
        }

        private void dateDoFrom_Leave(object sender, EventArgs e)
        {
            if (this.dateDoFrom.Text != "")
            {
                try
                {
                    DateTime time = Convert.ToDateTime(this.dateDoFrom.Text);
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_110, Resource.Title_003);
                    this.dateDoFrom.Focus();
                }
            }
        }

        private void dateDoTo_Layout(object sender, LayoutEventArgs e)
        {
        }

        private void dateDoTo_Leave(object sender, EventArgs e)
        {
            if (this.dateDoTo.Text != "")
            {
                try
                {
                    DateTime time = Convert.ToDateTime(this.dateDoTo.Text);
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_110, Resource.Title_003);
                    this.dateDoTo.Focus();
                }
            }
        }

        private void DateEntryFrom_Leave(object sender, EventArgs e)
        {
            if (this.DateEntryFrom.Text != "")
            {
                try
                {
                    DateTime time = Convert.ToDateTime(this.DateEntryFrom.Text);
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_110, Resource.Title_003);
                    this.DateEntryFrom.Focus();
                }
            }
        }

        private void DateEntryTo_Leave(object sender, EventArgs e)
        {
            if (this.DateEntryTo.Text != "")
            {
                try
                {
                    DateTime time = Convert.ToDateTime(this.DateEntryTo.Text);
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_110, Resource.Title_003);
                    this.DateEntryTo.Focus();
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormContractFilter_Load(object sender, EventArgs e)
        {
            bool flag1;
            if (WBSetting.Field("KB").ToString() == "Y")
            {
                flag1 = true;
            }
            else
            {
                flag1 = this.rdoNKB.Checked = true;
            }
            this.rdoKB.Checked = flag1;
        }

        private void InitializeComponent()
        {
            this.textVend = new TextBox();
            this.textCommodity = new TextBox();
            this.textType = new TextBox();
            this.textTransporter = new TextBox();
            this.label1 = new Label();
            this.label46 = new Label();
            this.label9 = new Label();
            this.textConf = new TextBox();
            this.textContract = new TextBox();
            this.label4 = new Label();
            this.label8 = new Label();
            this.label6 = new Label();
            this.label7 = new Label();
            this.textDO = new TextBox();
            this.label12 = new Label();
            this.textEstate = new TextBox();
            this.groupBox7 = new GroupBox();
            this.label11 = new Label();
            this.textPO = new TextBox();
            this.label23 = new Label();
            this.textNEGO = new TextBox();
            this.label22 = new Label();
            this.textSO = new TextBox();
            this.label21 = new Label();
            this.textGRPO = new TextBox();
            this.label20 = new Label();
            this.textSTO = new TextBox();
            this.label2 = new Label();
            this.btnFilter = new Button();
            this.button3 = new Button();
            this.button2 = new Button();
            this.button4 = new Button();
            this.btnEstate = new Button();
            this.buttonType = new Button();
            this.label3 = new Label();
            this.button1 = new Button();
            this.rdoKB = new RadioButton();
            this.rdoNKB = new RadioButton();
            this.dateDoTo = new TextBox();
            this.dateDoFrom = new TextBox();
            this.DateEntryTo = new TextBox();
            this.DateEntryFrom = new TextBox();
            this.label5 = new Label();
            this.label10 = new Label();
            this.label13 = new Label();
            this.groupBox7.SuspendLayout();
            base.SuspendLayout();
            this.textVend.Location = new Point(0x7d, 0x10d);
            this.textVend.MaxLength = 20;
            this.textVend.Name = "textVend";
            this.textVend.Size = new Size(0x63, 20);
            this.textVend.TabIndex = 9;
            this.textVend.KeyPress += new KeyPressEventHandler(this.textVend_KeyPress);
            this.textCommodity.Location = new Point(0x7d, 240);
            this.textCommodity.MaxLength = 50;
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0x63, 20);
            this.textCommodity.TabIndex = 8;
            this.textCommodity.KeyPress += new KeyPressEventHandler(this.textCommodity_KeyPress);
            this.textType.CharacterCasing = CharacterCasing.Upper;
            this.textType.Location = new Point(0x7d, 0x36);
            this.textType.MaxLength = 20;
            this.textType.Name = "textType";
            this.textType.Size = new Size(0x41, 20);
            this.textType.TabIndex = 2;
            this.textType.KeyPress += new KeyPressEventHandler(this.textType_KeyPress);
            this.textTransporter.Location = new Point(0x7d, 0x127);
            this.textTransporter.MaxLength = 20;
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.Size = new Size(0x63, 20);
            this.textTransporter.TabIndex = 10;
            this.textTransporter.KeyPress += new KeyPressEventHandler(this.textTransporter_KeyPress);
            this.label1.Location = new Point(0x13, 0x59);
            this.label1.Name = "label1";
            this.label1.Size = new Size(100, 13);
            this.label1.TabIndex = 70;
            this.label1.Text = "Delivery Order No.";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.label46.Location = new Point(0x13, 0x12b);
            this.label46.Name = "label46";
            this.label46.Size = new Size(100, 13);
            this.label46.TabIndex = 0x4f;
            this.label46.Text = "Transporter";
            this.label46.TextAlign = ContentAlignment.MiddleRight;
            this.label9.Location = new Point(0x13, 0x39);
            this.label9.Name = "label9";
            this.label9.Size = new Size(100, 13);
            this.label9.TabIndex = 0x4e;
            this.label9.Text = "Transaction Type";
            this.label9.TextAlign = ContentAlignment.MiddleRight;
            this.textConf.Location = new Point(0x7d, 0xd6);
            this.textConf.MaxLength = 30;
            this.textConf.Name = "textConf";
            this.textConf.Size = new Size(0x84, 20);
            this.textConf.TabIndex = 7;
            this.textConf.KeyPress += new KeyPressEventHandler(this.textConf_KeyPress);
            this.textContract.Location = new Point(0x7d, 0xbf);
            this.textContract.MaxLength = 30;
            this.textContract.Name = "textContract";
            this.textContract.Size = new Size(0x84, 20);
            this.textContract.TabIndex = 6;
            this.textContract.KeyPress += new KeyPressEventHandler(this.textContract_KeyPress);
            this.label4.Location = new Point(0x13, 0xc3);
            this.label4.Name = "label4";
            this.label4.Size = new Size(100, 13);
            this.label4.TabIndex = 0x48;
            this.label4.Text = "Contract No.";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            this.label8.Location = new Point(0x13, 0x111);
            this.label8.Name = "label8";
            this.label8.Size = new Size(100, 13);
            this.label8.TabIndex = 0x4d;
            this.label8.Text = "Vendor / Customer";
            this.label8.TextAlign = ContentAlignment.MiddleRight;
            this.label6.Location = new Point(0x13, 0xda);
            this.label6.Name = "label6";
            this.label6.Size = new Size(100, 13);
            this.label6.TabIndex = 0x4b;
            this.label6.Text = "Confirmation No.";
            this.label6.TextAlign = ContentAlignment.MiddleRight;
            this.label7.Location = new Point(0x13, 0xf4);
            this.label7.Name = "label7";
            this.label7.Size = new Size(100, 13);
            this.label7.TabIndex = 0x4c;
            this.label7.Text = "Commodity";
            this.label7.TextAlign = ContentAlignment.MiddleRight;
            this.textDO.Location = new Point(0x7d, 0x56);
            this.textDO.MaxLength = 30;
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0x84, 20);
            this.textDO.TabIndex = 3;
            this.textDO.KeyPress += new KeyPressEventHandler(this.textDO_KeyPress);
            this.label12.Location = new Point(0x13, 0x148);
            this.label12.Name = "label12";
            this.label12.Size = new Size(100, 13);
            this.label12.TabIndex = 0x54;
            this.label12.Text = "Estate ADM";
            this.label12.TextAlign = ContentAlignment.MiddleRight;
            this.textEstate.Location = new Point(0x7d, 0x144);
            this.textEstate.MaxLength = 20;
            this.textEstate.Name = "textEstate";
            this.textEstate.Size = new Size(0x63, 20);
            this.textEstate.TabIndex = 11;
            this.textEstate.KeyPress += new KeyPressEventHandler(this.textEstate_KeyPress);
            this.groupBox7.Controls.Add(this.label11);
            this.groupBox7.Controls.Add(this.textPO);
            this.groupBox7.Controls.Add(this.label23);
            this.groupBox7.Controls.Add(this.textNEGO);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Controls.Add(this.textSO);
            this.groupBox7.Controls.Add(this.label21);
            this.groupBox7.Controls.Add(this.textGRPO);
            this.groupBox7.Controls.Add(this.label20);
            this.groupBox7.Controls.Add(this.textSTO);
            this.groupBox7.Location = new Point(0x133, 0xbf);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new Size(0xd5, 0x97);
            this.groupBox7.TabIndex = 0x56;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "[ SAP Reference ]";
            this.label11.Location = new Point(6, 0x4a);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x2a, 13);
            this.label11.TabIndex = 0x40;
            this.label11.Text = "PO";
            this.label11.TextAlign = ContentAlignment.MiddleRight;
            this.textPO.Location = new Point(0x36, 0x47);
            this.textPO.MaxLength = 30;
            this.textPO.Name = "textPO";
            this.textPO.Size = new Size(0x90, 20);
            this.textPO.TabIndex = 2;
            this.label23.Location = new Point(7, 0x7e);
            this.label23.Name = "label23";
            this.label23.Size = new Size(0x2a, 13);
            this.label23.TabIndex = 0x2a;
            this.label23.Text = "NEGO";
            this.label23.TextAlign = ContentAlignment.MiddleRight;
            this.textNEGO.Location = new Point(0x37, 0x7b);
            this.textNEGO.MaxLength = 30;
            this.textNEGO.Name = "textNEGO";
            this.textNEGO.Size = new Size(0x8f, 20);
            this.textNEGO.TabIndex = 4;
            this.label22.Location = new Point(6, 100);
            this.label22.Name = "label22";
            this.label22.Size = new Size(0x2a, 13);
            this.label22.TabIndex = 40;
            this.label22.Text = "SO";
            this.label22.TextAlign = ContentAlignment.MiddleRight;
            this.textSO.Location = new Point(0x36, 0x61);
            this.textSO.MaxLength = 30;
            this.textSO.Name = "textSO";
            this.textSO.Size = new Size(0x90, 20);
            this.textSO.TabIndex = 3;
            this.label21.Location = new Point(6, 50);
            this.label21.Name = "label21";
            this.label21.Size = new Size(0x2a, 13);
            this.label21.TabIndex = 0x26;
            this.label21.Text = "GR PO";
            this.label21.TextAlign = ContentAlignment.MiddleRight;
            this.textGRPO.Location = new Point(0x36, 0x2f);
            this.textGRPO.MaxLength = 30;
            this.textGRPO.Name = "textGRPO";
            this.textGRPO.Size = new Size(0x90, 20);
            this.textGRPO.TabIndex = 1;
            this.label20.Location = new Point(6, 0x1a);
            this.label20.Name = "label20";
            this.label20.Size = new Size(0x2a, 13);
            this.label20.TabIndex = 0x24;
            this.label20.Text = "STO";
            this.label20.TextAlign = ContentAlignment.MiddleRight;
            this.textSTO.Location = new Point(0x36, 0x17);
            this.textSTO.MaxLength = 30;
            this.textSTO.Name = "textSTO";
            this.textSTO.Size = new Size(0x90, 20);
            this.textSTO.TabIndex = 0;
            this.label2.Location = new Point(0x13, 0x75);
            this.label2.Name = "label2";
            this.label2.Size = new Size(100, 13);
            this.label2.TabIndex = 0x57;
            this.label2.Text = "Date of DO";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.btnFilter.Location = new Point(0x13b, 0x166);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new Size(0x57, 0x1d);
            this.btnFilter.TabIndex = 12;
            this.btnFilter.Text = "Filter";
            this.btnFilter.UseVisualStyleBackColor = true;
            this.btnFilter.Click += new EventHandler(this.btnFilter_Click);
            this.button3.Location = new Point(0xea, 0x127);
            this.button3.Margin = new Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x17, 0x17);
            this.button3.TabIndex = 0x5e;
            this.button3.Text = "...";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.button2.Location = new Point(0xea, 0x10d);
            this.button2.Margin = new Padding(0);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x17, 0x17);
            this.button2.TabIndex = 0x5d;
            this.button2.Text = "...";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button4.Location = new Point(0xea, 240);
            this.button4.Margin = new Padding(0);
            this.button4.Name = "button4";
            this.button4.Size = new Size(0x17, 0x17);
            this.button4.TabIndex = 0x5c;
            this.button4.Text = "...";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new EventHandler(this.button4_Click);
            this.btnEstate.Location = new Point(0xea, 0x144);
            this.btnEstate.Margin = new Padding(0);
            this.btnEstate.Name = "btnEstate";
            this.btnEstate.Size = new Size(0x17, 0x17);
            this.btnEstate.TabIndex = 0x5b;
            this.btnEstate.Text = "...";
            this.btnEstate.UseVisualStyleBackColor = true;
            this.btnEstate.Click += new EventHandler(this.btnEstate_Click);
            this.buttonType.Location = new Point(0xc9, 0x33);
            this.buttonType.Margin = new Padding(0);
            this.buttonType.Name = "buttonType";
            this.buttonType.Size = new Size(0x17, 0x17);
            this.buttonType.TabIndex = 90;
            this.buttonType.Text = "...";
            this.buttonType.UseVisualStyleBackColor = true;
            this.buttonType.Click += new EventHandler(this.buttonType_Click);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0xe7, 0x73);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x10, 13);
            this.label3.TabIndex = 0x60;
            this.label3.Text = "to";
            this.button1.Location = new Point(410, 0x166);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x57, 0x1d);
            this.button1.TabIndex = 13;
            this.button1.Text = "Cancel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.rdoKB.AutoSize = true;
            this.rdoKB.Location = new Point(0x7d, 0x10);
            this.rdoKB.Name = "rdoKB";
            this.rdoKB.Size = new Size(0x27, 0x11);
            this.rdoKB.TabIndex = 0;
            this.rdoKB.TabStop = true;
            this.rdoKB.Text = "KB";
            this.rdoKB.UseVisualStyleBackColor = true;
            this.rdoNKB.AutoSize = true;
            this.rdoNKB.Location = new Point(0xc9, 0x10);
            this.rdoNKB.Name = "rdoNKB";
            this.rdoNKB.Size = new Size(0x2f, 0x11);
            this.rdoNKB.TabIndex = 1;
            this.rdoNKB.TabStop = true;
            this.rdoNKB.Text = "NKB";
            this.rdoNKB.UseVisualStyleBackColor = true;
            this.dateDoTo.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.dateDoTo.Location = new Point(0xfd, 0x70);
            this.dateDoTo.MaxLength = 10;
            this.dateDoTo.Name = "dateDoTo";
            this.dateDoTo.Size = new Size(100, 0x16);
            this.dateDoTo.TabIndex = 5;
            this.dateDoTo.Layout += new LayoutEventHandler(this.dateDoTo_Layout);
            this.dateDoTo.Leave += new EventHandler(this.dateDoTo_Leave);
            this.dateDoFrom.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.dateDoFrom.Location = new Point(0x7c, 0x70);
            this.dateDoFrom.MaxLength = 10;
            this.dateDoFrom.Name = "dateDoFrom";
            this.dateDoFrom.Size = new Size(100, 0x16);
            this.dateDoFrom.TabIndex = 4;
            this.dateDoFrom.Leave += new EventHandler(this.dateDoFrom_Leave);
            this.DateEntryTo.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.DateEntryTo.Location = new Point(0xfd, 0x8a);
            this.DateEntryTo.MaxLength = 10;
            this.DateEntryTo.Name = "DateEntryTo";
            this.DateEntryTo.Size = new Size(100, 0x16);
            this.DateEntryTo.TabIndex = 0x62;
            this.DateEntryTo.Leave += new EventHandler(this.DateEntryTo_Leave);
            this.DateEntryFrom.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.DateEntryFrom.Location = new Point(0x7c, 0x8a);
            this.DateEntryFrom.MaxLength = 10;
            this.DateEntryFrom.Name = "DateEntryFrom";
            this.DateEntryFrom.Size = new Size(100, 0x16);
            this.DateEntryFrom.TabIndex = 0x61;
            this.DateEntryFrom.Leave += new EventHandler(this.DateEntryFrom_Leave);
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0xe7, 0x8d);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x10, 13);
            this.label5.TabIndex = 100;
            this.label5.Text = "to";
            this.label10.Location = new Point(0x13, 0x90);
            this.label10.Name = "label10";
            this.label10.Size = new Size(100, 13);
            this.label10.TabIndex = 0x63;
            this.label10.Text = "Entry Date";
            this.label10.TextAlign = ContentAlignment.MiddleRight;
            this.label13.AutoSize = true;
            this.label13.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label13.Location = new Point(0x5f, 0xa3);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x102, 13);
            this.label13.TabIndex = 0x65;
            this.label13.Text = "*Date Format = DD/MM/YYYY (01/01/2013)";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x203, 0x193);
            base.ControlBox = false;
            base.Controls.Add(this.label13);
            base.Controls.Add(this.DateEntryTo);
            base.Controls.Add(this.DateEntryFrom);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.rdoNKB);
            base.Controls.Add(this.rdoKB);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.dateDoTo);
            base.Controls.Add(this.dateDoFrom);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button4);
            base.Controls.Add(this.btnEstate);
            base.Controls.Add(this.buttonType);
            base.Controls.Add(this.btnFilter);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.groupBox7);
            base.Controls.Add(this.textEstate);
            base.Controls.Add(this.label12);
            base.Controls.Add(this.textVend);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.textType);
            base.Controls.Add(this.textTransporter);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.label46);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.textConf);
            base.Controls.Add(this.textContract);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.textDO);
            base.Name = "FormContractFilter";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Contract Filter";
            base.Load += new EventHandler(this.FormContractFilter_Load);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private string mergeFilter(string[] pField, int x)
        {
            string str = " AND ";
            if (x <= 1)
            {
                str = str + pField[0];
            }
            else
            {
                int index = 0;
                while (true)
                {
                    if (index >= x)
                    {
                        break;
                    }
                    bool flag2 = index < (x - 1);
                    str = !flag2 ? (str + pField[index]) : (str + pField[index] + " AND ");
                    index++;
                }
            }
            return str;
        }

        private void rdoKB_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void rdoNKB_CheckedChanged(object sender, EventArgs e)
        {
        }

        private string replaceFind(string pFind)
        {
            string str = "";
            for (int i = 0; i < pFind.Length; i++)
            {
                bool flag = pFind[i] == '*';
                str = !flag ? (str + pFind[i].ToString()) : (str + "%");
            }
            return str;
        }

        private void textCommodity_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textConf_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textContract_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDO_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textEstate_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransporter_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textType_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textVend_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.label1.Text = Resource.Lbl_DO_No;
            this.label46.Text = Resource.Menu_025;
            this.label9.Text = Resource.Menu_041;
            this.label4.Text = Resource.Contract_No;
            this.label8.Text = Resource.Lbl_Vendor_Customer;
            this.label6.Text = Resource.Contract_Confirmation_No;
            this.label7.Text = Resource.Contract_004;
            this.label12.Text = Resource.Contract_Estate_ADM;
            this.label11.Text = Resource.Contract_026;
            this.label23.Text = Resource.Lbl_NEGO;
            this.label22.Text = Resource.Contract_023;
            this.label21.Text = Resource.Lbl_GR_PO;
            this.label20.Text = Resource.Contract_019;
            this.label2.Text = Resource.Contract_003;
            this.label3.Text = Resource.Main_029;
            this.label5.Text = Resource.Main_029;
            this.label10.Text = Resource.Lbl_Entry_Date;
            this.label13.Text = "*" + Resource.Lbl_Date_Format + " = DD/MM/YYYY (01/01/2013)";
            this.groupBox7.Text = "[ " + this.sapIDSYS + Resource.Gbx_SAP_Reference + " ]";
            this.rdoKB.Text = Resource.Contract_001;
            this.rdoNKB.Text = Resource.Rdb_NKB;
            this.btnFilter.Text = Resource.Menu_Filter;
            this.button1.Text = Resource.Menu_Cancel;
            this.Text = Resource.Title_Contract_Filter;
        }
    }
}

