﻿namespace WindowsFormsApplication1
{
    using Encryption.Utility;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormRegistrationKey : Form
    {
        public bool valid = false;
        private string siteCode = "";
        private string dateToActivate = "";
        private string numberOfWB = "";
        private string dateToRenew = "";
        private string siteCodeDB = "";
        private string dateToActivateDB = "";
        private string numberOfWBDB = "";
        private string dateToRenewDB = "";
        private IContainer components = null;
        private Label label1;
        private TextBox textCompName;
        private TextBox textWBCode;
        private Label label2;
        private TextBox textKey;
        private Label label3;
        private Label label4;
        private Button buttonProcess;
        private Button buttonCancel;

        public FormRegistrationKey()
        {
            this.InitializeComponent();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.valid = this.checkRegKey();
            if (this.valid)
            {
                base.Close();
            }
        }

        private bool checkRegKey()
        {
            bool flag2;
            try
            {
                if (this.isKeyValid())
                {
                    char[] separator = new char[] { '|' };
                    string[] strArray = WBEncryption.Decrypt(this.textKey.Text.Trim(), "R3gK3y4wb").Split(separator);
                    this.siteCode = strArray[0];
                    this.dateToActivate = strArray[1];
                    this.numberOfWB = strArray[2];
                    this.dateToRenew = strArray[3];
                    WBTable sourceTable = new WBTable();
                    sourceTable.OpenTable("wb_act", "SELECT * FROM wb_act WHERE 1 = 1", WBData.conn);
                    if (sourceTable.DT.Rows.Count > 0)
                    {
                        DataTable table2 = WBUtility.WBTableToDataTable(sourceTable, null);
                        int num = 0;
                        while (true)
                        {
                            if (num < table2.Rows.Count)
                            {
                                int num2 = 0;
                                while (true)
                                {
                                    if (num2 >= table2.Columns.Count)
                                    {
                                        num++;
                                        break;
                                    }
                                    if (table2.Columns[num2].ColumnName.ToUpper() != "UNIQ")
                                    {
                                        table2.Rows[num][num2] = WBEncryption.Decrypt(table2.Rows[num][num2].ToString(), "encryptDATA");
                                    }
                                    num2++;
                                }
                                continue;
                            }
                            char[] chArray2 = new char[] { '|' };
                            string[] strArray2 = WBEncryption.Decrypt(table2.Select(" param = 'key' ")[0][1].ToString(), "R3gK3y4wb").Split(chArray2);
                            string str4 = strArray2[0];
                            string str5 = strArray2[1];
                            string str6 = strArray2[2];
                            string str7 = strArray2[3];
                            string[] textArray1 = new string[] { str5.Substring(0, 2), "-", str5.Substring(2, 2), "-", str5.Substring(4) };
                            if (DateTime.Now.Date > Convert.ToDateTime(string.Concat(textArray1)).Date)
                            {
                                Cursor.Current = Cursors.Default;
                                object[] objArray2 = new object[5];
                                objArray2[0] = "Activation date is expired. Key must be used before ";
                                string[] textArray3 = new string[] { str5.Substring(0, 2), "-", str5.Substring(2, 2), "-", str5.Substring(4) };
                                objArray2[1] = Convert.ToDateTime(string.Concat(textArray3)).Date;
                                objArray2[2] = ".";
                                objArray2[3] = Environment.NewLine;
                                objArray2[4] = "Please contact WCS if you need further support.";
                                MessageBox.Show(string.Concat(objArray2), "ACTIVATION DATE IS NOT VALID", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                return false;
                            }
                            else
                            {
                                DataRow[] rowArray = table2.Select(" param LIKE 'WB|%' ");
                                if (rowArray.Length >= Convert.ToInt32(str6.Substring(2)))
                                {
                                    string str9 = "";
                                    int index = 0;
                                    while (true)
                                    {
                                        if (index >= rowArray.Length)
                                        {
                                            Cursor.Current = Cursors.Default;
                                            string[] textArray2 = new string[13];
                                            textArray2[0] = "Activation key has been used for ";
                                            textArray2[1] = str6.Substring(2);
                                            textArray2[2] = " WB(s) as requested before.";
                                            textArray2[3] = Environment.NewLine;
                                            textArray2[4] = "Current usage: ";
                                            textArray2[5] = Environment.NewLine;
                                            textArray2[6] = str9;
                                            textArray2[7] = Environment.NewLine;
                                            textArray2[8] = Environment.NewLine;
                                            textArray2[9] = "If you use the activation key to wrong PC or you want to change existing WB PC to another PC, please delete one of the key usage from menu Configuration - Activation Key Usage.";
                                            textArray2[10] = Environment.NewLine;
                                            textArray2[11] = Environment.NewLine;
                                            textArray2[12] = "But if you want to register another WB, please contact WCS to renew you activation key.";
                                            MessageBox.Show(string.Concat(textArray2), "ACTIVATION KEY IS FULLY USED", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                            flag2 = false;
                                            break;
                                        }
                                        char[] chArray3 = new char[] { '|' };
                                        string[] strArray3 = rowArray[index][0].ToString().Split(chArray3);
                                        object[] objArray1 = new object[] { str9, index + 1, ". WB code: ", strArray3[1], " (Computer name: ", strArray3[2], ") " };
                                        str9 = string.Concat(objArray1);
                                        if (index < (rowArray.Length - 1))
                                        {
                                            str9 = str9 + Environment.NewLine;
                                        }
                                        index++;
                                    }
                                    return flag2;
                                }
                                else if (this.siteCode != str4)
                                {
                                    Cursor.Current = Cursors.Default;
                                    MessageBox.Show("Entered activation key is not valid for this site. " + Environment.NewLine + "Please contact WCS for further support.", "ACTIVATION KEY IS NOT VALID", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    return false;
                                }
                                else
                                {
                                    string strToEncrypt = "wb|" + this.textWBCode.Text.Trim() + "|" + this.textCompName.Text.Trim();
                                    sourceTable.DR = sourceTable.DT.NewRow();
                                    sourceTable.DR["param"] = WBEncryption.Encrypt(strToEncrypt, "encryptDATA");
                                    sourceTable.DR["val"] = WBEncryption.Encrypt(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), "encryptDATA");
                                    sourceTable.DT.Rows.Add(sourceTable.DR);
                                    sourceTable.Save();
                                    Cursor.Current = Cursors.Default;
                                    MessageBox.Show("Activation key is ACCEPTED. " + Environment.NewLine + "This PC can be used for weighing now.", "KEY IS ACCEPTED", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                }
                            }
                            break;
                        }
                    }
                    else
                    {
                        sourceTable.DR = sourceTable.DT.NewRow();
                        sourceTable.DR["param"] = WBEncryption.Encrypt("checksum", "encryptDATA");
                        sourceTable.DR["val"] = WBEncryption.Encrypt("test", "encryptDATA");
                        sourceTable.DT.Rows.Add(sourceTable.DR);
                        sourceTable.Save();
                        sourceTable.DR = sourceTable.DT.NewRow();
                        sourceTable.DR["param"] = WBEncryption.Encrypt("key", "encryptDATA");
                        sourceTable.DR["val"] = WBEncryption.Encrypt(this.textKey.Text.Trim(), "encryptDATA");
                        sourceTable.DT.Rows.Add(sourceTable.DR);
                        sourceTable.Save();
                        string strToEncrypt = "wb|" + this.textWBCode.Text.Trim() + "|" + this.textCompName.Text.Trim();
                        sourceTable.DR = sourceTable.DT.NewRow();
                        sourceTable.DR["param"] = WBEncryption.Encrypt(strToEncrypt, "encryptDATA");
                        sourceTable.DR["val"] = WBEncryption.Encrypt(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), "encryptDATA");
                        sourceTable.DT.Rows.Add(sourceTable.DR);
                        sourceTable.Save();
                        Cursor.Current = Cursors.Default;
                        MessageBox.Show("Activation key is accepted. This PC can be used for weighing now.", "KEY IS ACCEPTED", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    flag2 = true;
                }
                else
                {
                    Cursor.Current = Cursors.Default;
                    MessageBox.Show("Activation key is not valid. Please contact WCS to get a valid one.", "KEY IS NOT VALID", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    flag2 = false;
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Fail to process key: " + exception.Message + Environment.NewLine + "Please contact WCS for further support!", "FAIL TO PROCESS KEY", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                flag2 = false;
            }
            return flag2;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormRegistrationKey_Load(object sender, EventArgs e)
        {
            this.textCompName.Text = Environment.MachineName;
            this.textWBCode.Text = WBSetting.WBCode;
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.textCompName = new TextBox();
            this.textWBCode = new TextBox();
            this.label2 = new Label();
            this.textKey = new TextBox();
            this.label3 = new Label();
            this.label4 = new Label();
            this.buttonProcess = new Button();
            this.buttonCancel = new Button();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(0x1c, 80);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x7d, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Computer Name";
            this.textCompName.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textCompName.Location = new Point(0x20, 0x67);
            this.textCompName.Name = "textCompName";
            this.textCompName.ReadOnly = true;
            this.textCompName.Size = new Size(0x12b, 0x1a);
            this.textCompName.TabIndex = 1;
            this.textWBCode.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textWBCode.Location = new Point(0x164, 0x67);
            this.textWBCode.Name = "textWBCode";
            this.textWBCode.ReadOnly = true;
            this.textWBCode.Size = new Size(0xcd, 0x1a);
            this.textWBCode.TabIndex = 3;
            this.label2.AutoSize = true;
            this.label2.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label2.Location = new Point(0x160, 80);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x4d, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "WB Code";
            this.textKey.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textKey.Location = new Point(0x20, 0xb3);
            this.textKey.Name = "textKey";
            this.textKey.Size = new Size(0x211, 0x1a);
            this.textKey.TabIndex = 5;
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(0x1c, 0x9c);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x23, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Key";
            this.label4.AutoSize = true;
            this.label4.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label4.Location = new Point(0x1d, 0x22);
            this.label4.Name = "label4";
            this.label4.Size = new Size(380, 0x11);
            this.label4.TabIndex = 6;
            this.label4.Text = "Enter activation key to enable weighing feature for:";
            this.buttonProcess.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonProcess.Location = new Point(0x147, 0xea);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(0x66, 0x2c);
            this.buttonProcess.TabIndex = 7;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.buttonCancel.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonCancel.Location = new Point(0x1cb, 0xea);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x66, 0x2c);
            this.buttonCancel.TabIndex = 8;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x24c, 0x135);
            base.ControlBox = false;
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonProcess);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textKey);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textWBCode);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textCompName);
            base.Controls.Add(this.label1);
            base.Name = "FormRegistrationKey";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterParent;
            base.Load += new EventHandler(this.FormRegistrationKey_Load);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private bool isKeyValid()
        {
            bool flag2;
            string str = WBEncryption.Decrypt(this.textKey.Text.Trim(), "R3gK3y4wb");
            if (!str.ToLower().Contains("wrong input"))
            {
                try
                {
                    char[] separator = new char[] { '|' };
                    string[] strArray = str.Split(separator);
                    if (strArray.Length == 4)
                    {
                        if (strArray[0].Length != 3)
                        {
                            flag2 = false;
                        }
                        else
                        {
                            try
                            {
                                int num = Convert.ToInt32(strArray[0]);
                            }
                            catch
                            {
                                return false;
                            }
                            if (strArray[1].Length != 8)
                            {
                                flag2 = false;
                            }
                            else
                            {
                                try
                                {
                                    string[] textArray1 = new string[] { strArray[1].Substring(0, 2), "-", strArray[1].Substring(2, 2), "-", strArray[1].Substring(4) };
                                    DateTime time = Convert.ToDateTime(string.Concat(textArray1));
                                }
                                catch
                                {
                                    return false;
                                }
                                if (strArray[2].Length < 3)
                                {
                                    flag2 = false;
                                }
                                else if (!strArray[2].Contains("WB"))
                                {
                                    flag2 = false;
                                }
                                else
                                {
                                    try
                                    {
                                        int num2 = Convert.ToInt32(strArray[2].Substring(2));
                                    }
                                    catch
                                    {
                                        return false;
                                    }
                                    if (strArray[3].Length != 8)
                                    {
                                        flag2 = false;
                                    }
                                    else
                                    {
                                        try
                                        {
                                            string[] textArray2 = new string[] { strArray[3].Substring(0, 2), "-", strArray[3].Substring(2, 2), "-", strArray[3].Substring(4) };
                                            DateTime time2 = Convert.ToDateTime(string.Concat(textArray2));
                                        }
                                        catch
                                        {
                                            return false;
                                        }
                                        flag2 = true;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        flag2 = false;
                    }
                }
                catch
                {
                    flag2 = false;
                }
            }
            else
            {
                flag2 = false;
            }
            return flag2;
        }
    }
}

