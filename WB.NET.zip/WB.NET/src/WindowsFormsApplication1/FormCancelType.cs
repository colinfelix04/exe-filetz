﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic;
    using SAP.Middleware.Connector;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCancelType : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable zTable = new WBTable();
        public DataRow ReturnRow;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private string[] zwbResult = new string[3];
        private string[] zwbRow = new string[13];
        private IContainer components = null;
        private ToolStripMenuItem closeToolStripMenuItem;
        private DataGridView dataGridView1;
        private TextBox TextFind;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private Panel panel1;
        private Button buttonFind;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addCancelTypeItemToolStripMenuItem;
        private ToolStripMenuItem editCancelTypeToolStripMenuItem;
        private ToolStripMenuItem chooseToolStripMenuItem;
        private ProgressBar progressBar1;
        private ToolStripMenuItem viewReordToolStripMenuItem;
        private ToolStripMenuItem zWBToolStripMenuItem;
        private ToolStripMenuItem getCancelTypeFromZWBToolStripMenuItem;
        private ToolStripMenuItem getAllCancelTypeFromZWBToolStripMenuItem;

        public FormCancelType()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
        }

        private void addCancelTypeItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.entry("ADD", "Add New Record of Cancel Type");
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.zTable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.zTable.GetRecNo(aField, aFind);
            this.ReturnRow = this.zTable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        public void CompareAll(string CancelType)
        {
            int num2 = 0;
            int num3 = 0;
            int count = this.dataGridView1.Rows.Count;
            this.progressBar1.Visible = true;
            this.progressBar1.Maximum = count;
            if (this.zTable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                try
                {
                    WBSetting.OpenSetting();
                    if (WBSAP.connect())
                    {
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_CANCEL_TYPE");
                        if (CancelType != "")
                        {
                            WBSAP.rfcFunction.SetValue("CANCELTYPE", CancelType);
                        }
                        WBSAP.sendZWB();
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("IT_ZWB_CANCEL_TYPE");
                        if (WBSAP.rfcTable.RowCount < 1)
                        {
                            MessageBox.Show("No Data Found", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        else
                        {
                            int num4 = 0;
                            while (true)
                            {
                                if (num4 >= WBSAP.rfcTable.RowCount)
                                {
                                    object[] objArray1 = new object[11];
                                    objArray1[0] = Resource.Mes_Inserted;
                                    objArray1[1] = " : ";
                                    objArray1[2] = num3;
                                    objArray1[3] = " ";
                                    objArray1[4] = Resource.Mes_Rows;
                                    objArray1[5] = Environment.NewLine;
                                    objArray1[6] = Resource.Mes_Updated;
                                    objArray1[7] = " : ";
                                    objArray1[8] = num2;
                                    objArray1[9] = " ";
                                    objArray1[10] = Resource.Mes_Rows;
                                    MessageBox.Show(string.Concat(objArray1));
                                    this.zTable.ReOpen();
                                    this.dataGridView1 = this.zTable.AfterEdit("ADD");
                                    break;
                                }
                                try
                                {
                                    string[] aField = new string[] { "cancel_type" };
                                    string[] aFind = new string[] { WBSAP.rfcTable[num4].GetString("CANCELTYPE").ToString() };
                                    DataRow data = this.zTable.GetData(aField, aFind);
                                    if (data == null)
                                    {
                                        num3++;
                                        this.zTable.DR = this.zTable.DT.NewRow();
                                    }
                                    else
                                    {
                                        string[] textArray3 = new string[] { "cancel_type" };
                                        string[] textArray4 = new string[] { WBSAP.rfcTable[num4].GetString("CANCELTYPE").ToString() };
                                        this.nCurrRow = this.zTable.GetRecNo(textArray3, textArray4);
                                        num2++;
                                        this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                                        this.logKey = this.zTable.DR["uniq"].ToString();
                                        this.zTable.DR.BeginEdit();
                                    }
                                    this.zTable.DR["cancel_Type"] = WBSAP.rfcTable[num4].GetString("CANCELTYPE").ToString();
                                    this.zTable.DR["description"] = WBSAP.rfcTable[num4].GetString("DESCRIPTION").ToString();
                                    this.zTable.DR["require_token"] = (WBSAP.rfcTable[num4].GetString("TOKEN").ToString().Trim() == "X") ? "Y" : "N";
                                    if (data != null)
                                    {
                                        this.zTable.DR["Edit_By"] = "ZWB";
                                        this.zTable.DR["Edit_Date"] = Program.DTOCSAP(DateTime.Now);
                                        this.zTable.DR.EndEdit();
                                    }
                                    else
                                    {
                                        this.zTable.DR["Create_By"] = "ZWB";
                                        this.zTable.DR["Create_Date"] = Program.DTOCSAP(DateTime.Now);
                                        this.zTable.DT.Rows.Add(this.zTable.DR);
                                    }
                                    this.zTable.Save();
                                    if (data == null)
                                    {
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Get Cancel Type from ZWB" };
                                        Program.updateLogHeader("wb_cancel_type", this.logKey, logField, logValue);
                                    }
                                    else
                                    {
                                        WBTable table = new WBTable();
                                        table.OpenTable("wb_cancel_type", "SELECT uniq FROM wb_cancel_type WHERE cancel_type = '" + WBSAP.rfcTable[num4].GetString("CANCELTYPE").ToString() + "'", WBData.conn);
                                        this.logKey = table.DT.Rows[0]["uniq"].ToString();
                                        table.Dispose();
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "ADD", WBUser.UserID, "Get Cancel Type from ZWB" };
                                        Program.updateLogHeader("wb_cancel_type", this.logKey, logField, logValue);
                                    }
                                }
                                catch (SyntaxErrorException)
                                {
                                }
                                num4++;
                            }
                        }
                    }
                }
                catch (RfcInvalidParameterException exception2)
                {
                    MessageBox.Show($"{exception2.GetType().Name} : {exception2.Message}", Resource.Mes_Error_With_Spaces + " <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (RfcCommunicationException exception3)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), Resource.Mes_Error_With_Spaces + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, Resource.Mes_Error_With_Spaces + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (RfcBaseException exception4)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception4.ToString(), Resource.Mes_Error_With_Spaces + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, Resource.Mes_Error_With_Spaces + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (Exception exception5)
                {
                    MessageBox.Show(Resource.Title_003 + "/n" + exception5.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseToolStripMenuItem.PerformClick();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.chooseToolStripMenuItem.PerformClick();
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.zTable.BeforeEdit(this.dataGridView1, "DELETE"))
            {
                this.nCurrRow = this.zTable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                WBTable table = new WBTable();
                table.OpenTable("wb_transaction", "Select uniq From wb_transaction where cancel_Type ='" + this.zTable.DT.Rows[this.nCurrRow]["Cancel_Type"].ToString() + "'", WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    string[] textArray2 = new string[] { this.zTable.DT.Rows[this.nCurrRow]["Cancel_Type"].ToString(), " - ", this.zTable.DT.Rows[this.nCurrRow]["Description"].ToString(), ".\n\n ", Resource.Mes_006 };
                    if (MessageBox.Show(string.Concat(textArray2), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = "Cancel Type" },
                            textRefNo = { Text = this.zTable.DT.Rows[this.nCurrRow]["Cancel_Type"].ToString() },
                            Text = Resource.Form_Delete_Reason,
                            label2 = { Text = Resource.Lbl_Delete_Reason }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                            this.zTable.ReOpen();
                            this.logKey = this.zTable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                            this.zTable.DT.Rows[this.nCurrRow].Delete();
                            this.zTable.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                            Program.updateLogHeader("wb_cancel_type", this.logKey, logField, logValue);
                            this.zTable.ReOpen();
                            this.zTable.AfterEdit("DELETE");
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                else
                {
                    string[] textArray1 = new string[] { Resource.Mes_047A, "\n ( ", table.DT.Rows.Count.ToString(), " ", Resource.Mes_047B, ")" };
                    MessageBox.Show(string.Concat(textArray1), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.zTable.UnLock();
                table.Dispose();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editCancelTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.entry("EDIT", "Edit Record of Cancel Type");
        }

        private void entry(string pMode, string formText)
        {
            if (this.zTable.BeforeEdit(this.dataGridView1, pMode))
            {
                FormCancelTypeEntry entry = new FormCancelTypeEntry {
                    pMode = pMode,
                    zTable = this.zTable,
                    Text = formText,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.zTable.ReOpen();
                    this.dataGridView1 = this.zTable.AfterEdit(entry.pMode);
                }
                this.zTable.UnLock();
                entry.Dispose();
            }
        }

        private void FormTransType_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTransType_Load(object sender, EventArgs e)
        {
            this.zTable.OpenTable("wb_cancel_type", "Select * From wb_cancel_type where 1=1", WBData.conn);
            this.dataGridView1.DataSource = this.zTable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Cancel_Type"], ListSortDirection.Ascending);
            this.dataGridView1.Focus();
            this.dataGridView1.Columns["Create_By"].Visible = false;
            this.dataGridView1.Columns["Create_Date"].Visible = false;
            this.dataGridView1.Columns["Edit_By"].Visible = false;
            this.dataGridView1.Columns["Edit_Date"].Visible = false;
            this.dataGridView1.Columns["Uniq"].Visible = false;
            this.dataGridView1.Columns["Cancel_Type"].HeaderText = "Cancel Type";
            this.dataGridView1.Columns["Description"].HeaderText = "Description";
            this.dataGridView1.Columns["Require_Token"].HeaderText = "Need Token";
            base.KeyPreview = true;
            this.addCancelTypeItemToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_CANCEL_TYPE", "A");
            if (WBSetting.Field("GM") == "Y")
            {
                this.editCancelTypeToolStripMenuItem.Enabled = true;
                this.deleteToolStripMenuItem.Enabled = true;
            }
            else
            {
                this.editCancelTypeToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_CANCEL_TYPE", "E");
                this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_CANCEL_TYPE", "D");
            }
            this.zWBToolStripMenuItem.Enabled = WBUser.UserLevel == "1";
            this.getAllCancelTypeFromZWBToolStripMenuItem.Text = this.getAllCancelTypeFromZWBToolStripMenuItem.Text + this.sapIDSYS;
            this.zWBToolStripMenuItem.Text = WBSetting.integrationIDSYS ? "IDSYS" : "ZWB";
            this.zWBToolStripMenuItem.Enabled = !WBSetting.integrationIDSYS;
        }

        private void getAllCancelTypeFromZWBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_028_IDSYS : Resource.Mes_028, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.CompareAll("");
            }
        }

        private void getCancelTypeFromZWBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("Entry Cancel Type", Resource.Mes_Get_Data_ZWB + this.sapIDSYS, "", 300, 300);
            if (str != "")
            {
                this.CompareAll(str.ToUpper());
            }
        }

        private void InitializeComponent()
        {
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.TextFind = new TextBox();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.buttonFind = new Button();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addCancelTypeItemToolStripMenuItem = new ToolStripMenuItem();
            this.viewReordToolStripMenuItem = new ToolStripMenuItem();
            this.editCancelTypeToolStripMenuItem = new ToolStripMenuItem();
            this.chooseToolStripMenuItem = new ToolStripMenuItem();
            this.zWBToolStripMenuItem = new ToolStripMenuItem();
            this.getCancelTypeFromZWBToolStripMenuItem = new ToolStripMenuItem();
            this.getAllCancelTypeFromZWBToolStripMenuItem = new ToolStripMenuItem();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(420, 0x15f);
            this.dataGridView1.TabIndex = 6;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.TextFind.Location = new Point(5, 3);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 0;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x177);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(420, 0x21);
            this.panel1.TabIndex = 7;
            this.progressBar1.Location = new Point(0x11d, 9);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0x84, 0x11);
            this.progressBar1.TabIndex = 12;
            this.buttonFind.Location = new Point(0xc3, 3);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 1;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(420, 0x18);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addCancelTypeItemToolStripMenuItem, this.viewReordToolStripMenuItem, this.editCancelTypeToolStripMenuItem, this.deleteToolStripMenuItem, this.zWBToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.addCancelTypeItemToolStripMenuItem.Name = "addCancelTypeItemToolStripMenuItem";
            this.addCancelTypeItemToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addCancelTypeItemToolStripMenuItem.Text = "Add New Record";
            this.addCancelTypeItemToolStripMenuItem.Click += new EventHandler(this.addCancelTypeItemToolStripMenuItem_Click);
            this.viewReordToolStripMenuItem.Name = "viewReordToolStripMenuItem";
            this.viewReordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewReordToolStripMenuItem.Text = "View Record";
            this.viewReordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            this.editCancelTypeToolStripMenuItem.Name = "editCancelTypeToolStripMenuItem";
            this.editCancelTypeToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editCancelTypeToolStripMenuItem.Text = "Edit  Record";
            this.editCancelTypeToolStripMenuItem.Click += new EventHandler(this.editCancelTypeToolStripMenuItem_Click);
            this.chooseToolStripMenuItem.Name = "chooseToolStripMenuItem";
            this.chooseToolStripMenuItem.Size = new Size(0x3b, 20);
            this.chooseToolStripMenuItem.Text = "Choose";
            this.chooseToolStripMenuItem.Click += new EventHandler(this.chooseToolStripMenuItem_Click);
            ToolStripItem[] itemArray3 = new ToolStripItem[] { this.getCancelTypeFromZWBToolStripMenuItem, this.getAllCancelTypeFromZWBToolStripMenuItem };
            this.zWBToolStripMenuItem.DropDownItems.AddRange(itemArray3);
            this.zWBToolStripMenuItem.Name = "zWBToolStripMenuItem";
            this.zWBToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.zWBToolStripMenuItem.Text = "ZWB";
            this.getCancelTypeFromZWBToolStripMenuItem.Name = "getCancelTypeFromZWBToolStripMenuItem";
            this.getCancelTypeFromZWBToolStripMenuItem.Size = new Size(0xeb, 0x16);
            this.getCancelTypeFromZWBToolStripMenuItem.Text = "Get Cancel Type From ZWB";
            this.getCancelTypeFromZWBToolStripMenuItem.Click += new EventHandler(this.getCancelTypeFromZWBToolStripMenuItem_Click);
            this.getAllCancelTypeFromZWBToolStripMenuItem.Name = "getAllCancelTypeFromZWBToolStripMenuItem";
            this.getAllCancelTypeFromZWBToolStripMenuItem.Size = new Size(0xeb, 0x16);
            this.getAllCancelTypeFromZWBToolStripMenuItem.Text = "Get All Cancel Type From ";
            this.getAllCancelTypeFromZWBToolStripMenuItem.Click += new EventHandler(this.getAllCancelTypeFromZWBToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(420, 0x198);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.menuStrip1);
            base.Name = "FormCancelType";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormCancelType";
            base.Load += new EventHandler(this.FormTransType_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransType_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseToolStripMenuItem.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addCancelTypeItemToolStripMenuItem.Text = Resource.Menu_Add;
            this.editCancelTypeToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
            this.viewReordToolStripMenuItem.Text = Resource.Menu_015;
            this.Text = "Cancel Type";
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.zTable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormCancelTypeEntry entry = new FormCancelTypeEntry {
                    pMode = "VIEW",
                    zTable = this.zTable,
                    Text = "View Record of Cancel Type ",
                    nCurrRow = this.zTable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                this.zTable.UnLock();
                entry.Dispose();
            }
        }
    }
}

