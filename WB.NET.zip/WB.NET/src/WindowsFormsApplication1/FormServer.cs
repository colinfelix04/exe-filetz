﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.Text.RegularExpressions;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormServer : Form
    {
        private DataTable ztable = new DataTable();
        private DataRow dr;
        private string[] aRow = new string[7];
        public string sServer;
        public string sDatabase;
        public string sUser;
        public string sPass;
        public string sCoyCode;
        public string sLocCode;
        public string sWBCode;
        public bool pReturn = false;
        private IContainer components = null;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem chooseToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        public DataGridView dataGridView1;

        public FormServer()
        {
            this.InitializeComponent();
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WBData data = new WBData();
            WBData.sServer = this.dataGridView1.CurrentRow.Cells["server"].Value.ToString();
            WBData.sDatabase = this.dataGridView1.CurrentRow.Cells["Database"].Value.ToString();
            WBData.sUserID = "sa";
            WBData.sPassword = Program.shoot(this.dataGridView1.CurrentRow.Cells["shoot"].Value.ToString(), false);
            if (this.dataGridView1.CurrentRow.Cells["Username"].Value.ToString() != "")
            {
                WBData.sUserID = Program.shoot(this.dataGridView1.CurrentRow.Cells["Username"].Value.ToString(), false);
            }
            if (!data.TestConnect())
            {
                MessageBox.Show(Resource.Mes_205, Resource.Title_002);
            }
            else
            {
                WBData.Close();
                this.sServer = WBData.sServer;
                this.sDatabase = WBData.sDatabase;
                this.sUser = WBData.sUserID;
                this.sPass = WBData.sPassword;
                WBConfigurationHandler.createDirectory();
                if (File.Exists(WBConfigurationHandler.configurationFile))
                {
                    Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                        { 
                            "SERVER",
                            WBData.sServer
                        },
                        { 
                            "DATABASE",
                            WBData.sDatabase
                        },
                        { 
                            "USERID",
                            WBData.sUserID
                        },
                        { 
                            "PASSWORD",
                            WBData.sPassword
                        }
                    };
                    WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                    dictToTxt.Clear();
                }
                else
                {
                    Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                        { 
                            "SERVER",
                            WBData.sServer
                        },
                        { 
                            "DATABASE",
                            WBData.sDatabase
                        },
                        { 
                            "USERID",
                            WBData.sUserID
                        },
                        { 
                            "PASSWORD",
                            WBData.sPassword
                        }
                    };
                    WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                    dictToTxt.Clear();
                }
                this.pReturn = true;
                MessageBox.Show(Resource.Mes_206, Resource.Title_007);
                base.Close();
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseToolStripMenuItem.PerformClick();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.chooseToolStripMenuItem.PerformClick();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        public void fLoad()
        {
            DataGridViewTextBoxColumn dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "No",
                HeaderText = "No",
                ReadOnly = true
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Coy",
                HeaderText = "Nama PT",
                ReadOnly = true
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Description",
                HeaderText = "Description",
                ReadOnly = true
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Server",
                HeaderText = "Server",
                ReadOnly = true,
                Visible = true
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Database",
                HeaderText = "Database",
                ReadOnly = true,
                Visible = false
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Shoot",
                HeaderText = "Shoot",
                ReadOnly = true,
                Visible = false
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Username",
                HeaderText = "Username",
                ReadOnly = true,
                Visible = false
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
        }

        private void FormServer_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormServer_Load(object sender, EventArgs e)
        {
            DataGridViewTextBoxColumn dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "No",
                HeaderText = "No",
                ReadOnly = true
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Coy",
                HeaderText = "Nama PT",
                ReadOnly = true
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Description",
                HeaderText = "Description",
                ReadOnly = true
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Server",
                HeaderText = "Server",
                ReadOnly = true,
                Visible = true
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Database",
                HeaderText = "Database",
                ReadOnly = true,
                Visible = false
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Shoot",
                HeaderText = "Shoot",
                ReadOnly = true,
                Visible = false
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            dataGridViewColumn = new DataGridViewTextBoxColumn {
                Name = "Username",
                HeaderText = "Username",
                ReadOnly = true,
                Visible = false
            };
            this.dataGridView1.Columns.Add(dataGridViewColumn);
            dataGridViewColumn.Dispose();
            Crypthography crypthography = new Crypthography();
            if (crypthography.checkFile())
            {
                this.readStr(crypthography.decrypt());
            }
            else
            {
                this.readText(Application.StartupPath + @"\server.txt");
            }
            crypthography.Dispose();
        }

        public bool getConnection()
        {
            try
            {
                Crypthography crypthography = new Crypthography();
                this.readStr(crypthography.decrypt());
                crypthography.Dispose();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        private void InitializeComponent()
        {
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.chooseToolStripMenuItem = new ToolStripMenuItem();
            this.exitToolStripMenuItem = new ToolStripMenuItem();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.BorderStyle = BorderStyle.Fixed3D;
            this.dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x1e2, 0x166);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.chooseToolStripMenuItem, this.exitToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x1e2, 0x18);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            this.chooseToolStripMenuItem.Name = "chooseToolStripMenuItem";
            this.chooseToolStripMenuItem.Size = new Size(0x3b, 20);
            this.chooseToolStripMenuItem.Text = "&Choose";
            this.chooseToolStripMenuItem.Click += new EventHandler(this.chooseToolStripMenuItem_Click);
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new Size(0x25, 20);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new EventHandler(this.exitToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1e2, 0x17e);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "FormServer";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Weighbridge Server List";
            base.Load += new EventHandler(this.FormServer_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormServer_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void readStr(string strData)
        {
            try
            {
                int num = 0;
                int index = 0;
                string[] values = new string[7];
                string[] strArray2 = Regex.Split(strData, "\r\n|\r|\n");
                int num3 = 0;
                while (true)
                {
                    if (num3 >= strArray2.Length)
                    {
                        break;
                    }
                    if (strArray2[num3].Substring(0, 1) != "=")
                    {
                        values[index] = strArray2[num3];
                        index++;
                        if (((index == 6) || (index == 7)) ? (strArray2[num3 + 1].Substring(0, 1) == "=") : false)
                        {
                            this.dataGridView1.Rows.Add(values);
                            index = 0;
                        }
                    }
                    else
                    {
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= values.Length)
                            {
                                num++;
                                index = 1;
                                values[0] = num.ToString();
                                break;
                            }
                            values[num4] = "";
                            num4++;
                        }
                    }
                    num3++;
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Resource.Mes_207 + "\n" + exception.Message.ToString(), Resource.Title_003);
            }
        }

        private void readText(string filePath)
        {
            try
            {
                int num = 0;
                int index = 0;
                string[] values = new string[7];
                string[] strArray2 = File.ReadAllLines(filePath);
                int num3 = 0;
                while (true)
                {
                    if (num3 >= strArray2.Length)
                    {
                        break;
                    }
                    if (strArray2[num3].Substring(0, 1) != "=")
                    {
                        values[index] = strArray2[num3];
                        index++;
                        if (((index == 6) || (index == 7)) ? (strArray2[num3 + 1].Substring(0, 1) == "=") : false)
                        {
                            this.dataGridView1.Rows.Add(values);
                            index = 0;
                        }
                    }
                    else
                    {
                        int num4 = 0;
                        while (true)
                        {
                            if (num4 >= values.Length)
                            {
                                num++;
                                index = 1;
                                values[0] = num.ToString();
                                break;
                            }
                            values[num4] = "";
                            num4++;
                        }
                    }
                    num3++;
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Resource.Mes_207 + "\n" + exception.Message.ToString(), Resource.Title_003);
            }
        }
    }
}

