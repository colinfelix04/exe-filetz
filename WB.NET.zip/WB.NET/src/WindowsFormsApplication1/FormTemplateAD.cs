﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTemplateAD : Form
    {
        public DataTable aTable;
        private IContainer components = null;
        private DataGridView dataGridView1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem exportExcelToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;

        public FormTemplateAD()
        {
            this.InitializeComponent();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
            base.Dispose();
        }

        private void exportExcelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program.export2Excel(this.dataGridView1, "TemplateAD", "Template AD", false);
            base.Close();
            base.Dispose();
        }

        private void FormTemplateAD_Load(object sender, EventArgs e)
        {
            this.dataGridView1.DataSource = this.aTable;
            this.dataGridView1.Columns["Remark"].Width = 500;
        }

        private void InitializeComponent()
        {
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.exportExcelToolStripMenuItem = new ToolStripMenuItem();
            this.exitToolStripMenuItem = new ToolStripMenuItem();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new Size(0x310, 0x1b5);
            this.dataGridView1.TabIndex = 0;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.exportExcelToolStripMenuItem, this.exitToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x310, 0x18);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            this.exportExcelToolStripMenuItem.Name = "exportExcelToolStripMenuItem";
            this.exportExcelToolStripMenuItem.Size = new Size(0x51, 20);
            this.exportExcelToolStripMenuItem.Text = "Export Excel";
            this.exportExcelToolStripMenuItem.Click += new EventHandler(this.exportExcelToolStripMenuItem_Click);
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new Size(0x25, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new EventHandler(this.exitToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x310, 0x1cd);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Name = "FormTemplateAD";
            this.Text = "Generate Template AD";
            base.Load += new EventHandler(this.FormTemplateAD_Load);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

