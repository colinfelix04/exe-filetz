﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;

    public class WBToken : Component
    {
        private Random random = new Random();
        private string vMode = "";
        public static int Kunci = 0x65;

        public static string Acak(string pTolDev, string keys, bool diAcak)
        {
            string str = "";
            int num = Convert.ToInt16(keys);
            str = "";
            for (int i = 0; i < pTolDev.Length; i++)
            {
                int num3 = Convert.ToInt16(pTolDev.Substring(i, 1));
                bool flag = diAcak;
                str = !flag ? (str + mod((num3 - num) - (i + 1), 10).ToString()) : (str + mod((num3 + num) + (i + 1), 10).ToString());
            }
            return str;
        }

        public string countManual(string PIN1, string PIN2)
        {
            string str2 = "";
            string str3 = "";
            string str4 = (Convert.ToDouble(PIN2) - Convert.ToDouble(PIN1)).ToString();
            str2 = this.getMenuCode(this.vMode);
            str3 = WBSetting.Field("AREA").ToString();
            double num = 0.0;
            for (int i = 0; i < PIN1.Length; i++)
            {
                num += Convert.ToDouble(PIN1.Substring(i, 1));
            }
            return (Convert.ToDouble(Math.Sqrt(Convert.ToDouble(((((((Convert.ToDouble(str4) / Convert.ToDouble(str2)) - 2409.0) - num) / Convert.ToDouble(str2)) - (2.0 * Convert.ToDouble(str3))) - Convert.ToDouble(num)).ToString())).ToString()) - num).ToString();
        }

        public static string Encrypt(double pPercent, double pTruck)
        {
            double num = 15.0 + (pPercent * 10.0);
            double num2 = (pTruck - num) + Kunci;
            string str2 = num.ToString().Trim();
            string str3 = num2.ToString().Trim().PadLeft(3, '0');
            return (str2.Substring(0, 1) + str3.Substring(0, 2) + str2.Substring(1, 1) + str3.Substring(2, 1));
        }

        public string generatePIN(string aToken, string pMode)
        {
            string str2 = "";
            string str3 = "";
            string s = "";
            string str5 = "";
            string str9 = "";
            string str10 = "";
            str9 = this.getMenuCode(pMode);
            this.vMode = pMode;
            str10 = WBSetting.Field("AREA").ToString();
            str3 = aToken;
            string str6 = DateTime.Now.Date.ToString("dd");
            string str7 = DateTime.Now.Date.ToString("MM");
            string str8 = DateTime.Now.Date.ToString("yyyy");
            int num2 = 0;
            while (true)
            {
                char ch;
                if (num2 >= aToken.Length)
                {
                    s = s + str6 + str7 + str8;
                    int num4 = 0;
                    while (true)
                    {
                        if (num4 >= aToken.Length)
                        {
                            s = str5;
                            int num = 0;
                            byte[] bytes = Encoding.ASCII.GetBytes(s);
                            int index = 0;
                            while (true)
                            {
                                if (index >= s.Length)
                                {
                                    num = Math.Abs((int) (((num * 0x3969c) * Convert.ToInt16(str9)) / (0x4b4 + Convert.ToInt16(str10))));
                                    string str = str2;
                                    return num.ToString();
                                }
                                num += bytes[index];
                                index++;
                            }
                        }
                        string[] textArray1 = new string[5];
                        textArray1[0] = str5;
                        textArray1[1] = (Convert.ToInt16(str9) * (num4 + 2)).ToString();
                        ch = s[num4];
                        textArray1[2] = ch.ToString();
                        textArray1[3] = (Convert.ToInt16(str10) * num4).ToString();
                        textArray1[4] = str9;
                        str5 = string.Concat(textArray1);
                        num4++;
                    }
                }
                ch = aToken[num2];
                s = s + (Convert.ToInt64(ch.ToString()) * Convert.ToInt64(str10)).ToString();
                num2++;
            }
        }

        public string generateToken(string[] parameters, string pMode, string comTol, string allTrx)
        {
            int num6;
            string str = "";
            string str2 = "0";
            if (Convert.ToInt16(this.getMenuCode(pMode)) == 0x12)
            {
                str = str2 = Encrypt(Convert.ToDouble(comTol), Convert.ToDouble(allTrx));
            }
            else
            {
                while (true)
                {
                    if (str.ToString().Length == 5)
                    {
                        break;
                    }
                    num6 = this.random.Next(0, 0x1869f);
                    str2 = num6.ToString();
                    str = str2.ToString().Trim().PadRight(5, '1');
                }
            }
            str = str.Substring(0, 5) + WBSetting.appCode + WBSetting.Field("Area");
            int num = Convert.ToInt16(str.Substring(1, 1));
            int num2 = Convert.ToInt16(str.Substring(2, 1));
            int num3 = Convert.ToInt16(str.Substring(4, 1));
            int[] array = new int[] { num, num2, num3 };
            Array.Reverse(array);
            int num4 = array.Max();
            int num5 = 0;
            while (num5.ToString().Length != 3)
            {
                if (Convert.ToInt16(this.getMenuCode(pMode)) != 0x12)
                {
                    str = (str2 = this.random.Next(0, 0x1869f).ToString()).ToString().Trim().PadRight(5, '1') + WBSetting.appCode + WBSetting.Field("Area");
                    num = Convert.ToInt16(str.Substring(1, 1));
                    num2 = Convert.ToInt16(str.Substring(2, 1));
                    num3 = Convert.ToInt16(str.Substring(4, 1));
                    array[0] = num;
                    array[1] = num2;
                    array[2] = num3;
                    num4 = array.Max();
                    Array.Reverse(array);
                    while (true)
                    {
                        if (((num != 0) && (num2 != 0)) && (num4 != 0))
                        {
                            break;
                        }
                        num6 = this.random.Next(0, 0x1869f);
                        str = (str2 = num6.ToString()).ToString().Trim().PadRight(5, '1') + WBSetting.appCode + WBSetting.Field("Area");
                        num = Convert.ToInt16(str.Substring(1, 1));
                        num2 = Convert.ToInt16(str.Substring(2, 1));
                        num3 = Convert.ToInt16(str.Substring(4, 1));
                        array[0] = num;
                        array[1] = num2;
                        array[2] = num3;
                        num4 = array.Max();
                        Array.Reverse(array);
                    }
                }
                int num7 = array.Min();
                int num8 = Convert.ToInt16(this.getMenuCode(pMode));
                num5 = (((((num + num2) + num3) + (Convert.ToInt16(num + num2 + num3) - ((num * num2) * num3))) - (num8 * num4)) + (0x2a * num7)) + 0xde;
                str = str + num5.ToString().PadLeft(3, '0');
            }
            return str;
        }

        public string generateV2PIN(string aToken, string menuCode)
        {
            string str2 = "";
            string str3 = "";
            string str4 = "";
            string str5 = "";
            int num = Convert.ToInt32(this.getMenuCode(menuCode));
            str2 = aToken;
            this.vMode = menuCode;
            str4 = WBSetting.Field("AREA").ToString();
            string str6 = DateTime.Now.Date.ToString("dd");
            string str7 = DateTime.Now.Date.ToString("MM");
            string str8 = DateTime.Now.Date.ToString("yyyy");
            int num3 = 0;
            while (true)
            {
                char ch;
                if (num3 >= aToken.Length)
                {
                    str3 = str3 + str6 + str7 + str8;
                    int num5 = 0;
                    while (true)
                    {
                        if (num5 >= aToken.Length)
                        {
                            str3 = str5;
                            int num2 = 0;
                            while (true)
                            {
                                if (str3.Length <= 5)
                                {
                                    if (str3.Length > 0)
                                    {
                                        num2 += Convert.ToInt32(str3);
                                    }
                                    num2 = Math.Abs((int) (((((num2 + Convert.ToInt32(aToken.Substring(0, 5))) + Convert.ToInt32(aToken.Substring(aToken.Length - 6, 5))) * 0x93c) * Convert.ToInt16(num)) / (0x4b4 + Convert.ToInt16(str4))));
                                    num2 = (num2 > 0xf423f) ? (num2 - 0xf423f) : num2;
                                    return ((num2 < 0x186a0) ? (num2 + Math.Max(Convert.ToInt32(str6[1].ToString() + "00000"), 0x61a80)) : num2).ToString();
                                }
                                num2 += Convert.ToInt32(str3.Substring(0, 5));
                                str3 = str3.Substring(5);
                            }
                        }
                        object[] objArray1 = new object[5];
                        objArray1[0] = str5;
                        objArray1[1] = (Convert.ToInt16(num) * (num5 + 2)).ToString();
                        ch = str3[num5];
                        objArray1[2] = ch.ToString();
                        objArray1[3] = (Convert.ToInt16(str4) * num5).ToString();
                        objArray1[4] = num;
                        str5 = string.Concat(objArray1);
                        num5++;
                    }
                }
                ch = aToken[num3];
                str3 = str3 + (Convert.ToInt64(ch.ToString()) * Convert.ToInt64(str4)).ToString();
                num3++;
            }
        }

        public string getMenuCode(string pMode)
        {
            string str = "";
            if (pMode == "DEDUCTION")
            {
                pMode = "EDIT_DEDUCTION";
            }
            else if (pMode == "EDIT_SPB")
            {
                pMode = "EDIT_DN_TRX";
            }
            else if (pMode == "EDIT_REPORTDATE")
            {
                pMode = "EDIT_REPORTDATE_TRX";
            }
            string s = pMode;
            uint num = <PrivateImplementationDetails>.ComputeStringHash(s);
            if (num <= 0x802918b0)
            {
                if (num <= 0x48d82ed7)
                {
                    if (num <= 0x783742a)
                    {
                        if (num <= 0x692164e)
                        {
                            if (num != 0x5f1a47c)
                            {
                                if ((num == 0x692164e) && (s == "UNLOCK_TDT"))
                                {
                                    str = "26";
                                }
                            }
                            else if (s == "MARK_ACCIDENT")
                            {
                                str = "11";
                            }
                        }
                        else if (num != 0x77e1c11)
                        {
                            if ((num == 0x783742a) && (s == "OVER_TARE_FOR_NX_TRANSACTION"))
                            {
                                str = "37";
                            }
                        }
                        else if (s == "EDIT")
                        {
                            str = "01";
                        }
                    }
                    else if (num <= 0x2523b2ee)
                    {
                        if (num != 0x1ec919e4)
                        {
                            if ((num == 0x2523b2ee) && (s == "EDIT_DELETE_MD_DN"))
                            {
                                str = "38";
                            }
                        }
                        else if (s == "VESSEL_PERCENTAGE_TOLERANCE")
                        {
                            str = "34";
                        }
                    }
                    else if (num != 0x361026d9)
                    {
                        if ((num == 0x48d82ed7) && (s == "REPRINT"))
                        {
                            str = "04";
                        }
                    }
                    else if (s == "OVER_GROSS_FFB")
                    {
                        str = "17";
                    }
                }
                else if (num <= 0x6caea7ae)
                {
                    if (num <= 0x55c17aca)
                    {
                        if (num != 0x52fabbdb)
                        {
                            if ((num == 0x55c17aca) && (s == "EDIT_COLLECTIVE"))
                            {
                                str = "22";
                            }
                        }
                        else if (s == "CANCEL")
                        {
                            str = "03";
                        }
                    }
                    else if (num != 0x67cf6a2c)
                    {
                        if ((num == 0x6caea7ae) && (s == "OVER_TARE"))
                        {
                            str = "16";
                        }
                    }
                    else if (s == "BLACKLIST")
                    {
                        str = "23";
                    }
                }
                else if (num <= 0x70b7f2f3)
                {
                    if (num != 0x70b5fcf5)
                    {
                        if ((num == 0x70b7f2f3) && (s == "QTY"))
                        {
                            str = "05";
                        }
                    }
                    else if (s == "EDIT_DEDUCTION")
                    {
                        str = "39";
                    }
                }
                else if (num == 0x7ba48539)
                {
                    if (s == "TOLERANCE_COMM")
                    {
                        str = "10";
                    }
                }
                else if (num != 0x7cc72f70)
                {
                    if ((num == 0x802918b0) && (s == "OVER_GROSSQTY"))
                    {
                        str = "14";
                    }
                }
                else if (s == "EDIT_SPAREPART")
                {
                    str = "33";
                }
            }
            else if (num <= 0xb630cc9d)
            {
                if (num <= 0x8be7f20f)
                {
                    if (num <= 0x85f72c2d)
                    {
                        if (num != 0x81f4c775)
                        {
                            if ((num == 0x85f72c2d) && (s == "EDIT_REPORTDATE_TRX"))
                            {
                                str = "41";
                            }
                        }
                        else if (s == "EDIT_DN_TRX")
                        {
                            str = "40";
                        }
                    }
                    else if (num != 0x87695a22)
                    {
                        if ((num == 0x8be7f20f) && (s == "GRCUST"))
                        {
                            str = "07";
                        }
                    }
                    else if (s == "BYPASS_MANNED_WEIGHING")
                    {
                        str = "25";
                    }
                }
                else if (num <= 0x9fe2ae77)
                {
                    if (num != 0x9034e195)
                    {
                        if ((num == 0x9fe2ae77) && (s == "BYPASS_EXPIRED_BC"))
                        {
                            str = "21";
                        }
                    }
                    else if (s == "DELIVERY")
                    {
                        str = "08";
                    }
                }
                else if (num == 0xa436af2a)
                {
                    if (s == "OVER_GROSS_LOSS_TOLERANCE")
                    {
                        str = "24";
                    }
                }
                else if (num != 0xaaced0c7)
                {
                    if ((num == 0xb630cc9d) && (s == "DO_SAP_FAIL_VALID"))
                    {
                        str = "13";
                    }
                }
                else if (s == "ADD_RETUR")
                {
                    str = "19";
                }
            }
            else if (num <= 0xccb95714)
            {
                if (num <= 0xc48fe103)
                {
                    if (num != 0xc3bae7e1)
                    {
                        if ((num == 0xc48fe103) && (s == "OVER_NET_LOSS_TOLERANCE"))
                        {
                            str = "24";
                        }
                    }
                    else if (s == "NOT_ADOPTSAP")
                    {
                        str = "12";
                    }
                }
                else if (num != 0xc861e707)
                {
                    if ((num == 0xccb95714) && (s == "OVER_BC_QTY"))
                    {
                        str = "28";
                    }
                }
                else if (s == "OVER_TANKER")
                {
                    str = "15";
                }
            }
            else if (num <= 0xce0783c6)
            {
                if (num != 0xcd1b3da3)
                {
                    if ((num == 0xce0783c6) && (s == "COMM_CONT_TOL"))
                    {
                        str = "18";
                    }
                }
                else if (s == "MANUAL")
                {
                    str = "06";
                }
            }
            else if (num == 0xe08c94d1)
            {
                if (s == "DISABLE_CONDITION")
                {
                    str = "27";
                }
            }
            else if (num != 0xe87f69c9)
            {
                if ((num == 0xf8718eca) && (s == "DELETE"))
                {
                    str = "02";
                }
            }
            else if (s == "OVERQTY")
            {
                str = "09";
            }
            return str;
        }

        public static double GetPercent(string pToken) => 
            (Convert.ToDouble(pToken.Substring(0, 1) + pToken.Substring(3, 1)) - 15.0) / 10.0;

        public string[] GetTDPIN(string pPIN)
        {
            string[] strArray2;
            string[] strArray = new string[] { "", "", "", "" };
            string str = pPIN.Substring(pPIN.Length - 1, 1);
            pPIN = pPIN.Substring(0, pPIN.Length - 1);
            if (pPIN.Length < (Convert.ToInt16(str) + 5))
            {
                strArray[0] = "0";
                strArray2 = strArray;
            }
            else
            {
                string oldValue = pPIN.Substring(Convert.ToInt16(str), 5);
                strArray[0] = pPIN.Replace(oldValue, "");
                oldValue = Acak(oldValue, str, false);
                strArray[1] = GetPercent(oldValue).ToString();
                strArray[2] = GetTrucks(oldValue).ToString();
                strArray2 = strArray;
            }
            return strArray2;
        }

        public static double GetTrucks(string pToken)
        {
            string str = pToken.Substring(0, 1) + pToken.Substring(3, 1);
            return ((Convert.ToDouble(pToken.Substring(1, 2) + pToken.Substring(4, 1)) - Kunci) + Convert.ToDouble(str));
        }

        private static int mod(int x, int m) => 
            ((x % m) + m) % m;

        public string tdPIN(string pPin, string pPercent, string pTrucks)
        {
            string str2 = ((char) new Random(DateTime.Now.Millisecond).Next(0x30, 0x35)).ToString();
            return ((string.IsNullOrEmpty(pPin) ? "" : pPin).Insert(Convert.ToInt16(str2), Acak(Encrypt(Convert.ToDouble(pPercent), Convert.ToDouble(pTrucks)), str2, true)) + str2);
        }

        public string TokenDeviation(string pDO, string pToken)
        {
            int num = 0;
            byte[] bytes = Encoding.ASCII.GetBytes(pDO);
            int index = 0;
            while (true)
            {
                if (index >= pDO.Length)
                {
                    string str2 = num.ToString().PadLeft(4, '0');
                    string str3 = this.random.Next(1, 9).ToString();
                    return (pToken.Insert(Convert.ToInt16(str3), str2) + str3);
                }
                num += bytes[index];
                index++;
            }
        }
    }
}

