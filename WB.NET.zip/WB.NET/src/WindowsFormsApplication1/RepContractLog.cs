﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.Windows.Forms;

    public class RepContractLog : Form
    {
        public bool zAuto = false;
        public string chckSQL;
        public string tipe;
        private WBTable tbl_DoNo;
        private WBTable tbl_info;
        private string fName = "";
        private IContainer components = null;
        public GroupBox groupBox1;
        public DateTimePicker monthCalendar1;
        public Label label5;
        public Label label6;
        public DateTimePicker monthCalendar2;
        public TextBox textDoNo;
        public CheckBox checkDate;
        public Label label3;
        public Button button1;
        public Label labelcommodity;
        public Button button2;
        public Label labelProses1;
        public Label labelProses2;

        public RepContractLog()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tbl_DoNo.OpenTable("wb_Contract", "Select * from wb_Contract where " + WBData.CompanyLocation(""), WBData.conn);
            if (this.textDoNo.Text.Trim() != "")
            {
                string[] aField = new string[] { "Do_No" };
                string[] aFind = new string[] { this.textDoNo.Text.Trim() };
                if (ReferenceEquals(this.tbl_DoNo.GetData(aField, aFind), null))
                {
                    MessageBox.Show("Do No not Exist...", "Warning...");
                    this.textDoNo.SelectAll();
                    this.textDoNo.Focus();
                    return;
                }
            }
            WBTable vContLog = new WBTable();
            vContLog = this.initTable(this.checkDate.Checked, this.monthCalendar1.Value, this.monthCalendar2.Value, this.textDoNo.Text, WBData.sCoyCode, WBData.sLocCode);
            if (vContLog.DT.Rows.Count <= 0)
            {
                MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                HTML html = new HTML();
                html = this.generateRep(vContLog, this.monthCalendar1.Value, WBData.sCoyCode, WBData.sLocCode);
                ViewReport report = new ViewReport {
                    webBrowser1 = { Url = new Uri("file:///" + html.File) }
                };
                report.ShowDialog();
                this.labelProses1.Text = "";
                this.labelProses1.Refresh();
                this.labelProses2.Text = "";
                this.labelProses2.Refresh();
                html.Dispose();
                report.Dispose();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void checkDate_CheckedChanged(object sender, EventArgs e)
        {
            this.textDoNo.Enabled = !this.checkDate.Checked;
            this.monthCalendar1.Enabled = this.checkDate.Checked;
            this.monthCalendar2.Enabled = this.checkDate.Checked;
            this.textDoNo.Text = "";
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public HTML generateRep(WBTable vContLog, DateTime dt, string coy, string loc)
        {
            DataRow row;
            bool flag;
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            string[] textArray1 = new string[] { "SELECT * FROM wb_location WHERE coy = '", coy, "' and location_code = '", loc, "'" };
            table2.OpenTable("wb_loc", string.Concat(textArray1), WBData.conn);
            table.OpenTable("wb_coy", "SELECT * FROM wb_company WHERE coy_code = '" + coy + "'", WBData.conn);
            this.labelProses1.Text = "0/" + vContLog.DT.Rows.Count;
            this.tbl_info = new WBTable();
            string sqltext = "Select ORDINAL_POSITION as NO, COLUMN_NAME as FIELD, DATA_TYPE as TYPE, CHARACTER_MAXIMUM_LENGTH as LENGTH, IS_NULLABLE as ISNULL from INFORMATION_SCHEMA.COLUMNS WHERE table_name ='wb_contract_log'";
            this.tbl_info.OpenTable("wb_info", sqltext, WBData.conn);
            int count = 0;
            count = this.tbl_info.DT.Rows.Count;
            HTML rep = new HTML();
            string path = rep.File + @"\LogReport";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            HTML html2 = rep;
            string[] textArray2 = new string[] { html2.File, @"\LogReport\", coy, loc, "CONTRACTLOG_", dt.ToString("ddMMyyyy"), ".htm" };
            html2.File = string.Concat(textArray2);
            rep.Title = "List of Contract Log";
            rep.Open();
            rep.Write(rep.Style());
            rep.Write("<br><font size=5><b>LOGS LIST OF CONTRACT/DO</b></font><br>");
            string[] textArray3 = new string[] { "<br><font size=4>", table.DT.Rows[0]["coy_name"].ToString(), " (", coy, ")</font>" };
            rep.Write(string.Concat(textArray3));
            string[] textArray4 = new string[] { "<br><font size=4>", table2.DT.Rows[0]["location_name"].ToString(), " (", loc, ")</font>" };
            rep.Write(string.Concat(textArray4));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                rep.Write("<br><font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font>");
            }
            else
            {
                rep.Write("<br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                rep.Write("<br><font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br><br>");
            }
            else
            {
                rep.Write("<br>");
            }
            rep.Write("<font size=3>");
            if (this.textDoNo.Text.Trim() != "")
            {
                rep.Write("<br>Ref Number : <b>" + this.textDoNo.Text + "</b>");
            }
            if (this.checkDate.Checked)
            {
                string[] textArray5 = new string[] { "<br>Date : <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar1.Value.ToShortDateString(), "</b>" };
                rep.Write(string.Concat(textArray5));
            }
            string str3 = "";
            int num2 = 0;
            string str4 = "";
            vContLog.OpenTable("wb_trans_Log", this.chckSQL + " and Delete_by is null", WBData.conn);
            if (vContLog.DT.Rows.Count > 0)
            {
                rep.Write("<br>");
                rep.Write("<br><b>CHANGES ON CONTRACT</b>");
                rep.Write("<br>");
                rep.Write("<br>");
                rep.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                this.initHeader(rep);
                this.fName = "";
                num2 = 0;
                str4 = "";
                str3 = "";
                str4 = vContLog.DT.Rows[0]["sUniq"].ToString();
                row = vContLog.DT.Rows[0];
                flag = false;
                using (IEnumerator enumerator = vContLog.DT.Rows.GetEnumerator())
                {
                    goto TR_0050;
                TR_0034:
                    flag = true;
                    rep.Write("</tr> ");
                    num2++;
                TR_0050:
                    while (enumerator.MoveNext())
                    {
                        DataRow current = (DataRow) enumerator.Current;
                        str3 = current["Deleted"].ToString();
                        if (str3 != "Y")
                        {
                            this.labelProses1.Text = num2.ToString();
                            this.labelProses1.Refresh();
                            this.labelProses2.Text = current["DO_NO"].ToString();
                            this.labelProses2.Refresh();
                            if (str4 != current["sUniq"].ToString())
                            {
                                rep.Write("<tr class='bd'> ");
                                object[] objArray1 = new object[] { "<td colspan=", count, ">", rep.strq(""), "</td> " };
                                rep.Write(string.Concat(objArray1));
                                rep.Write("</tr> ");
                                this.initHeader(rep);
                                str4 = current["sUniq"].ToString();
                                row = current;
                                flag = false;
                            }
                            this.fName = "";
                            rep.Write("<tr class='bd'> ");
                            using (IEnumerator enumerator2 = this.tbl_info.DT.Rows.GetEnumerator())
                            {
                                DataRow row3;
                                goto TR_0047;
                            TR_003C:
                                if (row3["TYPE"].ToString().ToUpper().Trim() == "FLOAT")
                                {
                                    str3 = $"{str3:N0}";
                                }
                                if (!flag)
                                {
                                    rep.Write("<td valign=top nowrap bgcolor=white>" + rep.strq(str3) + "</td> ");
                                }
                                else if (flag)
                                {
                                    if (row[this.fName].ToString().Trim() != current[this.fName].ToString().Trim())
                                    {
                                        rep.Write("<td valign=top nowrap bgcolor=yellow>" + rep.strq(str3) + "</td> ");
                                    }
                                    else
                                    {
                                        rep.Write("<td valign=top nowrap bgcolor=white>" + rep.strq(str3) + "</td> ");
                                    }
                                }
                            TR_0047:
                                while (true)
                                {
                                    if (enumerator2.MoveNext())
                                    {
                                        row3 = (DataRow) enumerator2.Current;
                                        this.fName = row3["Field"].ToString().ToUpper();
                                        if (((this.fName == "UNIQ") || (this.fName == "COY")) || (this.fName == "LOCATION_CODE"))
                                        {
                                            continue;
                                        }
                                        str3 = current[this.fName].ToString();
                                        if ((this.fName.Length > 4) && (this.fName.ToUpper() != "CHANGE_DATE"))
                                        {
                                            if (this.fName.Substring(this.fName.Length - 4, 4).Trim().ToUpper() == "DATE")
                                            {
                                                str3 = (str3.Length >= 10) ? str3.Substring(0, 10) : str3;
                                            }
                                            else if (this.fName.Substring(this.fName.Length - 4, 4).Trim().ToUpper() == "TIME")
                                            {
                                                try
                                                {
                                                    str3 = Convert.ToDateTime(str3).ToString("HH:mm:ss");
                                                }
                                                catch
                                                {
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        goto TR_0034;
                                    }
                                    break;
                                }
                                goto TR_003C;
                            }
                        }
                    }
                    rep.Write("</table>");
                    rep.Write("<br>");
                    rep.Write("<br>");
                }
            }
            vContLog.OpenTable("wb_contract_Log", this.chckSQL + " and Deleted = 'Y'", WBData.conn);
            if (vContLog.DT.Rows.Count > 0)
            {
                rep.Write("<br><b>CANCEL ON CONTRACT</b>");
                rep.Write("<br>");
                rep.Write("<br>");
                rep.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                this.initHeader(rep);
                this.fName = "";
                num2 = 0;
                str4 = "";
                str3 = "";
                row = vContLog.DT.Rows[0];
                flag = false;
                using (IEnumerator enumerator3 = vContLog.DT.Rows.GetEnumerator())
                {
                    goto TR_002A;
                TR_000E:
                    flag = true;
                    rep.Write("</tr> ");
                    num2++;
                TR_002A:
                    while (enumerator3.MoveNext())
                    {
                        DataRow current = (DataRow) enumerator3.Current;
                        str3 = current["Deleted"].ToString();
                        if (str3 == "Y")
                        {
                            this.labelProses1.Text = num2.ToString();
                            this.labelProses1.Refresh();
                            this.labelProses2.Text = current["DO_NO"].ToString();
                            this.labelProses2.Refresh();
                            if ((str4.Trim().ToUpper() != current["sUniq"].ToString().Trim().ToUpper()) && (str4.Trim().ToUpper() != ""))
                            {
                                rep.Write("<tr class='bd'> ");
                                object[] objArray2 = new object[] { "<td colspan=", count, ">", rep.strq(""), "</td> " };
                                rep.Write(string.Concat(objArray2));
                                rep.Write("</tr> ");
                                this.initHeader(rep);
                                str4 = current["sUniq"].ToString();
                                row = current;
                                flag = false;
                            }
                            this.fName = "";
                            rep.Write("<tr class='bd'> ");
                            using (IEnumerator enumerator4 = this.tbl_info.DT.Rows.GetEnumerator())
                            {
                                DataRow row5;
                                goto TR_0021;
                            TR_0016:
                                if (row5["TYPE"].ToString().ToUpper().Trim() == "FLOAT")
                                {
                                    str3 = $"{str3:N0}";
                                }
                                if (!flag)
                                {
                                    rep.Write("<td valign=top nowrap bgcolor=white>" + rep.strq(str3) + "</td> ");
                                }
                                else if (flag)
                                {
                                    if (row[this.fName].ToString().Trim() != current[this.fName].ToString().Trim())
                                    {
                                        rep.Write("<td valign=top nowrap bgcolor=yellow>" + rep.strq(str3) + "</td> ");
                                    }
                                    else
                                    {
                                        rep.Write("<td valign=top nowrap bgcolor=white>" + rep.strq(str3) + "</td> ");
                                    }
                                }
                            TR_0021:
                                while (true)
                                {
                                    if (enumerator4.MoveNext())
                                    {
                                        row5 = (DataRow) enumerator4.Current;
                                        this.fName = row5["Field"].ToString().ToUpper();
                                        if (((this.fName == "UNIQ") || (this.fName == "COY")) || (this.fName == "LOCATION_CODE"))
                                        {
                                            continue;
                                        }
                                        str3 = current[this.fName].ToString();
                                        if ((this.fName.Length > 4) && (this.fName.ToUpper() != "CHANGE_DATE"))
                                        {
                                            if (this.fName.Substring(this.fName.Length - 4, 4).Trim().ToUpper() == "DATE")
                                            {
                                                str3 = (str3.Length >= 10) ? str3.Substring(0, 10) : str3;
                                            }
                                            else if (this.fName.Substring(this.fName.Length - 4, 4).Trim().ToUpper() == "TIME")
                                            {
                                                try
                                                {
                                                    str3 = Convert.ToDateTime(str3).ToString("HH:mm:ss");
                                                }
                                                catch
                                                {
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        goto TR_000E;
                                    }
                                    break;
                                }
                                goto TR_0016;
                            }
                        }
                    }
                    rep.Write("</table>");
                    rep.Write("<br>");
                    rep.Write("<br>");
                }
            }
            rep.writeSign();
            rep.Close();
            this.tbl_info.Dispose();
            return rep;
        }

        private void initHeader(HTML rep)
        {
            rep.Write("<tr class='bd'> ");
            foreach (DataRow row in this.tbl_info.DT.Rows)
            {
                this.fName = row["Field"].ToString().ToUpper();
                if (((this.fName != "UNIQ") && (this.fName != "COY")) && (this.fName != "LOCATION_CODE"))
                {
                    rep.Write("<th rowspan=nowrap align=center>" + row["Field"].ToString() + "</th> ");
                }
            }
            rep.Write("</tr> ");
            this.fName = "";
        }

        private void InitializeComponent()
        {
            this.groupBox1 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label5 = new Label();
            this.label6 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.textDoNo = new TextBox();
            this.checkDate = new CheckBox();
            this.label3 = new Label();
            this.button1 = new Button();
            this.labelcommodity = new Label();
            this.button2 = new Button();
            this.labelProses1 = new Label();
            this.labelProses2 = new Label();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.groupBox1.Controls.Add(this.monthCalendar1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.monthCalendar2);
            this.groupBox1.Location = new Point(15, 0x43);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x178, 0x2d);
            this.groupBox1.TabIndex = 0x4f;
            this.groupBox1.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(80, 0x10);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(8, 0x13);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x3e, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "From Date :";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xc6, 0x13);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x34, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x100, 0x10);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.textDoNo.CharacterCasing = CharacterCasing.Upper;
            this.textDoNo.Location = new Point(0x5e, 0x7e);
            this.textDoNo.Name = "textDoNo";
            this.textDoNo.Size = new Size(0xc0, 20);
            this.textDoNo.TabIndex = 80;
            this.checkDate.AutoSize = true;
            this.checkDate.Checked = true;
            this.checkDate.CheckState = CheckState.Checked;
            this.checkDate.Location = new Point(15, 0x2d);
            this.checkDate.Name = "checkDate";
            this.checkDate.Size = new Size(60, 0x11);
            this.checkDate.TabIndex = 0x54;
            this.checkDate.Text = "byDate";
            this.checkDate.UseVisualStyleBackColor = true;
            this.checkDate.CheckedChanged += new EventHandler(this.checkDate_CheckedChanged);
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(11, 12);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0xc7, 20);
            this.label3.TabIndex = 0x57;
            this.label3.Text = "List of DO/Contract Log";
            this.label3.TextAlign = ContentAlignment.TopCenter;
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x1b9, 0x4d);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x22);
            this.button1.TabIndex = 0x51;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x16, 0x81);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3f, 13);
            this.labelcommodity.TabIndex = 0x53;
            this.labelcommodity.Text = "DO/SO No.";
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1b9, 0x7c);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x22);
            this.button2.TabIndex = 0x52;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(340, 0x11);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0xd3, 13);
            this.labelProses1.TabIndex = 0x56;
            this.labelProses1.Text = "1/88888";
            this.labelProses1.TextAlign = ContentAlignment.MiddleRight;
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0x151, 30);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0xd6, 13);
            this.labelProses2.TabIndex = 0x55;
            this.labelProses2.Text = "Progresssss . . . . . . . . . . . . . . . . . ";
            this.labelProses2.TextAlign = ContentAlignment.MiddleRight;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x233, 0xa8);
            base.ControlBox = false;
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.checkDate);
            base.Controls.Add(this.textDoNo);
            base.Controls.Add(this.groupBox1);
            base.KeyPreview = true;
            base.Name = "RepContractLog";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Report DO/Contract Log";
            base.Load += new EventHandler(this.RepContractLog_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        public WBTable initTable(bool byDate, DateTime dateFrom, DateTime dateTo, string Do_No, string coy, string loc)
        {
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "SELECT * FROM wb_contract_log WHERE coy = '", coy, "' and location_code = '", loc, "'" };
            string sqltext = string.Concat(textArray1);
            if (byDate && !this.zAuto)
            {
                sqltext = (sqltext + " AND (log_date>='" + dateFrom.ToString("yyyy-MM-dd") + " 00:00:00'") + " AND log_date<='" + dateTo.ToString("yyyy-MM-dd") + " 00:00:00')";
            }
            else if (byDate && this.zAuto)
            {
                sqltext = sqltext + " AND (log_date ='" + dateTo.ToString("yyyy-MM-dd") + " 00:00:00')";
            }
            if (Do_No != "")
            {
                string[] aField = new string[] { "Do_No" };
                string[] aFind = new string[] { Do_No };
                DataRow data = this.tbl_DoNo.GetData(aField, aFind);
                sqltext = (data == null) ? (sqltext + " AND 1=2") : (sqltext + " AND sUniq='" + data["Uniq"].ToString() + "'");
            }
            this.chckSQL = sqltext;
            sqltext = sqltext + " ORDER BY deleted, sUniq, log_date, log_time";
            table.OpenTable("wb_contractLog", sqltext, WBData.conn);
            return table;
        }

        private void RepContractLog_Load(object sender, EventArgs e)
        {
            this.tbl_DoNo = new WBTable();
            this.tbl_DoNo.OpenTable("wb_Contract", "Select Do_No,uniq from wb_Contract where " + WBData.CompanyLocation(""), WBData.conn);
            base.KeyPreview = true;
            this.textDoNo.Enabled = false;
            this.labelProses1.Text = "";
            this.labelProses2.Text = "";
        }

        private void textDoNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }
    }
}

