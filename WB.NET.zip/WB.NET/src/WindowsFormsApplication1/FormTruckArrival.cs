﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.IO.Ports;
    using System.Windows.Forms;

    public class FormTruckArrival : Form
    {
        public WBTable tblTruck = new WBTable();
        public WBTable tblDriver = new WBTable();
        public WBTable tblTransporter = new WBTable();
        public WBTable tblTransType = new WBTable();
        public WBTable tblVwGatepass = new WBTable();
        public WBTable tblTAApprove = new WBTable();
        public WBTable tblGatepassType1 = new WBTable();
        public WBTable tblGatepassType2 = new WBTable();
        public DateTime dFrom;
        public DateTime dTo;
        private int idxFind = 0;
        private string cField;
        private string changeReason = "";
        private string logKey = "";
        private IContainer components = null;
        private DataGridView dgTA;
        private Label lblDate;
        private Label lblNow;
        private Timer timerSAPUpd;
        private SerialPort serialPort1;
        private Timer timer1;
        private BackgroundWorker backgroundWorker1;
        private Label label1;
        private TableLayoutPanel tableLayoutPanel1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addToolStripMenuItem;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem approveToolStripMenuItem;
        private ToolStripMenuItem backToolStripMenuItem;
        private ToolStripMenuItem viewToolStripMenuItem;
        private Panel panel1;
        private DateTimePicker dateTimePicker2;
        private DateTimePicker dateTimePicker1;
        private Label label3;
        private Label label4;
        private TextBox TextFind;
        private Button buttonFind;
        private Button buttonFilter;
        private Label labelStatus1;
        private Label label7;
        private Label label9;
        private GroupBox groupFilter;
        private Label label5;
        private Label label6;
        private TextBox textDriver;
        private TextBox textTruck;
        private TextBox textTransporter;
        private TextBox textTransType;
        private CheckBox checkApproved;
        private CheckBox checkPartial;
        private CheckBox checkDeleted;

        public FormTruckArrival()
        {
            this.InitializeComponent();
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            this.addToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_TRUCKARRIVAL", "A");
            this.editToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_TRUCKARRIVAL", "E");
            this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_TRUCKARRIVAL", "D");
            this.viewToolStripMenuItem.Enabled = WBUser.CheckTrustee("MN_TRUCKARRIVAL", "V");
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTruckArrivalEntry entry = new FormTruckArrivalEntry();
            this.tblVwGatepass.BeforeEdit(this.dgTA, "ADD");
            entry.pMode = "ADD";
            entry.Text = "ADD TRUCK ARRIVAL";
            entry.ShowDialog();
            if (entry.saved)
            {
                this.tblVwGatepass.ReOpen();
                this.dgTA = this.tblVwGatepass.AfterEdit(entry.pMode);
                this.dgTA.Refresh();
                string[] aField = new string[] { "TA_Number" };
                string[] aFind = new string[] { entry.textTA_Number.Text };
                this.tblVwGatepass.SetCursor(this.dgTA, this.tblVwGatepass.GetCurrentRow(this.dgTA, aField, aFind));
                this.ShowStatus();
            }
            entry.Dispose();
        }

        private void approveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dgTA.Rows.Count > 0)
            {
                string[] aField = new string[] { "ApproveCode" };
                string[] aFind = new string[] { this.dgTA.CurrentRow.Cells["ApproveCode"].Value.ToString().Trim() };
                this.tblTAApprove.DR = this.tblTAApprove.GetData(aField, aFind);
                if (this.tblTAApprove.DR == null)
                {
                    MessageBox.Show(Resource.Mes_415, Resource.Title_002);
                }
                else if (!WBUser.CheckTrustee(this.tblTAApprove.DR["ApproveOth"].ToString(), "A"))
                {
                    MessageBox.Show(Resource.Mes_415, Resource.Title_002);
                }
                else
                {
                    FormTruckArrivalEntry entry = new FormTruckArrivalEntry {
                        pMode = "APPROVE",
                        Text = "APPROVE TRUCK ARRIVAL"
                    };
                    this.tblVwGatepass.BeforeEdit(this.dgTA, "APPROVE");
                    entry.sUniq = this.dgTA.CurrentRow.Cells["Uniq"].Value.ToString();
                    entry.ShowDialog();
                    if (entry.saved)
                    {
                        this.tblVwGatepass.ReOpen();
                        this.dgTA = this.tblVwGatepass.AfterEdit(entry.pMode);
                        this.dgTA.Refresh();
                    }
                    entry.Dispose();
                }
            }
        }

        private void backToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void backToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonFilter_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            string str2 = "select " + this.cField + " from vw_gatepass_oth WHERE " + WBData.CompanyLocation(" and (Reject = 'N') AND  ((TA_number is not null) OR (TA_number <> '')) AND  (Approved = 'N') And  ((Submit_Gatepass IS NULL) or (Submit_Gatepass=''))  AND  ((Deleted = 'N') or (Deleted is null) or (Deleted =''))");
            string sqltext = ("select " + this.cField + " from vw_gatepass_oth WHERE " + WBData.CompanyLocation("")) + " and (Reject = 'N') AND ((Submit_Gatepass IS NULL) or (Submit_Gatepass=''))  ";
            sqltext = !this.checkDeleted.Checked ? (sqltext + " AND ((Deleted = 'N') or (Deleted is null) or (Deleted =''))") : (sqltext + " AND (Deleted = 'Y' OR ((Deleted = 'N') or (Deleted is null) or (Deleted =''))) ");
            sqltext = !this.checkApproved.Checked ? (sqltext + " AND ((Approved = 'N') or (Approved is null)) ") : (sqltext + " AND ((Approved = 'Y') OR (Approved = 'N') OR (Approved is null)) ");
            this.dFrom = this.dateTimePicker1.Value;
            this.dTo = this.dateTimePicker2.Value;
            string str3 = Program.DTOC(this.dFrom) + " 00:00:00";
            string str4 = Program.DTOC(this.dTo) + " 00:00:00";
            string[] textArray1 = new string[] { sqltext, " and ((In_Date>='", str3, "' and In_Date<='", str4, "'))" };
            sqltext = string.Concat(textArray1);
            this.tblVwGatepass.Close();
            this.tblVwGatepass.OpenTable("vw_gatepass_oth", sqltext, WBData.conn);
            this.DataReset();
            Cursor.Current = Cursors.Default;
            this.ShowStatus();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.idxFind = this.tblVwGatepass.NextFindSql(this.dgTA, this.TextFind.Text, this.idxFind);
            Cursor.Current = Cursors.Default;
        }

        private void checkPartial_CheckedChanged(object sender, EventArgs e)
        {
            this.chkPartial();
        }

        private void chkPartial()
        {
            Cursor.Current = Cursors.WaitCursor;
            if (!this.checkPartial.Checked)
            {
                this.groupFilter.Enabled = true;
            }
            else
            {
                this.groupFilter.Enabled = false;
                this.textTruck.Text = "";
                this.textDriver.Text = "";
                this.textTransporter.Text = "";
                this.textTransType.Text = "";
                this.checkApproved.Checked = false;
                string sqltext = "select " + this.cField + " from vw_gatepass_oth WHERE " + WBData.CompanyLocation(" and (Reject = 'N')AND ((TA_number is not null) OR (TA_number <> '')) AND  (Approved = 'N') And  ((Submit_Gatepass IS NULL) or (Submit_Gatepass=''))  AND  ((Deleted = 'N') or (Deleted is null) or (Deleted =''))");
                this.tblVwGatepass.Close();
                this.tblVwGatepass.OpenTable("vw_gatepass_oth", sqltext, WBData.conn);
                this.DataReset();
                Cursor.Current = Cursors.Default;
                this.ShowStatus();
            }
            Cursor.Current = Cursors.Default;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dgTA.Rows[e.RowIndex].Cells["Deleted"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Red;
                e.CellStyle.SelectionBackColor = Color.HotPink;
            }
            else if (this.dgTA.Rows[e.RowIndex].Cells["Approved"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.DimGray;
                e.CellStyle.SelectionBackColor = Color.Gray;
            }
            if ((this.dgTA.Rows[e.RowIndex].Cells["gatepass_type2"].Value.ToString() != "") && (this.dgTA.Rows[e.RowIndex].Cells["gatepass_type1"].Value.ToString() != ""))
            {
                string[] aField = new string[] { "gatepass_type1", "gatepass_type2" };
                string[] aFind = new string[] { this.dgTA.Rows[e.RowIndex].Cells["gatepass_type1"].Value.ToString(), this.dgTA.Rows[e.RowIndex].Cells["gatepass_type2"].Value.ToString() };
                this.tblGatepassType2.DR = this.tblGatepassType2.GetData(aField, aFind);
                if (this.tblGatepassType2.DR != null)
                {
                    this.dgTA.Rows[e.RowIndex].Cells["gatepass_type2"].Value = this.tblGatepassType2.DR["gatepass_typeName"].ToString();
                }
            }
            if (this.dgTA.Rows[e.RowIndex].Cells["gatepass_type1"].Value.ToString() != "")
            {
                string[] aField = new string[] { "gatepass_type", "gatepass_type1" };
                string[] aFind = new string[] { this.dgTA.Rows[e.RowIndex].Cells["gatepass_type"].Value.ToString(), this.dgTA.Rows[e.RowIndex].Cells["gatepass_type1"].Value.ToString() };
                this.tblGatepassType1.DR = this.tblGatepassType1.GetData(aField, aFind);
                if (this.tblGatepassType1.DR != null)
                {
                    this.dgTA.Rows[e.RowIndex].Cells["gatepass_type1"].Value = this.tblGatepassType1.DR["gatepass_typeName"].ToString();
                }
            }
        }

        private void DataReset()
        {
            string str = this.dgTA.SortOrder.ToString();
            DataGridViewColumn sortedColumn = this.dgTA.SortedColumn;
            this.tblVwGatepass.BeforeEdit(this.dgTA, "REFRESH");
            this.tblVwGatepass.ReOpen();
            this.tblVwGatepass.AfterEdit("REFRESH");
            ListSortDirection direction = (str != "Ascending") ? ListSortDirection.Descending : ListSortDirection.Ascending;
            this.dgTA.Sort(this.dgTA.Columns[sortedColumn.Name.ToString()], direction);
            this.dgTA.Refresh();
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WBTable table;
            WBTable table2;
            if (this.dgTA.Rows.Count <= 0)
            {
                return;
            }
            else if (this.dgTA.CurrentRow.Cells["Deleted"].Value.ToString() != "Y")
            {
                table = new WBTable();
                table.OpenTable("wb_gatepass", "Select * from wb_gatepass where " + WBData.CompanyLocation(" and uniq = '" + this.dgTA.CurrentRow.Cells["Uniq"].Value.ToString() + "'"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    goto TR_0002;
                }
                else
                {
                    table.DR = table.DT.Rows[0];
                    if ((this.dgTA.CurrentRow.Cells["TA_number"].Value.ToString().Trim() == "") || ((table.DR["Ref"].ToString() == "") || (table.DR["Ref"].ToString() == "")))
                    {
                        goto TR_0006;
                    }
                    else
                    {
                        table2 = new WBTable();
                        table2.OpenTable("wb_Trans", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + table.DR["Ref"].ToString() + "'"), WBData.conn);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            goto TR_0007;
                        }
                        else
                        {
                            table2.DR = table2.DT.Rows[0];
                            if (table2.DR["deleted"].ToString() != "Y")
                            {
                                MessageBox.Show(Resource.Mes_159 + " " + table.DR["Ref"].ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                table2.Dispose();
                            }
                            else
                            {
                                goto TR_0007;
                            }
                        }
                    }
                    return;
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_154, Resource.Title_002);
                return;
            }
            goto TR_0007;
        TR_0002:
            table.Dispose();
            return;
        TR_0006:
            if (MessageBox.Show(Resource.Mes_411 + " " + table.DR["TA_Number"].ToString(), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "Truck Arrival No" },
                    textRefNo = { Text = table.DR["TA_Number"].ToString() },
                    Text = "DELETE REASON",
                    label2 = { Text = "Delete Reason : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                    this.tblVwGatepass.BeforeEdit(this.dgTA, "DELETE");
                    this.logKey = table.DR["uniq"].ToString();
                    table.DR.BeginEdit();
                    table.DR["Deleted"] = "Y";
                    table.DR["Delete_By"] = WBUser.UserID;
                    table.DR["Delete_Date"] = DateTime.Now.ToString();
                    table.DR.EndEdit();
                    table.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                    Program.updateLogHeader("wb_gatepass", this.logKey, logField, logValue);
                    this.tblVwGatepass.ReOpen();
                    this.dgTA = this.tblVwGatepass.AfterEdit("DELETE");
                    this.dgTA.Refresh();
                    this.ShowStatus();
                }
                else
                {
                    return;
                }
            }
            goto TR_0002;
        TR_0007:
            table2.Dispose();
            goto TR_0006;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dgTA.Rows.Count > 0)
            {
                if (this.dgTA.CurrentRow.Cells["Deleted"].Value.ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mes_026, Resource.Title_002);
                }
                else if (this.dgTA.CurrentRow.Cells["Approved"].Value.ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mes_413, Resource.Title_002);
                }
                else
                {
                    FormTruckArrivalEntry entry = new FormTruckArrivalEntry {
                        pMode = "EDIT",
                        Text = "EDIT TRUCK ARRIVAL"
                    };
                    this.tblVwGatepass.BeforeEdit(this.dgTA, "EDIT");
                    entry.sUniq = this.dgTA.CurrentRow.Cells["Uniq"].Value.ToString();
                    entry.ShowDialog();
                    if (entry.saved)
                    {
                        this.tblVwGatepass.ReOpen();
                        this.dgTA = this.tblVwGatepass.AfterEdit(entry.pMode);
                        this.dgTA.Refresh();
                        this.ShowStatus();
                        string[] aField = new string[] { "TA_Number" };
                        string[] aFind = new string[] { entry.textTA_Number.Text };
                        this.tblVwGatepass.SetCursor(this.dgTA, this.tblVwGatepass.GetCurrentRow(this.dgTA, aField, aFind));
                    }
                    entry.Dispose();
                }
            }
        }

        private void f_load()
        {
            this.cField = " Coy, Location_code, Gatepass_number, TA_number, transaction_code, truck_number, trailer_number, license_no, transporter_code, In_Date, In_time, Gatepass_type, Gatepass_type1, Gatepass_type2  , Approved, ApproveName, Approve_by,ApproveCode, Deleted, uniq";
            string sqltext = "select " + this.cField + " from vw_gatepass_oth WHERE " + WBData.CompanyLocation(" AND (Reject = 'N') AND  ((TA_number is not null) OR (TA_number <> '')) AND  ((Approved = 'N') or (Approved is null)) AND  ((Submit_Gatepass IS NULL) or (Submit_Gatepass=''))  AND  ((Deleted = 'N') or (Deleted is null) or (Deleted =''))");
            this.tblVwGatepass.OpenTable("vw_gatepass_oth", sqltext, WBData.conn);
            this.dgTA.DataSource = this.tblVwGatepass.DV;
            this.dgTA.Sort(this.dgTA.Columns["TA_Number"], ListSortDirection.Descending);
            this.DataReset();
            this.ShowStatus();
            this.dgTA.Columns["Coy"].Visible = false;
            this.dgTA.Columns["Location_Code"].Visible = false;
            this.dgTA.Columns["Uniq"].Visible = false;
            this.dgTA.Columns["Deleted"].Visible = false;
            this.dgTA.Columns["Gatepass_number"].Visible = false;
            this.dgTA.Columns["Approved"].Visible = false;
            this.dgTA.Columns["Transaction_Code"].HeaderText = "Tx";
            this.dgTA.Columns["TA_Number"].HeaderText = Resource.Truck_002;
            this.dgTA.Columns["Truck_Number"].HeaderText = Resource.Truck_003;
            this.dgTA.Columns["In_Date"].HeaderText = Resource.Truck_004;
            this.dgTA.Columns["In_Time"].HeaderText = Resource.Truck_005;
            this.dgTA.Columns["Gatepass_Type"].HeaderText = Resource.Truck_006;
            this.dgTA.Columns["Gatepass_Type1"].HeaderText = Resource.Truck_007;
            this.dgTA.Columns["Gatepass_Type2"].HeaderText = Resource.Truck_008;
            this.dgTA.Columns["ApproveName"].HeaderText = Resource.Truck_009;
            this.dgTA.Columns["Approve_By"].HeaderText = Resource.Truck_010;
            this.dgTA.Columns["ApproveCode"].HeaderText = Resource.Truck_011;
            this.dateTimePicker1.Value = DateTime.Now.AddDays(-1.0);
            this.dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.dateTimePicker2.Value = DateTime.Now;
            this.dateTimePicker2.Format = DateTimePickerFormat.Short;
            base.KeyPreview = true;
        }

        private void FormTruckArrival_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTruckArrival_Load(object sender, EventArgs e)
        {
            this.translate();
            Cursor.Current = Cursors.WaitCursor;
            base.Opacity = 0.0;
            this.init_table();
            this.f_load();
            this.groupFilter.Enabled = false;
            base.Opacity = 100.0;
            Cursor.Current = Cursors.Default;
        }

        private void init_table()
        {
            this.tblTruck.OpenTable("wb_truck", "Select * from wb_truck where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblDriver.OpenTable("wb_driver", "Select * from wb_driver where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL) and (Deleted IS NULL OR Deleted <> 'Y') "), WBData.conn);
            this.tblTransporter.OpenTable("wb_transporter", "Select * from wb_transporter where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblTransType.OpenTable("wb_transaction_type", "Select * from wb_transaction_type", WBData.conn);
            this.tblTAApprove.OpenTable("Wb_TAApprove", "Select * from wb_tAApprove", WBData.conn);
            this.tblGatepassType1.OpenTable("wb_GatepassType1", "Select * from wb_GatepassType1 where 1=1", WBData.conn);
            this.tblGatepassType2.OpenTable("wb_GatepassType2", "Select * from wb_GatepassType2 where 1=1", WBData.conn);
            Program.AutoComp(this.tblTruck, "Truck_Number", this.textTruck);
            Program.AutoComp(this.tblDriver, "License_No", this.textDriver);
            Program.AutoComp(this.tblTransporter, "Transporter_Code", this.textTransporter);
            Program.AutoComp(this.tblTransType, "Transaction_code", this.textTransType);
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.dgTA = new DataGridView();
            this.lblDate = new Label();
            this.lblNow = new Label();
            this.timerSAPUpd = new Timer(this.components);
            this.serialPort1 = new SerialPort(this.components);
            this.timer1 = new Timer(this.components);
            this.backgroundWorker1 = new BackgroundWorker();
            this.label1 = new Label();
            this.tableLayoutPanel1 = new TableLayoutPanel();
            this.panel1 = new Panel();
            this.checkPartial = new CheckBox();
            this.groupFilter = new GroupBox();
            this.checkDeleted = new CheckBox();
            this.textDriver = new TextBox();
            this.checkApproved = new CheckBox();
            this.textTruck = new TextBox();
            this.textTransporter = new TextBox();
            this.dateTimePicker2 = new DateTimePicker();
            this.textTransType = new TextBox();
            this.dateTimePicker1 = new DateTimePicker();
            this.label6 = new Label();
            this.label3 = new Label();
            this.label5 = new Label();
            this.label4 = new Label();
            this.label9 = new Label();
            this.label7 = new Label();
            this.buttonFilter = new Button();
            this.labelStatus1 = new Label();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addToolStripMenuItem = new ToolStripMenuItem();
            this.viewToolStripMenuItem = new ToolStripMenuItem();
            this.editToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.approveToolStripMenuItem = new ToolStripMenuItem();
            this.backToolStripMenuItem = new ToolStripMenuItem();
            ((ISupportInitialize) this.dgTA).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupFilter.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.dgTA.AllowUserToAddRows = false;
            this.dgTA.AllowUserToDeleteRows = false;
            this.dgTA.AllowUserToResizeRows = false;
            this.dgTA.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgTA.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgTA.ColumnHeadersDefaultCellStyle = style;
            this.dgTA.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgTA.DefaultCellStyle = style2;
            this.dgTA.Dock = DockStyle.Fill;
            this.dgTA.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgTA.Location = new Point(3, 0x1b);
            this.dgTA.MultiSelect = false;
            this.dgTA.Name = "dgTA";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgTA.RowHeadersDefaultCellStyle = style3;
            this.dgTA.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgTA.Size = new Size(0x3fe, 0x193);
            this.dgTA.TabIndex = 0;
            this.dgTA.CellClick += new DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dgTA.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.lblDate.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lblDate.AutoSize = true;
            this.lblDate.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.lblDate.Location = new Point(0x4d9, 8);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new Size(0x25, 13);
            this.lblDate.TabIndex = 11;
            this.lblDate.Text = "progre";
            this.lblNow.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lblNow.AutoSize = true;
            this.lblNow.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.lblNow.Location = new Point(0x520, 8);
            this.lblNow.Name = "lblNow";
            this.lblNow.Size = new Size(0x31, 13);
            this.lblNow.TabIndex = 10;
            this.lblNow.Text = "00:00:00";
            this.lblNow.Visible = false;
            this.timerSAPUpd.Interval = 0x3e8;
            this.label1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = Color.FromArgb(0x80, 0x80, 0xff);
            this.label1.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.ForeColor = Color.White;
            this.label1.Location = new Point(0, 0);
            this.label1.Margin = new Padding(0);
            this.label1.Name = "label1";
            this.label1.RightToLeft = RightToLeft.Yes;
            this.label1.Size = new Size(0x404, 0x18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Truck Arival";
            this.label1.TextAlign = ContentAlignment.TopCenter;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel1.Controls.Add(this.dgTA, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Dock = DockStyle.Fill;
            this.tableLayoutPanel1.Location = new Point(0, 0x18);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 24f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 91.74312f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 136f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 8f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 8f));
            this.tableLayoutPanel1.Size = new Size(0x404, 0x249);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new PaintEventHandler(this.tableLayoutPanel1_Paint);
            this.panel1.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.panel1.Controls.Add(this.checkPartial);
            this.panel1.Controls.Add(this.groupFilter);
            this.panel1.Controls.Add(this.labelStatus1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.ForeColor = Color.Black;
            this.panel1.Location = new Point(0, 440);
            this.panel1.Margin = new Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x404, 0x81);
            this.panel1.TabIndex = 0;
            this.checkPartial.AutoSize = true;
            this.checkPartial.Checked = true;
            this.checkPartial.CheckState = CheckState.Checked;
            this.checkPartial.Location = new Point(0x3e5, 11);
            this.checkPartial.Name = "checkPartial";
            this.checkPartial.Size = new Size(0x37, 0x11);
            this.checkPartial.TabIndex = 0x12;
            this.checkPartial.Text = "&Partial";
            this.checkPartial.UseVisualStyleBackColor = true;
            this.checkPartial.CheckedChanged += new EventHandler(this.checkPartial_CheckedChanged);
            this.groupFilter.Controls.Add(this.checkDeleted);
            this.groupFilter.Controls.Add(this.textDriver);
            this.groupFilter.Controls.Add(this.checkApproved);
            this.groupFilter.Controls.Add(this.textTruck);
            this.groupFilter.Controls.Add(this.textTransporter);
            this.groupFilter.Controls.Add(this.dateTimePicker2);
            this.groupFilter.Controls.Add(this.textTransType);
            this.groupFilter.Controls.Add(this.dateTimePicker1);
            this.groupFilter.Controls.Add(this.label6);
            this.groupFilter.Controls.Add(this.label3);
            this.groupFilter.Controls.Add(this.label5);
            this.groupFilter.Controls.Add(this.label4);
            this.groupFilter.Controls.Add(this.label9);
            this.groupFilter.Controls.Add(this.label7);
            this.groupFilter.Controls.Add(this.buttonFilter);
            this.groupFilter.Location = new Point(0xf4, 5);
            this.groupFilter.Name = "groupFilter";
            this.groupFilter.Size = new Size(0x2eb, 0x71);
            this.groupFilter.TabIndex = 0x10;
            this.groupFilter.TabStop = false;
            this.groupFilter.Text = "Filter By";
            this.checkDeleted.AutoSize = true;
            this.checkDeleted.Location = new Point(0x171, 0x29);
            this.checkDeleted.Name = "checkDeleted";
            this.checkDeleted.Size = new Size(0x65, 0x11);
            this.checkDeleted.TabIndex = 0x23;
            this.checkDeleted.Text = "Include D&eleted";
            this.checkDeleted.UseVisualStyleBackColor = true;
            this.textDriver.CharacterCasing = CharacterCasing.Upper;
            this.textDriver.Location = new Point(0x183, 0x54);
            this.textDriver.MaxLength = 20;
            this.textDriver.Name = "textDriver";
            this.textDriver.Size = new Size(0x7b, 20);
            this.textDriver.TabIndex = 0x22;
            this.textDriver.KeyPress += new KeyPressEventHandler(this.textDriver_KeyPress);
            this.checkApproved.AutoSize = true;
            this.checkApproved.Location = new Point(0x171, 0x11);
            this.checkApproved.Name = "checkApproved";
            this.checkApproved.Size = new Size(110, 0x11);
            this.checkApproved.TabIndex = 0x11;
            this.checkApproved.Text = "&Include Approved";
            this.checkApproved.UseVisualStyleBackColor = true;
            this.textTruck.CharacterCasing = CharacterCasing.Upper;
            this.textTruck.Location = new Point(0x183, 0x3a);
            this.textTruck.MaxLength = 20;
            this.textTruck.Name = "textTruck";
            this.textTruck.Size = new Size(0x7b, 20);
            this.textTruck.TabIndex = 0x21;
            this.textTruck.KeyPress += new KeyPressEventHandler(this.textTruck_KeyPress);
            this.textTransporter.CharacterCasing = CharacterCasing.Upper;
            this.textTransporter.Location = new Point(0x8f, 0x54);
            this.textTransporter.MaxLength = 20;
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.Size = new Size(0x7b, 20);
            this.textTransporter.TabIndex = 0x20;
            this.textTransporter.KeyPress += new KeyPressEventHandler(this.textTransporter_KeyPress);
            this.dateTimePicker2.Format = DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new Point(0x109, 0x13);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new Size(0x62, 20);
            this.dateTimePicker2.TabIndex = 9;
            this.dateTimePicker2.ValueChanged += new EventHandler(this.dateTimePicker2_ValueChanged);
            this.textTransType.CharacterCasing = CharacterCasing.Upper;
            this.textTransType.Location = new Point(0x8f, 0x3a);
            this.textTransType.MaxLength = 20;
            this.textTransType.Name = "textTransType";
            this.textTransType.Size = new Size(0x7b, 20);
            this.textTransType.TabIndex = 0x1f;
            this.textTransType.KeyPress += new KeyPressEventHandler(this.textTransType_KeyPress);
            this.dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new Point(0x8f, 0x13);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new Size(0x5f, 20);
            this.dateTimePicker1.TabIndex = 8;
            this.label6.Location = new Point(270, 0x3d);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x70, 0x11);
            this.label6.TabIndex = 0x17;
            this.label6.Text = "Vehicle No.";
            this.label6.TextAlign = ContentAlignment.TopRight;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0xf3, 0x15);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x10, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "to";
            this.label5.Location = new Point(270, 0x57);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x6f, 0x11);
            this.label5.TabIndex = 0x16;
            this.label5.Text = "License No";
            this.label5.TextAlign = ContentAlignment.TopRight;
            this.label4.Location = new Point(0x18, 0x15);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x71, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Filter data from";
            this.label4.TextAlign = ContentAlignment.TopRight;
            this.label9.Location = new Point(6, 0x3d);
            this.label9.Name = "label9";
            this.label9.Size = new Size(130, 0x11);
            this.label9.TabIndex = 0x15;
            this.label9.Text = "Transaction Type";
            this.label9.TextAlign = ContentAlignment.TopRight;
            this.label7.Location = new Point(0x22, 0x57);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x65, 0x11);
            this.label7.TabIndex = 0x13;
            this.label7.Text = "Transporter";
            this.label7.TextAlign = ContentAlignment.TopRight;
            this.buttonFilter.Location = new Point(0x27a, 0x4a);
            this.buttonFilter.Name = "buttonFilter";
            this.buttonFilter.Size = new Size(0x5f, 30);
            this.buttonFilter.TabIndex = 4;
            this.buttonFilter.Text = "Filter";
            this.buttonFilter.UseVisualStyleBackColor = true;
            this.buttonFilter.Click += new EventHandler(this.buttonFilter_Click);
            this.labelStatus1.AutoSize = true;
            this.labelStatus1.Dock = DockStyle.Right;
            this.labelStatus1.Location = new Point(0x3e1, 0);
            this.labelStatus1.Name = "labelStatus1";
            this.labelStatus1.Size = new Size(0x23, 13);
            this.labelStatus1.TabIndex = 15;
            this.labelStatus1.Text = "label5";
            this.TextFind.CharacterCasing = CharacterCasing.Upper;
            this.TextFind.Location = new Point(3, 8);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 0;
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.buttonFind.Location = new Point(0xc1, 5);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x2d, 0x1b);
            this.buttonFind.TabIndex = 2;
            this.buttonFind.Text = "&Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.menuStrip1.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.menuStrip1.ImageScalingSize = new Size(20, 20);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.approveToolStripMenuItem, this.backToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x404, 0x18);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addToolStripMenuItem, this.viewToolStripMenuItem, this.editToolStripMenuItem, this.deleteToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "&Activities";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new Size(0x6b, 0x16);
            this.addToolStripMenuItem.Text = "&Add";
            this.addToolStripMenuItem.Click += new EventHandler(this.addToolStripMenuItem_Click);
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new Size(0x6b, 0x16);
            this.viewToolStripMenuItem.Text = "&View";
            this.viewToolStripMenuItem.Click += new EventHandler(this.viewToolStripMenuItem_Click);
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new Size(0x6b, 0x16);
            this.editToolStripMenuItem.Text = "&Edit";
            this.editToolStripMenuItem.Click += new EventHandler(this.editToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0x6b, 0x16);
            this.deleteToolStripMenuItem.Text = "&Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.approveToolStripMenuItem.Name = "approveToolStripMenuItem";
            this.approveToolStripMenuItem.Size = new Size(0x40, 20);
            this.approveToolStripMenuItem.Text = "A&pprove";
            this.approveToolStripMenuItem.Click += new EventHandler(this.approveToolStripMenuItem_Click);
            this.backToolStripMenuItem.Name = "backToolStripMenuItem";
            this.backToolStripMenuItem.Size = new Size(0x2c, 20);
            this.backToolStripMenuItem.Text = "&Back";
            this.backToolStripMenuItem.Click += new EventHandler(this.backToolStripMenuItem_Click_1);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x404, 0x261);
            base.ControlBox = false;
            base.Controls.Add(this.lblDate);
            base.Controls.Add(this.lblNow);
            base.Controls.Add(this.tableLayoutPanel1);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.Name = "FormTruckArrival";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Form Truck Arrival";
            base.Load += new EventHandler(this.FormTruckArrival_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTruckArrival_KeyPress);
            ((ISupportInitialize) this.dgTA).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupFilter.ResumeLayout(false);
            this.groupFilter.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void ShowStatus()
        {
            this.labelStatus1.Text = this.tblVwGatepass.DT.Rows.Count.ToString() + " " + Resource.Main_034;
            this.labelStatus1.Refresh();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void textDriver_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void textTransporter_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransType_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTruck_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.Text = Resource.Truck_001;
            this.label1.Text = Resource.Truck_001;
            this.buttonFind.Text = Resource.Truck_012;
            this.buttonFilter.Text = Resource.Truck_013;
            this.label4.Text = Resource.Truck_014;
            this.label3.Text = Resource.Truck_015;
            this.checkDeleted.Text = Resource.Truck_016;
            this.checkApproved.Text = Resource.Truck_017;
            this.checkPartial.Text = Resource.Truck_018;
            this.label9.Text = Resource.Truck_019;
            this.label6.Text = Resource.Truck_020;
            this.label7.Text = Resource.Truck_021;
            this.label5.Text = Resource.Truck_022;
            this.approveToolStripMenuItem.Text = Resource.Truck_023;
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.backToolStripMenuItem.Text = Resource.Menu_Back;
            this.addToolStripMenuItem.Text = Resource.Menu_Add;
            this.editToolStripMenuItem.Text = Resource.Menu_Edit;
            this.viewToolStripMenuItem.Text = Resource.Menu_View;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
        }

        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dgTA.Rows.Count > 0)
            {
                FormTruckArrivalEntry entry = new FormTruckArrivalEntry {
                    pMode = "VIEW",
                    Text = "VIEW TRUCK ARRIVAL",
                    sUniq = this.dgTA.CurrentRow.Cells["Uniq"].Value.ToString()
                };
                entry.ShowDialog();
                entry.Dispose();
            }
        }
    }
}

