﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormAutoSync : Form
    {
        public string[,] sapD;
        private string[] sapJamKirim;
        public static bool unShow;
        private string[] autoSyncValue;
        private MainForm main;
        public bool checkLogoutChangeProfile;
        private IContainer components = null;
        private Timer timer1;
        private BackgroundWorker backgroundWorkerSync;
        private Label lblSync;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem closeToolStripMenuItem;
        private Label label10;
        private Label label1;
        private Label lblDate;
        private Label lblNow;
        private TextBox statTxt;

        public FormAutoSync()
        {
            this.InitializeComponent();
        }

        private void backgroundWorkerSync_DoWork_1(object sender, DoWorkEventArgs e)
        {
            unShow = !base.Visible;
            if (this.statTxt.Lines.Length >= 0x3e8)
            {
                this.statTxt.Clear();
            }
            if ((WBSetting.cpuSAP == "Y") && (WBSetting.zwb == "Y"))
            {
                WBSync sync = new WBSync();
                sync.DoAutoSync("", "", unShow);
                if (sync.status != null)
                {
                    this.autoSyncValue = sync.status;
                    if (this.autoSyncValue != null)
                    {
                        foreach (string val in this.autoSyncValue)
                        {
                            if (this.statTxt.InvokeRequired)
                            {
                                this.statTxt.Invoke(delegate {
                                    string[] textArray1 = new string[] { "[", this.lblSync.Text, "] ", val, Environment.NewLine };
                                    this.statTxt.AppendText(string.Concat(textArray1));
                                });
                            }
                            else
                            {
                                string[] textArray1 = new string[] { "[", this.lblSync.Text, "] ", val, Environment.NewLine };
                                this.statTxt.AppendText(string.Concat(textArray1));
                            }
                        }
                    }
                }
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.f_close();
        }

        private void closeToolStripMenuItem_Click(object sender, FormClosedEventArgs e)
        {
            this.f_close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void f_close()
        {
            unShow = true;
            base.Visible = false;
            this.main = new MainForm();
            if (!this.checkLogoutChangeProfile)
            {
                this.main.Show();
            }
        }

        private void f_load()
        {
            int num = 0;
            DateTime now = DateTime.Now;
            this.lblDate.Text = now.ToString("dd/MM/yyyy");
            this.lblNow.Text = DateTime.Now.ToString("HH:mm:ss");
            if (Program.StrToDouble(WBSetting.AutoSyncInterval, 3) > 0.0)
            {
                num = Convert.ToInt16((double) (24.0 / Program.StrToDouble(WBSetting.AutoSyncInterval, 3)));
                string[] strArray = new string[num];
                int index = 0;
                while (true)
                {
                    if (index >= num)
                    {
                        this.sapJamKirim = strArray;
                        this.timer1.Enabled = true;
                        this.timer1.Interval = 0xea60;
                        foreach (string str in strArray)
                        {
                            if (Convert.ToDateTime(str) <= now)
                            {
                                this.lblSync.Text = Convert.ToDateTime(str).ToString("HH:mm:ss");
                            }
                        }
                        break;
                    }
                    DateTime time = Convert.ToDateTime(WBSetting.startTime).AddHours(index * Program.StrToDouble(WBSetting.AutoSyncInterval, 3));
                    strArray[index] = Convert.ToString(time);
                    index++;
                }
            }
            WBTable table = new WBTable();
            table.OpenTable("wb_auto_sync", "SELECT * FROM wb_auto_sync WHERE " + WBData.CompanyLocation(""), WBData.conn);
            this.sapD = new string[table.DT.Rows.Count, 2];
            if ((WBSetting.SAPsch != "Y") && (table.DT.Rows.Count <= 0))
            {
                base.Close();
            }
            else
            {
                this.timer1.Enabled = true;
                this.timer1.Interval = 0xea60;
                WBSync sync = new WBSync();
                sync.DoAutoSync("", "", unShow);
                if (sync.status != null)
                {
                    this.autoSyncValue = sync.f_loadStatus(sync.status);
                    if (this.autoSyncValue != null)
                    {
                        foreach (string str2 in this.autoSyncValue)
                        {
                            string[] textArray1 = new string[] { "[", this.lblSync.Text, "] ", str2, Environment.NewLine };
                            this.statTxt.AppendText(string.Concat(textArray1));
                        }
                    }
                }
            }
            table.Dispose();
        }

        private void FormAutoSync_Load(object sender, EventArgs e)
        {
            WBSetting.OpenSetting(true);
            this.f_load();
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.timer1 = new Timer(this.components);
            this.backgroundWorkerSync = new BackgroundWorker();
            this.lblSync = new Label();
            this.menuStrip1 = new MenuStrip();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.label10 = new Label();
            this.label1 = new Label();
            this.lblDate = new Label();
            this.lblNow = new Label();
            this.statTxt = new TextBox();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.timer1.Tick += new EventHandler(this.timer1_Tick);
            this.backgroundWorkerSync.DoWork += new DoWorkEventHandler(this.backgroundWorkerSync_DoWork_1);
            this.lblSync.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lblSync.AutoSize = true;
            this.lblSync.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.lblSync.Location = new Point(0x47, 0x2c);
            this.lblSync.Name = "lblSync";
            this.lblSync.Size = new Size(0x31, 13);
            this.lblSync.TabIndex = 5;
            this.lblSync.Text = "00:00:00";
            this.lblSync.Click += new EventHandler(this.lblNow_Click);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x16d, 0x18);
            this.menuStrip1.TabIndex = 0x10;
            this.menuStrip1.Text = "menuStrip1";
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.label10.Location = new Point(2, 0x29);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x3f, 0x13);
            this.label10.TabIndex = 0x33;
            this.label10.Text = "Last Sync";
            this.label10.TextAlign = ContentAlignment.MiddleLeft;
            this.label10.Click += new EventHandler(this.label10_Click);
            this.label1.Location = new Point(2, 0x18);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x21, 14);
            this.label1.TabIndex = 0x34;
            this.label1.Text = "Date";
            this.label1.TextAlign = ContentAlignment.MiddleLeft;
            this.label1.Click += new EventHandler(this.label1_Click);
            this.lblDate.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lblDate.AutoSize = true;
            this.lblDate.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.lblDate.Location = new Point(0x47, 0x19);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new Size(0x3d, 13);
            this.lblDate.TabIndex = 0x35;
            this.lblDate.Text = "dd-mm-yyyy";
            this.lblDate.Click += new EventHandler(this.label2_Click);
            this.lblNow.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.lblNow.AutoSize = true;
            this.lblNow.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            this.lblNow.Location = new Point(0x13c, 0xc3);
            this.lblNow.Name = "lblNow";
            this.lblNow.Size = new Size(0x31, 13);
            this.lblNow.TabIndex = 0x36;
            this.lblNow.Text = "00:00:00";
            this.statTxt.Location = new Point(8, 0x3f);
            this.statTxt.Multiline = true;
            this.statTxt.Name = "statTxt";
            this.statTxt.ReadOnly = true;
            this.statTxt.Size = new Size(0x15c, 0x81);
            this.statTxt.TabIndex = 0x37;
            this.statTxt.TextChanged += new EventHandler(this.textBox1_TextChanged);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x16d, 0xd0);
            base.ControlBox = false;
            base.Controls.Add(this.statTxt);
            base.Controls.Add(this.lblNow);
            base.Controls.Add(this.lblDate);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.lblSync);
            base.Name = "FormAutoSync";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Auto Sync";
            base.FormClosed += new FormClosedEventHandler(this.closeToolStripMenuItem_Click);
            base.Load += new EventHandler(this.FormAutoSync_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void label10_Click(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void lblNow_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void textTransporter_TextChanged(object sender, EventArgs e)
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.lblNow.Text = DateTime.Now.ToString("HH:mm:ss");
            if (WBSetting.SAPsch == "Y")
            {
                if (Convert.ToDateTime(this.lblNow.Text).ToString("HH:mm") == Convert.ToDateTime(WBSetting.SAPTime).ToString("HH:mm"))
                {
                    if (!this.backgroundWorkerSync.IsBusy)
                    {
                        this.lblSync.Text = Convert.ToDateTime(this.lblNow.Text).ToString("HH:mm:ss");
                        this.backgroundWorkerSync.RunWorkerAsync();
                    }
                }
                else if (Program.StrToDouble(WBSetting.AutoSyncInterval, 3) > 0.0)
                {
                    int index = 0;
                    while (true)
                    {
                        if (index >= this.sapJamKirim.Length)
                        {
                            break;
                        }
                        bool flag5 = Convert.ToDateTime(this.lblNow.Text).ToString("HH:mm") == Convert.ToDateTime(this.sapJamKirim[index]).ToString("HH:mm");
                        if (flag5 && !this.backgroundWorkerSync.IsBusy)
                        {
                            this.lblSync.Text = Convert.ToDateTime(this.lblNow.Text).ToString("HH:mm:ss");
                            this.backgroundWorkerSync.RunWorkerAsync();
                        }
                        index++;
                    }
                }
            }
        }
    }
}

