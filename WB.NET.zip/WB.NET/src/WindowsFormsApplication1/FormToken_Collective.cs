﻿namespace WindowsFormsApplication1
{
    using Encryption.Utility;
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Net;
    using System.Windows.Forms;

    public class FormToken_Collective : Form
    {
        private WBToken aToken = new WBToken();
        private WBTable tblToken = new WBTable();
        public string pmode = "";
        public string tblName = "";
        public string oldToken = "";
        public string oldCode = "";
        public string newCode = "";
        public bool saved = false;
        public bool close = false;
        public bool use3x = false;
        public string completed = "N";
        public string manualQty = "0";
        public string email_code = "";
        public string AllTrx = "";
        public string CommTol = "";
        public string DoNo = "";
        public string TokenParam2;
        public bool iserrorsendtoken = false;
        private int sendingSMSCount = 0;
        private int toleranceForSendingSMS = 5;
        private IContainer components = null;
        private Button buttonProcess;
        private Button button1;
        private Label label1;
        private Label label2;
        public TextBox textBoxToken;
        private TextBox textBoxPIN;
        private Label label3;
        private TextBox textMessage;
        private GroupBox groupBox1;
        private Label labelTo;
        private Label labelFrom;
        public DateTimePicker date2;
        public DateTimePicker date1;

        public FormToken_Collective()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.saved = false;
            base.Close();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            if ((Convert.ToDateTime(Convert.ToDateTime(this.date2.Value).ToShortDateString()) - Convert.ToDateTime(Convert.ToDateTime(this.date1.Value).ToShortDateString())).Days >= 0)
            {
                TimeSpan span = (TimeSpan) (Convert.ToDateTime(Convert.ToDateTime(this.date2.Value).ToShortDateString()) - Convert.ToDateTime(Convert.ToDateTime(this.date1.Value).ToShortDateString()));
                if (span.Days <= 30)
                {
                    DateTime now;
                    if ((this.textBoxPIN.Text.Trim() != "") || (this.buttonProcess.Text.ToUpper() == "PROCESS"))
                    {
                        if (((this.textBoxPIN.Text.Trim() != "") || (this.buttonProcess.Text.ToUpper() != "PROCESS")) ? (this.textBoxPIN.Text != "") : true)
                        {
                            if (this.textBoxPIN.Text != "")
                            {
                                this.tblToken.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(" AND token_code = 'EDIT_COLLECTIVE' AND completed='Y'"), WBData.conn);
                                DateTime time7 = Convert.ToDateTime(Convert.ToDateTime(this.date1.Value).ToShortDateString());
                                now = Convert.ToDateTime(this.date2.Value);
                                DateTime time8 = Convert.ToDateTime(now.ToShortDateString());
                                using (IEnumerator enumerator2 = this.tblToken.DT.Rows.GetEnumerator())
                                {
                                    while (true)
                                    {
                                        if (!enumerator2.MoveNext())
                                        {
                                            break;
                                        }
                                        DataRow current = (DataRow) enumerator2.Current;
                                        DateTime time9 = Convert.ToDateTime(Convert.ToDateTime(current["key_1"].ToString()).ToShortDateString());
                                        DateTime time10 = Convert.ToDateTime(Convert.ToDateTime(current["key_2"].ToString()).ToShortDateString());
                                        DateTime time11 = Convert.ToDateTime(Convert.ToDateTime(current["datetime1"].ToString()).ToShortDateString()).AddDays(7.0);
                                        if (((time7 < time9) || (time7 > time10)) ? ((time8 >= time9) && (time8 <= time10)) : true)
                                        {
                                            now = DateTime.Now;
                                            if ((time11 - Convert.ToDateTime(now.ToShortDateString())).Days >= 0)
                                            {
                                                string[] textArray3 = new string[11];
                                                textArray3[0] = "Range of Date is invalid because previous token (";
                                                textArray3[1] = current["token_no"].ToString();
                                                textArray3[2] = ") has already been used to edit WB DOs and transactions from ";
                                                textArray3[3] = current["key_1"].ToString();
                                                textArray3[4] = " to ";
                                                textArray3[5] = current["key_2"].ToString();
                                                textArray3[6] = "!\n\nPlease ensure chosen range of date doesn't include in date between ";
                                                textArray3[7] = current["key_1"].ToString();
                                                textArray3[8] = " and ";
                                                textArray3[9] = current["key_2"].ToString();
                                                textArray3[10] = "!";
                                                MessageBox.Show(string.Concat(textArray3), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                return;
                                            }
                                        }
                                    }
                                }
                                string aToken = this.textBoxToken.Text.Trim();
                                if (this.textBoxPIN.Text.Trim() != this.aToken.generateV2PIN(aToken, this.pmode).Trim())
                                {
                                    MessageBox.Show("PIN is rejected!", "FAIL", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                else
                                {
                                    this.saved = true;
                                    this.completed = "Y";
                                    this.tblToken.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(" AND token_no = '" + aToken + "'"), WBData.conn);
                                    if (this.tblToken.DT.Rows.Count > 0)
                                    {
                                        this.tblToken.DR = this.tblToken.DT.Rows[0];
                                        this.tblToken.DR.BeginEdit();
                                        this.tblToken.DR["completed"] = "Y";
                                        this.tblToken.DR["Datetime1"] = DateTime.Now;
                                        this.tblToken.DR.EndEdit();
                                        this.tblToken.Save();
                                    }
                                    else
                                    {
                                        this.tblToken.DR = this.tblToken.DT.NewRow();
                                        this.tblToken.DR["coy"] = WBData.sCoyCode;
                                        this.tblToken.DR["location_code"] = WBData.sLocCode;
                                        this.tblToken.DR["key_1"] = this.date1.Value.ToShortDateString();
                                        this.tblToken.DR["key_2"] = this.date2.Value.ToShortDateString();
                                        this.tblToken.DR["token_code"] = this.pmode;
                                        this.tblToken.DR["token_no"] = this.textBoxToken.Text;
                                        this.tblToken.DR["completed"] = "Y";
                                        this.tblToken.DR["Datetime1"] = DateTime.Now;
                                        this.tblToken.DT.Rows.Add(this.tblToken.DR);
                                        this.tblToken.Save();
                                    }
                                    MessageBox.Show("PIN is accepted!", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    base.Close();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please fill in PIN!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                this.textMessage.Focus();
                            }
                        }
                    }
                    else
                    {
                        this.tblToken.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(" AND token_code = 'EDIT_COLLECTIVE' AND completed = 'Y'"), WBData.conn);
                        DateTime time2 = Convert.ToDateTime(Convert.ToDateTime(this.date1.Value).ToShortDateString());
                        now = Convert.ToDateTime(this.date2.Value);
                        DateTime time3 = Convert.ToDateTime(now.ToShortDateString());
                        using (IEnumerator enumerator = this.tblToken.DT.Rows.GetEnumerator())
                        {
                            while (true)
                            {
                                if (!enumerator.MoveNext())
                                {
                                    break;
                                }
                                DataRow current = (DataRow) enumerator.Current;
                                DateTime time4 = Convert.ToDateTime(Convert.ToDateTime(current["key_1"].ToString()).ToShortDateString());
                                DateTime time5 = Convert.ToDateTime(Convert.ToDateTime(current["key_2"].ToString()).ToShortDateString());
                                DateTime time6 = Convert.ToDateTime(Convert.ToDateTime(current["datetime1"].ToString()).ToShortDateString()).AddDays(7.0);
                                if (((time2 < time4) || (time2 > time5)) ? ((time3 >= time4) && (time3 <= time5)) : true)
                                {
                                    now = DateTime.Now;
                                    if ((time6 - Convert.ToDateTime(now.ToShortDateString())).Days >= 0)
                                    {
                                        string[] textArray1 = new string[11];
                                        textArray1[0] = "Range of date is invalid because previous token (";
                                        textArray1[1] = current["token_no"].ToString();
                                        textArray1[2] = ") has already been used to edit WB DOs and transactions from ";
                                        textArray1[3] = current["key_1"].ToString();
                                        textArray1[4] = " to ";
                                        textArray1[5] = current["key_2"].ToString();
                                        textArray1[6] = "!\n\nPlease ensure chosen range of date doesn't include in date between ";
                                        textArray1[7] = current["key_1"].ToString();
                                        textArray1[8] = " and ";
                                        textArray1[9] = current["key_2"].ToString();
                                        textArray1[10] = "!";
                                        MessageBox.Show(string.Concat(textArray1), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        return;
                                    }
                                }
                            }
                        }
                        if (this.textMessage.Text == "")
                        {
                            MessageBox.Show("Please fill in message!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.textMessage.Focus();
                        }
                        else
                        {
                            string[] textArray2 = new string[] { "Do you want to use this token to edit WB DOs and transactions created from ", this.date1.Value.ToShortDateString(), " to ", this.date2.Value.ToShortDateString(), "?" };
                            if (MessageBox.Show(string.Concat(textArray2), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.saved = true;
                                this.completed = "N";
                                this.tblToken.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(" AND token_no = '" + this.textBoxToken.Text.Trim() + "'"), WBData.conn);
                                if (this.tblToken.DT.Rows.Count == 0)
                                {
                                    this.tblToken.DR = this.tblToken.DT.NewRow();
                                    this.tblToken.DR["coy"] = WBData.sCoyCode;
                                    this.tblToken.DR["location_code"] = WBData.sLocCode;
                                    this.tblToken.DR["key_1"] = this.date1.Value.ToShortDateString();
                                    this.tblToken.DR["key_2"] = this.date2.Value.ToShortDateString();
                                    this.tblToken.DR["token_code"] = this.pmode;
                                    this.tblToken.DR["token_no"] = this.textBoxToken.Text;
                                    this.tblToken.DR["completed"] = "N";
                                    this.tblToken.DT.Rows.Add(this.tblToken.DR);
                                    this.tblToken.Save();
                                }
                                if (WBSetting.activeSMSToken)
                                {
                                    this.sendHTTPRequest(this.textBoxToken.Text.Trim(), WBUser.UserID, this.textMessage.Text.Trim());
                                }
                                else
                                {
                                    this.sendEmailToken(this.email_code);
                                }
                                if (!this.iserrorsendtoken)
                                {
                                    base.Close();
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Range of date must be smaller or equals to 30 days!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                MessageBox.Show("Date 'To' must be greater dan date 'From'!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private string firstLetterToUpper(string reason)
        {
            string str = reason.ToLower();
            return ((str.Length <= 1) ? str : (char.ToUpper(str[0]).ToString() + str.Substring(1)));
        }

        private void FormToken_Collective_Load(object sender, EventArgs e)
        {
            this.email_code = "TOKEN_EDITQTY";
            this.pmode = "EDIT_COLLECTIVE";
            this.tblToken.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(" AND token_code = 'EDIT_COLLECTIVE' AND completed = 'N' ORDER BY UNIQ DESC"), WBData.conn);
            if (this.tblToken.DT.Rows.Count > 0)
            {
                this.textBoxToken.Text = this.tblToken.DT.Rows[0]["token_no"].ToString();
                this.date1.Value = Convert.ToDateTime(this.tblToken.DT.Rows[0]["key_1"].ToString());
                this.date2.Value = Convert.ToDateTime(this.tblToken.DT.Rows[0]["key_2"].ToString());
                this.date1.Enabled = false;
                this.date2.Enabled = false;
            }
            else
            {
                string[] parameters = new string[] { "0" };
                this.textBoxToken.Text = this.aToken.generateToken(parameters, this.pmode, "", "").Trim();
                this.date1.Enabled = true;
                this.date2.Enabled = true;
            }
            this.setForm();
        }

        private void InitializeComponent()
        {
            this.buttonProcess = new Button();
            this.button1 = new Button();
            this.textBoxToken = new TextBox();
            this.label1 = new Label();
            this.label2 = new Label();
            this.textBoxPIN = new TextBox();
            this.label3 = new Label();
            this.textMessage = new TextBox();
            this.groupBox1 = new GroupBox();
            this.date2 = new DateTimePicker();
            this.date1 = new DateTimePicker();
            this.labelTo = new Label();
            this.labelFrom = new Label();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.buttonProcess.Location = new Point(0x6a, 0x10d);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(0x5d, 0x2b);
            this.buttonProcess.TabIndex = 0;
            this.buttonProcess.Text = "&Request for PIN";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.button1.Location = new Point(0x100, 0x10d);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x5d, 0x2b);
            this.button1.TabIndex = 1;
            this.button1.Text = "&Cancel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBoxToken.BackColor = SystemColors.Window;
            this.textBoxToken.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textBoxToken.HideSelection = false;
            this.textBoxToken.Location = new Point(0x6a, 12);
            this.textBoxToken.Name = "textBoxToken";
            this.textBoxToken.ReadOnly = true;
            this.textBoxToken.Size = new Size(290, 0x1f);
            this.textBoxToken.TabIndex = 2;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x22, 0x18);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x42, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Token Code";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x22, 0x92);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x35, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "PIN Code";
            this.textBoxPIN.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textBoxPIN.Location = new Point(0x67, 0x86);
            this.textBoxPIN.MaxLength = 15;
            this.textBoxPIN.Name = "textBoxPIN";
            this.textBoxPIN.Size = new Size(290, 0x1f);
            this.textBoxPIN.TabIndex = 5;
            this.textBoxPIN.TextChanged += new EventHandler(this.textBoxPIN_TextChanged);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x22, 0xb9);
            this.label3.Name = "label3";
            this.label3.Size = new Size(50, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Message";
            this.textMessage.Location = new Point(0x67, 0xb6);
            this.textMessage.MaxLength = 250;
            this.textMessage.Multiline = true;
            this.textMessage.Name = "textMessage";
            this.textMessage.Size = new Size(290, 0x49);
            this.textMessage.TabIndex = 12;
            this.groupBox1.Controls.Add(this.date2);
            this.groupBox1.Controls.Add(this.date1);
            this.groupBox1.Controls.Add(this.labelTo);
            this.groupBox1.Controls.Add(this.labelFrom);
            this.groupBox1.Location = new Point(0x25, 0x3d);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x164, 0x3b);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Range of Date";
            this.date2.Format = DateTimePickerFormat.Short;
            this.date2.Location = new Point(0xdf, 0x19);
            this.date2.Name = "date2";
            this.date2.Size = new Size(0x69, 20);
            this.date2.TabIndex = 12;
            this.date1.Format = DateTimePickerFormat.Short;
            this.date1.Location = new Point(0x39, 0x19);
            this.date1.Name = "date1";
            this.date1.Size = new Size(0x69, 20);
            this.date1.TabIndex = 11;
            this.labelTo.AutoSize = true;
            this.labelTo.Location = new Point(0xc5, 0x1d);
            this.labelTo.Name = "labelTo";
            this.labelTo.Size = new Size(20, 13);
            this.labelTo.TabIndex = 10;
            this.labelTo.Text = "To";
            this.labelFrom.AutoSize = true;
            this.labelFrom.Location = new Point(0x13, 0x1d);
            this.labelFrom.Name = "labelFrom";
            this.labelFrom.Size = new Size(30, 13);
            this.labelFrom.TabIndex = 9;
            this.labelFrom.Text = "From";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1b5, 330);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.textMessage);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textBoxPIN);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.textBoxToken);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.buttonProcess);
            base.KeyPreview = true;
            base.Name = "FormToken_Collective";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Token to Edit Multiple Contracts & Transactions";
            base.Load += new EventHandler(this.FormToken_Collective_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void sendEmailToken(string email_code)
        {
            WBMail mail = new WBMail();
            string str = "";
            string str2 = "";
            if (this.tblName.Length > 3)
            {
                str2 = this.tblName.Substring(3, this.tblName.Length - 3).ToUpper();
            }
            DateTime time = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd"));
            string[] textArray1 = new string[] { (("Dear Sir/Madam, <br><br>PIN HAS BEEN REQUESTED<br><br><a href='http://token.wilmar.co.id:8080/generate/?t=" + this.textBoxToken.Text.Trim() + "'>Click here to directly go to Web Token </a><br><br><table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name")) + "</tr><tr class='bd'><td nowrap>Request Date Time</td><td nowrap> : " + Convert.ToDateTime(DateTime.Now.ToString("hh:mm:ss")), "</tr><tr class='bd'><td nowrap>Requested By</td><td nowrap> : ", WBUser.UserID, " - ", WBUser.UserName, "</tr><tr class='bd'><td nowrap>Token No</td><td nowrap> : ", this.textBoxToken.Text.Trim() };
            string[] textArray2 = new string[10];
            textArray2[0] = string.Concat(textArray1);
            textArray2[1] = "</tr><tr class='bd'><td nowrap>Menu</td><td nowrap> : EDIT MULTIPLE WB DOs & TRANSACTIONS </td></tr><tr class='bd'><td nowrap>Menu Description</td><td nowrap> : This token is used to edit WB DOs created from ";
            textArray2[2] = this.date1.Value.ToShortDateString();
            textArray2[3] = " to ";
            textArray2[4] = this.date2.Value.ToShortDateString();
            textArray2[5] = " and edit transactions created from ";
            textArray2[6] = this.date1.Value.ToShortDateString();
            textArray2[7] = " to ";
            textArray2[8] = this.date2.Value.ToShortDateString();
            textArray2[9] = "</td></tr>";
            str = string.Concat(textArray2);
            if (this.textMessage.Text != "")
            {
                int index = 0;
                while (true)
                {
                    if (index >= this.textMessage.Lines.Length)
                    {
                        break;
                    }
                    if (index == 0)
                    {
                        str = str + "<tr class='bd'><td nowrap>Reason for Requesting Token</td><td nowrap> : " + this.textMessage.Lines[index] + "</td></tr>";
                    }
                    else if (index != 1)
                    {
                        str = str + "<tr><td nowrap>&nbsp;&nbsp;" + this.textMessage.Lines[index] + "</td></tr>";
                    }
                    else
                    {
                        object[] objArray1 = new object[] { str, "<tr><td rowspan=", this.textMessage.Lines.Length - 1, " nowrap></td><td nowrap>&nbsp;&nbsp;", this.textMessage.Lines[index], "</td></tr>" };
                        str = string.Concat(objArray1);
                    }
                    index++;
                }
            }
            str = str + "</table><br><br>Thank You. ";
            WBTable table = new WBTable();
            table.OpenTable("wb_email_master", "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND ( Email_Code ='" + email_code + "')"), WBData.conn);
            int num2 = 0;
            while (true)
            {
                if (num2 >= table.DT.Rows.Count)
                {
                    mail.Body = str;
                    try
                    {
                        mail.SendMail();
                    }
                    catch
                    {
                        this.iserrorsendtoken = true;
                        MessageBox.Show("Fail sending email!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    return;
                }
                DataRow row = table.DT.Rows[num2];
                string[] textArray3 = new string[] { row[0].ToString().Trim(), " ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
                mail.Subject = string.Concat(textArray3);
                mail.To = row[1].ToString().Trim();
                mail.CC = row[2].ToString().Trim();
                num2++;
            }
        }

        private bool sendHTTPRequest(string token_, string user_, string reason_)
        {
            string str3;
            string message;
            bool flag4;
            bool flag = true;
            bool flag2 = false;
            string str = WBSetting.token_path;
            if (str != "")
            {
                string[] textArray1 = new string[8];
                textArray1[0] = "tkn=";
                textArray1[1] = token_;
                textArray1[2] = "&user=";
                textArray1[3] = user_;
                textArray1[4] = "&user_name=";
                textArray1[5] = (WBUser.UserName.Length > 10) ? WBUser.UserName.Substring(0, 10).Trim() : WBUser.UserName.Trim();
                string[] local1 = textArray1;
                local1[6] = "&rmk=";
                local1[7] = reason_;
                string str2 = WBEncryption.Encrypt(string.Concat(local1));
                str3 = str + "?p=" + str2;
                message = "";
            }
            else
            {
                MessageBox.Show("Failed sending token: \n Token Path Not Found, please contact MIS HO", "FAILED SENDING TOKEN", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return false;
            }
            while (true)
            {
                if (!(flag && (this.sendingSMSCount < this.toleranceForSendingSMS)))
                {
                    if (this.sendingSMSCount >= this.toleranceForSendingSMS)
                    {
                        this.iserrorsendtoken = true;
                        string[] textArray3 = new string[] { "Failed sending token: \n", message, "\n\nPlease inform token ", token_, " to PIC manually to get PIN." };
                        MessageBox.Show(string.Concat(textArray3), "FAILED SENDING TOKEN", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    flag4 = flag2;
                    break;
                }
                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    using (WebClient client = new WebClient())
                    {
                        string[] separator = new string[] { "<!DOCTYPE" };
                        char[] chArray1 = new char[] { '|' };
                        string[] strArray2 = Convert.ToString(client.DownloadString(str3)).Split(separator, StringSplitOptions.None)[0].Trim().Split(chArray1);
                        if (strArray2[0].ToUpper().Trim() == "OK")
                        {
                            MessageBox.Show("Token " + token_ + " has been sent successfully!\n\n" + strArray2[1].Trim(), "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            flag2 = true;
                            flag = false;
                        }
                        else
                        {
                            message = this.firstLetterToUpper(strArray2[0].Trim().Replace("*", "").Replace(".", "").Trim());
                            flag2 = false;
                            flag = true;
                            this.sendingSMSCount++;
                        }
                    }
                    Cursor.Current = Cursors.Default;
                }
                catch (Exception exception)
                {
                    this.iserrorsendtoken = true;
                    flag2 = false;
                    flag = true;
                    this.sendingSMSCount++;
                    message = exception.Message;
                }
            }
            return flag4;
        }

        private void setForm()
        {
            if (this.textBoxPIN.Text != "")
            {
                this.buttonProcess.Text = "Process";
                this.textMessage.Text = "";
                this.textMessage.ReadOnly = true;
                this.textMessage.Enabled = false;
            }
            else if (this.date1.Enabled && this.date2.Enabled)
            {
                this.buttonProcess.Text = "Request for PIN";
                this.textMessage.ReadOnly = false;
                this.textMessage.Enabled = true;
            }
            else
            {
                this.buttonProcess.Text = "Process";
                this.textMessage.Text = "";
                this.textMessage.ReadOnly = true;
                this.textMessage.Enabled = false;
            }
        }

        private void textBoxPIN_TextChanged(object sender, EventArgs e)
        {
            this.setForm();
        }
    }
}

