﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Text.RegularExpressions;
    using System.Windows.Forms;

    public class FormUserEntry : Form
    {
        public string pMode;
        public string pMode2;
        public string changeReason = "";
        public string logKey = "";
        public string OldPassword = "";
        public WBTable zTable;
        public int nCurrRow;
        public bool saved;
        private IContainer components = null;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox textUser_ID;
        private TextBox textUser_Name;
        private TextBox textUser_Pass1;
        private TextBox textUser_Pass2;
        private Label label6;
        private ComboBox comboUser_Level;
        private Label label7;
        private Label label8;
        private Label label9;
        private ComboBox comboUser_Group;
        private Button button1;
        private Button button2;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;

        public FormUserEntry()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TextBox[] aText = new TextBox[] { this.textUser_ID, this.textUser_Name };
            if (!Program.CheckEmpty(aText))
            {
                if (this.checkPassComplexity(this.textUser_Pass1.Text))
                {
                    if ((this.OldPassword != this.textUser_Pass1.Text) || ((this.pMode != "EDIT") || (this.pMode2 != "CHANGE_FROM_DEFAULT")))
                    {
                        if (this.textUser_Pass1.Text.Trim() == this.textUser_Pass2.Text.Trim())
                        {
                            if (this.textUser_Pass1.Text.Trim().Length >= 8)
                            {
                                if (this.pMode != "ADD")
                                {
                                    if (this.pMode2 != "CHANGE_FROM_DEFAULT")
                                    {
                                        if (this.pMode2 == "RESET")
                                        {
                                            this.changeReason = "Reset password for security purpose";
                                            goto TR_0047;
                                        }
                                        else
                                        {
                                            FormTransCancel cancel = new FormTransCancel {
                                                label1 = { Text = "User ID" },
                                                textRefNo = { Text = this.zTable.DR["User_ID"].ToString() },
                                                Text = "CHANGE REASON",
                                                label2 = { Text = "Change Reason : " }
                                            };
                                            cancel.textReason.Focus();
                                            cancel.ShowDialog();
                                            if (cancel.Saved)
                                            {
                                                this.changeReason = cancel.textReason.Text;
                                                cancel.Dispose();
                                                goto TR_0047;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        this.changeReason = "Change password from default generated password";
                                        goto TR_0047;
                                    }
                                    return;
                                }
                                else
                                {
                                    WBTable table = new WBTable();
                                    table.OpenTable("wb_user", "Select * from wb_user where user_id = '" + this.textUser_ID.Text.Trim() + "'", WBData.conn);
                                    if (table.DT.Rows.Count != 0)
                                    {
                                        if ((table.DT.Rows[0]["deleted"].ToString() == "Y") || (table.DT.Rows[0]["deleted"].ToString() == "*"))
                                        {
                                            MessageBox.Show(Resource.Mes_460a, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                            this.textUser_ID.Focus();
                                        }
                                        else
                                        {
                                            MessageBox.Show(Resource.Mes_460, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                            base.Close();
                                        }
                                        return;
                                    }
                                    else
                                    {
                                        this.zTable.DR = this.zTable.DT.NewRow();
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_459, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                this.textUser_Pass1.Focus();
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_458, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.textUser_Pass1.Focus();
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Update Your Password", "W A R N I N G....");
                        this.textUser_Pass1.Focus();
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Password Complexity is too Simple, Please Change Password Complexity..", "W A R N I N G....");
                    this.textUser_Pass1.Focus();
                    return;
                }
            }
            else
            {
                return;
            }
        TR_003F:
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["User_id"] = this.textUser_ID.Text;
            this.zTable.DR["User_name"] = this.textUser_Name.Text;
            this.zTable.DR["User_pass"] = Program.shoot(this.textUser_Pass1.Text.Trim(), true);
            this.zTable.DR["User_Level"] = this.comboUser_Level.Text;
            this.zTable.DR["User_Group"] = this.comboUser_Group.Text;
            this.zTable.DR["ChangeReason"] = this.changeReason;
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DR["Checksum"] = this.zTable.Checksum(this.zTable.DR);
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR["Checksum"] = this.zTable.Checksum(this.zTable.DR);
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if (((this.pMode == "ADD") || (this.pMode == "EDIT")) || (this.pMode == "PASS"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_user", "SELECT uniq FROM wb_user WHERE " + WBData.CompanyLocation(" AND user_ID = '" + this.textUser_ID.Text + "'"), WBData.conn);
                    this.logKey = table2.DT.Rows[0]["uniq"].ToString();
                    table2.Dispose();
                }
                string pMode = this.pMode;
                if (this.pMode == "PASS")
                {
                    pMode = "EDIT";
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_user", this.logKey, logField, logValue);
            }
            string str = "";
            if (this.pMode == "ADD")
            {
                str = "Add";
            }
            else if (this.pMode == "EDIT")
            {
                str = "Edit";
            }
            else if (this.pMode == "PASS")
            {
                str = "Change Password of";
            }
            if (((this.pMode != "EDIT") || (this.pMode2 != "CHANGE_FROM_DEFAULT")) ? (this.pMode == "PASS") : true)
            {
                WBTable table3 = new WBTable();
                table3.OpenTable("wb_user", "SELECT * from wb_user WHERE User_Id = '" + this.textUser_ID.Text + "'", WBData.conn);
                foreach (DataRow row in table3.DT.Rows)
                {
                    row.BeginEdit();
                    row["User_pass"] = Program.shoot(this.textUser_Pass1.Text.Trim(), true);
                    row["require_change_pass"] = "N";
                    row["ChangeReason"] = this.changeReason;
                    row["Change_By"] = WBUser.UserID;
                    row["Change_Date"] = DateTime.Now;
                    row["Checksum"] = table3.Checksum(row);
                    row.EndEdit();
                    table3.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, this.changeReason };
                    Program.updateLogHeader("wb_user", row["uniq"].ToString(), logField, logValue);
                }
                table3.Dispose();
            }
            else if (this.pMode != "EDIT")
            {
                if (this.pMode == "ADD")
                {
                    bool flag1;
                    WBTable table6 = new WBTable();
                    table6.OpenTable("wb_location", "SELECT COUNT(uniq) AS n FROM wb_location WHERE 1=1", WBData.conn);
                    int num = Convert.ToInt16(table6.DT.Rows[0]["n"].ToString());
                    table6.Dispose();
                    if (num <= 1)
                    {
                        flag1 = false;
                    }
                    else
                    {
                        string[] textArray9 = new string[] { "Do you want to ", str.ToLower(), " user ", this.textUser_ID.Text, " (", this.textUser_Name.Text, ") in other locations?" };
                        flag1 = MessageBox.Show(string.Concat(textArray9), "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
                    }
                    if (flag1)
                    {
                        FormCopyUserAutho autho = new FormCopyUserAutho {
                            pMode = this.pMode,
                            userID = this.textUser_ID.Text,
                            userGroup = this.comboUser_Group.Text,
                            userPass = Program.shoot(this.textUser_Pass1.Text.Trim(), true),
                            userLevel = this.comboUser_Level.Text,
                            userName = this.textUser_Name.Text,
                            changeReason = this.changeReason,
                            table = "user",
                            Text = str + " User in Other Locations"
                        };
                        string[] textArray10 = new string[] { str, " user ", this.textUser_ID.Text, " (", this.textUser_Name.Text.Trim(), ") in locations:" };
                        autho.label1.Text = string.Concat(textArray10);
                        autho.ShowDialog();
                        if (autho.saved)
                        {
                        }
                        autho.Dispose();
                    }
                }
            }
            else
            {
                WBTable table4 = new WBTable();
                table4.OpenTable("wb_user", "SELECT * from wb_user WHERE coy is not null and location_code is not null and User_Id = '" + this.textUser_ID.Text + "'", WBData.conn);
                foreach (DataRow row2 in table4.DT.Rows)
                {
                    row2.BeginEdit();
                    row2["User_Name"] = this.textUser_Name.Text;
                    row2["User_Level"] = this.comboUser_Level.Text;
                    row2["User_group"] = this.comboUser_Group.Text;
                    row2["Change_By"] = WBUser.UserID;
                    row2["Change_Date"] = DateTime.Now;
                    row2["ChangeReason"] = this.changeReason;
                    row2["Checksum"] = table4.Checksum(row2);
                    row2.EndEdit();
                    table4.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, this.changeReason };
                    Program.updateLogHeader("wb_user", row2["uniq"].ToString(), logField, logValue);
                }
                table4.Dispose();
                WBTable table5 = new WBTable();
                table5.OpenTable("wb_user", "SELECT * from wb_user WHERE coy is null and location_code is null and User_Id = '" + this.textUser_ID.Text + "'", WBData.conn);
                foreach (DataRow row3 in table5.DT.Rows)
                {
                    row3.BeginEdit();
                    row3["User_Name"] = this.textUser_Name.Text;
                    row3["Change_By"] = WBUser.UserID;
                    row3["Change_Date"] = DateTime.Now;
                    row3["ChangeReason"] = this.changeReason;
                    row3["Checksum"] = table5.Checksum(row3);
                    row3.EndEdit();
                    table5.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, this.changeReason };
                    Program.updateLogHeader("wb_user", row3["uniq"].ToString(), logField, logValue);
                }
                table5.Dispose();
            }
            this.saved = true;
            base.Close();
            return;
        TR_0047:
            this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
            this.logKey = this.zTable.DR["uniq"].ToString();
            this.zTable.DR.BeginEdit();
            goto TR_003F;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        public bool checkPass_IsDefault(string userid)
        {
            bool flag = false;
            WBTable table = new WBTable();
            table.OpenTable("wb_user", "select * from wb_user where user_id = '" + userid + "'", WBData.conn);
            int num = 0;
            while (true)
            {
                if (num < table.DT.Rows.Count)
                {
                    string str = table.DT.Rows[num]["require_change_pass"].ToString();
                    if (str != "Y")
                    {
                        flag = false;
                        num++;
                        continue;
                    }
                    flag = true;
                }
                table.Dispose();
                return flag;
            }
        }

        public bool checkPassComplexity(string pass)
        {
            bool flag3;
            int count = 0;
            if (pass.Trim().Length < 8)
            {
                flag3 = false;
            }
            else
            {
                count = Regex.Matches(pass.Trim(), "[A-Z]").Count;
                if ((Regex.Matches(pass.Trim(), "[a-z]").Count <= 0) && (count <= 0))
                {
                    flag3 = false;
                }
                else
                {
                    count = 0;
                    flag3 = Regex.Matches(pass.Trim(), "[0-9]").Count > 0;
                }
            }
            return flag3;
        }

        private void comboUser_Group_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = '\0';
        }

        private void comboUser_Level_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = '\0';
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormUserEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormUserEntry_Load(object sender, EventArgs e)
        {
            this.translate();
            WBTable table = new WBTable();
            if (Convert.ToInt16(WBUser.UserLevel) >= 3)
            {
                table.OpenTable("wb_group", "Select * From wb_group where " + WBData.CompanyLocation(" and  code <> 'ADMIN' and Code <> 'MGR' and Code <> 'APPROVAL'"), WBData.conn);
            }
            else if (Convert.ToInt16(WBUser.UserLevel) == 2)
            {
                table.OpenTable("wb_group", "Select * From wb_group where " + WBData.CompanyLocation(" and  code <> 'ADMIN'"), WBData.conn);
            }
            else if (Convert.ToInt16(WBUser.UserLevel) == 1)
            {
                table.OpenTable("wb_group", "Select * From wb_group ", WBData.conn);
            }
            this.comboUser_Group.Items.Clear();
            foreach (DataRow row in table.DT.Rows)
            {
                this.comboUser_Group.Items.Add(row["code"].ToString());
            }
            this.comboUser_Level.Items.Clear();
            int num = Convert.ToInt16(WBUser.UserLevel);
            while (true)
            {
                if (num > 3)
                {
                    table.Dispose();
                    this.saved = false;
                    this.label10.Hide();
                    this.button1.Text = "&Save";
                    if (this.pMode == "ADD")
                    {
                        this.textUser_ID.Text = "";
                        this.textUser_Name.Text = "";
                        this.textUser_Pass1.Text = "";
                        this.textUser_Pass2.Text = "";
                        this.comboUser_Level.Text = "3";
                        this.comboUser_Group.Text = "OPR";
                    }
                    else
                    {
                        this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                        this.textUser_ID.Text = this.zTable.DR["User_id"].ToString();
                        this.textUser_Name.Text = this.zTable.DR["User_Name"].ToString();
                        this.textUser_Pass1.Text = Program.shoot(this.zTable.DR["User_pass"].ToString(), false);
                        this.textUser_Pass2.Text = Program.shoot(this.zTable.DR["User_pass"].ToString(), false);
                        this.comboUser_Level.Text = this.zTable.DR["User_Level"].ToString();
                        this.comboUser_Group.Text = this.zTable.DR["User_Group"].ToString();
                        this.OldPassword = Program.shoot(this.zTable.DR["User_pass"].ToString(), false);
                        if (this.pMode == "DELETE")
                        {
                            this.label10.Show();
                            this.button1.Text = "&Yes";
                            this.textUser_ID.ReadOnly = true;
                            this.textUser_Name.ReadOnly = true;
                            this.textUser_Pass1.ReadOnly = true;
                            this.textUser_Pass2.ReadOnly = true;
                            this.comboUser_Level.Enabled = false;
                            this.comboUser_Group.Enabled = false;
                        }
                    }
                    this.textUser_ID.ReadOnly = true;
                    this.textUser_Name.ReadOnly = true;
                    this.textUser_Pass1.ReadOnly = true;
                    this.textUser_Pass2.ReadOnly = true;
                    this.comboUser_Level.Enabled = false;
                    this.comboUser_Group.Enabled = false;
                    if (this.pMode == "EDIT")
                    {
                        if ((WBUser.UserLevel == "1") || WBUser.CheckTrustee("USERLIST", "D"))
                        {
                            this.textUser_Name.ReadOnly = false;
                            this.textUser_Pass1.ReadOnly = false;
                            this.textUser_Pass2.ReadOnly = false;
                            this.comboUser_Level.Enabled = true;
                            this.comboUser_Group.Enabled = true;
                        }
                        this.textUser_Pass1.ReadOnly = false;
                        this.textUser_Pass2.ReadOnly = false;
                    }
                    if ((this.pMode == "PASS") || ((this.pMode == "EDIT") && (this.pMode2 == "CHANGE_FROM_DEFAULT")))
                    {
                        this.textUser_Pass1.ReadOnly = false;
                        this.textUser_Pass2.ReadOnly = false;
                    }
                    if (this.pMode == "ADD")
                    {
                        this.textUser_ID.ReadOnly = false;
                        this.textUser_Name.ReadOnly = false;
                        this.textUser_Pass1.ReadOnly = false;
                        this.textUser_Pass2.ReadOnly = false;
                        this.comboUser_Level.Enabled = true;
                        this.comboUser_Group.Enabled = true;
                        if ((WBUser.UserLevel == "1") || WBUser.CheckTrustee("USERLIST", "D"))
                        {
                            this.textUser_ID.ReadOnly = false;
                            this.textUser_Name.ReadOnly = false;
                            this.textUser_Pass1.ReadOnly = false;
                            this.textUser_Pass2.ReadOnly = false;
                            this.comboUser_Level.Enabled = true;
                            this.comboUser_Group.Enabled = true;
                        }
                    }
                    if ((this.pMode2 == "RESET") || (this.pMode2 == "CHANGE_FROM_DEFAULT"))
                    {
                        foreach (Control control in base.Controls)
                        {
                            if ((control.GetType() == typeof(TextBox)) || (control.GetType() == typeof(ComboBox)))
                            {
                                control.Enabled = false;
                            }
                            if ((control.Name.ToString() == "textUser_Pass1") || (control.Name.ToString() == "textUser_Pass2"))
                            {
                                control.Enabled = true;
                            }
                        }
                    }
                    break;
                }
                this.comboUser_Level.Items.Add(num.ToString());
                num++;
            }
            base.KeyPreview = true;
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.label4 = new Label();
            this.label5 = new Label();
            this.textUser_ID = new TextBox();
            this.textUser_Name = new TextBox();
            this.textUser_Pass1 = new TextBox();
            this.textUser_Pass2 = new TextBox();
            this.label6 = new Label();
            this.comboUser_Level = new ComboBox();
            this.label7 = new Label();
            this.label8 = new Label();
            this.label9 = new Label();
            this.comboUser_Group = new ComboBox();
            this.button1 = new Button();
            this.button2 = new Button();
            this.label10 = new Label();
            this.label11 = new Label();
            this.label12 = new Label();
            this.label13 = new Label();
            base.SuspendLayout();
            this.label1.Location = new Point(12, 14);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x8a, 0x11);
            this.label1.TabIndex = 0;
            this.label1.Text = "User ID";
            this.label1.TextAlign = ContentAlignment.TopRight;
            this.label2.Location = new Point(15, 0x2d);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x87, 0x11);
            this.label2.TabIndex = 1;
            this.label2.Text = "User Name";
            this.label2.TextAlign = ContentAlignment.TopRight;
            this.label3.Location = new Point(15, 0x4b);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x87, 0x11);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password";
            this.label3.TextAlign = ContentAlignment.TopRight;
            this.label4.Location = new Point(15, 0x68);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x87, 0x11);
            this.label4.TabIndex = 3;
            this.label4.Text = "Retype Password";
            this.label4.TextAlign = ContentAlignment.TopRight;
            this.label5.Location = new Point(0x12, 260);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x84, 0x15);
            this.label5.TabIndex = 4;
            this.label5.Text = "User Group";
            this.label5.TextAlign = ContentAlignment.TopRight;
            this.textUser_ID.CharacterCasing = CharacterCasing.Upper;
            this.textUser_ID.Location = new Point(0x9c, 11);
            this.textUser_ID.Name = "textUser_ID";
            this.textUser_ID.Size = new Size(100, 20);
            this.textUser_ID.TabIndex = 5;
            this.textUser_Name.Location = new Point(0x9c, 0x2a);
            this.textUser_Name.Name = "textUser_Name";
            this.textUser_Name.Size = new Size(0x108, 20);
            this.textUser_Name.TabIndex = 6;
            this.textUser_Pass1.Location = new Point(0x9c, 0x48);
            this.textUser_Pass1.Name = "textUser_Pass1";
            this.textUser_Pass1.Size = new Size(0xa8, 20);
            this.textUser_Pass1.TabIndex = 7;
            this.textUser_Pass1.UseSystemPasswordChar = true;
            this.textUser_Pass2.Location = new Point(0x9c, 0x65);
            this.textUser_Pass2.Name = "textUser_Pass2";
            this.textUser_Pass2.Size = new Size(0xa8, 20);
            this.textUser_Pass2.TabIndex = 8;
            this.textUser_Pass2.UseSystemPasswordChar = true;
            this.label6.Location = new Point(15, 0xc3);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x87, 0x12);
            this.label6.TabIndex = 9;
            this.label6.Text = "User Level";
            this.label6.TextAlign = ContentAlignment.TopRight;
            this.comboUser_Level.FormattingEnabled = true;
            object[] items = new object[] { "1", "2", "3" };
            this.comboUser_Level.Items.AddRange(items);
            this.comboUser_Level.Location = new Point(0x9c, 0xc0);
            this.comboUser_Level.Name = "comboUser_Level";
            this.comboUser_Level.Size = new Size(50, 0x15);
            this.comboUser_Level.TabIndex = 10;
            this.comboUser_Level.KeyPress += new KeyPressEventHandler(this.comboUser_Level_KeyPress);
            this.label7.AutoSize = true;
            this.label7.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label7.Location = new Point(0xd4, 0xc0);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x67, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "1  = As Administrator";
            this.label8.AutoSize = true;
            this.label8.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label8.Location = new Point(0xd4, 0xd1);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x55, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "2  = As Manager";
            this.label9.AutoSize = true;
            this.label9.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label9.Location = new Point(0xd4, 0xe2);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x79, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "3  = As User Entry Level";
            this.comboUser_Group.FormattingEnabled = true;
            this.comboUser_Group.Location = new Point(0x9c, 260);
            this.comboUser_Group.Name = "comboUser_Group";
            this.comboUser_Group.Size = new Size(100, 0x15);
            this.comboUser_Group.TabIndex = 14;
            this.comboUser_Group.KeyPress += new KeyPressEventHandler(this.comboUser_Group_KeyPress);
            this.button1.Location = new Point(0xef, 0x147);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x20);
            this.button1.TabIndex = 15;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0x14f, 0x147);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x20);
            this.button2.TabIndex = 0x10;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.label10.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label10.ForeColor = Color.Red;
            this.label10.Location = new Point(12, 0x12b);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x19b, 0x12);
            this.label10.TabIndex = 0x11;
            this.label10.Text = "This data will be deleted, are you sure ?";
            this.label10.TextAlign = ContentAlignment.TopRight;
            this.label11.AutoSize = true;
            this.label11.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label11.Location = new Point(0x99, 0x7c);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0xc0, 13);
            this.label11.TabIndex = 0x12;
            this.label11.Text = "1. Password Min. Length is 8 Character";
            this.label12.AutoSize = true;
            this.label12.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label12.Location = new Point(0x99, 140);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0xb7, 13);
            this.label12.TabIndex = 0x13;
            this.label12.Text = "2. Combination of Alphabet && Number";
            this.label13.AutoSize = true;
            this.label13.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label13.Location = new Point(0x99, 0x9d);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0xb0, 13);
            this.label13.TabIndex = 20;
            this.label13.Text = "3. Minimum 1 Character && 1 Number";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1c3, 0x185);
            base.ControlBox = false;
            base.Controls.Add(this.label13);
            base.Controls.Add(this.label12);
            base.Controls.Add(this.label11);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.comboUser_Group);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.comboUser_Level);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.textUser_Pass2);
            base.Controls.Add(this.textUser_Pass1);
            base.Controls.Add(this.textUser_Name);
            base.Controls.Add(this.textUser_ID);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Name = "FormUserEntry";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Entry User List";
            base.Load += new EventHandler(this.FormUserEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormUserEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label1.Text = Resource.User_002;
            this.label2.Text = Resource.User_003;
            this.label5.Text = Resource.User_004;
            this.label6.Text = Resource.User_005;
            this.label3.Text = Resource.User_006;
            this.label4.Text = Resource.User_007;
            this.label7.Text = Resource.User_008;
            this.label8.Text = Resource.User_009;
            this.label9.Text = Resource.User_010;
            this.button1.Text = Resource.Save;
            this.button2.Text = Resource.Menu_Cancel;
        }
    }
}

