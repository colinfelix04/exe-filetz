﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormSplitBatch : Form
    {
        public DataGridView DGVsplitbatch;
        public string cCoy;
        public string cLocation;
        public string cRef;
        public bool lAdopted;
        public bool lApproved;
        public int PerBagQty;
        private IContainer components = null;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox textDLNo;
        private TextBox textItem;
        private TextBox textBatch;
        private TextBox textGunny;
        private TextBox textQty;
        private TextBox textSQty;
        private TextBox textSGunny;
        private TextBox textSBatch;
        private TextBox textSItem;
        private Label label10;
        private Label label11;
        private StatusStrip statusStrip1;
        private Button button1;
        private Button button2;
        private GroupBox groupBox1;
        private TextBox textBatchSTO;
        private TextBox textSTO;
        private Label label13;
        private Label label12;
        private Label label14;
        private Label label15;
        private TextBox textSTO2;
        private TextBox textBatchSTO2;

        public FormSplitBatch()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num = Convert.ToInt32(this.textGunny.Text) - Convert.ToInt32(this.textSGunny.Text);
            int num2 = Convert.ToInt32(this.textQty.Text) - Convert.ToInt32(this.textSQty.Text);
            if (num <= 0)
            {
                MessageBox.Show("Not Enough Quantity or Gunny");
            }
            else
            {
                this.textQty.Text = num2.ToString();
                this.textGunny.Text = num.ToString();
                string str = this.DGVsplitbatch.Rows[0].Cells["SO_No"].Value.ToString();
                this.DGVsplitbatch.Rows[0].Cells["Batch"].Value = this.textBatch.Text;
                this.DGVsplitbatch.Rows[0].Cells["Num_Of_Gunny"].Value = this.textGunny.Text;
                this.DGVsplitbatch.Rows[0].Cells["Netto"].Value = this.textQty.Text;
                this.DGVsplitbatch.Rows[0].Cells["STO_Batch"].Value = this.textBatchSTO.Text;
                this.DGVsplitbatch.Rows.Add();
                int num3 = this.DGVsplitbatch.Rows.Count - 1;
                this.DGVsplitbatch.Rows[num3].Cells["Coy"].Value = this.cCoy;
                this.DGVsplitbatch.Rows[num3].Cells["Location_Code"].Value = this.cLocation;
                this.DGVsplitbatch.Rows[num3].Cells["Ref"].Value = this.cRef;
                this.DGVsplitbatch.Rows[num3].Cells["SO_No"].Value = str;
                this.DGVsplitbatch.Rows[num3].Cells["DO_No"].Value = this.textDLNo.Text;
                this.DGVsplitbatch.Rows[num3].Cells["Item_No"].Value = this.textSItem.Text;
                this.DGVsplitbatch.Rows[num3].Cells["Batch"].Value = this.textSBatch.Text;
                this.DGVsplitbatch.Rows[num3].Cells["STO_No"].Value = this.textSTO2.Text;
                this.DGVsplitbatch.Rows[num3].Cells["STO_Batch"].Value = this.textBatchSTO2.Text;
                this.DGVsplitbatch.Rows[num3].Cells["Num_Of_Gunny"].Value = this.textSGunny.Text;
                this.DGVsplitbatch.Rows[num3].Cells["Netto"].Value = this.textSQty.Text;
                this.DGVsplitbatch.Rows[num3].Cells["Adopted"].Value = this.lAdopted ? "Y" : "N";
                this.DGVsplitbatch.Rows[num3].Cells["Approved"].Value = this.lApproved ? "Y" : "N";
                base.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormSplitBatch_Load(object sender, EventArgs e)
        {
            this.cCoy = this.DGVsplitbatch.Rows[0].Cells["Coy"].Value.ToString();
            this.cLocation = this.DGVsplitbatch.Rows[0].Cells["Location_Code"].Value.ToString();
            this.cRef = this.DGVsplitbatch.Rows[0].Cells["Ref"].Value.ToString();
            this.textDLNo.Text = this.DGVsplitbatch.Rows[0].Cells["DO_No"].Value.ToString();
            this.textItem.Text = this.DGVsplitbatch.Rows[0].Cells["Item_No"].Value.ToString();
            this.textBatch.Text = this.DGVsplitbatch.Rows[0].Cells["Batch"].Value.ToString();
            this.textSTO.Text = this.DGVsplitbatch.Rows[0].Cells["STO_No"].Value.ToString();
            this.textBatchSTO.Text = this.DGVsplitbatch.Rows[0].Cells["STO_Batch"].Value.ToString();
            this.textSTO2.Text = this.DGVsplitbatch.Rows[0].Cells["STO_No"].Value.ToString();
            this.textSItem.Text = this.DGVsplitbatch.Rows[0].Cells["Item_No"].Value.ToString();
            this.textSBatch.Text = this.DGVsplitbatch.Rows[0].Cells["Batch"].Value.ToString();
            this.textGunny.Text = this.DGVsplitbatch.Rows[0].Cells["Num_Of_Gunny"].Value.ToString();
            this.textQty.Text = this.DGVsplitbatch.Rows[0].Cells["Netto"].Value.ToString();
            this.lAdopted = this.DGVsplitbatch.Rows[0].Cells["Adopted"].Value.ToString() == "Y";
            this.lApproved = this.DGVsplitbatch.Rows[0].Cells["Approved"].Value.ToString() == "Y";
            this.textBatchSTO.ReadOnly = this.textBatchSTO.Text.Trim() != "";
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.label4 = new Label();
            this.label5 = new Label();
            this.label6 = new Label();
            this.label7 = new Label();
            this.label8 = new Label();
            this.label9 = new Label();
            this.textDLNo = new TextBox();
            this.textItem = new TextBox();
            this.textBatch = new TextBox();
            this.textGunny = new TextBox();
            this.textQty = new TextBox();
            this.textSQty = new TextBox();
            this.textSGunny = new TextBox();
            this.textSBatch = new TextBox();
            this.textSItem = new TextBox();
            this.label10 = new Label();
            this.label11 = new Label();
            this.statusStrip1 = new StatusStrip();
            this.button1 = new Button();
            this.button2 = new Button();
            this.groupBox1 = new GroupBox();
            this.label12 = new Label();
            this.label13 = new Label();
            this.textSTO = new TextBox();
            this.textBatchSTO = new TextBox();
            this.label14 = new Label();
            this.label15 = new Label();
            this.textSTO2 = new TextBox();
            this.textBatchSTO2 = new TextBox();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Location = new Point(8, 0x2c);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x2c, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Item No";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(8, 0x43);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x23, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Batch";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(8, 0x85);
            this.label3.Name = "label3";
            this.label3.Size = new Size(70, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "No. of Gunny";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(8, 0x9b);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x2e, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Quantity";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(8, 0x16);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x5f, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Delivery Letter No.";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(20, 340);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x2e, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Quantity";
            this.label7.AutoSize = true;
            this.label7.Location = new Point(20, 0x13e);
            this.label7.Name = "label7";
            this.label7.Size = new Size(70, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "No. of Gunny";
            this.label8.AutoSize = true;
            this.label8.Location = new Point(20, 0xf9);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x23, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Batch";
            this.label9.AutoSize = true;
            this.label9.Location = new Point(20, 0xe2);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x2c, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Item No";
            this.textDLNo.Location = new Point(0x7a, 0x13);
            this.textDLNo.Name = "textDLNo";
            this.textDLNo.ReadOnly = true;
            this.textDLNo.Size = new Size(0x73, 20);
            this.textDLNo.TabIndex = 9;
            this.textItem.Location = new Point(0x7a, 0x29);
            this.textItem.Name = "textItem";
            this.textItem.ReadOnly = true;
            this.textItem.Size = new Size(0x73, 20);
            this.textItem.TabIndex = 10;
            this.textBatch.Location = new Point(0x7a, 0x40);
            this.textBatch.Name = "textBatch";
            this.textBatch.ReadOnly = true;
            this.textBatch.Size = new Size(0x73, 20);
            this.textBatch.TabIndex = 11;
            this.textGunny.Location = new Point(0x7a, 130);
            this.textGunny.Name = "textGunny";
            this.textGunny.ReadOnly = true;
            this.textGunny.Size = new Size(0x73, 20);
            this.textGunny.TabIndex = 12;
            this.textGunny.Text = "0";
            this.textGunny.TextAlign = HorizontalAlignment.Right;
            this.textQty.Location = new Point(0x7a, 0x98);
            this.textQty.Name = "textQty";
            this.textQty.ReadOnly = true;
            this.textQty.Size = new Size(0x73, 20);
            this.textQty.TabIndex = 13;
            this.textQty.Text = "0";
            this.textQty.TextAlign = HorizontalAlignment.Right;
            this.textSQty.Location = new Point(0x86, 0x151);
            this.textSQty.Name = "textSQty";
            this.textSQty.Size = new Size(0x73, 20);
            this.textSQty.TabIndex = 0x11;
            this.textSQty.Text = "0";
            this.textSQty.TextAlign = HorizontalAlignment.Right;
            this.textSQty.TextChanged += new EventHandler(this.textSQty_TextChanged);
            this.textSQty.Leave += new EventHandler(this.textSQty_Leave);
            this.textSGunny.Location = new Point(0x86, 0x13a);
            this.textSGunny.Name = "textSGunny";
            this.textSGunny.Size = new Size(0x73, 20);
            this.textSGunny.TabIndex = 0x10;
            this.textSGunny.Text = "0";
            this.textSGunny.TextAlign = HorizontalAlignment.Right;
            this.textSGunny.TextChanged += new EventHandler(this.textSGunny_TextChanged);
            this.textSGunny.Leave += new EventHandler(this.textSGunny_Leave);
            this.textSBatch.Location = new Point(0x86, 0xf5);
            this.textSBatch.Name = "textSBatch";
            this.textSBatch.ReadOnly = true;
            this.textSBatch.Size = new Size(0x73, 20);
            this.textSBatch.TabIndex = 15;
            this.textSItem.Location = new Point(0x86, 0xdf);
            this.textSItem.Name = "textSItem";
            this.textSItem.ReadOnly = true;
            this.textSItem.Size = new Size(0x73, 20);
            this.textSItem.TabIndex = 14;
            this.textSItem.Leave += new EventHandler(this.textSItem_Leave);
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0xf3, 0x9b);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x19, 13);
            this.label10.TabIndex = 0x13;
            this.label10.Text = "KG.";
            this.label11.AutoSize = true;
            this.label11.Location = new Point(0xff, 340);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x19, 13);
            this.label11.TabIndex = 20;
            this.label11.Text = "KG.";
            this.statusStrip1.Location = new Point(0, 0x184);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(0x1da, 0x16);
            this.statusStrip1.TabIndex = 0x15;
            this.statusStrip1.Text = "statusStrip1";
            this.button1.Location = new Point(0x142, 0xdd);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 0x16;
            this.button1.Text = "Split";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0x142, 250);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 0x17;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.groupBox1.Controls.Add(this.textBatchSTO);
            this.groupBox1.Controls.Add(this.textSTO);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.textDLNo);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textItem);
            this.groupBox1.Controls.Add(this.textBatch);
            this.groupBox1.Controls.Add(this.textGunny);
            this.groupBox1.Controls.Add(this.textQty);
            this.groupBox1.Location = new Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x19f, 0xbc);
            this.groupBox1.TabIndex = 0x18;
            this.groupBox1.TabStop = false;
            this.label12.AutoSize = true;
            this.label12.Location = new Point(8, 0x59);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x1d, 13);
            this.label12.TabIndex = 20;
            this.label12.Text = "STO";
            this.label13.AutoSize = true;
            this.label13.Location = new Point(8, 0x6f);
            this.label13.Name = "label13";
            this.label13.Size = new Size(60, 13);
            this.label13.TabIndex = 0x15;
            this.label13.Text = "Batch STO";
            this.textSTO.Location = new Point(0x7a, 0x56);
            this.textSTO.Name = "textSTO";
            this.textSTO.ReadOnly = true;
            this.textSTO.Size = new Size(0x73, 20);
            this.textSTO.TabIndex = 0x16;
            this.textBatchSTO.Location = new Point(0x7a, 0x6c);
            this.textBatchSTO.Name = "textBatchSTO";
            this.textBatchSTO.Size = new Size(0x73, 20);
            this.textBatchSTO.TabIndex = 0x17;
            this.label14.AutoSize = true;
            this.label14.Location = new Point(20, 0x10f);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x1d, 13);
            this.label14.TabIndex = 0x19;
            this.label14.Text = "STO";
            this.label15.AutoSize = true;
            this.label15.Location = new Point(20, 0x126);
            this.label15.Name = "label15";
            this.label15.Size = new Size(60, 13);
            this.label15.TabIndex = 0x1a;
            this.label15.Text = "Batch STO";
            this.textSTO2.Location = new Point(0x86, 0x10c);
            this.textSTO2.Name = "textSTO2";
            this.textSTO2.ReadOnly = true;
            this.textSTO2.Size = new Size(0x73, 20);
            this.textSTO2.TabIndex = 0x1b;
            this.textBatchSTO2.Location = new Point(0x86, 0x123);
            this.textBatchSTO2.Name = "textBatchSTO2";
            this.textBatchSTO2.Size = new Size(0x73, 20);
            this.textBatchSTO2.TabIndex = 0x1c;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1da, 410);
            base.Controls.Add(this.textBatchSTO2);
            base.Controls.Add(this.textSTO2);
            base.Controls.Add(this.label15);
            base.Controls.Add(this.label14);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.statusStrip1);
            base.Controls.Add(this.label11);
            base.Controls.Add(this.textSQty);
            base.Controls.Add(this.textSGunny);
            base.Controls.Add(this.textSBatch);
            base.Controls.Add(this.textSItem);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label9);
            base.FormBorderStyle = FormBorderStyle.Fixed3D;
            base.Name = "FormSplitBatch";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Split Batch Info";
            base.Load += new EventHandler(this.FormSplitBatch_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textSGunny_Leave(object sender, EventArgs e)
        {
            if ((this.textSGunny.Text == "") || (this.textSGunny.Text == "0"))
            {
                this.textSQty.ReadOnly = false;
            }
            else
            {
                try
                {
                    int num = Convert.ToInt32(this.textSGunny.Text.Trim());
                    this.textSQty.Text = Convert.ToString((int) (num * this.PerBagQty));
                }
                catch
                {
                    MessageBox.Show("Invalid Entry..");
                    this.textSGunny.Text = "0";
                    this.textSGunny.Focus();
                }
                this.textSGunny.ReadOnly = false;
            }
        }

        private void textSGunny_TextChanged(object sender, EventArgs e)
        {
            this.textSQty.ReadOnly = true;
        }

        private void textSItem_Leave(object sender, EventArgs e)
        {
            if (this.textSItem.Text != "")
            {
                try
                {
                    int num = Convert.ToInt32(this.textSItem.Text.Trim());
                    this.textSItem.Text = num.ToString().PadLeft(6, '0');
                }
                catch
                {
                    MessageBox.Show("Invalid Entry");
                    this.textSItem.Focus();
                }
            }
        }

        private void textSQty_Leave(object sender, EventArgs e)
        {
            if ((this.textSQty.Text == "") || (this.textSQty.Text == "0"))
            {
                this.textSGunny.ReadOnly = false;
            }
            else
            {
                try
                {
                    int num = Convert.ToInt32(this.textSQty.Text.Trim());
                    this.textSGunny.Text = Convert.ToString((int) (num / this.PerBagQty));
                }
                catch
                {
                    MessageBox.Show("Invalid Entry..");
                    this.textSQty.Text = "0";
                    this.textSQty.Focus();
                }
                this.textSQty.ReadOnly = false;
            }
        }

        private void textSQty_TextChanged(object sender, EventArgs e)
        {
            this.textSGunny.ReadOnly = true;
        }
    }
}

