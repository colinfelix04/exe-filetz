﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormLocationTimbun : Form
    {
        public WBTable ztable = new WBTable();
        public string pMode;
        public string pCoy;
        public int nCurrRow;
        public DataRow ReturnRow;
        private IContainer components = null;
        public ToolStripMenuItem closeToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem1;
        public MenuStrip menuStrip1;
        private DataGridView dataGridView1;

        public FormLocationTimbun()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.toolStripMenuItem1.PerformClick();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormLocationTimbun_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormLocationTimbun_Load(object sender, EventArgs e)
        {
            string sqltext = "SELECT * FROM wb_location_timbun where 1=1";
            this.ztable.OpenTable("wb_location_timbun", sqltext, WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["timbun_code"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["Uniq"].Visible = false;
            this.dataGridView1.Columns["timbun_code"].HeaderText = Resource.Col_Timbun_Code;
            this.dataGridView1.Columns["Coy_timbun"].HeaderText = Resource.Col_Owner_Code;
            this.dataGridView1.Columns["location_timbun"].HeaderText = Resource.Col_Timbun_Location_Code;
            this.dataGridView1.Columns["Description"].HeaderText = Resource.Composite_007;
            this.dataGridView1.Columns["Relation_code"].HeaderText = Resource.Col_Owner_Batch;
            base.KeyPreview = true;
        }

        private void InitializeComponent()
        {
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripMenuItem();
            this.menuStrip1 = new MenuStrip();
            this.dataGridView1 = new DataGridView();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            base.SuspendLayout();
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0x3b, 20);
            this.toolStripMenuItem1.Text = "Choose";
            this.toolStripMenuItem1.Click += new EventHandler(this.toolStripMenuItem1_Click);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.toolStripMenuItem1, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x29c, 0x18);
            this.menuStrip1.TabIndex = 0x1a;
            this.menuStrip1.Text = "menuStrip1";
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x29c, 0x10b);
            this.dataGridView1.TabIndex = 0x1c;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x29c, 0x123);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.Name = "FormLocationTimbun";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "formt";
            base.Load += new EventHandler(this.FormLocationTimbun_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormLocationTimbun_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void translate()
        {
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.toolStripMenuItem1.Text = Resource.Menu_Choose;
            this.Text = Resource.Title_Location_Timbun;
        }
    }
}

