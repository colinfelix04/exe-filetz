﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormSourceMapping : Form
    {
        public string pMode = "";
        public string logKey = "";
        public string changeReason = "";
        public string reason = "";
        public string table = "";
        public bool saved;
        public string userID = "";
        public string userGroup = "";
        public string userPass = "";
        public string userLevel = "";
        public string userName = "";
        public string group = "";
        public string groupName = "";
        public string oldGroup = "";
        private IContainer components = null;
        private DataGridView dgvDest;
        private DataGridViewTextBoxColumn coy_;
        private DataGridViewTextBoxColumn loc_;
        private DataGridViewCheckBoxColumn Selected;
        private DataGridViewTextBoxColumn remark;
        private Button buttonProcess;
        private Button buttonCancel;

        public FormSourceMapping()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            WBTable table = new WBTable();
            int num = 2;
            while (true)
            {
                if (num >= this.dgvDest.ColumnCount)
                {
                    table.Dispose();
                    Cursor.Current = Cursors.Default;
                    MessageBox.Show(Resource.Mes_Destination_Mapping_Success, Resource.Title_007, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    return;
                }
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.dgvDest.RowCount)
                    {
                        num++;
                        break;
                    }
                    char[] separator = new char[] { '-' };
                    string[] strArray = this.dgvDest.Columns[num].HeaderText.Split(separator);
                    if ((this.dgvDest.Rows[num2].Cells[num].Value != null) && (this.dgvDest.Rows[num2].Cells[num].Value.ToString().ToUpper() == "TRUE"))
                    {
                        string[] textArray1 = new string[] { "SELECT * FROM wb_source_mapping WHERE coy = '", strArray[0].Trim(), "'  AND Location_Code = '", strArray[1].Trim(), "'  AND source_code = '", this.dgvDest.Rows[num2].Cells[0].Value.ToString(), "' " };
                        table.OpenTable("wb_source_mapping", string.Concat(textArray1), WBData.conn);
                        if (table.DT.Rows.Count <= 0)
                        {
                            table.DR = table.DT.NewRow();
                            table.DR["Coy"] = strArray[0].Trim();
                            table.DR["Location_Code"] = strArray[1].Trim();
                            table.DR["source_code"] = this.dgvDest.Rows[num2].Cells[0].Value.ToString();
                            table.DT.Rows.Add(table.DR);
                            table.Save();
                        }
                    }
                    else
                    {
                        string[] textArray2 = new string[] { "SELECT * FROM wb_source_mapping WHERE coy = '", strArray[0].Trim(), "'  AND Location_Code = '", strArray[1].Trim(), "'  AND source_code = '", this.dgvDest.Rows[num2].Cells[0].Value.ToString(), "' " };
                        table.OpenTable("wb_source_mapping", string.Concat(textArray2), WBData.conn);
                        if (table.DT.Rows.Count > 0)
                        {
                            int num3 = 0;
                            while (true)
                            {
                                if (num3 >= table.DT.Rows.Count)
                                {
                                    table.Save();
                                    break;
                                }
                                int posRec = table.GetPosRec(table.DT.Rows[num3]["uniq"].ToString());
                                table.DT.Rows[posRec].Delete();
                                num3++;
                            }
                        }
                    }
                    num2++;
                }
            }
        }

        private void dgvCopy_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if ((e.ColumnIndex == this.Selected.Index) && (e.RowIndex != -1))
            {
                this.dgvDest.EndEdit();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormSourceMapping_Load(object sender, EventArgs e)
        {
            this.dgvDest.Columns.Add("0", "Code");
            this.dgvDest.Columns["0"].Width = 50;
            this.dgvDest.Columns["0"].Frozen = true;
            this.dgvDest.Columns["0"].ReadOnly = true;
            this.dgvDest.Columns.Add("1", "Description");
            this.dgvDest.Columns["1"].Width = 250;
            this.dgvDest.Columns["1"].Frozen = true;
            this.dgvDest.Columns["1"].ReadOnly = true;
            WBTable table = new WBTable();
            table.OpenTable("wb_location", "SELECT coy, location_code FROM wb_location WHERE 1=1 ORDER BY coy, location_code", WBData.conn);
            int num = 2;
            foreach (DataRow row in table.DT.Rows)
            {
                DataGridViewCheckBoxColumn dataGridViewColumn = new DataGridViewCheckBoxColumn {
                    Name = num.ToString(),
                    HeaderText = row["coy"].ToString() + " - " + row["location_code"].ToString(),
                    Width = 70,
                    ReadOnly = false
                };
                this.dgvDest.Columns.Add(dataGridViewColumn);
                num++;
            }
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_checkpoint", "SELECT * FROM wb_checkpoint WHERE Type = 'D' ORDER BY checkpoint_code", WBData.conn);
            foreach (DataRow row2 in table2.DT.Rows)
            {
                string[] values = new string[] { row2["checkpoint_code"].ToString(), row2["description"].ToString() };
                this.dgvDest.Rows.Add(values);
            }
            WBTable table3 = new WBTable();
            int num2 = 2;
            foreach (DataRow row3 in table.DT.Rows)
            {
                int num3 = 0;
                foreach (DataRow row4 in table2.DT.Rows)
                {
                    string[] textArray2 = new string[] { "SELECT * FROM wb_source_mapping WHERE coy = '", row3["coy"].ToString(), "'  AND location_code = '", row3["location_code"].ToString(), "'  AND source_code = '", row4["checkpoint_code"].ToString(), "'" };
                    table3.OpenTable("wb_source_mapping", string.Concat(textArray2), WBData.conn);
                    if (table3.DT.Rows.Count > 0)
                    {
                        this.dgvDest.Rows[num3].Cells[num2].Value = "True";
                    }
                    num3++;
                }
                num2++;
            }
            table3.Dispose();
            table.Dispose();
            table2.Dispose();
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.Selected = new DataGridViewCheckBoxColumn();
            this.dgvDest = new DataGridView();
            this.coy_ = new DataGridViewTextBoxColumn();
            this.loc_ = new DataGridViewTextBoxColumn();
            this.remark = new DataGridViewTextBoxColumn();
            this.buttonProcess = new Button();
            this.buttonCancel = new Button();
            ((ISupportInitialize) this.dgvDest).BeginInit();
            base.SuspendLayout();
            this.Selected.HeaderText = "Select";
            this.Selected.Name = "Selected";
            this.Selected.Width = 0x2d;
            this.dgvDest.AllowUserToAddRows = false;
            this.dgvDest.AllowUserToDeleteRows = false;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgvDest.ColumnHeadersDefaultCellStyle = style;
            this.dgvDest.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ActiveCaptionText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgvDest.DefaultCellStyle = style2;
            this.dgvDest.Location = new Point(12, 12);
            this.dgvDest.Name = "dgvDest";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgvDest.RowHeadersDefaultCellStyle = style3;
            this.dgvDest.Size = new Size(0x2dd, 0x131);
            this.dgvDest.TabIndex = 1;
            this.dgvDest.CellMouseUp += new DataGridViewCellMouseEventHandler(this.dgvCopy_CellMouseUp);
            this.coy_.Name = "coy_";
            this.loc_.Name = "loc_";
            this.remark.Name = "remark";
            this.buttonProcess.Location = new Point(0x233, 0x147);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(0x54, 0x1f);
            this.buttonProcess.TabIndex = 3;
            this.buttonProcess.Text = "Save";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.buttonCancel.Location = new Point(0x295, 0x147);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x54, 0x1f);
            this.buttonCancel.TabIndex = 4;
            this.buttonCancel.Text = "Close";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x2f5, 370);
            base.ControlBox = false;
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonProcess);
            base.Controls.Add(this.dgvDest);
            base.Name = "FormSourceMapping";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Mapping Destination";
            base.Load += new EventHandler(this.FormSourceMapping_Load);
            ((ISupportInitialize) this.dgvDest).EndInit();
            base.ResumeLayout(false);
        }

        private void translate()
        {
            this.buttonProcess.Text = Resource.Save;
            this.buttonCancel.Text = Resource.Menu_Close;
            this.Text = Resource.Menu_Mapping_Destination;
        }
    }
}

