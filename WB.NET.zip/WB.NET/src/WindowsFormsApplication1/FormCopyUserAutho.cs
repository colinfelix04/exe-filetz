﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCopyUserAutho : Form
    {
        public string pMode = "";
        public string logKey = "";
        public string changeReason = "";
        public string reason = "";
        public string table = "";
        public bool saved;
        public string userID = "";
        public string userGroup = "";
        public string userPass = "";
        public string userLevel = "";
        public string userName = "";
        public string group = "";
        public string groupName = "";
        public string oldGroup = "";
        private IContainer components = null;
        private DataGridView dgvCopy;
        private DataGridViewTextBoxColumn coy_;
        private DataGridViewTextBoxColumn loc_;
        private DataGridViewCheckBoxColumn Selected;
        private DataGridViewTextBoxColumn remark;
        private CheckBox checkAll;
        private Button buttonProcess;
        private Button buttonCancel;
        public Label label1;

        public FormCopyUserAutho()
        {
            this.InitializeComponent();
        }

        private void activateDisactivateToOtherLoc()
        {
            WBTable table = new WBTable();
            bool flag = false;
            string str = "";
            int num = 0;
            while (true)
            {
                if (num >= this.dgvCopy.Rows.Count)
                {
                    table.Dispose();
                    return;
                }
                string coy = this.dgvCopy.Rows[num].Cells["coy_"].Value.ToString();
                string loc = this.dgvCopy.Rows[num].Cells["loc_"].Value.ToString();
                if (num == 0)
                {
                    string[] textArray1 = new string[] { "SELECT deleted FROM wb_user WHERE coy = '", WBData.sCoyCode, "' AND location_code = '", WBData.sLocCode, "' AND user_id = '", this.userID, "'" };
                    string sqltext = string.Concat(textArray1);
                    table.OpenTable("wb_user", sqltext, WBData.conn);
                    flag = table.DT.Rows[0]["deleted"].ToString() == "*";
                    str = flag ? "Disactivate" : "Activate";
                }
                if ((this.dgvCopy.Rows[num].Cells["selected"].Value.ToString() == "True") && ((coy != WBData.sCoyCode) || (loc != WBData.sLocCode)))
                {
                    string[] textArray2 = new string[] { "SELECT * FROM wb_user WHERE coy = '", coy, "' AND location_code = '", loc, "' AND user_id = '", this.userID, "'" };
                    string sqltext = string.Concat(textArray2);
                    table.OpenTable("wb_user", sqltext, WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        string[] textArray3 = new string[] { "User '", this.userID, "' is not found. Can't be ", str.ToLower(), "d." };
                        this.dgvCopy.Rows[num].Cells["remark"].Value = string.Concat(textArray3);
                    }
                    else
                    {
                        table.DR = table.DT.Rows[0];
                        this.logKey = table.DR["uniq"].ToString();
                        table.DR.BeginEdit();
                        if (!flag)
                        {
                            table.DR["deleted"] = "";
                            table.DR["Delete_By"] = "";
                            table.DR["Delete_Date"] = DBNull.Value;
                        }
                        else
                        {
                            table.DR["deleted"] = "*";
                            table.DR["Delete_By"] = WBUser.UserID;
                            table.DR["Delete_Date"] = DateTime.Now;
                        }
                        table.DR["Checksum"] = table.Checksum(table.DR);
                        table.DR.EndEdit();
                        table.Save();
                        string[] textArray4 = new string[] { this.changeReason, " (triggered from ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                        this.reason = string.Concat(textArray4);
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, this.reason };
                        Program.updateLogHeader_otherLocations("wb_user", this.logKey, logField, logValue, coy, loc);
                        string[] textArray7 = new string[] { "User '", this.userID, "' has been ", str.ToLower(), "d successfully." };
                        this.dgvCopy.Rows[num].Cells["remark"].Value = string.Concat(textArray7);
                    }
                }
                num++;
            }
        }

        private void addToOtherLoc()
        {
            WBTable table = new WBTable();
            int num = 0;
            while (true)
            {
                if (num >= this.dgvCopy.Rows.Count)
                {
                    table.Dispose();
                    return;
                }
                string coy = this.dgvCopy.Rows[num].Cells["coy_"].Value.ToString();
                string loc = this.dgvCopy.Rows[num].Cells["loc_"].Value.ToString();
                if ((this.dgvCopy.Rows[num].Cells["selected"].Value.ToString() == "True") && ((coy != WBData.sCoyCode) || (loc != WBData.sLocCode)))
                {
                    string[] textArray1 = new string[] { "SELECT * FROM wb_user WHERE coy = '", coy, "' AND location_code = '", loc, "' AND user_id = '", this.userID, "'" };
                    string sqltext = string.Concat(textArray1);
                    table.OpenTable("wb_user", sqltext, WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        this.dgvCopy.Rows[num].Cells["remark"].Value = "User '" + this.userID + "' has already existed.";
                    }
                    else
                    {
                        table.DR = table.DT.NewRow();
                        table.DR["Coy"] = coy;
                        table.DR["Location_Code"] = loc;
                        table.DR["User_id"] = this.userID;
                        table.DR["User_name"] = this.userName;
                        table.DR["User_pass"] = this.userPass;
                        table.DR["User_Level"] = this.userLevel;
                        table.DR["User_Group"] = this.userGroup;
                        table.DR["Create_By"] = WBUser.UserID;
                        table.DR["Create_Date"] = DateTime.Now;
                        table.DR["Checksum"] = table.Checksum(table.DR);
                        table.DT.Rows.Add(table.DR);
                        table.Save();
                        WBTable table2 = new WBTable();
                        string[] textArray2 = new string[] { "SELECT uniq FROM wb_user WHERE coy = '", coy, "' AND location_code = '", loc, "' AND user_ID = '", this.userID, "'" };
                        table2.OpenTable("wb_user", string.Concat(textArray2), WBData.conn);
                        this.logKey = table2.DT.Rows[0]["uniq"].ToString();
                        table2.Dispose();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "ADD", WBUser.UserID, "Copy user from " + WBData.sCoyCode + " - " + WBData.sLocCode };
                        Program.updateLogHeader_otherLocations("wb_user", this.logKey, logField, logValue, coy, loc);
                        this.dgvCopy.Rows[num].Cells["remark"].Value = "User '" + this.userID + "' has been added successfully.";
                    }
                }
                num++;
            }
        }

        private void addToOtherLoc_Auth()
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            WBTable table3 = new WBTable();
            int num = 0;
            while (true)
            {
                if (num >= this.dgvCopy.Rows.Count)
                {
                    table.Dispose();
                    table2.Dispose();
                    table3.Dispose();
                    return;
                }
                string coy = this.dgvCopy.Rows[num].Cells["coy_"].Value.ToString();
                string loc = this.dgvCopy.Rows[num].Cells["loc_"].Value.ToString();
                if ((this.dgvCopy.Rows[num].Cells["selected"].Value.ToString() == "True") && ((coy != WBData.sCoyCode) || (loc != WBData.sLocCode)))
                {
                    string[] textArray1 = new string[] { "SELECT * FROM wb_group WHERE coy = '", coy, "' AND location_code = '", loc, "' AND code = '", this.group, "'" };
                    string sqltext = string.Concat(textArray1);
                    table.OpenTable("wb_group", sqltext, WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        this.dgvCopy.Rows[num].Cells["remark"].Value = "Group '" + this.group + "' has already existed.";
                    }
                    else
                    {
                        table.DR = table.DT.NewRow();
                        table.DR["Coy"] = coy;
                        table.DR["Location_Code"] = loc;
                        table.DR["code"] = this.group;
                        table.DR["name"] = this.groupName;
                        table.DT.Rows.Add(table.DR);
                        table.Save();
                        WBTable table4 = new WBTable();
                        string[] textArray2 = new string[] { "SELECT uniq FROM wb_group WHERE coy = '", coy, "' AND location_code = '", loc, "' AND code = '", this.group, "'" };
                        table4.OpenTable("wb_group", string.Concat(textArray2), WBData.conn);
                        this.logKey = table4.DT.Rows[0]["uniq"].ToString();
                        table4.Dispose();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "ADD", WBUser.UserID, "Copy group from " + WBData.sCoyCode + " - " + WBData.sLocCode };
                        Program.updateLogHeader_otherLocations("wb_group", this.logKey, logField, logValue, coy, loc);
                        table2.OpenTable("wb_authorization", "SELECT * FROM wb_authorization WHERE " + WBData.CompanyLocation(" AND autho_group = '" + this.group + "' ORDER BY uniq ASC"), WBData.conn);
                        foreach (DataRow row in table2.DT.Rows)
                        {
                            string[] textArray5 = new string[9];
                            textArray5[0] = "SELECT * FROM wb_authorization WHERE coy = '";
                            textArray5[1] = coy;
                            textArray5[2] = "'  AND location_code = '";
                            textArray5[3] = loc;
                            textArray5[4] = "'  AND autho_group = '";
                            textArray5[5] = this.group;
                            textArray5[6] = "'  AND autho_menu = '";
                            textArray5[7] = row["autho_menu"].ToString();
                            textArray5[8] = "'";
                            string str4 = string.Concat(textArray5);
                            table3.OpenTable("wb_authorization", str4, WBData.conn);
                            if (table3.DT.Rows.Count <= 0)
                            {
                                table3.DR = table3.DT.NewRow();
                                table3.DR["Coy"] = coy;
                                table3.DR["Location_Code"] = loc;
                                table3.DR["autho_group"] = this.group;
                                table3.DR["autho_menu"] = row["autho_menu"].ToString();
                                table3.DR["autho_trustee"] = row["autho_trustee"].ToString();
                                table3.DR["Checksum"] = table3.Checksum(table3.DR);
                                table3.DT.Rows.Add(table3.DR);
                                table3.Save();
                                WBTable table5 = new WBTable();
                                table5.OpenTable("wb_authorization", str4, WBData.conn);
                                this.logKey = table5.DT.Rows[0]["uniq"].ToString();
                                table5.Dispose();
                                string[] textArray6 = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] textArray7 = new string[] { "ADD", WBUser.UserID, "Copy authorization from " + WBData.sCoyCode + " - " + WBData.sLocCode };
                                Program.updateLogHeader_otherLocations("wb_authorization", this.logKey, textArray6, textArray7, coy, loc);
                            }
                        }
                        this.dgvCopy.Rows[num].Cells["remark"].Value = "Group '" + this.group + "' has been added successfully.";
                    }
                }
                num++;
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            bool flag = false;
            int num = 0;
            while (true)
            {
                if (num < this.dgvCopy.Rows.Count)
                {
                    if (this.dgvCopy.Rows[num].Cells["selected"].Value.ToString() != "True")
                    {
                        num++;
                        continue;
                    }
                    flag = true;
                }
                if (!flag)
                {
                    MessageBox.Show("Please choose at least 1 location!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    string text = "";
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= this.dgvCopy.Rows.Count)
                        {
                            if (this.table != "user")
                            {
                                if (this.table == "auth")
                                {
                                    if (this.pMode == "COPY")
                                    {
                                        string[] textArray9 = new string[] { "Authorization of group ", this.group, " will be copied to \n", text, "\nAre you sure to continue?" };
                                        text = text = string.Concat(textArray9);
                                    }
                                    else if (this.pMode == "ADD")
                                    {
                                        string[] textArray10 = new string[] { "Authorization of group ", this.group, " will be added to \n", text, "\nAre you sure to continue?" };
                                        text = text = string.Concat(textArray10);
                                    }
                                    else if (this.pMode == "EDIT")
                                    {
                                        string[] textArray11 = new string[] { "Authorization of group ", this.group, " will be edited in \n", text, "\nAre you sure to continue?" };
                                        text = text = string.Concat(textArray11);
                                    }
                                    else if (this.pMode == "DELETE")
                                    {
                                        string[] textArray12 = new string[] { "Authorization of group ", this.group, " will be deleted in \n", text, "\nAre you sure to continue?" };
                                        text = text = string.Concat(textArray12);
                                    }
                                }
                            }
                            else if (this.pMode == "COPY")
                            {
                                string[] textArray2 = new string[] { "User ", this.userID, "(", this.userName, ") will be copied to \n", text, "\nAre you sure to continue?" };
                                text = string.Concat(textArray2);
                            }
                            else if (this.pMode == "ACT-NON")
                            {
                                if (this.Text.ToLower().Contains("disactivate"))
                                {
                                    string[] textArray3 = new string[] { "User ", this.userID, "(", this.userName, ") will be disactivated in \n", text, "\nAre you sure to continue?" };
                                    text = string.Concat(textArray3);
                                }
                                else if (this.Text.ToLower().Contains("activate"))
                                {
                                    string[] textArray4 = new string[] { "User ", this.userID, "(", this.userName, ") will be activated in \n", text, "\nAre you sure to continue?" };
                                    text = string.Concat(textArray4);
                                }
                            }
                            else if (this.pMode == "DELETE")
                            {
                                string[] textArray5 = new string[] { "User ", this.userID, "(", this.userName, ") will be deleted in \n", text, "\nAre you sure to continue?" };
                                text = string.Concat(textArray5);
                            }
                            else if (this.pMode == "ADD")
                            {
                                string[] textArray6 = new string[] { "User ", this.userID, "(", this.userName, ") will be added to \n", text, "\nAre you sure to continue?" };
                                text = string.Concat(textArray6);
                            }
                            else if (this.pMode == "EDIT")
                            {
                                string[] textArray7 = new string[] { "User ", this.userID, "(", this.userName, ") will be edited to \n", text, "\nAre you sure to continue?" };
                                text = string.Concat(textArray7);
                            }
                            else if (this.pMode == "PASS")
                            {
                                string[] textArray8 = new string[] { "Password of user ", this.userID, "(", this.userName, ") will be changed in \n", text, "\nAre you sure to continue?" };
                                text = string.Concat(textArray8);
                            }
                            if (MessageBox.Show(text, "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                Cursor.Current = Cursors.WaitCursor;
                                if (this.table != "user")
                                {
                                    if (this.table == "auth")
                                    {
                                        if (this.pMode == "COPY")
                                        {
                                            this.copyToOtherLoc_Auth();
                                        }
                                        else if (this.pMode == "ADD")
                                        {
                                            this.addToOtherLoc_Auth();
                                        }
                                        else if (this.pMode == "EDIT")
                                        {
                                            this.editToOtherLoc_Auth();
                                        }
                                        else if (this.pMode == "DELETE")
                                        {
                                            this.deleteToOtherLoc_Auth();
                                        }
                                    }
                                }
                                else if (this.pMode == "COPY")
                                {
                                    this.copyToOtherLoc();
                                }
                                else if (this.pMode == "ACT-NON")
                                {
                                    this.activateDisactivateToOtherLoc();
                                }
                                else if (this.pMode == "DELETE")
                                {
                                    this.deleteToOtherLoc();
                                }
                                else if (this.pMode == "ADD")
                                {
                                    this.addToOtherLoc();
                                }
                                else if ((this.pMode == "EDIT") || (this.pMode == "PASS"))
                                {
                                    this.editToOtherLoc();
                                }
                                this.saved = true;
                                Cursor.Current = Cursors.Default;
                                MessageBox.Show("Process has been finished!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            }
                            break;
                        }
                        if ((this.dgvCopy.Rows[num2].Cells["selected"].Value.ToString() == "True") && ((this.dgvCopy.Rows[num2].Cells["coy_"].Value.ToString() != WBData.sCoyCode) || (this.dgvCopy.Rows[num2].Cells["loc_"].Value.ToString() != WBData.sLocCode)))
                        {
                            string[] textArray1 = new string[] { text, this.dgvCopy.Rows[num2].Cells["coy_"].Value.ToString(), " - ", this.dgvCopy.Rows[num2].Cells["loc_"].Value.ToString(), "\n" };
                            text = string.Concat(textArray1);
                        }
                        num2++;
                    }
                }
                return;
            }
        }

        private void checkAll_CheckedChanged(object sender, EventArgs e)
        {
            if (this.dgvCopy.Rows.Count > 0)
            {
                if (this.checkAll.Checked)
                {
                    int num = 0;
                    while (true)
                    {
                        if (num >= this.dgvCopy.Rows.Count)
                        {
                            break;
                        }
                        this.dgvCopy.Rows[num].Cells["selected"].Value = true;
                        num++;
                    }
                }
                else
                {
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= this.dgvCopy.Rows.Count)
                        {
                            break;
                        }
                        this.dgvCopy.Rows[num2].Cells["selected"].Value = false;
                        num2++;
                    }
                }
            }
        }

        private void copyToOtherLoc()
        {
            WBTable table = new WBTable();
            int num = 0;
            while (true)
            {
                if (num >= this.dgvCopy.Rows.Count)
                {
                    table.Dispose();
                    return;
                }
                string coy = this.dgvCopy.Rows[num].Cells["coy_"].Value.ToString();
                string loc = this.dgvCopy.Rows[num].Cells["loc_"].Value.ToString();
                if ((this.dgvCopy.Rows[num].Cells["selected"].Value.ToString() == "True") && ((coy != WBData.sCoyCode) || (loc != WBData.sLocCode)))
                {
                    string[] textArray1 = new string[] { "SELECT * FROM wb_user WHERE coy = '", coy, "' AND location_code = '", loc, "' AND user_id = '", this.userID, "'" };
                    string sqltext = string.Concat(textArray1);
                    table.OpenTable("wb_user", sqltext, WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        table.DR = table.DT.Rows[0];
                        if (((table.DR["User_id"].ToString() == this.userID) && ((table.DR["User_name"].ToString() == this.userName) && ((table.DR["User_pass"].ToString() == this.userPass) && (table.DR["User_Level"].ToString() == this.userLevel)))) && (table.DR["User_Group"].ToString() == this.userGroup))
                        {
                            this.dgvCopy.Rows[num].Cells["remark"].Value = "User '" + this.userID + "' has been edited successfully.";
                        }
                        else
                        {
                            this.logKey = table.DR["uniq"].ToString();
                            table.DR.BeginEdit();
                            table.DR["Coy"] = coy;
                            table.DR["Location_Code"] = loc;
                            table.DR["User_id"] = this.userID;
                            table.DR["User_name"] = this.userName;
                            table.DR["User_pass"] = this.userPass;
                            table.DR["User_Level"] = this.userLevel;
                            table.DR["User_Group"] = this.userGroup;
                            table.DR["Change_By"] = WBUser.UserID;
                            table.DR["Change_Date"] = DateTime.Now;
                            table.DR["Checksum"] = table.Checksum(table.DR);
                            table.DR.EndEdit();
                            table.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Copy user from " + WBData.sCoyCode + " - " + WBData.sLocCode };
                            Program.updateLogHeader_otherLocations("wb_user", this.logKey, logField, logValue, coy, loc);
                            this.dgvCopy.Rows[num].Cells["remark"].Value = "User '" + this.userID + "' has been edited successfully.";
                        }
                    }
                    else
                    {
                        table.DR = table.DT.NewRow();
                        table.DR["Coy"] = coy;
                        table.DR["Location_Code"] = loc;
                        table.DR["User_id"] = this.userID;
                        table.DR["User_name"] = this.userName;
                        table.DR["User_pass"] = this.userPass;
                        table.DR["User_Level"] = this.userLevel;
                        table.DR["User_Group"] = this.userGroup;
                        table.DR["Create_By"] = WBUser.UserID;
                        table.DR["Create_Date"] = DateTime.Now;
                        table.DR["Checksum"] = table.Checksum(table.DR);
                        table.DT.Rows.Add(table.DR);
                        table.Save();
                        WBTable table2 = new WBTable();
                        string[] textArray2 = new string[] { "SELECT uniq FROM wb_user WHERE coy = '", coy, "' AND location_code = '", loc, "' AND user_ID = '", this.userID, "'" };
                        table2.OpenTable("wb_user", string.Concat(textArray2), WBData.conn);
                        this.logKey = table2.DT.Rows[0]["uniq"].ToString();
                        table2.Dispose();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "ADD", WBUser.UserID, "Copy user from " + WBData.sCoyCode + " - " + WBData.sLocCode };
                        Program.updateLogHeader_otherLocations("wb_user", this.logKey, logField, logValue, coy, loc);
                        this.dgvCopy.Rows[num].Cells["remark"].Value = "User '" + this.userID + "' is not found. User has been added successfully.";
                    }
                }
                num++;
            }
        }

        private void copyToOtherLoc_Auth()
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            WBTable table3 = new WBTable();
            int num = 0;
            while (true)
            {
                if (num >= this.dgvCopy.Rows.Count)
                {
                    table.Dispose();
                    table2.Dispose();
                    table3.Dispose();
                    return;
                }
                string coy = this.dgvCopy.Rows[num].Cells["coy_"].Value.ToString();
                string loc = this.dgvCopy.Rows[num].Cells["loc_"].Value.ToString();
                if ((this.dgvCopy.Rows[num].Cells["selected"].Value.ToString() == "True") && ((coy != WBData.sCoyCode) || (loc != WBData.sLocCode)))
                {
                    string[] textArray1 = new string[] { "SELECT * FROM wb_group WHERE coy = '", coy, "' AND location_code = '", loc, "' AND code = '", this.group, "'" };
                    string sqltext = string.Concat(textArray1);
                    table.OpenTable("wb_group", sqltext, WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        table.DR = table.DT.NewRow();
                        table.DR["Coy"] = coy;
                        table.DR["Location_Code"] = loc;
                        table.DR["code"] = this.group;
                        table.DR["name"] = this.groupName;
                        table.DT.Rows.Add(table.DR);
                        table.Save();
                        WBTable table4 = new WBTable();
                        string[] textArray2 = new string[] { "SELECT uniq FROM wb_group WHERE coy = '", coy, "' AND location_code = '", loc, "' AND code = '", this.group, "'" };
                        table4.OpenTable("wb_group", string.Concat(textArray2), WBData.conn);
                        this.logKey = table4.DT.Rows[0]["uniq"].ToString();
                        table4.Dispose();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "ADD", WBUser.UserID, "Copy group from " + WBData.sCoyCode + " - " + WBData.sLocCode };
                        Program.updateLogHeader_otherLocations("wb_group", this.logKey, logField, logValue, coy, loc);
                        table2.OpenTable("wb_authorization", "SELECT * FROM wb_authorization WHERE " + WBData.CompanyLocation(" AND autho_group = '" + this.group + "' ORDER BY uniq ASC"), WBData.conn);
                        foreach (DataRow row in table2.DT.Rows)
                        {
                            string[] textArray5 = new string[9];
                            textArray5[0] = "SELECT * FROM wb_authorization WHERE coy = '";
                            textArray5[1] = coy;
                            textArray5[2] = "'  AND location_code = '";
                            textArray5[3] = loc;
                            textArray5[4] = "'  AND autho_group = '";
                            textArray5[5] = this.group;
                            textArray5[6] = "'  AND autho_menu = '";
                            textArray5[7] = row["autho_menu"].ToString();
                            textArray5[8] = "'";
                            string str4 = string.Concat(textArray5);
                            table3.OpenTable("wb_authorization", str4, WBData.conn);
                            if (table3.DT.Rows.Count <= 0)
                            {
                                table3.DR = table3.DT.NewRow();
                                table3.DR["Coy"] = coy;
                                table3.DR["Location_Code"] = loc;
                                table3.DR["autho_group"] = this.group;
                                table3.DR["autho_menu"] = row["autho_menu"].ToString();
                                table3.DR["autho_trustee"] = row["autho_trustee"].ToString();
                                table3.DR["Checksum"] = table3.Checksum(table3.DR);
                                table3.DT.Rows.Add(table3.DR);
                                table3.Save();
                                WBTable table5 = new WBTable();
                                table5.OpenTable("wb_authorization", str4, WBData.conn);
                                this.logKey = table5.DT.Rows[0]["uniq"].ToString();
                                table5.Dispose();
                                string[] textArray6 = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] textArray7 = new string[] { "ADD", WBUser.UserID, "Copy authorization from " + WBData.sCoyCode + " - " + WBData.sLocCode };
                                Program.updateLogHeader_otherLocations("wb_authorization", this.logKey, textArray6, textArray7, coy, loc);
                            }
                        }
                        this.dgvCopy.Rows[num].Cells["remark"].Value = "Group '" + this.group + "' is not found. Group & Authorization have been added successfully.";
                    }
                    else
                    {
                        table.DR = table.DT.Rows[0];
                        this.logKey = table.DR["uniq"].ToString();
                        table.DR.BeginEdit();
                        table.DR["Coy"] = coy;
                        table.DR["Location_Code"] = loc;
                        table.DR["code"] = this.group;
                        table.DR["name"] = this.groupName;
                        table.DR.EndEdit();
                        table.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Copy group from " + WBData.sCoyCode + " - " + WBData.sLocCode };
                        Program.updateLogHeader_otherLocations("wb_group", this.logKey, logField, logValue, coy, loc);
                        table2.OpenTable("wb_authorization", "SELECT * FROM wb_authorization WHERE " + WBData.CompanyLocation(" AND autho_group = '" + this.group + "' ORDER BY uniq ASC"), WBData.conn);
                        foreach (DataRow row2 in table2.DT.Rows)
                        {
                            string[] textArray10 = new string[9];
                            textArray10[0] = "SELECT * FROM wb_authorization WHERE coy = '";
                            textArray10[1] = coy;
                            textArray10[2] = "'  AND location_code = '";
                            textArray10[3] = loc;
                            textArray10[4] = "'  AND autho_group = '";
                            textArray10[5] = this.group;
                            textArray10[6] = "'  AND autho_menu = '";
                            textArray10[7] = row2["autho_menu"].ToString();
                            textArray10[8] = "'";
                            string str5 = string.Concat(textArray10);
                            table3.OpenTable("wb_authorization", str5, WBData.conn);
                            if (table3.DT.Rows.Count > 0)
                            {
                                table3.DR = table3.DT.Rows[0];
                                this.logKey = table3.DR["uniq"].ToString();
                                table3.DR.BeginEdit();
                                table3.DR["Coy"] = coy;
                                table3.DR["Location_Code"] = loc;
                                table3.DR["autho_group"] = this.group;
                                table3.DR["autho_menu"] = row2["autho_menu"].ToString();
                                table3.DR["autho_trustee"] = row2["autho_trustee"].ToString();
                                table3.DR["Checksum"] = table3.Checksum(table3.DR);
                                table3.DR.EndEdit();
                                table3.Save();
                                string[] textArray13 = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] textArray14 = new string[] { "EDIT", WBUser.UserID, "Copy authorization from " + WBData.sCoyCode + " - " + WBData.sLocCode };
                                Program.updateLogHeader_otherLocations("wb_authorization", this.logKey, textArray13, textArray14, coy, loc);
                                continue;
                            }
                            table3.DR = table3.DT.NewRow();
                            table3.DR["Coy"] = coy;
                            table3.DR["Location_Code"] = loc;
                            table3.DR["autho_group"] = this.group;
                            table3.DR["autho_menu"] = row2["autho_menu"].ToString();
                            table3.DR["autho_trustee"] = row2["autho_trustee"].ToString();
                            table3.DR["Checksum"] = table3.Checksum(table3.DR);
                            table3.DT.Rows.Add(table3.DR);
                            table3.Save();
                            WBTable table6 = new WBTable();
                            table6.OpenTable("wb_authorization", str5, WBData.conn);
                            this.logKey = table6.DT.Rows[0]["uniq"].ToString();
                            table6.Dispose();
                            string[] textArray11 = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] textArray12 = new string[] { "ADD", WBUser.UserID, "Copy authorization from " + WBData.sCoyCode + " - " + WBData.sLocCode };
                            Program.updateLogHeader_otherLocations("wb_authorization", this.logKey, textArray11, textArray12, coy, loc);
                        }
                        this.dgvCopy.Rows[num].Cells["remark"].Value = "Group '" + this.group + "' is found. Group & authorization have been edited successfully.";
                    }
                }
                num++;
            }
        }

        private void deleteToOtherLoc()
        {
            WBTable table = new WBTable();
            int num = 0;
            while (true)
            {
                if (num >= this.dgvCopy.Rows.Count)
                {
                    table.Dispose();
                    return;
                }
                string coy = this.dgvCopy.Rows[num].Cells["coy_"].Value.ToString();
                string loc = this.dgvCopy.Rows[num].Cells["loc_"].Value.ToString();
                if ((this.dgvCopy.Rows[num].Cells["selected"].Value.ToString() == "True") && ((coy != WBData.sCoyCode) || (loc != WBData.sLocCode)))
                {
                    string[] textArray1 = new string[] { "SELECT * FROM wb_user WHERE coy = '", coy, "' AND location_code = '", loc, "' AND user_id = '", this.userID, "'" };
                    string sqltext = string.Concat(textArray1);
                    table.OpenTable("wb_user", sqltext, WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        this.dgvCopy.Rows[num].Cells["remark"].Value = "User '" + this.userID + "' is not found. Can't be deleted.";
                    }
                    else
                    {
                        table.DR = table.DT.Rows[0];
                        this.logKey = table.DR["uniq"].ToString();
                        table.DR.Delete();
                        table.Save();
                        string[] textArray2 = new string[] { this.changeReason, " (triggered from ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                        this.reason = string.Concat(textArray2);
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "DELETE", WBUser.UserID, this.reason };
                        Program.updateLogHeader_otherLocations("wb_user", this.logKey, logField, logValue, coy, loc);
                        this.dgvCopy.Rows[num].Cells["remark"].Value = "User '" + this.userID + "' has been deleted successfully.";
                    }
                }
                num++;
            }
        }

        private void deleteToOtherLoc_Auth()
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            WBTable table3 = new WBTable();
            int num = 0;
            while (true)
            {
                if (num >= this.dgvCopy.Rows.Count)
                {
                    table.Dispose();
                    table2.Dispose();
                    table3.Dispose();
                    return;
                }
                string coy = this.dgvCopy.Rows[num].Cells["coy_"].Value.ToString();
                string loc = this.dgvCopy.Rows[num].Cells["loc_"].Value.ToString();
                if ((this.dgvCopy.Rows[num].Cells["selected"].Value.ToString() == "True") && ((coy != WBData.sCoyCode) || (loc != WBData.sLocCode)))
                {
                    string[] textArray1 = new string[] { "SELECT * FROM wb_group WHERE coy = '", coy, "' AND location_code = '", loc, "' AND code = '", this.group, "'" };
                    string sqltext = string.Concat(textArray1);
                    table.OpenTable("wb_user", sqltext, WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        this.dgvCopy.Rows[num].Cells["remark"].Value = "Group '" + this.group + "' is not found. Can't be deleted.";
                    }
                    else
                    {
                        string[] textArray2 = new string[] { "SELECT uniq FROM wb_user WHERE coy = '", coy, "' AND location_code = '", loc, "' AND user_group = '", this.group, "'" };
                        table2.OpenTable("wb_user", string.Concat(textArray2), WBData.conn);
                        if (table2.DT.Rows.Count > 0)
                        {
                            this.dgvCopy.Rows[num].Cells["remark"].Value = "Group '" + this.group + "' is still used by some users. Can't be deleted.";
                        }
                        else
                        {
                            string[] textArray3 = new string[] { "SELECT * FROM wb_authorization WHERE coy = '", coy, "' AND location_code = '", loc, "' AND autho_group = '", this.group, "'" };
                            table3.OpenTable("wb_authorization", string.Concat(textArray3), WBData.conn);
                            string[] strArray = new string[table3.DT.Rows.Count];
                            int index = 0;
                            while (true)
                            {
                                if (index >= table3.DT.Rows.Count)
                                {
                                    table3.Save();
                                    string[] textArray4 = new string[] { this.changeReason, " (triggered from ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                                    this.reason = string.Concat(textArray4);
                                    int num3 = 0;
                                    while (true)
                                    {
                                        if (num3 >= strArray.Length)
                                        {
                                            table.DR = table.DT.Rows[0];
                                            this.logKey = table.DR["uniq"].ToString();
                                            table.DR.Delete();
                                            table.Save();
                                            string[] textArray7 = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] textArray8 = new string[] { "DELETE", WBUser.UserID, this.reason };
                                            Program.updateLogHeader_otherLocations("wb_group", this.logKey, textArray7, textArray8, coy, loc);
                                            this.dgvCopy.Rows[num].Cells["remark"].Value = "Group '" + this.group + "' & its authorization have been deleted successfully.";
                                            break;
                                        }
                                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                        string[] logValue = new string[] { "DELETE", WBUser.UserID, this.reason };
                                        Program.updateLogHeader_otherLocations("wb_authorization", strArray[num3], logField, logValue, coy, loc);
                                        num3++;
                                    }
                                    break;
                                }
                                table3.DR = table3.DT.Rows[index];
                                strArray[index] = table3.DR["uniq"].ToString();
                                table3.DR.Delete();
                                index++;
                            }
                        }
                    }
                }
                num++;
            }
        }

        private void dgvCopy_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if ((e.ColumnIndex == this.Selected.Index) && (e.RowIndex != -1))
            {
                this.dgvCopy.EndEdit();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editToOtherLoc()
        {
            WBTable table = new WBTable();
            int num = 0;
            while (true)
            {
                if (num >= this.dgvCopy.Rows.Count)
                {
                    table.Dispose();
                    return;
                }
                string coy = this.dgvCopy.Rows[num].Cells["coy_"].Value.ToString();
                string loc = this.dgvCopy.Rows[num].Cells["loc_"].Value.ToString();
                if ((this.dgvCopy.Rows[num].Cells["selected"].Value.ToString() == "True") && ((coy != WBData.sCoyCode) || (loc != WBData.sLocCode)))
                {
                    string[] textArray1 = new string[] { "SELECT * FROM wb_user WHERE coy = '", coy, "' AND location_code = '", loc, "' AND user_id = '", this.userID, "'" };
                    string sqltext = string.Concat(textArray1);
                    table.OpenTable("wb_user", sqltext, WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        this.dgvCopy.Rows[num].Cells["remark"].Value = "User '" + this.userID + "' is not found. Data can't be edited.";
                    }
                    else
                    {
                        table.DR = table.DT.Rows[0];
                        if (((table.DR["User_id"].ToString() == this.userID) && ((table.DR["User_name"].ToString() == this.userName) && ((table.DR["User_pass"].ToString() == this.userPass) && (table.DR["User_Level"].ToString() == this.userLevel)))) && (table.DR["User_Group"].ToString() == this.userGroup))
                        {
                            this.dgvCopy.Rows[num].Cells["remark"].Value = "User '" + this.userID + "' has been edited successfully.";
                        }
                        else
                        {
                            this.logKey = table.DR["uniq"].ToString();
                            table.DR.BeginEdit();
                            table.DR["Coy"] = coy;
                            table.DR["Location_Code"] = loc;
                            table.DR["User_id"] = this.userID;
                            table.DR["User_name"] = this.userName;
                            table.DR["User_pass"] = this.userPass;
                            table.DR["User_Level"] = this.userLevel;
                            table.DR["User_Group"] = this.userGroup;
                            table.DR["Change_By"] = WBUser.UserID;
                            table.DR["Change_Date"] = DateTime.Now;
                            table.DR["Checksum"] = table.Checksum(table.DR);
                            table.DR.EndEdit();
                            table.Save();
                            string[] textArray2 = new string[] { this.changeReason, " (triggered from ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                            string str = string.Concat(textArray2);
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "EDIT", WBUser.UserID, str };
                            Program.updateLogHeader_otherLocations("wb_user", this.logKey, logField, logValue, coy, loc);
                            this.dgvCopy.Rows[num].Cells["remark"].Value = "User '" + this.userID + "' has been edited successfully.";
                        }
                    }
                }
                num++;
            }
        }

        private void editToOtherLoc_Auth()
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            WBTable table3 = new WBTable();
            int num = 0;
            while (true)
            {
                if (num >= this.dgvCopy.Rows.Count)
                {
                    table.Dispose();
                    table2.Dispose();
                    table3.Dispose();
                    return;
                }
                string coy = this.dgvCopy.Rows[num].Cells["coy_"].Value.ToString();
                string loc = this.dgvCopy.Rows[num].Cells["loc_"].Value.ToString();
                if ((this.dgvCopy.Rows[num].Cells["selected"].Value.ToString() == "True") && ((coy != WBData.sCoyCode) || (loc != WBData.sLocCode)))
                {
                    string[] textArray1 = new string[] { "SELECT * FROM wb_group WHERE coy = '", coy, "' AND location_code = '", loc, "' AND code = '", this.group, "'" };
                    string sqltext = string.Concat(textArray1);
                    table.OpenTable("wb_group", sqltext, WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        this.dgvCopy.Rows[num].Cells["remark"].Value = "Group '" + this.group + "' is not found. Data can't be edited.";
                    }
                    else
                    {
                        table.DR = table.DT.Rows[0];
                        this.logKey = table.DR["uniq"].ToString();
                        table.DR.BeginEdit();
                        table.DR["Coy"] = coy;
                        table.DR["Location_Code"] = loc;
                        table.DR["code"] = this.group;
                        table.DR["name"] = this.groupName;
                        table.DR.EndEdit();
                        table.Save();
                        string[] textArray2 = new string[] { this.changeReason, " (triggered from ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                        this.reason = string.Concat(textArray2);
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, this.reason };
                        Program.updateLogHeader_otherLocations("wb_group", this.logKey, logField, logValue, coy, loc);
                        if (this.group != this.oldGroup)
                        {
                            WBTable table4 = new WBTable();
                            string[] textArray5 = new string[] { "Select * from wb_user WHERE coy = '", coy, "' AND location_code = '", loc, "' and User_Group = '", this.oldGroup, "'" };
                            table4.OpenTable("wb_user", string.Concat(textArray5), WBData.conn);
                            foreach (DataRow row in table4.DT.Rows)
                            {
                                this.logKey = row["uniq"].ToString();
                                row.BeginEdit();
                                row["User_Group"] = this.group;
                                row.EndEdit();
                                table4.Save();
                                string[] textArray6 = new string[] { this.changeReason, " (triggered from edit group in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                                this.reason = string.Concat(textArray6);
                                string[] textArray7 = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] textArray8 = new string[] { "EDIT", WBUser.UserID, this.reason };
                                Program.updateLogHeader_otherLocations("wb_user", this.logKey, textArray7, textArray8, coy, loc);
                            }
                            table4.Dispose();
                        }
                        table2.OpenTable("wb_authorization", "SELECT * FROM wb_authorization WHERE " + WBData.CompanyLocation(" AND autho_group = '" + this.group + "' ORDER BY uniq ASC"), WBData.conn);
                        foreach (DataRow row2 in table2.DT.Rows)
                        {
                            string[] textArray9 = new string[9];
                            textArray9[0] = "SELECT * FROM wb_authorization WHERE coy = '";
                            textArray9[1] = coy;
                            textArray9[2] = "'  AND location_code = '";
                            textArray9[3] = loc;
                            textArray9[4] = "'  AND autho_group = '";
                            textArray9[5] = this.group;
                            textArray9[6] = "'  AND autho_menu = '";
                            textArray9[7] = row2["autho_menu"].ToString();
                            textArray9[8] = "'";
                            string str4 = string.Concat(textArray9);
                            table3.OpenTable("wb_authorization", str4, WBData.conn);
                            if (table3.DT.Rows.Count > 0)
                            {
                                table3.DR = table3.DT.Rows[0];
                                this.logKey = table3.DR["uniq"].ToString();
                                table3.DR.BeginEdit();
                                table3.DR["Coy"] = coy;
                                table3.DR["Location_Code"] = loc;
                                table3.DR["autho_group"] = this.group;
                                table3.DR["autho_menu"] = row2["autho_menu"].ToString();
                                table3.DR["autho_trustee"] = row2["autho_trustee"].ToString();
                                table3.DR["Checksum"] = table3.Checksum(table3.DR);
                                table3.DR.EndEdit();
                                table3.Save();
                                string[] textArray13 = new string[] { this.changeReason, " (triggered from ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                                this.reason = string.Concat(textArray13);
                                string[] textArray14 = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] textArray15 = new string[] { "EDIT", WBUser.UserID, this.reason };
                                Program.updateLogHeader_otherLocations("wb_authorization", this.logKey, textArray14, textArray15, coy, loc);
                                continue;
                            }
                            table3.DR = table3.DT.NewRow();
                            table3.DR["Coy"] = coy;
                            table3.DR["Location_Code"] = loc;
                            table3.DR["autho_group"] = this.group;
                            table3.DR["autho_menu"] = row2["autho_menu"].ToString();
                            table3.DR["autho_trustee"] = row2["autho_trustee"].ToString();
                            table3.DR["Checksum"] = table3.Checksum(table3.DR);
                            table3.DT.Rows.Add(table3.DR);
                            table3.Save();
                            WBTable table5 = new WBTable();
                            table5.OpenTable("wb_authorization", str4, WBData.conn);
                            this.logKey = table5.DT.Rows[0]["uniq"].ToString();
                            table5.Dispose();
                            string[] textArray10 = new string[] { this.changeReason, " (triggered from ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                            this.reason = string.Concat(textArray10);
                            string[] textArray11 = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] textArray12 = new string[] { "ADD", WBUser.UserID, this.reason };
                            Program.updateLogHeader_otherLocations("wb_authorization", this.logKey, textArray11, textArray12, coy, loc);
                        }
                        this.dgvCopy.Rows[num].Cells["remark"].Value = "Group '" + this.group + "' has been edited successfully.";
                    }
                }
                num++;
            }
        }

        private void FormCopyUserAutho_Load(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_warning_trace", "SELECT coy, location_code FROM wb_location WHERE 1=1 ORDER BY coy, location_code", WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                string str = "False";
                if ((row["coy"].ToString() != WBData.sCoyCode) || (row["location_code"].ToString() != WBData.sLocCode))
                {
                    string[] values = new string[] { str, row["coy"].ToString(), row["location_code"].ToString(), "" };
                    this.dgvCopy.Rows.Add(values);
                }
            }
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.Selected = new DataGridViewCheckBoxColumn();
            this.dgvCopy = new DataGridView();
            this.coy_ = new DataGridViewTextBoxColumn();
            this.loc_ = new DataGridViewTextBoxColumn();
            this.remark = new DataGridViewTextBoxColumn();
            this.checkAll = new CheckBox();
            this.buttonProcess = new Button();
            this.buttonCancel = new Button();
            this.label1 = new Label();
            ((ISupportInitialize) this.dgvCopy).BeginInit();
            base.SuspendLayout();
            this.Selected.HeaderText = "Select";
            this.Selected.Name = "Selected";
            this.Selected.Width = 0x2d;
            this.dgvCopy.AllowUserToAddRows = false;
            this.dgvCopy.AllowUserToDeleteRows = false;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgvCopy.ColumnHeadersDefaultCellStyle = style;
            this.dgvCopy.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridViewColumn[] dataGridViewColumns = new DataGridViewColumn[] { this.Selected, this.coy_, this.loc_, this.remark };
            this.dgvCopy.Columns.AddRange(dataGridViewColumns);
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ActiveCaptionText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgvCopy.DefaultCellStyle = style2;
            this.dgvCopy.Location = new Point(12, 0x39);
            this.dgvCopy.Name = "dgvCopy";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgvCopy.RowHeadersDefaultCellStyle = style3;
            this.dgvCopy.Size = new Size(0x254, 260);
            this.dgvCopy.TabIndex = 1;
            this.dgvCopy.CellMouseUp += new DataGridViewCellMouseEventHandler(this.dgvCopy_CellMouseUp);
            this.coy_.HeaderText = "Company Code";
            this.coy_.Name = "coy_";
            this.coy_.ReadOnly = true;
            this.coy_.Width = 70;
            this.loc_.HeaderText = "Location Code";
            this.loc_.Name = "loc_";
            this.loc_.ReadOnly = true;
            this.loc_.Width = 70;
            this.remark.HeaderText = "Remark";
            this.remark.Name = "remark";
            this.remark.ReadOnly = true;
            this.remark.Width = 340;
            this.checkAll.AutoSize = true;
            this.checkAll.Location = new Point(12, 0x22);
            this.checkAll.Name = "checkAll";
            this.checkAll.Size = new Size(70, 0x11);
            this.checkAll.TabIndex = 2;
            this.checkAll.Text = "Select All";
            this.checkAll.UseVisualStyleBackColor = true;
            this.checkAll.CheckedChanged += new EventHandler(this.checkAll_CheckedChanged);
            this.buttonProcess.Location = new Point(0x1aa, 0x147);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(0x54, 0x1f);
            this.buttonProcess.TabIndex = 3;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.buttonCancel.Location = new Point(0x20c, 0x147);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x54, 0x1f);
            this.buttonCancel.TabIndex = 4;
            this.buttonCancel.Text = "Close";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(9, 12);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x6f, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "User will be copied to:";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(620, 370);
            base.ControlBox = false;
            base.Controls.Add(this.label1);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonProcess);
            base.Controls.Add(this.checkAll);
            base.Controls.Add(this.dgvCopy);
            base.Name = "FormCopyUserAutho";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Copy User to Other Locations";
            base.Load += new EventHandler(this.FormCopyUserAutho_Load);
            ((ISupportInitialize) this.dgvCopy).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

