﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormDivisionEntry : Form
    {
        public WBTable zTable;
        public WBTable tblEstate;
        public string pMode;
        public string OldCode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        private IContainer components = null;
        private Button button2;
        private Button button1;
        private TextBox textRemark;
        private TextBox textDivName;
        private Label label2;
        private Label label1;
        private Label label3;
        private TextBox textEstate;
        private Label label4;
        private Button button11;
        private Label labelEStateName;
        public TextBox textDivCode;

        public FormDivisionEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            TextBox[] aText = new TextBox[] { this.textDivCode, this.textDivName };
            if (!Program.CheckEmpty(aText))
            {
                WBTable table = new WBTable();
                string[] textArray1 = new string[] { " and (Estate_Code = '", this.textEstate.Text.Trim(), "') and (division_Code='", this.textDivCode.Text.Trim(), "')" };
                table.OpenTable("wb_division", "Select Uniq From wb_division Where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    Cursor.Current = Cursors.WaitCursor;
                    this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                    if ((this.pMode != "EDIT") || (this.textDivCode.Text.Trim() == this.OldCode.Trim()))
                    {
                        goto TR_0016;
                    }
                    else
                    {
                        table2 = new WBTable();
                        table2.OpenTable("wb_transDivision", "Select uniq From wb_transDivision where " + WBData.CompanyLocation("and (Division_Code='" + this.zTable.DT.Rows[this.nCurrRow]["Division_Code"].ToString() + "')"), WBData.conn);
                        WBTable table3 = new WBTable();
                        table3.OpenTable("wb_block", "Select uniq From wb_block where  " + WBData.CompanyLocation("and (Division_Code='" + this.zTable.DT.Rows[this.nCurrRow]["Division_Code"].ToString() + "')"), WBData.conn);
                        Cursor.Current = Cursors.Default;
                        if ((table2.DT.Rows.Count <= 0) && (table3.DT.Rows.Count <= 0))
                        {
                            goto TR_0017;
                        }
                        else
                        {
                            string[] textArray3 = new string[0x11];
                            textArray3[0] = Resource.Mes_130;
                            textArray3[1] = " ";
                            textArray3[2] = this.OldCode;
                            textArray3[3] = " -> ";
                            textArray3[4] = this.textDivCode.Text;
                            textArray3[5] = "\n\n";
                            textArray3[6] = Resource.Msg_Replace_Warning;
                            textArray3[7] = "  - ";
                            textArray3[8] = table2.DT.Rows.Count.ToString();
                            textArray3[9] = " ";
                            textArray3[10] = Resource.Mes_Records_In_Transaction;
                            textArray3[11] = "\n  - ";
                            textArray3[12] = table3.DT.Rows.Count.ToString();
                            textArray3[13] = " ";
                            textArray3[14] = Resource.Mes_Records_In_Block;
                            textArray3[15] = "\n\n";
                            textArray3[0x10] = Resource.Msg_Continue;
                            if (MessageBox.Show(string.Concat(textArray3), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.ReplaceAll = true;
                                goto TR_0017;
                            }
                            else
                            {
                                this.ReplaceAll = false;
                                this.textDivCode.Focus();
                            }
                        }
                    }
                }
                else
                {
                    table.Dispose();
                    string[] textArray2 = new string[] { Resource.Mes_129, " ", this.textDivCode.Text, " - ", this.textEstate.Text };
                    MessageBox.Show(string.Concat(textArray2));
                    this.textDivCode.Focus();
                }
            }
            return;
        TR_0016:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.Division_002 },
                    textRefNo = { Text = this.textDivCode.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Estate_Code"] = this.textEstate.Text;
            this.zTable.DR["Division_Code"] = this.textDivCode.Text;
            this.zTable.DR["Division_Name"] = this.textDivName.Text;
            this.zTable.DR["Remark"] = this.textRemark.Text;
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    string sqltext = (("SELECT uniq FROM wb_division WHERE " + WBData.CompanyLocation("")) + " AND estate_code = '" + this.textEstate.Text + "'") + " AND division_code = '" + this.textDivCode.Text + "'";
                    WBTable table4 = new WBTable();
                    table4.OpenTable("wb_division", sqltext, WBData.conn);
                    this.logKey = table4.DT.Rows[0]["uniq"].ToString();
                    table4.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_division", this.logKey, logField, logValue);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string[] aField = new string[] { "Division_Code", "Division_Name" };
                string[] aNewValue = new string[] { this.textDivCode.Text, this.textDivName.Text };
                Program.ReplaceAll("wb_transDivision", aField, aNewValue, " Division_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit division master data)");
                string[] textArray8 = new string[] { "Division_Code" };
                string[] textArray9 = new string[] { this.textDivCode.Text };
                Program.ReplaceAll("wb_block", textArray8, textArray9, " Division_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit division master data)");
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            base.Close();
            return;
        TR_0017:
            table2.Dispose();
            goto TR_0016;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            FormEstate estate = new FormEstate {
                pMode = "CHOOSE"
            };
            estate.ShowDialog();
            if (estate.ReturnRow != null)
            {
                this.textEstate.Text = estate.ReturnRow["Estate_Code"].ToString();
                this.labelEStateName.Text = estate.ReturnRow["Estate_Name"].ToString();
                this.textEstate.Focus();
            }
            estate.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormDivisionEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormDivisionEntry_Load(object sender, EventArgs e)
        {
            this.tblEstate = new WBTable();
            this.tblEstate.OpenTable("wb_estate", "Select * From wb_estate", WBData.conn);
            base.KeyPreview = true;
            if (this.pMode == "ADD")
            {
                this.labelEStateName.Text = "";
            }
            else
            {
                this.textDivCode.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Division_Code"].Value.ToString();
                this.OldCode = this.textDivCode.Text;
                this.textDivName.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Division_Name"].Value.ToString();
                this.textRemark.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Remark"].Value.ToString();
                this.textEstate.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Estate_Code"].Value.ToString();
                string[] aField = new string[] { "Estate_Code" };
                string[] aFind = new string[] { this.textEstate.Text };
                DataRow data = this.tblEstate.GetData(aField, aFind);
                if (data != null)
                {
                    this.labelEStateName.Text = data["Estate_Name"].ToString();
                }
                if (this.pMode == "VIEW")
                {
                    foreach (Control control in base.Controls)
                    {
                        control.Enabled = false;
                    }
                    this.button2.Text = Resource.Btn_Close;
                    this.button2.Enabled = true;
                }
            }
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.textRemark = new TextBox();
            this.textDivName = new TextBox();
            this.textDivCode = new TextBox();
            this.label2 = new Label();
            this.label1 = new Label();
            this.label3 = new Label();
            this.textEstate = new TextBox();
            this.label4 = new Label();
            this.button11 = new Button();
            this.labelEStateName = new Label();
            base.SuspendLayout();
            this.button2.Location = new Point(0x1dd, 0x92);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 6;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x17a, 0x92);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 5;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textRemark.Location = new Point(0x61, 0x65);
            this.textRemark.MaxLength = 50;
            this.textRemark.Multiline = true;
            this.textRemark.Name = "textRemark";
            this.textRemark.Size = new Size(0x1c7, 20);
            this.textRemark.TabIndex = 4;
            this.textDivName.Location = new Point(0x61, 0x4b);
            this.textDivName.MaxLength = 50;
            this.textDivName.Name = "textDivName";
            this.textDivName.Size = new Size(0x1c7, 20);
            this.textDivName.TabIndex = 3;
            this.textDivCode.CharacterCasing = CharacterCasing.Upper;
            this.textDivCode.Location = new Point(0x61, 0x31);
            this.textDivCode.MaxLength = 20;
            this.textDivCode.Name = "textDivCode";
            this.textDivCode.Size = new Size(0xa5, 20);
            this.textDivCode.TabIndex = 2;
            this.label2.Location = new Point(11, 0x4e);
            this.label2.Name = "label2";
            this.label2.Size = new Size(80, 13);
            this.label2.TabIndex = 0x29;
            this.label2.Text = "Division Name";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.label1.Location = new Point(11, 0x34);
            this.label1.Name = "label1";
            this.label1.Size = new Size(80, 13);
            this.label1.TabIndex = 40;
            this.label1.Text = "Division Code";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.label3.Location = new Point(11, 0x68);
            this.label3.Name = "label3";
            this.label3.Size = new Size(80, 13);
            this.label3.TabIndex = 0x3a;
            this.label3.Text = "Remark";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.textEstate.CharacterCasing = CharacterCasing.Upper;
            this.textEstate.Location = new Point(0x61, 0x17);
            this.textEstate.MaxLength = 20;
            this.textEstate.Name = "textEstate";
            this.textEstate.ReadOnly = true;
            this.textEstate.Size = new Size(0xa5, 20);
            this.textEstate.TabIndex = 1;
            this.label4.Location = new Point(11, 0x1a);
            this.label4.Name = "label4";
            this.label4.Size = new Size(80, 13);
            this.label4.TabIndex = 60;
            this.label4.Text = "Estate";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            this.button11.Location = new Point(0x109, 0x15);
            this.button11.Margin = new Padding(0);
            this.button11.Name = "button11";
            this.button11.Size = new Size(0x17, 0x17);
            this.button11.TabIndex = 0;
            this.button11.Text = "...";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new EventHandler(this.button11_Click);
            this.labelEStateName.AutoSize = true;
            this.labelEStateName.Location = new Point(0x123, 0x1a);
            this.labelEStateName.Name = "labelEStateName";
            this.labelEStateName.Size = new Size(0x41, 13);
            this.labelEStateName.TabIndex = 0x3e;
            this.labelEStateName.Text = "EstateName";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(580, 0xb9);
            base.ControlBox = false;
            base.Controls.Add(this.labelEStateName);
            base.Controls.Add(this.button11);
            base.Controls.Add(this.textEstate);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textRemark);
            base.Controls.Add(this.textDivName);
            base.Controls.Add(this.textDivCode);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Name = "FormDivisionEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormDivisionEntry";
            base.Load += new EventHandler(this.FormDivisionEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormDivisionEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label4.Text = Resource.Division_001;
            this.label1.Text = Resource.Division_002;
            this.label2.Text = Resource.Division_003;
            this.label3.Text = Resource.Division_004;
            this.button1.Text = Resource.Btn_Save;
            this.button2.Text = Resource.Btn_Cancel;
            this.Text = Resource.Title_Division_Entry;
        }
    }
}

