﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;

    public class FormDeliveryLetterEntry : Form
    {
        public WBTable wbdl = new WBTable();
        public string pMode;
        public int pUniq;
        public int nCurrRow;
        public bool lSave;
        public WBTable Dtable = new WBTable();
        public DataTable TempDT = new DataTable();
        public DataRow TempDR;
        public WBTable tblTruck = new WBTable();
        public WBTable tblDriver = new WBTable();
        private IContainer components = null;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private Panel panel2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        public Label labelNMSupir;
        public TextBox textTruckNo;
        public TextBox textSIM;
        public TextBox textDLN;
        public TextBox textDO;
        public TextBox textSO;
        public TextBox textSAP_DL;
        public DataGridView dataGridView1;
        public Button buttonDelete;
        public Button buttonEdit;
        public Button buttonAdd;
        public Button buttonAdopt;
        public Button buttonSave;
        public Button buttonCancel;

        public FormDeliveryLetterEntry()
        {
            this.InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            FormDLEntryDetail detail = new FormDLEntryDetail {
                sdataGrid = this.dataGridView1,
                pMode = "ADD",
                cSJ_No = this.textDLN.Text
            };
            detail.textItem.Clear();
            detail.textBatch.Clear();
            detail.textQty.Clear();
            detail.textUOM.Clear();
            detail.textQtyInKG.Clear();
            detail.lSave = false;
            detail.ShowDialog();
            if (detail.lSave)
            {
                this.dataGridView1 = detail.sdataGrid;
            }
            detail.Dispose();
        }

        private void buttonAdopt_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                WBSetting.OpenSetting();
                if (WBSAP.connect())
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_ADOPT_DO");
                    WBSAP.rfcFunction.SetValue("VBELN", this.textDLN.Text.Trim());
                    WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                    IRfcTable source = WBSAP.rfcFunction.GetTable("I_RECORD");
                    if (source.GetString("POSNR") == "")
                    {
                        MessageBox.Show("Adopt Failed. No Data From SAP", "F A I L E D", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        string[] textArray1 = new string[12];
                        textArray1[0] = "Item No   : ";
                        textArray1[1] = source.GetString("POSNR").ToString();
                        textArray1[2] = "\rMaterial  : ";
                        textArray1[3] = source.GetString("MATNR").ToString();
                        textArray1[4] = "\rQTY in KG : ";
                        textArray1[5] = source.GetString("LFIMG_KG").ToString();
                        textArray1[6] = "\rQTY DO    : ";
                        textArray1[7] = source.GetString("LFIMG").ToString();
                        textArray1[8] = "\rUNIT      : ";
                        textArray1[9] = source.GetString("VRKME").ToString();
                        textArray1[10] = "\rCUSTOMER  : ";
                        textArray1[11] = source.GetString("KUNNR").ToString();
                        MessageBox.Show(string.Concat(textArray1));
                        this.dataGridView1.Rows.Clear();
                        int num = 0;
                        while (true)
                        {
                            if (num >= source.RowCount)
                            {
                                break;
                            }
                            this.dataGridView1.Rows.Add();
                            this.dataGridView1.Rows[source.CurrentIndex].Cells["coy"].Value = WBData.sCoyCode;
                            this.dataGridView1.Rows[source.CurrentIndex].Cells["Location_Code"].Value = WBData.sLocCode;
                            this.dataGridView1.Rows[source.CurrentIndex].Cells["SJ_No"].Value = this.textDLN.Text;
                            this.dataGridView1.Rows[source.CurrentIndex].Cells["Item_No"].Value = source.GetString("POSNR").ToString();
                            this.dataGridView1.Rows[this.nCurrRow].Cells["Batch_No"].Value = "";
                            this.dataGridView1.Rows[source.CurrentIndex].Cells["Qty"].Value = source.GetString("LFIMG").ToString();
                            this.dataGridView1.Rows[source.CurrentIndex].Cells["UOM"].Value = source.GetString("VRKME").ToString();
                            this.dataGridView1.Rows[source.CurrentIndex].Cells["QtyKG"].Value = source.GetString("LFIMG_KG").ToString();
                            source.Skip<IRfcStructure>(1);
                            num++;
                        }
                    }
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "E R R O R <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), Resource.Mes_Error_With_Spaces + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, Resource.Mes_Error_With_Spaces + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), Resource.Mes_Error_With_Spaces + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, Resource.Mes_Error_With_Spaces + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show("Error " + exception4.ToString(), "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.tblDriver.Dispose();
            this.tblTruck.Dispose();
            base.Close();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            this.nCurrRow = this.dataGridView1.CurrentRow.Index;
            if (MessageBox.Show("Item No. " + this.dataGridView1.Rows[this.nCurrRow].Cells["Item_no"].Value.ToString() + ".\n\n Are you sure to deleted this record ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.dataGridView1.Rows.Remove(this.dataGridView1.CurrentRow);
            }
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                FormDLEntryDetail detail = new FormDLEntryDetail();
                this.nCurrRow = this.dataGridView1.CurrentRow.Index;
                detail.DataDetail = this.Dtable;
                detail.pMode = "EDIT";
                detail.sdataGrid = this.dataGridView1;
                detail.cSJ_No = this.textDLN.Text;
                detail.textItem.Text = this.dataGridView1.Rows[this.nCurrRow].Cells["Item_No"].Value.ToString();
                detail.textBatch.Text = this.dataGridView1.Rows[this.nCurrRow].Cells["Batch_No"].Value.ToString();
                detail.textQty.Text = this.dataGridView1.Rows[this.nCurrRow].Cells["Qty"].Value.ToString();
                detail.textUOM.Text = this.dataGridView1.Rows[this.nCurrRow].Cells["UOM"].Value.ToString();
                detail.textQtyInKG.Text = this.dataGridView1.Rows[this.nCurrRow].Cells["QTYKG"].Value.ToString();
                detail.lSave = false;
                detail.ShowDialog();
                if (detail.lSave)
                {
                    this.dataGridView1 = detail.sdataGrid;
                }
                detail.Dispose();
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            this.nCurrRow = this.wbdl.GetPosRec(this.wbdl.uniq);
            if (this.pMode == "ADD")
            {
                this.wbdl.DR = this.wbdl.DT.NewRow();
            }
            else
            {
                this.wbdl.DR = this.wbdl.DT.Rows[this.nCurrRow];
                this.wbdl.DR.BeginEdit();
            }
            this.wbdl.DR["coy"] = WBData.sCoyCode;
            this.wbdl.DR["Location_Code"] = WBData.sLocCode;
            this.wbdl.DR["Do_No"] = this.textDO.Text;
            this.wbdl.DR["SO_No"] = this.textSO.Text;
            this.wbdl.DR["SJ_No"] = this.textDLN.Text;
            this.wbdl.DR["SJ_No_SAP"] = this.textSAP_DL.Text;
            this.wbdl.DR["Truck_No"] = this.textTruckNo.Text;
            this.wbdl.DR["Driver_Lic"] = this.textSIM.Text;
            this.wbdl.DR["Driver_Name"] = this.labelNMSupir.Text;
            if (this.pMode == "ADD")
            {
                this.wbdl.DT.Rows.Add(this.wbdl.DR);
            }
            else
            {
                this.wbdl.DR.EndEdit();
            }
            this.wbdl.Save();
            this.Dtable.OpenTable("wb_DeliveryLetterD", "Delete from wb_DeliveryLetterD Where " + WBData.CompanyLocation(" and SJ_No = '" + this.textDLN.Text.Trim() + "'"), WBData.conn);
            this.Dtable.OpenTable("wb_DeliveryLetterD", "Select * from wb_DeliveryLetterD Where " + WBData.CompanyLocation(" and SJ_No = '" + this.textDLN.Text.Trim() + "'"), WBData.conn);
            int num = 0;
            while (true)
            {
                if (num >= this.dataGridView1.Rows.Count)
                {
                    this.lSave = true;
                    this.wbdl.Dispose();
                    this.Dtable.Dispose();
                    this.tblDriver.Dispose();
                    this.tblTruck.Dispose();
                    base.Close();
                    return;
                }
                this.Dtable.DR = this.Dtable.DT.NewRow();
                this.Dtable.DR["Coy"] = this.dataGridView1.Rows[num].Cells["Coy"].Value.ToString().Trim();
                this.Dtable.DR["Location_Code"] = this.dataGridView1.Rows[num].Cells["Location_Code"].Value.ToString().Trim();
                this.Dtable.DR["SJ_No"] = this.dataGridView1.Rows[num].Cells["SJ_No"].Value.ToString().Trim();
                this.Dtable.DR["Item_No"] = this.dataGridView1.Rows[num].Cells["Item_No"].Value.ToString().Trim();
                this.Dtable.DR["Batch_No"] = this.dataGridView1.Rows[num].Cells["Batch_No"].Value.ToString().Trim();
                try
                {
                    this.Dtable.DR["QTY"] = Convert.ToInt32(this.dataGridView1.Rows[num].Cells["Qty"].Value.ToString().Trim());
                }
                catch
                {
                }
                this.Dtable.DR["UOM"] = this.dataGridView1.Rows[num].Cells["UOM"].Value.ToString().Trim();
                try
                {
                    this.Dtable.DR["QtyKG"] = Convert.ToInt32(this.dataGridView1.Rows[num].Cells["QtyKG"].Value.ToString().Trim());
                }
                catch
                {
                }
                this.Dtable.DT.Rows.Add(this.Dtable.DR);
                this.Dtable.Save();
                num++;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormDeliveryLetterEntry_Load(object sender, EventArgs e)
        {
            this.tblTruck.OpenTable("wb_truck", "Select * from wb_truck where " + WBData.CompanyLocation(" and Black_List <> 'Y'"), WBData.conn);
            this.tblDriver.OpenTable("wb_driver", "Select * from wb_driver where " + WBData.CompanyLocation(" and Black_List <> 'Y'"), WBData.conn);
            Program.AutoComp(this.tblTruck, "Truck_Number", this.textTruckNo);
            Program.AutoComp(this.tblDriver, "License_No", this.textSIM);
            this.Dtable.OpenTable("wb_DeliveryLetterS", "Select * from wb_DeliveryLetterD Where " + WBData.CompanyLocation(" and SJ_No = '" + this.textDLN.Text.Trim() + "'"), WBData.conn);
            this.TempDT = this.Dtable.DT;
            this.TempDR = this.Dtable.DR;
            int count = this.TempDT.Columns.Count;
            int num2 = this.TempDT.Rows.Count;
            int num4 = 0;
            while (true)
            {
                if (num4 >= count)
                {
                    if (num2 > 0)
                    {
                        this.dataGridView1.Rows.Add(num2);
                    }
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 > (num2 - 1))
                        {
                            this.dataGridView1.Columns["Coy"].Visible = false;
                            this.dataGridView1.Columns["Location_Code"].Visible = false;
                            this.dataGridView1.Columns["SJ_No"].Visible = false;
                            this.dataGridView1.Columns["Item_No"].HeaderText = "No";
                            this.dataGridView1.Columns["Batch_no"].HeaderText = "Batch No";
                            this.dataGridView1.Columns["Qty"].HeaderText = "Quantity";
                            this.dataGridView1.Columns["UOM"].HeaderText = "UOM";
                            this.dataGridView1.Columns["QtyKG"].HeaderText = "Qty in KG";
                            this.dataGridView1.Columns["uniq"].Visible = false;
                            this.label4.Text = this.sapIDSYS + this.label4.Text;
                            return;
                        }
                        num4 = 0;
                        while (true)
                        {
                            if (num4 >= count)
                            {
                                this.dataGridView1.Refresh();
                                num3++;
                                break;
                            }
                            this.dataGridView1.Rows[num3].Cells[num4].Value = this.TempDT.Rows[num3][num4].ToString();
                            num4++;
                        }
                    }
                }
                DataGridViewTextBoxColumn dataGridViewColumn = new DataGridViewTextBoxColumn {
                    Name = this.TempDT.Columns[num4].ColumnName,
                    ReadOnly = true
                };
                this.dataGridView1.Columns.Add(dataGridViewColumn);
                dataGridViewColumn.Dispose();
                num4++;
            }
        }

        private void InitializeComponent()
        {
            this.dataGridView1 = new DataGridView();
            this.panel2 = new Panel();
            this.buttonDelete = new Button();
            this.buttonEdit = new Button();
            this.buttonAdd = new Button();
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.label4 = new Label();
            this.textDLN = new TextBox();
            this.textDO = new TextBox();
            this.textSO = new TextBox();
            this.textSAP_DL = new TextBox();
            this.buttonAdopt = new Button();
            this.buttonSave = new Button();
            this.buttonCancel = new Button();
            this.label5 = new Label();
            this.label6 = new Label();
            this.labelNMSupir = new Label();
            this.textTruckNo = new TextBox();
            this.textSIM = new TextBox();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.panel2.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new Point(0, 0xd5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x223, 0x9f);
            this.dataGridView1.TabIndex = 5;
            this.panel2.Controls.Add(this.buttonDelete);
            this.panel2.Controls.Add(this.buttonEdit);
            this.panel2.Controls.Add(this.buttonAdd);
            this.panel2.Dock = DockStyle.Bottom;
            this.panel2.Location = new Point(0, 0x176);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x223, 0x21);
            this.panel2.TabIndex = 7;
            this.buttonDelete.Location = new Point(0xb3, 4);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new Size(0x4b, 0x17);
            this.buttonDelete.TabIndex = 2;
            this.buttonDelete.Text = "&Delete";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new EventHandler(this.buttonDelete_Click);
            this.buttonEdit.Location = new Point(0x61, 4);
            this.buttonEdit.Name = "buttonEdit";
            this.buttonEdit.Size = new Size(0x4b, 0x17);
            this.buttonEdit.TabIndex = 1;
            this.buttonEdit.Text = "&Edit";
            this.buttonEdit.UseVisualStyleBackColor = true;
            this.buttonEdit.Click += new EventHandler(this.buttonEdit_Click);
            this.buttonAdd.Location = new Point(13, 4);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new Size(0x4b, 0x17);
            this.buttonAdd.TabIndex = 0;
            this.buttonAdd.Text = "&Add";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new EventHandler(this.buttonAdd_Click);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(12, 0x1a);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x5f, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Delivery Letter No.";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(12, 0x35);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x2b, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "DO No.";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(12, 80);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x2a, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "SO No.";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(12, 0x6b);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x63, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = " Delivery Letter";
            this.textDLN.Location = new Point(0x8e, 0x17);
            this.textDLN.Name = "textDLN";
            this.textDLN.Size = new Size(150, 20);
            this.textDLN.TabIndex = 12;
            this.textDO.Location = new Point(0x8e, 50);
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(150, 20);
            this.textDO.TabIndex = 13;
            this.textSO.Location = new Point(0x8e, 0x4d);
            this.textSO.Name = "textSO";
            this.textSO.Size = new Size(150, 20);
            this.textSO.TabIndex = 14;
            this.textSAP_DL.Location = new Point(0x8e, 0x68);
            this.textSAP_DL.Name = "textSAP_DL";
            this.textSAP_DL.Size = new Size(150, 20);
            this.textSAP_DL.TabIndex = 15;
            this.buttonAdopt.Location = new Point(0x18b, 0x15);
            this.buttonAdopt.Name = "buttonAdopt";
            this.buttonAdopt.Size = new Size(0x4b, 0x29);
            this.buttonAdopt.TabIndex = 0x10;
            this.buttonAdopt.Text = "&Adopt";
            this.buttonAdopt.UseVisualStyleBackColor = true;
            this.buttonAdopt.Click += new EventHandler(this.buttonAdopt_Click);
            this.buttonSave.Location = new Point(0x18b, 0x4b);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x4b, 0x17);
            this.buttonSave.TabIndex = 0x11;
            this.buttonSave.Text = "&Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.buttonCancel.Location = new Point(0x18b, 0x66);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x4b, 0x17);
            this.buttonCancel.TabIndex = 0x12;
            this.buttonCancel.Text = "&Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.label5.AutoSize = true;
            this.label5.Location = new Point(12, 0x86);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x37, 13);
            this.label5.TabIndex = 0x13;
            this.label5.Text = "Truck No.";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(12, 0xa1);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x4b, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "Driver License";
            this.labelNMSupir.AutoSize = true;
            this.labelNMSupir.Location = new Point(0x12a, 0xa1);
            this.labelNMSupir.Name = "labelNMSupir";
            this.labelNMSupir.Size = new Size(0x13, 13);
            this.labelNMSupir.TabIndex = 0x15;
            this.labelNMSupir.Text = "??";
            this.textTruckNo.Location = new Point(0x8e, 0x83);
            this.textTruckNo.Name = "textTruckNo";
            this.textTruckNo.Size = new Size(0x62, 20);
            this.textTruckNo.TabIndex = 0x16;
            this.textTruckNo.Leave += new EventHandler(this.textTruckNo_Leave);
            this.textSIM.Location = new Point(0x8e, 0x9e);
            this.textSIM.Name = "textSIM";
            this.textSIM.Size = new Size(150, 20);
            this.textSIM.TabIndex = 0x17;
            this.textSIM.Leave += new EventHandler(this.textSIM_Leave);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x223, 0x197);
            base.Controls.Add(this.textSIM);
            base.Controls.Add(this.textTruckNo);
            base.Controls.Add(this.labelNMSupir);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.buttonAdopt);
            base.Controls.Add(this.textSAP_DL);
            base.Controls.Add(this.textSO);
            base.Controls.Add(this.textDO);
            base.Controls.Add(this.textDLN);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.dataGridView1);
            base.Name = "FormDeliveryLetterEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Delivery Letter Entry";
            base.Load += new EventHandler(this.FormDeliveryLetterEntry_Load);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.panel2.ResumeLayout(false);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void textSIM_Leave(object sender, EventArgs e)
        {
            this.tblDriver.ReOpen();
            string[] aField = new string[] { "License_no" };
            string[] aFind = new string[] { this.textSIM.Text.Trim() };
            int recNo = this.tblDriver.GetRecNo(aField, aFind);
            if (recNo > -1)
            {
                this.textSIM.Text = this.tblDriver.DT.Rows[recNo]["License_no"].ToString().Trim();
                this.labelNMSupir.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString().Trim();
            }
        }

        private void textTruckNo_Leave(object sender, EventArgs e)
        {
            this.tblTruck.ReOpen();
            string[] aField = new string[] { "Truck_Number" };
            string[] aFind = new string[] { this.textTruckNo.Text.Trim() };
            int recNo = this.tblTruck.GetRecNo(aField, aFind);
            if (recNo > -1)
            {
                this.textTruckNo.Text = this.tblTruck.DT.Rows[recNo]["Truck_Number"].ToString().Trim();
            }
        }
    }
}

