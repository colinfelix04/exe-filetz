﻿namespace WindowsFormsApplication1
{
    using System;
    using System.CodeDom.Compiler;
    using System.Collections;
    using System.ComponentModel;
    using System.ComponentModel.Design;
    using System.Data;
    using System.Diagnostics;
    using System.IO;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;
    using System.Threading;
    using System.Xml;
    using System.Xml.Schema;
    using System.Xml.Serialization;

    [Serializable, DesignerCategory("code"), ToolboxItem(true), XmlSchemaProvider("GetTypedDataSetSchema"), XmlRoot("DataSetBASerahTerimaBarang"), HelpKeyword("vs.data.DataSet")]
    public class DataSetBASerahTerimaBarang : DataSet
    {
        private wb_locationDataTable tablewb_location;
        private wb_contractDataTable tablewb_contract;
        private wb_relationDataTable tablewb_relation;
        private wb_commodityDataTable tablewb_commodity;
        private wb_transactionDataTable tablewb_transaction;
        private wb_companyDataTable tablewb_company;
        private wb_transporterDataTable tablewb_transporter;
        private System.Data.SchemaSerializationMode _schemaSerializationMode;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public DataSetBASerahTerimaBarang()
        {
            this._schemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            base.BeginInit();
            this.InitClass();
            CollectionChangeEventHandler handler = new CollectionChangeEventHandler(this.SchemaChanged);
            base.Tables.CollectionChanged += handler;
            base.Relations.CollectionChanged += handler;
            base.EndInit();
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected DataSetBASerahTerimaBarang(SerializationInfo info, StreamingContext context) : base(info, context, false)
        {
            this._schemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            if (base.IsBinarySerialized(info, context))
            {
                this.InitVars(false);
                CollectionChangeEventHandler handler2 = new CollectionChangeEventHandler(this.SchemaChanged);
                this.Tables.CollectionChanged += handler2;
                this.Relations.CollectionChanged += handler2;
            }
            else
            {
                string s = (string) info.GetValue("XmlSchema", typeof(string));
                if (base.DetermineSchemaSerializationMode(info, context) != System.Data.SchemaSerializationMode.IncludeSchema)
                {
                    base.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
                }
                else
                {
                    DataSet dataSet = new DataSet();
                    dataSet.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
                    if (dataSet.Tables["wb_location"] != null)
                    {
                        base.Tables.Add(new wb_locationDataTable(dataSet.Tables["wb_location"]));
                    }
                    if (dataSet.Tables["wb_contract"] != null)
                    {
                        base.Tables.Add(new wb_contractDataTable(dataSet.Tables["wb_contract"]));
                    }
                    if (dataSet.Tables["wb_relation"] != null)
                    {
                        base.Tables.Add(new wb_relationDataTable(dataSet.Tables["wb_relation"]));
                    }
                    if (dataSet.Tables["wb_commodity"] != null)
                    {
                        base.Tables.Add(new wb_commodityDataTable(dataSet.Tables["wb_commodity"]));
                    }
                    if (dataSet.Tables["wb_transaction"] != null)
                    {
                        base.Tables.Add(new wb_transactionDataTable(dataSet.Tables["wb_transaction"]));
                    }
                    if (dataSet.Tables["wb_company"] != null)
                    {
                        base.Tables.Add(new wb_companyDataTable(dataSet.Tables["wb_company"]));
                    }
                    if (dataSet.Tables["wb_transporter"] != null)
                    {
                        base.Tables.Add(new wb_transporterDataTable(dataSet.Tables["wb_transporter"]));
                    }
                    base.DataSetName = dataSet.DataSetName;
                    base.Prefix = dataSet.Prefix;
                    base.Namespace = dataSet.Namespace;
                    base.Locale = dataSet.Locale;
                    base.CaseSensitive = dataSet.CaseSensitive;
                    base.EnforceConstraints = dataSet.EnforceConstraints;
                    base.Merge(dataSet, false, MissingSchemaAction.Add);
                    this.InitVars();
                }
                base.GetSerializationData(info, context);
                CollectionChangeEventHandler handler = new CollectionChangeEventHandler(this.SchemaChanged);
                base.Tables.CollectionChanged += handler;
                this.Relations.CollectionChanged += handler;
            }
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public override DataSet Clone()
        {
            DataSetBASerahTerimaBarang barang = (DataSetBASerahTerimaBarang) base.Clone();
            barang.InitVars();
            barang.SchemaSerializationMode = this.SchemaSerializationMode;
            return barang;
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override XmlSchema GetSchemaSerializable()
        {
            MemoryStream w = new MemoryStream();
            base.WriteXmlSchema(new XmlTextWriter(w, null));
            w.Position = 0L;
            return XmlSchema.Read(new XmlTextReader(w), null);
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public static XmlSchemaComplexType GetTypedDataSetSchema(XmlSchemaSet xs)
        {
            DataSetBASerahTerimaBarang barang = new DataSetBASerahTerimaBarang();
            XmlSchemaComplexType type = new XmlSchemaComplexType();
            XmlSchemaSequence sequence = new XmlSchemaSequence();
            XmlSchemaAny item = new XmlSchemaAny {
                Namespace = barang.Namespace
            };
            sequence.Items.Add(item);
            type.Particle = sequence;
            XmlSchema schemaSerializable = barang.GetSchemaSerializable();
            if (xs.Contains(schemaSerializable.TargetNamespace))
            {
                MemoryStream stream = new MemoryStream();
                MemoryStream stream2 = new MemoryStream();
                try
                {
                    XmlSchema current = null;
                    schemaSerializable.Write(stream);
                    IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                    while (true)
                    {
                        if (!enumerator.MoveNext())
                        {
                            break;
                        }
                        current = (XmlSchema) enumerator.Current;
                        stream2.SetLength(0L);
                        current.Write(stream2);
                        if (stream.Length == stream2.Length)
                        {
                            stream.Position = 0L;
                            stream2.Position = 0L;
                            while (true)
                            {
                                if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                {
                                    continue;
                                }
                                if (stream.Position != stream.Length)
                                {
                                    break;
                                }
                                return type;
                            }
                        }
                    }
                }
                finally
                {
                    if (stream != null)
                    {
                        stream.Close();
                    }
                    if (stream2 != null)
                    {
                        stream2.Close();
                    }
                }
            }
            xs.Add(schemaSerializable);
            return type;
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private void InitClass()
        {
            base.DataSetName = "DataSetBASerahTerimaBarang";
            base.Prefix = "";
            base.Namespace = "http://tempuri.org/DataSetBASerahTerimaBarang.xsd";
            base.EnforceConstraints = true;
            this.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            this.tablewb_location = new wb_locationDataTable();
            base.Tables.Add(this.tablewb_location);
            this.tablewb_contract = new wb_contractDataTable();
            base.Tables.Add(this.tablewb_contract);
            this.tablewb_relation = new wb_relationDataTable();
            base.Tables.Add(this.tablewb_relation);
            this.tablewb_commodity = new wb_commodityDataTable();
            base.Tables.Add(this.tablewb_commodity);
            this.tablewb_transaction = new wb_transactionDataTable();
            base.Tables.Add(this.tablewb_transaction);
            this.tablewb_company = new wb_companyDataTable();
            base.Tables.Add(this.tablewb_company);
            this.tablewb_transporter = new wb_transporterDataTable();
            base.Tables.Add(this.tablewb_transporter);
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override void InitializeDerivedDataSet()
        {
            base.BeginInit();
            this.InitClass();
            base.EndInit();
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        internal void InitVars()
        {
            this.InitVars(true);
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        internal void InitVars(bool initTable)
        {
            this.tablewb_location = (wb_locationDataTable) base.Tables["wb_location"];
            if (initTable && (this.tablewb_location != null))
            {
                this.tablewb_location.InitVars();
            }
            this.tablewb_contract = (wb_contractDataTable) base.Tables["wb_contract"];
            if (initTable && (this.tablewb_contract != null))
            {
                this.tablewb_contract.InitVars();
            }
            this.tablewb_relation = (wb_relationDataTable) base.Tables["wb_relation"];
            if (initTable && (this.tablewb_relation != null))
            {
                this.tablewb_relation.InitVars();
            }
            this.tablewb_commodity = (wb_commodityDataTable) base.Tables["wb_commodity"];
            if (initTable && (this.tablewb_commodity != null))
            {
                this.tablewb_commodity.InitVars();
            }
            this.tablewb_transaction = (wb_transactionDataTable) base.Tables["wb_transaction"];
            if (initTable && (this.tablewb_transaction != null))
            {
                this.tablewb_transaction.InitVars();
            }
            this.tablewb_company = (wb_companyDataTable) base.Tables["wb_company"];
            if (initTable && (this.tablewb_company != null))
            {
                this.tablewb_company.InitVars();
            }
            this.tablewb_transporter = (wb_transporterDataTable) base.Tables["wb_transporter"];
            if (initTable && (this.tablewb_transporter != null))
            {
                this.tablewb_transporter.InitVars();
            }
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override void ReadXmlSerializable(XmlReader reader)
        {
            if (base.DetermineSchemaSerializationMode(reader) != System.Data.SchemaSerializationMode.IncludeSchema)
            {
                base.ReadXml(reader);
                this.InitVars();
            }
            else
            {
                this.Reset();
                DataSet dataSet = new DataSet();
                dataSet.ReadXml(reader);
                if (dataSet.Tables["wb_location"] != null)
                {
                    base.Tables.Add(new wb_locationDataTable(dataSet.Tables["wb_location"]));
                }
                if (dataSet.Tables["wb_contract"] != null)
                {
                    base.Tables.Add(new wb_contractDataTable(dataSet.Tables["wb_contract"]));
                }
                if (dataSet.Tables["wb_relation"] != null)
                {
                    base.Tables.Add(new wb_relationDataTable(dataSet.Tables["wb_relation"]));
                }
                if (dataSet.Tables["wb_commodity"] != null)
                {
                    base.Tables.Add(new wb_commodityDataTable(dataSet.Tables["wb_commodity"]));
                }
                if (dataSet.Tables["wb_transaction"] != null)
                {
                    base.Tables.Add(new wb_transactionDataTable(dataSet.Tables["wb_transaction"]));
                }
                if (dataSet.Tables["wb_company"] != null)
                {
                    base.Tables.Add(new wb_companyDataTable(dataSet.Tables["wb_company"]));
                }
                if (dataSet.Tables["wb_transporter"] != null)
                {
                    base.Tables.Add(new wb_transporterDataTable(dataSet.Tables["wb_transporter"]));
                }
                base.DataSetName = dataSet.DataSetName;
                base.Prefix = dataSet.Prefix;
                base.Namespace = dataSet.Namespace;
                base.Locale = dataSet.Locale;
                base.CaseSensitive = dataSet.CaseSensitive;
                base.EnforceConstraints = dataSet.EnforceConstraints;
                base.Merge(dataSet, false, MissingSchemaAction.Add);
                this.InitVars();
            }
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private void SchemaChanged(object sender, CollectionChangeEventArgs e)
        {
            if (e.Action == CollectionChangeAction.Remove)
            {
                this.InitVars();
            }
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override bool ShouldSerializeRelations() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override bool ShouldSerializeTables() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializewb_commodity() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializewb_company() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializewb_contract() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializewb_location() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializewb_relation() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializewb_transaction() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializewb_transporter() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public wb_locationDataTable wb_location =>
            this.tablewb_location;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public wb_contractDataTable wb_contract =>
            this.tablewb_contract;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public wb_relationDataTable wb_relation =>
            this.tablewb_relation;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public wb_commodityDataTable wb_commodity =>
            this.tablewb_commodity;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public wb_transactionDataTable wb_transaction =>
            this.tablewb_transaction;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public wb_companyDataTable wb_company =>
            this.tablewb_company;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public wb_transporterDataTable wb_transporter =>
            this.tablewb_transporter;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public override System.Data.SchemaSerializationMode SchemaSerializationMode
        {
            get => 
                this._schemaSerializationMode;
            set => 
                this._schemaSerializationMode = value;
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataTableCollection Tables =>
            base.Tables;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataRelationCollection Relations =>
            base.Relations;

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class wb_commodityDataTable : TypedTableBase<DataSetBASerahTerimaBarang.wb_commodityRow>
        {
            private DataColumn columnComm_Name;
            private DataColumn columnUnit;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_commodityRowChangeEventHandler wb_commodityRowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_commodityRowChangeEventHandler wb_commodityRowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_commodityRowChangeEventHandler wb_commodityRowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_commodityRowChangeEventHandler wb_commodityRowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_commodityDataTable()
            {
                base.TableName = "wb_commodity";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_commodityDataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected wb_commodityDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Addwb_commodityRow(DataSetBASerahTerimaBarang.wb_commodityRow row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_commodityRow Addwb_commodityRow(string Comm_Name, string Unit)
            {
                DataSetBASerahTerimaBarang.wb_commodityRow row = (DataSetBASerahTerimaBarang.wb_commodityRow) base.NewRow();
                row.ItemArray = new object[] { Comm_Name, Unit };
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSetBASerahTerimaBarang.wb_commodityDataTable table = (DataSetBASerahTerimaBarang.wb_commodityDataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSetBASerahTerimaBarang.wb_commodityDataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSetBASerahTerimaBarang.wb_commodityRow);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSetBASerahTerimaBarang barang = new DataSetBASerahTerimaBarang();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = barang.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "wb_commodityDataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = barang.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnComm_Name = new DataColumn("Comm_Name", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnComm_Name);
                this.columnUnit = new DataColumn("Unit", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnUnit);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnComm_Name = base.Columns["Comm_Name"];
                this.columnUnit = base.Columns["Unit"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSetBASerahTerimaBarang.wb_commodityRow(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_commodityRow Newwb_commodityRow() => 
                (DataSetBASerahTerimaBarang.wb_commodityRow) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.wb_commodityRowChanged != null)
                {
                    this.wb_commodityRowChanged(this, new DataSetBASerahTerimaBarang.wb_commodityRowChangeEvent((DataSetBASerahTerimaBarang.wb_commodityRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.wb_commodityRowChanging != null)
                {
                    this.wb_commodityRowChanging(this, new DataSetBASerahTerimaBarang.wb_commodityRowChangeEvent((DataSetBASerahTerimaBarang.wb_commodityRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.wb_commodityRowDeleted != null)
                {
                    this.wb_commodityRowDeleted(this, new DataSetBASerahTerimaBarang.wb_commodityRowChangeEvent((DataSetBASerahTerimaBarang.wb_commodityRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.wb_commodityRowDeleting != null)
                {
                    this.wb_commodityRowDeleting(this, new DataSetBASerahTerimaBarang.wb_commodityRowChangeEvent((DataSetBASerahTerimaBarang.wb_commodityRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Removewb_commodityRow(DataSetBASerahTerimaBarang.wb_commodityRow row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn Comm_NameColumn =>
                this.columnComm_Name;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn UnitColumn =>
                this.columnUnit;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_commodityRow this[int index] =>
                (DataSetBASerahTerimaBarang.wb_commodityRow) base.Rows[index];
        }

        public class wb_commodityRow : DataRow
        {
            private DataSetBASerahTerimaBarang.wb_commodityDataTable tablewb_commodity;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_commodityRow(DataRowBuilder rb) : base(rb)
            {
                this.tablewb_commodity = (DataSetBASerahTerimaBarang.wb_commodityDataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsComm_NameNull() => 
                base.IsNull(this.tablewb_commodity.Comm_NameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsUnitNull() => 
                base.IsNull(this.tablewb_commodity.UnitColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetComm_NameNull()
            {
                base[this.tablewb_commodity.Comm_NameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetUnitNull()
            {
                base[this.tablewb_commodity.UnitColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string Comm_Name
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_commodity.Comm_NameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Comm_Name' in table 'wb_commodity' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_commodity.Comm_NameColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string Unit
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_commodity.UnitColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Unit' in table 'wb_commodity' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_commodity.UnitColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class wb_commodityRowChangeEvent : EventArgs
        {
            private DataSetBASerahTerimaBarang.wb_commodityRow eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_commodityRowChangeEvent(DataSetBASerahTerimaBarang.wb_commodityRow row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_commodityRow Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void wb_commodityRowChangeEventHandler(object sender, DataSetBASerahTerimaBarang.wb_commodityRowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class wb_companyDataTable : TypedTableBase<DataSetBASerahTerimaBarang.wb_companyRow>
        {
            private DataColumn columnCoy_Name;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_companyRowChangeEventHandler wb_companyRowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_companyRowChangeEventHandler wb_companyRowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_companyRowChangeEventHandler wb_companyRowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_companyRowChangeEventHandler wb_companyRowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_companyDataTable()
            {
                base.TableName = "wb_company";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_companyDataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected wb_companyDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_companyRow Addwb_companyRow(string Coy_Name)
            {
                DataSetBASerahTerimaBarang.wb_companyRow row = (DataSetBASerahTerimaBarang.wb_companyRow) base.NewRow();
                row.ItemArray = new object[] { Coy_Name };
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Addwb_companyRow(DataSetBASerahTerimaBarang.wb_companyRow row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSetBASerahTerimaBarang.wb_companyDataTable table = (DataSetBASerahTerimaBarang.wb_companyDataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSetBASerahTerimaBarang.wb_companyDataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSetBASerahTerimaBarang.wb_companyRow);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSetBASerahTerimaBarang barang = new DataSetBASerahTerimaBarang();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = barang.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "wb_companyDataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = barang.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnCoy_Name = new DataColumn("Coy_Name", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnCoy_Name);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnCoy_Name = base.Columns["Coy_Name"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSetBASerahTerimaBarang.wb_companyRow(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_companyRow Newwb_companyRow() => 
                (DataSetBASerahTerimaBarang.wb_companyRow) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.wb_companyRowChanged != null)
                {
                    this.wb_companyRowChanged(this, new DataSetBASerahTerimaBarang.wb_companyRowChangeEvent((DataSetBASerahTerimaBarang.wb_companyRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.wb_companyRowChanging != null)
                {
                    this.wb_companyRowChanging(this, new DataSetBASerahTerimaBarang.wb_companyRowChangeEvent((DataSetBASerahTerimaBarang.wb_companyRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.wb_companyRowDeleted != null)
                {
                    this.wb_companyRowDeleted(this, new DataSetBASerahTerimaBarang.wb_companyRowChangeEvent((DataSetBASerahTerimaBarang.wb_companyRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.wb_companyRowDeleting != null)
                {
                    this.wb_companyRowDeleting(this, new DataSetBASerahTerimaBarang.wb_companyRowChangeEvent((DataSetBASerahTerimaBarang.wb_companyRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Removewb_companyRow(DataSetBASerahTerimaBarang.wb_companyRow row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn Coy_NameColumn =>
                this.columnCoy_Name;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_companyRow this[int index] =>
                (DataSetBASerahTerimaBarang.wb_companyRow) base.Rows[index];
        }

        public class wb_companyRow : DataRow
        {
            private DataSetBASerahTerimaBarang.wb_companyDataTable tablewb_company;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_companyRow(DataRowBuilder rb) : base(rb)
            {
                this.tablewb_company = (DataSetBASerahTerimaBarang.wb_companyDataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsCoy_NameNull() => 
                base.IsNull(this.tablewb_company.Coy_NameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetCoy_NameNull()
            {
                base[this.tablewb_company.Coy_NameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string Coy_Name
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_company.Coy_NameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Coy_Name' in table 'wb_company' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_company.Coy_NameColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class wb_companyRowChangeEvent : EventArgs
        {
            private DataSetBASerahTerimaBarang.wb_companyRow eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_companyRowChangeEvent(DataSetBASerahTerimaBarang.wb_companyRow row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_companyRow Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void wb_companyRowChangeEventHandler(object sender, DataSetBASerahTerimaBarang.wb_companyRowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class wb_contractDataTable : TypedTableBase<DataSetBASerahTerimaBarang.wb_contractRow>
        {
            private DataColumn columnDo_No;
            private DataColumn columnPO;
            private DataColumn columnSO;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_contractRowChangeEventHandler wb_contractRowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_contractRowChangeEventHandler wb_contractRowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_contractRowChangeEventHandler wb_contractRowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_contractRowChangeEventHandler wb_contractRowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_contractDataTable()
            {
                base.TableName = "wb_contract";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_contractDataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected wb_contractDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Addwb_contractRow(DataSetBASerahTerimaBarang.wb_contractRow row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_contractRow Addwb_contractRow(string Do_No, string PO, string SO)
            {
                DataSetBASerahTerimaBarang.wb_contractRow row = (DataSetBASerahTerimaBarang.wb_contractRow) base.NewRow();
                row.ItemArray = new object[] { Do_No, PO, SO };
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSetBASerahTerimaBarang.wb_contractDataTable table = (DataSetBASerahTerimaBarang.wb_contractDataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSetBASerahTerimaBarang.wb_contractDataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSetBASerahTerimaBarang.wb_contractRow);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSetBASerahTerimaBarang barang = new DataSetBASerahTerimaBarang();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = barang.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "wb_contractDataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = barang.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnDo_No = new DataColumn("Do_No", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnDo_No);
                this.columnPO = new DataColumn("PO", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnPO);
                this.columnSO = new DataColumn("SO", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnSO);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnDo_No = base.Columns["Do_No"];
                this.columnPO = base.Columns["PO"];
                this.columnSO = base.Columns["SO"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSetBASerahTerimaBarang.wb_contractRow(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_contractRow Newwb_contractRow() => 
                (DataSetBASerahTerimaBarang.wb_contractRow) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.wb_contractRowChanged != null)
                {
                    this.wb_contractRowChanged(this, new DataSetBASerahTerimaBarang.wb_contractRowChangeEvent((DataSetBASerahTerimaBarang.wb_contractRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.wb_contractRowChanging != null)
                {
                    this.wb_contractRowChanging(this, new DataSetBASerahTerimaBarang.wb_contractRowChangeEvent((DataSetBASerahTerimaBarang.wb_contractRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.wb_contractRowDeleted != null)
                {
                    this.wb_contractRowDeleted(this, new DataSetBASerahTerimaBarang.wb_contractRowChangeEvent((DataSetBASerahTerimaBarang.wb_contractRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.wb_contractRowDeleting != null)
                {
                    this.wb_contractRowDeleting(this, new DataSetBASerahTerimaBarang.wb_contractRowChangeEvent((DataSetBASerahTerimaBarang.wb_contractRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Removewb_contractRow(DataSetBASerahTerimaBarang.wb_contractRow row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn Do_NoColumn =>
                this.columnDo_No;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn POColumn =>
                this.columnPO;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn SOColumn =>
                this.columnSO;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_contractRow this[int index] =>
                (DataSetBASerahTerimaBarang.wb_contractRow) base.Rows[index];
        }

        public class wb_contractRow : DataRow
        {
            private DataSetBASerahTerimaBarang.wb_contractDataTable tablewb_contract;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_contractRow(DataRowBuilder rb) : base(rb)
            {
                this.tablewb_contract = (DataSetBASerahTerimaBarang.wb_contractDataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsDo_NoNull() => 
                base.IsNull(this.tablewb_contract.Do_NoColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsPONull() => 
                base.IsNull(this.tablewb_contract.POColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsSONull() => 
                base.IsNull(this.tablewb_contract.SOColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetDo_NoNull()
            {
                base[this.tablewb_contract.Do_NoColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetPONull()
            {
                base[this.tablewb_contract.POColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetSONull()
            {
                base[this.tablewb_contract.SOColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string Do_No
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_contract.Do_NoColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Do_No' in table 'wb_contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_contract.Do_NoColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string PO
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_contract.POColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'PO' in table 'wb_contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_contract.POColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string SO
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_contract.SOColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'SO' in table 'wb_contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_contract.SOColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class wb_contractRowChangeEvent : EventArgs
        {
            private DataSetBASerahTerimaBarang.wb_contractRow eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_contractRowChangeEvent(DataSetBASerahTerimaBarang.wb_contractRow row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_contractRow Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void wb_contractRowChangeEventHandler(object sender, DataSetBASerahTerimaBarang.wb_contractRowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class wb_locationDataTable : TypedTableBase<DataSetBASerahTerimaBarang.wb_locationRow>
        {
            private DataColumn columnCoy_Addr1;
            private DataColumn columnCoy_Addr2;
            private DataColumn columnCoy_Addr3;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_locationRowChangeEventHandler wb_locationRowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_locationRowChangeEventHandler wb_locationRowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_locationRowChangeEventHandler wb_locationRowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_locationRowChangeEventHandler wb_locationRowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_locationDataTable()
            {
                base.TableName = "wb_location";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_locationDataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected wb_locationDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Addwb_locationRow(DataSetBASerahTerimaBarang.wb_locationRow row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_locationRow Addwb_locationRow(string Coy_Addr1, string Coy_Addr2, string Coy_Addr3)
            {
                DataSetBASerahTerimaBarang.wb_locationRow row = (DataSetBASerahTerimaBarang.wb_locationRow) base.NewRow();
                row.ItemArray = new object[] { Coy_Addr1, Coy_Addr2, Coy_Addr3 };
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSetBASerahTerimaBarang.wb_locationDataTable table = (DataSetBASerahTerimaBarang.wb_locationDataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSetBASerahTerimaBarang.wb_locationDataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSetBASerahTerimaBarang.wb_locationRow);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSetBASerahTerimaBarang barang = new DataSetBASerahTerimaBarang();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = barang.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "wb_locationDataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = barang.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnCoy_Addr1 = new DataColumn("Coy_Addr1", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnCoy_Addr1);
                this.columnCoy_Addr2 = new DataColumn("Coy_Addr2", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnCoy_Addr2);
                this.columnCoy_Addr3 = new DataColumn("Coy_Addr3", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnCoy_Addr3);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnCoy_Addr1 = base.Columns["Coy_Addr1"];
                this.columnCoy_Addr2 = base.Columns["Coy_Addr2"];
                this.columnCoy_Addr3 = base.Columns["Coy_Addr3"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSetBASerahTerimaBarang.wb_locationRow(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_locationRow Newwb_locationRow() => 
                (DataSetBASerahTerimaBarang.wb_locationRow) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.wb_locationRowChanged != null)
                {
                    this.wb_locationRowChanged(this, new DataSetBASerahTerimaBarang.wb_locationRowChangeEvent((DataSetBASerahTerimaBarang.wb_locationRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.wb_locationRowChanging != null)
                {
                    this.wb_locationRowChanging(this, new DataSetBASerahTerimaBarang.wb_locationRowChangeEvent((DataSetBASerahTerimaBarang.wb_locationRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.wb_locationRowDeleted != null)
                {
                    this.wb_locationRowDeleted(this, new DataSetBASerahTerimaBarang.wb_locationRowChangeEvent((DataSetBASerahTerimaBarang.wb_locationRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.wb_locationRowDeleting != null)
                {
                    this.wb_locationRowDeleting(this, new DataSetBASerahTerimaBarang.wb_locationRowChangeEvent((DataSetBASerahTerimaBarang.wb_locationRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Removewb_locationRow(DataSetBASerahTerimaBarang.wb_locationRow row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn Coy_Addr1Column =>
                this.columnCoy_Addr1;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn Coy_Addr2Column =>
                this.columnCoy_Addr2;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn Coy_Addr3Column =>
                this.columnCoy_Addr3;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_locationRow this[int index] =>
                (DataSetBASerahTerimaBarang.wb_locationRow) base.Rows[index];
        }

        public class wb_locationRow : DataRow
        {
            private DataSetBASerahTerimaBarang.wb_locationDataTable tablewb_location;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_locationRow(DataRowBuilder rb) : base(rb)
            {
                this.tablewb_location = (DataSetBASerahTerimaBarang.wb_locationDataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsCoy_Addr1Null() => 
                base.IsNull(this.tablewb_location.Coy_Addr1Column);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsCoy_Addr2Null() => 
                base.IsNull(this.tablewb_location.Coy_Addr2Column);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsCoy_Addr3Null() => 
                base.IsNull(this.tablewb_location.Coy_Addr3Column);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetCoy_Addr1Null()
            {
                base[this.tablewb_location.Coy_Addr1Column] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetCoy_Addr2Null()
            {
                base[this.tablewb_location.Coy_Addr2Column] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetCoy_Addr3Null()
            {
                base[this.tablewb_location.Coy_Addr3Column] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string Coy_Addr1
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_location.Coy_Addr1Column];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Coy_Addr1' in table 'wb_location' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_location.Coy_Addr1Column] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string Coy_Addr2
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_location.Coy_Addr2Column];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Coy_Addr2' in table 'wb_location' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_location.Coy_Addr2Column] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string Coy_Addr3
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_location.Coy_Addr3Column];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Coy_Addr3' in table 'wb_location' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_location.Coy_Addr3Column] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class wb_locationRowChangeEvent : EventArgs
        {
            private DataSetBASerahTerimaBarang.wb_locationRow eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_locationRowChangeEvent(DataSetBASerahTerimaBarang.wb_locationRow row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_locationRow Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void wb_locationRowChangeEventHandler(object sender, DataSetBASerahTerimaBarang.wb_locationRowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class wb_relationDataTable : TypedTableBase<DataSetBASerahTerimaBarang.wb_relationRow>
        {
            private DataColumn columnRelation_Name;
            private DataColumn columnAddress;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_relationRowChangeEventHandler wb_relationRowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_relationRowChangeEventHandler wb_relationRowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_relationRowChangeEventHandler wb_relationRowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_relationRowChangeEventHandler wb_relationRowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_relationDataTable()
            {
                base.TableName = "wb_relation";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_relationDataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected wb_relationDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Addwb_relationRow(DataSetBASerahTerimaBarang.wb_relationRow row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_relationRow Addwb_relationRow(string Relation_Name, string Address)
            {
                DataSetBASerahTerimaBarang.wb_relationRow row = (DataSetBASerahTerimaBarang.wb_relationRow) base.NewRow();
                row.ItemArray = new object[] { Relation_Name, Address };
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSetBASerahTerimaBarang.wb_relationDataTable table = (DataSetBASerahTerimaBarang.wb_relationDataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSetBASerahTerimaBarang.wb_relationDataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSetBASerahTerimaBarang.wb_relationRow);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSetBASerahTerimaBarang barang = new DataSetBASerahTerimaBarang();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = barang.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "wb_relationDataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = barang.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnRelation_Name = new DataColumn("Relation_Name", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnRelation_Name);
                this.columnAddress = new DataColumn("Address", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnAddress);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnRelation_Name = base.Columns["Relation_Name"];
                this.columnAddress = base.Columns["Address"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSetBASerahTerimaBarang.wb_relationRow(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_relationRow Newwb_relationRow() => 
                (DataSetBASerahTerimaBarang.wb_relationRow) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.wb_relationRowChanged != null)
                {
                    this.wb_relationRowChanged(this, new DataSetBASerahTerimaBarang.wb_relationRowChangeEvent((DataSetBASerahTerimaBarang.wb_relationRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.wb_relationRowChanging != null)
                {
                    this.wb_relationRowChanging(this, new DataSetBASerahTerimaBarang.wb_relationRowChangeEvent((DataSetBASerahTerimaBarang.wb_relationRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.wb_relationRowDeleted != null)
                {
                    this.wb_relationRowDeleted(this, new DataSetBASerahTerimaBarang.wb_relationRowChangeEvent((DataSetBASerahTerimaBarang.wb_relationRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.wb_relationRowDeleting != null)
                {
                    this.wb_relationRowDeleting(this, new DataSetBASerahTerimaBarang.wb_relationRowChangeEvent((DataSetBASerahTerimaBarang.wb_relationRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Removewb_relationRow(DataSetBASerahTerimaBarang.wb_relationRow row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn Relation_NameColumn =>
                this.columnRelation_Name;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn AddressColumn =>
                this.columnAddress;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_relationRow this[int index] =>
                (DataSetBASerahTerimaBarang.wb_relationRow) base.Rows[index];
        }

        public class wb_relationRow : DataRow
        {
            private DataSetBASerahTerimaBarang.wb_relationDataTable tablewb_relation;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_relationRow(DataRowBuilder rb) : base(rb)
            {
                this.tablewb_relation = (DataSetBASerahTerimaBarang.wb_relationDataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsAddressNull() => 
                base.IsNull(this.tablewb_relation.AddressColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsRelation_NameNull() => 
                base.IsNull(this.tablewb_relation.Relation_NameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetAddressNull()
            {
                base[this.tablewb_relation.AddressColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetRelation_NameNull()
            {
                base[this.tablewb_relation.Relation_NameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string Relation_Name
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_relation.Relation_NameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Relation_Name' in table 'wb_relation' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_relation.Relation_NameColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string Address
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_relation.AddressColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Address' in table 'wb_relation' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_relation.AddressColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class wb_relationRowChangeEvent : EventArgs
        {
            private DataSetBASerahTerimaBarang.wb_relationRow eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_relationRowChangeEvent(DataSetBASerahTerimaBarang.wb_relationRow row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_relationRow Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void wb_relationRowChangeEventHandler(object sender, DataSetBASerahTerimaBarang.wb_relationRowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class wb_transactionDataTable : TypedTableBase<DataSetBASerahTerimaBarang.wb_transactionRow>
        {
            private DataColumn columnTruck_Number;
            private DataColumn columnNet;
            private DataColumn columnReport_Date;
            private DataColumn columnDelivery_Date;
            private DataColumn columnnet_estate;
            private DataColumn columnLOADING_QTY;
            private DataColumn columnLOADING_QTY_OPW;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_transactionRowChangeEventHandler wb_transactionRowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_transactionRowChangeEventHandler wb_transactionRowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_transactionRowChangeEventHandler wb_transactionRowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_transactionRowChangeEventHandler wb_transactionRowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_transactionDataTable()
            {
                base.TableName = "wb_transaction";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_transactionDataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected wb_transactionDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Addwb_transactionRow(DataSetBASerahTerimaBarang.wb_transactionRow row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_transactionRow Addwb_transactionRow(string Truck_Number, double Net, string Report_Date, string Delivery_Date, double net_estate, double LOADING_QTY, double LOADING_QTY_OPW)
            {
                DataSetBASerahTerimaBarang.wb_transactionRow row = (DataSetBASerahTerimaBarang.wb_transactionRow) base.NewRow();
                row.ItemArray = new object[] { Truck_Number, Net, Report_Date, Delivery_Date, net_estate, LOADING_QTY, LOADING_QTY_OPW };
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSetBASerahTerimaBarang.wb_transactionDataTable table = (DataSetBASerahTerimaBarang.wb_transactionDataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSetBASerahTerimaBarang.wb_transactionDataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSetBASerahTerimaBarang.wb_transactionRow);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSetBASerahTerimaBarang barang = new DataSetBASerahTerimaBarang();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = barang.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "wb_transactionDataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = barang.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnTruck_Number = new DataColumn("Truck_Number", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnTruck_Number);
                this.columnNet = new DataColumn("Net", typeof(double), null, MappingType.Element);
                base.Columns.Add(this.columnNet);
                this.columnReport_Date = new DataColumn("Report_Date", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnReport_Date);
                this.columnDelivery_Date = new DataColumn("Delivery_Date", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnDelivery_Date);
                this.columnnet_estate = new DataColumn("net_estate", typeof(double), null, MappingType.Element);
                base.Columns.Add(this.columnnet_estate);
                this.columnLOADING_QTY = new DataColumn("LOADING_QTY", typeof(double), null, MappingType.Element);
                base.Columns.Add(this.columnLOADING_QTY);
                this.columnLOADING_QTY_OPW = new DataColumn("LOADING_QTY_OPW", typeof(double), null, MappingType.Element);
                base.Columns.Add(this.columnLOADING_QTY_OPW);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnTruck_Number = base.Columns["Truck_Number"];
                this.columnNet = base.Columns["Net"];
                this.columnReport_Date = base.Columns["Report_Date"];
                this.columnDelivery_Date = base.Columns["Delivery_Date"];
                this.columnnet_estate = base.Columns["net_estate"];
                this.columnLOADING_QTY = base.Columns["LOADING_QTY"];
                this.columnLOADING_QTY_OPW = base.Columns["LOADING_QTY_OPW"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSetBASerahTerimaBarang.wb_transactionRow(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_transactionRow Newwb_transactionRow() => 
                (DataSetBASerahTerimaBarang.wb_transactionRow) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.wb_transactionRowChanged != null)
                {
                    this.wb_transactionRowChanged(this, new DataSetBASerahTerimaBarang.wb_transactionRowChangeEvent((DataSetBASerahTerimaBarang.wb_transactionRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.wb_transactionRowChanging != null)
                {
                    this.wb_transactionRowChanging(this, new DataSetBASerahTerimaBarang.wb_transactionRowChangeEvent((DataSetBASerahTerimaBarang.wb_transactionRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.wb_transactionRowDeleted != null)
                {
                    this.wb_transactionRowDeleted(this, new DataSetBASerahTerimaBarang.wb_transactionRowChangeEvent((DataSetBASerahTerimaBarang.wb_transactionRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.wb_transactionRowDeleting != null)
                {
                    this.wb_transactionRowDeleting(this, new DataSetBASerahTerimaBarang.wb_transactionRowChangeEvent((DataSetBASerahTerimaBarang.wb_transactionRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Removewb_transactionRow(DataSetBASerahTerimaBarang.wb_transactionRow row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn Truck_NumberColumn =>
                this.columnTruck_Number;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn NetColumn =>
                this.columnNet;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn Report_DateColumn =>
                this.columnReport_Date;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn Delivery_DateColumn =>
                this.columnDelivery_Date;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn net_estateColumn =>
                this.columnnet_estate;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn LOADING_QTYColumn =>
                this.columnLOADING_QTY;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn LOADING_QTY_OPWColumn =>
                this.columnLOADING_QTY_OPW;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_transactionRow this[int index] =>
                (DataSetBASerahTerimaBarang.wb_transactionRow) base.Rows[index];
        }

        public class wb_transactionRow : DataRow
        {
            private DataSetBASerahTerimaBarang.wb_transactionDataTable tablewb_transaction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_transactionRow(DataRowBuilder rb) : base(rb)
            {
                this.tablewb_transaction = (DataSetBASerahTerimaBarang.wb_transactionDataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsDelivery_DateNull() => 
                base.IsNull(this.tablewb_transaction.Delivery_DateColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsLOADING_QTY_OPWNull() => 
                base.IsNull(this.tablewb_transaction.LOADING_QTY_OPWColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsLOADING_QTYNull() => 
                base.IsNull(this.tablewb_transaction.LOADING_QTYColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isnet_estateNull() => 
                base.IsNull(this.tablewb_transaction.net_estateColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsNetNull() => 
                base.IsNull(this.tablewb_transaction.NetColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsReport_DateNull() => 
                base.IsNull(this.tablewb_transaction.Report_DateColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsTruck_NumberNull() => 
                base.IsNull(this.tablewb_transaction.Truck_NumberColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetDelivery_DateNull()
            {
                base[this.tablewb_transaction.Delivery_DateColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetLOADING_QTY_OPWNull()
            {
                base[this.tablewb_transaction.LOADING_QTY_OPWColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetLOADING_QTYNull()
            {
                base[this.tablewb_transaction.LOADING_QTYColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setnet_estateNull()
            {
                base[this.tablewb_transaction.net_estateColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetNetNull()
            {
                base[this.tablewb_transaction.NetColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetReport_DateNull()
            {
                base[this.tablewb_transaction.Report_DateColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetTruck_NumberNull()
            {
                base[this.tablewb_transaction.Truck_NumberColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string Truck_Number
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_transaction.Truck_NumberColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Truck_Number' in table 'wb_transaction' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_transaction.Truck_NumberColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public double Net
            {
                get
                {
                    double num;
                    try
                    {
                        num = (double) base[this.tablewb_transaction.NetColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Net' in table 'wb_transaction' is DBNull.", exception);
                    }
                    return num;
                }
                set => 
                    base[this.tablewb_transaction.NetColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string Report_Date
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_transaction.Report_DateColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Report_Date' in table 'wb_transaction' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_transaction.Report_DateColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string Delivery_Date
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_transaction.Delivery_DateColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Delivery_Date' in table 'wb_transaction' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_transaction.Delivery_DateColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public double net_estate
            {
                get
                {
                    double num;
                    try
                    {
                        num = (double) base[this.tablewb_transaction.net_estateColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'net_estate' in table 'wb_transaction' is DBNull.", exception);
                    }
                    return num;
                }
                set => 
                    base[this.tablewb_transaction.net_estateColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public double LOADING_QTY
            {
                get
                {
                    double num;
                    try
                    {
                        num = (double) base[this.tablewb_transaction.LOADING_QTYColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'LOADING_QTY' in table 'wb_transaction' is DBNull.", exception);
                    }
                    return num;
                }
                set => 
                    base[this.tablewb_transaction.LOADING_QTYColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public double LOADING_QTY_OPW
            {
                get
                {
                    double num;
                    try
                    {
                        num = (double) base[this.tablewb_transaction.LOADING_QTY_OPWColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'LOADING_QTY_OPW' in table 'wb_transaction' is DBNull.", exception);
                    }
                    return num;
                }
                set => 
                    base[this.tablewb_transaction.LOADING_QTY_OPWColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class wb_transactionRowChangeEvent : EventArgs
        {
            private DataSetBASerahTerimaBarang.wb_transactionRow eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_transactionRowChangeEvent(DataSetBASerahTerimaBarang.wb_transactionRow row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_transactionRow Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void wb_transactionRowChangeEventHandler(object sender, DataSetBASerahTerimaBarang.wb_transactionRowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class wb_transporterDataTable : TypedTableBase<DataSetBASerahTerimaBarang.wb_transporterRow>
        {
            private DataColumn columnTransporter_Name;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_transporterRowChangeEventHandler wb_transporterRowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_transporterRowChangeEventHandler wb_transporterRowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_transporterRowChangeEventHandler wb_transporterRowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetBASerahTerimaBarang.wb_transporterRowChangeEventHandler wb_transporterRowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_transporterDataTable()
            {
                base.TableName = "wb_transporter";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_transporterDataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected wb_transporterDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_transporterRow Addwb_transporterRow(string Transporter_Name)
            {
                DataSetBASerahTerimaBarang.wb_transporterRow row = (DataSetBASerahTerimaBarang.wb_transporterRow) base.NewRow();
                row.ItemArray = new object[] { Transporter_Name };
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Addwb_transporterRow(DataSetBASerahTerimaBarang.wb_transporterRow row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSetBASerahTerimaBarang.wb_transporterDataTable table = (DataSetBASerahTerimaBarang.wb_transporterDataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSetBASerahTerimaBarang.wb_transporterDataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSetBASerahTerimaBarang.wb_transporterRow);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSetBASerahTerimaBarang barang = new DataSetBASerahTerimaBarang();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = barang.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "wb_transporterDataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = barang.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnTransporter_Name = new DataColumn("Transporter_Name", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnTransporter_Name);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnTransporter_Name = base.Columns["Transporter_Name"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSetBASerahTerimaBarang.wb_transporterRow(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_transporterRow Newwb_transporterRow() => 
                (DataSetBASerahTerimaBarang.wb_transporterRow) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.wb_transporterRowChanged != null)
                {
                    this.wb_transporterRowChanged(this, new DataSetBASerahTerimaBarang.wb_transporterRowChangeEvent((DataSetBASerahTerimaBarang.wb_transporterRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.wb_transporterRowChanging != null)
                {
                    this.wb_transporterRowChanging(this, new DataSetBASerahTerimaBarang.wb_transporterRowChangeEvent((DataSetBASerahTerimaBarang.wb_transporterRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.wb_transporterRowDeleted != null)
                {
                    this.wb_transporterRowDeleted(this, new DataSetBASerahTerimaBarang.wb_transporterRowChangeEvent((DataSetBASerahTerimaBarang.wb_transporterRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.wb_transporterRowDeleting != null)
                {
                    this.wb_transporterRowDeleting(this, new DataSetBASerahTerimaBarang.wb_transporterRowChangeEvent((DataSetBASerahTerimaBarang.wb_transporterRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Removewb_transporterRow(DataSetBASerahTerimaBarang.wb_transporterRow row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn Transporter_NameColumn =>
                this.columnTransporter_Name;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_transporterRow this[int index] =>
                (DataSetBASerahTerimaBarang.wb_transporterRow) base.Rows[index];
        }

        public class wb_transporterRow : DataRow
        {
            private DataSetBASerahTerimaBarang.wb_transporterDataTable tablewb_transporter;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal wb_transporterRow(DataRowBuilder rb) : base(rb)
            {
                this.tablewb_transporter = (DataSetBASerahTerimaBarang.wb_transporterDataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsTransporter_NameNull() => 
                base.IsNull(this.tablewb_transporter.Transporter_NameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetTransporter_NameNull()
            {
                base[this.tablewb_transporter.Transporter_NameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string Transporter_Name
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tablewb_transporter.Transporter_NameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'Transporter_Name' in table 'wb_transporter' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tablewb_transporter.Transporter_NameColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class wb_transporterRowChangeEvent : EventArgs
        {
            private DataSetBASerahTerimaBarang.wb_transporterRow eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public wb_transporterRowChangeEvent(DataSetBASerahTerimaBarang.wb_transporterRow row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetBASerahTerimaBarang.wb_transporterRow Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void wb_transporterRowChangeEventHandler(object sender, DataSetBASerahTerimaBarang.wb_transporterRowChangeEvent e);
    }
}

