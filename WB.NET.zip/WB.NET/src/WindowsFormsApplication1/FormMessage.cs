﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormMessage : Form
    {
        private IContainer components = null;
        public Label label1;
        private Panel panel1;
        private Panel panel2;
        private Label label2;
        public Timer timer1;
        public ProgressBar progressBar1;
        private Label labelWB;

        public FormMessage()
        {
            this.InitializeComponent();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormMessage_Load(object sender, EventArgs e)
        {
            this.progressBar1.Visible = false;
            this.progressBar1.Maximum = 100;
        }

        private void FormMessage_Shown(object sender, EventArgs e)
        {
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            ComponentResourceManager manager = new ComponentResourceManager(typeof(FormMessage));
            this.label1 = new Label();
            this.panel1 = new Panel();
            this.label2 = new Label();
            this.progressBar1 = new ProgressBar();
            this.panel2 = new Panel();
            this.labelWB = new Label();
            this.timer1 = new Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(0x12, 10);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3d, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Preparing";
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0xa1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x22f, 0x23);
            this.panel1.TabIndex = 1;
            this.label2.AutoSize = true;
            this.label2.Font = new Font("Calibri", 9f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label2.ForeColor = Color.MediumBlue;
            this.label2.Location = new Point(0x1a2, 12);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x75, 14);
            this.label2.TabIndex = 1;
            this.label2.Text = "\x00a9 Wilmar Group 2013";
            this.label2.Click += new EventHandler(this.label2_Click);
            this.progressBar1.Dock = DockStyle.Bottom;
            this.progressBar1.Location = new Point(0, 0x15);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0x22f, 14);
            this.progressBar1.Style = ProgressBarStyle.Continuous;
            this.progressBar1.TabIndex = 2;
            this.progressBar1.UseWaitCursor = true;
            this.panel2.BackgroundImage = (Image) manager.GetObject("panel2.BackgroundImage");
            this.panel2.BackgroundImageLayout = ImageLayout.Stretch;
            this.panel2.Controls.Add(this.labelWB);
            this.panel2.Dock = DockStyle.Fill;
            this.panel2.Location = new Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x22f, 0xa1);
            this.panel2.TabIndex = 2;
            this.panel2.Paint += new PaintEventHandler(this.panel2_Paint);
            this.labelWB.AutoSize = true;
            this.labelWB.BackColor = Color.Transparent;
            this.labelWB.Location = new Point(12, 9);
            this.labelWB.Name = "labelWB";
            this.labelWB.Size = new Size(150, 13);
            this.labelWB.TabIndex = 0;
            this.labelWB.Text = "WEIGHBRIDGE .NET System";
            this.timer1.Enabled = true;
            this.timer1.Tick += new EventHandler(this.timer1_Tick);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            this.BackgroundImageLayout = ImageLayout.Stretch;
            base.ClientSize = new Size(0x22f, 0xc4);
            base.ControlBox = false;
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.panel1);
            base.FormBorderStyle = FormBorderStyle.None;
            base.Icon = (Icon) manager.GetObject("$this.Icon");
            base.Name = "FormMessage";
            base.ShowIcon = false;
            base.ShowInTaskbar = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Message";
            base.Load += new EventHandler(this.FormMessage_Load);
            base.Shown += new EventHandler(this.FormMessage_Shown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            base.ResumeLayout(false);
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
        }
    }
}

