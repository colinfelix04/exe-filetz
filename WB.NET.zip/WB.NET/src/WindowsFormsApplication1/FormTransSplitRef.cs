﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormTransSplitRef : Form
    {
        public string pRef;
        public bool save = false;
        public string tolling = "";
        public string doNo = "";
        public WBTable tblTrans = new WBTable();
        public WBTable tblTransSplit = new WBTable();
        public WBTable tblTransDeduc = new WBTable();
        public WBTable tblTransDiv = new WBTable();
        public WBTable tblDO = new WBTable();
        public WBTable tblComm = new WBTable();
        public WBTable tblCommD = new WBTable();
        public WBTable tblTransDO = new WBTable();
        public WBTable tblTransQC = new WBTable();
        public WBTable tblTransContainer = new WBTable();
        public WBTable tblDOContainer = new WBTable();
        public WBTable tblDriver = new WBTable();
        public WBTable tblTransporter = new WBTable();
        public WBTable tblStorage;
        private DataGridView dgvQC_All;
        private DataGridView dgvQC;
        public bool changeComm = false;
        public bool lSTO1DO = false;
        private DataRow conRow;
        private double qty = 0.0;
        private double Net = 0.0;
        private string tolerance;
        private string DOConvUnit;
        public int nRef;
        private string chkqty;
        private string ISCC = "N";
        private string ISCC_No = "";
        private string ISCC_No2 = "";
        private string GHG = "";
        private string GC = "N";
        private int qCount = 0;
        private int ext = 0x40;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        public WBTable zCust = new WBTable();
        private IContainer components = null;
        private ShapeContainer shapeContainer1;
        private LineShape lineShape1;
        private Label labelTransporterName;
        private Label label4;
        private TextBox textDriverID;
        private Label labelDriverName;
        private TextBox textTransporter;
        private Label label3;
        private Label label1;
        private TextBox textTruck;
        private Button buttonCancel;
        private Label label2;
        private Label label5;
        private TextBox textFactOty;
        private TextBox textEstQty;
        private Label label8;
        private Label label9;
        private Label label11;
        public TextBox textDO;
        private Button button11;
        private Label label10;
        private GroupBox groupBox1;
        private TextBox textNetEstate;
        private TextBox textTareEstate;
        private TextBox textGrossEstate;
        private Label label20;
        private Label label21;
        private Label label22;
        private GroupBox groupBox2;
        private TextBox textNET2;
        private TextBox text4th;
        private TextBox text3rd;
        private Label label14;
        private Label label15;
        private Label label16;
        private TextBox textNET1;
        private TextBox text2nd;
        private TextBox text1st;
        private Label label12;
        private Label label13;
        private Label label19;
        private Label label17;
        private TextBox textDeducTotal;
        private Label label18;
        private TextBox textNet;
        private Label label45;
        private TextBox textVariance;
        private Label label6;
        private TextBox textDN;
        private Label label33;
        private TextBox textCommType;
        private Label label7;
        private Label quantityLeft;
        private Panel panel2;
        private TextBox textDate1st;
        private Button buttonAdd;
        private Panel panel1;
        private Button button1;
        private DataGridView dgvDO;
        private Button button5;
        public TextBox textRName;
        public TextBox textRCode;
        private Label label23;
        public TextBox textCont;
        private Label label24;
        public TextBox textTransporter2;
        private Label label25;
        public TextBox textEstate;
        private Label label26;
        private Panel panelSTO1DO;
        public TextBox text1DOSTO;
        private Label label27;
        public TextBox text1STO;
        private Label label28;
        private Label label29;
        private ShapeContainer shapeContainer2;
        private RectangleShape rectangleShape1;
        public Label labelKB;
        private Label labelZWB;
        private Button buttonStorage;
        public TextBox textStorage;
        private Label labelStorage;
        private Label labelStorageName;
        public Label labelConvUnit;
        public TextBox textConvNett;
        private Label label30;
        public Label label1STO1DO;
        private Label label31;
        private Label label34;
        private TextBox textDeduction;
        private Label label32;

        public FormTransSplitRef()
        {
            this.InitializeComponent();
        }

        private void _InitQC(string pDO_No)
        {
            if (this.dgvDO.Rows.Count > 0)
            {
                if (this.dgvQC_All.Rows.Count == 0)
                {
                    this.tblTransQC.Close();
                    this.tblTransQC.OpenTable("wb_TransQC", "Select * from wb_TransQC where  Ref='" + this.pRef + "'", WBData.conn);
                    this.dgvQC_All = this.tblTransQC.ToDGV(this.dgvQC_All);
                }
                this.dgvQC = this.DGV_Copy(this.dgvQC_All, this.dgvQC, this.dgvDO.Rows[0].Cells["ref"].Value.ToString());
                int count = this.dgvQC.Rows.Count;
                if (count == 0)
                {
                    this.tblCommD.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail where " + WBData.CompanyLocation(" and Comm_Code='" + this.dgvDO.Rows[0].Cells["Comm_Code"].Value.ToString().Trim() + "'"), WBData.conn);
                    foreach (DataRow row in this.tblCommD.DT.Rows)
                    {
                        count = this.dgvQC_All.Rows.Count;
                        this.dgvQC_All.Rows.Add();
                        this.dgvQC_All.Rows[count].Cells["Coy"].Value = WBData.sCoyCode;
                        this.dgvQC_All.Rows[count].Cells["Location_Code"].Value = WBData.sLocCode;
                        this.dgvQC_All.Rows[count].Cells["Ref"].Value = this.pRef;
                        this.dgvQC_All.Rows[count].Cells["DaRef"].Value = this.text1st.Text;
                        this.dgvQC_All.Rows[count].Cells["QualityControl"].Value = " ";
                        this.dgvQC_All.Rows[count].Cells["Tank"].Value = " ";
                        this.dgvQC_All.Rows[count].Cells["QCode"].Value = row["QCode"].ToString();
                        this.dgvQC_All.Rows[count].Cells["QName"].Value = row["QName"].ToString();
                        this.dgvQC_All.Rows[count].Cells["Comm_Code"].Value = this.dgvDO.Rows[0].Cells["Comm_Code"].Value;
                        this.dgvQC_All.Rows[count].Cells["Relation_Code"].Value = this.dgvDO.Rows[0].Cells["Relation_Code"].Value;
                        this.dgvQC_All.Rows[count].Cells["Estate_Code"].Value = this.dgvDO.Rows[0].Cells["Estate"].Value;
                        this.dgvQC_All.Refresh();
                    }
                    this.dgvQC = this.DGV_Copy(this.dgvQC_All, this.dgvQC, this.dgvDO.Rows[0].Cells["Ref"].Value.ToString());
                }
                this.qCount = this.tblTransQC.DT.Rows.Count;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.dgvDO.Rows.Count > 1) && (MessageBox.Show("Transaction will be Splitted, Are You Sure?", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes))
            {
                this.saveSplit(this.pRef);
                this.saveTrans("");
                this.save = true;
                WBTable table = new WBTable();
                foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
                {
                    if (row.Cells["STO1X"].Value.ToString().Trim() != "")
                    {
                        table.OpenTable("wb_contract", "update wb_contract set [STO1DO]='Y' Where " + WBData.CompanyLocation(" AND Do_No='" + row.Cells["Do_No"].Value.ToString().Trim() + "'"), WBData.conn);
                    }
                }
                table.Dispose();
                table = new WBTable();
                table.OpenTable("TollingContract", "SELECT Coy_Tolling FROM wb_contract WHERE " + WBData.CompanyLocation(" AND DO_NO = '" + this.doNo + "'"), WBData.conn);
                string str = (table.DT.Rows.Count > 0) ? table.DT.Rows[0][0].ToString() : "";
                table.Dispose();
                if ((this.tolling == "6") && (str != "NONE"))
                {
                    this.tblTrans.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and ref = '" + this.pRef + Constant.TITIP_TIMBUN_POSTFIX + "' "), WBData.conn);
                    this.tblTrans.DR = this.tblTrans.DT.Rows[0];
                    this.saveSplit(this.pRef + Constant.TITIP_TIMBUN_POSTFIX);
                    this.saveTrans(Constant.TITIP_TIMBUN_POSTFIX);
                    this.save = true;
                    table = new WBTable();
                    foreach (DataGridViewRow row2 in (IEnumerable) this.dgvDO.Rows)
                    {
                        if (row2.Cells["STO1X"].Value.ToString().Trim() != "")
                        {
                            table.OpenTable("wb_contract", "update wb_contract set [STO1DO]='Y' Where " + WBData.CompanyLocation(" AND Do_No='" + row2.Cells["Do_No"].Value.ToString().Trim() + "'"), WBData.conn);
                        }
                    }
                    table.Dispose();
                }
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE"
            };
            if (this.tolling == "6")
            {
                contract.flagTimbun = "6";
            }
            contract.pFind = this.textDO.Text.Trim();
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDO.Text = contract.ReturnRow["DO_NO"].ToString();
                this.quantityLeft.Text = $"{Program.checkOS(contract.ReturnRow["Do_No"].ToString(), "", "", "N"):N0}";
                this.textCont.Text = contract.ReturnRow["Contract"].ToString();
                this.textTransporter2.Text = contract.ReturnRow["Transporter_code"].ToString();
                this.textEstate.Text = contract.ReturnRow["Estate1_Code"].ToString();
                this.DOConvUnit = contract.ReturnRow["ConvertionUnit"].ToString();
                this.labelKB.Visible = contract.ReturnRow["Berikat"].ToString().Trim() == "Y";
                this.label1STO1DO.Visible = contract.ReturnRow["STO1DO"].ToString().Trim() == "Y";
                this.lSTO1DO = contract.ReturnRow["STO1DO"].ToString().Trim() == "Y";
                if (WBSetting.zwb == "Y")
                {
                    this.labelZWB.Visible = contract.ReturnRow["ZWB"].ToString() != "Y";
                }
                this.zCust.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" AND Relation_Code='" + contract.ReturnRow["Relation_Code"].ToString().Trim() + "'"), WBData.conn);
                if (this.zCust.DT.Rows.Count > 0)
                {
                    this.textRCode.Text = contract.ReturnRow["Relation_Code"].ToString().Trim();
                    this.textRName.Text = this.zCust.DT.Rows[0]["Relation_Name"].ToString().Trim();
                }
                this.textDO.Focus();
            }
            this.text1STO.Enabled = true;
            this.text1DOSTO.Enabled = true;
            contract.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if ((this.dgvDO.CurrentRow.Index != 0) && (MessageBox.Show("DO No. : " + this.dgvDO.CurrentRow.Cells["Do_No"].Value.ToString() + ".\n\n Are you sure to deleted this record ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes))
            {
                this.dgvDO.Rows[0].Cells["Bruto"].Value = $"{Program.StrToDouble(this.dgvDO.Rows[0].Cells["Bruto"].Value.ToString(), 0) + Program.StrToDouble(this.dgvDO.CurrentRow.Cells["Bruto"].Value.ToString(), 0):N0}";
                this.dgvDO.Rows[0].Cells["Netto"].Value = $"{Program.StrToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString(), 0) + Program.StrToDouble(this.dgvDO.CurrentRow.Cells["Netto"].Value.ToString(), 0):N0}";
                this.dgvDO.Rows[0].Cells["Estate_qty"].Value = $"{Program.StrToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString(), 0) + Program.StrToDouble(this.dgvDO.CurrentRow.Cells["Estate_qty"].Value.ToString(), 0):N0}";
                this.dgvDO.Rows.Remove(this.dgvDO.Rows[this.dgvDO.CurrentRow.Index]);
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (this.textDO.Text.Trim() != "")
            {
                if (this.textDO.Text != "")
                {
                    if ((this.chkqty != "Y") || ((Convert.ToDouble(this.quantityLeft.Text) + Convert.ToDouble(this.tolerance)) >= Convert.ToDouble(this.textFactOty.Text)))
                    {
                        FormContract contract = new FormContract();
                        string[] aField = new string[] { "DO_NO" };
                        string[] aFind = new string[] { this.textDO.Text.Trim().ToUpper() };
                        if (ReferenceEquals(this.tblDO.GetData(aField, aFind), null))
                        {
                            MessageBox.Show("Invalid DO Entry..", "Warning...");
                            this.textDO.Focus();
                        }
                        contract.Dispose();
                        if (Program.StrToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString(), 0) > Program.StrToDouble(this.textFactOty.Text, 0))
                        {
                            if (!(Program.StrToDouble(this.textFactOty.Text, 0) == 0.0))
                            {
                                if (this.lSTO1DO)
                                {
                                    TextBox[] aText = new TextBox[] { this.text1STO, this.text1DOSTO };
                                    if (Program.CheckEmpty(aText))
                                    {
                                        return;
                                    }
                                }
                                this.EntryDO();
                                this.hitVar();
                                this.textDO.Text = "";
                            }
                            else
                            {
                                MessageBox.Show("Please Fill in Qty Split", "WARNING...");
                                this.textFactOty.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Split Quantity Must Smaller than Main Transaction DO Qty (" + $"{Program.StrToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString(), 0):N0}" + ")", "WARNING....");
                            this.textFactOty.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannot ADD DO, Do Qty Left + Tolerance = " + (Convert.ToDouble(this.quantityLeft.Text) + Convert.ToDouble(this.tolerance)).ToString() + " KG \nPlease Check \nClick OK to Continue..", "W A R N I N G...");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please Entry DO No.", "WARNING...");
                this.textDO.Focus();
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        public void cekSisa(string DoNo, double zQty)
        {
            double num;
            WBTable table = new WBTable();
            table.OpenTable("vw_trans", "Select sum(NETTO) as Net from vw_trans where DO_NO = '" + DoNo + "' and (deleted is null or deleted = 'N') and report_date is not null", WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                num = 0.0;
            }
            else
            {
                table.DR = table.DT.Rows[0];
                num = (table.DR["Net"].ToString().Length <= 0) ? 0.0 : Convert.ToDouble(table.DR["Net"].ToString());
            }
            table.Dispose();
        }

        private DataGridView DGV_Copy(DataGridView dgv1, DataGridView dgv2, string pRef)
        {
            dgv2.Rows.Clear();
            int count = 0;
            for (int i = 0; i < dgv1.Rows.Count; i++)
            {
                if (dgv1.Rows[i].Cells["Ref"].Value.ToString() == pRef)
                {
                    count = dgv2.Rows.Count;
                    dgv2.Rows.Add();
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= dgv2.ColumnCount)
                        {
                            break;
                        }
                        dgv2[num3, count].Value = dgv1[num3, i].Value;
                        if (dgv2[num3, count].Value == null)
                        {
                            dgv2[num3, count].Value = 0;
                        }
                        num3++;
                    }
                }
            }
            return dgv2;
        }

        private void dgvDO_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void EntryDO()
        {
            this.tblTransDO.DR = this.tblTransDO.DT.Rows[0];
            DataRow row = this.tblTransDO.DT.NewRow();
            row["Coy"] = WBData.sCoyCode;
            row["Location_Code"] = WBData.sLocCode;
            row["Transaction_Code"] = this.tblTransDO.DR["Transaction_Code"].ToString();
            row["Ref"] = this.pRef;
            row["DO_No"] = this.textDO.Text;
            row["Comm_Code"] = this.conRow["Comm_code"].ToString();
            row["Confirmation"] = this.conRow["confirmation"].ToString();
            row["Contract"] = this.conRow["contract"].ToString();
            row["Relation_Code"] = this.conRow["relation_code"].ToString();
            row["Relation_Name"] = this.textRName.Text;
            row["Bruto"] = $"{Program.StrToDouble(this.textFactOty.Text, 0):N0}";
            row["Tarra"] = "0";
            row["Netto"] = $"{Program.StrToDouble(this.textFactOty.Text, 0):N0}";
            row["Estate_qty"] = $"{Program.StrToDouble(this.textEstQty.Text, 0):N0}";
            row["Agen"] = "";
            row["Estate"] = this.conRow["Estate1_Code"].ToString();
            row["ConvNett"] = $"{Program.StrToDouble(this.textConvNett.Text, 0):N0}";
            row["ConvUnit"] = this.DOConvUnit;
            row["PI_No"] = this.conRow["PI_No"].ToString();
            row["Transporter_Code"] = this.conRow["Transporter_code"].ToString();
            row["Storage_code"] = this.textStorage.Text;
            row["STO1X"] = this.text1STO.Text;
            row["DO1X"] = this.text1DOSTO.Text;
            this.dgvDO.Rows.Add(row.ItemArray);
            this.dgvDO.Refresh();
            this.dgvDO.Rows[0].Cells["Bruto"].Value = $"{Program.StrToDouble(this.dgvDO.Rows[0].Cells["Bruto"].Value.ToString(), 0) - Program.StrToDouble(this.textFactOty.Text, 0):N0}";
            this.dgvDO.Rows[0].Cells["Netto"].Value = $"{Program.StrToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString(), 0) - Program.StrToDouble(this.textFactOty.Text, 0):N0}";
            this.dgvDO.Rows[0].Cells["Estate_qty"].Value = $"{Program.StrToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString(), 0) - Program.StrToDouble(this.textEstQty.Text, 0):N0}";
        }

        private void FormTransSplitRef_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTransSplitRef_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.pRef = this.pRef.Trim();
            string str = this.pRef.Substring(this.pRef.Length - 1, 1);
            this.Text = "Split Weighing Transaction, Ref No : " + this.pRef;
            this.tblTrans.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and ref = '" + this.pRef + "' "), WBData.conn);
            string[] textArray1 = new string[] { " and ref like '", this.pRef, "%' and ref <> '", this.pRef, Constant.TITIP_TIMBUN_POSTFIX, "'" };
            this.tblTransDO.OpenTable("wb_transDO", "Select * From wb_transDO where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
            if (this.tblTransDO.DT.Rows.Count > 1)
            {
                int num = 0;
                num = 0;
                while (true)
                {
                    if (num >= this.tblTransDO.DT.Rows.Count)
                    {
                        this.tblTransDO.Save();
                        string[] textArray2 = new string[] { " and ref like '", this.pRef, "%' and ref <> '", this.pRef, Constant.TITIP_TIMBUN_POSTFIX, "'" };
                        this.tblTransDO.OpenTable("wb_transDO", "Select * From wb_transDO where " + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
                        this.tblTransSplit.OpenTable("wb_transSplit", "Select * from wb_transSplit where " + WBData.CompanyLocation(" and ref = '" + this.pRef + "' "), WBData.conn);
                        if (this.tblTransSplit.DT.Rows.Count > 0)
                        {
                            this.tblTransSplit.DR = this.tblTransSplit.DT.Rows[0];
                            this.tblTrans.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and ref = '" + this.pRef + "' "), WBData.conn);
                            this.tblTrans.DR = this.tblTrans.DT.Rows[0];
                            this.tblTrans.DR.BeginEdit();
                            this.tblTrans.DR["Split"] = "N";
                            this.tblTrans.DR["posted"] = "N";
                            this.tblTrans.DR["_1ST"] = this.tblTransSplit.DR["_1ST"].ToString();
                            this.tblTrans.DR["_2ND"] = this.tblTransSplit.DR["_2ND"].ToString();
                            this.tblTrans.DR["_3RD"] = this.tblTransSplit.DR["_3RD"].ToString();
                            this.tblTrans.DR["_4TH"] = this.tblTransSplit.DR["_4TH"].ToString();
                            this.tblTrans.DR["Gross"] = this.tblTransSplit.DR["Gross"].ToString();
                            this.tblTrans.DR["Tare"] = this.tblTransSplit.DR["Tare"].ToString();
                            this.tblTrans.DR["Received"] = this.tblTransSplit.DR["Received"].ToString();
                            this.tblTrans.DR["Net"] = this.tblTransSplit.DR["Net"].ToString();
                            this.tblTrans.DR["Gross_Estate"] = this.tblTransSplit.DR["Gross_Estate"].ToString();
                            this.tblTrans.DR["Tare_Estate"] = this.tblTransSplit.DR["Tare_Estate"].ToString();
                            this.tblTrans.DR["Net_Estate"] = this.tblTransSplit.DR["Net_Estate"].ToString();
                            this.tblTrans.DR["checksum"] = this.tblTrans.Checksum(this.tblTrans.DR);
                            this.tblTrans.DR.EndEdit();
                            this.tblTrans.Save();
                            this.tblTrans.Close();
                        }
                        break;
                    }
                    if ((this.tblTransDO.DT.Rows[num]["ref"].ToString() != this.pRef) && (this.tblTransDO.DT.Rows[num]["ref"].ToString().Substring(this.tblTransDO.DT.Rows[num]["ref"].ToString().Length - 1, 1) != Constant.TITIP_TIMBUN_POSTFIX))
                    {
                        this.tblTransDO.DT.Rows[num].Delete();
                    }
                    num++;
                }
            }
            this.tblTrans.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and ref = '" + this.pRef + "' "), WBData.conn);
            this.tblComm.OpenTable("wb_commodity", "Select *  from wb_commodity  where " + WBData.CompanyLocation(""), WBData.conn);
            string[] textArray3 = new string[] { " And Ref='", this.pRef, "' and ref <> '", this.pRef, Constant.TITIP_TIMBUN_POSTFIX, "'" };
            this.tblTransQC.OpenTable("wb_TransQC", "Select * from wb_TransQC where " + WBData.CompanyLocation(string.Concat(textArray3)), WBData.conn);
            this.qCount = this.tblTransQC.DT.Rows.Count;
            string sqltext = "";
            sqltext = "SELECT * FROM wb_contract Where " + WBData.CompanyLocation(" and (closed is null or closed <> 'X' or closed = 'N')") + " and (zAuto = 'N') ";
            this.tblDO.OpenTable("wb_contract", sqltext, WBData.conn);
            Program.AutoComp(this.tblDO, "Do_No", this.textDO);
            this.labelDriverName.Text = "";
            this.labelTransporterName.Text = "";
            this.dgvDO.ColumnCount = this.tblTransDO.DT.Columns.Count + 2;
            int num2 = 0;
            while (true)
            {
                if (num2 >= this.tblTransDO.DT.Columns.Count)
                {
                    this.dgvDO.Columns[this.tblTransDO.DT.Columns.Count].Name = "Variance";
                    this.dgvDO.Columns[this.tblTransDO.DT.Columns.Count].HeaderText = "Variance";
                    foreach (DataGridViewColumn column in this.dgvDO.Columns)
                    {
                        column.Visible = false;
                    }
                    this.dgvDO.Columns["Do_No"].Visible = true;
                    this.dgvDO.Columns["Contract"].Visible = true;
                    this.dgvDO.Columns["Comm_Code"].Visible = true;
                    this.dgvDO.Columns["Transaction_Code"].Visible = true;
                    this.dgvDO.Columns["Transporter_Code"].Visible = true;
                    this.dgvDO.Columns["Estate_qty"].Visible = true;
                    this.dgvDO.Columns["Bruto"].Visible = true;
                    this.dgvDO.Columns["Tarra"].Visible = true;
                    this.dgvDO.Columns["Netto"].Visible = true;
                    this.dgvDO.Columns["Estate_qty"].Visible = true;
                    this.dgvDO.Columns["Relation_Code"].Visible = true;
                    this.dgvDO.Columns["Variance"].Visible = true;
                    this.dgvDO.Columns["Variance"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["Do_No"].HeaderText = "DO No.";
                    this.dgvDO.Columns["Contract"].HeaderText = "Contract No.";
                    this.dgvDO.Columns["Comm_Code"].HeaderText = "Commodity";
                    this.dgvDO.Columns["Transaction_Code"].HeaderText = "Tx";
                    this.dgvDO.Columns["Transporter_Code"].HeaderText = "Transporter Code";
                    this.dgvDO.Columns["Relation_Code"].HeaderText = "Rel.Code";
                    this.dgvDO.Columns["Relation_Name"].HeaderText = "Relation Name";
                    this.dgvDO.Columns["Relation_Name"].Width = 300;
                    this.dgvDO.Columns["Netto"].HeaderText = "Net Weight";
                    this.dgvDO.Columns["Netto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["Netto"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["Estate_qty"].HeaderText = "Net Estate";
                    this.dgvDO.Columns["Estate_qty"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["Estate_qty"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["Bruto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["Bruto"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["Tarra"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["Tarra"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["ConvNett"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["ConvNett"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["ConvNett"].Visible = true;
                    this.dgvDO.Columns["ConvUnit"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["ConvUnit"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["ConvUnit"].Visible = true;
                    this.dgvDO.Columns["STO1X"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["STO1X"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["STO1X"].Visible = true;
                    this.dgvDO.Columns["DO1X"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["DO1X"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["DO1X"].Visible = true;
                    this.dgvDO.Columns["Storage_code"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDO.Columns["Storage_code"].DefaultCellStyle.Format = "N0";
                    this.dgvDO.Columns["Storage_code"].Visible = true;
                    foreach (DataGridViewColumn column2 in this.dgvDO.Columns)
                    {
                        column2.SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                    this.dgvDO.Refresh();
                    this.hitVar();
                    this.textTruck.Text = this.tblTrans.DT.Rows[0]["Truck_Number"].ToString();
                    this.textDriverID.Text = this.tblTrans.DT.Rows[0]["License_No"].ToString();
                    this.textTransporter.Text = this.tblTrans.DT.Rows[0]["Transporter_Code"].ToString();
                    this.tblDriver.OpenTable("wb_driver", "Select * from wb_driver where " + WBData.CompanyLocation(" and License_No='" + this.textDriverID.Text + "' and (Deleted IS NULL OR Deleted <> 'Y') "), WBData.conn);
                    this.tblTransporter.OpenTable("wb_transporter", "Select * from wb_transporter where " + WBData.CompanyLocation(" and Transporter_Code='" + this.textTransporter.Text + "'"), WBData.conn);
                    if (this.tblDriver.DT.Rows.Count > 0)
                    {
                        this.labelDriverName.Text = this.tblDriver.DT.Rows[0]["Name"].ToString();
                    }
                    if (this.tblTransporter.DT.Rows.Count > 0)
                    {
                        this.labelTransporterName.Text = this.tblTransporter.DT.Rows[0]["Transporter_Name"].ToString();
                    }
                    this.tblTrans.DR = this.tblTrans.DT.Rows[0];
                    this.textDate1st.Text = this.tblTrans.DR["Date1"].ToString();
                    this.textGrossEstate.Text = (this.tblTrans.DR["Gross_Estate"].ToString() == "") ? "0" : $"{this.tblTrans.DR["Gross_Estate"]:N0}";
                    this.textTareEstate.Text = (this.tblTrans.DR["Tare_Estate"].ToString() == "") ? "0" : $"{this.tblTrans.DR["Tare_Estate"]:N0}";
                    this.textNetEstate.Text = $"{Math.Abs((double) (Program.StrToDouble(this.tblTrans.DR["Gross_Estate"].ToString(), 0) - Program.StrToDouble(this.tblTrans.DR["Tare_Estate"].ToString(), 0))):N0}";
                    this.textEstQty.Enabled = Convert.ToDouble(this.textNetEstate.Text) > 0.0;
                    this.text1st.Text = (this.tblTrans.DR["_1ST"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_1ST"]:N0}";
                    this.text2nd.Text = (this.tblTrans.DR["_2ND"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_2ND"]:N0}";
                    this.text3rd.Text = (this.tblTrans.DR["_3RD"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_3RD"]:N0}";
                    this.text4th.Text = (this.tblTrans.DR["_4TH"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_4TH"]:N0}";
                    this.textDeducTotal.Text = $"{this.tblTrans.DR["Deduction"]:N0}";
                    this.dgvDO = this.tblTransDO.ToDGV(this.dgvDO);
                    this.textNet.Text = $"{this.tblTrans.DR["Net"]:N0}";
                    this.DOConvUnit = "";
                    this.HitNet();
                    string[] aField = new string[] { "Comm_Code" };
                    string[] aFind = new string[] { this.tblTrans.DR["Comm_code"].ToString() };
                    DataRow data = this.tblComm.GetData(aField, aFind);
                    if (data != null)
                    {
                        this.textCommType.Text = data["Type"].ToString();
                    }
                    if (WBSetting.Field("Check_Storage") != "N")
                    {
                        this.tblStorage = new WBTable();
                        this.tblStorage.OpenTable("wb_storage", "Select * from wb_storage", WBData.conn);
                        Program.AutoComp(this.tblStorage, "Storage_code", this.textStorage);
                    }
                    else
                    {
                        this.textStorage.Visible = false;
                        this.buttonStorage.Visible = false;
                        this.labelStorageName.Visible = false;
                        this.labelStorage.Visible = false;
                    }
                    this.labelZWB.Visible = false;
                    this.labelKB.Visible = false;
                    this.label1STO1DO.Visible = false;
                    this.panelSTO1DO.Visible = WBSetting.locType == "0";
                    this.hitungBTN();
                    this.labelZWB.Text = this.labelZWB.Text + this.sapIDSYS;
                    return;
                }
                this.dgvDO.Columns[num2].Name = this.tblTransDO.DT.Columns[num2].ColumnName;
                num2++;
            }
        }

        private void HitNet()
        {
            if ((Program.CheckNumeric(this.text1st) && (Program.CheckNumeric(this.text2nd) && (Program.CheckNumeric(this.text3rd) && Program.CheckNumeric(this.text4th)))) && Program.CheckNumeric(this.textDeducTotal))
            {
                double num = Math.Abs((double) (Convert.ToDouble(this.text1st.Text) - Convert.ToDouble(this.text2nd.Text)));
                double num2 = Math.Abs((double) ((num + Convert.ToDouble(this.text3rd.Text)) - Convert.ToDouble(this.text4th.Text)));
                this.textNET1.Text = $"{num:N0}";
                this.textNET2.Text = $"{num2:N0}";
                this.textNet.Text = $"{num2 - Convert.ToDouble(this.textDeducTotal.Text):N0}";
                this.textVariance.Text = (this.textNetEstate.Text.Trim() == "0") ? "0" : Convert.ToString((double) (Program.StrToDouble(this.textNet.Text, 0) - Program.StrToDouble(this.textNetEstate.Text, 0)));
            }
        }

        private void hitungBTN()
        {
            try
            {
                this.text1st.Text = (this.text1st.Text.Trim() == "") ? "0" : this.text1st.Text;
                this.text2nd.Text = (this.text2nd.Text.Trim() == "") ? "0" : this.text2nd.Text;
                if (this.dgvDO.Rows.Count == 1)
                {
                    if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text2nd.Text))
                    {
                        this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text);
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text1st.Text);
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = Convert.ToDouble(this.text2nd.Text);
                        this.dgvDO.Rows[0].Cells["Estate_qty"].Value = Convert.ToDouble(this.textNetEstate.Text);
                    }
                    else
                    {
                        this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text);
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text2nd.Text);
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = Convert.ToDouble(this.text1st.Text);
                        this.dgvDO.Rows[0].Cells["Estate_qty"].Value = Convert.ToDouble(this.textNetEstate.Text);
                    }
                }
            }
            catch
            {
            }
        }

        private void hitVar()
        {
            double num = 0.0;
            double num2 = 0.0;
            double num3 = 0.0;
            for (int i = 0; i < this.dgvDO.Rows.Count; i++)
            {
                num = Program.StrToDouble(this.dgvDO.Rows[i].Cells["estate_qty"].Value.ToString(), 0);
                num2 = Program.StrToDouble(this.dgvDO.Rows[i].Cells["netto"].Value.ToString(), 0);
                num3 = num2 - num;
                bool flag = this.textNetEstate.Text.Trim() != "";
                this.dgvDO.Rows[i].Cells["variance"].Value = !flag ? ((object) "0") : ((object) num3);
            }
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.shapeContainer1 = new ShapeContainer();
            this.lineShape1 = new LineShape();
            this.labelTransporterName = new Label();
            this.label4 = new Label();
            this.textDriverID = new TextBox();
            this.labelDriverName = new Label();
            this.textTransporter = new TextBox();
            this.label3 = new Label();
            this.label1 = new Label();
            this.textTruck = new TextBox();
            this.buttonCancel = new Button();
            this.label2 = new Label();
            this.label5 = new Label();
            this.textFactOty = new TextBox();
            this.textEstQty = new TextBox();
            this.label8 = new Label();
            this.label9 = new Label();
            this.label11 = new Label();
            this.textDO = new TextBox();
            this.button11 = new Button();
            this.label10 = new Label();
            this.groupBox1 = new GroupBox();
            this.textNetEstate = new TextBox();
            this.textTareEstate = new TextBox();
            this.textGrossEstate = new TextBox();
            this.label20 = new Label();
            this.label21 = new Label();
            this.label22 = new Label();
            this.groupBox2 = new GroupBox();
            this.textNET2 = new TextBox();
            this.text4th = new TextBox();
            this.text3rd = new TextBox();
            this.label14 = new Label();
            this.label15 = new Label();
            this.label16 = new Label();
            this.textNET1 = new TextBox();
            this.text2nd = new TextBox();
            this.text1st = new TextBox();
            this.label12 = new Label();
            this.label13 = new Label();
            this.label19 = new Label();
            this.label17 = new Label();
            this.textDeducTotal = new TextBox();
            this.label18 = new Label();
            this.textNet = new TextBox();
            this.label45 = new Label();
            this.textVariance = new TextBox();
            this.label6 = new Label();
            this.textDN = new TextBox();
            this.label33 = new Label();
            this.textCommType = new TextBox();
            this.label7 = new Label();
            this.quantityLeft = new Label();
            this.panel2 = new Panel();
            this.label34 = new Label();
            this.textDeduction = new TextBox();
            this.label32 = new Label();
            this.label31 = new Label();
            this.label1STO1DO = new Label();
            this.buttonStorage = new Button();
            this.textStorage = new TextBox();
            this.labelStorage = new Label();
            this.labelStorageName = new Label();
            this.labelConvUnit = new Label();
            this.textConvNett = new TextBox();
            this.label30 = new Label();
            this.labelZWB = new Label();
            this.labelKB = new Label();
            this.panelSTO1DO = new Panel();
            this.text1DOSTO = new TextBox();
            this.label27 = new Label();
            this.text1STO = new TextBox();
            this.label28 = new Label();
            this.label29 = new Label();
            this.shapeContainer2 = new ShapeContainer();
            this.rectangleShape1 = new RectangleShape();
            this.textEstate = new TextBox();
            this.label26 = new Label();
            this.textTransporter2 = new TextBox();
            this.label25 = new Label();
            this.textRName = new TextBox();
            this.textRCode = new TextBox();
            this.label23 = new Label();
            this.textCont = new TextBox();
            this.label24 = new Label();
            this.button5 = new Button();
            this.buttonAdd = new Button();
            this.textDate1st = new TextBox();
            this.panel1 = new Panel();
            this.button1 = new Button();
            this.dgvDO = new DataGridView();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panelSTO1DO.SuspendLayout();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dgvDO).BeginInit();
            base.SuspendLayout();
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.lineShape1 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(0x2d2, 0x1d8);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = -1;
            this.lineShape1.X2 = 0x2f2;
            this.lineShape1.Y1 = 200;
            this.lineShape1.Y2 = 200;
            this.labelTransporterName.AutoSize = true;
            this.labelTransporterName.Location = new Point(0xe7, 0x4a);
            this.labelTransporterName.Name = "labelTransporterName";
            this.labelTransporterName.Size = new Size(0x59, 13);
            this.labelTransporterName.TabIndex = 14;
            this.labelTransporterName.Text = "TransporterName";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x2a, 0x4a);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x3d, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Transporter";
            this.textDriverID.CharacterCasing = CharacterCasing.Upper;
            this.textDriverID.Location = new Point(0x120, 0x2c);
            this.textDriverID.Name = "textDriverID";
            this.textDriverID.ReadOnly = true;
            this.textDriverID.Size = new Size(0x7b, 20);
            this.textDriverID.TabIndex = 0x10;
            this.labelDriverName.AutoSize = true;
            this.labelDriverName.Location = new Point(0x1a0, 0x2f);
            this.labelDriverName.Name = "labelDriverName";
            this.labelDriverName.Size = new Size(0x3f, 13);
            this.labelDriverName.TabIndex = 0x11;
            this.labelDriverName.Text = "DriverName";
            this.textTransporter.CharacterCasing = CharacterCasing.Upper;
            this.textTransporter.Location = new Point(0x68, 70);
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.ReadOnly = true;
            this.textTransporter.Size = new Size(0x7b, 20);
            this.textTransporter.TabIndex = 11;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0xe7, 0x2f);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x31, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Driver ID";
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x2c, 0x2f);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3b, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Vehicle No";
            this.textTruck.CharacterCasing = CharacterCasing.Upper;
            this.textTruck.Location = new Point(0x68, 0x2c);
            this.textTruck.Name = "textTruck";
            this.textTruck.ReadOnly = true;
            this.textTruck.Size = new Size(0x7b, 20);
            this.textTruck.TabIndex = 12;
            this.buttonCancel.Location = new Point(0x24f, 9);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x5d, 0x2f);
            this.buttonCancel.TabIndex = 1;
            this.buttonCancel.Text = "&Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x41, 0x15b);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x41, 13);
            this.label2.TabIndex = 0x37;
            this.label2.Text = "Factory Nett";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(70, 0x144);
            this.label5.Name = "label5";
            this.label5.Size = new Size(60, 13);
            this.label5.TabIndex = 0x2a;
            this.label5.Text = "Estate Nett";
            this.textFactOty.Location = new Point(0x85, 0x157);
            this.textFactOty.Name = "textFactOty";
            this.textFactOty.Size = new Size(0x52, 20);
            this.textFactOty.TabIndex = 3;
            this.textFactOty.Text = "0";
            this.textFactOty.TextAlign = HorizontalAlignment.Right;
            this.textFactOty.Leave += new EventHandler(this.textNetFactory_Leave);
            this.textEstQty.Location = new Point(0x85, 0x141);
            this.textEstQty.Name = "textEstQty";
            this.textEstQty.Size = new Size(0x52, 20);
            this.textEstQty.TabIndex = 2;
            this.textEstQty.Text = "0";
            this.textEstQty.TextAlign = HorizontalAlignment.Right;
            this.textEstQty.Leave += new EventHandler(this.textNetEstate_Leave);
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0xdd, 0x15b);
            this.label8.Name = "label8";
            this.label8.Size = new Size(20, 13);
            this.label8.TabIndex = 0x2e;
            this.label8.Text = "Kg";
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0xdd, 0x143);
            this.label9.Name = "label9";
            this.label9.Size = new Size(20, 13);
            this.label9.TabIndex = 0x2c;
            this.label9.Text = "Kg";
            this.label11.AutoSize = true;
            this.label11.Location = new Point(0x4f, 0xd5);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x2b, 13);
            this.label11.TabIndex = 0x22;
            this.label11.Text = "DO No.";
            this.textDO.Location = new Point(0x80, 0xd3);
            this.textDO.MaxLength = 100;
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0xef, 20);
            this.textDO.TabIndex = 1;
            this.textDO.TextChanged += new EventHandler(this.textDO_TextChanged);
            this.textDO.KeyPress += new KeyPressEventHandler(this.textDO_KeyPress);
            this.textDO.Leave += new EventHandler(this.textDO_Leave);
            this.button11.Location = new Point(370, 0xd0);
            this.button11.Margin = new Padding(0);
            this.button11.Name = "button11";
            this.button11.Size = new Size(0x17, 0x17);
            this.button11.TabIndex = 0x21;
            this.button11.Text = "...";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new EventHandler(this.button11_Click);
            this.label10.AutoSize = true;
            this.label10.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label10.Location = new Point(15, 12);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0xcf, 0x10);
            this.label10.TabIndex = 7;
            this.label10.Text = "Main Transaction Information";
            this.groupBox1.Controls.Add(this.textNetEstate);
            this.groupBox1.Controls.Add(this.textTareEstate);
            this.groupBox1.Controls.Add(this.textGrossEstate);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Location = new Point(0x2c, 0x60);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x8a, 100);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "[ Other Party ]";
            this.textNetEstate.Location = new Point(0x41, 0x45);
            this.textNetEstate.MaxLength = 15;
            this.textNetEstate.Name = "textNetEstate";
            this.textNetEstate.ReadOnly = true;
            this.textNetEstate.Size = new Size(0x39, 20);
            this.textNetEstate.TabIndex = 3;
            this.textNetEstate.Text = "0";
            this.textNetEstate.TextAlign = HorizontalAlignment.Right;
            this.textTareEstate.BackColor = SystemColors.Control;
            this.textTareEstate.Enabled = false;
            this.textTareEstate.Location = new Point(0x41, 0x2f);
            this.textTareEstate.MaxLength = 15;
            this.textTareEstate.Name = "textTareEstate";
            this.textTareEstate.Size = new Size(0x39, 20);
            this.textTareEstate.TabIndex = 4;
            this.textTareEstate.Text = "0";
            this.textTareEstate.TextAlign = HorizontalAlignment.Right;
            this.textTareEstate.Leave += new EventHandler(this.textTareEstate_Leave);
            this.textGrossEstate.BackColor = SystemColors.Control;
            this.textGrossEstate.Enabled = false;
            this.textGrossEstate.Location = new Point(0x41, 0x18);
            this.textGrossEstate.MaxLength = 15;
            this.textGrossEstate.Name = "textGrossEstate";
            this.textGrossEstate.Size = new Size(0x39, 20);
            this.textGrossEstate.TabIndex = 5;
            this.textGrossEstate.Text = "0";
            this.textGrossEstate.TextAlign = HorizontalAlignment.Right;
            this.label20.AutoSize = true;
            this.label20.Location = new Point(14, 0x48);
            this.label20.Name = "label20";
            this.label20.Size = new Size(0x18, 13);
            this.label20.TabIndex = 2;
            this.label20.Text = "Net";
            this.label21.AutoSize = true;
            this.label21.Location = new Point(14, 50);
            this.label21.Name = "label21";
            this.label21.Size = new Size(0x1d, 13);
            this.label21.TabIndex = 1;
            this.label21.Text = "Tare";
            this.label22.AutoSize = true;
            this.label22.Location = new Point(14, 0x1b);
            this.label22.Name = "label22";
            this.label22.Size = new Size(0x22, 13);
            this.label22.TabIndex = 0;
            this.label22.Text = "Gross";
            this.groupBox2.Controls.Add(this.textNET2);
            this.groupBox2.Controls.Add(this.text4th);
            this.groupBox2.Controls.Add(this.text3rd);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.textNET1);
            this.groupBox2.Controls.Add(this.text2nd);
            this.groupBox2.Controls.Add(this.text1st);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Location = new Point(0xc7, 0x60);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0xd9, 100);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "[ Factory Weigh ]";
            this.textNET2.BackColor = SystemColors.Control;
            this.textNET2.Location = new Point(0x8b, 0x45);
            this.textNET2.MaxLength = 15;
            this.textNET2.Name = "textNET2";
            this.textNET2.ReadOnly = true;
            this.textNET2.Size = new Size(0x3d, 20);
            this.textNET2.TabIndex = 10;
            this.textNET2.Text = "0";
            this.textNET2.TextAlign = HorizontalAlignment.Right;
            this.text4th.BackColor = SystemColors.Control;
            this.text4th.Enabled = false;
            this.text4th.Location = new Point(0x8b, 0x2f);
            this.text4th.MaxLength = 15;
            this.text4th.Name = "text4th";
            this.text4th.Size = new Size(0x3d, 20);
            this.text4th.TabIndex = 11;
            this.text4th.Text = "0";
            this.text4th.TextAlign = HorizontalAlignment.Right;
            this.text4th.Leave += new EventHandler(this.text4th_Leave);
            this.text3rd.BackColor = SystemColors.Control;
            this.text3rd.Enabled = false;
            this.text3rd.Location = new Point(0x8b, 0x18);
            this.text3rd.MaxLength = 15;
            this.text3rd.Name = "text3rd";
            this.text3rd.Size = new Size(0x3d, 20);
            this.text3rd.TabIndex = 0;
            this.text3rd.Text = "0";
            this.text3rd.TextAlign = HorizontalAlignment.Right;
            this.text3rd.Leave += new EventHandler(this.text3rd_Leave);
            this.label14.AutoSize = true;
            this.label14.Location = new Point(0x6f, 0x48);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x18, 13);
            this.label14.TabIndex = 9;
            this.label14.Text = "Net";
            this.label15.AutoSize = true;
            this.label15.Location = new Point(0x6f, 50);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x16, 13);
            this.label15.TabIndex = 8;
            this.label15.Text = "4th";
            this.label16.AutoSize = true;
            this.label16.Location = new Point(0x6f, 0x1b);
            this.label16.Name = "label16";
            this.label16.Size = new Size(0x16, 13);
            this.label16.TabIndex = 7;
            this.label16.Text = "3rd";
            this.textNET1.BackColor = SystemColors.Control;
            this.textNET1.Location = new Point(0x29, 0x45);
            this.textNET1.MaxLength = 15;
            this.textNET1.Name = "textNET1";
            this.textNET1.ReadOnly = true;
            this.textNET1.Size = new Size(0x3a, 20);
            this.textNET1.TabIndex = 6;
            this.textNET1.Text = "0";
            this.textNET1.TextAlign = HorizontalAlignment.Right;
            this.text2nd.BackColor = SystemColors.Control;
            this.text2nd.Enabled = false;
            this.text2nd.Location = new Point(0x29, 0x2f);
            this.text2nd.MaxLength = 15;
            this.text2nd.Name = "text2nd";
            this.text2nd.Size = new Size(0x3a, 20);
            this.text2nd.TabIndex = 3;
            this.text2nd.Text = "0";
            this.text2nd.TextAlign = HorizontalAlignment.Right;
            this.text2nd.Leave += new EventHandler(this.text2nd_Leave);
            this.text1st.BackColor = SystemColors.Control;
            this.text1st.Enabled = false;
            this.text1st.Location = new Point(0x29, 0x18);
            this.text1st.MaxLength = 15;
            this.text1st.Name = "text1st";
            this.text1st.Size = new Size(0x3a, 20);
            this.text1st.TabIndex = 2;
            this.text1st.Text = "0";
            this.text1st.TextAlign = HorizontalAlignment.Right;
            this.text1st.Leave += new EventHandler(this.text1st_Leave);
            this.label12.AutoSize = true;
            this.label12.Location = new Point(14, 0x48);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x18, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "Net";
            this.label13.AutoSize = true;
            this.label13.Location = new Point(14, 50);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x19, 13);
            this.label13.TabIndex = 4;
            this.label13.Text = "2nd";
            this.label19.AutoSize = true;
            this.label19.Location = new Point(14, 0x1b);
            this.label19.Name = "label19";
            this.label19.Size = new Size(0x15, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "1st";
            this.label17.AutoSize = true;
            this.label17.Location = new Point(0x1a6, 0x5c);
            this.label17.Name = "label17";
            this.label17.Size = new Size(0x38, 13);
            this.label17.TabIndex = 0x12;
            this.label17.Text = "Deduction";
            this.textDeducTotal.Location = new Point(0x1de, 0x59);
            this.textDeducTotal.MaxLength = 15;
            this.textDeducTotal.Name = "textDeducTotal";
            this.textDeducTotal.ReadOnly = true;
            this.textDeducTotal.Size = new Size(0x54, 20);
            this.textDeducTotal.TabIndex = 0x13;
            this.textDeducTotal.Text = "0";
            this.textDeducTotal.TextAlign = HorizontalAlignment.Right;
            this.textDeducTotal.Leave += new EventHandler(this.textDeducTotal_Leave);
            this.label18.AutoSize = true;
            this.label18.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label18.Location = new Point(0x1af, 0x81);
            this.label18.Name = "label18";
            this.label18.Size = new Size(0x31, 0x18);
            this.label18.TabIndex = 20;
            this.label18.Text = "NET";
            this.textNet.BackColor = SystemColors.Control;
            this.textNet.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textNet.Location = new Point(0x1de, 0x7e);
            this.textNet.MaxLength = 15;
            this.textNet.Name = "textNet";
            this.textNet.ReadOnly = true;
            this.textNet.Size = new Size(0x54, 0x1d);
            this.textNet.TabIndex = 0x15;
            this.textNet.Text = "0";
            this.textNet.TextAlign = HorizontalAlignment.Right;
            this.textNet.TextChanged += new EventHandler(this.textNet_TextChanged);
            this.label45.AutoSize = true;
            this.label45.Location = new Point(0x1c3, 0xa4);
            this.label45.Name = "label45";
            this.label45.Size = new Size(0x15, 13);
            this.label45.TabIndex = 0x17;
            this.label45.Text = "+/-";
            this.textVariance.Location = new Point(0x1de, 0xa1);
            this.textVariance.MaxLength = 15;
            this.textVariance.Name = "textVariance";
            this.textVariance.ReadOnly = true;
            this.textVariance.Size = new Size(0x54, 20);
            this.textVariance.TabIndex = 0x16;
            this.textVariance.Text = "0";
            this.textVariance.TextAlign = HorizontalAlignment.Right;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x16, 0x1a);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x47, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Delivery Note";
            this.label6.Visible = false;
            this.label6.Click += new EventHandler(this.label6_Click);
            this.textDN.CharacterCasing = CharacterCasing.Upper;
            this.textDN.Location = new Point(0x5f, 0x17);
            this.textDN.MaxLength = 30;
            this.textDN.Name = "textDN";
            this.textDN.Size = new Size(0xef, 20);
            this.textDN.TabIndex = 3;
            this.textDN.Visible = false;
            this.textDN.TextChanged += new EventHandler(this.textDN_TextChanged);
            this.label33.AutoSize = true;
            this.label33.Cursor = Cursors.Arrow;
            this.label33.Location = new Point(0x237, 15);
            this.label33.Name = "label33";
            this.label33.Size = new Size(0x55, 13);
            this.label33.TabIndex = 0x18;
            this.label33.Text = "Commodity Type";
            this.label33.Visible = false;
            this.textCommType.CharacterCasing = CharacterCasing.Upper;
            this.textCommType.Location = new Point(0x292, 12);
            this.textCommType.Name = "textCommType";
            this.textCommType.ReadOnly = true;
            this.textCommType.Size = new Size(0x15, 20);
            this.textCommType.TabIndex = 0x1a;
            this.textCommType.Visible = false;
            this.label7.AutoSize = true;
            this.label7.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label7.Location = new Point(0x1a0, 0xd0);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x66, 13);
            this.label7.TabIndex = 0x20;
            this.label7.Text = "DO Quantity Left";
            this.quantityLeft.AutoSize = true;
            this.quantityLeft.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.quantityLeft.Location = new Point(0x238, 0xd0);
            this.quantityLeft.Name = "quantityLeft";
            this.quantityLeft.Size = new Size(14, 13);
            this.quantityLeft.TabIndex = 0x1b;
            this.quantityLeft.Text = "0";
            this.quantityLeft.TextAlign = ContentAlignment.TopRight;
            this.panel2.Controls.Add(this.label34);
            this.panel2.Controls.Add(this.textDeduction);
            this.panel2.Controls.Add(this.label32);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Controls.Add(this.label1STO1DO);
            this.panel2.Controls.Add(this.buttonStorage);
            this.panel2.Controls.Add(this.textStorage);
            this.panel2.Controls.Add(this.labelStorage);
            this.panel2.Controls.Add(this.labelStorageName);
            this.panel2.Controls.Add(this.labelConvUnit);
            this.panel2.Controls.Add(this.textConvNett);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.labelZWB);
            this.panel2.Controls.Add(this.labelKB);
            this.panel2.Controls.Add(this.panelSTO1DO);
            this.panel2.Controls.Add(this.textEstate);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.textTransporter2);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.textRName);
            this.panel2.Controls.Add(this.textRCode);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.textCont);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.buttonAdd);
            this.panel2.Controls.Add(this.textDate1st);
            this.panel2.Controls.Add(this.quantityLeft);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.textCommType);
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.textVariance);
            this.panel2.Controls.Add(this.label45);
            this.panel2.Controls.Add(this.textNet);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.textDeducTotal);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.button11);
            this.panel2.Controls.Add(this.textDO);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.textEstQty);
            this.panel2.Controls.Add(this.textFactOty);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.textTruck);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.textTransporter);
            this.panel2.Controls.Add(this.labelDriverName);
            this.panel2.Controls.Add(this.textDriverID);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.labelTransporterName);
            this.panel2.Controls.Add(this.shapeContainer1);
            this.panel2.Dock = DockStyle.Top;
            this.panel2.Location = new Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x2d2, 0x1d8);
            this.panel2.TabIndex = 0x3f;
            this.panel2.Paint += new PaintEventHandler(this.panel2_Paint);
            this.label34.AutoSize = true;
            this.label34.Location = new Point(0xde, 370);
            this.label34.Name = "label34";
            this.label34.Size = new Size(20, 13);
            this.label34.TabIndex = 0x2f;
            this.label34.Text = "Kg";
            this.textDeduction.Location = new Point(0x84, 0x16f);
            this.textDeduction.Name = "textDeduction";
            this.textDeduction.ReadOnly = true;
            this.textDeduction.Size = new Size(0x52, 20);
            this.textDeduction.TabIndex = 0;
            this.textDeduction.Text = "0";
            this.textDeduction.TextAlign = HorizontalAlignment.Right;
            this.label32.AutoSize = true;
            this.label32.Location = new Point(70, 370);
            this.label32.Name = "label32";
            this.label32.Size = new Size(0x38, 13);
            this.label32.TabIndex = 0x36;
            this.label32.Text = "Deduction";
            this.label31.AutoSize = true;
            this.label31.Location = new Point(0x10b, 0x144);
            this.label31.Name = "label31";
            this.label31.Size = new Size(0x41, 13);
            this.label31.TabIndex = 0x2d;
            this.label31.Text = "Factory Nett";
            this.label1STO1DO.AutoSize = true;
            this.label1STO1DO.Location = new Point(0x1a0, 0xe3);
            this.label1STO1DO.Name = "label1STO1DO";
            this.label1STO1DO.Size = new Size(0x59, 13);
            this.label1STO1DO.TabIndex = 0x1f;
            this.label1STO1DO.Text = "*1x STO = 1x DO";
            this.buttonStorage.Location = new Point(0xdb, 0x19d);
            this.buttonStorage.Margin = new Padding(0);
            this.buttonStorage.Name = "buttonStorage";
            this.buttonStorage.Size = new Size(0x17, 0x17);
            this.buttonStorage.TabIndex = 0x33;
            this.buttonStorage.Text = "...";
            this.buttonStorage.UseVisualStyleBackColor = true;
            this.textStorage.CharacterCasing = CharacterCasing.Upper;
            this.textStorage.Location = new Point(0x84, 0x1a0);
            this.textStorage.MaxLength = 5;
            this.textStorage.Name = "textStorage";
            this.textStorage.Size = new Size(0x53, 20);
            this.textStorage.TabIndex = 5;
            this.labelStorage.AutoSize = true;
            this.labelStorage.Location = new Point(0x52, 0x1a3);
            this.labelStorage.Name = "labelStorage";
            this.labelStorage.Size = new Size(0x2c, 13);
            this.labelStorage.TabIndex = 0x34;
            this.labelStorage.Text = "Storage";
            this.labelStorageName.AutoSize = true;
            this.labelStorageName.Location = new Point(0xf5, 0x1a3);
            this.labelStorageName.Name = "labelStorageName";
            this.labelStorageName.Size = new Size(0x48, 13);
            this.labelStorageName.TabIndex = 50;
            this.labelStorageName.Text = "StorageName";
            this.labelConvUnit.AutoSize = true;
            this.labelConvUnit.Location = new Point(0xd8, 0x189);
            this.labelConvUnit.Name = "labelConvUnit";
            this.labelConvUnit.Size = new Size(80, 13);
            this.labelConvUnit.TabIndex = 0x31;
            this.labelConvUnit.Text = "Convertion Unit";
            this.textConvNett.Location = new Point(0x84, 390);
            this.textConvNett.Name = "textConvNett";
            this.textConvNett.Size = new Size(0x53, 20);
            this.textConvNett.TabIndex = 4;
            this.textConvNett.Text = "0";
            this.textConvNett.TextAlign = HorizontalAlignment.Right;
            this.label30.AutoSize = true;
            this.label30.Location = new Point(14, 0x189);
            this.label30.Name = "label30";
            this.label30.Size = new Size(0x73, 13);
            this.label30.TabIndex = 0x35;
            this.label30.Text = "Qty Convertion (Comm)";
            this.labelZWB.AutoSize = true;
            this.labelZWB.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelZWB.ForeColor = Color.Red;
            this.labelZWB.Location = new Point(5, 0x1c3);
            this.labelZWB.Name = "labelZWB";
            this.labelZWB.Size = new Size(0xe9, 0x10);
            this.labelZWB.TabIndex = 0x38;
            this.labelZWB.Text = "Please Synchron this DO to ";
            this.labelKB.AutoSize = true;
            this.labelKB.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelKB.Location = new Point(0x238, 0x112);
            this.labelKB.Name = "labelKB";
            this.labelKB.Size = new Size(150, 20);
            this.labelKB.TabIndex = 0x1c;
            this.labelKB.Text = "*Kawasan Berikat";
            this.panelSTO1DO.Controls.Add(this.text1DOSTO);
            this.panelSTO1DO.Controls.Add(this.label27);
            this.panelSTO1DO.Controls.Add(this.text1STO);
            this.panelSTO1DO.Controls.Add(this.label28);
            this.panelSTO1DO.Controls.Add(this.label29);
            this.panelSTO1DO.Controls.Add(this.shapeContainer2);
            this.panelSTO1DO.Location = new Point(0x1a9, 0x133);
            this.panelSTO1DO.Name = "panelSTO1DO";
            this.panelSTO1DO.Size = new Size(0x121, 0x67);
            this.panelSTO1DO.TabIndex = 0x6a;
            this.text1DOSTO.CharacterCasing = CharacterCasing.Upper;
            this.text1DOSTO.Enabled = false;
            this.text1DOSTO.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.text1DOSTO.Location = new Point(0x59, 0x39);
            this.text1DOSTO.MaxLength = 20;
            this.text1DOSTO.Name = "text1DOSTO";
            this.text1DOSTO.Size = new Size(0xa5, 0x1d);
            this.text1DOSTO.TabIndex = 1;
            this.label27.AutoSize = true;
            this.label27.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label27.Location = new Point(0x1f, 0x3f);
            this.label27.Name = "label27";
            this.label27.Size = new Size(0x3b, 0x10);
            this.label27.TabIndex = 4;
            this.label27.Text = "DO STO";
            this.text1STO.CharacterCasing = CharacterCasing.Upper;
            this.text1STO.Enabled = false;
            this.text1STO.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.text1STO.Location = new Point(0x59, 0x18);
            this.text1STO.MaxLength = 20;
            this.text1STO.Name = "text1STO";
            this.text1STO.Size = new Size(0xa5, 0x1d);
            this.text1STO.TabIndex = 0;
            this.label28.AutoSize = true;
            this.label28.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label28.Location = new Point(0x2f, 0x21);
            this.label28.Name = "label28";
            this.label28.Size = new Size(0x24, 0x10);
            this.label28.TabIndex = 3;
            this.label28.Text = "STO";
            this.label29.AutoSize = true;
            this.label29.Font = new Font("Arial Narrow", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label29.Location = new Point(0xa3, 1);
            this.label29.Name = "label29";
            this.label29.Size = new Size(0x5b, 15);
            this.label29.TabIndex = 2;
            this.label29.Text = "* for 1xSTO = 1xDO";
            this.shapeContainer2.Location = new Point(0, 0);
            this.shapeContainer2.Margin = new Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            Shape[] shapeArray2 = new Shape[] { this.rectangleShape1 };
            this.shapeContainer2.Shapes.AddRange(shapeArray2);
            this.shapeContainer2.Size = new Size(0x121, 0x67);
            this.shapeContainer2.TabIndex = 5;
            this.shapeContainer2.TabStop = false;
            this.rectangleShape1.BorderColor = SystemColors.ControlDark;
            this.rectangleShape1.Location = new Point(0x19, 9);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new Size(0xf1, 0x52);
            this.textEstate.AutoCompleteSource = AutoCompleteSource.RecentlyUsedList;
            this.textEstate.Location = new Point(0x17e, 0xf2);
            this.textEstate.Name = "textEstate";
            this.textEstate.ReadOnly = true;
            this.textEstate.Size = new Size(180, 20);
            this.textEstate.TabIndex = 30;
            this.label26.AutoSize = true;
            this.label26.Location = new Point(0x153, 0xf5);
            this.label26.Name = "label26";
            this.label26.Size = new Size(0x25, 13);
            this.label26.TabIndex = 0x1d;
            this.label26.Text = "Estate";
            this.textTransporter2.CharacterCasing = CharacterCasing.Upper;
            this.textTransporter2.Location = new Point(0x80, 0x126);
            this.textTransporter2.Name = "textTransporter2";
            this.textTransporter2.ReadOnly = true;
            this.textTransporter2.Size = new Size(150, 20);
            this.textTransporter2.TabIndex = 0x29;
            this.label25.AutoSize = true;
            this.label25.Location = new Point(0x40, 0x129);
            this.label25.Name = "label25";
            this.label25.Size = new Size(0x3d, 13);
            this.label25.TabIndex = 40;
            this.label25.Text = "Transporter";
            this.textRName.Location = new Point(0xc1, 0x10c);
            this.textRName.Name = "textRName";
            this.textRName.ReadOnly = true;
            this.textRName.Size = new Size(0x171, 20);
            this.textRName.TabIndex = 0x27;
            this.textRCode.Location = new Point(0x80, 0x10c);
            this.textRCode.Name = "textRCode";
            this.textRCode.ReadOnly = true;
            this.textRCode.Size = new Size(0x3b, 20);
            this.textRCode.TabIndex = 0x26;
            this.label23.AutoSize = true;
            this.label23.Location = new Point(15, 0x10f);
            this.label23.Name = "label23";
            this.label23.Size = new Size(0x6b, 13);
            this.label23.TabIndex = 0x25;
            this.label23.Text = "Relation Code/Name";
            this.textCont.Location = new Point(0x80, 0xf2);
            this.textCont.Name = "textCont";
            this.textCont.ReadOnly = true;
            this.textCont.Size = new Size(180, 20);
            this.textCont.TabIndex = 0x24;
            this.textCont.TextChanged += new EventHandler(this.textCont_TextChanged);
            this.label24.AutoSize = true;
            this.label24.Location = new Point(0x37, 0xf5);
            this.label24.Name = "label24";
            this.label24.Size = new Size(0x43, 13);
            this.label24.TabIndex = 0x23;
            this.label24.Text = "Contract No.";
            this.button5.Location = new Point(0x1f8, 0x1b2);
            this.button5.Name = "button5";
            this.button5.Size = new Size(0x4b, 0x21);
            this.button5.TabIndex = 0x39;
            this.button5.Text = "&Delete DO";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new EventHandler(this.button5_Click);
            this.buttonAdd.Location = new Point(0x1a3, 0x1b2);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new Size(0x4b, 0x21);
            this.buttonAdd.TabIndex = 6;
            this.buttonAdd.Text = "&Add DO";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new EventHandler(this.buttonAdd_Click);
            this.textDate1st.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textDate1st.Location = new Point(0x263, 0x26);
            this.textDate1st.Name = "textDate1st";
            this.textDate1st.ReadOnly = true;
            this.textDate1st.Size = new Size(0x44, 20);
            this.textDate1st.TabIndex = 0x19;
            this.textDate1st.Text = "08/08/2013";
            this.textDate1st.Visible = false;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.buttonCancel);
            this.panel1.Controls.Add(this.textDN);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x270);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x2d2, 0x3e);
            this.panel1.TabIndex = 1;
            this.button1.Location = new Point(0x1cb, 9);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x6d, 0x2f);
            this.button1.TabIndex = 0;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.dgvDO.AllowUserToAddRows = false;
            this.dgvDO.AllowUserToDeleteRows = false;
            this.dgvDO.AllowUserToResizeRows = false;
            this.dgvDO.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDO.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgvDO.ColumnHeadersDefaultCellStyle = style;
            this.dgvDO.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgvDO.DefaultCellStyle = style2;
            this.dgvDO.Dock = DockStyle.Fill;
            this.dgvDO.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvDO.Location = new Point(0, 0x1d8);
            this.dgvDO.MultiSelect = false;
            this.dgvDO.Name = "dgvDO";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgvDO.RowHeadersDefaultCellStyle = style3;
            this.dgvDO.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDO.Size = new Size(0x2d2, 0x98);
            this.dgvDO.TabIndex = 0;
            this.dgvDO.CellContentClick += new DataGridViewCellEventHandler(this.dgvDO_CellContentClick);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x2d2, 0x2ae);
            base.ControlBox = false;
            base.Controls.Add(this.dgvDO);
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.panel1);
            base.Name = "FormTransSplitRef";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Split Reference";
            base.Load += new EventHandler(this.FormTransSplitRef_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransSplitRef_KeyPress);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panelSTO1DO.ResumeLayout(false);
            this.panelSTO1DO.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((ISupportInitialize) this.dgvDO).EndInit();
            base.ResumeLayout(false);
        }

        private void label6_Click(object sender, EventArgs e)
        {
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
        }

        private DataRow ReplaceDOitem(string[] pArg)
        {
            this.tblTransDO.DR = this.tblTransDO.DT.NewRow();
            this.tblTransDO.DR["Coy"] = WBData.sCoyCode;
            this.tblTransDO.DR["Location_Code"] = WBData.sLocCode;
            this.tblTransDO.DR["Transaction_Code"] = pArg[15];
            this.tblTransDO.DR["Ref"] = this.pRef;
            this.tblTransDO.DR["DO_No"] = pArg[1];
            this.tblTransDO.DR["Comm_Code"] = pArg[2];
            this.tblTransDO.DR["Confirmation"] = pArg[3];
            this.tblTransDO.DR["Contract"] = pArg[4];
            this.tblTransDO.DR["Relation_Code"] = pArg[5];
            this.tblTransDO.DR["Relation_Name"] = pArg[6];
            this.tblTransDO.DR["Netto"] = Program.StrToDouble(pArg[7], 2);
            this.tblTransDO.DR["Estate_qty"] = Program.StrToDouble(pArg[8], 2);
            this.tblTransDO.DR["Agen"] = pArg[9];
            this.tblTransDO.DR["Estate"] = pArg[10];
            this.tblTransDO.DR["ConvNett"] = Program.StrToDouble(pArg[11], 2);
            this.tblTransDO.DR["ConvUnit"] = pArg[12];
            this.tblTransDO.DR["PI_No"] = pArg[13];
            this.tblTransDO.DR["Transporter_Code"] = pArg[14];
            this.tblTransDO.DR["Storage_code"] = pArg[0x10];
            this.tblTransDO.DR["STO1X"] = pArg[0x11];
            this.tblTransDO.DR["DO1X"] = pArg[0x12];
            return this.tblTransDO.DR;
        }

        private void saveSplit(string zRef)
        {
            this.tblTransSplit.OpenTable("wb_transaction", "Select * From wb_transSplit where " + WBData.CompanyLocation(" and ref = '" + zRef + "'"), WBData.conn);
            if (this.tblTransSplit.DT.Rows.Count > 0)
            {
                this.tblTransSplit.DT.Rows[0].Delete();
                this.tblTransSplit.Save();
                this.tblTransSplit.ReOpen();
            }
            this.tblTransSplit.DR = this.tblTransSplit.DT.NewRow();
            foreach (DataColumn column in this.tblTransSplit.DT.Columns)
            {
                if (column.ColumnName.ToUpper() != "UNIQ")
                {
                    this.tblTransSplit.DR[column.ColumnName] = this.tblTrans.DR[column.ColumnName];
                }
                this.tblTransSplit.DR["Ref"] = zRef;
            }
            this.tblTransSplit.DT.Rows.Add(this.tblTransSplit.DR);
            this.tblTransSplit.Save();
            base.Close();
        }

        private void saveTrans(string zFlag)
        {
            WBTable table = new WBTable();
            table.OpenTable("tbl_transDO", "Select * from wb_transDO where " + WBData.CompanyLocation(" and ref = '" + this.pRef + zFlag + "'"), WBData.conn);
            int recNo = 0;
            foreach (DataGridViewRow row2 in (IEnumerable) this.dgvDO.Rows)
            {
                string[] aField = new string[] { "ref" };
                string[] aFind = new string[] { this.pRef + zFlag };
                recNo = table.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    table.DT.Rows[recNo].Delete();
                    table.Save();
                    table.ReOpen();
                }
            }
            this.ext = 0x3f;
            int num2 = 0;
            foreach (DataGridViewRow row3 in (IEnumerable) this.dgvDO.Rows)
            {
                table.DR = table.DT.NewRow();
                int num3 = 0;
                while (true)
                {
                    if (num3 >= this.tblTransDO.DT.Columns.Count)
                    {
                        this.ext++;
                        table.DR["Coy"] = WBData.sCoyCode;
                        table.DR["Location_Code"] = WBData.sLocCode;
                        table.DR["Ref"] = (num2 <= 0) ? (this.pRef + zFlag) : (this.pRef + zFlag + WBUtility.getSplitV2Ext(this.ext));
                        num2++;
                        table.DT.Rows.Add(table.DR);
                        table.Save();
                        break;
                    }
                    bool flag2 = this.dgvDO.Columns[num3].Name.ToUpper() != "UNIQ";
                    if (flag2 && ((this.dgvDO.Columns[num3].Name == table.DT.Columns[num3].ColumnName) && (row3.Cells[num3].Value.ToString() != "")))
                    {
                        table.DR[num3] = row3.Cells[num3].Value.ToString();
                    }
                    if (this.dgvDO.Columns[num3].Name.ToUpper() == "DO_NO")
                    {
                        table.DR[num3] = row3.Cells[num3].Value.ToString() + zFlag;
                    }
                    num3++;
                }
            }
            this.tblTrans.DR.BeginEdit();
            this.tblTrans.DR["Split"] = "Y";
            if (this.tblTrans.DR["WX"].ToString() == "2X")
            {
                if (Program.StrToDouble(this.tblTrans.DR["_1ST"].ToString(), 0) > Program.StrToDouble(this.tblTrans.DR["_2ND"].ToString(), 0))
                {
                    this.tblTrans.DR["_1ST"] = this.dgvDO.Rows[0].Cells["Bruto"].Value.ToString();
                }
                else
                {
                    this.tblTrans.DR["_2ND"] = this.dgvDO.Rows[0].Cells["Bruto"].Value.ToString();
                }
            }
            this.tblTrans.DR["Gross_estate"] = Program.StrToDouble(this.textTareEstate.Text, 0) + Program.StrToDouble(this.dgvDO.Rows[0].Cells["estate_qty"].Value.ToString(), 0);
            this.tblTrans.DR["net_estate"] = this.dgvDO.Rows[0].Cells["estate_qty"].Value.ToString();
            this.tblTrans.DR["Gross"] = this.dgvDO.Rows[0].Cells["Bruto"].Value.ToString();
            this.tblTrans.DR["Tare"] = this.dgvDO.Rows[0].Cells["Tarra"].Value.ToString();
            this.tblTrans.DR["Net"] = this.dgvDO.Rows[0].Cells["Netto"].Value.ToString();
            this.tblTrans.DR["posted"] = "N";
            this.tblTrans.DR["checksum"] = this.tblTrans.Checksum(this.tblTrans.DR);
            this.tblTrans.DR.EndEdit();
            this.tblTrans.Save();
            this.ext = 0x40;
            DataRow row = this.tblTrans.DT.Rows[0];
            int num4 = 1;
            while (true)
            {
                if (num4 >= this.dgvDO.Rows.Count)
                {
                    this.tblTrans.Save();
                    this.tblTransQC.Save();
                    return;
                }
                this.tblTrans.DR = this.tblTrans.DT.NewRow();
                int num5 = 0;
                while (true)
                {
                    if (num5 >= this.tblTrans.DT.Columns.Count)
                    {
                        this.tblTrans.DR["Split"] = "X";
                        if (this.tblTrans.DR["WX"].ToString() == "2X")
                        {
                            if (Program.StrToDouble(this.tblTrans.DR["_1ST"].ToString(), 0) > Program.StrToDouble(this.tblTrans.DR["_2ND"].ToString(), 0))
                            {
                                this.tblTrans.DR["_1ST"] = this.dgvDO.Rows[num4].Cells["Bruto"].Value.ToString();
                                this.tblTrans.DR["_2ND"] = "0";
                            }
                            else
                            {
                                this.tblTrans.DR["_1ST"] = "0";
                                this.tblTrans.DR["_2ND"] = this.dgvDO.Rows[num4].Cells["Bruto"].Value.ToString();
                            }
                        }
                        this.ext++;
                        if ((this.textCommType.Text.Trim() == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                        {
                            string[] textArray3 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(true) };
                            this.tblTrans.DR["Delivery_Note"] = string.Concat(textArray3);
                        }
                        else if ((this.textCommType.Text.Trim() == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                        {
                            string[] textArray4 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(true) };
                            this.tblTrans.DR["Delivery_Note"] = string.Concat(textArray4);
                        }
                        this.tblTrans.DR["Ref"] = this.pRef + zFlag + WBUtility.getSplitV2Ext(this.ext);
                        this.tblTrans.DR["Gross_estate"] = this.dgvDO.Rows[num4].Cells["estate_qty"].Value.ToString();
                        this.tblTrans.DR["DO_No"] = this.dgvDO.Rows[num4].Cells["DO_No"].Value.ToString();
                        if (WBSetting.checkISCC == "Y")
                        {
                            string[] aField = new string[] { "DO_NO" };
                            string[] aFind = new string[] { this.tblTrans.DR["DO_No"].ToString() };
                            if (this.tblDO.GetData(aField, aFind)["ISCC"].ToString() != "Y")
                            {
                                this.tblTrans.DR["ISCC_Checked"] = "N";
                                this.tblTrans.DR["ISCC_No"] = "";
                                this.tblTrans.DR["ISCC_No2"] = "";
                                this.tblTrans.DR["ISCC_Weight"] = Convert.ToDouble(0);
                                this.tblTrans.DR["ISCC_GC_Checked"] = "N";
                            }
                            else
                            {
                                this.tblTrans.DR["ISCC_Checked"] = "Y";
                                this.setISCC();
                                this.tblTrans.DR["ISCC_No"] = this.ISCC_No;
                                this.tblTrans.DR["ISCC_No2"] = this.ISCC_No2;
                                this.tblTrans.DR["ISCC_Weight"] = Convert.ToDouble(this.GHG);
                                this.tblTrans.DR["ISCC_GC_Checked"] = this.GC;
                            }
                        }
                        this.tblTrans.DR["net_estate"] = this.dgvDO.Rows[num4].Cells["estate_qty"].Value.ToString();
                        this.tblTrans.DR["Tare_estate"] = "0";
                        this.tblTrans.DR["Relation_Code"] = this.dgvDO.Rows[num4].Cells["Relation_Code"].Value.ToString();
                        this.tblTrans.DR["posted"] = "N";
                        this.tblTrans.DR["Gross"] = this.dgvDO.Rows[num4].Cells["Bruto"].Value.ToString();
                        this.tblTrans.DR["Tare"] = this.dgvDO.Rows[num4].Cells["Tarra"].Value.ToString();
                        this.tblTrans.DR["Printed"] = "0";
                        this.tblTrans.DR["Received"] = Convert.ToString((double) (Program.StrToDouble(this.dgvDO.Rows[num4].Cells["Bruto"].Value.ToString(), 0) - Program.StrToDouble(this.dgvDO.Rows[num4].Cells["Tarra"].Value.ToString(), 0)));
                        this.tblTrans.DR["Net"] = this.dgvDO.Rows[num4].Cells["Netto"].Value.ToString();
                        this.tblTrans.DR["Deduction"] = "0";
                        this.tblTrans.DR["checksum"] = this.tblTrans.Checksum(this.tblTrans.DR);
                        this.tblTrans.DT.Rows.Add(this.tblTrans.DR);
                        int num6 = 0;
                        while (true)
                        {
                            if (num6 >= this.qCount)
                            {
                                num4++;
                                break;
                            }
                            DataRow row4 = this.tblTransQC.DT.Rows[num6];
                            this.tblTransQC.DR = this.tblTransQC.DT.NewRow();
                            int num7 = 0;
                            while (true)
                            {
                                if (num7 >= this.tblTransQC.DT.Columns.Count)
                                {
                                    this.tblTransQC.DR["Ref"] = this.pRef + zFlag + WBUtility.getSplitV2Ext(this.ext);
                                    this.tblTransQC.DT.Rows.Add(this.tblTransQC.DR);
                                    num6++;
                                    break;
                                }
                                bool flag19 = this.tblTransQC.DT.Columns[num7].ColumnName.ToUpper() != "UNIQ";
                                if (flag19 && (row4[num7].ToString().Trim() != ""))
                                {
                                    this.tblTransQC.DR[this.tblTransQC.DT.Columns[num7].ColumnName] = row4[this.tblTransQC.DT.Columns[num7].ColumnName].ToString();
                                }
                                if (this.tblTransQC.DT.Columns[num7].ColumnName.ToUpper() == "DO_NO")
                                {
                                    this.tblTransQC.DR[this.tblTransQC.DT.Columns[num7].ColumnName] = row4[this.tblTransQC.DT.Columns[num7].ColumnName].ToString() + zFlag;
                                }
                                num7++;
                            }
                        }
                        break;
                    }
                    bool flag10 = this.tblTrans.DT.Columns[num5].ColumnName.ToUpper() != "UNIQ";
                    if (flag10 && (row[num5].ToString().Trim() != ""))
                    {
                        this.tblTrans.DR[this.tblTrans.DT.Columns[num5].ColumnName] = row[num5].ToString();
                    }
                    num5++;
                }
            }
        }

        private void setISCC()
        {
            this.ISCC_No = WBSetting.Field("ISCC_No").ToString().Trim();
            this.ISCC_No2 = (this.dgvDO.Rows[0].Cells["Comm_Code"].Value.ToString().ToUpper() != "CPO") ? "" : this.SetNoISCC(true);
            if (WBSetting.Field("ISCC_GC_Checked").ToString() == "Y")
            {
                this.GC = "Y";
                this.GHG = "0";
            }
            else
            {
                this.GC = "N";
                this.GHG = (this.textCommType.Text.Trim() == "") ? "0.000" : WBSetting.Field("ISCC_Weight_" + this.textCommType.Text.Trim());
            }
        }

        private string SetNoISCC(bool pSave)
        {
            string str = "";
            DateTime time = DateTime.Parse(this.textDate1st.Text);
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "Select * From wb_ref where ", WBData.CompanyLocation(""), " and Ref_Code = 'ISCC' and Ref_Year ='", DateTime.Now.Year.ToString(), "' and Ref_Month = '", DateTime.Now.Month.ToString(), "'" };
            table.OpenTable("wb_ref", string.Concat(textArray1), WBData.conn);
            if (table.DT.Rows.Count == 0)
            {
                table.DR = table.DT.NewRow();
                table.DR["Coy"] = WBData.sCoyCode;
                table.DR["Location_code"] = WBData.sLocCode;
                table.DR["Ref_Code"] = "ISCC";
                table.DR["Ref_Year"] = DateTime.Now.Year.ToString();
                table.DR["Ref_Month"] = DateTime.Now.Month.ToString();
                table.DR["Ref_No"] = "0";
                table.DT.Rows.Add(table.DR);
                table.Save();
                table.ReOpen();
            }
            DataRow row = table.DT.Rows[0];
            string str2 = row["Ref_No"].ToString();
            this.nRef = Convert.ToInt32(str2) + 1;
            str = this.nRef.ToString().Trim().PadLeft(4, '0');
            str = row["Ref_Year"].ToString().PadLeft(2, '0') + row["Ref_month"].ToString().PadLeft(2, '0') + "-" + str;
            if (pSave)
            {
                table.ReOpen();
                table.DR = table.DT.Rows[0];
                table.DR.BeginEdit();
                table.DR["Ref_No"] = this.nRef.ToString();
                table.DR.EndEdit();
                table.Save();
            }
            table.Close();
            table.Dispose();
            return str;
        }

        private string SetNoSPB(bool pSave)
        {
            string str = "";
            DateTime time = DateTime.Parse(this.textDate1st.Text);
            WBTable table = new WBTable();
            string[] textArray1 = new string[9];
            textArray1[0] = "Select * From wb_ref where ";
            textArray1[1] = WBData.CompanyLocation("");
            textArray1[2] = " and Ref_Code = 'AUTOSPB";
            textArray1[3] = this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim();
            textArray1[4] = "' and Ref_Year ='";
            textArray1[5] = DateTime.Now.Year.ToString();
            textArray1[6] = "' and Ref_Month = '";
            textArray1[7] = DateTime.Now.Month.ToString();
            textArray1[8] = "'";
            table.OpenTable("wb_ref", string.Concat(textArray1), WBData.conn);
            if (table.DT.Rows.Count == 0)
            {
                table.DR = table.DT.NewRow();
                table.DR["Coy"] = WBData.sCoyCode;
                table.DR["Location_code"] = WBData.sLocCode;
                table.DR["Ref_Code"] = "AUTOSPB" + this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim();
                table.DR["Ref_Year"] = DateTime.Now.Year.ToString();
                table.DR["Ref_Month"] = DateTime.Now.Month.ToString();
                table.DR["Ref_No"] = "0";
                table.DT.Rows.Add(table.DR);
                table.Save();
                table.ReOpen();
            }
            string str2 = table.DT.Rows[0]["Ref_No"].ToString();
            this.nRef = Convert.ToInt32(str2) + 1;
            str = this.nRef.ToString().Trim().PadLeft(4, '0');
            if (pSave)
            {
                table.ReOpen();
                table.DR = table.DT.Rows[0];
                table.DR.BeginEdit();
                table.DR["Ref_No"] = this.nRef.ToString();
                table.DR.EndEdit();
                table.Save();
            }
            table.Close();
            table.Dispose();
            return str;
        }

        private void text1st_Leave(object sender, EventArgs e)
        {
            this.HitNet();
        }

        private void text2nd_Leave(object sender, EventArgs e)
        {
            this.HitNet();
        }

        private void text3rd_Leave(object sender, EventArgs e)
        {
            this.HitNet();
        }

        private void text4th_Leave(object sender, EventArgs e)
        {
            this.HitNet();
        }

        private void textCont_TextChanged(object sender, EventArgs e)
        {
        }

        private void textDeducTotal_Leave(object sender, EventArgs e)
        {
            this.HitNet();
        }

        private void textDN_TextChanged(object sender, EventArgs e)
        {
        }

        private void textDO_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDO_Leave(object sender, EventArgs e)
        {
            if (this.textDO.Text != "")
            {
                FormContract contract = new FormContract();
                string[] aField = new string[] { "DO_NO" };
                string[] aFind = new string[] { this.textDO.Text.Trim().ToUpper() };
                DataRow data = this.tblDO.GetData(aField, aFind);
                if (!ReferenceEquals(data, null))
                {
                    contract.ReturnRow = data;
                    if ((this.tolling != "6") || (contract.ReturnRow["tolling"].ToString().Trim() == "6"))
                    {
                        this.conRow = contract.ReturnRow;
                        this.chkqty = contract.ReturnRow["check_qty"].ToString();
                        this.tolerance = contract.ReturnRow["tolerance"].ToString();
                        this.qty = Convert.ToDouble(contract.ReturnRow["quantity"].ToString());
                        this.tolerance = Convert.ToString((double) ((Program.StrToDouble(this.tolerance, 0) / 100.0) * this.qty));
                        this.quantityLeft.Text = $"{Program.checkOS(contract.ReturnRow["Do_No"].ToString(), "", "", "N"):N0}";
                        this.textCont.Text = contract.ReturnRow["Contract"].ToString();
                        this.textTransporter2.Text = contract.ReturnRow["Transporter_code"].ToString();
                        this.textEstate.Text = contract.ReturnRow["Estate1_Code"].ToString();
                        this.labelKB.Visible = contract.ReturnRow["Berikat"].ToString().Trim() == "Y";
                        this.label1STO1DO.Visible = contract.ReturnRow["STO1DO"].ToString().Trim() == "Y";
                        this.lSTO1DO = contract.ReturnRow["STO1DO"].ToString().Trim() == "Y";
                        this.zCust.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" AND Relation_Code='" + contract.ReturnRow["Relation_Code"].ToString().Trim() + "'"), WBData.conn);
                        if (this.zCust.DT.Rows.Count > 0)
                        {
                            this.textRCode.Text = contract.ReturnRow["Relation_Code"].ToString().Trim();
                            this.textRName.Text = this.zCust.DT.Rows[0]["Relation_Name"].ToString().Trim();
                        }
                        if ((this.chkqty == "Y") && !((Convert.ToDouble(this.quantityLeft.Text) + Convert.ToDouble(this.tolerance)) != 0.0))
                        {
                            MessageBox.Show("This DO Already Completed, Do Quantity Left = " + this.quantityLeft.Text + " \nPlease choose another DO \nClick OK to Continue..", "W A R N I N G...");
                            this.textDO.Focus();
                        }
                        if (WBSetting.zwb == "Y")
                        {
                            this.labelZWB.Visible = contract.ReturnRow["ZWB"].ToString() != "Y";
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannnot Choose DO Other than Titip Timbun", "WARNING...");
                        this.textDO.Focus();
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Invalid DO Entry..", "Warning...");
                    this.button11.PerformClick();
                }
                contract.Dispose();
                this.text1STO.Enabled = true;
                this.text1DOSTO.Enabled = true;
                WBSetting.OpenSetting();
                if ((this.textCommType.Text.Trim() == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    string[] textArray3 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(false) };
                    this.textDN.Text = string.Concat(textArray3);
                }
                else if ((this.textCommType.Text.Trim() == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    string[] textArray4 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(false) };
                    this.textDN.Text = string.Concat(textArray4);
                }
            }
        }

        private void textDO_TextChanged(object sender, EventArgs e)
        {
        }

        private void textNet_TextChanged(object sender, EventArgs e)
        {
        }

        private void textNetEstate_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textEstQty);
            this.textFactOty.Text = Convert.ToString(Math.Round((double) (Convert.ToDouble(this.textEstQty.Text) + ((Convert.ToDouble(this.textVariance.Text) / Convert.ToDouble(this.textNetEstate.Text)) * Convert.ToDouble(this.textEstQty.Text)))));
        }

        private void textNetFactory_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textFactOty);
            if ((Program.StrToDouble(this.textNetEstate.Text, 0) > 0.0) && (this.textEstQty.Text.Trim() == "0"))
            {
                this.textEstQty.Text = this.textFactOty.Text;
            }
        }

        private void textTareEstate_Leave(object sender, EventArgs e)
        {
            double num = Math.Abs((double) (Convert.ToDouble(this.textGrossEstate.Text) - Convert.ToDouble(this.textTareEstate.Text)));
            this.textEstQty.Text = $"{num:N0}";
        }
    }
}

