﻿namespace WindowsFormsApplication1
{
    using OffLine.Installer;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Properties;
    using WindowsFormsApplication1.Utility;

    public class FormEntryDeliveryNote : Form
    {
        public WBTable tblGatepass = new WBTable();
        private WBTable tblTrans = new WBTable();
        private string cField;
        public bool pReturn = false;
        public string deliveryNote;
        private string cardNo = "";
        private string uniqCardNo = "";
        private bool scanStatus = false;
        private IContainer components = null;
        private GroupBox groupBox3;
        private TextBox txtDeliveryNote;
        private Label label6;
        private Button btn_cancel;
        private Button btn_save;
        private Label labelScanMessage;
        private TextBox textCard;
        private Label label3;
        private Label label1;
        private InstallerClass installerClass1;
        private ComboBox comboBoxRef;

        public FormEntryDeliveryNote()
        {
            this.InitializeComponent();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.pReturn = false;
            base.Close();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (this.txtDeliveryNote.Text.Trim() == "")
            {
                MessageBox.Show(Resource.RegisGatepassMess_070, "Warning...", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.txtDeliveryNote.Focus();
            }
            else
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE ref = '" + this.comboBoxRef.Text + "'", WBData.conn);
                table.DR = table.DT.Rows[0];
                string pUniq = table.DR["uniq"].ToString();
                if (!table.Locked(pUniq, '1'))
                {
                    table.RLock(pUniq, true);
                    table.DR.BeginEdit();
                    table.DR["delivery_note"] = this.txtDeliveryNote.Text.Trim();
                    table.DR.EndEdit();
                    table.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "ENTRY DELIVERY NOTE" };
                    Program.updateLogHeader("wb_transaction", pUniq, logField, logValue);
                    table.Close();
                    table.Dispose();
                    table.RLock(pUniq, false);
                    this.pReturn = true;
                    base.Close();
                }
            }
        }

        private void comboBoxRef_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (DataRow row in this.tblTrans.DT.Rows)
            {
                if (row["ref"].ToString() == this.comboBoxRef.Text)
                {
                    this.txtDeliveryNote.Text = row["delivery_note"].ToString();
                    break;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormEntryDeliveryNote_Load(object sender, EventArgs e)
        {
            this.labelScanMessage.Text = "";
            this.labelScanMessage.ForeColor = Color.Black;
            string sqltext = "";
            if (WBSetting.gatepass_registration)
            {
                sqltext = "SELECT uniq, WX, card_no, Gatepass_Number, Truck_Number, tanker_no, License_No, Transporter_Code, delivery_note, seal, \r\n                GatePass_Remark, In_Date, In_Time, Create_By, Create_Date, Change_By, Change_Date, Submit_Gatepass FROM wb_gatepass \r\n                WHERE " + WBData.CompanyLocation("") + " AND (Submit_Gatepass IS NULL OR Submit_Gatepass='' OR submit_Gatepass = 'N')  AND  \r\n                (Deleted = 'N' OR Deleted IS NULL OR Deleted = '')";
            }
            else
            {
                this.cField = " Coy, Location_code, wx, card_no, Gatepass_number, TA_number,Ref, transaction_code, transporter_code,  truck_number, trailer_number,  In_Date, In_time,  Out_Date, Submit_Gatepass, Submit_Date, Submit_Time, GatePass_Remark,  Deleted, uniq";
                sqltext = "select " + this.cField + " from vw_gatepass_oth WHERE " + WBData.CompanyLocation(" and (Reject = 'N')AND(Gatepass_Number is not null)  And ((Ref is null) OR (Ref = ''))  And (((Submit_Gatepass IS NULL) or (Submit_Gatepass='') or (submit_Gatepass = 'N'))  AND ((Deleted = 'N') or (Deleted is null) or (Deleted =''))) and WB = '0'  order by Gatepass_Number Asc");
            }
            this.tblGatepass.OpenTable("wb_gatepass", sqltext, WBData.conn);
            this.comboBoxRef.Enabled = false;
            this.txtDeliveryNote.Enabled = false;
            this.btn_save.Enabled = false;
            this.Text = "Scan Card";
            this.textCard.Focus();
            this.textCard.Select();
        }

        private void InitializeComponent()
        {
            this.groupBox3 = new GroupBox();
            this.comboBoxRef = new ComboBox();
            this.label1 = new Label();
            this.txtDeliveryNote = new TextBox();
            this.label6 = new Label();
            this.btn_cancel = new Button();
            this.btn_save = new Button();
            this.labelScanMessage = new Label();
            this.textCard = new TextBox();
            this.label3 = new Label();
            this.installerClass1 = new InstallerClass();
            this.groupBox3.SuspendLayout();
            base.SuspendLayout();
            this.groupBox3.Controls.Add(this.comboBoxRef);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.txtDeliveryNote);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.btn_cancel);
            this.groupBox3.Controls.Add(this.btn_save);
            this.groupBox3.Location = new Point(20, 80);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(0x13c, 0xa2);
            this.groupBox3.TabIndex = 0x6c;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Delivery Information";
            this.comboBoxRef.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboBoxRef.FormattingEnabled = true;
            this.comboBoxRef.Location = new Point(0x60, 0x26);
            this.comboBoxRef.Name = "comboBoxRef";
            this.comboBoxRef.Size = new Size(0xc2, 0x15);
            this.comboBoxRef.TabIndex = 0x74;
            this.comboBoxRef.SelectedIndexChanged += new EventHandler(this.comboBoxRef_SelectedIndexChanged);
            this.label1.Location = new Point(9, 0x29);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x51, 0x12);
            this.label1.TabIndex = 0x73;
            this.label1.Text = "Reference No.";
            this.label1.TextAlign = ContentAlignment.TopRight;
            this.txtDeliveryNote.CharacterCasing = CharacterCasing.Upper;
            this.txtDeliveryNote.Location = new Point(0x60, 0x4a);
            this.txtDeliveryNote.MaxLength = 50;
            this.txtDeliveryNote.Name = "txtDeliveryNote";
            this.txtDeliveryNote.Size = new Size(0xc2, 20);
            this.txtDeliveryNote.TabIndex = 12;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x13, 0x4d);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x47, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Delivery Note";
            this.label6.TextAlign = ContentAlignment.TopRight;
            this.btn_cancel.Image = Resources.cancel_24px1;
            this.btn_cancel.ImageAlign = ContentAlignment.MiddleLeft;
            this.btn_cancel.Location = new Point(0xc4, 110);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new Size(0x5e, 0x23);
            this.btn_cancel.TabIndex = 110;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new EventHandler(this.btn_cancel_Click);
            this.btn_save.Image = Resources.Save;
            this.btn_save.ImageAlign = ContentAlignment.MiddleLeft;
            this.btn_save.Location = new Point(0x60, 110);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new Size(0x5e, 0x23);
            this.btn_save.TabIndex = 0x6d;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new EventHandler(this.btn_save_Click);
            this.labelScanMessage.AutoSize = true;
            this.labelScanMessage.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelScanMessage.Location = new Point(0x74, 50);
            this.labelScanMessage.Name = "labelScanMessage";
            this.labelScanMessage.Size = new Size(0x56, 15);
            this.labelScanMessage.TabIndex = 0x71;
            this.labelScanMessage.Text = "ScanMessage";
            this.labelScanMessage.TextAlign = ContentAlignment.MiddleLeft;
            this.labelScanMessage.Visible = false;
            this.textCard.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textCard.Location = new Point(0x77, 0x15);
            this.textCard.Name = "textCard";
            this.textCard.Size = new Size(0xd9, 0x1a);
            this.textCard.TabIndex = 0x6f;
            this.textCard.TextChanged += new EventHandler(this.textCard_TextChanged);
            this.textCard.KeyDown += new KeyEventHandler(this.textCard_KeyDown);
            this.textCard.KeyPress += new KeyPressEventHandler(this.textCard_KeyPress);
            this.label3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(11, 0x18);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x53, 0x12);
            this.label3.TabIndex = 0x70;
            this.label3.Text = "Card No.";
            this.label3.TextAlign = ContentAlignment.TopRight;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(360, 0x109);
            base.ControlBox = false;
            base.Controls.Add(this.labelScanMessage);
            base.Controls.Add(this.textCard);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.groupBox3);
            base.Name = "FormEntryDeliveryNote";
            this.Text = "Entry Delivery Note";
            base.Load += new EventHandler(this.FormEntryDeliveryNote_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textCard_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Tuple<bool, string, string, string, string, string, string> tuple = WBCard.scanCard(this.textCard.Text, "Delivery", this.comboBoxRef.Text);
                this.scanStatus = tuple.Item1;
                this.labelScanMessage.Text = tuple.Item2;
                this.textCard.Text = tuple.Item7;
                this.textCard.SelectAll();
                this.cardNo = WBCard.getUniqCardNo(this.textCard.Text);
                string[] aField = new string[] { "Card_No" };
                string[] aFind = new string[] { this.cardNo };
                DataRow data = this.tblGatepass.GetData(aField, aFind);
                if (data != null)
                {
                    if (data["wx"].ToString() != "4")
                    {
                        if (data["wx"].ToString() == "1")
                        {
                            if (data["submit_gatepass"].ToString() == "Y")
                            {
                                MessageBox.Show(Resource.RegisGatepassMess_072, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.RegisGatepassMess_071, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.RegisGatepassMess_064, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                }
                if (!tuple.Item1)
                {
                    MessageBox.Show(tuple.Item2, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.comboBoxRef.Items.Clear();
                    this.comboBoxRef.Enabled = false;
                    this.txtDeliveryNote.Enabled = false;
                    this.btn_save.Enabled = false;
                    this.textCard.SelectAll();
                    this.textCard.Focus();
                    this.labelScanMessage.ForeColor = Color.Red;
                }
                else
                {
                    this.labelScanMessage.ForeColor = Color.Black;
                    string str = data["gatepass_number"].ToString();
                    string[] textArray3 = new string[] { " SELECT * FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND gatepass_number = '", str, "'  AND ((Deleted = 'N' OR Deleted = '' OR Deleted IS NULL) OR (Deleted = 'Y' AND cancel_type = 'R'))  ORDER BY uniq DESC" };
                    this.tblTrans.OpenTable("wb_transaction", string.Concat(textArray3), WBData.conn);
                    if (this.tblTrans.DT.Rows.Count <= 0)
                    {
                        this.comboBoxRef.Enabled = false;
                        this.txtDeliveryNote.Enabled = false;
                        this.btn_save.Enabled = false;
                        MessageBox.Show(Resource.RegisGatepassMess_073, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        this.comboBoxRef.Items.Clear();
                        this.comboBoxRef.Enabled = true;
                        this.txtDeliveryNote.Enabled = true;
                        this.btn_save.Enabled = true;
                        foreach (DataRow row2 in this.tblTrans.DT.Rows)
                        {
                            this.comboBoxRef.Items.Add(row2["ref"].ToString());
                        }
                        this.comboBoxRef.SelectedIndex = 0;
                    }
                }
            }
        }

        private void textCard_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void textCard_TextChanged(object sender, EventArgs e)
        {
            if ((this.textCard.Text.Trim() != this.cardNo) && this.scanStatus)
            {
                this.scanStatus = false;
                this.labelScanMessage.Text = "";
            }
        }
    }
}

