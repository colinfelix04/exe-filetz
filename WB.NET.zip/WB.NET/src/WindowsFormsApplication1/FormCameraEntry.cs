﻿namespace WindowsFormsApplication1
{
    using Encryption.Utility;
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCameraEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public WBTable trans = new WBTable();
        private IContainer components = null;
        private Label label2;
        public TextBox txt_camera_code;
        private Label label1;
        private TextBox txt_ip;
        private Label label5;
        private TextBox txt_url;
        private GroupBox gb_account;
        private Label label4;
        private Label label3;
        private TextBox txt_user;
        private Button btn_save;
        private Button btn_cancel;
        private Button btn_test;
        private CheckBox checkPwd;
        private TextBox txt_password;

        public FormCameraEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (this.txt_camera_code.Text != "")
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_camera", "SELECT Uniq FROM wb_camera WHERE camera_Code ='" + this.txt_camera_code.Text.Trim() + "'", WBData.conn);
                if ((table.DT.Rows.Count <= 0) || (this.pMode != "ADD"))
                {
                    table.Dispose();
                    if (this.pMode == "EDIT")
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = Resource.Col_Camera_Code },
                            textRefNo = { Text = this.txt_camera_code.Text },
                            Text = Resource.Title_Change_Reason,
                            label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                        }
                        else
                        {
                            return;
                        }
                    }
                    Cursor.Current = Cursors.WaitCursor;
                    this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                    this.zTable.ReOpen();
                    if (this.pMode == "ADD")
                    {
                        this.zTable.DR = this.zTable.DT.NewRow();
                    }
                    else
                    {
                        this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                        this.logKey = this.zTable.DR["uniq"].ToString();
                        this.zTable.DR.BeginEdit();
                    }
                    this.zTable.DR["camera_code"] = this.txt_camera_code.Text.Trim();
                    this.zTable.DR["ip_address"] = this.txt_ip.Text.Trim();
                    this.zTable.DR["web_url"] = this.txt_url.Text.Trim();
                    this.zTable.DR["username"] = this.txt_user.Text.Trim();
                    this.zTable.DR["password"] = WBEncryption.Encrypt(this.txt_password.Text.Trim());
                    if (this.pMode == "ADD")
                    {
                        this.zTable.DR["Create_By"] = WBUser.UserID;
                        this.zTable.DR["Create_Date"] = DateTime.Now;
                        this.zTable.DT.Rows.Add(this.zTable.DR);
                    }
                    else
                    {
                        this.zTable.DR["Edit_By"] = WBUser.UserID;
                        this.zTable.DR["Edit_Date"] = DateTime.Now;
                        this.zTable.DR.EndEdit();
                    }
                    this.zTable.Save();
                    if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
                    {
                        if (this.pMode == "ADD")
                        {
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_camera", "SELECT uniq FROM wb_camera WHERE camera_code = '" + this.txt_camera_code.Text.Trim() + "'", WBData.conn);
                            this.logKey = table2.DT.Rows[0]["uniq"].ToString();
                            table2.Dispose();
                        }
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_camera", this.logKey, logField, logValue);
                    }
                    this.saved = true;
                    Cursor.Current = Cursors.Default;
                    base.Close();
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_Camera_Code_Exist);
                    this.txt_camera_code.Focus();
                }
            }
        }

        private void btn_test_Click(object sender, EventArgs e)
        {
            FormCameraPreview preview = new FormCameraPreview {
                camera_code = this.txt_camera_code.Text.Trim(),
                webcam_name = this.txt_url.Text.Trim(),
                ip_address = this.txt_ip.Text.Trim(),
                username = this.txt_user.Text.Trim(),
                password = this.txt_password.Text.Trim(),
                web_url = this.txt_url.Text.Trim(),
                camera_type = (this.txt_ip.Text.Trim() == "") ? "WEB_CAMERA" : "IP_CAMERA"
            };
            preview.ShowDialog();
            preview.Dispose();
        }

        private void checkPwd_CheckedChanged(object sender, EventArgs e)
        {
            this.txt_password.UseSystemPasswordChar = !this.checkPwd.Checked;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormCameraEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.pMode == "ADD")
            {
                this.txt_camera_code.Enabled = true;
            }
            else if ((this.pMode == "EDIT") || (this.pMode == "VIEW"))
            {
                this.txt_camera_code.Enabled = false;
                this.txt_camera_code.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["camera_code"].Value.ToString();
                this.txt_ip.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["ip_address"].Value.ToString();
                this.txt_url.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["web_url"].Value.ToString();
                this.txt_user.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["username"].Value.ToString();
                this.txt_password.Text = WBEncryption.Decrypt(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["password"].Value.ToString());
            }
            if (this.pMode == "VIEW")
            {
                this.btn_save.Visible = false;
            }
        }

        private void InitializeComponent()
        {
            this.label2 = new Label();
            this.txt_camera_code = new TextBox();
            this.label1 = new Label();
            this.txt_ip = new TextBox();
            this.label5 = new Label();
            this.txt_url = new TextBox();
            this.gb_account = new GroupBox();
            this.txt_password = new TextBox();
            this.checkPwd = new CheckBox();
            this.label4 = new Label();
            this.label3 = new Label();
            this.txt_user = new TextBox();
            this.btn_save = new Button();
            this.btn_cancel = new Button();
            this.btn_test = new Button();
            this.gb_account.SuspendLayout();
            base.SuspendLayout();
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x21, 0x17);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x47, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Camera Code";
            this.txt_camera_code.Location = new Point(0x7b, 20);
            this.txt_camera_code.Name = "txt_camera_code";
            this.txt_camera_code.Size = new Size(0x9b, 20);
            this.txt_camera_code.TabIndex = 4;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x21, 0x31);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3a, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "IP Address";
            this.txt_ip.Location = new Point(0x7b, 0x2e);
            this.txt_ip.Name = "txt_ip";
            this.txt_ip.Size = new Size(0x9b, 20);
            this.txt_ip.TabIndex = 6;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x21, 0x4b);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x37, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Web URL";
            this.txt_url.Location = new Point(0x7b, 0x48);
            this.txt_url.Name = "txt_url";
            this.txt_url.Size = new Size(0x199, 20);
            this.txt_url.TabIndex = 12;
            this.gb_account.Controls.Add(this.txt_password);
            this.gb_account.Controls.Add(this.checkPwd);
            this.gb_account.Controls.Add(this.label4);
            this.gb_account.Controls.Add(this.label3);
            this.gb_account.Controls.Add(this.txt_user);
            this.gb_account.Location = new Point(30, 110);
            this.gb_account.Name = "gb_account";
            this.gb_account.Size = new Size(0x1f6, 0x4b);
            this.gb_account.TabIndex = 14;
            this.gb_account.TabStop = false;
            this.gb_account.Text = "Account";
            this.txt_password.Location = new Point(0x77, 0x2b);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new Size(0x9b, 20);
            this.txt_password.TabIndex = 0x4a;
            this.txt_password.UseSystemPasswordChar = true;
            this.checkPwd.AutoSize = true;
            this.checkPwd.Location = new Point(280, 0x2e);
            this.checkPwd.Name = "checkPwd";
            this.checkPwd.Size = new Size(0x65, 0x11);
            this.checkPwd.TabIndex = 0x10;
            this.checkPwd.Text = "Show password";
            this.checkPwd.UseVisualStyleBackColor = true;
            this.checkPwd.CheckedChanged += new EventHandler(this.checkPwd_CheckedChanged);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x10, 0x2f);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x35, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Password";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x10, 0x15);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x37, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Username";
            this.txt_user.Location = new Point(0x77, 0x12);
            this.txt_user.Name = "txt_user";
            this.txt_user.Size = new Size(0x9b, 20);
            this.txt_user.TabIndex = 12;
            this.btn_save.Font = new Font("Microsoft Sans Serif", 9.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btn_save.Location = new Point(0x178, 0xcf);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new Size(0x4b, 0x20);
            this.btn_save.TabIndex = 15;
            this.btn_save.Text = "&Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new EventHandler(this.btn_save_Click);
            this.btn_cancel.Font = new Font("Microsoft Sans Serif", 9.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btn_cancel.Location = new Point(0x1c9, 0xcf);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new Size(0x4b, 0x20);
            this.btn_cancel.TabIndex = 0x10;
            this.btn_cancel.Text = "C&ancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new EventHandler(this.btn_cancel_Click);
            this.btn_test.Font = new Font("Microsoft Sans Serif", 9.5f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btn_test.Location = new Point(30, 0xcf);
            this.btn_test.Name = "btn_test";
            this.btn_test.Size = new Size(0x6c, 0x20);
            this.btn_test.TabIndex = 0x11;
            this.btn_test.Text = "&Test Capture";
            this.btn_test.UseVisualStyleBackColor = true;
            this.btn_test.Click += new EventHandler(this.btn_test_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x237, 0x101);
            base.Controls.Add(this.btn_test);
            base.Controls.Add(this.btn_cancel);
            base.Controls.Add(this.btn_save);
            base.Controls.Add(this.gb_account);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.txt_url);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.txt_ip);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.txt_camera_code);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormCameraEntry";
            base.ShowInTaskbar = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "FormCameraEntry";
            base.Load += new EventHandler(this.FormCameraEntry_Load);
            this.gb_account.ResumeLayout(false);
            this.gb_account.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label2.Text = Resource.Col_Camera_Code;
            this.label1.Text = Resource.Col_IP_Address;
            this.label5.Text = Resource.Col_Web_Url;
            this.gb_account.Text = Resource.Gbx_Account;
            this.checkPwd.Text = Resource.Chk_Show_Password;
            this.label4.Text = Resource.User_006;
            this.label3.Text = Resource.User_003;
            this.btn_save.Text = Resource.Btn_Save;
            this.btn_cancel.Text = Resource.Btn_Cancel;
            this.btn_test.Text = Resource.Btn_Test_Capture;
        }
    }
}

