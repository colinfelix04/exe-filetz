﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.Windows.Forms;

    public class RepCommTol : Form
    {
        public string chckSQL;
        public string DoNo;
        public bool firsttime = true;
        private WBTable vContLog2 = new WBTable();
        private WBTable tbl_DO;
        private IContainer components = null;
        public Button button2;
        public Button button1;
        public Label labelProses2;
        public Label labelProses1;
        public Label labelcommodity;
        public TextBox textDoNo;
        public CheckBox checkDate;
        public GroupBox groupBox1;
        public DateTimePicker monthCalendar1;
        public Label label5;
        public Label label6;
        public DateTimePicker monthCalendar2;

        public RepCommTol()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                WBTable vContLog = new WBTable();
                vContLog = this.initTable(this.checkDate.Checked, this.monthCalendar1.Value, this.monthCalendar2.Value, this.textDoNo.Text, WBData.sCoyCode, WBData.sLocCode);
                if (vContLog.DT.Rows.Count <= 0)
                {
                    MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    HTML html = new HTML();
                    html = this.generateRep(vContLog, this.monthCalendar1.Value, this.textDoNo.Text, WBData.sCoyCode, WBData.sLocCode);
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + html.File) }
                    };
                    report.ShowDialog();
                    this.labelProses1.Text = "";
                    this.labelProses1.Refresh();
                    this.labelProses2.Text = "";
                    this.labelProses2.Refresh();
                    html.Dispose();
                    report.Dispose();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void checkDate_CheckedChanged(object sender, EventArgs e)
        {
            this.groupBox1.Enabled = this.checkDate.Checked;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public HTML generateRep(WBTable vContLog, DateTime dt, string txtdono, string coy, string loc)
        {
            HTML html2;
            this.labelProses1.Text = "0/" + vContLog.DT.Rows.Count;
            HTML html = new HTML();
            string path = html.File + @"\LogReport";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            if (txtdono == "")
            {
                html2 = html;
                string[] textArray2 = new string[] { html2.File, @"\LogReport\", coy, loc, "COMM_CONT_LOG_", dt.ToString("ddMMyyyy"), ".htm" };
                html2.File = string.Concat(textArray2);
            }
            else
            {
                string str2 = txtdono.Replace("/", "");
                html2 = html;
                string[] textArray1 = new string[] { html2.File, @"\LogReport\", coy, loc, "COMM_CONT_LOG_", str2, ".htm" };
                html2.File = string.Concat(textArray1);
            }
            html.Title = "Changes List of Commodity Tolerance per Contract";
            html.Open();
            html.Write(html.Style());
            html.Write("<br><font size=5><b>CHANGES LIST OF COMMODITY TOLERANCE PER CONTRACT</b></font><br>");
            string[] textArray3 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
            html.Write(string.Concat(textArray3));
            string[] textArray4 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
            html.Write(string.Concat(textArray4));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            html.Write("<br><br>");
            html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
            html.Write("<tr class=bd>");
            html.Write("<td>Report Date</td>");
            html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
            html.Write("</tr>");
            html.Write("</table>");
            html.Write("<br/><br/><br/>");
            int num = 1;
            this.DoNo = txtdono;
            foreach (DataRow row in vContLog.DT.Rows)
            {
                if (this.firsttime || (this.DoNo.Trim().ToUpper() != row["Key_1"].ToString().Trim().ToUpper()))
                {
                    this.DoNo = row["Key_1"].ToString().Trim().ToUpper();
                    if (!this.firsttime)
                    {
                        html.Write("</table>");
                        html.Write("<br>");
                        html.Write("<br>");
                        html.Write("<br>");
                    }
                    html.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                    html.Write("<tr class='bd'> ");
                    html.Write("<th> DO/PO/SO No.</th> ");
                    html.Write("<td>" + row["key_1"].ToString().Trim() + "</td> </tr>");
                    html.Write("<tr class='bd'> ");
                    html.Write("<th> Commodity Code </th> ");
                    html.Write("<td>" + row["Comm_Code"].ToString().Trim() + "</td> </tr>");
                    html.Write("<tr class='bd'> ");
                    html.Write("<th> Commodity Desc </th> ");
                    html.Write("<td>" + row["Comm_Name"].ToString().Trim() + "</td> </tr>");
                    html.Write("<tr class='bd'> ");
                    html.Write("<th> Commodity Tolerance (std.) </th> ");
                    html.Write("<td>" + row["Comm_Tol"].ToString().Trim() + " % </td> </tr>");
                    html.Write("<tr class='bd'> ");
                    html.Write("<th> Contract No./Vessel</th> ");
                    html.Write("<td>" + row["Contract"].ToString().Trim() + "</td> </tr></table>");
                    this.firsttime = false;
                    html.Write("<br>");
                    html.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                    html.Write("<tr class='bd'> ");
                    html.Write("<th rowspan=2> Date</th> ");
                    html.Write("<th rowspan=2> Time </th>");
                    html.Write("<th colspan=2> Before</th> ");
                    html.Write("<th colspan=2> After </th>");
                    html.Write("<th rowspan=2> Token No. </th></tr>");
                    html.Write("<tr class='bd'> ");
                    html.Write("<th>Tolerance</th>");
                    html.Write("<th>Allowed Trx</th>");
                    html.Write("<th>Tolerance</th>");
                    html.Write("<th>Allowed Trx</th> </tr>");
                }
                html.Write("<tr class='bd'> ");
                DateTime time2 = Convert.ToDateTime(row["datetime1"]);
                html.Write("<td>" + time2.ToString("dd/MM/yyyy") + "</td>");
                html.Write("<td>" + time2.ToString("HH:mm:ss") + "</td>");
                if (this.vContLog2.DT.Rows.Count <= num)
                {
                    html.Write("<td align = right>" + row["Comm_Tol"].ToString().Trim() + "</td>");
                    html.Write("<td align = right> - </td>");
                }
                else if (row["key_1"].ToString().Trim() == this.vContLog2.DT.Rows[num]["key_1"].ToString().Trim())
                {
                    html.Write("<td align = right>" + this.vContLog2.DT.Rows[num]["Tolerance"].ToString().Trim() + "</td>");
                    html.Write("<td align = right>" + this.vContLog2.DT.Rows[num]["UnitofTrx"].ToString().Trim() + "</td>");
                }
                else
                {
                    html.Write("<td align = right>" + row["Comm_Tol"].ToString().Trim() + "</td>");
                    html.Write("<td align = right> - </td>");
                }
                html.Write("<td align = right>" + row["Tolerance"].ToString().Trim() + "</td>");
                html.Write("<td align = right>" + row["UnitofTrx"].ToString().Trim() + "</td>");
                html.Write("<td>" + row["Token_No"].ToString().Trim() + "</td> </tr>");
                num++;
            }
            html.Write("</table>");
            html.Write("<br>");
            html.Write("<br>");
            html.writeSign();
            html.Close();
            return html;
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.labelProses2 = new Label();
            this.labelProses1 = new Label();
            this.labelcommodity = new Label();
            this.textDoNo = new TextBox();
            this.checkDate = new CheckBox();
            this.groupBox1 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label5 = new Label();
            this.label6 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1cb, 0x67);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x22);
            this.button2.TabIndex = 0x49;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x1cb, 0x38);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x22);
            this.button1.TabIndex = 0x48;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0x170, 0x1c);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0xd6, 13);
            this.labelProses2.TabIndex = 0x4e;
            this.labelProses2.Text = "Progresssss . . . . . . . . . . . . . . . . . ";
            this.labelProses2.TextAlign = ContentAlignment.MiddleRight;
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(0x173, 15);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0xd3, 13);
            this.labelProses1.TabIndex = 0x4f;
            this.labelProses1.Text = "1/88888";
            this.labelProses1.TextAlign = ContentAlignment.MiddleRight;
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(15, 0x76);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3f, 13);
            this.labelcommodity.TabIndex = 0x55;
            this.labelcommodity.Text = "DO/SO No.";
            this.textDoNo.CharacterCasing = CharacterCasing.Upper;
            this.textDoNo.Location = new Point(0x57, 0x73);
            this.textDoNo.Name = "textDoNo";
            this.textDoNo.Size = new Size(0xc0, 20);
            this.textDoNo.TabIndex = 0x54;
            this.checkDate.AutoSize = true;
            this.checkDate.Location = new Point(14, 0x26);
            this.checkDate.Name = "checkDate";
            this.checkDate.Size = new Size(60, 0x11);
            this.checkDate.TabIndex = 0x57;
            this.checkDate.Text = "byDate";
            this.checkDate.UseVisualStyleBackColor = true;
            this.checkDate.CheckedChanged += new EventHandler(this.checkDate_CheckedChanged);
            this.groupBox1.Controls.Add(this.monthCalendar1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.monthCalendar2);
            this.groupBox1.Enabled = false;
            this.groupBox1.Location = new Point(11, 0x3b);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x178, 0x2d);
            this.groupBox1.TabIndex = 0x56;
            this.groupBox1.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(80, 0x10);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(8, 0x13);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x3e, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "From Date :";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xc6, 0x13);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x34, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x100, 0x10);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x252, 0x95);
            base.ControlBox = false;
            base.Controls.Add(this.checkDate);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.textDoNo);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Name = "RepCommTol";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Changes of Commodity Tolerance per Contract";
            base.Load += new EventHandler(this.RepCommTol_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        public WBTable initTable(bool byDate, DateTime dateFrom, DateTime dateTo, string DoNo, string coy, string loc)
        {
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "select token.*, cont.[Contract], cont.Do_No, cont.comm_code, comm.Comm_Name, comm.Tolerance as comm_tol from wb_token as token left outer join wb_contract as cont on cont.Do_No = token.key_1 and cont.coy = token.coy and cont.location_code = token.location_code left outer join wb_commodity as comm on cont.comm_code = comm.comm_code and cont.coy = comm.coy and cont.location_code = comm.location_code where token.Token_Code = 'COMM_CONT_TOL' and token.completed = 'Y' and token.coy = '", coy, "' and token.location_code = '", loc, "'" };
            string sqltext = string.Concat(textArray1);
            string str2 = sqltext;
            if (byDate)
            {
                sqltext = (sqltext + " AND (token.datetime1 >='" + dateFrom.ToString("yyyy-MM-dd") + " 00:00:00'") + " AND token.datetime1 <='" + dateTo.ToString("yyyy-MM-dd") + " 00:00:00')";
            }
            else if (DoNo != "")
            {
                sqltext = sqltext + " AND token.key_1='" + DoNo + "'";
                str2 = str2 + " AND token.key_1='" + DoNo + "'";
            }
            this.chckSQL = sqltext;
            sqltext = sqltext + " order by token.key_1 ASC, token.datetime1 desc";
            str2 = str2 + " order by token.key_1 ASC, token.datetime1 desc";
            table.OpenTable("wb_token", sqltext, WBData.conn);
            this.vContLog2.OpenTable("wb_token", str2, WBData.conn);
            return table;
        }

        private void RepCommTol_Load(object sender, EventArgs e)
        {
            this.tbl_DO = new WBTable();
            this.tbl_DO.OpenTable("wb_token", "Select distinct key_1 from wb_token where " + WBData.CompanyLocation("and token_code = 'COMM_CONT_TOL' and completed = 'Y'"), WBData.conn);
            Program.AutoComp(this.tbl_DO, "key_1", this.textDoNo);
        }
    }
}

