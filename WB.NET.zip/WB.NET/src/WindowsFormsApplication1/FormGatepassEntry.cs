﻿namespace WindowsFormsApplication1
{
    using CrystalDecisions.CrystalReports.Engine;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormGatepassEntry : Form
    {
        public WBTable tblTrans = new WBTable();
        public WBTable tblTruck = new WBTable();
        public WBTable tblContainer = new WBTable();
        public WBTable tblCust = new WBTable();
        public WBTable tblDriver = new WBTable();
        public WBTable tblTransporter = new WBTable();
        public WBTable tblTransType = new WBTable();
        public WBTable tblLocation = new WBTable();
        public WBTable tblGatepassType1 = new WBTable();
        public WBTable tblGatepassType2 = new WBTable();
        public WBTable tblTAApprove = new WBTable();
        public WBTable tblGatepass = new WBTable();
        private ReportDocument ticketRpt = new ReportDocument();
        private FormRpt fRpt = new FormRpt();
        private WBTable tblTmp = new WBTable();
        private string sqlTmp = "";
        public bool saved = false;
        public int nRef;
        private string gatepassType1 = "";
        private string gatepassType2 = "";
        private string changeReason = "";
        private string logKey = "";
        private string gType = "";
        private DateTime aDateTime;
        public string pMode = "";
        public string sUniq = "";
        private string oldTruck = "";
        private string oldTransType = "";
        private string oldDriver = "";
        private string oldTransporter = "";
        private bool ReplaceAll = false;
        private IContainer components = null;
        private Button buttonCancel;
        private Button buttonSave;
        private GroupBox groupGeneral;
        private Label label8;
        private TextBox textNet;
        private Label labelDriverName;
        private TextBox textGatepassType;
        private Label label12;
        private Label label10;
        private Button buttonContainer;
        private TextBox textContainer;
        private TextBox textTrailerNo;
        private Label label46;
        private Button buttonHaulier;
        private TextBox textHaulier;
        private Label label9;
        private Button buttonOwner;
        private TextBox textOwner;
        private Label labelRelation;
        private Label label5;
        private Label label6;
        private Button buttonTransporter;
        private TextBox textTransporter;
        private Label labelTransType;
        private ComboBox comTransType;
        private Button buttonTruck;
        public TextBox textTruck;
        private TextBox textDriverID;
        private Button buttonDriver;
        private Label label7;
        private Label labelTransporterName;
        private ComboBox comboVehicleDestination;
        private Label label4;
        private Label label1;
        public TextBox textGatepass_Number;
        private GroupBox groupReject;
        private CheckBox checkRejectComm;
        private CheckBox checkReject;
        private GroupBox groupPrint;
        private Label label14;
        private Label label13;
        private Label label15;
        private RadioButton radioGP2;
        private RadioButton radioGP1;
        private TextBox textGPQty;
        private TextBox textGPItem;
        private TextBox textReason;
        private GroupBox groupBox4;
        private RadioButton radioCommPart;
        private RadioButton radioCommFull;
        private TextBox textCommRetKet;
        private Label label16;
        private Label label18;
        private Label label21;
        private Label label22;
        private Label label19;
        private Label label20;
        public TextBox textGpManual;
        private TextBox textTimeSubmit;
        private TextBox textDateSubmit;
        private TextBox textTimeOut;
        private TextBox textDateOut;
        private TextBox textTimeIn;
        private TextBox textDateIn;
        private Label label23;
        private Label label24;
        private Label label17;
        private ComboBox comboGatepassType2;
        private ComboBox comboGatepassType1;
        private Button buttonPrint;
        private Button buttonLoad;
        private Button buttonRec;
        private Button buttonLoadCancel;
        private Button buttonRecCancel;
        private Label labelLoadTime;
        private Label labelLoadDate;
        private Label labelRecTime;
        private Label labelRecDate;
        private Label labelStatus;
        private TextBox textRef;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label label3;
        private Label label2;
        private TextBox textSubmitRemark;
        private Button buttonLoader;
        private TextBox textLoader;
        private Label label11;
        private Label labelTransName;

        public FormGatepassEntry()
        {
            this.InitializeComponent();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonContainer_Click(object sender, EventArgs e)
        {
            FormContainer container = new FormContainer {
                pMode = "CHOOSE",
                pFind = this.textContainer.Text
            };
            container.ShowDialog();
            if (container.ReturnRow != null)
            {
                this.textContainer.Text = container.ReturnRow["Container_Number"].ToString();
            }
            container.Dispose();
        }

        private void buttonDriver_Click(object sender, EventArgs e)
        {
            FormDriver driver = new FormDriver {
                pMode = "CHOOSE",
                pFind = this.textDriverID.Text
            };
            driver.ShowDialog();
            if (driver.ReturnRow != null)
            {
                this.textDriverID.Text = driver.ReturnRow["License_No"].ToString();
                this.labelDriverName.Text = driver.ReturnRow["Name"].ToString();
                if (this.textTruck.Text.Trim() == "")
                {
                    this.textTruck.Text = driver.ReturnRow["Truck_Number"].ToString();
                    this.textTruck.Focus();
                }
            }
            driver.Dispose();
        }

        private void buttonHaulier_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textHaulier.Text = vendor.ReturnRow["Relation_Code"].ToString();
                this.textHaulier.Focus();
            }
            vendor.Dispose();
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            this.labelLoadDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            this.labelLoadTime.Text = DateTime.Now.ToString("HH:mm:ss");
            this.checkGateAuth();
            this.checkStatus();
        }

        private void buttonLoadCancel_Click(object sender, EventArgs e)
        {
            this.labelLoadDate.Text = "";
            this.labelLoadTime.Text = "";
            this.checkGateAuth();
            this.checkStatus();
        }

        private void buttonLoader_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textLoader.Text = vendor.ReturnRow["Relation_Code"].ToString();
                this.textLoader.Focus();
            }
            vendor.Dispose();
        }

        private void buttonOwner_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textOwner.Text = vendor.ReturnRow["Relation_Code"].ToString();
                this.textOwner.Focus();
            }
            vendor.Dispose();
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            if ((this.comboVehicleDestination.Text.Length >= 5) && (this.comboVehicleDestination.Text.Substring(0, 5).ToUpper() == "STORE"))
            {
                if ((this.textGPItem.Text.Trim() != "") && (this.textGPQty.Text.Trim() != ""))
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_gatepass", "Select * from wb_Gatepass where " + WBData.CompanyLocation(" and uniq = '" + this.sUniq + "'"), WBData.conn);
                    string[] aField = new string[] { "uniq" };
                    string[] aFind = new string[] { this.sUniq };
                    table.DR = table.GetData(aField, aFind);
                    if (table.DR != null)
                    {
                        table.DR.BeginEdit();
                        this.logKey = table.DR["uniq"].ToString();
                        if (this.radioGP1.Checked)
                        {
                            table.DR["gp_purpose"] = "1";
                        }
                        else if (this.radioGP2.Checked)
                        {
                            table.DR["gp_purpose"] = "2";
                        }
                        table.DR["gp_item"] = this.textGPItem.Text;
                        table.DR["gp_qty"] = this.textGPQty.Text;
                        if (this.textDateOut.Text.Trim() != "")
                        {
                            table.DR["Out_Date"] = this.textDateOut.Text.Trim();
                        }
                        if (this.textTimeOut.Text.Trim() != "")
                        {
                            table.DR["Out_Time"] = this.textTimeOut.Text.Trim();
                        }
                        table.DR.EndEdit();
                        table.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "PRINT", WBUser.UserID, "Print Gatepass" };
                        Program.updateLogHeader("wb_gatepass", this.logKey, logField, logValue);
                    }
                    table.Dispose();
                }
                else
                {
                    MessageBox.Show(Resource.Gatepass_050, Resource.Title_002);
                    return;
                }
            }
            try
            {
                this.ticketRpt.Load(WBSetting.ticketGatepass);
                this.ticketRpt = Program.rptLogon(this.ticketRpt);
                this.fRpt.setReport(this.ticketRpt);
                this.print(this.textGatepass_Number.Text, this.labelStatus.Text, WBUser.UserID, this.ticketRpt);
            }
            catch
            {
                MessageBox.Show(Resource.Mes_165, Resource.Title_003);
                return;
            }
            base.Close();
        }

        private void buttonRec_Click(object sender, EventArgs e)
        {
            this.labelRecDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            this.labelRecTime.Text = DateTime.Now.ToString("HH:mm:ss");
            this.checkGateAuth();
            this.checkStatus();
        }

        private void buttonRecCancel_Click(object sender, EventArgs e)
        {
            this.labelRecDate.Text = "";
            this.labelRecTime.Text = "";
            this.checkGateAuth();
            this.checkStatus();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            WBTable table;
            TextBox[] aText = new TextBox[] { this.textTruck, this.textTransporter, this.textGatepassType, this.textDriverID };
            if (!Program.CheckEmpty(aText))
            {
                if (this.comboVehicleDestination.Text.Trim() != "")
                {
                    if (this.comboGatepassType1.Text.Trim() != "")
                    {
                        if ((this.comboGatepassType2.Text.Trim() != "") || (this.comboGatepassType2.Items.Count <= 0))
                        {
                            if (this.textGpManual.Text.Trim() == "")
                            {
                                this.textGpManual.Text = this.textGatepass_Number.Text;
                            }
                            if (this.pMode != "EDIT")
                            {
                                goto TR_0035;
                            }
                            else
                            {
                                table = new WBTable();
                                table.OpenTable("wb_trans", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" and Gatepass_Number='" + this.textGatepass_Number.Text.Trim() + "'"), WBData.conn);
                                if (table.DT.Rows.Count <= 0)
                                {
                                    goto TR_0036;
                                }
                                else if (MessageBox.Show(Resource.Mes_604, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                {
                                    int num = 0;
                                    while (true)
                                    {
                                        if (num < table.DT.Rows.Count)
                                        {
                                            table.DR = table.DT.Rows[num];
                                            if (!table.Locked(table.DR["uniq"].ToString(), '0'))
                                            {
                                                num++;
                                                continue;
                                            }
                                            MessageBox.Show(Resource.Mes_605, Resource.Title_008, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        }
                                        else
                                        {
                                            this.ReplaceAll = true;
                                            goto TR_0036;
                                        }
                                        break;
                                    }
                                }
                                else
                                {
                                    this.ReplaceAll = false;
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_163 + " " + this.textGatepassType.Text + " Type ", Resource.Title_002);
                            this.comboGatepassType2.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_162 + ":" + this.textGatepassType.Text, Resource.Title_002);
                        this.comboGatepassType1.Focus();
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_164, Resource.Title_002);
                    this.comboVehicleDestination.Focus();
                }
            }
            return;
        TR_0035:
            if (this.pMode == "EDIT")
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "Gatepass No" },
                    textRefNo = { Text = this.textGatepass_Number.Text },
                    Text = "CHANGE REASON",
                    label2 = { Text = "Change Reason : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            if (this.pMode == "ADD")
            {
                this.tblGatepass.DR = this.tblGatepass.DT.NewRow();
                this.tblGatepass.DR["Coy"] = WBData.sCoyCode;
                this.tblGatepass.DR["Location_code"] = WBData.sLocCode;
                this.tblGatepass.DR["In_Date"] = DateTime.Now.ToString("dd/MM/yyyy");
                this.tblGatepass.DR["In_Time"] = DateTime.Now.ToString("HH:mm:ss");
            }
            else if (this.pMode == "EDIT")
            {
                this.tblGatepass.DR.BeginEdit();
                this.logKey = this.tblGatepass.DR["uniq"].ToString();
            }
            this.tblGatepass.DR["Truck_number"] = this.textTruck.Text;
            this.tblGatepass.DR["Gatepass_number"] = this.textGatepass_Number.Text;
            this.tblGatepass.DR["gpManual"] = this.textGpManual.Text;
            this.tblGatepass.DR["Ref"] = this.textRef.Text;
            this.tblGatepass.DR["Trailer_number"] = this.textTrailerNo.Text;
            this.tblGatepass.DR["Container_number"] = this.textContainer.Text;
            this.tblGatepass.DR["Transporter_Code"] = this.textTransporter.Text;
            this.tblGatepass.DR["Transaction_Code"] = this.comTransType.Text;
            string[] aField = new string[] { "Transaction_code" };
            string[] aFind = new string[] { this.comTransType.Text };
            DataRow data = this.tblTransType.GetData(aField, aFind);
            if (data != null)
            {
                this.labelTransName.Text = data["Transaction_Name"].ToString();
            }
            this.tblGatepass.DR["License_No"] = this.textDriverID.Text;
            this.gType = (this.textGatepassType.Text != "INBOUND") ? "O" : "I";
            this.tblGatepass.DR["Gatepass_type"] = this.gType;
            this.tblGatepass.DR["Gatepass_type1"] = this.gatepassType1;
            this.tblGatepass.DR["Gatepass_type2"] = this.gatepassType2;
            this.tblGatepass.DR["OWner_Code"] = this.textOwner.Text;
            this.tblGatepass.DR["Loader_Code"] = this.textLoader.Text;
            this.tblGatepass.DR["Haulier_Code"] = this.textHaulier.Text;
            this.tblGatepass.DR["WB"] = this.comboVehicleDestination.SelectedIndex;
            if (this.labelRecDate.Text.Trim() != "")
            {
                this.tblGatepass.DR["ReceiptDate"] = this.labelRecDate.Text.Trim();
            }
            if (this.labelRecTime.Text.Trim() != "")
            {
                this.tblGatepass.DR["ReceiptTime"] = this.labelRecTime.Text.Trim();
            }
            if (this.labelLoadDate.Text.Trim() != "")
            {
                this.tblGatepass.DR["LoadDate"] = this.labelLoadDate.Text.Trim();
            }
            if (this.labelLoadTime.Text.Trim() != "")
            {
                this.tblGatepass.DR["LoadTime"] = this.labelLoadTime.Text.Trim();
            }
            if (this.textDateIn.Text.Trim() != "")
            {
                this.tblGatepass.DR["in_date"] = this.textDateIn.Text.Trim();
            }
            if (this.textTimeIn.Text.Trim() != "")
            {
                this.tblGatepass.DR["In_Time"] = this.textTimeIn.Text.Trim();
            }
            if (this.textDateOut.Text.Trim() != "")
            {
                this.tblGatepass.DR["Out_Date"] = this.textDateOut.Text.Trim();
            }
            if (this.textTimeOut.Text.Trim() != "")
            {
                this.tblGatepass.DR["Out_Time"] = this.textTimeOut.Text.Trim();
            }
            if (this.pMode == "SUBMIT")
            {
                this.tblGatepass.DR["Submit_gatepass"] = "Y";
                this.tblGatepass.DR["Submit_Date"] = DateTime.Now.ToString("dd/MM/yyyy");
                this.tblGatepass.DR["Submit_Time"] = DateTime.Now.ToString("HH:mm:ss");
                this.logKey = this.tblGatepass.DR["uniq"].ToString();
            }
            this.tblGatepass.DR["Submit_Remark"] = this.textSubmitRemark.Text;
            this.tblGatepass.DR["Reason"] = this.textReason.Text;
            this.tblGatepass.DR["Comm_Ret_Ket"] = this.textCommRetKet.Text;
            this.tblGatepass.DR["Reject"] = !this.checkReject.Checked ? "N" : "Y";
            this.tblGatepass.DR["Comm_Ret"] = !this.checkRejectComm.Checked ? "N" : "Y";
            if (this.radioGP1.Checked)
            {
                this.tblGatepass.DR["gp_purpose"] = "1";
            }
            else if (this.radioGP2.Checked)
            {
                this.tblGatepass.DR["gp_purpose"] = "2";
            }
            this.tblGatepass.DR["gp_item"] = this.textGPItem.Text;
            this.tblGatepass.DR["gp_qty"] = this.textGPQty.Text;
            if (this.pMode == "ADD")
            {
                this.tblGatepass.DR["Create_by"] = WBUser.UserID;
                this.tblGatepass.DR["Create_Date"] = DateTime.Now.ToString("dd/MM/yyyy");
                this.tblGatepass.DT.Rows.Add(this.tblGatepass.DR);
            }
            if (this.pMode == "EDIT")
            {
                this.tblGatepass.DR["Change_by"] = WBUser.UserID;
                this.tblGatepass.DR["Change_Date"] = DateTime.Now.ToString("dd/MM/yyyy");
                this.tblGatepass.DR.EndEdit();
            }
            this.tblGatepass.Save();
            if (((this.pMode == "EDIT") && this.ReplaceAll) && (((this.textDriverID.Text.Trim() != this.oldDriver.Trim()) || ((this.textTruck.Text.Trim() != this.oldTruck.Trim()) || (this.textTransporter.Text.Trim() != this.oldTransporter.Trim()))) || (this.comTransType.Text.Trim() != this.oldTransType.Trim())))
            {
                WBTable table2 = new WBTable();
                table2.OpenTable("wb_driver", "SELECT Name FROM wb_driver WHERE " + WBData.CompanyLocation(" AND License_No = '" + this.textDriverID.Text.Trim() + "' and (Deleted IS NULL OR Deleted <> 'Y') "), WBData.conn);
                table2.DR = table2.DT.Rows[0];
                string[] textArray3 = new string[] { "License_No", "Name", "Truck_Number", "Transporter_Code", "Transaction_Code" };
                string[] aNewValue = new string[] { this.textDriverID.Text.Trim(), table2.DR["Name"].ToString(), this.textTruck.Text.Trim(), this.textTransporter.Text.Trim(), this.comTransType.Text.Trim() };
                Program.ReplaceAll("wb_transaction", textArray3, aNewValue, " Gatepass_Number = '" + this.textGatepass_Number.Text.Trim() + "'", this.changeReason + " (Edit gatepass)");
                table2.Dispose();
                WBTable table3 = new WBTable();
                table3.OpenTable("wb_transaction", "SELECT ref FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Gatepass_Number = '" + this.textGatepass_Number.Text.Trim() + "'"), WBData.conn);
                table3.DR = table3.DT.Rows[0];
                string[] textArray5 = new string[] { "Transporter_Code", "Transaction_Code" };
                string[] textArray6 = new string[] { this.textTransporter.Text.Trim(), this.comTransType.Text.Trim() };
                Program.ReplaceAll("wb_transDO", textArray5, textArray6, " Ref = '" + table3.DR["Ref"].ToString() + "'", this.changeReason + " (Edit gatepass)");
                table3.Dispose();
            }
            if (((this.pMode == "ADD") || (this.pMode == "EDIT")) || (this.pMode == "SUBMIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table4 = new WBTable();
                    table4.OpenTable("wb_gatepass", "SELECT uniq FROM wb_gatepass WHERE " + WBData.CompanyLocation(" AND gatepass_number = '" + this.textGatepass_Number.Text + "'"), WBData.conn);
                    this.logKey = table4.DT.Rows[0]["uniq"].ToString();
                    table4.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_gatepass", this.logKey, logField, logValue);
            }
            this.saved = true;
            Cursor.Current = Cursors.Default;
            base.Close();
            return;
        TR_0036:
            table.Dispose();
            goto TR_0035;
        }

        private void buttonTransporter_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransporter.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.labelTransporterName.Text = transporter.ReturnRow["Transporter_Name"].ToString();
                this.textTransporter.Focus();
            }
            transporter.Dispose();
        }

        private void buttonTruck_Click(object sender, EventArgs e)
        {
            FormTruck truck = new FormTruck {
                pMode = "CHOOSE",
                pFind = this.textTruck.Text
            };
            truck.ShowDialog();
            if (truck.ReturnRow != null)
            {
                this.textTruck.Text = truck.ReturnRow["Truck_Number"].ToString();
                if ((this.textTransporter.Text.Trim() == "") && (truck.ReturnRow["Transporter_Code"].ToString().Trim() != ""))
                {
                    this.textTransporter.Text = truck.ReturnRow["Transporter_Code"].ToString();
                    string[] aField = new string[] { "Transporter_Code" };
                    string[] aFind = new string[] { this.textTransporter.Text };
                    DataRow data = this.tblTransporter.GetData(aField, aFind);
                    if (data != null)
                    {
                        this.labelTransporterName.Text = data["Transporter_Name"].ToString();
                    }
                }
            }
            truck.Dispose();
        }

        private void checkGateAuth()
        {
            this.buttonRec.Enabled = true;
            this.buttonRecCancel.Enabled = true;
            this.buttonLoad.Enabled = true;
            this.buttonLoadCancel.Enabled = true;
            if (Convert.ToInt16(WBUser.UserLevel) > 1)
            {
                this.buttonRec.Enabled = false;
                this.buttonRecCancel.Enabled = false;
                this.buttonLoad.Enabled = false;
                this.buttonLoadCancel.Enabled = false;
                if (WBUser.CheckTrustee("MN_GATERECEIPT", "V"))
                {
                    this.buttonRec.Enabled = true;
                    this.buttonRecCancel.Enabled = true;
                }
                if (WBUser.CheckTrustee("MN_GATELOAD", "V") && (this.labelRecDate.Text != ""))
                {
                    this.buttonLoad.Enabled = true;
                    this.buttonLoadCancel.Enabled = true;
                }
            }
        }

        private void checkStatus()
        {
            this.labelStatus.Text = "-";
            if (WBSetting.transflow == "3")
            {
                this.labelStatus.Text = (this.tblGatepass.DR["Approved"].ToString() != "Y") ? "-" : "GATE";
            }
            if (this.labelRecDate.Text != "")
            {
                this.labelStatus.Text = "Store";
                if (this.labelLoadDate.Text != "")
                {
                    this.labelStatus.Text = "Load/Unloading";
                }
            }
            if ((this.comboVehicleDestination.Text.Length > 5) && ((this.comboVehicleDestination.Text.Substring(0, 5) == "STORE") && (this.labelRecDate.Text == "")))
            {
                this.labelStatus.Text = "In Yard";
            }
            if (this.textGatepass_Number.Text != "")
            {
                this.tblTrans.OpenTable("wb_transaction", "Select * from WB_Transaction where gatepass_number = '" + this.textGatepass_Number.Text + "'", WBData.conn);
                if (this.tblTrans.DT.Rows.Count <= 0)
                {
                    if ((this.comboVehicleDestination.Text.Trim() == "WB") && (Convert.ToInt16(WBUser.UserLevel) > 1))
                    {
                        this.buttonRec.Enabled = false;
                        this.buttonRecCancel.Enabled = false;
                    }
                }
                else if (this.tblTrans.DT.Rows[0]["Report_date"].ToString() != "")
                {
                    this.labelStatus.Text = "Completed";
                }
                else if (this.labelRecDate.Text == "")
                {
                    this.labelStatus.Text = "In Yard";
                }
            }
            this.tblTrans.Dispose();
            if ((this.pMode != "ADD") && (this.tblGatepass.DR["Submit_date"].ToString().Trim() != ""))
            {
                this.labelStatus.Text = "SUBMITTED";
            }
            if (this.labelRecDate.Text != "")
            {
                this.buttonRec.Enabled = false;
            }
            if (this.labelLoadDate.Text != "")
            {
                this.buttonLoad.Enabled = false;
                this.buttonRecCancel.Enabled = false;
            }
        }

        private void comboGatepassType1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void comboGatepassType1_Leave(object sender, EventArgs e)
        {
            this.gatepass1_leave();
        }

        private void comboGatepassType2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void comboGatepassType2_Leave(object sender, EventArgs e)
        {
            this.gatepass2_leave();
        }

        private void comTransType_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void comTransType_Leave(object sender, EventArgs e)
        {
        }

        private void comTransType_TextChanged(object sender, EventArgs e)
        {
            this.TransType_Leave();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormGatepassEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormGatepassEntry_Load(object sender, EventArgs e)
        {
            this.translate();
            Cursor.Current = Cursors.WaitCursor;
            this.labelStatus.Text = "";
            this.InitTable();
            this.initCombo();
            this.labelRecDate.Text = "";
            this.labelRecTime.Text = "";
            this.labelLoadDate.Text = "";
            this.labelLoadTime.Text = "";
            if (WBSetting.transflow == "2")
            {
                this.comboVehicleDestination.Enabled = true;
            }
            if (this.pMode == "ADD")
            {
                this.SetGateNo(true);
                this.textGpManual.Text = this.textGatepass_Number.Text;
                this.tblGatepass.OpenTable("wb_gatepass", "Select * from wb_Gatepass where " + WBData.CompanyLocation(" and gatepass_number = '" + this.textGatepass_Number.Text.Trim() + "'"), WBData.conn);
            }
            else
            {
                this.tblGatepass.OpenTable("wb_gatepass", "Select * from wb_Gatepass where " + WBData.CompanyLocation(" and uniq = '" + this.sUniq + "'"), WBData.conn);
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.sUniq };
                this.tblGatepass.DR = this.tblGatepass.GetData(aField, aFind);
                this.textTruck.Text = this.tblGatepass.DR["Truck_number"].ToString();
                this.textGatepass_Number.Text = this.tblGatepass.DR["Gatepass_Number"].ToString();
                this.textGpManual.Text = this.tblGatepass.DR["gpManual"].ToString();
                this.textRef.Text = this.tblGatepass.DR["Ref"].ToString();
                this.textDriverID.Text = this.tblGatepass.DR["License_no"].ToString();
                if (this.textDriverID.Text.Trim() != "")
                {
                    string[] textArray3 = new string[] { "License_No" };
                    string[] textArray4 = new string[] { this.textDriverID.Text.Trim() };
                    int recNo = this.tblDriver.GetRecNo(textArray3, textArray4);
                    if (recNo > -1)
                    {
                        this.labelDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                    }
                }
                this.textTrailerNo.Text = this.tblGatepass.DR["Trailer_number"].ToString();
                this.textContainer.Text = this.tblGatepass.DR["Container_number"].ToString();
                this.textTransporter.Text = this.tblGatepass.DR["Transporter_Code"].ToString();
                if (this.textTransporter.Text.Trim() != "")
                {
                    string[] textArray5 = new string[] { "Transporter_code" };
                    string[] textArray6 = new string[] { this.textTransporter.Text.Trim() };
                    int recNo = this.tblTransporter.GetRecNo(textArray5, textArray6);
                    if (recNo > -1)
                    {
                        this.labelTransporterName.Text = this.tblTransporter.DT.Rows[recNo]["Transporter_Name"].ToString();
                    }
                    else
                    {
                        this.buttonTransporter.PerformClick();
                        this.textTransporter.Focus();
                    }
                }
                this.comTransType.Text = this.tblGatepass.DR["Transaction_Code"].ToString();
                this.TransType_Leave();
                this.gType = this.tblGatepass.DR["Gatepass_type"].ToString();
                this.textGatepassType.Text = (this.gType != "I") ? "OUTBOUND" : "INBOUND";
                this.gatepassType1 = this.tblGatepass.DR["Gatepass_type1"].ToString();
                string[] textArray7 = new string[] { "gatepass_Type1" };
                string[] textArray8 = new string[] { this.gatepassType1 };
                DataRow data = this.tblGatepassType1.GetData(textArray7, textArray8);
                if (data != null)
                {
                    this.comboGatepassType1.Text = data["gatepass_TypeName"].ToString();
                }
                this.gatepass1_leave();
                this.gatepassType2 = this.tblGatepass.DR["Gatepass_type2"].ToString();
                string[] textArray9 = new string[] { "gatepass_Type2" };
                string[] textArray10 = new string[] { this.gatepassType2 };
                data = this.tblGatepassType2.GetData(textArray9, textArray10);
                if (data != null)
                {
                    this.comboGatepassType2.Text = data["gatepass_TypeName"].ToString();
                }
                this.gatepass2_leave();
                this.textOwner.Text = this.tblGatepass.DR["OWner_Code"].ToString();
                this.textLoader.Text = this.tblGatepass.DR["Loader_Code"].ToString();
                this.textHaulier.Text = this.tblGatepass.DR["Haulier_Code"].ToString();
                this.comboVehicleDestination.SelectedIndex = (this.tblGatepass.DR["WB"].ToString().Trim() != "") ? Convert.ToInt16(this.tblGatepass.DR["WB"].ToString().Trim()) : 0;
                string[] textArray11 = new string[] { "ApproveCode" };
                string[] textArray12 = new string[] { this.tblGatepass.DR["ApproveBy"].ToString().Trim() };
                this.comboVehicleDestination.Enabled = this.tblTAApprove.GetData(textArray11, textArray12)["Store"].ToString() == "Y";
                this.labelRecDate.Text = (this.tblGatepass.DR["ReceiptDate"].ToString().Trim() != "") ? this.tblGatepass.DR["ReceiptDate"].ToString().Substring(0, 10) : "";
                this.labelRecTime.Text = this.tblGatepass.DR["ReceiptTime"].ToString();
                this.labelLoadDate.Text = (this.tblGatepass.DR["LoadDate"].ToString().Trim() != "") ? this.tblGatepass.DR["LoadDate"].ToString().Substring(0, 10) : "";
                this.labelLoadTime.Text = this.tblGatepass.DR["LoadTime"].ToString();
                this.textDateIn.Text = (this.tblGatepass.DR["in_date"].ToString().Trim() != "") ? this.tblGatepass.DR["in_date"].ToString().Substring(0, 10) : "";
                this.textDateOut.Text = (this.tblGatepass.DR["Out_Date"].ToString().Trim() != "") ? this.tblGatepass.DR["Out_Date"].ToString().Substring(0, 10) : "";
                this.textTimeIn.Text = this.tblGatepass.DR["In_Time"].ToString();
                this.textTimeOut.Text = this.tblGatepass.DR["Out_Time"].ToString();
                if ((this.comboVehicleDestination.Text.Trim().ToUpper() == "STORE") && (this.pMode == "PRINT"))
                {
                    if (this.textDateOut.Text.Trim() == "")
                    {
                        this.textDateOut.Text = DateTime.Now.Date.ToString("dd/MM/yyyy");
                    }
                    if (this.textTimeOut.Text.Trim() == "")
                    {
                        this.textTimeOut.Text = DateTime.Now.ToString("HH:mm:ss");
                    }
                }
                this.textDateSubmit.Text = (this.tblGatepass.DR["Submit_Date"].ToString().Trim() != "") ? this.tblGatepass.DR["Submit_Date"].ToString().Substring(0, 10) : "";
                this.textTimeSubmit.Text = this.tblGatepass.DR["Submit_Time"].ToString();
                this.textSubmitRemark.Text = this.tblGatepass.DR["Submit_Remark"].ToString();
                this.textReason.Text = this.tblGatepass.DR["Reason"].ToString();
                this.textCommRetKet.Text = this.tblGatepass.DR["Comm_Ret_Ket"].ToString();
                this.checkReject.Checked = this.tblGatepass.DR["Reject"].ToString() == "Y";
                this.checkRejectComm.Checked = this.tblGatepass.DR["Comm_Ret"].ToString() == "Y";
                if (this.tblGatepass.DR["gp_purpose"].ToString() == "1")
                {
                    this.radioGP1.Checked = true;
                }
                else if (this.tblGatepass.DR["gp_purpose"].ToString() == "2")
                {
                    this.radioGP2.Checked = true;
                }
                this.textGPItem.Text = this.tblGatepass.DR["gp_item"].ToString();
                this.textGPQty.Text = this.tblGatepass.DR["gp_qty"].ToString();
            }
            this.checkGateAuth();
            this.checkStatus();
            if (this.pMode == "SUBMIT")
            {
                this.textDateSubmit.Text = DateTime.Now.ToString("dd/MM/yyyy");
                this.textTimeSubmit.Text = DateTime.Now.ToString("HH:mm:ss");
            }
            if (this.pMode == "VIEW")
            {
                this.buttonSave.Visible = false;
            }
            if (this.pMode == "PRINT")
            {
                this.buttonSave.Enabled = false;
                this.buttonPrint.Enabled = true;
                this.groupGeneral.Enabled = false;
                this.groupReject.Enabled = false;
            }
            else
            {
                this.buttonSave.Enabled = true;
                this.buttonPrint.Enabled = false;
                this.groupGeneral.Enabled = true;
                this.groupReject.Enabled = true;
            }
            this.groupPrint.Enabled = true;
            this.oldTruck = this.textTruck.Text;
            this.oldDriver = this.textDriverID.Text;
            this.oldTransporter = this.textTransporter.Text;
            this.oldTransType = this.comTransType.Text;
            Cursor.Current = Cursors.Default;
        }

        private void gatepass1_leave()
        {
            if (this.comboGatepassType1.Text.Trim() != "")
            {
                string[] aField = new string[] { "gatepass_TypeName" };
                string[] aFind = new string[] { this.comboGatepassType1.Text };
                DataRow data = this.tblGatepassType1.GetData(aField, aFind);
                if (data != null)
                {
                    this.gatepassType1 = data["gatepass_type1"].ToString();
                    DataRow[] rowArray = this.tblGatepassType2.DT.Select("Gatepass_type1 = '" + data["gatepass_type1"].ToString() + "'");
                    this.comboGatepassType2.Items.Clear();
                    foreach (DataRow row2 in rowArray)
                    {
                        this.comboGatepassType2.Items.Add(row2["gatepass_typeName"].ToString());
                    }
                }
            }
        }

        private void gatepass2_leave()
        {
            if (this.comboGatepassType2.Text != "")
            {
                string[] aField = new string[] { "gatepass_TypeName" };
                string[] aFind = new string[] { this.comboGatepassType2.Text };
                DataRow data = this.tblGatepassType2.GetData(aField, aFind);
                this.gatepassType2 = data["gatepass_type2"].ToString();
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }

        private void initCombo()
        {
            this.comTransType.Items.Clear();
            foreach (DataRow row in this.tblTransType.DT.Rows)
            {
                this.comTransType.Items.Add(row["transaction_code"].ToString());
            }
        }

        private void InitializeComponent()
        {
            this.buttonCancel = new Button();
            this.buttonSave = new Button();
            this.groupGeneral = new GroupBox();
            this.labelTransName = new Label();
            this.buttonLoader = new Button();
            this.textLoader = new TextBox();
            this.label11 = new Label();
            this.groupBox1 = new GroupBox();
            this.labelStatus = new Label();
            this.buttonRec = new Button();
            this.buttonLoad = new Button();
            this.labelLoadTime = new Label();
            this.buttonRecCancel = new Button();
            this.labelLoadDate = new Label();
            this.buttonLoadCancel = new Button();
            this.labelRecTime = new Label();
            this.labelRecDate = new Label();
            this.textRef = new TextBox();
            this.comboGatepassType2 = new ComboBox();
            this.comboGatepassType1 = new ComboBox();
            this.label23 = new Label();
            this.textTimeSubmit = new TextBox();
            this.textDateSubmit = new TextBox();
            this.textTimeOut = new TextBox();
            this.textDateOut = new TextBox();
            this.textTimeIn = new TextBox();
            this.textDateIn = new TextBox();
            this.textGpManual = new TextBox();
            this.label21 = new Label();
            this.label22 = new Label();
            this.label19 = new Label();
            this.label24 = new Label();
            this.label20 = new Label();
            this.label17 = new Label();
            this.label18 = new Label();
            this.label16 = new Label();
            this.label8 = new Label();
            this.textNet = new TextBox();
            this.label3 = new Label();
            this.labelDriverName = new Label();
            this.textGatepassType = new TextBox();
            this.label12 = new Label();
            this.label10 = new Label();
            this.buttonContainer = new Button();
            this.textContainer = new TextBox();
            this.textTrailerNo = new TextBox();
            this.label46 = new Label();
            this.buttonHaulier = new Button();
            this.textHaulier = new TextBox();
            this.label9 = new Label();
            this.buttonOwner = new Button();
            this.textOwner = new TextBox();
            this.labelRelation = new Label();
            this.label5 = new Label();
            this.label6 = new Label();
            this.buttonTransporter = new Button();
            this.textTransporter = new TextBox();
            this.labelTransType = new Label();
            this.comTransType = new ComboBox();
            this.buttonTruck = new Button();
            this.textTruck = new TextBox();
            this.textDriverID = new TextBox();
            this.buttonDriver = new Button();
            this.label7 = new Label();
            this.labelTransporterName = new Label();
            this.comboVehicleDestination = new ComboBox();
            this.label4 = new Label();
            this.label1 = new Label();
            this.textGatepass_Number = new TextBox();
            this.groupReject = new GroupBox();
            this.textCommRetKet = new TextBox();
            this.groupBox4 = new GroupBox();
            this.radioCommPart = new RadioButton();
            this.radioCommFull = new RadioButton();
            this.textReason = new TextBox();
            this.checkRejectComm = new CheckBox();
            this.checkReject = new CheckBox();
            this.groupPrint = new GroupBox();
            this.textGPQty = new TextBox();
            this.textGPItem = new TextBox();
            this.radioGP2 = new RadioButton();
            this.radioGP1 = new RadioButton();
            this.label15 = new Label();
            this.label14 = new Label();
            this.label13 = new Label();
            this.buttonPrint = new Button();
            this.groupBox2 = new GroupBox();
            this.textSubmitRemark = new TextBox();
            this.label2 = new Label();
            this.groupGeneral.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupReject.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupPrint.SuspendLayout();
            this.groupBox2.SuspendLayout();
            base.SuspendLayout();
            this.buttonCancel.Location = new Point(0x2a6, 0x25a);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x58, 0x26);
            this.buttonCancel.TabIndex = 4;
            this.buttonCancel.Text = "Cancel (Esc)";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.buttonSave.Location = new Point(0x23d, 0x25a);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x58, 0x26);
            this.buttonSave.TabIndex = 3;
            this.buttonSave.Text = "&Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.groupGeneral.Controls.Add(this.labelTransName);
            this.groupGeneral.Controls.Add(this.buttonLoader);
            this.groupGeneral.Controls.Add(this.textLoader);
            this.groupGeneral.Controls.Add(this.label11);
            this.groupGeneral.Controls.Add(this.groupBox1);
            this.groupGeneral.Controls.Add(this.textRef);
            this.groupGeneral.Controls.Add(this.comboGatepassType2);
            this.groupGeneral.Controls.Add(this.comboGatepassType1);
            this.groupGeneral.Controls.Add(this.label23);
            this.groupGeneral.Controls.Add(this.textTimeSubmit);
            this.groupGeneral.Controls.Add(this.textDateSubmit);
            this.groupGeneral.Controls.Add(this.textTimeOut);
            this.groupGeneral.Controls.Add(this.textDateOut);
            this.groupGeneral.Controls.Add(this.textTimeIn);
            this.groupGeneral.Controls.Add(this.textDateIn);
            this.groupGeneral.Controls.Add(this.textGpManual);
            this.groupGeneral.Controls.Add(this.label21);
            this.groupGeneral.Controls.Add(this.label22);
            this.groupGeneral.Controls.Add(this.label19);
            this.groupGeneral.Controls.Add(this.label24);
            this.groupGeneral.Controls.Add(this.label20);
            this.groupGeneral.Controls.Add(this.label17);
            this.groupGeneral.Controls.Add(this.label18);
            this.groupGeneral.Controls.Add(this.label16);
            this.groupGeneral.Controls.Add(this.label8);
            this.groupGeneral.Controls.Add(this.textNet);
            this.groupGeneral.Controls.Add(this.label3);
            this.groupGeneral.Controls.Add(this.labelDriverName);
            this.groupGeneral.Controls.Add(this.textGatepassType);
            this.groupGeneral.Controls.Add(this.label12);
            this.groupGeneral.Controls.Add(this.label10);
            this.groupGeneral.Controls.Add(this.buttonContainer);
            this.groupGeneral.Controls.Add(this.textContainer);
            this.groupGeneral.Controls.Add(this.textTrailerNo);
            this.groupGeneral.Controls.Add(this.label46);
            this.groupGeneral.Controls.Add(this.buttonHaulier);
            this.groupGeneral.Controls.Add(this.textHaulier);
            this.groupGeneral.Controls.Add(this.label9);
            this.groupGeneral.Controls.Add(this.buttonOwner);
            this.groupGeneral.Controls.Add(this.textOwner);
            this.groupGeneral.Controls.Add(this.labelRelation);
            this.groupGeneral.Controls.Add(this.label5);
            this.groupGeneral.Controls.Add(this.label6);
            this.groupGeneral.Controls.Add(this.buttonTransporter);
            this.groupGeneral.Controls.Add(this.textTransporter);
            this.groupGeneral.Controls.Add(this.labelTransType);
            this.groupGeneral.Controls.Add(this.comTransType);
            this.groupGeneral.Controls.Add(this.buttonTruck);
            this.groupGeneral.Controls.Add(this.textTruck);
            this.groupGeneral.Controls.Add(this.textDriverID);
            this.groupGeneral.Controls.Add(this.buttonDriver);
            this.groupGeneral.Controls.Add(this.label7);
            this.groupGeneral.Controls.Add(this.labelTransporterName);
            this.groupGeneral.Controls.Add(this.comboVehicleDestination);
            this.groupGeneral.Controls.Add(this.label4);
            this.groupGeneral.Controls.Add(this.label1);
            this.groupGeneral.Controls.Add(this.textGatepass_Number);
            this.groupGeneral.Location = new Point(12, 0);
            this.groupGeneral.Name = "groupGeneral";
            this.groupGeneral.Size = new Size(0x364, 330);
            this.groupGeneral.TabIndex = 0;
            this.groupGeneral.TabStop = false;
            this.groupGeneral.Enter += new EventHandler(this.groupBox1_Enter);
            this.labelTransName.AutoSize = true;
            this.labelTransName.Location = new Point(0x11b, 0xc9);
            this.labelTransName.Name = "labelTransName";
            this.labelTransName.Size = new Size(60, 13);
            this.labelTransName.TabIndex = 0x38;
            this.labelTransName.Text = "Description";
            this.buttonLoader.Location = new Point(280, 170);
            this.buttonLoader.Margin = new Padding(0);
            this.buttonLoader.Name = "buttonLoader";
            this.buttonLoader.Size = new Size(0x17, 0x17);
            this.buttonLoader.TabIndex = 0x37;
            this.buttonLoader.Text = "...";
            this.buttonLoader.UseVisualStyleBackColor = true;
            this.buttonLoader.Click += new EventHandler(this.buttonLoader_Click);
            this.textLoader.CharacterCasing = CharacterCasing.Upper;
            this.textLoader.Location = new Point(0x9a, 0xac);
            this.textLoader.MaxLength = 50;
            this.textLoader.Name = "textLoader";
            this.textLoader.Size = new Size(0x7b, 20);
            this.textLoader.TabIndex = 0x35;
            this.textLoader.KeyPress += new KeyPressEventHandler(this.textLoader_KeyPress);
            this.textLoader.Leave += new EventHandler(this.textLoader_Leave);
            this.label11.Location = new Point(6, 0xaf);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x8e, 13);
            this.label11.TabIndex = 0x36;
            this.label11.Text = "Loader";
            this.label11.TextAlign = ContentAlignment.TopRight;
            this.groupBox1.Controls.Add(this.labelStatus);
            this.groupBox1.Controls.Add(this.buttonRec);
            this.groupBox1.Controls.Add(this.buttonLoad);
            this.groupBox1.Controls.Add(this.labelLoadTime);
            this.groupBox1.Controls.Add(this.buttonRecCancel);
            this.groupBox1.Controls.Add(this.labelLoadDate);
            this.groupBox1.Controls.Add(this.buttonLoadCancel);
            this.groupBox1.Controls.Add(this.labelRecTime);
            this.groupBox1.Controls.Add(this.labelRecDate);
            this.groupBox1.Location = new Point(0x146, 0x10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x112, 0x93);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.labelStatus.AutoSize = true;
            this.labelStatus.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelStatus.Location = new Point(90, 0x10);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new Size(0x53, 0x10);
            this.labelStatus.TabIndex = 4;
            this.labelStatus.Text = "LOCATION";
            this.labelStatus.TextAlign = ContentAlignment.MiddleCenter;
            this.buttonRec.Location = new Point(0x11, 0x31);
            this.buttonRec.Name = "buttonRec";
            this.buttonRec.Size = new Size(0x3a, 0x26);
            this.buttonRec.TabIndex = 0;
            this.buttonRec.Text = "&Receipt";
            this.buttonRec.UseVisualStyleBackColor = true;
            this.buttonRec.Click += new EventHandler(this.buttonRec_Click);
            this.buttonLoad.Location = new Point(0x11, 100);
            this.buttonLoad.Name = "buttonLoad";
            this.buttonLoad.Size = new Size(0x3a, 0x26);
            this.buttonLoad.TabIndex = 2;
            this.buttonLoad.Text = "&Load/  Unload";
            this.buttonLoad.UseVisualStyleBackColor = true;
            this.buttonLoad.Click += new EventHandler(this.buttonLoad_Click);
            this.labelLoadTime.AutoSize = true;
            this.labelLoadTime.Location = new Point(90, 0x79);
            this.labelLoadTime.Name = "labelLoadTime";
            this.labelLoadTime.Size = new Size(30, 13);
            this.labelLoadTime.TabIndex = 8;
            this.labelLoadTime.Text = "Time";
            this.buttonRecCancel.Location = new Point(0xc0, 0x31);
            this.buttonRecCancel.Name = "buttonRecCancel";
            this.buttonRecCancel.Size = new Size(0x3a, 0x26);
            this.buttonRecCancel.TabIndex = 1;
            this.buttonRecCancel.Text = "&Cancel";
            this.buttonRecCancel.UseVisualStyleBackColor = true;
            this.buttonRecCancel.Click += new EventHandler(this.buttonRecCancel_Click);
            this.labelLoadDate.AutoSize = true;
            this.labelLoadDate.Location = new Point(90, 0x6c);
            this.labelLoadDate.Name = "labelLoadDate";
            this.labelLoadDate.Size = new Size(30, 13);
            this.labelLoadDate.TabIndex = 7;
            this.labelLoadDate.Text = "Date";
            this.buttonLoadCancel.Location = new Point(0xc0, 100);
            this.buttonLoadCancel.Name = "buttonLoadCancel";
            this.buttonLoadCancel.Size = new Size(0x3a, 0x26);
            this.buttonLoadCancel.TabIndex = 3;
            this.buttonLoadCancel.Text = "&Cancel";
            this.buttonLoadCancel.UseVisualStyleBackColor = true;
            this.buttonLoadCancel.Click += new EventHandler(this.buttonLoadCancel_Click);
            this.labelRecTime.AutoSize = true;
            this.labelRecTime.Location = new Point(90, 70);
            this.labelRecTime.Name = "labelRecTime";
            this.labelRecTime.Size = new Size(30, 13);
            this.labelRecTime.TabIndex = 5;
            this.labelRecTime.Text = "Time";
            this.labelRecDate.AutoSize = true;
            this.labelRecDate.Location = new Point(90, 0x39);
            this.labelRecDate.Name = "labelRecDate";
            this.labelRecDate.Size = new Size(30, 13);
            this.labelRecDate.TabIndex = 6;
            this.labelRecDate.Text = "Date";
            this.textRef.BackColor = SystemColors.ScrollBar;
            this.textRef.CharacterCasing = CharacterCasing.Upper;
            this.textRef.Location = new Point(740, 0x10f);
            this.textRef.MaxLength = 20;
            this.textRef.Name = "textRef";
            this.textRef.Size = new Size(0x7a, 20);
            this.textRef.TabIndex = 0x22;
            this.comboGatepassType2.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboGatepassType2.FormattingEnabled = true;
            this.comboGatepassType2.Location = new Point(0x1ac, 0xe0);
            this.comboGatepassType2.Name = "comboGatepassType2";
            this.comboGatepassType2.Size = new Size(0x88, 0x15);
            this.comboGatepassType2.TabIndex = 7;
            this.comboGatepassType2.KeyPress += new KeyPressEventHandler(this.comboGatepassType2_KeyPress);
            this.comboGatepassType2.Leave += new EventHandler(this.comboGatepassType2_Leave);
            this.comboGatepassType1.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboGatepassType1.FormattingEnabled = true;
            this.comboGatepassType1.Location = new Point(0x11b, 0xe0);
            this.comboGatepassType1.Name = "comboGatepassType1";
            this.comboGatepassType1.Size = new Size(0x88, 0x15);
            this.comboGatepassType1.TabIndex = 6;
            this.comboGatepassType1.KeyPress += new KeyPressEventHandler(this.comboGatepassType1_KeyPress);
            this.comboGatepassType1.Leave += new EventHandler(this.comboGatepassType1_Leave);
            this.label23.Location = new Point(0x253, 0xc7);
            this.label23.Name = "label23";
            this.label23.Size = new Size(0x8b, 13);
            this.label23.TabIndex = 0x23;
            this.label23.Text = "Submit Time";
            this.label23.TextAlign = ContentAlignment.TopRight;
            this.textTimeSubmit.BackColor = SystemColors.ScrollBar;
            this.textTimeSubmit.CharacterCasing = CharacterCasing.Upper;
            this.textTimeSubmit.Location = new Point(740, 0xc1);
            this.textTimeSubmit.MaxLength = 20;
            this.textTimeSubmit.Name = "textTimeSubmit";
            this.textTimeSubmit.Size = new Size(0x57, 20);
            this.textTimeSubmit.TabIndex = 0x24;
            this.textDateSubmit.BackColor = SystemColors.ScrollBar;
            this.textDateSubmit.CharacterCasing = CharacterCasing.Upper;
            this.textDateSubmit.Location = new Point(740, 170);
            this.textDateSubmit.MaxLength = 20;
            this.textDateSubmit.Name = "textDateSubmit";
            this.textDateSubmit.Size = new Size(0x57, 20);
            this.textDateSubmit.TabIndex = 0x26;
            this.textTimeOut.BackColor = SystemColors.ScrollBar;
            this.textTimeOut.CharacterCasing = CharacterCasing.Upper;
            this.textTimeOut.Location = new Point(740, 0x90);
            this.textTimeOut.MaxLength = 20;
            this.textTimeOut.Name = "textTimeOut";
            this.textTimeOut.Size = new Size(0x57, 20);
            this.textTimeOut.TabIndex = 40;
            this.textDateOut.BackColor = SystemColors.ScrollBar;
            this.textDateOut.CharacterCasing = CharacterCasing.Upper;
            this.textDateOut.Location = new Point(740, 0x76);
            this.textDateOut.MaxLength = 20;
            this.textDateOut.Name = "textDateOut";
            this.textDateOut.Size = new Size(0x57, 20);
            this.textDateOut.TabIndex = 0x2a;
            this.textTimeIn.BackColor = SystemColors.ScrollBar;
            this.textTimeIn.CharacterCasing = CharacterCasing.Upper;
            this.textTimeIn.Location = new Point(740, 0x5d);
            this.textTimeIn.MaxLength = 20;
            this.textTimeIn.Name = "textTimeIn";
            this.textTimeIn.Size = new Size(0x57, 20);
            this.textTimeIn.TabIndex = 0x2c;
            this.textDateIn.BackColor = SystemColors.ScrollBar;
            this.textDateIn.CharacterCasing = CharacterCasing.Upper;
            this.textDateIn.Location = new Point(740, 0x47);
            this.textDateIn.MaxLength = 20;
            this.textDateIn.Name = "textDateIn";
            this.textDateIn.Size = new Size(0x57, 20);
            this.textDateIn.TabIndex = 0x2e;
            this.textGpManual.BackColor = SystemColors.Window;
            this.textGpManual.Location = new Point(740, 0x2f);
            this.textGpManual.Name = "textGpManual";
            this.textGpManual.Size = new Size(0x7b, 20);
            this.textGpManual.TabIndex = 50;
            this.textGpManual.KeyPress += new KeyPressEventHandler(this.textGpManual_KeyPress);
            this.label21.Location = new Point(0x253, 0xad);
            this.label21.Name = "label21";
            this.label21.Size = new Size(0x8b, 13);
            this.label21.TabIndex = 0x25;
            this.label21.Text = "Submit Date";
            this.label21.TextAlign = ContentAlignment.TopRight;
            this.label22.Location = new Point(0x253, 0x93);
            this.label22.Name = "label22";
            this.label22.Size = new Size(0x8b, 13);
            this.label22.TabIndex = 0x27;
            this.label22.Text = "Time Out";
            this.label22.TextAlign = ContentAlignment.TopRight;
            this.label22.Click += new EventHandler(this.label22_Click);
            this.label19.Location = new Point(0x253, 0x79);
            this.label19.Name = "label19";
            this.label19.Size = new Size(0x8b, 13);
            this.label19.TabIndex = 0x29;
            this.label19.Text = "Date Out";
            this.label19.TextAlign = ContentAlignment.TopRight;
            this.label19.Click += new EventHandler(this.label19_Click);
            this.label24.Location = new Point(0x253, 0x60);
            this.label24.Name = "label24";
            this.label24.Size = new Size(0x8b, 13);
            this.label24.TabIndex = 0x2b;
            this.label24.Text = "Time In";
            this.label24.TextAlign = ContentAlignment.TopRight;
            this.label24.Click += new EventHandler(this.label20_Click);
            this.label20.Location = new Point(0x253, 0x60);
            this.label20.Name = "label20";
            this.label20.Size = new Size(0x2a, 13);
            this.label20.TabIndex = 0x30;
            this.label20.Text = "Time In";
            this.label20.TextAlign = ContentAlignment.TopRight;
            this.label20.Click += new EventHandler(this.label20_Click);
            this.label17.Location = new Point(0x253, 0x4a);
            this.label17.Name = "label17";
            this.label17.Size = new Size(0x8b, 13);
            this.label17.TabIndex = 0x2d;
            this.label17.Text = "Date In";
            this.label17.TextAlign = ContentAlignment.TopRight;
            this.label17.Click += new EventHandler(this.label18_Click);
            this.label18.Location = new Point(0x253, 0x4a);
            this.label18.Name = "label18";
            this.label18.Size = new Size(0x2a, 13);
            this.label18.TabIndex = 0x2f;
            this.label18.Text = "Date In";
            this.label18.TextAlign = ContentAlignment.TopRight;
            this.label18.Click += new EventHandler(this.label18_Click);
            this.label16.Location = new Point(0x253, 50);
            this.label16.Name = "label16";
            this.label16.Size = new Size(0x8b, 13);
            this.label16.TabIndex = 0x31;
            this.label16.Text = "Gatepass Manual";
            this.label16.TextAlign = ContentAlignment.TopRight;
            this.label8.AutoSize = true;
            this.label8.Location = new Point(690, 0x112);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x2c, 13);
            this.label8.TabIndex = 0x21;
            this.label8.Text = "Ref No.";
            this.textNet.BackColor = SystemColors.ScrollBar;
            this.textNet.CharacterCasing = CharacterCasing.Upper;
            this.textNet.Location = new Point(0x99, 0x12f);
            this.textNet.MaxLength = 20;
            this.textNet.Name = "textNet";
            this.textNet.Size = new Size(0x7a, 20);
            this.textNet.TabIndex = 0x20;
            this.textNet.Text = "0";
            this.textNet.TextAlign = HorizontalAlignment.Right;
            this.label3.Location = new Point(6, 0x132);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x8e, 13);
            this.label3.TabIndex = 0x17;
            this.label3.Text = "Net Weight";
            this.label3.TextAlign = ContentAlignment.TopRight;
            this.labelDriverName.AutoSize = true;
            this.labelDriverName.Location = new Point(310, 0xfe);
            this.labelDriverName.Name = "labelDriverName";
            this.labelDriverName.Size = new Size(0x3f, 13);
            this.labelDriverName.TabIndex = 0x1d;
            this.labelDriverName.Text = "DriverName";
            this.textGatepassType.BackColor = SystemColors.ScrollBar;
            this.textGatepassType.CharacterCasing = CharacterCasing.Upper;
            this.textGatepassType.Location = new Point(0x9a, 0xe1);
            this.textGatepassType.MaxLength = 20;
            this.textGatepassType.Name = "textGatepassType";
            this.textGatepassType.Size = new Size(0x7b, 20);
            this.textGatepassType.TabIndex = 20;
            this.label12.Location = new Point(6, 0xe4);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x8e, 13);
            this.label12.TabIndex = 0x13;
            this.label12.Text = "GatePass Type";
            this.label12.TextAlign = ContentAlignment.TopRight;
            this.label10.Location = new Point(6, 0x63);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x8e, 13);
            this.label10.TabIndex = 15;
            this.label10.Text = "Container No.";
            this.label10.TextAlign = ContentAlignment.TopRight;
            this.buttonContainer.Location = new Point(0x119, 0x5e);
            this.buttonContainer.Margin = new Padding(0);
            this.buttonContainer.Name = "buttonContainer";
            this.buttonContainer.Size = new Size(0x17, 0x17);
            this.buttonContainer.TabIndex = 0x19;
            this.buttonContainer.Text = "...";
            this.buttonContainer.UseVisualStyleBackColor = true;
            this.buttonContainer.Click += new EventHandler(this.buttonContainer_Click);
            this.textContainer.CharacterCasing = CharacterCasing.Upper;
            this.textContainer.Location = new Point(0x9a, 0x60);
            this.textContainer.MaxLength = 20;
            this.textContainer.Name = "textContainer";
            this.textContainer.Size = new Size(0x7b, 20);
            this.textContainer.TabIndex = 2;
            this.textContainer.KeyPress += new KeyPressEventHandler(this.textContainer_KeyPress);
            this.textContainer.Leave += new EventHandler(this.textContainer_Leave);
            this.textTrailerNo.CharacterCasing = CharacterCasing.Upper;
            this.textTrailerNo.Location = new Point(0x99, 70);
            this.textTrailerNo.MaxLength = 20;
            this.textTrailerNo.Name = "textTrailerNo";
            this.textTrailerNo.Size = new Size(0x7c, 20);
            this.textTrailerNo.TabIndex = 1;
            this.textTrailerNo.KeyPress += new KeyPressEventHandler(this.textTrailerNo_KeyPress);
            this.label46.Location = new Point(6, 0x49);
            this.label46.Name = "label46";
            this.label46.Size = new Size(0x8e, 13);
            this.label46.TabIndex = 14;
            this.label46.Text = "Trailer No.";
            this.label46.TextAlign = ContentAlignment.TopRight;
            this.buttonHaulier.Location = new Point(280, 0x91);
            this.buttonHaulier.Margin = new Padding(0);
            this.buttonHaulier.Name = "buttonHaulier";
            this.buttonHaulier.Size = new Size(0x17, 0x17);
            this.buttonHaulier.TabIndex = 0x1b;
            this.buttonHaulier.Text = "...";
            this.buttonHaulier.UseVisualStyleBackColor = true;
            this.buttonHaulier.Click += new EventHandler(this.buttonHaulier_Click);
            this.textHaulier.CharacterCasing = CharacterCasing.Upper;
            this.textHaulier.Location = new Point(0x9a, 0x93);
            this.textHaulier.MaxLength = 50;
            this.textHaulier.Name = "textHaulier";
            this.textHaulier.Size = new Size(0x7b, 20);
            this.textHaulier.TabIndex = 4;
            this.textHaulier.KeyPress += new KeyPressEventHandler(this.textHaulier_KeyPress);
            this.textHaulier.Leave += new EventHandler(this.textHaulier_Leave);
            this.label9.Location = new Point(6, 150);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x8e, 13);
            this.label9.TabIndex = 0x11;
            this.label9.Text = "Haulier";
            this.label9.TextAlign = ContentAlignment.TopRight;
            this.buttonOwner.Location = new Point(280, 0x77);
            this.buttonOwner.Margin = new Padding(0);
            this.buttonOwner.Name = "buttonOwner";
            this.buttonOwner.Size = new Size(0x17, 0x17);
            this.buttonOwner.TabIndex = 0x1a;
            this.buttonOwner.Text = "...";
            this.buttonOwner.UseVisualStyleBackColor = true;
            this.buttonOwner.Click += new EventHandler(this.buttonOwner_Click);
            this.textOwner.CharacterCasing = CharacterCasing.Upper;
            this.textOwner.Location = new Point(0x9a, 0x79);
            this.textOwner.MaxLength = 50;
            this.textOwner.Name = "textOwner";
            this.textOwner.Size = new Size(0x7b, 20);
            this.textOwner.TabIndex = 3;
            this.textOwner.KeyPress += new KeyPressEventHandler(this.textOwner_KeyPress);
            this.textOwner.Leave += new EventHandler(this.textOwner_Leave);
            this.labelRelation.Location = new Point(6, 0x7c);
            this.labelRelation.Name = "labelRelation";
            this.labelRelation.Size = new Size(0x8e, 13);
            this.labelRelation.TabIndex = 0x10;
            this.labelRelation.Text = "Owner";
            this.labelRelation.TextAlign = ContentAlignment.TopRight;
            this.label5.Location = new Point(6, 0x31);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x8e, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Vehicle No.";
            this.label5.TextAlign = ContentAlignment.TopRight;
            this.label6.Location = new Point(6, 0xfe);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x8e, 13);
            this.label6.TabIndex = 0x15;
            this.label6.Text = "Driver ID";
            this.label6.TextAlign = ContentAlignment.TopRight;
            this.buttonTransporter.Location = new Point(0x119, 0x113);
            this.buttonTransporter.Margin = new Padding(0);
            this.buttonTransporter.Name = "buttonTransporter";
            this.buttonTransporter.Size = new Size(0x17, 0x17);
            this.buttonTransporter.TabIndex = 30;
            this.buttonTransporter.Text = "...";
            this.buttonTransporter.UseVisualStyleBackColor = true;
            this.buttonTransporter.Click += new EventHandler(this.buttonTransporter_Click);
            this.textTransporter.CharacterCasing = CharacterCasing.Upper;
            this.textTransporter.Location = new Point(0x99, 0x115);
            this.textTransporter.MaxLength = 20;
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.Size = new Size(0x7a, 20);
            this.textTransporter.TabIndex = 9;
            this.textTransporter.KeyPress += new KeyPressEventHandler(this.textTransporter_KeyPress);
            this.textTransporter.Leave += new EventHandler(this.textTransporter_Leave);
            this.labelTransType.Cursor = Cursors.Arrow;
            this.labelTransType.Location = new Point(6, 0xc9);
            this.labelTransType.Name = "labelTransType";
            this.labelTransType.Size = new Size(0x8e, 0x12);
            this.labelTransType.TabIndex = 0x12;
            this.labelTransType.Text = "Transaction Type";
            this.labelTransType.TextAlign = ContentAlignment.TopRight;
            this.comTransType.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comTransType.FormattingEnabled = true;
            this.comTransType.Location = new Point(0x9a, 0xc6);
            this.comTransType.Name = "comTransType";
            this.comTransType.Size = new Size(0x7b, 0x15);
            this.comTransType.TabIndex = 5;
            this.comTransType.TextChanged += new EventHandler(this.comTransType_TextChanged);
            this.comTransType.KeyPress += new KeyPressEventHandler(this.comTransType_KeyPress);
            this.comTransType.Leave += new EventHandler(this.comTransType_Leave);
            this.buttonTruck.Location = new Point(0x119, 0x2c);
            this.buttonTruck.Margin = new Padding(0);
            this.buttonTruck.Name = "buttonTruck";
            this.buttonTruck.Size = new Size(0x17, 0x17);
            this.buttonTruck.TabIndex = 0x18;
            this.buttonTruck.Text = "...";
            this.buttonTruck.UseVisualStyleBackColor = true;
            this.buttonTruck.Click += new EventHandler(this.buttonTruck_Click);
            this.textTruck.CharacterCasing = CharacterCasing.Upper;
            this.textTruck.Location = new Point(0x9a, 0x2e);
            this.textTruck.MaxLength = 20;
            this.textTruck.Name = "textTruck";
            this.textTruck.Size = new Size(0x7b, 20);
            this.textTruck.TabIndex = 0;
            this.textTruck.KeyPress += new KeyPressEventHandler(this.textTruck_KeyPress);
            this.textTruck.Leave += new EventHandler(this.textTruck_Leave);
            this.textDriverID.CharacterCasing = CharacterCasing.Upper;
            this.textDriverID.Location = new Point(0x99, 0xfb);
            this.textDriverID.MaxLength = 50;
            this.textDriverID.Name = "textDriverID";
            this.textDriverID.Size = new Size(0x7b, 20);
            this.textDriverID.TabIndex = 8;
            this.textDriverID.KeyPress += new KeyPressEventHandler(this.textDriverID_KeyPress);
            this.textDriverID.Leave += new EventHandler(this.textDriverID_Leave);
            this.buttonDriver.Location = new Point(280, 0xf9);
            this.buttonDriver.Margin = new Padding(0);
            this.buttonDriver.Name = "buttonDriver";
            this.buttonDriver.Size = new Size(0x17, 0x17);
            this.buttonDriver.TabIndex = 0x1c;
            this.buttonDriver.Text = "...";
            this.buttonDriver.UseVisualStyleBackColor = true;
            this.buttonDriver.Click += new EventHandler(this.buttonDriver_Click);
            this.label7.Location = new Point(6, 280);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x8e, 13);
            this.label7.TabIndex = 0x16;
            this.label7.Text = "Transporter";
            this.label7.TextAlign = ContentAlignment.TopRight;
            this.labelTransporterName.AutoSize = true;
            this.labelTransporterName.Location = new Point(0x133, 0x119);
            this.labelTransporterName.Name = "labelTransporterName";
            this.labelTransporterName.Size = new Size(0x59, 13);
            this.labelTransporterName.TabIndex = 0x1f;
            this.labelTransporterName.Text = "TransporterName";
            this.comboVehicleDestination.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboVehicleDestination.Enabled = false;
            this.comboVehicleDestination.FormattingEnabled = true;
            object[] items = new object[] { "WB", "STORE" };
            this.comboVehicleDestination.Items.AddRange(items);
            this.comboVehicleDestination.Location = new Point(740, 20);
            this.comboVehicleDestination.Name = "comboVehicleDestination";
            this.comboVehicleDestination.Size = new Size(0x7a, 0x15);
            this.comboVehicleDestination.TabIndex = 0x33;
            this.label4.Location = new Point(0x253, 0x17);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x8b, 13);
            this.label4.TabIndex = 0x34;
            this.label4.Text = "Vehicle Destination";
            this.label4.TextAlign = ContentAlignment.TopRight;
            this.label1.Location = new Point(6, 0x17);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x8e, 0x11);
            this.label1.TabIndex = 11;
            this.label1.Text = "Gatepass No.";
            this.label1.TextAlign = ContentAlignment.TopRight;
            this.textGatepass_Number.BackColor = SystemColors.ScrollBar;
            this.textGatepass_Number.Enabled = false;
            this.textGatepass_Number.Location = new Point(0x9a, 20);
            this.textGatepass_Number.Name = "textGatepass_Number";
            this.textGatepass_Number.Size = new Size(0x7b, 20);
            this.textGatepass_Number.TabIndex = 13;
            this.textGatepass_Number.Text = "ABKT00001";
            this.groupReject.Controls.Add(this.textCommRetKet);
            this.groupReject.Controls.Add(this.groupBox4);
            this.groupReject.Controls.Add(this.textReason);
            this.groupReject.Controls.Add(this.checkRejectComm);
            this.groupReject.Controls.Add(this.checkReject);
            this.groupReject.Location = new Point(12, 0x19d);
            this.groupReject.Name = "groupReject";
            this.groupReject.Size = new Size(0x360, 0x53);
            this.groupReject.TabIndex = 1;
            this.groupReject.TabStop = false;
            this.textCommRetKet.CharacterCasing = CharacterCasing.Upper;
            this.textCommRetKet.Location = new Point(0x125, 50);
            this.textCommRetKet.MaxLength = 20;
            this.textCommRetKet.Name = "textCommRetKet";
            this.textCommRetKet.Size = new Size(0x1e6, 20);
            this.textCommRetKet.TabIndex = 2;
            this.textCommRetKet.KeyPress += new KeyPressEventHandler(this.texRejectComm_KeyPress);
            this.groupBox4.Controls.Add(this.radioCommPart);
            this.groupBox4.Controls.Add(this.radioCommFull);
            this.groupBox4.Location = new Point(0x9a, 0x2a);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new Size(0x85, 0x23);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.radioCommPart.AutoSize = true;
            this.radioCommPart.Location = new Point(70, 12);
            this.radioCommPart.Name = "radioCommPart";
            this.radioCommPart.Size = new Size(0x2c, 0x11);
            this.radioCommPart.TabIndex = 1;
            this.radioCommPart.TabStop = true;
            this.radioCommPart.Text = "Part";
            this.radioCommPart.UseVisualStyleBackColor = true;
            this.radioCommFull.AutoSize = true;
            this.radioCommFull.Location = new Point(6, 12);
            this.radioCommFull.Name = "radioCommFull";
            this.radioCommFull.Size = new Size(0x29, 0x11);
            this.radioCommFull.TabIndex = 0;
            this.radioCommFull.TabStop = true;
            this.radioCommFull.Text = "Full";
            this.radioCommFull.UseVisualStyleBackColor = true;
            this.textReason.CharacterCasing = CharacterCasing.Upper;
            this.textReason.Location = new Point(0x9a, 0x10);
            this.textReason.MaxLength = 20;
            this.textReason.Name = "textReason";
            this.textReason.Size = new Size(0x271, 20);
            this.textReason.TabIndex = 0;
            this.textReason.KeyPress += new KeyPressEventHandler(this.textRejectGatepass_KeyPress);
            this.checkRejectComm.AutoSize = true;
            this.checkRejectComm.Location = new Point(6, 0x34);
            this.checkRejectComm.Name = "checkRejectComm";
            this.checkRejectComm.Size = new Size(0x6f, 0x11);
            this.checkRejectComm.TabIndex = 4;
            this.checkRejectComm.Text = "Reject Commodity";
            this.checkRejectComm.UseVisualStyleBackColor = true;
            this.checkReject.AutoSize = true;
            this.checkReject.Location = new Point(6, 0x12);
            this.checkReject.Name = "checkReject";
            this.checkReject.Size = new Size(0x69, 0x11);
            this.checkReject.TabIndex = 3;
            this.checkReject.Text = "Reject Gatepass";
            this.checkReject.UseVisualStyleBackColor = true;
            this.groupPrint.Controls.Add(this.textGPQty);
            this.groupPrint.Controls.Add(this.textGPItem);
            this.groupPrint.Controls.Add(this.radioGP2);
            this.groupPrint.Controls.Add(this.radioGP1);
            this.groupPrint.Controls.Add(this.label15);
            this.groupPrint.Controls.Add(this.label14);
            this.groupPrint.Controls.Add(this.label13);
            this.groupPrint.Location = new Point(0x10, 0x1f6);
            this.groupPrint.Name = "groupPrint";
            this.groupPrint.Size = new Size(0x360, 0x5e);
            this.groupPrint.TabIndex = 2;
            this.groupPrint.TabStop = false;
            this.groupPrint.Text = "To";
            this.textGPQty.CharacterCasing = CharacterCasing.Upper;
            this.textGPQty.Location = new Point(0x6f, 0x3d);
            this.textGPQty.MaxLength = 20;
            this.textGPQty.Name = "textGPQty";
            this.textGPQty.Size = new Size(0x29c, 20);
            this.textGPQty.TabIndex = 3;
            this.textGPQty.KeyPress += new KeyPressEventHandler(this.textQuantity_KeyPress);
            this.textGPItem.CharacterCasing = CharacterCasing.Upper;
            this.textGPItem.Location = new Point(0x6f, 0x25);
            this.textGPItem.MaxLength = 20;
            this.textGPItem.Name = "textGPItem";
            this.textGPItem.Size = new Size(0x29c, 20);
            this.textGPItem.TabIndex = 2;
            this.textGPItem.KeyPress += new KeyPressEventHandler(this.textIten_KeyPress);
            this.radioGP2.AutoSize = true;
            this.radioGP2.Location = new Point(0x142, 0x11);
            this.radioGP2.Name = "radioGP2";
            this.radioGP2.Size = new Size(120, 0x11);
            this.radioGP2.TabIndex = 1;
            this.radioGP2.Text = "Going Without Load";
            this.radioGP2.UseVisualStyleBackColor = true;
            this.radioGP1.AutoSize = true;
            this.radioGP1.Checked = true;
            this.radioGP1.Location = new Point(0x6f, 0x11);
            this.radioGP1.Name = "radioGP1";
            this.radioGP1.Size = new Size(0x7d, 0x11);
            this.radioGP1.TabIndex = 0;
            this.radioGP1.TabStop = true;
            this.radioGP1.Text = "Leaving After Offload";
            this.radioGP1.UseVisualStyleBackColor = true;
            this.label15.AutoSize = true;
            this.label15.Location = new Point(0x13, 0x44);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x2e, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "Quantity";
            this.label14.AutoSize = true;
            this.label14.Location = new Point(0x13, 0x2c);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x1b, 13);
            this.label14.TabIndex = 6;
            this.label14.Text = "Item";
            this.label13.AutoSize = true;
            this.label13.Location = new Point(0x13, 0x15);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x2e, 13);
            this.label13.TabIndex = 5;
            this.label13.Text = "Purpose";
            this.buttonPrint.Location = new Point(0x314, 0x25a);
            this.buttonPrint.Name = "buttonPrint";
            this.buttonPrint.Size = new Size(0x58, 0x26);
            this.buttonPrint.TabIndex = 5;
            this.buttonPrint.Text = "&Print";
            this.buttonPrint.UseVisualStyleBackColor = true;
            this.buttonPrint.Click += new EventHandler(this.buttonPrint_Click);
            this.groupBox2.Controls.Add(this.textSubmitRemark);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new Point(12, 0x149);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0x364, 0x54);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Submit Gatepass";
            this.textSubmitRemark.Location = new Point(0x9a, 0x15);
            this.textSubmitRemark.MaxLength = 150;
            this.textSubmitRemark.Multiline = true;
            this.textSubmitRemark.Name = "textSubmitRemark";
            this.textSubmitRemark.Size = new Size(0x271, 0x39);
            this.textSubmitRemark.TabIndex = 0x35;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x5d, 0x18);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x2c, 13);
            this.label2.TabIndex = 0x18;
            this.label2.Text = "Remark";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x37c, 0x286);
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.groupGeneral);
            base.Controls.Add(this.buttonPrint);
            base.Controls.Add(this.groupPrint);
            base.Controls.Add(this.groupReject);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Name = "FormGatepassEntry";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Form Gatepass Entry";
            base.Load += new EventHandler(this.FormGatepassEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormGatepassEntry_KeyPress);
            this.groupGeneral.ResumeLayout(false);
            this.groupGeneral.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupReject.ResumeLayout(false);
            this.groupReject.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupPrint.ResumeLayout(false);
            this.groupPrint.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            base.ResumeLayout(false);
        }

        private void InitTable()
        {
            this.tblTruck.OpenTable("wb_truck", "Select * from wb_truck where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblContainer.OpenTable("wb_Container", "Select * from wb_Container where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblCust.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblDriver.OpenTable("wb_driver", "Select * from wb_driver where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblTransporter.OpenTable("wb_transporter", "Select * from wb_transporter where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblTransType.OpenTable("wb_transaction_type", "Select * from wb_transaction_type", WBData.conn);
            this.tblTAApprove.OpenTable("wb_TAApprove", "Select * from wb_TAApprove where " + WBData.CompanyLocation(""), WBData.conn);
            this.tblGatepassType2.OpenTable("wb_gatepassType2", "Select * from wb_gatepasstype2 where 1=1", WBData.conn);
            this.tblGatepassType1.OpenTable("wb_gatepassType1", "Select * from wb_gatepasstype1 where 1=1", WBData.conn);
            Program.AutoComp(this.tblTruck, "Truck_Number", this.textTruck);
            Program.AutoComp(this.tblDriver, "License_No", this.textDriverID);
            Program.AutoComp(this.tblTransporter, "Transporter_Code", this.textTransporter);
            Program.AutoComp(this.tblCust, "Relation_Code", this.textOwner);
            Program.AutoComp(this.tblCust, "Relation_Code", this.textHaulier);
            Program.AutoComp(this.tblContainer, "Container_number", this.textContainer);
            this.labelTransporterName.Text = "";
            this.labelDriverName.Text = "";
        }

        private void label18_Click(object sender, EventArgs e)
        {
        }

        private void label19_Click(object sender, EventArgs e)
        {
        }

        private void label20_Click(object sender, EventArgs e)
        {
        }

        private void label22_Click(object sender, EventArgs e)
        {
        }

        private void print(string Gatepass_number, string status, string user, ReportDocument cryRpt)
        {
            string[] paramName = new string[3];
            string[] paramValue = new string[] { Gatepass_number, status, WBUser.UserName };
            paramName[0] = "Gatepass_number";
            paramName[1] = "Status";
            paramName[2] = "user";
            cryRpt.Refresh();
            cryRpt = Program.setParam2(this.ticketRpt, paramName, paramValue);
            this.fRpt.setReport(cryRpt);
            this.fRpt.ShowDialog();
            if (this.fRpt.doPrint)
            {
                cryRpt.PrintToPrinter(1, true, 0, 0);
            }
        }

        private object SetGateNo(bool pSave)
        {
            DataRow row;
            string str = "";
            int totalWidth = 7;
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            if (pSave)
            {
                bool flag2 = true;
                bool flag3 = false;
                string str3 = "";
                while (true)
                {
                    if (!flag2)
                    {
                        break;
                    }
                    table2.OpenTable("wb_location", "Select * From wb_location Where " + WBData.CompanyLocation(""), WBData.conn);
                    row = table2.DT.Rows[0];
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 < 5)
                        {
                            table2.ReOpen();
                            row = table2.DT.Rows[0];
                            if ((row["ref_lock"].ToString().Trim().ToUpper() != "N") && (row["ref_lock"].ToString().Trim() != ""))
                            {
                                str3 = row["ref_lockBy"].ToString().Trim().ToUpper();
                                flag3 = true;
                                num2++;
                                continue;
                            }
                            row.BeginEdit();
                            row["ref_lock"] = "Y";
                            row["ref_lockBy"] = WBSetting.WBCode;
                            row.EndEdit();
                            table2.Save();
                            table2.ReOpen();
                            row = table2.DT.Rows[0];
                            flag3 = false;
                            flag2 = false;
                        }
                        if (flag3 && (MessageBox.Show(" Save Data Failed, Locked by " + str3 + ".\n\n Retry Save Data? ", "R E T R Y...", MessageBoxButtons.OK, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK))
                        {
                            flag2 = true;
                        }
                        break;
                    }
                }
            }
            table2.OpenTable("wb_location", "Select * From wb_location Where " + WBData.CompanyLocation(""), WBData.conn);
            row = table2.DT.Rows[0];
            string str2 = (row["Gatepass_No"].ToString().Trim() == "") ? "0" : row["Gatepass_No"].ToString().Trim();
            totalWidth = 7;
            while (true)
            {
                this.nRef = Convert.ToInt32(str2) + 1;
                str = this.nRef.ToString().Trim().PadLeft(totalWidth, '0');
                str = WBSetting.sGatepassCode + str;
                str2 = this.nRef.ToString().Trim();
                table.OpenTable("wb_gatepass", "Select Gatepass_Number From wb_gatepass Where " + WBData.CompanyLocation(" AND Gatepass_Number='" + str + "'"), WBData.conn);
                if (table.DT.Rows.Count == 0)
                {
                    if (pSave)
                    {
                        table2.ReOpen();
                        table2.DR = table2.DT.Rows[0];
                        table2.DR.BeginEdit();
                        table2.DR["Gatepass_No"] = this.nRef.ToString();
                        table2.DR["Ref_Lock"] = "N";
                        table2.DR.EndEdit();
                        table2.Save();
                    }
                    table2.Close();
                    table2.Dispose();
                    this.textGatepass_Number.Text = str;
                    return str;
                }
            }
        }

        private void texRejectComm_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textContainer_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textContainer_Leave(object sender, EventArgs e)
        {
            if (this.textContainer.Text.Trim() != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tblContainer.ReOpen();
                string[] aField = new string[] { "Container_Number" };
                string[] aFind = new string[] { this.textContainer.Text.Trim() };
                if (this.tblContainer.GetRecNo(aField, aFind) <= 0)
                {
                    this.buttonContainer.PerformClick();
                    this.textContainer.Focus();
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void textDriverID_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDriverID_Leave(object sender, EventArgs e)
        {
            if (this.textDriverID.Text.Trim() != "")
            {
                this.tblDriver.ReOpen();
                string[] aField = new string[] { "License_No" };
                string[] aFind = new string[] { this.textDriverID.Text.Trim() };
                int recNo = this.tblDriver.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                }
                else
                {
                    this.buttonDriver.PerformClick();
                    this.textDriverID.Focus();
                }
            }
        }

        private void textGpManual_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textHaulier_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textHaulier_Leave(object sender, EventArgs e)
        {
            if (this.textHaulier.Text.Trim() != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tblCust.ReOpen();
                string[] aField = new string[] { "Relation_code" };
                string[] aFind = new string[] { this.textHaulier.Text.Trim() };
                if (this.tblCust.GetRecNo(aField, aFind) <= -1)
                {
                    this.buttonHaulier.PerformClick();
                    this.textHaulier.Focus();
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void textIten_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textLoader_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textLoader_Leave(object sender, EventArgs e)
        {
            if (this.textLoader.Text.Trim() != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tblCust.ReOpen();
                string[] aField = new string[] { "Relation_code" };
                string[] aFind = new string[] { this.textLoader.Text.Trim() };
                if (this.tblCust.GetRecNo(aField, aFind) <= -1)
                {
                    this.buttonLoader.PerformClick();
                    this.textLoader.Focus();
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void textOwner_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textOwner_Leave(object sender, EventArgs e)
        {
            if (this.textOwner.Text.Trim() != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tblCust.ReOpen();
                string[] aField = new string[] { "Relation_code" };
                string[] aFind = new string[] { this.textOwner.Text.Trim() };
                if (this.tblCust.GetRecNo(aField, aFind) <= -1)
                {
                    this.buttonOwner.PerformClick();
                    this.textOwner.Focus();
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void textQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textRejectGatepass_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTrailerNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransporter_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransporter_Leave(object sender, EventArgs e)
        {
            if (this.textTransporter.Text.Trim() != "")
            {
                this.tblTransporter.ReOpen();
                string[] aField = new string[] { "Transporter_code" };
                string[] aFind = new string[] { this.textTransporter.Text.Trim() };
                int recNo = this.tblTransporter.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelTransporterName.Text = this.tblTransporter.DT.Rows[recNo]["Transporter_Name"].ToString();
                }
                else
                {
                    this.buttonTransporter.PerformClick();
                    this.textTransporter.Focus();
                }
            }
        }

        private void textTruck_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTruck_Leave(object sender, EventArgs e)
        {
            if (this.textTruck.Text.Trim() != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                string[] textArray1 = new string[] { " and ((Submit_Gatepass = 'N') OR (submit_gatepass is null) or (submit_gatepass = '')) and ( Deleted = 'N' or Deleted is null)  and (Truck_number = '", this.textTruck.Text, "') and gatepass_number <>'", this.textGatepass_Number.Text, "'" };
                this.sqlTmp = "select gatepass_number, ref, truck_number from wb_gatepass WHERE " + WBData.CompanyLocation(string.Concat(textArray1));
                this.tblTmp.OpenTable("wb_tmpGatepass", this.sqlTmp, WBData.conn);
                if (this.tblTmp.DT.Rows.Count > 0)
                {
                    this.tblTmp.DR = this.tblTmp.DT.Rows[0];
                    MessageBox.Show(Resource.Mes_167 + " " + this.textTruck.Text, Resource.Title_002);
                    this.textTruck.SelectAll();
                    this.textTruck.Focus();
                }
                else
                {
                    this.tblTruck.ReOpen();
                    string[] aField = new string[] { "Truck_Number" };
                    string[] aFind = new string[] { this.textTruck.Text.Trim() };
                    int recNo = this.tblTruck.GetRecNo(aField, aFind);
                    if (recNo <= -1)
                    {
                        this.buttonTruck.PerformClick();
                        this.textTruck.Focus();
                    }
                    else
                    {
                        this.textTruck.Text = this.tblTruck.DT.Rows[recNo]["Truck_Number"].ToString().Trim();
                        if ((this.textTransporter.Text == "") && (this.tblTruck.DT.Rows[recNo]["Transporter_Code"].ToString().Trim() != ""))
                        {
                            this.textTransporter.Text = this.tblTruck.DT.Rows[recNo]["Transporter_Code"].ToString().Trim();
                            string[] textArray4 = new string[] { "Transporter_Code" };
                            string[] textArray5 = new string[] { this.textTransporter.Text };
                            DataRow data = this.tblTransporter.GetData(textArray4, textArray5);
                            if (data != null)
                            {
                                this.labelTransporterName.Text = data["Transporter_Name"].ToString().Trim();
                            }
                        }
                    }
                    Cursor.Current = Cursors.Default;
                }
            }
        }

        private void translate()
        {
            this.label3.Text = Resource.Gatepass_031;
            this.label11.Text = Resource.Gatepass_032;
            this.label16.Text = Resource.Gatepass_033;
            this.buttonRec.Text = Resource.Gatepass_034;
            this.buttonLoad.Text = Resource.Gatepass_035;
            this.buttonRecCancel.Text = Resource.Gatepass_036;
            this.label2.Text = Resource.Gatepass_037;
            this.checkReject.Text = Resource.Gatepass_038;
            this.checkRejectComm.Text = Resource.Gatepass_039;
            this.radioCommFull.Text = Resource.Gatepass_040;
            this.radioCommPart.Text = Resource.Gatepass_041;
            this.groupPrint.Text = Resource.Gatepass_042;
            this.label13.Text = Resource.Gatepass_043;
            this.radioGP1.Text = Resource.Gatepass_044;
            this.radioGP2.Text = Resource.Gatepass_045;
            this.label14.Text = Resource.Gatepass_046;
            this.label15.Text = Resource.Gatepass_047;
            this.buttonSave.Text = Resource.Gatepass_048;
            this.buttonCancel.Text = Resource.Gatepass_049;
            this.buttonLoadCancel.Text = Resource.Gatepass_036;
            this.label1.Text = Resource.Gatepass_001;
            this.label5.Text = Resource.Gatepass_003;
            this.label46.Text = Resource.Gatepass_004;
            this.label7.Text = Resource.Gatepass_002;
            this.label10.Text = Resource.TruckE_004;
            this.labelRelation.Text = Resource.TruckE_005;
            this.label9.Text = Resource.TruckE_006;
            this.label12.Text = Resource.TruckE_008;
            this.label6.Text = Resource.TruckE_009;
            this.groupBox2.Text = Resource.Gatepass_005;
            this.labelTransType.Text = Resource.Gatepass_023;
            this.label17.Text = Resource.Gatepass_006;
            this.label24.Text = Resource.Gatepass_007;
            this.label19.Text = Resource.Gatepass_008;
            this.label22.Text = Resource.Gatepass_009;
            this.label18.Text = Resource.Gatepass_006;
            this.label20.Text = Resource.Gatepass_007;
        }

        private void TransType_Leave()
        {
            if (this.comTransType.Text.Trim() != "")
            {
                string[] aField = new string[] { "Transaction_code" };
                string[] aFind = new string[] { this.comTransType.Text };
                DataRow data = this.tblTransType.GetData(aField, aFind);
                if (data == null)
                {
                    MessageBox.Show(Resource.Mes_426, Resource.Title_002);
                    this.comTransType.Text = "";
                    this.comboGatepassType1.Text = "";
                    this.comboGatepassType2.Text = "";
                    this.comboGatepassType2.Items.Clear();
                    this.comboGatepassType1.Items.Clear();
                    this.textGatepassType.Text = "";
                }
                else
                {
                    this.labelTransName.Text = data["Transaction_Name"].ToString();
                    if (data["gatepass_type"].ToString() == "I")
                    {
                        this.textGatepassType.Text = "INBOUND";
                        this.gType = "I";
                    }
                    else
                    {
                        this.textGatepassType.Text = "OUTBOUND";
                        this.gType = "O";
                    }
                    DataRow[] rowArray = this.tblGatepassType1.DT.Select("Gatepass_type ='" + this.gType + "'");
                    this.comboGatepassType1.Items.Clear();
                    foreach (DataRow row2 in rowArray)
                    {
                        this.comboGatepassType1.Items.Add(row2["gatepass_typeName"].ToString());
                    }
                }
            }
        }
    }
}

