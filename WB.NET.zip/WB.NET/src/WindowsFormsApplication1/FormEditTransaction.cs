﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text.RegularExpressions;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormEditTransaction : Form
    {
        public WBTable tblTrans = new WBTable();
        public WBTable tblGP = new WBTable();
        public DataGridView dgvTrans;
        public int nCurrRow;
        public string pMode = "";
        public string WX = "";
        public string sUniq = "";
        public bool Saved = false;
        public bool checkSPB = false;
        public bool scanESPB;
        public bool expiredSPB = false;
        public string gatepass_uniq = "";
        public string gatepass_no = "";
        public string register_by = "";
        public string card_no = "";
        public string noRef = "";
        public string wbDO = "";
        private string editTrace;
        private string relCode;
        private string relName;
        private string oldDN;
        private string oldRepDate;
        private string changeReason;
        private string truckno;
        private string commcode;
        private string licenseno;
        private DateTime dDate;
        private IContainer components = null;
        private Label lblRef;
        private Label lblDN;
        private TextBox txtBoxDN;
        public TextBox txtBoxRef;
        private Button buttonSave;
        private Button buttonCancel;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel lbleSPB;
        private Label lblReportDate;
        private DateTimePicker dateTimePicketReportDate;
        public TextBox txtBoxTruck;
        private Label lblTruck;
        public TextBox txtBoxLicense;
        private Label lblLicense;
        private Button buttonDN;

        public FormEditTransaction()
        {
            this.InitializeComponent();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to exit?", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                base.Close();
            }
        }

        private void buttonDN_Click(object sender, EventArgs e)
        {
            FormSPBv2 bv = new FormSPBv2();
            bv.ShowDialog();
            bv.Dispose();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (this.saveData())
            {
                this.SendMail();
                base.Close();
            }
        }

        private bool checkDataEdited()
        {
            bool flag4;
            string fieldname = (this.pMode == "EDIT_SPB") ? "delivery_note" : ((this.pMode == "EDIT_REPORT_DATE") ? "report_date" : "");
            this.tblTrans.DR = this.tblTrans.DT.Rows[0];
            WBTable table = new WBTable();
            table.OpenTable("wb_warning_trace", "select * from wb_warning_trace where " + WBData.CompanyLocation(" and type = 'TRANSACTION'"), WBData.conn);
            List<DataRow> list = table.DT.AsEnumerable().Where<DataRow>(r => (r["fieldname"].ToString().ToUpper() == fieldname.ToUpper())).ToList<DataRow>();
            if ((list.Count <= 0) || (list[0]["selected"].ToString() != "Y"))
            {
                flag4 = false;
            }
            else
            {
                if (fieldname == "delivery_note")
                {
                    string[] textArray1 = new string[] { "<tr class='bd'><td nowrap>", fieldname, "</td><td nowrap>", this.oldDN, "</td><td nowrap>", this.txtBoxDN.Text, "</td></tr>" };
                    this.editTrace = string.Concat(textArray1);
                }
                else if (fieldname == "report_date")
                {
                    string[] textArray2 = new string[] { "<tr class='bd'><td nowrap>", fieldname, "</td><td nowrap>", this.oldRepDate, "</td><td nowrap>", this.dateTimePicketReportDate.Text, "</td></tr>" };
                    this.editTrace = string.Concat(textArray2);
                }
                flag4 = true;
            }
            return flag4;
        }

        private bool checkDeliveryNote(string DN)
        {
            bool checkSPB;
            this.checkSPB = false;
            if (!this.scanESPB && !Regex.IsMatch(this.txtBoxDN.Text, "^[a-zA-Z0-9]+$"))
            {
                MessageBox.Show(Resource.Filter_004, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                checkSPB = true;
            }
            else
            {
                if (this.scanESPB)
                {
                    this.CheckTrxandGP();
                }
                else
                {
                    this.CheckTrxandGP();
                    if (!this.checkSPB)
                    {
                        this.checkDeliveryNoteRange();
                    }
                }
                checkSPB = this.checkSPB;
            }
            return checkSPB;
        }

        private void checkDeliveryNoteRange()
        {
            WBTable table = new WBTable();
            bool flag = false;
            table.OpenTable("wb_dn", "select delivery_note_from,Delivery_Note_to,expired_date from wb_delivery_note with (nolock) where relation_code = '" + this.relCode + "' and (Deleted is null or Deleted <> 'Y' or Deleted = 'N') ", WBData.conn);
            int num = 0;
            while (true)
            {
                if (num >= table.DT.Rows.Count)
                {
                    if (!((!this.checkSPB | flag) && WBSetting.checkCutOffDeliveryNote()))
                    {
                        MessageBox.Show(Resource.DeliveryNote_008, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        this.txtBoxDN.Focus();
                        this.checkSPB = true;
                    }
                    else
                    {
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_delivery_note", "Select delivery_note_from,Delivery_Note_to From wb_delivery_note with (nolock) where Do_No='" + this.wbDO + "' and (Deleted is null or Deleted <> 'Y' or Deleted = 'N') ", WBData.conn);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show(Resource.DeliveryNote_008, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            this.txtBoxDN.Focus();
                            this.checkSPB = true;
                        }
                        else
                        {
                            int num2 = 0;
                            while (true)
                            {
                                if (num2 >= table2.DT.Rows.Count)
                                {
                                    break;
                                }
                                table2.DR = table2.DT.Rows[num2];
                                if (this.txtBoxDN.Text.Length != table2.DR["delivery_note_from"].ToString().Length)
                                {
                                    this.checkSPB = true;
                                }
                                else if ((string.Compare(this.txtBoxDN.Text, table2.DR["Delivery_Note_From"].ToString()) >= 0) && (string.Compare(this.txtBoxDN.Text, table2.DR["Delivery_Note_to"].ToString()) <= 0))
                                {
                                    this.checkSPB = false;
                                    break;
                                }
                                num2++;
                            }
                            if (this.checkSPB)
                            {
                                MessageBox.Show(Resource.DeliveryNote_008, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.txtBoxDN.Focus();
                            }
                        }
                    }
                    table.Dispose();
                    break;
                }
                DataRow row = table.DT.Rows[num];
                if (this.txtBoxDN.Text.Length != row["delivery_note_from"].ToString().Length)
                {
                    flag = true;
                }
                else if ((string.Compare(this.txtBoxDN.Text, row["Delivery_Note_From"].ToString()) >= 0) && (string.Compare(this.txtBoxDN.Text, row["Delivery_Note_to"].ToString()) <= 0))
                {
                    if (Convert.ToDateTime(WBUtility.GetServerDatetime()) <= Convert.ToDateTime(row["expired_date"].ToString()))
                    {
                        flag = false;
                        this.checkSPB = false;
                        break;
                    }
                    MessageBox.Show(Resource.DeliveryNote_005, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.txtBoxDN.Focus();
                    this.checkSPB = true;
                    flag = false;
                }
                num++;
            }
        }

        private void CheckTrxandGP()
        {
            WBTable table = new WBTable();
            table.OpenTable("checkTrx", "select delivery_note,ref from wb_transaction with (nolock) where delivery_note = '" + this.txtBoxDN.Text + "'", WBData.conn);
            if (table.DT.Rows.Count != 0)
            {
                if (table.DT.Rows.Count > 0)
                {
                    MessageBox.Show(string.Format(Resource.DeliveryNote_010, table.DT.Rows[0]["ref"].ToString()), "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.checkSPB = true;
                }
            }
            else
            {
                WBTable table2 = new WBTable();
                table2.OpenTable("checkGP", "select delivery_note,gatepass_number from wb_gatepass as gp with (nolock) where delivery_note = '" + this.txtBoxDN.Text + "'", WBData.conn);
                if (table2.DT.Rows.Count > 0)
                {
                    MessageBox.Show(string.Format(Resource.DeliveryNote_010, table2.DT.Rows[0]["gatepass_number"].ToString()), "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.checkSPB = true;
                }
                table2.Dispose();
            }
            table.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormEditTransaction_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            WBSetting.OpenSetting();
            this.tblTrans.ReOpen();
            this.Text = (this.pMode == "EDIT_SPB") ? "Edit Delivery Note" : ((this.pMode == "EDIT_REPORTDATE") ? "Edit Report Date" : "");
            this.scanESPB = !WBSetting.activeTCS ? (!string.IsNullOrEmpty(this.tblTrans.DT.Rows[0]["scanespb"].ToString()) ? (this.tblTrans.DT.Rows[0]["scanespb"].ToString() == "Y") : false) : (!string.IsNullOrEmpty(this.tblGP.DT.Rows[0]["scanespb"].ToString()) ? (this.tblGP.DT.Rows[0]["scanespb"].ToString() == "Y") : false);
            this.lbleSPB.Visible = (this.pMode == "EDIT_SPB") && this.scanESPB;
            this.txtBoxRef.Text = this.noRef;
            this.relCode = this.tblTrans.DT.Rows[0]["relation_code"].ToString();
            WBTable table = new WBTable();
            table.OpenTable("wb_relation", "select relation_name from wb_relation with (nolock) where " + WBData.CompanyLocation(" AND relation_code = '" + this.relCode + "'"), WBData.conn);
            this.relName = table.DT.Rows[0]["relation_name"].ToString();
            if (this.pMode == "EDIT_SPB")
            {
                this.txtBoxDN.Enabled = true;
                this.dateTimePicketReportDate.Enabled = false;
            }
            else if (this.pMode == "EDIT_REPORTDATE")
            {
                this.txtBoxDN.Enabled = false;
                this.dateTimePicketReportDate.Enabled = true;
            }
            this.buttonDN.Visible = WBSetting.locType == "1";
            this.txtBoxDN.Text = this.tblTrans.DT.Rows[0]["delivery_note"].ToString();
            this.dateTimePicketReportDate.Text = this.tblTrans.DT.Rows[0]["report_date"].ToString();
            this.oldDN = this.txtBoxDN.Text;
            this.oldRepDate = this.dateTimePicketReportDate.Text;
            this.truckno = this.tblTrans.DT.Rows[0]["truck_number"].ToString();
            this.txtBoxTruck.Text = this.truckno;
            this.licenseno = this.tblTrans.DT.Rows[0]["license_no"].ToString();
            this.txtBoxLicense.Text = this.licenseno;
            this.commcode = this.tblTrans.DT.Rows[0]["comm_code"].ToString();
            this.wbDO = this.tblTrans.DT.Rows[0]["do_no"].ToString();
        }

        private void InitializeComponent()
        {
            ComponentResourceManager manager = new ComponentResourceManager(typeof(FormEditTransaction));
            this.lblRef = new Label();
            this.lblDN = new Label();
            this.txtBoxRef = new TextBox();
            this.txtBoxDN = new TextBox();
            this.buttonSave = new Button();
            this.buttonCancel = new Button();
            this.statusStrip1 = new StatusStrip();
            this.lbleSPB = new ToolStripStatusLabel();
            this.lblReportDate = new Label();
            this.dateTimePicketReportDate = new DateTimePicker();
            this.txtBoxTruck = new TextBox();
            this.lblTruck = new Label();
            this.txtBoxLicense = new TextBox();
            this.lblLicense = new Label();
            this.buttonDN = new Button();
            this.statusStrip1.SuspendLayout();
            base.SuspendLayout();
            manager.ApplyResources(this.lblRef, "lblRef");
            this.lblRef.Name = "lblRef";
            manager.ApplyResources(this.lblDN, "lblDN");
            this.lblDN.Name = "lblDN";
            manager.ApplyResources(this.txtBoxRef, "txtBoxRef");
            this.txtBoxRef.Name = "txtBoxRef";
            this.txtBoxDN.CharacterCasing = CharacterCasing.Upper;
            manager.ApplyResources(this.txtBoxDN, "txtBoxDN");
            this.txtBoxDN.Name = "txtBoxDN";
            this.txtBoxDN.KeyPress += new KeyPressEventHandler(this.txtBoxDN_KeyPress);
            this.txtBoxDN.Leave += new EventHandler(this.txtBoxDN_Leave);
            manager.ApplyResources(this.buttonSave, "buttonSave");
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            manager.ApplyResources(this.buttonCancel, "buttonCancel");
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.lbleSPB };
            this.statusStrip1.Items.AddRange(toolStripItems);
            manager.ApplyResources(this.statusStrip1, "statusStrip1");
            this.statusStrip1.Name = "statusStrip1";
            manager.ApplyResources(this.lbleSPB, "lbleSPB");
            this.lbleSPB.ForeColor = Color.Red;
            this.lbleSPB.Name = "lbleSPB";
            manager.ApplyResources(this.lblReportDate, "lblReportDate");
            this.lblReportDate.Name = "lblReportDate";
            manager.ApplyResources(this.dateTimePicketReportDate, "dateTimePicketReportDate");
            this.dateTimePicketReportDate.Format = DateTimePickerFormat.Short;
            this.dateTimePicketReportDate.Name = "dateTimePicketReportDate";
            this.dateTimePicketReportDate.Value = new DateTime(0x7e3, 5, 7, 0, 0, 0, 0);
            manager.ApplyResources(this.txtBoxTruck, "txtBoxTruck");
            this.txtBoxTruck.Name = "txtBoxTruck";
            manager.ApplyResources(this.lblTruck, "lblTruck");
            this.lblTruck.Name = "lblTruck";
            manager.ApplyResources(this.txtBoxLicense, "txtBoxLicense");
            this.txtBoxLicense.Name = "txtBoxLicense";
            manager.ApplyResources(this.lblLicense, "lblLicense");
            this.lblLicense.Name = "lblLicense";
            manager.ApplyResources(this.buttonDN, "buttonDN");
            this.buttonDN.Name = "buttonDN";
            this.buttonDN.UseVisualStyleBackColor = true;
            this.buttonDN.Click += new EventHandler(this.buttonDN_Click);
            manager.ApplyResources(this, "$this");
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ControlBox = false;
            base.Controls.Add(this.buttonDN);
            base.Controls.Add(this.txtBoxLicense);
            base.Controls.Add(this.lblLicense);
            base.Controls.Add(this.txtBoxTruck);
            base.Controls.Add(this.lblTruck);
            base.Controls.Add(this.dateTimePicketReportDate);
            base.Controls.Add(this.lblReportDate);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.txtBoxDN);
            base.Controls.Add(this.txtBoxRef);
            base.Controls.Add(this.lblDN);
            base.Controls.Add(this.lblRef);
            base.Controls.Add(this.statusStrip1);
            base.MaximizeBox = false;
            base.Name = "FormEditTransaction";
            base.Load += new EventHandler(this.FormEditTransaction_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private bool saveData()
        {
            bool flag3;
            bool flag = false;
            if (((this.pMode == "EDIT_SPB") && (WBSetting.locType == "1")) && this.checkDeliveryNote(this.txtBoxDN.Text))
            {
                flag3 = false;
            }
            else
            {
                FormTransCancel cancel = new FormTransCancel {
                    textRefNo = { Text = this.txtBoxRef.Text },
                    Text = "CHANGE REASON",
                    label2 = { Text = "Change Reason :" }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (!cancel.Saved)
                {
                    flag3 = false;
                }
                else
                {
                    this.changeReason = cancel.textReason.Text;
                    this.tblTrans.DR = this.tblTrans.DT.Rows[0];
                    this.tblTrans.DR.BeginEdit();
                    this.tblTrans.DR["delivery_note"] = this.txtBoxDN.Text;
                    this.tblTrans.DR["report_date"] = this.dateTimePicketReportDate.Text;
                    this.tblTrans.DR["edit_by"] = WBUser.UserID;
                    this.tblTrans.DR["edit_date"] = WBUtility.GetServerDatetime();
                    this.tblTrans.DR["Edit_Data"] = !string.IsNullOrEmpty(this.tblTrans.DR["Edit_Data"].ToString()) ? (Convert.ToInt16(this.tblTrans.DR["Edit_Data"].ToString()) + 1).ToString() : "1";
                    this.tblTrans.DR["edit_date"] = WBUtility.GetServerDatetime();
                    this.tblTrans.DR["Reason"] = this.changeReason;
                    this.tblTrans.DR.EndEdit();
                    this.tblTrans.Save();
                    flag = true;
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, this.changeReason };
                    Program.updateLogHeader("wb_transaction", this.tblTrans.DT.Rows[0]["uniq"].ToString(), logField, logValue);
                    if (WBSetting.activeTCS && (this.pMode == "EDIT_SPB"))
                    {
                        string str = this.changeReason + "(TRIGGER EDIT TRANSACTION)";
                        this.tblGP.DR = this.tblGP.DT.Rows[0];
                        this.tblGP.DR.BeginEdit();
                        this.tblGP.DR["delivery_note"] = this.txtBoxDN.Text;
                        this.tblGP.DR["change_by"] = WBUser.UserID;
                        this.tblGP.DR["change_date"] = WBUtility.GetServerDatetime();
                        this.tblGP.DR["reason"] = str.Substring(0, 0x31);
                        this.tblGP.DR.EndEdit();
                        this.tblGP.Save();
                        string[] textArray3 = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] textArray4 = new string[] { "EDIT", WBUser.UserID, str };
                        Program.updateLogHeader("wb_gatepass", this.tblGP.DT.Rows[0]["uniq"].ToString(), textArray3, textArray4);
                    }
                    flag3 = flag;
                }
            }
            return flag3;
        }

        private void SendMail()
        {
            if ((WBSetting.Field("check_email").Trim() == "Y") && this.checkDataEdited())
            {
                string[] textArray1 = new string[] { ("Dear All,<br><br>This email is to notify you that the following transaction has been edited :<table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name"), "</tr><tr class='bd'><td nowrap>Date & Time</td><td nowrap> : ", DateTime.Now.ToShortDateString(), " ", DateTime.Now.ToString("HH:mm:ss") };
                string[] textArray2 = new string[] { (((string.Concat(textArray1) + "</tr><tr class='bd'><td nowrap>Ref Number</td><td nowrap> : " + this.txtBoxRef.Text) + "</tr><tr class='bd'><td nowrap>Truck Number</td><td nowrap> : " + this.truckno) + "</tr><tr class='bd'><td nowrap>Commodity Code</td><td nowrap> : " + this.commcode) + "</tr><tr class='bd'><td nowrap>Change Reason</td><td nowrap> : " + this.changeReason, "</tr><tr class='bd'><td nowrap>WB User</td><td nowrap> : ", WBUser.UserGroup.Trim(), " ( ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " ) " };
                WBMail mail = new WBMail();
                mail.SendMail_Edit((((string.Concat(textArray2) + "</tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : " + WBData.sWBCode) + "</tr></table><br><br>~Changes on Data~               ") + "<table border=1 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Field</td><td nowrap>Before Edit</td><td nowrap>After Edit</td></tr>" + this.editTrace) + "</tr></table><br><br>" + "<br>Thank You.");
                mail.Dispose();
                WBTable table = new WBTable();
                table.OpenTable("wb_email", "select * from wb_email where " + WBData.CompanyLocation(" and email_code = 'TRANSLOG' and email_date = '" + DateTime.Now.ToString("yyyy-MM-dd") + " 00:00:00' "), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    table.DR = table.DT.NewRow();
                    table.DR["COY"] = WBData.sCoyCode;
                    table.DR["LOCATION_CODE"] = WBData.sLocCode;
                    table.DR["Email_code"] = "TRANSLOG";
                    table.DR["Email_date"] = DateTime.Now.ToString("dd/MM/yyyy");
                    table.DR["Status"] = "N";
                    table.DT.Rows.Add(table.DR);
                    table.Save();
                }
                else if (table.DT.Rows[0]["Status"].ToString() == "Y")
                {
                    table.DR = table.DT.Rows[0];
                    table.DR.BeginEdit();
                    table.DR["Status"] = "N";
                    table.DR.EndEdit();
                    table.Save();
                }
                table.Dispose();
            }
        }

        private void txtBoxDN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((this.pMode == "EDIT_SPB") && !this.scanESPB)
            {
                WBUtility.CheckInput(e, "A|N");
            }
        }

        private void txtBoxDN_Leave(object sender, EventArgs e)
        {
            if ((this.txtBoxDN.Text.Trim() != "-") && (!string.IsNullOrEmpty(this.txtBoxDN.Text) && (((this.pMode == "EDIT_SPB") && !this.scanESPB) && WBUtility.CheckLeave(this.txtBoxDN.Text, "A|N"))))
            {
                MessageBox.Show(Resource.Filter_004, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.txtBoxDN.Focus();
            }
        }
    }
}

