﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormMulesoft : Form
    {
        private int idxFind = 0;
        private int nCurrRow;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private IContainer components = null;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem closeToolStripMenuItem;
        private DataGridView dgvMulesoft;
        private ToolStripMenuItem viewRecordToolStripMenuItem;

        public FormMulesoft()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dgvMulesoft, "ADD"))
            {
                FormMulesoftEntry entry = new FormMulesoftEntry {
                    pMode = "ADD",
                    Text = "Add new URL for  Mulesoft",
                    zTable = this.ztable
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dgvMulesoft = this.ztable.AfterEdit("ADD");
                    string[] aField = new string[] { "RFC_Name" };
                    string[] aFind = new string[] { entry.textName.Text };
                    this.ztable.SetCursor(this.dgvMulesoft, this.ztable.GetCurrentRow(this.dgvMulesoft, aField, aFind));
                }
                this.ztable.UnLock();
                entry.Dispose();
            }
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dgvMulesoft.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dgvMulesoft.Rows.Count > 0) && (MessageBox.Show("Are you sure want to delete URL for RFC '" + this.dgvMulesoft.CurrentRow.Cells["RFC_Name"].Value.ToString() + "'?", Resource.Mes_Confirmation, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes))
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "RFC Name" },
                    textRefNo = { Text = this.dgvMulesoft.CurrentRow.Cells["RFC_Name"].Value.ToString() },
                    Text = Resource.Form_Delete_Reason,
                    label2 = { Text = Resource.Lbl_Delete_Reason }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                    if (this.ztable.BeforeEdit(this.dgvMulesoft, "DELETE"))
                    {
                        string[] aField = new string[] { "uniq" };
                        string[] aFind = new string[] { this.dgvMulesoft.CurrentRow.Cells["uniq"].Value.ToString() };
                        int recNo = this.ztable.GetRecNo(aField, aFind);
                        this.logKey = this.ztable.DT.Rows[recNo]["uniq"].ToString();
                        this.ztable.DT.Rows[recNo].Delete();
                        this.ztable.Save();
                        this.ztable.AfterEdit("DELETE");
                    }
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dgvMulesoft.Rows.Count > 0) && this.ztable.BeforeEdit(this.dgvMulesoft, "EDIT"))
            {
                FormMulesoftEntry entry = new FormMulesoftEntry {
                    pMode = "EDIT",
                    nCurrRow = this.ztable.GetPosRec(this.dgvMulesoft.CurrentRow.Cells["uniq"].Value.ToString()),
                    Text = "Edit URL for Mulesoft",
                    zTable = this.ztable
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dgvMulesoft = this.ztable.AfterEdit("EDIT");
                    string[] aField = new string[] { "RFC_Name" };
                    string[] aFind = new string[] { entry.textName.Text };
                    this.ztable.SetCursor(this.dgvMulesoft, this.ztable.GetCurrentRow(this.dgvMulesoft, aField, aFind));
                }
                this.ztable.UnLock();
                entry.Dispose();
            }
        }

        private void FormMulesoft_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormMulesoft_Load(object sender, EventArgs e)
        {
            this.viewRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_MULESOFTURL", "V");
            this.addNewRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_MULESOFTURL", "A");
            this.editRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_MULESOFTURL", "E");
            this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_MULESOFTURL", "D");
            string sqltext = "SELECT * FROM wb_mulesoftURL WHERE " + WBData.CompanyLocation("");
            this.ztable.OpenTable("wb_mulesoftURL", sqltext, WBData.conn);
            this.dgvMulesoft.DataSource = this.ztable.DT;
            this.dgvMulesoft.Sort(this.dgvMulesoft.Columns["RFC_Name"], ListSortDirection.Ascending);
            this.dgvMulesoft.Columns["Coy"].Visible = false;
            this.dgvMulesoft.Columns["Location_Code"].Visible = false;
            this.dgvMulesoft.Columns["Uniq"].Visible = false;
            this.dgvMulesoft.Columns["RFC_Name"].HeaderText = "RFC Name";
            this.dgvMulesoft.Columns["RFC_Description"].HeaderText = "Description";
            this.dgvMulesoft.Columns["RFC_URL"].HeaderText = "URL";
            this.dgvMulesoft.Columns["Create_By"].HeaderText = "Create By";
            this.dgvMulesoft.Columns["Create_Date"].HeaderText = "Create Date";
            this.dgvMulesoft.Columns["Change_By"].HeaderText = "Change By";
            this.dgvMulesoft.Columns["Change_Date"].HeaderText = "Change Date";
        }

        private void InitializeComponent()
        {
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.dgvMulesoft = new DataGridView();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dgvMulesoft).BeginInit();
            base.SuspendLayout();
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x29b, 0x18);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.viewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.dgvMulesoft.AllowUserToAddRows = false;
            this.dgvMulesoft.AllowUserToDeleteRows = false;
            this.dgvMulesoft.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvMulesoft.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMulesoft.Dock = DockStyle.Fill;
            this.dgvMulesoft.Location = new Point(0, 0x18);
            this.dgvMulesoft.MultiSelect = false;
            this.dgvMulesoft.Name = "dgvMulesoft";
            this.dgvMulesoft.ReadOnly = true;
            this.dgvMulesoft.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvMulesoft.Size = new Size(0x29b, 0x12f);
            this.dgvMulesoft.TabIndex = 1;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x29b, 0x147);
            base.ControlBox = false;
            base.Controls.Add(this.dgvMulesoft);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "FormMulesoft";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of URL for Mulesoft";
            base.Load += new EventHandler(this.FormMulesoft_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormMulesoft_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dgvMulesoft).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.UserGroup_012;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.Text = "List of URL for Mulesoft";
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dgvMulesoft.Rows.Count > 0) && this.ztable.BeforeEdit(this.dgvMulesoft, "ADD"))
            {
                FormMulesoftEntry entry = new FormMulesoftEntry {
                    pMode = "VIEW",
                    Text = "View URL for Mulesoft",
                    nCurrRow = this.ztable.GetPosRec(this.dgvMulesoft.CurrentRow.Cells["uniq"].Value.ToString()),
                    zTable = this.ztable
                };
                entry.ShowDialog();
                this.ztable.UnLock();
                entry.Dispose();
            }
        }
    }
}

