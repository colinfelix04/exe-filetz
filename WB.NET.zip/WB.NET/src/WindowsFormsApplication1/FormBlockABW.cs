﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormBlockABW : Form
    {
        private WBTable tbl_Blok_Abw = new WBTable();
        private WBTable tbl_Blok = new WBTable();
        private WBTable tblEstate = new WBTable();
        private DataRow gdRow;
        private bool saved = false;
        public string divisonCode = "";
        public string estateCode = "";
        private IContainer components = null;
        private StatusStrip statusStrip1;
        private Panel panelBlok;
        public TextBox TextFind;
        public Button buttonFind;
        private Button buttonRefresh;
        private TextBox textYear;
        private Label labelMonth;
        private Label labelYear;
        private DataGridView dgBlokABW;
        private Panel panel3;
        private NumericUpDown textMonth;
        private Panel panelAction;
        private Button buttonDelete;
        private Button buttonSave;
        private ToolStripProgressBar prgBar;
        private ToolStripStatusLabel lblPrg;
        private Label labelHeader;
        private Button buttonClose;
        private TextBox textEstate;
        private Button btnEstate;
        private Label labelEstateADM;
        private Label label12;

        public FormBlockABW()
        {
            this.InitializeComponent();
        }

        private void btnEstate_Click(object sender, EventArgs e)
        {
            FormEstate estate = new FormEstate {
                pMode = "CHOOSE",
                pFind = this.textEstate.Text
            };
            estate.ShowDialog();
            if (estate.ReturnRow != null)
            {
                this.textEstate.Text = estate.ReturnRow["Estate_Code"].ToString();
                this.labelEstateADM.Text = estate.ReturnRow["Estate_Name"].ToString();
            }
            estate.Dispose();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (this.saved)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.ResetData();
            }
            else if (MessageBox.Show(Resource.Mes_017, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.ResetData();
            }
            Cursor.Current = Cursors.Default;
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            if (this.saved)
            {
                if (this.textEstate.Text.Trim() == "")
                {
                    MessageBox.Show("Please input Estate Code", "WARNING...");
                }
                else
                {
                    Cursor.Current = Cursors.WaitCursor;
                    this.getDataABW();
                    Cursor.Current = Cursors.Default;
                }
            }
            else if (this.textEstate.Text.Trim() == "")
            {
                MessageBox.Show("Please input Estate Code", "WARNING...");
            }
            else if (MessageBox.Show(Resource.Mes_016, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.getDataABW();
                Cursor.Current = Cursors.Default;
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.saveData();
            Cursor.Current = Cursors.Default;
        }

        private bool ChkEstate(int err)
        {
            bool flag3;
            string sqltext = "";
            sqltext = "select * from wb_Estate where " + WBData.CompanyLocation("");
            this.tblEstate.OpenTable("wb_Estate", sqltext, WBData.conn);
            string[] aField = new string[] { "Estate_Code" };
            string[] aFind = new string[] { this.textEstate.Text.Trim() };
            this.tblEstate.DR = this.tblEstate.GetData(aField, aFind);
            if (!ReferenceEquals(this.tblEstate.DR, null))
            {
                this.labelEstateADM.Text = this.tblEstate.DR["Estate_Name"].ToString();
                flag3 = true;
            }
            else
            {
                if (err == 1)
                {
                    MessageBox.Show(Resource.Mes_105, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.labelEstateADM.Text = "";
                flag3 = false;
            }
            return flag3;
        }

        private void dgBlokABW_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (this.dgBlokABW.Columns[this.dgBlokABW.CurrentCell.ColumnIndex].HeaderText.ToString().ToUpper() == "ABW")
            {
                try
                {
                    if (((float) Convert.ToDouble(this.dgBlokABW.CurrentCell.Value.ToString())) <= 9999.999)
                    {
                        this.dgBlokABW.CurrentCell.Value = Convert.ToString(Program.StrToDouble(this.dgBlokABW.CurrentCell.Value.ToString(), 3));
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_018, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.dgBlokABW.CurrentCell.Value = "0";
                    }
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_018, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.dgBlokABW.CurrentCell.Value = "0";
                }
            }
        }

        private void dgBlokABW_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormBlokABW_Load(object sender, EventArgs e)
        {
            this.tblEstate.OpenTable("wb_estate", "Select * from wb_estate", WBData.conn);
            Program.AutoComp(this.tblEstate, "Estate_Code", this.textEstate);
            this.translate();
            this.textMonth.Text = DateTime.Now.Date.Month.ToString();
            this.textYear.Text = DateTime.Now.Date.Year.ToString();
            this.Text = " ESTATE BLOK ABW";
            string[] textArray1 = new string[] { " and Estate_code = '", this.textEstate.Text.Trim(), "' and (Year = '", this.textYear.Text, "' and Month = '", this.textMonth.Text, "')" };
            this.tbl_Blok_Abw.OpenTable("wb_blokAbw", "Select * from WB_Block_Abw where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
            this.dgBlokABW.DataSource = this.tbl_Blok_Abw.DT;
            if (this.textEstate.Text.Trim() != "")
            {
                this.getDataABW();
            }
            this.dgBlokABW.Columns["Coy"].Visible = false;
            this.dgBlokABW.Columns["Location_code"].Visible = false;
            this.dgBlokABW.Columns["Division_code"].Visible = false;
            this.dgBlokABW.Columns["Estate_code"].Visible = false;
            this.dgBlokABW.Columns["Uniq"].Visible = false;
            this.dgBlokABW.Columns["Month"].Visible = false;
            this.dgBlokABW.Columns["Year"].Visible = false;
            this.dgBlokABW.Columns["Estate_Code"].HeaderText = "Estate Code";
            this.dgBlokABW.Columns["block_code"].HeaderText = Resource.ABW_007;
            this.dgBlokABW.Columns["abw"].HeaderText = Resource.ABW_008;
            this.dgBlokABW.Columns["change_date"].HeaderText = Resource.ABW_009;
            this.dgBlokABW.Columns["change_by"].HeaderText = Resource.ABW_010;
            foreach (DataGridViewColumn column in this.dgBlokABW.Columns)
            {
                column.ReadOnly = true;
                if (column.Name.ToUpper().Trim() == "ABW")
                {
                    column.ReadOnly = false;
                }
            }
        }

        private void getDataABW()
        {
            string[] textArray1 = new string[] { " and Estate_code = '", this.textEstate.Text.Trim(), "' and (Year = '", this.textYear.Text, "' and Month = '", this.textMonth.Text, "')" };
            this.tbl_Blok_Abw.OpenTable("wb_blokAbw", "Select * from WB_Block_Abw where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
            this.dgBlokABW.DataSource = this.tbl_Blok_Abw.DT;
            string[] textArray2 = new string[9];
            textArray2[0] = "ESTATE ";
            textArray2[1] = this.textEstate.Text.Trim();
            textArray2[2] = " BLOK ABW - ";
            textArray2[3] = this.textYear.Text;
            textArray2[4] = " / ";
            textArray2[5] = this.textMonth.Text.PadLeft(2, '0');
            textArray2[6] = " (";
            textArray2[7] = new DateTime(0x76c, Convert.ToInt16(this.textMonth.Text), 1).ToString("MMMM");
            textArray2[8] = ")";
            this.labelHeader.Text = string.Concat(textArray2);
            this.tbl_Blok.OpenTable("wb_blok", "Select * from wb_block where " + WBData.CompanyLocation(""), WBData.conn);
            this.prgBar.Maximum = this.tbl_Blok.DT.Rows.Count;
            bool flag = false;
            this.prgBar.Value = 0;
            this.lblPrg.Text = this.prgBar.Value.ToString() + "/" + this.tbl_Blok.DT.Rows.Count.ToString();
            this.statusStrip1.Refresh();
            foreach (DataRow row in this.tbl_Blok.DT.Rows)
            {
                string[] aField = new string[] { "block_code" };
                string[] aFind = new string[] { row["block_code"].ToString() };
                this.gdRow = this.tbl_Blok_Abw.GetData(aField, aFind);
                if (ReferenceEquals(this.gdRow, null))
                {
                    this.tbl_Blok_Abw.DR = this.tbl_Blok_Abw.DT.NewRow();
                    this.tbl_Blok_Abw.DR["Coy"] = WBData.sCoyCode;
                    this.tbl_Blok_Abw.DR["Location_code"] = WBData.sLocCode;
                    this.tbl_Blok_Abw.DR["Estate_code"] = this.textEstate.Text.Trim().ToUpper();
                    this.tbl_Blok_Abw.DR["Block_code"] = row["block_code"].ToString().Trim();
                    this.tbl_Blok_Abw.DR["ABW"] = "0";
                    this.tbl_Blok_Abw.DR["Month"] = this.textMonth.Text;
                    this.tbl_Blok_Abw.DR["Year"] = this.textYear.Text;
                    this.tbl_Blok_Abw.DT.Rows.Add(this.tbl_Blok_Abw.DR);
                    flag = true;
                }
                this.prgBar.Value++;
                this.lblPrg.Text = this.prgBar.Value.ToString() + "/" + this.tbl_Blok.DT.Rows.Count.ToString();
                this.statusStrip1.Refresh();
            }
            if (flag)
            {
                this.tbl_Blok_Abw.Save();
                this.tbl_Blok_Abw.ReOpen();
                this.dgBlokABW.DataSource = this.tbl_Blok_Abw.DT;
            }
            this.prgBar.Value = 0;
            this.lblPrg.Text = this.prgBar.Value.ToString() + "/" + this.tbl_Blok.DT.Rows.Count.ToString();
            this.statusStrip1.Refresh();
            this.prgBar.Maximum = this.dgBlokABW.Rows.Count;
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.statusStrip1 = new StatusStrip();
            this.prgBar = new ToolStripProgressBar();
            this.lblPrg = new ToolStripStatusLabel();
            this.panelBlok = new Panel();
            this.dgBlokABW = new DataGridView();
            this.labelHeader = new Label();
            this.panel3 = new Panel();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.textMonth = new NumericUpDown();
            this.labelMonth = new Label();
            this.labelYear = new Label();
            this.buttonRefresh = new Button();
            this.textYear = new TextBox();
            this.panelAction = new Panel();
            this.buttonClose = new Button();
            this.buttonDelete = new Button();
            this.buttonSave = new Button();
            this.textEstate = new TextBox();
            this.btnEstate = new Button();
            this.labelEstateADM = new Label();
            this.label12 = new Label();
            this.statusStrip1.SuspendLayout();
            this.panelBlok.SuspendLayout();
            ((ISupportInitialize) this.dgBlokABW).BeginInit();
            this.panel3.SuspendLayout();
            this.textMonth.BeginInit();
            this.panelAction.SuspendLayout();
            base.SuspendLayout();
            this.statusStrip1.ImageScalingSize = new Size(20, 20);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.prgBar, this.lblPrg };
            this.statusStrip1.Items.AddRange(toolStripItems);
            this.statusStrip1.Location = new Point(0, 0x274);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new Padding(1, 0, 0x13, 0);
            this.statusStrip1.Size = new Size(0x3be, 0x1a);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            this.prgBar.Name = "prgBar";
            this.prgBar.Size = new Size(0x85, 20);
            this.lblPrg.Name = "lblPrg";
            this.lblPrg.Size = new Size(0x1f, 0x15);
            this.lblPrg.Text = "0/0";
            this.panelBlok.Controls.Add(this.dgBlokABW);
            this.panelBlok.Controls.Add(this.labelHeader);
            this.panelBlok.Controls.Add(this.panel3);
            this.panelBlok.Dock = DockStyle.Fill;
            this.panelBlok.Location = new Point(0, 0xb1);
            this.panelBlok.Margin = new Padding(4, 4, 4, 4);
            this.panelBlok.Name = "panelBlok";
            this.panelBlok.Size = new Size(0x3be, 0x1c3);
            this.panelBlok.TabIndex = 1;
            this.dgBlokABW.AllowDrop = true;
            this.dgBlokABW.AllowUserToAddRows = false;
            this.dgBlokABW.AllowUserToDeleteRows = false;
            this.dgBlokABW.AllowUserToResizeRows = false;
            this.dgBlokABW.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgBlokABW.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgBlokABW.ColumnHeadersDefaultCellStyle = style;
            this.dgBlokABW.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgBlokABW.DefaultCellStyle = style2;
            this.dgBlokABW.Dock = DockStyle.Fill;
            this.dgBlokABW.Location = new Point(0, 0x22);
            this.dgBlokABW.Margin = new Padding(4, 4, 4, 4);
            this.dgBlokABW.MultiSelect = false;
            this.dgBlokABW.Name = "dgBlokABW";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgBlokABW.RowHeadersDefaultCellStyle = style3;
            this.dgBlokABW.SelectionMode = DataGridViewSelectionMode.CellSelect;
            this.dgBlokABW.Size = new Size(0x3be, 0x163);
            this.dgBlokABW.TabIndex = 1;
            this.dgBlokABW.CellEndEdit += new DataGridViewCellEventHandler(this.dgBlokABW_CellEndEdit);
            this.dgBlokABW.CellLeave += new DataGridViewCellEventHandler(this.dgBlokABW_CellLeave);
            this.labelHeader.BackColor = Color.FromArgb(0x80, 0x80, 0xff);
            this.labelHeader.Dock = DockStyle.Top;
            this.labelHeader.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelHeader.Location = new Point(0, 0);
            this.labelHeader.Margin = new Padding(4, 0, 4, 0);
            this.labelHeader.Name = "labelHeader";
            this.labelHeader.Size = new Size(0x3be, 0x22);
            this.labelHeader.TabIndex = 3;
            this.labelHeader.Text = "ESTATE ABW BLOK - 2015/1";
            this.labelHeader.TextAlign = ContentAlignment.MiddleCenter;
            this.panel3.Controls.Add(this.TextFind);
            this.panel3.Controls.Add(this.buttonFind);
            this.panel3.Dock = DockStyle.Bottom;
            this.panel3.Location = new Point(0, 0x185);
            this.panel3.Margin = new Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new Size(0x3be, 0x3e);
            this.panel3.TabIndex = 2;
            this.TextFind.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.TextFind.Location = new Point(290, 0x12);
            this.TextFind.Margin = new Padding(4, 4, 4, 4);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xf4, 0x16);
            this.TextFind.TabIndex = 5;
            this.TextFind.Visible = false;
            this.buttonFind.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            this.buttonFind.Location = new Point(0x21f, 0x11);
            this.buttonFind.Margin = new Padding(4, 4, 4, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(100, 0x1c);
            this.buttonFind.TabIndex = 6;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Visible = false;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.textMonth.Location = new Point(0x9e, 0x4f);
            this.textMonth.Margin = new Padding(4, 4, 4, 4);
            int[] bits = new int[4];
            bits[0] = 12;
            this.textMonth.Maximum = new decimal(bits);
            int[] numArray2 = new int[4];
            numArray2[0] = 1;
            this.textMonth.Minimum = new decimal(numArray2);
            this.textMonth.Name = "textMonth";
            this.textMonth.Size = new Size(80, 0x16);
            this.textMonth.TabIndex = 5;
            this.textMonth.TextAlign = HorizontalAlignment.Right;
            int[] numArray3 = new int[4];
            numArray3[0] = 12;
            this.textMonth.Value = new decimal(numArray3);
            this.labelMonth.AutoSize = true;
            this.labelMonth.Location = new Point(100, 0x51);
            this.labelMonth.Margin = new Padding(4, 0, 4, 0);
            this.labelMonth.Name = "labelMonth";
            this.labelMonth.Size = new Size(0x2f, 0x11);
            this.labelMonth.TabIndex = 4;
            this.labelMonth.Text = "Month";
            this.labelYear.AutoSize = true;
            this.labelYear.Location = new Point(0x66, 0x34);
            this.labelYear.Margin = new Padding(4, 0, 4, 0);
            this.labelYear.Name = "labelYear";
            this.labelYear.Size = new Size(0x26, 0x11);
            this.labelYear.TabIndex = 3;
            this.labelYear.Text = "Year";
            this.buttonRefresh.Location = new Point(0x109, 0x34);
            this.buttonRefresh.Margin = new Padding(4, 4, 4, 4);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new Size(0x65, 0x31);
            this.buttonRefresh.TabIndex = 1;
            this.buttonRefresh.Text = "&Refresh";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            this.buttonRefresh.Click += new EventHandler(this.buttonRefresh_Click);
            this.textYear.Location = new Point(0x9e, 0x31);
            this.textYear.Margin = new Padding(4, 4, 4, 4);
            this.textYear.MaxLength = 4;
            this.textYear.Name = "textYear";
            this.textYear.Size = new Size(80, 0x16);
            this.textYear.TabIndex = 0;
            this.textYear.Text = "1990";
            this.textYear.TextAlign = HorizontalAlignment.Right;
            this.textYear.KeyPress += new KeyPressEventHandler(this.textYear_KeyPress);
            this.panelAction.Controls.Add(this.textEstate);
            this.panelAction.Controls.Add(this.btnEstate);
            this.panelAction.Controls.Add(this.labelEstateADM);
            this.panelAction.Controls.Add(this.label12);
            this.panelAction.Controls.Add(this.buttonClose);
            this.panelAction.Controls.Add(this.textMonth);
            this.panelAction.Controls.Add(this.buttonDelete);
            this.panelAction.Controls.Add(this.labelMonth);
            this.panelAction.Controls.Add(this.buttonSave);
            this.panelAction.Controls.Add(this.labelYear);
            this.panelAction.Controls.Add(this.buttonRefresh);
            this.panelAction.Controls.Add(this.textYear);
            this.panelAction.Dock = DockStyle.Top;
            this.panelAction.Location = new Point(0, 0);
            this.panelAction.Margin = new Padding(4, 4, 4, 4);
            this.panelAction.Name = "panelAction";
            this.panelAction.Size = new Size(0x3be, 0xb1);
            this.panelAction.TabIndex = 1;
            this.buttonClose.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.buttonClose.Location = new Point(0x343, 0x12);
            this.buttonClose.Margin = new Padding(4, 4, 4, 4);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new Size(0x6a, 0x4d);
            this.buttonClose.TabIndex = 6;
            this.buttonClose.Text = "&Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new EventHandler(this.buttonClose_Click);
            this.buttonDelete.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.buttonDelete.Location = new Point(0xe5, 0x79);
            this.buttonDelete.Margin = new Padding(4, 4, 4, 4);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new Size(0x89, 0x30);
            this.buttonDelete.TabIndex = 2;
            this.buttonDelete.Text = "&Reset Per Month";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new EventHandler(this.buttonDelete_Click);
            this.buttonSave.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.buttonSave.Location = new Point(0x54, 0x79);
            this.buttonSave.Margin = new Padding(4, 4, 4, 4);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x89, 0x30);
            this.buttonSave.TabIndex = 0;
            this.buttonSave.Text = "&Save Per Month";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.textEstate.Location = new Point(0x9e, 0x12);
            this.textEstate.Margin = new Padding(4, 5, 4, 5);
            this.textEstate.MaxLength = 20;
            this.textEstate.Name = "textEstate";
            this.textEstate.Size = new Size(0xad, 0x16);
            this.textEstate.TabIndex = 0x29;
            this.textEstate.KeyPress += new KeyPressEventHandler(this.textEstate_KeyPress);
            this.textEstate.Leave += new EventHandler(this.textEstate_Leave);
            this.btnEstate.Location = new Point(0x14f, 0x10);
            this.btnEstate.Margin = new Padding(0);
            this.btnEstate.Name = "btnEstate";
            this.btnEstate.Size = new Size(0x1f, 0x1b);
            this.btnEstate.TabIndex = 0x2b;
            this.btnEstate.Text = "...";
            this.btnEstate.UseVisualStyleBackColor = true;
            this.btnEstate.Click += new EventHandler(this.btnEstate_Click);
            this.labelEstateADM.AutoSize = true;
            this.labelEstateADM.Location = new Point(370, 0x15);
            this.labelEstateADM.Margin = new Padding(4, 0, 4, 0);
            this.labelEstateADM.Name = "labelEstateADM";
            this.labelEstateADM.Size = new Size(0x55, 0x11);
            this.labelEstateADM.TabIndex = 0x2c;
            this.labelEstateADM.Text = "EstateName";
            this.label12.Location = new Point(0x11, 0x15);
            this.label12.Margin = new Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x85, 0x10);
            this.label12.TabIndex = 0x2a;
            this.label12.Text = "Estate";
            this.label12.TextAlign = ContentAlignment.TopRight;
            base.AutoScaleDimensions = new SizeF(8f, 16f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x3be, 0x28e);
            base.ControlBox = false;
            base.Controls.Add(this.panelBlok);
            base.Controls.Add(this.panelAction);
            base.Controls.Add(this.statusStrip1);
            base.Margin = new Padding(4, 4, 4, 4);
            base.Name = "FormBlockABW";
            base.SizeGripStyle = SizeGripStyle.Show;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Form Blok ABW for Estate AAAAA Division BBBBB";
            base.Load += new EventHandler(this.FormBlokABW_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panelBlok.ResumeLayout(false);
            ((ISupportInitialize) this.dgBlokABW).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.textMonth.EndInit();
            this.panelAction.ResumeLayout(false);
            this.panelAction.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void ResetData()
        {
            this.prgBar.Value = 0;
            this.lblPrg.Text = this.prgBar.Value.ToString() + "/" + this.dgBlokABW.Rows.Count.ToString();
            this.statusStrip1.Refresh();
            foreach (DataGridViewRow row in (IEnumerable) this.dgBlokABW.Rows)
            {
                row.Cells["ABW"].Value = "0";
                this.prgBar.Value++;
            }
            MessageBox.Show(Resource.Mes_014, Resource.Title_007);
            this.prgBar.Value = 0;
            this.lblPrg.Text = this.prgBar.Value.ToString() + "/" + this.dgBlokABW.Rows.Count.ToString();
            this.statusStrip1.Refresh();
        }

        private void saveData()
        {
            Cursor.Current = Cursors.WaitCursor;
            this.prgBar.Value = 0;
            int count = this.dgBlokABW.Rows.Count;
            this.lblPrg.Text = this.prgBar.Value.ToString() + "/" + count.ToString();
            this.statusStrip1.Refresh();
            foreach (DataGridViewRow row in (IEnumerable) this.dgBlokABW.Rows)
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { row.Cells["uniq"].Value.ToString() };
                this.tbl_Blok_Abw.DR = this.tbl_Blok_Abw.GetData(aField, aFind);
                this.tbl_Blok_Abw.DR.BeginEdit();
                this.tbl_Blok_Abw.DR["ABW"] = row.Cells["ABW"].Value.ToString();
                this.tbl_Blok_Abw.DR["Change_by"] = WBUser.UserID;
                this.tbl_Blok_Abw.DR["Change_Date"] = DateTime.Now.ToString();
                this.tbl_Blok_Abw.DR.EndEdit();
                this.prgBar.Value++;
                this.lblPrg.Text = this.prgBar.Value.ToString() + "/" + this.dgBlokABW.Rows.Count.ToString();
                this.statusStrip1.Refresh();
            }
            this.tbl_Blok_Abw.Save();
            MessageBox.Show(Resource.Mes_015, Resource.Title_007);
            Cursor.Current = Cursors.Default;
            this.prgBar.Value = 0;
            this.lblPrg.Text = this.prgBar.Value.ToString() + "/" + this.dgBlokABW.Rows.Count.ToString();
            this.statusStrip1.Refresh();
        }

        private void textEstate_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textEstate_Leave(object sender, EventArgs e)
        {
            if (this.textEstate.Text.Trim() != "")
            {
                if (!this.ChkEstate(1))
                {
                    this.textEstate.Focus();
                }
            }
            else if (this.textEstate.Text.Trim() == "")
            {
                this.labelEstateADM.Text = "";
            }
        }

        private void textMonth_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void translate()
        {
            this.labelYear.Text = Resource.ABW_002;
            this.labelMonth.Text = Resource.ABW_003;
            this.buttonSave.Text = Resource.ABW_004;
            this.buttonDelete.Text = Resource.ABW_005;
            this.buttonRefresh.Text = Resource.ABW_006;
            this.buttonClose.Text = Resource.ABW_011;
            this.buttonFind.Text = Resource.Main_026;
        }
    }
}

