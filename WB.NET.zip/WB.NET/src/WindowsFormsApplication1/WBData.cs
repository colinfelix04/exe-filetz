﻿namespace WindowsFormsApplication1
{
    using Microsoft.Win32;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data.SqlClient;
    using System.IO;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class WBData : Component
    {
        public static string sServer;
        public static string sDatabase;
        public static string sUserID;
        public static string sPassword;
        public static string ConnStr;
        public static string sRegion;
        public static string sLanguage;
        public static string sCoyName;
        public static string sCoyCode;
        public static string sLocName;
        public static string sLocCode;
        public static string sWBCode;
        public static string sCheckDirect;
        public static string sPort;
        public static string sTruckRegion;
        public static SqlConnection conn;
        public static SqlConnection conn_album;
        public static string rptPath = (Application.StartupPath + @"\Report\");
        public static string NotMarkDeleted = "( ISNULL(Deleted,'')='' or Deleted<>'Y' )";
        public static string MarkDeleted = "( ISNULL(Deleted,'')<>'' AND ( Deleted='Y')";
        public static string NotMarkDelInclReject = "( ISNULL(Deleted,'')='' or Deleted<>'Y' or cancel_type = 'R')";
        public static string sDatabase_album;

        public static void Close()
        {
            conn.Close();
        }

        public static string Company(string pStr)
        {
            string str = "";
            if (WBSetting.copyToLoc == "Y")
            {
                str = " (Coy='" + sCoyCode + "') ";
            }
            else
            {
                string[] textArray1 = new string[] { " (Coy='", sCoyCode, "') and (Location_Code='", sLocCode, "') " };
                str = string.Concat(textArray1);
            }
            return (str + " " + pStr);
        }

        public static string CompanyLocation(string pStr)
        {
            string[] textArray1 = new string[] { " (Coy='", sCoyCode, "') and (Location_Code='", sLocCode, "') " };
            return (string.Concat(textArray1) + " " + pStr);
        }

        public bool Open()
        {
            if ((sUserID.Trim().ToUpper() == "SA") && !this.OpenNonSA())
            {
            }
            string[] textArray1 = new string[9];
            textArray1[0] = "server=";
            textArray1[1] = sServer;
            textArray1[2] = "; database=";
            textArray1[3] = sDatabase;
            textArray1[4] = "; uid=";
            textArray1[5] = sUserID;
            textArray1[6] = "; password=";
            textArray1[7] = sPassword;
            textArray1[8] = ";MultipleActiveResultSets=true;";
            ConnStr = string.Concat(textArray1);
            try
            {
                conn = new SqlConnection(ConnStr);
                conn.Open();
                WBTable table = new WBTable();
                table.OpenTable("wb_loc", "Select * from wb_location", conn);
                if (table.DT.Rows.Count > 0)
                {
                    sRegion = table.DT.Rows[0]["region"].ToString();
                    sLanguage = table.DT.Rows[0]["language"].ToString();
                    sTruckRegion = table.DT.Rows[0]["Truck_Region"].ToString();
                }
                table.Dispose();
                return true;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Resource.Mes_545 + " : \n\n" + exception.Message, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                FormCfg cfg = new FormCfg();
                cfg.ShowDialog();
                if (cfg.exit)
                {
                    Application.Exit();
                }
                else
                {
                    Application.Restart();
                }
                return false;
            }
        }

        public static bool open_album_db()
        {
            string[] textArray1 = new string[9];
            textArray1[0] = "server=";
            textArray1[1] = sServer;
            textArray1[2] = "; database=";
            textArray1[3] = sDatabase_album;
            textArray1[4] = "; uid=";
            textArray1[5] = sUserID;
            textArray1[6] = "; password=";
            textArray1[7] = sPassword;
            textArray1[8] = ";MultipleActiveResultSets=true;";
            ConnStr = string.Concat(textArray1);
            try
            {
                conn_album = new SqlConnection(ConnStr);
                conn_album.Open();
                return true;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Resource.Mes_545 + " : \n\n" + exception.Message, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                FormCfg cfg = new FormCfg();
                cfg.ShowDialog();
                if (cfg.exit)
                {
                    Application.Exit();
                }
                else
                {
                    Application.Restart();
                }
                return false;
            }
        }

        public bool OpenNonSA()
        {
            string str = "WBNET";
            string str2 = "WBN3t!23456";
            string[] textArray1 = new string[9];
            textArray1[0] = "server=";
            textArray1[1] = sServer;
            textArray1[2] = "; database=";
            textArray1[3] = sDatabase;
            textArray1[4] = "; uid=";
            textArray1[5] = str;
            textArray1[6] = "; password=";
            textArray1[7] = str2;
            textArray1[8] = ";MultipleActiveResultSets=true;";
            ConnStr = string.Concat(textArray1);
            try
            {
                conn = new SqlConnection(ConnStr);
                conn.Open();
                sUserID = str;
                sPassword = str2;
                sUserID = str;
                sPassword = str2;
                WBConfigurationHandler.createDirectory();
                if (File.Exists(WBConfigurationHandler.configurationFile))
                {
                    Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                        { 
                            "USERID",
                            str.Trim()
                        },
                        { 
                            "PASSWORD",
                            str2.Trim()
                        }
                    };
                    WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                    dictToTxt.Clear();
                }
                else
                {
                    RegistryKey key2 = Registry.LocalMachine.OpenSubKey("SOFTWARE", true);
                    RegistryKey key3 = key2.OpenSubKey("WCS DATABASE");
                    RegistryKey key4 = key2.CreateSubKey("WCS DATABASE").CreateSubKey("WB System");
                    key4.SetValue("UserID", Program.shoot(str.Trim(), true), RegistryValueKind.String);
                    key4.SetValue("Password", Program.shoot(str2.Trim(), true), RegistryValueKind.String);
                    WBConfigurationHandler.createTxtFile(WBConfigurationHandler.configurationFile);
                    if (File.Exists(WBConfigurationHandler.configurationFile))
                    {
                        Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                            { 
                                "USERID",
                                str.Trim()
                            },
                            { 
                                "PASSWORD",
                                str2.Trim()
                            }
                        };
                        WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                        dictToTxt.Clear();
                    }
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool TestConnect()
        {
            string[] textArray1 = new string[9];
            textArray1[0] = "server=";
            textArray1[1] = sServer;
            textArray1[2] = "; database=";
            textArray1[3] = sDatabase;
            textArray1[4] = "; uid=";
            textArray1[5] = sUserID;
            textArray1[6] = "; password=";
            textArray1[7] = sPassword;
            textArray1[8] = ";";
            ConnStr = string.Concat(textArray1);
            try
            {
                conn = new SqlConnection(ConnStr);
                conn.Open();
                return true;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Resource.Mes_545 + "\n\n" + exception.Message, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return false;
            }
        }
    }
}

