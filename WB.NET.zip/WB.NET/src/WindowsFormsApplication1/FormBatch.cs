﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormBatch : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private IContainer components = null;
        public Panel panel1;
        private ProgressBar progressBar1;
        public TextBox TextFind;
        public Button buttonFind;
        private ToolStripMenuItem printToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem chooseToolStripMenuItem;
        public ToolStripMenuItem closeToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private DataGridView dataGridView1;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;

        public FormBatch()
        {
            this.InitializeComponent();
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormBatchEntry entry = new FormBatchEntry();
            this.ztable.BeforeEdit(this.dataGridView1, "ADD");
            entry.pMode = "ADD";
            entry.zTable = this.ztable;
            entry.Text = "Add New SOURCE";
            entry.dataGridView1 = this.dataGridView1;
            entry.ShowDialog();
            if (entry.saved)
            {
                this.ztable.ReOpen();
                this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                string[] aField = new string[] { "batch" };
                string[] aFind = new string[] { entry.textBatch.Text };
                this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
            }
            this.ztable.UnLock();
            entry.Dispose();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ztable.BeforeEdit(this.dataGridView1, "DELETE");
            this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { " and (( Batch_GI ='", this.ztable.DT.Rows[this.nCurrRow]["batch"].ToString(), "') or ( Batch_GR='", this.ztable.DT.Rows[this.nCurrRow]["batch"].ToString(), "'))" };
            table.OpenTable("wb_contract", "Select Do_No,uniq From wb_contract where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                if (MessageBox.Show(this.ztable.DT.Rows[this.nCurrRow]["Batch"].ToString() + ".\n\n Are you sure to deleted this record ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    FormTransCancel cancel = new FormTransCancel {
                        label1 = { Text = "Batch" },
                        textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Batch"].ToString() },
                        Text = "DELETE REASON",
                        label2 = { Text = "Delete Reason : " }
                    };
                    cancel.textReason.Focus();
                    cancel.ShowDialog();
                    if (cancel.Saved)
                    {
                        this.changeReason = cancel.textReason.Text;
                        cancel.Dispose();
                        this.ztable.ReOpen();
                        this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                        this.ztable.DT.Rows[this.nCurrRow].Delete();
                        this.ztable.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_batch", this.logKey, logField, logValue);
                        this.ztable.ReOpen();
                        this.ztable.AfterEdit("DELETE");
                    }
                    else
                    {
                        return;
                    }
                }
            }
            else
            {
                MessageBox.Show("This record cannot be deleted, still used in the Contract.\n ( " + table.DT.Rows.Count.ToString() + " records )", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            this.ztable.UnLock();
            table.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                FormBatchEntry entry = new FormBatchEntry();
                this.ztable.BeforeEdit(this.dataGridView1, "EDIT");
                entry.pMode = "EDIT";
                entry.zTable = this.ztable;
                entry.Text = "Edit Record of Batch";
                entry.dataGridView1 = this.dataGridView1;
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                }
                this.ztable.UnLock();
                entry.Dispose();
            }
        }

        private void FormBatch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormBatch_Load(object sender, EventArgs e)
        {
            string str = "Coy,Location_Code,batch, description, valueType, Trade, uniq";
            if (this.pFilter != "")
            {
                this.ztable.OpenTable("wb_Batch", "SELECT " + str + " FROM wb_Batch Where " + WBData.CompanyLocation(this.pFilter), WBData.conn);
            }
            else
            {
                this.ztable.OpenTable("wb_Batch", "SELECT " + str + " FROM wb_Batch", WBData.conn);
            }
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Batch"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["Trade"].Visible = false;
            base.KeyPreview = true;
            if (!WBUser.CheckTrustee("MD_BATCH", "A"))
            {
                this.addNewRecordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_BATCH", "E"))
            {
                this.editRecordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_BATCH", "D"))
            {
                this.deleteToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_BATCH", "P"))
            {
                this.printToolStripMenuItem.Enabled = false;
            }
            if ((this.pMode != "") && (this.pFind.Trim() != ""))
            {
                this.TextFind.Text = this.pFind;
                this.buttonFind.PerformClick();
            }
            this.chooseToolStripMenuItem.Visible = this.pMode != "";
        }

        private void InitializeComponent()
        {
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.printToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator1 = new ToolStripSeparator();
            this.chooseToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 220);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x192, 0x21);
            this.panel1.TabIndex = 14;
            this.progressBar1.Location = new Point(0x290, 9);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xa7, 0x11);
            this.progressBar1.TabIndex = 10;
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.printToolStripMenuItem.Text = "Print";
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new Size(160, 6);
            this.chooseToolStripMenuItem.Name = "chooseToolStripMenuItem";
            this.chooseToolStripMenuItem.Size = new Size(0x3b, 20);
            this.chooseToolStripMenuItem.Text = "Choose";
            this.chooseToolStripMenuItem.Click += new EventHandler(this.chooseToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x192, 0xe5);
            this.dataGridView1.TabIndex = 13;
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x192, 0x18);
            this.menuStrip1.TabIndex = 15;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem, this.printToolStripMenuItem, this.toolStripSeparator1 };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x192, 0xfd);
            base.ControlBox = false;
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Name = "FormBatch";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "FormBatch";
            base.Load += new EventHandler(this.FormBatch_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormBatch_KeyPress);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }
    }
}

