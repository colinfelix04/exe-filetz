﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormEntryFFB_main : Form
    {
        private DataTable tblTrans = new DataTable();
        private WBTable tblCommGrading = new WBTable();
        private WBTable tbl_trans = new WBTable();
        private WBTable saveToTrans = new WBTable();
        private string sql;
        private string logKey = "";
        private int[] net;
        public string date1 = "";
        public string ref_no = "";
        public string estate = "";
        public string relation = "";
        public string truck = "";
        private IContainer components = null;
        private MenuStrip menuStrip1;
        public ToolStripMenuItem menuSave;
        private ToolStripMenuItem menuExit;
        private DataGridView dgTrans;

        public FormEntryFFB_main()
        {
            this.InitializeComponent();
        }

        private void dgTrans_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dgvToTable(DataGridView aDgv, DataTable aTable)
        {
            try
            {
                aTable.Rows.Clear();
                foreach (DataGridViewRow row2 in (IEnumerable) aDgv.Rows)
                {
                    DataRow row = aTable.NewRow();
                    int num = 0;
                    while (true)
                    {
                        if (num >= aTable.Columns.Count)
                        {
                            aTable.Rows.Add(row);
                            break;
                        }
                        row[aTable.Columns[num].ColumnName] = row2.Cells[aTable.Columns[num].ColumnName].Value;
                        num++;
                    }
                }
            }
            catch
            {
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void formatDG(DataGridView zDgv, DataTable zTable)
        {
            int num2 = 9 + this.tblCommGrading.DT.Rows.Count;
            zTable.Columns.Clear();
            zDgv.Columns.Clear();
            for (int i = 0; i < num2; i++)
            {
                DataGridViewTextBoxColumn dataGridViewColumn = new DataGridViewTextBoxColumn();
                DataColumn column = new DataColumn();
                if (i == 0)
                {
                    dataGridViewColumn.Name = "Ref. Date";
                }
                else if (i == 1)
                {
                    dataGridViewColumn.Name = "Ref. No";
                }
                else if (i == 2)
                {
                    dataGridViewColumn.Name = "Estate";
                }
                else if (i == 3)
                {
                    dataGridViewColumn.Name = "Truck No";
                }
                else if (i == 4)
                {
                    dataGridViewColumn.Name = "Post Time";
                }
                else if (i == 5)
                {
                    dataGridViewColumn.Name = "Relation";
                }
                else if (i == 6)
                {
                    dataGridViewColumn.Name = "Bunches";
                }
                else if (i == 7)
                {
                    dataGridViewColumn.Name = "FFB Grade";
                }
                else if (i == 8)
                {
                    dataGridViewColumn.Name = "OER";
                }
                else
                {
                    dataGridViewColumn.Name = this.tblCommGrading.DT.Rows[i - 9]["Code"].ToString();
                    dataGridViewColumn.HeaderText = this.tblCommGrading.DT.Rows[i - 9]["Name"].ToString();
                }
                if (i >= 7)
                {
                    dataGridViewColumn.ReadOnly = !WBUser.CheckTrustee("TRANS", "E") && (dataGridViewColumn.Name == "FFB Grade");
                }
                else
                {
                    dataGridViewColumn.ReadOnly = true;
                    dataGridViewColumn.Frozen = true;
                }
                column.ColumnName = dataGridViewColumn.Name;
                zDgv.Columns.Add(dataGridViewColumn);
                zTable.Columns.Add(column);
            }
        }

        private void formatDGRow(DataGridView zDgv)
        {
            this.sql = "SELECT t.ref_date AS ref_date, t.ref AS ref, t.net as net, e.estate_name AS estate_name, ";
            this.sql = this.sql + " r.relation_name AS relation_name, t.ffb_grade AS ffb_grade, t.rend_CPO AS rend_CPO, ";
            this.sql = this.sql + " t.truck_number AS truck_number, t.time2 AS time2, t.TotalBunch AS TotalBunch";
            this.sql = this.sql + " FROM wb_transaction t, wb_contract c, wb_relation r, wb_estate e";
            this.sql = this.sql + " WHERE t.do_no = c.do_no ";
            this.sql = this.sql + " AND t.relation_code = r.relation_code ";
            this.sql = this.sql + " AND c.estate1_code = e.estate_code ";
            this.sql = this.sql + " AND t.coy = c.coy AND t.location_code = c.location_code ";
            this.sql = this.sql + " AND t.coy = r.coy AND t.location_code = r.location_code ";
            this.sql = this.sql + " AND t.coy = e.coy AND t.location_code = e.location_code ";
            this.sql = this.sql + " AND t.time2 is not null ";
            this.sql = this.sql + " AND t.coy = '" + WBData.sCoyCode.Trim() + "' ";
            this.sql = this.sql + " AND t.location_code = '" + WBData.sLocCode.Trim() + "' ";
            this.sql = this.sql + " AND t.comm_code = '6.0110000' ";
            this.sql = this.sql + " AND t.ref_date = '" + this.date1 + "' ";
            if (this.ref_no != "")
            {
                this.sql = this.sql + "AND t.ref = '" + this.ref_no + "' ";
            }
            if (this.estate != "")
            {
                this.sql = this.sql + "AND c.estate1_code = '" + this.estate + "' ";
            }
            if (this.relation != "")
            {
                this.sql = this.sql + "AND t.relation_code = '" + this.relation + "' ";
            }
            if (this.truck != "")
            {
                this.sql = this.sql + "AND t.truck_number = '" + this.truck + "' ";
            }
            this.sql = this.sql + " ORDER BY t.ref";
            this.tbl_trans.OpenTable("wb_transaction", this.sql, WBData.conn);
            int count = this.tbl_trans.DT.Rows.Count;
            this.net = new int[count];
            if (count <= 0)
            {
                Cursor.Current = Cursors.Default;
                MessageBox.Show("No data found");
            }
            else
            {
                zDgv.Rows.Clear();
                int index = 0;
                while (true)
                {
                    if (index >= count)
                    {
                        Cursor.Current = Cursors.Default;
                        break;
                    }
                    zDgv.Rows.Add();
                    this.tbl_trans.DR = this.tbl_trans.DT.Rows[index];
                    int num3 = zDgv.Rows.Count - 1;
                    zDgv.Rows[index].Cells["Ref. Date"].Value = this.tbl_trans.DR["ref_date"].ToString();
                    zDgv.Rows[index].Cells["Ref. No"].Value = this.tbl_trans.DR["ref"].ToString();
                    zDgv.Rows[index].Cells["Estate"].Value = this.tbl_trans.DR["estate_name"].ToString();
                    zDgv.Rows[index].Cells["Truck No"].Value = this.tbl_trans.DR["truck_number"].ToString();
                    zDgv.Rows[index].Cells["Post Time"].Value = this.tbl_trans.DR["time2"].ToString();
                    zDgv.Rows[index].Cells["Relation"].Value = this.tbl_trans.DR["relation_name"].ToString();
                    zDgv.Rows[index].Cells["Bunches"].Value = this.tbl_trans.DR["TotalBunch"].ToString();
                    zDgv.Rows[index].Cells["FFB Grade"].Value = this.tbl_trans.DR["ffb_grade"].ToString();
                    zDgv.Rows[index].Cells["OER"].Value = this.tbl_trans.DR["rend_CPO"].ToString();
                    this.net[index] = Convert.ToInt32(this.tbl_trans.DR["net"].ToString());
                    WBTable table = new WBTable();
                    table.OpenTable("wb_transactionD", "SELECT * FROM wb_transactionD WHERE ref ='" + this.tbl_trans.DR["ref"].ToString() + "'", WBData.conn);
                    int num4 = 0;
                    while (true)
                    {
                        if (num4 >= table.DT.Rows.Count)
                        {
                            table.Dispose();
                            index++;
                            break;
                        }
                        table.DR = table.DT.Rows[num4];
                        string str = table.DR["code"].ToString();
                        zDgv.Rows[index].Cells[str].Value = table.DR["PDeduc"].ToString();
                        num4++;
                    }
                }
            }
        }

        private void FormEntryFFB_main_Load(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.tblCommGrading.OpenTable("wb_commodity_grading", "SELECT * FROM wb_commodity_grading WHERE " + WBData.CompanyLocation(" AND comm_code = '6.0110000'"), WBData.conn);
            this.formatDG(this.dgTrans, this.tblTrans);
            this.formatDGRow(this.dgTrans);
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.menuStrip1 = new MenuStrip();
            this.menuSave = new ToolStripMenuItem();
            this.menuExit = new ToolStripMenuItem();
            this.dgTrans = new DataGridView();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dgTrans).BeginInit();
            base.SuspendLayout();
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.menuSave, this.menuExit };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x3bc, 0x18);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            this.menuSave.Name = "menuSave";
            this.menuSave.Size = new Size(0x2b, 20);
            this.menuSave.Text = "Save";
            this.menuSave.Click += new EventHandler(this.menuSave_Click);
            this.menuExit.Name = "menuExit";
            this.menuExit.Size = new Size(0x25, 20);
            this.menuExit.Text = "Exit";
            this.menuExit.Click += new EventHandler(this.menuExit_Click);
            this.dgTrans.AllowUserToAddRows = false;
            this.dgTrans.AllowUserToDeleteRows = false;
            this.dgTrans.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgTrans.ColumnHeadersDefaultCellStyle = style;
            this.dgTrans.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgTrans.DefaultCellStyle = style2;
            this.dgTrans.Dock = DockStyle.Fill;
            this.dgTrans.Location = new Point(0, 0x18);
            this.dgTrans.MultiSelect = false;
            this.dgTrans.Name = "dgTrans";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgTrans.RowHeadersDefaultCellStyle = style3;
            this.dgTrans.SelectionMode = DataGridViewSelectionMode.CellSelect;
            this.dgTrans.Size = new Size(0x3bc, 0x1c3);
            this.dgTrans.TabIndex = 8;
            this.dgTrans.CellContentClick += new DataGridViewCellEventHandler(this.dgTrans_CellContentClick);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x3bc, 0x1db);
            base.Controls.Add(this.dgTrans);
            base.Controls.Add(this.menuStrip1);
            base.Name = "FormEntryFFB_main";
            base.ShowIcon = false;
            this.Text = "Entry FFB Grading";
            base.WindowState = FormWindowState.Maximized;
            base.Load += new EventHandler(this.FormEntryFFB_main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dgTrans).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void menuExit_Click(object sender, EventArgs e)
        {
            base.Close();
            base.Dispose();
        }

        private void menuSave_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.dgvToTable(this.dgTrans, this.tblTrans);
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            int num = 0;
            while (true)
            {
                if (num >= this.tblTrans.Rows.Count)
                {
                    Cursor.Current = Cursors.Default;
                    MessageBox.Show("Saving process is finished", "Information");
                    return;
                }
                string str = this.tblTrans.Rows[num]["Ref. No"].ToString();
                table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                table.DR = table.DT.Rows[0];
                if ((table.DR["ffb_grade"].ToString() != this.tblTrans.Rows[num]["FFB Grade"].ToString()) || (table.DR["rend_CPO"].ToString() != this.tblTrans.Rows[num]["OER"].ToString()))
                {
                    table.DR.BeginEdit();
                    this.logKey = table.DR["uniq"].ToString();
                    table.DR["ffb_grade"] = this.tblTrans.Rows[num]["FFB Grade"].ToString();
                    table.DR["rend_CPO"] = this.tblTrans.Rows[num]["OER"].ToString();
                    table.DR["posted"] = "N";
                    table.DR["ChangeReason"] = "Entry FFB Grade / OER";
                    table.DR["checksum"] = table.Checksum(table.DR);
                    table.DR.EndEdit();
                    table.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Entry FFB Grading/OER" };
                    Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                }
                this.tblCommGrading.ReOpen();
                int count = this.tblCommGrading.DT.Rows.Count;
                bool flag = false;
                int num3 = 0;
                while (true)
                {
                    if (num3 >= count)
                    {
                        break;
                    }
                    this.tblCommGrading.DR = this.tblCommGrading.DT.Rows[num3];
                    string str2 = this.tblCommGrading.DR["code"].ToString();
                    string[] textArray3 = new string[] { "SELECT * FROM wb_transactionD WHERE ref = '", str, "' AND code = '", str2, "'" };
                    table2.OpenTable("wb_transactionD", string.Concat(textArray3), WBData.conn);
                    flag = false;
                    if (table2.DT.Rows.Count <= 0)
                    {
                        if ((this.tblTrans.Rows[num][str2].ToString() != "") && (this.tblTrans.Rows[num][str2].ToString() != "0"))
                        {
                            flag = true;
                            break;
                        }
                    }
                    else
                    {
                        table2.DR = table2.DT.Rows[0];
                        if (table2.DR["PDeduc"].ToString() != this.tblTrans.Rows[num][str2].ToString())
                        {
                            flag = true;
                            break;
                        }
                    }
                    num3++;
                }
                if (flag)
                {
                    int num4 = 0;
                    while (true)
                    {
                        if (num4 >= count)
                        {
                            break;
                        }
                        this.tblCommGrading.DR = this.tblCommGrading.DT.Rows[num4];
                        string str3 = this.tblCommGrading.DR["code"].ToString();
                        string[] textArray4 = new string[] { "SELECT * FROM wb_transactionD WHERE ref = '", str, "' AND code = '", str3, "'" };
                        table2.OpenTable("wb_transactionD", string.Concat(textArray4), WBData.conn);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            this.logKey = "";
                            if ((this.tblTrans.Rows[num][str3].ToString() != "") && (this.tblTrans.Rows[num][str3].ToString() != "0"))
                            {
                                table2.DR = table2.DT.NewRow();
                                table2.DR["Coy"] = WBData.sCoyCode;
                                table2.DR["Location_Code"] = WBData.sLocCode;
                                table2.DR["Ref"] = str;
                                table2.DR["Type"] = "F";
                                table2.DR["Deduc_By"] = this.tblCommGrading.DR["Deduc_By"].ToString();
                                table2.DR["Code"] = this.tblCommGrading.DR["Code"].ToString();
                                table2.DR["Name"] = this.tblCommGrading.DR["Name"].ToString();
                                table2.DR["Variable"] = this.tblCommGrading.DR["Variable"].ToString();
                                table2.DR["PDeduc"] = Convert.ToDouble(this.tblTrans.Rows[num][str3].ToString());
                                double num5 = Convert.ToDouble(this.tblTrans.Rows[num][str3].ToString());
                                table2.DR["KGDeduc"] = Math.Round((double) (Convert.ToDouble(table.DR["Received"].ToString()) * (num5 / 100.0)), 0).ToString();
                                table2.DR["Comm_Code"] = this.tblCommGrading.DR["Comm_Code"].ToString();
                                table2.DT.Rows.Add(table2.DR);
                                table2.Save();
                            }
                        }
                        else
                        {
                            table2.DR = table2.DT.Rows[0];
                            this.logKey = table2.DR["uniq"].ToString();
                            table2.DR.BeginEdit();
                            table2.DR["PDeduc"] = Convert.ToDouble(this.tblTrans.Rows[num][str3].ToString());
                            double num7 = Convert.ToDouble(this.tblTrans.Rows[num][str3].ToString());
                            table2.DR["KgDeduc"] = Math.Round((double) (Convert.ToDouble(table.DR["Received"].ToString()) * (num7 / 100.0)), 0).ToString();
                            table2.DR.EndEdit();
                            table2.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Entry FFB Grading/OER" };
                            Program.updateLogHeader("wb_transactionD", this.logKey, logField, logValue);
                            table.DR.BeginEdit();
                            this.logKey = table.DR["uniq"].ToString();
                            table.DR["posted"] = "N";
                            table.DR["checksum"] = table.Checksum(table.DR);
                            table.DR.EndEdit();
                            table.Save();
                            string[] textArray7 = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] textArray8 = new string[] { "EDIT", WBUser.UserID, "Entry FFB Grading/OER" };
                            Program.updateLogHeader("wb_transaction", this.logKey, textArray7, textArray8);
                        }
                        num4++;
                    }
                }
                num++;
            }
        }

        private void TransToLog(string pUniq, string pmode)
        {
            WBTable table = new WBTable();
            if (pUniq.Trim() != "")
            {
                table.OpenTable("wb_transaction", "Select * From wb_transaction where Uniq=" + pUniq.Trim(), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_trans_log", "Select * From wb_trans_log where 1=2", WBData.conn);
                    table2.DR = table2.DT.NewRow();
                    foreach (DataColumn column in table2.DT.Columns)
                    {
                        try
                        {
                            if (((column.ColumnName.ToUpper() != "UNIQ") && (column.ColumnName.ToUpper() != "LOG_DATE".ToUpper())) && (column.ColumnName.ToUpper() != "LOG_TIME".ToUpper()))
                            {
                                table2.DR[column.ColumnName] = table.DT.Rows[0][column.ColumnName];
                            }
                        }
                        catch
                        {
                        }
                    }
                    table2.DR["log_Date"] = DateTime.Now.Date;
                    table2.DR["log_time"] = DateTime.Now.ToString("HH:mm");
                    if (pmode == "EDIT")
                    {
                        table2.DR["Edit_By"] = WBUser.UserID;
                        table2.DR["Edit_Date"] = DateTime.Now;
                    }
                    else if (pmode == "PRINT")
                    {
                        table2.DR["Printed_By"] = WBUser.UserID.Trim();
                        table2.DR["Printed_Date"] = DateTime.Now;
                    }
                    table2.DT.Rows.Add(table2.DR);
                    table2.Save();
                    table2.Dispose();
                }
            }
            else
            {
                return;
            }
            table.Dispose();
        }
    }
}

