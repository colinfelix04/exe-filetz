﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormSourceEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public string OldCode;
        private IContainer components = null;
        public TextBox textSourceCode;
        private Label label1;
        private Button button2;
        private Button button1;
        private TextBox textDesc;
        private Label label2;
        public TextBox textStorage;
        private Label label3;
        private Label label4;
        private GroupBox groupBox1;
        private RadioButton radio2Step;
        private RadioButton radio1Step;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        public TextBox textSD;
        public TextBox textMM;
        public TextBox textGroup;
        public TextBox textEstate;
        private GroupBox groupBox2;
        private RadioButton radioOPF;
        private RadioButton radioPlasma;
        private RadioButton radioEstate;

        public FormSourceEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            TextBox[] aText = new TextBox[] { this.textSourceCode };
            if (!Program.CheckEmpty(aText))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_source", "Select Uniq From wb_source Where " + WBData.CompanyLocation(" and ( source_Code='" + this.textSourceCode.Text.Trim() + "')"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    Cursor.Current = Cursors.WaitCursor;
                    if ((this.pMode != "EDIT") || (this.textSourceCode.Text.Trim() == this.OldCode.Trim()))
                    {
                        goto TR_0016;
                    }
                    else
                    {
                        table2 = new WBTable();
                        table2.OpenTable("wb_transaction", "Select uniq From wb_transaction where " + WBData.CompanyLocation(" and ( source_Code='" + this.zTable.DT.Rows[this.nCurrRow]["source_Code"].ToString() + "')"), WBData.conn);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            goto TR_0017;
                        }
                        else
                        {
                            Cursor.Current = Cursors.Default;
                            string[] textArray1 = new string[13];
                            textArray1[0] = Resource.Mes_011;
                            textArray1[1] = " ";
                            textArray1[2] = this.OldCode;
                            textArray1[3] = " -> ";
                            textArray1[4] = this.textSourceCode.Text;
                            textArray1[5] = "\n\n";
                            textArray1[6] = Resource.Msg_Replace_Warning;
                            textArray1[7] = "  - ";
                            textArray1[8] = table2.DT.Rows.Count.ToString();
                            textArray1[9] = " ";
                            textArray1[10] = Resource.Mes_Records_In_Transactions;
                            textArray1[11] = "\n";
                            textArray1[12] = Resource.Msg_Continue;
                            if (MessageBox.Show(string.Concat(textArray1), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.ReplaceAll = true;
                                goto TR_0017;
                            }
                            else
                            {
                                this.ReplaceAll = false;
                                this.textSourceCode.Focus();
                            }
                        }
                    }
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_044, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textSourceCode.Focus();
                }
            }
            return;
        TR_0016:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.Source_014 },
                    textRefNo = { Text = this.textSourceCode.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["source_Code"] = this.textSourceCode.Text;
            this.zTable.DR["Description"] = this.textDesc.Text;
            this.zTable.DR["TP_Method"] = this.radio1Step.Checked ? "1" : (this.radio2Step.Checked ? "2" : "1");
            this.zTable.DR["Storage_loc"] = this.textStorage.Text;
            this.zTable.DR["Estate_type"] = this.radioEstate.Checked ? "0" : (this.radioPlasma.Checked ? "1" : (this.radioOPF.Checked ? "2" : "1"));
            this.zTable.DR["MoveTypeMM"] = this.textMM.Text;
            this.zTable.DR["MoveTypeSD"] = this.textSD.Text;
            this.zTable.DR["GroupName"] = this.textGroup.Text;
            this.zTable.DR["Estate"] = this.textEstate.Text;
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_source", "SELECT uniq FROM wb_source WHERE " + WBData.CompanyLocation(" AND source_code = '" + this.textSourceCode.Text + "'"), WBData.conn);
                    this.logKey = table3.DT.Rows[0]["uniq"].ToString();
                    table3.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_source", this.logKey, logField, logValue);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string[] aField = new string[] { "source_Code" };
                string[] aNewValue = new string[] { this.textSourceCode.Text };
                Program.ReplaceAll("wb_transaction", aField, aNewValue, " source_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit source/destination master data)");
            }
            this.saved = true;
            base.Close();
            Cursor.Current = Cursors.Default;
            return;
        TR_0017:
            table2.Dispose();
            goto TR_0016;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormSourceEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormSourceEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.pMode != "ADD")
            {
                this.textSourceCode.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Source_Code"].Value.ToString();
                this.OldCode = this.textSourceCode.Text;
                this.textDesc.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["DEscription"].Value.ToString();
                if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["TP_Method"].Value.ToString() == "1")
                {
                    this.radio1Step.Checked = true;
                }
                else if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["TP_Method"].Value.ToString() == "2")
                {
                    this.radio2Step.Checked = true;
                }
                else
                {
                    this.radio1Step.Checked = true;
                }
                this.textStorage.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Storage_loc"].Value.ToString();
                if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Estate_type"].Value.ToString() == "0")
                {
                    this.radioEstate.Checked = true;
                }
                else if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Estate_type"].Value.ToString() == "1")
                {
                    this.radioPlasma.Checked = true;
                }
                else if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Estate_type"].Value.ToString() == "2")
                {
                    this.radioOPF.Checked = true;
                }
                this.textMM.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["MoveTypeMM"].Value.ToString();
                this.textSD.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["MoveTYpeSD"].Value.ToString();
                this.textGroup.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["GroupName"].Value.ToString();
                this.textEstate.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Estate"].Value.ToString();
            }
        }

        private void InitializeComponent()
        {
            this.textSourceCode = new TextBox();
            this.label1 = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.textDesc = new TextBox();
            this.label2 = new Label();
            this.textStorage = new TextBox();
            this.label3 = new Label();
            this.label4 = new Label();
            this.groupBox1 = new GroupBox();
            this.radio2Step = new RadioButton();
            this.radio1Step = new RadioButton();
            this.label5 = new Label();
            this.label6 = new Label();
            this.label7 = new Label();
            this.label8 = new Label();
            this.textSD = new TextBox();
            this.textMM = new TextBox();
            this.textGroup = new TextBox();
            this.textEstate = new TextBox();
            this.groupBox2 = new GroupBox();
            this.radioOPF = new RadioButton();
            this.radioPlasma = new RadioButton();
            this.radioEstate = new RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            base.SuspendLayout();
            this.textSourceCode.CharacterCasing = CharacterCasing.Upper;
            this.textSourceCode.Location = new Point(0x94, 12);
            this.textSourceCode.Name = "textSourceCode";
            this.textSourceCode.Size = new Size(0xa5, 20);
            this.textSourceCode.TabIndex = 2;
            this.textSourceCode.KeyPress += new KeyPressEventHandler(this.textSourceCode_KeyPress);
            this.label1.Location = new Point(6, 15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x88, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Source/Destination Code";
            this.label1.TextAlign = ContentAlignment.TopRight;
            this.button2.Location = new Point(0x1b6, 0x10b);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x63, 30);
            this.button2.TabIndex = 14;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x14d, 0x10b);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x63, 30);
            this.button1.TabIndex = 13;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textDesc.Location = new Point(0x94, 0x26);
            this.textDesc.Name = "textDesc";
            this.textDesc.Size = new Size(0x185, 20);
            this.textDesc.TabIndex = 0x10;
            this.label2.Location = new Point(6, 0x29);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x88, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Description";
            this.label2.TextAlign = ContentAlignment.TopRight;
            this.textStorage.CharacterCasing = CharacterCasing.Upper;
            this.textStorage.Location = new Point(0x94, 0x40);
            this.textStorage.Name = "textStorage";
            this.textStorage.Size = new Size(0xa5, 20);
            this.textStorage.TabIndex = 0x12;
            this.textStorage.KeyPress += new KeyPressEventHandler(this.textStorage_KeyPress);
            this.label3.Location = new Point(6, 0x43);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x88, 13);
            this.label3.TabIndex = 0x11;
            this.label3.Text = "Storage Loc";
            this.label3.TextAlign = ContentAlignment.TopRight;
            this.label4.Location = new Point(6, 0x6a);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x88, 13);
            this.label4.TabIndex = 0x13;
            this.label4.Text = "TP Method";
            this.label4.TextAlign = ContentAlignment.TopRight;
            this.groupBox1.Controls.Add(this.radio2Step);
            this.groupBox1.Controls.Add(this.radio1Step);
            this.groupBox1.Location = new Point(0x94, 90);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0xa5, 60);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.radio2Step.AutoSize = true;
            this.radio2Step.Location = new Point(6, 0x25);
            this.radio2Step.Name = "radio2Step";
            this.radio2Step.Size = new Size(0x38, 0x11);
            this.radio2Step.TabIndex = 1;
            this.radio2Step.TabStop = true;
            this.radio2Step.Text = "2 Step";
            this.radio2Step.UseVisualStyleBackColor = true;
            this.radio2Step.CheckedChanged += new EventHandler(this.radioButton2_CheckedChanged);
            this.radio1Step.AutoSize = true;
            this.radio1Step.Checked = true;
            this.radio1Step.Location = new Point(6, 14);
            this.radio1Step.Name = "radio1Step";
            this.radio1Step.Size = new Size(0x38, 0x11);
            this.radio1Step.TabIndex = 0;
            this.radio1Step.TabStop = true;
            this.radio1Step.Text = "1 Step";
            this.radio1Step.UseVisualStyleBackColor = true;
            this.radio1Step.CheckedChanged += new EventHandler(this.radioButton1_CheckedChanged);
            this.label5.Location = new Point(6, 0xa5);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x88, 13);
            this.label5.TabIndex = 0x15;
            this.label5.Text = "Movement Type SD";
            this.label5.TextAlign = ContentAlignment.TopRight;
            this.label6.Location = new Point(6, 0xc5);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x88, 13);
            this.label6.TabIndex = 0x16;
            this.label6.Text = "Movement Type MM";
            this.label6.TextAlign = ContentAlignment.TopRight;
            this.label7.Location = new Point(6, 0xe2);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x88, 13);
            this.label7.TabIndex = 0x17;
            this.label7.Text = "Group";
            this.label7.TextAlign = ContentAlignment.TopRight;
            this.label8.Location = new Point(6, 0xfe);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x88, 13);
            this.label8.TabIndex = 0x18;
            this.label8.Text = "Estate";
            this.label8.TextAlign = ContentAlignment.TopRight;
            this.textSD.CharacterCasing = CharacterCasing.Upper;
            this.textSD.Location = new Point(0x94, 0xa2);
            this.textSD.Name = "textSD";
            this.textSD.Size = new Size(0xa5, 20);
            this.textSD.TabIndex = 0x19;
            this.textSD.KeyPress += new KeyPressEventHandler(this.textSD_KeyPress);
            this.textMM.CharacterCasing = CharacterCasing.Upper;
            this.textMM.Location = new Point(0x94, 0xc2);
            this.textMM.Name = "textMM";
            this.textMM.Size = new Size(0xa5, 20);
            this.textMM.TabIndex = 0x1a;
            this.textMM.KeyPress += new KeyPressEventHandler(this.textMM_KeyPress);
            this.textGroup.CharacterCasing = CharacterCasing.Upper;
            this.textGroup.Location = new Point(0x94, 0xdf);
            this.textGroup.Name = "textGroup";
            this.textGroup.Size = new Size(0xa5, 20);
            this.textGroup.TabIndex = 0x1b;
            this.textGroup.KeyPress += new KeyPressEventHandler(this.textGroup_KeyPress);
            this.textEstate.CharacterCasing = CharacterCasing.Upper;
            this.textEstate.Location = new Point(0x94, 0xfb);
            this.textEstate.Name = "textEstate";
            this.textEstate.Size = new Size(0xa5, 20);
            this.textEstate.TabIndex = 0x1c;
            this.textEstate.KeyPress += new KeyPressEventHandler(this.textEstate_KeyPress);
            this.groupBox2.Controls.Add(this.radioOPF);
            this.groupBox2.Controls.Add(this.radioPlasma);
            this.groupBox2.Controls.Add(this.radioEstate);
            this.groupBox2.Location = new Point(0x147, 90);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(210, 0x5c);
            this.groupBox2.TabIndex = 0x1d;
            this.groupBox2.TabStop = false;
            this.radioOPF.AutoSize = true;
            this.radioOPF.Location = new Point(6, 60);
            this.radioOPF.Name = "radioOPF";
            this.radioOPF.Size = new Size(0x2e, 0x11);
            this.radioOPF.TabIndex = 2;
            this.radioOPF.TabStop = true;
            this.radioOPF.Text = "OPF";
            this.radioOPF.UseVisualStyleBackColor = true;
            this.radioPlasma.AutoSize = true;
            this.radioPlasma.Location = new Point(6, 0x25);
            this.radioPlasma.Name = "radioPlasma";
            this.radioPlasma.Size = new Size(0x3b, 0x11);
            this.radioPlasma.TabIndex = 1;
            this.radioPlasma.TabStop = true;
            this.radioPlasma.Text = "Plasma";
            this.radioPlasma.UseVisualStyleBackColor = true;
            this.radioEstate.AutoSize = true;
            this.radioEstate.Checked = true;
            this.radioEstate.Location = new Point(6, 14);
            this.radioEstate.Name = "radioEstate";
            this.radioEstate.Size = new Size(0x37, 0x11);
            this.radioEstate.TabIndex = 0;
            this.radioEstate.TabStop = true;
            this.radioEstate.Text = "Estate";
            this.radioEstate.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x227, 0x135);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.textEstate);
            base.Controls.Add(this.textGroup);
            base.Controls.Add(this.textMM);
            base.Controls.Add(this.textSD);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textStorage);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textDesc);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textSourceCode);
            base.Controls.Add(this.label1);
            base.Name = "FormSourceEntry";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "FormSourceEntry";
            base.Load += new EventHandler(this.FormSourceEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormSourceEntry_KeyPress);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void textEstate_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textGroup_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textMM_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textSD_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textSourceCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textStorage_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.label2.Text = Resource.Source_002;
            this.label3.Text = Resource.Source_003;
            this.label4.Text = Resource.Source_004;
            this.label7.Text = Resource.Source_009;
            this.label5.Text = Resource.Source_010;
            this.label8.Text = Resource.Source_011;
            this.label6.Text = Resource.Source_012;
            this.label1.Text = Resource.Source_014;
            this.radio1Step.Text = Resource.Source_015;
            this.radio2Step.Text = Resource.Source_016;
            this.radioEstate.Text = Resource.Source_017;
            this.radioPlasma.Text = Resource.Source_018;
            this.radioOPF.Text = Resource.Source_019;
            this.button2.Text = Resource.Btn_Cancel;
            this.button1.Text = Resource.Btn_Save;
        }
    }
}

