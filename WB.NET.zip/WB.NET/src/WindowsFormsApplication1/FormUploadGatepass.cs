﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormUploadGatepass : Form
    {
        private DataTable tblGP = new DataTable();
        private DataTable tblGPItem = new DataTable();
        private DataTable tblGPTruck = new DataTable();
        private DataTable tblGPSIM = new DataTable();
        private DataTable tblGPCont = new DataTable();
        private DataTable retTable = new DataTable();
        private ExpressionVariabel owner = new ExpressionVariabel();
        private string[] retValue = new string[3];
        private string sapFunc;
        private string sapTable;
        private string sapReturn;
        private string sapType;
        private string zwbRef;
        private string zwbRefDo;
        public string tipeTrans = "";
        public string comm = "";
        public string Do_No = "";
        public string sapDest = "";
        public string transpt = "";
        public string logKey = "";
        public string module;
        public string type;
        public string sqlText;
        public string date1;
        public string date2;
        public DateTime dateFrom;
        public DateTime dateTo;
        private int rCount;
        private int jlhkolom;
        private int countRef = 0;
        public bool showAll;
        public bool locked = false;
        public bool cTrans = false;
        public char auto = 'N';
        private WBTable tbl_gatepass = new WBTable();
        private WBTable tbl_tmpGP = new WBTable();
        private WBTable tbl_tmpGPItem = new WBTable();
        private WBTable tbl_tmpGPTruck = new WBTable();
        private WBTable tbl_tmpGPCont = new WBTable();
        private WBTable tbl_tmpGPSIM = new WBTable();
        private WBTable aTable = new WBTable();
        private WBTable bTable = new WBTable();
        private IContainer components = null;
        private MenuStrip menuStrip1;
        public ToolStripMenuItem mnUpd;
        private ToolStripMenuItem excelToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private Panel panel1;
        private Panel panelMain;
        private DataGridView dgGatepass;
        private Button buttonUnSelect;
        private Button buttonSelectAll;
        private Label labelTotalRecord3;
        private Label labelTotalRecord2;
        private Label labelTotalRecord;
        private ProgressBar prgBar;
        private DataGridView dgGPTruck;
        private DataGridView dgGPCont;
        private DataGridView dgGPItem;
        private Panel panelDetail;
        private Panel panelCont;
        private Panel panelTruck;
        private Panel panelItem;
        private Panel panelSIM;
        private DataGridView dgGPSIM;

        public FormUploadGatepass()
        {
            this.InitializeComponent();
        }

        public void btnUpload()
        {
            bool flag = false;
            foreach (DataGridViewRow row in (IEnumerable) this.dgGatepass.Rows)
            {
                if (Convert.ToBoolean(row.Cells["select"].Value))
                {
                    flag = true;
                    break;
                }
            }
            if (!flag)
            {
                MessageBox.Show(Resource.Mes_440, Resource.Title_002);
            }
            if (flag)
            {
                this.uploadGP();
                WBSAP.SyncCommTrx();
            }
        }

        private void buttonSelectAll_Click(object sender, EventArgs e)
        {
            this.selectAll();
        }

        private void buttonUnSelect_Click(object sender, EventArgs e)
        {
            if (this.dgGatepass.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgGatepass.Rows)
                {
                    row.Cells["select"].Value = false;
                }
            }
        }

        private void chkPosted_CheckedChanged(object sender, EventArgs e)
        {
            this.tblGP.Rows.Clear();
            this.retTable.Rows.Clear();
            this.dgGatepass.Rows.Clear();
            this.dgGatepass.Refresh();
        }

        private void dgTrans_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int columnIndex = this.dgGatepass.CurrentCell.ColumnIndex;
            if (this.dgGatepass.Columns[columnIndex].Name.ToUpper() == "SELECT".ToUpper())
            {
                this.dgGatepass.CurrentCell.Value = !Convert.ToBoolean(this.dgGatepass.CurrentCell.Value);
            }
        }

        private void dgTrans_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            int columnIndex = this.dgGatepass.CurrentCell.ColumnIndex;
            if (this.dgGatepass.Columns[columnIndex].Name.ToUpper() == "SELECT".ToUpper())
            {
                this.dgGatepass.CurrentCell.Value = !Convert.ToBoolean(this.dgGatepass.CurrentCell.Value);
            }
        }

        private void dgTrans_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (this.dgGatepass.CurrentCell.ColumnIndex != 0)
            {
                this.ViewTimbang();
            }
        }

        private void dgvDetailToTable(DataGridView aDgv, DataTable mainTable, DataTable subTable, string key)
        {
            try
            {
                subTable.Rows.Clear();
                foreach (DataRow row2 in mainTable.Rows)
                {
                    string str = row2[key].ToString();
                    foreach (DataGridViewRow row3 in (IEnumerable) aDgv.Rows)
                    {
                        if (row3.Cells[key].Value.ToString() == str)
                        {
                            DataRow row = subTable.NewRow();
                            int num = 0;
                            while (true)
                            {
                                if (num >= subTable.Columns.Count)
                                {
                                    subTable.Rows.Add(row);
                                    break;
                                }
                                row[subTable.Columns[num].ColumnName] = row3.Cells[subTable.Columns[num].ColumnName].Value;
                                num++;
                            }
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void dgvToTable(DataGridView aDgv, DataTable aTable)
        {
            try
            {
                aTable.Rows.Clear();
                foreach (DataGridViewRow row2 in (IEnumerable) aDgv.Rows)
                {
                    if (Convert.ToBoolean(row2.Cells["select"].Value))
                    {
                        DataRow row = aTable.NewRow();
                        int num = 0;
                        while (true)
                        {
                            if (num >= aTable.Columns.Count)
                            {
                                aTable.Rows.Add(row);
                                break;
                            }
                            row[aTable.Columns[num].ColumnName] = row2.Cells[aTable.Columns[num].ColumnName].Value;
                            num++;
                        }
                    }
                }
            }
            catch
            {
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void excelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.dgGatepass.Rows.Count > 0)
                {
                    Program.export2Excel(this.dgGatepass, "", "", false);
                }
                if (WBUser.UserLevel == "1")
                {
                    if (this.dgGPItem.Rows.Count > 0)
                    {
                        Program.export2Excel(this.dgGPItem, "", "", false);
                    }
                    if (this.dgGPCont.Rows.Count > 0)
                    {
                        Program.export2Excel(this.dgGPCont, "", "", false);
                    }
                    if (this.dgGPTruck.Rows.Count > 0)
                    {
                        Program.export2Excel(this.dgGPTruck, "", "", false);
                    }
                }
            }
            catch
            {
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void f_load()
        {
            Cursor.Current = Cursors.WaitCursor;
            if (Convert.ToInt16(WBUser.UserLevel) > 2)
            {
                this.mnUpd.Enabled = false;
                this.excelToolStripMenuItem.Enabled = false;
                if (WBUser.CheckTrustee("MD_SYNCH", "A"))
                {
                    this.mnUpd.Enabled = true;
                    this.excelToolStripMenuItem.Enabled = true;
                }
            }
            this.initTable();
            Cursor.Current = Cursors.Default;
        }

        private void fillDG(DataGridView zDgv, DataTable zTable, WBTable ztemplate)
        {
            this.rCount = this.tbl_gatepass.DT.Rows.Count;
            this.prgBar.Maximum = this.rCount;
            this.prgBar.Value = 0;
            this.zwbRef = "";
            this.zwbRefDo = "";
            zDgv.Rows.Clear();
            for (int i = 0; i < this.rCount; i++)
            {
                zDgv.Rows.Add();
                this.tbl_gatepass.DR = this.tbl_gatepass.DT.Rows[i];
                int crRow = zDgv.Rows.Count - 1;
                if (this.fillDGRow(this.tbl_gatepass.DR, zDgv, crRow, ztemplate))
                {
                    this.prgBar.Value++;
                    this.labelTotalRecord2.Text = this.prgBar.Value.ToString();
                }
            }
        }

        private void fillDGItem(DataGridView zDgv, DataTable zTable, WBTable ztemplate)
        {
            this.rCount = this.tbl_gatepass.DT.Rows.Count;
            this.prgBar.Maximum = this.rCount;
            this.prgBar.Value = 0;
            this.zwbRef = "";
            this.zwbRefDo = "";
            zDgv.Rows.Clear();
            for (int i = 0; i < this.rCount; i++)
            {
                zDgv.Rows.Add();
                this.tbl_gatepass.DR = this.tbl_gatepass.DT.Rows[i];
                int crRow = zDgv.Rows.Count - 1;
                if (this.fillDGRowItem(this.tbl_gatepass.DR, zDgv, crRow, ztemplate))
                {
                    this.prgBar.Value++;
                    this.labelTotalRecord2.Text = this.prgBar.Value.ToString();
                }
            }
        }

        private bool fillDGRow(DataRow aRow, DataGridView fDgv, int crRow, WBTable zTemplate)
        {
            bool flag = false;
            string str = "";
            string str3 = "N";
            int index = 0;
            WBTable table = new WBTable();
            int count = zTemplate.DT.Rows.Count;
            this.jlhkolom = count;
            string[] values = new string[count];
            string str13 = "";
            string str11 = aRow["ref"].ToString();
            str3 = aRow["Posted"].ToString();
            int num4 = 0;
            while (true)
            {
                string str5;
                string str8;
                string str9;
                while (true)
                {
                    if (num4 >= count)
                    {
                        bool flag46;
                        fDgv.Rows[crRow].Cells["posted"].Value = str3;
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and Ref='" + aRow["ref"].ToString() + "'"), WBData.conn);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            this.locked = false;
                        }
                        else
                        {
                            table2.DR = table2.DT.Rows[0];
                            this.locked = table2.Locked(table2.DR["uniq"].ToString(), '0');
                        }
                        if ((this.type == "1") && (this.zwbRef.Trim() != aRow["ref"].ToString().Trim()))
                        {
                            this.zwbRef = aRow["ref"].ToString();
                        }
                        if (this.locked)
                        {
                            flag46 = false;
                        }
                        else
                        {
                            if (flag)
                            {
                                values[index] = str;
                                fDgv.Rows.Add(values);
                            }
                            flag46 = true;
                        }
                        return flag46;
                    }
                    zTemplate.DR = zTemplate.DT.Rows[num4];
                    string tablename = zTemplate.DR["table_name"].ToString();
                    str8 = zTemplate.DR["title_excel"].ToString();
                    string str6 = zTemplate.DR["Key_Field"].ToString();
                    string str7 = zTemplate.DR["Key_Field2"].ToString();
                    str5 = zTemplate.DR["Field_WB"].ToString();
                    str9 = zTemplate.DR["data_type"].ToString();
                    int num2 = Convert.ToInt16(zTemplate.DR["fixed"].ToString());
                    if (str8.ToUpper() == "ZWB_LOC".ToUpper())
                    {
                        index = num4;
                    }
                    if (num2 != 0)
                    {
                        values[num4] = zTemplate.DR["value"].ToString();
                    }
                    else if ((tablename.ToUpper() != "wb_gatepass".ToUpper()) && (tablename != ""))
                    {
                        try
                        {
                            string[] textArray1 = new string[] { " And ", str6, "= '", aRow[str7].ToString(), "' " };
                            table.OpenTable(tablename, ("select * from " + tablename + " where ") + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                            table.DR = table.DT.Rows[0];
                            values[num4] = table.DR[str5].ToString();
                        }
                        catch
                        {
                            values[num4] = "";
                        }
                        if (str8.ToUpper() == "Incoterm".ToUpper())
                        {
                            values[num4] = (values[num4] != "0") ? "LCO" : "FRC";
                        }
                        if ((str8.ToUpper() == "WJLHGONI".ToUpper()) && ((values[num4] == "0") && (Program.StrToDouble(aRow["TotalBunch"].ToString(), 0) > 0.0)))
                        {
                            values[num4] = aRow["totalbunch"].ToString();
                        }
                    }
                    else if (tablename.ToUpper() != "wb_gatepass".ToUpper())
                    {
                        try
                        {
                            values[num4] = aRow[str5].ToString();
                        }
                        catch
                        {
                            values[num4] = "";
                        }
                    }
                    else
                    {
                        try
                        {
                            values[num4] = aRow[str5].ToString();
                            if ((str5.ToUpper() == "Received".ToUpper()) | (str5.ToUpper() == "terima".ToUpper()))
                            {
                                values[num4] = Convert.ToString(Math.Abs((double) (Convert.ToDouble(values[num4 - 2]) - Convert.ToDouble(values[num4 - 1]))));
                            }
                            if ((str5.ToUpper() == "Deleted".ToUpper()) && (values[num4] == "Y"))
                            {
                                values[num4] = "1";
                            }
                            if (str5.ToUpper() == "IO".ToUpper())
                            {
                                values[num4] = (values[num4] != "I") ? "S" : "P";
                            }
                            if (str8.ToUpper() == "Reject".ToUpper())
                            {
                                values[num4] = (values[num4] != "Y") ? "" : "X";
                            }
                            if (str8.ToUpper() == "Complete".ToUpper())
                            {
                                values[num4] = (values[num4] != "") ? "X" : "";
                            }
                            if (str8.ToUpper() == "gp_purpose".ToUpper())
                            {
                                values[num4] = (values[num4] != "1") ? "GOING WITHOUT LOAD" : "LEAVING AFTER OFFLOAD";
                            }
                        }
                        catch
                        {
                            values[num4] = "";
                        }
                    }
                    break;
                }
                if (((str8 == "ZWB_LOC") || (str8 == "WLOKASI")) && (str13 != ""))
                {
                    values[num4] = str13;
                }
                if (str8.ToUpper() == "WUNIQ".ToUpper())
                {
                    if (this.zwbRefDo.Trim() == aRow["ref"].ToString().Trim())
                    {
                        this.countRef++;
                    }
                    else
                    {
                        this.countRef = 0;
                        this.zwbRefDo = aRow["ref"].ToString().Trim();
                    }
                    values[num4] = this.countRef.ToString().PadLeft(2, '0');
                }
                if ((str5.ToUpper() == "DO_NO") && (Program.getFieldValue("wb_Contract", "zAuto", "DO_NO", values[num4]) == "Y"))
                {
                    values[num4] = values[num4].Substring(0, values[num4].Length - 1);
                }
                if (values[num4] != "")
                {
                    if (str9.ToUpper() == "DATE".ToUpper())
                    {
                        try
                        {
                            DateTime time = Convert.ToDateTime(values[num4]);
                            values[num4] = time.ToString("yyyyMMdd");
                        }
                        catch
                        {
                            values[num4] = "00000000";
                        }
                    }
                    else if (str9.ToUpper() != "TIME".ToUpper())
                    {
                        if (str9.ToUpper() == "Formula".ToUpper())
                        {
                            double num5 = Convert.ToDouble(values[num4]);
                            this.owner.NET = num5;
                            num5 = Program.eval(zTemplate.DR["value"].ToString().Replace("VAL", values[num4]), this.owner);
                            values[num4] = (num5 >= 1.0) ? Convert.ToString(num5) : "";
                        }
                    }
                    else
                    {
                        try
                        {
                            values[num4] = Convert.ToDateTime(values[num4]).ToString("HH:mm:ss");
                            if (values[num4] == "00:00:00")
                            {
                                values[num4] = "00:01:00";
                            }
                        }
                        catch
                        {
                            values[num4] = "";
                        }
                    }
                }
                if (str9.ToUpper() != "Number".ToUpper())
                {
                    if (str9.ToUpper() == "Boolean".ToUpper())
                    {
                        values[num4] = (values[num4] != "Y") ? "" : "X";
                    }
                }
                else
                {
                    if (ReferenceEquals(values[num4], null))
                    {
                        values[num4] = "0";
                    }
                    if (values[num4].Trim() == "")
                    {
                        values[num4] = "0";
                    }
                }
                if (str8 != "")
                {
                    fDgv.Rows[crRow].Cells[str8].Value = values[num4];
                }
                num4++;
            }
        }

        private bool fillDGRowItem(DataRow aRow, DataGridView fDgv, int crRow, WBTable zTemplate)
        {
            int num3;
            string str = "N";
            WBTable table = new WBTable();
            int count = zTemplate.DT.Rows.Count;
            this.jlhkolom = count;
            string[] strArray = new string[count];
            str = aRow["Posted"].ToString();
            string str10 = "";
            string str11 = "";
            str10 = aRow["TA_Number"].ToString();
            str11 = aRow["Gatepass_number"].ToString();
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_TADetail", "Select * from wb_TADetail where TA_Number = '" + str10 + "'", WBData.conn);
            int num4 = 0;
        TR_002C:
            while (true)
            {
                if (num4 < table2.DT.Rows.Count)
                {
                    num3 = 0;
                    break;
                }
                table2.Dispose();
                return true;
            }
            while (true)
            {
                string str6;
                string str7;
                while (true)
                {
                    if (num3 < count)
                    {
                        zTemplate.DR = zTemplate.DT.Rows[num3];
                        string tablename = zTemplate.DR["table_name"].ToString();
                        str6 = zTemplate.DR["title_excel"].ToString();
                        string str4 = zTemplate.DR["Key_Field"].ToString();
                        string str5 = zTemplate.DR["Key_Field2"].ToString();
                        string str3 = zTemplate.DR["Field_WB"].ToString();
                        str7 = zTemplate.DR["data_type"].ToString();
                        int num2 = Convert.ToInt16(zTemplate.DR["fixed"].ToString());
                        if (num2 != 0)
                        {
                            strArray[num3] = zTemplate.DR["value"].ToString();
                        }
                        else if ((tablename.ToUpper() != "wb_TADetail".ToUpper()) && (tablename != ""))
                        {
                            try
                            {
                                string[] textArray1 = new string[] { " And ", str4, "= '", aRow[str5].ToString(), "' " };
                                table.OpenTable(tablename, ("select * from " + tablename + " where ") + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                                table.DR = table.DT.Rows[0];
                                strArray[num3] = table.DR[str3].ToString();
                            }
                            catch
                            {
                                strArray[num3] = "";
                            }
                        }
                        else
                        {
                            try
                            {
                                if (str6.ToUpper().Trim() != "NUMBERING")
                                {
                                    strArray[num3] = aRow[str3].ToString();
                                }
                                else if (str6.ToUpper().Trim() == "NUMBERING")
                                {
                                    strArray[num3] = (num4 + 1).ToString().PadLeft(2, '0');
                                }
                            }
                            catch
                            {
                                strArray[num3] = "";
                            }
                        }
                    }
                    else
                    {
                        num4++;
                        goto TR_002C;
                    }
                    break;
                }
                if (strArray[num3] != "")
                {
                    if (str7.ToUpper() == "DATE".ToUpper())
                    {
                        try
                        {
                            DateTime time = Convert.ToDateTime(strArray[num3]);
                            strArray[num3] = time.ToString("yyyyMMdd");
                        }
                        catch
                        {
                            strArray[num3] = "00000000";
                        }
                    }
                    else if (str7.ToUpper() != "TIME".ToUpper())
                    {
                        if (str7.ToUpper() == "Formula".ToUpper())
                        {
                            double num6 = Convert.ToDouble(strArray[num3]);
                            this.owner.NET = num6;
                            num6 = Program.eval(zTemplate.DR["value"].ToString().Replace("VAL", strArray[num3]), this.owner);
                            strArray[num3] = (num6 >= 1.0) ? Convert.ToString(num6) : "";
                        }
                    }
                    else
                    {
                        try
                        {
                            strArray[num3] = Convert.ToDateTime(strArray[num3]).ToString("HH:mm:ss");
                            if (strArray[num3] == "00:00:00")
                            {
                                strArray[num3] = "00:01:00";
                            }
                        }
                        catch
                        {
                            strArray[num3] = "";
                        }
                    }
                }
                if (str7.ToUpper() != "Number".ToUpper())
                {
                    if (str7.ToUpper() == "Boolean".ToUpper())
                    {
                        strArray[num3] = (strArray[num3] != "Y") ? "" : "X";
                    }
                }
                else
                {
                    if (ReferenceEquals(strArray[num3], null))
                    {
                        strArray[num3] = "0";
                    }
                    if (strArray[num3].Trim() == "")
                    {
                        strArray[num3] = "0";
                    }
                }
                if (str6 != "")
                {
                    fDgv.Rows[crRow].Cells[str6].Value = strArray[num3];
                }
                num3++;
            }
        }

        private void fillQC()
        {
            int num = 0;
            int crRow = 0;
            int count = 0;
            int num4 = 0;
            num4 = this.tblGPSIM.Columns.Count;
            string sqltext = "";
            string str2 = "";
            WBTable table = new WBTable();
            num = this.dgGatepass.Rows.Count;
            str2 = " Ref = '" + this.dgGatepass.Rows[0].Cells["Ref"].Value.ToString().Trim() + "'";
            int num5 = 0;
            while (true)
            {
                if (num5 >= num)
                {
                    sqltext = "Select * from wb_transQC where " + str2;
                    table.OpenTable("wb_transQC", sqltext, WBData.conn);
                    count = table.DT.Rows.Count;
                    if (count > 0)
                    {
                        this.dgGPCont.Rows.Add(count);
                    }
                    crRow = 0;
                    int num6 = 0;
                    while (num6 < num)
                    {
                        int num7 = 0;
                        while (true)
                        {
                            if (num7 >= count)
                            {
                                num6++;
                                break;
                            }
                            table.DR = table.DT.Rows[num7];
                            if (table.DR["Ref"].ToString() == this.dgGatepass.Rows[num6].Cells["Ref"].Value.ToString().Trim())
                            {
                                this.fillQCRow(table.DR, this.dgGatepass.Rows[num6].Cells["Zwb_Loc"].Value.ToString(), crRow);
                                crRow++;
                            }
                            num7++;
                        }
                    }
                    return;
                }
                str2 = str2 + " Or Ref = '" + this.dgGatepass.Rows[num5].Cells["Ref"].Value.ToString().Trim() + "'";
                num5++;
            }
        }

        private bool fillQCRow(DataRow zRowQC, string tolLoc, int crRow)
        {
            WBTable table = new WBTable();
            string str7 = zRowQC["ref"].ToString();
            int count = this.tbl_tmpGPTruck.DT.Rows.Count;
            string[] strArray = new string[count];
            int index = 0;
            while (true)
            {
                string str5;
                string str6;
                while (true)
                {
                    if (index >= count)
                    {
                        return true;
                    }
                    this.tbl_tmpGPTruck.DR = this.tbl_tmpGPTruck.DT.Rows[index];
                    string tablename = this.tbl_tmpGPTruck.DR["table_name"].ToString();
                    str6 = this.tbl_tmpGPTruck.DR["title_excel"].ToString();
                    string str3 = this.tbl_tmpGPTruck.DR["Key_Field"].ToString();
                    string str4 = this.tbl_tmpGPTruck.DR["Key_Field2"].ToString();
                    string str2 = this.tbl_tmpGPTruck.DR["Field_WB"].ToString();
                    str5 = this.tbl_tmpGPTruck.DR["data_type"].ToString();
                    int num2 = Convert.ToInt16(this.tbl_tmpGPTruck.DR["fixed"].ToString());
                    if (num2 != 0)
                    {
                        strArray[index] = this.tbl_tmpGPTruck.DR["value"].ToString();
                    }
                    else
                    {
                        try
                        {
                            if (tablename.Trim().ToUpper() == "wb_transQC".ToUpper())
                            {
                                strArray[index] = zRowQC[str2].ToString();
                            }
                            else
                            {
                                string[] textArray1 = new string[] { " AND ", str3, "= '", zRowQC[str4].ToString(), "' " };
                                table.OpenTable(tablename, ("select * from " + tablename + " where ") + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                                table.DR = table.DT.Rows[0];
                                strArray[index] = table.DR[str2].ToString();
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                    break;
                }
                if (str6.ToUpper() == "ZWB_LOC".ToUpper())
                {
                    strArray[index] = tolLoc;
                }
                if (strArray[index] != "")
                {
                    if (str5.ToUpper() == "DATE".ToUpper())
                    {
                        DateTime time = Convert.ToDateTime(strArray[index]);
                        strArray[index] = time.ToString("yyyyMMdd");
                    }
                    else if (str5.ToUpper() != "TIME".ToUpper())
                    {
                        if (str5.ToUpper() == "Boolean".ToUpper())
                        {
                            strArray[index] = (strArray[index] != "Y") ? "" : "X";
                        }
                    }
                    else
                    {
                        try
                        {
                            strArray[index] = Convert.ToDateTime(strArray[index]).ToString("HH:mm:ss");
                            if (strArray[index] == "00:00:00")
                            {
                                strArray[index] = "00:01:00";
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                }
                if ((str5.ToUpper() == "Number".ToUpper()) && ((strArray[index] == null) || (strArray[index].Trim() == "")))
                {
                    strArray[index] = "0";
                }
                if (str6 != "")
                {
                    this.dgGPCont.Rows[crRow].Cells[str6].Value = strArray[index];
                }
                index++;
            }
        }

        public void fillTable()
        {
            if (this.auto == 'N')
            {
                this.date1 = Program.DTOC(this.dateFrom) + " 00:00:00";
                this.date2 = Program.DTOC(this.dateTo) + " 00:00:00";
            }
            if (this.cTrans)
            {
                this.sqlText = "select * from wb_gatepass where " + WBData.CompanyLocation("");
                this.sqlText = this.sqlText + " and (posted is null or posted ='N') ";
                this.sqlText = this.sqlText + " and (approved = 'Y') ";
                this.sqlText = this.sqlText + " order by Gatepass_number";
            }
            else
            {
                if (this.auto != 'N')
                {
                    this.sqlText = "select * from wb_gatepass where " + WBData.CompanyLocation("");
                }
                else
                {
                    string[] textArray1 = new string[] { " and (in_date >= '", this.date1, "' and in_date <= '", this.date2, "')" };
                    this.sqlText = "select * from wb_gatepass where " + WBData.CompanyLocation(string.Concat(textArray1));
                }
                this.sqlText = this.sqlText + " and (approved = 'Y') ";
                if (this.auto == 'N')
                {
                    if (!this.showAll)
                    {
                        this.sqlText = this.sqlText + " and (posted is null or posted ='N') ";
                    }
                    if (this.comm.Length > 0)
                    {
                        this.sqlText = this.sqlText + " and (Comm_code = '" + this.comm + "') ";
                    }
                    if (this.transpt.Length > 0)
                    {
                        this.sqlText = this.sqlText + " and (Transporter_code = '" + this.comm + "') ";
                    }
                    if (this.Do_No.Length > 0)
                    {
                        this.sqlText = this.sqlText + " and (Do_No = '" + this.Do_No + "') ";
                    }
                }
                this.sqlText = this.sqlText + " order by Gatepass_Number";
            }
            this.tbl_gatepass.OpenTable("vw_trans", this.sqlText, WBData.conn);
            this.labelTotalRecord2.Text = this.tbl_gatepass.DT.Rows.Count.ToString();
            this.labelTotalRecord2.Refresh();
            if (this.tbl_gatepass.DT.Rows.Count > 0)
            {
                this.dgGatepass.Refresh();
                this.dgGPTruck.Refresh();
                this.dgGPItem.Refresh();
                this.dgGPCont.Refresh();
                this.type = "1";
                this.fillDG(this.dgGatepass, this.tblGP, this.tbl_tmpGP);
                this.type = "2";
                this.fillDGItem(this.dgGPItem, this.tblGPItem, this.tbl_tmpGPItem);
                this.type = "3";
                this.fillDG(this.dgGPTruck, this.tblGPTruck, this.tbl_tmpGPTruck);
                this.type = "4";
                this.fillDG(this.dgGPCont, this.tblGPCont, this.tbl_tmpGPCont);
                this.type = "5";
                this.fillDG(this.dgGPSIM, this.tblGPSIM, this.tbl_tmpGPSIM);
                this.setReturnTable();
                this.labelTotalRecord.Refresh();
                this.labelTotalRecord2.Refresh();
                this.labelTotalRecord3.Refresh();
                this.prgBar.Value = 0;
                if (this.auto != 'N')
                {
                    if (this.auto == 'Y')
                    {
                        this.buttonSelectAll.PerformClick();
                        this.mnUpd.PerformClick();
                    }
                }
                else if (this.dgGatepass.Rows.Count > 0)
                {
                    MessageBox.Show(Resource.Mes_436, Resource.Title_007);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_592, Resource.Title_007);
                }
            }
        }

        private void formatDG(DataGridView zDgv, DataTable zTable, WBTable zTemplate)
        {
            this.rCount = zTemplate.DT.Rows.Count;
            this.jlhkolom = this.rCount;
            zTable.Columns.Clear();
            zDgv.Columns.Clear();
            if (zDgv.Name.ToUpper().Trim() == "DGGATEPASS")
            {
                DataGridViewCheckBoxColumn dataGridViewColumn = new DataGridViewCheckBoxColumn {
                    Name = "Select",
                    HeaderText = "Select",
                    ReadOnly = true
                };
                zDgv.Columns.Add(dataGridViewColumn);
            }
            int num = 0;
            while (true)
            {
                DataGridViewTextBoxColumn column;
                if (num >= this.rCount)
                {
                    column = new DataGridViewTextBoxColumn {
                        Name = "Posted",
                        HeaderText = "Posted",
                        ReadOnly = true
                    };
                    zDgv.Columns.Add(column);
                    return;
                }
                zTemplate.DR = zTemplate.DT.Rows[num];
                column = new DataGridViewTextBoxColumn();
                DataColumn column3 = new DataColumn();
                bool flag2 = zTemplate.DR["Title_Excel"].ToString().Trim() != "";
                column.Name = !flag2 ? ("Column_" + num.ToString()) : zTemplate.DR["Title_Excel"].ToString().Trim();
                column.HeaderText = zTemplate.DR["Title_Excel"].ToString();
                column.ReadOnly = true;
                column3.ColumnName = column.Name;
                zDgv.Columns.Add(column);
                zTable.Columns.Add(column3);
                num++;
            }
        }

        private void FormUploadGatepass_Load(object sender, EventArgs e)
        {
            this.Refresh();
            this.panelDetail.Visible = WBUser.UserLevel == "1";
            this.f_load();
        }

        private WBTable getTemplate(string ztype)
        {
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { " AND modul = '", this.module, "'  and type ='", ztype, "' " };
            this.sqlText = "Select * from wb_templateSAP where " + WBData.CompanyLocation(string.Concat(textArray1)) + " order by column_Numbering";
            table.OpenTable("wb_templateSAP", this.sqlText, WBData.conn);
            return table;
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            DataGridViewCellStyle style4 = new DataGridViewCellStyle();
            DataGridViewCellStyle style5 = new DataGridViewCellStyle();
            DataGridViewCellStyle style6 = new DataGridViewCellStyle();
            DataGridViewCellStyle style7 = new DataGridViewCellStyle();
            DataGridViewCellStyle style8 = new DataGridViewCellStyle();
            DataGridViewCellStyle style9 = new DataGridViewCellStyle();
            DataGridViewCellStyle style10 = new DataGridViewCellStyle();
            DataGridViewCellStyle style11 = new DataGridViewCellStyle();
            DataGridViewCellStyle style12 = new DataGridViewCellStyle();
            this.menuStrip1 = new MenuStrip();
            this.mnUpd = new ToolStripMenuItem();
            this.excelToolStripMenuItem = new ToolStripMenuItem();
            this.exitToolStripMenuItem = new ToolStripMenuItem();
            this.panel1 = new Panel();
            this.buttonUnSelect = new Button();
            this.buttonSelectAll = new Button();
            this.labelTotalRecord3 = new Label();
            this.labelTotalRecord2 = new Label();
            this.labelTotalRecord = new Label();
            this.prgBar = new ProgressBar();
            this.panelMain = new Panel();
            this.dgGatepass = new DataGridView();
            this.dgGPTruck = new DataGridView();
            this.dgGPCont = new DataGridView();
            this.dgGPItem = new DataGridView();
            this.panelDetail = new Panel();
            this.panelSIM = new Panel();
            this.dgGPSIM = new DataGridView();
            this.panelCont = new Panel();
            this.panelTruck = new Panel();
            this.panelItem = new Panel();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelMain.SuspendLayout();
            ((ISupportInitialize) this.dgGatepass).BeginInit();
            ((ISupportInitialize) this.dgGPTruck).BeginInit();
            ((ISupportInitialize) this.dgGPCont).BeginInit();
            ((ISupportInitialize) this.dgGPItem).BeginInit();
            this.panelDetail.SuspendLayout();
            this.panelSIM.SuspendLayout();
            ((ISupportInitialize) this.dgGPSIM).BeginInit();
            this.panelCont.SuspendLayout();
            this.panelTruck.SuspendLayout();
            this.panelItem.SuspendLayout();
            base.SuspendLayout();
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.mnUpd, this.excelToolStripMenuItem, this.exitToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x3bc, 0x18);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            this.mnUpd.Name = "mnUpd";
            this.mnUpd.Size = new Size(0x39, 20);
            this.mnUpd.Text = "Upload";
            this.mnUpd.Click += new EventHandler(this.mnUpd_Click);
            this.excelToolStripMenuItem.Name = "excelToolStripMenuItem";
            this.excelToolStripMenuItem.Size = new Size(0x2d, 20);
            this.excelToolStripMenuItem.Text = "Excel";
            this.excelToolStripMenuItem.Click += new EventHandler(this.excelToolStripMenuItem_Click);
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new Size(0x25, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new EventHandler(this.exitToolStripMenuItem_Click);
            this.panel1.Controls.Add(this.buttonUnSelect);
            this.panel1.Controls.Add(this.buttonSelectAll);
            this.panel1.Controls.Add(this.labelTotalRecord3);
            this.panel1.Controls.Add(this.labelTotalRecord2);
            this.panel1.Controls.Add(this.labelTotalRecord);
            this.panel1.Controls.Add(this.prgBar);
            this.panel1.Dock = DockStyle.Top;
            this.panel1.Location = new Point(0, 0x18);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x3bc, 0x27);
            this.panel1.TabIndex = 6;
            this.buttonUnSelect.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.buttonUnSelect.Location = new Point(0x68, 6);
            this.buttonUnSelect.Name = "buttonUnSelect";
            this.buttonUnSelect.Size = new Size(0x4b, 0x17);
            this.buttonUnSelect.TabIndex = 0x15;
            this.buttonUnSelect.Text = "UnSelect All";
            this.buttonUnSelect.UseVisualStyleBackColor = true;
            this.buttonUnSelect.Click += new EventHandler(this.buttonUnSelect_Click);
            this.buttonSelectAll.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.buttonSelectAll.Location = new Point(12, 6);
            this.buttonSelectAll.Name = "buttonSelectAll";
            this.buttonSelectAll.Size = new Size(0x4b, 0x17);
            this.buttonSelectAll.TabIndex = 20;
            this.buttonSelectAll.Text = "Select All";
            this.buttonSelectAll.UseVisualStyleBackColor = true;
            this.buttonSelectAll.Click += new EventHandler(this.buttonSelectAll_Click);
            this.labelTotalRecord3.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.labelTotalRecord3.AutoSize = true;
            this.labelTotalRecord3.Location = new Point(0x381, 6);
            this.labelTotalRecord3.Name = "labelTotalRecord3";
            this.labelTotalRecord3.Size = new Size(0x2f, 13);
            this.labelTotalRecord3.TabIndex = 0x13;
            this.labelTotalRecord3.Text = "Records";
            this.labelTotalRecord3.TextAlign = ContentAlignment.MiddleRight;
            this.labelTotalRecord2.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.labelTotalRecord2.AutoSize = true;
            this.labelTotalRecord2.Location = new Point(0x331, 6);
            this.labelTotalRecord2.Name = "labelTotalRecord2";
            this.labelTotalRecord2.Size = new Size(13, 13);
            this.labelTotalRecord2.TabIndex = 0x12;
            this.labelTotalRecord2.Text = "0";
            this.labelTotalRecord.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.labelTotalRecord.AutoSize = true;
            this.labelTotalRecord.Location = new Point(730, 6);
            this.labelTotalRecord.Name = "labelTotalRecord";
            this.labelTotalRecord.Size = new Size(0x51, 13);
            this.labelTotalRecord.TabIndex = 0x11;
            this.labelTotalRecord.Text = "Total Record = ";
            this.prgBar.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.prgBar.Location = new Point(0x2dd, 0x16);
            this.prgBar.Name = "prgBar";
            this.prgBar.Size = new Size(0xd3, 11);
            this.prgBar.TabIndex = 0x10;
            this.panelMain.Controls.Add(this.dgGatepass);
            this.panelMain.Dock = DockStyle.Fill;
            this.panelMain.Location = new Point(0, 0x3f);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new Size(0x3bc, 0x138);
            this.panelMain.TabIndex = 7;
            this.dgGatepass.AllowUserToAddRows = false;
            this.dgGatepass.AllowUserToDeleteRows = false;
            this.dgGatepass.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgGatepass.ColumnHeadersDefaultCellStyle = style;
            this.dgGatepass.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgGatepass.DefaultCellStyle = style2;
            this.dgGatepass.Dock = DockStyle.Fill;
            this.dgGatepass.Location = new Point(0, 0);
            this.dgGatepass.MultiSelect = false;
            this.dgGatepass.Name = "dgGatepass";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgGatepass.RowHeadersDefaultCellStyle = style3;
            this.dgGatepass.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgGatepass.Size = new Size(0x3bc, 0x138);
            this.dgGatepass.TabIndex = 8;
            this.dgGatepass.CellClick += new DataGridViewCellEventHandler(this.dgTrans_CellClick_1);
            this.dgGatepass.CellDoubleClick += new DataGridViewCellEventHandler(this.dgTrans_CellDoubleClick);
            this.dgGPTruck.AllowUserToAddRows = false;
            this.dgGPTruck.AllowUserToDeleteRows = false;
            this.dgGPTruck.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgGPTruck.Dock = DockStyle.Fill;
            this.dgGPTruck.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgGPTruck.Location = new Point(0, 0);
            this.dgGPTruck.Name = "dgGPTruck";
            this.dgGPTruck.Size = new Size(0xdf, 100);
            this.dgGPTruck.TabIndex = 0x11;
            this.dgGPCont.AllowUserToAddRows = false;
            this.dgGPCont.AllowUserToDeleteRows = false;
            style4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style4.BackColor = SystemColors.Control;
            style4.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style4.ForeColor = SystemColors.WindowText;
            style4.SelectionBackColor = SystemColors.Highlight;
            style4.SelectionForeColor = SystemColors.HighlightText;
            style4.WrapMode = DataGridViewTriState.True;
            this.dgGPCont.ColumnHeadersDefaultCellStyle = style4;
            this.dgGPCont.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style5.BackColor = SystemColors.Window;
            style5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style5.ForeColor = SystemColors.ControlText;
            style5.SelectionBackColor = SystemColors.Highlight;
            style5.SelectionForeColor = SystemColors.HighlightText;
            style5.WrapMode = DataGridViewTriState.False;
            this.dgGPCont.DefaultCellStyle = style5;
            this.dgGPCont.Dock = DockStyle.Fill;
            this.dgGPCont.Location = new Point(0, 0);
            this.dgGPCont.Name = "dgGPCont";
            style6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style6.BackColor = SystemColors.Control;
            style6.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style6.ForeColor = SystemColors.WindowText;
            style6.SelectionBackColor = SystemColors.Highlight;
            style6.SelectionForeColor = SystemColors.HighlightText;
            style6.WrapMode = DataGridViewTriState.True;
            this.dgGPCont.RowHeadersDefaultCellStyle = style6;
            this.dgGPCont.Size = new Size(0x106, 100);
            this.dgGPCont.TabIndex = 0x10;
            this.dgGPItem.AllowUserToAddRows = false;
            this.dgGPItem.AllowUserToDeleteRows = false;
            style7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style7.BackColor = SystemColors.Control;
            style7.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style7.ForeColor = SystemColors.WindowText;
            style7.SelectionBackColor = SystemColors.Highlight;
            style7.SelectionForeColor = SystemColors.HighlightText;
            style7.WrapMode = DataGridViewTriState.True;
            this.dgGPItem.ColumnHeadersDefaultCellStyle = style7;
            this.dgGPItem.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style8.BackColor = SystemColors.Window;
            style8.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style8.ForeColor = SystemColors.ControlText;
            style8.SelectionBackColor = SystemColors.Highlight;
            style8.SelectionForeColor = SystemColors.HighlightText;
            style8.WrapMode = DataGridViewTriState.False;
            this.dgGPItem.DefaultCellStyle = style8;
            this.dgGPItem.Dock = DockStyle.Fill;
            this.dgGPItem.Location = new Point(0, 0);
            this.dgGPItem.Name = "dgGPItem";
            style9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style9.BackColor = SystemColors.Control;
            style9.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style9.ForeColor = SystemColors.WindowText;
            style9.SelectionBackColor = SystemColors.Highlight;
            style9.SelectionForeColor = SystemColors.HighlightText;
            style9.WrapMode = DataGridViewTriState.True;
            this.dgGPItem.RowHeadersDefaultCellStyle = style9;
            this.dgGPItem.Size = new Size(0xe3, 100);
            this.dgGPItem.TabIndex = 15;
            this.panelDetail.Controls.Add(this.panelSIM);
            this.panelDetail.Controls.Add(this.panelCont);
            this.panelDetail.Controls.Add(this.panelTruck);
            this.panelDetail.Controls.Add(this.panelItem);
            this.panelDetail.Dock = DockStyle.Bottom;
            this.panelDetail.Location = new Point(0, 0x177);
            this.panelDetail.Name = "panelDetail";
            this.panelDetail.Size = new Size(0x3bc, 100);
            this.panelDetail.TabIndex = 0x13;
            this.panelSIM.Controls.Add(this.dgGPSIM);
            this.panelSIM.Dock = DockStyle.Fill;
            this.panelSIM.Location = new Point(0x1e9, 0);
            this.panelSIM.Name = "panelSIM";
            this.panelSIM.Size = new Size(0xf4, 100);
            this.panelSIM.TabIndex = 3;
            this.dgGPSIM.AllowUserToAddRows = false;
            this.dgGPSIM.AllowUserToDeleteRows = false;
            style10.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style10.BackColor = SystemColors.Control;
            style10.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style10.ForeColor = SystemColors.WindowText;
            style10.SelectionBackColor = SystemColors.Highlight;
            style10.SelectionForeColor = SystemColors.HighlightText;
            style10.WrapMode = DataGridViewTriState.True;
            this.dgGPSIM.ColumnHeadersDefaultCellStyle = style10;
            this.dgGPSIM.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style11.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style11.BackColor = SystemColors.Window;
            style11.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style11.ForeColor = SystemColors.ControlText;
            style11.SelectionBackColor = SystemColors.Highlight;
            style11.SelectionForeColor = SystemColors.HighlightText;
            style11.WrapMode = DataGridViewTriState.False;
            this.dgGPSIM.DefaultCellStyle = style11;
            this.dgGPSIM.Dock = DockStyle.Fill;
            this.dgGPSIM.Location = new Point(0, 0);
            this.dgGPSIM.Name = "dgGPSIM";
            style12.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style12.BackColor = SystemColors.Control;
            style12.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style12.ForeColor = SystemColors.WindowText;
            style12.SelectionBackColor = SystemColors.Highlight;
            style12.SelectionForeColor = SystemColors.HighlightText;
            style12.WrapMode = DataGridViewTriState.True;
            this.dgGPSIM.RowHeadersDefaultCellStyle = style12;
            this.dgGPSIM.Size = new Size(0xf4, 100);
            this.dgGPSIM.TabIndex = 0x10;
            this.panelCont.Controls.Add(this.dgGPCont);
            this.panelCont.Dock = DockStyle.Left;
            this.panelCont.Location = new Point(0xe3, 0);
            this.panelCont.Name = "panelCont";
            this.panelCont.Size = new Size(0x106, 100);
            this.panelCont.TabIndex = 2;
            this.panelTruck.Controls.Add(this.dgGPTruck);
            this.panelTruck.Dock = DockStyle.Right;
            this.panelTruck.Location = new Point(0x2dd, 0);
            this.panelTruck.Name = "panelTruck";
            this.panelTruck.Size = new Size(0xdf, 100);
            this.panelTruck.TabIndex = 1;
            this.panelItem.Controls.Add(this.dgGPItem);
            this.panelItem.Dock = DockStyle.Left;
            this.panelItem.Location = new Point(0, 0);
            this.panelItem.Name = "panelItem";
            this.panelItem.Size = new Size(0xe3, 100);
            this.panelItem.TabIndex = 0;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x3bc, 0x1db);
            base.Controls.Add(this.panelMain);
            base.Controls.Add(this.panelDetail);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.Name = "FormUploadGatepass";
            base.ShowIcon = false;
            this.Text = "Form Upload Gatepass";
            base.WindowState = FormWindowState.Maximized;
            base.Load += new EventHandler(this.FormUploadGatepass_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelMain.ResumeLayout(false);
            ((ISupportInitialize) this.dgGatepass).EndInit();
            ((ISupportInitialize) this.dgGPTruck).EndInit();
            ((ISupportInitialize) this.dgGPCont).EndInit();
            ((ISupportInitialize) this.dgGPItem).EndInit();
            this.panelDetail.ResumeLayout(false);
            this.panelSIM.ResumeLayout(false);
            ((ISupportInitialize) this.dgGPSIM).EndInit();
            this.panelCont.ResumeLayout(false);
            this.panelTruck.ResumeLayout(false);
            this.panelItem.ResumeLayout(false);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        public void initTable()
        {
            this.module = this.sapDest;
            this.type = "1";
            this.tbl_tmpGP = this.getTemplate(this.type);
            this.formatDG(this.dgGatepass, this.tblGP, this.tbl_tmpGP);
            this.type = "2";
            this.tbl_tmpGPItem = this.getTemplate(this.type);
            this.formatDG(this.dgGPItem, this.tblGPItem, this.tbl_tmpGPItem);
            this.type = "3";
            this.tbl_tmpGPTruck = this.getTemplate(this.type);
            this.formatDG(this.dgGPTruck, this.tblGPTruck, this.tbl_tmpGPTruck);
            this.type = "4";
            this.tbl_tmpGPCont = this.getTemplate(this.type);
            this.formatDG(this.dgGPCont, this.tblGPCont, this.tbl_tmpGPCont);
            this.type = "5";
            this.tbl_tmpGPSIM = this.getTemplate(this.type);
            this.formatDG(this.dgGPSIM, this.tblGPSIM, this.tbl_tmpGPSIM);
            this.setReturnTable();
            this.fillTable();
            this.prgBar.Value = 0;
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void mnUpd_Click(object sender, EventArgs e)
        {
            this.btnUpload();
        }

        private void repostMutuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (WBSAP.connect())
            {
                try
                {
                    this.dgvToTable(this.dgGatepass, this.tblGP);
                    this.dgvDetailToTable(this.dgGPCont, this.tblGP, this.tblGPSIM, "REF");
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_TRX_QUALITY");
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD_Quality");
                    WBSAP.sendTable(this.tblGPSIM);
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                    WBSAP.sendTable(this.tblGP);
                    WBSAP.setImportReturn();
                    WBSAP.sendZWB();
                    string[] strArray = new string[3];
                    WBSAP.getAllResult(this.tblGP, this.retTable, "WREF");
                    WBSAP.showReturn();
                    WBTable table = new WBTable();
                    int num = 0;
                    while (true)
                    {
                        if (num >= this.retTable.Rows.Count)
                        {
                            table.Dispose();
                            break;
                        }
                        DataRow row = this.retTable.Rows[num];
                        string str = row[0].ToString().Trim();
                        if (row[1].ToString() == "Y")
                        {
                            table.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str + "'", WBData.conn);
                            table.DR = table.DT.Rows[0];
                            this.logKey = table.DR["uniq"].ToString();
                            table.DR.BeginEdit();
                            table.DR["posted"] = "Y";
                            table.DR["checksum"] = table.Checksum(table.DR);
                            table.DR.EndEdit();
                            table.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload Quality to SAP" };
                            Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                        }
                        num++;
                    }
                }
                catch (RfcInvalidParameterException exception)
                {
                    if (this.auto != 'Y')
                    {
                        MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (RfcCommunicationException exception2)
                {
                    if (this.auto != 'Y')
                    {
                        if (WBUser.UserLevel == "1")
                        {
                            MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                }
                catch (RfcBaseException exception3)
                {
                    if (this.auto != 'Y')
                    {
                        if (WBUser.UserLevel == "1")
                        {
                            MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                }
                catch (Exception exception4)
                {
                    if (this.auto != 'Y')
                    {
                        MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
        }

        public void selectAll()
        {
            if (this.dgGatepass.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgGatepass.Rows)
                {
                    row.Cells["select"].Value = true;
                }
            }
        }

        private void setReturnTable()
        {
            this.retTable.Columns.Clear();
            DataColumn column = new DataColumn {
                ColumnName = "GatepassNumber"
            };
            this.retTable.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "ReturnCode"
            };
            this.retTable.Columns.Add(column);
            column = new DataColumn {
                ColumnName = "Messages"
            };
            this.retTable.Columns.Add(column);
            column.Dispose();
        }

        private void uploadGP()
        {
            if (this.auto == 'Y')
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgGatepass.Rows)
                {
                    row.Cells["select"].Value = true;
                }
            }
            if (WBSAP.connect())
            {
                try
                {
                    this.dgvToTable(this.dgGatepass, this.tblGP);
                    this.dgvDetailToTable(this.dgGPItem, this.tblGP, this.tblGPItem, "contract");
                    this.dgvDetailToTable(this.dgGPTruck, this.tblGP, this.tblGPTruck, "truck_number");
                    this.dgvDetailToTable(this.dgGPCont, this.tblGP, this.tblGPCont, "Container_number");
                    this.dgvDetailToTable(this.dgGPSIM, this.tblGP, this.tblGPSIM, "license_no");
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_WB_GATEPASS");
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("WBGP");
                    WBSAP.sendTable(this.tblGP);
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("WBGP_ITEM");
                    WBSAP.sendTable(this.tblGPItem);
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("WBGP_TRUCK");
                    WBSAP.sendTable(this.tblGPTruck);
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("WBGP_CONT");
                    WBSAP.sendTable(this.tblGPCont);
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("WBGP_SIM");
                    WBSAP.sendTable(this.tblGPSIM);
                    WBSAP.sendZWB();
                    string[] strArray = new string[3];
                    this.sapReturn = "RTN_GP";
                    this.retTable.Rows.Clear();
                    IRfcTable table = WBSAP.rfcFunction.GetTable(this.sapReturn);
                    int num = 0;
                    while (true)
                    {
                        if (num >= table.RowCount)
                        {
                            if (this.auto != 'Y')
                            {
                                FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                    aTable = this.retTable
                                };
                                return2.ShowDialog();
                                return2.Dispose();
                            }
                            WBTable table2 = new WBTable();
                            bool flag3 = false;
                            int num2 = 0;
                            while (true)
                            {
                                if (num2 >= this.retTable.Rows.Count)
                                {
                                    table2.Dispose();
                                    if (flag3)
                                    {
                                        this.fillTable();
                                    }
                                    break;
                                }
                                DataRow row2 = this.retTable.Rows[num2];
                                string str = row2[0].ToString().Trim();
                                if (row2[1].ToString() == "0")
                                {
                                    flag3 = true;
                                    table2.OpenTable("wb_gatepass", "select * from wb_gatepass where gatepass_number ='" + str + "'", WBData.conn);
                                    table2.DR = table2.DT.Rows[0];
                                    this.logKey = table2.DR["uniq"].ToString();
                                    table2.DR.BeginEdit();
                                    table2.DR["posted"] = "Y";
                                    table2.DR.EndEdit();
                                    table2.Save();
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload gatepass to SAP" };
                                    Program.updateLogHeader("wb_gatepass", this.logKey, logField, logValue);
                                }
                                num2++;
                            }
                            break;
                        }
                        this.retValue[0] = table[num].GetString("DOCNO");
                        this.retValue[1] = table[num].GetString("SUBRC").ToString().Trim();
                        this.retValue[2] = table[num].GetString("MESSAGE");
                        this.retTable.Rows.Add(this.retValue);
                        num++;
                    }
                }
                catch (RfcInvalidParameterException exception)
                {
                    if (this.auto != 'Y')
                    {
                        MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (RfcCommunicationException exception2)
                {
                    if (this.auto != 'Y')
                    {
                        if (WBUser.UserLevel == "1")
                        {
                            MessageBox.Show(exception2.ToString(), Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                }
                catch (RfcBaseException exception3)
                {
                    if (this.auto != 'Y')
                    {
                        if (WBUser.UserLevel == "1")
                        {
                            MessageBox.Show(exception3.ToString(), Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                }
                catch (Exception exception4)
                {
                    if (this.auto != 'Y')
                    {
                        MessageBox.Show(Resource.Title_003 + "\n" + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
        }

        private void ViewTimbang()
        {
            try
            {
                WBTable table = new WBTable();
                string str4 = "REF";
                string zValue = this.dgGatepass.CurrentRow.Cells[str4].Value.ToString();
                table.OpenTable("wb_transaction", "select * from wb_transaction where uniq ='" + Program.getFieldValue("wb_transaction", "uniq", "Ref", zValue) + "'", WBData.conn);
                FormTransaction transaction = new FormTransaction {
                    tblTrans = table,
                    tambahRecord = false,
                    pMode = "VIEW"
                };
                transaction.ShowDialog();
                Cursor.Current = Cursors.Default;
                transaction.Dispose();
                table.Dispose();
            }
            catch
            {
            }
        }
    }
}

