﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Globalization;
    using System.IO;
    using System.Text;
    using System.Windows.Forms;

    public class RepMasterDataLog : Form
    {
        private int rowCount = 1;
        private WBTable getMasterData = new WBTable();
        private WBTable log = new WBTable();
        private WBTable getUser = new WBTable();
        private bool titleEditDetail;
        private bool titleDeleteDetail;
        public string flag = "MASTER_DATA";
        private IContainer components = null;
        public Label labelHeader;
        public Button buttonProcess;
        public Button buttonClose;
        public Label labelProses1;
        public Label labelProses2;
        public RadioButton radioMenu;
        public GroupBox groupBox3;
        public DateTimePicker monthCalendar1;
        public Label labelFromDate;
        public Label labelToDate;
        public DateTimePicker monthCalendar2;
        private Button buttonCode;
        public RadioButton radioCode;
        private TextBox textCode;
        public GroupBox groupBox1;
        public ComboBox comboMasterData;
        public Label labelMasterData;
        private Panel panel1;

        public RepMasterDataLog()
        {
            this.InitializeComponent();
        }

        private void bagSearchHelp()
        {
            FormBag bag = new FormBag {
                pMode = "CHOOSE"
            };
            bag.ShowDialog();
            if (bag.ReturnRow != null)
            {
                this.textCode.Text = bag.ReturnRow["Bag_Code"].ToString();
                this.textCode.Focus();
            }
            bag.Dispose();
        }

        private void batchSearchHelp()
        {
            FormBatch batch = new FormBatch {
                pMode = "CHOOSE"
            };
            batch.ShowDialog();
            if (batch.ReturnRow != null)
            {
                this.textCode.Text = batch.ReturnRow["Batch"].ToString();
                this.textCode.Focus();
            }
            batch.Dispose();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonCode_Click(object sender, EventArgs e)
        {
            if (this.comboMasterData.Text == "BAG")
            {
                this.bagSearchHelp();
            }
            else if (this.comboMasterData.Text == "BATCH")
            {
                this.batchSearchHelp();
            }
            else if (this.comboMasterData.Text == "CAMERA")
            {
                this.cameraSearchHelp();
            }
            else if (this.comboMasterData.Text == "COMMODITY")
            {
                this.commoditySearchHelp();
            }
            else if (this.comboMasterData.Text == "CONTAINER")
            {
                this.containerSearchHelp();
            }
            else if (this.comboMasterData.Text == "CONTRACT")
            {
                this.contractSearchHelp();
            }
            else if (this.comboMasterData.Text == "DRIVER")
            {
                this.driverSearchHelp();
            }
            else if (this.comboMasterData.Text == "EMAIL")
            {
                this.emailSearchHelp();
            }
            else if (this.comboMasterData.Text == "ESTATE")
            {
                this.estateSearchHelp();
            }
            else if (this.comboMasterData.Text == "GRADING")
            {
                this.gradingSearchHelp();
            }
            else if (this.comboMasterData.Text == "LOAD UNLOAD")
            {
                this.loadUnloadSearchHelp();
            }
            else if (this.comboMasterData.Text == "MILL")
            {
                this.millSearchHelp();
            }
            else if (this.comboMasterData.Text == "SOURCE")
            {
                this.sourceSearchHelp();
            }
            else if (this.comboMasterData.Text == "STORAGE")
            {
                this.storageSearchHelp();
            }
            else if (this.comboMasterData.Text == "TANKER")
            {
                this.tankerSearchHelp();
            }
            else if (this.comboMasterData.Text == "TRANSPORTER")
            {
                this.transporterSearchHelp();
            }
            else if (this.comboMasterData.Text == "TRANS TYPE")
            {
                this.transTypeSearchHelp();
            }
            else if (this.comboMasterData.Text == "TRUCK")
            {
                this.truckSearchHelp();
            }
            else if (this.comboMasterData.Text == "RELATION")
            {
                this.relationSearchHelp();
            }
            else if (this.comboMasterData.Text == "YIELD")
            {
                this.yieldSearchHelp();
            }
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.radioCode.Checked && (this.textCode.Text == ""))
            {
                MessageBox.Show("Please enter code!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.textCode.Focus();
            }
            else if (this.comboMasterData.Text == "")
            {
                MessageBox.Show("Please choose master data first!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.comboMasterData.Focus();
            }
            else if (Math.Abs((this.monthCalendar1.Value - this.monthCalendar2.Value).Days) > Math.Abs(90))
            {
                MessageBox.Show("Date interval must be less than 3 months", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                HTML html = new HTML();
                html = this.generateRep(this.radioMenu.Checked, this.monthCalendar1.Value, this.monthCalendar2.Value, this.textCode.Text, WBData.sCoyCode, WBData.sLocCode, "0");
                if (html != null)
                {
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + html.File) }
                    };
                    report.ShowDialog();
                    html.Dispose();
                    report.Dispose();
                }
                this.labelProses1.Text = "";
                this.labelProses1.Refresh();
                this.labelProses2.Text = "";
                this.labelProses2.Refresh();
            }
        }

        private void cameraSearchHelp()
        {
            FormCamera camera = new FormCamera {
                pMode = "CHOOSE"
            };
            camera.ShowDialog();
            if (camera.ReturnRow != null)
            {
                this.textCode.Text = camera.ReturnRow["Camera_Code"].ToString();
                this.textCode.Focus();
            }
            camera.Dispose();
        }

        private void comboMasterData_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.comboMasterData.Text != "")
            {
                this.panel1.Enabled = true;
                this.radioMenu.Checked = true;
                this.textCode.Text = "";
                if (((this.comboMasterData.Text != "BLOCK") && ((this.comboMasterData.Text != "COMPOSIT") && ((this.comboMasterData.Text != "DEDUCTED BY") && ((this.comboMasterData.Text != "DIVISION") && ((this.comboMasterData.Text != "REASON") && ((this.comboMasterData.Text != "SPB") && ((this.comboMasterData.Text != "VENDOR NEGO") && ((this.comboMasterData.Text != "SETTING") && ((this.comboMasterData.Text != "LOCATION") && ((this.comboMasterData.Text != "USER LIST") && ((this.comboMasterData.Text != "AUTHORIZATION") && (this.comboMasterData.Text != "TEMPLATE SAP")))))))))))) && (this.comboMasterData.Text != "DELIVERY NOTE"))
                {
                    this.radioCode.Enabled = true;
                }
                else
                {
                    this.radioCode.Enabled = false;
                    this.textCode.Enabled = false;
                    this.buttonCode.Enabled = false;
                }
                if (this.comboMasterData.Text == "GATEPASS")
                {
                    this.buttonCode.Enabled = false;
                }
                if (this.comboMasterData.Text == "BAG")
                {
                    this.useAutoComplete("wb_bag", "Bag_Code");
                }
                else if (this.comboMasterData.Text == "BATCH")
                {
                    this.useAutoComplete("wb_batch", "Batch");
                }
                else if (this.comboMasterData.Text == "CAMERA")
                {
                    this.useAutoComplete("wb_camera", "camera_code");
                }
                else if (this.comboMasterData.Text == "COMMODITY")
                {
                    this.useAutoComplete("wb_commodity", "comm_code");
                }
                else if (this.comboMasterData.Text == "CONTAINER")
                {
                    this.useAutoComplete("wb_container", "container_number");
                }
                else if (this.comboMasterData.Text == "CONTRACT")
                {
                    this.useAutoComplete("wb_contract", "do_no");
                }
                else if (this.comboMasterData.Text == "DRIVER")
                {
                    this.useAutoComplete("wb_driver", "license_no");
                }
                else if (this.comboMasterData.Text == "EMAIL")
                {
                    this.useAutoComplete("wb_email_master", "email_code");
                }
                else if (this.comboMasterData.Text == "ESTATE")
                {
                    this.useAutoComplete("wb_estate", "estate_code");
                }
                else if (this.comboMasterData.Text == "GATEPASS")
                {
                    this.useAutoComplete("wb_gatepass", "gatepass_number");
                }
                else if (this.comboMasterData.Text == "GRADING")
                {
                    this.useAutoComplete("wb_grading", "grading_code");
                }
                else if (this.comboMasterData.Text == "LOAD UNLOAD")
                {
                    this.useAutoComplete("wb_load_unload", "load_unload");
                }
                else if (this.comboMasterData.Text == "MILL")
                {
                    this.useAutoComplete("wb_mill", "mill_code");
                }
                else if (this.comboMasterData.Text == "SOURCE")
                {
                    this.useAutoComplete("wb_source", "source_code");
                }
                else if (this.comboMasterData.Text == "STORAGE")
                {
                    this.useAutoComplete("wb_storage", "storage_code");
                }
                else if (this.comboMasterData.Text == "TANKER")
                {
                    this.useAutoComplete("wb_tanker", "tanker_no");
                }
                else if (this.comboMasterData.Text == "TRANSPORTER")
                {
                    this.useAutoComplete("wb_transporter", "transporter_code");
                }
                else if (this.comboMasterData.Text == "TRANS TYPE")
                {
                    this.useAutoComplete("wb_transaction_type", "transaction_code");
                }
                else if (this.comboMasterData.Text == "TRUCK")
                {
                    this.useAutoComplete("wb_truck", "truck_number");
                }
                else if (this.comboMasterData.Text == "RELATION")
                {
                    this.useAutoComplete("wb_relation", "relation_code");
                }
                else if (this.comboMasterData.Text == "YIELD")
                {
                    this.useAutoComplete("wb_yield", "yield_code");
                }
            }
        }

        private void commoditySearchHelp()
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCode.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.textCode.Focus();
            }
            commodity.Dispose();
        }

        private void containerSearchHelp()
        {
            FormContainer container = new FormContainer {
                pMode = "CHOOSE"
            };
            container.ShowDialog();
            if (container.ReturnRow != null)
            {
                this.textCode.Text = container.ReturnRow["Container_Number"].ToString();
                this.textCode.Focus();
            }
            container.Dispose();
        }

        private void contractSearchHelp()
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE"
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textCode.Text = contract.ReturnRow["DO_No"].ToString();
                this.textCode.Focus();
            }
            contract.Dispose();
        }

        public void defineCombo()
        {
            if (this.flag == "MASTER_DATA")
            {
                string sqltext = "SELECT DISTINCT Type FROM wb_warning_trace WHERE " + WBData.CompanyLocation("AND Type NOT LIKE 'TRANSACTION%' AND Type != 'CONTROL' AND Type != 'BLOCK HEADER' AND Type != 'BLOCK DETAIL' AND Type != 'COMMODITY DETAIL' AND Type != 'COMMODITY GRADING' AND Type != 'CONTRACT DETAIL' AND Type != 'CONTRACT SAP INFORMATION' AND Type != 'CAMERA' AND Type != 'VENDOR NEGO' AND Type != 'GATEPASS' ORDER BY Type ");
                this.getMasterData.OpenTable("wb_warning_trace", sqltext, WBData.conn);
                foreach (DataRow row in this.getMasterData.DT.Rows)
                {
                    this.comboMasterData.Items.Add(row["Type"].ToString());
                }
                this.panel1.Enabled = false;
            }
            else
            {
                if (this.flag == "SETTING")
                {
                    this.comboMasterData.Items.Add("SETTING");
                }
                else if (this.flag == "LOCATION")
                {
                    this.comboMasterData.Items.Add("LOCATION");
                }
                else if (this.flag == "USER LIST")
                {
                    this.comboMasterData.Items.Add("USER LIST");
                }
                else if (this.flag == "AUTHORIZATION")
                {
                    this.comboMasterData.Items.Add("AUTHORIZATION");
                }
                else if (this.flag == "TEMPLATE SAP")
                {
                    this.comboMasterData.Items.Add("TEMPLATE SAP");
                }
                this.comboMasterData.SelectedIndex = 0;
                this.radioCode.Enabled = false;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void driverSearchHelp()
        {
            FormDriver driver = new FormDriver {
                pMode = "CHOOSE"
            };
            driver.ShowDialog();
            if (driver.ReturnRow != null)
            {
                this.textCode.Text = driver.ReturnRow["License_No"].ToString();
                this.textCode.Focus();
            }
            driver.Dispose();
        }

        private void emailSearchHelp()
        {
            FormEmail email = new FormEmail {
                pMode = "CHOOSE"
            };
            email.ShowDialog();
            if (email.ReturnRow != null)
            {
                this.textCode.Text = email.ReturnRow["Email_Code"].ToString();
                this.textCode.Focus();
            }
            email.Dispose();
        }

        private void estateSearchHelp()
        {
            FormEstate estate = new FormEstate {
                pMode = "CHOOSE"
            };
            estate.ShowDialog();
            if (estate.ReturnRow != null)
            {
                this.textCode.Text = estate.ReturnRow["Estate_Code"].ToString();
                this.textCode.Focus();
            }
            estate.Dispose();
        }

        private string fieldNameToTitle(string str)
        {
            char[] separator = new char[] { '_' };
            string[] strArray = str.Split(separator);
            string str2 = "";
            for (int i = 0; i < strArray.Length; i++)
            {
                str2 = str2 + strArray[i] + " ";
            }
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str2);
        }

        private string firstLetterToUpper(string reason)
        {
            string str = reason.ToLower();
            return ((str.Length <= 1) ? str : (char.ToUpper(str[0]).ToString() + str.Substring(1)));
        }

        public HTML generateRep(bool byDate, DateTime dateFrom, DateTime dateTo, string code, string coy, string loc, string zAuto)
        {
            HTML html3;
            string tableName = "";
            string[] tableCode = null;
            this.rowCount = 1;
            this.titleEditDetail = true;
            this.titleDeleteDetail = true;
            HTML rep = new HTML();
            string path = rep.File + @"\LogReport";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            HTML html2 = rep;
            string[] textArray1 = new string[] { html2.File, @"\LogReport\", coy, loc, "MASTERLOG_", dateFrom.ToString("ddMMyyyy"), ".htm" };
            html2.File = string.Concat(textArray1);
            if (((this.comboMasterData.Text == "SETTING") || ((this.comboMasterData.Text == "LOCATION") || ((this.comboMasterData.Text == "USER LIST") || (this.comboMasterData.Text == "AUTHORIZATION")))) || (this.comboMasterData.Text == "TEMPLATE SAP"))
            {
                rep.Title = "Log of " + CultureInfo.CurrentCulture.TextInfo.ToTitleCase(this.comboMasterData.Text.ToLower());
                rep.Open();
                rep.Write(rep.Style());
                rep.Write("<br><font size=5><b>LOG OF " + this.comboMasterData.Text + "</b></font><br>");
            }
            else
            {
                rep.Title = "Log of " + CultureInfo.CurrentCulture.TextInfo.ToTitleCase(this.comboMasterData.Text.ToLower()) + " Master Data";
                rep.Open();
                rep.Write(rep.Style());
                rep.Write("<br><font size=5><b>LOG OF " + this.comboMasterData.Text + " MASTER DATA</b></font><br>");
            }
            string[] textArray2 = new string[] { "<br><font size=4><b>", WBSetting.tblSetting.DR["Coy_Name"].ToString(), " (", coy, ")</b></font>" };
            rep.Write(string.Concat(textArray2));
            string[] textArray3 = new string[] { "<br><font size=4><b>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", loc, ")</b></font><br>" };
            rep.Write(string.Concat(textArray3));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            rep.Write("<br><br>");
            rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
            if (this.radioCode.Checked && (this.textCode.Text.Trim() != ""))
            {
                rep.Write("<tr class=bd>");
                rep.Write("<td>Code</td>");
                rep.Write("<td>: <b>" + this.textCode.Text + "</b></td>");
                rep.Write("</tr>");
            }
            else if (this.radioMenu.Checked)
            {
                rep.Write("<tr class=bd>");
                rep.Write("<td>Selected Date</td>");
                string[] textArray4 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                rep.Write(string.Concat(textArray4));
                rep.Write("</tr>");
            }
            rep.Write("<tr class=bd>");
            rep.Write("<td>Report Date</td>");
            rep.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
            rep.Write("</tr>");
            rep.Write("</table>");
            rep.Write("<br/><br/><br/>");
            string[] textArray5 = new string[] { "SELECT * FROM wb_user WHERE coy = '", coy, "' and location_code = '", loc, "'" };
            this.getUser.OpenTable("wb_user", string.Concat(textArray5), WBData.conn);
            if (this.comboMasterData.Text.Trim() == "BAG")
            {
                tableName = "wb_bag";
                tableCode = new string[] { "Bag_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "BATCH")
            {
                tableName = "wb_batch";
                tableCode = new string[] { "Batch" };
            }
            else if (this.comboMasterData.Text.Trim() == "BLOCK")
            {
                tableName = "wb_block";
                tableCode = new string[] { "Estate_Code", "Division_Code", "Block_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "CAMERA")
            {
                tableName = "wb_camera";
                tableCode = new string[] { "Camera_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "COMMODITY")
            {
                string[] textArray10 = new string[] { "Comm_Code" };
                this.log = this.openLogTableForUpdate(byDate, dateFrom, dateTo, code, coy, loc, "wb_commodity", textArray10, "EDIT");
                string[] textArray11 = new string[] { "Comm_Code" };
                this.templateForEdit(rep, this.log, "wb_commodity", textArray11, "EDIT MAIN INFORMATION", "");
                string[] textArray12 = new string[] { "Comm_Code", "QCode" };
                this.log = this.openLogTableForUpdate(byDate, dateFrom, dateTo, code, coy, loc, "wb_commodity_detail", textArray12, "EDIT");
                string[] textArray13 = new string[] { "Comm_Code", "QCode" };
                this.templateForEdit(rep, this.log, "wb_commodity_detail", textArray13, "EDIT DETAIL INFORMATION", "Edit Commodity Detail");
                string[] textArray14 = new string[] { "Comm_Code", "Code" };
                this.log = this.openLogTableForUpdate(byDate, dateFrom, dateTo, code, coy, loc, "wb_commodity_grading", textArray14, "EDIT");
                string[] textArray15 = new string[] { "Comm_Code", "Code" };
                this.templateForEdit(rep, this.log, "wb_commodity_grading", textArray15, "EDIT DETAIL INFORMATION", "Edit Commodity Grading");
                string[] textArray16 = new string[] { "Comm_Code" };
                string[] pMode = new string[] { "DELETE" };
                this.log = this.openLogTableForDelete(byDate, dateFrom, dateTo, code, coy, loc, "wb_commodity", textArray16, pMode);
                this.templateForDelete(rep, this.log, "wb_commodity", "DELETE MAIN INFORMATION", "");
                string[] textArray18 = new string[] { "Comm_Code", "QCode" };
                string[] textArray19 = new string[] { "EDIT", "DELETE" };
                this.log = this.openLogTableForDelete(byDate, dateFrom, dateTo, code, coy, loc, "wb_commodity_detail", textArray18, textArray19);
                this.templateForDelete(rep, this.log, "wb_commodity_detail", "DELETE DETAIL INFORMATION", "Delete Commodity Detail");
                string[] textArray20 = new string[] { "Comm_Code", "Code" };
                string[] textArray21 = new string[] { "EDIT", "DELETE" };
                this.log = this.openLogTableForDelete(byDate, dateFrom, dateTo, code, coy, loc, "wb_commodity_grading", textArray20, textArray21);
                this.templateForDelete(rep, this.log, "wb_commodity_grading", "DELETE DETAIL INFORMATION", "Delete Commodity Grading");
            }
            else if (this.comboMasterData.Text.Trim() == "COMPOSIT")
            {
                tableName = "wb_yieldComposit";
                tableCode = new string[] { "Relation_Code", "Estate_Code", "Comm_Code", "Yield_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "CONTAINER")
            {
                tableName = "wb_container";
                tableCode = new string[] { "Container_Number" };
            }
            else if (this.comboMasterData.Text.Trim() == "CONTRACT")
            {
                string[] textArray24 = new string[] { "DO_No" };
                this.log = this.openLogTableForUpdate(byDate, dateFrom, dateTo, code, coy, loc, "wb_contract", textArray24, "EDIT");
                string[] textArray25 = new string[] { "DO_No" };
                this.templateForEdit(rep, this.log, "wb_contract", textArray25, "EDIT MAIN INFORMATION", "");
                string[] textArray26 = new string[] { "DO_No", "SAP_Code" };
                this.log = this.openLogTableForUpdate(byDate, dateFrom, dateTo, code, coy, loc, "wb_contract_detail", textArray26, "EDIT");
                string[] textArray27 = new string[] { "DO_No", "SAP_Code" };
                this.templateForEdit(rep, this.log, "wb_contract_detail", textArray27, "EDIT DETAIL INFORMATION", "Edit Contract Detail");
                string[] textArray28 = new string[] { "DO_No", "so", "so_item" };
                this.log = this.openLogTableForUpdate(byDate, dateFrom, dateTo, code, coy, loc, "wb_contract_sapinformation", textArray28, "EDIT");
                string[] textArray29 = new string[] { "DO_No", "so", "so_item" };
                this.templateForEdit(rep, this.log, "wb_contract_sapinformation", textArray29, "EDIT DETAIL INFORMATION", "SO Item/Line");
                string[] textArray30 = new string[] { "DO_No" };
                string[] pMode = new string[] { "DELETE" };
                this.log = this.openLogTableForDelete(byDate, dateFrom, dateTo, code, coy, loc, "wb_contract", textArray30, pMode);
                this.templateForDelete(rep, this.log, "wb_contract", "DELETE MAIN INFORMATION", "");
                string[] textArray32 = new string[] { "DO_No", "so", "so_item" };
                string[] textArray33 = new string[] { "EDIT", "DELETE" };
                this.log = this.openLogTableForDelete(byDate, dateFrom, dateTo, code, coy, loc, "wb_contract_sapinformation", textArray32, textArray33);
                this.templateForDelete(rep, this.log, "wb_contract", "DELETE DETAIL INFORMATION", "SO Item/Line");
            }
            else if (this.comboMasterData.Text.Trim() == "DEDUCTED BY")
            {
                tableName = "wb_deductedBy";
                tableCode = new string[] { "Transaction_Code", "Incoterm_Code", "DeductedBY" };
            }
            else if (this.comboMasterData.Text.Trim() == "DIVISION")
            {
                tableName = "wb_division";
                tableCode = new string[] { "Estate_Code", "Division_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "DRIVER")
            {
                tableName = "wb_driver";
                tableCode = new string[] { "License_No" };
            }
            else if (this.comboMasterData.Text.Trim() == "EMAIL")
            {
                tableName = "wb_email_master";
                tableCode = new string[] { "Email_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "ESTATE")
            {
                tableName = "wb_estate";
                tableCode = new string[] { "Estate_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "GATEPASS")
            {
                tableName = "wb_gatepass";
                tableCode = new string[] { "TA_Number", "Gatepass_Number" };
            }
            else if (this.comboMasterData.Text.Trim() == "GRADING")
            {
                tableName = "wb_grading";
                tableCode = new string[] { "Grading_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "LOAD UNLOAD")
            {
                tableName = "wb_load_unload";
                tableCode = new string[] { "Load_Unload" };
            }
            else if (this.comboMasterData.Text.Trim() == "MILL")
            {
                tableName = "wb_mill";
                tableCode = new string[] { "Mill_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "REASON")
            {
                tableName = "wb_reason";
                tableCode = new string[] { "purpose", "reason" };
            }
            else if (this.comboMasterData.Text.Trim() == "RELATION")
            {
                tableName = "wb_relation";
                tableCode = new string[] { "Relation_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "SOURCE")
            {
                tableName = "wb_source";
                tableCode = new string[] { "Source_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "DELIVERY NOTE")
            {
                tableName = "wb_delivery_note";
                tableCode = new string[] { "relation_code", "Delivery_Note_From", "Delivery_Note_To" };
            }
            else if (this.comboMasterData.Text.Trim() == "STORAGE")
            {
                tableName = "wb_storage";
                tableCode = new string[] { "Storage_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "TANKER")
            {
                tableName = "wb_tanker";
                tableCode = new string[] { "Tanker_No" };
            }
            else if (this.comboMasterData.Text.Trim() == "TRANSPORTER")
            {
                tableName = "wb_transporter";
                tableCode = new string[] { "Transporter_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "TRANS TYPE")
            {
                tableName = "wb_transaction_type";
                tableCode = new string[] { "Transaction_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "TRUCK")
            {
                tableName = "wb_truck";
                tableCode = new string[] { "Truck_Number" };
            }
            else if (this.comboMasterData.Text.Trim() == "UPLOAD TYPE")
            {
                tableName = "wb_upload_type";
                tableCode = new string[] { "upload_type" };
            }
            else if (this.comboMasterData.Text.Trim() == "VENDOR NEGO")
            {
                tableName = "wb_relation_nego";
                tableCode = new string[] { "Relation_Code", "DateFrom", "DateTo" };
            }
            else if (this.comboMasterData.Text.Trim() == "YIELD")
            {
                tableName = "wb_yield";
                tableCode = new string[] { "Yield_Code" };
            }
            else if (this.comboMasterData.Text.Trim() == "SETTING")
            {
                tableName = "wb_setting";
                tableCode = new string[] { "wbcode", "compName" };
            }
            else if (this.comboMasterData.Text.Trim() == "LOCATION")
            {
                tableName = "wb_location";
                tableCode = new string[] { "coy", "location_code" };
            }
            else if (this.comboMasterData.Text.Trim() == "USER LIST")
            {
                tableName = "wb_user";
                tableCode = new string[] { "user_id" };
            }
            else if (this.comboMasterData.Text.Trim() == "AUTHORIZATION")
            {
                tableName = "wb_authorization";
                tableCode = new string[] { "autho_group", "autho_menu" };
            }
            else if (this.comboMasterData.Text.Trim() == "TEMPLATE SAP")
            {
                tableName = "wb_templateSAP";
                tableCode = new string[] { "modul" };
            }
            else if (this.comboMasterData.Text.Trim() == "SAP DESTINATION")
            {
                tableName = "wb_SAPDest";
                tableCode = new string[] { "SAPDest" };
            }
            if ((this.comboMasterData.Text.Trim() != "CONTRACT") && (this.comboMasterData.Text.Trim() != "COMMODITY"))
            {
                this.log = this.openLogTableForUpdate(byDate, dateFrom, dateTo, code, coy, loc, tableName, tableCode, "EDIT");
                this.templateForEdit(rep, this.log, tableName, tableCode, "EDIT MASTER DATA", "");
                if (this.comboMasterData.Text.Trim() == "GATEPASS")
                {
                    this.log = this.openLogTableForUpdate(byDate, dateFrom, dateTo, code, coy, loc, tableName, tableCode, "DELETE");
                    this.templateForDeleteGatepass(rep, this.log, "Delete", "DELETE MASTER DATA", tableName);
                }
                else
                {
                    string[] pMode = new string[] { "DELETE" };
                    this.log = this.openLogTableForDelete(byDate, dateFrom, dateTo, code, coy, loc, tableName, tableCode, pMode);
                    this.templateForDelete(rep, this.log, tableName, "DELETE MASTER DATA", "");
                }
            }
            if (this.rowCount <= 1)
            {
                if (zAuto != "1")
                {
                    MessageBox.Show("No records found!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                rep.Close();
                html3 = null;
            }
            else
            {
                rep.Write("<br>");
                rep.Write("<br>");
                rep.writeSign();
                rep.Close();
                this.log.Dispose();
                html3 = rep;
            }
            return html3;
        }

        private void gradingSearchHelp()
        {
            FormGrading grading = new FormGrading {
                pMode = "CHOOSE"
            };
            grading.ShowDialog();
            if (grading.ReturnRow != null)
            {
                this.textCode.Text = grading.ReturnRow["Grading_Code"].ToString();
                this.textCode.Focus();
            }
            grading.Dispose();
        }

        private void InitializeComponent()
        {
            this.labelHeader = new Label();
            this.buttonProcess = new Button();
            this.buttonClose = new Button();
            this.labelProses1 = new Label();
            this.labelProses2 = new Label();
            this.radioMenu = new RadioButton();
            this.groupBox3 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.labelFromDate = new Label();
            this.labelToDate = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.buttonCode = new Button();
            this.radioCode = new RadioButton();
            this.textCode = new TextBox();
            this.groupBox1 = new GroupBox();
            this.panel1 = new Panel();
            this.comboMasterData = new ComboBox();
            this.labelMasterData = new Label();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.labelHeader.AutoSize = true;
            this.labelHeader.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelHeader.Location = new Point(11, 12);
            this.labelHeader.Name = "labelHeader";
            this.labelHeader.Size = new Size(0xa4, 20);
            this.labelHeader.TabIndex = 0x57;
            this.labelHeader.Text = "Log of Master Data";
            this.labelHeader.TextAlign = ContentAlignment.TopCenter;
            this.buttonProcess.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonProcess.Location = new Point(0xe7, 0xed);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(110, 0x22);
            this.buttonProcess.TabIndex = 0x51;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.buttonClose.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonClose.Location = new Point(0x15b, 0xed);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new Size(110, 0x22);
            this.buttonClose.TabIndex = 0x52;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new EventHandler(this.buttonClose_Click);
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(0xf3, 12);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0xd3, 13);
            this.labelProses1.TabIndex = 0x56;
            this.labelProses1.Text = "1/88888";
            this.labelProses1.TextAlign = ContentAlignment.MiddleRight;
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(240, 0x19);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0xd6, 13);
            this.labelProses2.TabIndex = 0x55;
            this.labelProses2.Text = "Progress . . . . . . . . . . ";
            this.labelProses2.TextAlign = ContentAlignment.MiddleRight;
            this.radioMenu.AutoSize = true;
            this.radioMenu.Location = new Point(3, 3);
            this.radioMenu.Name = "radioMenu";
            this.radioMenu.Size = new Size(0x6d, 0x11);
            this.radioMenu.TabIndex = 0x59;
            this.radioMenu.Text = "Generate by Date";
            this.radioMenu.UseVisualStyleBackColor = true;
            this.radioMenu.CheckedChanged += new EventHandler(this.radioMenu_CheckedChanged);
            this.groupBox3.Controls.Add(this.monthCalendar1);
            this.groupBox3.Controls.Add(this.labelFromDate);
            this.groupBox3.Controls.Add(this.labelToDate);
            this.groupBox3.Controls.Add(this.monthCalendar2);
            this.groupBox3.Location = new Point(0x11, 20);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(0x187, 0x2c);
            this.groupBox3.TabIndex = 80;
            this.groupBox3.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x56, 15);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.labelFromDate.AutoSize = true;
            this.labelFromDate.Location = new Point(14, 0x12);
            this.labelFromDate.Name = "labelFromDate";
            this.labelFromDate.Size = new Size(0x3e, 13);
            this.labelFromDate.TabIndex = 3;
            this.labelFromDate.Text = "From Date :";
            this.labelToDate.AutoSize = true;
            this.labelToDate.Location = new Point(0xd3, 0x12);
            this.labelToDate.Name = "labelToDate";
            this.labelToDate.Size = new Size(0x34, 13);
            this.labelToDate.TabIndex = 4;
            this.labelToDate.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x10d, 15);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.buttonCode.Enabled = false;
            this.buttonCode.Location = new Point(0x117, 0x4f);
            this.buttonCode.Name = "buttonCode";
            this.buttonCode.Size = new Size(0x19, 0x17);
            this.buttonCode.TabIndex = 0x58;
            this.buttonCode.Text = "...";
            this.buttonCode.UseVisualStyleBackColor = true;
            this.buttonCode.Click += new EventHandler(this.buttonCode_Click);
            this.radioCode.AutoSize = true;
            this.radioCode.Location = new Point(3, 0x52);
            this.radioCode.Name = "radioCode";
            this.radioCode.Size = new Size(0x6f, 0x11);
            this.radioCode.TabIndex = 90;
            this.radioCode.Text = "Generate by Code";
            this.radioCode.UseVisualStyleBackColor = true;
            this.radioCode.CheckedChanged += new EventHandler(this.radioCode_CheckedChanged);
            this.textCode.Enabled = false;
            this.textCode.Location = new Point(0x7d, 0x51);
            this.textCode.Name = "textCode";
            this.textCode.Size = new Size(0x98, 20);
            this.textCode.TabIndex = 0x58;
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.comboMasterData);
            this.groupBox1.Controls.Add(this.labelMasterData);
            this.groupBox1.Location = new Point(15, 0x2c);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x1ba, 0xb0);
            this.groupBox1.TabIndex = 0x61;
            this.groupBox1.TabStop = false;
            this.panel1.Controls.Add(this.radioMenu);
            this.panel1.Controls.Add(this.radioCode);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.textCode);
            this.panel1.Controls.Add(this.buttonCode);
            this.panel1.Location = new Point(9, 0x39);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x1a1, 0x6d);
            this.panel1.TabIndex = 0x62;
            this.comboMasterData.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboMasterData.FormattingEnabled = true;
            this.comboMasterData.Location = new Point(0xae, 0x13);
            this.comboMasterData.Name = "comboMasterData";
            this.comboMasterData.Size = new Size(0x95, 0x15);
            this.comboMasterData.TabIndex = 0x61;
            this.comboMasterData.SelectedIndexChanged += new EventHandler(this.comboMasterData_SelectedIndexChanged);
            this.labelMasterData.AutoSize = true;
            this.labelMasterData.Location = new Point(0x58, 0x16);
            this.labelMasterData.Name = "labelMasterData";
            this.labelMasterData.Size = new Size(0x47, 13);
            this.labelMasterData.TabIndex = 0x58;
            this.labelMasterData.Text = "Master Data :";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1e1, 0x120);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.buttonClose);
            base.Controls.Add(this.buttonProcess);
            base.Controls.Add(this.labelHeader);
            base.KeyPreview = true;
            base.Name = "RepMasterDataLog";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Master Data Log Report";
            base.Load += new EventHandler(this.RepMasterDataLog_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void loadUnloadSearchHelp()
        {
            FormLoadUnload unload = new FormLoadUnload {
                pMode = "CHOOSE"
            };
            unload.ShowDialog();
            if (unload.ReturnRow != null)
            {
                this.textCode.Text = unload.ReturnRow["Load_Unload"].ToString();
                this.textCode.Focus();
            }
            unload.Dispose();
        }

        private void millSearchHelp()
        {
            FormMill mill = new FormMill {
                pMode = "CHOOSE"
            };
            mill.ShowDialog();
            if (mill.ReturnRow != null)
            {
                this.textCode.Text = mill.ReturnRow["Mill_Code"].ToString();
                this.textCode.Focus();
            }
            mill.Dispose();
        }

        private WBTable openLogTableForDelete(bool byDate, DateTime dateFrom, DateTime dateTo, string code, string coy, string loc, string tableName, string[] tableCode, string[] pMode)
        {
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "SELECT * FROM wb_log_header h, wb_log_detail d WHERE h.uniq = d.keyHeader  AND h.coy = '", coy, "'  AND h.location_code = '", loc, "' AND h.tableName = '", tableName, "'" };
            string sqltext = string.Concat(textArray1);
            if (byDate)
            {
                sqltext = (sqltext + " AND (substring(convert(varchar, h.logDate, 120), 0, 11)>='" + dateFrom.ToString("yyyy-MM-dd") + "'") + " AND substring(convert(varchar, h.logdate, 120), 0, 11)<='" + dateTo.ToString("yyyy-MM-dd") + "')";
            }
            sqltext = sqltext + " AND d.fieldName = '" + tableCode[0] + "' ";
            if (!byDate)
            {
                sqltext = sqltext + " AND d.oldValue = '" + code + "'";
            }
            sqltext = (sqltext + " AND h.Type = 'D' " + " AND h.PMode is not null ") + " AND h.UserID is not null " + " AND h.ChangeReason is not null ";
            int index = 0;
            while (true)
            {
                if (index >= pMode.Length)
                {
                    sqltext = sqltext + " )";
                    sqltext = !byDate ? (sqltext + " ORDER BY h.keyField, h.uniq ASC") : (sqltext + " ORDER BY h.logDate, h.keyField, h.uniq ASC");
                    table.OpenTable("wb_log_header", sqltext, WBData.conn);
                    return table;
                }
                bool flag3 = index == 0;
                sqltext = !flag3 ? (sqltext + " OR h.pMode = '" + pMode[index] + "' ") : (sqltext + " AND (h.pMode = '" + pMode[index] + "' ");
                index++;
            }
        }

        private WBTable openLogTableForUpdate(bool byDate, DateTime dateFrom, DateTime dateTo, string code, string coy, string loc, string tableName, string[] tableCode, string pMode)
        {
            string sqltext = "";
            WBTable table = new WBTable();
            if (tableName == "wb_delivery_note")
            {
                sqltext = sqltext + " SELECT * FROM wb_log_header with (nolock) WHERE tableName = '" + tableName + "'";
            }
            else
            {
                string[] textArray1 = new string[] { sqltext, " SELECT * FROM wb_log_header with (nolock) WHERE coy = '", coy, "'  AND location_code = '", loc, "' AND tableName = '", tableName, "'" };
                sqltext = string.Concat(textArray1);
            }
            if (byDate)
            {
                sqltext = (sqltext + " AND (substring(convert(varchar, logDate, 120), 0, 11)>='" + dateFrom.ToString("yyyy-MM-dd") + "'") + " AND substring(convert(varchar, logdate, 120), 0, 11)<='" + dateTo.ToString("yyyy-MM-dd") + "')";
            }
            else
            {
                WBTable table2 = new WBTable();
                string[] textArray2 = new string[] { " AND ", tableCode[0], " = '", code, "'" };
                table2.OpenTable(tableName, "SELECT * FROM " + tableName + " WHERE " + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
                if (table2.DT.Rows.Count <= 0)
                {
                    sqltext = sqltext + " AND keyField = ''";
                }
                else
                {
                    sqltext = sqltext + " AND (keyField = '" + table2.DT.Rows[0]["uniq"].ToString() + "' ";
                    int num = 1;
                    while (true)
                    {
                        if (num >= table2.DT.Rows.Count)
                        {
                            sqltext = sqltext + " ) ";
                            break;
                        }
                        sqltext = sqltext + " OR keyField = '" + table2.DT.Rows[num]["uniq"].ToString() + "' ";
                        num++;
                    }
                }
            }
            sqltext = ((sqltext + " AND Type = 'U' " + " AND PMode is not null ") + " AND UserID is not null " + " AND ChangeReason is not null ") + " AND pMode = '" + pMode + "' ";
            sqltext = !byDate ? (sqltext + " ORDER BY keyField, uniq ASC") : (sqltext + " ORDER BY logDate, keyField, uniq ASC");
            table.OpenTable("wb_log_header", sqltext, WBData.conn);
            return table;
        }

        private void radioCode_CheckedChanged(object sender, EventArgs e)
        {
            this.groupBox3.Enabled = false;
            this.textCode.Enabled = true;
            this.buttonCode.Enabled = true;
        }

        private void radioMenu_CheckedChanged(object sender, EventArgs e)
        {
            this.groupBox3.Enabled = true;
            this.textCode.Enabled = false;
            this.buttonCode.Enabled = false;
            this.textCode.Text = "";
        }

        private void relationSearchHelp()
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textCode.Text = vendor.ReturnRow["Relation_Code"].ToString();
                this.textCode.Focus();
            }
            vendor.Dispose();
        }

        private void RepMasterDataLog_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.labelProses1.Text = "";
            this.labelProses2.Text = "";
            this.defineCombo();
        }

        private void sourceSearchHelp()
        {
            FormSource source = new FormSource {
                pMode = "CHOOSE"
            };
            source.ShowDialog();
            if (source.ReturnRow != null)
            {
                this.textCode.Text = source.ReturnRow["Source_Code"].ToString();
                this.textCode.Focus();
            }
            source.Dispose();
        }

        private void storageSearchHelp()
        {
            FormStorage storage = new FormStorage {
                pMode = "CHOOSE"
            };
            storage.ShowDialog();
            if (storage.ReturnRow != null)
            {
                this.textCode.Text = storage.ReturnRow["Storage_Code"].ToString();
                this.textCode.Focus();
            }
            storage.Dispose();
        }

        private void tankerSearchHelp()
        {
            FormTanker tanker = new FormTanker {
                pMode = "CHOOSE"
            };
            tanker.ShowDialog();
            if (tanker.ReturnRow != null)
            {
                this.textCode.Text = tanker.ReturnRow["Tanker_No"].ToString();
                this.textCode.Focus();
            }
            tanker.Dispose();
        }

        private void templateForDelete(HTML rep, WBTable log, string tableName, string title, string subtitle)
        {
            if (log.DT.Rows.Count > 0)
            {
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                if (subtitle == "")
                {
                    rep.Write("<font size=3><b>" + title + "</b></font><br/><br/>");
                }
                else
                {
                    if (this.titleDeleteDetail)
                    {
                        rep.Write("<font size=3><b>" + title + "</b></font><br/><br/>");
                        this.titleDeleteDetail = false;
                    }
                    rep.Write("<font size=2><b>- " + subtitle + "</b></font><br/><br/>");
                }
                rep.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                rep.Write("<tr class=bd>");
                table2.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail WHERE keyHeader = '" + log.DT.Rows[0]["keyHeader"].ToString() + "'", WBData.conn);
                foreach (DataRow row in table2.DT.Rows)
                {
                    rep.Write("<th>" + this.fieldNameToTitle(row["fieldName"].ToString()) + "</th>");
                }
                rep.Write("<th>Reason</th>");
                rep.Write("<th nowrap>Delete By</th>");
                rep.Write("<th nowrap>Delete Date/Time</th>");
                rep.Write("</tr>");
                int num = 0;
                foreach (DataRow row2 in log.DT.Rows)
                {
                    this.labelProses1.Text = this.rowCount.ToString();
                    this.labelProses1.Refresh();
                    this.labelProses2.Text = row2["oldValue"].ToString();
                    this.labelProses2.Refresh();
                    rep.Write("<tr class=bd>");
                    table2.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail WHERE keyHeader = '" + log.DT.Rows[num]["keyHeader"].ToString() + "'", WBData.conn);
                    foreach (DataRow row4 in table2.DT.Rows)
                    {
                        rep.Write("<td>" + row4["oldValue"].ToString() + "</td>");
                    }
                    string str = row2["UserID"].ToString();
                    string[] aField = new string[] { "User_ID" };
                    string[] aFind = new string[] { str };
                    DataRow data = this.getUser.GetData(aField, aFind);
                    if (data != null)
                    {
                        str = data["User_name"].ToString();
                    }
                    rep.Write("<td>" + row2["changeReason"].ToString() + "</td>");
                    rep.Write("<td>" + CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str.ToLower()) + "</td>");
                    rep.Write("<td>" + row2["logDate"].ToString() + "</td>");
                    rep.Write("</tr>");
                    this.rowCount++;
                    num++;
                }
                rep.Write("</table>");
                rep.Write("<br/><br/><br/>");
                table.Dispose();
                table2.Dispose();
            }
        }

        private void templateForDeleteGatepass(HTML rep, WBTable log, string mode, string title, string tableName)
        {
            if (log.DT.Rows.Count > 0)
            {
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                rep.Write("<font size=3><b>" + title + "</b></font><br/><br/>");
                rep.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                rep.Write("<tr class=bd>");
                rep.Write("<th>TA No</th>");
                rep.Write("<th>Gatepass No</th>");
                rep.Write("<th>Reason</th>");
                rep.Write("<th nowrap>" + mode + " By</th>");
                rep.Write("<th nowrap>" + mode + " Date/Time</th>");
                rep.Write("</tr>");
                foreach (DataRow row in log.DT.Rows)
                {
                    string[] textArray1 = new string[] { "SELECT * FROM ", tableName, " WHERE uniq = '", row["keyField"].ToString(), "'" };
                    table.OpenTable(tableName, string.Concat(textArray1), WBData.conn);
                    string str = "??TA??";
                    string str2 = "??GP??";
                    if (table.DT.Rows.Count > 0)
                    {
                        str = table.DT.Rows[0]["TA_Number"].ToString();
                        str2 = table.DT.Rows[0]["Gatepass_Number"].ToString();
                    }
                    this.labelProses1.Text = this.rowCount.ToString();
                    this.labelProses1.Refresh();
                    this.labelProses2.Text = str;
                    this.labelProses2.Refresh();
                    string str3 = row["UserID"].ToString();
                    string[] aField = new string[] { "User_ID" };
                    string[] aFind = new string[] { str3 };
                    DataRow data = this.getUser.GetData(aField, aFind);
                    if (data != null)
                    {
                        str3 = data["User_name"].ToString();
                    }
                    rep.Write("<tr class=bd>");
                    rep.Write("<td>" + str + "</td>");
                    rep.Write("<td>" + str2 + "</td>");
                    rep.Write("<td>" + this.firstLetterToUpper(row["changeReason"].ToString()) + "</td>");
                    rep.Write("<td>" + CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str3.ToLower()) + "</td>");
                    rep.Write("<td>" + row["logDate"].ToString() + "</td>");
                    rep.Write("</tr>");
                    this.rowCount++;
                }
                rep.Write("</table>");
                rep.Write("<br/><br/><br/>");
                table.Dispose();
                table2.Dispose();
            }
        }

        private void templateForEdit(HTML rep, WBTable log, string tableName, string[] tableCode, string title, string subtitle)
        {
            if (log.DT.Rows.Count > 0)
            {
                DataRow data;
                StringBuilder builder = new StringBuilder();
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                WBTable table3 = new WBTable();
                bool flag2 = false;
                bool flag3 = false;
                table3.OpenTable("wb_warning_trace", "SELECT * FROM wb_warning_trace WHERE " + WBData.CompanyLocation(" AND (selected = 'Y' OR traceOnly = 'Y')  AND tableName = '" + tableName + "'"), WBData.conn);
                foreach (DataRow row2 in log.DT.Rows)
                {
                    table2.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail WHERE keyHeader = '" + row2["uniq"].ToString() + "'", WBData.conn);
                    foreach (DataRow row3 in table2.DT.Rows)
                    {
                        string[] aField = new string[] { "fieldName" };
                        string[] aFind = new string[] { row3["fieldName"].ToString() };
                        data = table3.GetData(aField, aFind);
                        if (data != null)
                        {
                            flag2 = true;
                            break;
                        }
                    }
                }
                foreach (DataRow row4 in log.DT.Rows)
                {
                    string[] textArray3 = new string[] { "SELECT * FROM ", tableName, " WHERE uniq = '", row4["keyField"].ToString(), "'" };
                    table2.OpenTable(tableName, string.Concat(textArray3), WBData.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        flag3 = true;
                        break;
                    }
                }
                if (flag2 & flag3)
                {
                    if (subtitle == "")
                    {
                        builder.Append("<font size=3><b>" + title + "</b></font><br/><br/>");
                    }
                    else
                    {
                        if (this.titleEditDetail)
                        {
                            builder.Append("<font size=3><b>" + title + "</b></font><br/><br/>");
                            this.titleEditDetail = false;
                        }
                        builder.Append("<font size=2><b>- " + subtitle + "</b></font><br/><br/>");
                    }
                    builder.Append("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                    builder.Append("<tr class=bd>");
                    int index = 0;
                    while (true)
                    {
                        if (index >= tableCode.Length)
                        {
                            builder.Append("<th>Change Field</th>");
                            builder.Append("<th>Before</th>");
                            builder.Append("<th>After</th>");
                            builder.Append("<th>Reason</th>");
                            builder.Append("<th nowrap>Change By</th>");
                            builder.Append("<th nowrap>Change Date/Time</th>");
                            builder.Append("</tr>");
                            bool flag7 = true;
                            foreach (DataRow row5 in log.DT.Rows)
                            {
                                string[] textArray4 = new string[] { "SELECT * FROM ", tableName, " WHERE uniq = '", row5["keyField"].ToString(), "'" };
                                table.OpenTable(tableName, string.Concat(textArray4), WBData.conn);
                                string[] strArray = new string[tableCode.Length];
                                if (table.DT.Rows.Count > 0)
                                {
                                    int num3 = 0;
                                    while (true)
                                    {
                                        if (num3 >= strArray.Length)
                                        {
                                            table2.OpenTable("wb_log_detail", "SELECT * FROM wb_log_detail WHERE keyHeader = '" + row5["uniq"].ToString() + "'", WBData.conn);
                                            int num2 = 0;
                                            bool flag12 = true;
                                            int num4 = 0;
                                            while (true)
                                            {
                                                if (num4 >= table2.DT.Rows.Count)
                                                {
                                                    builder.Replace("nSpan", num2);
                                                    break;
                                                }
                                                table2.DR = table2.DT.Rows[num4];
                                                string[] aField = new string[] { "fieldName" };
                                                string[] aFind = new string[] { table2.DR["fieldName"].ToString() };
                                                data = table3.GetData(aField, aFind);
                                                if (data != null)
                                                {
                                                    this.labelProses1.Text = this.rowCount.ToString();
                                                    this.labelProses1.Refresh();
                                                    this.labelProses2.Text = strArray[0];
                                                    this.labelProses2.Refresh();
                                                    if (table2.DR["oldValue"].ToString() != table2.DR["newValue"].ToString())
                                                    {
                                                        flag7 = false;
                                                        num2++;
                                                        if (!flag12)
                                                        {
                                                            builder.Append("<tr class=bd>");
                                                            builder.Append("<td>" + data["Name"].ToString() + "</td>");
                                                            builder.Append("<td>" + table2.DR["oldValue"].ToString() + "</td>");
                                                            builder.Append("<td>" + table2.DR["newValue"].ToString() + "</td>");
                                                            builder.Append("</tr>");
                                                        }
                                                        else
                                                        {
                                                            string str = row5["UserID"].ToString();
                                                            string[] textArray7 = new string[] { "User_ID" };
                                                            string[] textArray8 = new string[] { str };
                                                            DataRow data = this.getUser.GetData(textArray7, textArray8);
                                                            if (data != null)
                                                            {
                                                                str = data["User_name"].ToString();
                                                            }
                                                            builder.Append("<tr class=bd>");
                                                            int num5 = 0;
                                                            while (true)
                                                            {
                                                                if (num5 >= strArray.Length)
                                                                {
                                                                    builder.Append("<td>" + data["Name"].ToString() + "</td>");
                                                                    builder.Append("<td>" + table2.DR["oldValue"].ToString() + "</td>");
                                                                    builder.Append("<td>" + table2.DR["newValue"].ToString() + "</td>");
                                                                    builder.Append("<td rowspan=nSpan valign=top>" + row5["changeReason"].ToString() + "</td>");
                                                                    builder.Append("<td rowspan=nSpan valign=top>" + CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str.ToLower()) + "</td>");
                                                                    builder.Append("<td rowspan=nSpan valign=top nowrap>" + row5["logDate"].ToString() + "</td>");
                                                                    builder.Append("</tr>");
                                                                    flag12 = false;
                                                                    this.rowCount++;
                                                                    break;
                                                                }
                                                                builder.Append("<td rowspan=nSpan valign=top>" + strArray[num5] + "</td>");
                                                                num5++;
                                                            }
                                                        }
                                                    }
                                                }
                                                num4++;
                                            }
                                            break;
                                        }
                                        strArray[num3] = table.DT.Rows[0][tableCode[num3]].ToString();
                                        num3++;
                                    }
                                }
                            }
                            if (!flag7)
                            {
                                rep.Write(builder.ToString());
                                rep.Write("</table>");
                                rep.Write("<br/><br/><br/>");
                            }
                            break;
                        }
                        builder.Append("<th>" + this.fieldNameToTitle(tableCode[index]) + "</th>");
                        index++;
                    }
                }
                builder.Clear();
                table3.Dispose();
                table.Dispose();
                table2.Dispose();
            }
        }

        private void transporterSearchHelp()
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textCode.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.textCode.Focus();
            }
            transporter.Dispose();
        }

        private void transTypeSearchHelp()
        {
            FormTransType type = new FormTransType {
                pMode = "CHOOSE"
            };
            type.ShowDialog();
            if (type.ReturnRow != null)
            {
                this.textCode.Text = type.ReturnRow["Transaction_Code"].ToString();
                this.textCode.Focus();
            }
            type.Dispose();
        }

        private void truckSearchHelp()
        {
            FormTruck truck = new FormTruck {
                pMode = "CHOOSE"
            };
            truck.ShowDialog();
            if (truck.ReturnRow != null)
            {
                this.textCode.Text = truck.ReturnRow["Truck_Number"].ToString();
                this.textCode.Focus();
            }
            truck.Dispose();
        }

        private void useAutoComplete(string tableName, string code)
        {
            WBTable tbl = new WBTable();
            string[] textArray1 = new string[] { "Select ", code, " from ", tableName, " WHERE ", WBData.CompanyLocation("") };
            tbl.OpenTable(tableName, string.Concat(textArray1), WBData.conn);
            Program.AutoComp(tbl, code, this.textCode);
            tbl.Dispose();
        }

        private void yieldSearchHelp()
        {
            FormYield yield = new FormYield {
                pMode = "CHOOSE"
            };
            yield.ShowDialog();
            if (yield.ReturnRow != null)
            {
                this.textCode.Text = yield.ReturnRow["Yield_Code"].ToString();
                this.textCode.Focus();
            }
            yield.Dispose();
        }
    }
}

