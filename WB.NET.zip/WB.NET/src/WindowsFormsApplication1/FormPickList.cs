﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormPickList : Form
    {
        public WBTable tempTable;
        public string autoField;
        private IContainer components = null;
        private TextBox textInput;
        private Button button1;
        private Button button2;
        public DataGridView dgView;
        private Button button3;
        private DataGridViewTextBoxColumn Column1;

        public FormPickList()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textInput.Text.Trim() != "")
            {
                object[] values = new object[] { this.textInput.Text };
                this.dgView.Rows.Add(values);
                this.textInput.Clear();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.dgView.Rows.Count > 0)
            {
                int index = this.dgView.CurrentRow.Index;
                this.dgView.Rows.Remove(this.dgView.Rows[index]);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormPickList_Load(object sender, EventArgs e)
        {
            Program.AutoComp(this.tempTable, this.autoField, this.textInput);
        }

        private void InitializeComponent()
        {
            this.textInput = new TextBox();
            this.dgView = new DataGridView();
            this.button1 = new Button();
            this.button2 = new Button();
            this.button3 = new Button();
            this.Column1 = new DataGridViewTextBoxColumn();
            ((ISupportInitialize) this.dgView).BeginInit();
            base.SuspendLayout();
            this.textInput.Location = new Point(0x18, 0x15);
            this.textInput.Name = "textInput";
            this.textInput.Size = new Size(0x12b, 20);
            this.textInput.TabIndex = 0;
            this.dgView.AllowUserToAddRows = false;
            this.dgView.AllowUserToDeleteRows = false;
            this.dgView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridViewColumn[] dataGridViewColumns = new DataGridViewColumn[] { this.Column1 };
            this.dgView.Columns.AddRange(dataGridViewColumns);
            this.dgView.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgView.Location = new Point(0x18, 0x4b);
            this.dgView.Name = "dgView";
            this.dgView.Size = new Size(0x12b, 0xc0);
            this.dgView.TabIndex = 4;
            this.button1.Location = new Point(0x97, 0x2f);
            this.button1.Name = "button1";
            this.button1.Size = new Size(80, 0x17);
            this.button1.TabIndex = 1;
            this.button1.Text = "&Add Item";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0xed, 0x2e);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x56, 0x17);
            this.button2.TabIndex = 3;
            this.button2.Text = "&Delete Item";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button3.Location = new Point(0xed, 0x111);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x56, 0x17);
            this.button3.TabIndex = 2;
            this.button3.Text = "&OK";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.Column1.HeaderText = "List";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 0xe1;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(350, 0x134);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.dgView);
            base.Controls.Add(this.textInput);
            base.KeyPreview = true;
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormPickList";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Pick List";
            base.Load += new EventHandler(this.FormPickList_Load);
            ((ISupportInitialize) this.dgView).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

