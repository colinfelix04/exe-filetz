﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTransDOEntryAfrica : Form
    {
        public string oldComm;
        public string remark;
        public bool changeComm = false;
        public bool lSTO1DO = false;
        public string ISCC = "N";
        public string chkqty = "N";
        public string doEntryMode;
        public string pComm;
        public string pTransType;
        public string ptextNet;
        public string ptextEstate;
        public string oldDO_No;
        public string WX;
        public string RefNo;
        public string DoConvUnit;
        public string DoConv;
        public string DoConvTol;
        public string xEstQty;
        public string date1;
        public string CommType;
        public int dgvDOCurrRow;
        public bool saved = false;
        public bool ChangeDOCont;
        public DataGridView dgvTrans;
        public DataGridView dgvCont;
        public DataGridView dgvDoCont;
        public DataGridView dgvDO;
        public string nonContract = "N";
        public WBTable tblTransDO;
        public WBTable tblDOContainer;
        public WBTable tblStorage;
        public WBTable tblDO = new WBTable();
        public WBTable tblComm = new WBTable();
        public WBTable tblCust = new WBTable();
        public WBTable tblEstate = new WBTable();
        public string refDate = "";
        public double totalNet = 0.0;
        public double totalNetEstate = 0.0;
        public double totalVariance = 0.0;
        public double sisaNet = 0.0;
        public double sisaEstateNet = 0.0;
        public double qty;
        public double variance;
        public double DONet = 0.0;
        public double DOEstateNet = 0.0;
        public double OSNetwoTol = 0.0;
        public double OSNetTol;
        public string party = "0";
        public string tolerance = "0";
        public string qualityInfo = "";
        public string tolling = "";
        public string transType = "";
        public string deductedBy = "0";
        public string dIncoterm = "";
        private IContainer components = null;
        private Label label1;
        private Button buttonDO;
        private Label label3;
        private Label label4;
        private Label labelFactNet;
        private Label labelFactKg;
        private Button buttonSave;
        private Button button2;
        public TextBox textDO;
        public TextBox textCont;
        public TextBox textRCode;
        public TextBox textFactNet;
        public Label labelAgen;
        public TextBox textComm;
        private Label label7;
        private Label labelDOQtyLeft;
        public TextBox textEstate;
        private Label label9;
        public TextBox textConvNett;
        private Label label10;
        public Label labelConvUnit;
        public TextBox textPI_No;
        private Label labelPI_No;
        private Label labelTransporter;
        public TextBox textTransporter;
        private Button btnFillContainer;
        public Label labelKB;
        public TextBox textOthNet;
        private Label labelOthNet;
        private Label labelOthKg;
        private Label labelStorageName;
        private Button buttonStorage;
        private Label labelStorage;
        public TextBox textStorage;
        private Label label16;
        public TextBox text1DOSTO;
        private Label label14;
        public TextBox text1STO;
        private Label label15;
        private RectangleShape rectangleShape1;
        public Label label1STO1DO;
        private Label labelZWB;
        private Panel panelSTO1DO;
        private ShapeContainer shapeContainer2;
        private ToolTip toolTip1;
        public Label labelQuantity;
        public Label labelQtyLeft;
        public TextBox txtDeliveryNote;
        private Label labelDN;
        private Label labelCommName;
        private Button buttonComm;
        private Button buttonEstate;
        private Button buttonRName;
        public Label labelRName;
        public CheckBox checkNonContract;

        public FormTransDOEntryAfrica()
        {
            this.InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormTransDOContainer container = new FormTransDOContainer {
                zTable = this.tblDOContainer,
                qty = Convert.ToDouble(this.textFactNet.Text),
                dgvContainer = this.dgvCont,
                dgvDOCont = this.dgvDoCont,
                Do_No = this.textDO.Text,
                RefNo = this.RefNo,
                DoConv = this.DoConv,
                DoConvUnit = this.DoConvUnit
            };
            container.ShowDialog();
            if (!container.pSave)
            {
                this.ChangeDOCont = false;
            }
            else
            {
                this.dgvDoCont = container.dgvDoContAll;
                this.ChangeDOCont = true;
            }
            container.Dispose();
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE",
                pFind = this.textComm.Text
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textComm.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
                this.CommType = (commodity.ReturnRow["Type"].ToString().Trim() != "") ? commodity.ReturnRow["Type"].ToString().Trim() : "S";
                this.textComm.Focus();
            }
            commodity.Dispose();
        }

        private void buttonDO_Click(object sender, EventArgs e)
        {
            FormContractAfrica africa = new FormContractAfrica {
                pMode = "CHOOSE",
                pFind = this.textDO.Text.Trim()
            };
            africa.ShowDialog();
            if (africa.ReturnRow != null)
            {
                this.tblDO.ReOpen();
                if (!this.CheckPeriodDO(africa.ReturnRow, this.refDate))
                {
                    this.textDO.Text = africa.ReturnRow["Do_NO"].ToString();
                    this.SetorVar(africa.ReturnRow);
                    string[] aField = new string[] { "Comm_Code" };
                    string[] aFind = new string[] { this.textComm.Text.Trim() };
                    DataRow data = this.tblComm.GetData(aField, aFind);
                    this.CommType = data["Type"].ToString();
                    if (this.dgvDO.Rows.Count > 0)
                    {
                        if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                        {
                            this.txtDeliveryNote.Enabled = false;
                        }
                        else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                        {
                            this.txtDeliveryNote.Enabled = false;
                        }
                        else if ((this.CommType == "F") && !this.CheckSPB())
                        {
                            MessageBox.Show(Resource.Mes_277, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            this.txtDeliveryNote.Focus();
                        }
                    }
                }
                else
                {
                    string[] textArray1 = new string[] { africa.ReturnRow["DO_NO"].ToString(), " ", Resource.Mes_366, africa.ReturnRow["Do_Date2"].ToString().Substring(0, 10), "...!" };
                    MessageBox.Show(string.Concat(textArray1), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            africa.Dispose();
        }

        private void buttonEstate_Click(object sender, EventArgs e)
        {
            FormEstate estate = new FormEstate {
                pMode = "CHOOSE",
                pFind = this.textEstate.Text
            };
            estate.ShowDialog();
            if (estate.ReturnRow != null)
            {
                this.textEstate.Text = estate.ReturnRow["Estate_Code"].ToString();
                this.textEstate.Focus();
            }
            estate.Dispose();
        }

        private void buttonRName_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE",
                pFind = this.textRCode.Text
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textRCode.Text = vendor.ReturnRow["Relation_Code"].ToString();
                this.labelRName.Text = vendor.ReturnRow["Relation_Name"].ToString();
                this.textRCode.Focus();
            }
            vendor.Dispose();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (this.textDO.Text.Trim() != "")
            {
                if ((WBSetting.locType != "1") || !(((this.txtDeliveryNote.Text.Trim() == "") && this.txtDeliveryNote.Visible) && this.txtDeliveryNote.Enabled))
                {
                    this.changeComm = false;
                    if (((this.dgvDOCurrRow == 0) && (this.doEntryMode == "EDIT")) && (this.oldComm.Trim().ToUpper() != this.textComm.Text.Trim().ToUpper()))
                    {
                        string[] textArray1 = new string[] { Resource.Mes_352, " ", this.oldComm, " -> ", this.textComm.Text };
                        if (MessageBox.Show(string.Concat(textArray1), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                        {
                            this.saved = false;
                            return;
                        }
                        else
                        {
                            this.changeComm = true;
                        }
                    }
                    if ((WBSetting.locType == "0") && this.lSTO1DO)
                    {
                        TextBox[] aText = new TextBox[] { this.text1STO, this.text1DOSTO };
                        if (Program.CheckEmpty(aText))
                        {
                            return;
                        }
                    }
                    if ((this.dgvDO.Rows.Count <= 0) || (((this.doEntryMode != "ADD") && ((this.doEntryMode != "EDIT") || (this.dgvDO.CurrentRow.Index <= 0))) || ((this.textFactNet.Text.Trim() != "") && (this.textFactNet.Text.Trim() != "0"))))
                    {
                        if (this.checkNonContract.Checked)
                        {
                            this.checkDONonContract();
                            TextBox[] aText = new TextBox[] { this.textComm, this.textRCode, this.textEstate };
                            if (!Program.CheckEmpty(aText))
                            {
                                this.pComm = this.textComm.Text;
                                this.chkqty = "N";
                            }
                            else
                            {
                                return;
                            }
                        }
                        if ((this.chkqty == "Y") && (this.nonContract == "N"))
                        {
                            if (this.OSNetTol != 0.0)
                            {
                                if (this.deductedBy != "0")
                                {
                                    if ((this.deductedBy == "1") && (Program.StrToDouble(this.textOthNet.Text, 0) > this.OSNetTol))
                                    {
                                        MessageBox.Show(Resource.Mes_358, Resource.Title_002);
                                        return;
                                    }
                                }
                                else if (Program.StrToDouble(this.textFactNet.Text, 0) > this.OSNetTol)
                                {
                                    MessageBox.Show(Resource.Mes_359, Resource.Title_002);
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_355, Resource.Title_002);
                                return;
                            }
                        }
                        if ((this.dgvDO.Rows.Count > 0) && (Convert.ToDouble(this.textFactNet.Text) > this.sisaNet))
                        {
                            MessageBox.Show(Resource.Mes_365 + $"{this.sisaNet:N0}", Resource.Title_002);
                            this.textFactNet.Focus();
                            this.textFactNet.SelectAll();
                        }
                        else if ((this.sisaEstateNet <= 0.0) || (Convert.ToDouble(this.textOthNet.Text) <= this.sisaEstateNet))
                        {
                            this.saved = true;
                            base.Close();
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_364 + $"{this.sisaEstateNet:N0}", Resource.Title_002);
                            this.textOthNet.Focus();
                            this.textOthNet.SelectAll();
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_361, Resource.Title_002);
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_294, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.txtDeliveryNote.Focus();
                }
            }
        }

        private void buttonStorage_Click(object sender, EventArgs e)
        {
            FormStorage storage = new FormStorage {
                pMode = "CHOOSE"
            };
            storage.ShowDialog();
            if (storage.ReturnRow != null)
            {
                this.textStorage.Text = storage.ReturnRow["Storage_Code"].ToString();
                this.labelStorageName.Text = storage.ReturnRow["Storage_Name"].ToString();
                this.textStorage.Focus();
            }
            storage.Dispose();
        }

        public void cekSisa(string DoNo, double zQty)
        {
            double num;
            WBTable table = new WBTable();
            table.OpenTable("vw_trans", "Select sum(NETTO) as Net from vw_trans where DO_NO = '" + DoNo + "' and (deleted is null or deleted = 'N') and report_date is not null", WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                num = 0.0;
            }
            else
            {
                table.DR = table.DT.Rows[0];
                num = (table.DR["Net"].ToString().Length <= 0) ? 0.0 : Convert.ToDouble(table.DR["Net"].ToString());
            }
            this.labelQtyLeft.Text = Convert.ToString((double) (zQty - num));
            this.labelQuantity.Text = "";
            table.Dispose();
        }

        private void checkDONonContract()
        {
            string[] aField = new string[] { "DO_NO" };
            string[] aFind = new string[] { this.textDO.Text.Trim() };
            if (ReferenceEquals(this.tblDO.GetData(aField, aFind), null))
            {
                this.tblDO.DR = this.tblDO.DT.NewRow();
                this.tblDO.DR["Coy"] = WBData.sCoyCode;
                this.tblDO.DR["location_code"] = WBData.sLocCode;
                this.tblDO.DR["berikat"] = WBSetting.KB;
                this.tblDO.DR["Check_Qty"] = "N";
                this.tblDO.DR["quantity"] = "0";
                this.tblDO.DR["DO_NO"] = "-";
                this.tblDO.DR["Create_by"] = "SYSTEM";
                this.tblDO.DR["Create_date"] = DateTime.Now.ToString();
                this.tblDO.DR["Franco"] = "";
                this.tblDO.DR["deductedby"] = "0";
                this.tblDO.DR["Closed"] = "N";
                this.tblDO.DR["Zauto"] = "N";
                this.tblDO.DT.Rows.Add(this.tblDO.DR);
                this.tblDO.Save();
                WBTable table = new WBTable();
                table.OpenTable("wb_contract", "SELECT uniq FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '-'"), WBData.conn);
                string keyField = table.DT.Rows[0]["uniq"].ToString();
                table.Dispose();
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { "ADD", WBUser.UserID, "" };
                Program.updateLogHeader("wb_contract", keyField, logField, logValue);
                this.tblDO.ReOpen();
            }
        }

        private void checkNonContract_CheckedChanged(object sender, EventArgs e)
        {
            this.NonContract();
        }

        private bool CheckPeriodDO(DataRow prDO, string pDate) => 
            (prDO["checkPeriod"].ToString() == "Y") && (Convert.ToDateTime(pDate) > Convert.ToDateTime(prDO["Do_Date2"].ToString()));

        private bool CheckSPB()
        {
            using (IEnumerator enumerator = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                    string strA = this.txtDeliveryNote.Text.Trim();
                    WBTable table = new WBTable();
                    table.OpenTable("wb_delivery_note", "Select * From wb_delivery_note where Do_No='" + current.Cells["DO_No"].Value.ToString().Trim() + "'", WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num >= table.DT.Rows.Count)
                            {
                                break;
                            }
                            table.DR = table.DT.Rows[num];
                            if ((string.Compare(strA, table.DR["Delivery_Note_From"].ToString()) < 0) || (string.Compare(strA, table.DR["Delivery_Note_to"].ToString()) > 0))
                            {
                                num++;
                                continue;
                            }
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        private void comboDOContainer_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = '\0';
        }

        private void countQtyLeft(string pDoNo)
        {
            string str;
            string[] aField = new string[] { "DO_NO" };
            string[] aFind = new string[] { this.textDO.Text };
            DataRow data = this.tblDO.GetData(aField, aFind);
            string[] textArray3 = new string[] { "comm_code" };
            string[] textArray4 = new string[] { data["comm_code"].ToString() };
            DataRow row2 = this.tblComm.GetData(textArray3, textArray4);
            if (row2 == null)
            {
                str = "N";
            }
            else
            {
                str = row2["using_gunny"].ToString();
                this.transType = row2["Type"].ToString();
            }
            if (str == "Y")
            {
                this.OSNetwoTol = Convert.ToDouble($"{Program.checkOSbyGunny(pDoNo, "", this.RefNo, "N"):N0}");
                this.OSNetTol = ((data["tolerance"].ToString().Trim() == "") && (data["tolerance"].ToString().Trim() == "0")) ? this.OSNetwoTol : Convert.ToDouble($"{Program.checkOSbyGunny(pDoNo, "", this.RefNo, "Y"):N0}");
            }
            else
            {
                this.OSNetwoTol = Convert.ToDouble($"{Program.checkOS(pDoNo, "", this.RefNo, "N"):N0}");
                this.OSNetTol = ((data["tolerance"].ToString().Trim() == "") && (data["tolerance"].ToString().Trim() == "0")) ? this.OSNetwoTol : Convert.ToDouble($"{Program.checkOS(pDoNo, "", this.RefNo, "Y"):N0}");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransDOEntry_Load(object sender, EventArgs e)
        {
            this.translate();
            this.checkNonContract.Checked = this.nonContract == "Y";
            this.NonContract();
            this.labelAgen.Text = "";
            this.labelKB.Text = "";
            this.labelRName.Text = "";
            this.labelCommName.Text = "";
            this.labelStorageName.Text = "";
            this.label1STO1DO.Visible = false;
            this.labelZWB.Visible = false;
            this.textOthNet.Text = "0";
            this.textFactNet.Text = "0";
            if (this.doEntryMode == "ADD")
            {
                if (this.dgvDO.Rows.Count == 0)
                {
                    this.textOthNet.Enabled = false;
                    this.textFactNet.Enabled = false;
                    this.txtDeliveryNote.Visible = false;
                    this.labelDN.Visible = false;
                }
                else
                {
                    this.textOthNet.Enabled = true;
                    this.textFactNet.Enabled = true;
                    this.txtDeliveryNote.Visible = true;
                    this.labelDN.Visible = true;
                    this.textOthNet.Enabled = this.totalNetEstate != 0.0;
                }
            }
            else if (this.doEntryMode == "EDIT")
            {
                this.txtDeliveryNote.Visible = false;
                this.labelDN.Visible = false;
                if (this.dgvDOCurrRow == 0)
                {
                    this.textOthNet.Enabled = false;
                    this.textFactNet.Enabled = false;
                }
                else
                {
                    this.textOthNet.Enabled = true;
                    this.textFactNet.Enabled = true;
                    this.textOthNet.Enabled = this.totalNetEstate != 0.0;
                }
            }
            if (WBSetting.Container == "N")
            {
                this.btnFillContainer.Visible = false;
                this.textPI_No.Visible = false;
                this.labelPI_No.Visible = false;
            }
            if (WBSetting.Field("Check_Storage") != "N")
            {
                this.tblStorage = new WBTable();
                this.tblStorage.OpenTable("wb_storage", "Select * from wb_storage", WBData.conn);
                Program.AutoComp(this.tblStorage, "Storage_code", this.textStorage);
            }
            else
            {
                this.textStorage.Visible = false;
                this.buttonStorage.Visible = false;
                this.labelStorageName.Visible = false;
                this.labelStorage.Visible = false;
            }
            this.tblDO.OpenTable("wb_contract", "select * from wb_contract where" + WBData.CompanyLocation(" and (closed is null or closed <> 'X' or closed = 'N') and zAuto = 'N'"), WBData.conn);
            Program.AutoComp(this.tblDO, "Do_No", this.textDO);
            if (WBSetting.zwb != "Y")
            {
                this.labelZWB.Visible = false;
            }
            this.panelSTO1DO.Visible = WBSetting.locType == "0";
            this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity  where " + WBData.CompanyLocation(" and (deleted is null or deleted ='N' or deleted = '')"), WBData.conn);
            this.tblCust.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblEstate.OpenTable("wb_estate", "Select * from wb_estate", WBData.conn);
            Program.AutoComp(this.tblComm, "Comm_Code", this.textComm);
            Program.AutoComp(this.tblCust, "Relation_Code", this.textRCode);
            Program.AutoComp(this.tblEstate, "Estate_Code", this.textEstate);
            this.sisaNet = this.totalNet;
            this.sisaEstateNet = this.totalNetEstate;
            if ((this.doEntryMode == "ADD") && (this.dgvDO.Rows.Count > 0))
            {
                this.sisaNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["netto"].Value.ToString());
                this.sisaEstateNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString());
            }
            if ((this.doEntryMode != "EDIT") || (this.dgvDOCurrRow <= 0))
            {
                if ((this.doEntryMode == "EDIT") && (this.dgvDOCurrRow == 0))
                {
                    this.sisaNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["netto"].Value.ToString());
                    this.sisaEstateNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString());
                }
            }
            else
            {
                this.sisaNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["netto"].Value.ToString());
                this.sisaEstateNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString());
                this.DONet = Convert.ToDouble(this.dgvDO.Rows[this.dgvDOCurrRow].Cells["netto"].Value.ToString());
                this.DOEstateNet = Convert.ToDouble(this.dgvDO.Rows[this.dgvDOCurrRow].Cells["Estate_qty"].Value.ToString());
                this.sisaNet += this.DONet;
                this.sisaEstateNet += this.DOEstateNet;
            }
            string[] textArray1 = new string[] { this.doEntryMode, " DO for Ref ", this.RefNo, " Available Net (", $"{this.sisaEstateNet:N0}", @"\", $"{this.sisaNet:N0}", ")" };
            this.Text = string.Concat(textArray1);
            if (this.doEntryMode == "EDIT")
            {
                this.textDO.Text = this.dgvDO.CurrentRow.Cells["DO_No"].Value.ToString();
                this.oldDO_No = this.textDO.Text;
                string[] aField = new string[] { "DO_NO" };
                string[] aFind = new string[] { this.textDO.Text };
                DataRow data = this.tblDO.GetData(aField, aFind);
                if (this.nonContract == "N")
                {
                    this.SetorVar(data);
                }
                this.textComm.Text = this.dgvDO.CurrentRow.Cells["Comm_Code"].Value.ToString();
                string[] textArray4 = new string[] { "comm_code" };
                string[] textArray5 = new string[] { this.textComm.Text };
                DataRow row2 = this.tblComm.GetData(textArray4, textArray5);
                if (row2 != null)
                {
                    this.labelCommName.Text = row2["Comm_Name"].ToString();
                    this.CommType = row2["Type"].ToString();
                }
                this.textCont.Text = this.dgvDO.CurrentRow.Cells["Contract"].Value.ToString();
                this.textRCode.Text = this.dgvDO.CurrentRow.Cells["Relation_Code"].Value.ToString().Trim();
                this.labelRName.Text = this.dgvDO.CurrentRow.Cells["Relation_Name"].Value.ToString().Trim();
                this.textFactNet.Text = this.dgvDO.CurrentRow.Cells["Netto"].Value.ToString();
                this.textOthNet.Text = this.dgvDO.CurrentRow.Cells["Estate_Qty"].Value.ToString();
                this.textConvNett.Text = this.dgvDO.CurrentRow.Cells["ConvNett"].Value.ToString();
                this.labelConvUnit.Text = this.dgvDO.CurrentRow.Cells["ConvUnit"].Value.ToString();
                this.labelAgen.Text = (this.dgvDO.CurrentRow.Cells["Agen"].Value.ToString() == "Y") ? "*Agen" : "";
                this.text1STO.Text = this.dgvDO.CurrentRow.Cells["STO1X"].Value.ToString();
                this.text1DOSTO.Text = this.dgvDO.CurrentRow.Cells["DO1X"].Value.ToString();
                this.textEstate.Text = this.dgvDO.CurrentRow.Cells["Estate"].Value.ToString();
                this.textStorage.Text = this.dgvDO.CurrentRow.Cells["storage_code"].Value.ToString();
                this.textTransporter.Text = this.dgvDO.CurrentRow.Cells["Transporter_Code"].Value.ToString();
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.label1 = new Label();
            this.textDO = new TextBox();
            this.buttonDO = new Button();
            this.textCont = new TextBox();
            this.label3 = new Label();
            this.textRCode = new TextBox();
            this.label4 = new Label();
            this.labelFactNet = new Label();
            this.textFactNet = new TextBox();
            this.labelFactKg = new Label();
            this.buttonSave = new Button();
            this.button2 = new Button();
            this.labelAgen = new Label();
            this.textComm = new TextBox();
            this.label7 = new Label();
            this.labelDOQtyLeft = new Label();
            this.textEstate = new TextBox();
            this.label9 = new Label();
            this.textConvNett = new TextBox();
            this.label10 = new Label();
            this.labelConvUnit = new Label();
            this.textPI_No = new TextBox();
            this.labelPI_No = new Label();
            this.textTransporter = new TextBox();
            this.labelTransporter = new Label();
            this.btnFillContainer = new Button();
            this.labelKB = new Label();
            this.textOthNet = new TextBox();
            this.labelOthNet = new Label();
            this.labelOthKg = new Label();
            this.labelStorageName = new Label();
            this.buttonStorage = new Button();
            this.textStorage = new TextBox();
            this.labelStorage = new Label();
            this.label16 = new Label();
            this.text1DOSTO = new TextBox();
            this.label14 = new Label();
            this.text1STO = new TextBox();
            this.label15 = new Label();
            this.rectangleShape1 = new RectangleShape();
            this.label1STO1DO = new Label();
            this.labelZWB = new Label();
            this.panelSTO1DO = new Panel();
            this.shapeContainer2 = new ShapeContainer();
            this.toolTip1 = new ToolTip(this.components);
            this.labelQuantity = new Label();
            this.labelQtyLeft = new Label();
            this.txtDeliveryNote = new TextBox();
            this.labelDN = new Label();
            this.labelCommName = new Label();
            this.buttonComm = new Button();
            this.buttonEstate = new Button();
            this.buttonRName = new Button();
            this.labelRName = new Label();
            this.checkNonContract = new CheckBox();
            this.panelSTO1DO.SuspendLayout();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x65, 0x21);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x2b, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "DO No.";
            this.textDO.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textDO.Location = new Point(0x93, 0x1c);
            this.textDO.MaxLength = 100;
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0x14e, 0x16);
            this.textDO.TabIndex = 0;
            this.textDO.KeyPress += new KeyPressEventHandler(this.textDO_KeyPress);
            this.textDO.Leave += new EventHandler(this.textDO_L);
            this.buttonDO.Location = new Point(0x1e4, 0x1b);
            this.buttonDO.Margin = new Padding(0);
            this.buttonDO.Name = "buttonDO";
            this.buttonDO.Size = new Size(0x17, 0x17);
            this.buttonDO.TabIndex = 1;
            this.buttonDO.Text = "...";
            this.buttonDO.UseVisualStyleBackColor = true;
            this.buttonDO.Click += new EventHandler(this.buttonDO_Click);
            this.textCont.Location = new Point(0x97, 0x57);
            this.textCont.Name = "textCont";
            this.textCont.ReadOnly = true;
            this.textCont.Size = new Size(0xb0, 20);
            this.textCont.TabIndex = 7;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x47, 90);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x43, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Contract No.";
            this.textRCode.Location = new Point(0x97, 0x8d);
            this.textRCode.Name = "textRCode";
            this.textRCode.Size = new Size(180, 20);
            this.textRCode.TabIndex = 8;
            this.textRCode.KeyPress += new KeyPressEventHandler(this.textRCode_KeyPress);
            this.textRCode.Leave += new EventHandler(this.textRCode_Leave);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x22, 0x90);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x6b, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Relation Code/Name";
            this.labelFactNet.AutoSize = true;
            this.labelFactNet.Location = new Point(0x4c, 0x12f);
            this.labelFactNet.Name = "labelFactNet";
            this.labelFactNet.Size = new Size(0x3e, 13);
            this.labelFactNet.TabIndex = 0x10;
            this.labelFactNet.Text = "Factory Net";
            this.textFactNet.Location = new Point(0x98, 300);
            this.textFactNet.Name = "textFactNet";
            this.textFactNet.Size = new Size(0x53, 20);
            this.textFactNet.TabIndex = 2;
            this.textFactNet.Text = "0";
            this.textFactNet.TextAlign = HorizontalAlignment.Right;
            this.textFactNet.Leave += new EventHandler(this.textFactNet_Leave);
            this.labelFactKg.AutoSize = true;
            this.labelFactKg.Location = new Point(0xec, 0x12f);
            this.labelFactKg.Name = "labelFactKg";
            this.labelFactKg.Size = new Size(20, 13);
            this.labelFactKg.TabIndex = 0x12;
            this.labelFactKg.Text = "Kg";
            this.buttonSave.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonSave.Location = new Point(0x213, 0x13b);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x6c, 0x24);
            this.buttonSave.TabIndex = 4;
            this.buttonSave.Text = "&Save";
            this.toolTip1.SetToolTip(this.buttonSave, "Save this DO\r\nShortcut : Alt +S");
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.button2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x298, 0x13b);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x6c, 0x24);
            this.button2.TabIndex = 5;
            this.button2.Text = "&Cancel";
            this.toolTip1.SetToolTip(this.button2, "Cancel this Screen\r\nShortcut : Esc atau Alt+C");
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.labelAgen.AutoSize = true;
            this.labelAgen.Location = new Point(0x2df, 0x94);
            this.labelAgen.Name = "labelAgen";
            this.labelAgen.Size = new Size(0x24, 13);
            this.labelAgen.TabIndex = 0x16;
            this.labelAgen.Text = "*Agen";
            this.textComm.Location = new Point(0x97, 0x73);
            this.textComm.Name = "textComm";
            this.textComm.Size = new Size(0xb2, 20);
            this.textComm.TabIndex = 6;
            this.textComm.KeyPress += new KeyPressEventHandler(this.textComm_KeyPress);
            this.textComm.Leave += new EventHandler(this.textComm_Leave);
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0x55, 0x76);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x3a, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Commodity";
            this.labelDOQtyLeft.AutoSize = true;
            this.labelDOQtyLeft.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelDOQtyLeft.Location = new Point(0x90, 0x33);
            this.labelDOQtyLeft.Name = "labelDOQtyLeft";
            this.labelDOQtyLeft.Size = new Size(0x77, 0x10);
            this.labelDOQtyLeft.TabIndex = 0x19;
            this.labelDOQtyLeft.Text = "DO Quantity Left";
            this.textEstate.AutoCompleteSource = AutoCompleteSource.RecentlyUsedList;
            this.textEstate.Location = new Point(0x97, 0xa6);
            this.textEstate.Name = "textEstate";
            this.textEstate.Size = new Size(180, 20);
            this.textEstate.TabIndex = 10;
            this.textEstate.KeyPress += new KeyPressEventHandler(this.textEstate_KeyPress);
            this.textEstate.Leave += new EventHandler(this.textEstate_Leave);
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x65, 0xa9);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x25, 13);
            this.label9.TabIndex = 0x11;
            this.label9.Text = "Estate";
            this.textConvNett.Location = new Point(0x95, 0x17b);
            this.textConvNett.Name = "textConvNett";
            this.textConvNett.Size = new Size(0x53, 20);
            this.textConvNett.TabIndex = 3;
            this.textConvNett.Text = "0";
            this.textConvNett.TextAlign = HorizontalAlignment.Right;
            this.textConvNett.Visible = false;
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0x1f, 0x17e);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x73, 13);
            this.label10.TabIndex = 30;
            this.label10.Text = "Qty Convertion (Comm)";
            this.label10.Visible = false;
            this.labelConvUnit.AutoSize = true;
            this.labelConvUnit.Location = new Point(0xe9, 0x17e);
            this.labelConvUnit.Name = "labelConvUnit";
            this.labelConvUnit.Size = new Size(80, 13);
            this.labelConvUnit.TabIndex = 0x1f;
            this.labelConvUnit.Text = "Convertion Unit";
            this.labelConvUnit.Visible = false;
            this.textPI_No.Location = new Point(0x95, 0x195);
            this.textPI_No.Name = "textPI_No";
            this.textPI_No.ReadOnly = true;
            this.textPI_No.Size = new Size(0x88, 20);
            this.textPI_No.TabIndex = 13;
            this.textPI_No.Visible = false;
            this.labelPI_No.AutoSize = true;
            this.labelPI_No.Location = new Point(0x6a, 0x198);
            this.labelPI_No.Name = "labelPI_No";
            this.labelPI_No.Size = new Size(0x25, 13);
            this.labelPI_No.TabIndex = 0x22;
            this.labelPI_No.Text = "PI No.";
            this.labelPI_No.Visible = false;
            this.textTransporter.CharacterCasing = CharacterCasing.Upper;
            this.textTransporter.Location = new Point(150, 0xde);
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.ReadOnly = true;
            this.textTransporter.Size = new Size(180, 20);
            this.textTransporter.TabIndex = 9;
            this.labelTransporter.AutoSize = true;
            this.labelTransporter.Location = new Point(0x52, 0xe1);
            this.labelTransporter.Name = "labelTransporter";
            this.labelTransporter.Size = new Size(0x3d, 13);
            this.labelTransporter.TabIndex = 0x10;
            this.labelTransporter.Text = "Transporter";
            this.btnFillContainer.Location = new Point(0x28b, 0x22);
            this.btnFillContainer.Name = "btnFillContainer";
            this.btnFillContainer.Size = new Size(0x79, 0x21);
            this.btnFillContainer.TabIndex = 0x17;
            this.btnFillContainer.Text = "Fill &DO Container";
            this.toolTip1.SetToolTip(this.btnFillContainer, "Fill this DO to Container\r\nShortcut : Alt+D");
            this.btnFillContainer.UseVisualStyleBackColor = true;
            this.btnFillContainer.Click += new EventHandler(this.button3_Click);
            this.labelKB.AutoSize = true;
            this.labelKB.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelKB.Location = new Point(0x261, 6);
            this.labelKB.Name = "labelKB";
            this.labelKB.Size = new Size(150, 20);
            this.labelKB.TabIndex = 0x18;
            this.labelKB.Text = "*Kawasan Berikat";
            this.textOthNet.AutoCompleteSource = AutoCompleteSource.RecentlyUsedList;
            this.textOthNet.Location = new Point(0x98, 0x112);
            this.textOthNet.Name = "textOthNet";
            this.textOthNet.Size = new Size(0x53, 20);
            this.textOthNet.TabIndex = 1;
            this.textOthNet.Text = "0";
            this.textOthNet.TextAlign = HorizontalAlignment.Right;
            this.textOthNet.Leave += new EventHandler(this.textOthNet_Leave);
            this.labelOthNet.AutoSize = true;
            this.labelOthNet.Location = new Point(0x55, 0x115);
            this.labelOthNet.Name = "labelOthNet";
            this.labelOthNet.Size = new Size(0x35, 13);
            this.labelOthNet.TabIndex = 40;
            this.labelOthNet.Text = "Other Net";
            this.labelOthKg.AutoSize = true;
            this.labelOthKg.Location = new Point(0xec, 0x115);
            this.labelOthKg.Name = "labelOthKg";
            this.labelOthKg.Size = new Size(20, 13);
            this.labelOthKg.TabIndex = 0x29;
            this.labelOthKg.Text = "Kg";
            this.labelStorageName.AutoSize = true;
            this.labelStorageName.Location = new Point(0x16a, 0xc3);
            this.labelStorageName.Name = "labelStorageName";
            this.labelStorageName.Size = new Size(0x48, 13);
            this.labelStorageName.TabIndex = 0x1a;
            this.labelStorageName.Text = "StorageName";
            this.buttonStorage.Location = new Point(0x150, 190);
            this.buttonStorage.Margin = new Padding(0);
            this.buttonStorage.Name = "buttonStorage";
            this.buttonStorage.Size = new Size(0x17, 0x17);
            this.buttonStorage.TabIndex = 3;
            this.buttonStorage.Text = "...";
            this.buttonStorage.UseVisualStyleBackColor = true;
            this.buttonStorage.Click += new EventHandler(this.buttonStorage_Click);
            this.textStorage.CharacterCasing = CharacterCasing.Upper;
            this.textStorage.Location = new Point(0x97, 0xc0);
            this.textStorage.MaxLength = 5;
            this.textStorage.Name = "textStorage";
            this.textStorage.Size = new Size(0xb2, 20);
            this.textStorage.TabIndex = 2;
            this.textStorage.KeyPress += new KeyPressEventHandler(this.textStorage_KeyPress);
            this.textStorage.Leave += new EventHandler(this.textStorage_Leave);
            this.labelStorage.AutoSize = true;
            this.labelStorage.Location = new Point(0x61, 0xc2);
            this.labelStorage.Name = "labelStorage";
            this.labelStorage.Size = new Size(0x2c, 13);
            this.labelStorage.TabIndex = 0x12;
            this.labelStorage.Text = "Storage";
            this.label16.AutoSize = true;
            this.label16.Font = new Font("Arial Narrow", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label16.Location = new Point(0xa3, 12);
            this.label16.Name = "label16";
            this.label16.Size = new Size(0x5b, 15);
            this.label16.TabIndex = 2;
            this.label16.Text = "* for 1xSTO = 1xDO";
            this.text1DOSTO.CharacterCasing = CharacterCasing.Upper;
            this.text1DOSTO.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.text1DOSTO.Location = new Point(0x59, 0x3d);
            this.text1DOSTO.MaxLength = 20;
            this.text1DOSTO.Name = "text1DOSTO";
            this.text1DOSTO.Size = new Size(0xa5, 0x1d);
            this.text1DOSTO.TabIndex = 1;
            this.label14.AutoSize = true;
            this.label14.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label14.Location = new Point(0x2f, 0x25);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x24, 0x10);
            this.label14.TabIndex = 3;
            this.label14.Text = "STO";
            this.text1STO.CharacterCasing = CharacterCasing.Upper;
            this.text1STO.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.text1STO.Location = new Point(0x59, 0x1c);
            this.text1STO.MaxLength = 20;
            this.text1STO.Name = "text1STO";
            this.text1STO.Size = new Size(0xa5, 0x1d);
            this.text1STO.TabIndex = 0;
            this.label15.AutoSize = true;
            this.label15.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label15.Location = new Point(0x1f, 0x43);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x3b, 0x10);
            this.label15.TabIndex = 4;
            this.label15.Text = "DO STO";
            this.rectangleShape1.BorderColor = SystemColors.ControlDark;
            this.rectangleShape1.Location = new Point(0x1d, 7);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new Size(0xeb, 90);
            this.label1STO1DO.AutoSize = true;
            this.label1STO1DO.Location = new Point(0x2aa, 0xa1);
            this.label1STO1DO.Name = "label1STO1DO";
            this.label1STO1DO.Size = new Size(0x59, 13);
            this.label1STO1DO.TabIndex = 0x15;
            this.label1STO1DO.Text = "*1x STO = 1x DO";
            this.labelZWB.AutoSize = true;
            this.labelZWB.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelZWB.ForeColor = Color.Red;
            this.labelZWB.Location = new Point(12, 0x148);
            this.labelZWB.Name = "labelZWB";
            this.labelZWB.Size = new Size(0x111, 20);
            this.labelZWB.TabIndex = 0x13;
            this.labelZWB.Text = "Please Synchron this DO to ZWB";
            this.labelZWB.Visible = false;
            this.panelSTO1DO.Controls.Add(this.text1DOSTO);
            this.panelSTO1DO.Controls.Add(this.label15);
            this.panelSTO1DO.Controls.Add(this.text1STO);
            this.panelSTO1DO.Controls.Add(this.label14);
            this.panelSTO1DO.Controls.Add(this.label16);
            this.panelSTO1DO.Location = new Point(0x1e2, 0xc0);
            this.panelSTO1DO.Name = "panelSTO1DO";
            this.panelSTO1DO.Size = new Size(0x121, 0x69);
            this.panelSTO1DO.TabIndex = 0x4e;
            this.shapeContainer2.Location = new Point(0, 0);
            this.shapeContainer2.Margin = new Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            Shape[] shapes = new Shape[] { this.rectangleShape1 };
            this.shapeContainer2.Shapes.AddRange(shapes);
            this.shapeContainer2.Size = new Size(0x121, 0x69);
            this.shapeContainer2.TabIndex = 5;
            this.shapeContainer2.TabStop = false;
            this.labelQuantity.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelQuantity.Location = new Point(0x182, 50);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new Size(0x79, 0x10);
            this.labelQuantity.TabIndex = 0x4f;
            this.labelQuantity.Text = "/ 0";
            this.labelQtyLeft.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelQtyLeft.Location = new Point(0x11a, 50);
            this.labelQtyLeft.Name = "labelQtyLeft";
            this.labelQtyLeft.Size = new Size(0x6b, 0x10);
            this.labelQtyLeft.TabIndex = 20;
            this.labelQtyLeft.Text = "0";
            this.labelQtyLeft.TextAlign = ContentAlignment.TopRight;
            this.txtDeliveryNote.Location = new Point(150, 0xf8);
            this.txtDeliveryNote.Name = "txtDeliveryNote";
            this.txtDeliveryNote.Size = new Size(0xb5, 20);
            this.txtDeliveryNote.TabIndex = 1;
            this.txtDeliveryNote.KeyPress += new KeyPressEventHandler(this.txtDeliveryNote_KeyPress);
            this.txtDeliveryNote.Leave += new EventHandler(this.txtDeliveryNote_Leave);
            this.labelDN.AutoSize = true;
            this.labelDN.Location = new Point(0x48, 0xfb);
            this.labelDN.Name = "labelDN";
            this.labelDN.Size = new Size(0x47, 13);
            this.labelDN.TabIndex = 0x51;
            this.labelDN.Text = "Delivery Note";
            this.labelCommName.AutoSize = true;
            this.labelCommName.Cursor = Cursors.Arrow;
            this.labelCommName.Location = new Point(360, 0x76);
            this.labelCommName.MaximumSize = new Size(350, 0);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x5c, 13);
            this.labelCommName.TabIndex = 0x58;
            this.labelCommName.Text = "Commodity Name ";
            this.buttonComm.Location = new Point(0x150, 0x71);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 0x57;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.buttonEstate.Location = new Point(0x150, 0xa4);
            this.buttonEstate.Margin = new Padding(0);
            this.buttonEstate.Name = "buttonEstate";
            this.buttonEstate.Size = new Size(0x17, 0x17);
            this.buttonEstate.TabIndex = 0x59;
            this.buttonEstate.Text = "...";
            this.buttonEstate.UseVisualStyleBackColor = true;
            this.buttonEstate.Click += new EventHandler(this.buttonEstate_Click);
            this.buttonRName.Location = new Point(0x150, 0x8a);
            this.buttonRName.Margin = new Padding(0);
            this.buttonRName.Name = "buttonRName";
            this.buttonRName.Size = new Size(0x17, 0x17);
            this.buttonRName.TabIndex = 0x5b;
            this.buttonRName.Text = "...";
            this.buttonRName.UseVisualStyleBackColor = true;
            this.buttonRName.Click += new EventHandler(this.buttonRName_Click);
            this.labelRName.AutoSize = true;
            this.labelRName.Location = new Point(360, 0x90);
            this.labelRName.Name = "labelRName";
            this.labelRName.Size = new Size(0x6b, 13);
            this.labelRName.TabIndex = 90;
            this.labelRName.Text = "Relation Code/Name";
            this.checkNonContract.AutoSize = true;
            this.checkNonContract.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.checkNonContract.Location = new Point(0x93, 8);
            this.checkNonContract.Name = "checkNonContract";
            this.checkNonContract.Size = new Size(0x74, 20);
            this.checkNonContract.TabIndex = 0x5c;
            this.checkNonContract.Text = "Non Contract";
            this.checkNonContract.UseVisualStyleBackColor = true;
            this.checkNonContract.CheckedChanged += new EventHandler(this.checkNonContract_CheckedChanged);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x310, 0x16c);
            base.ControlBox = false;
            base.Controls.Add(this.checkNonContract);
            base.Controls.Add(this.buttonRName);
            base.Controls.Add(this.labelRName);
            base.Controls.Add(this.buttonEstate);
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.labelDN);
            base.Controls.Add(this.txtDeliveryNote);
            base.Controls.Add(this.labelQtyLeft);
            base.Controls.Add(this.labelQuantity);
            base.Controls.Add(this.panelSTO1DO);
            base.Controls.Add(this.label1STO1DO);
            base.Controls.Add(this.buttonStorage);
            base.Controls.Add(this.textStorage);
            base.Controls.Add(this.labelStorage);
            base.Controls.Add(this.labelStorageName);
            base.Controls.Add(this.labelOthKg);
            base.Controls.Add(this.textOthNet);
            base.Controls.Add(this.labelOthNet);
            base.Controls.Add(this.labelKB);
            base.Controls.Add(this.btnFillContainer);
            base.Controls.Add(this.textTransporter);
            base.Controls.Add(this.labelTransporter);
            base.Controls.Add(this.textPI_No);
            base.Controls.Add(this.labelPI_No);
            base.Controls.Add(this.labelConvUnit);
            base.Controls.Add(this.textConvNett);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.textEstate);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.labelDOQtyLeft);
            base.Controls.Add(this.textComm);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.labelAgen);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.labelFactKg);
            base.Controls.Add(this.textFactNet);
            base.Controls.Add(this.labelFactNet);
            base.Controls.Add(this.textRCode);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textCont);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.buttonDO);
            base.Controls.Add(this.textDO);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.labelZWB);
            base.KeyPreview = true;
            base.Name = "FormTransDOEntryAfrica";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Entry DO";
            base.Load += new EventHandler(this.FormTransDOEntry_Load);
            this.panelSTO1DO.ResumeLayout(false);
            this.panelSTO1DO.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void NonContract()
        {
            if (this.checkNonContract.Checked)
            {
                this.textComm.Enabled = true;
                this.textRCode.Enabled = true;
                this.labelTransporter.Visible = false;
                this.textTransporter.Visible = false;
                this.textTransporter.Enabled = false;
                this.textEstate.Enabled = true;
                this.textEstate.BackColor = SystemColors.Window;
                this.textRCode.BackColor = SystemColors.Window;
                this.textComm.BackColor = SystemColors.Window;
                this.buttonComm.Visible = true;
                this.buttonEstate.Visible = true;
                this.buttonRName.Visible = true;
                this.textDO.Text = "-";
                this.textCont.Text = "-";
                this.textDO.Enabled = false;
                this.textDO.BackColor = SystemColors.Control;
                this.buttonDO.Visible = false;
            }
            else
            {
                this.textComm.Enabled = false;
                this.textRCode.Enabled = false;
                this.labelTransporter.Visible = true;
                this.textTransporter.Visible = true;
                this.textTransporter.Enabled = false;
                this.textEstate.Enabled = false;
                this.textEstate.BackColor = SystemColors.Control;
                this.textTransporter.BackColor = SystemColors.Control;
                this.textRCode.BackColor = SystemColors.Control;
                this.textComm.BackColor = SystemColors.Control;
                this.buttonComm.Visible = false;
                this.buttonEstate.Visible = false;
                this.buttonRName.Visible = false;
                this.textDO.Text = "";
                this.textCont.Text = "";
                this.textDO.Enabled = true;
                this.buttonDO.Visible = true;
                this.textDO.BackColor = SystemColors.Window;
            }
        }

        private void SetorVar(DataRow pDoRow)
        {
            this.labelKB.Text = (pDoRow["berikat"].ToString() == "Y") ? "*KB" : "";
            this.label1STO1DO.Visible = pDoRow["STO1DO"].ToString() == "Y";
            this.countQtyLeft(pDoRow["DO_NO"].ToString());
            this.chkqty = pDoRow["Check_qty"].ToString();
            this.tolerance = pDoRow["tolerance"].ToString();
            this.deductedBy = pDoRow["deductedBy"].ToString();
            this.labelQtyLeft.Text = $"{Convert.ToDouble(this.OSNetwoTol.ToString()):N0}";
            this.OSNetwoTol = Convert.ToDouble(this.labelQtyLeft.Text);
            this.labelQuantity.Text = "/ " + $"{Convert.ToDouble(pDoRow["quantity"].ToString()):N0}";
            this.textComm.Text = pDoRow["Comm_Code"].ToString();
            this.labelConvUnit.Text = pDoRow["ConvertionUnit"].ToString();
            this.textCont.Text = pDoRow["Contract"].ToString();
            this.textTransporter.Text = pDoRow["Transporter_Code"].ToString();
            this.textRCode.Text = pDoRow["Relation_Code"].ToString().Trim();
            this.textEstate.Text = pDoRow["Estate1_Code"].ToString();
            this.labelAgen.Text = (pDoRow["Agen"].ToString().Trim() == "Y") ? "*Agen" : "";
            this.labelKB.Text = (pDoRow["Berikat"].ToString().Trim() == "Y") ? "*KB" : "";
            this.label1STO1DO.Visible = pDoRow["STO1DO"].ToString().Trim() == "Y";
            this.lSTO1DO = pDoRow["STO1DO"].ToString().Trim() == "Y";
            this.ISCC = pDoRow["ISCC"].ToString().Trim();
            this.textPI_No.Text = pDoRow["PI_No"].ToString();
            string[] aField = new string[] { "relation_code" };
            string[] aFind = new string[] { this.textRCode.Text.Trim() };
            DataRow data = this.tblCust.GetData(aField, aFind);
            if (data != null)
            {
                this.textRCode.Text = pDoRow["Relation_Code"].ToString().Trim();
                this.labelRName.Text = data["Relation_Name"].ToString().Trim();
            }
            this.pComm = pDoRow["Comm_Code"].ToString();
            this.pTransType = pDoRow["Transaction_Code"].ToString();
            this.remark = pDoRow["remark"].ToString();
            this.DoConvUnit = pDoRow["ConvertionUnit"].ToString();
            this.labelConvUnit.Text = this.DoConvUnit;
            this.DoConv = pDoRow["Convertion"].ToString();
            this.DoConvTol = pDoRow["ConvertionTolerance"].ToString();
            this.qualityInfo = pDoRow["qualityInfo"].ToString();
            this.tolling = pDoRow["Tolling"].ToString();
            if (WBSetting.zwb == "Y")
            {
                this.labelZWB.Visible = pDoRow["ZWB"].ToString() != "Y";
            }
            if (pDoRow["check_qty"].ToString() == "Y")
            {
                double num = 0.3 * Program.StrToDouble(this.party, 2);
                if (this.OSNetwoTol >= num)
                {
                    this.labelQtyLeft.ForeColor = Color.Black;
                }
                else
                {
                    MessageBox.Show(Resource.Mes_363, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.labelQtyLeft.ForeColor = Color.Red;
                }
            }
        }

        private void textComm_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textComm_Leave(object sender, EventArgs e)
        {
            if (this.checkNonContract.Checked && (this.textComm.Text.Trim() != ""))
            {
                this.tblComm.ReOpen();
                string[] aField = new string[] { "comm_code" };
                string[] aFind = new string[] { this.textComm.Text };
                DataRow data = this.tblComm.GetData(aField, aFind);
                if (data != null)
                {
                    this.labelCommName.Text = data["Comm_Name"].ToString();
                    this.CommType = data["Type"].ToString();
                }
                else
                {
                    this.buttonComm.PerformClick();
                    this.textComm.Focus();
                }
            }
        }

        private void textCompany_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDO_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDO_L(object sender, EventArgs e)
        {
            if (this.textDO.Text != "")
            {
                this.tblDO.ReOpen();
                string[] aField = new string[] { "Do_No" };
                string[] aFind = new string[] { this.textDO.Text.Trim() };
                DataRow data = this.tblDO.GetData(aField, aFind);
                if (ReferenceEquals(data, null))
                {
                    this.buttonDO.PerformClick();
                    this.textDO.Focus();
                }
                else if (data["zAuto"].ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mes_354, Resource.Title_002);
                    this.textDO.Focus();
                }
                else if ((WBSetting.Field("GM") == "Y") && (data["completed"].ToString() == "N"))
                {
                    MessageBox.Show(Resource.Mes_064, Resource.Title_002);
                }
                else if (this.CheckPeriodDO(data, this.refDate))
                {
                    string[] textArray3 = new string[] { data["DO_NO"].ToString(), " ", Resource.Mes_366, data["Do_Date2"].ToString().Substring(0, 10), "...!" };
                    MessageBox.Show(string.Concat(textArray3), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    this.SetorVar(data);
                    if (!this.checkNonContract.Checked)
                    {
                        string[] textArray4 = new string[] { "Comm_Code" };
                        string[] textArray5 = new string[] { this.textComm.Text.Trim() };
                        string str = this.tblComm.GetData(textArray4, textArray5)["Type"].ToString();
                        if (this.dgvDO.Rows.Count > 0)
                        {
                            if ((str == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                            {
                                this.txtDeliveryNote.Enabled = false;
                            }
                            else if ((str == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                            {
                                this.txtDeliveryNote.Enabled = false;
                            }
                            else if ((str == "F") && !this.CheckSPB())
                            {
                                MessageBox.Show(Resource.Mes_277, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.txtDeliveryNote.Focus();
                            }
                        }
                    }
                }
            }
        }

        private void textEstate_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textEstate_Leave(object sender, EventArgs e)
        {
            if ((this.nonContract == "N") && (this.textEstate.Text.Trim() != ""))
            {
                string[] aField = new string[] { "Estate_code" };
                string[] aFind = new string[] { this.textEstate.Text };
                if (ReferenceEquals(this.tblEstate.GetData(aField, aFind), null))
                {
                    this.buttonEstate.PerformClick();
                    this.textEstate.Focus();
                }
            }
        }

        private void textFactNet_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textFactNet);
        }

        private void textOthNet_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textOthNet);
            if (((this.textOthNet.Text != "0") && (this.textOthNet.Text != "")) && (MessageBox.Show(Resource.Mes_362, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes))
            {
                this.textFactNet.Text = Convert.ToString(Math.Round((double) (Convert.ToDouble(this.textOthNet.Text) + ((Convert.ToDouble(this.totalVariance) / Convert.ToDouble(this.totalNetEstate)) * Convert.ToDouble(this.textOthNet.Text)))));
            }
        }

        private void textRCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textRCode_Leave(object sender, EventArgs e)
        {
            if (this.textRCode.Text.Trim() != "")
            {
                string[] aField = new string[] { "Relation_code" };
                string[] aFind = new string[] { this.textRCode.Text };
                DataRow data = this.tblCust.GetData(aField, aFind);
                if (data != null)
                {
                    this.textRCode.Text = data["Relation_Code"].ToString();
                    this.labelRName.Text = data["Relation_Name"].ToString();
                }
                else
                {
                    this.buttonRName.PerformClick();
                    this.textRCode.Focus();
                }
            }
        }

        private void textStorage_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textStorage_Leave(object sender, EventArgs e)
        {
            if (this.textStorage.Text != "")
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_storage", "SELECT * FROM wb_storage Where " + WBData.CompanyLocation(" and storage_code ='" + this.textStorage.Text.Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    this.buttonStorage.PerformClick();
                    this.textStorage.Focus();
                }
                table.Dispose();
            }
        }

        private void translate()
        {
            this.checkNonContract.Text = Resource.DoE_001;
            this.label1.Text = Resource.DoE_002;
            this.labelDOQtyLeft.Text = Resource.DoE_003;
            this.label3.Text = Resource.DoE_004;
            this.label7.Text = Resource.DoE_005;
            this.labelRName.Text = Resource.DoE_006;
            this.label9.Text = Resource.DoE_007;
            this.labelTransporter.Text = Resource.DoE_008;
            this.labelDN.Text = Resource.DoE_009;
            this.labelOthNet.Text = Resource.DoE_010;
            this.labelFactNet.Text = Resource.DoE_011;
            this.label14.Text = Resource.DoE_012;
            this.label15.Text = Resource.DoE_013;
        }

        private void txtDeliveryNote_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void txtDeliveryNote_Leave(object sender, EventArgs e)
        {
            string[] aField = new string[] { "Comm_Code" };
            string[] aFind = new string[] { this.textComm.Text.Trim() };
            DataRow data = this.tblComm.GetData(aField, aFind);
            if ((WBSetting.Field("DeliveryNote") == "Y") && (this.txtDeliveryNote.Text.Trim() != "-"))
            {
            }
        }
    }
}

