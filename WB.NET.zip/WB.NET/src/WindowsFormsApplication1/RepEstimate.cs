﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class RepEstimate : Form
    {
        public WBTable ttype = new WBTable();
        public WBTable tblComm = new WBTable();
        public WBTable tblTransporter = new WBTable();
        private IContainer components = null;
        public Label labelProses1;
        public Label labelProses2;
        public GroupBox groupDate;
        public DateTimePicker monthCalendar1;
        public Label label1;
        public Label label2;
        public DateTimePicker monthCalendar2;
        public Button button2;
        public Button buttonComm;
        public Label labelCommName;
        public TextBox textCommodity;
        public Label labelcommodity;
        public Button button1;
        public Label label3;
        private ComboBox comboBox1;
        public Label labelType;
        public Button button4;
        public Label label4;
        public TextBox textTransport;
        public Label label5;
        private LineShape lineShape2;
        private ShapeContainer shapeContainer1;
        private CheckBox cbGunny;
        private CheckBox cbDeduction;

        public RepEstimate()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.translate();
            Cursor.Current = Cursors.WaitCursor;
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                HTML html = new HTML();
                html.File = html.File + @"\" + WBUser.UserID + "_estimate.htm";
                html.Title = "List of Weighing";
                html.Open();
                html.Write(html.Style());
                WBTable table = new WBTable();
                table.OpenTable("wb_driver", "Select * From wb_driver", WBData.conn);
                WBTable table2 = new WBTable();
                string sqltext = "";
                sqltext = (this.comboBox1.Text.Trim() != "") ? ("Select * From wb_transaction where " + WBData.CompanyLocation(" and Transaction_Code='" + this.comboBox1.Text.Trim() + "'")) : ("Select * From wb_transaction where " + WBData.CompanyLocation(""));
                sqltext = (sqltext + " and (Ref_Date>='" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00'") + " and Ref_Date<='" + this.monthCalendar2.Value.ToString("yyyy-MM-dd") + " 00:00:00')";
                if (this.textCommodity.Text != "")
                {
                    sqltext = sqltext + " and Comm_Code='" + this.textCommodity.Text.Trim() + "'";
                }
                if (this.textTransport.Text != "")
                {
                    sqltext = sqltext + " and Transporter_Code='" + this.textTransport.Text.Trim() + "'";
                }
                sqltext = (sqltext + " and (NOT (Ref LIKE '%" + Constant.TITIP_TIMBUN_POSTFIX + "')) ") + " and WX='2X' Order By Comm_Code,Ref Asc";
                table2.OpenTable("view", sqltext, WBData.conn);
                if (table2.DT.Rows.Count <= 0)
                {
                    MessageBox.Show(Resource.Mes_348, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    html.Write("<br><font size=5><b>ESTIMATION OF RECEIVING</b></font><br>");
                    string[] textArray1 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                    html.Write(string.Concat(textArray1));
                    string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                    html.Write(string.Concat(textArray2));
                    if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                    {
                        html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                    }
                    if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                    {
                        html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                    }
                    if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                    {
                        html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                    }
                    html.Write("<br><br>");
                    html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                    if (this.textCommodity.Text.Trim() != "")
                    {
                        html.Write("<tr class=bd>");
                        html.Write("<td>Commodity</td>");
                        html.Write("<td>: <b>" + this.textCommodity.Text + "</b></td>");
                        html.Write("</tr>");
                    }
                    if (this.textTransport.Text.Trim() != "")
                    {
                        html.Write("<tr class=bd>");
                        html.Write("<td>Transporter</td>");
                        html.Write("<td>: <b>" + this.textTransport.Text + "</b></td>");
                        html.Write("</tr>");
                    }
                    html.Write("<tr class=bd>");
                    html.Write("<td>Selected Date</td>");
                    string[] textArray3 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                    html.Write(string.Concat(textArray3));
                    html.Write("</tr>");
                    html.Write("<tr class=bd>");
                    html.Write("<td>Report Date</td>");
                    html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                    html.Write("</tr>");
                    html.Write("</table>");
                    html.Write("<br/><br/><br/>");
                    html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                    html.Write("<tr class='bd'>");
                    html.Write("<td nowrap>" + Resource.Setting_094 + ".</td>");
                    html.Write("<td nowrap>" + Resource.Contract_005 + "</td>");
                    html.Write("<td nowrap>" + Resource.Trans_005 + "</td>");
                    html.Write("<td nowrap>" + Resource.Main_057 + "</td>");
                    html.Write("<td nowrap>" + Resource.Main_014 + "</td>");
                    html.Write("<td >" + Resource.Main_036 + "</td>");
                    html.Write("<td >" + Resource.Main_037 + "</td>");
                    html.Write("<td nowrap>" + Resource.Contract_002 + "</td>");
                    html.Write("<td nowrap>" + Resource.Composite_004 + "</td>");
                    html.Write("<td nowrap>" + Resource.Composite_002 + "</td>");
                    html.Write("<td nowrap>" + Resource.Block_001 + "</td>");
                    html.Write("<td nowrap>" + Resource.DriverE_001 + "</td>");
                    html.Write("<td nowrap>" + Resource.DriverE_002 + "</td>");
                    html.Write("<td nowrap>" + Resource.DriverE_003 + "</td>");
                    html.Write("<td nowrap>" + Resource.DoE_008 + "</td>");
                    html.Write("<td nowrap>NETT  (" + Resource.Block_001 + ")</td>");
                    string[] textArray4 = new string[] { "<td nowrap>", Resource.Main_019, " (", Resource.ContractE_038, ")</td>" };
                    html.Write(string.Concat(textArray4));
                    string[] textArray5 = new string[] { "<td nowrap>", Resource.Main_020, "  (", Resource.ContractE_038, ")</td>" };
                    html.Write(string.Concat(textArray5));
                    if (this.cbDeduction.Checked)
                    {
                        string[] textArray6 = new string[] { "<td nowrap>", Resource.Main_022, " (", Resource.ContractE_038, ")</td>" };
                        html.Write(string.Concat(textArray6));
                    }
                    if (this.cbGunny.Checked)
                    {
                        html.Write("<td nowrap>GUNNY (" + Resource.ContractE_038 + ")</td>");
                    }
                    html.Write("<td nowrap>NETT  (" + Resource.ContractE_038 + ")</td>");
                    html.Write("<td nowrap>" + Resource.Rep01_037 + "</td>");
                    html.Write("<td nowrap>" + Resource.Rep01_036 + "</td>");
                    html.Write("</tr>");
                    double num2 = 0.0;
                    double num3 = 0.0;
                    double num4 = 0.0;
                    double num5 = 0.0;
                    double num6 = 0.0;
                    double num7 = 0.0;
                    double num8 = 0.0;
                    double num9 = 0.0;
                    double num10 = 0.0;
                    double num11 = 0.0;
                    double num12 = 0.0;
                    double num13 = 0.0;
                    double num14 = 0.0;
                    double num15 = 0.0;
                    int num16 = 0;
                    int num17 = 1;
                    string str2 = "";
                    WBTable table3 = new WBTable();
                    int count = table2.DT.Rows.Count;
                    this.labelProses1.Text = "";
                    this.labelProses2.Text = "";
                    this.labelProses1.Visible = true;
                    this.labelProses2.Visible = true;
                    foreach (DataRow row in table2.DT.Rows)
                    {
                        this.labelProses1.Text = num16.ToString() + "/" + count;
                        this.labelProses1.Refresh();
                        this.labelProses2.Text = row["Comm_Code"].ToString() + "-" + row["Ref"].ToString();
                        this.labelProses2.Refresh();
                        table3.OpenTable("transDO", "Select * From wb_transDO Where " + WBData.CompanyLocation(" and Ref='" + row["Ref"].ToString().Trim() + "'"), WBData.conn);
                        int num19 = 0;
                        while (true)
                        {
                            if (num19 >= table3.DT.Rows.Count)
                            {
                                num16++;
                                break;
                            }
                            if (row["deleted"].ToString() != "Y")
                            {
                                if ((str2 != "") && (str2 != table3.DT.Rows[num19]["Comm_Code"].ToString()))
                                {
                                    html.Write("<tr class='bd'>");
                                    string[] textArray7 = new string[] { "<td colspan=15><b>", Resource.Menu_Subtotal, " ", str2, "</td>" };
                                    html.Write(string.Concat(textArray7));
                                    html.Write("<td nowrap align=right><b>" + $"{num6:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num7:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num8:N0}" + "</td>");
                                    num10 = Program.StrToDouble($"{num10:N0}", 0);
                                    num12 -= this.cbGunny.Checked ? num10 : 0.0;
                                    if (this.cbDeduction.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num12:N0}" + "</td>");
                                    }
                                    if (this.cbGunny.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num10:N0}" + "</td>");
                                    }
                                    html.Write("<td nowrap align=right><b>" + $"{num9:N0}" + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("</tr>");
                                    num6 = 0.0;
                                    num7 = 0.0;
                                    num8 = 0.0;
                                    num9 = 0.0;
                                    num10 = 0.0;
                                    num12 = 0.0;
                                    str2 = table3.DT.Rows[num19]["Comm_Code"].ToString();
                                    num17 = 1;
                                }
                                if (str2 == "")
                                {
                                    str2 = table3.DT.Rows[num19]["Comm_Code"].ToString();
                                }
                                num2 += Program.StrToDouble(table3.DT.Rows[num19]["Estate_Qty"].ToString(), 0);
                                num3 += Program.StrToDouble(table3.DT.Rows[num19]["Bruto"].ToString(), 0);
                                num4 += Program.StrToDouble(table3.DT.Rows[num19]["Tarra"].ToString(), 0);
                                num5 += Program.StrToDouble(table3.DT.Rows[num19]["Netto"].ToString(), 0);
                                num11 += Program.StrToDouble(row["WeightPerUnitName"].ToString(), 2) * Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                                num10 += Program.StrToDouble(row["WeightPerUnitName"].ToString(), 2) * Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                                num12 += Program.StrToDouble(row["Deduction"].ToString(), 0);
                                num13 += Program.StrToDouble(row["Deduction"].ToString(), 0);
                                num6 += Program.StrToDouble(table3.DT.Rows[num19]["Estate_Qty"].ToString(), 0);
                                num7 += Program.StrToDouble(table3.DT.Rows[num19]["Bruto"].ToString(), 0);
                                num8 += Program.StrToDouble(table3.DT.Rows[num19]["Tarra"].ToString(), 0);
                                num9 += Program.StrToDouble(table3.DT.Rows[num19]["Netto"].ToString(), 0);
                                html.Write("<tr class='bd'>");
                                html.Write("<td nowrap>" + html.strq(num17.ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row["Transaction_Code"].ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row["Ref"].ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row["Date1"].ToString().Substring(0, 10)) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row["Time1"].ToString().Substring(0, 5)) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row["Delivery_Date"].ToString().Substring(0, 10)) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row["Delivery_Time"].ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(table3.DT.Rows[num19]["DO_No"].ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row["Comm_code"].ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(table3.DT.Rows[num19]["Relation_code"].ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(table3.DT.Rows[num19]["Estate"].ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row["License_No"].ToString()) + "</td>");
                                if (row["Name"].ToString().Trim() == "")
                                {
                                    string[] aField = new string[] { "License_No" };
                                    string[] aFind = new string[] { row["License_No"].ToString() };
                                    string str3 = table.GetData(aField, aFind)["Name"].ToString();
                                }
                                html.Write("<td nowrap>" + html.strq(row["Name"].ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row["Truck_Number"].ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row["Transporter_Code"].ToString()) + "</td>");
                                html.Write("<td nowrap align=right>" + html.strq($"{table3.DT.Rows[num19]["Estate_Qty"]:N0}") + "</td>");
                                html.Write("<td nowrap align=right>" + html.strq($"{table3.DT.Rows[num19]["Bruto"]:N0}") + "</td>");
                                html.Write("<td nowrap align=right>" + html.strq($"{table3.DT.Rows[num19]["Tarra"]:N0}") + "</td>");
                                num14 = Program.StrToDouble(row["TotalBunch"].ToString(), 0) * Program.StrToDouble(row["WeightPerUnitName"].ToString(), 2);
                                num14 = Program.StrToDouble($"{num14:N0}", 0);
                                num15 = Program.StrToDouble(row["Deduction"].ToString(), 0) - (this.cbGunny.Checked ? num14 : 0.0);
                                if (this.cbDeduction.Checked)
                                {
                                    html.Write("<td nowrap align=right>" + html.strq($"{num15:N0}") + "</td>");
                                }
                                if (this.cbGunny.Checked)
                                {
                                    html.Write("<td nowrap align=right>" + html.strq($"{num14:N0}") + "</td>");
                                }
                                html.Write("<td nowrap align=right>" + html.strq($"{table3.DT.Rows[num19]["Netto"]:N0}") + "</td>");
                                html.Write("<td nowrap>" + html.strq(row["Remark_Ticket"].ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(row["Remark_Report"].ToString()) + "</td>");
                                html.Write("</tr>");
                            }
                            num17++;
                            num19++;
                        }
                    }
                    this.labelProses1.Text = num16.ToString() + "/" + count;
                    this.labelProses1.Refresh();
                    if (this.textCommodity.Text == "")
                    {
                        html.Write("<tr class='bd'>");
                        string[] textArray10 = new string[] { "<td colspan=15><b>", Resource.Menu_Subtotal, " ", str2, "</td>" };
                        html.Write(string.Concat(textArray10));
                        html.Write("<td nowrap align=right><b>" + $"{num6:N0}" + "</td>");
                        html.Write("<td nowrap align=right><b>" + $"{num7:N0}" + "</td>");
                        html.Write("<td nowrap align=right><b>" + $"{num8:N0}" + "</td>");
                        num10 = Program.StrToDouble($"{num10:N0}", 0);
                        num12 -= this.cbGunny.Checked ? num10 : 0.0;
                        if (this.cbDeduction.Checked)
                        {
                            html.Write("<td nowrap align=right><b>" + $"{num12:N0}" + "</td>");
                        }
                        if (this.cbGunny.Checked)
                        {
                            html.Write("<td nowrap align=right><b>" + $"{num10:N0}" + "</td>");
                        }
                        html.Write("<td nowrap align=right><b>" + $"{num9:N0}" + "</td>");
                        html.Write("<td>" + html.strq("") + "</td>");
                        html.Write("<td>" + html.strq("") + "</td>");
                        html.Write("</tr>");
                    }
                    html.Write("<tr class='bd'>");
                    html.Write("<td colspan=15><b>" + Resource.Menu_Total + "</td>");
                    html.Write("<td nowrap align=right><b>" + $"{num2:N0}" + "</td>");
                    html.Write("<td nowrap align=right><b>" + $"{num3:N0}" + "</td>");
                    html.Write("<td nowrap align=right><b>" + $"{num4:N0}" + "</td>");
                    num11 = Program.StrToDouble($"{num11:N0}", 0);
                    num13 -= this.cbGunny.Checked ? num11 : 0.0;
                    if (this.cbDeduction.Checked)
                    {
                        html.Write("<td nowrap align=right><b>" + $"{num13:N0}" + "</td>");
                    }
                    if (this.cbGunny.Checked)
                    {
                        html.Write("<td nowrap align=right><b>" + $"{num11:N0}" + "</td>");
                    }
                    html.Write("<td nowrap align=right><b>" + $"{num5:N0}" + "</td>");
                    html.Write("<td>" + html.strq("") + "</td>");
                    html.Write("<td>" + html.strq("") + "</td>");
                    html.Write("</tr>");
                    html.Write("</table>");
                    html.Write("<br>");
                    html.Write("<br>");
                    html.writeSign();
                    Cursor.Current = Cursors.Default;
                    html.Close();
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + html.File) }
                    };
                    report.ShowDialog();
                    html.Dispose();
                    report.Dispose();
                    this.labelProses1.Text = "";
                    this.labelProses2.Text = "";
                    this.labelProses1.Visible = false;
                    this.labelProses2.Visible = false;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransport.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.textTransport.Focus();
            }
            transporter.Dispose();
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
                this.textCommodity.Focus();
            }
            commodity.Dispose();
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.labelProses1 = new Label();
            this.labelProses2 = new Label();
            this.groupDate = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label1 = new Label();
            this.label2 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.button2 = new Button();
            this.buttonComm = new Button();
            this.labelCommName = new Label();
            this.textCommodity = new TextBox();
            this.labelcommodity = new Label();
            this.button1 = new Button();
            this.label3 = new Label();
            this.comboBox1 = new ComboBox();
            this.labelType = new Label();
            this.button4 = new Button();
            this.label4 = new Label();
            this.textTransport = new TextBox();
            this.label5 = new Label();
            this.lineShape2 = new LineShape();
            this.shapeContainer1 = new ShapeContainer();
            this.cbGunny = new CheckBox();
            this.cbDeduction = new CheckBox();
            this.groupDate.SuspendLayout();
            base.SuspendLayout();
            this.labelProses1.AutoSize = true;
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(0x17, 0xfc);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0x37, 13);
            this.labelProses1.TabIndex = 0x3e;
            this.labelProses1.Text = "1/88888";
            this.labelProses2.AutoSize = true;
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0x17, 0x10d);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0xd6, 13);
            this.labelProses2.TabIndex = 0x3d;
            this.labelProses2.Text = "Progresssss . . . . . . . . . . . . . . . . . ";
            this.groupDate.Controls.Add(this.monthCalendar1);
            this.groupDate.Controls.Add(this.label1);
            this.groupDate.Controls.Add(this.label2);
            this.groupDate.Controls.Add(this.monthCalendar2);
            this.groupDate.Location = new Point(0x1a, 0x4d);
            this.groupDate.Name = "groupDate";
            this.groupDate.Size = new Size(0x193, 0x2d);
            this.groupDate.TabIndex = 0x30;
            this.groupDate.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x54, 0x10);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3e, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "From Date :";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0xca, 20);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x34, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(260, 0x10);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x13b, 0xe2);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x71, 0x22);
            this.button2.TabIndex = 4;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.buttonComm.Location = new Point(0x108, 0x88);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 5;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.labelCommName.AutoSize = true;
            this.labelCommName.Location = new Point(290, 0x8d);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x3a, 13);
            this.labelCommName.TabIndex = 0x3a;
            this.labelCommName.Text = "Commodity";
            this.textCommodity.CharacterCasing = CharacterCasing.Upper;
            this.textCommodity.Cursor = Cursors.IBeam;
            this.textCommodity.Location = new Point(0x65, 0x89);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(160, 20);
            this.textCommodity.TabIndex = 1;
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x26, 0x8d);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3a, 13);
            this.labelcommodity.TabIndex = 0x39;
            this.labelcommodity.Text = "Commodity";
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0xc7, 0xe2);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x22);
            this.button1.TabIndex = 3;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x1b, 0x34);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x40, 13);
            this.label3.TabIndex = 0x40;
            this.label3.Text = "Trans. Type";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new Point(0x65, 0x30);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new Size(0x52, 0x15);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.KeyPress += new KeyPressEventHandler(this.comboBox1_KeyPress);
            this.labelType.AutoSize = true;
            this.labelType.Location = new Point(0xbd, 0x34);
            this.labelType.Name = "labelType";
            this.labelType.Size = new Size(0x5f, 13);
            this.labelType.TabIndex = 0x41;
            this.labelType.Text = "Trans. Type Name";
            this.button4.Location = new Point(0x108, 0xa2);
            this.button4.Margin = new Padding(0);
            this.button4.Name = "button4";
            this.button4.Size = new Size(0x17, 0x17);
            this.button4.TabIndex = 6;
            this.button4.Text = "...";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new EventHandler(this.button4_Click);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x23, 0xa7);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x3d, 13);
            this.label4.TabIndex = 0x44;
            this.label4.Text = "Transporter";
            this.textTransport.CharacterCasing = CharacterCasing.Upper;
            this.textTransport.Location = new Point(0x65, 0xa3);
            this.textTransport.Name = "textTransport";
            this.textTransport.Size = new Size(160, 20);
            this.textTransport.TabIndex = 2;
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(0x16, 9);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x127, 20);
            this.label5.TabIndex = 0x45;
            this.label5.Text = "Receiving Estimation from 3rd Party";
            this.label5.TextAlign = ContentAlignment.TopCenter;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 0x1ac;
            this.lineShape2.X2 = 0x1b;
            this.lineShape2.Y1 = 0x24;
            this.lineShape2.Y2 = 0x24;
            this.lineShape2.Click += new EventHandler(this.lineShape2_Click);
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.lineShape2 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(0x1cf, 0x127);
            this.shapeContainer1.TabIndex = 70;
            this.shapeContainer1.TabStop = false;
            this.cbGunny.AutoSize = true;
            this.cbGunny.Location = new Point(0xd7, 0xc4);
            this.cbGunny.Name = "cbGunny";
            this.cbGunny.Size = new Size(0x99, 0x11);
            this.cbGunny.TabIndex = 0x48;
            this.cbGunny.Text = "Show Deduction by Gunny";
            this.cbGunny.UseVisualStyleBackColor = true;
            this.cbDeduction.AutoSize = true;
            this.cbDeduction.Location = new Point(100, 0xc4);
            this.cbDeduction.Name = "cbDeduction";
            this.cbDeduction.Size = new Size(0x69, 0x11);
            this.cbDeduction.TabIndex = 0x47;
            this.cbDeduction.Text = "Show Deduction";
            this.cbDeduction.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1cf, 0x127);
            base.ControlBox = false;
            base.Controls.Add(this.cbGunny);
            base.Controls.Add(this.cbDeduction);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.button4);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textTransport);
            base.Controls.Add(this.labelType);
            base.Controls.Add(this.comboBox1);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.groupDate);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.shapeContainer1);
            base.Name = "RepEstimate";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Report Estimate";
            base.Load += new EventHandler(this.RepEstimate_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepEstimate_KeyPress);
            this.groupDate.ResumeLayout(false);
            this.groupDate.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void lineShape2_Click(object sender, EventArgs e)
        {
        }

        private void RepEstimate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepEstimate_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.labelProses1.Text = "";
            this.labelProses2.Text = "";
            this.labelType.Text = "";
            this.tblTransporter.OpenTable("wb_transporter", "Select * From wb_transporter", WBData.conn);
            this.ttype.OpenTable("wb_transaction_type", "Select * From wb_transaction_type where " + WBData.CompanyLocation(" and IO='I'"), WBData.conn);
            this.comboBox1.Items.Clear();
            this.comboBox1.Items.Add("  ");
            foreach (DataRow row in this.ttype.DT.Rows)
            {
                this.comboBox1.Items.Add(row["Transaction_Code"].ToString());
            }
            Program.AutoCompCombo(this.ttype, "Transaction_Code", this.comboBox1);
            Program.AutoComp(this.tblTransporter, "Transporter_Code", this.textTransport);
            this.tblComm.OpenTable("wb_commodity", "Select * From wb_commodity", WBData.conn);
            Program.AutoComp(this.tblComm, "comm_code", this.textCommodity);
        }

        private void translate()
        {
            this.label5.Text = Resource.Report04_001;
            this.label3.Text = Resource.Report04_002;
            this.label1.Text = Resource.Report04_003;
            this.label2.Text = Resource.Report04_004;
            this.labelcommodity.Text = Resource.Report04_005;
            this.label4.Text = Resource.Report04_006;
            this.cbDeduction.Text = Resource.Report04_007;
            this.cbGunny.Text = Resource.Report04_008;
            this.button1.Text = Resource.Rep01_042;
            this.button2.Text = Resource.Menu_Close;
        }
    }
}

