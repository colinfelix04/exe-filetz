﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormUserGroup : Form
    {
        public WBTable tGroup = new WBTable();
        public WBTable tAuth = new WBTable();
        public WBTable tMenu = new WBTable();
        public string logKey = "";
        private IContainer components = null;
        private DataGridView dataGridView1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addCommodityItemToolStripMenuItem;
        private ToolStripMenuItem editCommodityToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem closeToolStripMenuItem;
        private Panel panel1;
        private TextBox TextFind;
        private Button buttonFind;
        private ToolStripMenuItem repairAllChecksumToolStripMenuItem;
        private CheckBox checkShowAllUser;
        private ToolStripMenuItem copyToOtherLocationsToolStripMenuItem;

        public FormUserGroup()
        {
            this.InitializeComponent();
        }

        private void addCommodityItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormUserGroupEntry entry = new FormUserGroupEntry {
                pMode = "ADD",
                tGroup = this.tGroup,
                nCurrRow = this.dataGridView1.CurrentRow.Index,
                tAuth = this.tAuth,
                tMenu = this.tMenu
            };
            entry.ShowDialog();
            if (entry.Saved)
            {
                this.tGroup.ReOpen();
                this.dataGridView1.DataSource = this.tGroup.DT;
                this.tGroup.SetCursor(this.dataGridView1, entry.nCurrRow);
                this.tAuth.ReOpen();
            }
            entry.Dispose();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.tGroup.FindSql(this.dataGridView1, this.TextFind.Text);
        }

        private void checkShowAllUser_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkShowAllUser.Checked)
            {
                this.tGroup.OpenTable("wb_group", "Select * From wb_group WHERE 1 = 1 ORDER BY coy, location_code", WBData.conn);
                this.tAuth.OpenTable("wb_authorization", "Select * From wb_authorization WHERE 1 = 1", WBData.conn);
                this.dataGridView1.DataSource = this.tGroup.DT;
                this.dataGridView1.Columns["Coy"].Visible = true;
                this.dataGridView1.Columns["Location_Code"].Visible = true;
            }
            else
            {
                this.tGroup.OpenTable("wb_group", "Select * From wb_group", WBData.conn);
                this.tAuth.OpenTable("wb_authorization", "Select * From wb_authorization", WBData.conn);
                this.dataGridView1.DataSource = this.tGroup.DT;
                this.dataGridView1.Columns["Coy"].Visible = false;
                this.dataGridView1.Columns["Location_Code"].Visible = false;
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void copyToOtherLocationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.tGroup.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                int index = this.dataGridView1.CurrentRow.Index;
                FormCopyUserAutho autho = new FormCopyUserAutho {
                    pMode = "COPY",
                    group = this.dataGridView1.CurrentRow.Cells["code"].Value.ToString(),
                    groupName = this.dataGridView1.CurrentRow.Cells["name"].Value.ToString(),
                    table = "auth",
                    Text = "Copy Authorization to Other Locations",
                    label1 = { Text = "Authorization for group " + this.dataGridView1.CurrentRow.Cells["code"].Value.ToString() + " will be copied to:" }
                };
                autho.ShowDialog();
                if (autho.saved)
                {
                    this.tGroup.ReOpen();
                    this.tAuth.ReOpen();
                    this.dataGridView1 = this.tGroup.AfterEdit("EDIT");
                    this.tGroup.SetCursor(this.dataGridView1, index);
                }
                this.tGroup.UnLock();
                autho.Dispose();
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.CurrentRow.Cells["Code"].Value.ToString().Trim() == "ADMIN") && (WBUser.UserGroup != "ADMIN"))
            {
                MessageBox.Show(Resource.Mes_462, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                string str = "";
                this.tGroup.DR = this.tGroup.DT.Rows[this.dataGridView1.CurrentRow.Index];
                str = this.tGroup.DR["code"].ToString();
                WBTable table = new WBTable();
                table.OpenTable("wb_user", "Select * from wb_user where " + WBData.CompanyLocation(" and ((User_Group='" + str + "') and ( ISNULL(Deleted,'')='' or Deleted<>'*' ))"), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    MessageBox.Show(Resource.Mes_461, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    table.Dispose();
                }
                else if (this.tGroup.BeforeEdit(this.dataGridView1, "DELETE"))
                {
                    if (MessageBox.Show(Resource.Mes_455, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        table.Dispose();
                        FormUserGroupEntry entry = new FormUserGroupEntry {
                            pMode = "DELETE",
                            nCurrRow = this.dataGridView1.CurrentRow.Index,
                            tGroup = this.tGroup,
                            tAuth = this.tAuth,
                            tMenu = this.tMenu
                        };
                        entry.ShowDialog();
                        if (entry.Saved)
                        {
                            Cursor.Current = Cursors.WaitCursor;
                            this.tGroup.ReOpen();
                            this.tAuth.ReOpen();
                            Cursor.Current = Cursors.Default;
                            this.tGroup.nCurrRow = 0;
                            this.tGroup.AfterEdit("DELETE");
                        }
                        entry.Dispose();
                    }
                    this.tGroup.UnLock();
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editCommodityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.CurrentRow.Cells["Code"].Value.ToString().Trim() == "ADMIN") && (WBUser.UserGroup != "ADMIN"))
            {
                MessageBox.Show(Resource.Mes_463, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                this.tGroup.BeforeEdit(this.dataGridView1, "EDIT");
                FormUserGroupEntry entry = new FormUserGroupEntry {
                    pMode = "EDIT",
                    pUniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()
                };
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { entry.pUniq };
                entry.nCurrRow = this.tGroup.GetRecNo(aField, aFind);
                entry.tGroup = this.tGroup;
                entry.tAuth = this.tAuth;
                entry.tMenu = this.tMenu;
                this.tGroup.DR = this.tGroup.DT.Rows[entry.nCurrRow];
                entry.pGroup = this.tGroup.DR["code"].ToString();
                entry.ShowDialog();
                if (entry.Saved)
                {
                    Cursor.Current = Cursors.WaitCursor;
                    this.tGroup.ReOpen();
                    this.tAuth.ReOpen();
                    Cursor.Current = Cursors.Default;
                    this.tGroup.nCurrRow = this.tGroup.GetPosRec(entry.pUniq);
                    this.tGroup.AfterEdit("EDIT");
                }
                this.tGroup.UnLock();
                entry.Dispose();
            }
        }

        private void FormUserGroup_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormUserGroup_Load(object sender, EventArgs e)
        {
            this.translate();
            this.tGroup.OpenTable("wb_group", "Select * From wb_group WHERE " + WBData.CompanyLocation(" ORDER BY code ASC"), WBData.conn);
            this.tAuth.OpenTable("wb_authorization", "Select * From wb_authorization WHERE " + WBData.CompanyLocation(" ORDER BY uniq ASC"), WBData.conn);
            this.tMenu.OpenTable("wb_menu", "Select * From wb_menu Where 1=1 order by code", WBData.conn);
            this.dataGridView1.DataSource = this.tGroup.DT;
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Code"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["Code"].Width = 100;
            this.dataGridView1.Columns["Name"].Width = 400;
            if (Convert.ToInt16(WBUser.UserLevel) >= 2)
            {
                this.addCommodityItemToolStripMenuItem.Enabled = false;
                this.editCommodityToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
                this.copyToOtherLocationsToolStripMenuItem.Visible = false;
            }
            else
            {
                this.addCommodityItemToolStripMenuItem.Enabled = true;
                this.editCommodityToolStripMenuItem.Enabled = true;
                this.deleteToolStripMenuItem.Enabled = true;
                this.copyToOtherLocationsToolStripMenuItem.Visible = true;
            }
            this.repairAllChecksumToolStripMenuItem.Visible = WBUser.UserLevel == "1";
            WBTable table = new WBTable();
            table.OpenTable("wb_location", "SELECT COUNT(uniq) AS n FROM wb_location WHERE 1=1", WBData.conn);
            int num = Convert.ToInt16(table.DT.Rows[0]["n"].ToString());
            table.Dispose();
            if (num <= 1)
            {
                this.copyToOtherLocationsToolStripMenuItem.Enabled = false;
            }
            base.KeyPreview = true;
        }

        private void InitializeComponent()
        {
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addCommodityItemToolStripMenuItem = new ToolStripMenuItem();
            this.editCommodityToolStripMenuItem = new ToolStripMenuItem();
            this.copyToOtherLocationsToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.repairAllChecksumToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.panel1 = new Panel();
            this.checkShowAllUser = new CheckBox();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x21e, 0x152);
            this.dataGridView1.TabIndex = 1;
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x21e, 0x18);
            this.menuStrip1.TabIndex = 0x10;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addCommodityItemToolStripMenuItem, this.editCommodityToolStripMenuItem, this.copyToOtherLocationsToolStripMenuItem, this.deleteToolStripMenuItem, this.repairAllChecksumToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.addCommodityItemToolStripMenuItem.Name = "addCommodityItemToolStripMenuItem";
            this.addCommodityItemToolStripMenuItem.Size = new Size(0xcb, 0x16);
            this.addCommodityItemToolStripMenuItem.Text = "Add New Record";
            this.addCommodityItemToolStripMenuItem.Click += new EventHandler(this.addCommodityItemToolStripMenuItem_Click);
            this.editCommodityToolStripMenuItem.Name = "editCommodityToolStripMenuItem";
            this.editCommodityToolStripMenuItem.Size = new Size(0xcb, 0x16);
            this.editCommodityToolStripMenuItem.Text = "Edit Record";
            this.editCommodityToolStripMenuItem.Click += new EventHandler(this.editCommodityToolStripMenuItem_Click);
            this.copyToOtherLocationsToolStripMenuItem.Name = "copyToOtherLocationsToolStripMenuItem";
            this.copyToOtherLocationsToolStripMenuItem.Size = new Size(0xcb, 0x16);
            this.copyToOtherLocationsToolStripMenuItem.Text = "Copy to Other Locations";
            this.copyToOtherLocationsToolStripMenuItem.Click += new EventHandler(this.copyToOtherLocationsToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xcb, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.repairAllChecksumToolStripMenuItem.Name = "repairAllChecksumToolStripMenuItem";
            this.repairAllChecksumToolStripMenuItem.Size = new Size(0xcb, 0x16);
            this.repairAllChecksumToolStripMenuItem.Text = "Repair All Checksum";
            this.repairAllChecksumToolStripMenuItem.Click += new EventHandler(this.repairAllChecksumToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.checkShowAllUser);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x16a);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x21e, 0x21);
            this.panel1.TabIndex = 15;
            this.checkShowAllUser.AutoSize = true;
            this.checkShowAllUser.Location = new Point(0x114, 7);
            this.checkShowAllUser.Name = "checkShowAllUser";
            this.checkShowAllUser.Size = new Size(0x90, 0x11);
            this.checkShowAllUser.TabIndex = 6;
            this.checkShowAllUser.Text = "Show All Group in Server";
            this.checkShowAllUser.UseVisualStyleBackColor = true;
            this.checkShowAllUser.CheckedChanged += new EventHandler(this.checkShowAllUser_CheckedChanged);
            this.TextFind.Location = new Point(5, 3);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.buttonFind.Location = new Point(0xc3, 3);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x21e, 0x18b);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.Name = "FormUserGroup";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "User Group & Authorization";
            base.Load += new EventHandler(this.FormUserGroup_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormUserGroup_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void repairAllChecksumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                int num = 0;
                while (true)
                {
                    if (num >= this.tAuth.DT.Rows.Count)
                    {
                        MessageBox.Show(Resource.Mes_454, Resource.Title_007);
                        break;
                    }
                    this.tAuth.DR = this.tAuth.DT.Rows[num];
                    this.logKey = this.tAuth.DR["uniq"].ToString();
                    this.tAuth.DR.BeginEdit();
                    this.tAuth.DR["checksum"] = this.tAuth.Checksum(this.tAuth.DR);
                    this.tAuth.DR.EndEdit();
                    this.tAuth.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Repair checksum" };
                    Program.updateLogHeader("wb_authorization", this.logKey, logField, logValue);
                    num++;
                }
            }
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addCommodityItemToolStripMenuItem.Text = Resource.Menu_Add;
            this.editCommodityToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
        }
    }
}

