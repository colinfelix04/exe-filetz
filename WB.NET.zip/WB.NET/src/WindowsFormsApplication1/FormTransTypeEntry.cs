﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTransTypeEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private Button button2;
        private Button button1;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label2;
        private Label label1;
        private Label label3;
        private ComboBox comboBox1;
        private Label label4;
        private Label label5;
        private Label label6;
        private CheckBox checkBoxAdoptSAP;
        private CheckBox checkbox_is_vessel;
        private ToolTip toolTipInfo;
        private CheckBox chk_is_return;
        private CheckBox chk_req_internal_no;
        private CheckBox cMSinTrx;

        public FormTransTypeEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            TextBox[] aText = new TextBox[] { this.textBox1, this.textBox2 };
            if (!Program.CheckEmpty(aText))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_transaction_type", "Select Uniq From wb_transaction_type Where " + WBData.CompanyLocation(" and (Transaction_Code='" + this.textBox1.Text.Trim() + "')"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    if (this.chk_is_return.Checked)
                    {
                        table.OpenTable("wb_transaction_type", "Select * From wb_transaction_type Where " + WBData.CompanyLocation(" and (IO ='" + this.comboBox1.Text.Trim().ToUpper() + "' AND is_return = 'Y')"), WBData.conn);
                        if ((table.DT.Rows.Count > 0) && ((this.pMode == "ADD") || ((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                        {
                            table.Dispose();
                            MessageBox.Show(Resource.Mes_Return_Transaction_Type_Exist);
                            this.textBox1.Focus();
                            return;
                        }
                    }
                    table.Dispose();
                    Cursor.Current = Cursors.WaitCursor;
                    this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                    if ((this.pMode != "EDIT") || (this.textBox1.Text.Trim() == this.OldCode.Trim()))
                    {
                        goto TR_001F;
                    }
                    else
                    {
                        table2 = new WBTable();
                        table2.OpenTable("wb_transaction", "Select uniq From wb_transaction where " + WBData.Company(" and ( Transaction_Code='" + this.OldCode.Trim() + "')"), WBData.conn);
                        WBTable table3 = new WBTable();
                        table3.OpenTable("wb_contract", "Select uniq From wb_contract where " + WBData.Company(" and ( Transaction_Code='" + this.OldCode.Trim() + "')"), WBData.conn);
                        Cursor.Current = Cursors.Default;
                        if (table2.DT.Rows.Count <= 0)
                        {
                            goto TR_0020;
                        }
                        else
                        {
                            string[] textArray1 = new string[15];
                            textArray1[0] = Resource.Mes_Confirm_Edit_Transaction_Type;
                            textArray1[1] = " ";
                            textArray1[2] = this.OldCode;
                            textArray1[3] = " -> ";
                            textArray1[4] = this.textBox1.Text;
                            textArray1[5] = "\n\n";
                            textArray1[6] = Resource.Msg_Replace_Warning;
                            textArray1[7] = "\n - ";
                            textArray1[8] = table2.DT.Rows.Count.ToString();
                            textArray1[9] = Resource.Mes_Records_In_Transaction;
                            textArray1[10] = "\n - ";
                            textArray1[11] = table3.DT.Rows.Count.ToString();
                            textArray1[12] = Resource.Mes_Records_In_Contract;
                            textArray1[13] = "\n\n";
                            textArray1[14] = Resource.Mes_Confirm_Continue;
                            if (MessageBox.Show(string.Concat(textArray1), Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.ReplaceAll = true;
                                goto TR_0020;
                            }
                            else
                            {
                                this.ReplaceAll = false;
                                this.textBox1.Focus();
                            }
                        }
                    }
                    return;
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_240);
                    this.textBox1.Focus();
                    return;
                }
            }
            else
            {
                return;
            }
            goto TR_0020;
        TR_001F:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.TransType_001 },
                    textRefNo = { Text = this.textBox1.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["AdoptSAP"] = this.checkBoxAdoptSAP.Checked ? "Y" : "N";
            this.zTable.DR["Transaction_Code"] = this.textBox1.Text;
            this.zTable.DR["Transaction_Name"] = this.textBox2.Text;
            this.zTable.DR["IO"] = this.comboBox1.Text.Trim().ToUpper();
            this.zTable.DR["is_vessel"] = this.checkbox_is_vessel.Checked ? "Y" : "N";
            this.zTable.DR["is_return"] = this.chk_is_return.Checked ? "Y" : "N";
            this.zTable.DR["trx_require_internal_no"] = this.chk_req_internal_no.Checked ? "Y" : "N";
            this.zTable.DR["MS_in_Trx"] = this.cMSinTrx.Checked ? "Y" : "N";
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table4 = new WBTable();
                    table4.OpenTable("wb_transaction_type", "SELECT uniq FROM wb_transaction_type WHERE " + WBData.CompanyLocation(" AND transaction_code = '" + this.textBox1.Text + "'"), WBData.conn);
                    this.logKey = table4.DT.Rows[0]["uniq"].ToString();
                    table4.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_transaction_type", this.logKey, logField, logValue);
            }
            string str = "";
            if (this.pMode == "ADD")
            {
                string[] textArray4 = new string[] { "(Triggered add new transaction type in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                str = string.Concat(textArray4);
            }
            else if (this.pMode == "EDIT")
            {
                string[] textArray5 = new string[] { "(Triggered edit transaction type in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                str = string.Concat(textArray5);
            }
            Program.copyToLoc("wb_transaction_type", this.textBox1.Text, 0, this.changeReason + " " + str);
            if ((this.pMode == "EDIT") && (this.textBox1.Text != this.OldCode))
            {
                Program.copyToLoc("wb_transaction_type", this.OldCode, 0, this.changeReason + " " + str);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string[] aField = new string[] { "Transaction_Code" };
                string[] aNewValue = new string[] { this.textBox1.Text };
                Program.ReplaceInCompany("wb_transaction", aField, aNewValue, " Transaction_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit transaction type master data)");
                string[] textArray8 = new string[] { "Transaction_Code" };
                string[] textArray9 = new string[] { this.textBox1.Text };
                Program.ReplaceInCompany("wb_contract", textArray8, textArray9, " Transaction_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit transaction type master data)");
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            base.Close();
            return;
        TR_0020:
            table2.Dispose();
            goto TR_001F;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransTypeEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTransTypeEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.pMode != "ADD")
            {
                this.textBox1.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Transaction_Code"].Value.ToString();
                this.OldCode = this.textBox1.Text;
                this.textBox2.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Transaction_Name"].Value.ToString();
                this.comboBox1.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["IO"].Value.ToString();
                this.checkBoxAdoptSAP.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["AdoptSAP"].Value.ToString() == "Y";
                this.checkbox_is_vessel.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["is_vessel"].Value.ToString() == "Y";
                this.chk_is_return.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["is_return"].Value.ToString() == "Y";
                this.chk_req_internal_no.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["trx_require_internal_no"].Value.ToString() == "Y";
                this.cMSinTrx.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["MS_in_Trx"].Value.ToString() == "Y";
            }
            if (this.pMode == "VIEW")
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.button2.Text = Resource.Btn_Close;
                this.button2.Enabled = true;
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.button2 = new Button();
            this.button1 = new Button();
            this.textBox2 = new TextBox();
            this.textBox1 = new TextBox();
            this.label2 = new Label();
            this.label1 = new Label();
            this.label3 = new Label();
            this.comboBox1 = new ComboBox();
            this.label4 = new Label();
            this.label5 = new Label();
            this.label6 = new Label();
            this.checkBoxAdoptSAP = new CheckBox();
            this.checkbox_is_vessel = new CheckBox();
            this.toolTipInfo = new ToolTip(this.components);
            this.chk_is_return = new CheckBox();
            this.cMSinTrx = new CheckBox();
            this.chk_req_internal_no = new CheckBox();
            base.SuspendLayout();
            this.button2.Location = new Point(0x7e, 0x9a);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 4;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(15, 0x9a);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 3;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBox2.Location = new Point(0x6d, 0x31);
            this.textBox2.MaxLength = 50;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x166, 20);
            this.textBox2.TabIndex = 1;
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(0x6d, 0x17);
            this.textBox1.MaxLength = 10;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0x4e, 20);
            this.textBox1.TabIndex = 0;
            this.label2.Location = new Point(9, 0x34);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x5e, 13);
            this.label2.TabIndex = 0x4e;
            this.label2.Text = "Transaction Name";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.label1.Location = new Point(9, 0x19);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x5e, 13);
            this.label1.TabIndex = 0x4d;
            this.label1.Text = "Transaction Code";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.label3.Location = new Point(9, 0x4e);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x5e, 13);
            this.label3.TabIndex = 0x4f;
            this.label3.Text = "Type";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.comboBox1.FormattingEnabled = true;
            object[] items = new object[] { "I ", "O", "X" };
            this.comboBox1.Items.AddRange(items);
            this.comboBox1.Location = new Point(0x6d, 0x4b);
            this.comboBox1.MaxLength = 1;
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new Size(0x22, 0x15);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.Text = "I";
            this.label4.AutoSize = true;
            this.label4.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label4.Location = new Point(0x9a, 0x4b);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x2f, 15);
            this.label4.TabIndex = 0x51;
            this.label4.Text = "I - Input";
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(0x95, 90);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x3e, 15);
            this.label5.TabIndex = 0x52;
            this.label5.Text = "O - Output";
            this.label6.AutoSize = true;
            this.label6.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label6.Location = new Point(0x95, 0x69);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x3d, 15);
            this.label6.TabIndex = 0x53;
            this.label6.Text = "X - Others";
            this.checkBoxAdoptSAP.AutoSize = true;
            this.checkBoxAdoptSAP.Location = new Point(0xd0, 0x18);
            this.checkBoxAdoptSAP.Name = "checkBoxAdoptSAP";
            this.checkBoxAdoptSAP.Size = new Size(260, 0x11);
            this.checkBoxAdoptSAP.TabIndex = 0x54;
            this.checkBoxAdoptSAP.Text = "Require Master Data Contract to Adopt From ";
            this.toolTipInfo.SetToolTip(this.checkBoxAdoptSAP, "DO with this Transaction type must Adopt from ");
            this.checkBoxAdoptSAP.UseVisualStyleBackColor = true;
            this.checkbox_is_vessel.AutoSize = true;
            this.checkbox_is_vessel.Location = new Point(0x11b, 0x4d);
            this.checkbox_is_vessel.Name = "checkbox_is_vessel";
            this.checkbox_is_vessel.Size = new Size(0xb8, 0x11);
            this.checkbox_is_vessel.TabIndex = 0x55;
            this.checkbox_is_vessel.Text = "Main DO for Auto Split DO Vessel";
            this.toolTipInfo.SetToolTip(this.checkbox_is_vessel, "This DO will be used as Main DO for AutoSplit DO vessel.\r\nThis DO cannot be used unless it have been mapped to its DO Details.");
            this.checkbox_is_vessel.UseVisualStyleBackColor = true;
            this.chk_is_return.AutoSize = true;
            this.chk_is_return.Location = new Point(0x11b, 100);
            this.chk_is_return.Name = "chk_is_return";
            this.chk_is_return.Size = new Size(0x90, 0x11);
            this.chk_is_return.TabIndex = 0x56;
            this.chk_is_return.Text = "Return Transaction Type";
            this.toolTipInfo.SetToolTip(this.chk_is_return, "This DO will be used as Main DO for AutoSplit DO vessel.\r\nThis DO cannot be used unless it have been mapped to its DO Details.");
            this.chk_is_return.UseVisualStyleBackColor = true;
            this.cMSinTrx.AutoSize = true;
            this.cMSinTrx.Location = new Point(0x11b, 0x90);
            this.cMSinTrx.Name = "cMSinTrx";
            this.cMSinTrx.Size = new Size(0xe3, 0x11);
            this.cMSinTrx.TabIndex = 0x58;
            this.cMSinTrx.Text = "Insert Material Stuffing in Form Transaction";
            this.toolTipInfo.SetToolTip(this.cMSinTrx, "This DO will be used as Main DO for AutoSplit DO vessel.\r\nThis DO cannot be used unless it have been mapped to its DO Details.");
            this.cMSinTrx.UseVisualStyleBackColor = true;
            this.chk_req_internal_no.AutoSize = true;
            this.chk_req_internal_no.Location = new Point(0x11b, 0x79);
            this.chk_req_internal_no.Name = "chk_req_internal_no";
            this.chk_req_internal_no.Size = new Size(0xb6, 0x11);
            this.chk_req_internal_no.TabIndex = 0x57;
            this.chk_req_internal_no.Text = "Required DO SAP in Transaction";
            this.chk_req_internal_no.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x205, 0xc6);
            base.ControlBox = false;
            base.Controls.Add(this.cMSinTrx);
            base.Controls.Add(this.chk_req_internal_no);
            base.Controls.Add(this.chk_is_return);
            base.Controls.Add(this.checkbox_is_vessel);
            base.Controls.Add(this.checkBoxAdoptSAP);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.comboBox1);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Name = "FormTransTypeEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormTransTypeEntry";
            base.Load += new EventHandler(this.FormTransTypeEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransTypeEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label1.Text = Resource.TransType_001;
            this.label2.Text = Resource.TransType_002;
            this.label4.Text = Resource.TransType_003;
            this.label5.Text = Resource.TransType_004;
            this.label6.Text = Resource.TransType_005;
            this.label3.Text = Resource.TransType_006;
            this.button1.Text = Resource.Btn_Save;
            this.button2.Text = Resource.Btn_Cancel;
            this.checkBoxAdoptSAP.Text = Resource.Chk_Adopt_SAP + this.sapIDSYS;
            this.checkbox_is_vessel.Text = Resource.Chk_Is_Vessel;
            this.chk_is_return.Text = Resource.Chk_Is_Return;
            this.cMSinTrx.Text = Resource.Chk_MS_In_Trx;
            this.chk_req_internal_no.Text = WBSetting.integrationIDSYS ? Resource.Chk_Req_Internal_No_IDSYS : Resource.Chk_Req_Internal_No;
            this.Text = Resource.Title_TransTypeEntry;
            this.toolTipInfo.SetToolTip(this.checkBoxAdoptSAP, Resource.Ttp_Chk_Adopt_SAP + this.sapIDSYS);
            this.toolTipInfo.SetToolTip(this.checkbox_is_vessel, Resource.Ttp_Chk_Is_Vessel + "\r\n" + Resource.Ttp_DO_Mapped_Details);
            this.toolTipInfo.SetToolTip(this.chk_is_return, Resource.Ttp_Chk_Is_Vessel + "\r\n" + Resource.Ttp_DO_Mapped_Details);
            this.toolTipInfo.SetToolTip(this.cMSinTrx, Resource.Ttp_Chk_Is_Vessel + "\r\n" + Resource.Ttp_DO_Mapped_Details);
        }
    }
}

