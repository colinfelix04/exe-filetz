﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTransDeducUnitEntry : Form
    {
        public string UOM = "";
        public string DO_NO = "";
        public double qtyUOM = 0.0;
        public DataGridView dgvDO;
        public bool saved = false;
        private IContainer components = null;
        private StatusStrip statusStrip1;
        private Button button2;
        private Button buttonSave;
        private Panel panel1;
        private Label label1;
        private Panel panel2;
        private Label label2;
        private TextBox textBoxTotalDeduc;
        public DataGridView dgvDODeduc;
        private Label label5;
        private TextBox textBoxAverageWeight;
        private Label label6;
        private TextBox textBoxTotalQty;
        private Label label4;

        public FormTransDeducUnitEntry()
        {
            this.InitializeComponent();
            this.dgvDODeduc.AutoGenerateColumns = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.saved = false;
            base.Close();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            this.saved = true;
            base.Close();
        }

        private void calculateTotalDeduc(int p)
        {
            double num2 = 0.0;
            double num5 = 0.0;
            if (this.dgvDODeduc.Rows[p].Cells["WeightPerUnitName"].Value.ToString() == "")
            {
                this.dgvDODeduc.Rows[p].Cells["WeightPerUnitName"].Value = "0";
            }
            if (this.dgvDODeduc.Rows[p].Cells["DeducUnitQty"].Value.ToString() == "")
            {
                this.dgvDODeduc.Rows[p].Cells["DeducUnitQty"].Value = "0";
            }
            this.dgvDODeduc.Rows[p].Cells["TotalDeducUnit"].Value = Math.Round((double) (Program.StrToDouble(this.dgvDODeduc.Rows[p].Cells["WeightPerUnitName"].Value.ToString(), 2) * Program.StrToDouble(this.dgvDODeduc.Rows[p].Cells["DeducUnitQty"].Value.ToString(), 0)), 0).ToString();
            foreach (DataGridViewRow row in (IEnumerable) this.dgvDODeduc.Rows)
            {
                num2 += Program.StrToDouble(row.Cells["TotalDeducUnit"].Value.ToString(), 0);
                num5 += Program.StrToDouble(row.Cells["DeducUnitQty"].Value.ToString(), 0);
            }
            this.textBoxTotalDeduc.Text = $"{num2:N0}";
            this.textBoxTotalQty.Text = $"{num5:N0}";
            this.textBoxAverageWeight.Text = $"{Math.Round((double) (num2 / num5), 2):N2}";
        }

        private void CopyAll(DataGridView from, DataGridView to)
        {
            if (to.Columns.Count == 0)
            {
                foreach (DataGridViewColumn column in from.Columns)
                {
                    to.Columns.Add(column.Name, column.HeaderText);
                }
            }
            to.Rows.Clear();
            using (IEnumerator enumerator2 = ((IEnumerable) from.Rows).GetEnumerator())
            {
                List<string> list;
                goto TR_0017;
            TR_000D:
                to.Rows.Add(list.ToArray());
            TR_0017:
                while (true)
                {
                    if (!enumerator2.MoveNext())
                    {
                        break;
                    }
                    DataGridViewRow current = (DataGridViewRow) enumerator2.Current;
                    list = new List<string>();
                    foreach (DataGridViewCell cell in current.Cells)
                    {
                        try
                        {
                            list.Add(cell.Value.ToString());
                        }
                        catch
                        {
                            list.Add("");
                        }
                    }
                    goto TR_000D;
                }
            }
        }

        private void dgvDODeduc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dgvDODeduc_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            this.calculateTotalDeduc(e.RowIndex);
        }

        private void dgvDODeduc_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (this.dgvDODeduc.Columns[e.ColumnIndex].Name.ToString().ToUpper() == "DeducUnitQty".ToUpper())
            {
                int num;
                if (!int.TryParse(Convert.ToString(e.FormattedValue), out num))
                {
                    e.Cancel = true;
                    MessageBox.Show("Please Entry Numeric Only!!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            else
            {
                float num2;
                if ((this.dgvDODeduc.Columns[e.ColumnIndex].Name.ToString().ToUpper() == "WeightPerUnitName".ToUpper()) && !float.TryParse(Convert.ToString(e.FormattedValue), out num2))
                {
                    e.Cancel = true;
                    MessageBox.Show("Please Entry Numeric Only!!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransEntryDeduction_Load(object sender, EventArgs e)
        {
            this.CopyAll(this.dgvDO, this.dgvDODeduc);
            foreach (DataGridViewColumn column in this.dgvDODeduc.Columns)
            {
                column.ReadOnly = false;
                column.Visible = false;
                column.DefaultCellStyle.BackColor = Color.White;
            }
            foreach (DataGridViewColumn column2 in this.dgvDODeduc.Columns)
            {
                column2.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            this.dgvDODeduc.Columns["Do_No"].Visible = true;
            this.dgvDODeduc.Columns["Do_No"].DefaultCellStyle.BackColor = Color.LightGray;
            this.dgvDODeduc.Columns["Do_No"].ReadOnly = true;
            this.dgvDODeduc.Columns["WeightPerUnitName"].Visible = true;
            this.dgvDODeduc.Columns["WeightPerUnitName"].HeaderText = "Weight/Unit Deduction (KG)";
            this.dgvDODeduc.Columns["DeducUnitQty"].Visible = true;
            this.dgvDODeduc.Columns["DeducUnitQty"].HeaderText = "Qty Unit Deduction";
            this.dgvDODeduc.Columns["UnitName"].Visible = true;
            this.dgvDODeduc.Columns["UnitName"].HeaderText = "Unit Name";
            this.dgvDODeduc.Columns["TotalDeducUnit"].Visible = true;
            this.dgvDODeduc.Columns["TotalDeducUnit"].HeaderText = "Total Unit Dedution (KG)";
            this.dgvDODeduc.Columns["TotalDeducUnit"].ReadOnly = true;
            this.dgvDODeduc.Columns["TotalDeducUnit"].DefaultCellStyle.BackColor = Color.LightGray;
            this.dgvDODeduc.Refresh();
            if (this.dgvDODeduc.Rows.Count > 0)
            {
                this.calculateTotalDeduc(0);
            }
            this.translate();
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.statusStrip1 = new StatusStrip();
            this.button2 = new Button();
            this.buttonSave = new Button();
            this.panel1 = new Panel();
            this.label5 = new Label();
            this.textBoxAverageWeight = new TextBox();
            this.label6 = new Label();
            this.textBoxTotalQty = new TextBox();
            this.label4 = new Label();
            this.label2 = new Label();
            this.textBoxTotalDeduc = new TextBox();
            this.label1 = new Label();
            this.panel2 = new Panel();
            this.dgvDODeduc = new DataGridView();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dgvDODeduc).BeginInit();
            base.SuspendLayout();
            this.statusStrip1.Location = new Point(0, 350);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(0x2ae, 0x16);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            this.button2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x246, 0x2e);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x5c, 0x27);
            this.button2.TabIndex = 7;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.buttonSave.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonSave.Location = new Point(0x1e1, 0x2e);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x5c, 0x27);
            this.buttonSave.TabIndex = 6;
            this.buttonSave.Text = "&Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.textBoxAverageWeight);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.textBoxTotalQty);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textBoxTotalDeduc);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.buttonSave);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0xfb);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x2ae, 0x63);
            this.panel1.TabIndex = 8;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0xb3, 20);
            this.label5.Name = "label5";
            this.label5.Size = new Size(20, 13);
            this.label5.TabIndex = 0x10;
            this.label5.Text = "Kg";
            this.textBoxAverageWeight.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textBoxAverageWeight.Location = new Point(120, 0x11);
            this.textBoxAverageWeight.Name = "textBoxAverageWeight";
            this.textBoxAverageWeight.ReadOnly = true;
            this.textBoxAverageWeight.Size = new Size(0x35, 20);
            this.textBoxAverageWeight.TabIndex = 15;
            this.textBoxAverageWeight.Text = "0";
            this.textBoxAverageWeight.TextAlign = HorizontalAlignment.Right;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x15, 20);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x54, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Average Weight";
            this.textBoxTotalQty.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textBoxTotalQty.Location = new Point(120, 0x2b);
            this.textBoxTotalQty.Name = "textBoxTotalQty";
            this.textBoxTotalQty.ReadOnly = true;
            this.textBoxTotalQty.Size = new Size(0x35, 20);
            this.textBoxTotalQty.TabIndex = 12;
            this.textBoxTotalQty.Text = "0";
            this.textBoxTotalQty.TextAlign = HorizontalAlignment.Right;
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x15, 0x2e);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x49, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Total Quantity";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0xd4, 0x48);
            this.label2.Name = "label2";
            this.label2.Size = new Size(20, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Kg";
            this.textBoxTotalDeduc.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textBoxTotalDeduc.Location = new Point(120, 0x45);
            this.textBoxTotalDeduc.Name = "textBoxTotalDeduc";
            this.textBoxTotalDeduc.ReadOnly = true;
            this.textBoxTotalDeduc.Size = new Size(0x56, 20);
            this.textBoxTotalDeduc.TabIndex = 9;
            this.textBoxTotalDeduc.Text = "0";
            this.textBoxTotalDeduc.TextAlign = HorizontalAlignment.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x15, 0x48);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x53, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Total Deduction";
            this.panel2.Dock = DockStyle.Top;
            this.panel2.Location = new Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x2ae, 0x2b);
            this.panel2.TabIndex = 9;
            this.dgvDODeduc.AllowUserToAddRows = false;
            this.dgvDODeduc.AllowUserToDeleteRows = false;
            this.dgvDODeduc.AllowUserToResizeRows = false;
            this.dgvDODeduc.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDODeduc.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgvDODeduc.ColumnHeadersDefaultCellStyle = style;
            this.dgvDODeduc.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgvDODeduc.DefaultCellStyle = style2;
            this.dgvDODeduc.Dock = DockStyle.Fill;
            this.dgvDODeduc.EditMode = DataGridViewEditMode.EditOnKeystroke;
            this.dgvDODeduc.Location = new Point(0, 0x2b);
            this.dgvDODeduc.MultiSelect = false;
            this.dgvDODeduc.Name = "dgvDODeduc";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgvDODeduc.RowHeadersDefaultCellStyle = style3;
            this.dgvDODeduc.SelectionMode = DataGridViewSelectionMode.CellSelect;
            this.dgvDODeduc.Size = new Size(0x2ae, 0xd0);
            this.dgvDODeduc.TabIndex = 10;
            this.dgvDODeduc.CellContentClick += new DataGridViewCellEventHandler(this.dgvDODeduc_CellContentClick);
            this.dgvDODeduc.CellEndEdit += new DataGridViewCellEventHandler(this.dgvDODeduc_CellEndEdit);
            this.dgvDODeduc.CellValidating += new DataGridViewCellValidatingEventHandler(this.dgvDODeduc_CellValidating);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x2ae, 0x174);
            base.ControlBox = false;
            base.Controls.Add(this.dgvDODeduc);
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.statusStrip1);
            base.Name = "FormTransDeducUnitEntry";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Entry Deduction";
            base.Load += new EventHandler(this.FormTransEntryDeduction_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((ISupportInitialize) this.dgvDODeduc).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.Text = Resource.DeductionPerUnit_007;
            this.dgvDODeduc.Columns["Do_No"].HeaderText = Resource.RegisGatepassEntry_009;
            this.dgvDODeduc.Columns["WeightPerUnitName"].HeaderText = Resource.DeductionPerUnit_003;
            this.dgvDODeduc.Columns["DeducUnitQty"].HeaderText = Resource.DeductionPerUnit_004;
            this.dgvDODeduc.Columns["UnitName"].HeaderText = Resource.DeductionPerUnit_005;
            this.dgvDODeduc.Columns["TotalDeducUnit"].HeaderText = Resource.DeductionPerUnit_006;
            this.label6.Text = Resource.Trans_072;
            this.label4.Text = Resource.DeductionPerUnit_001;
            this.label1.Text = Resource.DeductionPerUnit_002;
            this.buttonSave.Text = Resource.Btn_Save;
            this.button2.Text = Resource.Btn_Cancel;
        }
    }
}

