﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class RepFailSync : Form
    {
        private IContainer components = null;
        public DateTimePicker monthCalendar1;
        public Label label5;
        public Button butClose;
        public Button butProcess;
        public Label label3;
        public CheckBox checkDate;
        public DateTimePicker monthCalendar2;
        public Label label6;
        public GroupBox groupBox1;
        public CheckBox cb_master_data;
        public CheckBox cb_send_via_email;
        private GroupBox groupBox2;
        private RadioButton detailRadio;
        private RadioButton summaryRadio;
        private CheckBox checkSync;
        private CheckBox checkCoyLoc;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private RadioButton radioComm;
        private RadioButton radioRef;

        public RepFailSync()
        {
            this.InitializeComponent();
        }

        private void butClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void butProcess_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days <= 31.0)
            {
                string str;
                HTML html2;
                HTML html = new HTML();
                if (this.detailRadio.Checked)
                {
                    str = (("SELECT a.ref, a.ref_date, a.sync_return, a.Do_No, a.Transaction_Code, a.report_date, a.lastUpload, b.Comm_Code, b.Comm_Name, b.postSAP " + " FROM wb_transaction a, wb_commodity b " + " WHERE a.Comm_Code = b.Comm_Code ") + " AND a.Coy = b.Coy " + " AND a.Location_Code = b.Location_Code ") + " AND (a.deleted = '' or a.deleted IS NULL) " + " AND a.report_date IS NOT NULL ";
                    if (this.checkDate.Checked)
                    {
                        str = (str + " AND a.report_date >= '" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00' ") + " AND a.report_date <= '" + this.monthCalendar2.Value.ToString("yyyy-MM-dd") + " 00:00:00' ";
                    }
                    if (!this.checkCoyLoc.Checked)
                    {
                        str = (str + " AND a.Coy = '" + WBData.sCoyCode + "'") + " AND a.Location_Code = '" + WBData.sLocCode + "'";
                    }
                    if (!this.checkSync.Checked)
                    {
                        str = str + " AND (a.sync_return IS NOT NULL OR a.sync_return != '') ";
                    }
                    str = (str + " AND (a.posted IS NULL OR a.posted ='N') ") + " AND  b.postSAP = 'Y' " + " AND  (a.NonContract IS NULL OR a.Noncontract = 'N' OR a.NonContract ='') ";
                    if (this.radioRef.Checked)
                    {
                        str = str + " ORDER BY a.coy, a.location_code, a.Ref";
                    }
                    else if (this.radioComm.Checked)
                    {
                        str = str + " ORDER BY a.coy, a.location_code, b.comm_code, a.Ref";
                    }
                    WBTable table = new WBTable();
                    table.OpenTable("vw_trans", str, WBData.conn);
                    if ((table.DT.Rows.Count > 0) || this.cb_master_data.Checked)
                    {
                        html2 = html;
                        string[] textArray1 = new string[] { html2.File, @"\", WBUser.UserID, "_Fail", DateTime.Today.ToString("dd_MM_yyyy"), ".htm" };
                        html2.File = string.Concat(textArray1);
                        html.Title = "FAIL SYNCHRONIZE REPORT";
                        html.Open();
                        html.Write(html.Style());
                        html.Write("<br><font size=5><b>FAIL SYNCHRONIZE REPORT</b></font><br>");
                        if (this.checkCoyLoc.Checked)
                        {
                            html.Write("<br><font size=4>For All Company & Location</font>");
                        }
                        else
                        {
                            string[] textArray2 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                            html.Write(string.Concat(textArray2));
                            string[] textArray3 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                            html.Write(string.Concat(textArray3));
                            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                            {
                                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                            }
                            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                            {
                                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                            }
                            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                            {
                                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                            }
                        }
                        html.Write("<br><br>");
                        html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                        if (this.checkDate.Checked)
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>Selected Date</td>");
                            html.Write("<td>: <b>" + this.monthCalendar1.Value.ToShortDateString() + "</b></td>");
                            html.Write("</tr>");
                        }
                        html.Write("<tr class=bd>");
                        html.Write("<td>Report Date</td>");
                        html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                        html.Write("</tr>");
                        html.Write("</table>");
                        html.Write("<br/><br/><br/>");
                        html.Write("<b><font size=3>FAIL TRANSACTION - DETAIL LIST</font></b><br><br>");
                        html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                        html.Write("<tr class='bd'>");
                        html.Write("<td align=center><b>No.</b></td>");
                        html.Write("<td align=center><b>Ref No</b></td>");
                        html.Write("<td align=center><b>Ref Date</b></td>");
                        html.Write("<td align=center><b>Tx</b></td>");
                        html.Write("<td align=center><b>DO No</b></td>");
                        html.Write("<td align=center><b>Commodity Code</b></td>");
                        html.Write("<td align=center><b>Commodity Name</b></td>");
                        html.Write("<td align=center><b>Last Upload</b></td>");
                        html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                        html.Write("</tr>");
                        int num2 = 0;
                        foreach (DataRow row in table.DT.Rows)
                        {
                            num2++;
                            html.Write("<tr class='bd'>");
                            html.Write("<td align=right>" + num2.ToString() + "</td>");
                            html.Write("<td align=left>" + row["ref"].ToString() + "</td>");
                            html.Write("<td align=left>" + row["Ref_Date"].ToString().Substring(0, 10) + "</td>");
                            html.Write("<td align=center>" + row["Transaction_Code"].ToString() + "</td>");
                            html.Write("<td align=left>" + row["Do_No"].ToString() + "</td>");
                            html.Write("<td>" + row["Comm_Code"].ToString() + "</td>");
                            html.Write("<td>" + row["Comm_Name"].ToString() + "</td>");
                            if (row["lastUpload"].ToString() == "")
                            {
                                html.Write("<td>&nbsp;</td>");
                            }
                            else
                            {
                                html.Write("<td>" + row["lastUpload"].ToString() + "</td>");
                            }
                            if (row["sync_return"].ToString() == "")
                            {
                                html.Write("<td><i>Not sync yet</i></td>");
                            }
                            else
                            {
                                html.Write("<td>" + row["sync_return"].ToString() + "</td>");
                            }
                            html.Write("</tr>");
                        }
                        html.Write("</table>");
                        html.Write("<br><br><br>");
                        if (this.cb_master_data.Checked)
                        {
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_estate", "SELECT estate_code, sync_return FROM wb_estate WHERE " + Sync.where_con + " ORDER BY estate_code", WBData.conn);
                            if (table2.DT.Rows.Count > 0)
                            {
                                html.Write("<br><br><b>MASTER DATA ESTATE</b>");
                                html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                html.Write("<tr class='bd'>");
                                html.Write("<td align=center><b>No.</b></td>");
                                html.Write("<td align=center><b>Estate Code</b></td>");
                                html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                html.Write("</tr>");
                                num2 = 0;
                                foreach (DataRow row2 in table2.DT.Rows)
                                {
                                    num2++;
                                    html.Write("<tr class='bd'>");
                                    html.Write("<td align=right>" + num2.ToString() + "</td>");
                                    html.Write("<td align=left>" + row2[0].ToString() + "</td>");
                                    if (row2["sync_return"].ToString() == "")
                                    {
                                        html.Write("<td align=left>&nbsp</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td align=left>" + row2["sync_return"].ToString() + "</td>");
                                    }
                                    html.Write("</tr>");
                                }
                                html.Write("</table>");
                            }
                            WBTable table3 = new WBTable();
                            table3.OpenTable("wb_truck", "SELECT truck_number, sync_return FROM wb_truck WHERE " + Sync.where_con + " ORDER BY truck_number", WBData.conn);
                            if (table3.DT.Rows.Count > 0)
                            {
                                html.Write("<br><br><b>MASTER DATA TRUCK</b>");
                                html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                html.Write("<tr class='bd'>");
                                html.Write("<td align=center><b>No.</b></td>");
                                html.Write("<td align=center><b>Truck No</b></td>");
                                html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                html.Write("</tr>");
                                num2 = 0;
                                foreach (DataRow row3 in table3.DT.Rows)
                                {
                                    num2++;
                                    html.Write("<tr class='bd'>");
                                    html.Write("<td align=right>" + num2.ToString() + "</td>");
                                    html.Write("<td align=left>" + row3[0].ToString() + "</td>");
                                    if (row3["sync_return"].ToString() == "")
                                    {
                                        html.Write("<td align=left>&nbsp</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td align=left>" + row3["sync_return"].ToString() + "</td>");
                                    }
                                    html.Write("</tr>");
                                }
                                html.Write("</table>");
                            }
                            WBTable table4 = new WBTable();
                            table4.OpenTable("wb_transporter", "SELECT transporter_code, sync_return FROM wb_transporter WHERE " + Sync.where_con + " ORDER BY transporter_code", WBData.conn);
                            if (table4.DT.Rows.Count > 0)
                            {
                                html.Write("<br><br><b>MASTER DATA TRANSPORTER</b>");
                                html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                html.Write("<tr class='bd'>");
                                html.Write("<td align=center><b>No.</b></td>");
                                html.Write("<td align=center><b>Transporter Code</b></td>");
                                html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                html.Write("</tr>");
                                num2 = 0;
                                foreach (DataRow row4 in table4.DT.Rows)
                                {
                                    num2++;
                                    html.Write("<tr class='bd'>");
                                    html.Write("<td align=right>" + num2.ToString() + "</td>");
                                    html.Write("<td align=left>" + row4[0].ToString() + "</td>");
                                    if (row4["sync_return"].ToString() == "")
                                    {
                                        html.Write("<td align=left>&nbsp</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td align=left>" + row4["sync_return"].ToString() + "</td>");
                                    }
                                    html.Write("</tr>");
                                }
                                html.Write("</table>");
                            }
                            WBTable table5 = new WBTable();
                            table5.OpenTable("wb_driver", "SELECT license_no, sync_return FROM wb_driver WHERE " + Sync.where_con + " ORDER BY license_no", WBData.conn);
                            if (table5.DT.Rows.Count > 0)
                            {
                                html.Write("<br><br><b>MASTER DATA DRIVER</b>");
                                html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                html.Write("<tr class='bd'>");
                                html.Write("<td align=center><b>No.</b></td>");
                                html.Write("<td align=center><b>Driver ID</b></td>");
                                html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                html.Write("</tr>");
                                num2 = 0;
                                foreach (DataRow row5 in table5.DT.Rows)
                                {
                                    num2++;
                                    html.Write("<tr class='bd'>");
                                    html.Write("<td align=right>" + num2.ToString() + "</td>");
                                    html.Write("<td align=left>" + row5[0].ToString() + "</td>");
                                    if (row5["sync_return"].ToString() == "")
                                    {
                                        html.Write("<td align=left>&nbsp</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td align=left>" + row5["sync_return"].ToString() + "</td>");
                                    }
                                    html.Write("</tr>");
                                }
                                html.Write("</table>");
                            }
                            WBTable table6 = new WBTable();
                            table6.OpenTable("wb_commodity", "SELECT comm_code, sync_return FROM wb_commodity WHERE " + Sync.where_con + " ORDER BY comm_code", WBData.conn);
                            if (table6.DT.Rows.Count > 0)
                            {
                                html.Write("<br><br><b>MASTER DATA COMMODITY</b>");
                                html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                html.Write("<tr class='bd'>");
                                html.Write("<td align=center><b>No.</b></td>");
                                html.Write("<td align=center><b>Commodity Code</b></td>");
                                html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                html.Write("</tr>");
                                num2 = 0;
                                foreach (DataRow row6 in table6.DT.Rows)
                                {
                                    num2++;
                                    html.Write("<tr class='bd'>");
                                    html.Write("<td align=right>" + num2.ToString() + "</td>");
                                    html.Write("<td align=left>" + row6[0].ToString() + "</td>");
                                    if (row6["sync_return"].ToString() == "")
                                    {
                                        html.Write("<td align=left>&nbsp</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td align=left>" + row6["sync_return"].ToString() + "</td>");
                                    }
                                    html.Write("</tr>");
                                }
                                html.Write("</table>");
                            }
                            WBTable table7 = new WBTable();
                            table7.OpenTable("wb_contract", "SELECT DO_NO, sync_return FROM wb_contract WHERE " + Sync.where_con + " ORDER BY DO_NO", WBData.conn);
                            if (table7.DT.Rows.Count > 0)
                            {
                                html.Write("<br><br><b>MASTER DATA DO</b>");
                                html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                html.Write("<tr class='bd'>");
                                html.Write("<td align=center><b>No.</b></td>");
                                html.Write("<td align=center><b>DO/SO No</b></td>");
                                html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                html.Write("</tr>");
                                num2 = 0;
                                foreach (DataRow row7 in table7.DT.Rows)
                                {
                                    num2++;
                                    html.Write("<tr class='bd'>");
                                    html.Write("<td align=right>" + num2.ToString() + "</td>");
                                    html.Write("<td align=left>" + row7[0].ToString() + "</td>");
                                    if (row7["sync_return"].ToString() == "")
                                    {
                                        html.Write("<td align=left>&nbsp</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td align=left>" + row7["sync_return"].ToString() + "</td>");
                                    }
                                    html.Write("</tr>");
                                }
                                html.Write("</table>");
                            }
                            WBTable table8 = new WBTable();
                            table8.OpenTable("wb_relation", "SELECT Relation_Code, sync_return FROM wb_relation WHERE " + Sync.where_con + " ORDER BY Relation_Code", WBData.conn);
                            if (table8.DT.Rows.Count > 0)
                            {
                                html.Write("<br><br><b>MASTER DATA VENDOR / CUSTOMER</b>");
                                html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                html.Write("<tr class='bd'>");
                                html.Write("<td align=center><b>No.</b></td>");
                                html.Write("<td align=center><b>Vendor/Customer Code</b></td>");
                                html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                html.Write("</tr>");
                                num2 = 0;
                                foreach (DataRow row8 in table8.DT.Rows)
                                {
                                    num2++;
                                    html.Write("<tr class='bd'>");
                                    html.Write("<td align=right>" + num2.ToString() + "</td>");
                                    html.Write("<td align=left>" + row8[0].ToString() + "</td>");
                                    if (row8["sync_return"].ToString() == "")
                                    {
                                        html.Write("<td align=left>&nbsp</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td align=left>" + row8["sync_return"].ToString() + "</td>");
                                    }
                                    html.Write("</tr>");
                                }
                                html.Write("</table>");
                            }
                        }
                        html.writeSign();
                        html.Close();
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_348, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        return;
                    }
                }
                if (this.summaryRadio.Checked)
                {
                    str = ((("SELECT a.coy, a.location_code, a.sync_return, count(*) AS n " + " FROM wb_transaction a, wb_commodity b ") + " WHERE a.coy = b.coy " + " AND a.location_code = b.location_code ") + " AND a.comm_code = b.comm_code " + " AND b.postsap = 'Y' ") + " AND (a.posted IS NULL OR a.posted = 'N') " + " AND a.report_date IS NOT NULL ";
                    if (this.checkDate.Checked)
                    {
                        str = (str + " AND a.report_date >= '" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00' ") + " AND a.report_date <= '" + this.monthCalendar2.Value.ToString("yyyy-MM-dd") + " 00:00:00' ";
                    }
                    if (!this.checkCoyLoc.Checked)
                    {
                        str = (str + " AND a.Coy = '" + WBData.sCoyCode + "'") + " AND a.Location_Code = '" + WBData.sLocCode + "'";
                    }
                    if (!this.checkSync.Checked)
                    {
                        str = str + " AND (a.sync_return IS NOT NULL OR a.sync_return != '') ";
                    }
                    str = (str + " AND (a.NonContract IS NULL OR a.Noncontract = 'N' OR a.NonContract = '') ") + " GROUP BY a.coy, a.location_code, a.sync_return " + " ORDER BY a.coy, a.location_code ";
                    WBTable table9 = new WBTable();
                    table9.OpenTable("vw_trans", str, WBData.conn);
                    if ((table9.DT.Rows.Count > 0) || this.cb_master_data.Checked)
                    {
                        html2 = html;
                        string[] textArray4 = new string[] { html2.File, @"\", WBUser.UserID, "_Fail", DateTime.Today.ToString("dd_MM_yyyy"), ".htm" };
                        html2.File = string.Concat(textArray4);
                        html.Title = "FAIL SYNCHRONIZE REPORT";
                        html.Open();
                        html.Write(html.Style());
                        html.Write("<br><font size=5><b>FAIL SYNCHRONIZE REPORT</b></font><br>");
                        if (this.checkCoyLoc.Checked)
                        {
                            html.Write("<br><font size=4>For All Company & Location</font>");
                        }
                        else
                        {
                            string[] textArray5 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                            html.Write(string.Concat(textArray5));
                            string[] textArray6 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                            html.Write(string.Concat(textArray6));
                            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                            {
                                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                            }
                            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                            {
                                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                            }
                            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                            {
                                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                            }
                        }
                        html.Write("<br><br>");
                        html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                        if (this.checkDate.Checked)
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>Selected Date</td>");
                            html.Write("<td>: <b>" + this.monthCalendar1.Value.ToShortDateString() + "</b></td>");
                            html.Write("</tr>");
                        }
                        html.Write("<tr class=bd>");
                        html.Write("<td>Report Date</td>");
                        html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                        html.Write("</tr>");
                        html.Write("</table>");
                        html.Write("<br/><br/><br/>");
                        html.Write("<b><font size=3>FAIL TRANSACTION - SUMMARY LIST</font></b><br><br>");
                        html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                        html.Write("<tr class='bd'>");
                        html.Write("<td align=center><b>No.</b></td>");
                        html.Write("<td align=center><b>Coy</b></td>");
                        html.Write("<td align=center><b>Location Code</b></td>");
                        html.Write("<td align=center width=300><b>Sync Return</b></td>");
                        html.Write("<td align=center width=80><b>Total</b></td>");
                        html.Write("</tr>");
                        int num3 = 0;
                        double num4 = 0.0;
                        double num5 = 0.0;
                        int num6 = 0;
                        while (true)
                        {
                            if (num6 >= table9.DT.Rows.Count)
                            {
                                html.Write("<tr class='bd'>");
                                html.Write("<td colspan='4' align='right'><b>TOTAL</b></td>");
                                html.Write("<td align='right'><b>" + num4 + "</b></td>");
                                html.Write("</tr>");
                                html.Write("</table>");
                                if (this.cb_master_data.Checked)
                                {
                                    WBTable table10 = new WBTable();
                                    if (this.checkCoyLoc.Checked)
                                    {
                                        table10.OpenTable("wb_estate", "select coy, location_code, sync_return, count(*) from wb_estate where (zwb IS NULL OR zwb <> 'Y') group by coy, location_code, sync_return  order by coy,location_code ", WBData.conn);
                                    }
                                    else
                                    {
                                        table10.OpenTable("wb_estate", "select coy, location_code, sync_return, count(*) from wb_estate where " + Sync.where_con + " group by coy, location_code,sync_return order by coy,location_code ", WBData.conn);
                                    }
                                    if (table10.DT.Rows.Count > 0)
                                    {
                                        html.Write("<br><br><b>MASTER DATA ESTATE</b>");
                                        html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                        html.Write("<tr class='bd'>");
                                        html.Write("<td align=center><b>No.</b></td>");
                                        html.Write("<td align=center><b>Coy</b></td>");
                                        html.Write("<td align=center><b>Location Code</b></td>");
                                        html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                        html.Write("<td align=center><b>Total</b></td>");
                                        html.Write("</tr>");
                                        num3 = 0;
                                        foreach (DataRow row11 in table10.DT.Rows)
                                        {
                                            num3++;
                                            html.Write("<tr class='bd'>");
                                            html.Write("<td align=right>" + num3.ToString() + "</td>");
                                            html.Write("<td align=left>" + row11[0].ToString() + "</td>");
                                            html.Write("<td align=left>" + row11[1].ToString() + "</td>");
                                            if (row11["sync_return"].ToString() == "")
                                            {
                                                html.Write("<td align=left>&nbsp</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td align=left>" + row11["sync_return"].ToString() + "</td>");
                                            }
                                            html.Write("<td align=left>" + row11[3].ToString() + "</td>");
                                            html.Write("</tr>");
                                        }
                                        html.Write("</table>");
                                    }
                                    WBTable table11 = new WBTable();
                                    if (this.checkCoyLoc.Checked)
                                    {
                                        table11.OpenTable("wb_truck", "select coy, location_code, sync_return, count(*) from wb_truck where (zwb IS NULL OR zwb <> 'Y') group by coy, location_code, sync_return order by coy,location_code ", WBData.conn);
                                    }
                                    else
                                    {
                                        table11.OpenTable("wb_truck", "select coy, location_code, sync_return, count(*) from wb_truck where " + Sync.where_con + " group by coy, location_code,sync_return order by coy,location_code ", WBData.conn);
                                    }
                                    if (table11.DT.Rows.Count > 0)
                                    {
                                        html.Write("<br><br><b>MASTER DATA TRUCK</b>");
                                        html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                        html.Write("<tr class='bd'>");
                                        html.Write("<td align=center><b>No.</b></td>");
                                        html.Write("<td align=center><b>Coy</b></td>");
                                        html.Write("<td align=center><b>Location Code</b></td>");
                                        html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                        html.Write("<td align=center><b>Total</b></td>");
                                        html.Write("</tr>");
                                        num3 = 0;
                                        foreach (DataRow row12 in table11.DT.Rows)
                                        {
                                            num3++;
                                            html.Write("<tr class='bd'>");
                                            html.Write("<td align=right>" + num3.ToString() + "</td>");
                                            html.Write("<td align=left>" + row12[0].ToString() + "</td>");
                                            html.Write("<td align=left>" + row12[1].ToString() + "</td>");
                                            if (row12["sync_return"].ToString() == "")
                                            {
                                                html.Write("<td align=left>&nbsp</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td align=left>" + row12["sync_return"].ToString() + "</td>");
                                            }
                                            html.Write("<td align=left>" + row12[3].ToString() + "</td>");
                                            html.Write("</tr>");
                                        }
                                        html.Write("</table>");
                                    }
                                    WBTable table12 = new WBTable();
                                    if (this.checkCoyLoc.Checked)
                                    {
                                        table12.OpenTable("wb_transporter", "select coy, location_code, sync_return, count(*) from wb_transporter where (zwb IS NULL OR zwb <> 'Y') group by coy, location_code, sync_return order by coy,location_code ", WBData.conn);
                                    }
                                    else
                                    {
                                        table12.OpenTable("wb_transporter", "select coy, location_code, sync_return, count(*) from wb_transporter where " + Sync.where_con + " group by coy, location_code,sync_return order by coy,location_code ", WBData.conn);
                                    }
                                    if (table12.DT.Rows.Count > 0)
                                    {
                                        html.Write("<br><br><b>MASTER DATA TRANSPORTER</b>");
                                        html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                        html.Write("<tr class='bd'>");
                                        html.Write("<td align=center><b>No.</b></td>");
                                        html.Write("<td align=center><b>Coy</b></td>");
                                        html.Write("<td align=center><b>Location Code</b></td>");
                                        html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                        html.Write("<td align=center><b>Total</b></td>");
                                        html.Write("</tr>");
                                        num3 = 0;
                                        foreach (DataRow row13 in table12.DT.Rows)
                                        {
                                            num3++;
                                            html.Write("<tr class='bd'>");
                                            html.Write("<td align=right>" + num3.ToString() + "</td>");
                                            html.Write("<td align=left>" + row13[0].ToString() + "</td>");
                                            html.Write("<td align=left>" + row13[1].ToString() + "</td>");
                                            if (row13["sync_return"].ToString() == "")
                                            {
                                                html.Write("<td align=left>&nbsp</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td align=left>" + row13["sync_return"].ToString() + "</td>");
                                            }
                                            html.Write("<td align=left>" + row13[3].ToString() + "</td>");
                                            html.Write("</tr>");
                                        }
                                        html.Write("</table>");
                                    }
                                    WBTable table13 = new WBTable();
                                    if (this.checkCoyLoc.Checked)
                                    {
                                        table13.OpenTable("wb_driver", "select coy, location_code, sync_return, count(*) from wb_driver where (zwb IS NULL OR zwb <> 'Y') group by coy, location_code, sync_return order by coy,location_code ", WBData.conn);
                                    }
                                    else
                                    {
                                        table13.OpenTable("wb_driver", "select coy, location_code, sync_return, count(*) from wb_driver where " + Sync.where_con + " group by coy, location_code,sync_return order by coy,location_code ", WBData.conn);
                                    }
                                    if (table13.DT.Rows.Count > 0)
                                    {
                                        html.Write("<br><br><b>MASTER DATA DRIVER</b>");
                                        html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                        html.Write("<tr class='bd'>");
                                        html.Write("<td align=center><b>No.</b></td>");
                                        html.Write("<td align=center><b>Coy</b></td>");
                                        html.Write("<td align=center><b>Location Code</b></td>");
                                        html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                        html.Write("<td align=center><b>Total</b></td>");
                                        html.Write("</tr>");
                                        num3 = 0;
                                        foreach (DataRow row14 in table13.DT.Rows)
                                        {
                                            num3++;
                                            html.Write("<tr class='bd'>");
                                            html.Write("<td align=right>" + num3.ToString() + "</td>");
                                            html.Write("<td align=left>" + row14[0].ToString() + "</td>");
                                            html.Write("<td align=left>" + row14[1].ToString() + "</td>");
                                            if (row14["sync_return"].ToString() == "")
                                            {
                                                html.Write("<td align=left>&nbsp</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td align=left>" + row14["sync_return"].ToString() + "</td>");
                                            }
                                            html.Write("<td align=left>" + row14[3].ToString() + "</td>");
                                            html.Write("</tr>");
                                        }
                                        html.Write("</table>");
                                    }
                                    WBTable table14 = new WBTable();
                                    if (this.checkCoyLoc.Checked)
                                    {
                                        table14.OpenTable("wb_commodity", "select coy, location_code, sync_return, count(*) from wb_commodity where (zwb IS NULL OR zwb <> 'Y') group by coy, location_code, sync_return order by coy,location_code ", WBData.conn);
                                    }
                                    else
                                    {
                                        table14.OpenTable("wb_commodity", "select coy, location_code, sync_return, count(*) from wb_commodity where " + Sync.where_con + " group by coy, location_code,sync_return order by coy,location_code ", WBData.conn);
                                    }
                                    if (table14.DT.Rows.Count > 0)
                                    {
                                        html.Write("<br><br><b>MASTER DATA COMMODITY</b>");
                                        html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                        html.Write("<tr class='bd'>");
                                        html.Write("<td align=center><b>No.</b></td>");
                                        html.Write("<td align=center><b>Coy</b></td>");
                                        html.Write("<td align=center><b>Location Code</b></td>");
                                        html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                        html.Write("<td align=center><b>Total</b></td>");
                                        html.Write("</tr>");
                                        num3 = 0;
                                        foreach (DataRow row15 in table14.DT.Rows)
                                        {
                                            num3++;
                                            html.Write("<tr class='bd'>");
                                            html.Write("<td align=right>" + num3.ToString() + "</td>");
                                            html.Write("<td align=left>" + row15[0].ToString() + "</td>");
                                            html.Write("<td align=left>" + row15[1].ToString() + "</td>");
                                            if (row15["sync_return"].ToString() == "")
                                            {
                                                html.Write("<td align=left>&nbsp</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td align=left>" + row15["sync_return"].ToString() + "</td>");
                                            }
                                            html.Write("<td align=left>" + row15[3].ToString() + "</td>");
                                            html.Write("</tr>");
                                        }
                                        html.Write("</table>");
                                    }
                                    WBTable table15 = new WBTable();
                                    if (this.checkCoyLoc.Checked)
                                    {
                                        table15.OpenTable("wb_contract", "select coy, location_code, sync_return, count(*) from wb_contract where (zwb IS NULL OR zwb <> 'Y') group by coy, location_code, sync_return order by coy,location_code ", WBData.conn);
                                    }
                                    else
                                    {
                                        table15.OpenTable("wb_contract", "select coy, location_code, sync_return, count(*) from wb_contract where " + Sync.where_con + " group by coy, location_code,sync_return order by coy,location_code ", WBData.conn);
                                    }
                                    if (table15.DT.Rows.Count > 0)
                                    {
                                        html.Write("<br><br><b>MASTER DATA CONTRACT</b>");
                                        html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                        html.Write("<tr class='bd'>");
                                        html.Write("<td align=center><b>No.</b></td>");
                                        html.Write("<td align=center><b>Coy</b></td>");
                                        html.Write("<td align=center><b>Location Code</b></td>");
                                        html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                        html.Write("<td align=center><b>Total</b></td>");
                                        html.Write("</tr>");
                                        num3 = 0;
                                        foreach (DataRow row16 in table15.DT.Rows)
                                        {
                                            num3++;
                                            html.Write("<tr class='bd'>");
                                            html.Write("<td align=right>" + num3.ToString() + "</td>");
                                            html.Write("<td align=left>" + row16[0].ToString() + "</td>");
                                            html.Write("<td align=left>" + row16[1].ToString() + "</td>");
                                            if (row16["sync_return"].ToString() == "")
                                            {
                                                html.Write("<td align=left>&nbsp</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td align=left>" + row16["sync_return"].ToString() + "</td>");
                                            }
                                            html.Write("<td align=left>" + row16[3].ToString() + "</td>");
                                            html.Write("</tr>");
                                        }
                                        html.Write("</table>");
                                    }
                                    WBTable table16 = new WBTable();
                                    if (this.checkCoyLoc.Checked)
                                    {
                                        table16.OpenTable("wb_relation", "select coy, location_code, sync_return, count(*) from wb_relation where (zwb IS NULL OR zwb <> 'Y') group by coy, location_code, sync_return order by coy,location_code ", WBData.conn);
                                    }
                                    else
                                    {
                                        table16.OpenTable("wb_relation", "select coy, location_code, sync_return, count(*) from wb_relation where " + Sync.where_con + " group by coy, location_code, sync_return order by coy,location_code ", WBData.conn);
                                    }
                                    if (table16.DT.Rows.Count > 0)
                                    {
                                        html.Write("<br><br><b>MASTER DATA RELATION</b>");
                                        html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                                        html.Write("<tr class='bd'>");
                                        html.Write("<td align=center><b>No.</b></td>");
                                        html.Write("<td align=center><b>Coy</b></td>");
                                        html.Write("<td align=center><b>Location Code</b></td>");
                                        html.Write("<td align=center><b>Sync Failure Reason</b></td>");
                                        html.Write("<td align=center><b>Total</b></td>");
                                        html.Write("</tr>");
                                        num3 = 0;
                                        foreach (DataRow row17 in table16.DT.Rows)
                                        {
                                            num3++;
                                            html.Write("<tr class='bd'>");
                                            html.Write("<td align=right>" + num3.ToString() + "</td>");
                                            html.Write("<td align=left>" + row17[0].ToString() + "</td>");
                                            html.Write("<td align=left>" + row17[1].ToString() + "</td>");
                                            if (row17["sync_return"].ToString() == "")
                                            {
                                                html.Write("<td align=left>&nbsp</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td align=left>" + row17["sync_return"].ToString() + "</td>");
                                            }
                                            html.Write("<td align=left>" + row17[3].ToString() + "</td>");
                                            html.Write("</tr>");
                                        }
                                        html.Write("</table>");
                                    }
                                }
                                html.writeSign();
                                html.Close();
                                break;
                            }
                            num3++;
                            DataRow row9 = table9.DT.Rows[num6];
                            html.Write("<tr class='bd'>");
                            html.Write("<td align=right>" + num3.ToString() + "</td>");
                            html.Write("<td align=left>" + row9["Coy"].ToString() + "</td>");
                            html.Write("<td align=left>" + row9["Location_Code"].ToString() + "</td>");
                            if (row9["sync_return"].ToString() == "")
                            {
                                html.Write("<td><i>Not sync yet</i></td>");
                            }
                            else
                            {
                                html.Write("<td>" + row9["sync_return"].ToString() + "</td>");
                            }
                            html.Write("<td align=right>" + row9["n"].ToString() + "</td>");
                            html.Write("</tr>");
                            num4 += Program.StrToDouble(row9["n"].ToString(), 0);
                            num5 += Program.StrToDouble(row9["n"].ToString(), 0);
                            if (!(((num6 + 1) < table9.DT.Rows.Count) && this.checkCoyLoc.Checked))
                            {
                                if ((num6 == (table9.DT.Rows.Count - 1)) && this.checkCoyLoc.Checked)
                                {
                                    html.Write("<tr class='bd'>");
                                    html.Write("<td colspan='4' align='right'><b>SUBTOTAL</b></td>");
                                    html.Write("<td align='right'><b>" + num5 + "</b></td>");
                                    html.Write("</tr>");
                                }
                            }
                            else
                            {
                                DataRow row10 = table9.DT.Rows[num6 + 1];
                                if ((row9["Coy"].ToString() != row10["Coy"].ToString()) || (row9["Location_Code"].ToString() != row10["Location_Code"].ToString()))
                                {
                                    html.Write("<tr class='bd'>");
                                    html.Write("<td colspan='4' align='right'><b>SUBTOTAL</b></td>");
                                    html.Write("<td align='right'><b>" + num5 + "</b></td>");
                                    html.Write("</tr>");
                                    num5 = 0.0;
                                }
                            }
                            num6++;
                        }
                    }
                    else
                    {
                        MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        return;
                    }
                }
                if (this.cb_send_via_email.Checked)
                {
                    WBMail mail = new WBMail();
                    WBTable table17 = new WBTable();
                    table17.OpenTable("wb_email_master", "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND ( Email_Code ='FAIL_SYNC')"), WBData.conn);
                    int num7 = 0;
                    while (true)
                    {
                        if (num7 >= table17.DT.Rows.Count)
                        {
                            mail.mailAttachment(html.File);
                            mail.Body = ((("Dear All, <br><br><table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name")) + "</tr></table>") + "<br><br>Attached FAIL SYNCHRONIZE Report For Date : " + DateTime.Today.ToString("dd/MM/yyyy");
                            mail.SendMail();
                            WBTable table18 = new WBTable();
                            table18.OpenTable("Wb_email", "select * from wb_email where " + WBData.CompanyLocation(" and Email_date = '" + DateTime.Now.AddDays(-1.0).ToString("yyyy-MM-dd") + " 00:00:00' order by Email_code"), WBData.conn);
                            table18.DR = table18.DT.NewRow();
                            table18.DR["Email_code"] = "FAIL_SYNC";
                            table18.DR["Status"] = "Y";
                            table18.DR["Coy"] = WBData.sCoyCode;
                            table18.DR["location_code"] = WBData.sLocCode;
                            table18.DR["Email_Date"] = DateTime.Now.AddDays(-1.0).ToString("yyyy-MM-dd");
                            table18.DT.Rows.Add(table18.DR);
                            table18.Save();
                            break;
                        }
                        DataRow row18 = table17.DT.Rows[num7];
                        mail.Subject = row18[0].ToString().Trim();
                        mail.To = row18[1].ToString().Trim();
                        mail.CC = row18[2].ToString().Trim();
                        num7++;
                    }
                }
                new ViewReport { webBrowser1 = { Url = new Uri(html.File) } }.ShowDialog();
            }
            else
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void cb_master_data_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void checkDate_CheckedChanged(object sender, EventArgs e)
        {
            this.monthCalendar1.Enabled = this.checkDate.Checked;
            this.monthCalendar2.Enabled = this.checkDate.Checked;
        }

        private void detailRadio_CheckedChanged(object sender, EventArgs e)
        {
            this.checkCoyLoc.Enabled = false;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.monthCalendar1 = new DateTimePicker();
            this.label5 = new Label();
            this.butClose = new Button();
            this.butProcess = new Button();
            this.label3 = new Label();
            this.checkDate = new CheckBox();
            this.monthCalendar2 = new DateTimePicker();
            this.label6 = new Label();
            this.groupBox1 = new GroupBox();
            this.cb_master_data = new CheckBox();
            this.cb_send_via_email = new CheckBox();
            this.groupBox2 = new GroupBox();
            this.detailRadio = new RadioButton();
            this.summaryRadio = new RadioButton();
            this.checkSync = new CheckBox();
            this.checkCoyLoc = new CheckBox();
            this.groupBox3 = new GroupBox();
            this.groupBox4 = new GroupBox();
            this.radioComm = new RadioButton();
            this.radioRef = new RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            base.SuspendLayout();
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x61, 0x2a);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x16, 0x2d);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x3e, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "From Date :";
            this.butClose.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.butClose.Location = new Point(0x1c9, 90);
            this.butClose.Name = "butClose";
            this.butClose.Size = new Size(110, 0x22);
            this.butClose.TabIndex = 0x52;
            this.butClose.Text = "Close";
            this.butClose.UseVisualStyleBackColor = true;
            this.butClose.Click += new EventHandler(this.butClose_Click);
            this.butProcess.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.butProcess.Location = new Point(0x1c9, 50);
            this.butProcess.Name = "butProcess";
            this.butProcess.Size = new Size(110, 0x22);
            this.butProcess.TabIndex = 0x51;
            this.butProcess.Text = "Process";
            this.butProcess.UseVisualStyleBackColor = true;
            this.butProcess.Click += new EventHandler(this.butProcess_Click);
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(12, 9);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0xc9, 20);
            this.label3.TabIndex = 0x57;
            this.label3.Text = "Fail Synchronize Report";
            this.label3.TextAlign = ContentAlignment.TopCenter;
            this.checkDate.AutoSize = true;
            this.checkDate.Location = new Point(12, 0x13);
            this.checkDate.Name = "checkDate";
            this.checkDate.Size = new Size(110, 0x11);
            this.checkDate.TabIndex = 0x54;
            this.checkDate.Text = "Generate by Date";
            this.checkDate.UseVisualStyleBackColor = true;
            this.checkDate.CheckedChanged += new EventHandler(this.checkDate_CheckedChanged);
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x111, 0x2a);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xd7, 0x2d);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x34, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "To Date :";
            this.groupBox1.Controls.Add(this.monthCalendar1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.monthCalendar2);
            this.groupBox1.Controls.Add(this.checkDate);
            this.groupBox1.Location = new Point(12, 0x65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x1ab, 0x4f);
            this.groupBox1.TabIndex = 0x4f;
            this.groupBox1.TabStop = false;
            this.cb_master_data.AutoSize = true;
            this.cb_master_data.Location = new Point(15, 0x13);
            this.cb_master_data.Name = "cb_master_data";
            this.cb_master_data.Size = new Size(0x8b, 0x11);
            this.cb_master_data.TabIndex = 0x58;
            this.cb_master_data.Text = "Show failed master data";
            this.cb_master_data.UseVisualStyleBackColor = true;
            this.cb_master_data.CheckedChanged += new EventHandler(this.cb_master_data_CheckedChanged);
            this.cb_send_via_email.AutoSize = true;
            this.cb_send_via_email.Location = new Point(0xd5, 0x2a);
            this.cb_send_via_email.Name = "cb_send_via_email";
            this.cb_send_via_email.Size = new Size(0x4f, 0x11);
            this.cb_send_via_email.TabIndex = 0x59;
            this.cb_send_via_email.Text = "Send Email";
            this.cb_send_via_email.UseVisualStyleBackColor = true;
            this.groupBox2.Controls.Add(this.detailRadio);
            this.groupBox2.Controls.Add(this.summaryRadio);
            this.groupBox2.Location = new Point(12, 0x2d);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0x1ab, 50);
            this.groupBox2.TabIndex = 90;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Report Type";
            this.detailRadio.AutoSize = true;
            this.detailRadio.Location = new Point(0x95, 0x16);
            this.detailRadio.Name = "detailRadio";
            this.detailRadio.Size = new Size(0x34, 0x11);
            this.detailRadio.TabIndex = 1;
            this.detailRadio.Text = "Detail";
            this.detailRadio.UseVisualStyleBackColor = true;
            this.detailRadio.CheckedChanged += new EventHandler(this.detailRadio_CheckedChanged);
            this.summaryRadio.AutoSize = true;
            this.summaryRadio.Checked = true;
            this.summaryRadio.Location = new Point(9, 0x16);
            this.summaryRadio.Name = "summaryRadio";
            this.summaryRadio.Size = new Size(0x44, 0x11);
            this.summaryRadio.TabIndex = 0;
            this.summaryRadio.TabStop = true;
            this.summaryRadio.Text = "Summary";
            this.summaryRadio.UseVisualStyleBackColor = true;
            this.summaryRadio.CheckedChanged += new EventHandler(this.summaryRadio_CheckedChanged);
            this.checkSync.AutoSize = true;
            this.checkSync.Location = new Point(0xd5, 0x13);
            this.checkSync.Name = "checkSync";
            this.checkSync.Size = new Size(0xd4, 0x11);
            this.checkSync.TabIndex = 0x5b;
            this.checkSync.Text = "Show transaction which hasn't sync yet";
            this.checkSync.UseVisualStyleBackColor = true;
            this.checkCoyLoc.AutoSize = true;
            this.checkCoyLoc.Location = new Point(15, 0x2a);
            this.checkCoyLoc.Name = "checkCoyLoc";
            this.checkCoyLoc.Size = new Size(0xb0, 0x11);
            this.checkCoyLoc.TabIndex = 0x5c;
            this.checkCoyLoc.Text = "Show for all company && location";
            this.checkCoyLoc.UseVisualStyleBackColor = true;
            this.groupBox3.Controls.Add(this.cb_master_data);
            this.groupBox3.Controls.Add(this.checkCoyLoc);
            this.groupBox3.Controls.Add(this.cb_send_via_email);
            this.groupBox3.Controls.Add(this.checkSync);
            this.groupBox3.Location = new Point(12, 240);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(0x1ab, 0x48);
            this.groupBox3.TabIndex = 0x5d;
            this.groupBox3.TabStop = false;
            this.groupBox4.Controls.Add(this.radioComm);
            this.groupBox4.Controls.Add(this.radioRef);
            this.groupBox4.Location = new Point(12, 0xbb);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new Size(0x1ab, 0x2f);
            this.groupBox4.TabIndex = 0x5e;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Order Data By";
            this.radioComm.AutoSize = true;
            this.radioComm.Location = new Point(0x95, 0x13);
            this.radioComm.Name = "radioComm";
            this.radioComm.Size = new Size(0x4c, 0x11);
            this.radioComm.TabIndex = 1;
            this.radioComm.TabStop = true;
            this.radioComm.Text = "Commodity";
            this.radioComm.UseVisualStyleBackColor = true;
            this.radioRef.AutoSize = true;
            this.radioRef.Location = new Point(15, 0x13);
            this.radioRef.Name = "radioRef";
            this.radioRef.Size = new Size(0x5f, 0x11);
            this.radioRef.TabIndex = 0;
            this.radioRef.TabStop = true;
            this.radioRef.Text = "Reference No.";
            this.radioRef.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x251, 0x144);
            base.Controls.Add(this.groupBox4);
            base.Controls.Add(this.groupBox3);
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.butClose);
            base.Controls.Add(this.butProcess);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.groupBox1);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "RepFailSync";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Fail Synchronize Report";
            base.Load += new EventHandler(this.RepFailSync_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void RepFailSync_Load(object sender, EventArgs e)
        {
            this.checkDate.Checked = true;
            this.checkDate.Checked = false;
            if (WBSetting.locType == "0")
            {
                this.radioRef.Checked = true;
            }
            else
            {
                this.radioComm.Checked = true;
            }
        }

        private void summaryRadio_CheckedChanged(object sender, EventArgs e)
        {
            this.checkCoyLoc.Enabled = true;
        }
    }
}

