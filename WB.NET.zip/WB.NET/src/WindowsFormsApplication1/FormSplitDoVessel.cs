﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormSplitDoVessel : Form
    {
        public WBTable t_item = new WBTable();
        public WBTable s_help = new WBTable();
        public WBTable t_trans = new WBTable();
        public WBTable t_do = new WBTable();
        public WBTable t_do_save = new WBTable();
        public WBTable t_os = new WBTable();
        private string[] map_ref = new string[0x3e7];
        private string[] map_date = new string[0x3e7];
        private string[] map_do = new string[0x63];
        private long[,] map = new long[0x3e7, 0x3e7];
        private long[] qty_do_item = new long[0x63];
        public long total_qty = 0L;
        public long qty_do_vessel = 0L;
        public double used = 0.0;
        private int n_ref = 0;
        private int n_do = 0;
        private string last_ref = "";
        private string dovessel_completed = "";
        private string dovessel_afterTolerance = "";
        private IContainer components = null;
        private GroupBox gb_header;
        private Button btn_go;
        private TextBox text_DO;
        private GroupBox gb_detail;
        private GroupBox gb_info;
        private DataGridView dgv_item;
        private DataGridView dgv_split;
        private DateTimePicker date_trans;
        private Button btn_search;
        private GroupBox gb_filter;
        private RadioButton rb_date;
        private RadioButton rb_all;
        private Panel panel_info;
        private DateTimePicker date_DO;
        private Label label2;
        private TextBox text_qty;
        private Label label1;
        private Button btn_cancel;
        private Button btn_Split;
        private Label label4;
        private TextBox text_remain;
        private Label label3;
        private TextBox text_used;
        private Label label_do_complete;
        private Button buttonDO;
        private Label label6;
        private Label label5;

        public FormSplitDoVessel()
        {
            this.InitializeComponent();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btn_go_Click(object sender, EventArgs e)
        {
            if (this.text_DO.Text == "")
            {
                MessageBox.Show("Please fill in DO Vessel", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                this.text_DO.Text = this.text_DO.Text.Trim();
                string[] aField = new string[] { "do_no" };
                string[] aFind = new string[] { this.text_DO.Text.Trim() };
                DataRow data = this.s_help.GetData(aField, aFind);
                if (ReferenceEquals(data, null))
                {
                    MessageBox.Show("Invalid DO", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_vessel_map", "select * from wb_vessel_map where uniq_vessel = '" + data["uniq"].ToString() + "'", WBData.conn);
                    if (table.DT.Rows.Count == 0)
                    {
                        MessageBox.Show("Please perform Map DO Vessel first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        WBTable table2 = new WBTable();
                        if (!string.IsNullOrEmpty(table2.CekTokenCompleted(this.text_DO.Text.Trim(), "", "VESSEL_PERCENTAGE_TOLERANCE", false)))
                        {
                            MessageBox.Show("Please complete any in-progress VESSEL_PERCENTAGE_TOLERANCE Token for able to continue Auto Split Vessel DO (" + this.text_DO.Text.Trim() + ").", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            table2.Dispose();
                            this.gb_detail.Visible = true;
                            this.gb_info.Visible = true;
                            this.panel_info.Visible = true;
                            this.gb_filter.Visible = true;
                            this.date_DO.Value = Convert.ToDateTime(data["Do_Date"].ToString());
                            this.text_qty.Text = data["quantity"].ToString();
                            this.qty_do_vessel = long.Parse(this.text_qty.Text);
                            this.total_qty = long.Parse(data["quantity"].ToString());
                            this.dovessel_completed = Program.getFieldValue("wb_vessel_map", "completed", "uniq_vessel", data["uniq"].ToString());
                            this.dovessel_afterTolerance = data["VesselAfterToleranceSplitMethod"].ToString();
                            this.label_do_complete.Visible = this.dovessel_completed == "Y";
                            double num = this.getDOVesselLimitTolerance(this.text_DO.Text.Trim());
                            string sqltext = ("SELECT Do_No, qty_map as Quantity, '0' as AMSQuantity, DeductedBy as Used, DeductedBy as Outstanding, DeductedBy as OPW_Used, '0' as GainLoss, '0' as VesselOPWPropor, '0' as VesselFactPropor," + " Comm_Code , Relation_Code, Estate1_Code, Transporter_Code, Transaction_Code" + " FROM wb_vessel_map m LEFT JOIN wb_contract c ON m.uniq_item = c.uniq") + " WHERE uniq_vessel = '" + data["uniq"].ToString() + "' ORDER BY qty_map asc, Do_No asc";
                            this.t_item.OpenTable("wb_contract", sqltext, WBData.conn);
                            this.dgv_item.DataSource = this.t_item.DT;
                            this.dgv_item.Columns["Comm_Code"].Visible = false;
                            this.dgv_item.Columns["Relation_Code"].Visible = false;
                            this.dgv_item.Columns["Estate1_Code"].Visible = false;
                            this.dgv_item.Columns["Transporter_Code"].Visible = false;
                            this.dgv_item.Columns["Transaction_Code"].Visible = false;
                            this.dgv_item.Columns["quantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            this.dgv_item.Columns["used"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            this.dgv_item.Columns["outstanding"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            this.dgv_item.Columns["AMSQuantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            this.dgv_item.Columns["AMSQuantity"].HeaderText = "Quantity * AMS tolerance (%)";
                            this.dgv_item.Columns["OPW_Used"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            this.dgv_item.Columns["OPW_Used"].HeaderText = "Used Other Party Net";
                            this.dgv_item.Columns["VesselOPWPropor"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            this.dgv_item.Columns["VesselOPWPropor"].HeaderText = "Proportionate Other Party Net";
                            this.dgv_item.Columns["VesselFactPropor"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            this.dgv_item.Columns["VesselFactPropor"].HeaderText = "Proportionate Factory Net";
                            this.dgv_item.Columns["GainLoss"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            this.dgv_item.Columns["GainLoss"].HeaderText = "Gain Loss";
                            foreach (DataGridViewRow row2 in (IEnumerable) this.dgv_item.Rows)
                            {
                                string str2 = ((DataGridViewTextBoxCell) row2.Cells["do_no"]).Value.ToString();
                                string str3 = ((DataGridViewTextBoxCell) row2.Cells["Outstanding"]).Value.ToString();
                                string str4 = ((("SELECT SUM(trans.Net) AS Nett, SUM(trans.Net_Estate) AS OPW_Nett FROM wb_transaction trans" + " LEFT JOIN wb_transSplit b ON trans.ref LIKE b.ref+'%'") + " WHERE b.Do_No LIKE '" + this.text_DO.Text + "'") + " AND trans.do_no = '" + str2 + "'") + " AND ((trans.mark_accident IS NULL) AND (trans.Deleted IS NULL) AND " + " (trans.Report_Date IS NOT NULL) OR (trans.mark_accident = '') AND (trans.Deleted = ''))";
                                this.t_os.OpenTable("vw_os", str4, WBData.conn);
                                double num2 = 0.0;
                                double num3 = 0.0;
                                double num4 = 0.0;
                                double num5 = 0.0;
                                if (this.t_os.DT.Rows.Count == 1)
                                {
                                    this.t_os.DR = this.t_os.DT.Rows[0];
                                    num2 = Program.StrToDouble(((DataGridViewTextBoxCell) row2.Cells["quantity"]).Value.ToString(), 0);
                                    num3 = Program.StrToDouble(this.t_os.DR["Nett"].ToString(), 0);
                                    ((DataGridViewTextBoxCell) row2.Cells["used"]).Value = num3;
                                    num4 = num2 - num3;
                                    ((DataGridViewTextBoxCell) row2.Cells["outstanding"]).Value = num4;
                                    this.used += num3;
                                    ((DataGridViewTextBoxCell) row2.Cells["AMSQuantity"]).Value = Program.StrToDouble(((num2 * num) / 100.0).ToString(), 0);
                                    num5 = Program.StrToDouble(this.t_os.DR["OPW_Nett"].ToString(), 0);
                                    ((DataGridViewTextBoxCell) row2.Cells["OPW_Used"]).Value = num5;
                                }
                            }
                            this.text_used.Text = this.used.ToString();
                            this.text_remain.Text = (Program.StrToDouble(this.text_qty.Text, 0) - this.used).ToString();
                            this.InitDGVSplit();
                        }
                    }
                }
            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            int num8;
            long num9;
            long num10;
            int num19;
            string str = "";
            long num = this.getTotalWeighedNet(this.text_DO.Text.Trim());
            long num2 = this.getTotalDOAnakQty(this.dgv_item);
            long num3 = num - num2;
            long num4 = Convert.ToInt64(Program.getFieldValue("wb_contract", "quantity", "do_no", this.text_DO.Text));
            double num5 = (((double) num3) / ((double) num2)) * 100.0;
            double num6 = this.getDOVesselLimitTolerance(this.text_DO.Text.Trim());
            double num7 = 100.0 - num6;
            if ((this.dovessel_completed != "Y") || (num5 >= (-1.0 * num7)))
            {
                this.dgv_split.Rows.Clear();
                str = Program.getFieldValue("wb_contract", "uniq", "do_no", this.text_DO.Text);
                string[] textArray1 = new string[9];
                textArray1[0] = "select * from wb_transaction\r\n                        where Coy = '";
                textArray1[1] = WBData.sCoyCode;
                textArray1[2] = "' and Location_Code = '";
                textArray1[3] = WBData.sLocCode;
                textArray1[4] = "' and Do_No in (\r\n                        select do_no from wb_contract where uniq in \r\n                        (select uniq_item from wb_vessel_map where uniq_vessel = '";
                textArray1[5] = str;
                textArray1[6] = "') or uniq = '";
                textArray1[7] = str;
                textArray1[8] = "')\r\n                        AND ((mark_accident IS NULL) AND (Deleted IS NULL) AND\r\n                        (@replaceDate) OR(mark_accident = '') AND (Deleted = ''))\r\n                        order by report_date asc, ref asc;";
                string sqltext = string.Concat(textArray1);
                if (this.rb_all.Checked)
                {
                    sqltext = sqltext.Replace("@replaceDate", "report_date is not null");
                }
                else if (this.rb_date.Checked)
                {
                    sqltext = sqltext.Replace("@replaceDate", "report_date <= '" + this.date_trans.Value.ToString("yyyy-MM-dd") + " 23:59:59'");
                }
                this.t_trans.OpenTable("wb_transaction", sqltext, WBData.conn);
                this.n_ref = this.t_trans.DT.Rows.Count;
                if (this.n_ref != 0)
                {
                    if (num4 == num2)
                    {
                        num8 = 0;
                        num9 = 0L;
                        num10 = this.getTotalDOAnakAMSQty(this.dgv_item);
                        if (this.dovessel_completed == "Y")
                        {
                            long num11 = 0L;
                            int num12 = 0;
                            while (true)
                            {
                                if (num12 >= this.dgv_item.Rows.Count)
                                {
                                    break;
                                }
                                long num13 = Convert.ToInt64(this.t_item.DT.Rows[num12]["Quantity"].ToString());
                                long num14 = Convert.ToInt64(this.t_item.DT.Rows[num12]["AMSQuantity"].ToString());
                                long num15 = 0L;
                                long num16 = 0L;
                                long num17 = 0L;
                                bool flag8 = num12 == (this.t_item.DT.Rows.Count - 1);
                                num15 = !flag8 ? Convert.ToInt64(Program.StrToDouble(((((double) num13) / ((double) num2)) * num3).ToString(), 0)) : (num3 - num11);
                                num11 += num15;
                                ((DataGridViewTextBoxCell) this.dgv_item.Rows[num12].Cells["GainLoss"]).Value = num15;
                                num16 = num13 - num14;
                                ((DataGridViewTextBoxCell) this.dgv_item.Rows[num12].Cells["VesselOPWPropor"]).Value = num16;
                                num17 = num16 + num15;
                                ((DataGridViewTextBoxCell) this.dgv_item.Rows[num12].Cells["VesselFactPropor"]).Value = num17;
                                num12++;
                            }
                        }
                        num19 = 0;
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Error_Qty_Vessel_Not_Equal, Resource.Mes_Error_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("No Transaction found.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            else
            {
                object[] objArray1 = new object[11];
                objArray1[0] = "Over Loss Tolerance between Total Weighed Net of DO Vessel and Total Qty of all Mapped DO Vessel.\n\nTotal Weighed Net \t\t: ";
                objArray1[1] = num;
                objArray1[2] = " KG\nTotal Qty of all Mapped DO Vessel \t: ";
                objArray1[3] = num2;
                objArray1[4] = " KG\nAMS Tolerance \t\t\t: ";
                objArray1[5] = num6;
                objArray1[6] = " %\nTotal Gain/Loss \t\t\t: ";
                objArray1[7] = num3;
                objArray1[8] = "\nGain/Loss Percentage \t\t: ";
                objArray1[9] = Program.StrToDouble(num5.ToString(), 2);
                objArray1[10] = " %\n\nPlease perform Auto Merge DO Vessel and Revise the Tolerance Percentage from Map DO Vessel menu at Master Data Contract.";
                MessageBox.Show(string.Concat(objArray1), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            goto TR_003C;
        TR_0007:
            num19++;
        TR_003C:
            while (true)
            {
                if (num19 >= this.n_ref)
                {
                    if (num8 >= this.n_ref)
                    {
                        MessageBox.Show("Number of Ref found : " + this.n_ref.ToString() + ".\nPlease check Split Simulation before proceeding.\nThank you.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        object[] objArray4 = new object[] { "Number of Ref found : ", this.n_ref.ToString(), ".\nNumber of Ignored Ref found : ", this.n_ref - num8, ".\nPlease check Split Simulation before proceeding.\n\nFor Ignored Ref(s), Please mark DO Vessel as Completed to able to split them.\nThank you." };
                        MessageBox.Show(string.Concat(objArray4), "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    break;
                }
                DataRow row = this.t_trans.DT.Rows[num19];
                WBTable table = new WBTable();
                bool flag10 = false;
                int num20 = 0x40;
                long num21 = long.Parse(row["Net"].ToString());
                table.OpenTable("wb_transDO", "select * from wb_transDO where ref = '" + row["ref"].ToString() + "'", WBData.conn);
                table.DR = table.DT.Rows[0];
                num9 += num21;
                if ((num9 <= num10) || ((num9 > num10) && (this.dovessel_completed == "Y")))
                {
                    num8 = num19 + 1;
                    if ((row["Split"].ToString() != "Y") && (row["Split"].ToString() != "X"))
                    {
                        using (IEnumerator enumerator = ((IEnumerable) this.dgv_item.Rows).GetEnumerator())
                        {
                            while (true)
                            {
                                if (enumerator.MoveNext())
                                {
                                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                                    string str3 = ((DataGridViewTextBoxCell) current.Cells["do_no"]).Value.ToString();
                                    long num24 = Convert.ToInt64(((DataGridViewTextBoxCell) current.Cells["quantity"]).Value.ToString());
                                    long num25 = Convert.ToInt64(((DataGridViewTextBoxCell) current.Cells["AMSquantity"]).Value.ToString());
                                    long num26 = this.getTotalUsedFactNetInDGV(this.dgv_split, str3);
                                    long num27 = num25 - num26;
                                    long num28 = 0L;
                                    long num29 = 0L;
                                    if (num21 != 0L)
                                    {
                                        if (num21 >= 0L)
                                        {
                                            if (num27 <= 0L)
                                            {
                                                continue;
                                            }
                                            if ((num21 - num27) >= 0L)
                                            {
                                                num28 = num27;
                                                num29 = num28;
                                            }
                                            else
                                            {
                                                num28 = num21;
                                                num29 = num28;
                                            }
                                            num21 -= Convert.ToInt64(num28);
                                            this.dgv_split.Rows.Add();
                                            int num30 = this.dgv_split.Rows.Count - 1;
                                            if (!flag10)
                                            {
                                                this.dgv_split.Rows[num30].Cells["REF"].Value = row["Ref"].ToString();
                                                this.dgv_split.Rows[num30].Cells["DATE"].Value = row["Report_Date"].ToString();
                                                this.dgv_split.Rows[num30].Cells["DO_NO"].Value = str3;
                                                this.dgv_split.Rows[num30].Cells["FACTORY_GROSS"].Value = (((Program.StrToDouble(table.DR["Tarra"].ToString(), 0) + num28) + Program.StrToDouble(row["Deduction"].ToString(), 0)) + Program.StrToDouble(row["MaterialStuffing"].ToString(), 0)).ToString();
                                                this.dgv_split.Rows[num30].Cells["FACTORY_TARE"].Value = table.DR["Tarra"].ToString();
                                                this.dgv_split.Rows[num30].Cells["FACTORY_NET"].Value = num28;
                                                this.dgv_split.Rows[num30].Cells["OPW_GROSS"].Value = num29;
                                                this.dgv_split.Rows[num30].Cells["OPW_TARE"].Value = "0";
                                                this.dgv_split.Rows[num30].Cells["OPW_NET"].Value = num29;
                                                this.dgv_split.Rows[num30].Cells["SPLIT"].Value = "NEW_Y";
                                                flag10 = true;
                                            }
                                            else
                                            {
                                                num20++;
                                                this.dgv_split.Rows[num30].Cells["REF"].Value = row["Ref"].ToString() + WBUtility.getSplitV2Ext(num20);
                                                this.dgv_split.Rows[num30].Cells["DATE"].Value = row["Report_Date"].ToString();
                                                this.dgv_split.Rows[num30].Cells["DO_NO"].Value = str3;
                                                this.dgv_split.Rows[num30].Cells["FACTORY_GROSS"].Value = num28.ToString();
                                                this.dgv_split.Rows[num30].Cells["FACTORY_TARE"].Value = "0";
                                                this.dgv_split.Rows[num30].Cells["FACTORY_NET"].Value = num28.ToString();
                                                this.dgv_split.Rows[num30].Cells["OPW_GROSS"].Value = num29;
                                                this.dgv_split.Rows[num30].Cells["OPW_TARE"].Value = "0";
                                                this.dgv_split.Rows[num30].Cells["OPW_NET"].Value = num29;
                                                this.dgv_split.Rows[num30].Cells["SPLIT"].Value = "NEW_X";
                                            }
                                            continue;
                                        }
                                        object[] objArray2 = new object[] { "Fatal error when use AMS Tolerance do_no : ", str3, ", temp_net : ", num21 };
                                        MessageBox.Show(string.Concat(objArray2));
                                        break;
                                    }
                                }
                                break;
                            }
                        }
                        if ((num9 <= num10) || (this.dovessel_completed != "Y"))
                        {
                            goto TR_0007;
                        }
                        else
                        {
                            using (IEnumerator enumerator2 = ((IEnumerable) this.dgv_item.Rows).GetEnumerator())
                            {
                                while (true)
                                {
                                    if (enumerator2.MoveNext())
                                    {
                                        DataGridViewRow current = (DataGridViewRow) enumerator2.Current;
                                        string str4 = ((DataGridViewTextBoxCell) current.Cells["do_no"]).Value.ToString();
                                        long num31 = Convert.ToInt64(((DataGridViewTextBoxCell) current.Cells["quantity"]).Value.ToString());
                                        long num32 = Convert.ToInt64(((DataGridViewTextBoxCell) current.Cells["AMSquantity"]).Value.ToString());
                                        long num33 = Convert.ToInt64(((DataGridViewTextBoxCell) current.Cells["VesselOPWPropor"]).Value.ToString());
                                        long num34 = Convert.ToInt64(((DataGridViewTextBoxCell) current.Cells["VesselFactPropor"]).Value.ToString());
                                        long num35 = this.getTotalUsedOPWNetInDGV(this.dgv_split, str4);
                                        long num36 = (num32 + num33) - num35;
                                        long num37 = this.getTotalUsedFactNetInDGV(this.dgv_split, str4);
                                        long num38 = (num32 + num34) - num37;
                                        long num39 = 0L;
                                        long num40 = 0L;
                                        if (num21 != 0L)
                                        {
                                            if (num21 >= 0L)
                                            {
                                                if (num38 <= 0L)
                                                {
                                                    continue;
                                                }
                                                if ((num21 - num38) >= 0L)
                                                {
                                                    num40 = num38;
                                                    num39 = (this.dovessel_afterTolerance != "1") ? ((num34 != num38) ? num36 : num33) : num40;
                                                }
                                                else
                                                {
                                                    num40 = num21;
                                                    num39 = (this.dovessel_afterTolerance != "1") ? ((num34 != num21) ? Convert.ToInt64(Program.StrToDouble(((((double) num40) / ((double) num34)) * num33).ToString(), 0)) : num33) : num40;
                                                }
                                                num21 -= Convert.ToInt64(num40);
                                                this.dgv_split.Rows.Add();
                                                int num41 = this.dgv_split.Rows.Count - 1;
                                                if (!flag10)
                                                {
                                                    this.dgv_split.Rows[num41].Cells["REF"].Value = row["Ref"].ToString();
                                                    this.dgv_split.Rows[num41].Cells["DATE"].Value = row["Report_Date"].ToString();
                                                    this.dgv_split.Rows[num41].Cells["DO_NO"].Value = str4;
                                                    this.dgv_split.Rows[num41].Cells["FACTORY_GROSS"].Value = (((Program.StrToDouble(table.DR["Tarra"].ToString(), 0) + num40) + Program.StrToDouble(row["Deduction"].ToString(), 0)) + Program.StrToDouble(row["MaterialStuffing"].ToString(), 0)).ToString();
                                                    this.dgv_split.Rows[num41].Cells["FACTORY_TARE"].Value = table.DR["Tarra"].ToString();
                                                    this.dgv_split.Rows[num41].Cells["FACTORY_NET"].Value = num40;
                                                    this.dgv_split.Rows[num41].Cells["OPW_GROSS"].Value = num39;
                                                    this.dgv_split.Rows[num41].Cells["OPW_TARE"].Value = "0";
                                                    this.dgv_split.Rows[num41].Cells["OPW_NET"].Value = num39;
                                                    this.dgv_split.Rows[num41].Cells["SPLIT"].Value = "NEW_Y";
                                                    flag10 = true;
                                                }
                                                else
                                                {
                                                    num20++;
                                                    this.dgv_split.Rows[num41].Cells["REF"].Value = row["Ref"].ToString() + WBUtility.getSplitV2Ext(num20);
                                                    this.dgv_split.Rows[num41].Cells["DATE"].Value = row["Report_Date"].ToString();
                                                    this.dgv_split.Rows[num41].Cells["DO_NO"].Value = str4;
                                                    this.dgv_split.Rows[num41].Cells["FACTORY_GROSS"].Value = num40.ToString();
                                                    this.dgv_split.Rows[num41].Cells["FACTORY_TARE"].Value = "0";
                                                    this.dgv_split.Rows[num41].Cells["FACTORY_NET"].Value = num40.ToString();
                                                    this.dgv_split.Rows[num41].Cells["OPW_GROSS"].Value = num39;
                                                    this.dgv_split.Rows[num41].Cells["OPW_TARE"].Value = "0";
                                                    this.dgv_split.Rows[num41].Cells["OPW_NET"].Value = num39;
                                                    this.dgv_split.Rows[num41].Cells["SPLIT"].Value = "NEW_X";
                                                }
                                                continue;
                                            }
                                            object[] objArray3 = new object[] { "Fatal error when use AML Tolerance do_no : ", str4, ", temp_net : ", num21 };
                                            MessageBox.Show(string.Concat(objArray3));
                                        }
                                        else
                                        {
                                            goto TR_0007;
                                        }
                                    }
                                    else
                                    {
                                        goto TR_0007;
                                    }
                                    break;
                                }
                            }
                        }
                        break;
                    }
                    else
                    {
                        this.dgv_split.Rows.Add();
                        int num22 = this.dgv_split.Rows.Count - 1;
                        this.dgv_split.Rows[num22].Cells["REF"].Value = row["Ref"].ToString();
                        this.dgv_split.Rows[num22].Cells["DATE"].Value = row["Report_Date"].ToString();
                        this.dgv_split.Rows[num22].Cells["DO_NO"].Value = row["Do_No"].ToString();
                        this.dgv_split.Rows[num22].Cells["FACTORY_GROSS"].Value = row["Gross"].ToString();
                        this.dgv_split.Rows[num22].Cells["FACTORY_TARE"].Value = row["Tare"].ToString();
                        this.dgv_split.Rows[num22].Cells["FACTORY_NET"].Value = row["Net"].ToString();
                        this.dgv_split.Rows[num22].Cells["OPW_GROSS"].Value = row["Gross_Estate"].ToString();
                        this.dgv_split.Rows[num22].Cells["OPW_TARE"].Value = row["Tare_Estate"].ToString();
                        this.dgv_split.Rows[num22].Cells["OPW_NET"].Value = row["Net_Estate"].ToString();
                        this.dgv_split.Rows[num22].Cells["SPLIT"].Value = row["Split"].ToString();
                        int num23 = 0;
                        while (true)
                        {
                            if (num23 >= this.dgv_split.ColumnCount)
                            {
                                break;
                            }
                            this.dgv_split[num23, num22].Style.BackColor = Color.PaleGreen;
                            num23++;
                        }
                    }
                }
                goto TR_0007;
            }
        }

        private void btn_Split_Click(object sender, EventArgs e)
        {
            int count = this.dgv_split.Rows.Count;
            if (count == 0)
            {
                MessageBox.Show("No Record to Split", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (MessageBox.Show("Are you sure you want to Split?", "Please confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Cursor.Current = Cursors.WaitCursor;
                int num2 = 0;
                while (true)
                {
                    if (num2 >= count)
                    {
                        Cursor.Current = Cursors.Default;
                        MessageBox.Show("Split Completed", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        base.Close();
                        break;
                    }
                    string str = this.dgv_split.Rows[num2].Cells["SPLIT"].Value.ToString();
                    string str2 = this.dgv_split.Rows[num2].Cells["REF"].Value.ToString();
                    string str3 = this.dgv_split.Rows[num2].Cells["DO_NO"].Value.ToString();
                    string str4 = this.dgv_split.Rows[num2].Cells["FACTORY_GROSS"].Value.ToString();
                    string str5 = this.dgv_split.Rows[num2].Cells["FACTORY_TARE"].Value.ToString();
                    string str6 = this.dgv_split.Rows[num2].Cells["FACTORY_NET"].Value.ToString();
                    string str7 = this.dgv_split.Rows[num2].Cells["OPW_GROSS"].Value.ToString();
                    string str8 = this.dgv_split.Rows[num2].Cells["OPW_TARE"].Value.ToString();
                    string str9 = this.dgv_split.Rows[num2].Cells["OPW_NET"].Value.ToString();
                    if ((str == "NEW_X") || (str == "NEW_Y"))
                    {
                        if (str == "NEW_Y")
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE ref = '" + str2.Trim() + "'", WBData.conn);
                            DataRow row = table.DT.Rows[0];
                            this.t_do.OpenTable("wb_transDo", "SELECT * FROM wb_transdo WHERE ref = '" + str2.Trim() + "'", WBData.conn);
                            this.t_do.DR = this.t_do.DT.Rows[0];
                            this.t_do_save.OpenTable("wb_transDo", "SELECT * FROM wb_transdo WHERE ref = '" + str2.Trim() + "'", WBData.conn);
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + str3.Trim().ToUpper() + "'"), WBData.conn);
                            table2.DR = table2.DT.Rows[0];
                            WBTable table3 = new WBTable();
                            table3.OpenTable("wb_transSplit", "SELECT * FROM wb_transSplit WHERE " + WBData.CompanyLocation(" AND ref = '" + str2.Trim() + "'"), WBData.conn);
                            if (table3.DT.Rows.Count > 0)
                            {
                                table3.DT.Rows[0].Delete();
                                table3.Save();
                                table3.ReOpen();
                            }
                            table3.DR = table3.DT.NewRow();
                            foreach (DataColumn column in table3.DT.Columns)
                            {
                                if (column.ColumnName.ToUpper() != "UNIQ")
                                {
                                    table3.DR[column.ColumnName] = row[column.ColumnName];
                                }
                            }
                            table3.DT.Rows.Add(table3.DR);
                            table3.Save();
                            table.DR = table.DT.Rows[0];
                            table.DR.BeginEdit();
                            table.DR["NOPW"] = "N";
                            table.DR["do_no"] = str3;
                            table.DR["Split"] = "Y";
                            table.DR["Transaction_Code"] = Program.getFieldValue("wb_contract", "transaction_code", "DO_NO", str3.Trim().ToString());
                            table.DR["Comm_Code"] = table2.DR["Comm_Code"].ToString().Trim();
                            table.DR["Relation_Code"] = table2.DR["Relation_Code"].ToString().Trim();
                            table.DR["Estate"] = table2.DR["Estate1_Code"].ToString().Trim();
                            table.DR["Transporter_Code"] = table2.DR["Transporter_Code"].ToString().Trim();
                            table.DR["PI_No"] = table2.DR["PI_No"].ToString();
                            table.DR["Gross"] = str4;
                            table.DR["Tare"] = str5;
                            table.DR["Net"] = str6;
                            table.DR["Received"] = Convert.ToInt64(str4) - Convert.ToInt64(str5);
                            table.DR["Gross_estate"] = str7;
                            table.DR["Net_estate"] = str9;
                            table.DR["Tare_estate"] = str8;
                            double num3 = Program.StrToDouble(table.DR["_1ST"].ToString(), 0);
                            double num4 = Program.StrToDouble(table.DR["_2ND"].ToString(), 0);
                            if (table.DR["WX"].ToString() == "2X")
                            {
                                if (Program.StrToDouble(table.DR["_1ST"].ToString(), 0) > Program.StrToDouble(table.DR["_2ND"].ToString(), 0))
                                {
                                    table.DR["_1ST"] = table.DR["Gross"].ToString();
                                    table.DR["_2ND"] = table.DR["Tare"].ToString();
                                }
                                else
                                {
                                    table.DR["_1ST"] = table.DR["Tare"].ToString();
                                    table.DR["_2ND"] = table.DR["Gross"].ToString();
                                }
                            }
                            table.DR["posted"] = "N";
                            table.DR["checksum"] = table.Checksum(table.DR);
                            table.DR.EndEdit();
                            table.Save();
                            this.t_do_save.DR = this.t_do_save.DT.Rows[0];
                            this.t_do_save.DR.BeginEdit();
                            this.t_do_save.DR["DO_No"] = str3;
                            this.t_do_save.DR["Contract"] = table2.DR["Contract"].ToString();
                            this.t_do_save.DR["PI_No"] = table2.DR["PI_No"].ToString();
                            this.t_do_save.DR["Netto"] = str6;
                            this.t_do_save.DR["Tarra"] = str5;
                            this.t_do_save.DR["Bruto"] = str4;
                            this.t_do_save.DR["Estate_qty"] = str9;
                            this.t_do_save.DR["Transaction_Code"] = Program.getFieldValue("wb_contract", "transaction_code", "DO_NO", str3.Trim().ToString());
                            this.t_do_save.DR["Comm_Code"] = table2.DR["Comm_Code"].ToString().Trim();
                            this.t_do_save.DR["Relation_Code"] = table2.DR["Relation_Code"].ToString().Trim();
                            this.t_do_save.DR["Estate"] = table2.DR["Estate1_Code"].ToString().Trim();
                            this.t_do_save.DR["Transporter_Code"] = table2.DR["Transporter_Code"].ToString().Trim();
                            this.t_do_save.DR["Relation_Name"] = Program.getFieldValue("wb_relation", "relation_name", "relation_code", table2.DR["Relation_Code"].ToString().Trim());
                            this.t_do_save.DR.EndEdit();
                            this.t_do_save.Save();
                            table.Dispose();
                            this.t_do.Dispose();
                            this.t_do_save.Dispose();
                            table3.Dispose();
                            table2.Dispose();
                        }
                        else if (str == "NEW_X")
                        {
                            WBTable table4 = new WBTable();
                            table4.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE ref = '" + str2.Trim().Substring(0, str2.Length - 2) + "'", WBData.conn);
                            DataRow row2 = table4.DT.Rows[0];
                            this.t_do.OpenTable("wb_transDo", "SELECT * FROM wb_transdo WHERE ref = '" + str2.Trim().Substring(0, str2.Length - 2) + "'", WBData.conn);
                            this.t_do.DR = this.t_do.DT.Rows[0];
                            this.t_do_save.OpenTable("wb_transDo", "SELECT * FROM wb_transdo WHERE ref = '" + str2.Trim().Substring(0, str2.Length - 2) + "'", WBData.conn);
                            WBTable table5 = new WBTable();
                            table5.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + str3.Trim().ToUpper() + "'"), WBData.conn);
                            table5.DR = table5.DT.Rows[0];
                            table4.DR = table4.DT.NewRow();
                            int num6 = 0;
                            while (true)
                            {
                                if (num6 >= table4.DT.Columns.Count)
                                {
                                    table4.DR["NOPW"] = "N";
                                    table4.DR["Split"] = "X";
                                    if (table4.DR["WX"].ToString() == "2X")
                                    {
                                        if (Program.StrToDouble(table4.DR["_1ST"].ToString(), 0) > Program.StrToDouble(table4.DR["_2ND"].ToString(), 0))
                                        {
                                            table4.DR["_1ST"] = str6;
                                            table4.DR["_2ND"] = "0";
                                        }
                                        else
                                        {
                                            table4.DR["_1ST"] = "0";
                                            table4.DR["_2ND"] = str6;
                                        }
                                    }
                                    table4.DR["Transaction_Code"] = Program.getFieldValue("wb_contract", "transaction_code", "DO_NO", str3.Trim().ToString());
                                    table4.DR["Comm_Code"] = table5.DR["Comm_Code"].ToString().Trim();
                                    table4.DR["Relation_Code"] = table5.DR["Relation_Code"].ToString().Trim();
                                    table4.DR["Estate"] = table5.DR["Estate1_Code"].ToString().Trim();
                                    table4.DR["Transporter_Code"] = table5.DR["Transporter_Code"].ToString().Trim();
                                    table4.DR["PI_No"] = table5.DR["PI_No"].ToString();
                                    table4.DR["Ref"] = str2;
                                    table4.DR["DO_No"] = str3;
                                    table4.DR["Gross"] = str6;
                                    table4.DR["Tare"] = "0";
                                    table4.DR["Printed"] = "0";
                                    table4.DR["Received"] = str6;
                                    table4.DR["Net"] = str6;
                                    table4.DR["Deduction"] = "0";
                                    table4.DR["MaterialStuffing"] = "0";
                                    table4.DR["TotalBunch"] = 0;
                                    table4.DR["TotalBunchGrading"] = 0;
                                    table4.DR["UnitName"] = "";
                                    table4.DR["WeightPerUnitName"] = 0;
                                    table4.DR["Average"] = 0;
                                    table4.DR["Gross_estate"] = str7;
                                    table4.DR["Net_estate"] = str9;
                                    table4.DR["Tare_estate"] = str8;
                                    table4.DR["posted"] = "N";
                                    table4.DR["checksum"] = table4.Checksum(table4.DR);
                                    table4.DT.Rows.Add(table4.DR);
                                    table4.Save();
                                    this.t_do_save.ReOpen();
                                    this.t_do_save.DR = this.t_do_save.DT.NewRow();
                                    int num7 = 0;
                                    while (true)
                                    {
                                        if (num7 >= this.t_do_save.DT.Columns.Count)
                                        {
                                            this.t_do_save.DR["Ref"] = str2;
                                            this.t_do_save.DR["DO_No"] = str3;
                                            this.t_do_save.DR["Contract"] = table5.DR["Contract"].ToString();
                                            this.t_do_save.DR["PI_No"] = table5.DR["PI_No"].ToString();
                                            this.t_do_save.DR["Bruto"] = str6;
                                            this.t_do_save.DR["Tarra"] = 0;
                                            this.t_do_save.DR["Netto"] = str6;
                                            this.t_do_save.DR["Estate_qty"] = str9;
                                            this.t_do_save.DR["Transaction_Code"] = table5.DR["Transaction_Code"].ToString().Trim();
                                            this.t_do_save.DR["Comm_Code"] = table5.DR["Comm_Code"].ToString().Trim();
                                            this.t_do_save.DR["Relation_Code"] = table5.DR["Relation_Code"].ToString().Trim();
                                            this.t_do_save.DR["Estate"] = table5.DR["Estate1_Code"].ToString().Trim();
                                            this.t_do_save.DR["Transporter_Code"] = table5.DR["Transporter_Code"].ToString().Trim();
                                            this.t_do_save.DR["Relation_Name"] = Program.getFieldValue("wb_relation", "relation_name", "relation_code", table5.DR["Relation_Code"].ToString().Trim());
                                            this.t_do_save.DT.Rows.Add(this.t_do_save.DR);
                                            this.t_do_save.Save();
                                            table4.Dispose();
                                            this.t_do.Dispose();
                                            this.t_do_save.Dispose();
                                            table5.Dispose();
                                            break;
                                        }
                                        bool flag15 = this.t_do_save.DT.Columns[num7].ColumnName.ToUpper() != "UNIQ";
                                        if (flag15 && (this.t_do.DR[num7].ToString().Trim() != ""))
                                        {
                                            this.t_do_save.DR[this.t_do_save.DT.Columns[num7].ColumnName] = this.t_do.DR[num7].ToString();
                                        }
                                        num7++;
                                    }
                                    break;
                                }
                                bool flag10 = table4.DT.Columns[num6].ColumnName.ToUpper() != "UNIQ";
                                if (flag10 && (row2[num6].ToString().Trim() != ""))
                                {
                                    table4.DR[table4.DT.Columns[num6].ColumnName] = row2[num6].ToString();
                                }
                                num6++;
                            }
                        }
                    }
                    num2++;
                }
            }
        }

        private void buttonDO_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                vessel = true,
                pFind = this.text_DO.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.text_DO.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormSplitDoVessel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormSplitDoVessel_Load(object sender, EventArgs e)
        {
            this.gb_detail.Visible = false;
            this.gb_info.Visible = false;
            this.panel_info.Visible = false;
            this.gb_filter.Visible = false;
            string sqltext = "SELECT * FROM wb_contract WHERE " + WBData.CompanyLocation(" AND uniq IN (SELECT uniq_vessel FROM wb_vessel_map GROUP BY uniq_vessel) ORDER BY do_no");
            this.s_help.OpenTable("wb_contract", sqltext, WBData.conn);
            Program.AutoComp(this.s_help, "do_no", this.text_DO);
            this.date_trans.Value = DateTime.Now.Date.AddDays(-1.0);
        }

        private double getDOVesselLimitTolerance(string do_ayah)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_contract", "SELECT * FROM wb_contract WHERE do_no = '" + do_ayah + "'", WBData.conn);
            return ((table.DT.Rows.Count <= 0) ? this.load_WBLocation_VesselLimitTolerance() : (!string.IsNullOrEmpty(table.DT.Rows[0]["VesselLimitTolerance"].ToString()) ? Convert.ToDouble(table.DT.Rows[0]["VesselLimitTolerance"].ToString()) : this.load_WBLocation_VesselLimitTolerance()));
        }

        private long getTotalDOAnakAMSQty(DataGridView _dgv_item)
        {
            long num = 0L;
            foreach (DataGridViewRow row in (IEnumerable) _dgv_item.Rows)
            {
                num += Convert.ToInt64(((DataGridViewTextBoxCell) row.Cells["AMSquantity"]).Value.ToString());
            }
            return num;
        }

        private long getTotalDOAnakQty(DataGridView _dgv_item)
        {
            long num = 0L;
            foreach (DataGridViewRow row in (IEnumerable) _dgv_item.Rows)
            {
                num += Convert.ToInt64(((DataGridViewTextBoxCell) row.Cells["quantity"]).Value.ToString());
            }
            return num;
        }

        private long getTotalUsedFactNetInDGV(DataGridView _dgv_split, string do_no)
        {
            long num = 0L;
            foreach (DataRow row in this.t_trans.DT.Rows)
            {
                if (((row["Split"].ToString() == "X") || ((row["Split"].ToString() == "Y") || ((row["Split"].ToString() == "NEW_X") || (row["Split"].ToString() == "NEW_Y")))) ? (row["Do_No"].ToString() == do_no) : false)
                {
                    num += Convert.ToInt64(row["Net"].ToString());
                }
            }
            foreach (DataGridViewRow row2 in (IEnumerable) _dgv_split.Rows)
            {
                if ((((DataGridViewTextBoxCell) row2.Cells["DO_NO"]).Value.ToString() == do_no) && ((((DataGridViewTextBoxCell) row2.Cells["Split"]).Value.ToString() == "NEW_X") || (((DataGridViewTextBoxCell) row2.Cells["Split"]).Value.ToString() == "NEW_Y")))
                {
                    num += Convert.ToInt64(((DataGridViewTextBoxCell) row2.Cells["FACTORY_NET"]).Value.ToString());
                }
            }
            return num;
        }

        private long getTotalUsedOPWNetInDGV(DataGridView _dgv_split, string do_no)
        {
            long num = 0L;
            foreach (DataRow row in this.t_trans.DT.Rows)
            {
                if (((row["Split"].ToString() == "X") || ((row["Split"].ToString() == "Y") || ((row["Split"].ToString() == "NEW_X") || (row["Split"].ToString() == "NEW_Y")))) ? (row["Do_No"].ToString() == do_no) : false)
                {
                    num += Convert.ToInt64(row["Net_Estate"].ToString());
                }
            }
            foreach (DataGridViewRow row2 in (IEnumerable) _dgv_split.Rows)
            {
                if ((((DataGridViewTextBoxCell) row2.Cells["DO_NO"]).Value.ToString() == do_no) && ((((DataGridViewTextBoxCell) row2.Cells["Split"]).Value.ToString() == "NEW_X") || (((DataGridViewTextBoxCell) row2.Cells["Split"]).Value.ToString() == "NEW_Y")))
                {
                    num += Convert.ToInt64(((DataGridViewTextBoxCell) row2.Cells["opw_net"]).Value.ToString());
                }
            }
            return num;
        }

        private long getTotalWeighedNet(string do_ayah)
        {
            long num = 0L;
            string str = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_contract", "select * from wb_contract where do_no = '" + do_ayah + "'", WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                str = table.DT.Rows[0]["uniq"].ToString();
            }
            if (!string.IsNullOrEmpty(str))
            {
                string[] textArray1 = new string[9];
                textArray1[0] = "select Sum(Net) as TotalWeighedNet from wb_transaction\r\n                                      where Coy = '";
                textArray1[1] = WBData.sCoyCode;
                textArray1[2] = "' and Location_Code = '";
                textArray1[3] = WBData.sLocCode;
                textArray1[4] = "' and Do_No in (\r\n                                      select do_no from wb_contract where uniq in \r\n                                      (select uniq_item from wb_vessel_map where uniq_vessel = '";
                textArray1[5] = str;
                textArray1[6] = "') or uniq = '";
                textArray1[7] = str;
                textArray1[8] = "')\r\n                                      AND((mark_accident IS NULL) AND(Deleted IS NULL) AND\r\n                                    (Report_Date IS NOT NULL) OR(mark_accident = '') AND(Deleted = ''))";
                string sqltext = string.Concat(textArray1);
                table.OpenTable("wb_vessel_map", sqltext, WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    num = Convert.ToInt64(table.DT.Rows[0]["TotalWeighedNet"].ToString());
                }
            }
            return num;
        }

        private void InitDGVSplit()
        {
            this.dgv_split.Rows.Clear();
            this.dgv_split.ColumnCount = 10;
            this.dgv_split.Columns[0].Name = "REF";
            this.dgv_split.Columns[0].HeaderText = "Ref No";
            this.dgv_split.Columns[1].Name = "DATE";
            this.dgv_split.Columns[1].HeaderText = "Report Date";
            this.dgv_split.Columns[2].Name = "DO_NO";
            this.dgv_split.Columns[2].HeaderText = "Do No";
            this.dgv_split.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dgv_split.Columns[3].Name = "FACTORY_GROSS";
            this.dgv_split.Columns[3].HeaderText = "Gross";
            this.dgv_split.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dgv_split.Columns[4].Name = "FACTORY_TARE";
            this.dgv_split.Columns[4].HeaderText = "Tare";
            this.dgv_split.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dgv_split.Columns[5].Name = "FACTORY_NET";
            this.dgv_split.Columns[5].HeaderText = "Net";
            this.dgv_split.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dgv_split.Columns[6].Name = "OPW_GROSS";
            this.dgv_split.Columns[6].HeaderText = "Other Party Gross";
            this.dgv_split.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dgv_split.Columns[7].Name = "OPW_TARE";
            this.dgv_split.Columns[7].HeaderText = "Other Party Tare";
            this.dgv_split.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dgv_split.Columns[8].Name = "OPW_NET";
            this.dgv_split.Columns[8].HeaderText = "Other Party Net";
            this.dgv_split.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dgv_split.Columns[9].Name = "SPLIT";
            this.dgv_split.Columns[9].HeaderText = "Split Flag";
            this.dgv_split.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dgv_split.Columns[9].Visible = false;
        }

        private void InitializeComponent()
        {
            this.gb_header = new GroupBox();
            this.buttonDO = new Button();
            this.label_do_complete = new Label();
            this.panel_info = new Panel();
            this.date_DO = new DateTimePicker();
            this.label2 = new Label();
            this.text_qty = new TextBox();
            this.label1 = new Label();
            this.btn_go = new Button();
            this.text_DO = new TextBox();
            this.gb_detail = new GroupBox();
            this.label6 = new Label();
            this.label5 = new Label();
            this.btn_cancel = new Button();
            this.btn_Split = new Button();
            this.dgv_split = new DataGridView();
            this.gb_filter = new GroupBox();
            this.btn_search = new Button();
            this.rb_date = new RadioButton();
            this.rb_all = new RadioButton();
            this.date_trans = new DateTimePicker();
            this.gb_info = new GroupBox();
            this.label4 = new Label();
            this.text_remain = new TextBox();
            this.label3 = new Label();
            this.text_used = new TextBox();
            this.dgv_item = new DataGridView();
            this.gb_header.SuspendLayout();
            this.panel_info.SuspendLayout();
            this.gb_detail.SuspendLayout();
            ((ISupportInitialize) this.dgv_split).BeginInit();
            this.gb_filter.SuspendLayout();
            this.gb_info.SuspendLayout();
            ((ISupportInitialize) this.dgv_item).BeginInit();
            base.SuspendLayout();
            this.gb_header.Controls.Add(this.buttonDO);
            this.gb_header.Controls.Add(this.label_do_complete);
            this.gb_header.Controls.Add(this.panel_info);
            this.gb_header.Controls.Add(this.btn_go);
            this.gb_header.Controls.Add(this.text_DO);
            this.gb_header.Location = new Point(0, 0);
            this.gb_header.Name = "gb_header";
            this.gb_header.Size = new Size(0x116, 0x89);
            this.gb_header.TabIndex = 0;
            this.gb_header.TabStop = false;
            this.gb_header.Text = "DO Vessel";
            this.buttonDO.Location = new Point(0xf9, 0x11);
            this.buttonDO.Margin = new Padding(0);
            this.buttonDO.Name = "buttonDO";
            this.buttonDO.Size = new Size(0x17, 0x17);
            this.buttonDO.TabIndex = 12;
            this.buttonDO.Text = "...";
            this.buttonDO.UseVisualStyleBackColor = true;
            this.buttonDO.Click += new EventHandler(this.buttonDO_Click);
            this.label_do_complete.AutoSize = true;
            this.label_do_complete.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label_do_complete.ForeColor = Color.DarkGreen;
            this.label_do_complete.Location = new Point(70, 50);
            this.label_do_complete.Name = "label_do_complete";
            this.label_do_complete.Size = new Size(0x94, 13);
            this.label_do_complete.TabIndex = 11;
            this.label_do_complete.Text = "DO Status: COMPLETED";
            this.label_do_complete.Visible = false;
            this.panel_info.Controls.Add(this.date_DO);
            this.panel_info.Controls.Add(this.label2);
            this.panel_info.Controls.Add(this.text_qty);
            this.panel_info.Controls.Add(this.label1);
            this.panel_info.Location = new Point(6, 0x4a);
            this.panel_info.Name = "panel_info";
            this.panel_info.Size = new Size(0x10a, 0x35);
            this.panel_info.TabIndex = 9;
            this.date_DO.Enabled = false;
            this.date_DO.Format = DateTimePickerFormat.Short;
            this.date_DO.Location = new Point(0x4f, 3);
            this.date_DO.Name = "date_DO";
            this.date_DO.Size = new Size(0x57, 20);
            this.date_DO.TabIndex = 11;
            this.date_DO.Value = new DateTime(0x7df, 7, 20, 0, 0, 0, 0);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(11, 0x20);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x41, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "DO Quantity";
            this.text_qty.Location = new Point(0x4f, 0x1d);
            this.text_qty.Name = "text_qty";
            this.text_qty.ReadOnly = true;
            this.text_qty.Size = new Size(0x7c, 20);
            this.text_qty.TabIndex = 9;
            this.text_qty.TextAlign = HorizontalAlignment.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(11, 6);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x31, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "DO Date";
            this.btn_go.Location = new Point(6, 0x2d);
            this.btn_go.Name = "btn_go";
            this.btn_go.Size = new Size(0x3a, 0x17);
            this.btn_go.TabIndex = 2;
            this.btn_go.Text = "Go";
            this.btn_go.UseVisualStyleBackColor = true;
            this.btn_go.Click += new EventHandler(this.btn_go_Click);
            this.text_DO.Location = new Point(6, 0x13);
            this.text_DO.Name = "text_DO";
            this.text_DO.Size = new Size(0xee, 20);
            this.text_DO.TabIndex = 0;
            this.text_DO.KeyPress += new KeyPressEventHandler(this.text_DO_KeyPress);
            this.gb_detail.Controls.Add(this.label6);
            this.gb_detail.Controls.Add(this.label5);
            this.gb_detail.Controls.Add(this.btn_cancel);
            this.gb_detail.Controls.Add(this.btn_Split);
            this.gb_detail.Controls.Add(this.dgv_split);
            this.gb_detail.Location = new Point(0, 0xdf);
            this.gb_detail.Name = "gb_detail";
            this.gb_detail.Size = new Size(0x306, 0x149);
            this.gb_detail.TabIndex = 1;
            this.gb_detail.TabStop = false;
            this.gb_detail.Text = "Split Simulation";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(70, 0x12f);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x7a, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "= Previously Splitted Ref";
            this.label5.AutoSize = true;
            this.label5.BackColor = Color.PaleGreen;
            this.label5.BorderStyle = BorderStyle.FixedSingle;
            this.label5.ForeColor = SystemColors.ControlLightLight;
            this.label5.Location = new Point(10, 0x12e);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x36, 15);
            this.label5.TabIndex = 13;
            this.label5.Text = "               ";
            this.btn_cancel.Location = new Point(710, 0x129);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new Size(0x3a, 0x17);
            this.btn_cancel.TabIndex = 12;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new EventHandler(this.btn_cancel_Click);
            this.btn_Split.Location = new Point(0x26e, 0x129);
            this.btn_Split.Name = "btn_Split";
            this.btn_Split.Size = new Size(0x3a, 0x17);
            this.btn_Split.TabIndex = 11;
            this.btn_Split.Text = "Split";
            this.btn_Split.UseVisualStyleBackColor = true;
            this.btn_Split.Click += new EventHandler(this.btn_Split_Click);
            this.dgv_split.AllowUserToAddRows = false;
            this.dgv_split.AllowUserToDeleteRows = false;
            this.dgv_split.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_split.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_split.Location = new Point(6, 0x13);
            this.dgv_split.Name = "dgv_split";
            this.dgv_split.ReadOnly = true;
            this.dgv_split.Size = new Size(0x2fa, 0x110);
            this.dgv_split.TabIndex = 1;
            this.gb_filter.Controls.Add(this.btn_search);
            this.gb_filter.Controls.Add(this.rb_date);
            this.gb_filter.Controls.Add(this.rb_all);
            this.gb_filter.Controls.Add(this.date_trans);
            this.gb_filter.Location = new Point(0, 0x8f);
            this.gb_filter.Name = "gb_filter";
            this.gb_filter.Size = new Size(0x116, 0x49);
            this.gb_filter.TabIndex = 0;
            this.gb_filter.TabStop = false;
            this.gb_filter.Text = "Filter";
            this.btn_search.Location = new Point(190, 0x26);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new Size(0x3a, 0x17);
            this.btn_search.TabIndex = 10;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new EventHandler(this.btn_search_Click);
            this.rb_date.AutoSize = true;
            this.rb_date.Location = new Point(6, 0x27);
            this.rb_date.Name = "rb_date";
            this.rb_date.Size = new Size(0x55, 0x11);
            this.rb_date.TabIndex = 1;
            this.rb_date.TabStop = true;
            this.rb_date.Text = "By Date (To)";
            this.rb_date.UseVisualStyleBackColor = true;
            this.rb_all.AutoSize = true;
            this.rb_all.Checked = true;
            this.rb_all.Location = new Point(6, 0x10);
            this.rb_all.Name = "rb_all";
            this.rb_all.Size = new Size(0x24, 0x11);
            this.rb_all.TabIndex = 0;
            this.rb_all.TabStop = true;
            this.rb_all.Text = "All";
            this.rb_all.UseVisualStyleBackColor = true;
            this.date_trans.Format = DateTimePickerFormat.Short;
            this.date_trans.Location = new Point(0x63, 0x27);
            this.date_trans.Name = "date_trans";
            this.date_trans.Size = new Size(0x57, 20);
            this.date_trans.TabIndex = 8;
            this.date_trans.Value = new DateTime(0x7df, 7, 20, 0, 0, 0, 0);
            this.gb_info.Controls.Add(this.label4);
            this.gb_info.Controls.Add(this.text_remain);
            this.gb_info.Controls.Add(this.label3);
            this.gb_info.Controls.Add(this.text_used);
            this.gb_info.Controls.Add(this.dgv_item);
            this.gb_info.Location = new Point(0x11e, 0);
            this.gb_info.Name = "gb_info";
            this.gb_info.Size = new Size(0x1e8, 0xe2);
            this.gb_info.TabIndex = 2;
            this.gb_info.TabStop = false;
            this.gb_info.Text = "Vessel Information";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0xd7, 0xce);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x54, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Total Remaining";
            this.text_remain.Location = new Point(0x131, 0xcb);
            this.text_remain.Name = "text_remain";
            this.text_remain.ReadOnly = true;
            this.text_remain.Size = new Size(0x7c, 20);
            this.text_remain.TabIndex = 13;
            this.text_remain.TextAlign = HorizontalAlignment.Right;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(8, 0xcf);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x3b, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Total Used";
            this.text_used.Location = new Point(0x4c, 0xcc);
            this.text_used.Name = "text_used";
            this.text_used.ReadOnly = true;
            this.text_used.Size = new Size(0x7c, 20);
            this.text_used.TabIndex = 11;
            this.text_used.TextAlign = HorizontalAlignment.Right;
            this.dgv_item.AllowUserToAddRows = false;
            this.dgv_item.AllowUserToDeleteRows = false;
            this.dgv_item.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_item.Location = new Point(6, 0x13);
            this.dgv_item.Name = "dgv_item";
            this.dgv_item.ReadOnly = true;
            this.dgv_item.Size = new Size(0x1dc, 0xb0);
            this.dgv_item.TabIndex = 0;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x307, 0x228);
            base.Controls.Add(this.gb_info);
            base.Controls.Add(this.gb_detail);
            base.Controls.Add(this.gb_header);
            base.Controls.Add(this.gb_filter);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormSplitDoVessel";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Split DO Vessel";
            base.Load += new EventHandler(this.FormSplitDoVessel_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormSplitDoVessel_KeyPress);
            this.gb_header.ResumeLayout(false);
            this.gb_header.PerformLayout();
            this.panel_info.ResumeLayout(false);
            this.panel_info.PerformLayout();
            this.gb_detail.ResumeLayout(false);
            this.gb_detail.PerformLayout();
            ((ISupportInitialize) this.dgv_split).EndInit();
            this.gb_filter.ResumeLayout(false);
            this.gb_filter.PerformLayout();
            this.gb_info.ResumeLayout(false);
            this.gb_info.PerformLayout();
            ((ISupportInitialize) this.dgv_item).EndInit();
            base.ResumeLayout(false);
        }

        private double load_WBLocation_VesselLimitTolerance()
        {
            double num = 0.0;
            WBTable table = new WBTable();
            table.OpenTable("wb_location", "select VesselLimitTolerance from wb_location WHERE" + WBData.CompanyLocation(""), WBData.conn);
            if ((table.DT != null) && (table.DT.Rows.Count > 0))
            {
                try
                {
                    num = string.IsNullOrEmpty(table.DT.Rows[0]["VesselLimitTolerance"].ToString()) ? 0.0 : Convert.ToDouble(table.DT.Rows[0]["VesselLimitTolerance"].ToString());
                }
                catch (Exception)
                {
                    num = 0.0;
                }
            }
            return num;
        }

        private void text_DO_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.btn_go.PerformClick();
            }
            else
            {
                e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
            }
        }
    }
}

