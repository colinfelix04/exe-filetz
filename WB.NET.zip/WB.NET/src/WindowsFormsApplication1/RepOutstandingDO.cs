﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class RepOutstandingDO : Form
    {
        private WBTable tbl_DO = new WBTable();
        private WBTable tbl_Trans = new WBTable();
        private WBTable tbl_OS = new WBTable();
        private WBTable tbl_OS2 = new WBTable();
        private WBTable tbl_return = new WBTable();
        private WBTable tbl_temp = new WBTable();
        private WBTable tbl_Do = new WBTable();
        private WBTable tbl_Comm = new WBTable();
        private WBTable tbl_Csi = new WBTable();
        private string sqlTrans;
        private string do_no;
        private string po;
        private string so;
        private string incoterm;
        private string contract_no;
        private int maxRow = 50;
        private int No = 0;
        private int jlhkol = 0;
        private int jlhRecord = 0;
        private double os;
        private double issue;
        private double party;
        private double qty_return;
        private double gos;
        private double gissue;
        private double mtd;
        private double gmtd;
        private double partybuom;
        private double mtdbuom;
        private double issuebuom;
        private double osbuom;
        private double colly;
        private double tcolly;
        private string do_deductedbBy = "0";
        private string do_relationCode = "";
        private string do_doDate = "";
        private string comm_bulkPack = "";
        private string comm_unit = "KG";
        private string comm_type = "";
        private float comm_netW = 0f;
        private IContainer components = null;
        public Label labelRecNo;
        public Label labelProcess;
        public Label label5;
        private LineShape lineShape1;
        private ShapeContainer shapeContainer1;
        public TextBox text2ndDO;
        public Label label4;
        public TextBox text1stDO;
        public Label labelcommodity;
        public Button button1st;
        public Button button2nd;
        public DateTimePicker monthCalendar1;
        public Label label1;
        private TextBox textBox1;
        public Label label3;
        public Button button2;
        public Button button3;
        public GroupBox grType;
        public RadioButton rboGI;
        public RadioButton rboGR;
        private CheckBox checkShowClosedDO;
        private GroupBox gbDispOpt;
        private CheckBox cBoxLossInPack;
        private CheckBox cBoxLossInKg;
        private CheckBox cBoxReturInPack;
        private CheckBox cBoxReturInKg;
        private CheckBox cBoxTotalMTD;
        private CheckBox cBoxIncoterm;
        private CheckBox cBoxPOSONo;
        private CheckBox cBoxContractNo;
        private CheckBox cBoxSQBUOM;

        public RepOutstandingDO()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE"
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.text2ndDO.Text = contract.ReturnRow["do_no"].ToString();
                this.text2ndDO.Focus();
            }
            contract.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.text1stDO.Text.Trim() == "")
            {
                MessageBox.Show("Please Fill in First DO Number.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (this.text2ndDO.Text.Trim() == "")
            {
                MessageBox.Show("Please Fill in Second DO Number.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                this.maxRow = Convert.ToInt16(this.textBox1.Text);
                this.sqlTrans = "SELECT Do_No, IO FROM wb_contract, wb_transaction_type ";
                string[] textArray1 = new string[] { this.sqlTrans, "WHERE wb_contract.Coy = '", WBData.sCoyCode, "' AND wb_contract.Location_Code = '", WBData.sLocCode, "'" };
                this.sqlTrans = string.Concat(textArray1);
                string[] textArray2 = new string[] { this.sqlTrans, "AND wb_transaction_type.Coy = '", WBData.sCoyCode, "' AND wb_transaction_type.Location_Code = '", WBData.sLocCode, "'" };
                this.sqlTrans = string.Concat(textArray2);
                if (this.rboGI.Checked)
                {
                    this.sqlTrans = this.sqlTrans + " AND IO = 'O' ";
                }
                if (this.rboGR.Checked)
                {
                    this.sqlTrans = this.sqlTrans + " AND IO = 'I' ";
                }
                string[] textArray3 = new string[] { this.sqlTrans, " AND do_no >= '", this.text1stDO.Text, "' AND do_no <= '", this.text2ndDO.Text, "' " };
                this.sqlTrans = string.Concat(textArray3);
                this.sqlTrans = this.sqlTrans + " AND wb_contract.Transaction_Code = wb_transaction_type.Transaction_Code ";
                this.sqlTrans = this.sqlTrans + " ORDER BY do_no ASC";
                this.tbl_Trans = new WBTable();
                this.tbl_Trans.OpenTable("vw_trans", this.sqlTrans, WBData.conn);
                if (this.tbl_Trans.DT.Rows.Count <= 0)
                {
                    MessageBox.Show("No Records Found", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    this.labelProcess.Visible = true;
                    this.labelRecNo.Visible = true;
                    this.labelProcess.Refresh();
                    this.labelRecNo.Refresh();
                    this.jlhRecord = this.tbl_Trans.DT.Rows.Count;
                    this.printReport();
                    this.labelProcess.Visible = false;
                    this.labelRecNo.Visible = false;
                }
            }
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE"
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.text1stDO.Text = contract.ReturnRow["do_no"].ToString();
                this.text1stDO.Focus();
            }
            contract.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public static DateTime GetNow()
        {
            WBTable table = new WBTable();
            table.OpenTable("Tbl_now", "Select getdate() as now where 1=1", WBData.conn);
            return Convert.ToDateTime(table.DT.Rows[0]["now"].ToString());
        }

        private void initHeader(HTML rep)
        {
            rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
            rep.Write("<tr class='bd'>");
            rep.Write("<td nowrap align=center><b>No.</b></td>");
            rep.Write("<td nowrap align=center><b>DO/SO Date</b></td>");
            rep.Write("<td nowrap align=center><b>DO/SO Number</b></td>");
            rep.Write("<td nowrap align=center><b>Relation</b></td>");
            if (this.cBoxContractNo.Checked)
            {
                this.jlhkol++;
                rep.Write("<td nowrap align=center><b>Contract Number</b></td>");
            }
            if (this.cBoxPOSONo.Checked)
            {
                this.jlhkol++;
                if (this.rboGI.Checked)
                {
                    rep.Write("<td nowrap align=center><b>SO Number</b></td>");
                }
                else if (this.rboGR.Checked)
                {
                    rep.Write("<td nowrap align=center><b>PO Number</b></td>");
                }
            }
            rep.Write("<td nowrap align=center><b>Commodity</b></td>");
            if (this.cBoxIncoterm.Checked)
            {
                this.jlhkol++;
                rep.Write("<td nowrap align=center><b>Incoterm</b></td>");
            }
            rep.Write("<td nowrap align=center><b>Party</b></td>");
            if (this.cBoxSQBUOM.Checked)
            {
                this.jlhkol += 2;
                rep.Write("<td nowrap align=center colspan=2><b>Party (in Base UOM)</b></td>");
            }
            if (this.cBoxTotalMTD.Checked)
            {
                rep.Write("<td nowrap align=center><b>MTD</b></td>");
            }
            if (this.cBoxSQBUOM.Checked && this.cBoxTotalMTD.Checked)
            {
                rep.Write("<td nowrap align=center colspan=2><b>MTD (in Base UOM)</b></td>");
            }
            rep.Write("<td nowrap align=center><b>Net Good Issue</b></td>");
            if (this.cBoxSQBUOM.Checked)
            {
                rep.Write("<td nowrap align=center colspan=2><b>Net Good Issue (in Base UOM)</b></td>");
            }
            rep.Write("<td nowrap align=center><b>Outstanding</b></td>");
            if (this.cBoxSQBUOM.Checked)
            {
                rep.Write("<td nowrap align=center colspan=2><b>Outstanding (in Base UOM)</b></td>");
            }
            if (this.cBoxReturInKg.Checked)
            {
                rep.Write("<td align=center width=100><b>Return (Kg)</b></td>");
            }
            if (this.cBoxReturInPack.Checked)
            {
                rep.Write("<td align=center width=100><b>Return (Pack)</b></td>");
            }
            if (this.cBoxLossInKg.Checked)
            {
                rep.Write("<td align=center width=100><b>Loss(-)/Gain(+) (Kg)</b></td>");
            }
            if (this.cBoxLossInPack.Checked)
            {
                rep.Write("<td align=center width=100><b>Loss(-)/Gain(+) (Pack)</b></td>");
            }
            rep.Write("</tr>");
        }

        private void InitializeComponent()
        {
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.label5 = new Label();
            this.lineShape1 = new LineShape();
            this.shapeContainer1 = new ShapeContainer();
            this.text2ndDO = new TextBox();
            this.label4 = new Label();
            this.text1stDO = new TextBox();
            this.labelcommodity = new Label();
            this.button1st = new Button();
            this.button2nd = new Button();
            this.monthCalendar1 = new DateTimePicker();
            this.label1 = new Label();
            this.textBox1 = new TextBox();
            this.label3 = new Label();
            this.button2 = new Button();
            this.button3 = new Button();
            this.grType = new GroupBox();
            this.rboGI = new RadioButton();
            this.rboGR = new RadioButton();
            this.checkShowClosedDO = new CheckBox();
            this.gbDispOpt = new GroupBox();
            this.cBoxTotalMTD = new CheckBox();
            this.cBoxIncoterm = new CheckBox();
            this.cBoxPOSONo = new CheckBox();
            this.cBoxContractNo = new CheckBox();
            this.cBoxLossInPack = new CheckBox();
            this.cBoxLossInKg = new CheckBox();
            this.cBoxReturInPack = new CheckBox();
            this.cBoxReturInKg = new CheckBox();
            this.cBoxSQBUOM = new CheckBox();
            this.grType.SuspendLayout();
            this.gbDispOpt.SuspendLayout();
            base.SuspendLayout();
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x19e, 0x15);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 120;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x126, 0x15);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 0x77;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(0x1f, 0x15);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0xc1, 13);
            this.label5.TabIndex = 0x76;
            this.label5.Text = "Report Outstanding DO/Contract";
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 0x22;
            this.lineShape1.X2 = 0x1b4;
            this.lineShape1.Y1 = 0x29;
            this.lineShape1.Y2 = 0x29;
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.lineShape1 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(0x1e7, 0x141);
            this.shapeContainer1.TabIndex = 0x79;
            this.shapeContainer1.TabStop = false;
            this.text2ndDO.CharacterCasing = CharacterCasing.Upper;
            this.text2ndDO.Location = new Point(0x86, 0x7f);
            this.text2ndDO.Name = "text2ndDO";
            this.text2ndDO.Size = new Size(0x11b, 20);
            this.text2ndDO.TabIndex = 0x83;
            this.text2ndDO.Leave += new EventHandler(this.text2ndDO_Leave);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x66, 0x83);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x1a, 13);
            this.label4.TabIndex = 0x85;
            this.label4.Text = "To :";
            this.text1stDO.CharacterCasing = CharacterCasing.Upper;
            this.text1stDO.Location = new Point(0x86, 0x65);
            this.text1stDO.Name = "text1stDO";
            this.text1stDO.Size = new Size(0x11b, 20);
            this.text1stDO.TabIndex = 130;
            this.text1stDO.Leave += new EventHandler(this.text1stDO_Leave);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x21, 0x68);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x5f, 13);
            this.labelcommodity.TabIndex = 0x84;
            this.labelcommodity.Text = "DO Number From :";
            this.button1st.Location = new Point(420, 0x63);
            this.button1st.Margin = new Padding(0);
            this.button1st.Name = "button1st";
            this.button1st.Size = new Size(0x17, 0x17);
            this.button1st.TabIndex = 0x86;
            this.button1st.Text = "...";
            this.button1st.UseVisualStyleBackColor = true;
            this.button1st.Click += new EventHandler(this.buttonComm_Click);
            this.button2nd.Location = new Point(420, 0x7d);
            this.button2nd.Margin = new Padding(0);
            this.button2nd.Name = "button2nd";
            this.button2nd.Size = new Size(0x17, 0x17);
            this.button2nd.TabIndex = 0x87;
            this.button2nd.Text = "...";
            this.button2nd.UseVisualStyleBackColor = true;
            this.button2nd.Click += new EventHandler(this.button1_Click);
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x86, 0x99);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0x88;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x37, 0x9f);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x49, 13);
            this.label1.TabIndex = 0x89;
            this.label1.Text = "Current Date :";
            this.textBox1.Location = new Point(0x4f, 0x120);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0x31, 20);
            this.textBox1.TabIndex = 0x8d;
            this.textBox1.Text = "999";
            this.textBox1.TextAlign = HorizontalAlignment.Right;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x17, 0x124);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x34, 13);
            this.label3.TabIndex = 140;
            this.label3.Text = "Max Row";
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x164, 0x113);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x58, 0x20);
            this.button2.TabIndex = 0x8b;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button3.Location = new Point(0x106, 0x113);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x58, 0x21);
            this.button3.TabIndex = 0x8a;
            this.button3.Text = "Process";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x22, 0x30);
            this.grType.Name = "grType";
            this.grType.Size = new Size(260, 0x2d);
            this.grType.TabIndex = 0x8e;
            this.grType.TabStop = false;
            this.grType.Text = "Report Type";
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(130, 0x12);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 0x11;
            this.rboGI.TabStop = true;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.rboGI.TextChanged += new EventHandler(this.rboGI_TextChanged);
            this.rboGR.AutoSize = true;
            this.rboGR.Location = new Point(0x11, 0x12);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0x10;
            this.rboGR.TabStop = true;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            this.rboGR.TextChanged += new EventHandler(this.rboGR_TextChanged);
            this.checkShowClosedDO.AutoSize = true;
            this.checkShowClosedDO.Location = new Point(0x151, 0x43);
            this.checkShowClosedDO.Name = "checkShowClosedDO";
            this.checkShowClosedDO.Size = new Size(0x6b, 0x11);
            this.checkShowClosedDO.TabIndex = 0x8f;
            this.checkShowClosedDO.Text = "Show Closed DO";
            this.checkShowClosedDO.UseVisualStyleBackColor = true;
            this.gbDispOpt.Controls.Add(this.cBoxTotalMTD);
            this.gbDispOpt.Controls.Add(this.cBoxIncoterm);
            this.gbDispOpt.Controls.Add(this.cBoxPOSONo);
            this.gbDispOpt.Controls.Add(this.cBoxContractNo);
            this.gbDispOpt.Controls.Add(this.cBoxLossInPack);
            this.gbDispOpt.Controls.Add(this.cBoxLossInKg);
            this.gbDispOpt.Controls.Add(this.cBoxReturInPack);
            this.gbDispOpt.Controls.Add(this.cBoxReturInKg);
            this.gbDispOpt.Location = new Point(0x1a, 190);
            this.gbDispOpt.Name = "gbDispOpt";
            this.gbDispOpt.Size = new Size(0x19f, 0x48);
            this.gbDispOpt.TabIndex = 0xb1;
            this.gbDispOpt.TabStop = false;
            this.gbDispOpt.Text = "Display Options";
            this.cBoxTotalMTD.AutoSize = true;
            this.cBoxTotalMTD.Location = new Point(0x137, 0x2a);
            this.cBoxTotalMTD.Name = "cBoxTotalMTD";
            this.cBoxTotalMTD.Size = new Size(0x4d, 0x11);
            this.cBoxTotalMTD.TabIndex = 180;
            this.cBoxTotalMTD.Text = "Total MTD";
            this.cBoxTotalMTD.UseVisualStyleBackColor = true;
            this.cBoxIncoterm.AutoSize = true;
            this.cBoxIncoterm.Location = new Point(0x137, 0x15);
            this.cBoxIncoterm.Name = "cBoxIncoterm";
            this.cBoxIncoterm.Size = new Size(0x43, 0x11);
            this.cBoxIncoterm.TabIndex = 0xb3;
            this.cBoxIncoterm.Text = "Incoterm";
            this.cBoxIncoterm.UseVisualStyleBackColor = true;
            this.cBoxPOSONo.AutoSize = true;
            this.cBoxPOSONo.Location = new Point(0xd4, 0x2a);
            this.cBoxPOSONo.Name = "cBoxPOSONo";
            this.cBoxPOSONo.Size = new Size(0x4e, 0x11);
            this.cBoxPOSONo.TabIndex = 0xb2;
            this.cBoxPOSONo.Text = "PO/SO No";
            this.cBoxPOSONo.UseVisualStyleBackColor = true;
            this.cBoxContractNo.AutoSize = true;
            this.cBoxContractNo.Location = new Point(0xd4, 0x15);
            this.cBoxContractNo.Name = "cBoxContractNo";
            this.cBoxContractNo.Size = new Size(0x53, 0x11);
            this.cBoxContractNo.TabIndex = 0xb1;
            this.cBoxContractNo.Text = "Contract No";
            this.cBoxContractNo.UseVisualStyleBackColor = true;
            this.cBoxLossInPack.AutoSize = true;
            this.cBoxLossInPack.Location = new Point(0x77, 0x2c);
            this.cBoxLossInPack.Name = "cBoxLossInPack";
            this.cBoxLossInPack.Size = new Size(0x57, 0x11);
            this.cBoxLossInPack.TabIndex = 0xb0;
            this.cBoxLossInPack.Text = "Loss in Pack";
            this.cBoxLossInPack.UseVisualStyleBackColor = true;
            this.cBoxLossInKg.AutoSize = true;
            this.cBoxLossInKg.Location = new Point(0x77, 0x15);
            this.cBoxLossInKg.Name = "cBoxLossInKg";
            this.cBoxLossInKg.Size = new Size(0x4d, 0x11);
            this.cBoxLossInKg.TabIndex = 0xb0;
            this.cBoxLossInKg.Text = "Loss in KG";
            this.cBoxLossInKg.UseVisualStyleBackColor = true;
            this.cBoxReturInPack.AutoSize = true;
            this.cBoxReturInPack.Location = new Point(14, 0x2c);
            this.cBoxReturInPack.Name = "cBoxReturInPack";
            this.cBoxReturInPack.Size = new Size(0x61, 0x11);
            this.cBoxReturInPack.TabIndex = 0xb0;
            this.cBoxReturInPack.Text = "Return in Pack";
            this.cBoxReturInPack.UseVisualStyleBackColor = true;
            this.cBoxReturInKg.AutoSize = true;
            this.cBoxReturInKg.Location = new Point(14, 0x15);
            this.cBoxReturInKg.Name = "cBoxReturInKg";
            this.cBoxReturInKg.Size = new Size(0x57, 0x11);
            this.cBoxReturInKg.TabIndex = 0xb0;
            this.cBoxReturInKg.Text = "Return in KG";
            this.cBoxReturInKg.UseVisualStyleBackColor = true;
            this.cBoxSQBUOM.AutoSize = true;
            this.cBoxSQBUOM.Location = new Point(40, 0x109);
            this.cBoxSQBUOM.Name = "cBoxSQBUOM";
            this.cBoxSQBUOM.Size = new Size(0x89, 0x11);
            this.cBoxSQBUOM.TabIndex = 0xb2;
            this.cBoxSQBUOM.Text = "Show Qty in base UOM";
            this.cBoxSQBUOM.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1e7, 0x141);
            base.ControlBox = false;
            base.Controls.Add(this.cBoxSQBUOM);
            base.Controls.Add(this.gbDispOpt);
            base.Controls.Add(this.checkShowClosedDO);
            base.Controls.Add(this.grType);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.monthCalendar1);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.button2nd);
            base.Controls.Add(this.button1st);
            base.Controls.Add(this.text2ndDO);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.text1stDO);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.shapeContainer1);
            base.KeyPreview = true;
            base.Name = "RepOutstandingDO";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Report Outstanding DO/Contract";
            base.Load += new EventHandler(this.RepOutstandingDO_Load);
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            this.gbDispOpt.ResumeLayout(false);
            this.gbDispOpt.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void printReport()
        {
            HTML rep = new HTML();
            rep.File = rep.File + @"\" + WBUser.UserID + "_Oustanding_DO.htm";
            rep.Title = "Report of Outstanding DO/Contract";
            rep.Open();
            rep.Write(rep.Style());
            rep.Write("<br><font size=5><b>REPORT OF OUTSTANDING DO</b></font><br>");
            string[] textArray1 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
            rep.Write(string.Concat(textArray1));
            string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
            rep.Write(string.Concat(textArray2));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            rep.Write("<br><br>");
            rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
            rep.Write("<tr class=bd>");
            rep.Write("<td>Selected Date</td>");
            DateTime time2 = this.monthCalendar1.Value;
            rep.Write("<td>: <b>" + time2.ToShortDateString() + "</b></td>");
            rep.Write("</tr>");
            rep.Write("<tr class=bd>");
            rep.Write("<td>DO/SO Number</td>");
            string[] textArray3 = new string[] { "<td>: <b>", this.text1stDO.Text, "</b> to <b>", this.text2ndDO.Text, "</b></td>" };
            rep.Write(string.Concat(textArray3));
            rep.Write("</tr>");
            rep.Write("<tr class=bd>");
            rep.Write("<td>Report Date</td>");
            rep.Write("<td>: <b>" + GetNow().ToShortDateString() + "</b></td>");
            rep.Write("</tr>");
            rep.Write("</table>");
            rep.Write("<br/><br/><br/>");
            this.jlhkol = 6;
            this.initHeader(rep);
            int num = 0;
            int num2 = 0;
            int num3 = 0;
            this.os = 0.0;
            double party = 0.0;
            double num5 = 0.0;
            double num6 = 0.0;
            string str = "";
            string pStr = "";
            double num7 = 0.0;
            this.No = 0;
            foreach (DataRow row in this.tbl_Trans.DT.Rows)
            {
                this.No++;
                this.labelRecNo.Text = num3.ToString() + " / " + this.jlhRecord.ToString();
                this.labelRecNo.Refresh();
                num2++;
                num3++;
                this.do_no = row["do_no"].ToString();
                string sqltext = (((((("Select " + " sum(netFactory) as NetFactory , " + " sum(case when netOther = '0' then netFactory else netOther end) as NetOther, ") + " sum(loading_qty) as loading_qty, " + " sum(loading_qty_opw) as loading_qty_opw,") + "SUM (return_qty_kg) as ReturInKg, SUM (return_qty_pack) as ReturInPack," + "SUM (case when loading_qty_opw > 0 or return_qty_pack > 0 then (loading_qty - loading_qty_opw - return_qty_pack) * -1 else 0 end) as lossinpack,") + "sum (case when netOther > 0 or return_qty_kg > 0 then (netFactory - netOther - return_qty_kg) * -1 else 0 end) as lossinkg " + " from vw_outstanding") + " WHERE " + WBData.CompanyLocation(" and DO_NO = '" + this.do_no + "'")) + " AND (mark_return = '' OR mark_return is null) and (is_return <> 'Y' or is_return is null)") + " and report_date <= '" + Program.DTOC(Convert.ToDateTime(this.monthCalendar1.Value.ToString())) + "' ";
                this.tbl_OS.OpenTable("vw_os", sqltext, WBData.conn);
                this.tbl_Do.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + this.do_no + "'"), WBData.conn);
                this.tbl_Do.DR = this.tbl_Do.DT.Rows[0];
                if (this.tbl_Do.DT.Rows[0]["check_qty"].ToString() != "Y")
                {
                    this.tbl_Do.Dispose();
                }
                this.party = Program.StrToDouble(this.tbl_Do.DR["Quantity"].ToString(), 0);
                pStr = this.tbl_Do.DR["comm_code"].ToString();
                this.do_deductedbBy = this.tbl_Do.DR["deductedby"].ToString();
                this.do_relationCode = this.tbl_Do.DR["relation_code"].ToString();
                this.do_doDate = this.tbl_Do.DR["do_date"].ToString();
                this.po = this.tbl_Do.DR["po"].ToString();
                this.so = this.tbl_Do.DR["so"].ToString();
                this.incoterm = this.tbl_Do.DR["franco"].ToString();
                this.contract_no = this.tbl_Do.DR["contract"].ToString();
                party = (this.do_deductedbBy != "1") ? ((Program.StrToDouble(this.tbl_Do.DR["Entry_Fact"].ToString(), 0) <= 0.0) ? Program.StrToDouble(this.tbl_Do.DR["Quantity"].ToString(), 0) : Program.StrToDouble(this.tbl_Do.DR["Entry_Fact"].ToString(), 0)) : ((Program.StrToDouble(this.tbl_Do.DR["Entry_Est"].ToString(), 0) <= 0.0) ? Program.StrToDouble(this.tbl_Do.DR["Quantity"].ToString(), 0) : Program.StrToDouble(this.tbl_Do.DR["Entry_Est"].ToString(), 0));
                num7 = (this.tbl_Do.DR["tolerance"].ToString() == "") ? 0.0 : Convert.ToDouble(this.tbl_Do.DR["tolerance"].ToString());
                this.tbl_Comm.OpenTable("wb_Comm", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + pStr + "'"), WBData.conn);
                this.tbl_Comm.DR = this.tbl_Comm.DT.Rows[0];
                this.comm_bulkPack = this.tbl_Comm.DR["BulkPack"].ToString();
                this.comm_unit = this.tbl_Comm.DR["Unit"].ToString();
                this.comm_type = this.tbl_Comm.DR["Type"].ToString();
                try
                {
                    this.comm_netW = float.Parse(this.tbl_Comm.DR["Netto_Weight"].ToString());
                }
                catch (Exception)
                {
                    this.comm_netW = 0f;
                }
                if (this.tbl_OS.DT.Rows.Count <= 0)
                {
                    num5 = 0.0;
                    this.issue = num5;
                    this.os = party - this.issue;
                }
                else
                {
                    if (party == 0.0)
                    {
                        party = this.party;
                    }
                    num5 = 0.0;
                    string str4 = "Select " + " do.do_sap, do.internal_number";
                    string[] textArray4 = new string[] { str4, " FROM wb_transaction as ts RIGHT OUTER JOIN  wb_transDO as do ON ts.Ref = do.Ref AND ts.Coy = do.Coy AND  ts.Location_Code = do.Location_Code  WHERE (ts.mark_accident IS NULL or ts.mark_accident = '') AND (ts.Deleted IS NULL or ts.Deleted = '')  and do.do_no = '", this.do_no, "' and ((do.do_sap is not null and do.do_sap <> '') or (do.internal_number is not null and do.internal_number <> '')) and do.coy = '", WBData.sCoyCode, "' and do.location_code = '", WBData.sLocCode, "' " };
                    str4 = string.Concat(textArray4);
                    new WBTable().OpenTable("wb_transdo", str4, WBData.conn);
                    num5 = (this.do_deductedbBy != "0") ? (((this.comm_unit != "KG") && (this.comm_unit != "")) ? ((this.tbl_Trans.DT.Rows.Count <= 0) ? (num5 + Program.StrToDouble(this.tbl_OS.DT.Rows[0]["NetOther"].ToString(), 0)) : (num5 + (Program.StrToDouble(this.tbl_OS.DT.Rows[0]["loading_qty_opw"].ToString(), 0) * this.comm_netW))) : (num5 + Program.StrToDouble(this.tbl_OS.DT.Rows[0]["NetOther"].ToString(), 0))) : (((this.comm_unit != "KG") && (this.comm_unit != "")) ? ((this.tbl_Trans.DT.Rows.Count <= 0) ? (num5 + Program.StrToDouble(this.tbl_OS.DT.Rows[0]["NetFactory"].ToString(), 0)) : (num5 + (Program.StrToDouble(this.tbl_OS.DT.Rows[0]["loading_qty"].ToString(), 0) * this.comm_netW))) : (num5 + Program.StrToDouble(this.tbl_OS.DT.Rows[0]["NetFactory"].ToString(), 0)));
                    this.issue = num5;
                    this.os = party - this.issue;
                }
                DateTime time3 = Convert.ToDateTime(this.monthCalendar1.Value.ToString());
                int year = time3.Year;
                int month = time3.Month;
                time2 = this.monthCalendar1.Value;
                string str5 = (((((("Select " + " sum(netFactory) as NetFactory , " + " sum(case when netOther = '0' then netFactory else netOther end) as NetOther, ") + " sum(loading_qty) as loading_qty, " + " sum(loading_qty_opw) as loading_qty_opw,") + "SUM (return_qty_kg) as ReturInKg, SUM (return_qty_pack) as ReturInPack," + "SUM (case when loading_qty_opw > 0 or return_qty_pack > 0 then (loading_qty - loading_qty_opw - return_qty_pack) * -1 else 0 end) as lossinpack,") + "sum (case when netOther > 0 or return_qty_kg > 0 then (netFactory - netOther - return_qty_kg) * -1 else 0 end) as lossinkg " + " from vw_outstanding") + " WHERE " + WBData.CompanyLocation(" and DO_NO = '" + this.do_no + "'")) + " AND (mark_return = '' OR mark_return is null) and (is_return <> 'Y' or is_return is null)") + " and report_date <= '" + Program.DTOC(Convert.ToDateTime(time2.ToString())) + "' ";
                object[] objArray1 = new object[] { str5, " and report_date >= '", year, "-", month, "-01 00:00:00.000' " };
                str5 = string.Concat(objArray1);
                this.tbl_OS2.OpenTable("vw_os2", str5, WBData.conn);
                if (this.tbl_OS2.DT.Rows.Count <= 0)
                {
                    num6 = 0.0;
                    this.mtd = num6;
                }
                else
                {
                    if (party == 0.0)
                    {
                        party = this.party;
                    }
                    num6 = 0.0;
                    num6 = (this.do_deductedbBy != "0") ? (((this.comm_unit != "KG") && (this.comm_unit != "")) ? ((this.tbl_Trans.DT.Rows.Count <= 0) ? (num6 + Program.StrToDouble(this.tbl_OS2.DT.Rows[0]["NetOther"].ToString(), 0)) : (num6 + (Program.StrToDouble(this.tbl_OS2.DT.Rows[0]["loading_qty_opw"].ToString(), 0) * this.comm_netW))) : (num6 + Program.StrToDouble(this.tbl_OS2.DT.Rows[0]["NetOther"].ToString(), 0))) : (((this.comm_unit != "KG") && (this.comm_unit != "")) ? ((this.tbl_Trans.DT.Rows.Count <= 0) ? (num6 + Program.StrToDouble(this.tbl_OS2.DT.Rows[0]["NetFactory"].ToString(), 0)) : (num6 + (Program.StrToDouble(this.tbl_OS2.DT.Rows[0]["loading_qty"].ToString(), 0) * this.comm_netW))) : (num6 + Program.StrToDouble(this.tbl_OS2.DT.Rows[0]["NetFactory"].ToString(), 0)));
                    this.mtd = num6;
                }
                if ((!this.checkShowClosedDO.Checked && (this.os == 0.0)) && (this.party == this.issue))
                {
                    this.No--;
                    num2--;
                }
                else
                {
                    if ((num2 == 1) && (num > 0))
                    {
                        rep.Write("</table>");
                        rep.Write("<br>");
                        rep.Write("<br>");
                        this.initHeader(rep);
                    }
                    else if (num2 == this.maxRow)
                    {
                        num2 = 0;
                        num++;
                    }
                    this.qty_return = 0.0;
                    sqltext = (((("Select " + " sum(case when netOther = '0' then netFactory else netOther end) as NetOther, ") + " sum(loading_qty_opw) as loading_qty_opw" + " from vw_outstanding") + " WHERE " + WBData.CompanyLocation(" and DO_NO = '" + this.do_no + "'")) + " AND (mark_return = 'X')") + " and report_date <= '" + Program.DTOC(Convert.ToDateTime(this.monthCalendar1.Value.ToString())) + "' ";
                    this.tbl_return.OpenTable("vw_return", sqltext, WBData.conn);
                    if (this.tbl_return.DT.Rows.Count > 0)
                    {
                        this.qty_return = Program.StrToDouble(this.tbl_return.DT.Rows[0]["NetOther"].ToString(), 0);
                    }
                    rep.Write("<tr class='bd'>");
                    rep.Write("<td nowrap align=right>" + $"{this.No:N0}" + "</td>");
                    str = this.do_doDate;
                    rep.Write("<td nowrap align=left>" + rep.strq((str.Length > 10) ? str.Substring(0, 10) : str) + "</td>");
                    rep.Write("<td nowrap align=left>" + rep.strq(this.do_no) + "</td>");
                    rep.Write("<td nowrap align=left>" + rep.strq(this.do_relationCode) + "</td>");
                    if (this.cBoxContractNo.Checked)
                    {
                        rep.Write("<td nowrap align=left>" + rep.strq(this.contract_no) + "</td>");
                    }
                    if (this.cBoxPOSONo.Checked)
                    {
                        if (this.rboGI.Checked)
                        {
                            rep.Write("<td nowrap align=left>" + rep.strq(this.so) + "</td>");
                        }
                        else if (this.rboGR.Checked)
                        {
                            rep.Write("<td nowrap align=left>" + rep.strq(this.po) + "</td>");
                        }
                    }
                    rep.Write("<td nowrap align=left>" + rep.strq(pStr) + "</td>");
                    if (this.cBoxIncoterm.Checked)
                    {
                        rep.Write("<td nowrap align=left>" + rep.strq(this.incoterm) + "</td>");
                    }
                    rep.Write("<td nowrap align=right>" + $"{this.party:N0}" + "</td>");
                    if (this.cBoxSQBUOM.Checked)
                    {
                        this.partybuom = this.party / ((double) this.comm_netW);
                        rep.Write("<td nowrap align=right>" + $"{this.partybuom:N0}" + "</td>");
                        rep.Write("<td nowrap align=left>" + this.comm_unit.ToString() + "</td>");
                    }
                    if (this.cBoxTotalMTD.Checked)
                    {
                        rep.Write("<td nowrap align=right>" + $"{this.mtd:N0}" + "</td>");
                    }
                    if (this.cBoxSQBUOM.Checked && this.cBoxTotalMTD.Checked)
                    {
                        this.mtdbuom = this.mtd / ((double) this.comm_netW);
                        rep.Write("<td nowrap align=right>" + $"{this.mtdbuom:N0}" + "</td>");
                        rep.Write("<td nowrap align=left>" + this.comm_unit.ToString() + "</td>");
                    }
                    rep.Write("<td nowrap align=right>" + $"{this.issue:N0}" + "</td>");
                    if (this.cBoxSQBUOM.Checked)
                    {
                        this.issuebuom = this.issue / ((double) this.comm_netW);
                        rep.Write("<td nowrap align=right>" + $"{this.issuebuom:N0}" + "</td>");
                        rep.Write("<td nowrap align=left>" + this.comm_unit.ToString() + "</td>");
                    }
                    rep.Write("<td nowrap align=right>" + $"{this.os:N0}" + "</td>");
                    if (this.cBoxSQBUOM.Checked)
                    {
                        this.osbuom = this.os / ((double) this.comm_netW);
                        rep.Write("<td nowrap align=right>" + $"{this.osbuom:N0}" + "</td>");
                        rep.Write("<td nowrap align=left>" + this.comm_unit.ToString() + "</td>");
                    }
                    if (this.cBoxReturInKg.Checked)
                    {
                        rep.Write("<td nowrap align=right>" + Program.StrToDouble(this.tbl_OS.DT.Rows[0]["Returinkg"].ToString(), 0) + "</td>");
                    }
                    if (this.cBoxReturInPack.Checked)
                    {
                        rep.Write("<td nowrap align=right>" + Program.StrToDouble(this.tbl_OS.DT.Rows[0]["Returinpack"].ToString(), 0) + "</td>");
                    }
                    if (this.cBoxLossInKg.Checked)
                    {
                        if (Program.StrToDouble(this.tbl_OS.DT.Rows[0]["lossinpack"].ToString(), 0) == 0.0)
                        {
                            rep.Write("<td nowrap align=right>" + Program.StrToDouble(this.tbl_OS.DT.Rows[0]["lossinkg"].ToString(), 0) + "</td>");
                        }
                        else
                        {
                            rep.Write("<td nowrap align=right>0</td>");
                        }
                    }
                    if (this.cBoxLossInPack.Checked)
                    {
                        rep.Write("<td nowrap align=right>" + Program.StrToDouble(this.tbl_OS.DT.Rows[0]["lossinpack"].ToString(), 0) + "</td>");
                    }
                    rep.Write("</tr>");
                    if (num2 == (this.maxRow + 1))
                    {
                        rep.Write("</table>");
                    }
                    this.gmtd += this.mtd;
                    this.gissue += this.issue;
                    this.gos += this.os;
                }
            }
            rep.Write("<tr class='bd'>");
            rep.Write("<td colspan=" + this.jlhkol + "><b>TOTAL</b></td>");
            if (this.cBoxTotalMTD.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + $"{this.gmtd:N0}" + "</b></td>");
            }
            if (this.cBoxSQBUOM.Checked)
            {
                rep.Write("<td nowrap align=right colspan=2>&nbsp;</td>");
            }
            rep.Write("<td nowrap align=right><b>" + $"{this.gissue:N0}" + "</b></td>");
            if (this.cBoxSQBUOM.Checked)
            {
                rep.Write("<td nowrap align=right colspan=2>&nbsp;</td>");
            }
            rep.Write("<td nowrap align=right><b>" + $"{this.gos:N0}" + "</b></td>");
            if (this.cBoxSQBUOM.Checked)
            {
                rep.Write("<td nowrap align=right colspan=2>&nbsp;</td>");
            }
            rep.Write("</tr>");
            this.No++;
            this.labelRecNo.Text = num3.ToString() + " / " + this.jlhRecord.ToString();
            this.labelRecNo.Refresh();
            rep.Write("</table>");
            rep.Write("<br>");
            rep.Write("<br>");
            rep.Write("<br>");
            rep.writeSign();
            rep.Close();
            ViewReport report = new ViewReport {
                webBrowser1 = { Url = new Uri("file:///" + rep.File) }
            };
            report.ShowDialog();
            rep.Dispose();
            report.Dispose();
        }

        private void rboGI_TextChanged(object sender, EventArgs e)
        {
            this.labelcommodity.Text = !this.rboGR.Checked ? "SO Number From :" : "DO Number From :";
        }

        private void rboGR_TextChanged(object sender, EventArgs e)
        {
            this.labelcommodity.Text = !this.rboGR.Checked ? "SO Number From :" : "DO Number From :";
        }

        private void RepOutstandingDO_Load(object sender, EventArgs e)
        {
            this.rboGI.Checked = true;
            this.tbl_DO.OpenTable("wb_contract", "SELECT * FROM wb_contract WHERE " + WBData.CompanyLocation(""), WBData.conn);
            Program.AutoComp(this.tbl_DO, "do_no", this.text1stDO);
            Program.AutoComp(this.tbl_DO, "do_no", this.text2ndDO);
        }

        private void text1stDO_Leave(object sender, EventArgs e)
        {
            if (this.text1stDO.Text.Trim() != "")
            {
                this.tbl_DO.ReOpen();
                string[] aField = new string[] { "Do_No" };
                string[] aFind = new string[] { this.text1stDO.Text.Trim() };
                if (this.tbl_DO.GetRecNo(aField, aFind) <= -1)
                {
                    this.button1st.PerformClick();
                    this.text1stDO.Focus();
                }
            }
        }

        private void text2ndDO_Leave(object sender, EventArgs e)
        {
            if (this.text2ndDO.Text.Trim() != "")
            {
                this.tbl_DO.ReOpen();
                string[] aField = new string[] { "Do_No" };
                string[] aFind = new string[] { this.text2ndDO.Text.Trim() };
                if (this.tbl_DO.GetRecNo(aField, aFind) <= -1)
                {
                    this.button2nd.PerformClick();
                    this.text2ndDO.Focus();
                }
            }
        }
    }
}

