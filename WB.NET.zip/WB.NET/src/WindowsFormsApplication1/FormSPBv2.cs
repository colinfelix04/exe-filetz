﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormSPBv2 : Form
    {
        public string pMode = "";
        public string pDo_No;
        public string changeReason = "";
        public string logKey = "";
        public string sqlShow;
        public string spMode = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public WBTable tbl_rlock = new WBTable();
        public WBTable tbl_temp = new WBTable();
        public int zUniq;
        private int idxFind = 0;
        private DateTime now = Convert.ToDateTime(WBUtility.GetServerDatetime().ToString("yyyy-MM-dd HH:mm:ss"));
        private string[] hasil;
        private bool result = false;
        private IContainer components = null;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem markdeleteToolStripMenuItem;
        public ToolStripMenuItem closeToolStripMenuItem;
        private TableLayoutPanel tableLayoutPanel1;
        private ToolStripMenuItem extendValidDateToolStripMenuItem;
        private ToolStripMenuItem viewtoolStripMenuItem;
        public Panel panel2;
        private Label lblVendorCode;
        public TextBox txtBoxVendor;
        public Panel panel1;
        private CheckBox chkBoxExpired;
        private CheckBox checkDeleted;
        private Label labelCount;
        private Label Garis1;
        public TextBox TextFind;
        public Button buttonFind;
        private DataGridView dataGridView1;
        public Button buttonFindVendor;

        public FormSPBv2()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count == 0) || (this.dataGridView1.CurrentRow.Cells["deleted"].Value.ToString().Trim() == "Y"))
            {
                if (!WBUser.CheckTrustee("MD_DN", "A"))
                {
                    this.addNewRecordToolStripMenuItem.Enabled = false;
                }
                this.viewtoolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
                this.markdeleteToolStripMenuItem.Enabled = false;
                this.extendValidDateToolStripMenuItem.Enabled = false;
            }
            else
            {
                this.editRecordToolStripMenuItem.Enabled = true;
                this.markdeleteToolStripMenuItem.Enabled = true;
                this.extendValidDateToolStripMenuItem.Enabled = true;
                if (!WBUser.CheckTrustee("MD_DN", "A"))
                {
                    this.addNewRecordToolStripMenuItem.Enabled = false;
                }
                if (!WBUser.CheckTrustee("MD_DN", "E"))
                {
                    this.editRecordToolStripMenuItem.Enabled = false;
                }
                if (!WBUser.CheckTrustee("MD_DN", "D"))
                {
                    this.markdeleteToolStripMenuItem.Enabled = false;
                }
                if (!WBUser.CheckTrustee("MD_DN", "E"))
                {
                    this.extendValidDateToolStripMenuItem.Enabled = false;
                }
                if (!WBUser.CheckTrustee("MD_DN", "V"))
                {
                    this.viewtoolStripMenuItem.Enabled = false;
                }
            }
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Simpan("ADD");
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void buttonFindVendor_Click(object sender, EventArgs e)
        {
            (this.dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"relation_code like '%{this.txtBoxVendor.Text}%'";
            this.labelCount.Text = Resource.Lbl_Total_Record + " = " + this.dataGridView1.Rows.Count.ToString();
            this.labelCount.Refresh();
        }

        private void checkDeleted_CheckedChanged(object sender, EventArgs e)
        {
            this.filter();
        }

        private void chkBoxExpired_CheckedChanged(object sender, EventArgs e)
        {
            this.filter();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1.Rows[e.RowIndex].Cells["deleted"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Gray;
                e.CellStyle.SelectionBackColor = Color.Black;
            }
            else if (Convert.ToDateTime(this.dataGridView1.Rows[e.RowIndex].Cells["expired_date"].Value.ToString()) <= this.now)
            {
                e.CellStyle.BackColor = Color.Orange;
                e.CellStyle.SelectionBackColor = Color.OrangeRed;
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                bool flag = false;
                this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                string str = this.dataGridView1.CurrentRow.Cells["deleted"].Value.ToString();
                string str2 = this.ztable.DT.Rows[this.nCurrRow]["Relation_Code"].ToString();
                string from = this.ztable.DT.Rows[this.nCurrRow]["delivery_note_from"].ToString();
                string to = this.ztable.DT.Rows[this.nCurrRow]["delivery_note_to"].ToString();
                string pUniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                string str6 = WBUtility.MergeDNNumber(from, to);
                WBTable table = new WBTable();
                table.OpenTable("checkTrx", "select ref,delivery_note from wb_transaction with (nolock) where delivery_note in (" + str6 + ")", WBData.conn);
                if (table.DT.Rows.Count != 0)
                {
                    if (table.DT.Rows.Count > 0)
                    {
                        MessageBox.Show(string.Format(Resource.DeliveryNote_004, table.DT.Rows[0]["ref"].ToString(), table.DT.Rows[0]["delivery_note"].ToString()), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        return;
                    }
                }
                else if (WBSetting.activeTCS)
                {
                    WBTable table2 = new WBTable();
                    table2.OpenTable("checkGP", "select gatepass_number,delivery_note from wb_gatepass as gp with (nolock) where delivery_note in (" + str6 + ")", WBData.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        MessageBox.Show(string.Format(Resource.DeliveryNote_003, table2.DT.Rows[0]["gatepass_number"].ToString(), table2.DT.Rows[0]["delivery_note"].ToString()), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        return;
                    }
                }
                string[] textArray1 = new string[11];
                textArray1[0] = this.ztable.DT.Rows[this.nCurrRow]["Relation_Code"].ToString();
                textArray1[1] = " : ";
                textArray1[2] = Resource.Setting_046;
                textArray1[3] = " ";
                textArray1[4] = this.ztable.DT.Rows[this.nCurrRow]["Delivery_Note_From"].ToString();
                textArray1[5] = " ";
                textArray1[6] = Resource.Main_029;
                textArray1[7] = " ";
                textArray1[8] = this.ztable.DT.Rows[this.nCurrRow]["Delivery_Note_to"].ToString();
                textArray1[9] = "\n";
                textArray1[10] = Resource.Mes_006;
                if (MessageBox.Show(string.Concat(textArray1), Resource.Menu_Mark_Delete, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.pMode = "DELETE";
                    if (!this.ztable.Locked(pUniq, '1'))
                    {
                        this.ztable.RLock(pUniq, true);
                        this.hasil = this.ztable.tokenOrApp(this.dataGridView1.CurrentRow.Cells["delivery_note_from"].Value.ToString(), this.dataGridView1.CurrentRow.Cells["delivery_note_to"].Value.ToString(), "EDIT_DELETE_MD_DN", "TOKEN_EDIT_DELETE_MASTER_DATA_DELIVERY_NOTE", "EDIT_DELETE_MD_DN", "E", "", null);
                        this.result = this.hasil[0] != "completed";
                        if (!this.result)
                        {
                            FormTransCancel cancel = new FormTransCancel {
                                label1 = { Text = "Delivery Note" },
                                textRefNo = { Text = from + " - " + to },
                                Text = Resource.Form_Mark_Delete_Reason,
                                label2 = { Text = Resource.Lbl_Mark_Delete_Reason }
                            };
                            cancel.textReason.Focus();
                            cancel.ShowDialog();
                            if (cancel.Saved)
                            {
                                this.changeReason = cancel.textReason.Text;
                                cancel.Dispose();
                                this.ztable.uniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                                WBUtility.MarkDeleteDataNoCoyLoc("wb_delivery_note", this.nCurrRow, this.changeReason, this.ztable);
                                flag = true;
                                this.ztable.RLock(pUniq, false);
                                this.dataGridView1.DataSource = this.ztable.DT;
                                this.dataGridView1.Sort(this.dataGridView1.Columns["relation_code"], ListSortDirection.Ascending);
                                this.dataGridView1.Update();
                                this.dataGridView1.Refresh();
                            }
                            else
                            {
                                this.ztable.RLock(pUniq, false);
                                return;
                            }
                        }
                        else
                        {
                            this.ztable.RLock(pUniq, false);
                            return;
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                this.ztable.UnLock();
                if (flag)
                {
                    FormSPBEntryv2 entryv = new FormSPBEntryv2 {
                        delRelCode = str2,
                        delDNFrom = from,
                        delDNTo = to
                    };
                    entryv.GenerateEmail(this.pMode);
                    entryv.Dispose();
                }
                MessageBox.Show(Resource.DeliveryNote_002, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count != 0)
            {
                this.Simpan("EDIT");
            }
        }

        private void extendValidDateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.result = false;
            this.pMode = "EDIT";
            if ((this.dataGridView1.Rows.Count != 0) && !this.ztable.Locked(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString(), '1'))
            {
                string pUniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                this.ztable.RLock(pUniq, true);
                this.hasil = this.ztable.tokenOrApp(this.dataGridView1.CurrentRow.Cells["delivery_note_from"].Value.ToString(), this.dataGridView1.CurrentRow.Cells["delivery_note_to"].Value.ToString(), "EDIT_DELETE_MD_DN", "TOKEN_EDIT_DELETE_MASTER_DATA_DELIVERY_NOTE", "EDIT_DELETE_MD_DN", "E", "", null);
                this.result = this.hasil[0] != "completed";
                if (this.result)
                {
                    this.ztable.RLock(pUniq, false);
                }
                else
                {
                    this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                    string str2 = this.dataGridView1.CurrentRow.Cells["deleted"].Value.ToString();
                    string str3 = this.ztable.DT.Rows[this.nCurrRow]["Relation_Code"].ToString();
                    string str4 = this.ztable.DT.Rows[this.nCurrRow]["delivery_note_from"].ToString();
                    string str5 = this.ztable.DT.Rows[this.nCurrRow]["delivery_note_to"].ToString();
                    string str6 = this.ztable.DT.Rows[this.nCurrRow]["Expired_date"].ToString();
                    FormTransCancel cancel = new FormTransCancel {
                        label1 = { Text = "Delivery Note" },
                        textRefNo = { Text = str4 + " - " + str5 },
                        Text = Resource.Title_Change_Reason,
                        label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                    };
                    cancel.textReason.Focus();
                    cancel.ShowDialog();
                    if (!cancel.Saved)
                    {
                        this.ztable.RLock(pUniq, false);
                    }
                    else
                    {
                        this.changeReason = cancel.textReason.Text;
                        cancel.Dispose();
                        this.ztable.DR = this.ztable.DT.Rows[this.nCurrRow];
                        this.ztable.DR.BeginEdit();
                        this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                        this.ztable.DR["expired_date"] = Convert.ToDateTime(WBUtility.GetServerDatetime().ToShortDateString()).AddDays((double) (WBSetting.DeliveryNoteExpiredDuration * 30));
                        this.ztable.DR["reason"] = this.changeReason;
                        this.ztable.DR["Change_By"] = WBUser.UserID;
                        this.ztable.DR["Change_Date"] = WBUtility.GetServerDatetime();
                        this.ztable.DR.EndEdit();
                        this.ztable.Save();
                        this.ztable.RLock(pUniq, false);
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_delivery_note", this.logKey, logField, logValue);
                        MessageBox.Show(string.Format(Resource.DeliveryNote_001, Convert.ToDateTime(WBUtility.GetServerDatetime().ToShortDateString()).AddDays((double) (WBSetting.DeliveryNoteExpiredDuration * 30)).ToShortDateString()), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
            }
        }

        private void filter()
        {
            this.now = Convert.ToDateTime(WBUtility.GetServerDatetime().ToString("yyyy-MM-dd HH:mm:ss"));
            this.sqlShow = this.checkDeleted.Checked ? "" : " and (Deleted is null or Deleted <> 'Y' or Deleted = 'N')";
            if (!this.chkBoxExpired.Checked)
            {
                this.sqlShow = this.sqlShow + " and expired_date >= '" + WBUtility.GetServerDatetime().ToString("yyyy-MM-dd HH:mm:ss") + "'";
            }
            else
            {
                string sqlShow = this.sqlShow;
                if (this.sqlShow == null)
                {
                    string local1 = this.sqlShow;
                    sqlShow = "";
                }
                this.sqlShow = sqlShow;
            }
            this.ztable.OpenTable("wb_delivery_note", "SELECT * FROM wb_delivery_note where relation_code is not null " + this.sqlShow, WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["relation_code"], ListSortDirection.Ascending);
            this.dataGridView1.Update();
            this.dataGridView1.Refresh();
            this.labelCount.Text = Resource.Lbl_Total_Record + " = " + this.ztable.DT.Rows.Count.ToString();
            this.labelCount.Refresh();
        }

        private void FormSPB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormSPB_Load(object sender, EventArgs e)
        {
            this.sqlShow = this.checkDeleted.Checked ? "" : " and (Deleted is null or Deleted <> 'Y' or Deleted = 'N')";
            if (!this.chkBoxExpired.Checked)
            {
                this.sqlShow = this.sqlShow + " and expired_date >= '" + WBUtility.GetServerDatetime().ToString("yyyy-MM-dd HH:mm:ss") + "'";
            }
            else
            {
                string sqlShow = this.sqlShow;
                if (this.sqlShow == null)
                {
                    string local1 = this.sqlShow;
                    sqlShow = "";
                }
                this.sqlShow = sqlShow;
            }
            this.ztable.OpenTable("wb_delivery_note", "SELECT * FROM wb_delivery_note where relation_code is not null " + this.sqlShow, WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["relation_code"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["relation_code"].DisplayIndex = 0;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["token"].Visible = false;
            this.dataGridView1.Columns["do_no"].Visible = false;
            this.dataGridView1.Columns["token"].Visible = false;
            this.dataGridView1.Columns["Completed"].Visible = false;
            this.dataGridView1.Columns["tes"].Visible = false;
            this.dataGridView1.Columns["relation_code"].HeaderText = Resource.Lbl_Vendor_Customer;
            this.dataGridView1.Columns["Delivery_Note_From"].HeaderText = Resource.Setting_046;
            this.dataGridView1.Columns["Delivery_Note_To"].HeaderText = Resource.Setting_053;
            base.KeyPreview = true;
            this.labelCount.Text = Resource.Lbl_Total_Record + " = " + this.ztable.DT.Rows.Count.ToString();
            this.labelCount.Refresh();
            if (!WBUser.CheckTrustee("MD_DN", "A"))
            {
                this.addNewRecordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_DN", "E"))
            {
                this.editRecordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_DN", "D"))
            {
                this.markdeleteToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_DN", "E"))
            {
                this.extendValidDateToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_DN", "V"))
            {
                this.viewtoolStripMenuItem.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.viewtoolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.markdeleteToolStripMenuItem = new ToolStripMenuItem();
            this.extendValidDateToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.tableLayoutPanel1 = new TableLayoutPanel();
            this.panel2 = new Panel();
            this.buttonFindVendor = new Button();
            this.lblVendorCode = new Label();
            this.txtBoxVendor = new TextBox();
            this.panel1 = new Panel();
            this.chkBoxExpired = new CheckBox();
            this.checkDeleted = new CheckBox();
            this.labelCount = new Label();
            this.Garis1 = new Label();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.dataGridView1 = new DataGridView();
            this.menuStrip1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            base.SuspendLayout();
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x3e4, 0x18);
            this.menuStrip1.TabIndex = 0x12;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.viewtoolStripMenuItem, this.editRecordToolStripMenuItem, this.markdeleteToolStripMenuItem, this.extendValidDateToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xb1, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.viewtoolStripMenuItem.Name = "viewtoolStripMenuItem";
            this.viewtoolStripMenuItem.Size = new Size(0xb1, 0x16);
            this.viewtoolStripMenuItem.Text = "View";
            this.viewtoolStripMenuItem.Click += new EventHandler(this.viewtoolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xb1, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.markdeleteToolStripMenuItem.Name = "markdeleteToolStripMenuItem";
            this.markdeleteToolStripMenuItem.Size = new Size(0xb1, 0x16);
            this.markdeleteToolStripMenuItem.Text = "Mark Delete";
            this.markdeleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.extendValidDateToolStripMenuItem.Name = "extendValidDateToolStripMenuItem";
            this.extendValidDateToolStripMenuItem.Size = new Size(0xb1, 0x16);
            this.extendValidDateToolStripMenuItem.Text = "Extend Expired Date";
            this.extendValidDateToolStripMenuItem.Click += new EventHandler(this.extendValidDateToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel1.Dock = DockStyle.Fill;
            this.tableLayoutPanel1.Location = new Point(0, 0x18);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 8.767123f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 91.23288f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 39f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20f));
            this.tableLayoutPanel1.Size = new Size(0x3e4, 0x195);
            this.tableLayoutPanel1.TabIndex = 20;
            this.panel2.BackColor = Color.LightSteelBlue;
            this.panel2.Controls.Add(this.buttonFindVendor);
            this.panel2.Controls.Add(this.lblVendorCode);
            this.panel2.Controls.Add(this.txtBoxVendor);
            this.panel2.Dock = DockStyle.Fill;
            this.panel2.Location = new Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(990, 0x1a);
            this.panel2.TabIndex = 20;
            this.buttonFindVendor.Location = new Point(0x10b, 1);
            this.buttonFindVendor.Name = "buttonFindVendor";
            this.buttonFindVendor.Size = new Size(0x4b, 0x17);
            this.buttonFindVendor.TabIndex = 0x15;
            this.buttonFindVendor.Text = "Find";
            this.buttonFindVendor.UseVisualStyleBackColor = true;
            this.buttonFindVendor.Click += new EventHandler(this.buttonFindVendor_Click);
            this.lblVendorCode.AutoSize = true;
            this.lblVendorCode.Location = new Point(3, 6);
            this.lblVendorCode.Name = "lblVendorCode";
            this.lblVendorCode.Size = new Size(0x4a, 13);
            this.lblVendorCode.TabIndex = 0x17;
            this.lblVendorCode.Text = "Relation Code";
            this.txtBoxVendor.CharacterCasing = CharacterCasing.Upper;
            this.txtBoxVendor.Location = new Point(0x60, 3);
            this.txtBoxVendor.Name = "txtBoxVendor";
            this.txtBoxVendor.Size = new Size(0xa5, 20);
            this.txtBoxVendor.TabIndex = 0;
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.chkBoxExpired);
            this.panel1.Controls.Add(this.checkDeleted);
            this.panel1.Controls.Add(this.labelCount);
            this.panel1.Controls.Add(this.Garis1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Fill;
            this.panel1.Location = new Point(3, 0x170);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(990, 0x22);
            this.panel1.TabIndex = 0x13;
            this.chkBoxExpired.AutoSize = true;
            this.chkBoxExpired.Location = new Point(0x120, 0);
            this.chkBoxExpired.Name = "chkBoxExpired";
            this.chkBoxExpired.Size = new Size(0x5b, 0x11);
            this.chkBoxExpired.TabIndex = 0x18;
            this.chkBoxExpired.Text = "Show Expired";
            this.chkBoxExpired.UseVisualStyleBackColor = true;
            this.chkBoxExpired.CheckedChanged += new EventHandler(this.chkBoxExpired_CheckedChanged);
            this.checkDeleted.AutoSize = true;
            this.checkDeleted.Location = new Point(0x120, 0x11);
            this.checkDeleted.Name = "checkDeleted";
            this.checkDeleted.Size = new Size(0x5d, 0x11);
            this.checkDeleted.TabIndex = 0x17;
            this.checkDeleted.Text = "Show Deleted";
            this.checkDeleted.UseVisualStyleBackColor = true;
            this.checkDeleted.CheckedChanged += new EventHandler(this.checkDeleted_CheckedChanged);
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new Point(0x37e, 12);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new Size(0x57, 13);
            this.labelCount.TabIndex = 0x16;
            this.labelCount.Text = "Total Record = 0";
            this.Garis1.BorderStyle = BorderStyle.Fixed3D;
            this.Garis1.Location = new Point(0x112, -8);
            this.Garis1.Margin = new Padding(1, 0, 1, 0);
            this.Garis1.Name = "Garis1";
            this.Garis1.Size = new Size(10, 0x2d);
            this.Garis1.TabIndex = 5;
            this.TextFind.Location = new Point(5, 7);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 0;
            this.buttonFind.Location = new Point(0xc3, 7);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 1;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.ClipboardCopyMode = DataGridViewClipboardCopyMode.Disable;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(3, 0x23);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(990, 0x147);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x3e4, 0x1ad);
            base.ControlBox = false;
            base.Controls.Add(this.tableLayoutPanel1);
            base.Controls.Add(this.menuStrip1);
            base.Name = "FormSPBv2";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Delivery Note Number";
            base.Load += new EventHandler(this.FormSPB_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormSPB_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void Simpan(string prMode)
        {
            string pUniq = "";
            if (prMode == "EDIT")
            {
                this.spMode = "EDIT_DELETE_MD_DN";
                pUniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
                int index = this.dataGridView1.CurrentRow.Index;
            }
            else if (prMode == "ADD")
            {
                this.spMode = "ADD";
            }
            this.result = false;
            if (prMode != "ADD")
            {
                if (!this.ztable.Locked(pUniq, '1'))
                {
                    this.ztable.RLock(pUniq, true);
                    this.hasil = this.ztable.tokenOrApp(this.dataGridView1.CurrentRow.Cells["delivery_note_from"].Value.ToString(), this.dataGridView1.CurrentRow.Cells["delivery_note_to"].Value.ToString(), "EDIT_DELETE_MD_DN", "TOKEN_EDIT_DELETE_MASTER_DATA_DELIVERY_NOTE", "EDIT_DELETE_MD_DN", "E", "", null);
                    this.result = this.hasil[0] != "completed";
                    if (this.result)
                    {
                        this.ztable.RLock(pUniq, false);
                        return;
                    }
                }
                else
                {
                    return;
                }
            }
            FormSPBEntryv2 entryv = new FormSPBEntryv2 {
                pMode = prMode,
                pDo_No = this.pDo_No,
                zTable = this.ztable
            };
            if (prMode != "ADD")
            {
                entryv.dataGridPosRow = this.dataGridView1.CurrentRow.Index;
            }
            entryv.Text = (prMode == "ADD") ? Resource.Menu_Add : Resource.Menu_Edit;
            entryv.dataGridView1 = this.dataGridView1;
            if (prMode != "ADD")
            {
                entryv.sUniq = Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
            }
            entryv.ShowDialog();
            if (entryv.saved)
            {
                this.ztable.ReOpen();
                this.dataGridView1.DataSource = this.ztable.DT;
                this.dataGridView1.Sort(this.dataGridView1.Columns["relation_code"], ListSortDirection.Ascending);
                this.dataGridView1.Update();
                this.dataGridView1.Refresh();
            }
            if (this.pMode != "ADD")
            {
                this.ztable.RLock(pUniq, false);
            }
            entryv.Dispose();
            this.ztable.UnLock();
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.markdeleteToolStripMenuItem.Text = Resource.Menu_Mark_Delete;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
        }

        private void viewtoolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSPBEntryv2 entryv = new FormSPBEntryv2 {
                pMode = "VIEW",
                zTable = this.ztable,
                Text = Resource.Menu_View,
                dataGridView1 = this.dataGridView1
            };
            if (this.dataGridView1.Rows.Count > 0)
            {
                entryv.sUniq = Convert.ToInt32(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
            }
            entryv.ShowDialog();
            this.ztable.UnLock();
            entryv.Dispose();
        }
    }
}

