﻿namespace WindowsFormsApplication1
{
    using System;
    using System.CodeDom.Compiler;
    using System.Collections;
    using System.ComponentModel;
    using System.ComponentModel.Design;
    using System.Data;
    using System.Diagnostics;
    using System.IO;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.Serialization;
    using System.Threading;
    using System.Xml;
    using System.Xml.Schema;
    using System.Xml.Serialization;

    [Serializable, DesignerCategory("code"), ToolboxItem(true), XmlSchemaProvider("GetTypedDataSetSchema"), XmlRoot("DataSetTicketSPB"), HelpKeyword("vs.data.DataSet")]
    public class DataSetTicketSPB : DataSet
    {
        private TransactionDataTable tableTransaction;
        private ContractDataTable tableContract;
        private SettingDataTable tableSetting;
        private ContainerDataTable tableContainer;
        private DetailGamaDataTable tableDetailGama;
        private HeaderGamaDataTable tableHeaderGama;
        private System.Data.SchemaSerializationMode _schemaSerializationMode;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public DataSetTicketSPB()
        {
            this._schemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            base.BeginInit();
            this.InitClass();
            CollectionChangeEventHandler handler = new CollectionChangeEventHandler(this.SchemaChanged);
            base.Tables.CollectionChanged += handler;
            base.Relations.CollectionChanged += handler;
            base.EndInit();
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected DataSetTicketSPB(SerializationInfo info, StreamingContext context) : base(info, context, false)
        {
            this._schemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            if (base.IsBinarySerialized(info, context))
            {
                this.InitVars(false);
                CollectionChangeEventHandler handler2 = new CollectionChangeEventHandler(this.SchemaChanged);
                this.Tables.CollectionChanged += handler2;
                this.Relations.CollectionChanged += handler2;
            }
            else
            {
                string s = (string) info.GetValue("XmlSchema", typeof(string));
                if (base.DetermineSchemaSerializationMode(info, context) != System.Data.SchemaSerializationMode.IncludeSchema)
                {
                    base.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
                }
                else
                {
                    DataSet dataSet = new DataSet();
                    dataSet.ReadXmlSchema(new XmlTextReader(new StringReader(s)));
                    if (dataSet.Tables["Transaction"] != null)
                    {
                        base.Tables.Add(new TransactionDataTable(dataSet.Tables["Transaction"]));
                    }
                    if (dataSet.Tables["Contract"] != null)
                    {
                        base.Tables.Add(new ContractDataTable(dataSet.Tables["Contract"]));
                    }
                    if (dataSet.Tables["Setting"] != null)
                    {
                        base.Tables.Add(new SettingDataTable(dataSet.Tables["Setting"]));
                    }
                    if (dataSet.Tables["Container"] != null)
                    {
                        base.Tables.Add(new ContainerDataTable(dataSet.Tables["Container"]));
                    }
                    if (dataSet.Tables["DetailGama"] != null)
                    {
                        base.Tables.Add(new DetailGamaDataTable(dataSet.Tables["DetailGama"]));
                    }
                    if (dataSet.Tables["HeaderGama"] != null)
                    {
                        base.Tables.Add(new HeaderGamaDataTable(dataSet.Tables["HeaderGama"]));
                    }
                    base.DataSetName = dataSet.DataSetName;
                    base.Prefix = dataSet.Prefix;
                    base.Namespace = dataSet.Namespace;
                    base.Locale = dataSet.Locale;
                    base.CaseSensitive = dataSet.CaseSensitive;
                    base.EnforceConstraints = dataSet.EnforceConstraints;
                    base.Merge(dataSet, false, MissingSchemaAction.Add);
                    this.InitVars();
                }
                base.GetSerializationData(info, context);
                CollectionChangeEventHandler handler = new CollectionChangeEventHandler(this.SchemaChanged);
                base.Tables.CollectionChanged += handler;
                this.Relations.CollectionChanged += handler;
            }
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public override DataSet Clone()
        {
            DataSetTicketSPB tspb = (DataSetTicketSPB) base.Clone();
            tspb.InitVars();
            tspb.SchemaSerializationMode = this.SchemaSerializationMode;
            return tspb;
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override XmlSchema GetSchemaSerializable()
        {
            MemoryStream w = new MemoryStream();
            base.WriteXmlSchema(new XmlTextWriter(w, null));
            w.Position = 0L;
            return XmlSchema.Read(new XmlTextReader(w), null);
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public static XmlSchemaComplexType GetTypedDataSetSchema(XmlSchemaSet xs)
        {
            DataSetTicketSPB tspb = new DataSetTicketSPB();
            XmlSchemaComplexType type = new XmlSchemaComplexType();
            XmlSchemaSequence sequence = new XmlSchemaSequence();
            XmlSchemaAny item = new XmlSchemaAny {
                Namespace = tspb.Namespace
            };
            sequence.Items.Add(item);
            type.Particle = sequence;
            XmlSchema schemaSerializable = tspb.GetSchemaSerializable();
            if (xs.Contains(schemaSerializable.TargetNamespace))
            {
                MemoryStream stream = new MemoryStream();
                MemoryStream stream2 = new MemoryStream();
                try
                {
                    XmlSchema current = null;
                    schemaSerializable.Write(stream);
                    IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                    while (true)
                    {
                        if (!enumerator.MoveNext())
                        {
                            break;
                        }
                        current = (XmlSchema) enumerator.Current;
                        stream2.SetLength(0L);
                        current.Write(stream2);
                        if (stream.Length == stream2.Length)
                        {
                            stream.Position = 0L;
                            stream2.Position = 0L;
                            while (true)
                            {
                                if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                {
                                    continue;
                                }
                                if (stream.Position != stream.Length)
                                {
                                    break;
                                }
                                return type;
                            }
                        }
                    }
                }
                finally
                {
                    if (stream != null)
                    {
                        stream.Close();
                    }
                    if (stream2 != null)
                    {
                        stream2.Close();
                    }
                }
            }
            xs.Add(schemaSerializable);
            return type;
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private void InitClass()
        {
            base.DataSetName = "DataSetTicketSPB";
            base.Prefix = "";
            base.Namespace = "http://tempuri.org/DataSetTicketSPB.xsd";
            base.EnforceConstraints = true;
            this.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            this.tableTransaction = new TransactionDataTable();
            base.Tables.Add(this.tableTransaction);
            this.tableContract = new ContractDataTable();
            base.Tables.Add(this.tableContract);
            this.tableSetting = new SettingDataTable();
            base.Tables.Add(this.tableSetting);
            this.tableContainer = new ContainerDataTable();
            base.Tables.Add(this.tableContainer);
            this.tableDetailGama = new DetailGamaDataTable();
            base.Tables.Add(this.tableDetailGama);
            this.tableHeaderGama = new HeaderGamaDataTable();
            base.Tables.Add(this.tableHeaderGama);
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override void InitializeDerivedDataSet()
        {
            base.BeginInit();
            this.InitClass();
            base.EndInit();
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        internal void InitVars()
        {
            this.InitVars(true);
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        internal void InitVars(bool initTable)
        {
            this.tableTransaction = (TransactionDataTable) base.Tables["Transaction"];
            if (initTable && (this.tableTransaction != null))
            {
                this.tableTransaction.InitVars();
            }
            this.tableContract = (ContractDataTable) base.Tables["Contract"];
            if (initTable && (this.tableContract != null))
            {
                this.tableContract.InitVars();
            }
            this.tableSetting = (SettingDataTable) base.Tables["Setting"];
            if (initTable && (this.tableSetting != null))
            {
                this.tableSetting.InitVars();
            }
            this.tableContainer = (ContainerDataTable) base.Tables["Container"];
            if (initTable && (this.tableContainer != null))
            {
                this.tableContainer.InitVars();
            }
            this.tableDetailGama = (DetailGamaDataTable) base.Tables["DetailGama"];
            if (initTable && (this.tableDetailGama != null))
            {
                this.tableDetailGama.InitVars();
            }
            this.tableHeaderGama = (HeaderGamaDataTable) base.Tables["HeaderGama"];
            if (initTable && (this.tableHeaderGama != null))
            {
                this.tableHeaderGama.InitVars();
            }
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override void ReadXmlSerializable(XmlReader reader)
        {
            if (base.DetermineSchemaSerializationMode(reader) != System.Data.SchemaSerializationMode.IncludeSchema)
            {
                base.ReadXml(reader);
                this.InitVars();
            }
            else
            {
                this.Reset();
                DataSet dataSet = new DataSet();
                dataSet.ReadXml(reader);
                if (dataSet.Tables["Transaction"] != null)
                {
                    base.Tables.Add(new TransactionDataTable(dataSet.Tables["Transaction"]));
                }
                if (dataSet.Tables["Contract"] != null)
                {
                    base.Tables.Add(new ContractDataTable(dataSet.Tables["Contract"]));
                }
                if (dataSet.Tables["Setting"] != null)
                {
                    base.Tables.Add(new SettingDataTable(dataSet.Tables["Setting"]));
                }
                if (dataSet.Tables["Container"] != null)
                {
                    base.Tables.Add(new ContainerDataTable(dataSet.Tables["Container"]));
                }
                if (dataSet.Tables["DetailGama"] != null)
                {
                    base.Tables.Add(new DetailGamaDataTable(dataSet.Tables["DetailGama"]));
                }
                if (dataSet.Tables["HeaderGama"] != null)
                {
                    base.Tables.Add(new HeaderGamaDataTable(dataSet.Tables["HeaderGama"]));
                }
                base.DataSetName = dataSet.DataSetName;
                base.Prefix = dataSet.Prefix;
                base.Namespace = dataSet.Namespace;
                base.Locale = dataSet.Locale;
                base.CaseSensitive = dataSet.CaseSensitive;
                base.EnforceConstraints = dataSet.EnforceConstraints;
                base.Merge(dataSet, false, MissingSchemaAction.Add);
                this.InitVars();
            }
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private void SchemaChanged(object sender, CollectionChangeEventArgs e)
        {
            if (e.Action == CollectionChangeAction.Remove)
            {
                this.InitVars();
            }
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializeContainer() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializeContract() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializeDetailGama() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializeHeaderGama() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override bool ShouldSerializeRelations() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializeSetting() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        protected override bool ShouldSerializeTables() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        private bool ShouldSerializeTransaction() => 
            false;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public TransactionDataTable Transaction =>
            this.tableTransaction;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public ContractDataTable Contract =>
            this.tableContract;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public SettingDataTable Setting =>
            this.tableSetting;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public ContainerDataTable Container =>
            this.tableContainer;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public DetailGamaDataTable DetailGama =>
            this.tableDetailGama;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public HeaderGamaDataTable HeaderGama =>
            this.tableHeaderGama;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public override System.Data.SchemaSerializationMode SchemaSerializationMode
        {
            get => 
                this._schemaSerializationMode;
            set => 
                this._schemaSerializationMode = value;
        }

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataTableCollection Tables =>
            base.Tables;

        [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataRelationCollection Relations =>
            base.Relations;

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class ContainerDataTable : TypedTableBase<DataSetTicketSPB.ContainerRow>
        {
            private DataColumn columnContainerNo;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.ContainerRowChangeEventHandler ContainerRowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.ContainerRowChangeEventHandler ContainerRowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.ContainerRowChangeEventHandler ContainerRowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.ContainerRowChangeEventHandler ContainerRowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public ContainerDataTable()
            {
                base.TableName = "Container";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal ContainerDataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected ContainerDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.ContainerRow AddContainerRow(string ContainerNo)
            {
                DataSetTicketSPB.ContainerRow row = (DataSetTicketSPB.ContainerRow) base.NewRow();
                row.ItemArray = new object[] { ContainerNo };
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void AddContainerRow(DataSetTicketSPB.ContainerRow row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSetTicketSPB.ContainerDataTable table = (DataSetTicketSPB.ContainerDataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSetTicketSPB.ContainerDataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSetTicketSPB.ContainerRow);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSetTicketSPB tspb = new DataSetTicketSPB();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = tspb.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "ContainerDataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = tspb.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnContainerNo = new DataColumn("ContainerNo", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnContainerNo);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnContainerNo = base.Columns["ContainerNo"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.ContainerRow NewContainerRow() => 
                (DataSetTicketSPB.ContainerRow) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSetTicketSPB.ContainerRow(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.ContainerRowChanged != null)
                {
                    this.ContainerRowChanged(this, new DataSetTicketSPB.ContainerRowChangeEvent((DataSetTicketSPB.ContainerRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.ContainerRowChanging != null)
                {
                    this.ContainerRowChanging(this, new DataSetTicketSPB.ContainerRowChangeEvent((DataSetTicketSPB.ContainerRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.ContainerRowDeleted != null)
                {
                    this.ContainerRowDeleted(this, new DataSetTicketSPB.ContainerRowChangeEvent((DataSetTicketSPB.ContainerRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.ContainerRowDeleting != null)
                {
                    this.ContainerRowDeleting(this, new DataSetTicketSPB.ContainerRowChangeEvent((DataSetTicketSPB.ContainerRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void RemoveContainerRow(DataSetTicketSPB.ContainerRow row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn ContainerNoColumn =>
                this.columnContainerNo;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.ContainerRow this[int index] =>
                (DataSetTicketSPB.ContainerRow) base.Rows[index];
        }

        public class ContainerRow : DataRow
        {
            private DataSetTicketSPB.ContainerDataTable tableContainer;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal ContainerRow(DataRowBuilder rb) : base(rb)
            {
                this.tableContainer = (DataSetTicketSPB.ContainerDataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsContainerNoNull() => 
                base.IsNull(this.tableContainer.ContainerNoColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetContainerNoNull()
            {
                base[this.tableContainer.ContainerNoColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string ContainerNo
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableContainer.ContainerNoColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'ContainerNo' in table 'Container' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableContainer.ContainerNoColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class ContainerRowChangeEvent : EventArgs
        {
            private DataSetTicketSPB.ContainerRow eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public ContainerRowChangeEvent(DataSetTicketSPB.ContainerRow row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.ContainerRow Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void ContainerRowChangeEventHandler(object sender, DataSetTicketSPB.ContainerRowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class ContractDataTable : TypedTableBase<DataSetTicketSPB.ContractRow>
        {
            private DataColumn columndo_no;
            private DataColumn columnPO;
            private DataColumn columnrelation_name;
            private DataColumn columnrelation_address;
            private DataColumn columntransporter_name;
            private DataColumn columnsend_date;
            private DataColumn columndate2;
            private DataColumn columndelivery_date;
            private DataColumn columnno_ticket_spb;
            private DataColumn columnno_ticket_spb2;
            private DataColumn columnSO;
            private DataColumn columncommodity_uom;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.ContractRowChangeEventHandler ContractRowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.ContractRowChangeEventHandler ContractRowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.ContractRowChangeEventHandler ContractRowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.ContractRowChangeEventHandler ContractRowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public ContractDataTable()
            {
                base.TableName = "Contract";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal ContractDataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected ContractDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void AddContractRow(DataSetTicketSPB.ContractRow row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.ContractRow AddContractRow(string do_no, string PO, string relation_name, string relation_address, string transporter_name, string send_date, string date2, string delivery_date, string no_ticket_spb, string no_ticket_spb2, string SO, string commodity_uom)
            {
                DataSetTicketSPB.ContractRow row = (DataSetTicketSPB.ContractRow) base.NewRow();
                object[] objArray1 = new object[12];
                objArray1[0] = do_no;
                objArray1[1] = PO;
                objArray1[2] = relation_name;
                objArray1[3] = relation_address;
                objArray1[4] = transporter_name;
                objArray1[5] = send_date;
                objArray1[6] = date2;
                objArray1[7] = delivery_date;
                objArray1[8] = no_ticket_spb;
                objArray1[9] = no_ticket_spb2;
                objArray1[10] = SO;
                objArray1[11] = commodity_uom;
                row.ItemArray = objArray1;
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSetTicketSPB.ContractDataTable table = (DataSetTicketSPB.ContractDataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSetTicketSPB.ContractDataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSetTicketSPB.ContractRow);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSetTicketSPB tspb = new DataSetTicketSPB();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = tspb.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "ContractDataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = tspb.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columndo_no = new DataColumn("do_no", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columndo_no);
                this.columnPO = new DataColumn("PO", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnPO);
                this.columnrelation_name = new DataColumn("relation_name", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnrelation_name);
                this.columnrelation_address = new DataColumn("relation_address", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnrelation_address);
                this.columntransporter_name = new DataColumn("transporter_name", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columntransporter_name);
                this.columnsend_date = new DataColumn("send_date", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnsend_date);
                this.columndate2 = new DataColumn("date2", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columndate2);
                this.columndelivery_date = new DataColumn("delivery_date", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columndelivery_date);
                this.columnno_ticket_spb = new DataColumn("no_ticket_spb", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnno_ticket_spb);
                this.columnno_ticket_spb2 = new DataColumn("no_ticket_spb2", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnno_ticket_spb2);
                this.columnSO = new DataColumn("SO", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnSO);
                this.columncommodity_uom = new DataColumn("commodity_uom", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columncommodity_uom);
                this.columnsend_date.Caption = "Report_date";
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columndo_no = base.Columns["do_no"];
                this.columnPO = base.Columns["PO"];
                this.columnrelation_name = base.Columns["relation_name"];
                this.columnrelation_address = base.Columns["relation_address"];
                this.columntransporter_name = base.Columns["transporter_name"];
                this.columnsend_date = base.Columns["send_date"];
                this.columndate2 = base.Columns["date2"];
                this.columndelivery_date = base.Columns["delivery_date"];
                this.columnno_ticket_spb = base.Columns["no_ticket_spb"];
                this.columnno_ticket_spb2 = base.Columns["no_ticket_spb2"];
                this.columnSO = base.Columns["SO"];
                this.columncommodity_uom = base.Columns["commodity_uom"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.ContractRow NewContractRow() => 
                (DataSetTicketSPB.ContractRow) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSetTicketSPB.ContractRow(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.ContractRowChanged != null)
                {
                    this.ContractRowChanged(this, new DataSetTicketSPB.ContractRowChangeEvent((DataSetTicketSPB.ContractRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.ContractRowChanging != null)
                {
                    this.ContractRowChanging(this, new DataSetTicketSPB.ContractRowChangeEvent((DataSetTicketSPB.ContractRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.ContractRowDeleted != null)
                {
                    this.ContractRowDeleted(this, new DataSetTicketSPB.ContractRowChangeEvent((DataSetTicketSPB.ContractRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.ContractRowDeleting != null)
                {
                    this.ContractRowDeleting(this, new DataSetTicketSPB.ContractRowChangeEvent((DataSetTicketSPB.ContractRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void RemoveContractRow(DataSetTicketSPB.ContractRow row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn do_noColumn =>
                this.columndo_no;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn POColumn =>
                this.columnPO;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn relation_nameColumn =>
                this.columnrelation_name;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn relation_addressColumn =>
                this.columnrelation_address;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn transporter_nameColumn =>
                this.columntransporter_name;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn send_dateColumn =>
                this.columnsend_date;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn date2Column =>
                this.columndate2;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn delivery_dateColumn =>
                this.columndelivery_date;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn no_ticket_spbColumn =>
                this.columnno_ticket_spb;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn no_ticket_spb2Column =>
                this.columnno_ticket_spb2;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn SOColumn =>
                this.columnSO;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn commodity_uomColumn =>
                this.columncommodity_uom;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.ContractRow this[int index] =>
                (DataSetTicketSPB.ContractRow) base.Rows[index];
        }

        public class ContractRow : DataRow
        {
            private DataSetTicketSPB.ContractDataTable tableContract;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal ContractRow(DataRowBuilder rb) : base(rb)
            {
                this.tableContract = (DataSetTicketSPB.ContractDataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Iscommodity_uomNull() => 
                base.IsNull(this.tableContract.commodity_uomColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isdate2Null() => 
                base.IsNull(this.tableContract.date2Column);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isdelivery_dateNull() => 
                base.IsNull(this.tableContract.delivery_dateColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isdo_noNull() => 
                base.IsNull(this.tableContract.do_noColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isno_ticket_spb2Null() => 
                base.IsNull(this.tableContract.no_ticket_spb2Column);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isno_ticket_spbNull() => 
                base.IsNull(this.tableContract.no_ticket_spbColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsPONull() => 
                base.IsNull(this.tableContract.POColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isrelation_addressNull() => 
                base.IsNull(this.tableContract.relation_addressColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isrelation_nameNull() => 
                base.IsNull(this.tableContract.relation_nameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Issend_dateNull() => 
                base.IsNull(this.tableContract.send_dateColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsSONull() => 
                base.IsNull(this.tableContract.SOColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Istransporter_nameNull() => 
                base.IsNull(this.tableContract.transporter_nameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setcommodity_uomNull()
            {
                base[this.tableContract.commodity_uomColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setdate2Null()
            {
                base[this.tableContract.date2Column] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setdelivery_dateNull()
            {
                base[this.tableContract.delivery_dateColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setdo_noNull()
            {
                base[this.tableContract.do_noColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setno_ticket_spb2Null()
            {
                base[this.tableContract.no_ticket_spb2Column] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setno_ticket_spbNull()
            {
                base[this.tableContract.no_ticket_spbColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetPONull()
            {
                base[this.tableContract.POColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setrelation_addressNull()
            {
                base[this.tableContract.relation_addressColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setrelation_nameNull()
            {
                base[this.tableContract.relation_nameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setsend_dateNull()
            {
                base[this.tableContract.send_dateColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetSONull()
            {
                base[this.tableContract.SOColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Settransporter_nameNull()
            {
                base[this.tableContract.transporter_nameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string do_no
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableContract.do_noColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'do_no' in table 'Contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableContract.do_noColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string PO
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableContract.POColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'PO' in table 'Contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableContract.POColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string relation_name
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableContract.relation_nameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'relation_name' in table 'Contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableContract.relation_nameColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string relation_address
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableContract.relation_addressColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'relation_address' in table 'Contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableContract.relation_addressColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string transporter_name
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableContract.transporter_nameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'transporter_name' in table 'Contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableContract.transporter_nameColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string send_date
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableContract.send_dateColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'send_date' in table 'Contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableContract.send_dateColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string date2
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableContract.date2Column];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'date2' in table 'Contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableContract.date2Column] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string delivery_date
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableContract.delivery_dateColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'delivery_date' in table 'Contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableContract.delivery_dateColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string no_ticket_spb
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableContract.no_ticket_spbColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'no_ticket_spb' in table 'Contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableContract.no_ticket_spbColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string no_ticket_spb2
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableContract.no_ticket_spb2Column];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'no_ticket_spb2' in table 'Contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableContract.no_ticket_spb2Column] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string SO
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableContract.SOColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'SO' in table 'Contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableContract.SOColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string commodity_uom
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableContract.commodity_uomColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'commodity_uom' in table 'Contract' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableContract.commodity_uomColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class ContractRowChangeEvent : EventArgs
        {
            private DataSetTicketSPB.ContractRow eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public ContractRowChangeEvent(DataSetTicketSPB.ContractRow row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.ContractRow Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void ContractRowChangeEventHandler(object sender, DataSetTicketSPB.ContractRowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class DetailGamaDataTable : TypedTableBase<DataSetTicketSPB.DetailGamaRow>
        {
            private DataColumn columnno;
            private DataColumn columncomm_name;
            private DataColumn columngross;
            private DataColumn columntare;
            private DataColumn columnnetto;
            private DataColumn columnloading_qty;
            private DataColumn columndo_base_uom;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.DetailGamaRowChangeEventHandler DetailGamaRowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.DetailGamaRowChangeEventHandler DetailGamaRowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.DetailGamaRowChangeEventHandler DetailGamaRowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.DetailGamaRowChangeEventHandler DetailGamaRowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DetailGamaDataTable()
            {
                base.TableName = "DetailGama";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal DetailGamaDataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected DetailGamaDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void AddDetailGamaRow(DataSetTicketSPB.DetailGamaRow row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.DetailGamaRow AddDetailGamaRow(int no, string comm_name, string gross, string tare, string netto, string loading_qty, string do_base_uom)
            {
                DataSetTicketSPB.DetailGamaRow row = (DataSetTicketSPB.DetailGamaRow) base.NewRow();
                row.ItemArray = new object[] { no, comm_name, gross, tare, netto, loading_qty, do_base_uom };
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSetTicketSPB.DetailGamaDataTable table = (DataSetTicketSPB.DetailGamaDataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSetTicketSPB.DetailGamaDataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSetTicketSPB.DetailGamaRow);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSetTicketSPB tspb = new DataSetTicketSPB();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = tspb.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "DetailGamaDataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = tspb.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnno = new DataColumn("no", typeof(int), null, MappingType.Element);
                base.Columns.Add(this.columnno);
                this.columncomm_name = new DataColumn("comm_name", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columncomm_name);
                this.columngross = new DataColumn("gross", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columngross);
                this.columntare = new DataColumn("tare", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columntare);
                this.columnnetto = new DataColumn("netto", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnnetto);
                this.columnloading_qty = new DataColumn("loading_qty", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnloading_qty);
                this.columndo_base_uom = new DataColumn("do_base_uom", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columndo_base_uom);
                this.columntare.Caption = "tarra";
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnno = base.Columns["no"];
                this.columncomm_name = base.Columns["comm_name"];
                this.columngross = base.Columns["gross"];
                this.columntare = base.Columns["tare"];
                this.columnnetto = base.Columns["netto"];
                this.columnloading_qty = base.Columns["loading_qty"];
                this.columndo_base_uom = base.Columns["do_base_uom"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.DetailGamaRow NewDetailGamaRow() => 
                (DataSetTicketSPB.DetailGamaRow) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSetTicketSPB.DetailGamaRow(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.DetailGamaRowChanged != null)
                {
                    this.DetailGamaRowChanged(this, new DataSetTicketSPB.DetailGamaRowChangeEvent((DataSetTicketSPB.DetailGamaRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.DetailGamaRowChanging != null)
                {
                    this.DetailGamaRowChanging(this, new DataSetTicketSPB.DetailGamaRowChangeEvent((DataSetTicketSPB.DetailGamaRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.DetailGamaRowDeleted != null)
                {
                    this.DetailGamaRowDeleted(this, new DataSetTicketSPB.DetailGamaRowChangeEvent((DataSetTicketSPB.DetailGamaRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.DetailGamaRowDeleting != null)
                {
                    this.DetailGamaRowDeleting(this, new DataSetTicketSPB.DetailGamaRowChangeEvent((DataSetTicketSPB.DetailGamaRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void RemoveDetailGamaRow(DataSetTicketSPB.DetailGamaRow row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn noColumn =>
                this.columnno;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn comm_nameColumn =>
                this.columncomm_name;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn grossColumn =>
                this.columngross;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn tareColumn =>
                this.columntare;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn nettoColumn =>
                this.columnnetto;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn loading_qtyColumn =>
                this.columnloading_qty;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn do_base_uomColumn =>
                this.columndo_base_uom;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.DetailGamaRow this[int index] =>
                (DataSetTicketSPB.DetailGamaRow) base.Rows[index];
        }

        public class DetailGamaRow : DataRow
        {
            private DataSetTicketSPB.DetailGamaDataTable tableDetailGama;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal DetailGamaRow(DataRowBuilder rb) : base(rb)
            {
                this.tableDetailGama = (DataSetTicketSPB.DetailGamaDataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Iscomm_nameNull() => 
                base.IsNull(this.tableDetailGama.comm_nameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isdo_base_uomNull() => 
                base.IsNull(this.tableDetailGama.do_base_uomColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsgrossNull() => 
                base.IsNull(this.tableDetailGama.grossColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isloading_qtyNull() => 
                base.IsNull(this.tableDetailGama.loading_qtyColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsnettoNull() => 
                base.IsNull(this.tableDetailGama.nettoColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsnoNull() => 
                base.IsNull(this.tableDetailGama.noColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IstareNull() => 
                base.IsNull(this.tableDetailGama.tareColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setcomm_nameNull()
            {
                base[this.tableDetailGama.comm_nameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setdo_base_uomNull()
            {
                base[this.tableDetailGama.do_base_uomColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetgrossNull()
            {
                base[this.tableDetailGama.grossColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setloading_qtyNull()
            {
                base[this.tableDetailGama.loading_qtyColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetnettoNull()
            {
                base[this.tableDetailGama.nettoColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetnoNull()
            {
                base[this.tableDetailGama.noColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SettareNull()
            {
                base[this.tableDetailGama.tareColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public int no
            {
                get
                {
                    int num;
                    try
                    {
                        num = (int) base[this.tableDetailGama.noColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'no' in table 'DetailGama' is DBNull.", exception);
                    }
                    return num;
                }
                set => 
                    base[this.tableDetailGama.noColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string comm_name
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDetailGama.comm_nameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'comm_name' in table 'DetailGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDetailGama.comm_nameColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string gross
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDetailGama.grossColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'gross' in table 'DetailGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDetailGama.grossColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string tare
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDetailGama.tareColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'tare' in table 'DetailGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDetailGama.tareColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string netto
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDetailGama.nettoColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'netto' in table 'DetailGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDetailGama.nettoColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string loading_qty
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDetailGama.loading_qtyColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'loading_qty' in table 'DetailGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDetailGama.loading_qtyColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string do_base_uom
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableDetailGama.do_base_uomColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'do_base_uom' in table 'DetailGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableDetailGama.do_base_uomColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class DetailGamaRowChangeEvent : EventArgs
        {
            private DataSetTicketSPB.DetailGamaRow eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DetailGamaRowChangeEvent(DataSetTicketSPB.DetailGamaRow row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.DetailGamaRow Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void DetailGamaRowChangeEventHandler(object sender, DataSetTicketSPB.DetailGamaRowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class HeaderGamaDataTable : TypedTableBase<DataSetTicketSPB.HeaderGamaRow>
        {
            private DataColumn columnspb_no;
            private DataColumn columntruck_number;
            private DataColumn columndo_no;
            private DataColumn columnrelation_name;
            private DataColumn columnrelation_address;
            private DataColumn columntransporter_name;
            private DataColumn columndate2;
            private DataColumn columnsubmit_date;
            private DataColumn columnno_ticket_spb;
            private DataColumn columnSO;
            private DataColumn columncontainer_no;
            private DataColumn columnseal_no;
            private DataColumn columncoy_name;
            private DataColumn columnbulkpack;
            private DataColumn columnunit;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.HeaderGamaRowChangeEventHandler HeaderGamaRowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.HeaderGamaRowChangeEventHandler HeaderGamaRowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.HeaderGamaRowChangeEventHandler HeaderGamaRowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.HeaderGamaRowChangeEventHandler HeaderGamaRowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public HeaderGamaDataTable()
            {
                base.TableName = "HeaderGama";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal HeaderGamaDataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected HeaderGamaDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void AddHeaderGamaRow(DataSetTicketSPB.HeaderGamaRow row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.HeaderGamaRow AddHeaderGamaRow(string spb_no, string truck_number, string do_no, string relation_name, string relation_address, string transporter_name, string date2, string submit_date, int no_ticket_spb, string SO, string container_no, string seal_no, string coy_name, string bulkpack, string unit)
            {
                DataSetTicketSPB.HeaderGamaRow row = (DataSetTicketSPB.HeaderGamaRow) base.NewRow();
                object[] objArray1 = new object[15];
                objArray1[0] = spb_no;
                objArray1[1] = truck_number;
                objArray1[2] = do_no;
                objArray1[3] = relation_name;
                objArray1[4] = relation_address;
                objArray1[5] = transporter_name;
                objArray1[6] = date2;
                objArray1[7] = submit_date;
                objArray1[8] = no_ticket_spb;
                objArray1[9] = SO;
                objArray1[10] = container_no;
                objArray1[11] = seal_no;
                objArray1[12] = coy_name;
                objArray1[13] = bulkpack;
                objArray1[14] = unit;
                row.ItemArray = objArray1;
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSetTicketSPB.HeaderGamaDataTable table = (DataSetTicketSPB.HeaderGamaDataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSetTicketSPB.HeaderGamaDataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSetTicketSPB.HeaderGamaRow);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSetTicketSPB tspb = new DataSetTicketSPB();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = tspb.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "HeaderGamaDataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = tspb.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnspb_no = new DataColumn("spb_no", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnspb_no);
                this.columntruck_number = new DataColumn("truck_number", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columntruck_number);
                this.columndo_no = new DataColumn("do_no", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columndo_no);
                this.columnrelation_name = new DataColumn("relation_name", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnrelation_name);
                this.columnrelation_address = new DataColumn("relation_address", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnrelation_address);
                this.columntransporter_name = new DataColumn("transporter_name", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columntransporter_name);
                this.columndate2 = new DataColumn("date2", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columndate2);
                this.columnsubmit_date = new DataColumn("submit_date", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnsubmit_date);
                this.columnno_ticket_spb = new DataColumn("no_ticket_spb", typeof(int), null, MappingType.Element);
                base.Columns.Add(this.columnno_ticket_spb);
                this.columnSO = new DataColumn("SO", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnSO);
                this.columncontainer_no = new DataColumn("container_no", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columncontainer_no);
                this.columnseal_no = new DataColumn("seal_no", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnseal_no);
                this.columncoy_name = new DataColumn("coy_name", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columncoy_name);
                this.columnbulkpack = new DataColumn("bulkpack", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnbulkpack);
                this.columnunit = new DataColumn("unit", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnunit);
                this.columnsubmit_date.Caption = "delivery_date";
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnspb_no = base.Columns["spb_no"];
                this.columntruck_number = base.Columns["truck_number"];
                this.columndo_no = base.Columns["do_no"];
                this.columnrelation_name = base.Columns["relation_name"];
                this.columnrelation_address = base.Columns["relation_address"];
                this.columntransporter_name = base.Columns["transporter_name"];
                this.columndate2 = base.Columns["date2"];
                this.columnsubmit_date = base.Columns["submit_date"];
                this.columnno_ticket_spb = base.Columns["no_ticket_spb"];
                this.columnSO = base.Columns["SO"];
                this.columncontainer_no = base.Columns["container_no"];
                this.columnseal_no = base.Columns["seal_no"];
                this.columncoy_name = base.Columns["coy_name"];
                this.columnbulkpack = base.Columns["bulkpack"];
                this.columnunit = base.Columns["unit"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.HeaderGamaRow NewHeaderGamaRow() => 
                (DataSetTicketSPB.HeaderGamaRow) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSetTicketSPB.HeaderGamaRow(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.HeaderGamaRowChanged != null)
                {
                    this.HeaderGamaRowChanged(this, new DataSetTicketSPB.HeaderGamaRowChangeEvent((DataSetTicketSPB.HeaderGamaRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.HeaderGamaRowChanging != null)
                {
                    this.HeaderGamaRowChanging(this, new DataSetTicketSPB.HeaderGamaRowChangeEvent((DataSetTicketSPB.HeaderGamaRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.HeaderGamaRowDeleted != null)
                {
                    this.HeaderGamaRowDeleted(this, new DataSetTicketSPB.HeaderGamaRowChangeEvent((DataSetTicketSPB.HeaderGamaRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.HeaderGamaRowDeleting != null)
                {
                    this.HeaderGamaRowDeleting(this, new DataSetTicketSPB.HeaderGamaRowChangeEvent((DataSetTicketSPB.HeaderGamaRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void RemoveHeaderGamaRow(DataSetTicketSPB.HeaderGamaRow row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn spb_noColumn =>
                this.columnspb_no;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn truck_numberColumn =>
                this.columntruck_number;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn do_noColumn =>
                this.columndo_no;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn relation_nameColumn =>
                this.columnrelation_name;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn relation_addressColumn =>
                this.columnrelation_address;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn transporter_nameColumn =>
                this.columntransporter_name;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn date2Column =>
                this.columndate2;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn submit_dateColumn =>
                this.columnsubmit_date;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn no_ticket_spbColumn =>
                this.columnno_ticket_spb;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn SOColumn =>
                this.columnSO;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn container_noColumn =>
                this.columncontainer_no;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn seal_noColumn =>
                this.columnseal_no;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn coy_nameColumn =>
                this.columncoy_name;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn bulkpackColumn =>
                this.columnbulkpack;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn unitColumn =>
                this.columnunit;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.HeaderGamaRow this[int index] =>
                (DataSetTicketSPB.HeaderGamaRow) base.Rows[index];
        }

        public class HeaderGamaRow : DataRow
        {
            private DataSetTicketSPB.HeaderGamaDataTable tableHeaderGama;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal HeaderGamaRow(DataRowBuilder rb) : base(rb)
            {
                this.tableHeaderGama = (DataSetTicketSPB.HeaderGamaDataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsbulkpackNull() => 
                base.IsNull(this.tableHeaderGama.bulkpackColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Iscontainer_noNull() => 
                base.IsNull(this.tableHeaderGama.container_noColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Iscoy_nameNull() => 
                base.IsNull(this.tableHeaderGama.coy_nameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isdate2Null() => 
                base.IsNull(this.tableHeaderGama.date2Column);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isdo_noNull() => 
                base.IsNull(this.tableHeaderGama.do_noColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isno_ticket_spbNull() => 
                base.IsNull(this.tableHeaderGama.no_ticket_spbColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isrelation_addressNull() => 
                base.IsNull(this.tableHeaderGama.relation_addressColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isrelation_nameNull() => 
                base.IsNull(this.tableHeaderGama.relation_nameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isseal_noNull() => 
                base.IsNull(this.tableHeaderGama.seal_noColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsSONull() => 
                base.IsNull(this.tableHeaderGama.SOColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isspb_noNull() => 
                base.IsNull(this.tableHeaderGama.spb_noColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Issubmit_dateNull() => 
                base.IsNull(this.tableHeaderGama.submit_dateColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Istransporter_nameNull() => 
                base.IsNull(this.tableHeaderGama.transporter_nameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Istruck_numberNull() => 
                base.IsNull(this.tableHeaderGama.truck_numberColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsunitNull() => 
                base.IsNull(this.tableHeaderGama.unitColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetbulkpackNull()
            {
                base[this.tableHeaderGama.bulkpackColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setcontainer_noNull()
            {
                base[this.tableHeaderGama.container_noColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setcoy_nameNull()
            {
                base[this.tableHeaderGama.coy_nameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setdate2Null()
            {
                base[this.tableHeaderGama.date2Column] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setdo_noNull()
            {
                base[this.tableHeaderGama.do_noColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setno_ticket_spbNull()
            {
                base[this.tableHeaderGama.no_ticket_spbColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setrelation_addressNull()
            {
                base[this.tableHeaderGama.relation_addressColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setrelation_nameNull()
            {
                base[this.tableHeaderGama.relation_nameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setseal_noNull()
            {
                base[this.tableHeaderGama.seal_noColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetSONull()
            {
                base[this.tableHeaderGama.SOColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setspb_noNull()
            {
                base[this.tableHeaderGama.spb_noColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setsubmit_dateNull()
            {
                base[this.tableHeaderGama.submit_dateColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Settransporter_nameNull()
            {
                base[this.tableHeaderGama.transporter_nameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Settruck_numberNull()
            {
                base[this.tableHeaderGama.truck_numberColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetunitNull()
            {
                base[this.tableHeaderGama.unitColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string spb_no
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.spb_noColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'spb_no' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.spb_noColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string truck_number
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.truck_numberColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'truck_number' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.truck_numberColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string do_no
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.do_noColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'do_no' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.do_noColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string relation_name
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.relation_nameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'relation_name' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.relation_nameColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string relation_address
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.relation_addressColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'relation_address' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.relation_addressColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string transporter_name
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.transporter_nameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'transporter_name' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.transporter_nameColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string date2
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.date2Column];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'date2' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.date2Column] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string submit_date
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.submit_dateColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'submit_date' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.submit_dateColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public int no_ticket_spb
            {
                get
                {
                    int num;
                    try
                    {
                        num = (int) base[this.tableHeaderGama.no_ticket_spbColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'no_ticket_spb' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return num;
                }
                set => 
                    base[this.tableHeaderGama.no_ticket_spbColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string SO
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.SOColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'SO' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.SOColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string container_no
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.container_noColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'container_no' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.container_noColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string seal_no
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.seal_noColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'seal_no' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.seal_noColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string coy_name
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.coy_nameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'coy_name' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.coy_nameColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string bulkpack
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.bulkpackColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'bulkpack' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.bulkpackColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string unit
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableHeaderGama.unitColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'unit' in table 'HeaderGama' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableHeaderGama.unitColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class HeaderGamaRowChangeEvent : EventArgs
        {
            private DataSetTicketSPB.HeaderGamaRow eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public HeaderGamaRowChangeEvent(DataSetTicketSPB.HeaderGamaRow row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.HeaderGamaRow Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void HeaderGamaRowChangeEventHandler(object sender, DataSetTicketSPB.HeaderGamaRowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class SettingDataTable : TypedTableBase<DataSetTicketSPB.SettingRow>
        {
            private DataColumn columnusername;
            private DataColumn columncoy_name2;
            private DataColumn columncoy_name;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.SettingRowChangeEventHandler SettingRowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.SettingRowChangeEventHandler SettingRowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.SettingRowChangeEventHandler SettingRowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.SettingRowChangeEventHandler SettingRowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public SettingDataTable()
            {
                base.TableName = "Setting";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal SettingDataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected SettingDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void AddSettingRow(DataSetTicketSPB.SettingRow row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.SettingRow AddSettingRow(string username, string coy_name2, string coy_name)
            {
                DataSetTicketSPB.SettingRow row = (DataSetTicketSPB.SettingRow) base.NewRow();
                row.ItemArray = new object[] { username, coy_name2, coy_name };
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSetTicketSPB.SettingDataTable table = (DataSetTicketSPB.SettingDataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSetTicketSPB.SettingDataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSetTicketSPB.SettingRow);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSetTicketSPB tspb = new DataSetTicketSPB();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = tspb.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "SettingDataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = tspb.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnusername = new DataColumn("username", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnusername);
                this.columncoy_name2 = new DataColumn("coy_name2", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columncoy_name2);
                this.columncoy_name = new DataColumn("coy_name", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columncoy_name);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnusername = base.Columns["username"];
                this.columncoy_name2 = base.Columns["coy_name2"];
                this.columncoy_name = base.Columns["coy_name"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSetTicketSPB.SettingRow(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.SettingRow NewSettingRow() => 
                (DataSetTicketSPB.SettingRow) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.SettingRowChanged != null)
                {
                    this.SettingRowChanged(this, new DataSetTicketSPB.SettingRowChangeEvent((DataSetTicketSPB.SettingRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.SettingRowChanging != null)
                {
                    this.SettingRowChanging(this, new DataSetTicketSPB.SettingRowChangeEvent((DataSetTicketSPB.SettingRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.SettingRowDeleted != null)
                {
                    this.SettingRowDeleted(this, new DataSetTicketSPB.SettingRowChangeEvent((DataSetTicketSPB.SettingRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.SettingRowDeleting != null)
                {
                    this.SettingRowDeleting(this, new DataSetTicketSPB.SettingRowChangeEvent((DataSetTicketSPB.SettingRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void RemoveSettingRow(DataSetTicketSPB.SettingRow row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn usernameColumn =>
                this.columnusername;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn coy_name2Column =>
                this.columncoy_name2;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn coy_nameColumn =>
                this.columncoy_name;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.SettingRow this[int index] =>
                (DataSetTicketSPB.SettingRow) base.Rows[index];
        }

        public class SettingRow : DataRow
        {
            private DataSetTicketSPB.SettingDataTable tableSetting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal SettingRow(DataRowBuilder rb) : base(rb)
            {
                this.tableSetting = (DataSetTicketSPB.SettingDataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Iscoy_name2Null() => 
                base.IsNull(this.tableSetting.coy_name2Column);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Iscoy_nameNull() => 
                base.IsNull(this.tableSetting.coy_nameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsusernameNull() => 
                base.IsNull(this.tableSetting.usernameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setcoy_name2Null()
            {
                base[this.tableSetting.coy_name2Column] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setcoy_nameNull()
            {
                base[this.tableSetting.coy_nameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetusernameNull()
            {
                base[this.tableSetting.usernameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string username
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableSetting.usernameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'username' in table 'Setting' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableSetting.usernameColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string coy_name2
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableSetting.coy_name2Column];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'coy_name2' in table 'Setting' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableSetting.coy_name2Column] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string coy_name
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableSetting.coy_nameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'coy_name' in table 'Setting' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableSetting.coy_nameColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class SettingRowChangeEvent : EventArgs
        {
            private DataSetTicketSPB.SettingRow eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public SettingRowChangeEvent(DataSetTicketSPB.SettingRow row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.SettingRow Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void SettingRowChangeEventHandler(object sender, DataSetTicketSPB.SettingRowChangeEvent e);

        [Serializable, XmlSchemaProvider("GetTypedTableSchema")]
        public class TransactionDataTable : TypedTableBase<DataSetTicketSPB.TransactionRow>
        {
            private DataColumn columnLicense_no;
            private DataColumn columndriver_name;
            private DataColumn columntruck_number;
            private DataColumn columndo_base_uom;
            private DataColumn columndo_base_qty;
            private DataColumn columncomm_name;
            private DataColumn columndo_qty;
            private DataColumn columndo_uom;
            private DataColumn columnPartaiDO;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.TransactionRowChangeEventHandler TransactionRowChanged;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.TransactionRowChangeEventHandler TransactionRowChanging;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.TransactionRowChangeEventHandler TransactionRowDeleted;

            [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public event DataSetTicketSPB.TransactionRowChangeEventHandler TransactionRowDeleting;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public TransactionDataTable()
            {
                base.TableName = "Transaction";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal TransactionDataTable(DataTable table)
            {
                base.TableName = table.TableName;
                if (table.CaseSensitive != table.DataSet.CaseSensitive)
                {
                    base.CaseSensitive = table.CaseSensitive;
                }
                if (table.Locale.ToString() != table.DataSet.Locale.ToString())
                {
                    base.Locale = table.Locale;
                }
                if (table.Namespace != table.DataSet.Namespace)
                {
                    base.Namespace = table.Namespace;
                }
                base.Prefix = table.Prefix;
                base.MinimumCapacity = table.MinimumCapacity;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected TransactionDataTable(SerializationInfo info, StreamingContext context) : base(info, context)
            {
                this.InitVars();
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void AddTransactionRow(DataSetTicketSPB.TransactionRow row)
            {
                base.Rows.Add(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.TransactionRow AddTransactionRow(string License_no, string driver_name, string truck_number, string do_base_uom, string do_base_qty, string comm_name, string do_qty, string do_uom, string PartaiDO)
            {
                DataSetTicketSPB.TransactionRow row = (DataSetTicketSPB.TransactionRow) base.NewRow();
                object[] objArray1 = new object[9];
                objArray1[0] = License_no;
                objArray1[1] = driver_name;
                objArray1[2] = truck_number;
                objArray1[3] = do_base_uom;
                objArray1[4] = do_base_qty;
                objArray1[5] = comm_name;
                objArray1[6] = do_qty;
                objArray1[7] = do_uom;
                objArray1[8] = PartaiDO;
                row.ItemArray = objArray1;
                base.Rows.Add(row);
                return row;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public override DataTable Clone()
            {
                DataSetTicketSPB.TransactionDataTable table = (DataSetTicketSPB.TransactionDataTable) base.Clone();
                table.InitVars();
                return table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataTable CreateInstance() => 
                new DataSetTicketSPB.TransactionDataTable();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override Type GetRowType() => 
                typeof(DataSetTicketSPB.TransactionRow);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public static XmlSchemaComplexType GetTypedTableSchema(XmlSchemaSet xs)
            {
                XmlSchemaComplexType type = new XmlSchemaComplexType();
                XmlSchemaSequence sequence = new XmlSchemaSequence();
                DataSetTicketSPB tspb = new DataSetTicketSPB();
                XmlSchemaAny item = new XmlSchemaAny {
                    Namespace = "http://www.w3.org/2001/XMLSchema",
                    MinOccurs = 0M,
                    MaxOccurs = decimal.MaxValue,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(item);
                XmlSchemaAny any2 = new XmlSchemaAny {
                    Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1",
                    MinOccurs = 1M,
                    ProcessContents = XmlSchemaContentProcessing.Lax
                };
                sequence.Items.Add(any2);
                XmlSchemaAttribute attribute = new XmlSchemaAttribute {
                    Name = "namespace",
                    FixedValue = tspb.Namespace
                };
                type.Attributes.Add(attribute);
                XmlSchemaAttribute attribute2 = new XmlSchemaAttribute {
                    Name = "tableTypeName",
                    FixedValue = "TransactionDataTable"
                };
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                XmlSchema schemaSerializable = tspb.GetSchemaSerializable();
                if (xs.Contains(schemaSerializable.TargetNamespace))
                {
                    MemoryStream stream = new MemoryStream();
                    MemoryStream stream2 = new MemoryStream();
                    try
                    {
                        XmlSchema current = null;
                        schemaSerializable.Write(stream);
                        IEnumerator enumerator = xs.Schemas(schemaSerializable.TargetNamespace).GetEnumerator();
                        while (true)
                        {
                            if (!enumerator.MoveNext())
                            {
                                break;
                            }
                            current = (XmlSchema) enumerator.Current;
                            stream2.SetLength(0L);
                            current.Write(stream2);
                            if (stream.Length == stream2.Length)
                            {
                                stream.Position = 0L;
                                stream2.Position = 0L;
                                while (true)
                                {
                                    if ((stream.Position != stream.Length) && (stream.ReadByte() == stream2.ReadByte()))
                                    {
                                        continue;
                                    }
                                    if (stream.Position != stream.Length)
                                    {
                                        break;
                                    }
                                    return type;
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (stream != null)
                        {
                            stream.Close();
                        }
                        if (stream2 != null)
                        {
                            stream2.Close();
                        }
                    }
                }
                xs.Add(schemaSerializable);
                return type;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            private void InitClass()
            {
                this.columnLicense_no = new DataColumn("License_no", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnLicense_no);
                this.columndriver_name = new DataColumn("driver_name", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columndriver_name);
                this.columntruck_number = new DataColumn("truck_number", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columntruck_number);
                this.columndo_base_uom = new DataColumn("do_base_uom", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columndo_base_uom);
                this.columndo_base_qty = new DataColumn("do_base_qty", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columndo_base_qty);
                this.columncomm_name = new DataColumn("comm_name", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columncomm_name);
                this.columndo_qty = new DataColumn("do_qty", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columndo_qty);
                this.columndo_uom = new DataColumn("do_uom", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columndo_uom);
                this.columnPartaiDO = new DataColumn("PartaiDO", typeof(string), null, MappingType.Element);
                base.Columns.Add(this.columnPartaiDO);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal void InitVars()
            {
                this.columnLicense_no = base.Columns["License_no"];
                this.columndriver_name = base.Columns["driver_name"];
                this.columntruck_number = base.Columns["truck_number"];
                this.columndo_base_uom = base.Columns["do_base_uom"];
                this.columndo_base_qty = base.Columns["do_base_qty"];
                this.columncomm_name = base.Columns["comm_name"];
                this.columndo_qty = base.Columns["do_qty"];
                this.columndo_uom = base.Columns["do_uom"];
                this.columnPartaiDO = base.Columns["PartaiDO"];
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => 
                new DataSetTicketSPB.TransactionRow(builder);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.TransactionRow NewTransactionRow() => 
                (DataSetTicketSPB.TransactionRow) base.NewRow();

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanged(DataRowChangeEventArgs e)
            {
                base.OnRowChanged(e);
                if (this.TransactionRowChanged != null)
                {
                    this.TransactionRowChanged(this, new DataSetTicketSPB.TransactionRowChangeEvent((DataSetTicketSPB.TransactionRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowChanging(DataRowChangeEventArgs e)
            {
                base.OnRowChanging(e);
                if (this.TransactionRowChanging != null)
                {
                    this.TransactionRowChanging(this, new DataSetTicketSPB.TransactionRowChangeEvent((DataSetTicketSPB.TransactionRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleted(DataRowChangeEventArgs e)
            {
                base.OnRowDeleted(e);
                if (this.TransactionRowDeleted != null)
                {
                    this.TransactionRowDeleted(this, new DataSetTicketSPB.TransactionRowChangeEvent((DataSetTicketSPB.TransactionRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            protected override void OnRowDeleting(DataRowChangeEventArgs e)
            {
                base.OnRowDeleting(e);
                if (this.TransactionRowDeleting != null)
                {
                    this.TransactionRowDeleting(this, new DataSetTicketSPB.TransactionRowChangeEvent((DataSetTicketSPB.TransactionRow) e.Row, e.Action));
                }
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void RemoveTransactionRow(DataSetTicketSPB.TransactionRow row)
            {
                base.Rows.Remove(row);
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn License_noColumn =>
                this.columnLicense_no;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn driver_nameColumn =>
                this.columndriver_name;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn truck_numberColumn =>
                this.columntruck_number;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn do_base_uomColumn =>
                this.columndo_base_uom;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn do_base_qtyColumn =>
                this.columndo_base_qty;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn comm_nameColumn =>
                this.columncomm_name;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn do_qtyColumn =>
                this.columndo_qty;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn do_uomColumn =>
                this.columndo_uom;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataColumn PartaiDOColumn =>
                this.columnPartaiDO;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0"), Browsable(false)]
            public int Count =>
                base.Rows.Count;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.TransactionRow this[int index] =>
                (DataSetTicketSPB.TransactionRow) base.Rows[index];
        }

        public class TransactionRow : DataRow
        {
            private DataSetTicketSPB.TransactionDataTable tableTransaction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            internal TransactionRow(DataRowBuilder rb) : base(rb)
            {
                this.tableTransaction = (DataSetTicketSPB.TransactionDataTable) base.Table;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Iscomm_nameNull() => 
                base.IsNull(this.tableTransaction.comm_nameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isdo_base_qtyNull() => 
                base.IsNull(this.tableTransaction.do_base_qtyColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isdo_base_uomNull() => 
                base.IsNull(this.tableTransaction.do_base_uomColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isdo_qtyNull() => 
                base.IsNull(this.tableTransaction.do_qtyColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isdo_uomNull() => 
                base.IsNull(this.tableTransaction.do_uomColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Isdriver_nameNull() => 
                base.IsNull(this.tableTransaction.driver_nameColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsLicense_noNull() => 
                base.IsNull(this.tableTransaction.License_noColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool IsPartaiDONull() => 
                base.IsNull(this.tableTransaction.PartaiDOColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public bool Istruck_numberNull() => 
                base.IsNull(this.tableTransaction.truck_numberColumn);

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setcomm_nameNull()
            {
                base[this.tableTransaction.comm_nameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setdo_base_qtyNull()
            {
                base[this.tableTransaction.do_base_qtyColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setdo_base_uomNull()
            {
                base[this.tableTransaction.do_base_uomColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setdo_qtyNull()
            {
                base[this.tableTransaction.do_qtyColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setdo_uomNull()
            {
                base[this.tableTransaction.do_uomColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Setdriver_nameNull()
            {
                base[this.tableTransaction.driver_nameColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetLicense_noNull()
            {
                base[this.tableTransaction.License_noColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void SetPartaiDONull()
            {
                base[this.tableTransaction.PartaiDOColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public void Settruck_numberNull()
            {
                base[this.tableTransaction.truck_numberColumn] = Convert.DBNull;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string License_no
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableTransaction.License_noColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'License_no' in table 'Transaction' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableTransaction.License_noColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string driver_name
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableTransaction.driver_nameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'driver_name' in table 'Transaction' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableTransaction.driver_nameColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string truck_number
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableTransaction.truck_numberColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'truck_number' in table 'Transaction' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableTransaction.truck_numberColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string do_base_uom
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableTransaction.do_base_uomColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'do_base_uom' in table 'Transaction' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableTransaction.do_base_uomColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string do_base_qty
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableTransaction.do_base_qtyColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'do_base_qty' in table 'Transaction' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableTransaction.do_base_qtyColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string comm_name
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableTransaction.comm_nameColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'comm_name' in table 'Transaction' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableTransaction.comm_nameColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string do_qty
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableTransaction.do_qtyColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'do_qty' in table 'Transaction' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableTransaction.do_qtyColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string do_uom
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableTransaction.do_uomColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'do_uom' in table 'Transaction' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableTransaction.do_uomColumn] = value;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public string PartaiDO
            {
                get
                {
                    string str;
                    try
                    {
                        str = (string) base[this.tableTransaction.PartaiDOColumn];
                    }
                    catch (InvalidCastException exception)
                    {
                        throw new StrongTypingException("The value for column 'PartaiDO' in table 'Transaction' is DBNull.", exception);
                    }
                    return str;
                }
                set => 
                    base[this.tableTransaction.PartaiDOColumn] = value;
            }
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public class TransactionRowChangeEvent : EventArgs
        {
            private DataSetTicketSPB.TransactionRow eventRow;
            private DataRowAction eventAction;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public TransactionRowChangeEvent(DataSetTicketSPB.TransactionRow row, DataRowAction action)
            {
                this.eventRow = row;
                this.eventAction = action;
            }

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataSetTicketSPB.TransactionRow Row =>
                this.eventRow;

            [DebuggerNonUserCode, GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
            public DataRowAction Action =>
                this.eventAction;
        }

        [GeneratedCode("System.Data.Design.TypedDataSetGenerator", "4.0.0.0")]
        public delegate void TransactionRowChangeEventHandler(object sender, DataSetTicketSPB.TransactionRowChangeEvent e);
    }
}

