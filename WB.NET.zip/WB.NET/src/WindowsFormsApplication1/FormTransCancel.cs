﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTransCancel : Form
    {
        public bool Saved;
        private IContainer components = null;
        public Label label1;
        private Button button1;
        private Button button2;
        public TextBox textRefNo;
        public TextBox textReason;
        public Label label2;

        public FormTransCancel()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textReason.Text.Trim().Length <= 0)
            {
                MessageBox.Show(Resource.Mes_335, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                this.Saved = true;
                base.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to exit?", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Saved = false;
                base.Close();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransCancel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.Saved = false;
                base.Close();
            }
            else if (e.KeyChar == '\r')
            {
                this.button1.PerformClick();
            }
        }

        private void FormTransCancel_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.textReason.Focus();
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.textRefNo = new TextBox();
            this.label2 = new Label();
            this.textReason = new TextBox();
            this.button1 = new Button();
            this.button2 = new Button();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Location = new Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x65, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ref/Document No :";
            this.textRefNo.Location = new Point(12, 0x24);
            this.textRefNo.Name = "textRefNo";
            this.textRefNo.ReadOnly = true;
            this.textRefNo.Size = new Size(0xcd, 20);
            this.textRefNo.TabIndex = 1;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(12, 0x4c);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x66, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "* Cancelled reason :";
            this.textReason.Location = new Point(12, 0x5c);
            this.textReason.MaxLength = 250;
            this.textReason.Name = "textReason";
            this.textReason.Size = new Size(0x1db, 20);
            this.textReason.TabIndex = 0;
            this.textReason.KeyPress += new KeyPressEventHandler(this.textReason_KeyPress);
            this.button1.Location = new Point(0x138, 0x80);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 1;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0x19c, 0x80);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 2;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1f3, 0xb0);
            base.ControlBox = false;
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textReason);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textRefNo);
            base.Controls.Add(this.label1);
            base.Name = "FormTransCancel";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Cancel Record";
            base.Load += new EventHandler(this.FormTransCancel_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransCancel_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textReason_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.label1.Text = Resource.Lbl_Ref_No + " :";
            this.label2.Text = Resource.Lbl_Cancelled_Reason + " :";
            this.button1.Text = Resource.Btn_Process;
            this.button2.Text = Resource.Btn_Cancel;
            this.Text = Resource.Title_Cancel_Record;
        }
    }
}

