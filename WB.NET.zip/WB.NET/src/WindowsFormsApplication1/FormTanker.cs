﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTanker : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private WBTable tblTruck = new WBTable();
        private IContainer components = null;
        public ToolStripMenuItem closeToolStripMenuItem;
        private DataGridView dataGridView1;
        public TextBox TextFind;
        private ToolStripMenuItem printToolStripMenuItem;
        public Button buttonFind;
        private ToolStripMenuItem deleteToolStripMenuItem;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        public Panel panel1;
        private ToolStripMenuItem chooseStripMenuItem1;
        private ToolStripMenuItem viewRecordToolStripMenuItem;

        public FormTanker()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Entry("ADD", Resource.Title_Add_Tanker);
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void chooseStripMenuItem1_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseStripMenuItem1.PerformClick();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.chooseStripMenuItem1.PerformClick();
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
            {
                this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                WBTable table = new WBTable();
                table.OpenTable("wb_transaction", "Select Uniq From wb_transaction where " + WBData.CompanyLocation(" and ( Tanker='" + this.ztable.DT.Rows[this.nCurrRow]["Tanker_No"].ToString() + "')"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    table.Close();
                    this.tblTruck.OpenTable("wb_truck", "Select Uniq From wb_truck where " + WBData.CompanyLocation(" and ( Tanker_No='" + this.ztable.DT.Rows[this.nCurrRow]["Tanker_No"].ToString() + "')"), WBData.conn);
                    if (this.tblTruck.DT.Rows.Count <= 0)
                    {
                        string[] textArray3 = new string[9];
                        textArray3[0] = Resource.Lbl_Tanker_No;
                        textArray3[1] = " : ";
                        textArray3[2] = this.ztable.DT.Rows[this.nCurrRow]["Tanker_No"].ToString();
                        textArray3[3] = ", ";
                        textArray3[4] = Resource.Mes_Max_Capacity;
                        textArray3[5] = " : ";
                        textArray3[6] = this.ztable.DT.Rows[this.nCurrRow]["Capacity"].ToString();
                        textArray3[7] = ".\n\n ";
                        textArray3[8] = Resource.Mes_006;
                        if (MessageBox.Show(string.Concat(textArray3), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                        {
                            FormTransCancel cancel = new FormTransCancel {
                                label1 = { Text = Resource.Tanker_002 },
                                textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Tanker_No"].ToString() },
                                Text = Resource.Form_Delete_Reason,
                                label2 = { Text = Resource.Lbl_Delete_Reason }
                            };
                            cancel.textReason.Focus();
                            cancel.ShowDialog();
                            if (cancel.Saved)
                            {
                                this.changeReason = cancel.textReason.Text;
                                cancel.Dispose();
                                this.ztable.ReOpen();
                                this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                                this.ztable.DT.Rows[this.nCurrRow].Delete();
                                this.ztable.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                                Program.updateLogHeader("wb_tanker", this.logKey, logField, logValue);
                                this.ztable.ReOpen();
                                this.ztable.AfterEdit("DELETE");
                            }
                            else
                            {
                                return;
                            }
                        }
                        table.Dispose();
                        this.ztable.UnLock();
                        if (this.dataGridView1.RowCount == 0)
                        {
                            this.viewRecordToolStripMenuItem.Enabled = false;
                            this.editRecordToolStripMenuItem.Enabled = false;
                            this.deleteToolStripMenuItem.Enabled = false;
                            this.printToolStripMenuItem.Enabled = false;
                            this.chooseStripMenuItem1.Enabled = false;
                        }
                    }
                    else
                    {
                        string[] textArray2 = new string[] { Resource.Mes_Error_Delete_Used_Tanker, "\n ( ", this.tblTruck.DT.Rows.Count.ToString(), " ", Resource.Mes_Records, ")" };
                        MessageBox.Show(string.Concat(textArray2), Resource.Mes_Error_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                else
                {
                    string[] textArray1 = new string[] { Resource.Mes_047A, " ", table.DT.Rows.Count.ToString(), " ", Resource.Mes_047B, ")" };
                    MessageBox.Show(string.Concat(textArray1), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    table.Dispose();
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Entry("EDIT", Resource.Title_Edit_Tanker);
            if (this.dataGridView1.RowCount > 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = true;
                this.editRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_CAPACITY", "E");
                this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_CAPACITY", "D");
                this.printToolStripMenuItem.Enabled = true;
                this.chooseStripMenuItem1.Enabled = true;
            }
        }

        private void Entry(string pMode, string Message)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, pMode))
            {
                FormTankerEntry entry = new FormTankerEntry {
                    pMode = pMode,
                    zTable = this.ztable,
                    Text = Message,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                    string[] aField = new string[] { "tanker_No" };
                    string[] aFind = new string[] { entry.textBox1.Text };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                entry.Dispose();
                this.ztable.UnLock();
            }
        }

        private void FormTanker_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTanker_Load(object sender, EventArgs e)
        {
            this.ztable.OpenTable("wb_tanker", "SELECT " + "Coy,Location_Code,Tanker_No, Capacity,Check_Tanker, checktankertol, checktankerKG,Create_By,Create_Date,Change_By,Change_Date,Delete_By,Delete_Date,Deleted,token, completed, uniq" + " FROM wb_tanker", WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Tanker_No"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["Capacity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dataGridView1.Columns["Capacity"].DefaultCellStyle.Format = "N0";
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["Delete_By"].Visible = false;
            this.dataGridView1.Columns["Delete_Date"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["token"].Visible = true;
            this.dataGridView1.Columns["Completed"].Visible = true;
            this.dataGridView1.Columns["deleted"].Visible = false;
            this.dataGridView1.Columns["Tanker_No"].HeaderText = Resource.Tanker_002;
            this.dataGridView1.Columns["Capacity"].HeaderText = Resource.Tanker_003;
            base.KeyPreview = true;
            if (!WBUser.CheckTrustee("MD_CAPACITY", "A"))
            {
                this.addNewRecordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_CAPACITY", "E"))
            {
                this.editRecordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_CAPACITY", "D"))
            {
                this.deleteToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_CAPACITY", "P"))
            {
                this.printToolStripMenuItem.Enabled = false;
            }
            this.chooseStripMenuItem1.Visible = this.pMode != "";
            if (this.dataGridView1.RowCount == 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
                this.printToolStripMenuItem.Enabled = false;
                this.chooseStripMenuItem1.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.TextFind = new TextBox();
            this.printToolStripMenuItem = new ToolStripMenuItem();
            this.buttonFind = new Button();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.chooseStripMenuItem1 = new ToolStripMenuItem();
            this.panel1 = new Panel();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x255, 280);
            this.dataGridView1.TabIndex = 0x13;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.printToolStripMenuItem.Text = "Print";
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseStripMenuItem1, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x255, 0x18);
            this.menuStrip1.TabIndex = 0x15;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.viewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem, this.printToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.chooseStripMenuItem1.Name = "chooseStripMenuItem1";
            this.chooseStripMenuItem1.Size = new Size(0x3b, 20);
            this.chooseStripMenuItem1.Text = "Choose";
            this.chooseStripMenuItem1.Click += new EventHandler(this.chooseStripMenuItem1_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x130);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x255, 0x21);
            this.panel1.TabIndex = 20;
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x255, 0x151);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.Name = "FormTanker";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Tanker List & Capacity";
            base.Load += new EventHandler(this.FormTanker_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTanker_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseStripMenuItem1.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
            this.printToolStripMenuItem.Text = Resource.Menu_016;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.Text = Resource.Title_Tanker;
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormTankerEntry entry = new FormTankerEntry {
                    pMode = "VIEW",
                    zTable = this.ztable,
                    Text = Resource.Title_View_Tanker,
                    nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                this.ztable.UnLock();
                entry.Dispose();
            }
        }
    }
}

