﻿namespace WindowsFormsApplication1
{
    using CrystalDecisions.CrystalReports.Engine;
    using Microsoft.VisualBasic.PowerPacks;
    using SAP.Middleware.Connector;
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Diagnostics;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;

    public class FormTransactionAfrica : Form
    {
        public WBTable tblTrans = new WBTable();
        public DataGridView dgvTrans;
        private WBTable tblTransDeduc = new WBTable();
        private WBTable tblTransDeducPorla = new WBTable();
        private WBTable tblTransBatch = new WBTable();
        private WBTable tblTransContainer = new WBTable();
        private WBTable tblTransCopra = new WBTable();
        private WBTable tblTransDiv = new WBTable();
        private WBTable tblDO = new WBTable();
        private WBTable tblTransDO = new WBTable();
        private WBTable tblTransQC = new WBTable();
        private WBTable tblTruck = new WBTable();
        private WBTable tblComm = new WBTable();
        private WBTable tblCommD = new WBTable();
        private WBTable tblCust = new WBTable();
        private WBTable tblDriver = new WBTable();
        private WBTable tblTransporter = new WBTable();
        private WBTable tblEstate = new WBTable();
        private WBTable tblStorage = new WBTable();
        private WBTable tblGrading = new WBTable();
        private WBTable tblQC = new WBTable();
        private WBTable tblTanker = new WBTable();
        private WBTable tblTransType = new WBTable();
        private WBTable tblDOContainer = new WBTable();
        private WBTable tblLocation = new WBTable();
        private WBTable tblGatepass = new WBTable();
        private WBTable tblSource = new WBTable();
        private WBTable tblMill = new WBTable();
        private WBTable tblDivision = new WBTable();
        private WBTable tblLoadUnload = new WBTable();
        private WBTable tblBag = new WBTable();
        private DataGridView dgvDOCont = new DataGridView();
        private WBTable tbl_warning_trace = new WBTable();
        public bool tambahRecord = false;
        public bool Saved = false;
        public string pMode = "";
        public string WX = "";
        public string sUniq = "";
        public string gatepassNumber = "";
        public int nCurrRow;
        public ReportDocument ticketRpt = new ReportDocument();
        public ReportDocument ticket2Rpt = new ReportDocument();
        public ReportDocument ticketGradingRpt = new ReportDocument();
        public FormRpt fRpt;
        private IRfcTable ISReturn;
        private DataRow transBefore;
        private DataRow transDOBefore;
        private DataRow rowTransType;
        private DataTable tmpTrans;
        private DataTable tmp_transDO = new DataTable();
        private string editTrace = "";
        private string editDoTrace = "";
        private string spMode = "";
        private string mChangeReason = "";
        private string comm_code = "";
        private string oldComm = "";
        private string[] approval = new string[3];
        private string transType;
        private string maxTare;
        private string minTare;
        private string approve;
        private string approve_type;
        private string approveBy1;
        private string approveBy2;
        private string sTransType;
        private string sIO;
        private string ApproveReason;
        private string completed = "Y";
        private bool ChangeDO;
        private bool ChangeDiv;
        private bool ChangeDeduc;
        private bool ChangeDeducPorla;
        private bool ChangeContainer;
        private bool ChangeQC;
        private bool ChangeDoCont;
        private bool CheckControl;
        private bool CheckQuantity;
        private bool needApproval;
        private bool ChangeBatch;
        private bool Copied = false;
        private bool lSTO1DO = false;
        private bool splitRef = false;
        private bool printTicket = false;
        private bool loadCopraForm = false;
        private int nRef;
        private int nKg;
        private double gross;
        private double tare;
        private double netto;
        private EventArgs e;
        private string[] hasil = new string[3];
        private DateTime rptdate;
        private string CommType = "";
        private string use_gunny = "";
        private string is_pack = "";
        private string MaterialType = "";
        private string check_tare_comm = "N";
        private double sGunnyNet = 0.0;
        private double sGunnyMin = 0.0;
        private double sGunnyMax = 0.0;
        private bool SJApproved = false;
        private bool SJAdopted = false;
        private string msgApprove;
        private string SJToken = "";
        private FormTransCopraEntry fCopra;
        private string nonContract = "N";
        private WBIndicator_File wbIndicator = new WBIndicator_File();
        private string indStableWarning = "0";
        private string transIndStableWarning = "0000";
        private string logDate1 = "";
        private string logTime1 = "";
        private string logRef = "";
        private string logReason = "";
        private string logMode = "";
        private string logKeyField = "";
        private IContainer components = null;
        private Label label1;
        private Label labTankerNo;
        private Label label3;
        private TextBox textTruck2;
        private Label labelDriverName;
        private Label labelTankerMax;
        private Label labelTransporterName;
        private Label label4;
        private Label label2;
        private TextBox textDN;
        private TextBox textUnloading;
        private Label label5;
        private TextBox textRemarkTicket;
        private Label label6;
        private TextBox textRemarkReport;
        private Label label7;
        private GroupBox groupOtherParty;
        private TextBox textNetEstate;
        private TextBox textTareEstate;
        private TextBox textGrossEstate;
        private Label label10;
        private Label label9;
        private Label label8;
        private GroupBox groupFactoryWeight;
        private TextBox textNET2;
        private TextBox text4th;
        private TextBox text3rd;
        private Label label14;
        private Label label15;
        private Label label16;
        private TextBox textNET1;
        private TextBox text2nd;
        private TextBox text1st;
        private Label label11;
        private Label label12;
        private Label label13;
        private TextBox textDeducTotal;
        private Label label17;
        private TextBox textNet;
        private Label label18;
        private TextBox textSEAL;
        private Label label19;
        private Button buttonSave;
        public Button buttonSavePrint;
        private Button buttonCancel;
        private Button buttonReset;
        private Button buttonReadIndicator;
        private TextBox textTime4th;
        private TextBox textDate4th;
        private TextBox textTime3rd;
        private TextBox textDate3rd;
        private TextBox textTime2nd;
        public TextBox textRefNo;
        private ComboBox comTransType;
        private Label labelTransType;
        private DateTimePicker dateRegister;
        private Label label26;
        private DateTimePicker dateDelivery;
        private Label label25;
        private Label labelTransTypeName;
        private Button buttonTruck;
        private TextBox textTruck;
        private TextBox textDriverID;
        private Button buttonDriver;
        private Button buttonTransporter;
        private TextBox textTransporter;
        private Button buttonTanker;
        private TextBox textTanker;
        private MaskedTextBox TimeRegister;
        private MaskedTextBox TimeDelivery;
        private TextBox textRef_Date;
        private Label label35;
        private TextBox textReport_Date;
        private Label label37;
        private Label label33;
        private TextBox textCommType;
        private TextBox textVariance;
        private Label label45;
        private TextBox textTrailerNo;
        private Label label46;
        private TextBox textDriverName;
        private TextBox textWBNo;
        private Label labelWBNo;
        private TextBox textDate1st;
        private TextBox textDate2nd;
        private TextBox textTime1st;
        private CheckBox checkEstate;
        private Panel panel4X;
        private Button buttonTarraHistory;
        private Label label21;
        private TextBox textGatepass;
        private Label labelGatepass;
        private TextBox textGPManual;
        private TabPage tabPageBag;
        private TabPage tabPageDL;
        private Button button19;
        private TextBox textNettoBatchLeft;
        private TextBox textGunnyBatchLeft;
        private TextBox textDL;
        private TextBox textBox1;
        private TextBox textSTO;
        private Label label51;
        private Label label53;
        private Label label52;
        private Button buttonAdopt;
        private Label label56;
        private Label label55;
        private Label label54;
        private GroupBox groupBox2;
        private Label label60;
        private Label label59;
        private TextBox textBox3;
        private TextBox textBox2;
        private Label label58;
        private Label label57;
        private Button button20;
        private GroupBox groupBox1;
        private TextBox textNettoBatch;
        private Label label36;
        private Label label48;
        private TextBox textGunnyBatch;
        private Label label50;
        private Button button18;
        private Label label28;
        private DataGridView dgvBatch;
        private ShapeContainer shapeContainer4;
        private RectangleShape rectangleShape3;
        private TabPage tabPageCopra;
        private Button buttonEntryCopra;
        private Label label24;
        private TextBox textTotalCopra;
        private Label label27;
        private TabPage tabPagePorla;
        private Label label22;
        private Button buttonDeletePorla;
        private Button buttonEditPorla;
        private DataGridView dgvDeducPorla;
        private Button buttonAddPorla;
        private ShapeContainer shapeContainer3;
        private RectangleShape rectangleShape2;
        private TabPage tabPageCont;
        private DataGridView dgvCont;
        private Panel panel5;
        private Button buttonContDelete;
        private Button buttonContEdit;
        private Button buttonContAdd;
        private TabPage tabPageQC;
        private Label label20;
        private RichTextBox textQualityInfo;
        private TextBox textTankQC;
        private TextBox textQControl;
        private DataGridView dgvQC_All;
        private Label label44;
        private Label label43;
        private ComboBox combodgvDO;
        private Label label42;
        private DataGridView dgvQC;
        private TabPage tabPageDivision;
        private DataGridView dgvDivBlock;
        private Panel panel3;
        private Button button15;
        private Button button16;
        private Button button17;
        private TabPage tabPageDeduc;
        private Label labelUnit;
        private TextBox textUnitNameWeight;
        private TextBox textUnitName;
        private Label label34;
        private GroupBox groupBox4;
        private TextBox textBunchTotal;
        private TextBox textBunchDeduc;
        private Label label29;
        private Label label30;
        private TextBox textAvg;
        private Label label31;
        private Button buttonDeleteDeduc;
        private Button buttonEditDeduc;
        private DataGridView dgvDeduc;
        private Button buttonAddDeduc;
        private ShapeContainer shapeContainer2;
        private RectangleShape rectangleShape1;
        private TabPage tabPageInfo;
        private Panel panelInfo;
        private Label labelSourceName;
        private Button buttonSource;
        private TextBox textSource;
        private Label label62;
        private Button buttonLoadUnload;
        private Label label63;
        private TextBox textBoxLoadUnload;
        private Label labelLoadUnloadName;
        private Button buttonStorage;
        private TextBox textStorage;
        private TextBox textEstate;
        private TextBox textCommodity;
        private TextBox textCust;
        private Label labelStorageName;
        private Label labelStorage;
        private Button buttonEstate;
        private Label labelEstateName;
        private Panel panel4;
        private TextBox textISCC2;
        private GroupBox groupBox3;
        private Label label39;
        private TextBox textGHG;
        private RadioButton radioGHG2;
        private RadioButton radioGHG1;
        private TextBox textISCC;
        private Label label38;
        private CheckBox checkISCC;
        private Label labelCustName;
        private Label label40;
        private Button buttonCust;
        private Label labelComm;
        private Label labelCommName;
        private Label labelRelation;
        private Button buttonComm;
        private TabPage tabPageDO;
        private DataGridView dgvDO;
        private Panel panel1;
        private Button buttonMergeDO;
        public Button buttonDeleteDO;
        private Button buttonEditDO;
        private Button buttonAddDO;
        private TabControl tabControl1;
        private Label label61;
        private Label label64;
        private Label label65;
        private CheckBox checkOverrideBag;
        private TextBox textTotalBagWeight;
        private TextBox textTotalBag;
        private TextBox textBagCode;
        private ShapeContainer shapeContainer1;
        private LineShape lineShape1;
        private Label labelBagDesc;
        private Button buttonBag;
        private Label labelBagWeight;
        private Label label66;
        private Label label67;
        private TextBox textGrade;
        private Label label23;
        private Button buttonSavePrintGrading;
        private Label labelMill;
        private Button buttonMill;
        private TextBox textMill;
        private Label labelMillName;
        private Label labelDivision;
        private Button buttonDivision;
        private TextBox textDivision;
        private Label labelDivisionName;
        private Label label32;
        private TextBox textDocStatusLab;

        public FormTransactionAfrica()
        {
            this.InitializeComponent();
        }

        private void _InitBlankGrading(string comm_code)
        {
            if ((this.tblTransDeduc.DT.Rows.Count <= 0) || this.Copied)
            {
                this.dgvDeduc.Rows.Clear();
                WBTable table = new WBTable();
                table.OpenTable("wb_commodity_grading", "select * from wb_commodity_grading where comm_code = '" + comm_code + "'", WBData.conn);
                this.dgvDeduc = table.ToDGV(this.dgvDeduc);
            }
        }

        private void _InitBlankGradingPorla(string comm_code)
        {
            if ((this.tblTransDeducPorla.DT.Rows.Count <= 0) || this.Copied)
            {
                this.dgvDeducPorla.Rows.Clear();
                WBTable table = new WBTable();
                table.OpenTable("wb_commodity_grading", "select * from wb_commodity_grading where comm_code = '" + comm_code + "'", WBData.conn);
                this.dgvDeducPorla = table.ToDGV(this.dgvDeducPorla);
            }
        }

        private void _InitBlankQC(string pDO_No)
        {
            this.dgvQC.Rows.Clear();
            this.dgvQC_All.Rows.Clear();
            int count = 0;
            this.tblCommD.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail where " + WBData.CompanyLocation(" and Comm_Code='" + this.dgvDO.Rows[0].Cells["Comm_Code"].Value.ToString().Trim() + "'"), WBData.conn);
            foreach (DataRow row in this.tblCommD.DT.Rows)
            {
                count = this.dgvQC_All.Rows.Count;
                this.dgvQC_All.Rows.Add();
                this.dgvQC_All.Rows[count].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvQC_All.Rows[count].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvQC_All.Rows[count].Cells["Ref"].Value = this.textRefNo.Text;
                this.dgvQC_All.Rows[count].Cells["DaRef"].Value = this.textRef_Date.Text;
                if (this.Copied)
                {
                    this.dgvQC_All.Rows[count].Cells["DO_No"].Value = this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString();
                }
                this.dgvQC_All.Rows[count].Cells["QualityControl"].Value = " ";
                this.dgvQC_All.Rows[count].Cells["Tank"].Value = " ";
                this.dgvQC_All.Rows[count].Cells["Estate"].Value = "0";
                this.dgvQC_All.Rows[count].Cells["Factory"].Value = "0";
                this.dgvQC_All.Rows[count].Cells["QCode"].Value = row["QCode"].ToString();
                this.dgvQC_All.Rows[count].Cells["QName"].Value = row["QName"].ToString();
                this.dgvQC_All.Rows[count].Cells["Comm_Code"].Value = this.dgvDO.Rows[0].Cells["Comm_Code"].Value;
                this.dgvQC_All.Rows[count].Cells["Relation_Code"].Value = this.dgvDO.Rows[0].Cells["Relation_Code"].Value;
                this.dgvQC_All.Rows[count].Cells["Estate_Code"].Value = this.dgvDO.Rows[0].Cells["Estate"].Value;
                this.dgvQC_All.Refresh();
            }
            this.dgvQC = this.DGV_Copy(this.dgvQC_All, this.dgvQC, this.dgvDO.Rows[0].Cells["Ref"].Value.ToString());
        }

        private void _InitQC(string pDO_No)
        {
            if (this.dgvDO.Rows.Count > 0)
            {
                if (this.dgvQC_All.Rows.Count == 0)
                {
                    this.tblTransQC.Close();
                    this.tblTransQC.OpenTable("wb_TransQC", "Select * from wb_TransQC where  Ref='" + this.textRefNo.Text.Trim() + "'", WBData.conn);
                    this.dgvQC_All = this.tblTransQC.ToDGV(this.dgvQC_All);
                }
                this.dgvQC = this.DGV_Copy(this.dgvQC_All, this.dgvQC, this.dgvDO.Rows[0].Cells["ref"].Value.ToString());
                int count = this.dgvQC.Rows.Count;
                if (count == 0)
                {
                    this.tblCommD.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail where " + WBData.CompanyLocation(" and Comm_Code='" + this.dgvDO.Rows[0].Cells["Comm_Code"].Value.ToString().Trim() + "'"), WBData.conn);
                    foreach (DataRow row in this.tblCommD.DT.Rows)
                    {
                        count = this.dgvQC_All.Rows.Count;
                        this.dgvQC_All.Rows.Add();
                        this.dgvQC_All.Rows[count].Cells["Coy"].Value = WBData.sCoyCode;
                        this.dgvQC_All.Rows[count].Cells["Location_Code"].Value = WBData.sLocCode;
                        this.dgvQC_All.Rows[count].Cells["Ref"].Value = this.textRefNo.Text;
                        this.dgvQC_All.Rows[count].Cells["DaRef"].Value = this.textRef_Date.Text;
                        this.dgvQC_All.Rows[count].Cells["DO_No"].Value = this.dgvDO.Rows[0].Cells["DO_No"].ToString();
                        this.dgvQC_All.Rows[count].Cells["QualityControl"].Value = " ";
                        this.dgvQC_All.Rows[count].Cells["Tank"].Value = " ";
                        this.dgvQC_All.Rows[count].Cells["QCode"].Value = row["QCode"].ToString();
                        this.dgvQC_All.Rows[count].Cells["QName"].Value = row["QName"].ToString();
                        this.dgvQC_All.Rows[count].Cells["Comm_Code"].Value = this.dgvDO.Rows[0].Cells["Comm_Code"].Value;
                        this.dgvQC_All.Rows[count].Cells["Relation_Code"].Value = this.dgvDO.Rows[0].Cells["Relation_Code"].Value;
                        this.dgvQC_All.Rows[count].Cells["Estate_Code"].Value = this.dgvDO.Rows[0].Cells["Estate"].Value;
                        this.dgvQC_All.Refresh();
                    }
                    this.dgvQC = this.DGV_Copy(this.dgvQC_All, this.dgvQC, this.dgvDO.Rows[0].Cells["Ref"].Value.ToString());
                }
            }
        }

        private void _QC_SaveTankQC()
        {
            for (int i = 0; i < this.dgvQC_All.Rows.Count; i++)
            {
                if ((this.dgvQC_All.Rows[i].Cells["Ref"].Value.ToString() == this.textRefNo.Text) && (this.dgvQC_All.Rows[i].Cells["DO_No"].Value.ToString() == this.combodgvDO.Text))
                {
                    this.dgvQC_All.Rows[i].Cells["QualityControl"].Value = this.textQControl.Text;
                    this.dgvQC_All.Rows[i].Cells["Tank"].Value = this.textTankQC.Text;
                }
                this.ChangeQC = true;
            }
        }

        private void BJR()
        {
            Cursor.Current = Cursors.WaitCursor;
            WBSetting.ReOpen();
            if (((this.textAvg.Text.Trim() == "") || (this.textAvg.Text.Trim() == "0")) || this.textAvg.ReadOnly)
            {
                if ((this.textNET2.Text.Trim() == "0") || (this.textBunchTotal.Text.Trim() == "0"))
                {
                    this.textAvg.Text = "0";
                }
                else
                {
                    this.textAvg.Text = (Convert.ToDouble(this.textNET2.Text) / Convert.ToDouble(this.textBunchTotal.Text)).ToString();
                    this.textAvg.Text = Program.StrToDouble(this.textAvg.Text, 2).ToString();
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.dgvDeduc.Rows.Count > 0)
            {
                int index = this.dgvDeduc.CurrentRow.Index;
                if (MessageBox.Show(Resource.Mes_006, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.dgvDeduc.Rows.Remove(this.dgvDeduc.Rows[index]);
                    this.ChangeDeduc = true;
                    this.HitNet();
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            FormDriver driver = new FormDriver {
                pMode = "CHOOSE",
                pFind = this.textDriverID.Text
            };
            driver.ShowDialog();
            if (driver.ReturnRow != null)
            {
                this.textDriverID.Text = driver.ReturnRow["License_No"].ToString();
                this.labelDriverName.Text = driver.ReturnRow["Name"].ToString();
                this.textDriverName.Text = driver.ReturnRow["Name"].ToString();
                if (this.textTruck.Text.Trim() == "")
                {
                    this.textTruck.Text = driver.ReturnRow["Truck_Number"].ToString();
                    this.textTruck.Focus();
                }
            }
            driver.Dispose();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransporter.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.labelTransporterName.Text = transporter.ReturnRow["Transporter_Name"].ToString();
                this.textTransporter.Focus();
            }
            transporter.Dispose();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            FormTanker tanker = new FormTanker {
                pMode = "CHOOSE"
            };
            tanker.ShowDialog();
            if (tanker.ReturnRow != null)
            {
                this.textTanker.Text = tanker.ReturnRow["Tanker_No"].ToString();
                this.labelTankerMax.Text = "Max.Tanker = " + $"{tanker.ReturnRow["Capacity"]:0,0}" + " Kg";
                this.textTanker.Focus();
            }
            tanker.Dispose();
        }

        private void button12_Click_1(object sender, EventArgs e)
        {
            if (this.dgvDeducPorla.Rows.Count > 0)
            {
                this.EntryDeductionPorla("EDIT");
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
                this.textCommType.Text = (commodity.ReturnRow["Type"].ToString().Trim() != "") ? commodity.ReturnRow["Type"].ToString().Trim() : "S";
                this.CommType = commodity.ReturnRow["Type"].ToString().Trim();
                this.MaterialType = commodity.ReturnRow["Material_type"].ToString().Trim();
                this.check_tare_comm = commodity.ReturnRow["Check_Tare"].ToString().Trim();
                this.textCommodity.Focus();
            }
            commodity.Dispose();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            this.EntryDeductionPorla("ADD");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (this.dgvDivBlock.Rows.Count > 0)
            {
                int index = this.dgvDivBlock.CurrentRow.Index;
                if (MessageBox.Show(Resource.Mes_006, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.dgvDivBlock.Rows.Remove(this.dgvDivBlock.Rows[index]);
                    this.ChangeDiv = true;
                }
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            this.EntryDivBlock("EDIT");
        }

        private void button17_Click(object sender, EventArgs e)
        {
            this.EntryDivBlock("ADD");
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (((((this.comTransType.Text != "LGK") && ((this.comTransType.Text != "LGM") && (this.comTransType.Text != "RI"))) && (this.comTransType.Text != "RO")) && !this.SJApproved) && ((WBSetting.Field("GM").ToString() == "Y") && (Convert.ToInt16(WBUser.UserLevel) > 1)))
            {
                FormToken token = new FormToken();
                string[] tokenParams = new string[] { this.textTruck.Text.Trim() };
                token.initData(tokenParams, "DELIVERY", "WB_TRANSACTION", "0", "");
                if (this.completed == "N")
                {
                    token.textBoxToken.Text = this.SJToken;
                }
                token.ShowDialog();
                this.completed = token.completed;
                this.SJToken = token.textBoxToken.Text;
                if (!(token.saved && (token.completed == "Y")))
                {
                    return;
                }
                else
                {
                    this.SJApproved = true;
                    token.Dispose();
                }
            }
            if (this.dgvDO.Rows.Count <= 0)
            {
                this.textGunnyBatch.Focus();
                MessageBox.Show(Resource.Mes_303, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.textDL.Text.Trim() == "")
            {
                MessageBox.Show(Resource.Mes_330);
                this.textDL.Focus();
            }
            else
            {
                this.dgvBatch.Rows.Add();
                this.dgvBatch.ReadOnly = false;
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["ref"].Value = this.textRefNo.Text.Trim();
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["SO_No"].Value = this.dgvDO.Rows[0].Cells["DO_No"].Value;
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Do_No"].Value = this.textDL.Text.Trim();
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["STO_No"].Value = this.textSTO.Text;
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Item_No"].Value = "";
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Batch"].Value = "";
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["STO_Batch"].Value = "";
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Adopted"].Value = "N";
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Approved"].Value = "Y";
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (this.dgvBatch.Rows.Count > 0)
            {
                FormSplitBatch batch = new FormSplitBatch();
                if (this.dgvBatch.Rows[0].Cells["STO_No"].ToString().Trim() == "")
                {
                }
                batch.DGVsplitbatch = this.dgvBatch;
                batch.PerBagQty = Convert.ToInt32(this.textBox1.Text);
                batch.ShowDialog();
                this.dgvBatch = batch.DGVsplitbatch;
                batch.Dispose();
                string[] strArray = new string[] { "", "-A", "-B", "-C", "-D", "-E", "-F", "-G", "-H" };
                strArray[9] = "-I";
                int num = 0;
                int index = 0;
                while (true)
                {
                    if (index >= this.dgvBatch.Rows.Count)
                    {
                        this.textNettoBatch.Text = num.ToString();
                        this.textNettoBatch_Leave(this, e);
                        this.text2nd_Leave(this, e);
                        break;
                    }
                    num += Convert.ToInt32(this.dgvBatch.Rows[index].Cells["Netto"].Value);
                    this.dgvBatch.Rows[index].Cells["Ref"].Value = this.textRefNo.Text.Trim() + strArray[index];
                    index++;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.dgvDeduc.Rows.Count > 0)
            {
                this.EntryDeduction("EDIT");
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (!((this.dgvBatch.Rows.Count <= 0) || ReferenceEquals(this.dgvBatch.CurrentRow, this.dgvBatch.Rows[0])))
            {
                if ((this.dgvBatch.CurrentRow.Cells["Num_of_Gunny"].Value == null) || (this.dgvBatch.CurrentRow.Cells["Num_of_Gunny"].Value.ToString() == "0"))
                {
                    this.dgvBatch.Rows.Remove(this.dgvBatch.CurrentRow);
                }
                else if (MessageBox.Show(Resource.Mes_255, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    int num = Convert.ToInt32(this.dgvBatch.Rows[0].Cells["Num_of_Gunny"].Value.ToString());
                    this.dgvBatch.Rows[0].Cells["Num_of_Gunny"].Value = Convert.ToString((int) (num + Convert.ToInt32(this.dgvBatch.CurrentRow.Cells["Num_of_Gunny"].Value.ToString())));
                    num = Convert.ToInt32(this.dgvBatch.Rows[0].Cells["Netto"].Value.ToString());
                    this.dgvBatch.Rows[0].Cells["Netto"].Value = Convert.ToString((int) (num + Convert.ToInt32(this.dgvBatch.CurrentRow.Cells["Netto"].Value.ToString())));
                    this.dgvBatch.Rows.Remove(this.dgvBatch.CurrentRow);
                    this.ChangeBatch = true;
                    if (this.dgvBatch.Rows.Count > 0)
                    {
                        string[] strArray = new string[] { "", "-A", "-B", "-C", "-D", "-E", "-F", "-G", "-H" };
                        strArray[9] = "-I";
                        int num3 = 0;
                        int index = 0;
                        while (true)
                        {
                            if (index >= this.dgvBatch.Rows.Count)
                            {
                                this.textNettoBatch.Text = num3.ToString();
                                this.textNettoBatch_Leave(this, e);
                                this.text2nd_Leave(this, e);
                                break;
                            }
                            num3 += Convert.ToInt32(this.dgvBatch.Rows[index].Cells["Netto"].Value);
                            this.dgvBatch.Rows[index].Cells["Ref"].Value = this.textRefNo.Text.Trim() + strArray[index];
                            index++;
                        }
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.EntryDeduction("ADD");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormEstate estate = new FormEstate {
                pMode = "CHOOSE"
            };
            estate.ShowDialog();
            if (estate.ReturnRow != null)
            {
                this.textEstate.Text = estate.ReturnRow["Estate_Code"].ToString();
                this.labelEstateName.Text = estate.ReturnRow["Estate_Name"].ToString();
                this.textEstate.Focus();
            }
            estate.Dispose();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (((WBSetting.WB_Type == "5") && (WBSetting.Check_Zero == "Y")) && (Convert.ToInt16(WBUser.UserLevel) > 2))
            {
                this.wbIndicator.Init();
                this.wbIndicator.checkStatus();
                if (!this.wbIndicator.check0())
                {
                    MessageBox.Show("Indicator not zero...");
                    return;
                }
            }
            FormReadIndicator indicator = new FormReadIndicator();
            if (WBSetting.bGate == "Y")
            {
                if (((this.pMode == "1ST") || (this.pMode == "3RD")) & (this.WX != ""))
                {
                    Process.Start(WBSetting.gate1Close);
                }
                if (((this.pMode == "2ND") || (this.pMode == "4TH")) & (this.WX != ""))
                {
                    Process.Start(WBSetting.gate1CloseOut);
                }
            }
            indicator.ShowDialog();
            if (indicator.ok)
            {
                this.indStableWarning = indicator.indStableWarning;
                if (this.pMode == "1ST")
                {
                    this.textDate1st.Text = DateTime.Now.ToString("dd/MM/yyyy");
                    this.textTime1st.Text = (DateTime.Now.ToString("HH:mm") == "00:00") ? DateTime.Now.ToString("HH:01:ss") : DateTime.Now.ToString("HH:mm:ss");
                    this.text1st.Text = $"{Convert.ToInt32(indicator.Hasil.Trim()):N0}";
                }
                else if (this.pMode == "2ND")
                {
                    this.textDate2nd.Text = DateTime.Now.ToString("dd/MM/yyyy");
                    this.textTime2nd.Text = (DateTime.Now.ToString("HH:mm") == "00:00") ? DateTime.Now.ToString("HH:01:ss") : DateTime.Now.ToString("HH:mm:ss");
                    this.textReport_Date.Text = this.textDate2nd.Text;
                    this.text2nd.Text = $"{Convert.ToInt32(indicator.Hasil.Trim()):N0}";
                }
                else if (this.pMode == "3RD")
                {
                    this.textDate3rd.Text = DateTime.Now.ToShortDateString();
                    this.textTime3rd.Text = DateTime.Now.ToString("HH:mm:ss");
                    this.text3rd.Text = $"{Convert.ToInt32(indicator.Hasil.Trim()):N0}";
                }
                else
                {
                    this.text4th.Text = $"{Convert.ToInt32(indicator.Hasil.Trim()):N0}";
                    this.textDate4th.Text = DateTime.Now.ToShortDateString();
                    this.textReport_Date.Text = this.textDate4th.Text;
                    this.textTime4th.Text = DateTime.Now.ToString("HH:mm:ss");
                }
                WBTable table = new WBTable();
                table.OpenTable("wb_setting", "SELECT uniq, usedForWeighing FROM wb_setting WHERE " + WBData.CompanyLocation(" AND Wbcode = '" + WBData.sWBCode + "'"), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    table.DR = table.DT.Rows[0];
                    if (table.DR["usedForWeighing"].ToString() != "Y")
                    {
                        table.DR.BeginEdit();
                        table.DR["usedForWeighing"] = "Y";
                        table.DR.EndEdit();
                        table.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Change flag for PC which is used to weigh" };
                        Program.updateLogHeader("wb_setting", table.DR["uniq"].ToString(), logField, logValue);
                    }
                }
                table.Dispose();
            }
            indicator.Dispose();
            this.HitNet();
            if ((this.pMode == "2ND") && !(Convert.ToDouble(this.textNet.Text) == 0.0))
            {
                if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text2nd.Text))
                {
                    this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text1st.Text;
                    this.dgvDO.Rows[0].Cells["Tarra"].Value = this.text2nd.Text;
                }
                else
                {
                    this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text2nd.Text;
                    this.dgvDO.Rows[0].Cells["Tarra"].Value = this.text1st.Text;
                }
                this.dgvDO.Rows[0].Cells["Netto"].Value = this.textNet.Text;
                this.dgvDO.Refresh();
                this.ChangeDO = true;
            }
            this.hitungBTN();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (this.dgvDeducPorla.Rows.Count > 0)
            {
                int index = this.dgvDeducPorla.CurrentRow.Index;
                if (MessageBox.Show(Resource.Mes_006, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.dgvDeducPorla.Rows.Remove(this.dgvDeducPorla.Rows[index]);
                    this.ChangeDeducPorla = true;
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (this.dgvDO.RowCount > 0)
            {
                this.entryDO("EDIT");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if ((this.dgvDO.Rows.Count > 1) && (this.dgvDO.CurrentRow.Index != 0))
            {
                int index = this.dgvDO.CurrentRow.Index;
                if (MessageBox.Show(Resource.Mes_250, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    if (index > 0)
                    {
                        this.dgvDO.Rows[0].Cells["Estate_qty"].Value = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString()) + Convert.ToDouble(this.dgvDO.Rows[index].Cells["Estate_qty"].Value.ToString());
                        this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString()) + Convert.ToDouble(this.dgvDO.Rows[index].Cells["Netto"].Value.ToString());
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Tarra"].Value.ToString()) + Convert.ToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString());
                    }
                    this.dgvDO.Rows.Remove(this.dgvDO.Rows[index]);
                    this.ChangeDO = true;
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            FormTruck truck = new FormTruck {
                pMode = "CHOOSE",
                pFind = this.textTruck.Text
            };
            truck.ShowDialog();
            if (truck.ReturnRow != null)
            {
                if ((this.pMode == "3RD") || (this.pMode == "4TH"))
                {
                    this.textTruck2.Text = truck.ReturnRow["Truck_Number"].ToString();
                }
                else
                {
                    this.textTruck.Text = truck.ReturnRow["Truck_Number"].ToString();
                    if (this.textTransporter.Text.Trim() == "")
                    {
                        this.textTransporter.Text = truck.ReturnRow["Transporter_Code"].ToString();
                        string[] aField = new string[] { "Transporter_Code" };
                        string[] aFind = new string[] { this.textTransporter.Text };
                        DataRow data = this.tblTransporter.GetData(aField, aFind);
                        if (data != null)
                        {
                            this.labelTransporterName.Text = data["Transporter_Name"].ToString();
                        }
                    }
                }
            }
            truck.Dispose();
        }

        private void buttonAddDO_Click(object sender, EventArgs e)
        {
            if (!(((this.pMode == "1ST") || (this.pMode == "3RD")) ? (this.dgvDO.Rows.Count > 0) : false))
            {
                if ((this.pMode == "2ND") || (this.pMode == "4TH"))
                {
                    if ((this.WX != "2X") || (this.text2nd.Text.Trim() != "0"))
                    {
                        if ((this.WX == "4X") && (this.text4th.Text.Trim() == "0"))
                        {
                            MessageBox.Show(Resource.Mes_314);
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_314);
                        return;
                    }
                }
                this.entryDO("ADD");
                if (this.dgvDO.Rows.Count > 0)
                {
                    if ((this.oldComm == null) || (this.oldComm == ""))
                    {
                        this.oldComm = this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString();
                    }
                    this.comm_code = this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString();
                }
                if (this.nonContract == "N")
                {
                    this.textDN.Enabled = !((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))) ? !((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))) : false;
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_257);
            }
        }

        private void buttonAdopt_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.SJApproved = false;
            this.dgvBatch.ReadOnly = true;
            if (this.textDL.Text.Trim() == "")
            {
                MessageBox.Show(Resource.Mes_265);
                this.textDL.Focus();
            }
            else if (this.dgvDO.Rows.Count == 0)
            {
                MessageBox.Show(Resource.Mes_248);
                this.textDL.Focus();
            }
            else if ((this.textBox1.Text.Trim() == "0") || (this.textBox1.Text.Trim() == ""))
            {
                MessageBox.Show(Resource.Mes_313);
            }
            else
            {
                try
                {
                    WBSetting.OpenSetting();
                    if (WBSAP.connect())
                    {
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_ADOPT_DO");
                        WBSAP.rfcFunction.SetValue("VBELN", this.textDL.Text.Trim());
                        WBSAP.rfcFunction.SetValue("SO_NO", this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString().Trim());
                        WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                        this.ISReturn = WBSAP.rfcFunction.GetTable("I_RECORD");
                        if (this.ISReturn.GetString("POSNR") == "")
                        {
                            MessageBox.Show(Resource.Mes_249, Resource.Title_008, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.SJAdopted = false;
                            this.SJApproved = false;
                        }
                        else
                        {
                            string[] textArray1 = new string[12];
                            textArray1[0] = "Item No   : ";
                            textArray1[1] = this.ISReturn.GetString("POSNR").ToString();
                            textArray1[2] = "\rMaterial  : ";
                            textArray1[3] = this.ISReturn.GetString("MATNR").ToString();
                            textArray1[4] = "\rQTY in KG : ";
                            textArray1[5] = this.ISReturn.GetString("LFIMG_KG").ToString();
                            textArray1[6] = "\rQTY DO    : ";
                            textArray1[7] = this.ISReturn.GetString("LFIMG").ToString();
                            textArray1[8] = "\rUNIT      : ";
                            textArray1[9] = this.ISReturn.GetString("VRKME").ToString();
                            textArray1[10] = "\rCUSTOMER  : ";
                            textArray1[11] = this.ISReturn.GetString("KUNNR").ToString();
                            string str = string.Concat(textArray1);
                            this.dgvBatch.Rows.Clear();
                            int num2 = 0;
                            int num3 = 0;
                            int num = 0;
                            while (true)
                            {
                                if (num >= this.ISReturn.RowCount)
                                {
                                    this.textGunnyBatchLeft.Text = num2.ToString();
                                    this.textNettoBatchLeft.Text = num3.ToString();
                                    this.SJAdopted = true;
                                    this.SJApproved = false;
                                    string[] strArray = new string[] { "", "-A", "-B", "-C", "-D", "-E", "-F", "-G", "-H" };
                                    strArray[9] = "-I";
                                    int num6 = 0;
                                    int index = 0;
                                    while (true)
                                    {
                                        if (index >= this.dgvBatch.Rows.Count)
                                        {
                                            this.textNettoBatch.Text = num6.ToString();
                                            this.textNettoBatch_Leave(this, e);
                                            this.text2nd_Leave(this, e);
                                            break;
                                        }
                                        num6 += Convert.ToInt32(this.dgvBatch.Rows[index].Cells["Netto"].Value);
                                        this.dgvBatch.Rows[index].Cells["Ref"].Value = this.textRefNo.Text.Trim() + strArray[index];
                                        index++;
                                    }
                                    break;
                                }
                                string str2 = this.ISReturn[num].GetString("LFIMG_KG").ToString().Trim().Replace(",", "").Replace(".", "");
                                num3 += Convert.ToInt32(str2);
                                this.textSTO.Text = this.ISReturn[num].GetString("STO_NO").ToString();
                                this.dgvBatch.Rows.Add();
                                int num5 = this.dgvBatch.Rows.Count - 1;
                                this.dgvBatch.Rows[num5].Cells["Coy"].Value = WBData.sCoyCode;
                                this.dgvBatch.Rows[num5].Cells["Location_Code"].Value = WBData.sLocCode;
                                this.dgvBatch.Rows[num5].Cells["ref"].Value = this.textRefNo.Text.Trim();
                                this.dgvBatch.Rows[num5].Cells["Item_No"].Value = this.ISReturn[num].GetString("POSNR").ToString();
                                this.dgvBatch.Rows[num5].Cells["SO_No"].Value = this.dgvDO.Rows[0].Cells["DO_No"].Value;
                                this.dgvBatch.Rows[num5].Cells["Do_No"].Value = this.textDL.Text.Trim();
                                this.dgvBatch.Rows[num5].Cells["Num_Of_Gunny"].Value = Convert.ToString((int) (Convert.ToInt32(str2) / Convert.ToInt32(this.textBox1.Text)));
                                this.dgvBatch.Rows[num5].Cells["Netto"].Value = str2.ToString();
                                this.dgvBatch.Rows[num5].Cells["STO_No"].Value = this.ISReturn[num].GetString("STO_NO").ToString();
                                this.dgvBatch.Rows[num5].Cells["Batch"].Value = this.ISReturn[num].GetString("CHARG").ToString();
                                this.dgvBatch.Rows[num5].Cells["STO_Batch"].Value = "";
                                this.dgvBatch.Rows[num5].Cells["Adopted"].Value = "Y";
                                this.dgvBatch.Rows[num5].Cells["Approved"].Value = "N";
                                num++;
                            }
                        }
                    }
                }
                catch (RfcInvalidParameterException exception)
                {
                    this.SJAdopted = false;
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "E R R O R <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (RfcAbapException exception2)
                {
                    string text = "";
                    if (exception2.Message == "INVALID_DO")
                    {
                        text = "Invalid Delivery Letter Number";
                    }
                    else if (exception2.Message == "INVALID_LINK")
                    {
                        text = "DO and Delivery Letter not Linked";
                    }
                    MessageBox.Show(text, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.SJAdopted = false;
                }
                catch (RfcCommunicationException exception3)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    this.SJAdopted = false;
                }
                catch (RfcBaseException exception4)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception4.ToString(), "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    this.SJAdopted = false;
                }
                catch (Exception exception5)
                {
                    MessageBox.Show(Resource.Title_003 + " " + exception5.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.SJAdopted = false;
                }
            }
        }

        private void buttonBag_Click(object sender, EventArgs e)
        {
            FormBag bag = new FormBag {
                pMode = "CHOOSE",
                pFind = this.textBagCode.Text
            };
            bag.ShowDialog();
            if (bag.ReturnRow != null)
            {
                this.textBagCode.Text = bag.ReturnRow["Bag_Code"].ToString();
                this.labelBagDesc.Text = bag.ReturnRow["Description"].ToString().Trim();
                this.labelBagWeight.Text = $"{Program.StrToDouble(bag.ReturnRow["Weight"].ToString().Trim(), 2):#,##0.###}";
                this.textTotalBagWeight.Text = $"{Program.StrToDouble(this.labelBagWeight.Text, 2) * Program.StrToDouble(this.textTotalBag.Text, 2):#,##0.###}";
            }
            bag.Dispose();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.fCopra.Dispose();
            this.ThisClose();
        }

        private void buttonContAdd_Click(object sender, EventArgs e)
        {
            this.entryCont("ADD");
        }

        private void buttonContDelete_Click(object sender, EventArgs e)
        {
            if (this.dgvCont.Rows.Count > 0)
            {
                int index = this.dgvCont.CurrentRow.Index;
                if (MessageBox.Show(Resource.Mes_006, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.dgvCont.Rows.Remove(this.dgvCont.Rows[index]);
                    this.ChangeContainer = true;
                }
            }
        }

        private void buttonContEdit_Click(object sender, EventArgs e)
        {
            this.entryCont("EDIT");
        }

        private void buttonCust_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textCust.Text = vendor.ReturnRow["Relation_Code"].ToString();
                this.labelCustName.Text = vendor.ReturnRow["Relation_Name"].ToString();
                this.textCust.Focus();
            }
            vendor.Dispose();
        }

        private void buttonDivision_Click(object sender, EventArgs e)
        {
            FormDivision division = new FormDivision {
                pMode = "CHOOSE",
                pFind = this.textDivision.Text.Trim()
            };
            division.ShowDialog();
            if (division.ReturnRow != null)
            {
                this.textDivision.Text = division.ReturnRow["division_code"].ToString();
                this.labelDivisionName.Text = division.ReturnRow["Division_name"].ToString();
                this.tblDivision.ReOpen();
                this.textDivision.Focus();
            }
            division.Dispose();
        }

        private void buttonEntryCopra_Click(object sender, EventArgs e)
        {
            if (Convert.ToDouble(this.text2nd.Text.Trim()) <= 0.0)
            {
                if (this.pMode != "QC")
                {
                    MessageBox.Show(Resource.Mes_293, Resource.Title_002);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_256, Resource.Title_002);
                }
            }
            else if ((this.pMode == "2ND") || ((this.pMode == "EDIT") || (this.spMode == "QTY")))
            {
                this.fCopra.textTarra.Text = this.textNET1.Text;
                this.fCopra.totalTarra = this.textNET1.Text;
                WBTable table = new WBTable();
                table.OpenTable("wb_bag", "select * from wb_bag", WBData.conn);
                this.fCopra.tbl_bag = table;
                this.fCopra.ShowDialog();
                this.textTotalCopra.Text = this.fCopra.textTotalCopra.Text;
                this.HitNet();
            }
        }

        private void buttonLoadUnload_Click(object sender, EventArgs e)
        {
            FormLoadUnload unload = new FormLoadUnload {
                pMode = "CHOOSE",
                pFind = this.textBoxLoadUnload.Text.Trim()
            };
            unload.ShowDialog();
            if (unload.ReturnRow != null)
            {
                this.textBoxLoadUnload.Text = unload.ReturnRow["load_unload"].ToString();
                this.labelLoadUnloadName.Text = unload.ReturnRow["load_desc"].ToString();
                this.tblLoadUnload.ReOpen();
                this.textBoxLoadUnload.Focus();
            }
            unload.Dispose();
        }

        private void buttonMerge_Click(object sender, EventArgs e)
        {
            if (this.dgvDO.Rows.Count > 0)
            {
                int num = 1;
                while (true)
                {
                    if (num >= this.dgvDO.Rows.Count)
                    {
                        this.hitungBTN();
                        this.dgvDO.Rows[0].Cells["Estate_qty"].Value = this.textNetEstate.Text;
                        break;
                    }
                    this.dgvDO.Rows.Remove(this.dgvDO.Rows[num]);
                    num++;
                }
            }
        }

        private void buttonMill_Click(object sender, EventArgs e)
        {
            FormMill mill = new FormMill {
                pMode = "CHOOSE",
                pFind = this.textMill.Text.Trim()
            };
            mill.ShowDialog();
            if (mill.ReturnRow != null)
            {
                this.textMill.Text = mill.ReturnRow["Mill_code"].ToString();
                this.labelMillName.Text = mill.ReturnRow["Mill_name"].ToString();
                this.tblMill.ReOpen();
                this.textMill.Focus();
            }
            mill.Dispose();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            if (this.Simpan())
            {
                this.fCopra.Dispose();
                base.Close();
            }
            Cursor.Current = Cursors.Default;
        }

        private void buttonSavePrint_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.printTicket = true;
            if (this.Simpan())
            {
                this.fCopra.Dispose();
                base.Close();
            }
            Cursor.Current = Cursors.Default;
        }

        private void buttonSavePrintGrading_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            if (this.Simpan())
            {
                FormRpt rpt = new FormRpt();
                string[] paramName = new string[4];
                string[] paramValue = new string[] { this.textRefNo.Text, this.textDriverName.Text, WBData.sCoyName, WBSetting.Field("location_name") };
                paramName[0] = "ref";
                paramName[1] = "driver_name";
                paramName[2] = "coy_name";
                paramName[3] = "location_name";
                try
                {
                    this.ticketGradingRpt.Refresh();
                    this.ticketGradingRpt = Program.setParam2(this.ticketGradingRpt, paramName, paramValue);
                    rpt.setReport(this.ticketGradingRpt);
                    if (WBData.sCheckDirect == "Y")
                    {
                        this.ticketGradingRpt.PrintToPrinter(1, false, 0, 0);
                    }
                    else
                    {
                        rpt.ShowDialog();
                        if (rpt.doPrint)
                        {
                            this.ticketGradingRpt.PrintToPrinter(1, true, 0, 0);
                        }
                    }
                }
                catch (SyntaxErrorException exception)
                {
                    MessageBox.Show(Resource.Mes_316 + " " + exception.Message, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                rpt.Dispose();
            }
            Cursor.Current = Cursors.Default;
        }

        private void buttonSource_Click(object sender, EventArgs e)
        {
            FormSource source = new FormSource {
                pMode = "CHOOSE",
                pFind = this.textSource.Text
            };
            source.ShowDialog();
            if (source.ReturnRow != null)
            {
                this.textSource.Text = source.ReturnRow["Source_code"].ToString();
                this.labelSourceName.Text = source.ReturnRow["Description"].ToString();
                this.tblSource.ReOpen();
                this.textSource.Focus();
            }
            source.Dispose();
        }

        private void buttonStorage_Click(object sender, EventArgs e)
        {
            FormStorage storage = new FormStorage {
                pMode = "CHOOSE"
            };
            storage.ShowDialog();
            if (storage.ReturnRow != null)
            {
                this.textStorage.Text = storage.ReturnRow["Storage_Code"].ToString();
                this.labelStorageName.Text = storage.ReturnRow["Storage_Name"].ToString();
                this.textStorage.Focus();
            }
            storage.Dispose();
        }

        private void buttonTarraHistory_Click(object sender, EventArgs e)
        {
            FormTransactionTarraHistory history = new FormTransactionTarraHistory {
                truck_number = this.textTruck.Text
            };
            history.ShowDialog();
            history.Dispose();
        }

        private bool checkDoubleSPB()
        {
            bool flag = false;
            DateTime pTgl = Convert.ToDateTime(this.textRef_Date.Text);
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "select * from wb_transaction where ref_date = '", Program.DTOC(pTgl), "' and ref <> '", this.textRefNo.Text, "' and Delivery_note = '", this.textDN.Text, "'" };
            table.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
            flag = table.DT.Rows.Count > 0;
            table.Dispose();
            return flag;
        }

        private void checkISCC_CheckedChanged(object sender, EventArgs e)
        {
            this.setISCC();
        }

        private bool checkOverQty()
        {
            bool flag = false;
            string pDoNo = "";
            double num = 0.0;
            string str = "" + "Do_no = '" + this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString() + "'";
            int num2 = 1;
            while (true)
            {
                if (num2 >= this.dgvDO.Rows.Count)
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_tmpDOqty", "Select * from wb_contract where " + WBData.CompanyLocation(" and " + str), WBData.conn);
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= this.dgvDO.Rows.Count)
                        {
                            break;
                        }
                        double num4 = 0.0;
                        pDoNo = this.dgvDO.Rows[num3].Cells["do_no"].Value.ToString();
                        string[] aField = new string[] { "DO_NO" };
                        string[] aFind = new string[] { pDoNo };
                        DataRow data = table.GetData(aField, aFind);
                        if (data["Deductedby"].ToString() == "0")
                        {
                            num4 = Program.StrToDouble(this.dgvDO.Rows[num3].Cells["Netto"].Value.ToString(), 0);
                        }
                        else if (data["Deductedby"].ToString() == "1")
                        {
                            num4 = Program.StrToDouble(this.dgvDO.Rows[num3].Cells["Estate_qty"].Value.ToString(), 0);
                        }
                        if (data["Check_qty"].ToString() == "Y")
                        {
                            num = this.countQtyLeft(pDoNo, data);
                            if (num4 > num)
                            {
                                string[] textArray3 = new string[] { Resource.Mes_290, " ", pDoNo, ": ", (num4 - num).ToString() };
                                MessageBox.Show(string.Concat(textArray3));
                                flag = true;
                                break;
                            }
                        }
                        num3++;
                    }
                    table.Dispose();
                    return flag;
                }
                str = str + " and Do_no = '" + this.dgvDO.Rows[num2].Cells["DO_NO"].Value.ToString() + "'";
                num2++;
            }
        }

        private void checkOverrideBag_CheckedChanged(object sender, EventArgs e)
        {
            this.textTotalBagWeight.ReadOnly = !this.checkOverrideBag.Checked;
        }

        private bool checkQtySplitDO()
        {
            double num = 0.0;
            double num2 = 0.0;
            double num3 = 0.0;
            double num4 = 0.0;
            num2 = Program.StrToDouble(this.textNet.Text, 0);
            num4 = Program.StrToDouble(this.textNetEstate.Text, 0);
            int num5 = 0;
            while (true)
            {
                if (num5 >= this.dgvDO.Rows.Count)
                {
                    bool flag3;
                    if (!(num == num2))
                    {
                        MessageBox.Show(Resource.Mes_327, Resource.Title_006);
                        flag3 = false;
                    }
                    else if (num3 == num4)
                    {
                        flag3 = true;
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_328, Resource.Title_006);
                        flag3 = false;
                    }
                    return flag3;
                }
                num += Program.StrToDouble(this.dgvDO.Rows[num5].Cells["Netto"].Value.ToString(), 0);
                num3 += Program.StrToDouble(this.dgvDO.Rows[num5].Cells["Estate_Qty"].Value.ToString(), 0);
                num5++;
            }
        }

        private bool CheckSPB()
        {
            using (IEnumerator enumerator = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                    string strA = this.textDN.Text.Trim();
                    WBTable table = new WBTable();
                    table.OpenTable("wb_delivery_note", "Select * From wb_delivery_note where Do_No='" + current.Cells["DO_No"].Value.ToString().Trim() + "'", WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num >= table.DT.Rows.Count)
                            {
                                break;
                            }
                            table.DR = table.DT.Rows[num];
                            if ((string.Compare(strA, table.DR["Delivery_Note_From"].ToString()) < 0) || (string.Compare(strA, table.DR["Delivery_Note_to"].ToString()) > 0))
                            {
                                num++;
                                continue;
                            }
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        private bool checkTare()
        {
            bool flag = false;
            string str = "0";
            string str2 = "0";
            string[] aField = new string[] { "Truck_Number" };
            string[] aFind = new string[] { this.textTruck.Text };
            int recNo = this.tblTruck.GetRecNo(aField, aFind);
            if (recNo > -1)
            {
                this.maxTare = this.tblTruck.DT.Rows[recNo]["max_Tare"].ToString();
                this.minTare = this.tblTruck.DT.Rows[recNo]["min_Tare"].ToString();
            }
            if (this.maxTare.Length <= 0)
            {
                this.maxTare = "0";
            }
            if (this.minTare.Length <= 0)
            {
                this.minTare = "0";
            }
            if (this.pMode == "2ND")
            {
                str = (Convert.ToDouble(this.text1st.Text) <= Convert.ToDouble(this.text2nd.Text)) ? this.text2nd.Text : this.text1st.Text;
                str2 = Convert.ToString(Math.Abs((double) (Convert.ToDouble(str) - Convert.ToDouble(this.textNet.Text))));
            }
            if (this.pMode == "1ST")
            {
                str2 = (this.transType != "I") ? this.text1st.Text : this.text2nd.Text;
            }
            flag = (Convert.ToDouble(str2) >= Convert.ToDouble(this.minTare)) & (Convert.ToDouble(str2) <= Convert.ToDouble(this.maxTare));
            if (Convert.ToDouble(str2) == 0.0)
            {
                flag = true;
            }
            if ((this.tblTruck.DT.Rows[recNo]["lastCheck"].ToString().Length <= 0) & !flag)
            {
                flag = true;
            }
            return flag;
        }

        private void combodgvDO_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = '\0';
        }

        private void combodgvDO_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.dgvQC.Rows.Count > 0)
            {
                this.textQControl.Text = this.dgvQC.Rows[0].Cells["QualityControl"].Value.ToString();
            }
        }

        private void comTransType_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = '\0';
        }

        private void comTransType_Leave(object sender, EventArgs e)
        {
            this.TransType();
        }

        private void comTransType_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.TransType();
        }

        private double countQtyLeft(string pDoNo, DataRow dr_DO)
        {
            string str;
            this.tblComm.OpenTable("wb_comm", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + dr_DO["comm_code"].ToString() + "'"), WBData.conn);
            string[] aField = new string[] { "comm_code" };
            string[] aFind = new string[] { dr_DO["comm_code"].ToString() };
            DataRow data = this.tblComm.GetData(aField, aFind);
            if (data == null)
            {
                str = "N";
            }
            else
            {
                str = data["using_gunny"].ToString();
                this.transType = data["Type"].ToString();
            }
            return ((str != "Y") ? Convert.ToDouble($"{Program.checkOS(pDoNo, "", this.textRefNo.Text, "Y"):N0}") : Convert.ToDouble($"{Program.checkOSbyGunny(pDoNo, "", this.textRefNo.Text, "Y"):N0}"));
        }

        private DataGridView DGV_Copy(DataGridView dgv1, DataGridView dgv2, string pRef)
        {
            dgv2.Rows.Clear();
            int count = 0;
            for (int i = 0; i < dgv1.Rows.Count; i++)
            {
                if (dgv1.Rows[i].Cells["Ref"].Value.ToString() == pRef)
                {
                    count = dgv2.Rows.Count;
                    dgv2.Rows.Add();
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= dgv2.ColumnCount)
                        {
                            break;
                        }
                        dgv2[num3, count].Value = dgv1[num3, i].Value;
                        if (dgv2[num3, count].Value == null)
                        {
                            dgv2[num3, count].Value = 0;
                        }
                        num3++;
                    }
                }
            }
            return dgv2;
        }

        private void dgvBatch_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            int index = this.dgvBatch.Columns["Num_Of_Gunny"].Index;
            int num2 = this.dgvBatch.Columns["Netto"].Index;
            if (this.dgvBatch.CurrentCell.ColumnIndex == index)
            {
                this.dgvBatch.CurrentRow.Cells["Netto"].Value = "";
            }
            if (this.dgvBatch.CurrentCell.ColumnIndex == num2)
            {
                this.dgvBatch.CurrentRow.Cells["Num_of_Gunny"].Value = "";
            }
        }

        private void dgvBatch_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.button20.Text = (this.dgvBatch.Rows.Count != 1) ? "Merge" : "Delete";
        }

        private void dgvBatch_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            int num;
            if ((this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Num_of_Gunny"].Value != null) && (this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Num_of_Gunny"].Value.ToString().Trim() != ""))
            {
                try
                {
                    num = Convert.ToInt32(this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Num_of_Gunny"].Value.ToString().Trim()) * Convert.ToInt32(this.textBox1.Text);
                    this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Netto"].Value = num.ToString();
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_233);
                    this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Netto"].Value = "";
                }
            }
            if ((this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Netto"].Value != null) && (this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Netto"].Value.ToString().Trim() != ""))
            {
                try
                {
                    num = Convert.ToInt32(this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Netto"].Value.ToString().Trim()) / Convert.ToInt32(this.textBox1.Text);
                    this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Num_of_Gunny"].Value = num.ToString();
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_233);
                    this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Netto"].Value = "";
                }
            }
            if ((this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Item_No"].Value != null) && (this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Item_No"].Value.ToString().Trim() != ""))
            {
                try
                {
                    num = Convert.ToInt32(this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Item_No"].Value.ToString().Trim());
                    this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Item_No"].Value = num.ToString().PadLeft(5, '0');
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_233);
                    this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Item_No"].Value = "";
                }
            }
            int num2 = 0;
            foreach (DataGridViewRow row in (IEnumerable) this.dgvBatch.Rows)
            {
                try
                {
                    num2 += Convert.ToInt32(row.Cells["Netto"].Value);
                }
                catch
                {
                    num2 = num2;
                }
            }
            this.textNettoBatch.Text = num2.ToString();
            this.textNettoBatch_Leave(this, e);
            this.text2nd_Leave(this, e);
        }

        private void dgvDeduc_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.buttonEditDeduc.PerformClick();
        }

        private void dgvDeducPorla_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.buttonEditPorla.PerformClick();
        }

        private void dgvDO_SelectionChanged(object sender, EventArgs e)
        {
            if ((this.pMode == "SPLIT") || (this.pMode == "DL"))
            {
                this.buttonEditDO.Enabled = this.dgvDO.CurrentRow.Index.ToString() != "0";
            }
        }

        private void dgvQC_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dgvQC_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            string[] aField = new string[] { "Yield_Code" };
            string[] aFind = new string[] { this.dgvQC.Rows[this.dgvQC.CurrentCell.RowIndex].Cells["Qcode"].Value.ToString() };
            DataRow data = this.tblQC.GetData(aField, aFind);
            if (data["Type"].ToString() != "1")
            {
                if (this.dgvQC.CurrentCell.Value.ToString().Length > 10)
                {
                    MessageBox.Show(Resource.Mes_051, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    this.dgvQC_SaveItem(this.dgvQC.CurrentRow, data["Type"].ToString());
                }
            }
            else
            {
                try
                {
                    if (((float) Convert.ToDouble(this.dgvQC.CurrentCell.Value.ToString())) > 99.999)
                    {
                        MessageBox.Show(Resource.Mes_053, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.dgvQC.CurrentCell.Value = "0";
                    }
                    else
                    {
                        this.dgvQC.CurrentCell.Value = Convert.ToString(Program.StrToDouble(this.dgvQC.CurrentCell.Value.ToString(), 3));
                        this.dgvQC_SaveItem(this.dgvQC.CurrentRow, data["Type"].ToString());
                    }
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_053, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.dgvQC.CurrentCell.Value = "0";
                }
            }
        }

        private void dgvQC_DoubleClick(object sender, EventArgs e)
        {
        }

        private void dgvQC_SaveItem(DataGridViewRow pRow, string type)
        {
            for (int i = 0; i < this.dgvQC_All.Rows.Count; i++)
            {
                if (((this.dgvQC_All.Rows[i].Cells["Ref"].Value == pRow.Cells["Ref"].Value) && (this.dgvQC_All.Rows[i].Cells["QCode"].Value == pRow.Cells["QCode"].Value)) && (this.dgvQC_All.Rows[i].Cells["QName"].Value == pRow.Cells["QName"].Value))
                {
                    if (type == "1")
                    {
                        this.dgvQC_All.Rows[i].Cells["Estate"].Value = (pRow.Cells["Estate"].Value != null) ? $"{Program.StrToDouble(pRow.Cells["Estate"].Value.ToString(), 3):N3}" : "0";
                        this.dgvQC_All.Rows[i].Cells["Factory"].Value = (pRow.Cells["Factory"].Value != null) ? $"{Program.StrToDouble(pRow.Cells["Factory"].Value.ToString(), 3):N3}" : "0";
                    }
                    else
                    {
                        this.dgvQC_All.Rows[i].Cells["Estate"].Value = (pRow.Cells["Estate"].Value.ToString() != "") ? pRow.Cells["Estate"].Value.ToString() : "0";
                        this.dgvQC_All.Rows[i].Cells["Factory"].Value = (pRow.Cells["Factory"].Value.ToString() != "") ? pRow.Cells["Factory"].Value.ToString() : "0";
                    }
                }
                this.ChangeQC = true;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool editWarning()
        {
            this.editTrace = "";
            bool flag = false;
            this.tblTrans.ReOpen();
            this.tblTrans.DR = this.tblTrans.DT.Rows[this.nCurrRow];
            this.tblTransDO.ReOpen();
            foreach (DataRow row in this.tbl_warning_trace.DT.Rows)
            {
                if (row["selected"].ToString() == "Y")
                {
                    if (row["name"].ToString().ToUpper().Trim() != "DO")
                    {
                        this.transBefore = this.tmpTrans.Rows[0];
                        if (this.tblTrans.DR[row["FieldName"].ToString()].ToString().ToUpper().Trim() == this.transBefore[row["FieldName"].ToString()].ToString().ToUpper().Trim())
                        {
                            continue;
                        }
                        flag = true;
                        string str = "Blank";
                        if (this.transBefore[row["FieldName"].ToString()].ToString().Trim().Length > 0)
                        {
                            str = this.transBefore[row["FieldName"].ToString()].ToString().Trim();
                        }
                        string[] textArray1 = new string[] { this.editTrace, "<tr class='bd'><td nowrap>", row["Name"].ToString().Trim().PadRight(20, ' '), "</td><td nowrap>", str.PadRight(20, ' '), "</td><td nowrap>", this.tblTrans.DR[row["FieldName"].ToString()].ToString().Trim().PadRight(20, ' '), "</td></tr>" };
                        this.editTrace = string.Concat(textArray1);
                        continue;
                    }
                    if (this.tblTransDO.DT.Rows.Count != this.tmp_transDO.Rows.Count)
                    {
                        flag = true;
                        this.editDoTrace = this.editDoTrace + "DO Before : \n";
                        int num = 0;
                        while (true)
                        {
                            if (num >= this.tmp_transDO.Rows.Count)
                            {
                                this.editDoTrace = this.editDoTrace + "\nDO After : \n";
                                int num2 = 0;
                                while (true)
                                {
                                    if (num2 >= this.tblTransDO.DT.Rows.Count)
                                    {
                                        break;
                                    }
                                    this.tblTransDO.DR = this.tblTransDO.DT.Rows[num2];
                                    string[] textArray3 = new string[] { this.editDoTrace, this.tblTransDO.DR["Do_No"].ToString().PadRight(0x21, ' '), " Qty : ", this.tblTransDO.DR["Netto"].ToString(), "\n" };
                                    this.editDoTrace = string.Concat(textArray3);
                                    num2++;
                                }
                                break;
                            }
                            this.transDOBefore = this.tmp_transDO.Rows[num];
                            string[] textArray2 = new string[] { this.editDoTrace, this.transDOBefore["Do_No"].ToString().PadRight(0x21, ' '), " Qty : ", this.transDOBefore["Netto"].ToString(), "\n" };
                            this.editDoTrace = string.Concat(textArray2);
                            num++;
                        }
                        continue;
                    }
                    bool flag9 = false;
                    int count = this.tmp_transDO.Rows.Count;
                    int num4 = 0;
                    while (true)
                    {
                        if (num4 >= count)
                        {
                            break;
                        }
                        this.tblTransDO.DR = this.tblTransDO.DT.Rows[num4];
                        this.transDOBefore = this.tmp_transDO.Rows[num4];
                        int num5 = 0;
                        while (true)
                        {
                            if (num5 >= this.tblTransDO.DR.ItemArray.Count<object>())
                            {
                                if (flag9)
                                {
                                    this.editDoTrace = this.editDoTrace + "<tr class='bd'>";
                                    string[] textArray4 = new string[] { this.editDoTrace, "<td nowrap>Before</td><td nowrap>", this.transDOBefore["Do_No"].ToString(), "</td><td nowrap>", this.transDOBefore["Netto"].ToString(), "</td>" };
                                    this.editDoTrace = string.Concat(textArray4);
                                    this.editDoTrace = this.editDoTrace + "</tr>";
                                    string[] textArray5 = new string[] { this.editDoTrace, "<td nowrap>After</td><td nowrap>", this.tblTransDO.DR["Do_No"].ToString(), "</td><td nowrap>", this.tblTransDO.DR["Netto"].ToString(), "</td>" };
                                    this.editDoTrace = string.Concat(textArray5);
                                    this.editDoTrace = this.editDoTrace + "</tr>";
                                }
                                num4++;
                                break;
                            }
                            bool flag10 = this.transDOBefore.Table.Columns[num5].ColumnName.ToUpper().Trim() != "UNIQ";
                            if (flag10 && (this.tblTransDO.DR[num5].ToString().Trim().ToUpper() != this.transDOBefore[num5].ToString().Trim().ToUpper()))
                            {
                                flag = true;
                                flag9 = true;
                            }
                            num5++;
                        }
                    }
                }
            }
            return flag;
        }

        private void enableBySetting()
        {
            if (WBSetting.Container == "N")
            {
                this.tabControl1.TabPages.Remove(this.tabPageCont);
            }
            if (WBSetting.Field("Check_Tanker") == "N")
            {
                this.textTanker.Visible = false;
                this.buttonTanker.Visible = false;
                this.labelTankerMax.Visible = false;
                this.labTankerNo.Visible = false;
            }
            if (WBSetting.Field("WB_ref") == "N")
            {
                this.labelWBNo.Visible = false;
                this.textWBNo.Visible = false;
            }
            if (WBSetting.Field("ISCC_Checked") == "Y")
            {
                this.panel4.Visible = true;
                this.checkISCC.Enabled = true;
                this.checkISCC.Checked = false;
            }
            else
            {
                this.panel4.Visible = false;
                this.checkISCC.Enabled = false;
                this.checkISCC.Checked = false;
            }
            if (WBSetting.Container == "Y")
            {
                this.textTruck2.Visible = true;
                this.panel4X.Visible = true;
            }
            else
            {
                this.textTruck2.Visible = false;
                foreach (Control control in this.tabPageCont.Controls)
                {
                    control.Enabled = false;
                }
                this.panel4X.Visible = false;
            }
            if (WBSetting.Trailer == "Y")
            {
                this.textTrailerNo.Visible = true;
                this.label46.Visible = true;
            }
            else
            {
                this.textTrailerNo.Visible = false;
                this.label46.Visible = false;
            }
            this.labelMill.Visible = false;
            this.textMill.Visible = false;
            this.labelMillName.Visible = false;
            this.buttonMill.Visible = false;
            this.buttonDivision.Visible = false;
            this.labelDivisionName.Visible = false;
            this.labelDivision.Visible = false;
            this.textDivision.Visible = false;
            this.labelDivision.Visible = false;
            if (WBSetting.locType == "0")
            {
                this.checkEstate.Visible = true;
                this.labelMill.Visible = true;
                this.textMill.Visible = true;
                this.labelMillName.Visible = true;
                this.buttonMill.Visible = true;
            }
            else
            {
                this.checkEstate.Visible = false;
                this.buttonDivision.Visible = true;
                this.labelDivisionName.Visible = true;
                this.labelDivision.Visible = true;
                this.textDivision.Visible = true;
                this.labelDivisionName.Visible = true;
            }
            this.buttonReset.Visible = WBSetting.WBType() == "2";
        }

        private void entryCont(string pMod)
        {
            int index = -1;
            FormTransContEntry entry = new FormTransContEntry {
                pMode = pMod
            };
            if (pMod == "EDIT")
            {
                index = this.dgvCont.CurrentRow.Index;
                entry.textBox1.Text = this.dgvCont.CurrentRow.Cells["Container"].Value.ToString();
                entry.textBox2.Text = this.dgvCont.CurrentRow.Cells["Seal"].Value.ToString();
            }
            entry.dgvCont = this.dgvCont;
            entry.ShowDialog();
            if (entry.pSave)
            {
                this.ChangeContainer = true;
                if (pMod == "ADD")
                {
                    index = this.dgvCont.Rows.Count;
                    this.dgvCont.Rows.Add();
                }
                this.dgvCont.Rows[index].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvCont.Rows[index].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvCont.Rows[index].Cells["Ref"].Value = this.textRefNo.Text;
                this.dgvCont.Rows[index].Cells["Container"].Value = entry.textBox1.Text.Trim();
                this.dgvCont.Rows[index].Cells["Seal"].Value = entry.textBox2.Text.Trim();
            }
            entry.Dispose();
        }

        private void EntryDeduction(string pmode)
        {
            FormTransDeducEntry entry = new FormTransDeducEntry {
                pMode = pmode,
                textNET2 = this.textNET2.Text.Trim(),
                textBunchDeduc = this.textBunchDeduc.Text
            };
            if (pmode == "ADD")
            {
                entry.Text = "Add Deduction Item";
                entry.oldDeducCode = "";
            }
            else
            {
                entry.Text = "Edit Deduction Item";
                entry.comboDeducBy.Text = this.dgvDeduc.CurrentRow.Cells["Deduc_by"].Value.ToString();
                entry.textDeducCode.Text = this.dgvDeduc.CurrentRow.Cells["Code"].Value.ToString();
                entry.oldDeducCode = this.dgvDeduc.CurrentRow.Cells["Code"].Value.ToString();
                entry.textDeducName.Text = this.dgvDeduc.CurrentRow.Cells["Name"].Value.ToString();
                entry.textFormula.Text = this.dgvDeduc.CurrentRow.Cells["Formula"].Value.ToString();
                entry.textDeducVar.Text = this.dgvDeduc.CurrentRow.Cells["Variable"].Value.ToString();
                entry.textDeducPercent.Text = this.dgvDeduc.CurrentRow.Cells["PDeduc"].Value.ToString();
                entry.textDeducKG.Text = this.dgvDeduc.CurrentRow.Cells["KgDeduc"].Value.ToString();
                entry.textDeducQtyUnit.Text = this.dgvDeduc.CurrentRow.Cells["QtyBunch"].Value.ToString();
                entry.checkDeducReturn.Checked = this.dgvDeduc.CurrentRow.Cells["Retur"].Value.ToString() == "Y";
                entry.checkDeduct.Checked = this.dgvDeduc.CurrentRow.Cells["Deduct"].Value.ToString() != "N";
                entry.textTarget.Text = this.dgvDeduc.CurrentRow.Cells["Target"].Value.ToString();
            }
            entry.labelKgUnit.Text = this.textUnitName.Text.Trim();
            entry.dataGridView1 = this.dgvDeduc;
            entry.tblTransD = this.tblTransDeduc;
            entry.ShowDialog();
            if (entry.saved)
            {
                this.ChangeDeduc = true;
                Cursor.Current = Cursors.WaitCursor;
                int index = this.dgvDeduc.CurrentRow.Index;
                if (pmode == "ADD")
                {
                    index = this.dgvDeduc.Rows.Count;
                    this.dgvDeduc.Rows.Add();
                }
                this.dgvDeduc.Rows[index].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvDeduc.Rows[index].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvDeduc.Rows[index].Cells["Ref"].Value = this.textRefNo.Text;
                this.dgvDeduc.Rows[index].Cells["Type"].Value = this.CommType;
                this.dgvDeduc.Rows[index].Cells["Deduc_by"].Value = entry.comboDeducBy.Text;
                this.dgvDeduc.Rows[index].Cells["Code"].Value = entry.textDeducCode.Text;
                this.dgvDeduc.Rows[index].Cells["Name"].Value = entry.textDeducName.Text;
                this.dgvDeduc.Rows[index].Cells["Formula"].Value = entry.textFormula.Text;
                this.dgvDeduc.Rows[index].Cells["Variable"].Value = entry.textDeducVar.Text;
                this.dgvDeduc.Rows[index].Cells["PDeduc"].Value = Convert.ToDouble(entry.textDeducPercent.Text.Trim());
                this.dgvDeduc.Rows[index].Cells["KgDeduc"].Value = Convert.ToDouble(entry.textDeducKG.Text.Trim());
                this.dgvDeduc.Rows[index].Cells["QtyBunch"].Value = Convert.ToDouble(entry.textDeducQtyUnit.Text.Trim());
                this.dgvDeduc.Rows[index].Cells["Retur"].Value = entry.checkDeducReturn.Checked ? "Y" : " ";
                this.dgvDeduc.Rows[index].Cells["Deduct"].Value = !entry.checkDeduct.Checked ? "N" : "Y";
                this.dgvDeduc.Rows[index].Cells["Target"].Value = entry.textTarget.Text;
                this.dgvDeduc.Refresh();
                this.HitNet();
                if ((this.dgvDO.Rows.Count == 1) && ((this.pMode == "2ND") && !(Convert.ToDouble(this.textNet.Text) == 0.0)))
                {
                    if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text2nd.Text))
                    {
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text1st.Text;
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = this.text2nd.Text;
                    }
                    else
                    {
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text2nd.Text;
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = this.text1st.Text;
                    }
                    this.dgvDO.Rows[0].Cells["Netto"].Value = this.textNet.Text;
                    this.dgvDO.Refresh();
                    this.ChangeDO = true;
                }
                Cursor.Current = Cursors.Default;
            }
            entry.Dispose();
        }

        private void EntryDeductionPorla(string pmode)
        {
            FormTransDeducEntry entry = new FormTransDeducEntry {
                pMode = pmode,
                textNET2 = this.textNET2.Text.Trim(),
                textBunchDeduc = this.textBunchDeduc.Text
            };
            if (pmode == "ADD")
            {
                entry.Text = "Add Deduction Porla Item";
                entry.oldDeducCode = "";
            }
            else
            {
                entry.Text = "Edit Deduction Item";
                entry.comboDeducBy.Text = this.dgvDeducPorla.CurrentRow.Cells["Deduc_by"].Value.ToString();
                entry.textDeducCode.Text = this.dgvDeducPorla.CurrentRow.Cells["Code"].Value.ToString();
                entry.oldDeducCode = this.dgvDeducPorla.CurrentRow.Cells["Code"].Value.ToString();
                entry.textDeducName.Text = this.dgvDeducPorla.CurrentRow.Cells["Name"].Value.ToString();
                entry.textFormula.Text = this.dgvDeducPorla.CurrentRow.Cells["Formula"].Value.ToString();
                entry.textDeducVar.Text = this.dgvDeducPorla.CurrentRow.Cells["Variable"].Value.ToString();
                entry.textDeducPercent.Text = this.dgvDeducPorla.CurrentRow.Cells["PDeduc"].Value.ToString();
                entry.textDeducKG.Text = this.dgvDeducPorla.CurrentRow.Cells["KgDeduc"].Value.ToString();
                entry.textDeducQtyUnit.Text = this.dgvDeducPorla.CurrentRow.Cells["QtyBunch"].Value.ToString();
                entry.checkDeducReturn.Checked = this.dgvDeducPorla.CurrentRow.Cells["Retur"].Value.ToString() == "Y";
                entry.checkDeduct.Checked = this.dgvDeducPorla.CurrentRow.Cells["Deduct"].Value.ToString() != "N";
            }
            entry.labelKgUnit.Text = this.textUnitName.Text.Trim();
            entry.dataGridView1 = this.dgvDeducPorla;
            entry.tblTransD = this.tblTransDeducPorla;
            entry.ShowDialog();
            if (entry.saved)
            {
                this.ChangeDeducPorla = true;
                Cursor.Current = Cursors.WaitCursor;
                int index = this.dgvDeducPorla.CurrentRow.Index;
                if (pmode == "ADD")
                {
                    index = this.dgvDeducPorla.Rows.Count;
                    this.dgvDeducPorla.Rows.Add();
                }
                this.dgvDeducPorla.Rows[index].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvDeducPorla.Rows[index].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvDeducPorla.Rows[index].Cells["Ref"].Value = this.textRefNo.Text;
                this.dgvDeducPorla.Rows[index].Cells["Type"].Value = this.CommType;
                this.dgvDeducPorla.Rows[index].Cells["Deduc_by"].Value = entry.comboDeducBy.Text;
                this.dgvDeducPorla.Rows[index].Cells["Code"].Value = entry.textDeducCode.Text;
                this.dgvDeducPorla.Rows[index].Cells["Name"].Value = entry.textDeducName.Text;
                this.dgvDeducPorla.Rows[index].Cells["Formula"].Value = entry.textFormula.Text;
                this.dgvDeducPorla.Rows[index].Cells["Variable"].Value = entry.textDeducVar.Text;
                this.dgvDeducPorla.Rows[index].Cells["PDeduc"].Value = Convert.ToDouble(entry.textDeducPercent.Text.Trim());
                this.dgvDeducPorla.Rows[index].Cells["KgDeduc"].Value = Convert.ToDouble(entry.textDeducKG.Text.Trim());
                this.dgvDeducPorla.Rows[index].Cells["QtyBunch"].Value = Convert.ToDouble(entry.textDeducQtyUnit.Text.Trim());
                this.dgvDeducPorla.Rows[index].Cells["Retur"].Value = entry.checkDeducReturn.Checked ? "Y" : " ";
                this.dgvDeducPorla.Rows[index].Cells["Deduct"].Value = !entry.checkDeduct.Checked ? "N" : "Y";
                this.dgvDeducPorla.Refresh();
                Cursor.Current = Cursors.Default;
            }
            entry.Dispose();
        }

        private void EntryDivBlock(string pmode)
        {
            int index = -1;
            FormTransDivision division = new FormTransDivision {
                dgvDiv = this.dgvDivBlock,
                jTandan = Convert.ToInt32(this.textBunchTotal.Text),
                textEstate = { Text = this.textEstate.Text },
                refDate = this.textRef_Date.Text,
                maskedAVG = { Text = this.textAvg.Text }
            };
            if (pmode == "ADD")
            {
                division.Text = "Add Division/Block item";
            }
            else
            {
                index = this.dgvDivBlock.CurrentRow.Index;
                division.Text = "Edit Division/Block item";
                division.textEstate.Text = this.dgvDivBlock.CurrentRow.Cells["Estate_Code"].Value.ToString();
                division.textEstateName.Text = this.dgvDivBlock.CurrentRow.Cells["Estate_Name"].Value.ToString();
                division.textDiv.Text = this.dgvDivBlock.CurrentRow.Cells["Division_Code"].Value.ToString();
                division.textDivName.Text = this.dgvDivBlock.CurrentRow.Cells["Division_Name"].Value.ToString();
                division.textBlockCode.Text = this.dgvDivBlock.CurrentRow.Cells["Block_Code"].Value.ToString();
                division.textBlockName.Text = this.dgvDivBlock.CurrentRow.Cells["Block_Name"].Value.ToString();
                division.maskedAVG.Text = this.dgvDivBlock.CurrentRow.Cells["Average"].Value.ToString().PadLeft(5, '0');
                division.textBunch.Text = this.dgvDivBlock.CurrentRow.Cells["Bunch"].Value.ToString();
                division.textWeight.Text = this.dgvDivBlock.CurrentRow.Cells["Weight"].Value.ToString();
                division.textYear.Text = this.dgvDivBlock.CurrentRow.Cells["yearPlanting"].Value.ToString();
            }
            division.ShowDialog();
            if (division.Saved)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.ChangeDiv = true;
                if (pmode == "ADD")
                {
                    index = this.dgvDivBlock.Rows.Count;
                    this.dgvDivBlock.Rows.Add();
                }
                this.dgvDivBlock.Rows[index].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvDivBlock.Rows[index].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvDivBlock.Rows[index].Cells["Ref"].Value = this.textRefNo.Text;
                this.dgvDivBlock.Rows[index].Cells["Estate_Code"].Value = division.textEstate.Text;
                this.dgvDivBlock.Rows[index].Cells["Estate_Name"].Value = division.textEstateName.Text;
                this.dgvDivBlock.Rows[index].Cells["Division_Code"].Value = division.textDiv.Text;
                this.dgvDivBlock.Rows[index].Cells["Division_Name"].Value = division.textDivName.Text;
                this.dgvDivBlock.Rows[index].Cells["Block_Code"].Value = division.textBlockCode.Text;
                this.dgvDivBlock.Rows[index].Cells["Block_Name"].Value = division.textBlockName.Text;
                this.dgvDivBlock.Rows[index].Cells["Average"].Value = division.maskedAVG.Text;
                this.dgvDivBlock.Rows[index].Cells["Bunch"].Value = Convert.ToDouble(division.textBunch.Text);
                this.dgvDivBlock.Rows[index].Cells["Weight"].Value = Convert.ToDouble(division.textWeight.Text);
                this.dgvDivBlock.Rows[index].Cells["YearPlanting"].Value = Convert.ToDouble(division.textYear.Text);
                Cursor.Current = Cursors.Default;
            }
            division.Dispose();
        }

        private void entryDO(string doEntryMode)
        {
            int dgvDOCurrRow;
            DataRow data;
            int count = this.dgvDO.Rows.Count;
            double num2 = Convert.ToDouble(this.textNet.Text);
            double num3 = Convert.ToDouble(this.textNetEstate.Text);
            double num4 = Convert.ToDouble(this.textVariance.Text);
            double num5 = 0.0;
            double num6 = 0.0;
            double num7 = 0.0;
            if (this.dgvDO.Rows.Count == 0)
            {
                num5 = 0.0;
                num6 = 0.0;
                num7 = 0.0;
            }
            else if (this.dgvDO.CurrentRow.Index > 0)
            {
                num5 = Program.StrToDouble(this.dgvDO.CurrentRow.Cells["Netto"].Value.ToString(), 0);
                num7 = Program.StrToDouble(this.dgvDO.CurrentRow.Cells["Bruto"].Value.ToString(), 0);
                num6 = Program.StrToDouble(this.dgvDO.CurrentRow.Cells["Estate_qty"].Value.ToString(), 0);
            }
            FormTransDOEntryAfrica africa = new FormTransDOEntryAfrica {
                Text = doEntryMode + " DO item",
                RefNo = this.textRefNo.Text,
                refDate = this.textRef_Date.Text,
                doEntryMode = doEntryMode,
                totalVariance = num4,
                totalNet = num2,
                totalNetEstate = num3,
                pComm = this.textCommodity.Text,
                WX = this.WX,
                pTransType = this.comTransType.Text,
                tblTransDO = this.tblTransDO,
                tblDOContainer = this.tblDOContainer,
                tblComm = this.tblComm,
                dgvDO = this.dgvDO,
                dgvCont = this.dgvCont,
                dgvDoCont = this.dgvDOCont,
                nonContract = this.nonContract
            };
            if (doEntryMode == "EDIT")
            {
                africa.dgvDOCurrRow = this.dgvDO.CurrentRow.Index;
                africa.oldComm = this.oldComm;
            }
            africa.ShowDialog();
            if (!africa.saved)
            {
                goto TR_0000;
            }
            else
            {
                Cursor.Current = Cursors.WaitCursor;
                dgvDOCurrRow = africa.dgvDOCurrRow;
                this.nonContract = africa.checkNonContract.Checked ? "Y" : "N";
                this.ChangeDoCont = africa.ChangeDOCont;
                if (this.ChangeDoCont)
                {
                    this.dgvDOCont = africa.dgvDoCont;
                }
                this.lSTO1DO = africa.lSTO1DO;
                this.ChangeDO = true;
                if (doEntryMode != "ADD")
                {
                    this.dgvDO.Rows[0].Cells["Estate_qty"].Value = (Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString()) - Convert.ToDouble(africa.textOthNet.Text)) + num6;
                    this.dgvDO.Rows[0].Cells["Bruto"].Value = (Convert.ToDouble(this.dgvDO.Rows[0].Cells["Tarra"].Value.ToString()) + Convert.ToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString())) + Convert.ToDouble(this.textDeducTotal.Text);
                    this.dgvDO.Rows[0].Cells["Netto"].Value = (Convert.ToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString()) - Convert.ToDouble(africa.textFactNet.Text)) + num5;
                }
                else
                {
                    this.dgvDO.Rows.Add();
                    dgvDOCurrRow = this.dgvDO.Rows.Count - 1;
                    if ((this.dgvDO.Rows.Count <= 0) || (dgvDOCurrRow <= 0))
                    {
                        this.hitungBTN();
                    }
                    else
                    {
                        this.dgvDO.Rows[0].Cells["Estate_qty"].Value = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString()) - Convert.ToDouble(africa.textOthNet.Text);
                        this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString()) - Convert.ToDouble(africa.textFactNet.Text);
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = (Convert.ToDouble(this.dgvDO.Rows[0].Cells["Tarra"].Value.ToString()) + Convert.ToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString())) + Convert.ToDouble(this.textDeducTotal.Text);
                        this.dgvDO.Rows[0].Cells["DeliNo"].Value = this.textDN.Text;
                    }
                }
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Transaction_Code"].Value = this.comTransType.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Ref"].Value = this.textRefNo.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["DeliNo"].Value = africa.txtDeliveryNote.Text;
                if (this.pMode == "1ST")
                {
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Date1"].Value = this.textDate1st.Text;
                }
                else if (this.pMode == "2ND")
                {
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Date2"].Value = this.textDate2nd.Text;
                }
                else if (this.pMode == "3RD")
                {
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Date3"].Value = this.textDate3rd.Text;
                }
                else if (this.pMode == "4TH")
                {
                    this.dgvDO.Rows[dgvDOCurrRow].Cells["Date4"].Value = this.textDate4th.Text;
                }
                this.dgvDO.Rows[dgvDOCurrRow].Cells["DO_No"].Value = africa.textDO.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Comm_Code"].Value = africa.textComm.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Contract"].Value = africa.textCont.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Relation_Code"].Value = africa.textRCode.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Relation_Name"].Value = africa.labelRName.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Netto"].Value = Program.StrToDouble(africa.textFactNet.Text, 2);
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Estate_qty"].Value = Program.StrToDouble(africa.textOthNet.Text, 2);
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Agen"].Value = (africa.labelAgen.Text != "") ? "Y" : "N";
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Estate"].Value = africa.textEstate.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["ConvNett"].Value = Program.StrToDouble(africa.textConvNett.Text, 2);
                this.dgvDO.Rows[dgvDOCurrRow].Cells["ConvUnit"].Value = africa.labelConvUnit.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["PI_No"].Value = africa.textPI_No.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Transporter_Code"].Value = (this.textTransporter.Text.Trim() != "") ? this.textTransporter.Text : africa.textTransporter.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Transaction_Code"].Value = africa.pTransType;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Storage_code"].Value = africa.textStorage.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["STO1X"].Value = africa.text1STO.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["DO1X"].Value = africa.text1DOSTO.Text;
                this.dgvDO.Rows[dgvDOCurrRow].Cells["Tolling"].Value = africa.tolling;
                if (dgvDOCurrRow != 0)
                {
                    if (dgvDOCurrRow > 0)
                    {
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["Bruto"].Value = Convert.ToDouble(this.dgvDO.Rows[dgvDOCurrRow].Cells["Netto"].Value.ToString());
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["Tarra"].Value = "0";
                        this.dgvDO.Rows[dgvDOCurrRow].Cells["Netto"].Value = africa.textFactNet.Text;
                    }
                    goto TR_0005;
                }
                else
                {
                    this.textCommodity.Text = africa.pComm;
                    this.comTransType.Text = africa.pTransType;
                    this.TransType();
                    this.textCust.Text = africa.textRCode.Text;
                    this.textQualityInfo.Text = africa.qualityInfo;
                    if (this.textRemarkTicket.Text.Trim() == "")
                    {
                        this.textRemarkTicket.Text = africa.remark;
                    }
                    this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and  comm_code = '" + africa.textComm.Text.Trim() + "'"), WBData.conn);
                    string[] aField = new string[] { "Comm_Code" };
                    string[] aFind = new string[] { africa.textComm.Text };
                    data = this.tblComm.GetData(aField, aFind);
                    if (data == null)
                    {
                        goto TR_0017;
                    }
                    else
                    {
                        this.labelCommName.Text = data["Comm_Name"].ToString();
                        this.textCommType.Text = data["Type"].ToString();
                        this.CommType = data["Type"].ToString();
                        this.MaterialType = data["Material_Type"].ToString();
                        this.use_gunny = data["Using_Gunny"].ToString();
                        this.is_pack = data["Trade"].ToString();
                        this.check_tare_comm = data["Check_Tare"].ToString();
                        if (this.use_gunny == "Y")
                        {
                            try
                            {
                                this.sGunnyNet = Convert.ToDouble(data["Netto_Gunny"].ToString().Trim());
                                this.sGunnyMin = Convert.ToDouble(data["Gross_Min_Gunny"].ToString().Trim());
                                this.sGunnyMax = Convert.ToDouble(data["Gross_Max_Gunny"].ToString().Trim());
                            }
                            catch
                            {
                                this.sGunnyNet = 0.0;
                                this.sGunnyMax = 0.0;
                                this.sGunnyMin = 0.0;
                            }
                        }
                    }
                }
            }
            try
            {
                if ((data["Unit"].ToString().Trim() != "") & (data["Unit"].ToString().Substring(0, 2).ToUpper() != "KG"))
                {
                    this.textUnitName.Text = data["Unit"].ToString().Trim();
                    this.textBox8_TextChanged(this, this.e);
                }
            }
            catch
            {
            }
            goto TR_0017;
        TR_0000:
            africa.Dispose();
            Cursor.Current = Cursors.Default;
            return;
        TR_0005:
            if (doEntryMode == "2ND")
            {
                if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    string[] textArray5 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(false) };
                    this.textDN.Text = string.Concat(textArray5);
                }
                else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    string[] textArray6 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(false) };
                    this.textDN.Text = string.Concat(textArray6);
                }
            }
            goto TR_0000;
        TR_0017:
            if (this.textTransporter.Text.Trim() == "")
            {
                this.textTransporter.Text = africa.textTransporter.Text;
            }
            if (this.textTransporter.Text.Trim() != "")
            {
                string[] aField = new string[] { "Transporter_Code" };
                string[] aFind = new string[] { this.textTransporter.Text };
                DataRow data = this.tblTransporter.GetData(aField, aFind);
                this.labelTransporterName.Text = (data == null) ? "" : data["Transporter_Name"].ToString();
            }
            this.tabPageShow(this.CommType, this.MaterialType);
            if ((this.CommType == "G") && (africa.dIncoterm == "1"))
            {
                this.dgvBatch.Columns["Ref"].Visible = false;
            }
            if (africa.changeComm || ((doEntryMode == "ADD") && (this.dgvDO.Rows.Count == 1)))
            {
                if (this.CommType != "F")
                {
                    this._InitBlankQC(this.dgvDO.Rows[dgvDOCurrRow].Cells["DO_NO"].Value.ToString());
                }
                else
                {
                    this._InitBlankGrading(this.textCommodity.Text);
                    this._InitBlankGradingPorla(this.textCommodity.Text);
                }
                if (africa.changeComm)
                {
                    this.oldComm = africa.textComm.Text.Trim();
                }
            }
            this.ChangeQC = true;
            this.ChangeDeduc = true;
            this.ChangeDeducPorla = true;
            if (WBSetting.Field("ISCC_Checked") == "Y")
            {
                this.checkISCC.Checked = africa.ISCC == "Y";
                if (africa.ISCC == "Y")
                {
                    this.setISCC();
                    this.textISCC2.Text = (this.textCommodity.Text.Trim().ToUpper() != "CPO") ? "" : this.SetNoISCC(false);
                }
            }
            goto TR_0005;
        }

        private void FormTransaction_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.fCopra.Close();
                this.ThisClose();
            }
        }

        private void FormTransaction_Load(object sender, EventArgs e)
        {
            this.translate();
            base.KeyPreview = true;
            Cursor.Current = Cursors.WaitCursor;
            WBSetting.OpenSetting();
            this.enableBySetting();
            this.spMode = this.pMode;
            if (Convert.ToInt16(WBSetting.transflow) >= 2)
            {
                this.labelGatepass.Visible = true;
                this.textGatepass.Visible = true;
                this.textGPManual.Visible = true;
                this.textDriverID.Enabled = false;
                this.textDriverID.BackColor = SystemColors.Control;
                this.textTruck.Enabled = false;
                this.textTruck.BackColor = SystemColors.Control;
                this.textTrailerNo.Enabled = false;
                this.textTrailerNo.BackColor = SystemColors.Control;
                this.textDriverName.Enabled = false;
                this.textDriverName.BackColor = SystemColors.Control;
                this.textTransporter.Enabled = false;
                this.textTransporter.BackColor = SystemColors.Control;
                this.buttonTruck.Visible = false;
                this.buttonDriver.Visible = false;
                this.buttonTransporter.Visible = false;
                this.comTransType.Enabled = false;
            }
            else
            {
                this.labelGatepass.Visible = false;
                this.textGatepass.Visible = false;
                this.textGPManual.Visible = false;
                this.textDriverID.Enabled = true;
                this.textDriverID.BackColor = SystemColors.Window;
                this.textTruck.Enabled = true;
                this.textTruck.BackColor = SystemColors.Window;
                this.textDriverName.Enabled = true;
                this.textDriverName.BackColor = SystemColors.Window;
                this.textTransporter.Enabled = true;
                this.textTransporter.BackColor = SystemColors.Window;
                this.buttonTruck.Visible = true;
                this.buttonDriver.Visible = true;
                this.buttonTransporter.Visible = true;
                this.textTrailerNo.Enabled = true;
                this.textTrailerNo.BackColor = SystemColors.Window;
                this.comTransType.Enabled = true;
            }
            this.Copied = this.pMode == "COPY";
            this.pMode = (this.pMode == "COPY") ? "1ST" : this.pMode;
            if (((this.pMode != "1ST") || ((this.pMode == "1ST") & !this.tambahRecord)) & (this.pMode != "MANUAL"))
            {
                this.tblTrans.DR = this.tblTrans.DT.Rows[this.nCurrRow];
                this.textRefNo.Text = this.tblTrans.DR["Ref"].ToString();
                if (Convert.ToInt16(WBSetting.transflow) >= 2)
                {
                    this.textGatepass.Text = this.tblTrans.DR["Gatepass_Number"].ToString();
                }
                if (WBSetting.NonContract == "Y")
                {
                    this.nonContract = this.tblTrans.DR["NonContract"].ToString();
                }
            }
            if (this.Copied)
            {
                this.tblTrans.DR = this.tblTrans.DT.Rows[this.nCurrRow];
                this.textRefNo.Text = this.tblTrans.DR["Ref"].ToString();
            }
            this.InitTable();
            this.loadDatagrid();
            if (this.pMode != "MANUAL")
            {
                this.Text = this.pMode.Trim() + " WEIGHT TRANSACTION ( " + this.WX.Trim() + " )";
            }
            else if ((WBUser.UserLevel == "1") || (WBSetting.Field("GM") != "Y"))
            {
                this.Text = this.pMode.Trim() + " WEIGHT TRANSACTION ( " + this.WX.Trim() + " )";
            }
            else
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_loc", "select coy, location_code, tokenManual, maxEntry, currEntry,uniq from wb_location", WBData.conn);
                string str = Program.shoot(table.DT.Rows[0]["MaxEntry"].ToString(), false);
                string str2 = Program.shoot(table.DT.Rows[0]["CurrEntry"].ToString(), false);
                string[] textArray1 = new string[] { this.pMode.Trim(), " WEIGHT TRANSACTION ( ", this.WX.Trim(), " ) , Manual Entry Left = ", (Convert.ToDouble(str) - Convert.ToDouble(str2)).ToString() };
                this.Text = string.Concat(textArray1);
                table.Dispose();
            }
            this.tabControl1.TabPages.Remove(this.tabPageDeduc);
            this.tabControl1.TabPages.Remove(this.tabPageDivision);
            this.tabControl1.TabPages.Remove(this.tabPageQC);
            this.tabControl1.TabPages.Remove(this.tabPagePorla);
            this.tabControl1.TabPages.Remove(this.tabPageCopra);
            this.tabControl1.TabPages.Remove(this.tabPageDL);
            this.tabControl1.TabPages.Remove(this.tabPageBag);
            this.fCopra = new FormTransCopraEntry();
            this.buttonSavePrint.Enabled = !((this.WX == "2X") & (this.pMode == "2ND")) ? ((this.WX == "4X") & (this.pMode == "4TH")) : true;
            if (this.spMode == "QTY")
            {
                this.pMode = "EDIT";
                foreach (Control control in this.GetOffsprings())
                {
                    if ((control.GetType() != typeof(Label)) || (control.GetType() != typeof(TabControl)))
                    {
                        control.Enabled = false;
                    }
                }
                this.buttonSave.Enabled = true;
                this.buttonCancel.Enabled = true;
                this.groupOtherParty.Enabled = true;
                this.groupFactoryWeight.Enabled = true;
                foreach (Control control2 in this.groupOtherParty.Controls)
                {
                    control2.Enabled = true;
                }
                foreach (Control control3 in this.groupFactoryWeight.Controls)
                {
                    control3.Enabled = true;
                }
                this.tabControl1.Enabled = true;
                foreach (Control control4 in this.tabPageDO.Controls)
                {
                    control4.Enabled = false;
                }
                foreach (Control control5 in this.tabPageInfo.Controls)
                {
                    control5.Enabled = false;
                }
                foreach (Control control6 in this.tabPageCont.Controls)
                {
                    control6.Enabled = false;
                }
                foreach (Control control7 in this.tabPageCont.Controls)
                {
                    control7.Enabled = false;
                }
            }
            this.textRefNo.ReadOnly = true;
            this.textRef_Date.ReadOnly = ((this.pMode != "MANUAL") && (this.spMode != "QTY")) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textRef_Date.BackColor = (this.pMode != "MANUAL") ? Color.LightGray : Color.White;
            this.textReport_Date.ReadOnly = ((this.pMode != "MANUAL") && (this.spMode != "QTY")) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textReport_Date.Enabled = ((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1);
            this.textReport_Date.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (Convert.ToInt32(WBUser.UserLevel) == 1))) ? Color.White : Color.LightGray;
            this.text1st.ReadOnly = (Convert.ToInt32(WBUser.UserLevel) != 1) && ((this.spMode != "QTY") && (this.pMode != "MANUAL"));
            this.text2nd.ReadOnly = (Convert.ToInt32(WBUser.UserLevel) != 1) && ((this.spMode != "QTY") && (this.pMode != "MANUAL"));
            this.text3rd.ReadOnly = ((Convert.ToInt32(WBUser.UserLevel) == 1) || ((this.spMode == "QTY") || (this.pMode == "MANUAL"))) ? (this.WX != "4X") : true;
            this.text4th.ReadOnly = ((Convert.ToInt32(WBUser.UserLevel) == 1) || ((this.spMode == "QTY") || (this.pMode == "MANUAL"))) ? (this.WX != "4X") : true;
            this.textTime1st.ReadOnly = ((this.pMode != "MANUAL") && (this.spMode != "QTY")) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textTime2nd.ReadOnly = ((this.pMode != "MANUAL") && (this.spMode != "QTY")) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textTime3rd.ReadOnly = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X"));
            this.textTime4th.ReadOnly = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X"));
            this.textDate1st.ReadOnly = ((this.pMode != "MANUAL") && (this.spMode != "QTY")) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textDate2nd.ReadOnly = ((this.pMode != "MANUAL") && (this.spMode != "QTY")) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textDate3rd.ReadOnly = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X"));
            this.textDate4th.ReadOnly = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X"));
            this.textTime1st.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (Convert.ToInt32(WBUser.UserLevel) == 1))) ? Color.White : Color.LightGray;
            this.textTime2nd.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (Convert.ToInt32(WBUser.UserLevel) == 1))) ? Color.White : Color.LightGray;
            this.textTime3rd.BackColor = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X")) ? Color.LightGray : Color.White;
            this.textTime4th.BackColor = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X")) ? Color.LightGray : Color.White;
            this.textDate1st.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (Convert.ToInt32(WBUser.UserLevel) == 1))) ? Color.White : Color.LightGray;
            this.textDate2nd.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (Convert.ToInt32(WBUser.UserLevel) == 1))) ? Color.White : Color.LightGray;
            this.textDate3rd.BackColor = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X")) ? Color.LightGray : Color.White;
            this.textDate4th.BackColor = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X")) ? Color.LightGray : Color.White;
            this.textRefNo.ReadOnly = true;
            this.textRef_Date.ReadOnly = ((this.pMode != "MANUAL") && (this.spMode != "QTY")) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textRef_Date.BackColor = (this.pMode != "MANUAL") ? Color.LightGray : Color.White;
            this.textReport_Date.ReadOnly = ((this.pMode != "MANUAL") && (this.spMode != "QTY")) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textReport_Date.Enabled = ((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1);
            this.textReport_Date.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (Convert.ToInt32(WBUser.UserLevel) == 1))) ? Color.White : Color.LightGray;
            this.text1st.ReadOnly = (Convert.ToInt32(WBUser.UserLevel) != 1) && ((this.spMode != "QTY") && (this.pMode != "MANUAL"));
            this.text2nd.ReadOnly = (Convert.ToInt32(WBUser.UserLevel) != 1) && ((this.spMode != "QTY") && (this.pMode != "MANUAL"));
            this.text3rd.ReadOnly = ((Convert.ToInt32(WBUser.UserLevel) == 1) || ((this.spMode == "QTY") || (this.pMode == "MANUAL"))) ? (this.WX != "4X") : true;
            this.text4th.ReadOnly = ((Convert.ToInt32(WBUser.UserLevel) == 1) || ((this.spMode == "QTY") || (this.pMode == "MANUAL"))) ? (this.WX != "4X") : true;
            this.textTime1st.ReadOnly = ((this.pMode != "MANUAL") && (this.spMode != "QTY")) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textTime2nd.ReadOnly = ((this.pMode != "MANUAL") && (this.spMode != "QTY")) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textTime3rd.ReadOnly = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X"));
            this.textTime4th.ReadOnly = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X"));
            this.textDate1st.ReadOnly = ((this.pMode != "MANUAL") && (this.spMode != "QTY")) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textDate2nd.ReadOnly = ((this.pMode != "MANUAL") && (this.spMode != "QTY")) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textDate3rd.ReadOnly = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X"));
            this.textDate4th.ReadOnly = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X"));
            this.textTime1st.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (Convert.ToInt32(WBUser.UserLevel) == 1))) ? Color.White : Color.LightGray;
            this.textTime2nd.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (Convert.ToInt32(WBUser.UserLevel) == 1))) ? Color.White : Color.LightGray;
            this.textTime3rd.BackColor = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X")) ? Color.LightGray : Color.White;
            this.textTime4th.BackColor = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X")) ? Color.LightGray : Color.White;
            this.textDate1st.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (Convert.ToInt32(WBUser.UserLevel) == 1))) ? Color.White : Color.LightGray;
            this.textDate2nd.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (Convert.ToInt32(WBUser.UserLevel) == 1))) ? Color.White : Color.LightGray;
            this.textDate3rd.BackColor = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X")) ? Color.LightGray : Color.White;
            this.textDate4th.BackColor = !((((this.pMode == "MANUAL") || (this.spMode == "QTY")) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X")) ? Color.LightGray : Color.White;
            if (Convert.ToInt16(WBUser.UserLevel) == 1)
            {
                this.textDate1st.Enabled = true;
                this.textTime1st.Enabled = true;
                this.textDate2nd.Enabled = true;
                this.textTime2nd.Enabled = true;
                this.textDate3rd.Enabled = true;
                this.textTime3rd.Enabled = true;
                this.textDate4th.Enabled = true;
                this.textTime4th.Enabled = true;
                this.textReport_Date.Enabled = true;
            }
            this.tblTransType.DT.DefaultView.Sort = "Transaction_Code ASC";
            this.tblTransType.DT = this.tblTransType.DT.DefaultView.ToTable();
            this.comTransType.Items.Clear();
            this.comTransType.Text = "";
            this.labelTransTypeName.Text = "";
            foreach (DataRow row in this.tblTransType.DT.Rows)
            {
                this.comTransType.Items.Add(row["Transaction_Code"].ToString());
            }
            this.labelTransporterName.Text = "";
            this.labelTankerMax.Text = "";
            this.labelStorageName.Text = "";
            this.labelCommName.Text = "";
            this.labelDriverName.Text = "";
            this.labelEstateName.Text = "";
            this.TimeRegister.Text = DateTime.Now.ToShortTimeString();
            this.buttonComm.Enabled = this.dgvDO.Rows.Count <= 0;
            if (this.pMode == "QC")
            {
                this._InitQC(this.dgvDO.Rows[0].Cells["DO_No"].Value.ToString());
                foreach (Control control8 in base.Controls)
                {
                    control8.Enabled = false;
                }
                this.tabControl1.Enabled = true;
                foreach (Control control9 in this.tabPageInfo.Controls)
                {
                    control9.Enabled = false;
                }
                foreach (Control control10 in this.tabPageDO.Controls)
                {
                    control10.Enabled = false;
                }
                foreach (Control control11 in this.tabPageDeduc.Controls)
                {
                    control11.Enabled = false;
                }
                foreach (Control control12 in this.tabPageDivision.Controls)
                {
                    control12.Enabled = false;
                }
                foreach (Control control13 in this.tabPagePorla.Controls)
                {
                    control13.Enabled = false;
                }
                foreach (Control control14 in this.tabPageCopra.Controls)
                {
                    control14.Enabled = false;
                }
                foreach (Control control15 in this.tabPageDL.Controls)
                {
                    control15.Enabled = false;
                }
                this.tabPageQC.Focus();
                this.buttonReadIndicator.Visible = false;
                this.buttonSavePrint.Visible = false;
                this.buttonSave.Enabled = true;
                this.buttonCancel.Enabled = true;
                this.textDN.Enabled = true;
                this.label2.Enabled = true;
            }
            else if (this.pMode == "DL")
            {
                this._InitQC(this.dgvDO.Rows[0].Cells["DO_No"].Value.ToString());
                foreach (Control control16 in base.Controls)
                {
                    control16.Enabled = false;
                }
                this.tabControl1.Enabled = true;
                foreach (Control control17 in this.tabPageInfo.Controls)
                {
                    control17.Enabled = false;
                }
                foreach (Control control18 in this.tabPageDO.Controls)
                {
                    control18.Enabled = false;
                }
                foreach (Control control19 in this.tabPageDeduc.Controls)
                {
                    control19.Enabled = false;
                }
                foreach (Control control20 in this.tabPageDivision.Controls)
                {
                    control20.Enabled = false;
                }
                foreach (Control control21 in this.tabPageQC.Controls)
                {
                    control21.Enabled = false;
                }
                foreach (Control control22 in this.tabPagePorla.Controls)
                {
                    control22.Enabled = false;
                }
                foreach (Control control23 in this.tabPageCopra.Controls)
                {
                    control23.Enabled = false;
                }
                this.tabPageDL.Focus();
                this.buttonReadIndicator.Visible = false;
                this.buttonSavePrint.Visible = false;
                this.buttonSave.Enabled = true;
                this.buttonCancel.Enabled = true;
            }
            else if (this.pMode == "VIEW")
            {
                this.tabControl1.Enabled = true;
                this.buttonSave.Visible = false;
                this.buttonReadIndicator.Visible = false;
                this.buttonSavePrint.Visible = false;
                this.buttonCancel.Enabled = true;
            }
            else if ((this.pMode == "EDIT") || (this.pMode == "CANCEL"))
            {
                this.buttonReadIndicator.Visible = false;
            }
            else if (this.pMode != "SPLIT")
            {
                if (this.WX == "")
                {
                    this.buttonReadIndicator.Visible = false;
                }
            }
            else
            {
                foreach (Control control24 in base.Controls)
                {
                    control24.Enabled = false;
                }
                this.tabControl1.Enabled = true;
                foreach (Control control25 in this.tabPageInfo.Controls)
                {
                    control25.Enabled = false;
                }
                foreach (Control control26 in this.tabPageDO.Controls)
                {
                    control26.Enabled = true;
                }
                foreach (Control control27 in this.tabPageQC.Controls)
                {
                    control27.Enabled = false;
                }
                foreach (Control control28 in this.tabPageDeduc.Controls)
                {
                    control28.Enabled = false;
                }
                foreach (Control control29 in this.tabPageDivision.Controls)
                {
                    control29.Enabled = false;
                }
                foreach (Control control30 in this.tabPagePorla.Controls)
                {
                    control30.Enabled = false;
                }
                foreach (Control control31 in this.tabPageCopra.Controls)
                {
                    control31.Enabled = false;
                }
                foreach (Control control32 in this.tabPageDL.Controls)
                {
                    control32.Enabled = false;
                }
                this.tabPageDO.Focus();
                this.buttonReadIndicator.Visible = false;
                this.buttonSavePrint.Visible = false;
                this.buttonSave.Enabled = true;
                this.buttonCancel.Enabled = true;
            }
            if ((((this.pMode == "EDIT") || ((this.pMode == "QC") || (this.pMode == "DL"))) ? !this.tambahRecord : false) && ((this.tblTrans.DR["Split"].ToString() == "X") || (this.tblTrans.DR["Split"].ToString() == "Y")))
            {
                this.buttonReadIndicator.Visible = false;
                this.buttonReset.Visible = false;
                if (Convert.ToInt16(WBUser.UserLevel) > 1)
                {
                    this.groupOtherParty.Enabled = false;
                    this.groupFactoryWeight.Enabled = false;
                }
            }
            if (!(((this.pMode != "1ST") || ((this.pMode == "1ST") & !this.tambahRecord)) ? (this.pMode != "MANUAL") : false))
            {
                this.ChangeDO = true;
                this.ChangeDiv = true;
                this.ChangeDeduc = true;
                this.ChangeDeducPorla = true;
                this.textDate1st.Text = DateTime.Now.ToString("dd/MM/yyyy");
                this.textTime1st.Text = DateTime.Now.ToString("HH:mm:ss");
                this.textDate2nd.Text = "";
                this.textTime2nd.Text = "";
                this.textDate3rd.Text = "";
                this.textTime3rd.Text = "";
                this.textDate4th.Text = "";
                this.textTime4th.Text = "";
                this.textRef_Date.Text = DateTime.Now.ToString("dd/MM/yyyy");
                this.buttonSavePrint.Enabled = false;
                this.checkISCC.Checked = false;
                this.checkISCC.Enabled = false;
                if (this.pMode != "MANUAL")
                {
                    this.textRefNo.Text = this.SetNoref(false);
                }
                else if (WBSetting.Field("GM") == "Y")
                {
                    this.textRefNo.Text = this.SetNorefManual();
                }
                else if (WBSetting.Field("GM") == "N")
                {
                    this.textRefNo.Text = this.SetNoref(false);
                }
                if ((this.gatepassNumber != "") && (Convert.ToInt16(WBSetting.transflow) >= 2))
                {
                    this.textGatepass.Text = this.gatepassNumber;
                    this.tblGatepass.OpenTable("wb_gatepass", "Select * from wb_Gatepass where " + WBData.CompanyLocation(" and Gatepass_Number = '" + this.textGatepass.Text + "'"), WBData.conn);
                    if (this.tblGatepass.DT.Rows.Count > 0)
                    {
                        this.tblGatepass.DR = this.tblGatepass.DT.Rows[0];
                        this.textGPManual.Text = this.tblGatepass.DR["Gpmanual"].ToString();
                        this.textTruck.Text = this.tblGatepass.DR["truck_number"].ToString();
                        this.textTrailerNo.Text = this.tblGatepass.DR["trailer_number"].ToString();
                        this.textTransporter.Text = this.tblGatepass.DR["transporter_code"].ToString();
                        this.comTransType.Text = this.tblGatepass.DR["transaction_code"].ToString();
                        this.TransType();
                        this.textDriverID.Text = this.tblGatepass.DR["License_no"].ToString();
                        string[] aField = new string[] { "License_no" };
                        string[] aFind = new string[] { this.textDriverID.Text };
                        this.tblDriver.DR = this.tblDriver.GetData(aField, aFind);
                        if (this.tblDriver.DR != null)
                        {
                            this.textDriverName.Text = this.tblDriver.DR["name"].ToString();
                            this.labelDriverName.Text = this.tblDriver.DR["Name"].ToString();
                        }
                    }
                }
            }
            else
            {
                this.ChangeDO = false;
                this.ChangeDiv = false;
                this.ChangeDeduc = false;
                this.ChangeDeducPorla = false;
                this.ChangeQC = false;
                this.ChangeBatch = false;
                this.tblTrans.DR = this.tblTrans.DT.Rows[this.nCurrRow];
                this.textDate1st.Text = (this.tblTrans.DR["Date1"].ToString().Length > 0) ? this.tblTrans.DR["Date1"].ToString().Substring(0, 10) : "";
                this.textTime1st.Text = (this.tblTrans.DR["Time1"].ToString().Length > 0) ? this.tblTrans.DR["time1"].ToString().Substring(0, 8) : "";
                this.textDate2nd.Text = (this.tblTrans.DR["Date2"].ToString().Length > 0) ? this.tblTrans.DR["Date2"].ToString().Substring(0, 10) : "";
                this.textTime2nd.Text = (this.tblTrans.DR["Time2"].ToString().Length > 0) ? this.tblTrans.DR["time2"].ToString().Substring(0, 8) : "";
                this.textDate3rd.Text = (this.tblTrans.DR["Date3"].ToString().Length > 0) ? this.tblTrans.DR["Date3"].ToString().Substring(0, 10) : "";
                this.textTime3rd.Text = (this.tblTrans.DR["Time3"].ToString().Length > 0) ? this.tblTrans.DR["time3"].ToString().Substring(0, 8) : "";
                this.textDate4th.Text = (this.tblTrans.DR["Date4"].ToString().Length > 0) ? this.tblTrans.DR["Date4"].ToString().Substring(0, 10) : "";
                this.textTime4th.Text = (this.tblTrans.DR["Time4"].ToString().Length > 0) ? this.tblTrans.DR["time4"].ToString().Substring(0, 8) : "";
                if (this.tblTrans.DR["Ref_Date"].ToString().Trim() != "")
                {
                    this.textRef_Date.Text = Convert.ToDateTime(this.tblTrans.DR["Ref_Date"].ToString()).ToShortDateString();
                }
                if (this.tblTrans.DR["Report_Date"].ToString().Trim() != "")
                {
                    this.textReport_Date.Text = Convert.ToDateTime(this.tblTrans.DR["Report_Date"].ToString()).ToShortDateString();
                }
                if (this.pMode == "1ST")
                {
                    this.textDate1st.Text = DateTime.Now.ToShortDateString();
                    this.textTime1st.Text = (DateTime.Now.ToString("HH:mm") != "00:00") ? DateTime.Now.ToString("HH:mm:ss") : DateTime.Now.ToString("HH:01:ss");
                }
                else if (this.pMode == "2ND")
                {
                    this.textDate2nd.Text = DateTime.Now.ToShortDateString();
                    this.textTime2nd.Text = (DateTime.Now.ToString("HH:mm") != "00:00") ? DateTime.Now.ToString("HH:mm:ss") : DateTime.Now.ToString("HH:01:ss");
                    if (this.nonContract == "N")
                    {
                        if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                        {
                            string[] textArray2 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(true) };
                            this.textDN.Text = string.Concat(textArray2);
                        }
                        else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                        {
                            string[] textArray3 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(true) };
                            this.textDN.Text = string.Concat(textArray3);
                        }
                    }
                }
                else if (this.pMode == "3RD")
                {
                    this.textTruck.ReadOnly = true;
                    this.textTruck2.ReadOnly = false;
                    this.textDate3rd.Text = DateTime.Now.ToShortDateString();
                    this.textTime3rd.Text = DateTime.Now.ToString("HH:mm:ss");
                }
                else if (this.pMode == "4TH")
                {
                    this.textTruck.ReadOnly = true;
                    this.textTruck2.ReadOnly = false;
                    this.textDate4th.Text = DateTime.Now.ToShortDateString();
                    this.textTime4th.Text = DateTime.Now.ToString("HH:mm:ss");
                }
                else if (this.pMode == "EDIT")
                {
                    this.tbl_warning_trace.OpenTable("wb_warning_trace", "select * from wb_warning_trace where type = 'TRANSACTION'", WBData.conn);
                    this.tmpTrans = this.tblTrans.DT.Clone();
                    this.transBefore = this.tmpTrans.NewRow();
                    this.transBefore.ItemArray = this.tblTrans.DT.Rows[this.nCurrRow].ItemArray;
                    this.tmpTrans.Rows.Add(this.transBefore);
                    this.tmp_transDO = this.tblTransDO.DT.Clone();
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= this.tblTransDO.DT.Rows.Count)
                        {
                            if (this.spMode != "QTY")
                            {
                                this.textRefNo.ReadOnly = this.tblTrans.DR["Manual"].ToString() != "Y";
                                this.textRef_Date.ReadOnly = this.tblTrans.DR["Manual"].ToString() != "Y";
                                this.textReport_Date.ReadOnly = (this.tblTrans.DR["Manual"].ToString() != "Y") && (Convert.ToInt16(WBUser.UserLevel) != 1);
                                this.textRefNo.BackColor = (this.tblTrans.DR["Manual"].ToString() != "Y") ? Color.LightGray : Color.White;
                                this.textRef_Date.BackColor = (this.tblTrans.DR["Manual"].ToString() != "Y") ? Color.LightGray : Color.White;
                                if (WBSetting.Field("GM").ToString() != "Y")
                                {
                                    string str3 = (this.tblTrans.DR["_1ST"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_1ST"]:N0}";
                                    string str4 = (this.tblTrans.DR["_2ND"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_2ND"]:N0}";
                                    string str5 = (this.tblTrans.DR["_3RD"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_3RD"]:N0}";
                                    string str6 = (this.tblTrans.DR["_4TH"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_4TH"]:N0}";
                                    string str7 = this.tblTrans.DR["Report_Date"].ToString();
                                    this.textReport_Date.BackColor = ((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str7 != ""))) ? Color.White : Color.LightGray;
                                    this.textTime1st.ReadOnly = (this.tblTrans.DR["Manual"].ToString() != "Y") && ((Convert.ToInt16(WBUser.UserLevel) != 1) || (str3 == "0"));
                                    this.textTime2nd.ReadOnly = (this.tblTrans.DR["Manual"].ToString() != "Y") && ((Convert.ToInt16(WBUser.UserLevel) != 1) || (str4 == "0"));
                                    this.textTime3rd.ReadOnly = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str5 != "0"))) & (this.WX == "4X"));
                                    this.textTime4th.ReadOnly = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str6 != "0"))) & (this.WX == "4X"));
                                    this.textDate1st.ReadOnly = (this.tblTrans.DR["Manual"].ToString() != "Y") && ((Convert.ToInt16(WBUser.UserLevel) != 1) || (str3 == "0"));
                                    this.textDate2nd.ReadOnly = (this.tblTrans.DR["Manual"].ToString() != "Y") && ((Convert.ToInt16(WBUser.UserLevel) != 1) || (str4 == "0"));
                                    this.textDate3rd.ReadOnly = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str5 != "0"))) & (this.WX == "4X"));
                                    this.textDate4th.ReadOnly = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str6 != "0"))) & (this.WX == "4X"));
                                    this.textTime1st.BackColor = ((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str3 != "0"))) ? Color.White : Color.LightGray;
                                    this.textTime2nd.BackColor = ((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str4 != "0"))) ? Color.White : Color.LightGray;
                                    this.textTime3rd.BackColor = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str5 != "0"))) & (this.WX == "4X")) ? Color.LightGray : Color.White;
                                    this.textTime4th.BackColor = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str6 != "0"))) & (this.WX == "4X")) ? Color.LightGray : Color.White;
                                    this.textDate1st.BackColor = ((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str3 != "0"))) ? Color.White : Color.LightGray;
                                    this.textDate2nd.BackColor = ((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str4 != "0"))) ? Color.White : Color.LightGray;
                                    this.textDate3rd.BackColor = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str5 != "0"))) & (this.WX == "4X")) ? Color.LightGray : Color.White;
                                    this.textDate4th.BackColor = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str6 != "0"))) & (this.WX == "4X")) ? Color.LightGray : Color.White;
                                    str3 = "";
                                    str4 = "";
                                    str5 = "";
                                    str6 = "";
                                    str7 = "";
                                }
                                if (WBUser.UserLevel != "3")
                                {
                                    this.textTruck.ReadOnly = false;
                                    this.textTruck2.ReadOnly = false;
                                }
                                this.buttonSavePrint.Visible = false;
                            }
                            break;
                        }
                        this.transDOBefore = this.tmp_transDO.NewRow();
                        this.tblTransDO.DR = this.tblTransDO.DT.Rows[num3];
                        this.transDOBefore.ItemArray = this.tblTransDO.DR.ItemArray;
                        this.tmp_transDO.Rows.Add(this.transDOBefore);
                        num3++;
                    }
                }
                this.textRefNo.Text = this.tblTrans.DR["Ref"].ToString();
                if (Convert.ToInt16(WBSetting.transflow) >= 2)
                {
                    this.textGatepass.Text = this.tblTrans.DR["Gatepass_Number"].ToString();
                }
                if (this.WX == "")
                {
                    this.WX = this.tblTrans.DR["WX"].ToString();
                }
                this.dateDelivery.Text = this.tblTrans.DR["Delivery_Date"].ToString();
                this.dateRegister.Text = this.tblTrans.DR["Register_Date"].ToString();
                this.TimeDelivery.Text = this.tblTrans.DR["Delivery_Time"].ToString();
                this.TimeRegister.Text = this.tblTrans.DR["Register_Time"].ToString();
                this.textWBNo.Text = this.tblTrans.DR["Ticket"].ToString();
                this.textCommodity.Text = this.tblTrans.DR["Comm_Code"].ToString();
                this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and  comm_code = '" + this.textCommodity.Text.Trim() + "'"), WBData.conn);
                string[] aField = new string[] { "Comm_Code" };
                string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                DataRow data = this.tblComm.GetData(aField, aFind);
                if (data != null)
                {
                    this.labelCommName.Text = data["Comm_Name"].ToString().Trim();
                    this.textCommType.Text = data["Type"].ToString();
                    this.CommType = data["Type"].ToString();
                    this.MaterialType = data["Material_type"].ToString();
                    this.is_pack = data["Trade"].ToString();
                    this.use_gunny = data["Using_Gunny"].ToString();
                    this.check_tare_comm = data["check_tare"].ToString();
                    if (this.use_gunny == "Y")
                    {
                        this.sGunnyNet = Convert.ToDouble(data["Netto_Gunny"].ToString().Trim());
                        this.sGunnyMin = Convert.ToDouble(data["Gross_Min_Gunny"].ToString().Trim());
                        this.sGunnyMax = Convert.ToDouble(data["Gross_Max_Gunny"].ToString().Trim());
                    }
                    else
                    {
                        this.sGunnyNet = 0.0;
                        this.sGunnyMax = 0.0;
                        this.sGunnyMin = 0.0;
                    }
                    this.textBox1.Text = this.sGunnyNet.ToString();
                }
                this.textDN.Enabled = !((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))) ? !((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))) : false;
                this.tabPageShow(this.CommType, this.MaterialType);
                this.textBagCode.Text = this.tblTrans.DR["Bag_Code"].ToString();
                string[] textArray6 = new string[] { "Bag_Code" };
                string[] textArray7 = new string[] { this.textBagCode.Text.Trim() };
                int recNo = this.tblBag.GetRecNo(textArray6, textArray7);
                if (recNo > -1)
                {
                    this.labelBagDesc.Text = this.tblBag.DT.Rows[recNo]["Description"].ToString().Trim();
                    this.labelBagWeight.Text = $"{Program.StrToDouble(this.tblBag.DT.Rows[recNo]["Weight"].ToString().Trim(), 2):#,##0.###}";
                }
                this.textTotalBag.Text = (this.tblTrans.DR["Bag"].ToString().Trim() == "") ? "0" : this.tblTrans.DR["Bag"].ToString();
                this.textTotalBagWeight.Text = (this.tblTrans.DR["Total_Bag_Weight"].ToString().Trim() == "") ? "0" : this.tblTrans.DR["Total_Bag_Weight"].ToString();
                this.checkOverrideBag.Checked = this.tblTrans.DR["Bag_Change"].ToString().Trim() == "Y";
                if (this.checkOverrideBag.Checked)
                {
                    this.textTotalBagWeight.ReadOnly = false;
                }
                else
                {
                    this.textTotalBagWeight.Enabled = true;
                }
                this.textSource.Text = this.tblTrans.DR["Source_code"].ToString().Trim();
                string[] textArray8 = new string[] { "source_code" };
                string[] textArray9 = new string[] { this.textSource.Text.Trim() };
                this.tblSource.DR = this.tblSource.GetData(textArray8, textArray9);
                this.labelSourceName.Text = (this.tblSource.DR == null) ? "" : this.tblSource.DR["Description"].ToString();
                this.textBoxLoadUnload.Text = this.tblTrans.DR["Load_unload"].ToString().Trim();
                string[] textArray10 = new string[] { "load_unload" };
                string[] textArray11 = new string[] { this.textBoxLoadUnload.Text };
                this.tblLoadUnload.DR = this.tblLoadUnload.GetData(textArray10, textArray11);
                this.labelLoadUnloadName.Text = (this.tblLoadUnload.DR == null) ? "" : this.tblLoadUnload.DR["load_desc"].ToString();
                if (WBSetting.locType == "0")
                {
                    this.textMill.Text = this.tblTrans.DR["Mill_code"].ToString().Trim();
                    string[] textArray12 = new string[] { "Mill_code" };
                    string[] textArray13 = new string[] { this.textMill.Text.Trim() };
                    this.tblMill.DR = this.tblMill.GetData(textArray12, textArray13);
                    this.labelMillName.Text = (this.tblMill.DR == null) ? "" : this.tblMill.DR["Mill_Name"].ToString();
                }
                if (WBSetting.locType == "1")
                {
                    this.textDivision.Text = this.tblTrans.DR["Division_code"].ToString().Trim();
                    string[] textArray14 = new string[] { "Division_code" };
                    string[] textArray15 = new string[] { this.textDivision.Text.Trim() };
                    this.tblDivision.DR = this.tblDivision.GetData(textArray14, textArray15);
                    this.labelDivisionName.Text = (this.tblDivision.DR == null) ? "" : this.tblDivision.DR["Division_Name"].ToString();
                }
                this.oldComm = this.textCommodity.Text;
                this.textTruck.Text = this.tblTrans.DR["Truck_Number"].ToString();
                this.textTruck2.Text = this.tblTrans.DR["Truck_Number2"].ToString();
                this.textTrailerNo.Text = this.tblTrans.DR["Truck_Trailer_Number"].ToString();
                this.textTankQC.Text = this.tblTrans.DR["TankQC"].ToString();
                this.textTanker.Text = this.tblTrans.DR["Tanker"].ToString();
                if (this.textTanker.Text.Trim() != "")
                {
                    string[] textArray16 = new string[] { "Tanker_No" };
                    string[] textArray17 = new string[] { this.textTanker.Text };
                    DataRow row3 = this.tblTanker.GetData(textArray16, textArray17);
                    if (row3 != null)
                    {
                        this.labelTankerMax.Text = "Max.Tanker = " + $"{row3["Capacity"]:0,0}" + " Kg";
                    }
                }
                this.textStorage.Text = this.tblTrans.DR["Storage"].ToString();
                if (this.textStorage.Text.Trim() != "")
                {
                    string[] textArray18 = new string[] { "Storage_Code" };
                    string[] textArray19 = new string[] { this.textStorage.Text };
                    DataRow row4 = this.tblStorage.GetData(textArray18, textArray19);
                    if (row4 != null)
                    {
                        this.labelStorageName.Text = row4["Storage_Name"].ToString();
                    }
                }
                this.textDriverID.Text = this.tblTrans.DR["License_No"].ToString();
                this.labelDriverName.Text = this.tblTrans.DR["Name"].ToString();
                this.textDriverName.Text = this.tblTrans.DR["Name"].ToString();
                this.textTransporter.Text = this.tblTrans.DR["Transporter_Code"].ToString();
                if (this.textTransporter.Text.Length > 0)
                {
                    string[] textArray20 = new string[] { "Transporter_Code" };
                    string[] textArray21 = new string[] { this.textTransporter.Text };
                    DataRow row5 = this.tblTransporter.GetData(textArray20, textArray21);
                    if (row5 != null)
                    {
                        this.labelTransporterName.Text = row5["Transporter_Name"].ToString();
                    }
                }
                this.textDN.Text = this.tblTrans.DR["Delivery_Note"].ToString();
                this.textUnloading.Text = this.tblTrans.DR["Unloading"].ToString();
                this.textRemarkTicket.Text = this.tblTrans.DR["Remark_Ticket"].ToString();
                this.textRemarkReport.Text = this.tblTrans.DR["Remark_Report"].ToString();
                this.textRemarkReport.Text = this.tblTrans.DR["Remark_Report"].ToString();
                this.textSEAL.Text = this.tblTrans.DR["Seal"].ToString();
                if (this.tblTrans.DR["Estate"].ToString().Trim() != "")
                {
                    this.textEstate.Text = this.tblTrans.DR["Estate"].ToString();
                    string[] textArray22 = new string[] { "Estate_Code" };
                    string[] textArray23 = new string[] { this.textEstate.Text };
                    DataRow row6 = this.tblEstate.GetData(textArray22, textArray23);
                    if (row6 != null)
                    {
                        this.labelEstateName.Text = row6["Estate_Name"].ToString();
                    }
                }
                this.textGrossEstate.Text = (this.tblTrans.DR["Gross_Estate"].ToString() == "") ? "0" : $"{this.tblTrans.DR["Gross_Estate"]:N0}";
                this.textTareEstate.Text = (this.tblTrans.DR["Tare_Estate"].ToString() == "") ? "0" : $"{this.tblTrans.DR["Tare_Estate"]:N0}";
                this.textNetEstate.Text = (this.tblTrans.DR["Net_Estate"].ToString() == "") ? "0" : $"{this.tblTrans.DR["Net_Estate"]:N0}";
                this.comTransType.Text = this.tblTrans.DR["Transaction_Code"].ToString();
                this.TransType();
                this.text1st.Text = (this.tblTrans.DR["_1ST"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_1ST"]:N0}";
                this.text2nd.Text = (this.tblTrans.DR["_2ND"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_2ND"]:N0}";
                this.text3rd.Text = (this.tblTrans.DR["_3RD"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_3RD"]:N0}";
                this.text4th.Text = (this.tblTrans.DR["_4TH"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_4TH"]:N0}";
                this.textDeducTotal.Text = $"{this.tblTrans.DR["Deduction"]:N0}";
                this.textNet.Text = $"{this.tblTrans.DR["Net"]:#,##0.###}";
                if (this.tblTransCopra.DT.Rows.Count > 0)
                {
                    this.tblTransCopra.DR = this.tblTransCopra.DT.Rows[0];
                    this.fCopra.textColly1.Text = this.tblTransCopra.DR["Colly1"].ToString();
                    this.fCopra.textColly2.Text = this.tblTransCopra.DR["Colly2"].ToString();
                    this.fCopra.textColly3.Text = this.tblTransCopra.DR["Colly3"].ToString();
                    this.fCopra.textColly4.Text = this.tblTransCopra.DR["Colly4"].ToString();
                    this.fCopra.textColly5.Text = this.tblTransCopra.DR["Colly5"].ToString();
                    this.fCopra.textColly6.Text = this.tblTransCopra.DR["Colly6"].ToString();
                    this.fCopra.textColly7.Text = this.tblTransCopra.DR["Colly7"].ToString();
                    this.fCopra.textColly8.Text = this.tblTransCopra.DR["Colly8"].ToString();
                    this.fCopra.textColly1KG.Text = this.tblTransCopra.DR["NetColly1"].ToString();
                    this.fCopra.textColly2KG.Text = this.tblTransCopra.DR["NetColly2"].ToString();
                    this.fCopra.textColly3KG.Text = this.tblTransCopra.DR["NetColly3"].ToString();
                    this.fCopra.textColly4KG.Text = this.tblTransCopra.DR["NetColly4"].ToString();
                    this.fCopra.textColly5KG.Text = this.tblTransCopra.DR["NetColly5"].ToString();
                    this.fCopra.textColly6KG.Text = this.tblTransCopra.DR["NetColly6"].ToString();
                    this.fCopra.textColly7KG.Text = this.tblTransCopra.DR["NetColly7"].ToString();
                    this.fCopra.textColly8KG.Text = this.tblTransCopra.DR["NetColly8"].ToString();
                    this.fCopra.textJlhColly1.Text = this.tblTransCopra.DR["JlhColly1"].ToString();
                    this.fCopra.textJlhColly2.Text = this.tblTransCopra.DR["JlhColly2"].ToString();
                    this.fCopra.textJlhColly3.Text = this.tblTransCopra.DR["JlhColly3"].ToString();
                    this.fCopra.textJlhColly4.Text = this.tblTransCopra.DR["JlhColly4"].ToString();
                    this.fCopra.textJlhColly5.Text = this.tblTransCopra.DR["JlhColly5"].ToString();
                    this.fCopra.textJlhColly6.Text = this.tblTransCopra.DR["JlhColly6"].ToString();
                    this.fCopra.textJlhColly7.Text = this.tblTransCopra.DR["JlhColly7"].ToString();
                    this.fCopra.textForm1.Text = this.tblTransCopra.DR["Form1"].ToString();
                    this.fCopra.textForm2.Text = this.tblTransCopra.DR["Form2"].ToString();
                    this.fCopra.textForm3.Text = this.tblTransCopra.DR["Form3"].ToString();
                    this.fCopra.textForm4.Text = this.tblTransCopra.DR["Form4"].ToString();
                    this.fCopra.textForm5.Text = this.tblTransCopra.DR["Form5"].ToString();
                    this.fCopra.textForm6.Text = this.tblTransCopra.DR["Form6"].ToString();
                    this.fCopra.textForm7.Text = this.tblTransCopra.DR["Form7"].ToString();
                    this.fCopra.textForm1KG.Text = this.tblTransCopra.DR["NetF1"].ToString();
                    this.fCopra.textForm2KG.Text = this.tblTransCopra.DR["NetF2"].ToString();
                    this.fCopra.textForm3KG.Text = this.tblTransCopra.DR["NetF3"].ToString();
                    this.fCopra.textForm4KG.Text = this.tblTransCopra.DR["NetF4"].ToString();
                    this.fCopra.textForm5KG.Text = this.tblTransCopra.DR["NetF5"].ToString();
                    this.fCopra.textForm6KG.Text = this.tblTransCopra.DR["NetF6"].ToString();
                    this.fCopra.textForm7KG.Text = this.tblTransCopra.DR["NetF7"].ToString();
                    this.fCopra.textPotLain.Text = this.tblTransCopra.DR["PotLain"].ToString();
                    this.fCopra.textFormTotalKG.Text = this.tblTransCopra.DR["TPColly"].ToString();
                    this.fCopra.textTPAir.Text = this.tblTransCopra.DR["TPAir"].ToString();
                    this.fCopra.textJlhColly.Text = this.tblTransCopra.DR["JlhColly"].ToString();
                    this.textTotalCopra.Text = this.tblTransCopra.DR["TPCopra"].ToString();
                }
                this.textBunchTotal.Text = this.tblTrans.DR["TotalBunch"].ToString();
                this.textBunchDeduc.Text = this.tblTrans.DR["TotalBunchGrading"].ToString();
                this.textUnitName.Text = (this.tblTrans.DR["UnitName"].ToString() == "") ? "Bunch" : this.tblTrans.DR["UnitName"].ToString();
                this.labelUnit.Text = (this.tblTrans.DR["UnitName"].ToString() == "") ? "KG per Bunch" : ("KG per " + this.tblTrans.DR["UnitName"].ToString());
                this.textUnitNameWeight.Text = this.tblTrans.DR["WeightPerUnitName"].ToString();
                this.textAvg.Text = this.tblTrans.DR["Average"].ToString();
                this.textGrade.Text = this.tblTrans.DR["Grade"].ToString();
                this.checkEstate.Checked = this.tblTrans.DR["Truck_Number2"].ToString() == "Y";
                this.mChangeReason = this.tblTrans.DR["ChangeReason"].ToString();
                this.checkEstate.Checked = this.tblTrans.DR["EstateDiff"].ToString() == "Y";
                this.nonContract = this.tblTrans.DR["NonContract"].ToString();
                this.textDocStatusLab.Text = this.tblTrans.DR["QCStatus"].ToString();
                this.textCust.Text = this.tblTrans.DR["Relation_code"].ToString();
                if (this.tblTrans.DR["ISCC_Checked"].ToString() == "Y")
                {
                    this.checkISCC.Checked = true;
                    this.textISCC.Text = this.tblTrans.DR["ISCC_No"].ToString();
                    this.textISCC2.Text = this.tblTrans.DR["ISCC_No2"].ToString();
                    if (this.tblTrans.DR["ISCC_GC_Checked"].ToString() == "Y")
                    {
                        this.radioGHG1.Checked = true;
                    }
                    else
                    {
                        this.radioGHG2.Checked = true;
                        this.textGHG.Text = this.tblTrans.DR["ISCC_Weight"].ToString();
                    }
                }
                if (this.tblTrans.DR["transWarning"].ToString().Length > 4)
                {
                    this.transIndStableWarning = this.tblTrans.DR["transWarning"].ToString().Substring(0, 4);
                }
                this.text2nd_Leave(this, e);
                this.HitNetEstate();
            }
            this.buttonReadIndicator.Visible = (this.pMode != "EDIT") && (this.WX.Trim() != "");
            if (this.Copied)
            {
                this.WX = "2X";
                this.comTransType.Text = this.tblTrans.DR["Transaction_Code"].ToString();
                this.TransType();
                this.textCommodity.Text = this.tblTrans.DR["Comm_Code"].ToString();
                this._InitBlankGrading(this.textCommodity.Text);
                this._InitBlankGradingPorla(this.textCommodity.Text);
                if (this.textCommodity.Text.Length > 0)
                {
                    this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and  comm_code = '" + this.textCommodity.Text.Trim() + "'"), WBData.conn);
                    string[] aField = new string[] { "Comm_Code" };
                    string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                    DataRow data = this.tblComm.GetData(aField, aFind);
                    if (data != null)
                    {
                        this.labelCommName.Text = data["Comm_Name"].ToString().Trim();
                        this.textCommType.Text = data["Type"].ToString();
                        this.CommType = data["Type"].ToString();
                        this.MaterialType = data["Material_Type"].ToString();
                        this.tabPageShow(this.CommType, this.MaterialType);
                    }
                }
                int num4 = 0;
                while (true)
                {
                    if (num4 >= this.dgvDO.RowCount)
                    {
                        int num5 = 0;
                        while (true)
                        {
                            if (num5 >= this.dgvQC.RowCount)
                            {
                                this.Text = this.pMode.Trim() + " WEIGHT TRANSACTION ( " + this.WX.Trim() + " )";
                                this.buttonReadIndicator.Visible = true;
                                this._InitBlankQC(this.dgvDO.Rows[0].Cells["DO_NO"].ToString());
                                this._InitBlankGrading(this.textCommodity.Text);
                                this._InitBlankGradingPorla(this.textCommodity.Text);
                                break;
                            }
                            this.dgvQC.Rows[num5].Cells["Ref"].Value = this.textRefNo.Text;
                            this.dgvQC.Rows[num5].Cells["Estate"].Value = 0;
                            this.dgvQC.Rows[num5].Cells["Factory"].Value = 0;
                            num5++;
                        }
                        break;
                    }
                    this.dgvDO.Rows[num4].Cells["Ref"].Value = this.textRefNo.Text;
                    this.dgvDO.Rows[num4].Cells["Netto"].Value = 0;
                    this.dgvDO.Rows[num4].Cells["Estate_qty"].Value = 0;
                    this.dgvDO.Rows[num4].Cells["Bruto"].Value = 0;
                    this.dgvDO.Rows[num4].Cells["Tarra"].Value = 0;
                    this.dgvDO.Rows[num4].Cells["ConvNett"].Value = 0;
                    num4++;
                }
            }
            if (WBSetting.bGate == "Y")
            {
                if (((this.pMode == "1ST") || (this.pMode == "3RD")) & (this.WX != ""))
                {
                    Process.Start(WBSetting.gate1Open);
                }
                if (((this.pMode == "2ND") || (this.pMode == "4TH")) & (this.WX != ""))
                {
                    Process.Start(WBSetting.gate1OpenOut);
                }
            }
            this.textNettoBatch_Leave(this, e);
            if (this.pMode == "VIEW")
            {
                this.buttonReadIndicator.Visible = false;
            }
            this.checkOverrideBag.Enabled = (WBUser.CheckTrustee("TRANS_OVERRIDEBAG", "V") || WBUser.CheckTrustee("TRANS_OVERRIDEBAG", "A")) || WBUser.CheckTrustee("TRANS_OVERRIDEBAG", "E");
            Cursor.Current = Cursors.Default;
        }

        private double GetDeduc()
        {
            double num = 0.0;
            foreach (DataGridViewRow row in (IEnumerable) this.dgvDeduc.Rows)
            {
                num += (row.Cells["Deduct"].Value.ToString() == "Y") ? Convert.ToDouble(row.Cells["KgDeduc"].Value.ToString()) : 0.0;
            }
            return num;
        }

        private double GetDeducByUnit()
        {
            double num = 0.0;
            if (!(Program.StrToDouble(this.textUnitNameWeight.Text, 2) == 0.0))
            {
                num = Convert.ToDouble(this.textUnitNameWeight.Text) * Convert.ToDouble(this.textBunchTotal.Text);
            }
            return num;
        }

        private double getTotalBagWeight() => 
            Program.StrToDouble(this.textTotalBagWeight.Text, 3);

        private void HitNet()
        {
            this.textDeducTotal.Text = $"{((this.GetDeducByUnit() + this.GetDeduc()) + Program.StrToDouble(this.textTotalCopra.Text, 0)) + this.getTotalBagWeight():N0}";
            if ((Program.CheckNumeric(this.text1st) && (Program.CheckNumeric(this.text2nd) && (Program.CheckNumeric(this.text3rd) && Program.CheckNumeric(this.text4th)))) && Program.CheckNumeric(this.textDeducTotal))
            {
                double num = Math.Abs((double) (Convert.ToDouble(this.text1st.Text) - Convert.ToDouble(this.text2nd.Text)));
                double num2 = Math.Abs((double) ((num + Convert.ToDouble(this.text3rd.Text)) - Convert.ToDouble(this.text4th.Text)));
                this.textNET1.Text = $"{num:N0}";
                this.textNET2.Text = $"{num2:N0}";
                this.textNet.Text = $"{num2 - Program.StrToDouble(this.textDeducTotal.Text, 3):#,##0.###}";
                this.textVariance.Text = $"{Convert.ToDouble(this.textNet.Text) - Convert.ToDouble(this.textNetEstate.Text):#,##0.###}";
            }
            this.settingTabControl();
        }

        private void HitNetEstate()
        {
            if (Program.CheckNumeric(this.textGrossEstate) && Program.CheckNumeric(this.textTareEstate))
            {
                double num = Math.Abs((double) (Convert.ToDouble(this.textGrossEstate.Text) - Convert.ToDouble(this.textTareEstate.Text)));
                this.textNetEstate.Text = $"{num:N0}";
                this.textVariance.Text = Convert.ToString((double) (Convert.ToDouble(this.textNet.Text) - Convert.ToDouble(this.textNetEstate.Text)));
                if (this.dgvDO.Rows.Count > 0)
                {
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 >= this.dgvDO.Rows.Count)
                        {
                            this.dgvDO.Rows[0].Cells["estate_qty"].Value = num;
                            break;
                        }
                        num -= Convert.ToDouble(this.dgvDO.Rows[num2].Cells["estate_qty"].Value);
                        num2++;
                    }
                }
            }
        }

        private double hitQtyToday(string pRef, string pDate, string pRelation)
        {
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "Select sum(NET) as Net from wb_transaction where relation_code = '", pRelation, "'and report_date <= '", Program.DTOC(Convert.ToDateTime(pDate)), "' and Ref <> '", pRef, "' and (deleted is null or deleted = 'N')  and report_date is not null " };
            table.OpenTable("tmp_transaction", string.Concat(textArray1), WBData.conn);
            return ((table.DT.Rows.Count <= 0) ? 0.0 : Program.StrToDouble(table.DT.Rows[0]["net"].ToString(), 0));
        }

        private void hitungBTN()
        {
            try
            {
                this.text1st.Text = (this.text1st.Text.Trim() == "") ? "0" : this.text1st.Text;
                this.text2nd.Text = (this.text2nd.Text.Trim() == "") ? "0" : this.text2nd.Text;
                if (this.WX == "2X")
                {
                    if (this.dgvDO.Rows.Count == 1)
                    {
                        if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text2nd.Text))
                        {
                            this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text);
                            this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text1st.Text);
                            this.dgvDO.Rows[0].Cells["Tarra"].Value = Convert.ToDouble(this.text2nd.Text);
                            this.dgvDO.Rows[0].Cells["Estate_Qty"].Value = Convert.ToDouble(this.textNetEstate.Text);
                        }
                        else
                        {
                            this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text);
                            this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text2nd.Text);
                            this.dgvDO.Rows[0].Cells["Tarra"].Value = Convert.ToDouble(this.text1st.Text);
                            this.dgvDO.Rows[0].Cells["Estate_Qty"].Value = Convert.ToDouble(this.textNetEstate.Text);
                        }
                    }
                }
                else if (this.dgvDO.Rows.Count == 1)
                {
                    if (this.transType == "I")
                    {
                        this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text);
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text1st.Text);
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = (Convert.ToDouble(this.text4th.Text) - Convert.ToDouble(this.text3rd.Text)) + Convert.ToDouble(this.text2nd.Text);
                        this.dgvDO.Rows[0].Cells["Estate_Qty"].Value = Convert.ToDouble(this.textNetEstate.Text);
                    }
                    else
                    {
                        this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text);
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text4th.Text);
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = (Convert.ToDouble(this.text1st.Text) - Convert.ToDouble(this.text2nd.Text)) + Convert.ToDouble(this.text3rd.Text);
                        this.dgvDO.Rows[0].Cells["Estate_Qty"].Value = Convert.ToDouble(this.textNetEstate.Text);
                    }
                }
            }
            catch
            {
            }
        }

        private void InitCombo()
        {
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            DataGridViewCellStyle style4 = new DataGridViewCellStyle();
            DataGridViewCellStyle style5 = new DataGridViewCellStyle();
            DataGridViewCellStyle style6 = new DataGridViewCellStyle();
            DataGridViewCellStyle style7 = new DataGridViewCellStyle();
            DataGridViewCellStyle style8 = new DataGridViewCellStyle();
            DataGridViewCellStyle style9 = new DataGridViewCellStyle();
            DataGridViewCellStyle style10 = new DataGridViewCellStyle();
            DataGridViewCellStyle style11 = new DataGridViewCellStyle();
            DataGridViewCellStyle style12 = new DataGridViewCellStyle();
            DataGridViewCellStyle style13 = new DataGridViewCellStyle();
            DataGridViewCellStyle style14 = new DataGridViewCellStyle();
            DataGridViewCellStyle style15 = new DataGridViewCellStyle();
            DataGridViewCellStyle style16 = new DataGridViewCellStyle();
            DataGridViewCellStyle style17 = new DataGridViewCellStyle();
            DataGridViewCellStyle style18 = new DataGridViewCellStyle();
            DataGridViewCellStyle style19 = new DataGridViewCellStyle();
            DataGridViewCellStyle style20 = new DataGridViewCellStyle();
            DataGridViewCellStyle style21 = new DataGridViewCellStyle();
            this.label1 = new Label();
            this.labTankerNo = new Label();
            this.label3 = new Label();
            this.textTruck2 = new TextBox();
            this.labelDriverName = new Label();
            this.labelTankerMax = new Label();
            this.labelTransporterName = new Label();
            this.label4 = new Label();
            this.label2 = new Label();
            this.textDN = new TextBox();
            this.textUnloading = new TextBox();
            this.label5 = new Label();
            this.textRemarkTicket = new TextBox();
            this.label6 = new Label();
            this.textRemarkReport = new TextBox();
            this.label7 = new Label();
            this.groupOtherParty = new GroupBox();
            this.textWBNo = new TextBox();
            this.textNetEstate = new TextBox();
            this.labelWBNo = new Label();
            this.textTareEstate = new TextBox();
            this.textGrossEstate = new TextBox();
            this.label10 = new Label();
            this.label9 = new Label();
            this.label8 = new Label();
            this.label25 = new Label();
            this.dateDelivery = new DateTimePicker();
            this.TimeDelivery = new MaskedTextBox();
            this.groupFactoryWeight = new GroupBox();
            this.panel4X = new Panel();
            this.label16 = new Label();
            this.textTime4th = new TextBox();
            this.label15 = new Label();
            this.textTime3rd = new TextBox();
            this.textNET2 = new TextBox();
            this.label14 = new Label();
            this.text4th = new TextBox();
            this.textDate3rd = new TextBox();
            this.textDate4th = new TextBox();
            this.text3rd = new TextBox();
            this.textDate1st = new TextBox();
            this.textTime2nd = new TextBox();
            this.textNET1 = new TextBox();
            this.textTime1st = new TextBox();
            this.textDate2nd = new TextBox();
            this.text2nd = new TextBox();
            this.text1st = new TextBox();
            this.label11 = new Label();
            this.label12 = new Label();
            this.label13 = new Label();
            this.TimeRegister = new MaskedTextBox();
            this.dateRegister = new DateTimePicker();
            this.label26 = new Label();
            this.textDeducTotal = new TextBox();
            this.label17 = new Label();
            this.textNet = new TextBox();
            this.label18 = new Label();
            this.textSEAL = new TextBox();
            this.label19 = new Label();
            this.textReport_Date = new TextBox();
            this.label37 = new Label();
            this.textRefNo = new TextBox();
            this.textRef_Date = new TextBox();
            this.label35 = new Label();
            this.labelTransTypeName = new Label();
            this.comTransType = new ComboBox();
            this.labelTransType = new Label();
            this.buttonSave = new Button();
            this.buttonSavePrint = new Button();
            this.buttonCancel = new Button();
            this.buttonReset = new Button();
            this.buttonReadIndicator = new Button();
            this.buttonTruck = new Button();
            this.textTruck = new TextBox();
            this.textDriverID = new TextBox();
            this.buttonDriver = new Button();
            this.buttonTransporter = new Button();
            this.textTransporter = new TextBox();
            this.buttonTanker = new Button();
            this.textTanker = new TextBox();
            this.label33 = new Label();
            this.textCommType = new TextBox();
            this.textVariance = new TextBox();
            this.label45 = new Label();
            this.textTrailerNo = new TextBox();
            this.label46 = new Label();
            this.textDriverName = new TextBox();
            this.checkEstate = new CheckBox();
            this.buttonTarraHistory = new Button();
            this.label21 = new Label();
            this.textGatepass = new TextBox();
            this.labelGatepass = new Label();
            this.textGPManual = new TextBox();
            this.tabPageBag = new TabPage();
            this.label67 = new Label();
            this.labelBagWeight = new Label();
            this.label66 = new Label();
            this.labelBagDesc = new Label();
            this.buttonBag = new Button();
            this.textTotalBagWeight = new TextBox();
            this.textTotalBag = new TextBox();
            this.textBagCode = new TextBox();
            this.checkOverrideBag = new CheckBox();
            this.label65 = new Label();
            this.label64 = new Label();
            this.label61 = new Label();
            this.shapeContainer1 = new ShapeContainer();
            this.lineShape1 = new LineShape();
            this.tabPageDL = new TabPage();
            this.button19 = new Button();
            this.textNettoBatchLeft = new TextBox();
            this.textGunnyBatchLeft = new TextBox();
            this.textDL = new TextBox();
            this.textBox1 = new TextBox();
            this.textSTO = new TextBox();
            this.label51 = new Label();
            this.label53 = new Label();
            this.label52 = new Label();
            this.buttonAdopt = new Button();
            this.label56 = new Label();
            this.label55 = new Label();
            this.label54 = new Label();
            this.groupBox2 = new GroupBox();
            this.label60 = new Label();
            this.label59 = new Label();
            this.textBox3 = new TextBox();
            this.textBox2 = new TextBox();
            this.label58 = new Label();
            this.label57 = new Label();
            this.button20 = new Button();
            this.groupBox1 = new GroupBox();
            this.textNettoBatch = new TextBox();
            this.label36 = new Label();
            this.label48 = new Label();
            this.textGunnyBatch = new TextBox();
            this.label50 = new Label();
            this.button18 = new Button();
            this.label28 = new Label();
            this.dgvBatch = new DataGridView();
            this.shapeContainer4 = new ShapeContainer();
            this.rectangleShape3 = new RectangleShape();
            this.tabPageCopra = new TabPage();
            this.buttonEntryCopra = new Button();
            this.label24 = new Label();
            this.textTotalCopra = new TextBox();
            this.label27 = new Label();
            this.tabPagePorla = new TabPage();
            this.label22 = new Label();
            this.buttonDeletePorla = new Button();
            this.buttonEditPorla = new Button();
            this.dgvDeducPorla = new DataGridView();
            this.buttonAddPorla = new Button();
            this.shapeContainer3 = new ShapeContainer();
            this.rectangleShape2 = new RectangleShape();
            this.tabPageCont = new TabPage();
            this.dgvCont = new DataGridView();
            this.panel5 = new Panel();
            this.buttonContDelete = new Button();
            this.buttonContEdit = new Button();
            this.buttonContAdd = new Button();
            this.tabPageQC = new TabPage();
            this.label20 = new Label();
            this.textQualityInfo = new RichTextBox();
            this.textTankQC = new TextBox();
            this.textQControl = new TextBox();
            this.dgvQC_All = new DataGridView();
            this.label44 = new Label();
            this.label43 = new Label();
            this.combodgvDO = new ComboBox();
            this.label42 = new Label();
            this.dgvQC = new DataGridView();
            this.tabPageDivision = new TabPage();
            this.dgvDivBlock = new DataGridView();
            this.panel3 = new Panel();
            this.button15 = new Button();
            this.button16 = new Button();
            this.button17 = new Button();
            this.tabPageDeduc = new TabPage();
            this.buttonSavePrintGrading = new Button();
            this.textGrade = new TextBox();
            this.label23 = new Label();
            this.labelUnit = new Label();
            this.textUnitNameWeight = new TextBox();
            this.textUnitName = new TextBox();
            this.label34 = new Label();
            this.groupBox4 = new GroupBox();
            this.textBunchTotal = new TextBox();
            this.textBunchDeduc = new TextBox();
            this.label29 = new Label();
            this.label30 = new Label();
            this.textAvg = new TextBox();
            this.label31 = new Label();
            this.buttonDeleteDeduc = new Button();
            this.buttonEditDeduc = new Button();
            this.dgvDeduc = new DataGridView();
            this.buttonAddDeduc = new Button();
            this.shapeContainer2 = new ShapeContainer();
            this.rectangleShape1 = new RectangleShape();
            this.tabPageInfo = new TabPage();
            this.panelInfo = new Panel();
            this.labelDivision = new Label();
            this.buttonDivision = new Button();
            this.textDivision = new TextBox();
            this.labelDivisionName = new Label();
            this.labelMill = new Label();
            this.buttonMill = new Button();
            this.textMill = new TextBox();
            this.labelMillName = new Label();
            this.labelSourceName = new Label();
            this.buttonSource = new Button();
            this.textSource = new TextBox();
            this.label62 = new Label();
            this.buttonLoadUnload = new Button();
            this.label63 = new Label();
            this.textBoxLoadUnload = new TextBox();
            this.labelLoadUnloadName = new Label();
            this.buttonStorage = new Button();
            this.textStorage = new TextBox();
            this.textEstate = new TextBox();
            this.textCommodity = new TextBox();
            this.textCust = new TextBox();
            this.labelStorageName = new Label();
            this.labelStorage = new Label();
            this.buttonEstate = new Button();
            this.labelEstateName = new Label();
            this.panel4 = new Panel();
            this.textISCC2 = new TextBox();
            this.groupBox3 = new GroupBox();
            this.label39 = new Label();
            this.textGHG = new TextBox();
            this.radioGHG2 = new RadioButton();
            this.radioGHG1 = new RadioButton();
            this.textISCC = new TextBox();
            this.label38 = new Label();
            this.checkISCC = new CheckBox();
            this.labelCustName = new Label();
            this.label40 = new Label();
            this.buttonCust = new Button();
            this.labelComm = new Label();
            this.labelCommName = new Label();
            this.labelRelation = new Label();
            this.buttonComm = new Button();
            this.tabPageDO = new TabPage();
            this.dgvDO = new DataGridView();
            this.panel1 = new Panel();
            this.buttonMergeDO = new Button();
            this.buttonDeleteDO = new Button();
            this.buttonEditDO = new Button();
            this.buttonAddDO = new Button();
            this.tabControl1 = new TabControl();
            this.label32 = new Label();
            this.textDocStatusLab = new TextBox();
            this.groupOtherParty.SuspendLayout();
            this.groupFactoryWeight.SuspendLayout();
            this.panel4X.SuspendLayout();
            this.tabPageBag.SuspendLayout();
            this.tabPageDL.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((ISupportInitialize) this.dgvBatch).BeginInit();
            this.tabPageCopra.SuspendLayout();
            this.tabPagePorla.SuspendLayout();
            ((ISupportInitialize) this.dgvDeducPorla).BeginInit();
            this.tabPageCont.SuspendLayout();
            ((ISupportInitialize) this.dgvCont).BeginInit();
            this.panel5.SuspendLayout();
            this.tabPageQC.SuspendLayout();
            ((ISupportInitialize) this.dgvQC_All).BeginInit();
            ((ISupportInitialize) this.dgvQC).BeginInit();
            this.tabPageDivision.SuspendLayout();
            ((ISupportInitialize) this.dgvDivBlock).BeginInit();
            this.panel3.SuspendLayout();
            this.tabPageDeduc.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((ISupportInitialize) this.dgvDeduc).BeginInit();
            this.tabPageInfo.SuspendLayout();
            this.panelInfo.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPageDO.SuspendLayout();
            ((ISupportInitialize) this.dgvDO).BeginInit();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            base.SuspendLayout();
            this.label1.Location = new Point(4, 0x52);
            this.label1.Margin = new Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x90, 0x10);
            this.label1.TabIndex = 0x10;
            this.label1.Text = "Vehicle No. * ";
            this.label1.TextAlign = ContentAlignment.TopRight;
            this.labTankerNo.AutoSize = true;
            this.labTankerNo.Location = new Point(0x235, 0x70);
            this.labTankerNo.Margin = new Padding(4, 0, 4, 0);
            this.labTankerNo.Name = "labTankerNo";
            this.labTankerNo.Size = new Size(0x53, 0x11);
            this.labTankerNo.TabIndex = 0x1a;
            this.labTankerNo.Text = "Tanker No. ";
            this.label3.Location = new Point(4, 0x72);
            this.label3.Margin = new Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x90, 0x10);
            this.label3.TabIndex = 0x11;
            this.label3.Text = "Driver ID *";
            this.label3.TextAlign = ContentAlignment.TopRight;
            this.textTruck2.CharacterCasing = CharacterCasing.Upper;
            this.textTruck2.Location = new Point(0x16f, 0x4c);
            this.textTruck2.Margin = new Padding(4);
            this.textTruck2.Name = "textTruck2";
            this.textTruck2.ReadOnly = true;
            this.textTruck2.Size = new Size(0xbf, 0x16);
            this.textTruck2.TabIndex = 2;
            this.labelDriverName.AutoSize = true;
            this.labelDriverName.Location = new Point(0x191, 0x71);
            this.labelDriverName.Margin = new Padding(4, 0, 4, 0);
            this.labelDriverName.Name = "labelDriverName";
            this.labelDriverName.Size = new Size(0x53, 0x11);
            this.labelDriverName.TabIndex = 0x18;
            this.labelDriverName.Text = "DriverName";
            this.labelTankerMax.AutoSize = true;
            this.labelTankerMax.Location = new Point(0x361, 0x72);
            this.labelTankerMax.Margin = new Padding(4, 0, 4, 0);
            this.labelTankerMax.Name = "labelTankerMax";
            this.labelTankerMax.Size = new Size(0xb7, 0x11);
            this.labelTankerMax.TabIndex = 0x1b;
            this.labelTankerMax.Text = "Maximum Tanker = ###,###";
            this.labelTransporterName.AutoSize = true;
            this.labelTransporterName.Location = new Point(0x167, 0x92);
            this.labelTransporterName.Margin = new Padding(4, 0, 4, 0);
            this.labelTransporterName.Name = "labelTransporterName";
            this.labelTransporterName.Size = new Size(120, 0x11);
            this.labelTransporterName.TabIndex = 0x1d;
            this.labelTransporterName.Text = "TransporterName";
            this.label4.Location = new Point(4, 0x91);
            this.label4.Margin = new Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x90, 0x10);
            this.label4.TabIndex = 0x15;
            this.label4.Text = "Transporter";
            this.label4.TextAlign = ContentAlignment.TopRight;
            this.label2.Location = new Point(4, 0xb0);
            this.label2.Margin = new Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x90, 0x10);
            this.label2.TabIndex = 14;
            this.label2.Text = "Delivery Note";
            this.label2.TextAlign = ContentAlignment.TopRight;
            this.textDN.CharacterCasing = CharacterCasing.Upper;
            this.textDN.Location = new Point(0x9b, 0xac);
            this.textDN.Margin = new Padding(4);
            this.textDN.MaxLength = 30;
            this.textDN.Name = "textDN";
            this.textDN.Size = new Size(0xc1, 0x16);
            this.textDN.TabIndex = 1;
            this.textDN.KeyPress += new KeyPressEventHandler(this.textDN_KeyPress);
            this.textDN.Leave += new EventHandler(this.textDN_Leave);
            this.textUnloading.CharacterCasing = CharacterCasing.Upper;
            this.textUnloading.Location = new Point(0x1d8, 0xac);
            this.textUnloading.Margin = new Padding(4);
            this.textUnloading.MaxLength = 20;
            this.textUnloading.Name = "textUnloading";
            this.textUnloading.Size = new Size(0x55, 0x16);
            this.textUnloading.TabIndex = 2;
            this.textUnloading.Visible = false;
            this.textUnloading.KeyPress += new KeyPressEventHandler(this.textUnloading_KeyPress);
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x163, 0xb0);
            this.label5.Margin = new Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x6c, 0x11);
            this.label5.TabIndex = 0x27;
            this.label5.Text = "Unloading Point";
            this.label5.Visible = false;
            this.textRemarkTicket.Location = new Point(0x9b, 0xca);
            this.textRemarkTicket.Margin = new Padding(4);
            this.textRemarkTicket.MaxLength = 250;
            this.textRemarkTicket.Multiline = true;
            this.textRemarkTicket.Name = "textRemarkTicket";
            this.textRemarkTicket.Size = new Size(0x241, 0x4d);
            this.textRemarkTicket.TabIndex = 3;
            this.textRemarkTicket.TextChanged += new EventHandler(this.textRemarkTicket_TextChanged);
            this.label6.Location = new Point(4, 0xce);
            this.label6.Margin = new Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x90, 0x10);
            this.label6.TabIndex = 15;
            this.label6.Text = "Remark for ticket";
            this.label6.TextAlign = ContentAlignment.TopRight;
            this.textRemarkReport.Location = new Point(0x9b, 0x11f);
            this.textRemarkReport.Margin = new Padding(4);
            this.textRemarkReport.MaxLength = 100;
            this.textRemarkReport.Name = "textRemarkReport";
            this.textRemarkReport.Size = new Size(0x241, 0x16);
            this.textRemarkReport.TabIndex = 4;
            this.label7.Location = new Point(3, 290);
            this.label7.Margin = new Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x90, 0x10);
            this.label7.TabIndex = 0x10;
            this.label7.Text = "Remark for Report";
            this.label7.TextAlign = ContentAlignment.TopRight;
            this.groupOtherParty.Controls.Add(this.textWBNo);
            this.groupOtherParty.Controls.Add(this.textNetEstate);
            this.groupOtherParty.Controls.Add(this.labelWBNo);
            this.groupOtherParty.Controls.Add(this.textTareEstate);
            this.groupOtherParty.Controls.Add(this.textGrossEstate);
            this.groupOtherParty.Controls.Add(this.label10);
            this.groupOtherParty.Controls.Add(this.label9);
            this.groupOtherParty.Controls.Add(this.label8);
            this.groupOtherParty.Controls.Add(this.label25);
            this.groupOtherParty.Controls.Add(this.dateDelivery);
            this.groupOtherParty.Controls.Add(this.TimeDelivery);
            this.groupOtherParty.Location = new Point(0x13, 0x155);
            this.groupOtherParty.Margin = new Padding(4);
            this.groupOtherParty.Name = "groupOtherParty";
            this.groupOtherParty.Padding = new Padding(4);
            this.groupOtherParty.Size = new Size(0x134, 160);
            this.groupOtherParty.TabIndex = 6;
            this.groupOtherParty.TabStop = false;
            this.groupOtherParty.Text = "[ Other Party ]";
            this.textWBNo.CharacterCasing = CharacterCasing.Upper;
            this.textWBNo.Location = new Point(0x57, 0x76);
            this.textWBNo.Margin = new Padding(4);
            this.textWBNo.MaxLength = 30;
            this.textWBNo.Name = "textWBNo";
            this.textWBNo.Size = new Size(0xc5, 0x16);
            this.textWBNo.TabIndex = 4;
            this.textNetEstate.Location = new Point(0xe0, 0x39);
            this.textNetEstate.Margin = new Padding(4);
            this.textNetEstate.MaxLength = 15;
            this.textNetEstate.Name = "textNetEstate";
            this.textNetEstate.ReadOnly = true;
            this.textNetEstate.Size = new Size(0x4b, 0x16);
            this.textNetEstate.TabIndex = 10;
            this.textNetEstate.Text = "0";
            this.textNetEstate.TextAlign = HorizontalAlignment.Right;
            this.labelWBNo.AutoSize = true;
            this.labelWBNo.Location = new Point(8, 0x7a);
            this.labelWBNo.Margin = new Padding(4, 0, 4, 0);
            this.labelWBNo.Name = "labelWBNo";
            this.labelWBNo.Size = new Size(0x42, 0x11);
            this.labelWBNo.TabIndex = 8;
            this.labelWBNo.Text = "WB (Ref)";
            this.textTareEstate.Location = new Point(0x57, 0x3a);
            this.textTareEstate.Margin = new Padding(4);
            this.textTareEstate.MaxLength = 15;
            this.textTareEstate.Name = "textTareEstate";
            this.textTareEstate.Size = new Size(0x4b, 0x16);
            this.textTareEstate.TabIndex = 1;
            this.textTareEstate.Text = "0";
            this.textTareEstate.TextAlign = HorizontalAlignment.Right;
            this.textTareEstate.Enter += new EventHandler(this.textTareEstate_Enter);
            this.textTareEstate.Leave += new EventHandler(this.textTareEstate_Leave);
            this.textGrossEstate.Location = new Point(0x57, 30);
            this.textGrossEstate.Margin = new Padding(4);
            this.textGrossEstate.MaxLength = 15;
            this.textGrossEstate.Name = "textGrossEstate";
            this.textGrossEstate.Size = new Size(0x4b, 0x16);
            this.textGrossEstate.TabIndex = 0;
            this.textGrossEstate.Text = "0";
            this.textGrossEstate.TextAlign = HorizontalAlignment.Right;
            this.textGrossEstate.Enter += new EventHandler(this.textGrossEstate_Enter);
            this.textGrossEstate.Leave += new EventHandler(this.textGrossEstate_Leave);
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0xab, 0x3e);
            this.label10.Margin = new Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new Size(30, 0x11);
            this.label10.TabIndex = 9;
            this.label10.Text = "Net";
            this.label9.AutoSize = true;
            this.label9.Location = new Point(8, 0x3e);
            this.label9.Margin = new Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x26, 0x11);
            this.label9.TabIndex = 6;
            this.label9.Text = "Tare";
            this.label8.AutoSize = true;
            this.label8.Location = new Point(8, 0x21);
            this.label8.Margin = new Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x2e, 0x11);
            this.label8.TabIndex = 5;
            this.label8.Text = "Gross";
            this.label25.AutoSize = true;
            this.label25.Location = new Point(8, 0x5c);
            this.label25.Margin = new Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new Size(0x47, 0x11);
            this.label25.TabIndex = 7;
            this.label25.Text = "Dlvr. Date";
            this.dateDelivery.Format = DateTimePickerFormat.Short;
            this.dateDelivery.Location = new Point(0x57, 90);
            this.dateDelivery.Margin = new Padding(4);
            this.dateDelivery.Name = "dateDelivery";
            this.dateDelivery.Size = new Size(0x87, 0x16);
            this.dateDelivery.TabIndex = 2;
            this.TimeDelivery.Location = new Point(0xe7, 90);
            this.TimeDelivery.Margin = new Padding(4);
            this.TimeDelivery.Mask = "00:00";
            this.TimeDelivery.Name = "TimeDelivery";
            this.TimeDelivery.Size = new Size(0x35, 0x16);
            this.TimeDelivery.TabIndex = 3;
            this.TimeDelivery.ValidatingType = typeof(DateTime);
            this.groupFactoryWeight.Controls.Add(this.panel4X);
            this.groupFactoryWeight.Controls.Add(this.textDate1st);
            this.groupFactoryWeight.Controls.Add(this.textTime2nd);
            this.groupFactoryWeight.Controls.Add(this.textNET1);
            this.groupFactoryWeight.Controls.Add(this.textTime1st);
            this.groupFactoryWeight.Controls.Add(this.textDate2nd);
            this.groupFactoryWeight.Controls.Add(this.text2nd);
            this.groupFactoryWeight.Controls.Add(this.text1st);
            this.groupFactoryWeight.Controls.Add(this.label11);
            this.groupFactoryWeight.Controls.Add(this.label12);
            this.groupFactoryWeight.Controls.Add(this.label13);
            this.groupFactoryWeight.Controls.Add(this.TimeRegister);
            this.groupFactoryWeight.Controls.Add(this.dateRegister);
            this.groupFactoryWeight.Controls.Add(this.label26);
            this.groupFactoryWeight.Location = new Point(0x158, 0x155);
            this.groupFactoryWeight.Margin = new Padding(4);
            this.groupFactoryWeight.Name = "groupFactoryWeight";
            this.groupFactoryWeight.Padding = new Padding(4);
            this.groupFactoryWeight.Size = new Size(0x275, 160);
            this.groupFactoryWeight.TabIndex = 7;
            this.groupFactoryWeight.TabStop = false;
            this.groupFactoryWeight.Text = "[ Factory Weigh ]";
            this.panel4X.Controls.Add(this.label16);
            this.panel4X.Controls.Add(this.textTime4th);
            this.panel4X.Controls.Add(this.label15);
            this.panel4X.Controls.Add(this.textTime3rd);
            this.panel4X.Controls.Add(this.textNET2);
            this.panel4X.Controls.Add(this.label14);
            this.panel4X.Controls.Add(this.text4th);
            this.panel4X.Controls.Add(this.textDate3rd);
            this.panel4X.Controls.Add(this.textDate4th);
            this.panel4X.Controls.Add(this.text3rd);
            this.panel4X.Location = new Point(0x133, 20);
            this.panel4X.Margin = new Padding(4);
            this.panel4X.Name = "panel4X";
            this.panel4X.Size = new Size(0x137, 0x5f);
            this.panel4X.TabIndex = 13;
            this.label16.AutoSize = true;
            this.label16.Location = new Point(4, 15);
            this.label16.Margin = new Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new Size(0x1d, 0x11);
            this.label16.TabIndex = 6;
            this.label16.Text = "3rd";
            this.textTime4th.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textTime4th.Location = new Point(0xe5, 0x25);
            this.textTime4th.Margin = new Padding(4);
            this.textTime4th.MaxLength = 8;
            this.textTime4th.Name = "textTime4th";
            this.textTime4th.ReadOnly = true;
            this.textTime4th.Size = new Size(0x44, 0x16);
            this.textTime4th.TabIndex = 5;
            this.label15.AutoSize = true;
            this.label15.Location = new Point(4, 0x2b);
            this.label15.Margin = new Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x1c, 0x11);
            this.label15.TabIndex = 7;
            this.label15.Text = "4th";
            this.textTime3rd.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textTime3rd.Location = new Point(0xe5, 11);
            this.textTime3rd.Margin = new Padding(4);
            this.textTime3rd.MaxLength = 8;
            this.textTime3rd.Name = "textTime3rd";
            this.textTime3rd.ReadOnly = true;
            this.textTime3rd.Size = new Size(0x44, 0x16);
            this.textTime3rd.TabIndex = 4;
            this.textTime3rd.Leave += new EventHandler(this.textTime3rd_Leave);
            this.textNET2.BackColor = Color.Silver;
            this.textNET2.Location = new Point(0x29, 0x42);
            this.textNET2.Margin = new Padding(4);
            this.textNET2.MaxLength = 15;
            this.textNET2.Name = "textNET2";
            this.textNET2.ReadOnly = true;
            this.textNET2.Size = new Size(80, 0x16);
            this.textNET2.TabIndex = 9;
            this.textNET2.Text = "0";
            this.textNET2.TextAlign = HorizontalAlignment.Right;
            this.label14.AutoSize = true;
            this.label14.Location = new Point(4, 70);
            this.label14.Margin = new Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new Size(30, 0x11);
            this.label14.TabIndex = 8;
            this.label14.Text = "Net";
            this.text4th.Location = new Point(0x29, 0x27);
            this.text4th.Margin = new Padding(4);
            this.text4th.MaxLength = 15;
            this.text4th.Name = "text4th";
            this.text4th.Size = new Size(80, 0x16);
            this.text4th.TabIndex = 1;
            this.text4th.Text = "0";
            this.text4th.TextAlign = HorizontalAlignment.Right;
            this.text4th.Leave += new EventHandler(this.text4th_Leave);
            this.textDate3rd.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textDate3rd.Location = new Point(0x83, 11);
            this.textDate3rd.Margin = new Padding(4);
            this.textDate3rd.MaxLength = 10;
            this.textDate3rd.Name = "textDate3rd";
            this.textDate3rd.ReadOnly = true;
            this.textDate3rd.Size = new Size(0x59, 0x16);
            this.textDate3rd.TabIndex = 2;
            this.textDate3rd.Leave += new EventHandler(this.textDate3rd_Leave);
            this.textDate4th.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textDate4th.Location = new Point(0x83, 0x25);
            this.textDate4th.Margin = new Padding(4);
            this.textDate4th.MaxLength = 10;
            this.textDate4th.Name = "textDate4th";
            this.textDate4th.ReadOnly = true;
            this.textDate4th.Size = new Size(0x59, 0x16);
            this.textDate4th.TabIndex = 3;
            this.textDate4th.Leave += new EventHandler(this.textDate4th_Leave);
            this.text3rd.Location = new Point(0x29, 11);
            this.text3rd.Margin = new Padding(4);
            this.text3rd.MaxLength = 15;
            this.text3rd.Name = "text3rd";
            this.text3rd.Size = new Size(80, 0x16);
            this.text3rd.TabIndex = 0;
            this.text3rd.Text = "0";
            this.text3rd.TextAlign = HorizontalAlignment.Right;
            this.text3rd.Leave += new EventHandler(this.text3rd_Leave);
            this.textDate1st.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textDate1st.Location = new Point(140, 30);
            this.textDate1st.Margin = new Padding(4);
            this.textDate1st.MaxLength = 10;
            this.textDate1st.Name = "textDate1st";
            this.textDate1st.ReadOnly = true;
            this.textDate1st.Size = new Size(0x59, 0x16);
            this.textDate1st.TabIndex = 2;
            this.textDate1st.Text = "08/08/2013";
            this.textDate1st.Leave += new EventHandler(this.textDate1st_Leave);
            this.textTime2nd.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textTime2nd.Location = new Point(0xe9, 0x39);
            this.textTime2nd.Margin = new Padding(4);
            this.textTime2nd.MaxLength = 8;
            this.textTime2nd.Name = "textTime2nd";
            this.textTime2nd.ReadOnly = true;
            this.textTime2nd.Size = new Size(0x44, 0x16);
            this.textTime2nd.TabIndex = 5;
            this.textTime2nd.Leave += new EventHandler(this.textTime2nd_Leave);
            this.textNET1.BackColor = Color.Silver;
            this.textNET1.Location = new Point(0x37, 0x55);
            this.textNET1.Margin = new Padding(4);
            this.textNET1.MaxLength = 15;
            this.textNET1.Name = "textNET1";
            this.textNET1.ReadOnly = true;
            this.textNET1.Size = new Size(0x4c, 0x16);
            this.textNET1.TabIndex = 12;
            this.textNET1.Text = "0";
            this.textNET1.TextAlign = HorizontalAlignment.Right;
            this.textTime1st.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textTime1st.Location = new Point(0xe9, 30);
            this.textTime1st.Margin = new Padding(4);
            this.textTime1st.MaxLength = 8;
            this.textTime1st.Name = "textTime1st";
            this.textTime1st.ReadOnly = true;
            this.textTime1st.Size = new Size(0x44, 0x16);
            this.textTime1st.TabIndex = 4;
            this.textTime1st.Text = "24:59:59";
            this.textTime1st.Leave += new EventHandler(this.textTime1st_Leave);
            this.textDate2nd.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textDate2nd.Location = new Point(140, 0x39);
            this.textDate2nd.Margin = new Padding(4);
            this.textDate2nd.MaxLength = 10;
            this.textDate2nd.Name = "textDate2nd";
            this.textDate2nd.ReadOnly = true;
            this.textDate2nd.Size = new Size(0x59, 0x16);
            this.textDate2nd.TabIndex = 3;
            this.textDate2nd.Leave += new EventHandler(this.textDate2nd_Leave);
            this.text2nd.Location = new Point(0x37, 0x3a);
            this.text2nd.Margin = new Padding(4);
            this.text2nd.MaxLength = 15;
            this.text2nd.Name = "text2nd";
            this.text2nd.Size = new Size(0x4c, 0x16);
            this.text2nd.TabIndex = 1;
            this.text2nd.Text = "0";
            this.text2nd.TextAlign = HorizontalAlignment.Right;
            this.text2nd.TextChanged += new EventHandler(this.text2nd_TextChanged);
            this.text2nd.Leave += new EventHandler(this.text2nd_Leave);
            this.text1st.Location = new Point(0x37, 30);
            this.text1st.Margin = new Padding(4);
            this.text1st.MaxLength = 15;
            this.text1st.Name = "text1st";
            this.text1st.Size = new Size(0x4c, 0x16);
            this.text1st.TabIndex = 0;
            this.text1st.Text = "0";
            this.text1st.TextAlign = HorizontalAlignment.Right;
            this.text1st.TextChanged += new EventHandler(this.text1st_TextChanged);
            this.text1st.Leave += new EventHandler(this.text1st_Leave);
            this.label11.AutoSize = true;
            this.label11.Location = new Point(5, 0x59);
            this.label11.Margin = new Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new Size(30, 0x11);
            this.label11.TabIndex = 10;
            this.label11.Text = "Net";
            this.label12.AutoSize = true;
            this.label12.Location = new Point(5, 0x3e);
            this.label12.Margin = new Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x20, 0x11);
            this.label12.TabIndex = 9;
            this.label12.Text = "2nd";
            this.label13.AutoSize = true;
            this.label13.Location = new Point(5, 0x21);
            this.label13.Margin = new Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x1b, 0x11);
            this.label13.TabIndex = 8;
            this.label13.Text = "1st";
            this.TimeRegister.Location = new Point(0x101, 0x80);
            this.TimeRegister.Margin = new Padding(4);
            this.TimeRegister.Mask = "00:00";
            this.TimeRegister.Name = "TimeRegister";
            this.TimeRegister.Size = new Size(0x35, 0x16);
            this.TimeRegister.TabIndex = 7;
            this.TimeRegister.ValidatingType = typeof(DateTime);
            this.dateRegister.Format = DateTimePickerFormat.Short;
            this.dateRegister.Location = new Point(140, 0x80);
            this.dateRegister.Margin = new Padding(4);
            this.dateRegister.Name = "dateRegister";
            this.dateRegister.Size = new Size(0x6c, 0x16);
            this.dateRegister.TabIndex = 6;
            this.label26.AutoSize = true;
            this.label26.Cursor = Cursors.Arrow;
            this.label26.Location = new Point(20, 0x84);
            this.label26.Margin = new Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new Size(0x5f, 0x11);
            this.label26.TabIndex = 11;
            this.label26.Text = "Register Date";
            this.textDeducTotal.Location = new Point(0x43c, 0x161);
            this.textDeducTotal.Margin = new Padding(4);
            this.textDeducTotal.MaxLength = 15;
            this.textDeducTotal.Name = "textDeducTotal";
            this.textDeducTotal.ReadOnly = true;
            this.textDeducTotal.Size = new Size(0x6f, 0x16);
            this.textDeducTotal.TabIndex = 11;
            this.textDeducTotal.Text = "0";
            this.textDeducTotal.TextAlign = HorizontalAlignment.Right;
            this.label17.AutoSize = true;
            this.label17.Location = new Point(0x3f1, 0x165);
            this.label17.Margin = new Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new Size(0x48, 0x11);
            this.label17.TabIndex = 0x17;
            this.label17.Text = "Deduction";
            this.textNet.BackColor = Color.Silver;
            this.textNet.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textNet.Location = new Point(0x3f5, 0x1a0);
            this.textNet.Margin = new Padding(4);
            this.textNet.MaxLength = 15;
            this.textNet.Name = "textNet";
            this.textNet.ReadOnly = true;
            this.textNet.Size = new Size(0xb1, 0x22);
            this.textNet.TabIndex = 12;
            this.textNet.Text = "0";
            this.textNet.TextAlign = HorizontalAlignment.Right;
            this.textNet.TextChanged += new EventHandler(this.textNet_TextChanged);
            this.label18.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label18.Location = new Point(0x3d5, 0x17e);
            this.label18.Margin = new Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new Size(0xd3, 30);
            this.label18.TabIndex = 0x18;
            this.label18.Text = "NET";
            this.label18.TextAlign = ContentAlignment.TopRight;
            this.textSEAL.Location = new Point(0x99, 0x13f);
            this.textSEAL.Margin = new Padding(4);
            this.textSEAL.MaxLength = 100;
            this.textSEAL.Name = "textSEAL";
            this.textSEAL.Size = new Size(0x241, 0x16);
            this.textSEAL.TabIndex = 5;
            this.label19.Location = new Point(3, 0x142);
            this.label19.Margin = new Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new Size(0x90, 0x10);
            this.label19.TabIndex = 0x11;
            this.label19.Text = "SEAL";
            this.label19.TextAlign = ContentAlignment.TopRight;
            this.textReport_Date.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textReport_Date.Location = new Point(0x42f, 0x49);
            this.textReport_Date.Margin = new Padding(4);
            this.textReport_Date.MaxLength = 10;
            this.textReport_Date.Name = "textReport_Date";
            this.textReport_Date.ReadOnly = true;
            this.textReport_Date.Size = new Size(0x87, 0x16);
            this.textReport_Date.TabIndex = 7;
            this.textReport_Date.Leave += new EventHandler(this.textReport_Date_Leave);
            this.label37.Location = new Point(880, 0x4c);
            this.label37.Margin = new Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new Size(0xb5, 0x16);
            this.label37.TabIndex = 14;
            this.label37.Text = "Report Date";
            this.label37.TextAlign = ContentAlignment.TopRight;
            this.textRefNo.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textRefNo.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textRefNo.Location = new Point(0x3b7, 5);
            this.textRefNo.Margin = new Padding(4);
            this.textRefNo.MaxLength = 0x10;
            this.textRefNo.Name = "textRefNo";
            this.textRefNo.Size = new Size(0x100, 30);
            this.textRefNo.TabIndex = 0x63;
            this.textRefNo.Text = "PANMNAKTJ0002420A";
            this.textRefNo.TextAlign = HorizontalAlignment.Right;
            this.textRefNo.KeyPress += new KeyPressEventHandler(this.textRefNo_KeyPress);
            this.textRefNo.Leave += new EventHandler(this.textRefNo_Leave);
            this.textRef_Date.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textRef_Date.Location = new Point(0x42f, 0x2a);
            this.textRef_Date.Margin = new Padding(4);
            this.textRef_Date.Name = "textRef_Date";
            this.textRef_Date.ReadOnly = true;
            this.textRef_Date.Size = new Size(0x87, 0x16);
            this.textRef_Date.TabIndex = 20;
            this.textRef_Date.Text = "08/08/2013";
            this.label35.Location = new Point(0x394, 0x2e);
            this.label35.Margin = new Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new Size(0x8f, 0x17);
            this.label35.TabIndex = 0x15;
            this.label35.Text = "Ref Date";
            this.label35.TextAlign = ContentAlignment.TopRight;
            this.labelTransTypeName.AutoSize = true;
            this.labelTransTypeName.Cursor = Cursors.Arrow;
            this.labelTransTypeName.Location = new Point(0x147, 0x2f);
            this.labelTransTypeName.Margin = new Padding(4, 0, 4, 0);
            this.labelTransTypeName.Name = "labelTransTypeName";
            this.labelTransTypeName.Size = new Size(0x7e, 0x11);
            this.labelTransTypeName.TabIndex = 0x16;
            this.labelTransTypeName.Text = "Trans Type Name ";
            this.comTransType.Enabled = false;
            this.comTransType.FormattingEnabled = true;
            this.comTransType.Location = new Point(0x9c, 0x2b);
            this.comTransType.Margin = new Padding(4);
            this.comTransType.Name = "comTransType";
            this.comTransType.Size = new Size(0xa3, 0x18);
            this.comTransType.TabIndex = 10;
            this.comTransType.SelectedIndexChanged += new EventHandler(this.comTransType_SelectedIndexChanged);
            this.comTransType.KeyPress += new KeyPressEventHandler(this.comTransType_KeyPress);
            this.comTransType.Leave += new EventHandler(this.comTransType_Leave);
            this.labelTransType.Cursor = Cursors.Arrow;
            this.labelTransType.Location = new Point(4, 0x2f);
            this.labelTransType.Margin = new Padding(4, 0, 4, 0);
            this.labelTransType.Name = "labelTransType";
            this.labelTransType.Size = new Size(0x90, 0x10);
            this.labelTransType.TabIndex = 0x13;
            this.labelTransType.Text = "Transaction Type";
            this.labelTransType.TextAlign = ContentAlignment.TopRight;
            this.buttonSave.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonSave.Location = new Point(0x407, 130);
            this.buttonSave.Margin = new Padding(4);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0xa1, 0x25);
            this.buttonSave.TabIndex = 10;
            this.buttonSave.Text = "&Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.buttonSavePrint.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonSavePrint.Location = new Point(0x407, 0xaf);
            this.buttonSavePrint.Margin = new Padding(4);
            this.buttonSavePrint.Name = "buttonSavePrint";
            this.buttonSavePrint.Size = new Size(0xa1, 60);
            this.buttonSavePrint.TabIndex = 11;
            this.buttonSavePrint.Text = "Save && &Print";
            this.buttonSavePrint.UseVisualStyleBackColor = true;
            this.buttonSavePrint.Click += new EventHandler(this.buttonSavePrint_Click);
            this.buttonCancel.Location = new Point(0x407, 0xf2);
            this.buttonCancel.Margin = new Padding(4);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0xa1, 0x25);
            this.buttonCancel.TabIndex = 7;
            this.buttonCancel.Text = "&Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.buttonReset.Location = new Point(0x411, 0x1eb);
            this.buttonReset.Margin = new Padding(4);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new Size(0xa1, 0x25);
            this.buttonReset.TabIndex = 12;
            this.buttonReset.Text = "Reset &Indicator";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Visible = false;
            this.buttonReadIndicator.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonReadIndicator.Location = new Point(0x407, 0x11f);
            this.buttonReadIndicator.Margin = new Padding(4);
            this.buttonReadIndicator.Name = "buttonReadIndicator";
            this.buttonReadIndicator.Size = new Size(0xa1, 0x3b);
            this.buttonReadIndicator.TabIndex = 9;
            this.buttonReadIndicator.Text = "&Read Indicator";
            this.buttonReadIndicator.UseVisualStyleBackColor = true;
            this.buttonReadIndicator.Click += new EventHandler(this.button5_Click);
            this.buttonTruck.Location = new Point(0x144, 0x4a);
            this.buttonTruck.Margin = new Padding(0);
            this.buttonTruck.Name = "buttonTruck";
            this.buttonTruck.Size = new Size(0x1f, 0x1c);
            this.buttonTruck.TabIndex = 1;
            this.buttonTruck.Text = "...";
            this.buttonTruck.UseVisualStyleBackColor = true;
            this.buttonTruck.Click += new EventHandler(this.button9_Click);
            this.textTruck.CharacterCasing = CharacterCasing.Upper;
            this.textTruck.Location = new Point(0x9b, 0x4c);
            this.textTruck.Margin = new Padding(4);
            this.textTruck.MaxLength = 20;
            this.textTruck.Name = "textTruck";
            this.textTruck.Size = new Size(0xa3, 0x16);
            this.textTruck.TabIndex = 0;
            this.textTruck.Enter += new EventHandler(this.textTruck_Enter);
            this.textTruck.KeyPress += new KeyPressEventHandler(this.textTruck_KeyPress);
            this.textTruck.Leave += new EventHandler(this.textTruck_Leave);
            this.textDriverID.CharacterCasing = CharacterCasing.Upper;
            this.textDriverID.Location = new Point(0x9b, 0x6c);
            this.textDriverID.Margin = new Padding(4);
            this.textDriverID.MaxLength = 50;
            this.textDriverID.Name = "textDriverID";
            this.textDriverID.Size = new Size(0xa3, 0x16);
            this.textDriverID.TabIndex = 4;
            this.textDriverID.KeyPress += new KeyPressEventHandler(this.textDriverID_KeyPress);
            this.textDriverID.Leave += new EventHandler(this.textDriverID_Leave);
            this.buttonDriver.Location = new Point(0x144, 0x6a);
            this.buttonDriver.Margin = new Padding(0);
            this.buttonDriver.Name = "buttonDriver";
            this.buttonDriver.Size = new Size(0x1f, 0x1c);
            this.buttonDriver.TabIndex = 5;
            this.buttonDriver.Text = "...";
            this.buttonDriver.UseVisualStyleBackColor = true;
            this.buttonDriver.Click += new EventHandler(this.button10_Click);
            this.buttonTransporter.Location = new Point(0x144, 0x8b);
            this.buttonTransporter.Margin = new Padding(0);
            this.buttonTransporter.Name = "buttonTransporter";
            this.buttonTransporter.Size = new Size(0x1f, 0x1c);
            this.buttonTransporter.TabIndex = 14;
            this.buttonTransporter.Text = "...";
            this.buttonTransporter.UseVisualStyleBackColor = true;
            this.buttonTransporter.Click += new EventHandler(this.button11_Click);
            this.textTransporter.CharacterCasing = CharacterCasing.Upper;
            this.textTransporter.Location = new Point(0x9b, 0x8d);
            this.textTransporter.Margin = new Padding(4);
            this.textTransporter.MaxLength = 20;
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.Size = new Size(0xa1, 0x16);
            this.textTransporter.TabIndex = 13;
            this.textTransporter.TextChanged += new EventHandler(this.textTransporter_TextChanged);
            this.textTransporter.KeyPress += new KeyPressEventHandler(this.textTransporter_KeyPress);
            this.buttonTanker.Location = new Point(0x33f, 0x6a);
            this.buttonTanker.Margin = new Padding(0);
            this.buttonTanker.Name = "buttonTanker";
            this.buttonTanker.Size = new Size(0x1f, 0x1c);
            this.buttonTanker.TabIndex = 30;
            this.buttonTanker.Text = "...";
            this.buttonTanker.UseVisualStyleBackColor = true;
            this.buttonTanker.Click += new EventHandler(this.button12_Click);
            this.textTanker.CharacterCasing = CharacterCasing.Upper;
            this.textTanker.Location = new Point(0x284, 0x6c);
            this.textTanker.Margin = new Padding(4);
            this.textTanker.Name = "textTanker";
            this.textTanker.ReadOnly = true;
            this.textTanker.Size = new Size(0xb5, 0x16);
            this.textTanker.TabIndex = 7;
            this.textTanker.KeyPress += new KeyPressEventHandler(this.textTanker_KeyPress);
            this.label33.AutoSize = true;
            this.label33.Cursor = Cursors.Arrow;
            this.label33.Location = new Point(0x2e7, 0xdb);
            this.label33.Margin = new Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new Size(0x71, 0x11);
            this.label33.TabIndex = 0x12;
            this.label33.Text = "Commodity Type";
            this.label33.Visible = false;
            this.textCommType.CharacterCasing = CharacterCasing.Upper;
            this.textCommType.Location = new Point(0x360, 0xd7);
            this.textCommType.Margin = new Padding(4);
            this.textCommType.Name = "textCommType";
            this.textCommType.ReadOnly = true;
            this.textCommType.Size = new Size(0x1b, 0x16);
            this.textCommType.TabIndex = 0x2e;
            this.textCommType.Visible = false;
            this.textVariance.Location = new Point(0x438, 0x1cb);
            this.textVariance.Margin = new Padding(4);
            this.textVariance.MaxLength = 15;
            this.textVariance.Name = "textVariance";
            this.textVariance.ReadOnly = true;
            this.textVariance.Size = new Size(0x6f, 0x16);
            this.textVariance.TabIndex = 13;
            this.textVariance.Text = "0";
            this.textVariance.TextAlign = HorizontalAlignment.Right;
            this.label45.AutoSize = true;
            this.label45.Location = new Point(0x414, 0x1cf);
            this.label45.Margin = new Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new Size(0x19, 0x11);
            this.label45.TabIndex = 0x19;
            this.label45.Text = "+/-";
            this.textTrailerNo.CharacterCasing = CharacterCasing.Upper;
            this.textTrailerNo.Location = new Point(0x284, 0x4c);
            this.textTrailerNo.Margin = new Padding(4);
            this.textTrailerNo.MaxLength = 20;
            this.textTrailerNo.Name = "textTrailerNo";
            this.textTrailerNo.Size = new Size(0xb5, 0x16);
            this.textTrailerNo.TabIndex = 3;
            this.textTrailerNo.KeyPress += new KeyPressEventHandler(this.textTrailerNo_KeyPress);
            this.label46.AutoSize = true;
            this.label46.Location = new Point(0x237, 80);
            this.label46.Margin = new Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new Size(0x4b, 0x11);
            this.label46.TabIndex = 0x19;
            this.label46.Text = "Trailer No.";
            this.textDriverName.CharacterCasing = CharacterCasing.Upper;
            this.textDriverName.Location = new Point(0x16f, 0x6c);
            this.textDriverName.Margin = new Padding(4);
            this.textDriverName.MaxLength = 50;
            this.textDriverName.Name = "textDriverName";
            this.textDriverName.Size = new Size(0xc0, 0x16);
            this.textDriverName.TabIndex = 6;
            this.textDriverName.KeyPress += new KeyPressEventHandler(this.textDriverName_KeyPress);
            this.textDriverName.Leave += new EventHandler(this.textDriverName_Leave);
            this.checkEstate.AutoSize = true;
            this.checkEstate.Location = new Point(0x2eb, 250);
            this.checkEstate.Margin = new Padding(4);
            this.checkEstate.Name = "checkEstate";
            this.checkEstate.Size = new Size(0x8e, 0x15);
            this.checkEstate.TabIndex = 12;
            this.checkEstate.Text = "Estate is Different";
            this.checkEstate.UseVisualStyleBackColor = true;
            this.buttonTarraHistory.Location = new Point(0x279, 0xa8);
            this.buttonTarraHistory.Margin = new Padding(4);
            this.buttonTarraHistory.Name = "buttonTarraHistory";
            this.buttonTarraHistory.Size = new Size(100, 0x1c);
            this.buttonTarraHistory.TabIndex = 15;
            this.buttonTarraHistory.Text = "&Tarre History";
            this.buttonTarraHistory.UseVisualStyleBackColor = true;
            this.buttonTarraHistory.Click += new EventHandler(this.buttonTarraHistory_Click);
            this.label21.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label21.Location = new Point(0x284, 11);
            this.label21.Margin = new Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new Size(0x12b, 0x12);
            this.label21.TabIndex = 0x2f;
            this.label21.Text = "Ref No.";
            this.label21.TextAlign = ContentAlignment.TopRight;
            this.textGatepass.BackColor = SystemColors.Control;
            this.textGatepass.CharacterCasing = CharacterCasing.Upper;
            this.textGatepass.Location = new Point(0x9c, 11);
            this.textGatepass.Margin = new Padding(4);
            this.textGatepass.MaxLength = 20;
            this.textGatepass.Name = "textGatepass";
            this.textGatepass.Size = new Size(0xa3, 0x16);
            this.textGatepass.TabIndex = 0x31;
            this.labelGatepass.Location = new Point(4, 15);
            this.labelGatepass.Margin = new Padding(4, 0, 4, 0);
            this.labelGatepass.Name = "labelGatepass";
            this.labelGatepass.Size = new Size(0x90, 0x15);
            this.labelGatepass.TabIndex = 0x30;
            this.labelGatepass.Text = "Gatepass No.";
            this.labelGatepass.TextAlign = ContentAlignment.TopRight;
            this.textGPManual.BackColor = SystemColors.Control;
            this.textGPManual.CharacterCasing = CharacterCasing.Upper;
            this.textGPManual.Location = new Point(0x157, 11);
            this.textGPManual.Margin = new Padding(4);
            this.textGPManual.MaxLength = 20;
            this.textGPManual.Name = "textGPManual";
            this.textGPManual.Size = new Size(0xbf, 0x16);
            this.textGPManual.TabIndex = 50;
            this.tabPageBag.BackColor = SystemColors.ButtonFace;
            this.tabPageBag.Controls.Add(this.label67);
            this.tabPageBag.Controls.Add(this.labelBagWeight);
            this.tabPageBag.Controls.Add(this.label66);
            this.tabPageBag.Controls.Add(this.labelBagDesc);
            this.tabPageBag.Controls.Add(this.buttonBag);
            this.tabPageBag.Controls.Add(this.textTotalBagWeight);
            this.tabPageBag.Controls.Add(this.textTotalBag);
            this.tabPageBag.Controls.Add(this.textBagCode);
            this.tabPageBag.Controls.Add(this.checkOverrideBag);
            this.tabPageBag.Controls.Add(this.label65);
            this.tabPageBag.Controls.Add(this.label64);
            this.tabPageBag.Controls.Add(this.label61);
            this.tabPageBag.Controls.Add(this.shapeContainer1);
            this.tabPageBag.Location = new Point(4, 0x19);
            this.tabPageBag.Margin = new Padding(4);
            this.tabPageBag.Name = "tabPageBag";
            this.tabPageBag.Padding = new Padding(4);
            this.tabPageBag.Size = new Size(0x4b4, 0x107);
            this.tabPageBag.TabIndex = 9;
            this.tabPageBag.Text = "Bag Deduction";
            this.label67.AutoSize = true;
            this.label67.Location = new Point(0x16b, 0x44);
            this.label67.Margin = new Padding(4, 0, 4, 0);
            this.label67.Name = "label67";
            this.label67.Size = new Size(0x1c, 0x11);
            this.label67.TabIndex = 12;
            this.label67.Text = "KG";
            this.labelBagWeight.Location = new Point(0x123, 0x44);
            this.labelBagWeight.Margin = new Padding(4, 0, 4, 0);
            this.labelBagWeight.Name = "labelBagWeight";
            this.labelBagWeight.Size = new Size(0x3f, 0x10);
            this.labelBagWeight.TabIndex = 11;
            this.labelBagWeight.Text = "0";
            this.labelBagWeight.TextAlign = ContentAlignment.MiddleRight;
            this.label66.AutoSize = true;
            this.label66.Location = new Point(0x10b, 0x44);
            this.label66.Margin = new Padding(4, 0, 4, 0);
            this.label66.Name = "label66";
            this.label66.Size = new Size(14, 0x11);
            this.label66.TabIndex = 10;
            this.label66.Text = "x";
            this.labelBagDesc.AutoSize = true;
            this.labelBagDesc.Location = new Point(0x18f, 0x1b);
            this.labelBagDesc.Margin = new Padding(4, 0, 4, 0);
            this.labelBagDesc.Name = "labelBagDesc";
            this.labelBagDesc.Size = new Size(0x45, 0x11);
            this.labelBagDesc.TabIndex = 9;
            this.labelBagDesc.Text = "Bag Desc";
            this.buttonBag.Location = new Point(0x16b, 0x15);
            this.buttonBag.Margin = new Padding(0);
            this.buttonBag.Name = "buttonBag";
            this.buttonBag.Size = new Size(0x1f, 0x1c);
            this.buttonBag.TabIndex = 8;
            this.buttonBag.Text = "...";
            this.buttonBag.UseVisualStyleBackColor = true;
            this.buttonBag.Click += new EventHandler(this.buttonBag_Click);
            this.textTotalBagWeight.Location = new Point(0xa1, 0x6c);
            this.textTotalBagWeight.Margin = new Padding(4);
            this.textTotalBagWeight.Name = "textTotalBagWeight";
            this.textTotalBagWeight.ReadOnly = true;
            this.textTotalBagWeight.Size = new Size(0x88, 0x16);
            this.textTotalBagWeight.TabIndex = 7;
            this.textTotalBagWeight.Text = "0";
            this.textTotalBagWeight.TextAlign = HorizontalAlignment.Right;
            this.textTotalBagWeight.Leave += new EventHandler(this.textTotalBagWeight_Leave);
            this.textTotalBag.Location = new Point(160, 0x40);
            this.textTotalBag.Margin = new Padding(4);
            this.textTotalBag.MaxLength = 5;
            this.textTotalBag.Name = "textTotalBag";
            this.textTotalBag.Size = new Size(0x61, 0x16);
            this.textTotalBag.TabIndex = 6;
            this.textTotalBag.Text = "0";
            this.textTotalBag.TextAlign = HorizontalAlignment.Right;
            this.textTotalBag.TextChanged += new EventHandler(this.textTotalBag_TextChanged);
            this.textTotalBag.Leave += new EventHandler(this.textTotalBag_Leave);
            this.textBagCode.Location = new Point(0xa1, 0x17);
            this.textBagCode.Margin = new Padding(4);
            this.textBagCode.Name = "textBagCode";
            this.textBagCode.Size = new Size(0xc0, 0x16);
            this.textBagCode.TabIndex = 5;
            this.textBagCode.Leave += new EventHandler(this.textBagCode_Leave);
            this.checkOverrideBag.AutoSize = true;
            this.checkOverrideBag.Location = new Point(0x133, 0x6f);
            this.checkOverrideBag.Margin = new Padding(4);
            this.checkOverrideBag.Name = "checkOverrideBag";
            this.checkOverrideBag.Size = new Size(0xa2, 0x15);
            this.checkOverrideBag.TabIndex = 3;
            this.checkOverrideBag.Text = "Override Bag Weight";
            this.checkOverrideBag.UseVisualStyleBackColor = true;
            this.checkOverrideBag.CheckedChanged += new EventHandler(this.checkOverrideBag_CheckedChanged);
            this.label65.AutoSize = true;
            this.label65.Location = new Point(0x1d, 0x70);
            this.label65.Margin = new Padding(4, 0, 4, 0);
            this.label65.Name = "label65";
            this.label65.Size = new Size(0x75, 0x11);
            this.label65.TabIndex = 2;
            this.label65.Text = "Total Bag Weight";
            this.label64.AutoSize = true;
            this.label64.Location = new Point(0x51, 0x44);
            this.label64.Margin = new Padding(4, 0, 4, 0);
            this.label64.Name = "label64";
            this.label64.Size = new Size(0x45, 0x11);
            this.label64.TabIndex = 1;
            this.label64.Text = "Total Bag";
            this.label61.AutoSize = true;
            this.label61.Location = new Point(0x51, 0x1b);
            this.label61.Margin = new Padding(4, 0, 4, 0);
            this.label61.Name = "label61";
            this.label61.Size = new Size(70, 0x11);
            this.label61.TabIndex = 0;
            this.label61.Text = "Bag Code";
            this.shapeContainer1.Location = new Point(4, 4);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.lineShape1 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(0x4ac, 0xff);
            this.shapeContainer1.TabIndex = 4;
            this.shapeContainer1.TabStop = false;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 0x17;
            this.lineShape1.X2 = 0x15b;
            this.lineShape1.Y1 = 0x4d;
            this.lineShape1.Y2 = 0x4d;
            this.tabPageDL.BackColor = SystemColors.Control;
            this.tabPageDL.Controls.Add(this.button19);
            this.tabPageDL.Controls.Add(this.textNettoBatchLeft);
            this.tabPageDL.Controls.Add(this.textGunnyBatchLeft);
            this.tabPageDL.Controls.Add(this.textDL);
            this.tabPageDL.Controls.Add(this.textBox1);
            this.tabPageDL.Controls.Add(this.textSTO);
            this.tabPageDL.Controls.Add(this.label51);
            this.tabPageDL.Controls.Add(this.label53);
            this.tabPageDL.Controls.Add(this.label52);
            this.tabPageDL.Controls.Add(this.buttonAdopt);
            this.tabPageDL.Controls.Add(this.label56);
            this.tabPageDL.Controls.Add(this.label55);
            this.tabPageDL.Controls.Add(this.label54);
            this.tabPageDL.Controls.Add(this.groupBox2);
            this.tabPageDL.Controls.Add(this.button20);
            this.tabPageDL.Controls.Add(this.groupBox1);
            this.tabPageDL.Controls.Add(this.button18);
            this.tabPageDL.Controls.Add(this.label28);
            this.tabPageDL.Controls.Add(this.dgvBatch);
            this.tabPageDL.Controls.Add(this.shapeContainer4);
            this.tabPageDL.Location = new Point(4, 0x19);
            this.tabPageDL.Margin = new Padding(4);
            this.tabPageDL.Name = "tabPageDL";
            this.tabPageDL.Padding = new Padding(4);
            this.tabPageDL.Size = new Size(0x4b4, 0x107);
            this.tabPageDL.TabIndex = 8;
            this.tabPageDL.Text = "Delivery Letter";
            this.button19.Location = new Point(0x234, 210);
            this.button19.Margin = new Padding(4);
            this.button19.Name = "button19";
            this.button19.Size = new Size(0x6c, 0x22);
            this.button19.TabIndex = 0x3a;
            this.button19.Text = "Split Batch";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new EventHandler(this.button19_Click);
            this.textNettoBatchLeft.Enabled = false;
            this.textNettoBatchLeft.Location = new Point(0x327, 0xe7);
            this.textNettoBatchLeft.Margin = new Padding(4);
            this.textNettoBatchLeft.MaxLength = 20;
            this.textNettoBatchLeft.Name = "textNettoBatchLeft";
            this.textNettoBatchLeft.Size = new Size(140, 0x16);
            this.textNettoBatchLeft.TabIndex = 0x16;
            this.textNettoBatchLeft.Text = "0";
            this.textNettoBatchLeft.Visible = false;
            this.textGunnyBatchLeft.Enabled = false;
            this.textGunnyBatchLeft.Location = new Point(0x327, 0xcf);
            this.textGunnyBatchLeft.Margin = new Padding(4);
            this.textGunnyBatchLeft.MaxLength = 20;
            this.textGunnyBatchLeft.Name = "textGunnyBatchLeft";
            this.textGunnyBatchLeft.Size = new Size(0x4b, 0x16);
            this.textGunnyBatchLeft.TabIndex = 0x18;
            this.textGunnyBatchLeft.Text = "0";
            this.textGunnyBatchLeft.Visible = false;
            this.textDL.Location = new Point(0x70, 20);
            this.textDL.Margin = new Padding(4);
            this.textDL.Name = "textDL";
            this.textDL.Size = new Size(0x79, 0x16);
            this.textDL.TabIndex = 0x38;
            this.textDL.Leave += new EventHandler(this.textDL_Leave);
            this.textBox1.Enabled = false;
            this.textBox1.Location = new Point(0x413, 0xcf);
            this.textBox1.Margin = new Padding(4);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0x6f, 0x16);
            this.textBox1.TabIndex = 0x34;
            this.textSTO.Location = new Point(0x70, 0x3a);
            this.textSTO.Margin = new Padding(4);
            this.textSTO.MaxLength = 20;
            this.textSTO.Name = "textSTO";
            this.textSTO.Size = new Size(180, 0x16);
            this.textSTO.TabIndex = 0x2c;
            this.label51.Location = new Point(0x2d1, 0xeb);
            this.label51.Margin = new Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new Size(80, 0x10);
            this.label51.TabIndex = 0x17;
            this.label51.Text = "Netto Left";
            this.label51.TextAlign = ContentAlignment.TopRight;
            this.label51.Visible = false;
            this.label53.AutoSize = true;
            this.label53.Location = new Point(0x3b8, 0xeb);
            this.label53.Margin = new Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new Size(0x1c, 0x11);
            this.label53.TabIndex = 0x1a;
            this.label53.Text = "KG";
            this.label53.Visible = false;
            this.label52.Location = new Point(0x2d3, 210);
            this.label52.Margin = new Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new Size(0x4f, 0x10);
            this.label52.TabIndex = 0x19;
            this.label52.Text = "Gunny Left";
            this.label52.TextAlign = ContentAlignment.TopRight;
            this.label52.Visible = false;
            this.buttonAdopt.Location = new Point(240, 0x12);
            this.buttonAdopt.Margin = new Padding(4);
            this.buttonAdopt.Name = "buttonAdopt";
            this.buttonAdopt.Size = new Size(0x34, 0x1b);
            this.buttonAdopt.TabIndex = 0x39;
            this.buttonAdopt.Text = "&Get";
            this.buttonAdopt.UseVisualStyleBackColor = true;
            this.buttonAdopt.Click += new EventHandler(this.buttonAdopt_Click);
            this.label56.AutoSize = true;
            this.label56.Location = new Point(8, 0x17);
            this.label56.Margin = new Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new Size(100, 0x11);
            this.label56.TabIndex = 0x37;
            this.label56.Text = "Delivery Letter";
            this.label55.AutoSize = true;
            this.label55.Location = new Point(0x484, 210);
            this.label55.Margin = new Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new Size(0x1c, 0x11);
            this.label55.TabIndex = 0x36;
            this.label55.Text = "KG";
            this.label54.AutoSize = true;
            this.label54.Location = new Point(0x39b, 210);
            this.label54.Margin = new Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new Size(0x71, 0x11);
            this.label54.TabIndex = 0x35;
            this.label54.Text = "Netto per Gunny";
            this.groupBox2.Controls.Add(this.label60);
            this.groupBox2.Controls.Add(this.label59);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.label58);
            this.groupBox2.Controls.Add(this.label57);
            this.groupBox2.Location = new Point(15, 170);
            this.groupBox2.Margin = new Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new Padding(4);
            this.groupBox2.Size = new Size(0x117, 0x4f);
            this.groupBox2.TabIndex = 50;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "WB Info";
            this.label60.AutoSize = true;
            this.label60.Location = new Point(0xf3, 0x30);
            this.label60.Margin = new Padding(4, 0, 4, 0);
            this.label60.Name = "label60";
            this.label60.Size = new Size(0x1c, 0x11);
            this.label60.TabIndex = 0x1c;
            this.label60.Text = "KG";
            this.label59.AutoSize = true;
            this.label59.Location = new Point(0xf3, 0x17);
            this.label59.Margin = new Padding(4, 0, 4, 0);
            this.label59.Name = "label59";
            this.label59.Size = new Size(0x1c, 0x11);
            this.label59.TabIndex = 0x1b;
            this.label59.Text = "KG";
            this.textBox3.Location = new Point(0x87, 0x2c);
            this.textBox3.Margin = new Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new Size(0x67, 0x16);
            this.textBox3.TabIndex = 3;
            this.textBox3.TextAlign = HorizontalAlignment.Right;
            this.textBox2.Location = new Point(0x71, 20);
            this.textBox2.Margin = new Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new Size(0x7c, 0x16);
            this.textBox2.TabIndex = 2;
            this.textBox2.TextAlign = HorizontalAlignment.Right;
            this.textBox2.TextChanged += new EventHandler(this.textBox2_TextChanged);
            this.label58.AutoSize = true;
            this.label58.Location = new Point(13, 50);
            this.label58.Margin = new Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new Size(0x71, 0x11);
            this.label58.TabIndex = 1;
            this.label58.Text = "Netto per Gunny";
            this.label57.AutoSize = true;
            this.label57.Location = new Point(13, 0x17);
            this.label57.Margin = new Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new Size(0x56, 0x11);
            this.label57.TabIndex = 0;
            this.label57.Text = "Netto Weigh";
            this.button20.Location = new Point(0x1bc, 210);
            this.button20.Margin = new Padding(4);
            this.button20.Name = "button20";
            this.button20.Size = new Size(0x6c, 0x22);
            this.button20.TabIndex = 0x30;
            this.button20.Text = "Merge Batch";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new EventHandler(this.button20_Click);
            this.groupBox1.Controls.Add(this.textNettoBatch);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.label48);
            this.groupBox1.Controls.Add(this.textGunnyBatch);
            this.groupBox1.Controls.Add(this.label50);
            this.groupBox1.Location = new Point(15, 0x51);
            this.groupBox1.Margin = new Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new Padding(4);
            this.groupBox1.Size = new Size(0x117, 0x51);
            this.groupBox1.TabIndex = 0x31;
            this.groupBox1.TabStop = false;
            this.textNettoBatch.Location = new Point(0x61, 0x31);
            this.textNettoBatch.Margin = new Padding(4);
            this.textNettoBatch.MaxLength = 20;
            this.textNettoBatch.Name = "textNettoBatch";
            this.textNettoBatch.ReadOnly = true;
            this.textNettoBatch.Size = new Size(140, 0x16);
            this.textNettoBatch.TabIndex = 0x2e;
            this.textNettoBatch.Text = "0";
            this.textNettoBatch.Leave += new EventHandler(this.textNettoBatch_Leave);
            this.label36.Location = new Point(12, 0x35);
            this.label36.Margin = new Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new Size(80, 0x10);
            this.label36.TabIndex = 0x17;
            this.label36.Text = "Netto";
            this.label36.TextAlign = ContentAlignment.TopRight;
            this.label48.Location = new Point(13, 0x16);
            this.label48.Margin = new Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new Size(80, 0x10);
            this.label48.TabIndex = 0x19;
            this.label48.Text = "Gunny";
            this.label48.TextAlign = ContentAlignment.TopRight;
            this.textGunnyBatch.Location = new Point(0x61, 0x12);
            this.textGunnyBatch.Margin = new Padding(4);
            this.textGunnyBatch.MaxLength = 20;
            this.textGunnyBatch.Name = "textGunnyBatch";
            this.textGunnyBatch.ReadOnly = true;
            this.textGunnyBatch.Size = new Size(0x4b, 0x16);
            this.textGunnyBatch.TabIndex = 0x2d;
            this.textGunnyBatch.Text = "0";
            this.label50.AutoSize = true;
            this.label50.Location = new Point(0xf3, 0x35);
            this.label50.Margin = new Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new Size(0x1c, 0x11);
            this.label50.TabIndex = 0x1a;
            this.label50.Text = "KG";
            this.button18.Location = new Point(0x145, 210);
            this.button18.Margin = new Padding(4);
            this.button18.Name = "button18";
            this.button18.Size = new Size(0x6c, 0x22);
            this.button18.TabIndex = 0x2f;
            this.button18.Text = "Add";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new EventHandler(this.button18_Click);
            this.label28.AutoSize = true;
            this.label28.Location = new Point(0x43, 0x3e);
            this.label28.Margin = new Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new Size(0x25, 0x11);
            this.label28.TabIndex = 0x2d;
            this.label28.Text = "STO";
            this.dgvBatch.AllowUserToAddRows = false;
            this.dgvBatch.AllowUserToDeleteRows = false;
            this.dgvBatch.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBatch.Location = new Point(300, 4);
            this.dgvBatch.Margin = new Padding(4);
            this.dgvBatch.Name = "dgvBatch";
            this.dgvBatch.ReadOnly = true;
            this.dgvBatch.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvBatch.Size = new Size(0x365, 0xc7);
            this.dgvBatch.TabIndex = 0x2f;
            this.dgvBatch.CellBeginEdit += new DataGridViewCellCancelEventHandler(this.dgvBatch_CellBeginEdit);
            this.dgvBatch.CellClick += new DataGridViewCellEventHandler(this.dgvBatch_CellClick);
            this.dgvBatch.CellEndEdit += new DataGridViewCellEventHandler(this.dgvBatch_CellEndEdit);
            this.shapeContainer4.Location = new Point(4, 4);
            this.shapeContainer4.Margin = new Padding(0);
            this.shapeContainer4.Name = "shapeContainer4";
            Shape[] shapeArray2 = new Shape[] { this.rectangleShape3 };
            this.shapeContainer4.Shapes.AddRange(shapeArray2);
            this.shapeContainer4.Size = new Size(0x4ac, 0xff);
            this.shapeContainer4.TabIndex = 0x33;
            this.shapeContainer4.TabStop = false;
            this.rectangleShape3.Location = new Point(0xdf, 0xa5);
            this.rectangleShape3.Name = "rectangleShape3";
            this.rectangleShape3.Size = new Size(0x132, 0x21);
            this.tabPageCopra.BackColor = SystemColors.Control;
            this.tabPageCopra.Controls.Add(this.buttonEntryCopra);
            this.tabPageCopra.Controls.Add(this.label24);
            this.tabPageCopra.Controls.Add(this.textTotalCopra);
            this.tabPageCopra.Controls.Add(this.label27);
            this.tabPageCopra.Location = new Point(4, 0x19);
            this.tabPageCopra.Margin = new Padding(4);
            this.tabPageCopra.Name = "tabPageCopra";
            this.tabPageCopra.Padding = new Padding(4);
            this.tabPageCopra.Size = new Size(0x4b4, 0x107);
            this.tabPageCopra.TabIndex = 7;
            this.tabPageCopra.Text = "Copra";
            this.buttonEntryCopra.Location = new Point(0x19, 0x1c);
            this.buttonEntryCopra.Margin = new Padding(4);
            this.buttonEntryCopra.Name = "buttonEntryCopra";
            this.buttonEntryCopra.Size = new Size(0xbc, 0x35);
            this.buttonEntryCopra.TabIndex = 0x8f;
            this.buttonEntryCopra.Text = "Entry Copra Deduction";
            this.buttonEntryCopra.UseVisualStyleBackColor = true;
            this.buttonEntryCopra.Click += new EventHandler(this.buttonEntryCopra_Click);
            this.label24.AutoSize = true;
            this.label24.Location = new Point(0x13f, 110);
            this.label24.Margin = new Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new Size(0x1c, 0x11);
            this.label24.TabIndex = 0x8e;
            this.label24.Text = "KG";
            this.textTotalCopra.BackColor = SystemColors.ControlDark;
            this.textTotalCopra.Location = new Point(0xc3, 0x6a);
            this.textTotalCopra.Margin = new Padding(4);
            this.textTotalCopra.Name = "textTotalCopra";
            this.textTotalCopra.ReadOnly = true;
            this.textTotalCopra.Size = new Size(0x75, 0x16);
            this.textTotalCopra.TabIndex = 0x8d;
            this.textTotalCopra.Text = "0";
            this.textTotalCopra.TextAlign = HorizontalAlignment.Right;
            this.label27.AutoSize = true;
            this.label27.Location = new Point(0x21, 110);
            this.label27.Margin = new Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new Size(150, 0x11);
            this.label27.TabIndex = 140;
            this.label27.Text = "Total Copra Deduction";
            this.tabPagePorla.BackColor = SystemColors.Control;
            this.tabPagePorla.Controls.Add(this.label22);
            this.tabPagePorla.Controls.Add(this.buttonDeletePorla);
            this.tabPagePorla.Controls.Add(this.buttonEditPorla);
            this.tabPagePorla.Controls.Add(this.dgvDeducPorla);
            this.tabPagePorla.Controls.Add(this.buttonAddPorla);
            this.tabPagePorla.Controls.Add(this.shapeContainer3);
            this.tabPagePorla.Location = new Point(4, 0x19);
            this.tabPagePorla.Margin = new Padding(4);
            this.tabPagePorla.Name = "tabPagePorla";
            this.tabPagePorla.Padding = new Padding(4);
            this.tabPagePorla.Size = new Size(0x4b4, 0x107);
            this.tabPagePorla.TabIndex = 6;
            this.tabPagePorla.Text = "Porla";
            this.label22.AutoSize = true;
            this.label22.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label22.Location = new Point(0x4c, 20);
            this.label22.Margin = new Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new Size(0x73, 20);
            this.label22.TabIndex = 0x30;
            this.label22.Text = "Entry Porla :";
            this.buttonDeletePorla.Location = new Point(0x1b5, 0xce);
            this.buttonDeletePorla.Margin = new Padding(4);
            this.buttonDeletePorla.Name = "buttonDeletePorla";
            this.buttonDeletePorla.Size = new Size(100, 0x1c);
            this.buttonDeletePorla.TabIndex = 0x1b;
            this.buttonDeletePorla.Text = "Delete";
            this.buttonDeletePorla.UseVisualStyleBackColor = true;
            this.buttonDeletePorla.Click += new EventHandler(this.button5_Click_1);
            this.buttonEditPorla.Location = new Point(0x149, 0xce);
            this.buttonEditPorla.Margin = new Padding(4);
            this.buttonEditPorla.Name = "buttonEditPorla";
            this.buttonEditPorla.Size = new Size(100, 0x1c);
            this.buttonEditPorla.TabIndex = 0x1a;
            this.buttonEditPorla.Text = "Edit";
            this.buttonEditPorla.UseVisualStyleBackColor = true;
            this.buttonEditPorla.Click += new EventHandler(this.button12_Click_1);
            this.dgvDeducPorla.AllowUserToAddRows = false;
            this.dgvDeducPorla.AllowUserToDeleteRows = false;
            this.dgvDeducPorla.AllowUserToResizeRows = false;
            this.dgvDeducPorla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDeducPorla.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgvDeducPorla.ColumnHeadersDefaultCellStyle = style;
            this.dgvDeducPorla.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgvDeducPorla.DefaultCellStyle = style2;
            this.dgvDeducPorla.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvDeducPorla.Location = new Point(0xd8, 20);
            this.dgvDeducPorla.Margin = new Padding(4);
            this.dgvDeducPorla.MultiSelect = false;
            this.dgvDeducPorla.Name = "dgvDeducPorla";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgvDeducPorla.RowHeadersDefaultCellStyle = style3;
            this.dgvDeducPorla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDeducPorla.Size = new Size(0x315, 0xb5);
            this.dgvDeducPorla.TabIndex = 0x18;
            this.dgvDeducPorla.CellDoubleClick += new DataGridViewCellEventHandler(this.dgvDeducPorla_CellDoubleClick);
            this.buttonAddPorla.Location = new Point(0xdd, 0xce);
            this.buttonAddPorla.Margin = new Padding(4);
            this.buttonAddPorla.Name = "buttonAddPorla";
            this.buttonAddPorla.Size = new Size(100, 0x1c);
            this.buttonAddPorla.TabIndex = 0x19;
            this.buttonAddPorla.Text = "Add ";
            this.buttonAddPorla.UseVisualStyleBackColor = true;
            this.buttonAddPorla.Click += new EventHandler(this.button14_Click);
            this.shapeContainer3.Location = new Point(4, 4);
            this.shapeContainer3.Margin = new Padding(0);
            this.shapeContainer3.Name = "shapeContainer3";
            Shape[] shapeArray3 = new Shape[] { this.rectangleShape2 };
            this.shapeContainer3.Shapes.AddRange(shapeArray3);
            this.shapeContainer3.Size = new Size(0x4ac, 0xff);
            this.shapeContainer3.TabIndex = 0x27;
            this.shapeContainer3.TabStop = false;
            this.rectangleShape2.Location = new Point(0x9f, 0x9d);
            this.rectangleShape2.Name = "rectangleShape2";
            this.rectangleShape2.Size = new Size(0xf6, 0x21);
            this.tabPageCont.BackColor = SystemColors.Control;
            this.tabPageCont.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageCont.Controls.Add(this.dgvCont);
            this.tabPageCont.Controls.Add(this.panel5);
            this.tabPageCont.Location = new Point(4, 0x19);
            this.tabPageCont.Margin = new Padding(4);
            this.tabPageCont.Name = "tabPageCont";
            this.tabPageCont.Padding = new Padding(4);
            this.tabPageCont.Size = new Size(0x4b4, 0x107);
            this.tabPageCont.TabIndex = 5;
            this.tabPageCont.Text = "Container No ";
            this.dgvCont.AllowUserToAddRows = false;
            this.dgvCont.AllowUserToDeleteRows = false;
            this.dgvCont.AllowUserToResizeRows = false;
            this.dgvCont.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvCont.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style4.BackColor = SystemColors.Control;
            style4.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style4.ForeColor = SystemColors.WindowText;
            style4.SelectionBackColor = SystemColors.Highlight;
            style4.SelectionForeColor = SystemColors.HighlightText;
            style4.WrapMode = DataGridViewTriState.True;
            this.dgvCont.ColumnHeadersDefaultCellStyle = style4;
            this.dgvCont.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style5.BackColor = SystemColors.Window;
            style5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style5.ForeColor = SystemColors.ControlText;
            style5.SelectionBackColor = SystemColors.Highlight;
            style5.SelectionForeColor = SystemColors.HighlightText;
            style5.WrapMode = DataGridViewTriState.False;
            this.dgvCont.DefaultCellStyle = style5;
            this.dgvCont.Dock = DockStyle.Fill;
            this.dgvCont.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvCont.Location = new Point(4, 4);
            this.dgvCont.Margin = new Padding(4);
            this.dgvCont.MultiSelect = false;
            this.dgvCont.Name = "dgvCont";
            style6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style6.BackColor = SystemColors.Control;
            style6.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style6.ForeColor = SystemColors.WindowText;
            style6.SelectionBackColor = SystemColors.Highlight;
            style6.SelectionForeColor = SystemColors.HighlightText;
            style6.WrapMode = DataGridViewTriState.True;
            this.dgvCont.RowHeadersDefaultCellStyle = style6;
            this.dgvCont.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvCont.Size = new Size(0x4aa, 0xcc);
            this.dgvCont.TabIndex = 2;
            this.panel5.BackColor = SystemColors.Control;
            this.panel5.Controls.Add(this.buttonContDelete);
            this.panel5.Controls.Add(this.buttonContEdit);
            this.panel5.Controls.Add(this.buttonContAdd);
            this.panel5.Dock = DockStyle.Bottom;
            this.panel5.Location = new Point(4, 0xd0);
            this.panel5.Margin = new Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new Size(0x4aa, 0x31);
            this.panel5.TabIndex = 3;
            this.buttonContDelete.Location = new Point(0xdf, 4);
            this.buttonContDelete.Margin = new Padding(4);
            this.buttonContDelete.Name = "buttonContDelete";
            this.buttonContDelete.Size = new Size(100, 0x25);
            this.buttonContDelete.TabIndex = 2;
            this.buttonContDelete.Text = "Delete";
            this.buttonContDelete.UseVisualStyleBackColor = true;
            this.buttonContDelete.Click += new EventHandler(this.buttonContDelete_Click);
            this.buttonContEdit.Location = new Point(0x73, 2);
            this.buttonContEdit.Margin = new Padding(4);
            this.buttonContEdit.Name = "buttonContEdit";
            this.buttonContEdit.Size = new Size(100, 0x25);
            this.buttonContEdit.TabIndex = 1;
            this.buttonContEdit.Text = "Edit";
            this.buttonContEdit.UseVisualStyleBackColor = true;
            this.buttonContEdit.Click += new EventHandler(this.buttonContEdit_Click);
            this.buttonContAdd.Location = new Point(7, 2);
            this.buttonContAdd.Margin = new Padding(4);
            this.buttonContAdd.Name = "buttonContAdd";
            this.buttonContAdd.Size = new Size(100, 0x25);
            this.buttonContAdd.TabIndex = 0;
            this.buttonContAdd.Text = "Add ";
            this.buttonContAdd.UseVisualStyleBackColor = true;
            this.buttonContAdd.Click += new EventHandler(this.buttonContAdd_Click);
            this.tabPageQC.BackColor = SystemColors.Control;
            this.tabPageQC.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageQC.Controls.Add(this.label20);
            this.tabPageQC.Controls.Add(this.textQualityInfo);
            this.tabPageQC.Controls.Add(this.textTankQC);
            this.tabPageQC.Controls.Add(this.textQControl);
            this.tabPageQC.Controls.Add(this.dgvQC_All);
            this.tabPageQC.Controls.Add(this.label44);
            this.tabPageQC.Controls.Add(this.label43);
            this.tabPageQC.Controls.Add(this.combodgvDO);
            this.tabPageQC.Controls.Add(this.label42);
            this.tabPageQC.Controls.Add(this.dgvQC);
            this.tabPageQC.Location = new Point(4, 0x19);
            this.tabPageQC.Margin = new Padding(4);
            this.tabPageQC.Name = "tabPageQC";
            this.tabPageQC.Padding = new Padding(4);
            this.tabPageQC.Size = new Size(0x4b4, 0x107);
            this.tabPageQC.TabIndex = 4;
            this.tabPageQC.Text = "Quality Control / Yield";
            this.label20.AutoSize = true;
            this.label20.Location = new Point(13, 15);
            this.label20.Margin = new Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new Size(0x57, 0x11);
            this.label20.TabIndex = 0x17;
            this.label20.Text = "Quality Info :";
            this.textQualityInfo.Enabled = false;
            this.textQualityInfo.Font = new Font("Lucida Console", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textQualityInfo.Location = new Point(9, 0x22);
            this.textQualityInfo.Margin = new Padding(4);
            this.textQualityInfo.Name = "textQualityInfo";
            this.textQualityInfo.Size = new Size(0xfd, 0x6b);
            this.textQualityInfo.TabIndex = 0x16;
            this.textQualityInfo.Text = " ";
            this.textTankQC.CharacterCasing = CharacterCasing.Upper;
            this.textTankQC.Location = new Point(3, 0xd6);
            this.textTankQC.Margin = new Padding(4);
            this.textTankQC.MaxLength = 15;
            this.textTankQC.Name = "textTankQC";
            this.textTankQC.Size = new Size(0xfd, 0x16);
            this.textTankQC.TabIndex = 2;
            this.textTankQC.Leave += new EventHandler(this.textTankQC_Leave);
            this.textQControl.CharacterCasing = CharacterCasing.Upper;
            this.textQControl.Location = new Point(3, 0xa6);
            this.textQControl.Margin = new Padding(4);
            this.textQControl.MaxLength = 20;
            this.textQControl.Name = "textQControl";
            this.textQControl.Size = new Size(0xfd, 0x16);
            this.textQControl.TabIndex = 1;
            this.textQControl.Leave += new EventHandler(this.textQControl_Leave);
            this.dgvQC_All.AllowUserToAddRows = false;
            this.dgvQC_All.AllowUserToDeleteRows = false;
            this.dgvQC_All.AllowUserToResizeRows = false;
            this.dgvQC_All.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvQC_All.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style7.BackColor = SystemColors.Control;
            style7.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style7.ForeColor = SystemColors.WindowText;
            style7.SelectionBackColor = SystemColors.Highlight;
            style7.SelectionForeColor = SystemColors.HighlightText;
            style7.WrapMode = DataGridViewTriState.True;
            this.dgvQC_All.ColumnHeadersDefaultCellStyle = style7;
            this.dgvQC_All.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style8.BackColor = SystemColors.Window;
            style8.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style8.ForeColor = SystemColors.ControlText;
            style8.SelectionBackColor = SystemColors.Highlight;
            style8.SelectionForeColor = SystemColors.HighlightText;
            style8.WrapMode = DataGridViewTriState.False;
            this.dgvQC_All.DefaultCellStyle = style8;
            this.dgvQC_All.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvQC_All.Location = new Point(0x127, 210);
            this.dgvQC_All.Margin = new Padding(4);
            this.dgvQC_All.MultiSelect = false;
            this.dgvQC_All.Name = "dgvQC_All";
            style9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style9.BackColor = SystemColors.Control;
            style9.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style9.ForeColor = SystemColors.WindowText;
            style9.SelectionBackColor = SystemColors.Highlight;
            style9.SelectionForeColor = SystemColors.HighlightText;
            style9.WrapMode = DataGridViewTriState.True;
            this.dgvQC_All.RowHeadersDefaultCellStyle = style9;
            this.dgvQC_All.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvQC_All.Size = new Size(0x24, 0x27);
            this.dgvQC_All.TabIndex = 4;
            this.dgvQC_All.Visible = false;
            this.label44.AutoSize = true;
            this.label44.Location = new Point(3, 0xc2);
            this.label44.Margin = new Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new Size(0x30, 0x11);
            this.label44.TabIndex = 7;
            this.label44.Text = "Tank :";
            this.label43.AutoSize = true;
            this.label43.Location = new Point(0x175, 210);
            this.label43.Margin = new Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new Size(0x1d, 0x11);
            this.label43.TabIndex = 5;
            this.label43.Text = "DO";
            this.label43.Visible = false;
            this.combodgvDO.FormattingEnabled = true;
            this.combodgvDO.Location = new Point(0x173, 230);
            this.combodgvDO.Margin = new Padding(4);
            this.combodgvDO.Name = "combodgvDO";
            this.combodgvDO.Size = new Size(0xfd, 0x18);
            this.combodgvDO.TabIndex = 0;
            this.combodgvDO.Visible = false;
            this.combodgvDO.SelectedIndexChanged += new EventHandler(this.combodgvDO_SelectedIndexChanged);
            this.combodgvDO.KeyPress += new KeyPressEventHandler(this.combodgvDO_KeyPress);
            this.label42.AutoSize = true;
            this.label42.Location = new Point(3, 0x92);
            this.label42.Margin = new Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new Size(0x6d, 0x11);
            this.label42.TabIndex = 6;
            this.label42.Text = "Quality Control :";
            this.dgvQC.AllowUserToAddRows = false;
            this.dgvQC.AllowUserToDeleteRows = false;
            this.dgvQC.AllowUserToResizeRows = false;
            this.dgvQC.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvQC.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style10.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style10.BackColor = SystemColors.Control;
            style10.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style10.ForeColor = SystemColors.WindowText;
            style10.SelectionBackColor = SystemColors.Highlight;
            style10.SelectionForeColor = SystemColors.HighlightText;
            style10.WrapMode = DataGridViewTriState.True;
            this.dgvQC.ColumnHeadersDefaultCellStyle = style10;
            this.dgvQC.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style11.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style11.BackColor = SystemColors.Window;
            style11.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style11.ForeColor = SystemColors.ControlText;
            style11.SelectionBackColor = SystemColors.Highlight;
            style11.SelectionForeColor = SystemColors.HighlightText;
            style11.WrapMode = DataGridViewTriState.False;
            this.dgvQC.DefaultCellStyle = style11;
            this.dgvQC.EditMode = DataGridViewEditMode.EditOnKeystroke;
            this.dgvQC.Location = new Point(0x110, 2);
            this.dgvQC.Margin = new Padding(4);
            this.dgvQC.MultiSelect = false;
            this.dgvQC.Name = "dgvQC";
            style12.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style12.BackColor = SystemColors.Control;
            style12.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style12.ForeColor = SystemColors.WindowText;
            style12.SelectionBackColor = SystemColors.Highlight;
            style12.SelectionForeColor = SystemColors.HighlightText;
            style12.WrapMode = DataGridViewTriState.True;
            this.dgvQC.RowHeadersDefaultCellStyle = style12;
            this.dgvQC.SelectionMode = DataGridViewSelectionMode.CellSelect;
            this.dgvQC.Size = new Size(0x379, 230);
            this.dgvQC.TabIndex = 3;
            this.dgvQC.CellContentClick += new DataGridViewCellEventHandler(this.dgvQC_CellContentClick);
            this.dgvQC.CellEndEdit += new DataGridViewCellEventHandler(this.dgvQC_CellEndEdit);
            this.dgvQC.DoubleClick += new EventHandler(this.dgvQC_DoubleClick);
            this.tabPageDivision.BackColor = SystemColors.Control;
            this.tabPageDivision.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageDivision.Controls.Add(this.dgvDivBlock);
            this.tabPageDivision.Controls.Add(this.panel3);
            this.tabPageDivision.Location = new Point(4, 0x19);
            this.tabPageDivision.Margin = new Padding(4);
            this.tabPageDivision.Name = "tabPageDivision";
            this.tabPageDivision.Padding = new Padding(4);
            this.tabPageDivision.Size = new Size(0x4b4, 0x107);
            this.tabPageDivision.TabIndex = 3;
            this.tabPageDivision.Text = "Division & Block";
            this.dgvDivBlock.AllowUserToAddRows = false;
            this.dgvDivBlock.AllowUserToDeleteRows = false;
            this.dgvDivBlock.AllowUserToResizeRows = false;
            this.dgvDivBlock.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDivBlock.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style13.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style13.BackColor = SystemColors.Control;
            style13.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style13.ForeColor = SystemColors.WindowText;
            style13.SelectionBackColor = SystemColors.Highlight;
            style13.SelectionForeColor = SystemColors.HighlightText;
            style13.WrapMode = DataGridViewTriState.True;
            this.dgvDivBlock.ColumnHeadersDefaultCellStyle = style13;
            this.dgvDivBlock.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style14.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style14.BackColor = SystemColors.Window;
            style14.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style14.ForeColor = SystemColors.ControlText;
            style14.SelectionBackColor = SystemColors.Highlight;
            style14.SelectionForeColor = SystemColors.HighlightText;
            style14.WrapMode = DataGridViewTriState.False;
            this.dgvDivBlock.DefaultCellStyle = style14;
            this.dgvDivBlock.Dock = DockStyle.Fill;
            this.dgvDivBlock.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvDivBlock.Location = new Point(4, 4);
            this.dgvDivBlock.Margin = new Padding(4);
            this.dgvDivBlock.MultiSelect = false;
            this.dgvDivBlock.Name = "dgvDivBlock";
            style15.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style15.BackColor = SystemColors.Control;
            style15.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style15.ForeColor = SystemColors.WindowText;
            style15.SelectionBackColor = SystemColors.Highlight;
            style15.SelectionForeColor = SystemColors.HighlightText;
            style15.WrapMode = DataGridViewTriState.True;
            this.dgvDivBlock.RowHeadersDefaultCellStyle = style15;
            this.dgvDivBlock.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDivBlock.Size = new Size(0x4aa, 0xde);
            this.dgvDivBlock.TabIndex = 2;
            this.panel3.BackColor = SystemColors.Control;
            this.panel3.Controls.Add(this.button15);
            this.panel3.Controls.Add(this.button16);
            this.panel3.Controls.Add(this.button17);
            this.panel3.Dock = DockStyle.Bottom;
            this.panel3.Location = new Point(4, 0xe2);
            this.panel3.Margin = new Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new Size(0x4aa, 0x1f);
            this.panel3.TabIndex = 3;
            this.button15.Location = new Point(0xdf, 4);
            this.button15.Margin = new Padding(4);
            this.button15.Name = "button15";
            this.button15.Size = new Size(100, 0x1c);
            this.button15.TabIndex = 2;
            this.button15.Text = "Delete";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new EventHandler(this.button15_Click);
            this.button16.Location = new Point(0x73, 2);
            this.button16.Margin = new Padding(4);
            this.button16.Name = "button16";
            this.button16.Size = new Size(100, 0x1c);
            this.button16.TabIndex = 1;
            this.button16.Text = "Edit";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new EventHandler(this.button16_Click);
            this.button17.Location = new Point(7, 2);
            this.button17.Margin = new Padding(4);
            this.button17.Name = "button17";
            this.button17.Size = new Size(100, 0x1c);
            this.button17.TabIndex = 0;
            this.button17.Text = "Add ";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new EventHandler(this.button17_Click);
            this.tabPageDeduc.BackColor = SystemColors.Control;
            this.tabPageDeduc.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageDeduc.Controls.Add(this.buttonSavePrintGrading);
            this.tabPageDeduc.Controls.Add(this.textGrade);
            this.tabPageDeduc.Controls.Add(this.label23);
            this.tabPageDeduc.Controls.Add(this.labelUnit);
            this.tabPageDeduc.Controls.Add(this.textUnitNameWeight);
            this.tabPageDeduc.Controls.Add(this.textUnitName);
            this.tabPageDeduc.Controls.Add(this.label34);
            this.tabPageDeduc.Controls.Add(this.groupBox4);
            this.tabPageDeduc.Controls.Add(this.buttonDeleteDeduc);
            this.tabPageDeduc.Controls.Add(this.buttonEditDeduc);
            this.tabPageDeduc.Controls.Add(this.dgvDeduc);
            this.tabPageDeduc.Controls.Add(this.buttonAddDeduc);
            this.tabPageDeduc.Controls.Add(this.shapeContainer2);
            this.tabPageDeduc.Location = new Point(4, 0x19);
            this.tabPageDeduc.Margin = new Padding(4);
            this.tabPageDeduc.Name = "tabPageDeduc";
            this.tabPageDeduc.Padding = new Padding(4);
            this.tabPageDeduc.Size = new Size(0x4b4, 0x107);
            this.tabPageDeduc.TabIndex = 2;
            this.tabPageDeduc.Text = "Deduction";
            this.buttonSavePrintGrading.Location = new Point(0x340, 0xe2);
            this.buttonSavePrintGrading.Margin = new Padding(4);
            this.buttonSavePrintGrading.Name = "buttonSavePrintGrading";
            this.buttonSavePrintGrading.Size = new Size(0xdd, 0x1c);
            this.buttonSavePrintGrading.TabIndex = 0x16;
            this.buttonSavePrintGrading.Text = "Save && Print Grading Report";
            this.buttonSavePrintGrading.UseVisualStyleBackColor = true;
            this.buttonSavePrintGrading.Click += new EventHandler(this.buttonSavePrintGrading_Click);
            this.textGrade.CharacterCasing = CharacterCasing.Upper;
            this.textGrade.Location = new Point(140, 0xc1);
            this.textGrade.Margin = new Padding(4);
            this.textGrade.MaxLength = 10;
            this.textGrade.Name = "textGrade";
            this.textGrade.Size = new Size(0xa1, 0x16);
            this.textGrade.TabIndex = 0x15;
            this.textGrade.KeyPress += new KeyPressEventHandler(this.textGrade_KeyPress);
            this.label23.AutoSize = true;
            this.label23.Location = new Point(60, 0xc5);
            this.label23.Margin = new Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new Size(0x30, 0x11);
            this.label23.TabIndex = 20;
            this.label23.Text = "Grade";
            this.labelUnit.AutoSize = true;
            this.labelUnit.Location = new Point(0xa5, 0x35);
            this.labelUnit.Margin = new Padding(4, 0, 4, 0);
            this.labelUnit.Name = "labelUnit";
            this.labelUnit.Size = new Size(0x61, 0x11);
            this.labelUnit.TabIndex = 0x11;
            this.labelUnit.Text = "KG per Bunch";
            this.textUnitNameWeight.Location = new Point(0x7f, 0x30);
            this.textUnitNameWeight.Margin = new Padding(4);
            this.textUnitNameWeight.MaxLength = 15;
            this.textUnitNameWeight.Name = "textUnitNameWeight";
            this.textUnitNameWeight.Size = new Size(0x23, 0x16);
            this.textUnitNameWeight.TabIndex = 0x12;
            this.textUnitNameWeight.Text = "0";
            this.textUnitNameWeight.TextAlign = HorizontalAlignment.Right;
            this.textUnitNameWeight.Leave += new EventHandler(this.textUnitNameWeight_Leave);
            this.textUnitName.Location = new Point(0x7f, 12);
            this.textUnitName.Margin = new Padding(4);
            this.textUnitName.MaxLength = 20;
            this.textUnitName.Name = "textUnitName";
            this.textUnitName.Size = new Size(0xaf, 0x16);
            this.textUnitName.TabIndex = 1;
            this.textUnitName.Text = "Bunch";
            this.textUnitName.TextChanged += new EventHandler(this.textBox8_TextChanged);
            this.label34.AutoSize = true;
            this.label34.Location = new Point(0x24, 0x10);
            this.label34.Margin = new Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new Size(0x4a, 0x11);
            this.label34.TabIndex = 0x13;
            this.label34.Text = "Unit Name";
            this.groupBox4.Controls.Add(this.textBunchTotal);
            this.groupBox4.Controls.Add(this.textBunchDeduc);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.textAvg);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Location = new Point(0x23, 0x4e);
            this.groupBox4.Margin = new Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new Padding(4);
            this.groupBox4.Size = new Size(0x10b, 0x67);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "[ Bunch ]";
            this.textBunchTotal.Location = new Point(180, 12);
            this.textBunchTotal.Margin = new Padding(4);
            this.textBunchTotal.MaxLength = 15;
            this.textBunchTotal.Name = "textBunchTotal";
            this.textBunchTotal.Size = new Size(0x4b, 0x16);
            this.textBunchTotal.TabIndex = 0;
            this.textBunchTotal.Text = "0";
            this.textBunchTotal.TextAlign = HorizontalAlignment.Right;
            this.textBunchTotal.Leave += new EventHandler(this.textBunchTotal_Leave);
            this.textBunchDeduc.Location = new Point(180, 0x2b);
            this.textBunchDeduc.Margin = new Padding(4);
            this.textBunchDeduc.MaxLength = 15;
            this.textBunchDeduc.Name = "textBunchDeduc";
            this.textBunchDeduc.Size = new Size(0x4b, 0x16);
            this.textBunchDeduc.TabIndex = 1;
            this.textBunchDeduc.Text = "0";
            this.textBunchDeduc.TextAlign = HorizontalAlignment.Right;
            this.label29.AutoSize = true;
            this.label29.Location = new Point(0x87, 0x10);
            this.label29.Margin = new Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new Size(0x2c, 0x11);
            this.label29.TabIndex = 5;
            this.label29.Text = "Total ";
            this.label30.AutoSize = true;
            this.label30.Location = new Point(0x10, 0x2f);
            this.label30.Margin = new Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new Size(0xa4, 0x11);
            this.label30.TabIndex = 4;
            this.label30.Text = "Total for Deduction Calc.";
            this.textAvg.Location = new Point(180, 0x4a);
            this.textAvg.Margin = new Padding(4);
            this.textAvg.MaxLength = 15;
            this.textAvg.Name = "textAvg";
            this.textAvg.Size = new Size(0x4b, 0x16);
            this.textAvg.TabIndex = 2;
            this.textAvg.Text = "0";
            this.textAvg.TextAlign = HorizontalAlignment.Right;
            this.textAvg.Leave += new EventHandler(this.textAvg_Leave);
            this.label31.AutoSize = true;
            this.label31.Location = new Point(60, 0x4a);
            this.label31.Margin = new Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new Size(0x6d, 0x11);
            this.label31.TabIndex = 3;
            this.label31.Text = "Average Weight";
            this.buttonDeleteDeduc.Location = new Point(0x41c, 0xbf);
            this.buttonDeleteDeduc.Margin = new Padding(4);
            this.buttonDeleteDeduc.Name = "buttonDeleteDeduc";
            this.buttonDeleteDeduc.Size = new Size(100, 0x1c);
            this.buttonDeleteDeduc.TabIndex = 8;
            this.buttonDeleteDeduc.Text = "Delete";
            this.buttonDeleteDeduc.UseVisualStyleBackColor = true;
            this.buttonDeleteDeduc.Click += new EventHandler(this.button1_Click);
            this.buttonEditDeduc.Location = new Point(0x3b0, 0xbf);
            this.buttonEditDeduc.Margin = new Padding(4);
            this.buttonEditDeduc.Name = "buttonEditDeduc";
            this.buttonEditDeduc.Size = new Size(100, 0x1c);
            this.buttonEditDeduc.TabIndex = 7;
            this.buttonEditDeduc.Text = "Edit";
            this.buttonEditDeduc.UseVisualStyleBackColor = true;
            this.buttonEditDeduc.Click += new EventHandler(this.button2_Click);
            this.dgvDeduc.AllowUserToAddRows = false;
            this.dgvDeduc.AllowUserToDeleteRows = false;
            this.dgvDeduc.AllowUserToResizeRows = false;
            this.dgvDeduc.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDeduc.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style16.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style16.BackColor = SystemColors.Control;
            style16.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style16.ForeColor = SystemColors.WindowText;
            style16.SelectionBackColor = SystemColors.Highlight;
            style16.SelectionForeColor = SystemColors.HighlightText;
            style16.WrapMode = DataGridViewTriState.True;
            this.dgvDeduc.ColumnHeadersDefaultCellStyle = style16;
            this.dgvDeduc.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style17.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style17.BackColor = SystemColors.Window;
            style17.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style17.ForeColor = SystemColors.ControlText;
            style17.SelectionBackColor = SystemColors.Highlight;
            style17.SelectionForeColor = SystemColors.HighlightText;
            style17.WrapMode = DataGridViewTriState.False;
            this.dgvDeduc.DefaultCellStyle = style17;
            this.dgvDeduc.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvDeduc.Location = new Point(0x16d, 4);
            this.dgvDeduc.Margin = new Padding(4);
            this.dgvDeduc.MultiSelect = false;
            this.dgvDeduc.Name = "dgvDeduc";
            style18.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style18.BackColor = SystemColors.Control;
            style18.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style18.ForeColor = SystemColors.WindowText;
            style18.SelectionBackColor = SystemColors.Highlight;
            style18.SelectionForeColor = SystemColors.HighlightText;
            style18.WrapMode = DataGridViewTriState.True;
            this.dgvDeduc.RowHeadersDefaultCellStyle = style18;
            this.dgvDeduc.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDeduc.Size = new Size(0x315, 0xb5);
            this.dgvDeduc.TabIndex = 5;
            this.dgvDeduc.CellDoubleClick += new DataGridViewCellEventHandler(this.dgvDeduc_CellDoubleClick);
            this.buttonAddDeduc.Location = new Point(0x344, 0xbf);
            this.buttonAddDeduc.Margin = new Padding(4);
            this.buttonAddDeduc.Name = "buttonAddDeduc";
            this.buttonAddDeduc.Size = new Size(100, 0x1c);
            this.buttonAddDeduc.TabIndex = 6;
            this.buttonAddDeduc.Text = "Add ";
            this.buttonAddDeduc.UseVisualStyleBackColor = true;
            this.buttonAddDeduc.Click += new EventHandler(this.button3_Click);
            this.shapeContainer2.Location = new Point(4, 4);
            this.shapeContainer2.Margin = new Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            Shape[] shapeArray4 = new Shape[] { this.rectangleShape1 };
            this.shapeContainer2.Shapes.AddRange(shapeArray4);
            this.shapeContainer2.Size = new Size(0x4aa, 0xfd);
            this.shapeContainer2.TabIndex = 0;
            this.shapeContainer2.TabStop = false;
            this.rectangleShape1.Location = new Point(0x268, 0x91);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new Size(0xf6, 0x21);
            this.tabPageInfo.BackColor = SystemColors.Control;
            this.tabPageInfo.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageInfo.Controls.Add(this.panelInfo);
            this.tabPageInfo.Controls.Add(this.buttonStorage);
            this.tabPageInfo.Controls.Add(this.textStorage);
            this.tabPageInfo.Controls.Add(this.textEstate);
            this.tabPageInfo.Controls.Add(this.textCommodity);
            this.tabPageInfo.Controls.Add(this.textCust);
            this.tabPageInfo.Controls.Add(this.labelStorageName);
            this.tabPageInfo.Controls.Add(this.labelStorage);
            this.tabPageInfo.Controls.Add(this.buttonEstate);
            this.tabPageInfo.Controls.Add(this.labelEstateName);
            this.tabPageInfo.Controls.Add(this.panel4);
            this.tabPageInfo.Controls.Add(this.labelCustName);
            this.tabPageInfo.Controls.Add(this.label40);
            this.tabPageInfo.Controls.Add(this.buttonCust);
            this.tabPageInfo.Controls.Add(this.labelComm);
            this.tabPageInfo.Controls.Add(this.labelCommName);
            this.tabPageInfo.Controls.Add(this.labelRelation);
            this.tabPageInfo.Controls.Add(this.buttonComm);
            this.tabPageInfo.Location = new Point(4, 0x19);
            this.tabPageInfo.Margin = new Padding(4);
            this.tabPageInfo.Name = "tabPageInfo";
            this.tabPageInfo.Padding = new Padding(4);
            this.tabPageInfo.Size = new Size(0x4b4, 0x107);
            this.tabPageInfo.TabIndex = 0;
            this.tabPageInfo.Text = "General Information";
            this.panelInfo.BorderStyle = BorderStyle.FixedSingle;
            this.panelInfo.Controls.Add(this.labelDivision);
            this.panelInfo.Controls.Add(this.buttonDivision);
            this.panelInfo.Controls.Add(this.textDivision);
            this.panelInfo.Controls.Add(this.labelDivisionName);
            this.panelInfo.Controls.Add(this.labelMill);
            this.panelInfo.Controls.Add(this.buttonMill);
            this.panelInfo.Controls.Add(this.textMill);
            this.panelInfo.Controls.Add(this.labelMillName);
            this.panelInfo.Controls.Add(this.labelSourceName);
            this.panelInfo.Controls.Add(this.buttonSource);
            this.panelInfo.Controls.Add(this.textSource);
            this.panelInfo.Controls.Add(this.label62);
            this.panelInfo.Controls.Add(this.buttonLoadUnload);
            this.panelInfo.Controls.Add(this.label63);
            this.panelInfo.Controls.Add(this.textBoxLoadUnload);
            this.panelInfo.Controls.Add(this.labelLoadUnloadName);
            this.panelInfo.Location = new Point(12, 0x10);
            this.panelInfo.Margin = new Padding(4);
            this.panelInfo.Name = "panelInfo";
            this.panelInfo.Size = new Size(630, 0xae);
            this.panelInfo.TabIndex = 0x40;
            this.panelInfo.Paint += new PaintEventHandler(this.panelInfo_Paint);
            this.labelDivision.AutoSize = true;
            this.labelDivision.Location = new Point(3, 0x37);
            this.labelDivision.Margin = new Padding(4, 0, 4, 0);
            this.labelDivision.Name = "labelDivision";
            this.labelDivision.Size = new Size(0x39, 0x11);
            this.labelDivision.TabIndex = 70;
            this.labelDivision.Text = "Division";
            this.buttonDivision.Location = new Point(0x14d, 0x30);
            this.buttonDivision.Margin = new Padding(0);
            this.buttonDivision.Name = "buttonDivision";
            this.buttonDivision.Size = new Size(0x1f, 0x1c);
            this.buttonDivision.TabIndex = 0x45;
            this.buttonDivision.Text = "...";
            this.buttonDivision.UseVisualStyleBackColor = true;
            this.buttonDivision.Click += new EventHandler(this.buttonDivision_Click);
            this.textDivision.CharacterCasing = CharacterCasing.Upper;
            this.textDivision.Location = new Point(0xa5, 0x34);
            this.textDivision.Margin = new Padding(4);
            this.textDivision.Name = "textDivision";
            this.textDivision.Size = new Size(0x9c, 0x16);
            this.textDivision.TabIndex = 0x44;
            this.textDivision.KeyPress += new KeyPressEventHandler(this.textDivision_KeyPress);
            this.textDivision.Leave += new EventHandler(this.textDivision_Leave);
            this.labelDivisionName.AutoSize = true;
            this.labelDivisionName.Location = new Point(0x171, 0x37);
            this.labelDivisionName.Margin = new Padding(4, 0, 4, 0);
            this.labelDivisionName.Name = "labelDivisionName";
            this.labelDivisionName.Size = new Size(0x62, 0x11);
            this.labelDivisionName.TabIndex = 0x47;
            this.labelDivisionName.Text = "Division Name";
            this.labelMill.AutoSize = true;
            this.labelMill.Location = new Point(3, 0x17);
            this.labelMill.Margin = new Padding(4, 0, 4, 0);
            this.labelMill.Name = "labelMill";
            this.labelMill.Size = new Size(0x1c, 0x11);
            this.labelMill.TabIndex = 0x42;
            this.labelMill.Text = "Mill";
            this.buttonMill.Location = new Point(0x14d, 0x10);
            this.buttonMill.Margin = new Padding(0);
            this.buttonMill.Name = "buttonMill";
            this.buttonMill.Size = new Size(0x1f, 0x1c);
            this.buttonMill.TabIndex = 0x41;
            this.buttonMill.Text = "...";
            this.buttonMill.UseVisualStyleBackColor = true;
            this.buttonMill.Click += new EventHandler(this.buttonMill_Click);
            this.textMill.CharacterCasing = CharacterCasing.Upper;
            this.textMill.Location = new Point(0xa5, 20);
            this.textMill.Margin = new Padding(4);
            this.textMill.Name = "textMill";
            this.textMill.Size = new Size(0x9c, 0x16);
            this.textMill.TabIndex = 0x40;
            this.textMill.KeyPress += new KeyPressEventHandler(this.textMill_KeyPress);
            this.textMill.Leave += new EventHandler(this.textMill_Leave);
            this.labelMillName.AutoSize = true;
            this.labelMillName.Location = new Point(0x171, 0x17);
            this.labelMillName.Margin = new Padding(4, 0, 4, 0);
            this.labelMillName.Name = "labelMillName";
            this.labelMillName.Size = new Size(0x45, 0x11);
            this.labelMillName.TabIndex = 0x43;
            this.labelMillName.Text = "Mill Name";
            this.labelSourceName.AutoSize = true;
            this.labelSourceName.Location = new Point(0x171, 0x52);
            this.labelSourceName.Margin = new Padding(4, 0, 4, 0);
            this.labelSourceName.Name = "labelSourceName";
            this.labelSourceName.Size = new Size(0x5e, 0x11);
            this.labelSourceName.TabIndex = 0x3f;
            this.labelSourceName.Text = "Source Name";
            this.buttonSource.Location = new Point(0x14d, 0x4c);
            this.buttonSource.Margin = new Padding(0);
            this.buttonSource.Name = "buttonSource";
            this.buttonSource.Size = new Size(0x1f, 0x1c);
            this.buttonSource.TabIndex = 0x16;
            this.buttonSource.Text = "...";
            this.buttonSource.UseVisualStyleBackColor = true;
            this.buttonSource.Click += new EventHandler(this.buttonSource_Click);
            this.textSource.CharacterCasing = CharacterCasing.Upper;
            this.textSource.Location = new Point(0xa5, 80);
            this.textSource.Margin = new Padding(4);
            this.textSource.MaxLength = 20;
            this.textSource.Name = "textSource";
            this.textSource.Size = new Size(0x9c, 0x16);
            this.textSource.TabIndex = 20;
            this.textSource.KeyPress += new KeyPressEventHandler(this.textSource_KeyPress);
            this.textSource.Leave += new EventHandler(this.textSource_Leave);
            this.label62.Location = new Point(3, 0x70);
            this.label62.Margin = new Padding(4, 0, 4, 0);
            this.label62.Name = "label62";
            this.label62.Size = new Size(0x85, 0x24);
            this.label62.TabIndex = 0x13;
            this.label62.Text = "Load/Unload Place";
            this.buttonLoadUnload.Location = new Point(0x14d, 0x69);
            this.buttonLoadUnload.Margin = new Padding(0);
            this.buttonLoadUnload.Name = "buttonLoadUnload";
            this.buttonLoadUnload.Size = new Size(0x1f, 0x1c);
            this.buttonLoadUnload.TabIndex = 10;
            this.buttonLoadUnload.Text = "...";
            this.buttonLoadUnload.UseVisualStyleBackColor = true;
            this.buttonLoadUnload.Click += new EventHandler(this.buttonLoadUnload_Click);
            this.label63.AutoSize = true;
            this.label63.Location = new Point(3, 0x55);
            this.label63.Margin = new Padding(4, 0, 4, 0);
            this.label63.Name = "label63";
            this.label63.Size = new Size(0x88, 0x11);
            this.label63.TabIndex = 0x11;
            this.label63.Text = "Source / Destination";
            this.textBoxLoadUnload.CharacterCasing = CharacterCasing.Upper;
            this.textBoxLoadUnload.Location = new Point(0xa5, 0x6c);
            this.textBoxLoadUnload.Margin = new Padding(4);
            this.textBoxLoadUnload.Name = "textBoxLoadUnload";
            this.textBoxLoadUnload.Size = new Size(0x9c, 0x16);
            this.textBoxLoadUnload.TabIndex = 9;
            this.textBoxLoadUnload.KeyPress += new KeyPressEventHandler(this.textBox6_KeyPress);
            this.textBoxLoadUnload.Leave += new EventHandler(this.textBoxLoadUnload_Leave);
            this.labelLoadUnloadName.AutoSize = true;
            this.labelLoadUnloadName.Location = new Point(0x171, 0x70);
            this.labelLoadUnloadName.Margin = new Padding(4, 0, 4, 0);
            this.labelLoadUnloadName.Name = "labelLoadUnloadName";
            this.labelLoadUnloadName.Size = new Size(0x51, 0x11);
            this.labelLoadUnloadName.TabIndex = 0x3e;
            this.labelLoadUnloadName.Text = "Load Name";
            this.buttonStorage.Location = new Point(0x407, 190);
            this.buttonStorage.Margin = new Padding(0);
            this.buttonStorage.Name = "buttonStorage";
            this.buttonStorage.Size = new Size(0x1f, 0x1c);
            this.buttonStorage.TabIndex = 10;
            this.buttonStorage.Text = "...";
            this.buttonStorage.UseVisualStyleBackColor = true;
            this.buttonStorage.Visible = false;
            this.buttonStorage.Click += new EventHandler(this.buttonStorage_Click);
            this.textStorage.CharacterCasing = CharacterCasing.Upper;
            this.textStorage.Location = new Point(0x35f, 0xc1);
            this.textStorage.Margin = new Padding(4);
            this.textStorage.Name = "textStorage";
            this.textStorage.ReadOnly = true;
            this.textStorage.Size = new Size(0xa3, 0x16);
            this.textStorage.TabIndex = 9;
            this.textStorage.Visible = false;
            this.textEstate.CharacterCasing = CharacterCasing.Upper;
            this.textEstate.Location = new Point(0x35f, 0xe1);
            this.textEstate.Margin = new Padding(4);
            this.textEstate.Name = "textEstate";
            this.textEstate.ReadOnly = true;
            this.textEstate.Size = new Size(0xa3, 0x16);
            this.textEstate.TabIndex = 8;
            this.textEstate.Visible = false;
            this.textCommodity.BackColor = SystemColors.Window;
            this.textCommodity.CharacterCasing = CharacterCasing.Upper;
            this.textCommodity.Location = new Point(0x1c7, 0xe1);
            this.textCommodity.Margin = new Padding(4);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0xa3, 0x16);
            this.textCommodity.TabIndex = 8;
            this.textCommodity.Visible = false;
            this.textCommodity.KeyPress += new KeyPressEventHandler(this.textCommodity_KeyPress);
            this.textCust.CharacterCasing = CharacterCasing.Upper;
            this.textCust.Location = new Point(0x1c3, 0xc6);
            this.textCust.Margin = new Padding(4);
            this.textCust.MaxLength = 50;
            this.textCust.Name = "textCust";
            this.textCust.Size = new Size(0xa3, 0x16);
            this.textCust.TabIndex = 11;
            this.textCust.Visible = false;
            this.textCust.Leave += new EventHandler(this.textCust_Leave);
            this.labelStorageName.AutoSize = true;
            this.labelStorageName.Location = new Point(0x428, 0xc4);
            this.labelStorageName.Margin = new Padding(4, 0, 4, 0);
            this.labelStorageName.Name = "labelStorageName";
            this.labelStorageName.Size = new Size(0x5f, 0x11);
            this.labelStorageName.TabIndex = 0x3e;
            this.labelStorageName.Text = "StorageName";
            this.labelStorageName.Visible = false;
            this.labelStorage.AutoSize = true;
            this.labelStorage.Location = new Point(800, 0xc6);
            this.labelStorage.Margin = new Padding(4, 0, 4, 0);
            this.labelStorage.Name = "labelStorage";
            this.labelStorage.Size = new Size(0x3a, 0x11);
            this.labelStorage.TabIndex = 0x3d;
            this.labelStorage.Text = "Storage";
            this.labelStorage.Visible = false;
            this.buttonEstate.Location = new Point(0x407, 0xdf);
            this.buttonEstate.Margin = new Padding(0);
            this.buttonEstate.Name = "buttonEstate";
            this.buttonEstate.Size = new Size(0x1f, 0x1c);
            this.buttonEstate.TabIndex = 10;
            this.buttonEstate.Text = "...";
            this.buttonEstate.UseVisualStyleBackColor = true;
            this.buttonEstate.Visible = false;
            this.buttonEstate.Click += new EventHandler(this.button4_Click);
            this.labelEstateName.AutoSize = true;
            this.labelEstateName.Location = new Point(0x428, 0xe5);
            this.labelEstateName.Margin = new Padding(4, 0, 4, 0);
            this.labelEstateName.Name = "labelEstateName";
            this.labelEstateName.Size = new Size(0x55, 0x11);
            this.labelEstateName.TabIndex = 0x36;
            this.labelEstateName.Text = "EstateName";
            this.labelEstateName.Visible = false;
            this.panel4.BorderStyle = BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.textISCC2);
            this.panel4.Controls.Add(this.groupBox3);
            this.panel4.Controls.Add(this.textISCC);
            this.panel4.Controls.Add(this.label38);
            this.panel4.Controls.Add(this.checkISCC);
            this.panel4.Location = new Point(0x299, 0x10);
            this.panel4.Margin = new Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new Size(0x1eb, 0x94);
            this.panel4.TabIndex = 12;
            this.textISCC2.BackColor = SystemColors.Window;
            this.textISCC2.Enabled = false;
            this.textISCC2.Location = new Point(0x164, 0x34);
            this.textISCC2.Margin = new Padding(4);
            this.textISCC2.MaxLength = 50;
            this.textISCC2.Name = "textISCC2";
            this.textISCC2.Size = new Size(0x7d, 0x16);
            this.textISCC2.TabIndex = 4;
            this.textISCC2.TextAlign = HorizontalAlignment.Right;
            this.groupBox3.Controls.Add(this.label39);
            this.groupBox3.Controls.Add(this.textGHG);
            this.groupBox3.Controls.Add(this.radioGHG2);
            this.groupBox3.Controls.Add(this.radioGHG1);
            this.groupBox3.Location = new Point(4, 0x47);
            this.groupBox3.Margin = new Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new Padding(4);
            this.groupBox3.Size = new Size(0x1df, 0x47);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "[ GHG Emissions ]";
            this.label39.AutoSize = true;
            this.label39.Location = new Point(0x18b, 0x20);
            this.label39.Margin = new Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new Size(0x19, 0x11);
            this.label39.TabIndex = 0x38;
            this.label39.Text = "Kg";
            this.textGHG.Enabled = false;
            this.textGHG.Location = new Point(0x11f, 0x1c);
            this.textGHG.Margin = new Padding(4);
            this.textGHG.MaxLength = 15;
            this.textGHG.Name = "textGHG";
            this.textGHG.Size = new Size(0x69, 0x16);
            this.textGHG.TabIndex = 2;
            this.textGHG.Text = "0.000";
            this.textGHG.TextAlign = HorizontalAlignment.Right;
            this.radioGHG2.AutoSize = true;
            this.radioGHG2.Checked = true;
            this.radioGHG2.Enabled = false;
            this.radioGHG2.Location = new Point(260, 0x1f);
            this.radioGHG2.Margin = new Padding(4);
            this.radioGHG2.Name = "radioGHG2";
            this.radioGHG2.Size = new Size(0x11, 0x10);
            this.radioGHG2.TabIndex = 1;
            this.radioGHG2.TabStop = true;
            this.radioGHG2.UseVisualStyleBackColor = true;
            this.radioGHG2.CheckedChanged += new EventHandler(this.radioGHG2_CheckedChanged);
            this.radioGHG1.AutoSize = true;
            this.radioGHG1.Enabled = false;
            this.radioGHG1.Location = new Point(8, 30);
            this.radioGHG1.Margin = new Padding(4);
            this.radioGHG1.Name = "radioGHG1";
            this.radioGHG1.Size = new Size(0xc6, 0x15);
            this.radioGHG1.TabIndex = 0;
            this.radioGHG1.Text = "Use of Grandfather Clause";
            this.radioGHG1.UseVisualStyleBackColor = true;
            this.radioGHG1.CheckedChanged += new EventHandler(this.radioGHG1_CheckedChanged);
            this.textISCC.BackColor = SystemColors.Window;
            this.textISCC.Enabled = false;
            this.textISCC.Location = new Point(0x4d, 0x19);
            this.textISCC.Margin = new Padding(4);
            this.textISCC.MaxLength = 100;
            this.textISCC.Name = "textISCC";
            this.textISCC.ReadOnly = true;
            this.textISCC.Size = new Size(0x194, 0x16);
            this.textISCC.TabIndex = 1;
            this.textISCC.Text = "EU-ISCC-Cert-DE999-1234567890";
            this.textISCC.TextAlign = HorizontalAlignment.Right;
            this.label38.AutoSize = true;
            this.label38.Location = new Point(5, 0x1c);
            this.label38.Margin = new Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new Size(0x40, 0x11);
            this.label38.TabIndex = 0;
            this.label38.Text = "ISCC No.";
            this.checkISCC.AutoSize = true;
            this.checkISCC.Location = new Point(9, 2);
            this.checkISCC.Margin = new Padding(4);
            this.checkISCC.Name = "checkISCC";
            this.checkISCC.Size = new Size(0x7b, 0x15);
            this.checkISCC.TabIndex = 11;
            this.checkISCC.Text = "Used ISCC No.";
            this.checkISCC.UseVisualStyleBackColor = true;
            this.checkISCC.CheckedChanged += new EventHandler(this.checkISCC_CheckedChanged);
            this.labelCustName.AutoSize = true;
            this.labelCustName.Location = new Point(0x297, 0xc9);
            this.labelCustName.Margin = new Padding(4, 0, 4, 0);
            this.labelCustName.Name = "labelCustName";
            this.labelCustName.Size = new Size(0x69, 0x11);
            this.labelCustName.TabIndex = 0x1c;
            this.labelCustName.Text = "CustomerName";
            this.labelCustName.Visible = false;
            this.label40.AutoSize = true;
            this.label40.Location = new Point(0x325, 230);
            this.label40.Margin = new Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new Size(0x30, 0x11);
            this.label40.TabIndex = 0x35;
            this.label40.Text = "Estate";
            this.label40.Visible = false;
            this.buttonCust.Location = new Point(0x26f, 0xc2);
            this.buttonCust.Margin = new Padding(0);
            this.buttonCust.Name = "buttonCust";
            this.buttonCust.Size = new Size(0x1f, 0x1c);
            this.buttonCust.TabIndex = 12;
            this.buttonCust.Text = "...";
            this.buttonCust.UseVisualStyleBackColor = true;
            this.buttonCust.Visible = false;
            this.buttonCust.Click += new EventHandler(this.buttonCust_Click);
            this.labelComm.AutoSize = true;
            this.labelComm.Cursor = Cursors.Arrow;
            this.labelComm.Location = new Point(0x177, 0xe5);
            this.labelComm.Margin = new Padding(4, 0, 4, 0);
            this.labelComm.Name = "labelComm";
            this.labelComm.Size = new Size(0x4d, 0x11);
            this.labelComm.TabIndex = 0x12;
            this.labelComm.Text = "Commodity";
            this.labelComm.Visible = false;
            this.labelCommName.AutoSize = true;
            this.labelCommName.Cursor = Cursors.Arrow;
            this.labelCommName.Location = new Point(0x295, 0xe5);
            this.labelCommName.Margin = new Padding(4, 0, 4, 0);
            this.labelCommName.MaximumSize = new Size(0x1d3, 0);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x7a, 0x11);
            this.labelCommName.TabIndex = 0x17;
            this.labelCommName.Text = "Commodity Name ";
            this.labelCommName.Visible = false;
            this.labelRelation.AutoSize = true;
            this.labelRelation.Location = new Point(0x17d, 0xca);
            this.labelRelation.Margin = new Padding(4, 0, 4, 0);
            this.labelRelation.Name = "labelRelation";
            this.labelRelation.Size = new Size(0x3a, 0x11);
            this.labelRelation.TabIndex = 20;
            this.labelRelation.Text = "Vendor ";
            this.labelRelation.TextAlign = ContentAlignment.TopRight;
            this.labelRelation.Visible = false;
            this.buttonComm.Location = new Point(0x26f, 0xdf);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x1f, 0x1c);
            this.buttonComm.TabIndex = 9;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Visible = false;
            this.buttonComm.Click += new EventHandler(this.button13_Click);
            this.tabPageDO.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageDO.Controls.Add(this.dgvDO);
            this.tabPageDO.Controls.Add(this.panel1);
            this.tabPageDO.Location = new Point(4, 0x19);
            this.tabPageDO.Margin = new Padding(4);
            this.tabPageDO.Name = "tabPageDO";
            this.tabPageDO.Padding = new Padding(4);
            this.tabPageDO.Size = new Size(0x4b4, 0x107);
            this.tabPageDO.TabIndex = 1;
            this.tabPageDO.Text = "Contract / DO ";
            this.tabPageDO.UseVisualStyleBackColor = true;
            this.dgvDO.AllowUserToAddRows = false;
            this.dgvDO.AllowUserToDeleteRows = false;
            this.dgvDO.AllowUserToResizeRows = false;
            this.dgvDO.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDO.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style19.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style19.BackColor = SystemColors.Control;
            style19.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style19.ForeColor = SystemColors.WindowText;
            style19.SelectionBackColor = SystemColors.Highlight;
            style19.SelectionForeColor = SystemColors.HighlightText;
            style19.WrapMode = DataGridViewTriState.True;
            this.dgvDO.ColumnHeadersDefaultCellStyle = style19;
            this.dgvDO.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style20.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style20.BackColor = SystemColors.Window;
            style20.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style20.ForeColor = SystemColors.ControlText;
            style20.SelectionBackColor = SystemColors.Highlight;
            style20.SelectionForeColor = SystemColors.HighlightText;
            style20.WrapMode = DataGridViewTriState.False;
            this.dgvDO.DefaultCellStyle = style20;
            this.dgvDO.Dock = DockStyle.Fill;
            this.dgvDO.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvDO.Location = new Point(4, 4);
            this.dgvDO.Margin = new Padding(4);
            this.dgvDO.MultiSelect = false;
            this.dgvDO.Name = "dgvDO";
            style21.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style21.BackColor = SystemColors.Control;
            style21.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style21.ForeColor = SystemColors.WindowText;
            style21.SelectionBackColor = SystemColors.Highlight;
            style21.SelectionForeColor = SystemColors.HighlightText;
            style21.WrapMode = DataGridViewTriState.True;
            this.dgvDO.RowHeadersDefaultCellStyle = style21;
            this.dgvDO.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDO.Size = new Size(0x4aa, 0xcd);
            this.dgvDO.TabIndex = 1;
            this.dgvDO.SelectionChanged += new EventHandler(this.dgvDO_SelectionChanged);
            this.panel1.BackColor = SystemColors.Control;
            this.panel1.Controls.Add(this.buttonMergeDO);
            this.panel1.Controls.Add(this.buttonDeleteDO);
            this.panel1.Controls.Add(this.buttonEditDO);
            this.panel1.Controls.Add(this.buttonAddDO);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(4, 0xd1);
            this.panel1.Margin = new Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x4aa, 0x30);
            this.panel1.TabIndex = 0;
            this.buttonMergeDO.Location = new Point(0x184, 7);
            this.buttonMergeDO.Margin = new Padding(4);
            this.buttonMergeDO.Name = "buttonMergeDO";
            this.buttonMergeDO.Size = new Size(0x90, 0x1c);
            this.buttonMergeDO.TabIndex = 3;
            this.buttonMergeDO.Text = "Refresh";
            this.buttonMergeDO.UseVisualStyleBackColor = true;
            this.buttonMergeDO.Click += new EventHandler(this.buttonMerge_Click);
            this.buttonDeleteDO.Location = new Point(0xdb, 10);
            this.buttonDeleteDO.Margin = new Padding(4);
            this.buttonDeleteDO.Name = "buttonDeleteDO";
            this.buttonDeleteDO.Size = new Size(100, 0x1c);
            this.buttonDeleteDO.TabIndex = 2;
            this.buttonDeleteDO.Text = "Delete";
            this.buttonDeleteDO.UseVisualStyleBackColor = true;
            this.buttonDeleteDO.Click += new EventHandler(this.button8_Click);
            this.buttonEditDO.Location = new Point(0x6f, 9);
            this.buttonEditDO.Margin = new Padding(4);
            this.buttonEditDO.Name = "buttonEditDO";
            this.buttonEditDO.Size = new Size(100, 0x1c);
            this.buttonEditDO.TabIndex = 1;
            this.buttonEditDO.Text = "&Edit";
            this.buttonEditDO.UseVisualStyleBackColor = true;
            this.buttonEditDO.Click += new EventHandler(this.button7_Click);
            this.buttonAddDO.Location = new Point(3, 9);
            this.buttonAddDO.Margin = new Padding(4);
            this.buttonAddDO.Name = "buttonAddDO";
            this.buttonAddDO.Size = new Size(100, 0x1c);
            this.buttonAddDO.TabIndex = 0;
            this.buttonAddDO.Text = "&Add";
            this.buttonAddDO.UseVisualStyleBackColor = true;
            this.buttonAddDO.Click += new EventHandler(this.buttonAddDO_Click);
            this.tabControl1.Controls.Add(this.tabPageDO);
            this.tabControl1.Controls.Add(this.tabPageInfo);
            this.tabControl1.Controls.Add(this.tabPageBag);
            this.tabControl1.Controls.Add(this.tabPageQC);
            this.tabControl1.Controls.Add(this.tabPageDeduc);
            this.tabControl1.Controls.Add(this.tabPageDivision);
            this.tabControl1.Controls.Add(this.tabPageCont);
            this.tabControl1.Controls.Add(this.tabPagePorla);
            this.tabControl1.Controls.Add(this.tabPageCopra);
            this.tabControl1.Controls.Add(this.tabPageDL);
            this.tabControl1.Dock = DockStyle.Bottom;
            this.tabControl1.Location = new Point(0, 0x1fc);
            this.tabControl1.Margin = new Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new Size(0x4bc, 0x124);
            this.tabControl1.TabIndex = 8;
            this.label32.AutoSize = true;
            this.label32.Location = new Point(0x237, 15);
            this.label32.Margin = new Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new Size(0x48, 0x11);
            this.label32.TabIndex = 100;
            this.label32.Text = "QC Status";
            this.textDocStatusLab.CharacterCasing = CharacterCasing.Upper;
            this.textDocStatusLab.Location = new Point(0x284, 11);
            this.textDocStatusLab.Margin = new Padding(4);
            this.textDocStatusLab.Name = "textDocStatusLab";
            this.textDocStatusLab.ReadOnly = true;
            this.textDocStatusLab.Size = new Size(0xb5, 0x16);
            this.textDocStatusLab.TabIndex = 0x65;
            base.AutoScaleDimensions = new SizeF(8f, 16f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x4bc, 800);
            base.ControlBox = false;
            base.Controls.Add(this.textDocStatusLab);
            base.Controls.Add(this.label32);
            base.Controls.Add(this.textGatepass);
            base.Controls.Add(this.labelGatepass);
            base.Controls.Add(this.textGPManual);
            base.Controls.Add(this.buttonTarraHistory);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.labTankerNo);
            base.Controls.Add(this.labelTransporterName);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textTruck2);
            base.Controls.Add(this.buttonDriver);
            base.Controls.Add(this.labelTransTypeName);
            base.Controls.Add(this.textTanker);
            base.Controls.Add(this.textDriverID);
            base.Controls.Add(this.labelTankerMax);
            base.Controls.Add(this.comTransType);
            base.Controls.Add(this.buttonTanker);
            base.Controls.Add(this.buttonTransporter);
            base.Controls.Add(this.labelTransType);
            base.Controls.Add(this.textTruck);
            base.Controls.Add(this.textTransporter);
            base.Controls.Add(this.buttonTruck);
            base.Controls.Add(this.label46);
            base.Controls.Add(this.textTrailerNo);
            base.Controls.Add(this.textReport_Date);
            base.Controls.Add(this.label37);
            base.Controls.Add(this.label21);
            base.Controls.Add(this.textRefNo);
            base.Controls.Add(this.checkEstate);
            base.Controls.Add(this.textRef_Date);
            base.Controls.Add(this.label35);
            base.Controls.Add(this.textVariance);
            base.Controls.Add(this.label45);
            base.Controls.Add(this.textCommType);
            base.Controls.Add(this.label33);
            base.Controls.Add(this.buttonReadIndicator);
            base.Controls.Add(this.buttonReset);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSavePrint);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.tabControl1);
            base.Controls.Add(this.textSEAL);
            base.Controls.Add(this.label19);
            base.Controls.Add(this.textNet);
            base.Controls.Add(this.label18);
            base.Controls.Add(this.textDeducTotal);
            base.Controls.Add(this.label17);
            base.Controls.Add(this.groupFactoryWeight);
            base.Controls.Add(this.groupOtherParty);
            base.Controls.Add(this.textRemarkReport);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.textRemarkTicket);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.textUnloading);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.textDN);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textDriverName);
            base.Controls.Add(this.labelDriverName);
            base.KeyPreview = true;
            base.Margin = new Padding(4);
            base.Name = "FormTransactionAfrica";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Transaction Entry";
            base.Load += new EventHandler(this.FormTransaction_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransaction_KeyPress);
            this.groupOtherParty.ResumeLayout(false);
            this.groupOtherParty.PerformLayout();
            this.groupFactoryWeight.ResumeLayout(false);
            this.groupFactoryWeight.PerformLayout();
            this.panel4X.ResumeLayout(false);
            this.panel4X.PerformLayout();
            this.tabPageBag.ResumeLayout(false);
            this.tabPageBag.PerformLayout();
            this.tabPageDL.ResumeLayout(false);
            this.tabPageDL.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((ISupportInitialize) this.dgvBatch).EndInit();
            this.tabPageCopra.ResumeLayout(false);
            this.tabPageCopra.PerformLayout();
            this.tabPagePorla.ResumeLayout(false);
            this.tabPagePorla.PerformLayout();
            ((ISupportInitialize) this.dgvDeducPorla).EndInit();
            this.tabPageCont.ResumeLayout(false);
            ((ISupportInitialize) this.dgvCont).EndInit();
            this.panel5.ResumeLayout(false);
            this.tabPageQC.ResumeLayout(false);
            this.tabPageQC.PerformLayout();
            ((ISupportInitialize) this.dgvQC_All).EndInit();
            ((ISupportInitialize) this.dgvQC).EndInit();
            this.tabPageDivision.ResumeLayout(false);
            ((ISupportInitialize) this.dgvDivBlock).EndInit();
            this.panel3.ResumeLayout(false);
            this.tabPageDeduc.ResumeLayout(false);
            this.tabPageDeduc.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((ISupportInitialize) this.dgvDeduc).EndInit();
            this.tabPageInfo.ResumeLayout(false);
            this.tabPageInfo.PerformLayout();
            this.panelInfo.ResumeLayout(false);
            this.panelInfo.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPageDO.ResumeLayout(false);
            ((ISupportInitialize) this.dgvDO).EndInit();
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void InitTable()
        {
            string str = ((this.pMode != "1ST") || (!this.tambahRecord || (this.WX != ""))) ? this.textRefNo.Text.Trim() : "~SZ~";
            this.tblTransDeduc.OpenTable("wb_TransactionD", "Select * from wb_TransactionD where Ref='" + str + "'", WBData.conn);
            this.tblTransDeducPorla.OpenTable("wb_TransactionPorla", "Select * from wb_TransactionPorla where Ref='" + str + "'", WBData.conn);
            this.tblTransCopra.OpenTable("wb_TransCopra", "Select * from wb_TransCopra where Ref='" + str + "'", WBData.conn);
            this.tblTransDO.OpenTable("wb_transDO", "Select * from wb_transDO where " + WBData.CompanyLocation(" And Ref='" + str + "'"), WBData.conn);
            this.tblTransQC.OpenTable("wb_TransQC", "Select * from wb_TransQC where " + WBData.CompanyLocation(" And Ref='" + str + "'"), WBData.conn);
            this.tblTransDiv.OpenTable("wb_transDivision", "Select * from wb_transDivision where " + WBData.CompanyLocation(" And Ref='" + str + "'"), WBData.conn);
            this.tblTransContainer.OpenTable("wb_transContainer", "Select * from wb_transContainer where " + WBData.CompanyLocation(" And Ref='" + str + "'"), WBData.conn);
            this.tblTruck.OpenTable("wb_truck", "Select * from wb_truck where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblCommD.OpenTable("wb_commodity_detail", "Select * from wb_commodity_detail", WBData.conn);
            this.tblDriver.OpenTable("wb_driver", "Select * from wb_driver where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblTransporter.OpenTable("wb_transporter", "Select * from wb_transporter where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblEstate.OpenTable("wb_estate", "Select * from wb_estate", WBData.conn);
            this.tblStorage.OpenTable("wb_storage", "Select * from wb_storage", WBData.conn);
            this.tblGrading.OpenTable("wb_grading", "Select * from wb_grading", WBData.conn);
            this.tblQC.OpenTable("wb_yield", "Select * from wb_yield", WBData.conn);
            this.tblTanker.OpenTable("wb_tanker", "Select * from wb_tanker", WBData.conn);
            this.tblTransType.OpenTable("wb_transaction_type", "Select * from wb_transaction_type", WBData.conn);
            this.tblSource.OpenTable("wb_source", "Select * from wb_source", WBData.conn);
            if (WBSetting.locType == "0")
            {
                this.tblMill.OpenTable("wb_mill", "Select * from wb_mill", WBData.conn);
            }
            else if (WBSetting.locType == "1")
            {
                this.tblDivision.OpenTable("wb_division", "Select * from wb_division", WBData.conn);
            }
            this.tblLoadUnload.OpenTable("wb_load_unload", "Select * from wb_load_unload", WBData.conn);
            this.tblBag.OpenTable("wb_bag", "Select * from wb_bag", WBData.conn);
            this.tblDOContainer.OpenTable("wb_transDo_container", "select * from wb_transDO_Container where Ref = '" + str + "'", WBData.conn);
            this.tblTransBatch.OpenTable("wb_transBatch", "SELECT * FROM wb_transBatch WHERE Ref like '" + str + "%'", WBData.conn);
            Program.AutoComp(this.tblTruck, "Truck_Number", this.textTruck);
            Program.AutoComp(this.tblDriver, "License_No", this.textDriverID);
            Program.AutoComp(this.tblDriver, "Name", this.textDriverName);
            Program.AutoComp(this.tblTransporter, "Transporter_Code", this.textTransporter);
            Program.AutoComp(this.tblSource, "Source_Code", this.textSource);
            Program.AutoComp(this.tblLoadUnload, "Load_unload", this.textBoxLoadUnload);
            Program.AutoComp(this.tblBag, "Bag_code", this.textBagCode);
            if (WBSetting.locType == "0")
            {
                Program.AutoComp(this.tblMill, "Mill_code", this.textMill);
            }
            if (WBSetting.locType == "1")
            {
                Program.AutoComp(this.tblDivision, "Division_code", this.textDivision);
            }
        }

        private void labelBagWeight_Click(object sender, EventArgs e)
        {
            if ((this.textTotalBag.Text.Trim() != "") && (this.labelBagWeight.Text.Trim() != ""))
            {
                this.textTotalBagWeight.Text = $"{Program.StrToDouble(this.labelBagWeight.Text, 2) * Program.StrToDouble(this.textTotalBag.Text, 2):#,##0.###}";
            }
        }

        private void loadDatagrid()
        {
            this.dgvDivBlock.ColumnCount = this.tblTransDiv.DT.Columns.Count;
            int num2 = 0;
            while (true)
            {
                if (num2 >= this.tblTransDiv.DT.Columns.Count)
                {
                    this.dgvDivBlock.Columns["Coy"].Visible = false;
                    this.dgvDivBlock.Columns["Location_Code"].Visible = false;
                    this.dgvDivBlock.Columns["SAP_Code"].Visible = false;
                    this.dgvDivBlock.Columns["Uniq"].Visible = false;
                    this.dgvDivBlock.Columns["UnitName"].Visible = false;
                    this.dgvDivBlock.Columns["Estate_Code"].HeaderText = Resource.Trans_084;
                    this.dgvDivBlock.Columns["Estate_Name"].HeaderText = Resource.Trans_085;
                    this.dgvDivBlock.Columns["Division_Code"].HeaderText = Resource.Trans_086;
                    this.dgvDivBlock.Columns["Division_Name"].HeaderText = Resource.Trans_087;
                    this.dgvDivBlock.Columns["Block_Code"].HeaderText = Resource.Trans_088;
                    this.dgvDivBlock.Columns["Block_Name"].HeaderText = Resource.Trans_089;
                    this.dgvDivBlock.Columns["YearPlanting"].HeaderText = Resource.Trans_090;
                    this.dgvDivBlock.Columns["UnitName"].HeaderText = Resource.Trans_068;
                    this.dgvDivBlock.Columns["Bunch"].HeaderText = Resource.Trans_091;
                    this.dgvDivBlock.Columns["Bunch"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDivBlock.Columns["Weight"].HeaderText = Resource.Trans_093;
                    this.dgvDivBlock.Columns["Weight"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDivBlock.Columns["Average"].HeaderText = Resource.Trans_092;
                    this.dgvDivBlock = this.tblTransDiv.ToDGV(this.dgvDivBlock);
                    this.dgvCont.ColumnCount = this.tblTransContainer.DT.Columns.Count;
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= this.tblTransContainer.DT.Columns.Count)
                        {
                            int num4 = 0;
                            while (true)
                            {
                                if (num4 >= this.dgvCont.Columns.Count)
                                {
                                    this.dgvCont.Columns["Container"].Visible = true;
                                    this.dgvCont.Columns["Container"].HeaderText = Resource.Trans_028;
                                    this.dgvCont.Columns["Seal"].Visible = true;
                                    this.dgvCont.Columns["Seal"].HeaderText = "Seal No.";
                                    this.dgvCont = this.tblTransContainer.ToDGV(this.dgvCont);
                                    this.dgvQC.ColumnCount = this.tblTransQC.DT.Columns.Count;
                                    this.dgvQC_All.ColumnCount = this.tblTransQC.DT.Columns.Count;
                                    int num5 = 0;
                                    while (true)
                                    {
                                        if (num5 >= this.tblTransQC.DT.Columns.Count)
                                        {
                                            int num6 = 0;
                                            while (true)
                                            {
                                                if (num6 >= this.dgvQC.Columns.Count)
                                                {
                                                    this.dgvQC.Columns["QCode"].Visible = true;
                                                    this.dgvQC.Columns["QCode"].ReadOnly = true;
                                                    this.dgvQC.Columns["QCode"].HeaderText = Resource.Trans_064;
                                                    this.dgvQC.Columns["QCode"].ReadOnly = true;
                                                    this.dgvQC.Columns["QCode"].DefaultCellStyle.BackColor = Color.LightGray;
                                                    this.dgvQC.Columns["QName"].Visible = true;
                                                    this.dgvQC.Columns["QName"].HeaderText = Resource.Trans_065;
                                                    this.dgvQC.Columns["QName"].ReadOnly = true;
                                                    this.dgvQC.Columns["QName"].DefaultCellStyle.BackColor = Color.LightGray;
                                                    this.dgvQC.Columns["Estate"].HeaderText = Resource.Trans_066;
                                                    this.dgvQC.Columns["Estate"].Visible = true;
                                                    this.dgvQC.Columns["Estate"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                    this.dgvQC.Columns["Estate"].DefaultCellStyle.Format = "N3";
                                                    this.dgvQC.Columns["Factory"].HeaderText = Resource.Trans_067;
                                                    this.dgvQC.Columns["Factory"].Visible = true;
                                                    this.dgvQC.Columns["Factory"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                    this.dgvQC.Columns["Factory"].DefaultCellStyle.Format = "N3";
                                                    this.dgvQC_All = this.tblTransQC.ToDGV(this.dgvQC_All);
                                                    this.dgvQC = this.tblTransQC.ToDGV(this.dgvQC);
                                                    this.dgvDO.ColumnCount = this.tblTransDO.DT.Columns.Count;
                                                    this.dgvDO.ColumnCount++;
                                                    int num = 0;
                                                    while (true)
                                                    {
                                                        if (num >= this.tblTransDO.DT.Columns.Count)
                                                        {
                                                            this.dgvDO.Columns[num].Name = "DeliNo";
                                                            this.dgvDO.Columns["Coy"].Visible = false;
                                                            this.dgvDO.Columns["Location_Code"].Visible = false;
                                                            this.dgvDO.Columns["uniq"].Visible = false;
                                                            this.dgvDO.Columns["ref"].Visible = false;
                                                            this.dgvDO.Columns["Date1"].Visible = false;
                                                            this.dgvDO.Columns["Date2"].Visible = false;
                                                            this.dgvDO.Columns["Date3"].Visible = false;
                                                            this.dgvDO.Columns["Date4"].Visible = false;
                                                            this.dgvDO.Columns["posted"].Visible = false;
                                                            this.dgvDO.Columns["Do_No"].HeaderText = Resource.Trans_025;
                                                            this.dgvDO.Columns["PI_No"].HeaderText = Resource.Trans_026;
                                                            this.dgvDO.Columns["Comm_Code"].HeaderText = Resource.Trans_027;
                                                            this.dgvDO.Columns["Transaction_Code"].HeaderText = "Tx";
                                                            this.dgvDO.Columns["Transporter_Code"].HeaderText = Resource.Trans_042;
                                                            this.dgvDO.Columns["Relation_Code"].HeaderText = Resource.Trans_029;
                                                            this.dgvDO.Columns["Relation_Name"].HeaderText = Resource.Trans_030;
                                                            this.dgvDO.Columns["Relation_Name"].Width = 300;
                                                            this.dgvDO.Columns["Netto"].HeaderText = Resource.Trans_038;
                                                            this.dgvDO.Columns["Netto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                            this.dgvDO.Columns["Netto"].DefaultCellStyle.Format = "N0";
                                                            this.dgvDO.Columns["Estate_qty"].HeaderText = Resource.Trans_035;
                                                            this.dgvDO.Columns["Estate_qty"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                            this.dgvDO.Columns["Estate_qty"].DefaultCellStyle.Format = "N0";
                                                            this.dgvDO.Columns["Bruto"].HeaderText = Resource.Trans_036;
                                                            this.dgvDO.Columns["Bruto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                            this.dgvDO.Columns["Bruto"].DefaultCellStyle.Format = "N0";
                                                            this.dgvDO.Columns["Tarra"].HeaderText = Resource.Trans_037;
                                                            this.dgvDO.Columns["Tarra"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                            this.dgvDO.Columns["Tarra"].DefaultCellStyle.Format = "N0";
                                                            this.dgvDO.Columns["ConvNett"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                            this.dgvDO.Columns["ConvNett"].DefaultCellStyle.Format = "N0";
                                                            this.dgvDO.Columns["DeliNo"].HeaderText = Resource.Trans_048;
                                                            this.dgvDO.Columns["DeliNo"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                            this.dgvDO.Columns["DeliNo"].DefaultCellStyle.Format = "N0";
                                                            this.dgvDO.Columns["Confirmation"].HeaderText = Resource.Trans_031;
                                                            this.dgvDO.Columns["Contract"].HeaderText = Resource.Trans_032;
                                                            this.dgvDO.Columns["Estate"].HeaderText = Resource.Trans_033;
                                                            this.dgvDO.Columns["Agen"].HeaderText = Resource.Trans_034;
                                                            this.dgvDO.Columns["Storage_Code"].HeaderText = Resource.Trans_039;
                                                            this.dgvDO.Columns["ConvNett"].HeaderText = Resource.Trans_040;
                                                            this.dgvDO.Columns["ConvUnit"].HeaderText = Resource.Trans_041;
                                                            this.dgvDO.Columns["STO1X"].HeaderText = Resource.Trans_043;
                                                            this.dgvDO.Columns["DO1X"].HeaderText = Resource.Trans_044;
                                                            this.dgvDO.Columns["SEAL"].HeaderText = Resource.Trans_045;
                                                            this.dgvDO.Columns["Tolling"].HeaderText = Resource.Trans_046;
                                                            this.dgvDO.Columns["Tolling_location"].HeaderText = Resource.Trans_047;
                                                            this.dgvDO = this.tblTransDO.ToDGV(this.dgvDO);
                                                            foreach (DataGridViewColumn column in this.dgvDO.Columns)
                                                            {
                                                                column.SortMode = DataGridViewColumnSortMode.NotSortable;
                                                            }
                                                            foreach (DataGridViewColumn column2 in this.dgvQC.Columns)
                                                            {
                                                                column2.SortMode = DataGridViewColumnSortMode.NotSortable;
                                                            }
                                                            this.dgvDOCont.ColumnCount = this.tblDOContainer.DT.Columns.Count;
                                                            int num8 = 0;
                                                            while (true)
                                                            {
                                                                if (num8 >= this.tblDOContainer.DT.Columns.Count)
                                                                {
                                                                    this.dgvDOCont.Rows.Clear();
                                                                    this.dgvDOCont.AllowUserToAddRows = false;
                                                                    this.dgvDOCont = this.tblDOContainer.ToDGV(this.dgvDOCont);
                                                                    if (this.dgvDO.Rows.Count > 0)
                                                                    {
                                                                        if (this.use_gunny == "Y")
                                                                        {
                                                                            this.label23.Hide();
                                                                            this.dgvDeduc.Hide();
                                                                            this.rectangleShape1.Hide();
                                                                            this.buttonAddDeduc.Hide();
                                                                            this.buttonEditDeduc.Hide();
                                                                            this.buttonDeleteDeduc.Hide();
                                                                            this.textAvg.Enabled = false;
                                                                        }
                                                                        else
                                                                        {
                                                                            this.label23.Show();
                                                                            this.dgvDeduc.Show();
                                                                            this.rectangleShape1.Show();
                                                                            this.buttonAddDeduc.Show();
                                                                            this.buttonEditDeduc.Show();
                                                                            this.buttonDeleteDeduc.Show();
                                                                            this.textAvg.Enabled = true;
                                                                        }
                                                                    }
                                                                    this.dgvBatch.ColumnCount = this.tblTransBatch.DT.Columns.Count;
                                                                    int num9 = 0;
                                                                    while (true)
                                                                    {
                                                                        if (num9 >= this.dgvBatch.ColumnCount)
                                                                        {
                                                                            this.dgvBatch.Columns["Uniq"].Visible = false;
                                                                            this.dgvBatch.Columns["Coy"].Visible = false;
                                                                            this.dgvBatch.Columns["Location_Code"].Visible = false;
                                                                            this.dgvBatch.Columns["SO_No"].Visible = false;
                                                                            this.dgvBatch.Columns["Do_No"].Visible = false;
                                                                            this.dgvBatch.Columns["Adopted"].Visible = false;
                                                                            this.dgvBatch.Columns["Approved"].Visible = false;
                                                                            this.dgvBatch.Columns["Num_of_Gunny"].HeaderText = "Num of Gunny";
                                                                            this.dgvBatch = this.tblTransBatch.ToDGV(this.dgvBatch);
                                                                            foreach (DataGridViewColumn column3 in this.dgvBatch.Columns)
                                                                            {
                                                                                column3.SortMode = DataGridViewColumnSortMode.NotSortable;
                                                                            }
                                                                            if (this.dgvBatch.Rows.Count > 0)
                                                                            {
                                                                                int num10 = 0;
                                                                                this.textDL.Text = this.dgvBatch.Rows[0].Cells["Do_No"].Value.ToString();
                                                                                this.textSTO.Text = this.dgvBatch.Rows[0].Cells["STO_No"].Value.ToString();
                                                                                this.SJAdopted = this.dgvBatch.Rows[0].Cells["Adopted"].Value.ToString() == "Y";
                                                                                this.SJApproved = this.dgvBatch.Rows[0].Cells["Approved"].Value.ToString() == "Y";
                                                                                foreach (DataGridViewRow row in (IEnumerable) this.dgvBatch.Rows)
                                                                                {
                                                                                    num10 += Convert.ToInt32(row.Cells["Netto"].Value);
                                                                                }
                                                                                this.textNettoBatch.Text = num10.ToString();
                                                                                this.textNettoBatch_Leave(this, this.e);
                                                                            }
                                                                            if (!WBUser.CheckTrustee("DL_ADOPT", "V"))
                                                                            {
                                                                                this.textDL.ReadOnly = true;
                                                                                this.textSTO.ReadOnly = true;
                                                                                this.dgvBatch.ReadOnly = true;
                                                                                this.button18.Enabled = false;
                                                                                this.buttonAdopt.Enabled = false;
                                                                                this.button19.Enabled = false;
                                                                                this.button20.Enabled = false;
                                                                            }
                                                                            this.dgvDeduc.ColumnCount = this.tblTransDeduc.DT.Columns.Count;
                                                                            int num11 = 0;
                                                                            while (true)
                                                                            {
                                                                                if (num11 >= this.tblTransDeduc.DT.Columns.Count)
                                                                                {
                                                                                    this.dgvDeduc.Columns["Coy"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Location_Code"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Ref"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Type"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Formula"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Variable"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Uniq"].Visible = false;
                                                                                    this.dgvDeduc.Columns["comm_code"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Deduc_by"].HeaderText = "D";
                                                                                    this.dgvDeduc.Columns["Deduc_by"].Width = 20;
                                                                                    this.dgvDeduc.Columns["KgDeduc"].HeaderText = "Deduction (Kg)";
                                                                                    this.dgvDeduc.Columns["KgDeduc"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                                                    this.dgvDeduc.Columns["KgDeduc"].DefaultCellStyle.Format = "N0";
                                                                                    this.dgvDeduc.Columns["PDeduc"].HeaderText = " % ";
                                                                                    this.dgvDeduc.Columns["PDeduc"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                                                    this.dgvDeduc.Columns["PDeduc"].DefaultCellStyle.Format = "N2";
                                                                                    this.dgvDeduc.Columns["QtyBunch"].HeaderText = " Qty of Unit";
                                                                                    this.dgvDeduc.Columns["QtyBunch"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                                                    this.dgvDeduc.Columns["QtyBunch"].DefaultCellStyle.Format = "N0";
                                                                                    this.dgvDeduc = this.tblTransDeduc.ToDGV(this.dgvDeduc);
                                                                                    this.dgvDeducPorla.ColumnCount = this.tblTransDeducPorla.DT.Columns.Count;
                                                                                    int num12 = 0;
                                                                                    while (true)
                                                                                    {
                                                                                        if (num12 >= this.tblTransDeducPorla.DT.Columns.Count)
                                                                                        {
                                                                                            this.dgvDeducPorla.Columns["Coy"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Location_Code"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Ref"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Type"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Formula"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Variable"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Uniq"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["comm_code"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Deduc_by"].HeaderText = "D";
                                                                                            this.dgvDeducPorla.Columns["Deduc_by"].Width = 20;
                                                                                            this.dgvDeducPorla.Columns["KgDeduc"].HeaderText = "Deduction (Kg)";
                                                                                            this.dgvDeducPorla.Columns["KgDeduc"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                                                            this.dgvDeducPorla.Columns["KgDeduc"].DefaultCellStyle.Format = "N0";
                                                                                            this.dgvDeducPorla.Columns["PDeduc"].HeaderText = " % ";
                                                                                            this.dgvDeducPorla.Columns["PDeduc"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                                                            this.dgvDeducPorla.Columns["PDeduc"].DefaultCellStyle.Format = "N2";
                                                                                            this.dgvDeducPorla.Columns["QtyBunch"].HeaderText = " Qty of Unit";
                                                                                            this.dgvDeducPorla.Columns["QtyBunch"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                                                            this.dgvDeducPorla.Columns["QtyBunch"].DefaultCellStyle.Format = "N0";
                                                                                            this.dgvDeducPorla = this.tblTransDeducPorla.ToDGV(this.dgvDeducPorla);
                                                                                            return;
                                                                                        }
                                                                                        this.dgvDeducPorla.Columns[num12].Name = this.tblTransDeducPorla.DT.Columns[num12].ColumnName;
                                                                                        num12++;
                                                                                    }
                                                                                }
                                                                                this.dgvDeduc.Columns[num11].Name = this.tblTransDeduc.DT.Columns[num11].ColumnName;
                                                                                num11++;
                                                                            }
                                                                        }
                                                                        this.dgvBatch.Columns[num9].Name = this.tblTransBatch.DT.Columns[num9].ColumnName;
                                                                        num9++;
                                                                    }
                                                                }
                                                                this.dgvDOCont.Columns[num8].Name = this.tblDOContainer.DT.Columns[num8].ColumnName;
                                                                num8++;
                                                            }
                                                        }
                                                        this.dgvDO.Columns[num].Name = this.tblTransDO.DT.Columns[num].ColumnName;
                                                        num++;
                                                    }
                                                }
                                                this.dgvQC.Columns[num6].Visible = false;
                                                num6++;
                                            }
                                        }
                                        this.dgvQC.Columns[num5].Name = this.tblTransQC.DT.Columns[num5].ColumnName;
                                        this.dgvQC_All.Columns[num5].Name = this.tblTransQC.DT.Columns[num5].ColumnName;
                                        num5++;
                                    }
                                }
                                this.dgvCont.Columns[num4].Visible = false;
                                num4++;
                            }
                        }
                        this.dgvCont.Columns[num3].Name = this.tblTransContainer.DT.Columns[num3].ColumnName;
                        num3++;
                    }
                }
                this.dgvDivBlock.Columns[num2].Name = this.tblTransDiv.DT.Columns[num2].ColumnName;
                num2++;
            }
        }

        private void panelInfo_Paint(object sender, PaintEventArgs e)
        {
        }

        private void panelMainInfo_Paint(object sender, PaintEventArgs e)
        {
        }

        private void print(string refno, ReportDocument cryRpt)
        {
            string[] paramName = new string[2];
            string[] paramValue = new string[] { refno, WBUser.UserName };
            paramName[0] = "ref";
            paramName[1] = "user";
            cryRpt.Refresh();
            cryRpt = Program.setParam2(this.ticket2Rpt, paramName, paramValue);
            this.fRpt.setReport(cryRpt);
            if (WBData.sCheckDirect == "Y")
            {
                cryRpt.PrintToPrinter(1, false, 0, 0);
            }
            else
            {
                this.fRpt.ShowDialog();
                if (this.fRpt.doPrint)
                {
                    cryRpt.PrintToPrinter(1, true, 0, 0);
                }
            }
        }

        private void print(string refno, string Do_No, ReportDocument cryRpt)
        {
            string[] paramName = new string[3];
            string[] paramValue = new string[] { refno, Do_No, WBUser.UserName };
            paramName[0] = "ref";
            paramName[1] = "Do_No";
            paramName[2] = "user";
            cryRpt.Refresh();
            cryRpt = Program.setParam2(this.ticketRpt, paramName, paramValue);
            this.fRpt.setReport(cryRpt);
            if (WBData.sCheckDirect == "Y")
            {
                cryRpt.PrintToPrinter(1, false, 0, 0);
            }
            else
            {
                this.fRpt.ShowDialog();
                if (this.fRpt.doPrint)
                {
                    cryRpt.PrintToPrinter(1, true, 0, 0);
                }
            }
        }

        private void radioGHG1_CheckedChanged(object sender, EventArgs e)
        {
            this.textGHG.Enabled = false;
        }

        private void radioGHG2_CheckedChanged(object sender, EventArgs e)
        {
            this.textGHG.Enabled = true;
            this.textGHG.Focus();
        }

        private DataRow ReplaceDOitem(string[] pArg) => 
            this.tblTransDO.DR;

        private void saveTransSplit(string pUniq)
        {
            int num = 0x40;
            string str = "";
            string keyField = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_transaction", "Select * From wb_transaction where Uniq=" + pUniq.Trim(), WBData.conn);
            DataRow row = table.DT.Rows[0];
            str = row["Ref"].ToString();
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_transSplit", "Select * From wb_transSplit where " + WBData.CompanyLocation(" and ref = '" + row["Ref"].ToString() + "'"), WBData.conn);
            if (table2.DT.Rows.Count > 0)
            {
                keyField = table2.DT.Rows[0]["uniq"].ToString();
                table2.DT.Rows[0].Delete();
                table2.Save();
                table2.ReOpen();
                string[] textArray1 = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] textArray2 = new string[] { this.logMode, WBUser.UserID, this.logReason };
                Program.updateLogHeader("wb_transSplit", keyField, textArray1, textArray2);
            }
            table2.DR = table2.DT.NewRow();
            foreach (DataColumn column in table2.DT.Columns)
            {
                if (column.ColumnName.ToUpper() != "UNIQ")
                {
                    table2.DR[column.ColumnName] = row[column.ColumnName];
                }
            }
            table2.DT.Rows.Add(table2.DR);
            table2.Save();
            table2.Dispose();
            string sqltext = (((((("SELECT uniq FROM wb_transSplit WHERE " + WBData.CompanyLocation("")) + " AND Ref = '" + row["Ref"].ToString() + "'") + " AND Do_No = '" + row["Do_No"].ToString() + "'") + " AND Gross = '" + row["Gross"].ToString() + "'") + " AND Tare = '" + row["Tare"].ToString() + "'") + " AND Received = '" + row["Received"].ToString() + "'") + " AND Net = '" + row["Net"].ToString() + "'";
            WBTable table3 = new WBTable();
            table3.OpenTable("wb_transSplit", sqltext, WBData.conn);
            keyField = table3.DT.Rows[0]["uniq"].ToString();
            table3.Dispose();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { this.logMode, WBUser.UserID, this.logReason };
            Program.updateLogHeader("wb_transSplit", keyField, logField, logValue);
            int num2 = 0;
            while (true)
            {
                if (num2 >= this.dgvDO.Rows.Count)
                {
                    table.Dispose();
                    return;
                }
                keyField = "";
                if (num2 == 0)
                {
                    table.DR = table.DT.Rows[num2];
                    table.DR.BeginEdit();
                    table.DR["Split"] = "Y";
                    if (table.DR["WX"].ToString() == "2X")
                    {
                        if (Program.StrToDouble(table.DR["_1ST"].ToString(), 0) > Program.StrToDouble(table.DR["_2ND"].ToString(), 0))
                        {
                            table.DR["_1ST"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                        }
                        else
                        {
                            table.DR["_2ND"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                        }
                    }
                    table.DR["Gross_estate"] = Program.StrToDouble(table.DR["Tare_Estate"].ToString(), 0) + Program.StrToDouble(this.dgvDO.Rows[num2].Cells["estate_qty"].Value.ToString(), 0);
                    table.DR["net_estate"] = this.dgvDO.Rows[num2].Cells["estate_qty"].Value.ToString();
                    table.DR["Gross"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                    table.DR["Tare"] = this.dgvDO.Rows[num2].Cells["Tarra"].Value.ToString();
                    table.DR["Received"] = Convert.ToString((double) (Convert.ToDouble(this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString()) - Convert.ToDouble(this.dgvDO.Rows[num2].Cells["Tarra"].Value.ToString())));
                    table.DR["Net"] = this.dgvDO.Rows[num2].Cells["Netto"].Value.ToString();
                    table.DR["posted"] = "N";
                    table.DR["checksum"] = table.Checksum(table.DR);
                    table.DR.EndEdit();
                    table.Save();
                    keyField = table.DR["uniq"].ToString();
                }
                else
                {
                    table.ReOpen();
                    row = table.DT.Rows[0];
                    table.DR = table.DT.NewRow();
                    table.DR = table.DT.NewRow();
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= table.DT.Columns.Count)
                        {
                            table.DR["Split"] = "X";
                            if (table.DR["WX"].ToString() == "2X")
                            {
                                if (Program.StrToDouble(table.DR["_1ST"].ToString(), 0) > Program.StrToDouble(table.DR["_2ND"].ToString(), 0))
                                {
                                    table.DR["_1ST"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                                    table.DR["_2ND"] = "0";
                                }
                                else
                                {
                                    table.DR["_1ST"] = "0";
                                    table.DR["_2ND"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                                }
                            }
                            num++;
                            this.tblDO.OpenTable("tmpDO", "select * from wb_contract where " + WBData.CompanyLocation(" and DO_NO = '" + this.dgvDO.Rows[num2].Cells["DO_NO"].Value.ToString() + "'"), WBData.conn);
                            DataRow row2 = this.tblDO.DT.Rows[0];
                            table.DR["Delivery_Note"] = (this.dgvDO.Rows[num2].Cells["DeliNo"].Value != null) ? this.dgvDO.Rows[num2].Cells["DeliNo"].Value.ToString() : "";
                            this.tblComm.OpenTable("tmpComm", "select * from wb_commodity where " + WBData.CompanyLocation(" and comm_Code = '" + row2["Comm_code"].ToString() + "'"), WBData.conn);
                            DataRow row3 = this.tblComm.DT.Rows[0];
                            if ((row3["type"].ToString().Trim() == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                            {
                                string[] textArray5 = new string[] { WBData.sCoyCode.Trim(), "/", row2["comm_code"].ToString().Trim(), "/", this.SetNoSPB(true) };
                                table.DR["Delivery_Note"] = string.Concat(textArray5);
                            }
                            else if ((row3["type"].ToString().Trim() == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                            {
                                string[] textArray6 = new string[] { WBData.sCoyCode.Trim(), "/", row2["comm_code"].ToString().Trim(), "/", this.SetNoSPB(true) };
                                table.DR["Delivery_Note"] = string.Concat(textArray6);
                            }
                            table.DR["Ref"] = str + Convert.ToChar(num).ToString();
                            table.DR["Gross_estate"] = this.dgvDO.Rows[num2].Cells["estate_qty"].Value.ToString();
                            table.DR["DO_No"] = this.dgvDO.Rows[num2].Cells["DO_No"].Value.ToString();
                            if (WBSetting.checkISCC == "Y")
                            {
                                if (row2["ISCC"].ToString() != "Y")
                                {
                                    table.DR["ISCC_Checked"] = "N";
                                    table.DR["ISCC_No"] = "";
                                    table.DR["ISCC_No2"] = "";
                                    table.DR["ISCC_Weight"] = Convert.ToDouble(0);
                                    table.DR["ISCC_GC_Checked"] = "N";
                                }
                                else
                                {
                                    table.DR["ISCC_Checked"] = "Y";
                                    this.setISCC();
                                    table.DR["ISCC_No"] = this.textISCC.Text.Trim();
                                    table.DR["ISCC_No2"] = this.SetNoISCC(true);
                                    table.DR["ISCC_Weight"] = Convert.ToDouble(this.textGHG.Text);
                                    table.DR["ISCC_GC_Checked"] = this.radioGHG1.Checked ? "Y" : "N";
                                }
                            }
                            table.DR["net_estate"] = this.dgvDO.Rows[num2].Cells["estate_qty"].Value.ToString();
                            table.DR["Tare_estate"] = "0";
                            table.DR["Relation_Code"] = this.dgvDO.Rows[num2].Cells["Relation_Code"].Value.ToString();
                            table.DR["Gross"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                            table.DR["Tare"] = this.dgvDO.Rows[num2].Cells["Tarra"].Value.ToString();
                            table.DR["Printed"] = "0";
                            table.DR["Received"] = Convert.ToString((double) (Program.StrToDouble(this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString(), 0) - Program.StrToDouble(this.dgvDO.Rows[num2].Cells["Tarra"].Value.ToString(), 0)));
                            table.DR["Net"] = this.dgvDO.Rows[num2].Cells["Netto"].Value.ToString();
                            table.DR["Deduction"] = "0";
                            table.DR["posted"] = "N";
                            table.DR["checksum"] = table.Checksum(table.DR);
                            table.DT.Rows.Add(table.DR);
                            table.Save();
                            WBTable table4 = new WBTable();
                            table4.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Ref = '" + table.DR["Ref"].ToString() + "'"), WBData.conn);
                            keyField = table4.DT.Rows[0]["uniq"].ToString();
                            table4.Dispose();
                            break;
                        }
                        bool flag6 = table.DT.Columns[num3].ColumnName.ToUpper() != "UNIQ";
                        if (flag6 && (row[num3].ToString().Trim() != ""))
                        {
                            table.DR[table.DT.Columns[num3].ColumnName] = row[num3].ToString();
                        }
                        num3++;
                    }
                }
                string[] textArray7 = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] textArray8 = new string[] { this.logMode, WBUser.UserID, this.logReason };
                Program.updateLogHeader("wb_transaction", keyField, textArray7, textArray8);
                num2++;
            }
        }

        private void setISCC()
        {
            if (!this.checkISCC.Checked)
            {
                this.textISCC.Enabled = false;
                this.radioGHG1.Enabled = false;
                this.radioGHG2.Enabled = false;
                this.textGHG.Text = "0.000";
                this.textGHG.Enabled = false;
            }
            else
            {
                this.textISCC.Text = WBSetting.Field("ISCC_No").ToString().Trim();
                this.radioGHG1.Enabled = true;
                this.radioGHG2.Enabled = true;
                if (WBSetting.Field("ISCC_GC_Checked").ToString() == "Y")
                {
                    this.radioGHG1.Checked = true;
                    this.textGHG.Text = "0";
                }
                else
                {
                    this.textGHG.Text = (this.CommType == "") ? "0.000" : WBSetting.Field("ISCC_Weight_" + this.CommType);
                    this.textGHG.Enabled = true;
                    this.textISCC.Enabled = true;
                }
            }
        }

        private string SetNoISCC(bool pSave)
        {
            string str = "";
            DateTime time = DateTime.Parse(this.textDate1st.Text);
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "Select * From wb_ref where ", WBData.CompanyLocation(""), " and Ref_Code = 'ISCC' and Ref_Year ='", DateTime.Now.Year.ToString(), "' and Ref_Month = '", DateTime.Now.Month.ToString(), "'" };
            table.OpenTable("wb_ref", string.Concat(textArray1), WBData.conn);
            if (table.DT.Rows.Count == 0)
            {
                table.DR = table.DT.NewRow();
                table.DR["Coy"] = WBData.sCoyCode;
                table.DR["Location_code"] = WBData.sLocCode;
                table.DR["Ref_Code"] = "ISCC";
                table.DR["Ref_Year"] = DateTime.Now.Year.ToString();
                table.DR["Ref_Month"] = DateTime.Now.Month.ToString();
                table.DR["Ref_No"] = "0";
                table.DT.Rows.Add(table.DR);
                table.Save();
                table.ReOpen();
            }
            DataRow row = table.DT.Rows[0];
            string str2 = row["Ref_No"].ToString();
            this.nRef = Convert.ToInt32(str2) + 1;
            str = this.nRef.ToString().Trim().PadLeft(4, '0');
            str = row["Ref_Year"].ToString().PadLeft(2, '0') + row["Ref_month"].ToString().PadLeft(2, '0') + "-" + str;
            if (pSave)
            {
                table.ReOpen();
                table.DR = table.DT.Rows[0];
                table.DR.BeginEdit();
                table.DR["Ref_No"] = this.nRef.ToString();
                table.DR.EndEdit();
                table.Save();
            }
            table.Close();
            table.Dispose();
            return str;
        }

        private string SetNoref(bool pSave)
        {
            DataRow row;
            string str = "";
            int totalWidth = 7;
            DateTime time = DateTime.Parse(this.textDate1st.Text);
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            if (pSave)
            {
                string keyField = "";
                bool flag2 = true;
                bool flag3 = false;
                string str4 = "";
                while (true)
                {
                    if (!flag2)
                    {
                        break;
                    }
                    table2.OpenTable("wb_location", "Select * From wb_location Where " + WBData.CompanyLocation(""), WBData.conn);
                    row = table2.DT.Rows[0];
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 < 5)
                        {
                            table2.ReOpen();
                            row = table2.DT.Rows[0];
                            keyField = row["uniq"].ToString();
                            if ((row["ref_lock"].ToString().Trim().ToUpper() != "N") && (row["ref_lock"].ToString().Trim() != ""))
                            {
                                str4 = row["ref_lockBy"].ToString().Trim().ToUpper();
                                flag3 = true;
                                num2++;
                                continue;
                            }
                            row.BeginEdit();
                            row["ref_lock"] = "Y";
                            row["ref_lockBy"] = WBSetting.WBCode;
                            row.EndEdit();
                            table2.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "REFLOCK", WBUser.UserID, "Lock reference no when weighing" };
                            Program.updateLogHeader("wb_location", keyField, logField, logValue);
                            table2.ReOpen();
                            row = table2.DT.Rows[0];
                            flag3 = false;
                            flag2 = false;
                        }
                        if (flag3 && (MessageBox.Show(" Save Data Failed, Locked by " + str4 + ".\n\n Retry Save Data? ", "R E T R Y...", MessageBoxButtons.OK, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK))
                        {
                            flag2 = true;
                        }
                        break;
                    }
                }
            }
            table2.OpenTable("wb_location", "Select * From wb_location Where " + WBData.CompanyLocation(""), WBData.conn);
            row = table2.DT.Rows[0];
            string str2 = (row["Ref_No"].ToString().Trim() == "") ? "0" : row["Ref_No"].ToString().Trim();
            if ((WBSetting.Ref6 == "Y") && (WBSetting.date6 != ""))
            {
                try
                {
                    if (Convert.ToDateTime(Convert.ToDateTime(this.textRef_Date.Text).ToShortDateString()) >= Convert.ToDateTime(Convert.ToDateTime(WBSetting.date6).ToShortDateString()))
                    {
                        totalWidth = 6;
                    }
                }
                catch
                {
                    totalWidth = 7;
                }
            }
            while (true)
            {
                this.nRef = Convert.ToInt32(str2) + 1;
                str = this.nRef.ToString().Trim().PadLeft(totalWidth, '0');
                str = WBData.sCoyCode.Trim() + WBData.sLocCode.Trim() + str;
                str2 = this.nRef.ToString().Trim();
                table.OpenTable("wb_transaction", "Select Ref From wb_transaction Where " + WBData.CompanyLocation(" AND Ref='" + str + "'"), WBData.conn);
                if (table.DT.Rows.Count == 0)
                {
                    if (pSave)
                    {
                        string keyField = "";
                        table2.ReOpen();
                        table2.DR = table2.DT.Rows[0];
                        keyField = table2.DR["uniq"].ToString();
                        table2.DR.BeginEdit();
                        table2.DR["Ref_No"] = this.nRef.ToString();
                        table2.DR["Ref_Lock"] = "N";
                        table2.DR.EndEdit();
                        table2.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "REFLOCK", WBUser.UserID, "Unlock reference no when weighing" };
                        Program.updateLogHeader("wb_location", keyField, logField, logValue);
                    }
                    table2.Close();
                    table2.Dispose();
                    return str;
                }
            }
        }

        private string SetNorefManual()
        {
            string str = "";
            int totalWidth = 7;
            DateTime time = DateTime.Parse(this.textDate1st.Text);
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_location", "Select Ref_No, CurrEntry, StartRef, uniq From wb_location Where " + WBData.CompanyLocation(""), WBData.conn);
            DataRow row = table2.DT.Rows[0];
            string str2 = (Convert.ToDouble((row["StartRef"].ToString().Trim() == "") ? "0" : Program.shoot(row["StartRef"].ToString().Trim(), false)) + Convert.ToDouble(Program.shoot(row["CurrEntry"].ToString().Trim(), false))).ToString();
            if ((WBSetting.Ref6 == "Y") && (WBSetting.date6 != ""))
            {
                try
                {
                    if (Convert.ToDateTime(Convert.ToDateTime(this.textRef_Date.Text).ToShortDateString()) >= Convert.ToDateTime(Convert.ToDateTime(WBSetting.date6).ToShortDateString()))
                    {
                        totalWidth = 6;
                    }
                }
                catch
                {
                    totalWidth = 7;
                }
            }
            while (true)
            {
                this.nRef = Convert.ToInt32(str2) + 1;
                str = this.nRef.ToString().Trim().PadLeft(totalWidth, '0');
                str = WBData.sCoyCode.Trim() + WBData.sLocCode.Trim() + str;
                str2 = this.nRef.ToString().Trim();
                table.OpenTable("wb_transaction", "Select Ref From wb_transaction Where " + WBData.CompanyLocation(" AND Ref='" + str + "'"), WBData.conn);
                if (table.DT.Rows.Count == 0)
                {
                    table2.Close();
                    table2.Dispose();
                    return str;
                }
            }
        }

        private string SetNoSPB(bool pSave)
        {
            string str = "";
            DateTime time = DateTime.Parse(this.textDate1st.Text);
            WBTable table = new WBTable();
            string[] textArray1 = new string[9];
            textArray1[0] = "Select * From wb_ref where ";
            textArray1[1] = WBData.CompanyLocation("");
            textArray1[2] = " and Ref_Code = 'AUTOSPB";
            textArray1[3] = this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim();
            textArray1[4] = "' and Ref_Year ='";
            textArray1[5] = DateTime.Now.Year.ToString();
            textArray1[6] = "' and Ref_Month = '";
            textArray1[7] = DateTime.Now.Month.ToString();
            textArray1[8] = "'";
            table.OpenTable("wb_ref", string.Concat(textArray1), WBData.conn);
            if (table.DT.Rows.Count == 0)
            {
                table.DR = table.DT.NewRow();
                table.DR["Coy"] = WBData.sCoyCode;
                table.DR["Location_code"] = WBData.sLocCode;
                table.DR["Ref_Code"] = "AUTOSPB" + this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim();
                table.DR["Ref_Year"] = DateTime.Now.Year.ToString();
                table.DR["Ref_Month"] = DateTime.Now.Month.ToString();
                table.DR["Ref_No"] = "0";
                table.DT.Rows.Add(table.DR);
                table.Save();
                table.ReOpen();
            }
            string str2 = table.DT.Rows[0]["Ref_No"].ToString();
            this.nRef = Convert.ToInt32(str2) + 1;
            str = this.nRef.ToString().Trim().PadLeft(4, '0');
            if (pSave)
            {
                table.ReOpen();
                table.DR = table.DT.Rows[0];
                table.DR.BeginEdit();
                table.DR["Ref_No"] = this.nRef.ToString();
                table.DR.EndEdit();
                table.Save();
            }
            table.Close();
            table.Dispose();
            return str;
        }

        private void settingTabControl()
        {
            if ((Convert.ToInt16(this.textBunchTotal.Text.Trim()) > 0) && (this.dgvBatch.Rows.Count <= 0))
            {
                this.textGunnyBatchLeft.Text = this.textBunchTotal.Text;
                this.textNettoBatchLeft.Text = this.textNet.Text.Replace(",", "");
            }
            else if (this.dgvBatch.Rows.Count > 0)
            {
                int num = 0;
                int num2 = 0;
                foreach (DataGridViewRow row in (IEnumerable) this.dgvBatch.Rows)
                {
                    num += Convert.ToInt32(row.Cells["Num_of_Gunny"].Value);
                    num2 += Convert.ToInt32(row.Cells["Netto"].Value);
                }
                this.textGunnyBatchLeft.Text = (Convert.ToInt32(this.textBunchTotal.Text) - num);
                this.textNettoBatchLeft.Text = (Convert.ToInt32(this.textNet.Text.Replace(",", "")) - num2);
            }
            if ((((this.pMode != "VIEW") && (this.pMode != "QC")) && (this.pMode != "DL")) && ((this.pMode != "VIEW") && (this.pMode != "QC")))
            {
                this.combodgvDO.Items.Clear();
                this.combodgvDO.Text = "";
                foreach (DataGridViewRow row2 in (IEnumerable) this.dgvDO.Rows)
                {
                    this.combodgvDO.Items.Add(row2.Cells["DO_No"].Value.ToString());
                    if (this.combodgvDO.Text == "")
                    {
                        this.combodgvDO.Text = row2.Cells["DO_No"].Value.ToString();
                    }
                }
                if (WBSetting.locType == "1")
                {
                    this.dgvDivBlock.Columns["UnitName"].HeaderText = this.textUnitName.Text;
                    this.dgvDivBlock.Columns["Bunch"].HeaderText = "Qty of " + this.textUnitName.Text;
                    if (WBUser.UserLevel == "3")
                    {
                        if ((((this.pMode != "2ND") && (this.pMode != "1ST")) || (this.text2nd.Text.Trim() != "0")) ? (((this.pMode == "EDIT") && (this.spMode == "QTY")) && (this.text2nd.Text.Trim() == "0")) : true)
                        {
                            this.dgvDeduc.Enabled = false;
                            this.buttonDeleteDeduc.Enabled = false;
                            this.buttonEditDeduc.Enabled = false;
                            this.buttonAddDeduc.Enabled = false;
                            this.textBunchDeduc.Enabled = false;
                            this.textBunchTotal.Enabled = false;
                            this.textAvg.Enabled = false;
                            this.dgvDeducPorla.Enabled = false;
                            this.buttonAddPorla.Enabled = false;
                            this.buttonEditPorla.Enabled = false;
                            this.buttonDeletePorla.Enabled = false;
                            this.buttonSavePrintGrading.Enabled = false;
                        }
                        else
                        {
                            this.dgvDeduc.Enabled = true;
                            this.buttonDeleteDeduc.Enabled = true;
                            this.buttonEditDeduc.Enabled = true;
                            this.buttonAddDeduc.Enabled = true;
                            this.textBunchDeduc.Enabled = true;
                            this.textBunchTotal.Enabled = true;
                            this.textAvg.Enabled = true;
                            this.dgvDeducPorla.Enabled = true;
                            this.buttonAddPorla.Enabled = true;
                            this.buttonEditPorla.Enabled = true;
                            this.buttonDeletePorla.Enabled = true;
                            this.buttonSavePrintGrading.Enabled = true;
                        }
                    }
                    else if (this.text2nd.Text.Trim() == "0")
                    {
                        this.dgvDeduc.Enabled = false;
                        this.buttonDeleteDeduc.Enabled = false;
                        this.buttonEditDeduc.Enabled = false;
                        this.buttonAddDeduc.Enabled = false;
                        this.textBunchDeduc.Enabled = false;
                        this.textBunchTotal.Enabled = false;
                        this.textAvg.Enabled = false;
                        this.dgvDeducPorla.Enabled = false;
                        this.buttonAddPorla.Enabled = false;
                        this.buttonEditPorla.Enabled = false;
                        this.buttonDeletePorla.Enabled = false;
                        this.buttonSavePrintGrading.Enabled = false;
                    }
                    else
                    {
                        this.dgvDeduc.Enabled = true;
                        this.buttonDeleteDeduc.Enabled = true;
                        this.buttonEditDeduc.Enabled = true;
                        this.buttonAddDeduc.Enabled = true;
                        this.textBunchDeduc.Enabled = true;
                        this.textBunchTotal.Enabled = true;
                        this.textAvg.Enabled = true;
                        this.dgvDeducPorla.Enabled = true;
                        this.buttonAddPorla.Enabled = true;
                        this.buttonEditPorla.Enabled = true;
                        this.buttonDeletePorla.Enabled = true;
                        this.buttonSavePrintGrading.Enabled = true;
                    }
                    if (this.textBunchTotal.Text.Trim() != "")
                    {
                        this.BJR();
                    }
                }
            }
        }

        private bool Simpan()
        {
            bool flag2;
            DateTime time = Convert.ToDateTime(this.textRef_Date.Text.ToString());
            if (this.dateDelivery.Value.Date <= time.Date)
            {
                if ((this.pMode == "2ND") && ((WBSetting.locType == "1") && ((this.CommType == "F") && ((this.textBunchTotal.Text.Trim() == "") || (this.textBunchTotal.Text.Trim() == "0")))))
                {
                    if (MessageBox.Show("Total Bunch is 0, Save Data Transaction?", "WARNING", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                    {
                        return false;
                    }
                    else
                    {
                        this.textBunchTotal.Text = "0";
                    }
                }
                if ((this.dgvDO.Rows.Count > 0) || (this.WX == ""))
                {
                    if (this.pMode != "1ST")
                    {
                        if (this.pMode != "2ND")
                        {
                            if (this.pMode != "3RD")
                            {
                                if (this.pMode != "4TH")
                                {
                                    if (this.pMode != "MANUAL")
                                    {
                                        if ((this.pMode == "SPLIT") && (this.dgvDO.Rows.Count == 1))
                                        {
                                            MessageBox.Show(Resource.Mes_329, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            return false;
                                        }
                                    }
                                    else if (this.textDate1st.Text.Trim() != "")
                                    {
                                        if (this.textDate2nd.Text.Trim() != "")
                                        {
                                            if (this.textTime1st.Text.Trim() != "")
                                            {
                                                if (this.textTime2nd.Text.Trim() != "")
                                                {
                                                    if (this.textReport_Date.Text.Trim() != "")
                                                    {
                                                        if (this.textRef_Date.Text.Trim() != "")
                                                        {
                                                            if (this.textRefNo.Text.Trim() != "")
                                                            {
                                                                if (this.text1st.Text.Trim() != "")
                                                                {
                                                                    if (this.text2nd.Text.Trim() != "")
                                                                    {
                                                                        if (this.WX == "4X")
                                                                        {
                                                                            if (this.textDate3rd.Text.Trim() != "")
                                                                            {
                                                                                if (this.textDate4th.Text.Trim() != "")
                                                                                {
                                                                                    if (this.textTime3rd.Text.Trim() != "")
                                                                                    {
                                                                                        if (this.textTime4th.Text.Trim() != "")
                                                                                        {
                                                                                            if (this.text3rd.Text.Trim() != "")
                                                                                            {
                                                                                                if (this.text4th.Text.Trim() == "")
                                                                                                {
                                                                                                    MessageBox.Show(Resource.Mes_298, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                                    this.text4th.Focus();
                                                                                                    return false;
                                                                                                }
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                MessageBox.Show(Resource.Mes_297, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                                this.text3rd.Focus();
                                                                                                return false;
                                                                                            }
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            MessageBox.Show(Resource.Mes_312, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                            this.textTime4th.Focus();
                                                                                            return false;
                                                                                        }
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        MessageBox.Show(Resource.Mes_311, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                        this.textTime3rd.Focus();
                                                                                        return false;
                                                                                    }
                                                                                }
                                                                                else
                                                                                {
                                                                                    MessageBox.Show(Resource.Mes_302, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                    this.textDate4th.Focus();
                                                                                    return false;
                                                                                }
                                                                            }
                                                                            else
                                                                            {
                                                                                MessageBox.Show(Resource.Mes_301, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                this.textDate3rd.Focus();
                                                                                return false;
                                                                            }
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        MessageBox.Show(Resource.Mes_296, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                        this.text2nd.Focus();
                                                                        return false;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    MessageBox.Show(Resource.Mes_295, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                    this.text1st.Focus();
                                                                    return false;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                MessageBox.Show(Resource.Mes_307, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                this.textRefNo.Focus();
                                                                return false;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            MessageBox.Show(Resource.Mes_306, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                            this.textRef_Date.Focus();
                                                            return false;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        MessageBox.Show(Resource.Mes_308, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                        this.textRef_Date.Focus();
                                                        return false;
                                                    }
                                                }
                                                else
                                                {
                                                    MessageBox.Show(Resource.Mes_310, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                    this.textTime2nd.Focus();
                                                    return false;
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show(Resource.Mes_309, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                this.textTime1st.Focus();
                                                return false;
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show(Resource.Mes_300, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            this.textDate2nd.Focus();
                                            return false;
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show(Resource.Mes_299, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        this.textDate1st.Focus();
                                        return false;
                                    }
                                }
                                else if (Convert.ToDouble(this.text4th.Text.Trim()) != 0.0)
                                {
                                    if (this.checkOverQty())
                                    {
                                        return false;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(Resource.Mes_317, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    return false;
                                }
                            }
                            else if (!(Convert.ToDouble(this.text3rd.Text.Trim()) != 0.0))
                            {
                                MessageBox.Show(Resource.Mes_317, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                return false;
                            }
                        }
                        else if (Convert.ToDouble(this.text2nd.Text.Trim()) != 0.0)
                        {
                            if (this.checkOverQty())
                            {
                                return false;
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_317, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return false;
                        }
                    }
                    else if (((this.WX != "") && !(Convert.ToDouble(this.text1st.Text.Trim()) != 0.0)) & (this.pMode == "1ST"))
                    {
                        MessageBox.Show(Resource.Mes_317, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return false;
                    }
                    if (((this.dgvDO.Rows.Count <= 1) || (this.WX != "2X")) || this.checkQtySplitDO())
                    {
                        if (WBSetting.locType == "1")
                        {
                            if (this.textCust.Text != "")
                            {
                                double num4 = 0.0;
                                this.tblCust.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" and relation_code = '" + this.textCust.Text.Trim() + "' and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
                                string[] aField = new string[] { "Relation_Code" };
                                string[] textArray2 = new string[] { this.textCust.Text.Trim() };
                                this.tblCust.DR = this.tblCust.GetData(aField, textArray2);
                                if ((this.tblCust.DR != null) && (this.tblCust.DR["DailyQuantity"].ToString() == "Y"))
                                {
                                    if (this.tblCust.DR["Quantity"].ToString().Trim() != "")
                                    {
                                        num4 = Program.StrToDouble(this.tblCust.DR["Quantity"].ToString(), 0);
                                    }
                                    if (num4 > (this.hitQtyToday(this.textRefNo.Text, this.textRef_Date.Text, this.textCust.Text) + Program.StrToDouble(this.textNet.Text, 0)))
                                    {
                                        string[] textArray3 = new string[] { this.textCust.Text, " ", Resource.Mes_331, "  ", num4.ToString() };
                                        MessageBox.Show(string.Concat(textArray3), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    }
                                }
                            }
                            if (!WBSetting.CheckSPB() || !(this.checkDoubleSPB() & (this.textDN.Text.Length > 0)))
                            {
                                if (WBSetting.Field("DeliveryNote") == "Y")
                                {
                                    if (!((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))))
                                    {
                                        if (!((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))))
                                        {
                                            if (this.textDN.Text.Trim() == "")
                                            {
                                                MessageBox.Show(Resource.Mes_294, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                this.textDN.Focus();
                                                return false;
                                            }
                                        }
                                        else
                                        {
                                            this.textDN.Enabled = false;
                                        }
                                    }
                                    else
                                    {
                                        this.textDN.Enabled = false;
                                    }
                                    if (this.textDN.Text.Trim() != "-")
                                    {
                                        if (this.dgvDO.Rows.Count <= 0)
                                        {
                                            MessageBox.Show(Resource.Mes_303, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                            this.textDN.Text = "";
                                            return false;
                                        }
                                        else if (!((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))))
                                        {
                                            if (!((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))))
                                            {
                                                if ((this.CommType == "F") && !this.CheckSPB())
                                                {
                                                    MessageBox.Show(Resource.Mes_277, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                    this.textDN.Focus();
                                                    return false;
                                                }
                                            }
                                            else
                                            {
                                                this.textDN.Enabled = false;
                                            }
                                        }
                                        else
                                        {
                                            this.textDN.Enabled = false;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_264, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                return false;
                            }
                        }
                        if (!(((this.CommType == "G") & (this.sIO == "O")) & (this.pMode == "2ND")) || (this.dgvBatch.Rows.Count > 0))
                        {
                            string str = "";
                            int num = 0;
                            foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
                            {
                                if (Convert.ToDouble(row.Cells["Netto"].Value.ToString()) > 0.0)
                                {
                                    this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and  comm_code = '" + row.Cells["Comm_Code"].Value.ToString() + "'"), WBData.conn);
                                    string[] aField = new string[] { "Comm_Code" };
                                    string[] textArray5 = new string[] { row.Cells["Comm_Code"].Value.ToString() };
                                    this.tblComm.DR = this.tblComm.GetData(aField, textArray5);
                                    if ((this.tblComm.DR != null) && ((this.tblComm.DR["ConvertionCheck"].ToString() == "Y") && (Convert.ToDouble((row.Cells["ConvNett"].Value.ToString().Trim() == "") ? "0" : row.Cells["ConvNett"].Value.ToString()) > 0.0)))
                                    {
                                        double num6 = Convert.ToDouble(row.Cells["ConvNett"].Value.ToString()) * Convert.ToDouble(this.tblComm.DR["Convertion"].ToString());
                                        double num7 = (num6 / 1000.0) * Convert.ToDouble(this.tblComm.DR["ConvertionTolerance"].ToString());
                                        double num8 = num6 - num7;
                                        double num9 = num6 + num7;
                                        double num10 = Convert.ToDouble(row.Cells["Netto"].Value.ToString());
                                        if ((num10 < num8) || (num10 > num9))
                                        {
                                            str = ((row.Cells["Comm_Code"].Value.ToString() + " : ") + "Minimum Weight is " + $"{num8:N0}") + " Kg and Maximum Weight is " + $"{num9:N0}" + " Kg";
                                        }
                                        this.dgvDO.Rows[num].Cells["ConvTolerance"].Value = num7;
                                    }
                                }
                                if (str != "")
                                {
                                    str = str + "\n";
                                }
                                num++;
                            }
                            if (str == "")
                            {
                                this.needApproval = false;
                                if ((this.pMode == "2ND") || (this.pMode == "4TH"))
                                {
                                    if (this.use_gunny == "Y")
                                    {
                                        double num11;
                                        try
                                        {
                                            num11 = Convert.ToDouble(this.textBox3.Text);
                                        }
                                        catch
                                        {
                                            num11 = 0.0;
                                        }
                                        if (((num11 > this.sGunnyMax) || (num11 < this.sGunnyMin)) ? (this.is_pack == "P") : false)
                                        {
                                            string[] textArray6 = new string[] { Resource.Mes_285, "( ", this.sGunnyMin.ToString().Trim(), " - ", this.sGunnyMax.ToString().Trim() };
                                            MessageBox.Show(string.Concat(textArray6), Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            this.needApproval = true;
                                        }
                                    }
                                    if ((this.pMode == "4TH") && ((Convert.ToInt16(WBUser.UserLevel) > 2) && ((Program.StrToDouble(this.textNetEstate.Text, 0) - Program.StrToDouble(this.textNet.Text, 0)) < -40.0)))
                                    {
                                        MessageBox.Show(Resource.Mes_286 + this.textVariance.Text + " Kg", Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        return false;
                                    }
                                }
                                if (this.needApproval)
                                {
                                    this.approve = "N";
                                    this.approval = Program.fillApproval(this.msgApprove);
                                    this.approve = this.approval[0];
                                    this.approveBy1 = this.approval[1];
                                    this.approveBy2 = this.approval[2];
                                    if (this.approve == "N")
                                    {
                                        MessageBox.Show(Resource.Mes_326, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        return false;
                                    }
                                }
                                if (WBSetting.Field("Check_tare") == "Y")
                                {
                                    if ((this.transType == "I") && (this.check_tare_comm == "Y"))
                                    {
                                        if (((this.pMode == "2ND") || (this.pMode == "4TH")) && !this.checkTare())
                                        {
                                            string[] textArray7 = new string[] { "Tare is Beyond Tolerance ( ", this.minTare, " - ", this.maxTare, " )\n please ask for Manager Approval " };
                                            MessageBox.Show(string.Concat(textArray7), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            this.needApproval = true;
                                        }
                                    }
                                    else if ((this.transType == "O") && (((this.pMode == "1ST") && (this.check_tare_comm == "Y")) && !this.checkTare()))
                                    {
                                        string[] textArray8 = new string[] { "Tare is Beyond Tolerance ( ", this.minTare, " - ", this.maxTare, " )\n please ask for Manager Approval " };
                                        MessageBox.Show(string.Concat(textArray8), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        this.needApproval = true;
                                    }
                                    if (this.needApproval)
                                    {
                                        this.hasil = this.tblComm.tokenOrApp(this.textTruck.Text, "", "OVER_TARE", "TOKEN_OVER_TARE", "OVER_TARE", "E", "", null);
                                        if (this.hasil[0] != "completed")
                                        {
                                            this.approve = "N";
                                            MessageBox.Show("This Transaction Tare not approved.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            return false;
                                        }
                                        else
                                        {
                                            this.approve = "Y";
                                            this.approveBy1 = this.hasil[1];
                                            this.ApproveReason = this.hasil[2];
                                            this.approve_type = "OVER_TARE";
                                        }
                                    }
                                }
                                if ((this.spMode != "COPY") && (this.spMode != "QTY"))
                                {
                                    this.pMode = this.spMode;
                                }
                                if (!(((this.pMode != "1ST") || !this.tambahRecord) ? (this.pMode == "MANUAL") : true))
                                {
                                    if (((this.pMode != "EDIT") && (this.pMode != "QTY")) && (this.pMode != "CANCEL"))
                                    {
                                        goto TR_0153;
                                    }
                                    else
                                    {
                                        FormTransCancel cancel = new FormTransCancel {
                                            textRefNo = { Text = this.textRefNo.Text }
                                        };
                                        if (this.pMode == "EDIT")
                                        {
                                            cancel.Text = "CHANGE REASON";
                                            cancel.label2.Text = "Change Reason : ";
                                        }
                                        else if (this.pMode == "QTY")
                                        {
                                            cancel.Text = "CHANGE QTY REASON";
                                            cancel.label2.Text = "Change QTY Reason : ";
                                        }
                                        else
                                        {
                                            cancel.Text = "CANCEL REASON";
                                            cancel.label2.Text = "Cancel Reason : ";
                                        }
                                        cancel.textReason.Text = this.mChangeReason;
                                        cancel.textReason.Focus();
                                        cancel.ShowDialog();
                                        if (cancel.Saved)
                                        {
                                            this.mChangeReason = cancel.textReason.Text;
                                            cancel.Dispose();
                                            goto TR_0153;
                                        }
                                        else
                                        {
                                            flag2 = false;
                                        }
                                    }
                                }
                                else
                                {
                                    if (this.pMode == "1ST")
                                    {
                                        this.textRefNo.Text = this.SetNoref(true);
                                    }
                                    if ((this.pMode == "MANUAL") && (WBSetting.Field("GM") == "N"))
                                    {
                                        this.textRefNo.Text = this.SetNoref(true);
                                    }
                                    this.tblTrans.DR = this.tblTrans.DT.NewRow();
                                    goto TR_014B;
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_261 + "\n\\n\n" + (str + "\nTransaction will be cancelled . . !\n"), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                flag2 = false;
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_291, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            flag2 = false;
                        }
                    }
                    else
                    {
                        flag2 = false;
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_292, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.tabControl1.Focus();
                    flag2 = false;
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_262, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.textRef_Date.Focus();
                flag2 = false;
            }
            return flag2;
        TR_014B:
            this.tblTrans.DR["Coy"] = WBData.sCoyCode;
            this.tblTrans.DR["Location_Code"] = WBData.sLocCode;
            this.tblTrans.DR["Ref"] = this.textRefNo.Text.Trim();
            if (Convert.ToInt16(WBSetting.transflow) >= 2)
            {
                this.tblTrans.DR["Gatepass_Number"] = this.textGatepass.Text.Trim();
            }
            if (this.pMode == "1ST")
            {
                if (this.text1st.Text.Trim() == "0")
                {
                    this.WX = "";
                }
                this.tblTrans.DR["WX"] = this.WX;
                this.tblTrans.DR["Date1"] = this.textDate1st.Text;
                this.tblTrans.DR["Time1"] = this.textTime1st.Text;
                this.tblTrans.DR["_1st"] = this.text1st.Text;
                this.tblTrans.DR["WBCode1"] = WBSetting.WBCode;
                this.tblTrans.DR["Ref_Date"] = Convert.ToDateTime(this.textRef_Date.Text);
                this.tblTrans.DR["_2nd"] = "0";
                this.tblTrans.DR["_3rd"] = "0";
                this.tblTrans.DR["_4th"] = "0";
                if (this.TimeRegister.Text != "")
                {
                    this.tblTrans.DR["Register_Time"] = this.TimeRegister.Text;
                }
                if (this.dateRegister.Text != "")
                {
                    this.tblTrans.DR["Register_Date"] = this.dateRegister.Text;
                }
            }
            else if (this.pMode == "2ND")
            {
                this.tblTrans.DR["Date2"] = this.textDate2nd.Text;
                this.tblTrans.DR["Time2"] = this.textTime2nd.Text;
                this.tblTrans.DR["_2nd"] = this.text2nd.Text;
                this.tblTrans.DR["WBCode2"] = WBSetting.WBCode;
                this.tblTrans.DR["Report_Date"] = WBSetting.WorkingTime(this.textDate2nd.Text, this.textTime2nd.Text);
                if (this.nonContract == "N")
                {
                    if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                    {
                        string[] textArray11 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(true) };
                        this.textDN.Text = string.Concat(textArray11);
                    }
                    else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                    {
                        string[] textArray12 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(true) };
                        this.textDN.Text = string.Concat(textArray12);
                    }
                }
            }
            else if (this.pMode == "3RD")
            {
                this.tblTrans.DR["Date3"] = this.textDate3rd.Text;
                this.tblTrans.DR["Time3"] = this.textTime3rd.Text;
                this.tblTrans.DR["_3rd"] = this.text3rd.Text;
                this.tblTrans.DR["WBCode3"] = WBSetting.WBCode;
            }
            else if (this.pMode == "4TH")
            {
                this.tblTrans.DR["Date4"] = this.textDate4th.Text;
                this.tblTrans.DR["Time4"] = this.textTime4th.Text;
                this.tblTrans.DR["_4th"] = this.text4th.Text;
                this.tblTrans.DR["WBCode4"] = WBSetting.WBCode;
                this.tblTrans.DR["Report_Date"] = WBSetting.WorkingTime(this.textDate4th.Text, this.textTime4th.Text);
            }
            else if (this.pMode == "EDIT")
            {
                if (this.textDate1st.Text != "")
                {
                    this.tblTrans.DR["Date1"] = this.textDate1st.Text;
                }
                this.tblTrans.DR["Time1"] = this.textTime1st.Text;
                if (this.textDate2nd.Text != "")
                {
                    this.tblTrans.DR["Date2"] = this.textDate2nd.Text;
                }
                this.tblTrans.DR["Time2"] = this.textTime2nd.Text;
                if (this.textDate3rd.Text != "")
                {
                    this.tblTrans.DR["Date3"] = this.textDate3rd.Text;
                }
                this.tblTrans.DR["Time3"] = this.textTime3rd.Text;
                if (this.textDate4th.Text != "")
                {
                    this.tblTrans.DR["Date4"] = this.textDate4th.Text;
                }
                this.tblTrans.DR["Time4"] = this.textTime4th.Text;
                this.tblTrans.DR["_1st"] = this.text1st.Text;
                this.tblTrans.DR["_2nd"] = this.text2nd.Text;
                this.tblTrans.DR["_3rd"] = this.text3rd.Text;
                this.tblTrans.DR["_4th"] = this.text4th.Text;
                if (this.textReport_Date.Text.Trim() != "")
                {
                    this.tblTrans.DR["Report_Date"] = this.textReport_Date.Text;
                }
                else if (this.textDate2nd.Text.Trim() != "")
                {
                    this.tblTrans.DR["Report_Date"] = WBSetting.WorkingTime(this.textDate2nd.Text, this.textTime2nd.Text);
                    this.textReport_Date.Text = this.tblTrans.DR["Report_Date"].ToString();
                }
            }
            else if (this.pMode == "MANUAL")
            {
                this.tblTrans.DR["WX"] = this.WX;
                this.tblTrans.DR["Ref"] = this.textRefNo.Text.Trim();
                this.tblTrans.DR["Date1"] = this.textDate1st.Text;
                this.tblTrans.DR["Time1"] = this.textTime1st.Text;
                this.tblTrans.DR["_1st"] = this.text1st.Text;
                this.tblTrans.DR["WBCode1"] = WBSetting.WBCode;
                this.tblTrans.DR["WBCode2"] = WBSetting.WBCode;
                this.tblTrans.DR["Ref_Date"] = Convert.ToDateTime(this.textRef_Date.Text);
                this.tblTrans.DR["Manual"] = "Y";
                if (this.TimeRegister.Text != "")
                {
                    this.tblTrans.DR["Register_Time"] = this.TimeRegister.Text;
                }
                if (this.dateRegister.Text != "")
                {
                    this.tblTrans.DR["Register_Date"] = this.dateRegister.Text;
                }
                if (this.textDate1st.Text != "")
                {
                    this.tblTrans.DR["Date1"] = this.textDate1st.Text;
                }
                this.tblTrans.DR["Time1"] = this.textTime1st.Text;
                if (this.textDate2nd.Text != "")
                {
                    this.tblTrans.DR["Date2"] = this.textDate2nd.Text;
                }
                this.tblTrans.DR["Time2"] = this.textTime2nd.Text;
                if (this.textDate3rd.Text != "")
                {
                    this.tblTrans.DR["Date3"] = this.textDate3rd.Text;
                }
                this.tblTrans.DR["Time3"] = this.textTime3rd.Text;
                if (this.textDate4th.Text != "")
                {
                    this.tblTrans.DR["Date4"] = this.textDate4th.Text;
                }
                this.tblTrans.DR["Time4"] = this.textTime4th.Text;
                this.tblTrans.DR["_1st"] = this.text1st.Text;
                this.tblTrans.DR["_2nd"] = this.text2nd.Text;
                this.tblTrans.DR["_3rd"] = this.text3rd.Text;
                this.tblTrans.DR["_4th"] = this.text4th.Text;
                if (this.textReport_Date.Text.Trim() != "")
                {
                    this.tblTrans.DR["Report_Date"] = this.textReport_Date.Text;
                }
                else if (this.textDate2nd.Text.Trim() != "")
                {
                    this.tblTrans.DR["Report_Date"] = WBSetting.WorkingTime(this.textDate2nd.Text, this.textTime2nd.Text);
                    this.textReport_Date.Text = this.tblTrans.DR["Report_Date"].ToString();
                }
            }
            if (!this.checkISCC.Checked)
            {
                this.tblTrans.DR["ISCC_Checked"] = 'N';
                this.tblTrans.DR["ISCC_No"] = "";
                this.tblTrans.DR["ISCC_GC_Checked"] = 'N';
                this.tblTrans.DR["ISCC_Weight"] = 0;
            }
            else if (this.pMode == "1ST")
            {
                this.tblTrans.DR["ISCC_Checked"] = "Y";
                this.tblTrans.DR["ISCC_No"] = this.textISCC.Text;
                this.tblTrans.DR["ISCC_GC_Checked"] = this.radioGHG1.Checked ? "Y" : "N";
                if (this.radioGHG2.Checked)
                {
                    this.tblTrans.DR["ISCC_Weight"] = Convert.ToDouble(this.textGHG.Text);
                }
            }
            else if ((this.pMode != "1ST") && (this.pMode != "EDIT"))
            {
                this.tblTrans.DR["ISCC_Checked"] = "Y";
                if (this.tblTrans.DR["ISCC_No"].ToString().Trim() == "")
                {
                    this.tblTrans.DR["ISCC_No"] = this.textISCC.Text.Trim();
                }
                if ((this.tblTrans.DR["ISCC_No2"].ToString().Trim() == "") && (this.textCommodity.Text.Trim().ToUpper() == "CPO"))
                {
                    this.tblTrans.DR["ISCC_No2"] = this.SetNoISCC(true);
                }
                this.tblTrans.DR["ISCC_GC_Checked"] = this.radioGHG1.Checked ? "Y" : "N";
                if (this.radioGHG2.Checked)
                {
                    this.tblTrans.DR["ISCC_Weight"] = Convert.ToDouble(this.textGHG.Text);
                }
            }
            this.tblTrans.DR["Approve"] = this.approve;
            this.tblTrans.DR["approveBy1"] = this.approveBy1;
            this.tblTrans.DR["approveBy2"] = this.approveBy2;
            this.tblTrans.DR["Delivery_Date"] = this.dateDelivery.Value;
            this.tblTrans.DR["Delivery_Time"] = this.TimeDelivery.Text;
            this.tblTrans.DR["EstateDiff"] = this.checkEstate.Checked ? "Y" : "N";
            this.tblTrans.DR["Comm_Code"] = this.textCommodity.Text;
            this.tblTrans.DR["DO_NO"] = (this.dgvDO.Rows.Count > 0) ? this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString() : "";
            this.tblTrans.DR["tolling"] = (this.dgvDO.Rows.Count > 0) ? this.dgvDO.Rows[0].Cells["tolling"].Value.ToString() : "N";
            this.tblTrans.DR["zAuto"] = "N";
            this.tblTrans.DR["Transaction_Code"] = this.comTransType.Text;
            this.tblTrans.DR["relation_Code"] = this.textCust.Text;
            this.tblTrans.DR["Truck_Number"] = this.textTruck.Text;
            this.tblTrans.DR["Truck_Number2"] = this.textTruck2.Text;
            this.tblTrans.DR["Truck_Trailer_Number"] = this.textTrailerNo.Text;
            this.tblTrans.DR["Tanker"] = this.textTanker.Text;
            this.tblTrans.DR["TankQC"] = this.textTankQC.Text;
            this.tblTrans.DR["Storage"] = this.textStorage.Text;
            this.tblTrans.DR["License_No"] = this.textDriverID.Text;
            this.tblTrans.DR["Name"] = this.labelDriverName.Text;
            this.tblTrans.DR["Transporter_Code"] = this.textTransporter.Text;
            this.tblTrans.DR["Delivery_Note"] = this.textDN.Text;
            this.tblTrans.DR["Unloading"] = this.textUnloading.Text;
            this.tblTrans.DR["Remark_Ticket"] = this.textRemarkTicket.Text;
            this.tblTrans.DR["Remark_Report"] = this.textRemarkReport.Text;
            this.tblTrans.DR["Remark_Report"] = this.textRemarkReport.Text;
            this.tblTrans.DR["Seal"] = this.textSEAL.Text;
            this.tblTrans.DR["Estate"] = this.textEstate.Text;
            this.tblTrans.DR["Ticket"] = this.textWBNo.Text;
            this.tblTrans.DR["NonContract"] = this.nonContract;
            this.tblTrans.DR["TotalGunny"] = Convert.ToDouble(this.textGunnyBatch.Text);
            this.tblTrans.DR["bag_code"] = this.textBagCode.Text;
            this.tblTrans.DR["bag"] = this.textTotalBag.Text;
            this.tblTrans.DR["Total_bag_Weight"] = this.textTotalBagWeight.Text;
            this.tblTrans.DR["Bag_Change"] = this.checkOverrideBag.Checked ? "Y" : "N";
            this.tblTrans.DR["source_code"] = this.textSource.Text;
            this.tblTrans.DR["mill_code"] = this.textMill.Text;
            this.tblTrans.DR["division_code"] = this.textDivision.Text;
            this.tblTrans.DR["load_unload"] = this.textBoxLoadUnload.Text;
            this.tblTrans.DR["grade"] = this.textGrade.Text;
            this.tblTrans.DR["printed"] = !this.printTicket ? "0" : "1";
            this.tblTrans.DR["posted"] = "N";
            this.tblTrans.DR["Gross_Estate"] = Convert.ToDouble(this.textGrossEstate.Text);
            this.tblTrans.DR["Tare_Estate"] = Convert.ToDouble(this.textTareEstate.Text);
            this.tblTrans.DR["Net_Estate"] = Convert.ToDouble(this.textNetEstate.Text);
            if (this.WX == "2X")
            {
                if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text2nd.Text))
                {
                    this.tblTrans.DR["Gross"] = Convert.ToDouble(this.text1st.Text);
                    this.tblTrans.DR["Tare"] = Convert.ToDouble(this.text2nd.Text);
                }
                else
                {
                    this.tblTrans.DR["Gross"] = Convert.ToDouble(this.text2nd.Text);
                    this.tblTrans.DR["Tare"] = Convert.ToDouble(this.text1st.Text);
                }
            }
            else
            {
                this.sTransType = "";
                if (this.comTransType.Text != "")
                {
                    string[] aField = new string[] { "Transaction_Code" };
                    string[] textArray14 = new string[] { this.comTransType.Text };
                    this.sTransType = this.tblTransType.GetData(aField, textArray14)["IO"].ToString();
                }
                if (this.sTransType == "I")
                {
                    this.tblTrans.DR["Gross"] = Convert.ToDouble(this.text1st.Text);
                    this.tblTrans.DR["Tare"] = (Convert.ToDouble(this.text4th.Text) - Convert.ToDouble(this.text3rd.Text)) + Convert.ToDouble(this.text2nd.Text);
                }
                else
                {
                    this.tblTrans.DR["Gross"] = Convert.ToDouble(this.text4th.Text);
                    this.tblTrans.DR["Tare"] = (Convert.ToDouble(this.text1st.Text) - Convert.ToDouble(this.text2nd.Text)) + Convert.ToDouble(this.text3rd.Text);
                }
            }
            this.tblTrans.DR["Received"] = Convert.ToDouble(this.textNET2.Text);
            this.tblTrans.DR["Deduction"] = Convert.ToDouble(this.textDeducTotal.Text);
            this.tblTrans.DR["Net"] = Convert.ToDouble(this.textNet.Text);
            this.tblTrans.DR["UnitName"] = this.textUnitName.Text;
            this.textUnitNameWeight.Text = (this.textUnitNameWeight.Text.Trim() == "") ? "0" : this.textUnitNameWeight.Text;
            this.tblTrans.DR["WeightPerUnitName"] = Convert.ToDouble(this.textUnitNameWeight.Text);
            this.tblTrans.DR["TotalBunch"] = Convert.ToDouble(this.textBunchTotal.Text);
            this.tblTrans.DR["TotalBunchGrading"] = Convert.ToDouble(this.textBunchDeduc.Text);
            this.tblTrans.DR["Average"] = Convert.ToDouble(this.textAvg.Text);
            if ((this.pMode == "1ST") || (this.pMode == "MANUAL"))
            {
                this.tblTrans.DR["Create_By"] = WBUser.UserID;
                this.tblTrans.DR["Create_Date"] = DateTime.Now;
                if (this.tambahRecord)
                {
                    this.tblTrans.DT.Rows.Add(this.tblTrans.DR);
                }
                else
                {
                    this.tblTrans.DR.EndEdit();
                }
            }
            else
            {
                if (this.pMode == "EDIT")
                {
                    this.tblTrans.DR["ChangeReason"] = this.mChangeReason;
                    this.tblTrans.DR["Edit_By"] = WBUser.UserID;
                    this.tblTrans.DR["Edit_Date"] = DateTime.Now;
                    if ((this.pMode == "EDIT") && (this.spMode != "QTY"))
                    {
                        this.tblTrans.DR["Edit_Data"] = (this.tblTrans.DR["Edit_Data"].ToString() != "") ? (Convert.ToInt16(this.tblTrans.DR["Edit_Data"].ToString()) + 1).ToString() : "1";
                    }
                    else if ((this.pMode == "EDIT") && (this.spMode == "QTY"))
                    {
                        this.tblTrans.DR["Edit_Qty"] = (this.tblTrans.DR["Edit_Qty"].ToString() != "") ? (Convert.ToInt16(this.tblTrans.DR["Edit_Qty"].ToString()) + 1).ToString() : "1";
                    }
                }
                else if ((this.pMode == "QC") || (this.pMode == "SPLIT"))
                {
                    this.tblTrans.DR["Edit_By"] = WBUser.UserID;
                    this.tblTrans.DR["Edit_Date"] = DateTime.Now;
                }
                else if (this.pMode != "CANCEL")
                {
                    this.tblTrans.DR["Change_By"] = WBUser.UserID;
                    this.tblTrans.DR["Change_Date"] = DateTime.Now;
                }
                else
                {
                    this.tblTrans.DR["ChangeReason"] = this.mChangeReason;
                    this.tblTrans.DR["Deleted"] = "Y";
                    this.tblTrans.DR["Delete_By"] = WBUser.UserID;
                    this.tblTrans.DR["Delete_Date"] = Program.DTOC(DateTime.Now);
                }
                this.tblTrans.DR.EndEdit();
            }
            this.tblTrans.DR["checksum"] = this.tblTrans.Checksum(this.tblTrans.DR);
            if (((this.pMode == "1ST") || ((this.pMode == "2ND") || (this.pMode == "3RD"))) || (this.pMode == "4TH"))
            {
                if (this.tblTrans.DR["transWarning"].ToString().Length == 0)
                {
                    this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString() + "0000";
                }
                else if (this.tblTrans.DR["transWarning"].ToString().Length == 1)
                {
                    this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString() + "000";
                }
                else if (this.tblTrans.DR["transWarning"].ToString().Length == 2)
                {
                    this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString() + "00";
                }
                else if (this.tblTrans.DR["transWarning"].ToString().Length == 3)
                {
                    this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString() + "0";
                }
            }
            if (this.pMode == "1ST")
            {
                this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString().Remove(0, 1).Insert(0, this.indStableWarning);
            }
            else if (this.pMode == "2ND")
            {
                this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString().Remove(1, 1).Insert(1, this.indStableWarning);
            }
            else if (this.pMode == "3RD")
            {
                this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString().Remove(2, 1).Insert(2, this.indStableWarning);
            }
            else if (this.pMode == "4TH")
            {
                this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString().Remove(3, 1).Insert(3, this.indStableWarning);
            }
            this.logDate1 = Convert.ToDateTime(this.tblTrans.DR["Date1"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
            this.logTime1 = this.tblTrans.DR["Time1"].ToString();
            this.logRef = this.tblTrans.DR["Ref"].ToString();
            string str2 = this.tblTrans.DR["Truck_Number"].ToString();
            this.tblTrans.Save();
            if ((this.pMode == "CANCEL") && (WBSetting.Field("Check_Email").Trim() == "Y"))
            {
                string[] textArray15 = new string[] { ("Dear All,<br><br>This email is to notify you that the following transaction has been cancelled :<table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name"), "</tr><tr class='bd'><td nowrap>Date & Time</td><td nowrap> : ", DateTime.Now.ToShortDateString(), " ", DateTime.Now.ToString("HH:mm:ss") };
                string[] textArray16 = new string[] { ((string.Concat(textArray15) + "</tr><tr class='bd'><td nowrap>Ref Number</td><td nowrap> : " + this.logRef) + "</tr><tr class='bd'><td nowrap>Truck Number</td><td nowrap> : " + str2) + "</tr><tr class='bd'><td nowrap>Change Reason</td><td nowrap> : " + this.mChangeReason, "</tr><tr class='bd'><td nowrap>WB User</td><td nowrap> : ", WBUser.UserGroup.Trim(), " ( ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " ) " };
                WBMail mail = new WBMail();
                mail.SendMail_Cancel((string.Concat(textArray16) + "</tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : " + WBData.sWBCode) + "</tr></table><br>Thank you.");
                mail.Dispose();
                WBTable table3 = new WBTable();
                table3.OpenTable("wb_email", "select * from wb_email where " + WBData.CompanyLocation(" and email_code = 'TRANSLOG' and email_date = '" + DateTime.Now.ToString("yyyy-MM-dd") + " 00:00:00' "), WBData.conn);
                if (table3.DT.Rows.Count <= 0)
                {
                    table3.DR = table3.DT.NewRow();
                    table3.DR["COY"] = WBData.sCoyCode;
                    table3.DR["LOCATION_CODE"] = WBData.sLocCode;
                    table3.DR["Email_code"] = "TRANSLOG";
                    table3.DR["Email_date"] = DateTime.Now.ToString("dd/MM/yyyy");
                    table3.DR["Status"] = "N";
                    table3.DT.Rows.Add(table3.DR);
                    table3.Save();
                }
                else if (table3.DT.Rows[0]["Status"].ToString() == "Y")
                {
                    table3.DR = table3.DT.Rows[0];
                    table3.DR.BeginEdit();
                    table3.DR["Status"] = "N";
                    table3.DR.EndEdit();
                    table3.Save();
                }
                table3.Dispose();
            }
            if (((this.pMode == "1ST") || ((this.pMode == "2ND") || ((this.pMode == "3RD") || (this.pMode == "4TH")))) ? ((this.indStableWarning == "1") || (this.indStableWarning == "2")) : false)
            {
                WBTable table4 = new WBTable();
                table4.OpenTable("wb_email", "select * from wb_email where " + WBData.CompanyLocation(" and email_code = 'INDICATOR_STABILITY' and email_date = '" + DateTime.Now.ToString("yyyy-MM-dd") + " 00:00:00' "), WBData.conn);
                if (table4.DT.Rows.Count <= 0)
                {
                    table4.DR = table4.DT.NewRow();
                    table4.DR["COY"] = WBData.sCoyCode;
                    table4.DR["LOCATION_CODE"] = WBData.sLocCode;
                    table4.DR["Email_code"] = "INDICATOR_STABILITY";
                    table4.DR["Email_date"] = DateTime.Now.ToString("dd/MM/yyyy");
                    table4.DR["Status"] = "N";
                    table4.DT.Rows.Add(table4.DR);
                    table4.Save();
                }
                else if (table4.DT.Rows[0]["Status"].ToString() == "Y")
                {
                    table4.DR = table4.DT.Rows[0];
                    table4.DR.BeginEdit();
                    table4.DR["Status"] = "N";
                    table4.DR.EndEdit();
                    table4.Save();
                }
                table4.Dispose();
            }
            this.logKeyField = this.sUniq;
            if (((this.pMode != "1ST") || !this.tambahRecord) ? (this.pMode == "MANUAL") : true)
            {
                string sqltext = ((((("" + "SELECT uniq FROM wb_transaction WHERE " + WBData.CompanyLocation("")) + " AND Ref = '" + this.logRef + "' ") + " AND Date1 = '" + this.logDate1 + "' ") + " AND Time1 = '" + this.logTime1 + "' ") + " AND Create_by = '" + WBUser.UserID + "' ") + " AND WBCode1 = '" + WBData.sWBCode + "' ";
                WBTable table5 = new WBTable();
                table5.OpenTable("wb_transaction", sqltext, WBData.conn);
                this.logKeyField = table5.DT.Rows[0]["uniq"].ToString();
                table5.Dispose();
                this.sUniq = this.logKeyField;
            }
            this.logMode = this.pMode;
            if ((this.spMode == "QTY") || (this.spMode == "EDIT_OPW"))
            {
                this.logMode = this.spMode;
            }
            this.logReason = this.mChangeReason;
            if (this.logMode == "SPLIT")
            {
                this.logReason = "Split Transaction";
            }
            else if (this.logMode == "QC")
            {
                this.logReason = "Entry Quality Control";
            }
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { this.logMode, WBUser.UserID, this.logReason };
            Program.updateLogHeader("wb_transaction", this.logKeyField, logField, logValue);
            if (this.dgvDO.Rows.Count > 1)
            {
                this.saveTransSplit(this.sUniq);
            }
            this.Saved = true;
            if (((WBUser.UserLevel != "1") && (WBSetting.Field("GM") == "Y")) && (this.pMode == "MANUAL"))
            {
                WBTable table6 = new WBTable();
                table6.OpenTable("wb_loc", "select coy, location_code, tokenManual, maxEntry, currEntry,uniq from wb_location", WBData.conn);
                if (table6.DT.Rows.Count > 0)
                {
                    table6.DR = table6.DT.Rows[0];
                    string str10 = "";
                    str10 = Program.shoot(table6.DR["CurrEntry"].ToString(), false);
                    table6.DR = table6.DT.Rows[0];
                    table6.DR.BeginEdit();
                    table6.DR["CurrEntry"] = Program.shoot((Convert.ToDouble(str10) + 1.0).ToString(), true);
                    table6.DR.EndEdit();
                    table6.Save();
                }
                table6.Dispose();
            }
            this.tblTransDO.ReOpen();
            string str3 = "";
            int num2 = 0x40;
            int num3 = 0;
            if (this.tblTransDO.DT.Rows.Count > 0)
            {
                foreach (DataRow row2 in this.tblTransDO.DT.Rows)
                {
                    if (row2["Ref"].ToString() == this.textRefNo.Text)
                    {
                        row2.Delete();
                    }
                }
                this.tblTransDO.Save();
            }
            foreach (DataGridViewRow row3 in (IEnumerable) this.dgvDO.Rows)
            {
                this.tblTransDO.DR = this.tblTransDO.DT.NewRow();
                int num15 = 0;
                while (true)
                {
                    if (num15 >= (this.tblTransDO.DT.Columns.Count - 1))
                    {
                        this.tblTransDO.DR["Coy"] = WBData.sCoyCode;
                        this.tblTransDO.DR["Location_Code"] = WBData.sLocCode;
                        this.tblTransDO.DR["Ref"] = (num3 != 0) ? (this.textRefNo.Text + Convert.ToChar(num2).ToString()) : this.textRefNo.Text;
                        if (this.tblTransDO.DR["return_qty_kg"].ToString() == "")
                        {
                            this.tblTransDO.DR["return_qty_kg"] = 0;
                        }
                        if (this.tblTransDO.DR["return_qty_pack"].ToString() == "")
                        {
                            this.tblTransDO.DR["return_qty_pack"] = 0;
                        }
                        this.tblTransDO.DT.Rows.Add(this.tblTransDO.DR);
                        this.tblTransDO.Save();
                        num3++;
                        num2++;
                        break;
                    }
                    str3 = this.tblTransDO.DT.Columns[num15].ColumnName.ToString();
                    bool flag163 = str3.ToUpper() != "UNIQ".ToUpper();
                    if (flag163 && ((row3.Cells[str3].Value != null) && (row3.Cells[str3].Value.ToString().Trim() != "")))
                    {
                        this.tblTransDO.DR[str3] = row3.Cells[str3].Value;
                        if (((str3 == "return_qty_kg") || (str3 == "return_qty_pack")) ? ReferenceEquals(row3.Cells[str3], null) : false)
                        {
                            this.tblTransDO.DR[str3] = 0;
                        }
                    }
                    num15++;
                }
            }
            WBTable table = new WBTable();
            foreach (DataRow row4 in this.tblTransDO.DT.Rows)
            {
                if (row4["STO1X"].ToString().Trim() != "")
                {
                    table.OpenTable("wb_contract", "update wb_contract set [STO1DO]='Y' Where " + WBData.CompanyLocation(" AND Do_No='" + row4["Do_No"].ToString().Trim() + "'"), WBData.conn);
                    string[] textArray19 = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] textArray20 = new string[] { this.logMode, WBUser.UserID, "Generated from transaction" };
                    Program.updateLogHeader("wb_contract", row4["Do_No"].ToString().Trim(), textArray19, textArray20);
                }
            }
            table.Dispose();
            if (this.ChangeDoCont)
            {
                this.tblDOContainer.AddFromDGV_new(this.dgvDOCont, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                this.tblDOContainer.ReOpen();
            }
            if (this.ChangeDiv)
            {
                this.tblTransDiv.AddFromDGV_new(this.dgvDivBlock, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                this.tblTransDiv.ReOpen();
            }
            if (this.ChangeDeduc)
            {
                this.tblTransDeduc.AddFromDGV_new(this.dgvDeduc, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                this.tblTransDeduc.ReOpen();
            }
            if (this.ChangeDeducPorla)
            {
                this.tblTransDeducPorla.AddFromDGV_new(this.dgvDeducPorla, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                this.tblTransDeducPorla.ReOpen();
            }
            if (this.ChangeBatch)
            {
                int num16 = 0;
                while (true)
                {
                    if (num16 >= this.dgvBatch.RowCount)
                    {
                        this.tblTransBatch.AddFromDGV_new(this.dgvBatch, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                        this.tblTransBatch.ReOpen();
                        break;
                    }
                    if (this.dgvBatch.Rows[num16].Cells["Num_of_Gunny"].Value == null)
                    {
                        this.dgvBatch.Rows[num16].Cells["Num_of_Gunny"].Value = "0";
                    }
                    if (this.dgvBatch.Rows[num16].Cells["Netto"].Value == null)
                    {
                        this.dgvBatch.Rows[num16].Cells["Netto"].Value = "0";
                    }
                    num16++;
                }
            }
            if (WBSetting.region == "0")
            {
                this.tblTransQC.AddFromDGV_new(this.dgvQC_All, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                this.tblTransQC.ReOpen();
                if (this.dgvDO.Rows.Count > 0)
                {
                    int num17 = 1;
                    while (true)
                    {
                        if (num17 >= this.dgvDO.Rows.Count)
                        {
                            break;
                        }
                        string pVal = this.textRefNo.Text + Convert.ToChar((int) (0x40 + num17)).ToString();
                        WBTable table7 = new WBTable();
                        table7.OpenTable("wb_transQC", "SELECT * FROM wb_transQC WHERE " + WBData.CompanyLocation(" AND ref = '" + pVal + "'"), WBData.conn);
                        table7.AddFromDGV_new(this.dgvQC_All, "Ref", pVal, this.logMode, this.logReason);
                        table7.ReOpen();
                        table7.Dispose();
                        num17++;
                    }
                }
            }
            if (this.ChangeContainer)
            {
                this.tblTransContainer.AddFromDGV_new(this.dgvCont, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                this.tblTransContainer.ReOpen();
            }
            this.tblTransCopra.ReOpen();
            string keyField = "";
            if (this.tblTransCopra.DT.Rows.Count <= 0)
            {
                this.tblTransCopra.DR = this.tblTransCopra.DT.NewRow();
            }
            else
            {
                this.tblTransCopra.DR = this.tblTransCopra.DT.Rows[0];
                keyField = this.tblTransCopra.DR["uniq"].ToString();
                this.tblTransCopra.DR.BeginEdit();
            }
            this.tblTransCopra.DR["Coy"] = WBData.sCoyCode;
            this.tblTransCopra.DR["Location_code"] = WBData.sLocCode;
            this.tblTransCopra.DR["Ref"] = this.textRefNo.Text;
            this.tblTransCopra.DR["Colly1"] = (this.fCopra.textColly1.Text == "") ? "0" : this.fCopra.textColly1.Text;
            this.tblTransCopra.DR["Colly2"] = (this.fCopra.textColly2.Text == "") ? "0" : this.fCopra.textColly2.Text;
            this.tblTransCopra.DR["Colly3"] = (this.fCopra.textColly3.Text == "") ? "0" : this.fCopra.textColly3.Text;
            this.tblTransCopra.DR["Colly4"] = (this.fCopra.textColly4.Text == "") ? "0" : this.fCopra.textColly4.Text;
            this.tblTransCopra.DR["Colly5"] = (this.fCopra.textColly5.Text == "") ? "0" : this.fCopra.textColly5.Text;
            this.tblTransCopra.DR["Colly6"] = (this.fCopra.textColly6.Text == "") ? "0" : this.fCopra.textColly6.Text;
            this.tblTransCopra.DR["Colly7"] = (this.fCopra.textColly7.Text == "") ? "0" : this.fCopra.textColly7.Text;
            this.tblTransCopra.DR["Colly8"] = (this.fCopra.textColly8.Text == "") ? "0" : this.fCopra.textColly8.Text;
            this.tblTransCopra.DR["NetColly1"] = (this.fCopra.textColly1KG.Text == "") ? "0" : this.fCopra.textColly1KG.Text;
            this.tblTransCopra.DR["NetColly2"] = (this.fCopra.textColly2KG.Text == "") ? "0" : this.fCopra.textColly2KG.Text;
            this.tblTransCopra.DR["NetColly3"] = (this.fCopra.textColly3KG.Text == "") ? "0" : this.fCopra.textColly3KG.Text;
            this.tblTransCopra.DR["NetColly4"] = (this.fCopra.textColly4KG.Text == "") ? "0" : this.fCopra.textColly4KG.Text;
            this.tblTransCopra.DR["NetColly5"] = (this.fCopra.textColly5KG.Text == "") ? "0" : this.fCopra.textColly5KG.Text;
            this.tblTransCopra.DR["NetColly6"] = (this.fCopra.textColly6KG.Text == "") ? "0" : this.fCopra.textColly6KG.Text;
            this.tblTransCopra.DR["NetColly7"] = (this.fCopra.textColly7KG.Text == "") ? "0" : this.fCopra.textColly7KG.Text;
            this.tblTransCopra.DR["NetColly8"] = (this.fCopra.textColly8KG.Text == "") ? "0" : this.fCopra.textColly8KG.Text;
            this.tblTransCopra.DR["JlhColly1"] = (this.fCopra.textJlhColly1.Text == "") ? "0" : this.fCopra.textJlhColly1.Text;
            this.tblTransCopra.DR["JlhColly2"] = (this.fCopra.textJlhColly2.Text == "") ? "0" : this.fCopra.textJlhColly2.Text;
            this.tblTransCopra.DR["JlhColly3"] = (this.fCopra.textJlhColly3.Text == "") ? "0" : this.fCopra.textJlhColly3.Text;
            this.tblTransCopra.DR["JlhColly4"] = (this.fCopra.textJlhColly4.Text == "") ? "0" : this.fCopra.textJlhColly4.Text;
            this.tblTransCopra.DR["JlhColly5"] = (this.fCopra.textJlhColly5.Text == "") ? "0" : this.fCopra.textJlhColly5.Text;
            this.tblTransCopra.DR["JlhColly6"] = (this.fCopra.textJlhColly6.Text == "") ? "0" : this.fCopra.textJlhColly6.Text;
            this.tblTransCopra.DR["JlhColly7"] = (this.fCopra.textJlhColly7.Text == "") ? "0" : this.fCopra.textJlhColly7.Text;
            this.tblTransCopra.DR["Form1"] = (this.fCopra.textForm1.Text == "") ? "0" : this.fCopra.textForm1.Text;
            this.tblTransCopra.DR["Form2"] = (this.fCopra.textForm2.Text == "") ? "0" : this.fCopra.textForm2.Text;
            this.tblTransCopra.DR["Form3"] = (this.fCopra.textForm3.Text == "") ? "0" : this.fCopra.textForm3.Text;
            this.tblTransCopra.DR["Form4"] = (this.fCopra.textForm4.Text == "") ? "0" : this.fCopra.textForm4.Text;
            this.tblTransCopra.DR["Form5"] = (this.fCopra.textForm5.Text == "") ? "0" : this.fCopra.textForm5.Text;
            this.tblTransCopra.DR["Form6"] = (this.fCopra.textForm6.Text == "") ? "0" : this.fCopra.textForm6.Text;
            this.tblTransCopra.DR["Form7"] = (this.fCopra.textForm7.Text == "") ? "0" : this.fCopra.textForm7.Text;
            this.tblTransCopra.DR["NetF1"] = (this.fCopra.textForm1KG.Text == "") ? "0" : this.fCopra.textForm1KG.Text;
            this.tblTransCopra.DR["NetF2"] = (this.fCopra.textForm2KG.Text == "") ? "0" : this.fCopra.textForm2KG.Text;
            this.tblTransCopra.DR["NetF3"] = (this.fCopra.textForm3KG.Text == "") ? "0" : this.fCopra.textForm3KG.Text;
            this.tblTransCopra.DR["NetF4"] = (this.fCopra.textForm4KG.Text == "") ? "0" : this.fCopra.textForm4KG.Text;
            this.tblTransCopra.DR["NetF5"] = (this.fCopra.textForm5KG.Text == "") ? "0" : this.fCopra.textForm5KG.Text;
            this.tblTransCopra.DR["NetF6"] = (this.fCopra.textForm6KG.Text == "") ? "0" : this.fCopra.textForm6KG.Text;
            this.tblTransCopra.DR["NetF7"] = (this.fCopra.textForm7KG.Text == "") ? "0" : this.fCopra.textForm7KG.Text;
            this.tblTransCopra.DR["PotLain"] = (this.fCopra.textPotLain.Text == "") ? "0" : this.fCopra.textPotLain.Text;
            this.tblTransCopra.DR["TPColly"] = (this.fCopra.textFormTotalKG.Text == "") ? "0" : this.fCopra.textFormTotalKG.Text;
            this.tblTransCopra.DR["TPAir"] = (this.fCopra.textTPAir.Text == "") ? "0" : this.fCopra.textTPAir.Text;
            this.tblTransCopra.DR["JlhColly"] = (this.fCopra.textJlhColly.Text == "") ? "0" : this.fCopra.textJlhColly.Text;
            this.tblTransCopra.DR["TPCopra"] = (this.fCopra.textTotalCopra.Text == "") ? "0" : this.fCopra.textTotalCopra.Text;
            if (this.tblTransCopra.DT.Rows.Count > 0)
            {
                this.tblTransCopra.DR.EndEdit();
            }
            else
            {
                this.tblTransCopra.DT.Rows.Add(this.tblTransCopra.DR);
            }
            this.tblTransCopra.Save();
            if (keyField == "")
            {
                WBTable table8 = new WBTable();
                table8.OpenTable("wb_transCopra", "SELECT uniq FROM wb_transCopra WHERE " + WBData.CompanyLocation(" AND Ref = '" + this.tblTransCopra.DR["Ref"].ToString() + "'"), WBData.conn);
                keyField = table8.DT.Rows[0]["uniq"].ToString();
                table8.Dispose();
            }
            string[] textArray21 = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] textArray22 = new string[] { this.logMode, WBUser.UserID, this.logReason };
            Program.updateLogHeader("wb_transCopra", keyField, textArray21, textArray22);
            if ((Convert.ToInt16(WBSetting.transflow) >= 2) && (this.textGatepass.Text.Trim() != ""))
            {
                this.tblGatepass.OpenTable("wb_gatepass", "select * from wb_gatepass where " + WBData.CompanyLocation(" and gatepass_number = '" + this.textGatepass.Text.Trim() + "'"), WBData.conn);
                this.tblGatepass.DR = this.tblGatepass.DT.Rows[0];
                this.tblGatepass.DR.BeginEdit();
                this.tblGatepass.DR["Ref"] = this.textRefNo.Text;
                if ((this.pMode == "2ND") || (this.pMode == "MANUAL"))
                {
                    this.tblGatepass.DR["Out_Date"] = DateTime.Now.ToString("dd/MM/yyyy");
                    this.tblGatepass.DR["Out_time"] = DateTime.Now.ToString("HH:mm:ss");
                }
                this.tblGatepass.DR.EndEdit();
                this.tblGatepass.Save();
                string[] textArray23 = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] textArray24 = new string[] { this.logMode, WBUser.UserID, this.logReason };
                Program.updateLogHeader("wb_gatepass", this.tblGatepass.DR["uniq"].ToString(), textArray23, textArray24);
            }
            if ((this.CommType == "G") && ((this.SJAdopted && ((this.pMode == "2ND") || (this.pMode == "EDIT"))) && (this.sIO == "O")))
            {
                try
                {
                    WBSetting.OpenSetting();
                    if (!WBSAP.connect())
                    {
                        this.rptdate = Convert.ToDateTime(this.textReport_Date.Text);
                    }
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_AFTER_WEIGH");
                    IRfcStructure structure = WBSAP.rfcFunction.GetStructure("WA_RECORD");
                    structure.SetValue("VBELN", this.textDL.Text.Trim());
                    structure.SetValue("ZDVR", this.textDriverName.Text.Trim());
                    structure.SetValue("ZDID", this.textDriverID.Text.Trim());
                    structure.SetValue("ZCPN", this.textTruck.Text.Trim());
                    structure.SetValue("WADAT_IST", this.rptdate.ToString("yyyymmdd"));
                    structure.SetValue("LFIMG", this.textNet.Text.Trim());
                    WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                    string text = WBSAP.rfcFunction.GetValue("MSG").ToString();
                    if (text != "")
                    {
                        MessageBox.Show(text);
                    }
                }
                catch (RfcInvalidParameterException exception)
                {
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "E R R O R <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (RfcCommunicationException exception2)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception2.ToString(), "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (RfcBaseException exception3)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                catch (Exception exception4)
                {
                    MessageBox.Show(Resource.Title_003 + " " + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            WBTable table2 = new WBTable();
            table2.OpenTable("tollingContract", "SELECT Coy_Tolling FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + ((this.dgvDO.Rows.Count > 0) ? this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString() : "") + "'"), WBData.conn);
            string sCoyTolling = (table2.DT.Rows.Count > 0) ? table2.DT.Rows[0][0].ToString() : "";
            table2.Dispose();
            if (this.textReport_Date.Text != "")
            {
                this.simpanTimbun(this.dgvDO.Rows[0].Cells["tolling"].Value.ToString(), sCoyTolling);
            }
            if (((((this.pMode == "1ST") || ((this.pMode == "2ND") || (this.pMode == "3RD"))) || (this.pMode == "4TH")) & (this.WX != "")) && (WBSetting.WB_Type == "5"))
            {
                this.wbIndicator.updateCheck0();
            }
            if ((this.pMode == "EDIT") && ((WBSetting.Field("Check_Email").Trim() == "Y") && this.editWarning()))
            {
                string[] textArray25 = new string[] { ("Dear All,<br><br>This email is to notify you that the following transaction has been edited :<table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name"), "</tr><tr class='bd'><td nowrap>Date & Time</td><td nowrap> : ", DateTime.Now.ToShortDateString(), " ", DateTime.Now.ToString("HH:mm:ss") };
                string[] textArray26 = new string[] { ((string.Concat(textArray25) + "</tr><tr class='bd'><td nowrap>Ref Number</td><td nowrap> : " + this.textRefNo.Text) + "</tr><tr class='bd'><td nowrap>Truck Number</td><td nowrap> : " + this.textTruck.Text.Trim()) + "</tr><tr class='bd'><td nowrap>Change Reason</td><td nowrap> : " + this.mChangeReason, "</tr><tr class='bd'><td nowrap>WB Operator</td><td nowrap> : ", WBUser.UserGroup.Trim(), " ( ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " ) " };
                string str13 = (((string.Concat(textArray26) + "</tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : " + WBData.sWBCode) + "</tr></table><br><br>~Changes on Data~               ") + "<table border=1 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Field</td><td nowrap>Before Edit</td><td nowrap>After Edit</td></tr>" + this.editTrace) + "</tr></table><br><br>";
                if (this.editDoTrace.Length > 0)
                {
                    str13 = str13 + "~Changes On DO No~               <table border=1 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>&nbsp</td><td nowrap>DO No.</td><td nowrap>Quantity Nett</td></tr>" + this.editDoTrace + "</table>";
                }
                WBMail mail2 = new WBMail();
                mail2.SendMail_Edit(str13 + "<br>Thank you.");
                mail2.Dispose();
            }
            if ((WBSetting.Field("Check_Email").Trim() == "Y") && ((Program.StrToDouble(this.text2nd.Text, 0) > 0.0) && (Program.StrToDouble(this.textVariance.Text, 0) > 70.0)))
            {
                string[] textArray27 = new string[] { ("Dear All,<br><br>This email is to notify you that the following truck has VARIANCE :<table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name"), "</tr><tr class='bd'><td nowrap>Date & Time</td><td nowrap> : ", DateTime.Now.ToShortDateString(), " ", DateTime.Now.ToString("HH:mm:ss") };
                string[] textArray28 = new string[] { ((((string.Concat(textArray27) + "</tr><tr class='bd'><td nowrap>Ref Number</td><td nowrap> : " + this.textRefNo.Text) + "</tr><tr class='bd'><td nowrap>Truck Number</td><td nowrap> : " + this.textTruck.Text) + "</tr><tr class='bd'><td nowrap>Transporter</td><td nowrap> : " + this.textTransporter.Text) + "</tr><tr class='bd'><td nowrap>Gatepass Number</td><td nowrap> : " + this.textGatepass.Text) + "</tr><tr class='bd'><td nowrap>Variance</td><td nowrap> : " + this.textVariance.Text, "</tr><tr class='bd'><td nowrap>User ID</td><td nowrap> : ", WBUser.UserGroup.Trim(), " ( ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " ) " };
                string str14 = (string.Concat(textArray28) + "</tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : " + WBData.sWBCode) + "</tr></table>" + "<br>Thank you.";
                WBMail mail3 = new WBMail();
                WBTable table9 = new WBTable();
                table9.OpenTable("wb_email_master", "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND ( Email_Code ='VARIANCE')"), WBData.conn);
                int num18 = 0;
                while (true)
                {
                    if (num18 >= table9.DT.Rows.Count)
                    {
                        mail3.SendMail();
                        mail3.Dispose();
                        table9.Dispose();
                        break;
                    }
                    DataRow row5 = table9.DT.Rows[num18];
                    string[] textArray29 = new string[] { row5[0].ToString().Trim(), " ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
                    mail3.Subject = string.Concat(textArray29);
                    mail3.To = row5[1].ToString().Trim();
                    mail3.CC = row5[2].ToString().Trim();
                    num18++;
                }
            }
            if ((this.pMode == "1ST") && (Program.StrToDouble(this.textNet.Text, 0) > 0.0))
            {
                string[] aField = new string[] { "comm_code" };
                string[] textArray31 = new string[] { this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim() };
                this.tblComm.DR = this.tblComm.GetData(aField, textArray31);
                if ((this.tblComm.DR != null) && ((WBSetting.Field("Check_Email").Trim() == "Y") && (this.tblComm.DR["QCapprove"].ToString() == "Y")))
                {
                    string[] textArray32 = new string[] { ("Dear All,<br><br>This email is to notify you that the following truck QUALITY is FAIL :<table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name"), "</tr><tr class='bd'><td nowrap>Date & Time</td><td nowrap> : ", DateTime.Now.ToShortDateString(), " ", DateTime.Now.ToString("HH:mm:ss") };
                    string[] textArray33 = new string[] { (string.Concat(textArray32) + "</tr><tr class='bd'><td nowrap>Ref Number</td><td nowrap> : " + this.textRefNo.Text) + "</tr><tr class='bd'><td nowrap>Truck Number</td><td nowrap> : " + this.textTruck.Text, "</tr><tr class='bd'><td nowrap>User ID</td><td nowrap> : ", WBUser.UserGroup.Trim(), " ( ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " ) " };
                    string str15 = (string.Concat(textArray33) + "</tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : " + WBData.sWBCode) + "</tr></table>" + "<br>Thank you.";
                    WBMail mail4 = new WBMail();
                    WBTable table10 = new WBTable();
                    table10.OpenTable("wb_email_master", "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND ( Email_Code ='QUALITYCHECK')"), WBData.conn);
                    int num19 = 0;
                    while (true)
                    {
                        if (num19 >= table10.DT.Rows.Count)
                        {
                            mail4.SendMail();
                            mail4.Dispose();
                            table10.Dispose();
                            break;
                        }
                        DataRow row6 = table10.DT.Rows[num19];
                        string[] textArray34 = new string[] { row6[0].ToString().Trim(), " ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
                        mail4.Subject = string.Concat(textArray34);
                        mail4.To = row6[1].ToString().Trim();
                        mail4.CC = row6[2].ToString().Trim();
                        num19++;
                    }
                }
            }
            string refno = "";
            if (this.printTicket)
            {
                int num20 = 0;
                while (true)
                {
                    if (num20 >= this.dgvDO.Rows.Count)
                    {
                        break;
                    }
                    string str6 = this.dgvDO.Rows[num20].Cells["Do_No"].Value.ToString().Trim();
                    bool flag212 = num20 > 0;
                    refno = !flag212 ? this.textRefNo.Text : (this.textRefNo.Text + Convert.ToChar((int) (0x40 + num20)).ToString());
                    this.print(refno, str6, this.ticketRpt);
                    num20++;
                }
            }
            if (((WBSetting.bGate == "Y") & (this.pMode != "EDIT")) & (this.WX != ""))
            {
                if (((this.pMode == "1ST") || (this.pMode == "3RD")) & (this.WX != ""))
                {
                    Process.Start(WBSetting.gate2Open);
                }
                if (((this.pMode == "2ND") || (this.pMode == "4TH")) & (this.WX != ""))
                {
                    Process.Start(WBSetting.gate2OpenOut);
                }
                while (true)
                {
                    MessageBox.Show(Resource.Mes_258, Resource.Title_005, MessageBoxButtons.OK);
                    this.nKg = -999;
                    this.nKg = WBSetting.CheckZero();
                    if (this.nKg == 0)
                    {
                        if (((this.pMode == "1ST") || (this.pMode == "3RD")) & (this.WX != ""))
                        {
                            Process.Start(WBSetting.gate2Close);
                        }
                        if (((this.pMode == "2ND") || (this.pMode == "4TH")) & (this.WX != ""))
                        {
                            Process.Start(WBSetting.gate2CloseOut);
                        }
                        break;
                    }
                }
            }
            return this.Saved;
        TR_0153:
            string[] textArray9 = new string[] { "uniq" };
            string[] aFind = new string[] { this.sUniq };
            this.nCurrRow = this.tblTrans.GetRecNo(textArray9, aFind);
            this.tblTrans.DR = this.tblTrans.DT.Rows[this.nCurrRow];
            this.tblTrans.DR.BeginEdit();
            goto TR_014B;
        }

        private void simpanTimbun(string sTol, string sCoyTolling)
        {
            if (this.sUniq.Trim() != "")
            {
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                WBTable table3 = new WBTable();
                WBTable table4 = new WBTable();
                WBTable table5 = new WBTable();
                table2.OpenTable("wb_trans", "select * from wb_transaction where " + WBData.CompanyLocation(" and ref like '" + this.textRefNo.Text.Trim() + "%T' and zAuto = 'Y'"), WBData.conn);
                if (table2.DT.Rows.Count > 0)
                {
                    table2.DR = table2.DT.Rows[0];
                    table2.DR.Delete();
                    table2.Save();
                }
                table3.OpenTable("wb_transDO", "select * from wb_transDO where " + WBData.CompanyLocation(" and ref like '" + this.textRefNo.Text.Trim() + "%T'"), WBData.conn);
                if (table3.DT.Rows.Count > 0)
                {
                    foreach (DataRow row2 in table3.DT.Rows)
                    {
                        row2.Delete();
                    }
                    table3.Save();
                }
                table4.OpenTable("wb_transQC", "select * from wb_transQC where " + WBData.CompanyLocation(" and ref like '" + this.textRefNo.Text.Trim() + "%T'"), WBData.conn);
                if (table4.DT.Rows.Count > 0)
                {
                    foreach (DataRow row3 in table4.DT.Rows)
                    {
                        row3.Delete();
                    }
                    table4.Save();
                }
                table.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and Ref like '" + this.textRefNo.Text + "%'"), WBData.conn);
                foreach (DataRow row4 in table.DT.Rows)
                {
                    table3.OpenTable("wb_transDO", "select * from wb_transDO where " + WBData.CompanyLocation(" and ref like '" + row4["Ref"].ToString() + "'"), WBData.conn);
                    DataRow row = table3.DT.Rows[0];
                    if (row["tolling"].ToString() == "6")
                    {
                        table2.DR = table2.DT.NewRow();
                        foreach (DataColumn column in table2.DT.Columns)
                        {
                            if (column.ColumnName.ToUpper() != "UNIQ")
                            {
                                table2.DR[column.ColumnName] = row4[column.ColumnName];
                            }
                        }
                        table2.DR["ref"] = table2.DR["ref"].ToString() + "T";
                        table2.DR["DO_NO"] = table2.DR["DO_NO"].ToString() + "T";
                        string str = row4["DO_NO"].ToString();
                        table5.OpenTable("wb_timbunDO", "select * from wb_contract where " + WBData.CompanyLocation(" and DO_NO = '" + str + "T' and zAuto = 'Y'"), WBData.conn);
                        table5.DR = table5.DT.Rows[0];
                        table2.DR["Transaction_Code"] = table5.DR["transaction_Code"].ToString();
                        table2.DR["tolling"] = table5.DR["tolling"].ToString();
                        table2.DR["zAuto"] = "Y";
                        table2.DR["checksum"] = table2.Checksum(table2.DR);
                        table2.DT.Rows.Add(table2.DR);
                        table2.Save();
                        table3.DR = table3.DT.NewRow();
                        foreach (DataColumn column2 in table3.DT.Columns)
                        {
                            if (column2.ColumnName.ToUpper() != "UNIQ")
                            {
                                table3.DR[column2.ColumnName] = row[column2.ColumnName];
                            }
                        }
                        table3.DR["ref"] = table3.DR["ref"].ToString() + "T";
                        table3.DR["DO_NO"] = table3.DR["DO_NO"].ToString() + "T";
                        table3.DR["tolling"] = table5.DR["tolling"].ToString();
                        table3.DT.Rows.Add(table3.DR);
                        table3.Save();
                        WBTable table6 = new WBTable();
                        table6.OpenTable("wb_transQC", "SELECT * FROM wb_transQC WHERE " + WBData.CompanyLocation(" AND ref = '" + row4["REF"].ToString() + "T'"), WBData.conn);
                        table6.AddFromDGV(this.dgvQC_All, "Ref", row4["REF"].ToString() + "T");
                        table6.ReOpen();
                        table6.Dispose();
                    }
                }
                table.Dispose();
                table2.Dispose();
                table3.Dispose();
                table4.Dispose();
            }
        }

        private void tabControl1_MouseClick(object sender, MouseEventArgs e)
        {
            this.settingTabControl();
        }

        private void tabPageShow(string pCommType, string pMaterialType)
        {
            if (this.tabControl1.TabPages.IndexOf(this.tabPageDeduc) >= 0)
            {
                this.tabControl1.TabPages.Remove(this.tabPageDeduc);
            }
            if (this.tabControl1.TabPages.IndexOf(this.tabPageDivision) >= 0)
            {
                this.tabControl1.TabPages.Remove(this.tabPageDivision);
            }
            if (this.tabControl1.TabPages.IndexOf(this.tabPageQC) >= 0)
            {
                this.tabControl1.TabPages.Remove(this.tabPageQC);
            }
            if (this.tabControl1.TabPages.IndexOf(this.tabPagePorla) >= 0)
            {
                this.tabControl1.TabPages.Remove(this.tabPagePorla);
            }
            if (this.tabControl1.TabPages.IndexOf(this.tabPageCopra) >= 0)
            {
                this.tabControl1.TabPages.Remove(this.tabPageCopra);
            }
            if (this.tabControl1.TabPages.IndexOf(this.tabPageDL) >= 0)
            {
                this.tabControl1.TabPages.Remove(this.tabPageDL);
            }
            if (this.tabControl1.TabPages.IndexOf(this.tabPageBag) >= 0)
            {
                this.tabControl1.TabPages.Remove(this.tabPageBag);
            }
            if ((pMaterialType == "SOLD") && (this.tabControl1.TabPages.IndexOf(this.tabPageBag) < 0))
            {
                this.tabControl1.TabPages.Add(this.tabPageBag);
            }
            if (pCommType == "S")
            {
                if (this.tabControl1.TabPages.IndexOf(this.tabPageQC) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPageQC);
                }
            }
            else if (pCommType == "F")
            {
                if (this.tabControl1.TabPages.IndexOf(this.tabPageDeduc) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPageDeduc);
                }
                this.tabControl1.TabPages["tabPageDeduc"].Text = "Deduction";
                if (this.tabControl1.TabPages.IndexOf(this.tabPagePorla) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPagePorla);
                }
                if (this.tabControl1.TabPages.IndexOf(this.tabPageDivision) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPageDivision);
                }
            }
            else if (pCommType == "C")
            {
                if (this.tabControl1.TabPages.IndexOf(this.tabPageCopra) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPageCopra);
                }
            }
            else if ((pCommType == "G") && (this.tabControl1.TabPages.IndexOf(this.tabPageDL) < 0))
            {
                this.tabControl1.TabPages.Add(this.tabPageDL);
            }
        }

        private void text1st_Leave(object sender, EventArgs e)
        {
            this.HitNet();
        }

        private void text1st_TextChanged(object sender, EventArgs e)
        {
            this.hitungBTN();
        }

        private void text2nd_Leave(object sender, EventArgs e)
        {
            this.HitNet();
        }

        private void text2nd_TextChanged(object sender, EventArgs e)
        {
            try
            {
                this.hitungBTN();
                string str = Program.getFieldValue("wb_transaction_Type", "IO", "transaction_code", this.dgvDO.Rows[0].Cells["transaction_code"].ToString());
                if (((Program.getFieldValue("wb_commodity", "check_tare", "comm_code", this.dgvDO.Rows[0].Cells["comm_code"].ToString()) == "Y") && (Convert.ToDouble(this.text2nd.Text) != 0.0)) && (str.Trim() == "I"))
                {
                    if ((Convert.ToDouble(this.minTare) <= 0.0) || !(Convert.ToDouble(this.maxTare) != 0.0))
                    {
                        MessageBox.Show(Resource.Mes_282, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    if (!this.checkTare())
                    {
                        string[] textArray1 = new string[] { Resource.Mes_323, " ( ", this.minTare, " - ", this.maxTare, " )" };
                        MessageBox.Show(string.Concat(textArray1), Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
            }
            catch
            {
            }
        }

        private void text3rd_Leave(object sender, EventArgs e)
        {
            this.HitNet();
        }

        private void text4th_Leave(object sender, EventArgs e)
        {
            this.HitNet();
        }

        private void textAvg_Leave(object sender, EventArgs e)
        {
            if (this.textAvg.Enabled && (Program.CheckNumeric(this.textAvg) && !(Program.StrToDouble(this.textBunchTotal.Text, 0) != 0.0)))
            {
                if ((Program.StrToDouble(this.textNET1.Text, 0) > 0.0) & (Program.StrToDouble(this.textAvg.Text, 0) > 0.0))
                {
                    this.textBunchTotal.Text = Convert.ToString((double) (Program.StrToDouble(this.textNET1.Text, 2) / Program.StrToDouble(this.textAvg.Text, 2)));
                    this.textBunchTotal.Text = Math.Round(Program.StrToDouble(this.textBunchTotal.Text, 2), 0).ToString();
                    this.textBunchDeduc.Text = this.textBunchTotal.Text;
                }
                this.BJR();
            }
        }

        private void textBagCode_Leave(object sender, EventArgs e)
        {
            if (this.textBagCode.Text.Trim() != "")
            {
                this.tblBag.ReOpen();
                string[] aField = new string[] { "Bag_Code" };
                string[] aFind = new string[] { this.textBagCode.Text.Trim() };
                int recNo = this.tblBag.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.buttonBag.PerformClick();
                    this.textBagCode.Focus();
                }
                else
                {
                    this.labelBagDesc.Text = this.tblBag.DT.Rows[recNo]["Description"].ToString().Trim();
                    this.labelBagWeight.Text = $"{Program.StrToDouble(this.tblBag.DT.Rows[recNo]["Weight"].ToString().Trim(), 2):#,##0.###}";
                    this.textTotalBagWeight.Text = $"{Program.StrToDouble(this.labelBagWeight.Text, 2) * Program.StrToDouble(this.textTotalBag.Text, 2):#,##0.###}";
                }
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                this.textBox3.Text = (Convert.ToDouble(this.textBox2.Text) / Convert.ToDouble(this.textGunnyBatch.Text)).ToString("0.00");
            }
            catch
            {
                this.textBox3.Text = "0";
            }
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            this.groupBox4.Text = "[ " + this.textUnitName.Text.Trim() + " ]";
            this.labelUnit.Text = "KG per " + this.textUnitName.Text.Trim();
            this.label48.Text = this.textUnitName.Text.Trim();
            this.label52.Text = this.textUnitName.Text.Trim();
            this.label54.Text = "Netto per " + this.textUnitName.Text.Trim();
            this.label48.Text = this.textUnitName.Text.Trim();
            this.label52.Text = this.textUnitName.Text.Trim() + " Left";
        }

        private void textBoxLoadUnload_Leave(object sender, EventArgs e)
        {
            if (this.textBoxLoadUnload.Text.Trim() != "")
            {
                string[] aField = new string[] { "load_unload" };
                string[] aFind = new string[] { this.textBoxLoadUnload.Text };
                this.tblLoadUnload.DR = this.tblLoadUnload.GetData(aField, aFind);
                if (!ReferenceEquals(this.tblLoadUnload.DR, null))
                {
                    this.labelLoadUnloadName.Text = this.tblLoadUnload.DR["load_desc"].ToString();
                }
                else
                {
                    this.buttonLoadUnload.PerformClick();
                    this.textBoxLoadUnload.Focus();
                }
            }
        }

        private void textBunchTotal_Leave(object sender, EventArgs e)
        {
            if (Program.CheckNumeric(this.textBunchTotal))
            {
                this.HitNet();
                this.BJR();
                if (this.use_gunny == "Y")
                {
                    double num = Convert.ToDouble(this.textAvg.Text);
                    if ((num < this.sGunnyMin) || (num > this.sGunnyMax))
                    {
                        MessageBox.Show(Resource.Mes_287, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        this.textAvg.Text = "0";
                        this.textBunchTotal.Text = "0";
                        this.textBunchDeduc.Text = "0";
                        return;
                    }
                }
                if ((this.textBunchDeduc.Text.Trim() == "0") || (this.textBunchDeduc.Text.Trim() == ""))
                {
                    this.textBunchDeduc.Text = this.textBunchTotal.Text;
                }
                this.textAvg.ReadOnly = Program.StrToDouble(this.textBunchTotal.Text, 0) > 0.0;
            }
        }

        private void textCommodity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\b')
            {
                this.textCommodity.Text = "";
            }
        }

        private void textCust_Leave(object sender, EventArgs e)
        {
            if (this.textCust.Text != "")
            {
                this.tblCust.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" and relation_code = '" + this.textCust.Text.Trim() + "' and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
                string[] aField = new string[] { "Relation_Code" };
                string[] aFind = new string[] { this.textCust.Text };
                DataRow data = this.tblCust.GetData(aField, aFind);
                if (data != null)
                {
                    this.labelCustName.Text = data["Relation_name"].ToString().Trim();
                    this.labelCustName.Refresh();
                }
                else
                {
                    this.buttonCust.PerformClick();
                    this.textCust.Focus();
                }
            }
        }

        private void textDate1st_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textTime1st.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textDate1st.Text).ToShortDateString());
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_110, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textDate1st.Focus();
                }
            }
        }

        private void textDate2nd_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textDate2nd.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textDate2nd.Text).ToShortDateString());
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_110, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textDate2nd.Focus();
                }
            }
        }

        private void textDate3rd_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textDate3rd.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textDate3rd.Text).ToShortDateString());
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_110, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textDate3rd.Focus();
                }
            }
        }

        private void textDate4th_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textDate4th.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textDate4th.Text).ToShortDateString());
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_110, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textDate4th.Focus();
                }
            }
        }

        private void textDivision_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDivision_Leave(object sender, EventArgs e)
        {
            if (this.textDivision.Text.Trim() != "")
            {
                string[] aField = new string[] { "Division_code" };
                string[] aFind = new string[] { this.textDivision.Text.Trim() };
                this.tblDivision.DR = this.tblDivision.GetData(aField, aFind);
                if (!ReferenceEquals(this.tblDivision.DR, null))
                {
                    this.labelDivisionName.Text = this.tblDivision.DR["Division_name"].ToString();
                }
                else
                {
                    this.buttonDivision.PerformClick();
                    this.textDivision.Focus();
                }
            }
        }

        private void textDL_Leave(object sender, EventArgs e)
        {
            if (this.textDL.Text.Trim() != "")
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_transBatch", "Select * from wb_transBatch where Do_No ='" + this.textDL.Text.Trim() + "'", WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    int num = 0;
                    while (true)
                    {
                        if (num >= table.DT.Rows.Count)
                        {
                            break;
                        }
                        table.DR = table.DT.Rows[num];
                        string zValue = table.DR["Ref"].ToString().Trim();
                        string str2 = Program.getFieldValue("wb_transaction", "Deleted", "Ref", zValue);
                        if (!((str2 != "Y") & (zValue != this.textRefNo.Text.Trim())))
                        {
                            num++;
                            continue;
                        }
                        MessageBox.Show(this.textDL.Text.Trim() + " " + Resource.Mes_263);
                        this.textDL.Focus();
                        this.textDL.SelectAll();
                        table.Dispose();
                        return;
                    }
                }
                table.Dispose();
            }
        }

        private void textDN_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDN_Leave(object sender, EventArgs e)
        {
            if ((WBSetting.Field("DeliveryNote") == "Y") && (this.textDN.Text.Trim() != "-"))
            {
                if (this.dgvDO.Rows.Count <= 0)
                {
                    MessageBox.Show(Resource.Mes_303, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textDN.Text = "";
                }
                else if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    this.textDN.Enabled = false;
                }
                else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    this.textDN.Enabled = false;
                }
                else if ((this.CommType == "F") && !this.CheckSPB())
                {
                    MessageBox.Show(Resource.Mes_277, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.textDN.Focus();
                }
            }
        }

        private void textDriverID_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDriverID_Leave(object sender, EventArgs e)
        {
            this.tblDriver.ReOpen();
            string[] aField = new string[] { "License_No" };
            string[] aFind = new string[] { this.textDriverID.Text.Trim() };
            int recNo = this.tblDriver.GetRecNo(aField, aFind);
            if (recNo <= -1)
            {
                this.buttonDriver.PerformClick();
                this.textDriverID.Focus();
            }
            else
            {
                this.labelDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                this.textDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                if (this.textTruck.Text.Trim() == "")
                {
                    this.textTruck.Text = this.tblDriver.DT.Rows[recNo]["Truck_Number"].ToString();
                    this.textTruck.Focus();
                }
            }
        }

        private void textDriverName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDriverName_Leave(object sender, EventArgs e)
        {
            this.tblDriver.ReOpen();
            string[] aField = new string[] { "Name" };
            string[] aFind = new string[] { this.textDriverName.Text.Trim() };
            int recNo = this.tblDriver.GetRecNo(aField, aFind);
            if (recNo <= -1)
            {
                this.buttonDriver.PerformClick();
                this.textDriverID.Focus();
            }
            else
            {
                this.textDriverID.Text = this.tblDriver.DT.Rows[recNo]["License_No"].ToString();
                this.labelDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                this.textDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                if (this.textTruck.Text.Trim() == "")
                {
                    this.textTruck.Text = this.tblDriver.DT.Rows[recNo]["Truck_Number"].ToString();
                    this.textTruck.Focus();
                }
            }
        }

        private void textGrade_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textGrossEstate_Enter(object sender, EventArgs e)
        {
            this.textGrossEstate.SelectAll();
        }

        private void textGrossEstate_Leave(object sender, EventArgs e)
        {
            this.HitNetEstate();
        }

        private void textGrossEstate_TextChanged(object sender, EventArgs e)
        {
        }

        private void textMill_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textMill_Leave(object sender, EventArgs e)
        {
            if (this.textMill.Text.Trim() != "")
            {
                string[] aField = new string[] { "Mill_code" };
                string[] aFind = new string[] { this.textMill.Text.Trim() };
                this.tblMill.DR = this.tblMill.GetData(aField, aFind);
                if (!ReferenceEquals(this.tblMill.DR, null))
                {
                    this.labelMillName.Text = this.tblMill.DR["Mill_name"].ToString();
                }
                else
                {
                    this.buttonMill.PerformClick();
                    this.textMill.Focus();
                }
            }
        }

        private void textNet_TextChanged(object sender, EventArgs e)
        {
            this.hitungBTN();
        }

        private void textNettoBatch_Leave(object sender, EventArgs e)
        {
            try
            {
                double num = Convert.ToInt32(this.textNettoBatch.Text) / Convert.ToInt32(this.sGunnyNet);
                this.textGunnyBatch.Text = Math.Round(num, 0);
            }
            catch
            {
                this.textGunnyBatch.Text = "0";
            }
        }

        private void textQControl_Leave(object sender, EventArgs e)
        {
            this._QC_SaveTankQC();
        }

        private void textRefNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textRefNo_Leave(object sender, EventArgs e)
        {
            if ((this.pMode == "MANUAL") && (this.textRefNo.Text.Trim() != ""))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_transaction", "Select Ref From wb_transaction Where " + WBData.CompanyLocation(" AND Ref='" + this.textRefNo.Text.Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count != 0)
                {
                    MessageBox.Show(Resource.Mes_289 + " " + this.textRefNo.Text.Trim(), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textRefNo.Focus();
                }
            }
        }

        private void textRemarkTicket_TextChanged(object sender, EventArgs e)
        {
        }

        private void textReport_Date_Leave(object sender, EventArgs e)
        {
            if ((this.pMode == "MANUAL") && (this.textReport_Date.Text.Trim() != ""))
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textReport_Date.Text).ToShortDateString());
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_110, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textReport_Date.Focus();
                }
            }
        }

        private void textSource_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textSource_Leave(object sender, EventArgs e)
        {
            if (this.textSource.Text.Trim() != "")
            {
                string[] aField = new string[] { "source_code" };
                string[] aFind = new string[] { this.textSource.Text.Trim() };
                this.tblSource.DR = this.tblSource.GetData(aField, aFind);
                if (!ReferenceEquals(this.tblSource.DR, null))
                {
                    this.labelSourceName.Text = this.tblSource.DR["Description"].ToString();
                }
                else
                {
                    this.buttonSource.PerformClick();
                    this.textSource.Focus();
                }
            }
        }

        private void textTanker_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\b')
            {
                this.textTanker.Text = "";
                this.labelTankerMax.Text = "";
            }
        }

        private void textTankQC_Leave(object sender, EventArgs e)
        {
            this._QC_SaveTankQC();
        }

        private void textTareEstate_Enter(object sender, EventArgs e)
        {
            this.textTareEstate.SelectAll();
        }

        private void textTareEstate_Leave(object sender, EventArgs e)
        {
            this.HitNetEstate();
        }

        private void textTareEstate_TextChanged(object sender, EventArgs e)
        {
            this.HitNetEstate();
        }

        private void textTime1st_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textTime1st.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textTime1st.Text).ToShortTimeString());
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_274, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textTime1st.Focus();
                }
            }
        }

        private void textTime2nd_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textTime2nd.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textTime2nd.Text).ToShortTimeString());
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_274, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textTime2nd.Focus();
                }
            }
        }

        private void textTime3rd_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textTime3rd.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textTime3rd.Text).ToShortTimeString());
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_274, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textTime3rd.Focus();
                }
            }
        }

        private void textTotalBag_Leave(object sender, EventArgs e)
        {
            if ((this.textTotalBag.Text.Trim() != "") && (this.labelBagWeight.Text.Trim() != ""))
            {
                this.textTotalBagWeight.Text = $"{Program.StrToDouble(this.labelBagWeight.Text, 2) * Program.StrToDouble(this.textTotalBag.Text, 2):#,##0.###}";
                this.HitNet();
            }
        }

        private void textTotalBag_TextChanged(object sender, EventArgs e)
        {
        }

        private void textTotalBagWeight_Leave(object sender, EventArgs e)
        {
            if (!Program.CheckNumeric(this.textTotalBagWeight))
            {
                this.textTotalBagWeight.SelectAll();
                this.textTotalBagWeight.Focus();
            }
            else if (this.textTotalBagWeight.Text.Trim() != "")
            {
                this.HitNet();
            }
        }

        private void textTotalBagWeight_TextChanged(object sender, EventArgs e)
        {
        }

        private void textTrailerNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransporter_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransporter_TextChanged(object sender, EventArgs e)
        {
            if (this.textTransporter.Text != "")
            {
                string[] aField = new string[] { "Transporter_Code" };
                string[] aFind = new string[] { this.textTransporter.Text };
                DataRow data = this.tblTransporter.GetData(aField, aFind);
                if (data == null)
                {
                    this.labelTransporterName.Text = "";
                }
                else
                {
                    this.labelTransporterName.Text = data["Transporter_Name"].ToString().Trim();
                    this.labelTransporterName.Refresh();
                }
            }
        }

        private void textTruck_Enter(object sender, EventArgs e)
        {
        }

        private void textTruck_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTruck_Leave(object sender, EventArgs e)
        {
            this.tblTruck.ReOpen();
            string[] aField = new string[] { "Truck_Number" };
            string[] aFind = new string[] { this.textTruck.Text.Trim() };
            int recNo = this.tblTruck.GetRecNo(aField, aFind);
            if (recNo <= -1)
            {
                this.buttonTruck.PerformClick();
                this.textTruck.Focus();
            }
            else
            {
                this.textTruck.Text = this.tblTruck.DT.Rows[recNo]["Truck_Number"].ToString().Trim();
                if (this.textTransporter.Text == "")
                {
                    this.textTransporter.Text = this.tblTruck.DT.Rows[recNo]["Transporter_Code"].ToString().Trim();
                    string[] textArray3 = new string[] { "Transporter_Code" };
                    string[] textArray4 = new string[] { this.textTransporter.Text };
                    DataRow data = this.tblTransporter.GetData(textArray3, textArray4);
                    if (data != null)
                    {
                        this.labelTransporterName.Text = data["Transporter_Name"].ToString().Trim();
                    }
                }
                this.maxTare = this.tblTruck.DT.Rows[recNo]["max_Tare"].ToString().Trim();
                this.minTare = this.tblTruck.DT.Rows[recNo]["min_Tare"].ToString().Trim();
            }
        }

        private void textUnitNameWeight_Leave(object sender, EventArgs e)
        {
            if (Program.CheckNumeric(this.textUnitNameWeight))
            {
                this.HitNet();
            }
        }

        private void textUnloading_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void ThisClose()
        {
            this.nKg = -999;
            if ((this.pMode == "VIEW") || (MessageBox.Show(Resource.Mes_266, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes))
            {
                if ((WBSetting.bGate == "Y") & (this.WX != ""))
                {
                    if (((this.pMode == "1ST") || (this.pMode == "3RD")) & (this.WX != ""))
                    {
                        Process.Start(WBSetting.gate1Open);
                        while (true)
                        {
                            MessageBox.Show(Resource.Mes_258, Resource.Title_005, MessageBoxButtons.OK);
                            if (WBSetting.CheckZero() == 0)
                            {
                                Process.Start(WBSetting.gate1Close);
                                break;
                            }
                        }
                    }
                    if (((this.pMode == "2ND") || (this.pMode == "4TH")) & (this.WX != ""))
                    {
                        Process.Start(WBSetting.gate2Open);
                        while (true)
                        {
                            MessageBox.Show(Resource.Mes_258, Resource.Title_005, MessageBoxButtons.OK);
                            this.nKg = WBSetting.CheckZero();
                            if (this.nKg == 0)
                            {
                                Process.Start(WBSetting.gate2Close);
                                break;
                            }
                        }
                    }
                }
                base.Close();
            }
        }

        private void translate()
        {
            this.label2.Text = Resource.Trans_001;
            this.label6.Text = Resource.Trans_002;
            this.label7.Text = Resource.Trans_003;
            this.label19.Text = Resource.Trans_004;
            this.label21.Text = Resource.Trans_005;
            this.label35.Text = Resource.Trans_006;
            this.label37.Text = Resource.Trans_007;
            this.groupOtherParty.Text = Resource.Trans_008;
            this.label8.Text = Resource.Trans_009;
            this.label9.Text = Resource.Trans_010;
            this.label10.Text = Resource.Trans_011;
            this.label25.Text = Resource.Trans_012;
            this.groupFactoryWeight.Text = Resource.Trans_013;
            this.label13.Text = Resource.Trans_014;
            this.label12.Text = Resource.Trans_015;
            this.label11.Text = Resource.Trans_016;
            this.label26.Text = Resource.Trans_017;
            this.buttonTarraHistory.Text = Resource.Trans_018;
            this.buttonSave.Text = Resource.Trans_019;
            this.buttonSavePrint.Text = Resource.Trans_020;
            this.buttonCancel.Text = Resource.Trans_021;
            this.buttonReadIndicator.Text = Resource.Trans_022;
            this.label17.Text = Resource.Trans_023;
            this.label18.Text = Resource.Trans_024;
            this.tabPageDO.Text = Resource.Trans_049;
            this.tabPageInfo.Text = Resource.Trans_050;
            this.tabPageQC.Text = Resource.Trans_051;
            this.tabPageDeduc.Text = Resource.Trans_052;
            this.tabPagePorla.Text = Resource.Trans_053;
            this.tabPageDivision.Text = Resource.Trans_054;
            this.buttonAddDeduc.Text = Resource.Trans_055;
            this.buttonAddDO.Text = Resource.Trans_055;
            this.button17.Text = Resource.Trans_055;
            this.buttonContAdd.Text = Resource.Trans_055;
            this.buttonAddPorla.Text = Resource.Trans_055;
            this.button18.Text = Resource.Trans_055;
            this.buttonEditDeduc.Text = Resource.Trans_056;
            this.buttonEditDO.Text = Resource.Trans_056;
            this.button16.Text = Resource.Trans_056;
            this.buttonContEdit.Text = Resource.Trans_056;
            this.buttonEditPorla.Text = Resource.Trans_056;
            this.buttonDeleteDO.Text = Resource.Trans_057;
            this.buttonDeleteDeduc.Text = Resource.Trans_057;
            this.button15.Text = Resource.Trans_057;
            this.buttonContDelete.Text = Resource.Trans_057;
            this.buttonDeletePorla.Text = Resource.Trans_057;
            this.buttonMergeDO.Text = Resource.Trans_058;
            this.label63.Text = Resource.Trans_059;
            this.label62.Text = Resource.Trans_060;
            this.label20.Text = Resource.Trans_061;
            this.label42.Text = Resource.Trans_062;
            this.label44.Text = Resource.Trans_063;
            this.label34.Text = Resource.Trans_068;
            this.labelUnit.Text = Resource.Trans_069;
            this.label29.Text = Resource.Trans_070;
            this.label30.Text = Resource.Trans_071;
            this.label31.Text = Resource.Trans_072;
            this.tabPageBag.Text = Resource.Trans_094;
            this.label61.Text = Resource.Trans_095;
            this.labelBagDesc.Text = Resource.Trans_096;
            this.label64.Text = Resource.Trans_097;
            this.label65.Text = Resource.Trans_098;
            this.labelGatepass.Text = Resource.Gatepass_001;
            this.labelTransType.Text = Resource.Gatepass_023;
            this.label1.Text = Resource.Gatepass_025;
            this.label3.Text = Resource.TruckE_009;
            this.label4.Text = Resource.Gatepass_002;
        }

        private void TransToLog(string pUniq, string pmode)
        {
            WBTable table = new WBTable();
            if (pUniq.Trim() != "")
            {
                table.OpenTable("wb_transaction", "Select * From wb_transaction where Uniq=" + pUniq.Trim(), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_trans_log", "Select * From wb_trans_log where 1=2", WBData.conn);
                    table2.DR = table2.DT.NewRow();
                    foreach (DataColumn column in table2.DT.Columns)
                    {
                        try
                        {
                            if (((column.ColumnName.ToUpper() != "UNIQ") && (column.ColumnName.ToUpper() != "LOG_DATE".ToUpper())) && (column.ColumnName.ToUpper() != "LOG_TIME".ToUpper()))
                            {
                                table2.DR[column.ColumnName] = table.DT.Rows[0][column.ColumnName];
                            }
                        }
                        catch
                        {
                        }
                    }
                    if (pmode == "EDIT")
                    {
                        table2.DR["ChangeReason"] = this.mChangeReason;
                        table2.DR["Edit_By"] = WBUser.UserID;
                        table2.DR["Edit_Date"] = DateTime.Now;
                        table2.DR["log_Date"] = DateTime.Now.Date;
                        table2.DR["log_time"] = DateTime.Now.ToString("HH:mm");
                    }
                    else if (pmode == "PRINT")
                    {
                        table2.DR["Printed_By"] = WBUser.UserID.Trim();
                        table2.DR["Printed_Date"] = DateTime.Now;
                    }
                    table2.DT.Rows.Add(table2.DR);
                    table2.Save();
                    table2.Dispose();
                }
            }
            else
            {
                return;
            }
            table.Dispose();
        }

        private void TransType()
        {
            string[] aField = new string[] { "Transaction_Code" };
            string[] aFind = new string[] { this.comTransType.Text };
            this.rowTransType = this.tblTransType.GetData(aField, aFind);
            if (this.rowTransType != null)
            {
                this.labelTransTypeName.Text = "(" + this.rowTransType["IO"].ToString() + ") " + this.rowTransType["Transaction_Name"].ToString();
                this.sIO = this.rowTransType["IO"].ToString();
                this.labelRelation.Text = (this.sIO != "I") ? "Customer" : "Vendor";
                this.transType = this.rowTransType["IO"].ToString().Trim();
            }
        }
    }
}

