﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTransDO_View : Form
    {
        public WBTable ztable = new WBTable();
        public WBTable ztable_PI = new WBTable();
        public WBTable wbContainer = new WBTable();
        public bool doviewFirsttime;
        public bool contFirstTime;
        public DateTime date1;
        public DateTime date2;
        public string fDate;
        public string fNoRef;
        public string fMode;
        private IContainer components = null;
        public TextBox textDO;
        private Panel panel1;
        private Button button1;
        private Button button3;
        public TextBox textRefNo;
        public Button buttonComm;
        public TextBox textCommodity;
        public Label label28;
        public Button buttonDO;
        public Label label1;
        public Label label3;
        public TextBox textRelation;
        public Button buttonRelation;
        public Label label2;
        private Button button2;
        private DataGridView dataGridView1;
        public Panel panel2;
        public TextBox TextFind;
        public Button buttonFind;
        public Label labelRecords;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem exportToExcelToolStripMenuItem;
        public TextBox textContainer;
        public Label label5;
        private Button button4;
        public Label label6;
        private DateTimePicker dtFrom;
        private Label label7;
        private Label label8;
        private DataGridView dataGridView2;
        private CheckBox chkDate;
        public TextBox textPI_No;
        public Label label4;

        public FormTransDO_View()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.doviewFirsttime = false;
            this.textRelation.Text = "";
            this.textCommodity.Text = "";
            this.textDO.Text = "";
            this.textRefNo.Text = "";
            this.dtFrom.Checked = false;
            this.button3.PerformClick();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.fMode = "";
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.doviewFirsttime = false;
            this.OpenTable();
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Refresh();
            this.dataGridView1.Focus();
        }

        private void button4_Click(object sender, EventArgs e)
        {
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            string sqltext = "select * from vw_Container";
            if ((this.textContainer.Text.Trim().Length > 0) || this.chkDate.Checked)
            {
                sqltext = sqltext + " WHERE ";
            }
            this.fDate = Program.DTOC(this.dtFrom.Value);
            if (this.textContainer.Text.Trim().Length > 0)
            {
                sqltext = sqltext + " container like '%" + this.textContainer.Text.Trim() + "%' ";
            }
            if (this.chkDate.Checked)
            {
                if (this.textContainer.Text.Length > 0)
                {
                    sqltext = sqltext + " and ";
                }
                sqltext = sqltext + " ref_date >= '" + this.fDate + "'";
            }
            this.wbContainer.OpenTable("vw_Container", sqltext, WBData.conn);
            this.dataGridView2.DataSource = this.wbContainer.DV;
            if (this.wbContainer.DT.Rows.Count < 0)
            {
                MessageBox.Show("Container Not Found");
            }
            else
            {
                try
                {
                    this.wbContainer.DR = this.wbContainer.DT.Rows[0];
                    this.ztable.OpenTable("wb_transDO", "SELECT *  FROM wb_transDO WHERE ref ='" + this.wbContainer.DR["ref"].ToString() + "'", WBData.conn);
                    this.dataGridView1.DataSource = this.ztable.DV;
                }
                catch
                {
                }
            }
            this.contFirstTime = true;
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
            }
            commodity.Dispose();
        }

        private void buttonDO_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE"
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDO.Text = contract.ReturnRow["DO_No"].ToString();
            }
            contract.Dispose();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.ztable.FindSql(this.dataGridView1, this.TextFind.Text);
        }

        private void buttonRelation_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textRelation.Text = vendor.ReturnRow["relation_code"].ToString();
            }
            vendor.Dispose();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.wbContainer.OpenTable("vw_Container", "select * from vw_Container where ref = '" + this.dataGridView1.Rows[this.dataGridView1.CurrentRow.Index].Cells["ref"].Value.ToString() + "'", WBData.conn);
                this.dataGridView2.DataSource = this.wbContainer.DV;
            }
            catch
            {
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.fNoRef = this.dataGridView1.CurrentRow.Cells["ref"].Value.ToString();
            this.fMode = "FIND";
            base.Close();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.fDate = Program.DTOC(this.dtFrom.Value);
                this.ztable.Close();
                this.ztable.OpenTable("wb_transDO", "SELECT *  FROM wb_transDO where ref ='" + this.dataGridView2.Rows[this.dataGridView2.CurrentRow.Index].Cells["ref"].Value.ToString() + "'", WBData.conn);
                this.dataGridView1.DataSource = this.ztable.DV;
                this.contFirstTime = false;
            }
            catch
            {
            }
        }

        private void dataGridView2_SelectionChanged(object sender, EventArgs e)
        {
        }

        private void dataGridView2_SelectionChanged_1(object sender, EventArgs e)
        {
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void dOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.dataGridView1.Refresh();
            this.initDGTrans();
        }

        private void exportToExcelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Program.export2Excel(this.dataGridView1, "", "", false);
                Program.export2Excel(this.dataGridView2, "", "", false);
            }
            catch
            {
            }
        }

        private void FormTransDO_View_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.fMode = "";
                base.Close();
            }
        }

        private void FormTransDO_View_Load(object sender, EventArgs e)
        {
            this.dtFrom.Checked = true;
            this.dtFrom.Value = DateTime.Today;
            this.chkDate.Checked = true;
            base.KeyPreview = true;
            this.labelRecords.Text = "";
            this.initDGTrans();
            this.wbContainer.OpenTable("vw_container", "select * from vw_container where 1=2", WBData.conn);
            this.dataGridView2.DataSource = this.wbContainer.DV;
            this.dataGridView2.Columns["coy"].Visible = false;
            this.dataGridView2.Columns["Location_code"].Visible = false;
        }

        private void initDGTrans()
        {
            this.OpenTable();
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["DO_No"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["posted"].Visible = false;
            this.dataGridView1.Columns["Container"].Visible = false;
            this.dataGridView1.Columns["Transaction_Code"].HeaderText = "Tx";
            this.dataGridView1.Columns["Ref"].HeaderText = "Ref No";
            this.dataGridView1.Columns["Date1"].HeaderText = "1st Date";
            this.dataGridView1.Columns["Date2"].HeaderText = "2nd Date";
            this.dataGridView1.Columns["Date3"].HeaderText = "3rd Date";
            this.dataGridView1.Columns["Date4"].HeaderText = "4th Date";
            this.dataGridView1.Columns["DO_No"].HeaderText = "DO No";
            this.dataGridView1.Columns["PI_No"].HeaderText = "PI No";
            this.dataGridView1.Columns["Comm_Code"].HeaderText = "Commodity";
            this.dataGridView1.Columns["Relation_Code"].HeaderText = "Relation Code";
            this.dataGridView1.Columns["Relation_Name"].HeaderText = "Relation Name";
            this.dataGridView1.Columns["Confirmation"].HeaderText = "Confirmation No";
            this.dataGridView1.Columns["Contract"].HeaderText = "Contract No";
            this.dataGridView1.Columns["Estate"].HeaderText = "Estate";
            this.dataGridView1.Columns["Agen"].HeaderText = "As Agen";
            this.dataGridView1.Columns["Bruto"].HeaderText = "Bruto";
            this.dataGridView1.Columns["Bruto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dataGridView1.Columns["Bruto"].DefaultCellStyle.Format = "N0";
            this.dataGridView1.Columns["Tarra"].HeaderText = "Tare";
            this.dataGridView1.Columns["Tarra"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dataGridView1.Columns["Tarra"].DefaultCellStyle.Format = "N0";
            this.dataGridView1.Columns["Netto"].HeaderText = "Net";
            this.dataGridView1.Columns["Netto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dataGridView1.Columns["Netto"].DefaultCellStyle.Format = "N0";
            this.dataGridView1.Columns["ConvNett"].HeaderText = "Convertion Net";
            this.dataGridView1.Columns["ConvNett"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dataGridView1.Columns["ConvNett"].DefaultCellStyle.Format = "N0";
            this.dataGridView1.Columns["ConvUnit"].HeaderText = "Conv. Unit";
            this.dataGridView1.Columns["ConvTolerance"].HeaderText = "Conv. Tolerance";
            this.dataGridView1.Columns["ConvTolerance"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dataGridView1.Columns["ConvTolerance"].DefaultCellStyle.Format = "N0";
            this.dataGridView1.Columns["Transporter_Code"].HeaderText = "Transporter Code";
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            this.buttonComm = new Button();
            this.textCommodity = new TextBox();
            this.label28 = new Label();
            this.buttonDO = new Button();
            this.textDO = new TextBox();
            this.label1 = new Label();
            this.panel1 = new Panel();
            this.chkDate = new CheckBox();
            this.label6 = new Label();
            this.dtFrom = new DateTimePicker();
            this.button4 = new Button();
            this.textContainer = new TextBox();
            this.label5 = new Label();
            this.textPI_No = new TextBox();
            this.label4 = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.button3 = new Button();
            this.label3 = new Label();
            this.textRelation = new TextBox();
            this.buttonRelation = new Button();
            this.textRefNo = new TextBox();
            this.label2 = new Label();
            this.menuStrip1 = new MenuStrip();
            this.exportToExcelToolStripMenuItem = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.panel2 = new Panel();
            this.labelRecords = new Label();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.label7 = new Label();
            this.label8 = new Label();
            this.dataGridView2 = new DataGridView();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.panel2.SuspendLayout();
            ((ISupportInitialize) this.dataGridView2).BeginInit();
            base.SuspendLayout();
            this.buttonComm.Location = new Point(0x246, 0x3f);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 5;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.textCommodity.CharacterCasing = CharacterCasing.Upper;
            this.textCommodity.Location = new Point(0x19d, 0x41);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0xa6, 20);
            this.textCommodity.TabIndex = 4;
            this.label28.AutoSize = true;
            this.label28.Cursor = Cursors.Arrow;
            this.label28.Location = new Point(0x163, 0x44);
            this.label28.Name = "label28";
            this.label28.Size = new Size(0x3a, 13);
            this.label28.TabIndex = 0x25;
            this.label28.Text = "Commodity";
            this.buttonDO.Location = new Point(0x246, 0x24);
            this.buttonDO.Margin = new Padding(0);
            this.buttonDO.Name = "buttonDO";
            this.buttonDO.Size = new Size(0x17, 0x17);
            this.buttonDO.TabIndex = 3;
            this.buttonDO.Text = "...";
            this.buttonDO.UseVisualStyleBackColor = true;
            this.buttonDO.Click += new EventHandler(this.buttonDO_Click);
            this.textDO.Location = new Point(0x19d, 0x26);
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0xa6, 20);
            this.textDO.TabIndex = 2;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x176, 0x29);
            this.label1.Name = "label1";
            this.label1.Size = new Size(40, 13);
            this.label1.TabIndex = 0x27;
            this.label1.Text = "DO No";
            this.panel1.BackColor = SystemColors.ButtonFace;
            this.panel1.Controls.Add(this.chkDate);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.dtFrom);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.textContainer);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.textPI_No);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textRelation);
            this.panel1.Controls.Add(this.buttonRelation);
            this.panel1.Controls.Add(this.textRefNo);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textDO);
            this.panel1.Controls.Add(this.buttonDO);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.textCommodity);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.buttonComm);
            this.panel1.Controls.Add(this.menuStrip1);
            this.panel1.Dock = DockStyle.Top;
            this.panel1.Location = new Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x3c4, 0x9d);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new PaintEventHandler(this.panel1_Paint);
            this.chkDate.AutoSize = true;
            this.chkDate.Location = new Point(0xe3, 0x7c);
            this.chkDate.Name = "chkDate";
            this.chkDate.Size = new Size(15, 14);
            this.chkDate.TabIndex = 0x3b;
            this.chkDate.UseVisualStyleBackColor = true;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x16, 0x7d);
            this.label6.Name = "label6";
            this.label6.Size = new Size(30, 13);
            this.label6.TabIndex = 0x3a;
            this.label6.Text = "From";
            this.dtFrom.Location = new Point(0x37, 0x77);
            this.dtFrom.Name = "dtFrom";
            this.dtFrom.Size = new Size(0xa6, 20);
            this.dtFrom.TabIndex = 0x39;
            this.button4.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button4.Location = new Point(0xf8, 0x55);
            this.button4.Name = "button4";
            this.button4.Size = new Size(0x67, 0x36);
            this.button4.TabIndex = 0x38;
            this.button4.Text = "Find Container";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new EventHandler(this.button4_Click_1);
            this.textContainer.Location = new Point(0x37, 0x5d);
            this.textContainer.Name = "textContainer";
            this.textContainer.Size = new Size(0xa6, 20);
            this.textContainer.TabIndex = 0x36;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(3, 0x60);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x34, 13);
            this.label5.TabIndex = 0x37;
            this.label5.Text = "Container";
            this.textPI_No.Location = new Point(0x37, 0x41);
            this.textPI_No.Name = "textPI_No";
            this.textPI_No.Size = new Size(0xa6, 20);
            this.textPI_No.TabIndex = 1;
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x16, 0x44);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x22, 13);
            this.label4.TabIndex = 0x33;
            this.label4.Text = "PI No";
            this.button2.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x36d, 0x44);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x2e);
            this.button2.TabIndex = 10;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x282, 0x4b);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x69, 0x26);
            this.button1.TabIndex = 9;
            this.button1.Text = "Show All";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button3.Location = new Point(0x282, 0x21);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x69, 0x24);
            this.button3.TabIndex = 8;
            this.button3.Text = "Filter";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.label3.AutoSize = true;
            this.label3.Cursor = Cursors.Arrow;
            this.label3.Location = new Point(0x16f, 0x5e);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x2e, 13);
            this.label3.TabIndex = 0x2e;
            this.label3.Text = "Relation";
            this.textRelation.CharacterCasing = CharacterCasing.Upper;
            this.textRelation.Location = new Point(0x19d, 0x5b);
            this.textRelation.Name = "textRelation";
            this.textRelation.Size = new Size(0xa6, 20);
            this.textRelation.TabIndex = 6;
            this.buttonRelation.Location = new Point(0x246, 0x59);
            this.buttonRelation.Margin = new Padding(0);
            this.buttonRelation.Name = "buttonRelation";
            this.buttonRelation.Size = new Size(0x17, 0x17);
            this.buttonRelation.TabIndex = 7;
            this.buttonRelation.Text = "...";
            this.buttonRelation.UseVisualStyleBackColor = true;
            this.buttonRelation.Click += new EventHandler(this.buttonRelation_Click);
            this.textRefNo.Location = new Point(0x37, 0x27);
            this.textRefNo.Name = "textRefNo";
            this.textRefNo.Size = new Size(0xa6, 20);
            this.textRefNo.TabIndex = 0;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(12, 0x2a);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x2c, 13);
            this.label2.TabIndex = 0x2a;
            this.label2.Text = "Ref. No";
            this.menuStrip1.BackColor = Color.FromArgb(0xc0, 0xc0, 0xff);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.exportToExcelToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x3c4, 0x18);
            this.menuStrip1.TabIndex = 0x35;
            this.menuStrip1.Text = "menuStrip1";
            this.exportToExcelToolStripMenuItem.Name = "exportToExcelToolStripMenuItem";
            this.exportToExcelToolStripMenuItem.Size = new Size(0x5f, 20);
            this.exportToExcelToolStripMenuItem.Text = "Export to Excel";
            this.exportToExcelToolStripMenuItem.Click += new EventHandler(this.exportToExcelToolStripMenuItem_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.Anchor = AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0xbc);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x232, 290);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.SelectionChanged += new EventHandler(this.dataGridView1_SelectionChanged);
            this.panel2.BackColor = Color.LightSteelBlue;
            this.panel2.Controls.Add(this.labelRecords);
            this.panel2.Controls.Add(this.TextFind);
            this.panel2.Controls.Add(this.buttonFind);
            this.panel2.Dock = DockStyle.Bottom;
            this.panel2.Location = new Point(0, 0x1de);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x3c4, 0x21);
            this.panel2.TabIndex = 1;
            this.labelRecords.AutoSize = true;
            this.labelRecords.Cursor = Cursors.Arrow;
            this.labelRecords.Dock = DockStyle.Right;
            this.labelRecords.Location = new Point(0x371, 0);
            this.labelRecords.Name = "labelRecords";
            this.labelRecords.Size = new Size(0x53, 13);
            this.labelRecords.TabIndex = 0x34;
            this.labelRecords.Text = "Records Shown";
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.buttonFind.Location = new Point(0xc3, 5);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.label7.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.label7.AutoSize = true;
            this.label7.BackColor = Color.FromArgb(0x80, 0x80, 0xff);
            this.label7.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label7.ForeColor = Color.White;
            this.label7.Location = new Point(0x7e, 160);
            this.label7.Margin = new Padding(0);
            this.label7.Name = "label7";
            this.label7.RightToLeft = RightToLeft.Yes;
            this.label7.Size = new Size(0xea, 0x19);
            this.label7.TabIndex = 3;
            this.label7.Text = "TRANSACTION TABLE";
            this.label7.TextAlign = ContentAlignment.TopCenter;
            this.label8.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            this.label8.AutoSize = true;
            this.label8.BackColor = Color.FromArgb(0x80, 0x80, 0xff);
            this.label8.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label8.ForeColor = Color.White;
            this.label8.Location = new Point(0x291, 160);
            this.label8.Margin = new Padding(0);
            this.label8.Name = "label8";
            this.label8.RightToLeft = RightToLeft.Yes;
            this.label8.Size = new Size(0xcf, 0x19);
            this.label8.TabIndex = 4;
            this.label8.Text = "CONTAINER TABLE";
            this.label8.TextAlign = ContentAlignment.TopCenter;
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.Anchor = AnchorStyles.Right | AnchorStyles.Bottom | AnchorStyles.Top;
            this.dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView2.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
            style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = style;
            this.dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new Point(0x238, 0xbc);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.SelectionMode = DataGridViewSelectionMode.CellSelect;
            this.dataGridView2.Size = new Size(0x189, 290);
            this.dataGridView2.TabIndex = 2;
            this.dataGridView2.CellClick += new DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            this.dataGridView2.SelectionChanged += new EventHandler(this.dataGridView2_SelectionChanged_1);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.FromArgb(0x80, 0x80, 0xff);
            base.ClientSize = new Size(0x3c4, 0x1ff);
            base.ControlBox = false;
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.dataGridView2);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.panel1);
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "FormTransDO_View";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "View DO Transaction";
            base.Load += new EventHandler(this.FormTransDO_View_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransDO_View_KeyPress);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((ISupportInitialize) this.dataGridView2).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void OpenTable()
        {
            string str = "*";
            this.fDate = Program.DTOC(this.dtFrom.Value);
            string str2 = WBData.CompanyLocation("");
            if (this.textRefNo.Text != "")
            {
                str2 = str2 + " and Ref like '%" + this.textRefNo.Text + "%'";
            }
            if (this.textDO.Text != "")
            {
                str2 = str2 + " and DO_No like '%" + this.textDO.Text + "%'";
            }
            if (this.textCommodity.Text != "")
            {
                str2 = str2 + " and Comm_Code like '%" + this.textCommodity.Text + "%'";
            }
            if (this.textPI_No.Text != "")
            {
                str2 = str2 + " and Relation_Code like '%" + this.textPI_No.Text + "%'";
            }
            if (this.textRelation.Text != "")
            {
                str2 = str2 + " and Relation_Code like '%" + this.textRelation.Text + "%'";
            }
            if (this.chkDate.Checked)
            {
                str2 = str2 + " and date1 >= '" + this.fDate + "'";
            }
            if (this.doviewFirsttime && (((this.textRefNo.Text == "") && ((this.textDO.Text == "") && ((this.textCommodity.Text == "") && (this.textPI_No.Text == "")))) && (this.textRelation.Text == "")))
            {
                this.ztable.OpenTable("wb_transDO", "SELECT " + str + " FROM wb_transDO where 1=2", WBData.conn);
                this.labelRecords.Text = "";
            }
            else
            {
                this.ztable.OpenTable("wb_transDO", "SELECT " + str + " FROM wb_transDO where " + str2, WBData.conn);
                if (this.ztable.DT.Rows.Count == 0)
                {
                    MessageBox.Show(" No records found . .  ! ");
                }
                this.labelRecords.Text = $"{this.ztable.DT.Rows.Count:N0}";
                this.doviewFirsttime = false;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }
    }
}

