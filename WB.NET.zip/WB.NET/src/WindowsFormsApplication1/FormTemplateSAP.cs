﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTemplateSAP : Form
    {
        private WBTable tbl_templateSAP = new WBTable();
        public int nCurrRow;
        public DataRow ReturnRow;
        private string sqlText;
        private string changeReason = "";
        private string logKey = "";
        private IContainer components = null;
        private NumericUpDown numericBoxType;
        private Label label9;
        private Label label8;
        private ComboBox comboBoxModuleName;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem aDDToolStripMenuItem;
        private ToolStripMenuItem eDITToolStripMenuItem;
        private ToolStripMenuItem dELETEToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private DataGridView dataGridView1;
        private ToolStripMenuItem changeFieldToolStripMenuItem;
        private Panel panel2;

        public FormTemplateSAP()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void activitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void aDDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.tbl_templateSAP.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormTemplateSAPEntry entry = new FormTemplateSAPEntry {
                    pmode = "ADD",
                    comboBoxModuleName = { Text = this.comboBoxModuleName.Text },
                    numericType = { Value = this.numericBoxType.Value }
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.tbl_templateSAP.ReOpen();
                    this.dataGridView1 = this.tbl_templateSAP.AfterEdit("ADD");
                }
                entry.Dispose();
                this.tbl_templateSAP.UnLock();
                if (this.dataGridView1.RowCount > 0)
                {
                    this.eDITToolStripMenuItem.Enabled = true;
                    this.dELETEToolStripMenuItem.Enabled = true;
                    this.changeFieldToolStripMenuItem.Enabled = true;
                }
            }
        }

        private void changeFieldToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTemplateSAPPosition position = new FormTemplateSAPPosition {
                comboBoxModuleName = { Text = this.comboBoxModuleName.Text },
                numericBoxType = { Value = this.numericBoxType.Value }
            };
            position.ShowDialog();
            this.tbl_templateSAP.ReOpen();
            this.dataGridView1.DataSource = this.tbl_templateSAP.DV;
            position.Dispose();
        }

        private void comboBoxModuleName_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void comboBoxModuleName_TextChanged(object sender, EventArgs e)
        {
            this.isiDataGrid();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.tbl_templateSAP.BeforeEdit(this.dataGridView1, "DELETE"))
            {
                this.nCurrRow = this.tbl_templateSAP.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                string[] textArray1 = new string[] { this.tbl_templateSAP.DT.Rows[this.nCurrRow]["Modul"].ToString(), " - ", this.tbl_templateSAP.DT.Rows[this.nCurrRow]["Title_excel"].ToString(), ".\n\n", Resource.Mes_250 };
                if (MessageBox.Show(string.Concat(textArray1), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    FormTransCancel cancel = new FormTransCancel {
                        label1 = { Text = Resource.Lbl_Module },
                        textRefNo = { Text = this.tbl_templateSAP.DT.Rows[this.nCurrRow]["Modul"].ToString() },
                        Text = Resource.Form_Delete_Reason,
                        label2 = { Text = Resource.Lbl_Delete_Reason }
                    };
                    cancel.textReason.Focus();
                    cancel.ShowDialog();
                    if (cancel.Saved)
                    {
                        this.changeReason = cancel.textReason.Text;
                        cancel.Dispose();
                        this.tbl_templateSAP.ReOpen();
                        this.logKey = this.tbl_templateSAP.DT.Rows[this.nCurrRow]["uniq"].ToString();
                        this.tbl_templateSAP.DT.Rows[this.nCurrRow].Delete();
                        this.tbl_templateSAP.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_templateSAP", this.logKey, logField, logValue);
                        this.tbl_templateSAP.ReOpen();
                        this.tbl_templateSAP.AfterEdit("DELETE");
                    }
                    else
                    {
                        return;
                    }
                }
                this.tbl_templateSAP.UnLock();
                if (this.dataGridView1.RowCount == 0)
                {
                    this.eDITToolStripMenuItem.Enabled = false;
                    this.dELETEToolStripMenuItem.Enabled = false;
                    this.changeFieldToolStripMenuItem.Enabled = false;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void eDITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.tbl_templateSAP.GetRecNo(aField, aFind);
            this.ReturnRow = this.tbl_templateSAP.DT.Rows[this.nCurrRow];
            if (!this.tbl_templateSAP.BeforeEdit(this.dataGridView1, "EDIT"))
            {
            }
            FormTemplateSAPEntry entry = new FormTemplateSAPEntry(this.ReturnRow) {
                pmode = "EDIT"
            };
            entry.ShowDialog();
            if (entry.saved)
            {
                this.tbl_templateSAP.ReOpen();
                this.dataGridView1 = this.tbl_templateSAP.AfterEdit("EDIT");
                this.dataGridView1.Rows[this.nCurrRow].Selected = true;
            }
            entry.Dispose();
            this.tbl_templateSAP.UnLock();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.tbl_templateSAP.Dispose();
            base.Close();
        }

        private void FormTemplateSAP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.exitToolStripMenuItem.PerformClick();
            }
        }

        private void FormTemplateSAP_Load(object sender, EventArgs e)
        {
            this.numericBoxType.Value = 1M;
            this.isiDataGrid();
            if (!WBUser.CheckTrustee("MD_TEMPLATE", "A"))
            {
                this.aDDToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_TEMPLATE", "E"))
            {
                this.eDITToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_TEMPLATE", "D"))
            {
                this.dELETEToolStripMenuItem.Enabled = false;
            }
            WBTable table = new WBTable();
            table.OpenTable("wb_sapDest", "Select * from wb_SapDest where " + WBData.CompanyLocation(""), WBData.conn);
            this.comboBoxModuleName.Items.Clear();
            foreach (DataRow row in table.DT.Rows)
            {
                this.comboBoxModuleName.Items.Add(row["SAPDest"].ToString());
            }
            this.comboBoxModuleName.SelectedIndex = 0;
            if (this.dataGridView1.RowCount == 0)
            {
                this.eDITToolStripMenuItem.Enabled = false;
                this.dELETEToolStripMenuItem.Enabled = false;
                this.changeFieldToolStripMenuItem.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.numericBoxType = new NumericUpDown();
            this.label9 = new Label();
            this.label8 = new Label();
            this.comboBoxModuleName = new ComboBox();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.aDDToolStripMenuItem = new ToolStripMenuItem();
            this.eDITToolStripMenuItem = new ToolStripMenuItem();
            this.dELETEToolStripMenuItem = new ToolStripMenuItem();
            this.changeFieldToolStripMenuItem = new ToolStripMenuItem();
            this.exitToolStripMenuItem = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.panel2 = new Panel();
            this.numericBoxType.BeginInit();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.panel2.SuspendLayout();
            base.SuspendLayout();
            this.numericBoxType.Location = new Point(0xa2, 0x1d);
            this.numericBoxType.Name = "numericBoxType";
            this.numericBoxType.Size = new Size(0x37, 20);
            this.numericBoxType.TabIndex = 12;
            int[] bits = new int[4];
            bits[0] = 1;
            this.numericBoxType.Value = new decimal(bits);
            this.numericBoxType.ValueChanged += new EventHandler(this.numericUpDown1_ValueChanged);
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x9f, 10);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x1f, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Type";
            this.label9.Click += new EventHandler(this.label9_Click);
            this.label8.AutoSize = true;
            this.label8.Location = new Point(20, 10);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x2a, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Module";
            this.label8.Click += new EventHandler(this.label8_Click);
            this.comboBoxModuleName.FormattingEnabled = true;
            object[] items = new object[] { "MM", "SD", "ZWB", "ZPOM", "GAIN", "ZDO" };
            this.comboBoxModuleName.Items.AddRange(items);
            this.comboBoxModuleName.Location = new Point(0x17, 0x1c);
            this.comboBoxModuleName.Name = "comboBoxModuleName";
            this.comboBoxModuleName.Size = new Size(0x79, 0x15);
            this.comboBoxModuleName.TabIndex = 9;
            this.comboBoxModuleName.SelectedIndexChanged += new EventHandler(this.comboBoxModuleName_SelectedIndexChanged);
            this.comboBoxModuleName.TextChanged += new EventHandler(this.comboBoxModuleName_TextChanged);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.exitToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x369, 0x18);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.aDDToolStripMenuItem, this.eDITToolStripMenuItem, this.dELETEToolStripMenuItem, this.changeFieldToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.activitiesToolStripMenuItem.Click += new EventHandler(this.activitiesToolStripMenuItem_Click);
            this.aDDToolStripMenuItem.Name = "aDDToolStripMenuItem";
            this.aDDToolStripMenuItem.Size = new Size(0xbd, 0x16);
            this.aDDToolStripMenuItem.Text = "Add Record";
            this.aDDToolStripMenuItem.Click += new EventHandler(this.aDDToolStripMenuItem_Click);
            this.eDITToolStripMenuItem.Name = "eDITToolStripMenuItem";
            this.eDITToolStripMenuItem.Size = new Size(0xbd, 0x16);
            this.eDITToolStripMenuItem.Text = "Edit Record";
            this.eDITToolStripMenuItem.Click += new EventHandler(this.eDITToolStripMenuItem_Click);
            this.dELETEToolStripMenuItem.Name = "dELETEToolStripMenuItem";
            this.dELETEToolStripMenuItem.Size = new Size(0xbd, 0x16);
            this.dELETEToolStripMenuItem.Text = "Delete Record";
            this.dELETEToolStripMenuItem.Click += new EventHandler(this.dELETEToolStripMenuItem_Click);
            this.changeFieldToolStripMenuItem.Name = "changeFieldToolStripMenuItem";
            this.changeFieldToolStripMenuItem.Size = new Size(0xbd, 0x16);
            this.changeFieldToolStripMenuItem.Text = "Change Field Position";
            this.changeFieldToolStripMenuItem.Click += new EventHandler(this.changeFieldToolStripMenuItem_Click);
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new Size(0x25, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new EventHandler(this.exitToolStripMenuItem_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = style;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = style2;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x55);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = style3;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x369, 0x198);
            this.dataGridView1.TabIndex = 1;
            this.panel2.Controls.Add(this.numericBoxType);
            this.panel2.Controls.Add(this.comboBoxModuleName);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Dock = DockStyle.Top;
            this.panel2.Location = new Point(0, 0x18);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x369, 0x3d);
            this.panel2.TabIndex = 0x10;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x369, 0x1ed);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "FormTemplateSAP";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "List Of Template SAP";
            base.Load += new EventHandler(this.FormTemplateSAP_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTemplateSAP_KeyPress);
            this.numericBoxType.EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void isiDataGrid()
        {
            string[] textArray1 = new string[] { " and modul = '", this.comboBoxModuleName.Text.Trim().ToUpper(), "'  and type ='", this.numericBoxType.Value.ToString().Trim(), "' order by column_Numbering" };
            this.sqlText = "Select * from wb_templateSAP where " + WBData.CompanyLocation(string.Concat(textArray1));
            this.tbl_templateSAP.OpenTable("wb_templateSAP", this.sqlText, WBData.conn);
            this.dataGridView1.DataSource = this.tbl_templateSAP.DV;
        }

        private void label8_Click(object sender, EventArgs e)
        {
        }

        private void label9_Click(object sender, EventArgs e)
        {
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            this.isiDataGrid();
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.exitToolStripMenuItem.Text = Resource.Menu_Close;
            this.aDDToolStripMenuItem.Text = Resource.Menu_Add;
            this.eDITToolStripMenuItem.Text = Resource.Menu_Edit;
            this.dELETEToolStripMenuItem.Text = Resource.Menu_Delete;
            this.changeFieldToolStripMenuItem.Text = Resource.Mnu_Change_Position;
            this.label9.Text = Resource.Setting_057;
            this.label8.Text = Resource.Lbl_Module;
            this.Text = Resource.Title_Template_SAP;
        }
    }
}

