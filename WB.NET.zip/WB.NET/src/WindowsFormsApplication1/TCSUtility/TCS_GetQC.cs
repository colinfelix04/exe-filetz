﻿namespace WindowsFormsApplication1.TCSUtility
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using WindowsFormsApplication1;

    public class TCS_GetQC : Component
    {
        public static bool getChangedQC(string ref_no)
        {
            WBTable table = new WBTable();
            bool flag = false;
            table.OpenTable("wb_ChangeData", "SELECT * FROM wb_changeData WHERE ref = '" + ref_no + "' AND Type = 'QC'", TSC_DBIntegrator.conn);
            if (table.DT.Rows.Count > 0)
            {
                flag = true;
            }
            table.Dispose();
            return flag;
        }

        public static string getDeductedQC(string ref_no)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            WBTable table3 = new WBTable();
            string str = "N";
            table.OpenTable("wb_QCMapping", "SELECT * FROM wb_QCMapping WHERE mappingField IS NOT NULL AND mappingField != ''", TSC_DBIntegrator.conn);
            if (table.DT.Rows.Count > 0)
            {
                table2.OpenTable("VTC_QC", "SELECT * FROM VTC_QC WHERE regreff = '" + ref_no + "'", TSC_DBIntegrator.conn);
                if (table2.DT.Rows.Count > 0)
                {
                    table2.DR = table2.DT.Rows[0];
                    foreach (DataRow row in table.DT.Rows)
                    {
                        string[] textArray1 = new string[] { " AND ref = '", ref_no, "' AND QCode = '", row["QCode"].ToString(), "' AND deduct = 'Y'" };
                        table3.OpenTable("wb_transQC", "SELECT * FROM wb_transQC WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                        if (table3.DT.Rows.Count > 0)
                        {
                            str = "Y";
                            break;
                        }
                    }
                }
            }
            table.Dispose();
            table2.Dispose();
            table3.Dispose();
            return str;
        }

        public static bool getQC(string ref_no)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            WBTable table3 = new WBTable();
            bool flag = false;
            if (!hasQC(ref_no))
            {
                flag = true;
            }
            else
            {
                table.OpenTable("wb_QCMapping", "SELECT * FROM wb_QCMapping WHERE mappingField IS NOT NULL AND mappingField != ''", TSC_DBIntegrator.conn);
                if (table.DT.Rows.Count > 0)
                {
                    table2.OpenTable("VTC_QC", "SELECT * FROM VTC_QC WHERE regreff = '" + ref_no + "'", TSC_DBIntegrator.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        table2.DR = table2.DT.Rows[0];
                        string keyField = "";
                        foreach (DataRow row in table.DT.Rows)
                        {
                            string[] textArray1 = new string[] { " AND ref = '", ref_no, "' AND QCode = '", row["QCode"].ToString(), "'" };
                            table3.OpenTable("wb_transQC", "SELECT * FROM wb_transQC WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                            if (table3.DT.Rows.Count > 0)
                            {
                                table3.DR = table3.DT.Rows[0];
                                keyField = table3.DR["uniq"].ToString();
                                table3.DR.BeginEdit();
                                try
                                {
                                    table3.DR["Factory"] = (table2.DR[row["mappingField"].ToString()].ToString() == "") ? "" : $"{Program.StrToDouble(table2.DR[row["mappingField"].ToString()].ToString(), 3):N3}";
                                }
                                catch
                                {
                                    table3.DR["Factory"] = table2.DR[row["mappingField"].ToString()].ToString();
                                }
                                table3.DR.EndEdit();
                                table3.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "COPY", WBUser.UserID, "Copy QC value from TCS" };
                                Program.updateLogHeader("wb_transQC", keyField, logField, logValue);
                                flag = true;
                            }
                        }
                    }
                }
            }
            table.Dispose();
            table2.Dispose();
            table3.Dispose();
            return flag;
        }

        public static bool getQCStatus(string ref_no)
        {
            WBTable table = new WBTable();
            bool flag = false;
            if (!hasQC(ref_no))
            {
                flag = true;
            }
            else
            {
                table.OpenTable("VTC_QC", "SELECT QCStatus FROM VTC_QC WHERE regreff = '" + ref_no + "'", TSC_DBIntegrator.conn);
                if ((table.DT.Rows.Count > 0) && ((table.DT.Rows[0]["QCStatus"].ToString().ToUpper() == "OK") || (table.DT.Rows[0]["QCStatus"].ToString().ToUpper() == "RJ")))
                {
                    flag = true;
                }
            }
            table.Dispose();
            return flag;
        }

        public static bool hasQC(string ref_no)
        {
            bool flag = false;
            WBTable table = new WBTable();
            table.OpenTable("wb_transQC", "SELECT * FROM wb_transQC WHERE " + WBData.CompanyLocation(" AND ref = '" + ref_no + "'"), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                flag = true;
            }
            return flag;
        }

        public static string refreshQC(string ref_no)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            WBTable table3 = new WBTable();
            WBTable table4 = new WBTable();
            string str = "";
            if (!hasQC(ref_no))
            {
                str = "has no QC in WB.Net";
            }
            else
            {
                table.OpenTable("wb_QCMapping", "SELECT * FROM wb_QCMapping WHERE mappingField IS NOT NULL AND mappingField != ''", TSC_DBIntegrator.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    str = "can't be updated because QC hasn't been mapped yet";
                }
                else
                {
                    table4.OpenTable("wb_transaction", "SELECT split FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref = '" + ref_no + "'"), WBData.conn);
                    if (table4.DT.Rows[0]["split"].ToString() == "X")
                    {
                        table2.OpenTable("VTC_QC", "SELECT * FROM VTC_QC WHERE regreff = '" + ref_no.Substring(0, ref_no.Length - 1) + "'", TSC_DBIntegrator.conn);
                    }
                    else
                    {
                        table2.OpenTable("VTC_QC", "SELECT * FROM VTC_QC WHERE regreff = '" + ref_no + "'", TSC_DBIntegrator.conn);
                    }
                    if (table2.DT.Rows.Count <= 0)
                    {
                        str = "can't be updated because QC doesn't exist in TCS";
                    }
                    else
                    {
                        table2.DR = table2.DT.Rows[0];
                        string keyField = "";
                        bool flag5 = false;
                        foreach (DataRow row2 in table.DT.Rows)
                        {
                            bool flag6 = false;
                            string[] textArray1 = new string[] { " AND ref = '", ref_no, "' AND QCode = '", row2["QCode"].ToString(), "'" };
                            table3.OpenTable("wb_transQC", "SELECT * FROM wb_transQC WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                            if (table3.DT.Rows.Count > 0)
                            {
                                table3.DR = table3.DT.Rows[0];
                                keyField = table3.DR["uniq"].ToString();
                                table3.DR.BeginEdit();
                                try
                                {
                                    if (table2.DR[row2["mappingField"].ToString()].ToString() == "")
                                    {
                                        if (table3.DR["Factory"].ToString() != "")
                                        {
                                            table3.DR["Factory"] = "";
                                            flag5 = true;
                                            flag6 = true;
                                        }
                                    }
                                    else
                                    {
                                        string str3 = $"{Program.StrToDouble(table2.DR[row2["mappingField"].ToString()].ToString(), 3):N3}";
                                        if (table3.DR["Factory"].ToString() == "")
                                        {
                                            table3.DR["Factory"] = str3;
                                            flag5 = true;
                                            flag6 = true;
                                        }
                                        else if ($"{Program.StrToDouble(table3.DR["Factory"].ToString(), 3):N3}" != str3)
                                        {
                                            table3.DR["Factory"] = str3;
                                            flag5 = true;
                                            flag6 = true;
                                        }
                                    }
                                }
                                catch
                                {
                                    if (table3.DR["Factory"].ToString().Trim() != table2.DR[row2["mappingField"].ToString()].ToString().Trim())
                                    {
                                        table3.DR["Factory"] = table2.DR[row2["mappingField"].ToString()].ToString();
                                        flag5 = true;
                                        flag6 = true;
                                    }
                                }
                                table3.DR.EndEdit();
                                table3.Save();
                                if (flag6)
                                {
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Refresh QC value from TCS" };
                                    Program.updateLogHeader("wb_transQC", keyField, logField, logValue);
                                }
                            }
                        }
                        str = !flag5 ? "has no changes" : "has been updated";
                    }
                }
            }
            table.Dispose();
            table2.Dispose();
            table3.Dispose();
            table4.Dispose();
            return str;
        }
    }
}

