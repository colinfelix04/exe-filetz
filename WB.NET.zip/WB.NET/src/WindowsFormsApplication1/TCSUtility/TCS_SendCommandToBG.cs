﻿namespace WindowsFormsApplication1.TCSUtility
{
    using System;
    using System.ComponentModel;
    using WindowsFormsApplication1;

    public class TCS_SendCommandToBG : Component
    {
        public static bool sendCommand(string cardNo, string wbCode, string gatepassNo, string cmd)
        {
            try
            {
                WBTable table = new WBTable();
                table.OpenTable("TC_InstructionGate", "SELECT * FROM TC_InstructionGate WHERE 1 = 2", TSC_DBIntegrator.conn);
                table.DR = table.DT.NewRow();
                table.DR["wilpass"] = cardNo;
                table.DR["WBCode"] = wbCode;
                table.DR["WBRef"] = gatepassNo;
                table.DR["Cmds"] = cmd;
                table.DT.Rows.Add(table.DR);
                table.Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}

