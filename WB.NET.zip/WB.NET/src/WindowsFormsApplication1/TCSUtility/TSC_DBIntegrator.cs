﻿namespace WindowsFormsApplication1.TCSUtility
{
    using System;
    using System.ComponentModel;
    using System.Data.SqlClient;
    using WindowsFormsApplication1;

    public class TSC_DBIntegrator : Component
    {
        public static string sServer;
        public static string sDatabase = "DBIntegrator";
        public static string sUserID = WBData.sUserID;
        public static string sPassword = WBData.sPassword;
        public static string ConnStr;
        public static string sRegion;
        public static string sLanguage;
        public static string sCoyName;
        public static string sCoyCode;
        public static string sLocName;
        public static string sLocCode;
        public static string sWBCode;
        public static string sCheckDirect;
        public static bool connected = false;
        public static SqlConnection conn;

        public static void Close()
        {
            conn.Close();
        }

        public bool Open()
        {
            sServer = WBData.sServer;
            sDatabase = "DBIntegrator";
            sUserID = WBData.sUserID;
            sPassword = WBData.sPassword;
            string[] textArray1 = new string[9];
            textArray1[0] = "server=";
            textArray1[1] = sServer;
            textArray1[2] = "; database=";
            textArray1[3] = sDatabase;
            textArray1[4] = "; uid=";
            textArray1[5] = sUserID;
            textArray1[6] = "; password=";
            textArray1[7] = sPassword;
            textArray1[8] = ";MultipleActiveResultSets=true;";
            ConnStr = string.Concat(textArray1);
            try
            {
                conn = new SqlConnection(ConnStr);
                conn.Open();
                connected = true;
                return true;
            }
            catch (Exception)
            {
                connected = false;
                return false;
            }
        }

        public bool TestConnect()
        {
            string[] textArray1 = new string[9];
            textArray1[0] = "server=";
            textArray1[1] = sServer;
            textArray1[2] = "; database=";
            textArray1[3] = sDatabase;
            textArray1[4] = "; uid=";
            textArray1[5] = sUserID;
            textArray1[6] = "; password=";
            textArray1[7] = sPassword;
            textArray1[8] = ";";
            ConnStr = string.Concat(textArray1);
            try
            {
                conn = new SqlConnection(ConnStr);
                conn.Open();
                connected = true;
                return true;
            }
            catch (Exception)
            {
                connected = false;
                return false;
            }
        }
    }
}

