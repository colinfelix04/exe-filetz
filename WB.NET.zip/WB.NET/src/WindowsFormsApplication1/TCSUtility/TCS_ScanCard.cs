﻿namespace WindowsFormsApplication1.TCSUtility
{
    using System;
    using System.ComponentModel;
    using WindowsFormsApplication1;

    public class TCS_ScanCard : Component
    {
        private WBTable tblCard = new WBTable();
        public string resultMessage = "";

        public static string getCardNo(string cardReg)
        {
            string str = "";
            WBTable table = new WBTable();
            table.OpenTable("VTC_WILPASS", "Select * from vTC_wilpass where RegNo = '" + cardReg + "'", TSC_DBIntegrator.conn);
            if (table.DT.Rows.Count > 0)
            {
                str = table.DT.Rows[0]["CardNo"].ToString();
            }
            table.Dispose();
            return str;
        }

        public static string getCardRegNo(string uniqCard)
        {
            string str = "";
            WBTable table = new WBTable();
            table.OpenTable("VTC_WILPASS", "Select * from vTC_wilpass where CardNo = '" + uniqCard + "'", TSC_DBIntegrator.conn);
            if (table.DT.Rows.Count > 0)
            {
                str = table.DT.Rows[0]["RegNo"].ToString();
            }
            table.Dispose();
            return str;
        }

        public static Tuple<bool, string, string, string, string, string, string> scanCard(string inputNo, string mode, string gatepass)
        {
            string str = "";
            string str2 = "";
            string str3 = "";
            string str4 = "";
            string str5 = "";
            string str6 = "";
            bool flag = false;
            WBTable table = new WBTable();
            str6 = inputNo;
            string[] textArray1 = new string[] { "Select * from vTC_wilpass where CardNo = '", inputNo, "' or regNo = '", inputNo, "'" };
            table.OpenTable("VTC_WILPASS", string.Concat(textArray1), TSC_DBIntegrator.conn);
            if (table.DT.Rows.Count <= 0)
            {
                str = Resource.TCS_Scan005;
            }
            else
            {
                str6 = table.DT.Rows[0]["RegNo"].ToString();
                if (table.DT.Rows[0]["flag"].ToString() != "T")
                {
                    str = Resource.TCS_Scan004;
                }
                else if (table.DT.Rows[0]["stat"].ToString() == "I")
                {
                    if (mode != "ADD")
                    {
                        str = Resource.TCS_Scan003;
                    }
                    else
                    {
                        WBTable table2 = new WBTable();
                        string[] textArray2 = new string[] { " AND (Card_No = '", inputNo, "' OR Card_No = '", getCardNo(inputNo), "')  AND gatepass_number != '", gatepass, "' and (submit_gatepass <> 'Y' or submit_gatepass is null or submit_gatepass= 'N') and (Deleted IS NULL OR Deleted = 'N' or Deleted = '')" };
                        table2.OpenTable("wb_gatepass", "Select * from wb_gatepass where " + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
                        if (table2.DT.Rows.Count > 0)
                        {
                            str = Resource.TCS_Scan001;
                        }
                        else
                        {
                            flag = true;
                        }
                    }
                }
                else if (table.DT.Rows[0]["stat"].ToString() != "A")
                {
                    str = Resource.TCS_Scan003;
                }
                else if (mode == "EDIT")
                {
                    WBTable table3 = new WBTable();
                    string[] textArray3 = new string[] { " AND (Card_No = '", inputNo, "' OR Card_No = '", getCardNo(inputNo), "')  AND gatepass_number != '", gatepass, "' and (submit_gatepass <> 'Y' or submit_gatepass is null or submit_gatepass='N') and (Deleted IS NULL OR Deleted = 'N' or Deleted = '')" };
                    table3.OpenTable("wb_gatepass", "Select * from wb_gatepass where " + WBData.CompanyLocation(string.Concat(textArray3)), WBData.conn);
                    if (table3.DT.Rows.Count > 0)
                    {
                        str = Resource.TCS_Scan001;
                    }
                    else
                    {
                        flag = true;
                    }
                }
                else if ((mode != "Timbang") && (mode != "SUBMIT"))
                {
                    if (mode == "ADD")
                    {
                        str = Resource.TCS_Scan003;
                    }
                }
                else
                {
                    WBTable table4 = new WBTable();
                    string[] textArray4 = new string[] { " AND (Card_No = '", inputNo, "' OR Card_No = '", getCardNo(inputNo), "')  AND (submit_gatepass != 'Y' OR submit_gatepass IS NULL or submit_gatepass = 'N') and (Deleted IS NULL OR Deleted = 'N' or Deleted = '')" };
                    table4.OpenTable("wb_gatepass", "Select * from wb_gatepass where " + WBData.CompanyLocation(string.Concat(textArray4)), WBData.conn);
                    if (table4.DT.Rows.Count <= 0)
                    {
                        str = Resource.TCS_Scan002;
                    }
                    else
                    {
                        str2 = table4.DT.Rows[0]["gatepass_number"].ToString();
                        str3 = table4.DT.Rows[0]["Ref"].ToString();
                        str4 = table4.DT.Rows[0]["WX"].ToString();
                        str5 = table4.DT.Rows[0]["uniq"].ToString();
                        flag = true;
                    }
                }
            }
            table.Dispose();
            return new Tuple<bool, string, string, string, string, string, string>(flag, str, str3, str2, str4, str5, str6);
        }
    }
}

