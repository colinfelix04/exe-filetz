﻿namespace WindowsFormsApplication1.TCSUtility
{
    using System;
    using System.ComponentModel;
    using System.Data.SqlClient;
    using WindowsFormsApplication1;

    internal class TCS_WILUPDCARD : Component
    {
        public bool updateStat_RegIn(string regNo)
        {
            string[] textArray1 = new string[] { "server=", WBData.sServer, "; database=master; uid=", WBData.sUserID, "; password=", WBData.sPassword, ";" };
            SqlConnection connection = new SqlConnection(string.Concat(textArray1));
            SqlCommand command = connection.CreateCommand();
            connection.Open();
            command.CommandText = "UPDATE WILPAS.WILPASDATA.dbo.FRFID set Stat = 'A' where regNo = '" + regNo + "'";
            try
            {
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool updateStat_RegOut(string regNo)
        {
            string[] textArray1 = new string[] { "server=", WBData.sServer, "; database=master; uid=", WBData.sUserID, "; password=", WBData.sPassword, ";" };
            SqlConnection connection = new SqlConnection(string.Concat(textArray1));
            SqlCommand command = connection.CreateCommand();
            connection.Open();
            command.CommandText = "UPDATE WILPAS.WILPASDATA.dbo.FRFID set Stat = 'F' where regNo = '" + regNo + "'";
            try
            {
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}

