﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormSAPDestination : Form
    {
        private int idxFind = 0;
        private int nCurrRow;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        public string upload = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private MenuStrip menuStrip1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem closeToolStripMenuItem;
        private DataGridView dgvSAPDest;
        private ToolStripMenuItem viewRecordToolStripMenuItem;

        public FormSAPDestination()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dgvSAPDest, "ADD"))
            {
                FormSAPDestinationEntry entry = new FormSAPDestinationEntry {
                    pMode = "ADD",
                    Text = WBSetting.integrationIDSYS ? Resource.Title_Add_SAP_Destination_IDSYS : Resource.Title_Add_SAP_Destination,
                    zTable = this.ztable
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dgvSAPDest = this.ztable.AfterEdit("ADD");
                    string[] aField = new string[] { "SAPDest" };
                    string[] aFind = new string[] { entry.textSAPDest.Text };
                    this.ztable.SetCursor(this.dgvSAPDest, this.ztable.GetCurrentRow(this.dgvSAPDest, aField, aFind));
                }
                this.ztable.UnLock();
                entry.Dispose();
                if (this.dgvSAPDest.RowCount > 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = true;
                    this.editRecordToolStripMenuItem.Enabled = true;
                    this.deleteToolStripMenuItem.Enabled = true;
                }
            }
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dgvSAPDest.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dgvSAPDest.Rows.Count > 0)
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_SAPDest", "SELECT uniq FROM wb_templateSAP WHERE " + WBData.CompanyLocation(" AND modul = '" + this.dgvSAPDest.CurrentRow.Cells["SAPDest"].Value.ToString() + "'"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    if (MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_Confirm_Delete_SAP_Destination_IDSYS : (Resource.Mes_Confirm_Delete_SAP_Destination + " : '" + this.dgvSAPDest.CurrentRow.Cells["SAPDest"].Value.ToString() + "'?"), Resource.Mes_Confirmation, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = this.upload + Resource.Menu_073 },
                            textRefNo = { Text = this.dgvSAPDest.CurrentRow.Cells["SAPDest"].Value.ToString() },
                            Text = Resource.Form_Delete_Reason,
                            label2 = { Text = Resource.Lbl_Delete_Reason }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                            if (this.ztable.BeforeEdit(this.dgvSAPDest, "DELETE"))
                            {
                                string[] aField = new string[] { "uniq" };
                                string[] aFind = new string[] { this.dgvSAPDest.CurrentRow.Cells["uniq"].Value.ToString() };
                                int recNo = this.ztable.GetRecNo(aField, aFind);
                                this.logKey = this.ztable.DT.Rows[recNo]["uniq"].ToString();
                                this.ztable.DT.Rows[recNo].Delete();
                                this.ztable.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                                Program.updateLogHeader("wb_SAPDest", this.logKey, logField, logValue);
                                this.ztable.AfterEdit("DELETE");
                            }
                            else
                            {
                                return;
                            }
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                else
                {
                    MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Title_Error_Delete_Used_SAP_Destination_IDSYS : Resource.Title_Error_Delete_Used_SAP_Destination, Resource.Mes_Error_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }
            }
            if (this.dgvSAPDest.RowCount == 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dgvSAPDest.Rows.Count > 0) && this.ztable.BeforeEdit(this.dgvSAPDest, "EDIT"))
            {
                FormSAPDestinationEntry entry = new FormSAPDestinationEntry {
                    pMode = "EDIT",
                    nCurrRow = this.ztable.GetPosRec(this.dgvSAPDest.CurrentRow.Cells["uniq"].Value.ToString()),
                    Text = WBSetting.integrationIDSYS ? Resource.Title_Edit_SAP_Destination_IDSYS : Resource.Title_Edit_SAP_Destination,
                    zTable = this.ztable
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dgvSAPDest = this.ztable.AfterEdit("EDIT");
                    string[] aField = new string[] { "SAPDest" };
                    string[] aFind = new string[] { entry.textSAPDest.Text };
                    this.ztable.SetCursor(this.dgvSAPDest, this.ztable.GetCurrentRow(this.dgvSAPDest, aField, aFind));
                }
                this.ztable.UnLock();
                entry.Dispose();
            }
        }

        private void FormSAPDestination_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormSAPDestination_Load(object sender, EventArgs e)
        {
            this.viewRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_SAP_DESTINATION", "V");
            this.addNewRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_SAP_DESTINATION", "A");
            this.editRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_SAP_DESTINATION", "E");
            this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_SAP_DESTINATION", "D");
            string sqltext = "SELECT * FROM wb_SAPDest WHERE " + WBData.CompanyLocation("");
            this.ztable.OpenTable("wb_SAPDest", sqltext, WBData.conn);
            this.dgvSAPDest.DataSource = this.ztable.DT;
            this.dgvSAPDest.Sort(this.dgvSAPDest.Columns["SAPDest"], ListSortDirection.Ascending);
            this.dgvSAPDest.Columns["Coy"].Visible = false;
            this.dgvSAPDest.Columns["Location_Code"].Visible = false;
            this.dgvSAPDest.Columns["Uniq"].Visible = false;
            this.dgvSAPDest.Columns["passwordExcel"].Visible = false;
            this.dgvSAPDest.Columns["Deleted"].Visible = false;
            this.dgvSAPDest.Columns["token"].Visible = false;
            this.dgvSAPDest.Columns["completed"].Visible = false;
            this.dgvSAPDest.Columns["SAPDest"].HeaderText = this.upload + Resource.Menu_073;
            this.dgvSAPDest.Columns["protectExcel"].HeaderText = Resource.Col_Protect_Excel;
            this.dgvSAPDest.Columns["automaticUpload"].HeaderText = Resource.Col_Automatic_Upload;
            this.dgvSAPDest.Columns["automaticTime"].HeaderText = Resource.Col_Automatic_Time;
            this.dgvSAPDest.Columns["automaticInterval"].HeaderText = Resource.Col_Automatic_Interval;
            this.dgvSAPDest.Columns["Create_By"].HeaderText = Resource.Gatepass_063;
            this.dgvSAPDest.Columns["Create_Date"].HeaderText = Resource.Gatepass_064;
            this.dgvSAPDest.Columns["Change_By"].HeaderText = Resource.Gatepass_065;
            this.dgvSAPDest.Columns["Change_Date"].HeaderText = Resource.Gatepass_066;
            this.dgvSAPDest.Columns["Delete_By"].HeaderText = Resource.Col_Delete_By;
            this.dgvSAPDest.Columns["Delete_Date"].HeaderText = Resource.Col_Delete_Date;
            if (this.dgvSAPDest.RowCount == 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
            }
            this.Text = "List of " + this.sapIDSYS + " Destination";
        }

        private void InitializeComponent()
        {
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.dgvSAPDest = new DataGridView();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dgvSAPDest).BeginInit();
            base.SuspendLayout();
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x29b, 0x18);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.viewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.dgvSAPDest.AllowUserToAddRows = false;
            this.dgvSAPDest.AllowUserToDeleteRows = false;
            this.dgvSAPDest.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSAPDest.Dock = DockStyle.Fill;
            this.dgvSAPDest.Location = new Point(0, 0x18);
            this.dgvSAPDest.MultiSelect = false;
            this.dgvSAPDest.Name = "dgvSAPDest";
            this.dgvSAPDest.ReadOnly = true;
            this.dgvSAPDest.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvSAPDest.Size = new Size(0x29b, 250);
            this.dgvSAPDest.TabIndex = 1;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x29b, 0x112);
            base.ControlBox = false;
            base.Controls.Add(this.dgvSAPDest);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "FormSAPDestination";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of SAP Destination";
            base.Load += new EventHandler(this.FormSAPDestination_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormSAPDestination_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dgvSAPDest).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.UserGroup_012;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.Text = WBSetting.integrationIDSYS ? Resource.Title_SAP_Destination_IDSYS : Resource.Title_SAP_Destination;
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dgvSAPDest.Rows.Count > 0) && this.ztable.BeforeEdit(this.dgvSAPDest, "ADD"))
            {
                FormSAPDestinationEntry entry = new FormSAPDestinationEntry {
                    pMode = "VIEW",
                    Text = WBSetting.integrationIDSYS ? Resource.Title_View_SAP_Destination_IDSYS : Resource.Title_View_SAP_Destination,
                    nCurrRow = this.ztable.GetPosRec(this.dgvSAPDest.CurrentRow.Cells["uniq"].Value.ToString()),
                    zTable = this.ztable
                };
                entry.ShowDialog();
                this.ztable.UnLock();
                entry.Dispose();
            }
        }
    }
}

