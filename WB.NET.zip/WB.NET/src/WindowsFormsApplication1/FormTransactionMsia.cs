﻿namespace WindowsFormsApplication1
{
    using BarrierGate.Utility;
    using CrystalDecisions.CrystalReports.Engine;
    using JR.Utils.GUI.Forms;
    using Microsoft.VisualBasic.PowerPacks;
    using SAP.Middleware.Connector;
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Diagnostics;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormTransactionMsia : Form
    {
        public WBTable tblTrans = new WBTable();
        public DataGridView dgvTrans;
        private WBTable tblTransDeduc = new WBTable();
        private WBTable tblTransDeducPorla = new WBTable();
        private WBTable tblTransBatch = new WBTable();
        private WBTable tblTransContainer = new WBTable();
        private WBTable tblTransCopra = new WBTable();
        private WBTable tblTransDiv = new WBTable();
        private WBTable tblDO = new WBTable();
        private WBTable tblTransDO = new WBTable();
        private WBTable tblTransQC = new WBTable();
        private WBTable tblTruck = new WBTable();
        private WBTable tblComm = new WBTable();
        private WBTable tblCommD = new WBTable();
        private WBTable tblContractDetail = new WBTable();
        private WBTable tblCust = new WBTable();
        private WBTable tblDriver = new WBTable();
        private WBTable tblTransporter = new WBTable();
        private WBTable tblEstate = new WBTable();
        private WBTable tblStorage = new WBTable();
        private WBTable tblGrading = new WBTable();
        private WBTable tblQC = new WBTable();
        private WBTable tblTanker = new WBTable();
        private WBTable tblTransType = new WBTable();
        private WBTable tblDOContainer = new WBTable();
        private WBTable tblLocation = new WBTable();
        private WBTable sh_return = new WBTable();
        private WBTable tblEmail = new WBTable();
        private WBTable tblTrans__ = new WBTable();
        private DataGridView dgvDOCont = new DataGridView();
        private WBTable tbl_warning_trace = new WBTable();
        private WBTable tbl_ffb_grade = new WBTable();
        public bool tambahRecord = false;
        public bool Saved = false;
        public bool hasChanged = false;
        public bool firstLoadTCS = true;
        public bool manualCopyfromMainForm = false;
        public string pMode = "";
        public string WX = "";
        public string sUniq = "";
        public int nCurrRow;
        public ReportDocument ticketRpt = new ReportDocument();
        public ReportDocument ticket2Rpt = new ReportDocument();
        public ReportDocument rpt_advise = new ReportDocument();
        public FormRpt fRpt;
        private IRfcTable ISReturn;
        private DataRow transBefore;
        private DataRow transDOBefore;
        private DataRow rowTransType;
        private DataTable tmpTrans;
        private DataTable tmp_transDO = new DataTable();
        private string editTrace = "";
        private string editDoTrace = "";
        private string spMode = "";
        private string jtdate = "";
        private string WXGatepass = "";
        private bool ref_return_valid = false;
        private string mChangeReason = "";
        private string comm_code = "";
        private string oldComm = "";
        private string[] approval = new string[4];
        private string transType;
        private string MSinTrx;
        private string sReq_Tanker;
        private string maxTare;
        private string minTare;
        private string approve;
        private string approve_type;
        private string approveBy1;
        private string approveBy2;
        private string sTransType;
        private string sIO;
        private string is_vessel;
        private string ApproveReason;
        private string completed = "Y";
        private bool ChangeDO;
        private bool ChangeDiv;
        private bool ChangeDeduc;
        private bool ChangeDeducPorla;
        private bool ChangeContainer;
        private bool ChangeQC;
        private bool ChangeDoCont;
        private bool CheckControl;
        private bool CheckQuantity;
        private bool needApproval;
        private bool ChangeBatch;
        private bool Copied = false;
        private bool lSTO1DO = false;
        private bool splitRef = false;
        private bool printTicket = false;
        private bool loadCopraForm = false;
        private string[] CloseDO;
        private int nRef;
        private int nKg;
        private double gross;
        private double tare;
        private double netto;
        private EventArgs e;
        private string[] hasil = new string[3];
        private DateTime rptdate;
        private string CommType = "";
        private string use_gunny = "";
        private string is_trade = "";
        private string is_bulk = "";
        private string check_tare_comm = "N";
        private double sGunnyNet = 0.0;
        private double sGunnyMin = 0.0;
        private double sGunnyMax = 0.0;
        private bool SJApproved = false;
        private bool SJAdopted = false;
        private bool OTApproved = false;
        private string msgApprove;
        private string SJToken = "";
        private FormTransCopraEntry fCopra;
        private WBIndicator wbIndicator = new WBIndicator();
        private bool weighDifferent = false;
        private DateTime timeReadIndicator;
        private int allowedSaveInSecond = 3;
        private double totaldeducUnitQty = 0.0;
        private double averageWeightDeducUnit = 0.0;
        private double totaldeducUnit = 0.0;
        private string unitName = "";
        private bool auto_generate_dummy_contract = false;
        private WBNFC nfcReader;
        public string gatepass_uniq = "";
        public string gatepass_no = "";
        public string register_by = "";
        public string card_no = "";
        private string indStableWarning = "0";
        private string transIndStableWarning = "0000";
        private string logDate1 = "";
        private string logTime1 = "";
        private string logRef = "";
        private string logReason = "";
        private string logMode = "";
        private string logKeyField = "";
        private bool returnGate;
        private IContainer components = null;
        private Label label1;
        private Label labTankerNo;
        private Label label3;
        private TextBox textTruck2;
        private Label labelDriverName;
        private Label labelTankerMax;
        private Label labelTransporterName;
        private Label label4;
        private Label label2;
        private TextBox textDN;
        private TextBox textUnloading;
        private Label label5;
        private TextBox textRemarkTicket;
        private Label label6;
        private TextBox textRemarkReport;
        private Label label7;
        private GroupBox groupOtherParty;
        private TextBox textNetEstate;
        private TextBox textTareEstate;
        private TextBox textGrossEstate;
        private Label label10;
        private Label label9;
        private Label label8;
        private GroupBox groupFactoryWeight;
        private TextBox textNET2;
        private TextBox text4th;
        private TextBox text3rd;
        private Label label14;
        private Label label15;
        private Label label16;
        private TextBox textNET1;
        private TextBox text2nd;
        private TextBox text1st;
        private Label label11;
        private Label label12;
        private Label label13;
        private TextBox textDeducTotal;
        private Label label17;
        private TextBox textNet;
        private Label label18;
        private TextBox textSEAL;
        private Label label19;
        private TabControl tabControl1;
        private TabPage tabPageInfo;
        private TabPage tabPageDO;
        private Button buttonSave;
        public Button buttonSavePrint;
        private Button buttonCancel;
        private Button buttonReset;
        private Button buttonReadIndicator;
        private TextBox textTime4th;
        private TextBox textDate4th;
        private TextBox textTime3rd;
        private TextBox textDate3rd;
        private TextBox textTime2nd;
        public TextBox textRefNo;
        private TabPage tabPageDeduc;
        private ComboBox comboTransType;
        private DateTimePicker dateRegister;
        private Label label26;
        private DateTimePicker dateDelivery;
        private Label label25;
        private TabPage tabPageDivision;
        private Panel panel1;
        private Button buttonEditDO;
        private Button buttonAddDO;
        private Button buttonTruck;
        private TextBox textTruck;
        private TextBox textDriverID;
        private Button buttonDriver;
        private Button buttonTranspt;
        private TextBox textTransporter;
        private Button buttonTanker;
        private TextBox textTanker;
        private MaskedTextBox TimeRegister;
        private MaskedTextBox TimeDelivery;
        private TextBox textBunchDeduc;
        private Label label30;
        private TextBox textBunchTotal;
        private Label label29;
        private Button buttonDeleteDeduc;
        private Button buttonEditDeduc;
        private Button buttonAddDeduc;
        private TextBox textAvg;
        private Label label31;
        private GroupBox groupBoxTotalBunchFFB;
        private TextBox textFruitsType;
        private Label label32;
        private DataGridView dgvDivBlock;
        private Panel panel3;
        private Button button15;
        private Button button16;
        private Button button17;
        private Panel panel4;
        private GroupBox groupBox3;
        private TextBox textGHG;
        private RadioButton radioGHG2;
        private RadioButton radioGHG1;
        private TextBox textISCC;
        private Label label38;
        private CheckBox checkISCC;
        private Label label39;
        private Button buttonEstate;
        private TextBox textEstate;
        private Label labelEstateName;
        private Label label40;
        private Label labelFruitsTypeName;
        private TextBox textRef_Date;
        private Label label35;
        private TextBox textReport_Date;
        private Label label37;
        private Button buttonStorage;
        private TextBox textStorage;
        private Label labelStorageName;
        private Label labelStorage;
        private TabPage tabPageQC;
        private DataGridView dgvQC;
        private Label labelComm;
        private Label labelCommName;
        private TextBox textCommodity;
        private Button buttonComm;
        private Label label33;
        private TextBox textCommType;
        private TextBox textTankQC;
        private Label label44;
        private Label label43;
        private TextBox textQControl;
        private Label label42;
        private DataGridView dgvQC_All;
        private TabPage tabPageCont;
        private DataGridView dgvCont;
        private Panel panel5;
        private Button buttonContDelete;
        private Button buttonContEdit;
        private Button buttonContAdd;
        private TextBox textVariance;
        private Label label45;
        private TextBox textTrailerNo;
        private Label label46;
        private TextBox textRendCPO;
        private Label label41;
        private Button buttonMergeDO;
        private ShapeContainer shapeContainer1;
        private RectangleShape kotakOS;
        private Label lblOSDO;
        private TextBox textDriverName;
        private TextBox textWBNo;
        private Label labelWBNo;
        private Label label49;
        private TextBox textReason;
        private Label labelReject;
        private TextBox textTBSReject;
        private Label label47;
        private TextBox textISCC2;
        private DataGridView dgvDeduc;
        private TextBox textDate1st;
        private TextBox textDate2nd;
        private TextBox textTime1st;
        private ShapeContainer shapeContainer2;
        private RectangleShape rectangleShape1;
        private DataGridView dgvDO;
        private Label labelRelation;
        private TextBox textCust;
        private Button buttonCust;
        private CheckBox checkNonContract;
        private Label labelCustName;
        private CheckBox checkEstate;
        private Panel panelMainInfo;
        private Panel panel4X;
        private Button buttonTarraHistory;
        private Label label21;
        private TabPage tabPagePorla;
        private Button buttonDeletePorla;
        private Button buttonEditPorla;
        private DataGridView dgvDeducPorla;
        private Button buttonAddPorla;
        private ShapeContainer shapeContainer3;
        private RectangleShape rectangleShape2;
        private Label label22;
        private Label label23;
        private TextBox textBoxKG;
        private ComboBox combodgvDO;
        private TabPage tabPageCopra;
        private Button buttonEntryCopra;
        private Label label24;
        private TextBox textTotalCopra;
        private Label label27;
        private TabPage tabPageDL;
        private TextBox textSTO;
        private GroupBox groupBox2;
        private TextBox textNettoBatchLeft;
        private Label label51;
        private Label label52;
        private TextBox textGunnyBatchLeft;
        private Label label53;
        private Button button20;
        private GroupBox groupBox1;
        private TextBox textNettoBatch;
        private Label label36;
        private Label label48;
        private TextBox textGunnyBatch;
        private Label label50;
        private Button button18;
        private Label label28;
        private DataGridView dgvBatch;
        private TextBox textBox1;
        private Label label55;
        private TextBox textDL;
        private Label label56;
        private Button buttonAdopt;
        private Label label60;
        private TextBox textBox3;
        private Label label58;
        private Button button19;
        private Label label20;
        public Button buttonDeleteDO;
        private Panel panelDeducTBS;
        private DataGridView dgvListDO;
        private Process process1;
        private CheckBox checkNOPW;
        private Label label54;
        private TextBox txtAddInfo;
        private Panel panel_return;
        private Button btn_check;
        private TextBox text_ref_return;
        private CheckBox chk_return;
        private Label labelMS;
        private ShapeContainer shapeContainer4;
        private ToolTip toolTip1;
        private TextBox txtMS;
        private Label label57;
        private RichTextBox textQualityInfo;
        public Button buttonEntryDeduc;
        private Button buttonScanCard;
        private RadioButton radioButtonEntryAVG;
        private RadioButton radioButtonEntryTotalBunch;
        private TextBox textGrade;
        private Label labelGrade;
        private TextBox textPL3;
        private Label label59;
        private DateTimePicker dateDelivery2;
        private MaskedTextBox TimeDelivery2;
        private Label label61;

        public FormTransactionMsia()
        {
            this.InitializeComponent();
        }

        private void _InitBlankGrading(string comm_code)
        {
            if ((this.tblTransDeduc.DT.Rows.Count <= 0) || this.Copied)
            {
                this.dgvDeduc.Rows.Clear();
                WBTable table = new WBTable();
                table.OpenTable("wb_commodity_grading", "select * from wb_commodity_grading where " + WBData.CompanyLocation(" AND comm_code = '" + comm_code + "'"), WBData.conn);
                this.dgvDeduc = table.ToDGV(this.dgvDeduc);
            }
        }

        private void _InitBlankGradingPorla(string comm_code)
        {
            if ((this.tblTransDeducPorla.DT.Rows.Count <= 0) || this.Copied)
            {
                this.dgvDeducPorla.Rows.Clear();
                WBTable table = new WBTable();
                table.OpenTable("wb_commodity_grading", "select * from wb_commodity_grading where " + WBData.CompanyLocation(" AND comm_code = '" + comm_code + "'"), WBData.conn);
                this.dgvDeducPorla = table.ToDGV(this.dgvDeducPorla);
            }
        }

        private void _InitBlankQC(string pDO_No)
        {
            this.dgvQC.Rows.Clear();
            this.dgvQC_All.Rows.Clear();
            int count = 0;
            this.tblCommD.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail where " + WBData.CompanyLocation(" and Comm_Code='" + this.dgvDO.Rows[0].Cells["Comm_Code"].Value.ToString().Trim() + "'"), WBData.conn);
            foreach (DataRow row in this.tblCommD.DT.Rows)
            {
                count = this.dgvQC_All.Rows.Count;
                this.dgvQC_All.Rows.Add();
                this.dgvQC_All.Rows[count].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvQC_All.Rows[count].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvQC_All.Rows[count].Cells["Ref"].Value = this.textRefNo.Text;
                this.dgvQC_All.Rows[count].Cells["DaRef"].Value = this.textRef_Date.Text;
                this.dgvQC_All.Rows[count].Cells["DO_No"].Value = this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString();
                this.dgvQC_All.Rows[count].Cells["QualityControl"].Value = " ";
                this.dgvQC_All.Rows[count].Cells["Tank"].Value = " ";
                this.dgvQC_All.Rows[count].Cells["Estate"].Value = "0";
                this.dgvQC_All.Rows[count].Cells["Factory"].Value = "";
                this.dgvQC_All.Rows[count].Cells["QCode"].Value = row["QCode"].ToString();
                this.dgvQC_All.Rows[count].Cells["QName"].Value = row["QName"].ToString();
                this.dgvQC_All.Rows[count].Cells["Comm_Code"].Value = this.dgvDO.Rows[0].Cells["Comm_Code"].Value;
                this.dgvQC_All.Rows[count].Cells["Relation_Code"].Value = this.dgvDO.Rows[0].Cells["Relation_Code"].Value;
                this.dgvQC_All.Rows[count].Cells["Estate_Code"].Value = this.dgvDO.Rows[0].Cells["Estate"].Value;
                string[] textArray1 = new string[9];
                textArray1[0] = "SELECT * FROM wb_contract_detail a, wb_yield b WHERE a.SAP_code = b.SAP_code AND b.Coy = '";
                textArray1[1] = WBData.sCoyCode;
                textArray1[2] = "' AND b.Location_Code = '";
                textArray1[3] = WBData.sLocCode;
                textArray1[4] = "' AND a.Do_No = '";
                textArray1[5] = this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString();
                textArray1[6] = "' AND b.Yield_Code = '";
                textArray1[7] = row["QCode"].ToString();
                textArray1[8] = "' ";
                string sqltext = string.Concat(textArray1);
                this.tblContractDetail.OpenTable("wb_contract_detail", sqltext, WBData.conn);
                bool flag = this.tblContractDetail.DT.Rows.Count > 0;
                this.dgvQC_All.Rows[count].Cells["SAP_Value"].Value = !flag ? "0" : this.tblContractDetail.DT.Rows[0]["SAP_Value"].ToString();
                this.dgvQC_All.Refresh();
            }
            this.dgvQC = this.DGV_Copy(this.dgvQC_All, this.dgvQC, this.dgvDO.Rows[0].Cells["Ref"].Value.ToString());
        }

        private void _InitQC(string pDO_No)
        {
            if (this.dgvDO.Rows.Count > 0)
            {
                if (this.dgvQC_All.Rows.Count == 0)
                {
                    this.tblTransQC.Close();
                    this.tblTransQC.OpenTable("wb_TransQC", "Select * from wb_TransQC where  Ref='" + this.textRefNo.Text.Trim() + "'", WBData.conn);
                    this.dgvQC_All = this.tblTransQC.ToDGV(this.dgvQC_All);
                }
                this.dgvQC = this.DGV_Copy(this.dgvQC_All, this.dgvQC, this.dgvDO.Rows[0].Cells["ref"].Value.ToString());
                int count = this.dgvQC.Rows.Count;
                if (count != 0)
                {
                    WBTable table = new WBTable();
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= this.dgvQC.Rows.Count)
                        {
                            table.Dispose();
                            break;
                        }
                        string[] textArray2 = new string[9];
                        textArray2[0] = "SELECT * FROM wb_contract_detail a, wb_yield b WHERE a.SAP_code = b.SAP_code AND b.Coy = '";
                        textArray2[1] = WBData.sCoyCode;
                        textArray2[2] = "' AND b.Location_Code = '";
                        textArray2[3] = WBData.sLocCode;
                        textArray2[4] = "' AND a.Do_No = '";
                        textArray2[5] = this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString();
                        textArray2[6] = "' AND b.Yield_Code = '";
                        textArray2[7] = this.dgvQC.Rows[num2].Cells["QCode"].Value.ToString();
                        textArray2[8] = "' ";
                        string sqltext = string.Concat(textArray2);
                        table.OpenTable("wb_contract_detail", sqltext, WBData.conn);
                        if (table.DT.Rows.Count <= 0)
                        {
                            this.dgvQC.Rows[num2].Cells["SAP_Value"].Value = "0";
                        }
                        else
                        {
                            if (this.dgvQC.Rows[num2].Cells["SAP_Value"].Value.ToString() != table.DT.Rows[0]["SAP_Value"].ToString())
                            {
                                this.dgvQC.Rows[num2].Cells["SAP_Value"].Value = table.DT.Rows[0]["SAP_Value"].ToString();
                            }
                            this.dgvQC.Refresh();
                        }
                        num2++;
                    }
                }
                else
                {
                    this.tblCommD.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail where " + WBData.CompanyLocation(" and Comm_Code='" + this.dgvDO.Rows[0].Cells["Comm_Code"].Value.ToString().Trim() + "'"), WBData.conn);
                    foreach (DataRow row in this.tblCommD.DT.Rows)
                    {
                        count = this.dgvQC_All.Rows.Count;
                        this.dgvQC_All.Rows.Add();
                        this.dgvQC_All.Rows[count].Cells["Coy"].Value = WBData.sCoyCode;
                        this.dgvQC_All.Rows[count].Cells["Location_Code"].Value = WBData.sLocCode;
                        this.dgvQC_All.Rows[count].Cells["Ref"].Value = this.textRefNo.Text;
                        this.dgvQC_All.Rows[count].Cells["DaRef"].Value = this.textRef_Date.Text;
                        this.dgvQC_All.Rows[count].Cells["DO_No"].Value = this.dgvDO.Rows[0].Cells["DO_No"].ToString();
                        this.dgvQC_All.Rows[count].Cells["QualityControl"].Value = " ";
                        this.dgvQC_All.Rows[count].Cells["Tank"].Value = " ";
                        this.dgvQC_All.Rows[count].Cells["QCode"].Value = row["QCode"].ToString();
                        this.dgvQC_All.Rows[count].Cells["QName"].Value = row["QName"].ToString();
                        this.dgvQC_All.Rows[count].Cells["Comm_Code"].Value = this.dgvDO.Rows[0].Cells["Comm_Code"].Value;
                        this.dgvQC_All.Rows[count].Cells["Relation_Code"].Value = this.dgvDO.Rows[0].Cells["Relation_Code"].Value;
                        this.dgvQC_All.Rows[count].Cells["Estate_Code"].Value = this.dgvDO.Rows[0].Cells["Estate"].Value;
                        string[] textArray1 = new string[9];
                        textArray1[0] = "SELECT * FROM wb_contract_detail a, wb_yield b WHERE a.SAP_code = b.SAP_code AND b.Coy = '";
                        textArray1[1] = WBData.sCoyCode;
                        textArray1[2] = "' AND b.Location_Code = '";
                        textArray1[3] = WBData.sLocCode;
                        textArray1[4] = "' AND a.Do_No = '";
                        textArray1[5] = this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString();
                        textArray1[6] = "' AND b.Yield_Code = '";
                        textArray1[7] = row["QCode"].ToString();
                        textArray1[8] = "' ";
                        string sqltext = string.Concat(textArray1);
                        this.tblContractDetail.OpenTable("wb_contract_detail", sqltext, WBData.conn);
                        bool flag4 = this.tblContractDetail.DT.Rows.Count > 0;
                        this.dgvQC_All.Rows[count].Cells["SAP_Value"].Value = !flag4 ? "0" : this.tblContractDetail.DT.Rows[0]["SAP_Value"].ToString();
                        this.dgvQC_All.Refresh();
                    }
                    this.dgvQC = this.DGV_Copy(this.dgvQC_All, this.dgvQC, this.dgvDO.Rows[0].Cells["Ref"].Value.ToString());
                }
            }
        }

        private void _QC_SaveTankQC()
        {
            for (int i = 0; i < this.dgvQC_All.Rows.Count; i++)
            {
                if ((this.dgvQC_All.Rows[i].Cells["Ref"].Value.ToString() == this.textRefNo.Text) && (this.dgvQC_All.Rows[i].Cells["DO_No"].Value.ToString() == this.combodgvDO.Text))
                {
                    this.dgvQC_All.Rows[i].Cells["QualityControl"].Value = this.textQControl.Text;
                    this.dgvQC_All.Rows[i].Cells["Tank"].Value = this.textTankQC.Text;
                }
                this.ChangeQC = true;
            }
        }

        private void BJR()
        {
            Cursor.Current = Cursors.WaitCursor;
            WBSetting.ReOpen();
            if (this.radioButtonEntryTotalBunch.Checked)
            {
                if ((this.textNET2.Text.Trim() == "0") || (this.textBunchTotal.Text.Trim() == "0"))
                {
                    this.textAvg.Text = "0";
                }
                else
                {
                    this.textAvg.Text = (Convert.ToDouble(this.textNET2.Text) / Convert.ToDouble(this.textBunchTotal.Text)).ToString();
                    this.textAvg.Text = Program.StrToDouble(this.textAvg.Text, 2).ToString();
                }
            }
            else if (this.radioButtonEntryAVG.Checked)
            {
                if ((this.textNET2.Text.Trim() != "0") && (this.textAvg.Text.Trim() != "0"))
                {
                    this.textBunchTotal.Text = (Convert.ToDouble(this.textNET2.Text) / Convert.ToDouble(this.textAvg.Text)).ToString();
                    this.textBunchTotal.Text = Program.StrToDouble(this.textBunchTotal.Text, 0).ToString();
                }
                else
                {
                    this.textBunchTotal.Text = "0";
                    this.textBunchDeduc.Text = "0";
                }
            }
            if (this.dgvDO.Rows.Count > 0)
            {
                string[] strArray = WBSetting.FruitsType(this.textAvg.Text, this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString());
                this.textFruitsType.Text = strArray[0];
                this.labelFruitsTypeName.Text = strArray[1];
                this.textFruitsType.Refresh();
                this.labelFruitsTypeName.Refresh();
                try
                {
                    if (((this.pMode == "1ST") || ((this.pMode == "2ND") || (this.pMode == "GRADING"))) ? !this.hasChanged : false)
                    {
                        string sqltext = "SELECT * FROM information_schema.tables WHERE table_name = 'wb_ffb_grade'";
                        this.tbl_ffb_grade.OpenTable("wb_ffb_grade", sqltext, WBData.conn);
                        if (this.tbl_ffb_grade.DT.Rows.Count > 0)
                        {
                            sqltext = "SELECT * FROM wb_ffb_grade WHERE " + WBData.CompanyLocation(" AND fruit_type = '" + this.textFruitsType.Text + "'");
                            this.tbl_ffb_grade.OpenTable("wb_ffb_grade", sqltext, WBData.conn);
                            if (this.tbl_ffb_grade.DT.Rows.Count > 0)
                            {
                                this.textGrade.Text = this.tbl_ffb_grade.DT.Rows[0]["ffb_grade"].ToString();
                                this.textGrade.Refresh();
                            }
                        }
                    }
                }
                catch
                {
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void btn_check_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            this.text_ref_return.Text = this.text_ref_return.Text.Trim();
            string[] textArray1 = new string[] { " AND returref = '", this.text_ref_return.Text, "' and ref <> '", this.textRefNo.Text.Trim(), "' and ( deleted <> 'Y' or deleted is null)" };
            table.OpenTable("wb_transDO", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                MessageBox.Show("Ref No. Has Been Used. \nPlease Check Again.\nThank You.", "Warning", MessageBoxButtons.OK);
                this.ref_return_valid = false;
            }
            else
            {
                table.OpenTable("wb_transDO", "SELECT * FROM wb_transdo WHERE " + WBData.CompanyLocation(" AND (return_qty_kg <> '' OR return_qty_pack <> '') and ref = '" + this.text_ref_return.Text + "'"), WBData.conn);
                string[] aField = new string[] { "ref" };
                string[] aFind = new string[] { this.text_ref_return.Text };
                DataRow data = this.sh_return.GetData(aField, aFind);
                if (ReferenceEquals(data, null))
                {
                    MessageBox.Show("Invalid Ref No.\nPlease check again.\nThank you", "Warning", MessageBoxButtons.OK);
                    this.ref_return_valid = false;
                }
                else if (this.text_ref_return.Text == this.textRefNo.Text.Trim())
                {
                    MessageBox.Show("Cannot Return with same Ref as Transaction.\nPlease check again.\nThank you", "Warning", MessageBoxButtons.OK);
                    this.ref_return_valid = false;
                }
                else if (table.DT.Rows.Count <= 0)
                {
                    MessageBox.Show("Ref No. " + this.textRefNo.Text.Trim() + " Not Yet Fill In Retur Qty \nPlease Check Again.\nThank You.", "Warning", MessageBoxButtons.OK);
                    this.ref_return_valid = false;
                }
                else
                {
                    string[] textArray4 = new string[] { "Transaction_Code" };
                    string[] textArray5 = new string[] { data["transaction_code"].ToString() };
                    this.rowTransType = this.tblTransType.GetData(textArray4, textArray5);
                    if (this.rowTransType != null)
                    {
                        this.transType = this.rowTransType["IO"].ToString().Trim();
                        this.MSinTrx = this.rowTransType["MS_in_Trx"].ToString().Trim();
                        WBCondition condition = new WBCondition();
                        DataRow[] dgRows = new DataRow[] { this.rowTransType };
                        condition.fillParameter("TRANS_TANKERNO", dgRows);
                        this.sReq_Tanker = condition.getResult() ? "Y" : "N";
                        condition.Dispose();
                    }
                    WBTable table2 = new WBTable();
                    if (this.transType == "I")
                    {
                        table2.OpenTable("wb_transaction_type", "SELECT * FROM wb_transaction_type WHERE " + WBData.CompanyLocation(" AND is_return = 'Y' AND IO = 'O'"), WBData.conn);
                    }
                    else if (this.transType == "O")
                    {
                        table2.OpenTable("wb_transaction_type", "SELECT * FROM wb_transaction_type WHERE " + WBData.CompanyLocation(" AND is_return = 'Y' AND IO = 'I'"), WBData.conn);
                    }
                    else
                    {
                        table2.OpenTable("wb_transaction_type", "SELECT * FROM wb_transaction_type WHERE " + WBData.CompanyLocation(" AND is_return = 'Y' AND IO = 'X'"), WBData.conn);
                    }
                    if (table2.DT.Rows.Count != 1)
                    {
                        MessageBox.Show("Please maintain Return Transaction Type for " + data["transaction_code"].ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        this.comboTransType.Text = table2.DT.Rows[0]["transaction_code"].ToString();
                        string[] textArray6 = new string[15];
                        textArray6[0] = "Ref No: ";
                        textArray6[1] = data["ref"].ToString();
                        textArray6[2] = "\nTransaction Code: ";
                        textArray6[3] = data["transaction_code"].ToString();
                        textArray6[4] = "\nReport Date: ";
                        textArray6[5] = data["report_date"].ToString().Substring(0, 10);
                        textArray6[6] = "\nDO No: ";
                        textArray6[7] = data["do_no"].ToString();
                        textArray6[8] = "\nCommodity: ";
                        textArray6[9] = data["comm_code"].ToString();
                        textArray6[10] = "\nFactory Net: ";
                        textArray6[11] = data["net"].ToString();
                        textArray6[12] = "\n\nFactory Quantity from [ ";
                        textArray6[13] = this.text_ref_return.Text;
                        textArray6[14] = " ] will be copied to Other Pary Quantity.";
                        MessageBox.Show(string.Concat(textArray6), "Ref Information", MessageBoxButtons.OK);
                        this.ref_return_valid = true;
                        this.textGrossEstate.Text = data["gross"].ToString();
                        this.textTareEstate.Text = data["tare"].ToString();
                        this.textNetEstate.Text = data["net"].ToString();
                        this.dateDelivery.Text = data["Delivery_Date"].ToString();
                        this.dateDelivery2.Text = data["Delivery_Date2"].ToString();
                        if (this.dgvDO.Rows.Count > 0)
                        {
                            int index = this.dgvDO.Rows.Count - 1;
                            while (true)
                            {
                                if (index < 0)
                                {
                                    break;
                                }
                                this.dgvDO.Rows.RemoveAt(index);
                                index--;
                            }
                        }
                        if (this.dgvDO.Rows.Count == 0)
                        {
                            this.dgvDO.Rows.Add();
                            int num2 = 0;
                            WBTable table3 = new WBTable();
                            table3.OpenTable("wb_transdo", "SELECT * FROM wb_transDo WHERE " + WBData.CompanyLocation(" AND ref = '" + this.text_ref_return.Text.Trim() + "'"), WBData.conn);
                            DataRow row2 = table3.DT.Rows[0];
                            this.dgvDO.Rows[num2].Cells["Coy"].Value = WBData.sCoyCode;
                            this.dgvDO.Rows[num2].Cells["Location_Code"].Value = WBData.sLocCode;
                            this.dgvDO.Rows[num2].Cells["Transaction_Code"].Value = this.comboTransType.Text;
                            this.dgvDO.Rows[num2].Cells["Ref"].Value = this.textRefNo.Text;
                            this.dgvDO.Rows[num2].Cells["do_sap"].Value = row2["do_sap"].ToString();
                            this.dgvDO.Rows[num2].Cells["do_sap_item"].Value = row2["do_sap_item"].ToString();
                            this.dgvDO.Rows[num2].Cells["Date1"].Value = this.textDate1st.Text;
                            this.dgvDO.Rows[num2].Cells["DO_No"].Value = row2["do_no"].ToString();
                            this.dgvDO.Rows[num2].Cells["Comm_Code"].Value = row2["comm_code"].ToString();
                            this.dgvDO.Rows[num2].Cells["Contract"].Value = row2["contract"].ToString();
                            this.dgvDO.Rows[num2].Cells["Relation_Code"].Value = row2["relation_code"].ToString();
                            this.dgvDO.Rows[num2].Cells["Relation_Name"].Value = row2["relation_name"].ToString();
                            this.dgvDO.Rows[num2].Cells["Netto"].Value = row2["netto"].ToString();
                            this.dgvDO.Rows[num2].Cells["Estate_qty"].Value = row2["estate_qty"].ToString();
                            this.dgvDO.Rows[num2].Cells["Agen"].Value = row2["agen"].ToString();
                            this.dgvDO.Rows[num2].Cells["Estate"].Value = row2["estate"].ToString();
                            this.dgvDO.Rows[num2].Cells["ConvNett"].Value = row2["convnett"].ToString();
                            this.dgvDO.Rows[num2].Cells["ConvUnit"].Value = row2["convunit"].ToString();
                            this.dgvDO.Rows[num2].Cells["PI_No"].Value = row2["pi_no"].ToString();
                            this.dgvDO.Rows[num2].Cells["Transporter_Code"].Value = row2["transporter_code"].ToString();
                            this.dgvDO.Rows[num2].Cells["Storage_code"].Value = row2["storage_code"].ToString();
                            this.dgvDO.Rows[num2].Cells["STO1X"].Value = row2["sto1x"].ToString();
                            this.dgvDO.Rows[num2].Cells["DO1X"].Value = row2["do1x"].ToString();
                            this.dgvDO.Rows[num2].Cells["Tolling"].Value = row2["tolling"].ToString();
                            this.dgvDO.Rows[num2].Cells["Estate_qty"].Value = row2["return_qty_kg"].ToString();
                            this.textGrossEstate.Text = row2["return_qty_kg"].ToString();
                            this.textNetEstate.Text = row2["return_qty_kg"].ToString();
                            this.textTareEstate.Text = "0";
                            this.dgvDO.Rows[num2].Cells["loading_qty_opw"].Value = row2["return_qty_pack"].ToString();
                            this.hitungBTN();
                            this.HitNet();
                            this.chk_return.Enabled = false;
                            this.text_ref_return.ReadOnly = true;
                            this.textCommodity.Text = row2["comm_code"].ToString();
                            table2.Dispose();
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.dgvDeduc.Rows.Count > 0)
            {
                int index = this.dgvDeduc.CurrentRow.Index;
                if (MessageBox.Show(" Are you sure to deleted this record ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.dgvDeduc.Rows.Remove(this.dgvDeduc.Rows[index]);
                    this.ChangeDeduc = true;
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            FormDriver driver = new FormDriver {
                pMode = "CHOOSE",
                pFind = this.textDriverID.Text
            };
            driver.ShowDialog();
            if (driver.ReturnRow != null)
            {
                this.textDriverID.Text = driver.ReturnRow["License_No"].ToString();
                this.labelDriverName.Text = driver.ReturnRow["Name"].ToString();
                this.textDriverName.Text = driver.ReturnRow["Name"].ToString();
                if (this.textTruck.Text.Trim() == "")
                {
                    this.textTruck.Text = driver.ReturnRow["Truck_Number"].ToString();
                    this.textTruck.Focus();
                }
            }
            driver.Dispose();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransporter.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.labelTransporterName.Text = transporter.ReturnRow["Transporter_Name"].ToString();
                this.textTransporter.Focus();
            }
            transporter.Dispose();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            FormTanker tanker = new FormTanker {
                pMode = "CHOOSE"
            };
            tanker.ShowDialog();
            if (tanker.ReturnRow != null)
            {
                this.textTanker.Text = tanker.ReturnRow["Tanker_No"].ToString();
                this.labelTankerMax.Text = "Max.Tanker = " + $"{tanker.ReturnRow["Capacity"]:N0}" + " Kg";
                this.labelTankerMax.Text = (tanker.ReturnRow["Check_tanker"].ToString() != "P") ? ((tanker.ReturnRow["Check_tanker"].ToString() != "K") ? (this.labelTankerMax.Text + " (NOT CHECK) ") : (this.labelTankerMax.Text + " (Tolerance : " + tanker.ReturnRow["CheckTankerKG"].ToString() + " KG)")) : (this.labelTankerMax.Text + " (Tolerance : " + tanker.ReturnRow["CheckTankerTol"].ToString() + " %)");
                this.textTanker.Focus();
            }
            tanker.Dispose();
        }

        private void button12_Click_1(object sender, EventArgs e)
        {
            if (this.dgvDeducPorla.Rows.Count > 0)
            {
                this.EntryDeductionPorla("EDIT");
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
                this.textCommType.Text = (commodity.ReturnRow["Type"].ToString().Trim() != "") ? commodity.ReturnRow["Type"].ToString().Trim() : "S";
                this.CommType = commodity.ReturnRow["Type"].ToString().Trim();
                this.check_tare_comm = commodity.ReturnRow["Check_Tare"].ToString().Trim();
                this.textCommodity.Focus();
            }
            commodity.Dispose();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            this.EntryDeductionPorla("ADD");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (this.dgvDivBlock.Rows.Count > 0)
            {
                int index = this.dgvDivBlock.CurrentRow.Index;
                if (MessageBox.Show(" Are you sure to deleted this record ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.dgvDivBlock.Rows.Remove(this.dgvDivBlock.Rows[index]);
                    this.ChangeDiv = true;
                }
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (this.dgvDivBlock.Rows.Count > 0)
            {
                this.EntryDivBlock("EDIT");
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (Program.StrToDouble(this.text2nd.Text, 0) > 0.0)
            {
                this.EntryDivBlock("ADD");
            }
            else
            {
                MessageBox.Show("Please Read Indicator First to Add Division Block");
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (((((this.dgvListDO.CurrentRow.Cells["transaction_code"].Value.ToString() != "LGK") && ((this.dgvListDO.CurrentRow.Cells["transaction_code"].Value.ToString() != "LGM") && (this.dgvListDO.CurrentRow.Cells["transaction_code"].Value.ToString() != "RI"))) && (this.dgvListDO.CurrentRow.Cells["transaction_code"].Value.ToString() != "RO")) && !this.SJApproved) && ((WBSetting.Field("GM").ToString() == "Y") && (Convert.ToInt16(WBUser.UserLevel) > 1)))
            {
                FormToken token = new FormToken {
                    email_code = "TOKEN_DELIVERY"
                };
                string[] tokenParams = new string[] { this.textTruck.Text.Trim() };
                token.initData(tokenParams, "DELIVERY", "WB_TRANSACTION", "0", "");
                this.tblTrans.DR = this.tblTrans.DT.Rows[0];
                this.tblTrans.DR.BeginEdit();
                if (this.tblTrans.DR["completedDL"].ToString() == "N")
                {
                    token.textBoxToken.Text = this.tblTrans.DR["TokenDL"].ToString();
                }
                token.ShowDialog();
                this.completed = token.completed;
                this.tblTrans.DR["TokenDL"] = token.textBoxToken.Text;
                if (!(token.saved && (token.completed == "N")))
                {
                    if (!(token.saved && (token.completed == "Y")))
                    {
                        return;
                    }
                    else
                    {
                        this.SJApproved = true;
                        this.tblTrans.DR["TokenDL"] = "";
                        this.tblTrans.DR["completedDL"] = "Y";
                        this.tblTrans.DR["checksum"] = this.tblTrans.Checksum(this.tblTrans.DR);
                        this.tblTrans.DR.EndEdit();
                        this.tblTrans.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { this.logMode, WBUser.UserID, this.logReason };
                        Program.updateLogHeader("wb_transaction", this.tblTrans.DR["ref"].ToString(), logField, logValue);
                        token.Dispose();
                    }
                }
                else
                {
                    this.tblTrans.DR["completedDL"] = "N";
                    this.tblTrans.DR["checksum"] = this.tblTrans.Checksum(this.tblTrans.DR);
                    this.tblTrans.DR.EndEdit();
                    this.tblTrans.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { this.logMode, WBUser.UserID, this.logReason };
                    Program.updateLogHeader("wb_transaction", this.tblTrans.DR["ref"].ToString(), logField, logValue);
                    return;
                }
            }
            if ((this.dgvDO.Rows.Count <= 0) && (this.WX != "1x"))
            {
                this.textGunnyBatch.Focus();
                MessageBox.Show("Please Input DO Number First !", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.textDL.Text.Trim() == "")
            {
                MessageBox.Show("Type Delivery Letter Number first..");
                this.textDL.Focus();
            }
            else
            {
                this.dgvBatch.Rows.Add();
                this.dgvBatch.ReadOnly = false;
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Location_Code"].Value = WBData.sLocCode;
                string[] strArray = new string[] { "", "A", "B", "C", "D", "E", "F", "G", "H" };
                strArray[9] = "I";
                int rowCount = this.dgvBatch.Rows.GetRowCount(DataGridViewElementStates.Visible);
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["ref"].Value = (this.dgvListDO.CurrentRow.Index != 0) ? ((rowCount > 1) ? (this.textRefNo.Text.Trim() + strArray[this.dgvListDO.CurrentRow.Index] + "-" + strArray[rowCount - 1]) : (this.textRefNo.Text.Trim() + strArray[this.dgvListDO.CurrentRow.Index])) : ((rowCount > 1) ? (this.textRefNo.Text.Trim() + "-" + strArray[rowCount - 1]) : this.textRefNo.Text.Trim());
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["SO_No"].Value = this.dgvListDO.CurrentRow.Cells["Do_No"].Value;
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Do_No"].Value = this.textDL.Text.Trim();
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["STO_No"].Value = this.textSTO.Text;
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Item_No"].Value = "";
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Batch"].Value = "";
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["STO_Batch"].Value = "";
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Adopted"].Value = "N";
                this.dgvBatch.Rows[this.dgvBatch.Rows.Count - 1].Cells["Approved"].Value = "Y";
                this.ChangeBatch = true;
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (this.dgvBatch.Rows.Count > 0)
            {
                FormSplitBatch batch = new FormSplitBatch();
                if (this.dgvBatch.Rows[0].Cells["STO_No"].ToString().Trim() == "")
                {
                }
                batch.DGVsplitbatch = this.dgvBatch;
                batch.PerBagQty = Convert.ToInt32(this.textBox1.Text);
                batch.ShowDialog();
                this.dgvBatch = batch.DGVsplitbatch;
                batch.Dispose();
                string[] strArray = new string[] { "", "-A", "-B", "-C", "-D", "-E", "-F", "-G", "-H" };
                strArray[9] = "-I";
                int num = 0;
                int index = 0;
                while (true)
                {
                    if (index >= this.dgvBatch.Rows.Count)
                    {
                        this.textNettoBatch.Text = num.ToString();
                        this.textNettoBatch_Leave(this, e);
                        this.text2nd_Leave(this, e);
                        this.ChangeBatch = true;
                        break;
                    }
                    num += Convert.ToInt32(this.dgvBatch.Rows[index].Cells["Netto"].Value);
                    this.dgvBatch.Rows[index].Cells["Ref"].Value = this.textRefNo.Text.Trim() + strArray[index];
                    index++;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.dgvDeduc.Rows.Count > 0)
            {
                this.EntryDeduction("EDIT");
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (this.dgvBatch.Rows.Count > 0)
            {
                if (this.dgvBatch.CurrentRow.Cells["Num_of_Gunny"].Value == null)
                {
                    this.dgvBatch.Rows.Remove(this.dgvBatch.CurrentRow);
                }
                else if (MessageBox.Show("Are you sure to " + this.button20.Text.Trim() + " this records ?", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    int num = Convert.ToInt32(this.dgvBatch.Rows[0].Cells["Num_of_Gunny"].Value.ToString());
                    int num2 = Convert.ToInt32(this.dgvBatch.CurrentRow.Cells["Num_of_Gunny"].Value.ToString());
                    this.dgvBatch.Rows[0].Cells["Num_of_Gunny"].Value = Convert.ToString((int) (num + num2));
                    int num3 = Convert.ToInt32(this.dgvBatch.Rows[0].Cells["Netto"].Value.ToString());
                    int num4 = Convert.ToInt32(this.dgvBatch.CurrentRow.Cells["Netto"].Value.ToString());
                    this.dgvBatch.Rows[0].Cells["Netto"].Value = Convert.ToString((int) (num3 + num4));
                    this.dgvBatch.Rows.Remove(this.dgvBatch.CurrentRow);
                    this.ChangeBatch = true;
                    if (this.dgvBatch.Rows.Count <= 0)
                    {
                        this.textNettoBatch.Text = "0";
                        this.textNettoBatch_Leave(this, e);
                    }
                    else
                    {
                        string[] strArray = new string[] { "", "A", "B", "C", "D", "E", "F", "G", "H" };
                        strArray[9] = "I";
                        int num5 = 0;
                        int index = 0;
                        int num6 = 0;
                        while (true)
                        {
                            if (num6 >= this.dgvBatch.Rows.Count)
                            {
                                this.textNettoBatch.Text = num5.ToString();
                                this.textNettoBatch_Leave(this, e);
                                this.text2nd_Leave(this, e);
                                this.ChangeBatch = true;
                                break;
                            }
                            num5 += Convert.ToInt32(this.dgvBatch.Rows[num6].Cells["Netto"].Value);
                            if (this.dgvBatch.Rows[num6].Cells["SO_No"].Value.ToString().Trim() == this.dgvListDO.CurrentRow.Cells["Do_No"].Value.ToString().Trim())
                            {
                                if (this.dgvListDO.CurrentRow.Index == 0)
                                {
                                    if (index != 0)
                                    {
                                        this.dgvBatch.Rows[num6].Cells["ref"].Value = this.textRefNo.Text.Trim() + "-" + strArray[index];
                                    }
                                    else
                                    {
                                        this.dgvBatch.Rows[num6].Cells["ref"].Value = this.textRefNo.Text.Trim();
                                        this.dgvBatch.Rows[num6].Cells["Num_of_Gunny"].Value = Convert.ToString((int) (num + num2));
                                        this.dgvBatch.Rows[num6].Cells["Netto"].Value = Convert.ToString((int) (num3 + num4));
                                    }
                                }
                                else if (index != 0)
                                {
                                    this.dgvBatch.Rows[num6].Cells["ref"].Value = this.textRefNo.Text.Trim() + strArray[this.dgvListDO.CurrentRow.Index] + "-" + strArray[index];
                                }
                                else
                                {
                                    this.dgvBatch.Rows[num6].Cells["ref"].Value = this.textRefNo.Text.Trim() + strArray[this.dgvListDO.CurrentRow.Index];
                                    this.dgvBatch.Rows[num6].Cells["Num_of_Gunny"].Value = Convert.ToString((int) (num + num2));
                                    this.dgvBatch.Rows[num6].Cells["Netto"].Value = Convert.ToString((int) (num3 + num4));
                                }
                                index++;
                            }
                            num6++;
                        }
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.EntryDeduction("ADD");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormEstate estate = new FormEstate {
                pMode = "CHOOSE"
            };
            estate.ShowDialog();
            if (estate.ReturnRow != null)
            {
                this.textEstate.Text = estate.ReturnRow["Estate_Code"].ToString();
                this.labelEstateName.Text = estate.ReturnRow["Estate_Name"].ToString();
                this.textEstate.Focus();
            }
            estate.Dispose();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            WBTable table;
            bool flag = false;
            if (((WBSetting.WB_Type == "5") && (WBSetting.Check_Zero == "Y")) && (Convert.ToInt16(WBUser.UserLevel) > 2))
            {
                this.wbIndicator.Init();
                this.wbIndicator.checkStatus();
                if (WBSetting.chkZeroMode.IndexOf(this.pMode.Substring(0, 1)) >= 0)
                {
                    flag = true;
                }
                if (!this.wbIndicator.check0() & flag)
                {
                    MessageBox.Show("Indicator not zero...");
                    return;
                }
            }
            FormReadIndicator indicator = new FormReadIndicator();
            if (((WBSetting.bGate == "Y") && (WBSetting.WB_Type != "5")) && !WBSetting.activeTCS)
            {
                if (((this.pMode == "1ST") || (this.pMode == "3RD")) & (this.WX != ""))
                {
                    if ((WBSetting.gateType != "1") && (WBSetting.gateType != ""))
                    {
                        if (WBSetting.gateType == "2")
                        {
                            this.returnGate = WBBarrierGate2.closeGate(WBSetting.gate1IP, WBSetting.gate1Port);
                            if (!this.returnGate)
                            {
                                MessageBox.Show("Error close gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                return;
                            }
                        }
                    }
                    else
                    {
                        WBBarrierGate1.runGate(WBSetting.gate1Close);
                    }
                }
                if (((this.pMode == "2ND") || (this.pMode == "4TH")) & (this.WX != ""))
                {
                    if ((WBSetting.gateType != "1") && (WBSetting.gateType != ""))
                    {
                        if (WBSetting.gateType == "2")
                        {
                            this.returnGate = WBBarrierGate2.closeGate(WBSetting.gate1IPOut, WBSetting.gate1PortOut);
                            if (!this.returnGate)
                            {
                                MessageBox.Show("Error close gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                return;
                            }
                        }
                    }
                    else
                    {
                        WBBarrierGate1.runGate(WBSetting.gate1CloseOut);
                    }
                }
            }
            indicator.ShowDialog();
            if (!indicator.ok)
            {
                goto TR_0013;
            }
            else
            {
                this.indStableWarning = indicator.indStableWarning;
                if (this.pMode == "1ST")
                {
                    this.textDate1st.Text = DateTime.Now.ToString("dd/MM/yyyy");
                    this.textTime1st.Text = (DateTime.Now.ToString("HH:mm") == "00:00") ? DateTime.Now.ToString("HH:01:ss") : DateTime.Now.ToString("HH:mm:ss");
                    this.text1st.Text = $"{Convert.ToInt32(indicator.Hasil.Trim()):N0}";
                }
                else if (this.pMode == "2ND")
                {
                    this.textDate2nd.Text = DateTime.Now.ToString("dd/MM/yyyy");
                    this.textTime2nd.Text = (DateTime.Now.ToString("HH:mm") == "00:00") ? DateTime.Now.ToString("HH:01:ss") : DateTime.Now.ToString("HH:mm:ss");
                    this.textReport_Date.Text = this.textDate2nd.Text;
                    this.text2nd.Text = $"{Convert.ToInt32(indicator.Hasil.Trim()):N0}";
                }
                else if (this.pMode == "3RD")
                {
                    this.textDate3rd.Text = DateTime.Now.ToShortDateString();
                    this.textTime3rd.Text = DateTime.Now.ToString("HH:mm:ss");
                    this.text3rd.Text = $"{Convert.ToInt32(indicator.Hasil.Trim()):N0}";
                }
                else
                {
                    this.text4th.Text = $"{Convert.ToInt32(indicator.Hasil.Trim()):N0}";
                    this.textDate4th.Text = DateTime.Now.ToShortDateString();
                    this.textReport_Date.Text = this.textDate4th.Text;
                    this.textTime4th.Text = DateTime.Now.ToString("HH:mm:ss");
                }
                if (((WBSetting.bGate != "Y") || (WBSetting.WB_Type != "5")) || WBSetting.activeTCS)
                {
                    goto TR_0019;
                }
                else
                {
                    if (((this.pMode == "1ST") || (this.pMode == "3RD")) & (this.WX != ""))
                    {
                        if ((WBSetting.gateType != "1") && (WBSetting.gateType != ""))
                        {
                            if (WBSetting.gateType == "2")
                            {
                                this.returnGate = WBBarrierGate2.closeGate(WBSetting.gate1IP, WBSetting.gate1Port);
                                if (!this.returnGate)
                                {
                                    MessageBox.Show("Error close gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    return;
                                }
                            }
                        }
                        else
                        {
                            WBBarrierGate1.runGate(WBSetting.gate1Close);
                        }
                    }
                    if (!(((this.pMode == "2ND") || (this.pMode == "4TH")) & (this.WX != "")))
                    {
                        goto TR_0019;
                    }
                    else if ((WBSetting.gateType != "1") && (WBSetting.gateType != ""))
                    {
                        if (WBSetting.gateType != "2")
                        {
                            goto TR_0019;
                        }
                        else
                        {
                            this.returnGate = WBBarrierGate2.closeGate(WBSetting.gate1IPOut, WBSetting.gate1PortOut);
                            if (this.returnGate)
                            {
                                goto TR_0019;
                            }
                            else
                            {
                                MessageBox.Show("Error close gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                        }
                    }
                    else
                    {
                        WBBarrierGate1.runGate(WBSetting.gate1CloseOut);
                        goto TR_0019;
                    }
                }
            }
            return;
        TR_0013:
            indicator.Dispose();
            this.HitNet();
            if ((this.pMode == "2ND") && !(Convert.ToDouble(this.textNet.Text) == 0.0))
            {
                if (!WBSetting.activeTCS || (WBSetting.activeTCS && (this.dgvDO.RowCount == 1)))
                {
                    if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text2nd.Text))
                    {
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text1st.Text;
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = this.text2nd.Text;
                    }
                    else
                    {
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text2nd.Text;
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = this.text1st.Text;
                    }
                    this.dgvDO.Rows[0].Cells["Netto"].Value = this.textNet.Text;
                    this.dgvDO.Refresh();
                    this.ChangeDO = true;
                }
                this.hitungBTN();
                if (this.dgvBatch.RowCount > 1)
                {
                    this.calc_dl();
                }
                else
                {
                    this.calc_loadstuff();
                }
                if (((this.pMode == "2ND") || (this.pMode == "4TH")) ? (this.dgvDeduc.Enabled || this.dgvDivBlock.Enabled) : false)
                {
                    if (this.dgvDeduc.RowCount > 0)
                    {
                        this.recalc_deduc();
                    }
                    if (this.dgvDivBlock.RowCount > 0)
                    {
                        this.recalc_division();
                    }
                }
                if (this.CommType == "F")
                {
                    this.BJR();
                }
                this.timeReadIndicator = DateTime.Now;
            }
            return;
        TR_0019:
            table = new WBTable();
            table.OpenTable("wb_setting", "SELECT uniq, usedForWeighing FROM wb_setting WHERE " + WBData.CompanyLocation(" AND Wbcode = '" + WBData.sWBCode + "'"), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                table.DR = table.DT.Rows[0];
                if (table.DR["usedForWeighing"].ToString() != "Y")
                {
                    table.DR.BeginEdit();
                    table.DR["usedForWeighing"] = "Y";
                    table.DR.EndEdit();
                    table.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Change flag for PC which is used to weigh" };
                    Program.updateLogHeader("wb_setting", table.DR["uniq"].ToString(), logField, logValue);
                }
            }
            table.Dispose();
            goto TR_0013;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (this.dgvDeducPorla.Rows.Count > 0)
            {
                int index = this.dgvDeducPorla.CurrentRow.Index;
                if (MessageBox.Show(" Are you sure to deleted this record ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.dgvDeducPorla.Rows.Remove(this.dgvDeducPorla.Rows[index]);
                    this.ChangeDeducPorla = true;
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            bool enabled = this.textDN.Enabled;
            if (this.dgvDO.RowCount > 0)
            {
                if (this.spMode == "EDIT_OPW")
                {
                    this.entryDO("EDIT_OPW");
                }
                else
                {
                    this.entryDO("EDIT");
                }
            }
            if (!this.checkNonContract.Checked)
            {
                this.textDN.Enabled = !((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))) ? !((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))) : false;
                if (enabled != this.textDN.Enabled)
                {
                    this.textDN.Text = "";
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if ((this.dgvDO.Rows.Count > 1) && (this.dgvDO.CurrentRow.Index != 0))
            {
                int index = this.dgvDO.CurrentRow.Index;
                if (MessageBox.Show(" Are you sure to deleted this record ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    if (index > 0)
                    {
                        this.dgvDO.Rows[0].Cells["Estate_qty"].Value = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString()) + Convert.ToDouble(this.dgvDO.Rows[index].Cells["Estate_qty"].Value.ToString());
                        this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString()) + Convert.ToDouble(this.dgvDO.Rows[index].Cells["Netto"].Value.ToString());
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Tarra"].Value.ToString()) + Convert.ToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString());
                        if ((this.comboTransType.Text == "JUL") && ((this.dgvDO.Rows[0].Cells["internal_number"].Value.ToString() != "") || (this.dgvDO.Rows[0].Cells["do_sap"].Value.ToString() != "")))
                        {
                            this.tblComm.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + this.dgvDO.Rows[0].Cells["Comm_code"].Value + "' and bulkpack = 'P' and upper(unit) = 'KG'"), WBData.conn);
                            if (this.tblComm.DT.Rows.Count > 0)
                            {
                                this.dgvDO.Rows[0].Cells["loading_qty"].Value = this.dgvDO.Rows[0].Cells["Netto"].Value;
                            }
                        }
                    }
                    this.dgvDO.Rows.Remove(this.dgvDO.Rows[index]);
                    this.ChangeDO = true;
                    if (this.CommType == "G")
                    {
                        this.dgvBatch.Rows.Clear();
                    }
                }
                this.buttonComm.Enabled = this.dgvDO.Rows.Count <= 0;
                this.comboTransType.Enabled = this.dgvDO.Rows.Count <= 0;
                if (this.comboTransType.Enabled)
                {
                    this.comboTransType.Text = "";
                    this.textCommodity.Text = "";
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            FormTruck truck = new FormTruck {
                pMode = "CHOOSE",
                pFind = this.textTruck.Text
            };
            truck.ShowDialog();
            if (truck.ReturnRow != null)
            {
                if ((this.pMode == "3RD") || (this.pMode == "4TH"))
                {
                    this.textTruck2.Text = truck.ReturnRow["Truck_Number"].ToString();
                }
                else
                {
                    this.textTruck.Text = truck.ReturnRow["Truck_Number"].ToString();
                    this.textTanker.Text = truck.ReturnRow["Tanker_no"].ToString().Trim();
                    this.tblTanker.ReOpen();
                    string[] aField = new string[] { "Tanker_No" };
                    string[] aFind = new string[] { this.textTanker.Text.Trim() };
                    int recNo = this.tblTanker.GetRecNo(aField, aFind);
                    if (recNo <= -1)
                    {
                        this.labelTankerMax.Text = "Max.Tanker =-";
                    }
                    else
                    {
                        this.labelTankerMax.Text = "Max.Tanker = " + $"{this.tblTanker.DT.Rows[recNo]["Capacity"].ToString().Trim():N0}" + " Kg";
                        this.labelTankerMax.Text = (this.tblTanker.DT.Rows[recNo]["Check_tanker"].ToString() != "P") ? ((this.tblTanker.DT.Rows[recNo]["Check_tanker"].ToString() != "K") ? (this.labelTankerMax.Text + " (NOT CHECK) ") : (this.labelTankerMax.Text + " (Tolerance : " + this.tblTanker.DT.Rows[recNo]["CheckTankerKG"].ToString() + " KG)")) : (this.labelTankerMax.Text + " (Tolerance : " + this.tblTanker.DT.Rows[recNo]["CheckTankerTol"].ToString() + " %)");
                    }
                    if (this.textTransporter.Text.Trim() == "")
                    {
                        this.textTransporter.Text = truck.ReturnRow["Transporter_Code"].ToString();
                        string[] textArray3 = new string[] { "Transporter_Code" };
                        string[] textArray4 = new string[] { this.textTransporter.Text };
                        DataRow data = this.tblTransporter.GetData(textArray3, textArray4);
                        if (data != null)
                        {
                            this.labelTransporterName.Text = data["Transporter_Name"].ToString();
                        }
                    }
                }
                if ((((this.pMode == "1ST") || ((this.pMode == "2ND") || ((this.pMode == "3RD") || (this.pMode == "4TH")))) || (this.WX == "")) && this.checkTruckinYard(this.textTruck.Text, this.textTruck2.Text))
                {
                    if (((this.pMode == "1ST") || (this.pMode == "2ND")) || (this.WX == ""))
                    {
                        this.textTruck.SelectAll();
                        this.textTruck.Focus();
                    }
                    else if ((this.pMode == "3RD") || (this.pMode == "4TH"))
                    {
                        this.textTruck2.SelectAll();
                        this.textTruck2.Focus();
                    }
                }
            }
            truck.Dispose();
        }

        private void buttonAddDO_Click(object sender, EventArgs e)
        {
            if ((this.pMode == "2ND") || (this.pMode == "4TH"))
            {
                if ((this.WX != "2X") || (this.text2nd.Text.Trim() != "0"))
                {
                    if ((this.WX == "4X") && (this.text4th.Text.Trim() == "0"))
                    {
                        MessageBox.Show("Please Read Indicator before Add DO");
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Please Read Indicator before Add DO");
                    return;
                }
            }
            this.entryDO("ADD");
            if (this.dgvDO.Rows.Count > 0)
            {
                if ((this.oldComm == null) || (this.oldComm == ""))
                {
                    this.oldComm = this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString();
                }
                this.comm_code = this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString();
            }
            this.buttonComm.Enabled = this.dgvDO.RowCount <= 0;
            this.comboTransType.Enabled = this.dgvDO.RowCount <= 0;
            if (!this.checkNonContract.Checked)
            {
                this.textDN.Enabled = !((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))) ? !((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))) : false;
            }
        }

        private void buttonAdopt_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.SJApproved = false;
            this.dgvBatch.ReadOnly = ((this.dgvListDO.CurrentRow.Cells["transaction_code"].Value.ToString() != "LGK") && ((this.dgvListDO.CurrentRow.Cells["transaction_code"].Value.ToString() != "LGM") && (this.dgvListDO.CurrentRow.Cells["transaction_code"].Value.ToString() != "RI"))) && (this.dgvListDO.CurrentRow.Cells["transaction_code"].Value.ToString() != "RO");
            if (this.textDL.Text.Trim() == "")
            {
                MessageBox.Show("Entry Delivery Letter Number first");
                this.textDL.Focus();
            }
            else if (this.dgvListDO.Rows.Count == 0)
            {
                MessageBox.Show("ADD DO line first");
                this.textDL.Focus();
            }
            else if ((this.textBox1.Text.Trim() == "0") || (this.textBox1.Text.Trim() == ""))
            {
                MessageBox.Show("Please maintain Net per Gunny first..");
            }
            else
            {
                try
                {
                    WBSetting.OpenSetting();
                    if (WBSAP.connect())
                    {
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_ADOPT_DO");
                        WBSAP.rfcFunction.SetValue("VBELN", this.textDL.Text.Trim());
                        WBSAP.rfcFunction.SetValue("SO_NO", this.dgvListDO.CurrentRow.Cells["Do_No"].Value.ToString().Trim());
                        WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                        this.ISReturn = WBSAP.rfcFunction.GetTable("I_RECORD");
                        if (this.ISReturn.GetString("NOT_EXIST") != "")
                        {
                            MessageBox.Show("Adopt Failed. No Data From SAP", "F A I L E D", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.SJAdopted = false;
                            this.SJApproved = false;
                        }
                        else
                        {
                            string[] textArray1 = new string[12];
                            textArray1[0] = "Item No   : ";
                            textArray1[1] = this.ISReturn.GetString("POSNR").ToString();
                            textArray1[2] = "\rMaterial  : ";
                            textArray1[3] = this.ISReturn.GetString("MATNR").ToString();
                            textArray1[4] = "\rQTY in KG : ";
                            textArray1[5] = this.ISReturn.GetString("LFIMG_KG").ToString();
                            textArray1[6] = "\rQTY DO    : ";
                            textArray1[7] = this.ISReturn.GetString("LFIMG").ToString();
                            textArray1[8] = "\rUNIT      : ";
                            textArray1[9] = this.ISReturn.GetString("VRKME").ToString();
                            textArray1[10] = "\rCUSTOMER  : ";
                            textArray1[11] = this.ISReturn.GetString("KUNNR").ToString();
                            string str = string.Concat(textArray1);
                            int num8 = this.dgvBatch.RowCount - 1;
                            while (true)
                            {
                                if (num8 < 0)
                                {
                                    int num2 = 0;
                                    int num3 = 0;
                                    int num = 0;
                                    while (true)
                                    {
                                        if (num >= this.ISReturn.RowCount)
                                        {
                                            this.textGunnyBatchLeft.Text = num2.ToString();
                                            this.textNettoBatchLeft.Text = num3.ToString();
                                            this.SJAdopted = true;
                                            this.SJApproved = false;
                                            string[] strArray = new string[] { "", "A", "B", "C", "D", "E", "F", "G", "H" };
                                            strArray[9] = "I";
                                            int num5 = 0;
                                            int index = 0;
                                            int num6 = 0;
                                            while (true)
                                            {
                                                if (num6 >= this.dgvBatch.Rows.Count)
                                                {
                                                    this.textNettoBatch.Text = num5.ToString();
                                                    this.textNettoBatch_Leave(this, e);
                                                    this.text2nd_Leave(this, e);
                                                    break;
                                                }
                                                num5 += Convert.ToInt32(this.dgvBatch.Rows[num6].Cells["Netto"].Value);
                                                if (this.dgvBatch.Rows[num6].Cells["SO_No"].Value.ToString().Trim() == this.dgvListDO.CurrentRow.Cells["Do_No"].Value.ToString().Trim())
                                                {
                                                    this.dgvBatch.Rows[num6].Cells["ref"].Value = (this.dgvListDO.CurrentRow.Index != 0) ? ((index != 0) ? (this.textRefNo.Text.Trim() + strArray[this.dgvListDO.CurrentRow.Index] + "-" + strArray[index]) : (this.textRefNo.Text.Trim() + strArray[this.dgvListDO.CurrentRow.Index])) : ((index != 0) ? (this.textRefNo.Text.Trim() + "-" + strArray[index]) : this.textRefNo.Text.Trim());
                                                    index++;
                                                }
                                                num6++;
                                            }
                                            break;
                                        }
                                        string str2 = this.ISReturn[num].GetString("LFIMG_KG").ToString().Trim().Replace(",", "").Replace(".", "");
                                        num3 += Convert.ToInt32(str2);
                                        this.textSTO.Text = this.ISReturn[num].GetString("STO_NO").ToString();
                                        this.dgvBatch.Rows.Add();
                                        int num4 = this.dgvBatch.Rows.Count - 1;
                                        this.dgvBatch.Rows[num4].Cells["Coy"].Value = WBData.sCoyCode;
                                        this.dgvBatch.Rows[num4].Cells["Location_Code"].Value = WBData.sLocCode;
                                        this.dgvBatch.Rows[num4].Cells["ref"].Value = this.textRefNo.Text.Trim();
                                        this.dgvBatch.Rows[num4].Cells["Item_No"].Value = this.ISReturn[num].GetString("POSNR").ToString();
                                        this.dgvBatch.Rows[num4].Cells["SO_No"].Value = this.dgvListDO.CurrentRow.Cells["Do_No"].Value.ToString().Trim();
                                        this.dgvBatch.Rows[num4].Cells["Do_No"].Value = this.textDL.Text.Trim();
                                        this.dgvBatch.Rows[num4].Cells["Num_Of_Gunny"].Value = Convert.ToString((int) (Convert.ToInt32(str2) / Convert.ToInt32(this.textBox1.Text)));
                                        this.dgvBatch.Rows[num4].Cells["Netto"].Value = str2.ToString();
                                        this.dgvBatch.Rows[num4].Cells["STO_No"].Value = this.ISReturn[num].GetString("STO_NO").ToString();
                                        this.dgvBatch.Rows[num4].Cells["Batch"].Value = this.ISReturn[num].GetString("CHARG").ToString();
                                        this.dgvBatch.Rows[num4].Cells["STO_Batch"].Value = "";
                                        this.dgvBatch.Rows[num4].Cells["Adopted"].Value = "Y";
                                        this.dgvBatch.Rows[num4].Cells["Approved"].Value = "N";
                                        num++;
                                    }
                                    break;
                                }
                                DataGridViewRow dataGridViewRow = this.dgvBatch.Rows[num8];
                                if ((dataGridViewRow.Cells["SO_No"].Value.ToString().Trim() == this.dgvListDO.CurrentRow.Cells["Do_No"].Value.ToString().Trim()) || (dataGridViewRow.Cells["SO_No"].Value.ToString().Trim() == ""))
                                {
                                    this.dgvBatch.Rows.Remove(dataGridViewRow);
                                }
                                num8--;
                            }
                        }
                    }
                }
                catch (RfcInvalidParameterException exception)
                {
                    this.SJAdopted = false;
                    MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "E R R O R <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (RfcAbapException exception2)
                {
                    string text = "";
                    if (exception2.Message == "INVALID_DO")
                    {
                        text = "Invalid Delivery Letter Number";
                    }
                    else if (exception2.Message == "INVALID_LINK")
                    {
                        text = "DO and Delivery Letter not Linked";
                    }
                    MessageBox.Show(text, "E R R O R ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.SJAdopted = false;
                }
                catch (RfcCommunicationException exception3)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception3.ToString(), "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    this.SJAdopted = false;
                }
                catch (RfcBaseException exception4)
                {
                    if (WBUser.UserLevel == "1")
                    {
                        MessageBox.Show(exception4.ToString(), "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    this.SJAdopted = false;
                }
                catch (Exception exception5)
                {
                    MessageBox.Show("Error " + exception5.ToString(), "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.SJAdopted = false;
                }
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.fCopra.Dispose();
            this.ThisClose();
        }

        private void buttonContAdd_Click(object sender, EventArgs e)
        {
            this.entryCont("ADD");
        }

        private void buttonContDelete_Click(object sender, EventArgs e)
        {
            if (this.dgvCont.Rows.Count > 0)
            {
                int index = this.dgvCont.CurrentRow.Index;
                if (MessageBox.Show(" Are you sure to deleted this record ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.dgvCont.Rows.Remove(this.dgvCont.Rows[index]);
                    this.ChangeContainer = true;
                }
            }
        }

        private void buttonContEdit_Click(object sender, EventArgs e)
        {
            this.entryCont("EDIT");
        }

        private void buttonCust_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textCust.Text = vendor.ReturnRow["Relation_Code"].ToString();
                this.labelCustName.Text = vendor.ReturnRow["Relation_Name"].ToString();
                this.textCust.Focus();
            }
            vendor.Dispose();
        }

        private void buttonEntryCopra_Click(object sender, EventArgs e)
        {
            if (Convert.ToDouble(this.text2nd.Text.Trim()) <= 0.0)
            {
                if (this.pMode != "QC")
                {
                    MessageBox.Show("Please Fill 2nd Weight", "WARNING....");
                }
                else
                {
                    MessageBox.Show("Cannot Entry Copra in QC Mode", "WARNING...");
                }
            }
            else if ((this.pMode == "2ND") || (((this.pMode == "EDIT") || (this.spMode == "QTY")) || (this.spMode == "EDIT_OPW")))
            {
                this.fCopra.textTarra.Text = this.textNET1.Text;
                this.fCopra.totalTarra = this.textNET1.Text;
                WBTable table = new WBTable();
                table.OpenTable("wb_bag", "select * from wb_bag", WBData.conn);
                this.fCopra.tbl_bag = table;
                this.fCopra.ShowDialog();
                this.textTotalCopra.Text = this.fCopra.textTotalCopra.Text;
                this.HitNet();
            }
        }

        private void buttonEntryDeduc_Click(object sender, EventArgs e)
        {
            new DataGridView().ColumnCount = this.dgvDO.ColumnCount;
            FormTransDeducUnitEntry entry = new FormTransDeducUnitEntry {
                dgvDO = this.dgvDO
            };
            entry.ShowDialog();
            if (entry.saved)
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
                {
                    foreach (DataGridViewRow row2 in (IEnumerable) entry.dgvDODeduc.Rows)
                    {
                        if (row.Cells["DO_NO"].Value.ToString().Trim().ToUpper() == row2.Cells["DO_NO"].Value.ToString().Trim().ToUpper())
                        {
                            row.Cells["WeightPerUnitName"].Value = row2.Cells["WeightPerUnitName"].Value;
                            row.Cells["DeducUnitQty"].Value = row2.Cells["DeducUnitQty"].Value;
                            row.Cells["TotalDeducUnit"].Value = row2.Cells["TotalDeducUnit"].Value;
                            row.Cells["Deduction"].Value = row2.Cells["TotalDeducUnit"].Value;
                            row.Cells["UnitName"].Value = row2.Cells["UnitName"].Value;
                            break;
                        }
                    }
                }
                this.HitNet();
            }
            entry.Dispose();
        }

        private void buttonMerge_Click(object sender, EventArgs e)
        {
            if (this.dgvDO.Rows.Count > 0)
            {
                if (this.CommType != "G")
                {
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 >= this.dgvDO.Rows.Count)
                        {
                            this.hitungBTN();
                            break;
                        }
                        this.dgvDO.Rows.Remove(this.dgvDO.Rows[num2]);
                        num2++;
                    }
                }
                else if (MessageBox.Show("This will reset delivery letter. Are you sure? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    int num = 1;
                    while (true)
                    {
                        if (num >= this.dgvDO.Rows.Count)
                        {
                            this.hitungBTN();
                            this.dgvBatch.Rows.Clear();
                            break;
                        }
                        this.dgvDO.Rows.Remove(this.dgvDO.Rows[num]);
                        num++;
                    }
                }
            }
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            string[] source = new string[this.dgvDO.Rows.Count];
            int index = 0;
            bool flag = false;
            Cursor.Current = Cursors.WaitCursor;
            foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
            {
                if ((!string.IsNullOrEmpty(row.Cells["do_sap"].Value.ToString()) && ((row.Cells["do_sap"].Value != null) && !string.IsNullOrEmpty(row.Cells["do_sap_item"].Value.ToString()))) && (row.Cells["do_sap_item"].Value != null))
                {
                    string str = row.Cells["do_sap"].Value.ToString() + row.Cells["do_sap_item"].Value.ToString();
                    if (source.Contains<string>(str))
                    {
                        flag = true;
                        break;
                    }
                    source[index] = str;
                    index++;
                }
            }
            if (flag)
            {
                MessageBox.Show("There are two or more same DO SAP and DO SAP Item No.", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                if (this.Simpan())
                {
                    this.fCopra.Dispose();
                    base.Close();
                }
                Cursor.Current = Cursors.Default;
            }
            Cursor.Current = Cursors.Default;
        }

        private void buttonSavePrint_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.printTicket = true;
            if (this.Simpan())
            {
                this.fCopra.Dispose();
                base.Close();
            }
            Cursor.Current = Cursors.Default;
        }

        private void buttonScanCard_Click(object sender, EventArgs e)
        {
            if (!this.nfcReader.connected())
            {
                MessageBox.Show("Device not Connected or Card not Exist", "WARNING...");
            }
            else
            {
                string str = this.nfcReader.readCard();
                if (str != "0")
                {
                    MessageBox.Show("Error Read Card.. Please Check The Card..\n" + str, "ERROR...");
                }
                else
                {
                    this.textTruck.Text = ((this.nfcReader.getTruck() != null) || (this.nfcReader.getTruck() != "")) ? this.nfcReader.getTruck() : this.textTruck.Text;
                    this.textDriverID.Text = ((this.nfcReader.getDriverID() != null) || (this.nfcReader.getDriverID() != "")) ? this.nfcReader.getDriverID() : this.textDriverID.Text;
                    this.textDriverName.Text = ((this.nfcReader.getDriverName() != null) || (this.nfcReader.getDriverName() != "")) ? this.nfcReader.getDriverName() : this.textDriverName.Text;
                    this.textDN.Text = ((this.nfcReader.getSPB() != null) || (this.nfcReader.getSPB() != "")) ? this.nfcReader.getSPB() : this.textDN.Text;
                    this.textRemarkTicket.Text = ((this.nfcReader.getRemarkTicket() != null) || (this.nfcReader.getRemarkTicket() != "")) ? this.nfcReader.getRemarkTicket() : this.textRemarkTicket.Text;
                    this.textRemarkReport.Text = ((this.nfcReader.getRemarkReport() != null) || (this.nfcReader.getRemarkReport() != "")) ? this.nfcReader.getRemarkReport() : this.textRemarkReport.Text;
                    this.textSEAL.Text = ((this.nfcReader.getSeal() != null) || (this.nfcReader.getSeal() != "")) ? this.nfcReader.getSeal() : this.textSEAL.Text;
                    this.txtAddInfo.Text = ((this.nfcReader.getAddiInfo() != null) || (this.nfcReader.getAddiInfo() != "")) ? this.nfcReader.getAddiInfo() : this.txtAddInfo.Text;
                    this.textGrossEstate.Text = ((this.nfcReader.getGrossOPW() != null) || (this.nfcReader.getGrossOPW() != "")) ? this.nfcReader.getGrossOPW() : this.textGrossEstate.Text;
                    this.textGrossEstate.Text = (this.textGrossEstate.Text.Trim() == "") ? "0" : this.textGrossEstate.Text;
                    this.textTareEstate.Text = ((this.nfcReader.getTareOPW() != null) || (this.nfcReader.getTareOPW() != "")) ? this.nfcReader.getTareOPW() : this.textTareEstate.Text;
                    this.textTareEstate.Text = (this.textTareEstate.Text.Trim() == "") ? "0" : this.textTareEstate.Text;
                    this.textNetEstate.Text = ((this.nfcReader.getNetOPW() != null) || (this.nfcReader.getNetOPW() != "")) ? this.nfcReader.getNetOPW() : this.textNetEstate.Text;
                    this.textNetEstate.Text = (this.textNetEstate.Text.Trim() == "") ? "0" : this.textNetEstate.Text;
                    this.dateDelivery.Text = ((this.nfcReader.getDeliveryDate() != null) || (this.nfcReader.getDeliveryDate() != "")) ? this.nfcReader.getDeliveryDate() : this.dateDelivery.Text;
                    this.TimeDelivery.Text = ((this.nfcReader.getDeliveryTime() != null) || (this.nfcReader.getDeliveryTime() != "")) ? this.nfcReader.getDeliveryTime() : this.TimeDelivery.Text;
                    this.dateRegister.Text = ((this.nfcReader.getRegisterDate() != null) || (this.nfcReader.getRegisterDate() != "")) ? this.nfcReader.getRegisterDate() : this.dateRegister.Text;
                    this.TimeRegister.Text = ((this.nfcReader.getRegisterTime() != null) || (this.nfcReader.getRegisterTime() != "")) ? this.nfcReader.getRegisterTime() : this.TimeRegister.Text;
                    this.textBunchTotal.Text = ((this.nfcReader.getTotalBunch() != null) || (this.nfcReader.getTotalBunch() != "")) ? this.nfcReader.getTotalBunch() : this.textBunchTotal.Text;
                    this.textBunchTotal.Text = (this.textBunchTotal.Text.Trim() == "") ? "0" : this.textBunchTotal.Text;
                    this.textBunchDeduc.Text = ((this.nfcReader.getTotalBunchDeduc() != null) || (this.nfcReader.getTotalBunchDeduc() != "")) ? this.nfcReader.getTotalBunchDeduc() : this.textBunchDeduc.Text;
                    this.textBunchDeduc.Text = (this.textBunchDeduc.Text.Trim() == "") ? "0" : this.textBunchDeduc.Text;
                    this.textBunchDeduc.Text = (this.textBunchDeduc.Text == "0") ? this.textBunchTotal.Text : this.textBunchDeduc.Text;
                    this.textAvg.Text = ((this.nfcReader.getAVG() != null) || (this.nfcReader.getAVG() != "")) ? this.nfcReader.getAVG() : this.textAvg.Text;
                    this.textAvg.Text = (this.textAvg.Text.Trim() == "") ? "0" : this.textAvg.Text;
                    this.textRendCPO.Text = ((this.nfcReader.getRendCPO() != null) || (this.nfcReader.getRendCPO() != "")) ? this.nfcReader.getRendCPO() : this.textRendCPO.Text;
                    this.textRendCPO.Text = (this.textRendCPO.Text.Trim() == "") ? "0" : this.textRendCPO.Text;
                    this.textTBSReject.Text = ((this.nfcReader.getTBSRejectBunch() != null) || (this.nfcReader.getTBSRejectBunch() != "")) ? this.nfcReader.getTBSRejectBunch() : this.textTBSReject.Text;
                    this.textTBSReject.Text = (this.textTBSReject.Text.Trim() == "") ? "0" : this.textTBSReject.Text;
                    this.textBoxKG.Text = ((this.nfcReader.getTBSRejectKG() != null) || (this.nfcReader.getTBSRejectKG() != "")) ? this.nfcReader.getTBSRejectKG() : this.textBoxKG.Text;
                    this.textBoxKG.Text = (this.textBoxKG.Text.Trim() == "") ? "0" : this.textBoxKG.Text;
                    this.textReason.Text = ((this.nfcReader.getTBSRejectReason() != null) || (this.nfcReader.getTBSRejectReason() != "")) ? this.nfcReader.getTBSRejectReason() : this.textReason.Text;
                    this.textTransporter.Text = ((this.nfcReader.getTransporter() != null) || (this.nfcReader.getTransporter() != "")) ? this.nfcReader.getTransporter() : this.textTransporter.Text;
                    if (!this.validTruck())
                    {
                        MessageBox.Show("Truck Not Yet Registered in Truck Master.", "WARNING....");
                    }
                    if (!this.validTransporter())
                    {
                        MessageBox.Show("Transporter Not Yet Registered in Transporter Master.", "WARNING....");
                    }
                    if ((((this.pMode == "1ST") || ((this.pMode == "2ND") || ((this.pMode == "3RD") || (this.pMode == "4TH")))) || (this.WX == "")) && !this.checkTruckinYard(this.textTruck.Text, this.textTruck2.Text))
                    {
                    }
                    if (!this.validDriverID())
                    {
                        MessageBox.Show("Driver ID Not Yet Registered in Driver Master.", "WARNING....");
                    }
                }
            }
        }

        private void buttonStorage_Click(object sender, EventArgs e)
        {
            FormStorage storage = new FormStorage {
                pMode = "CHOOSE"
            };
            storage.ShowDialog();
            if (storage.ReturnRow != null)
            {
                this.textStorage.Text = storage.ReturnRow["Storage_Code"].ToString();
                this.labelStorageName.Text = storage.ReturnRow["Storage_Name"].ToString();
                this.textStorage.Focus();
            }
            storage.Dispose();
        }

        private void buttonTarraHistory_Click(object sender, EventArgs e)
        {
            FormTransactionTarraHistory history = new FormTransactionTarraHistory {
                truck_number = this.textTruck.Text
            };
            history.ShowDialog();
            history.Dispose();
        }

        private void calc_AverageDeducUnit()
        {
            this.totaldeducUnit = 0.0;
            this.totaldeducUnitQty = 0.0;
            this.unitName = "";
            this.averageWeightDeducUnit = 0.0;
            if (this.dgvDO.Rows.Count > 0)
            {
                this.unitName = this.dgvDO.Rows[0].Cells["UnitName"].Value.ToString();
                foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
                {
                    this.totaldeducUnit += Program.StrToDouble(row.Cells["TotalDeducUnit"].Value.ToString(), 0);
                    this.totaldeducUnitQty += Program.StrToDouble(row.Cells["DeducUnitQty"].Value.ToString(), 0);
                }
                if ((this.totaldeducUnit > 0.0) && (this.totaldeducUnitQty > 0.0))
                {
                    this.averageWeightDeducUnit = Math.Round((double) (this.totaldeducUnit / this.totaldeducUnitQty), 2);
                }
            }
        }

        private void calc_dl()
        {
            int num;
            int num2;
            if (this.text2nd.Text.Trim() == "0")
            {
                return;
            }
            else
            {
                num = 0;
                num2 = this.dgvDO.RowCount - 1;
            }
            while (true)
            {
                while (true)
                {
                    if (num2 >= 1)
                    {
                        DataGridViewRow row = this.dgvDO.Rows[num2];
                        int num3 = 0;
                        int num4 = this.dgvBatch.RowCount - 1;
                        while (true)
                        {
                            if (num4 >= 0)
                            {
                                DataGridViewRow row2 = this.dgvBatch.Rows[num4];
                                if (row2.Cells["SO_No"].Value.ToString().Trim() == row.Cells["Do_No"].Value.ToString().Trim())
                                {
                                    num3 += Convert.ToInt32(row2.Cells["Netto"].Value);
                                }
                                num4--;
                                continue;
                            }
                            if (num3 <= Convert.ToDouble(this.textNet.Text))
                            {
                                this.dgvDO.Rows[num2].Cells["Bruto"].Value = num3;
                                this.dgvDO.Rows[num2].Cells["Netto"].Value = num3;
                                num += Convert.ToInt32(this.dgvDO.Rows[num2].Cells["Bruto"].Value);
                                num2--;
                                continue;
                            }
                            else
                            {
                                MessageBox.Show("Netto delivery letter greater than Netto transaction");
                            }
                            break;
                        }
                    }
                    else if (this.WX == "2X")
                    {
                        if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text2nd.Text))
                        {
                            this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text1st.Text) - num;
                            this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text) - num;
                        }
                        else
                        {
                            this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text2nd.Text) - num;
                            this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text) - num;
                        }
                    }
                    else if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text4th.Text))
                    {
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text1st.Text) - num;
                        this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text) - num;
                    }
                    else
                    {
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text4th.Text) - num;
                        this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text) - num;
                    }
                    return;
                }
            }
        }

        private void calc_loadstuff()
        {
            if ((this.dgvDO.RowCount > 0) && (((this.text2nd.Text != "") || ((this.text2nd.Text != "0") || (this.text1st.Text != ""))) || (this.text1st.Text != "0")))
            {
                int num = 0;
                int num2 = 0;
                double num3 = 0.0;
                int num5 = this.dgvDO.RowCount - 1;
                while (true)
                {
                    if (num5 < 0)
                    {
                        num3 = Convert.ToDouble(this.textNet.Text) - Convert.ToDouble(num);
                        double num4 = 0.0;
                        int num6 = this.dgvDO.RowCount - 1;
                        while (true)
                        {
                            if (num6 < 1)
                            {
                                if (this.WX == "2X")
                                {
                                    if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text2nd.Text))
                                    {
                                        this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text1st.Text) - num2;
                                        this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text) - num2;
                                    }
                                    else
                                    {
                                        this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text2nd.Text) - num2;
                                        this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text) - num2;
                                    }
                                }
                                else if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text4th.Text))
                                {
                                    this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text1st.Text) - num2;
                                    this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text) - num2;
                                }
                                else
                                {
                                    this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text4th.Text) - num2;
                                    this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text) - num2;
                                }
                                if ((this.comboTransType.Text == "JUL") && ((this.dgvDO.Rows[0].Cells["internal_number"].Value.ToString() != "") || (this.dgvDO.Rows[0].Cells["do_sap"].Value.ToString() != "")))
                                {
                                    this.tblComm.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + this.dgvDO.Rows[0].Cells["Comm_code"].Value + "' and bulkpack = 'P' and upper(unit) = 'KG'"), WBData.conn);
                                    if (this.tblComm.DT.Rows.Count > 0)
                                    {
                                        this.dgvDO.Rows[0].Cells["loading_qty"].Value = this.dgvDO.Rows[0].Cells["Netto"].Value;
                                    }
                                }
                                if (WBSetting.activeTCS)
                                {
                                    this.proportionateReceivingbyOPW();
                                }
                                break;
                            }
                            DataGridViewRow row3 = this.dgvDO.Rows[num6];
                            num4 = ((Convert.ToDouble(this.dgvDO.Rows[num6].Cells["Bruto"].Value) <= 0.0) || (num == 0)) ? 0.0 : ((Convert.ToDouble(this.dgvDO.Rows[num6].Cells["Bruto"].Value) / ((double) num)) * num3);
                            this.dgvDO.Rows[num6].Cells["Bruto"].Value = Convert.ToInt32((double) (Convert.ToDouble(this.dgvDO.Rows[num6].Cells["Bruto"].Value) + num4));
                            this.dgvDO.Rows[num6].Cells["Netto"].Value = this.dgvDO.Rows[num6].Cells["Bruto"].Value;
                            num2 += Convert.ToInt32(this.dgvDO.Rows[num6].Cells["Bruto"].Value);
                            if ((this.comboTransType.Text == "JUL") && ((this.dgvDO.Rows[num6].Cells["internal_number"].Value.ToString() != "") || (this.dgvDO.Rows[num6].Cells["do_sap"].Value.ToString() != "")))
                            {
                                this.tblComm.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + this.dgvDO.Rows[num6].Cells["Comm_code"].Value + "' and bulkpack = 'P' and upper(unit) = 'KG'"), WBData.conn);
                                if (this.tblComm.DT.Rows.Count > 0)
                                {
                                    this.dgvDO.Rows[num6].Cells["loading_qty"].Value = this.dgvDO.Rows[num6].Cells["Netto"].Value;
                                }
                            }
                            num6--;
                        }
                        break;
                    }
                    DataGridViewRow row = this.dgvDO.Rows[num5];
                    if (this.dgvDO.Rows[num5].Cells["loading_qty"].Value == null)
                    {
                        this.dgvDO.Rows[num5].Cells["loading_qty"].Value = "0";
                    }
                    else if (this.dgvDO.Rows[num5].Cells["loading_qty"].Value.ToString() == "")
                    {
                        this.dgvDO.Rows[num5].Cells["loading_qty"].Value = "0";
                    }
                    this.tblComm.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + this.dgvDO.Rows[num5].Cells["Comm_code"].Value + "' and gross_weight is not null and unit <> 'KG' "), WBData.conn);
                    if (this.tblComm.DT.Rows.Count > 0)
                    {
                        DataRow row2 = this.tblComm.DT.Rows[0];
                        if ((row2["Gross_Weight"].ToString() != "0") && (row2["Gross_Weight"].ToString() != ""))
                        {
                            this.dgvDO.Rows[num5].Cells["Bruto"].Value = Convert.ToDouble(this.dgvDO.Rows[num5].Cells["loading_qty"].Value) * Convert.ToDouble(row2["Gross_Weight"].ToString());
                            this.dgvDO.Rows[num5].Cells["Netto"].Value = this.dgvDO.Rows[num5].Cells["Bruto"].Value;
                        }
                        num += Convert.ToInt32(Program.StrToDouble(this.dgvDO.Rows[num5].Cells["Bruto"].Value.ToString(), 0));
                    }
                    num5--;
                }
            }
        }

        private bool cek_grossWeight()
        {
            bool flag19;
            if (WBSetting.GrossWeightControl != "Y")
            {
                flag19 = true;
            }
            else
            {
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                WBTable table3 = new WBTable();
                WBTable table4 = new WBTable();
                WBCondition condition = new WBCondition();
                string str = "";
                double number = 0.0;
                double num8 = 0.0;
                double num = 0.0;
                int num9 = 0;
                bool flag2 = false;
                string str4 = "";
                double num10 = 0.0;
                double num11 = 0.0;
                double num12 = 0.0;
                double num15 = 0.0;
                double num16 = 0.0;
                string str5 = "";
                int num17 = 0;
                while (true)
                {
                    if (num17 >= this.dgvDO.Rows.Count)
                    {
                        num8 = Program.RoundbyTen(num8);
                        number = Program.RoundbyTen(number);
                        num16 = Program.RoundbyTen(num16);
                        num15 = Program.RoundbyTen(num15);
                        condition.Dispose();
                        if (!(((Convert.ToDouble(this.textNet.Text) > number) || (num8 > Convert.ToDouble(this.textNet.Text))) & flag2))
                        {
                            flag19 = true;
                        }
                        else
                        {
                            if ((this.dgvDO.Rows.Count == 1) && (table4.DT.Rows.Count > 0))
                            {
                                if ((Convert.ToDouble(this.textNet.Text) <= num15) && (num16 <= Convert.ToDouble(this.textNet.Text)))
                                {
                                    table4.DT.Rows[0].BeginEdit();
                                    table4.DT.Rows[0]["CountUsed"] = Convert.ToInt32(table4.DT.Rows[0]["CountUsed"].ToString().Trim()) + 1;
                                    table4.DT.Rows[0].EndEdit();
                                    table4.Save();
                                    flag19 = true;
                                    break;
                                }
                                str4 = str5;
                                number = num15;
                                num8 = num16;
                            }
                            str4 = ((str4 + "\nTotal Maximum Qty: " + number.ToString() + " KG") + "\nTotal Minimum Qty: " + num8.ToString() + " KG") + "\nTotal Transaction Qty : " + this.textNet.Text.ToString() + " KG";
                            double num18 = 0.0;
                            string str6 = "";
                            if (Convert.ToDouble(this.textNet.Text) > number)
                            {
                                num18 = Convert.ToDouble(this.textNet.Text) - number;
                                str4 = str4 + "\n\n Transaction Qty is Bigger than MAXIMUM Allowed Qty (" + Math.Round(num18, 0).ToString() + " KG)";
                                str6 = "Transaction Qty is Bigger than MAXIMUM Allowed Qty (" + Math.Round(num18, 0).ToString() + " KG)";
                            }
                            else if (num8 > Convert.ToDouble(this.textNet.Text))
                            {
                                num18 = num8 - Convert.ToDouble(this.textNet.Text);
                                str4 = str4 + "\n\n Transaction Qty is Smaller than MINIMUM Allowed Qty (" + Math.Round(num18, 0).ToString() + " KG)";
                                str6 = "Transaction Qty is Smaller than MINIMUM Allowed Qty (" + Math.Round(num18, 0).ToString() + " KG)";
                            }
                            if (FlexibleMessageBox.Show("\nTotal Gross Weight Commodity For This Transaction is Beyond Tolerance \n\n" + str4 + "\n\n To Save This Transaction Will Need Approval, Continue ?", "N O T I C E", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                            {
                                flag19 = false;
                            }
                            else
                            {
                                this.hasil = table.tokenOrApp(this.tblTrans.DT.Rows[0]["Ref"].ToString().Trim(), "", "OVER_GROSSQTY", "TOKEN_OVER_GROSSQTY", "OVER_GROSSQTY", "E", "", null);
                                if (this.hasil[0] != "completed")
                                {
                                    flag19 = false;
                                }
                                else
                                {
                                    this.approve = "Y";
                                    this.approveBy1 = this.hasil[1];
                                    this.ApproveReason = this.hasil[2];
                                    this.approve_type = "OVER_GROSSQTY";
                                    flag19 = true;
                                }
                            }
                        }
                        break;
                    }
                    if (this.dgvDO.Rows.Count == 1)
                    {
                        table4.OpenTable("wb_token", "Select top 1 * from wb_token where " + WBData.CompanyLocation(" and key_1 = '" + this.dgvDO.Rows[num17].Cells["DO_NO"].Value.ToString() + "' and completed = 'Y' and token_code = 'COMM_CONT_TOL'") + "order by key_1, datetime1 desc", WBData.conn);
                        if ((table4.DT.Rows.Count > 0) && ((table4.DT.Rows[0]["Unitoftrx"].ToString().Trim() == table4.DT.Rows[0]["countused"].ToString().Trim()) && (table4.DT.Rows[0]["Unitoftrx"].ToString().Trim() != "0")))
                        {
                            table4.DT.Rows.Clear();
                        }
                    }
                    table2.OpenTable("wb_do", "Select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + this.dgvDO.Rows[num17].Cells["DO_NO"].Value.ToString() + "'"), WBData.conn);
                    str = this.dgvDO.Rows[num17].Cells["Comm_code"].Value.ToString();
                    table.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + str + "' and gross_weight is not null"), WBData.conn);
                    DataRow row = table.DT.Rows[0];
                    table2.DR = table2.DT.Rows[0];
                    table2.DR["Transaction_code"] = this.dgvDO.Rows[num17].Cells["transaction_code"].Value.ToString();
                    DataRow[] dgRows = new DataRow[] { table2.DT.Rows[0], row };
                    condition.fillParameter("CHECK_GROSS_WEIGHT", dgRows);
                    if ((condition.getResult() && (row["UNIT"].ToString().Trim().ToUpper() != "KG")) && ((row["Gross_Weight"].ToString() != "0") && (row["Gross_Weight"].ToString() != "")))
                    {
                        if ((row["Tolerance"].ToString() == "0") && (row["Tolerance"].ToString() == ""))
                        {
                            row["Tolerance"] = "0";
                        }
                        flag2 = true;
                        num = Convert.ToDouble(row["Tolerance"]);
                        double num4 = Convert.ToDouble(row["Gross_Weight"]);
                        double num2 = num4 + ((num4 * num) / 100.0);
                        double num3 = num4 - ((num4 * num) / 100.0);
                        if ((this.dgvDO.Rows.Count == 1) && (table4.DT.Rows.Count > 0))
                        {
                            num10 = Convert.ToDouble(table4.DT.Rows[0]["Tolerance"].ToString().Trim());
                            num11 = num4 + ((num4 * num10) / 100.0);
                            num12 = num4 - ((num4 * num10) / 100.0);
                        }
                        number += num2 * Convert.ToInt32(this.dgvDO.Rows[num17].Cells["loading_qty"].Value);
                        num8 += num3 * Convert.ToInt32(this.dgvDO.Rows[num17].Cells["loading_qty"].Value);
                        double num6 = Program.RoundbyTen(num3 * Convert.ToInt32(this.dgvDO.Rows[num17].Cells["loading_qty"].Value));
                        double num5 = Program.RoundbyTen(num2 * Convert.ToInt32(this.dgvDO.Rows[num17].Cells["loading_qty"].Value));
                        num9 = Convert.ToInt32((double) (Convert.ToDouble(this.dgvDO.Rows[num17].Cells["loading_qty"].Value) * num4));
                        object[] objArray1 = new object[] { str4, "DO No ", this.dgvDO.Rows[num17].Cells["Do_No"].Value, " : " };
                        str4 = string.Concat(objArray1);
                        string[] textArray1 = new string[] { str4, "\nTotal Gross Weight : ", num9.ToString(), " ( Gross Weight @", row["Gross_Weight"].ToString(), " * Load Qty ", this.dgvDO.Rows[num17].Cells["loading_qty"].Value.ToString(), ")" };
                        str4 = string.Concat(textArray1);
                        string[] textArray2 = new string[] { str4, "\nMin : ", num6.ToString(), " (Tolerance ", num.ToString(), "% from Total )" };
                        str4 = string.Concat(textArray2);
                        string[] textArray3 = new string[] { str4, "\nMax : ", num5.ToString(), " (Tolerance ", num.ToString(), "% from Total )" };
                        str4 = string.Concat(textArray3);
                        num4 = ((this.dgvDO.Rows[num17].Cells["loading_qty"].Value.ToString() != "0") && (this.dgvDO.Rows[num17].Cells["loading_qty"].Value != null)) ? ((double) Convert.ToInt32((double) (Convert.ToDouble(this.dgvDO.Rows[num17].Cells["netto"].Value) / Convert.ToDouble(this.dgvDO.Rows[num17].Cells["loading_qty"].Value)))) : 0.0;
                        str4 = (str4 + "\nAverage Gross Weight per commodity : " + num4.ToString() + " KG") + "\n\n";
                        if ((this.dgvDO.Rows.Count == 1) && (table4.DT.Rows.Count > 0))
                        {
                            num15 += num11 * Convert.ToInt32(this.dgvDO.Rows[num17].Cells["loading_qty"].Value);
                            num16 += num12 * Convert.ToInt32(this.dgvDO.Rows[num17].Cells["loading_qty"].Value);
                            double num14 = Program.RoundbyTen(num12 * Convert.ToInt32(this.dgvDO.Rows[num17].Cells["loading_qty"].Value));
                            double num13 = Program.RoundbyTen(num11 * Convert.ToInt32(this.dgvDO.Rows[num17].Cells["loading_qty"].Value));
                            object[] objArray2 = new object[] { str5, "DO No ", this.dgvDO.Rows[num17].Cells["Do_No"].Value, " : " };
                            str5 = string.Concat(objArray2);
                            string[] textArray4 = new string[] { str5, "\nTotal Gross Weight : ", num9.ToString(), " ( Gross Weight @", row["Gross_Weight"].ToString(), " * Load Qty ", this.dgvDO.Rows[num17].Cells["loading_qty"].Value.ToString(), ")" };
                            str5 = string.Concat(textArray4);
                            string[] textArray5 = new string[] { str5, "\nMin : ", num14.ToString(), " (Tolerance ", num10.ToString(), "% from Total )" };
                            str5 = string.Concat(textArray5);
                            string[] textArray6 = new string[] { str5, "\nMax : ", num13.ToString(), " (Tolerance ", num10.ToString(), "% from Total )" };
                            str5 = (string.Concat(textArray6) + "\nAverage Gross Weight per commodity : " + num4.ToString() + " KG") + "\n\n";
                        }
                    }
                    num17++;
                }
            }
            return flag19;
        }

        private bool check_TankerCapacity()
        {
            bool flag4;
            double num2 = 0.0;
            double num3 = 0.0;
            this.tblTanker.ReOpen();
            string[] aField = new string[] { "Tanker_No" };
            string[] aFind = new string[] { this.textTanker.Text.Trim() };
            int recNo = this.tblTanker.GetRecNo(aField, aFind);
            if (recNo <= -1)
            {
                MessageBox.Show(Resource.Mes_628, Resource.Title_002);
                flag4 = false;
            }
            else
            {
                double num;
                this.textTanker.Text = this.tblTanker.DT.Rows[recNo]["Tanker_No"].ToString().Trim();
                this.labelTankerMax.Text = "Max.Tanker = " + $"{this.tblTanker.DT.Rows[recNo]["Capacity"].ToString().Trim():0,0}" + " Kg";
                string str = "" + ("\nMax Capacity Tanker : " + this.tblTanker.DT.Rows[recNo]["Capacity"].ToString().Trim());
                if (this.tblTanker.DT.Rows[recNo]["Check_Tanker"].ToString().Trim() != "P")
                {
                    if (this.tblTanker.DT.Rows[recNo]["Check_Tanker"].ToString().Trim() != "K")
                    {
                        return true;
                    }
                    else
                    {
                        num = Convert.ToDouble(this.tblTanker.DT.Rows[recNo]["CheckTankerKG"].ToString().Trim());
                        num3 = Program.RoundbyTen(Convert.ToDouble(this.tblTanker.DT.Rows[recNo]["Capacity"].ToString().Trim()) + num);
                        num2 = Program.RoundbyTen(Convert.ToDouble(this.tblTanker.DT.Rows[recNo]["Capacity"].ToString().Trim()) - num);
                        string[] textArray5 = new string[] { str, "\nMin : ", num2.ToString(), "KG (Tolerance : ", this.tblTanker.DT.Rows[recNo]["CheckTankerKG"].ToString().Trim(), "KG )" };
                        str = string.Concat(textArray5);
                        string[] textArray6 = new string[] { str, "\nMax : ", num3.ToString(), "KG (Tolerance : ", this.tblTanker.DT.Rows[recNo]["CheckTankerKG"].ToString().Trim(), "KG )" };
                        str = string.Concat(textArray6);
                    }
                }
                else
                {
                    num = Convert.ToDouble(this.tblTanker.DT.Rows[recNo]["CheckTankerTol"].ToString().Trim());
                    num3 = Program.RoundbyTen(Convert.ToDouble(this.tblTanker.DT.Rows[recNo]["Capacity"].ToString().Trim()) + ((Convert.ToDouble(this.tblTanker.DT.Rows[recNo]["Capacity"].ToString().Trim()) * num) / 100.0));
                    num2 = Program.RoundbyTen(Convert.ToDouble(this.tblTanker.DT.Rows[recNo]["Capacity"].ToString().Trim()) - ((Convert.ToDouble(this.tblTanker.DT.Rows[recNo]["Capacity"].ToString().Trim()) * num) / 100.0));
                    string[] textArray3 = new string[] { str, "\nMin : ", num2.ToString(), "KG (Tolerance : ", this.tblTanker.DT.Rows[recNo]["CheckTankerTol"].ToString().Trim(), "% )" };
                    str = string.Concat(textArray3);
                    string[] textArray4 = new string[] { str, "\nMax : ", num3.ToString(), "KG (Tolerance : ", this.tblTanker.DT.Rows[recNo]["CheckTankerTol"].ToString().Trim(), "% )" };
                    str = string.Concat(textArray4);
                }
                if ((Convert.ToDouble(this.textNet.Text) <= num3) && (num2 <= Convert.ToDouble(this.textNet.Text)))
                {
                    flag4 = true;
                }
                else
                {
                    str = str + "\nTransaction Qty : " + this.textNet.Text.ToString() + " KG";
                    double num5 = 0.0;
                    if (Convert.ToDouble(this.textNet.Text) > num3)
                    {
                        num5 = Convert.ToDouble(this.textNet.Text) - num3;
                        str = str + "\n\n Transaction Qty is Bigger than MAXIMUM Allowed Qty (" + Math.Round(num5, 0).ToString() + " KG)";
                    }
                    else if (num2 > Convert.ToDouble(this.textNet.Text))
                    {
                        num5 = num2 - Convert.ToDouble(this.textNet.Text);
                        str = str + "\n\n Transaction Qty is Smaller than MINIMUM Allowed Qty (" + Math.Round(num5, 0).ToString() + " KG)";
                    }
                    if (MessageBox.Show("\nTotal Tanker Capacity For This Transaction is Beyond Tolerance \n" + str + "\n\n To Save This Transaction Will Need Approval, Continue ?", "N O T I C E", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                    {
                        flag4 = false;
                    }
                    else
                    {
                        this.hasil = this.tblComm.tokenOrApp(this.tblTrans.DT.Rows[0]["Ref"].ToString().Trim(), "", "OVER_TANKER", "TOKEN_OVER_TANKER", "OVER_TANKER", "E", "", null);
                        if (this.hasil[0] != "completed")
                        {
                            flag4 = false;
                        }
                        else
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_tanker_log", "select * from wb_tanker_log where " + WBData.CompanyLocation("and 1 = 2 "), WBData.conn);
                            table.DR = table.DT.NewRow();
                            table.DR["coy"] = WBData.sCoyCode;
                            table.DR["location_code"] = WBData.sLocCode;
                            table.DR["DateTime"] = DateTime.Now.ToShortDateString();
                            table.DR["Ref"] = this.textRefNo.Text;
                            table.DR["tanker_no"] = this.textTanker.Text;
                            table.DR["max_cap"] = this.tblTanker.DT.Rows[recNo]["Capacity"].ToString().Trim();
                            table.DR["Net"] = Convert.ToDouble(this.textNet.Text);
                            table.DR["ReleaseBy"] = this.hasil[1];
                            table.DR["remark"] = this.hasil[2];
                            table.DT.Rows.Add(table.DR);
                            table.Save();
                            table.Dispose();
                            this.approve = "Y";
                            this.approveBy1 = this.hasil[1];
                            this.ApproveReason = this.hasil[2];
                            this.approve_type = "OVER_TANKER";
                            flag4 = true;
                        }
                    }
                }
            }
            return flag4;
        }

        private bool checkDoubleSPB()
        {
            bool flag = false;
            DateTime pTgl = Convert.ToDateTime(this.textRef_Date.Text);
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "select * from wb_transaction where ref_date = '", Program.DTOC(pTgl), "' and ref <> '", this.textRefNo.Text, "' and Delivery_note = '", this.textDN.Text, "'" };
            table.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
            flag = table.DT.Rows.Count > 0;
            table.Dispose();
            return flag;
        }

        private void CheckedChanged_checkNOPW(object sender, EventArgs e)
        {
            if (!this.checkNOPW.Checked)
            {
                this.textGrossEstate.Enabled = true;
                this.textTareEstate.Enabled = true;
            }
            else
            {
                this.textGrossEstate.Text = "0";
                this.textGrossEstate.Enabled = false;
                this.textTareEstate.Text = "0";
                this.textTareEstate.Enabled = false;
                this.textNetEstate.Text = "0";
                foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
                {
                    row.Cells["Estate_qty"].Value = "0";
                }
            }
        }

        private void checkEntryAVGorTotalBunch()
        {
            if (this.CommType == "F")
            {
                if (this.radioButtonEntryAVG.Checked)
                {
                    this.textAvg.ReadOnly = false;
                    this.textBunchTotal.ReadOnly = true;
                }
                else if (this.radioButtonEntryTotalBunch.Checked)
                {
                    this.textAvg.ReadOnly = true;
                    this.textBunchTotal.ReadOnly = false;
                }
            }
        }

        private void checkEntryDOforManual(TextBox weight)
        {
            if (((this.pMode == "MANUAL") && (this.dgvDO.RowCount < 1)) && (weight.Text != "0"))
            {
                MessageBox.Show("Please enter DO before fill in weight!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.tabControl1.SelectTab(this.tabPageDO);
                weight.Text = "0";
            }
        }

        private bool checkGrossHistoryControl()
        {
            string str = DateTime.Now.ToString("yyyy-MM-dd 00:00:00");
            string str2 = "";
            string sqltext = "";
            DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textDate1st.Text).ToShortDateString() + " " + Convert.ToDateTime(this.textTime1st.Text).ToString("HH:mm:ss"));
            double num = 0.0;
            double num2 = 0.0;
            int grossHistoryMinute = WBSetting.grossHistoryMinute;
            double grossHistoryVariance = WBSetting.grossHistoryVariance;
            double num5 = 0.0;
            double num6 = 0.0;
            string[] textArray1 = new string[] { " SELECT * from VW_TRANS  where ", WBData.CompanyLocation(""), " and (IO = 'I') and (Type = 'F')  and (deleted is null or deleted = '' or deleted = 'N')  and (ref_date = '", str, "')" };
            sqltext = string.Concat(textArray1);
            WBTable table = new WBTable();
            table.OpenTable("wb_transTmp", sqltext, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                using (IEnumerator enumerator = table.DT.Rows.GetEnumerator())
                {
                    while (true)
                    {
                        if (!enumerator.MoveNext())
                        {
                            break;
                        }
                        DataRow current = (DataRow) enumerator.Current;
                        str2 = current["time1"].ToString();
                        DateTime time2 = Convert.ToDateTime(str2);
                        TimeSpan span = (TimeSpan) (time2 - time);
                        num = Math.Round(Math.Abs(span.TotalMinutes), 0);
                        if (num <= grossHistoryMinute)
                        {
                            num2 = Program.StrToDouble(current["Bruto"].ToString(), 0);
                            num5 = num2 - grossHistoryVariance;
                            num6 = num2 + grossHistoryVariance;
                            if ((Program.StrToDouble(this.text1st.Text, 0) <= num6) && (Program.StrToDouble(this.text1st.Text, 0) >= num5))
                            {
                                string[] textArray2 = new string[11];
                                textArray2[0] = " Control Gross Weight Block !!  \nConflict With Ref No : ";
                                textArray2[1] = current["Ref"].ToString();
                                textArray2[2] = "  Gross Weight : ";
                                textArray2[3] = current["Bruto"].ToString();
                                textArray2[4] = " KG \nThis Transaction Gross Weight ";
                                textArray2[5] = this.text1st.Text;
                                textArray2[6] = " KG \nIs In Range of : ";
                                textArray2[7] = num5.ToString();
                                textArray2[8] = " KG - ";
                                textArray2[9] = num6.ToString();
                                textArray2[10] = " KG";
                                MessageBox.Show(string.Concat(textArray2));
                                return false;
                            }
                        }
                    }
                }
            }
            return true;
        }

        private void checkISCC_CheckedChanged(object sender, EventArgs e)
        {
            this.setISCC();
        }

        private void checkNonContract_CheckedChanged(object sender, EventArgs e)
        {
            this.textCust.Enabled = this.checkNonContract.Checked;
            this.buttonCust.Enabled = this.checkNonContract.Checked;
            if (!this.checkNonContract.Checked)
            {
                this.typeContract(0);
            }
            else if ((this.dgvDO.Rows.Count <= 0) || (MessageBox.Show("Checking This Option Will Erase DO, Are You Sure?", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.No))
            {
                this.typeContract(1);
                this.dgvDO.Rows.Clear();
            }
        }

        private bool checkOverQty()
        {
            bool flag;
            string str2;
            double num;
            string str4;
            string str5;
            float num2;
            WBTable table;
            DataRow row;
            int num4;
            double num5;
            string str6;
            string str7;
            string str8;
            string str10;
            double num6;
            double num9;
            int num14;
            if (!this.chk_return.Checked)
            {
                flag = false;
                str2 = "";
                num = 0.0;
                string str = "" + "( Do_no = '" + this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString() + "'";
                int num3 = 1;
                while (true)
                {
                    if (num3 >= this.dgvDO.Rows.Count)
                    {
                        str = str + ")";
                        table = new WBTable();
                        table.OpenTable("wb_tmpDOqty", "Select * from wb_contract where " + WBData.CompanyLocation(" and " + str), WBData.conn);
                        this.CloseDO = new string[this.dgvDO.Rows.Count];
                        num4 = 0;
                        break;
                    }
                    str = str + " OR Do_no = '" + this.dgvDO.Rows[num3].Cells["DO_NO"].Value.ToString() + "'";
                    num3++;
                }
            }
            else
            {
                return false;
            }
            goto TR_005C;
        TR_0002:
            table.Dispose();
            return flag;
        TR_0003:
            num4++;
            goto TR_005C;
        TR_0026:
            if (row["Check_qty"].ToString() == "Y")
            {
                num = this.countQtyLeft(str2, row, "Y");
                if (num5 <= num)
                {
                    if ((num5 >= (num - num9)) && (((this.textReport_Date.Text.Trim() != "") || (this.pMode == "2ND")) && ((WBSetting.AutoCloseDO == "Y") && (row["closed_date"].ToString() == ""))))
                    {
                        string[] textArray6 = new string[] { "DO No: ", str2, "\nDO Quantity: ", $"{row["Quantity"].ToString():N0}", " KG \nTolerance Percentage: ", $"{row["Tolerance"].ToString():N0}", " % \n\nThis DO has reach DO quantity and now will be automatically closed.\n(DO can be opened again from Master DO, if needed)" };
                        MessageBox.Show(string.Concat(textArray6), "DO Auto Close", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
                        this.CloseDO[num4] = row["uniq"].ToString();
                    }
                }
                else if ((str8 == "") || ReferenceEquals(str8, null))
                {
                    string[] textArray5 = new string[] { "Over Quantity ", (num5 - num).ToString(), " For DO = ", str2, ".\nPlease check again." };
                    MessageBox.Show(string.Concat(textArray5), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    flag = true;
                    goto TR_0002;
                }
            }
            string str11 = row["uniq"].ToString();
            if (this.dgvDO.Rows[num4].Cells["loading_qty"].Value == null)
            {
                this.dgvDO.Rows[num4].Cells["loading_qty"].Value = "0";
            }
            double num10 = Program.StrToDouble(this.dgvDO.Rows[num4].Cells["loading_qty"].Value.ToString(), 0);
            double num11 = 0.0;
            string str12 = this.dgvDO.Rows[num4].Cells["comm_code"].Value.ToString();
            string[] aField = new string[] { "Comm_Code" };
            string[] aFind = new string[] { str12 };
            DataRow data = this.tblComm.GetData(aField, aFind);
            float num12 = 0f;
            if ((str6 != "") || (str8 != ""))
            {
                if (str10 != "X")
                {
                    if (((str6 != "") && (str4 == "B")) && (str5.ToUpper() == "KG"))
                    {
                        num12 = float.Parse(data["netto_weight"].ToString());
                        num11 = Program.StrToDouble(this.dgvDO.Rows[num4].Cells["Netto"].Value.ToString(), 0);
                        if (((num6 < num11) && (this.spMode != "EDIT_OPW")) && ((num6.ToString() != "") && (num6.ToString() != "0")))
                        {
                            string[] textArray11 = new string[] { "Over Quantity DO SAP :  ", this.dgvDO.Rows[num4].Cells["do_sap"].Value.ToString(), "\nDO SAP Qty        = ", num6.ToString(), "\nLoading Qty Netto = ", num11.ToString() };
                            MessageBox.Show(string.Concat(textArray11), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            flag = true;
                            goto TR_0002;
                        }
                    }
                    if (((str8 != "") && (str4 == "B")) && (str5.ToUpper() == "KG"))
                    {
                        num11 = Program.StrToDouble(this.dgvDO.Rows[num4].Cells["Netto"].Value.ToString(), 0);
                        if ((num6 < num11) && ((this.spMode != "EDIT_OPW") && ((num6.ToString() != "") && (num6.ToString() != "0"))))
                        {
                            MessageBox.Show("Over Quantity Internal Number:\nInternal Number Qty = " + num6.ToString() + "\nNetto = " + num11.ToString(), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            flag = true;
                            goto TR_0002;
                        }
                    }
                    goto TR_0003;
                }
                else
                {
                    double num21;
                    string str13 = data["BulkPack"].ToString();
                    string str14 = data["Unit"].ToString();
                    num12 = float.Parse(data["netto_weight"].ToString());
                    string str15 = row["DeductedBy"].ToString();
                    string[] textArray9 = new string[] { " and do_sap = '", str6, "' AND do_sap_item = '", str7, "'" };
                    string sqltext = ((("SELECT " + " sum(NetFactory) as NetFactory , " + " sum(NetOther) as NetOther ,  ") + " sum(loading_qty) as loading_qty " + " from vw_outstanding ") + " WHERE " + WBData.CompanyLocation(string.Concat(textArray9))) + " and Ref <> '" + this.textRefNo.Text.Trim() + "' ";
                    WBTable table2 = new WBTable();
                    table2.OpenTable("vw_outstanding", sqltext, WBData.conn);
                    double num20 = 0.0;
                    double num22 = Program.StrToDouble(table2.DT.Rows[0]["loading_qty"].ToString(), 0);
                    if (str15 == "0")
                    {
                        num21 = Program.StrToDouble(table2.DT.Rows[0]["NetFactory"].ToString(), 0);
                        num11 = Program.StrToDouble(this.dgvDO.Rows[num4].Cells["Netto"].Value.ToString(), 0);
                    }
                    else if (str15 == "1")
                    {
                        num21 = Program.StrToDouble(table2.DT.Rows[0]["NetOther"].ToString(), 0);
                        num11 = !(Program.StrToDouble(this.dgvDO.Rows[num4].Cells["Estate_qty"].Value.ToString(), 0) == 0.0) ? Program.StrToDouble(this.dgvDO.Rows[num4].Cells["Estate_qty"].Value.ToString(), 0) : Program.StrToDouble(this.dgvDO.Rows[num4].Cells["Netto"].Value.ToString(), 0);
                    }
                    else
                    {
                        num21 = Program.StrToDouble(table2.DT.Rows[0]["NetFactory"].ToString(), 0);
                        num11 = Program.StrToDouble(this.dgvDO.Rows[num4].Cells["Netto"].Value.ToString(), 0);
                    }
                    num11 = Math.Round(num11, 0);
                    num20 = (str13 != "B") ? (num6 - ((num22 + num10) * num12)) : ((str14.ToUpper() != "KG") ? (num6 - ((num22 + num10) * num12)) : ((num6 - num21) - num11));
                    num20 = Math.Round(num20, 0);
                    if (num20 >= 0.0)
                    {
                        goto TR_0003;
                    }
                    else
                    {
                        if ((str13 != "B") || (str14.ToUpper() != "KG"))
                        {
                            if ((num6.ToString() != "") && (num6.ToString() != "0"))
                            {
                                object[] objArray1 = new object[12];
                                objArray1[0] = "Over Quantity DO SAP:\nDO SAP Qty = ";
                                objArray1[1] = num6.ToString();
                                objArray1[2] = "\nNetto Conversion = ";
                                objArray1[3] = num12.ToString();
                                objArray1[4] = "\nLoading Qty in other trans = ";
                                objArray1[5] = num22.ToString();
                                objArray1[6] = "\nLoading Qty in current trans = ";
                                objArray1[7] = num10.ToString();
                                objArray1[8] = "\nLoading Qty in KG = ";
                                objArray1[9] = (num22 + num10) * num12;
                                objArray1[10] = "\nOver Quantity: ";
                                objArray1[11] = Math.Abs(num20).ToString();
                                MessageBox.Show(string.Concat(objArray1), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                flag = true;
                                goto TR_0002;
                            }
                        }
                        else if ((this.spMode != "EDIT_OPW") && ((num6.ToString() != "") && (num6.ToString() != "0")))
                        {
                            string[] textArray10 = new string[] { "Over Quantity DO SAP:\nDO SAP Qty = ", num6.ToString(), "\nUsed Qty in other trans = ", num21.ToString(), "\nNetto current trans = ", num11.ToString(), "\nOver Quantity: ", Math.Abs(num20).ToString() };
                            MessageBox.Show(string.Concat(textArray10), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            flag = true;
                            goto TR_0002;
                        }
                        goto TR_0003;
                    }
                }
            }
            else
            {
                goto TR_0003;
            }
            goto TR_0002;
        TR_0035:
            num14++;
        TR_003E:
            while (true)
            {
                if (num14 >= this.dgvDO.Rows.Count)
                {
                    break;
                }
                if (this.dgvDO.Rows[num14].Cells["DO_NO"].Value.ToString() == str2)
                {
                    if (this.dgvDO.Rows[num14].Cells["Loading_Qty"].Value == null)
                    {
                        this.dgvDO.Rows[num14].Cells["Loading_Qty"].Value = "0";
                    }
                    if ((this.dgvDO.Rows[num14].Cells["Loading_Qty"].Value.ToString() != "0") && (this.dgvDO.Rows[num14].Cells["Loading_Qty"].Value.ToString() != ""))
                    {
                        double num15 = 0.0;
                        num15 = Program.StrToDouble(this.dgvDO.Rows[num14].Cells["Loading_Qty"].Value.ToString(), 0);
                        num5 += Math.Round((double) (num2 * num15), 0);
                        goto TR_0035;
                    }
                    else
                    {
                        MessageBox.Show("Please Entry Loading Qty For DO = " + str2 + ".\nThank you.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        flag = true;
                    }
                    break;
                }
                goto TR_0035;
            }
            goto TR_0026;
        TR_005C:
            while (true)
            {
                if (num4 >= this.dgvDO.Rows.Count)
                {
                    break;
                }
                num5 = 0.0;
                str6 = this.dgvDO.Rows[num4].Cells["do_sap"].Value.ToString();
                str7 = this.dgvDO.Rows[num4].Cells["do_sap_item"].Value.ToString();
                str8 = this.dgvDO.Rows[num4].Cells["internal_number"].Value.ToString();
                string str9 = this.dgvDO.Rows[num4].Cells["internal_number_item"].Value.ToString();
                str10 = this.dgvDO.Rows[num4].Cells["do_besar"].Value.ToString();
                num6 = Program.StrToDouble(this.dgvDO.Rows[num4].Cells["do_qty_kg"].Value.ToString(), 0);
                double num7 = Program.StrToDouble(this.dgvDO.Rows[num4].Cells["do_base_qty"].Value.ToString(), 0);
                str2 = this.dgvDO.Rows[num4].Cells["do_no"].Value.ToString();
                string[] textArray1 = new string[] { "DO_NO" };
                string[] textArray2 = new string[] { str2 };
                row = table.GetData(textArray1, textArray2);
                if (row["so_item"].ToString().Trim() != "*")
                {
                    double num8 = double.Parse(row["quantity"].ToString());
                    num9 = (double.Parse(row["tolerance"].ToString()) / 100.0) * num8;
                    this.tblComm.OpenTable("wb_comm", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.dgvDO.Rows[num4].Cells["Comm_code"].Value.ToString() + "'"), WBData.conn);
                    string[] textArray3 = new string[] { "comm_code" };
                    string[] textArray4 = new string[] { this.dgvDO.Rows[num4].Cells["comm_code"].Value.ToString() };
                    DataRow row2 = this.tblComm.GetData(textArray3, textArray4);
                    string str3 = row2["type"].ToString();
                    str4 = row2["bulkpack"].ToString();
                    str5 = row2["Unit"].ToString();
                    num2 = (row2["netto_weight"].ToString().Trim() == "") ? 0f : float.Parse(row2["netto_weight"].ToString());
                    if (((str3 != "S") && (str3 != "C")) && (str3 != "F"))
                    {
                        if (str3 == "G")
                        {
                            int num18 = this.dgvBatch.RowCount - 1;
                            while (true)
                            {
                                if (num18 < 0)
                                {
                                    break;
                                }
                                DataGridViewRow row4 = this.dgvBatch.Rows[num18];
                                if (row4.Cells["SO_No"].Value.ToString().Trim() == str2)
                                {
                                    num5 += Program.StrToDouble(this.dgvBatch.Rows[num18].Cells["Netto"].Value.ToString(), 0);
                                }
                                num18--;
                            }
                        }
                        goto TR_0026;
                    }
                    else if ((str4 != "B") || ((str5 != "KG") && (str5 != "")))
                    {
                        if (((str4 != "B") || (str5 == "")) || (str3 == "KG"))
                        {
                            if (str4 == "P")
                            {
                                int num16 = 0;
                                while (true)
                                {
                                    if (num16 >= this.dgvDO.Rows.Count)
                                    {
                                        break;
                                    }
                                    if (this.dgvDO.Rows[num16].Cells["DO_NO"].Value.ToString() == str2)
                                    {
                                        if (this.dgvDO.Rows[num16].Cells["Loading_Qty"].Value == null)
                                        {
                                            this.dgvDO.Rows[num16].Cells["Loading_Qty"].Value = "0";
                                        }
                                        double num17 = 0.0;
                                        num17 = Program.StrToDouble(this.dgvDO.Rows[num16].Cells["Loading_Qty"].Value.ToString(), 0);
                                        num5 += Math.Truncate((double) ((num2 * num17) * 10.0)) / 10.0;
                                    }
                                    num16++;
                                }
                            }
                            goto TR_0026;
                        }
                        else
                        {
                            num14 = 0;
                        }
                    }
                    else
                    {
                        int num13 = 0;
                        while (true)
                        {
                            if (num13 >= this.dgvDO.Rows.Count)
                            {
                                break;
                            }
                            if (this.dgvDO.Rows[num13].Cells["DO_NO"].Value.ToString() == str2)
                            {
                                if (row["Deductedby"].ToString() == "0")
                                {
                                    num5 += Program.StrToDouble(this.dgvDO.Rows[num13].Cells["Netto"].Value.ToString(), 0);
                                }
                                else if (row["Deductedby"].ToString() == "1")
                                {
                                    num5 += Program.StrToDouble(this.dgvDO.Rows[num13].Cells["Estate_qty"].Value.ToString(), 0);
                                    if ((Program.StrToDouble(this.dgvDO.Rows[num13].Cells["Estate_qty"].Value.ToString(), 0) == 0.0) && (Program.StrToDouble(this.dgvDO.Rows[num13].Cells["Return_Qty_KG"].Value.ToString(), 0) == 0.0))
                                    {
                                        num5 += Program.StrToDouble(this.dgvDO.Rows[num13].Cells["Netto"].Value.ToString(), 0);
                                    }
                                }
                            }
                            num13++;
                        }
                        goto TR_0026;
                    }
                    goto TR_003E;
                }
                goto TR_0003;
            }
            goto TR_0002;
        }

        private bool checkQtySplitDO()
        {
            double num = 0.0;
            double num2 = 0.0;
            double num3 = 0.0;
            double num4 = 0.0;
            num2 = Program.StrToDouble(this.textNet.Text, 0);
            num4 = Program.StrToDouble(this.textNetEstate.Text, 0);
            int num5 = 0;
            while (true)
            {
                if (num5 >= this.dgvDO.Rows.Count)
                {
                    bool flag3;
                    if (!(num == num2))
                    {
                        MessageBox.Show("Total Net Split DO and Net Transaction differen. Please Check DO...", "Notice...");
                        flag3 = false;
                    }
                    else if (num3 == num4)
                    {
                        flag3 = true;
                    }
                    else
                    {
                        MessageBox.Show("Total Other Net Split DO and Other Net Transaction different. Please Check DO...", "Notice...");
                        flag3 = false;
                    }
                    return flag3;
                }
                num += Program.StrToDouble(this.dgvDO.Rows[num5].Cells["Netto"].Value.ToString(), 0);
                num3 += Program.StrToDouble(this.dgvDO.Rows[num5].Cells["Estate_Qty"].Value.ToString(), 0);
                num5++;
            }
        }

        private bool CheckSPB()
        {
            using (IEnumerator enumerator = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                    string s = this.textDN.Text.Trim();
                    string str2 = Convert_to_Regex(s);
                    WBTable table = new WBTable();
                    string[] textArray1 = new string[] { "Select * From wb_delivery_note where Do_No='", current.Cells["DO_No"].Value.ToString().Trim(), "' and Delivery_Note_From like '", str2, "' and Delivery_Note_to like '", str2, "'" };
                    table.OpenTable("wb_delivery_note", string.Concat(textArray1), WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num >= table.DT.Rows.Count)
                            {
                                break;
                            }
                            table.DR = table.DT.Rows[num];
                            if ((string.Compare(s, table.DR["Delivery_Note_From"].ToString()) < 0) || (string.Compare(s, table.DR["Delivery_Note_to"].ToString()) > 0))
                            {
                                num++;
                                continue;
                            }
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        private bool checkTare()
        {
            bool flag = false;
            string str = "0";
            string str2 = "0";
            string[] aField = new string[] { "Truck_Number" };
            string[] aFind = new string[] { this.textTruck.Text };
            int recNo = this.tblTruck.GetRecNo(aField, aFind);
            if (recNo > -1)
            {
                this.maxTare = this.tblTruck.DT.Rows[recNo]["max_Tare"].ToString();
                this.minTare = this.tblTruck.DT.Rows[recNo]["min_Tare"].ToString();
            }
            if (this.maxTare.Length <= 0)
            {
                this.maxTare = "0";
            }
            if (this.minTare.Length <= 0)
            {
                this.minTare = "0";
            }
            if (this.pMode == "2ND")
            {
                str = (Convert.ToDouble(this.text1st.Text) <= Convert.ToDouble(this.text2nd.Text)) ? this.text2nd.Text : this.text1st.Text;
                str2 = Convert.ToString(Math.Abs((double) (Convert.ToDouble(str) - Convert.ToDouble(this.textNet.Text))));
            }
            if (this.pMode == "1ST")
            {
                str2 = (this.transType != "I") ? this.text1st.Text : this.text2nd.Text;
            }
            flag = (Convert.ToDouble(str2) >= Convert.ToDouble(this.minTare)) & (Convert.ToDouble(str2) <= Convert.ToDouble(this.maxTare));
            if (Convert.ToDouble(str2) == 0.0)
            {
                flag = true;
            }
            if ((this.tblTruck.DT.Rows[recNo]["lastCheck"].ToString().Length <= 0) & !flag)
            {
                flag = true;
            }
            return flag;
        }

        private bool checkTruckinYard(string truckNumber, string truckNumber2)
        {
            bool flag = false;
            string sqltext = "";
            WBTable table = new WBTable();
            string[] textArray1 = new string[11];
            textArray1[0] = "Select * from wb_transaction where ";
            textArray1[1] = WBData.CompanyLocation("");
            textArray1[2] = " and (truck_number = '";
            textArray1[3] = truckNumber.Trim();
            textArray1[4] = "' or truck_number = '";
            textArray1[5] = truckNumber2.Trim();
            textArray1[6] = "' or truck_number2 = '";
            textArray1[7] = truckNumber.Trim();
            textArray1[8] = "' or truck_number2 = '";
            textArray1[9] = truckNumber2.Trim();
            textArray1[10] = "') and (deleted is null or deleted = 'N') and ( mark_accident IS NULL OR mark_accident = '' or mark_accident = 'N' ) and (_2nd=0 or( WX='4X' and _3rd <> 0 and _4th=0)) and report_date is null  and (ref not like 'X%' or (linked is null or linked = ''))";
            sqltext = string.Concat(textArray1);
            table.OpenTable("wb_truck", sqltext, WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                if (this.textRefNo.Text.Trim() == row["ref"].ToString().Trim())
                {
                    flag = false;
                    continue;
                }
                if (((this.WX == "") || (this.pMode == "1ST")) || (this.pMode == "2ND"))
                {
                    if ((row["_2nd"].ToString() == "0") && (row["truck_number"].ToString() == truckNumber))
                    {
                        flag = true;
                        string[] textArray2 = new string[] { "Truck ", truckNumber, " is still in yard with Reference No ", row["ref"].ToString(), "! Please check truck number!" };
                        MessageBox.Show(string.Concat(textArray2), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        if (((row["_3rd"].ToString() == "0") || ((row["_4th"].ToString() != "0") || (row["wx"].ToString() != "4X"))) || (row["truck_number2"].ToString() != truckNumber))
                        {
                            flag = false;
                            continue;
                        }
                        flag = true;
                        string[] textArray3 = new string[] { "Truck ", truckNumber, " is still in yard with Reference No ", row["ref"].ToString(), "! Please check truck number!" };
                        MessageBox.Show(string.Concat(textArray3), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                else
                {
                    if ((this.pMode != "3RD") && (this.pMode != "4TH"))
                    {
                        flag = false;
                        continue;
                    }
                    if (((row["_2nd"].ToString() == "0") && (row["truck_number"].ToString() == truckNumber2)) && (truckNumber2 != ""))
                    {
                        flag = true;
                        string[] textArray4 = new string[] { "Truck ", truckNumber2, " is still in yard with Reference No ", row["ref"].ToString(), "! Please check truck number 2!" };
                        MessageBox.Show(string.Concat(textArray4), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        if (((row["_3rd"].ToString() == "0") || ((row["_4th"].ToString() != "0") || ((row["wx"].ToString() != "4X") || (row["truck_number2"].ToString() != truckNumber2)))) || (truckNumber2 == ""))
                        {
                            flag = false;
                            continue;
                        }
                        flag = true;
                        string[] textArray5 = new string[] { "Truck ", truckNumber2, " is still in yard with Reference No ", row["ref"].ToString(), "! Please check truck number 2!" };
                        MessageBox.Show(string.Concat(textArray5), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                break;
            }
            table.Dispose();
            return flag;
        }

        private void chk_return_CheckedChanged(object sender, EventArgs e)
        {
            this.text_ref_return.Text = "";
            this.ref_return_valid = false;
            if (this.chk_return.Checked)
            {
                this.panel_return.Visible = true;
                this.panel_return.Enabled = true;
                this.sh_return.OpenTable("wb_transaction", "SELECT transaction_code, ref, do_no, report_date, comm_code, gross, tare, net, delivery_date FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND (mark_return = '' OR mark_return IS null) AND (report_date IS NOT NULL) ORDER BY ref"), WBData.conn);
                if (this.sh_return.DT.Rows.Count > 0)
                {
                    Program.AutoComp(this.sh_return, "ref", this.text_ref_return);
                }
                this.buttonEditDO.Enabled = false;
                this.buttonAddDO.Enabled = false;
            }
            else
            {
                this.panel_return.Visible = false;
                if (this.dgvDO.RowCount > 0)
                {
                    string str = this.dgvDO.Rows[0].Cells["DO_No"].Value.ToString();
                    WBTable table = new WBTable();
                    table.OpenTable("wb_tmpDO", "Select * from wb_contract where " + WBData.CompanyLocation(" and do_no = '" + str + "'"), WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        table.DR = table.DT.Rows[0];
                        this.dgvDO.CurrentRow.Cells["transaction_code"].Value = table.DR["transaction_code"].ToString();
                        this.comboTransType.Text = table.DR["transaction_code"].ToString();
                        this.TransType();
                    }
                }
                if ((this.pMode != "SPLIT") && (this.pMode != "DL"))
                {
                    this.buttonEditDO.Enabled = true;
                }
                this.buttonAddDO.Enabled = true;
            }
        }

        private void combodgvDO_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = '\0';
        }

        private void combodgvDO_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.dgvQC.Rows.Count > 0)
            {
                this.textQControl.Text = this.dgvQC.Rows[0].Cells["QualityControl"].Value.ToString();
            }
        }

        private void comTransType_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = '\0';
        }

        private void comTransType_Leave(object sender, EventArgs e)
        {
            this.TransType();
        }

        private void comTransType_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.TransType();
        }

        private static string Convert_to_Regex(string s)
        {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
            {
                bool flag1;
                if (s[i].Equals('0') || (s[i].Equals('1') || (s[i].Equals('2') || (s[i].Equals('3') || (s[i].Equals('4') || (s[i].Equals('5') || (s[i].Equals('6') || (s[i].Equals('7') || s[i].Equals('8')))))))))
                {
                    flag1 = true;
                }
                else
                {
                    flag1 = s[i].Equals('9');
                }
                if (flag1)
                {
                    builder.Append("[0-9]");
                }
                else
                {
                    builder.Append(s[i]);
                }
            }
            return builder.ToString();
        }

        private double countQtyLeft(string pDoNo, DataRow dr_DO, string tolerance)
        {
            string str;
            double num = 0.0;
            this.tblComm.OpenTable("wb_comm", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + dr_DO["comm_code"].ToString() + "'"), WBData.conn);
            string[] aField = new string[] { "comm_code" };
            string[] aFind = new string[] { dr_DO["comm_code"].ToString() };
            DataRow data = this.tblComm.GetData(aField, aFind);
            if (data == null)
            {
                str = "N";
            }
            else
            {
                str = data["using_gunny"].ToString();
                this.CommType = data["Type"].ToString();
            }
            if (str == "Y")
            {
                num = (tolerance != "N") ? Program.checkOSbyGunny(pDoNo, "", this.textRefNo.Text, "Y") : Program.checkOSbyGunny(pDoNo, "", this.textRefNo.Text, "N");
            }
            else
            {
                num = (tolerance != "N") ? Program.checkOS(pDoNo, "", this.textRefNo.Text, "Y") : Program.checkOS(pDoNo, "", this.textRefNo.Text, "N");
                if (dr_DO["deductedBy"].ToString() == "1")
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_transaction_type", "SELECT * FROM wb_transaction_type WHERE " + WBData.CompanyLocation(""), WBData.conn);
                    string[] textArray3 = new string[] { "Transaction_Code" };
                    string[] textArray4 = new string[] { dr_DO["transaction_code"].ToString() };
                    this.rowTransType = table.GetData(textArray3, textArray4);
                    if ((this.rowTransType != null) && (this.rowTransType["IO"].ToString().Trim().ToUpper() == "I"))
                    {
                        num -= Convert.ToDouble(Convert.ToDouble($"{Program.checkQtyUsedOngoingOPW(pDoNo, "", this.textRefNo.Text, "", ""):N0}"));
                    }
                    table.Dispose();
                }
            }
            return num;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            for (int i = this.dgvBatch.RowCount - 1; i >= 0; i--)
            {
                DataGridViewRow row = this.dgvBatch.Rows[i];
                bool flag = row.Cells["SO_No"].Value.ToString().Trim() == this.dgvListDO.CurrentRow.Cells["Do_No"].Value.ToString().Trim();
                this.dgvBatch.Rows[i].Visible = flag;
            }
        }

        private DataGridView DGV_Copy(DataGridView dgv1, DataGridView dgv2, string pRef)
        {
            dgv2.Rows.Clear();
            int count = 0;
            for (int i = 0; i < dgv1.Rows.Count; i++)
            {
                if (dgv1.Rows[i].Cells["Ref"].Value.ToString() == pRef)
                {
                    count = dgv2.Rows.Count;
                    dgv2.Rows.Add();
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= dgv2.ColumnCount)
                        {
                            break;
                        }
                        dgv2[num3, count].Value = dgv1[num3, i].Value;
                        if (dgv2[num3, count].Value == null)
                        {
                            dgv2[num3, count].Value = 0;
                        }
                        num3++;
                    }
                }
            }
            return dgv2;
        }

        private void dgvBatch_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            int index = this.dgvBatch.Columns["Num_Of_Gunny"].Index;
            int num2 = this.dgvBatch.Columns["Netto"].Index;
            if (this.dgvBatch.CurrentCell.ColumnIndex == index)
            {
                this.dgvBatch.CurrentRow.Cells["Netto"].Value = "";
            }
            if (this.dgvBatch.CurrentCell.ColumnIndex == num2)
            {
                this.dgvBatch.CurrentRow.Cells["Num_of_Gunny"].Value = "";
            }
        }

        private void dgvBatch_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.button20.Text = (this.dgvBatch.Rows.Count != 1) ? "Merge" : "Delete";
        }

        private void dgvBatch_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            int num;
            if ((this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Num_of_Gunny"].Value != null) && (this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Num_of_Gunny"].Value.ToString().Trim() != ""))
            {
                try
                {
                    num = Convert.ToInt32(this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Num_of_Gunny"].Value.ToString().Trim()) * Convert.ToInt32(this.textBox1.Text);
                    this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Netto"].Value = num.ToString();
                }
                catch
                {
                    MessageBox.Show("Invalid Entry");
                    this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Netto"].Value = "";
                }
            }
            if ((this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Netto"].Value != null) && (this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Netto"].Value.ToString().Trim() != ""))
            {
                try
                {
                    num = Convert.ToInt32(this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Netto"].Value.ToString().Trim()) / Convert.ToInt32(this.textBox1.Text);
                    this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Num_of_Gunny"].Value = num.ToString();
                }
                catch
                {
                    MessageBox.Show("Invalid Entry");
                    this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Netto"].Value = "";
                }
            }
            if ((this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Item_No"].Value != null) && (this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Item_No"].Value.ToString().Trim() != ""))
            {
                try
                {
                    num = Convert.ToInt32(this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Item_No"].Value.ToString().Trim());
                    this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Item_No"].Value = num.ToString().PadLeft(5, '0');
                }
                catch
                {
                    MessageBox.Show("Invalid Entry");
                    this.dgvBatch.Rows[this.dgvBatch.CurrentRow.Index].Cells["Item_No"].Value = "";
                }
            }
            int num2 = 0;
            foreach (DataGridViewRow row in (IEnumerable) this.dgvBatch.Rows)
            {
                try
                {
                    num2 += Convert.ToInt32(row.Cells["Netto"].Value);
                }
                catch
                {
                    num2 = num2;
                }
            }
            this.textNettoBatch.Text = num2.ToString();
            this.textNettoBatch_Leave(this, e);
            this.text2nd_Leave(this, e);
        }

        private void dgvDeduc_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.buttonEditDeduc.PerformClick();
        }

        private void dgvDeducPorla_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.buttonEditPorla.PerformClick();
        }

        private void dgvDO_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            WBTable table = new WBTable();
            if ((e.ColumnIndex == this.dgvDO.Columns["comm_code"].Index) && (e.Value != null))
            {
                DataGridViewCell cell = this.dgvDO.Rows[e.RowIndex].Cells[e.ColumnIndex];
                table.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + e.Value.ToString().Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    cell.ToolTipText = table.DT.Rows[0]["comm_name"].ToString();
                }
            }
        }

        private void dgvDO_SelectionChanged(object sender, EventArgs e)
        {
            if ((this.pMode == "SPLIT") || (this.pMode == "DL"))
            {
                this.buttonEditDO.Enabled = this.dgvDO.CurrentRow.Index.ToString() != "0";
            }
        }

        private void dgvQC_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            string[] aField = new string[] { "Yield_Code" };
            string[] aFind = new string[] { this.dgvQC.Rows[this.dgvQC.CurrentCell.RowIndex].Cells["Qcode"].Value.ToString() };
            DataRow data = this.tblQC.GetData(aField, aFind);
            if (data["Type"].ToString() != "1")
            {
                if (((this.dgvQC.CurrentCell.Value != null) && (this.dgvQC.CurrentCell.Value.ToString() != "")) && (this.dgvQC.CurrentCell.Value.ToString().Length > 10))
                {
                    MessageBox.Show("Maximum length of this field is 10!", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    this.dgvQC_SaveItem(this.dgvQC.CurrentRow, data["Type"].ToString());
                }
            }
            else
            {
                try
                {
                    if (((float) Convert.ToDouble(this.dgvQC.CurrentCell.Value.ToString())) > 99.999)
                    {
                        MessageBox.Show("Wrong format entry! Format is '##.###'.   ", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.dgvQC.CurrentCell.Value = "0";
                    }
                    else
                    {
                        if (((WBSetting.checkOutSpec == "Y") && (this.transType == "I")) && (e.ColumnIndex == this.dgvQC.Columns["Factory"].Index))
                        {
                            this.tblCommD.ReOpen();
                            string[] textArray3 = new string[] { "Coy", "Location_Code", "Comm_Code", "QCode" };
                            string[] textArray4 = new string[] { WBData.sCoyCode, WBData.sLocCode, this.dgvQC.Rows[this.dgvQC.CurrentCell.RowIndex].Cells["Comm_Code"].Value.ToString(), this.dgvQC.Rows[this.dgvQC.CurrentCell.RowIndex].Cells["QCode"].Value.ToString() };
                            if (Convert.ToBoolean(this.tblCommD.GetData(textArray3, textArray4)["checked"].ToString()))
                            {
                                double num2 = Program.StrToDouble(this.dgvQC.CurrentCell.Value.ToString(), 3);
                                double num3 = Program.StrToDouble(this.dgvQC.Rows[this.dgvQC.CurrentCell.RowIndex].Cells["SAP_Value"].Value.ToString(), 3);
                                if ((num2 > num3) && !(num3 == 0.0))
                                {
                                    string[] textArray5 = new string[] { "Quality ", this.dgvQC.Rows[this.dgvQC.CurrentCell.RowIndex].Cells["QCode"].Value.ToString(), " for commodity ", this.dgvQC.Rows[this.dgvQC.CurrentCell.RowIndex].Cells["Comm_Code"].Value.ToString(), " is out of specification.\nContract specification: ", num3.ToString(), "\nFactory value: ", num2.ToString() };
                                    MessageBox.Show(string.Concat(textArray5), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }
                            }
                        }
                        this.dgvQC.CurrentCell.Value = Convert.ToString(Program.StrToDouble(this.dgvQC.CurrentCell.Value.ToString(), 3));
                        this.dgvQC_SaveItem(this.dgvQC.CurrentRow, data["Type"].ToString());
                    }
                }
                catch
                {
                    MessageBox.Show("This field requires numerical entry!", "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.dgvQC.CurrentCell.Value = "";
                }
            }
        }

        private void dgvQC_DoubleClick(object sender, EventArgs e)
        {
        }

        private void dgvQC_SaveItem(DataGridViewRow pRow, string type)
        {
            int num = 0;
            while (true)
            {
                while (true)
                {
                    if (num >= this.dgvQC_All.Rows.Count)
                    {
                        return;
                    }
                    if (((this.dgvQC_All.Rows[num].Cells["Ref"].Value == pRow.Cells["Ref"].Value) && (this.dgvQC_All.Rows[num].Cells["QCode"].Value == pRow.Cells["QCode"].Value)) && (this.dgvQC_All.Rows[num].Cells["QName"].Value == pRow.Cells["QName"].Value))
                    {
                        if (type == "1")
                        {
                            this.dgvQC_All.Rows[num].Cells["Estate"].Value = ((pRow.Cells["Estate"].Value == null) || (pRow.Cells["Estate"].Value.ToString() == "")) ? "0" : $"{Program.StrToDouble(pRow.Cells["Estate"].Value.ToString(), 3):N3}";
                            this.dgvQC_All.Rows[num].Cells["Factory"].Value = ((pRow.Cells["Factory"].Value == null) || (pRow.Cells["Factory"].Value.ToString() == "")) ? "" : $"{Program.StrToDouble(pRow.Cells["Factory"].Value.ToString(), 3):N3}";
                            try
                            {
                                this.dgvQC_All.Rows[num].Cells["SAP_Value"].Value = (pRow.Cells["SAP_Value"].Value != null) ? $"{Program.StrToDouble(pRow.Cells["SAP_Value"].Value.ToString(), 3):N3}" : "0";
                            }
                            catch (Exception)
                            {
                                this.dgvQC_All.Rows[num].Cells["SAP_Value"].Value = pRow.Cells["SAP_Value"].Value.ToString();
                            }
                        }
                        else
                        {
                            this.dgvQC_All.Rows[num].Cells["Estate"].Value = (pRow.Cells["Estate"].Value.ToString() != "") ? pRow.Cells["Estate"].Value.ToString() : "0";
                            this.dgvQC_All.Rows[num].Cells["Factory"].Value = (pRow.Cells["Factory"].Value.ToString() != "") ? pRow.Cells["Factory"].Value.ToString() : "0";
                            try
                            {
                                this.dgvQC_All.Rows[num].Cells["SAP_Value"].Value = (pRow.Cells["SAP_Value"].Value != null) ? $"{Program.StrToDouble(pRow.Cells["SAP_Value"].Value.ToString(), 3):N3}" : "0";
                            }
                            catch (Exception)
                            {
                                this.dgvQC_All.Rows[num].Cells["SAP_Value"].Value = pRow.Cells["SAP_Value"].Value.ToString();
                            }
                        }
                    }
                    break;
                }
                this.ChangeQC = true;
                num++;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool editWarning()
        {
            this.editTrace = "";
            bool flag = false;
            this.tblTrans.ReOpen();
            this.tblTrans.DR = this.tblTrans.DT.Rows[0];
            this.tblTransDO.ReOpen();
            foreach (DataRow row in this.tbl_warning_trace.DT.Rows)
            {
                if (row["selected"].ToString() == "Y")
                {
                    if (row["name"].ToString().ToUpper().Trim() != "DO")
                    {
                        if (this.tblTrans.DR[row["FieldName"].ToString()].ToString().ToUpper().Trim() == this.transBefore[row["FieldName"].ToString()].ToString().ToUpper().Trim())
                        {
                            continue;
                        }
                        flag = true;
                        string str = "Blank";
                        if (this.transBefore[row["FieldName"].ToString()].ToString().Trim().Length > 0)
                        {
                            str = this.transBefore[row["FieldName"].ToString()].ToString().Trim();
                        }
                        string[] textArray1 = new string[] { this.editTrace, "<tr class='bd'><td nowrap>", row["Name"].ToString().Trim().PadRight(20, ' '), "</td><td nowrap>", str.PadRight(20, ' '), "</td><td nowrap>", this.tblTrans.DR[row["FieldName"].ToString()].ToString().Trim().PadRight(20, ' '), "</td></tr>" };
                        this.editTrace = string.Concat(textArray1);
                        continue;
                    }
                    if (this.tblTransDO.DT.Rows.Count != this.tmp_transDO.Rows.Count)
                    {
                        flag = true;
                        this.editDoTrace = this.editDoTrace + "DO Before : \n";
                        int num = 0;
                        while (true)
                        {
                            if (num >= this.tmp_transDO.Rows.Count)
                            {
                                this.editDoTrace = this.editDoTrace + "\nDO After : \n";
                                int num2 = 0;
                                while (true)
                                {
                                    if (num2 >= this.tblTransDO.DT.Rows.Count)
                                    {
                                        break;
                                    }
                                    this.tblTransDO.DR = this.tblTransDO.DT.Rows[num2];
                                    string[] textArray3 = new string[] { this.editDoTrace, this.tblTransDO.DR["Do_No"].ToString().PadRight(0x21, ' '), " Qty : ", this.tblTransDO.DR["Netto"].ToString(), "\n" };
                                    this.editDoTrace = string.Concat(textArray3);
                                    num2++;
                                }
                                break;
                            }
                            this.transDOBefore = this.tmp_transDO.Rows[num];
                            string[] textArray2 = new string[] { this.editDoTrace, this.transDOBefore["Do_No"].ToString().PadRight(0x21, ' '), " Qty : ", this.transDOBefore["Netto"].ToString(), "\n" };
                            this.editDoTrace = string.Concat(textArray2);
                            num++;
                        }
                        continue;
                    }
                    bool flag9 = false;
                    int count = this.tmp_transDO.Rows.Count;
                    int num4 = 0;
                    while (true)
                    {
                        if (num4 >= count)
                        {
                            break;
                        }
                        this.tblTransDO.DR = this.tblTransDO.DT.Rows[num4];
                        this.transDOBefore = this.tmp_transDO.Rows[num4];
                        if (this.tblTransDO.DR["Do_No"].ToString().Trim().ToUpper() != this.transDOBefore["Do_No"].ToString().Trim().ToUpper())
                        {
                            flag = true;
                            flag9 = true;
                        }
                        if (flag9)
                        {
                            this.editDoTrace = this.editDoTrace + "<tr class='bd'>";
                            string[] textArray4 = new string[] { this.editDoTrace, "<td nowrap>Before</td><td nowrap>", this.transDOBefore["Do_No"].ToString(), "</td><td nowrap>", this.transDOBefore["Netto"].ToString(), "</td>" };
                            this.editDoTrace = string.Concat(textArray4);
                            this.editDoTrace = this.editDoTrace + "</tr>";
                            string[] textArray5 = new string[] { this.editDoTrace, "<td nowrap>After</td><td nowrap>", this.tblTransDO.DR["Do_No"].ToString(), "</td><td nowrap>", this.tblTransDO.DR["Netto"].ToString(), "</td>" };
                            this.editDoTrace = string.Concat(textArray5);
                            this.editDoTrace = this.editDoTrace + "</tr>";
                        }
                        num4++;
                    }
                }
            }
            return flag;
        }

        private void enableBySetting()
        {
            if (WBSetting.Container == "N")
            {
                this.tabControl1.TabPages.Remove(this.tabPageCont);
            }
            this.textTanker.Visible = true;
            this.buttonTanker.Visible = true;
            this.labelTankerMax.Visible = true;
            this.labTankerNo.Visible = true;
            if (WBSetting.Field("WB_ref") == "N")
            {
                this.labelWBNo.Visible = false;
                this.textWBNo.Visible = false;
            }
            if (WBSetting.NonContract == "N")
            {
                this.checkNonContract.Checked = false;
                this.checkNonContract.Visible = false;
            }
            if (WBSetting.Field("ISCC_Checked") == "Y")
            {
                this.panel4.Visible = true;
                this.checkISCC.Enabled = true;
                this.checkISCC.Checked = false;
            }
            else
            {
                this.panel4.Visible = false;
                this.checkISCC.Enabled = false;
                this.checkISCC.Checked = false;
            }
            if (WBSetting.Container == "Y")
            {
                this.textTruck2.Visible = true;
                this.panel4X.Visible = true;
            }
            else
            {
                this.textTruck2.Visible = false;
                foreach (Control control in this.tabPageCont.Controls)
                {
                    control.Enabled = false;
                }
                this.panel4X.Visible = false;
            }
            if (WBSetting.Trailer == "Y")
            {
                this.textTrailerNo.Visible = true;
                this.label46.Visible = true;
            }
            else
            {
                this.textTrailerNo.Visible = false;
                this.label46.Visible = false;
            }
            this.checkEstate.Visible = WBSetting.locType == "0";
            this.buttonReset.Visible = WBSetting.WBType() == "2";
        }

        private void entryCont(string pMod)
        {
            int index = -1;
            FormTransContEntry entry = new FormTransContEntry {
                pMode = pMod
            };
            if (pMod == "EDIT")
            {
                index = this.dgvCont.CurrentRow.Index;
                entry.textBox1.Text = this.dgvCont.CurrentRow.Cells["Container"].Value.ToString();
                entry.textBox2.Text = this.dgvCont.CurrentRow.Cells["Seal"].Value.ToString();
            }
            entry.dgvCont = this.dgvCont;
            entry.ShowDialog();
            if (entry.pSave)
            {
                this.ChangeContainer = true;
                if (pMod == "ADD")
                {
                    index = this.dgvCont.Rows.Count;
                    this.dgvCont.Rows.Add();
                }
                this.dgvCont.Rows[index].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvCont.Rows[index].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvCont.Rows[index].Cells["Ref"].Value = this.textRefNo.Text;
                this.dgvCont.Rows[index].Cells["Container"].Value = entry.textBox1.Text.Trim();
                this.dgvCont.Rows[index].Cells["Seal"].Value = entry.textBox2.Text.Trim();
            }
            entry.Dispose();
        }

        private void EntryDeduction(string pmode)
        {
            double num2;
            FormTransDeducEntry entry = new FormTransDeducEntry {
                pMode = pmode,
                textNET2 = this.textNET2.Text.Trim(),
                textBunchDeduc = this.textBunchDeduc.Text
            };
            if (pmode == "ADD")
            {
                entry.Text = "Add Deduction Item";
                entry.oldDeducCode = "";
            }
            else
            {
                entry.Text = "Edit Deduction Item";
                entry.comboDeducBy.Text = this.dgvDeduc.CurrentRow.Cells["Deduc_by"].Value.ToString();
                entry.textDeducCode.Text = this.dgvDeduc.CurrentRow.Cells["Code"].Value.ToString();
                entry.oldDeducCode = this.dgvDeduc.CurrentRow.Cells["Code"].Value.ToString();
                entry.textDeducName.Text = this.dgvDeduc.CurrentRow.Cells["Name"].Value.ToString();
                entry.textFormula.Text = this.dgvDeduc.CurrentRow.Cells["Formula"].Value.ToString();
                entry.textDeducVar.Text = this.dgvDeduc.CurrentRow.Cells["Variable"].Value.ToString();
                entry.textDeducPercent.Text = this.dgvDeduc.CurrentRow.Cells["PDeduc"].Value.ToString();
                entry.textDeducKG.Text = this.dgvDeduc.CurrentRow.Cells["KgDeduc"].Value.ToString();
                entry.textDeducQtyUnit.Text = this.dgvDeduc.CurrentRow.Cells["QtyBunch"].Value.ToString();
                entry.checkDeducReturn.Checked = this.dgvDeduc.CurrentRow.Cells["Retur"].Value.ToString() == "Y";
                entry.checkDeduct.Checked = this.dgvDeduc.CurrentRow.Cells["Deduct"].Value.ToString() != "N";
            }
            entry.labelKgUnit.Text = "BUNCH";
            entry.dataGridView1 = this.dgvDeduc;
            entry.tblTransD = this.tblTransDeduc;
            entry.ShowDialog();
            if (!entry.saved)
            {
                goto TR_0004;
            }
            else
            {
                int index;
                this.ChangeDeduc = true;
                Cursor.Current = Cursors.WaitCursor;
                try
                {
                    index = this.dgvDeduc.CurrentRow.Index;
                }
                catch
                {
                    index = 0;
                }
                if (pmode == "ADD")
                {
                    index = this.dgvDeduc.Rows.Count;
                    this.dgvDeduc.Rows.Add();
                }
                this.dgvDeduc.Rows[index].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvDeduc.Rows[index].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvDeduc.Rows[index].Cells["Ref"].Value = this.textRefNo.Text;
                this.dgvDeduc.Rows[index].Cells["Type"].Value = this.CommType;
                this.dgvDeduc.Rows[index].Cells["Deduc_by"].Value = entry.comboDeducBy.Text;
                this.dgvDeduc.Rows[index].Cells["Code"].Value = entry.textDeducCode.Text;
                this.dgvDeduc.Rows[index].Cells["Name"].Value = entry.textDeducName.Text;
                this.dgvDeduc.Rows[index].Cells["Formula"].Value = entry.textFormula.Text;
                this.dgvDeduc.Rows[index].Cells["Variable"].Value = entry.textDeducVar.Text;
                this.dgvDeduc.Rows[index].Cells["PDeduc"].Value = Convert.ToDouble(entry.textDeducPercent.Text.Trim());
                this.dgvDeduc.Rows[index].Cells["KgDeduc"].Value = Convert.ToDouble(entry.textDeducKG.Text.Trim());
                this.dgvDeduc.Rows[index].Cells["QtyBunch"].Value = Convert.ToDouble(entry.textDeducQtyUnit.Text.Trim());
                this.dgvDeduc.Rows[index].Cells["Retur"].Value = entry.checkDeducReturn.Checked ? "Y" : " ";
                this.dgvDeduc.Rows[index].Cells["Deduct"].Value = !entry.checkDeduct.Checked ? "N" : "Y";
                this.dgvDeduc.Refresh();
                num2 = 0.0;
                foreach (DataGridViewRow row in (IEnumerable) this.dgvDeduc.Rows)
                {
                    num2 += (row.Cells["Retur"].Value.ToString() == "Y") ? 0.0 : Convert.ToDouble(row.Cells["KgDeduc"].Value.ToString());
                }
            }
            try
            {
                if (this.txtMS.Text == "")
                {
                    this.txtMS.Text = "0";
                }
            }
            catch
            {
                this.txtMS.Text = "0";
            }
            num2 += Convert.ToDouble(this.txtMS.Text);
            this.textDeducTotal.Text = $"{num2:N0}";
            this.HitNet();
            if ((this.dgvDO.Rows.Count == 1) && ((this.pMode == "2ND") && !(Convert.ToDouble(this.textNet.Text) == 0.0)))
            {
                if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text2nd.Text))
                {
                    this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text1st.Text;
                    this.dgvDO.Rows[0].Cells["Tarra"].Value = this.text2nd.Text;
                }
                else
                {
                    this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text2nd.Text;
                    this.dgvDO.Rows[0].Cells["Tarra"].Value = this.text1st.Text;
                }
                this.dgvDO.Rows[0].Cells["Netto"].Value = this.textNet.Text;
                this.dgvDO.Refresh();
                this.ChangeDO = true;
            }
            Cursor.Current = Cursors.Default;
        TR_0004:
            entry.Dispose();
        }

        private void EntryDeductionPorla(string pmode)
        {
            FormTransDeducEntry entry = new FormTransDeducEntry {
                pMode = pmode,
                textNET2 = this.textNET2.Text.Trim(),
                textBunchDeduc = this.textBunchDeduc.Text
            };
            if (pmode == "ADD")
            {
                entry.Text = "Add Deduction Porla Item";
                entry.oldDeducCode = "";
            }
            else
            {
                entry.Text = "Edit Deduction Item";
                entry.comboDeducBy.Text = this.dgvDeducPorla.CurrentRow.Cells["Deduc_by"].Value.ToString();
                entry.textDeducCode.Text = this.dgvDeducPorla.CurrentRow.Cells["Code"].Value.ToString();
                entry.oldDeducCode = this.dgvDeducPorla.CurrentRow.Cells["Code"].Value.ToString();
                entry.textDeducName.Text = this.dgvDeducPorla.CurrentRow.Cells["Name"].Value.ToString();
                entry.textFormula.Text = this.dgvDeducPorla.CurrentRow.Cells["Formula"].Value.ToString();
                entry.textDeducVar.Text = this.dgvDeducPorla.CurrentRow.Cells["Variable"].Value.ToString();
                entry.textDeducPercent.Text = this.dgvDeducPorla.CurrentRow.Cells["PDeduc"].Value.ToString();
                entry.textDeducKG.Text = this.dgvDeducPorla.CurrentRow.Cells["KgDeduc"].Value.ToString();
                entry.textDeducQtyUnit.Text = this.dgvDeducPorla.CurrentRow.Cells["QtyBunch"].Value.ToString();
                entry.checkDeducReturn.Checked = this.dgvDeducPorla.CurrentRow.Cells["Retur"].Value.ToString() == "Y";
                entry.checkDeduct.Checked = this.dgvDeducPorla.CurrentRow.Cells["Deduct"].Value.ToString() != "N";
            }
            entry.labelKgUnit.Text = "BUNCH";
            entry.dataGridView1 = this.dgvDeducPorla;
            entry.tblTransD = this.tblTransDeducPorla;
            entry.ShowDialog();
            if (entry.saved)
            {
                this.ChangeDeducPorla = true;
                Cursor.Current = Cursors.WaitCursor;
                int index = this.dgvDeducPorla.CurrentRow.Index;
                if (pmode == "ADD")
                {
                    index = this.dgvDeducPorla.Rows.Count;
                    this.dgvDeducPorla.Rows.Add();
                }
                this.dgvDeducPorla.Rows[index].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvDeducPorla.Rows[index].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvDeducPorla.Rows[index].Cells["Ref"].Value = this.textRefNo.Text;
                this.dgvDeducPorla.Rows[index].Cells["Type"].Value = this.CommType;
                this.dgvDeducPorla.Rows[index].Cells["Deduc_by"].Value = entry.comboDeducBy.Text;
                this.dgvDeducPorla.Rows[index].Cells["Code"].Value = entry.textDeducCode.Text;
                this.dgvDeducPorla.Rows[index].Cells["Name"].Value = entry.textDeducName.Text;
                this.dgvDeducPorla.Rows[index].Cells["Formula"].Value = entry.textFormula.Text;
                this.dgvDeducPorla.Rows[index].Cells["Variable"].Value = entry.textDeducVar.Text;
                this.dgvDeducPorla.Rows[index].Cells["PDeduc"].Value = Convert.ToDouble(entry.textDeducPercent.Text.Trim());
                this.dgvDeducPorla.Rows[index].Cells["KgDeduc"].Value = Convert.ToDouble(entry.textDeducKG.Text.Trim());
                this.dgvDeducPorla.Rows[index].Cells["QtyBunch"].Value = Convert.ToDouble(entry.textDeducQtyUnit.Text.Trim());
                this.dgvDeducPorla.Rows[index].Cells["Retur"].Value = entry.checkDeducReturn.Checked ? "Y" : " ";
                this.dgvDeducPorla.Rows[index].Cells["Deduct"].Value = !entry.checkDeduct.Checked ? "N" : "Y";
                this.dgvDeducPorla.Refresh();
                if ((this.dgvDO.Rows.Count == 1) && ((this.pMode == "2ND") && !(Convert.ToDouble(this.textNet.Text) == 0.0)))
                {
                    if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text2nd.Text))
                    {
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text1st.Text;
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = this.text2nd.Text;
                    }
                    else
                    {
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text2nd.Text;
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = this.text1st.Text;
                    }
                    this.dgvDO.Rows[0].Cells["Netto"].Value = this.textNet.Text;
                    this.dgvDO.Refresh();
                    this.ChangeDO = true;
                }
                Cursor.Current = Cursors.Default;
            }
            entry.Dispose();
        }

        private void EntryDivBlock(string pmode)
        {
            int index = -1;
            this.BJR();
            FormTransDivision division = new FormTransDivision {
                dgvDiv = this.dgvDivBlock,
                jTandan = Convert.ToInt32(this.textBunchTotal.Text),
                textEstate = { Text = this.textEstate.Text },
                refDate = this.textRef_Date.Text,
                maskedAVG = { Text = this.textAvg.Text },
                pMode = pmode
            };
            if (pmode == "ADD")
            {
                division.Text = "Add Division/Block item";
            }
            else
            {
                index = this.dgvDivBlock.CurrentRow.Index;
                division.Text = "Edit Division/Block item";
                division.textEstate.Text = this.dgvDivBlock.CurrentRow.Cells["Estate_Code"].Value.ToString();
                division.textEstateName.Text = this.dgvDivBlock.CurrentRow.Cells["Estate_Name"].Value.ToString();
                division.textDiv.Text = this.dgvDivBlock.CurrentRow.Cells["Division_Code"].Value.ToString();
                division.textDivName.Text = this.dgvDivBlock.CurrentRow.Cells["Division_Name"].Value.ToString();
                division.textBlockCode.Text = this.dgvDivBlock.CurrentRow.Cells["Block_Code"].Value.ToString();
                division.textBlockName.Text = this.dgvDivBlock.CurrentRow.Cells["Block_Name"].Value.ToString();
                division.maskedAVG.Text = this.dgvDivBlock.CurrentRow.Cells["Average"].Value.ToString().PadLeft(5, '0');
                division.textBunch.Text = this.dgvDivBlock.CurrentRow.Cells["Bunch"].Value.ToString();
                division.textWeight.Text = this.dgvDivBlock.CurrentRow.Cells["Weight"].Value.ToString();
                division.textYear.Text = this.dgvDivBlock.CurrentRow.Cells["yearPlanting"].Value.ToString();
            }
            division.ShowDialog();
            if (division.Saved)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.ChangeDiv = true;
                if (pmode == "ADD")
                {
                    index = this.dgvDivBlock.Rows.Count;
                    this.dgvDivBlock.Rows.Add();
                }
                this.dgvDivBlock.Rows[index].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvDivBlock.Rows[index].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvDivBlock.Rows[index].Cells["Ref"].Value = this.textRefNo.Text;
                this.dgvDivBlock.Rows[index].Cells["Estate_Code"].Value = division.textEstate.Text;
                this.dgvDivBlock.Rows[index].Cells["Estate_Name"].Value = division.textEstateName.Text;
                this.dgvDivBlock.Rows[index].Cells["Division_Code"].Value = division.textDiv.Text;
                this.dgvDivBlock.Rows[index].Cells["Division_Name"].Value = division.textDivName.Text;
                this.dgvDivBlock.Rows[index].Cells["Block_Code"].Value = division.textBlockCode.Text;
                this.dgvDivBlock.Rows[index].Cells["Block_Name"].Value = division.textBlockName.Text;
                this.dgvDivBlock.Rows[index].Cells["Average"].Value = division.maskedAVG.Text;
                this.dgvDivBlock.Rows[index].Cells["Bunch"].Value = Convert.ToDouble(division.textBunch.Text);
                this.dgvDivBlock.Rows[index].Cells["Weight"].Value = Convert.ToDouble(division.textWeight.Text);
                this.dgvDivBlock.Rows[index].Cells["YearPlanting"].Value = Convert.ToDouble(division.textYear.Text);
                Cursor.Current = Cursors.Default;
            }
            division.Dispose();
        }

        private void entryDO(string doEntryMode)
        {
            int num8;
            int count = this.dgvDO.Rows.Count;
            double num2 = Convert.ToDouble(this.textNet.Text);
            double num3 = Convert.ToDouble(this.textNetEstate.Text);
            double num4 = Convert.ToDouble(this.textVariance.Text);
            double num5 = 0.0;
            double num6 = 0.0;
            double num7 = 0.0;
            if (this.dgvDO.Rows.Count == 0)
            {
                num5 = 0.0;
                num6 = 0.0;
                num7 = 0.0;
            }
            else
            {
                num5 = Program.StrToDouble(this.dgvDO.CurrentRow.Cells["Netto"].Value.ToString(), 0);
                num7 = Program.StrToDouble(this.dgvDO.CurrentRow.Cells["Bruto"].Value.ToString(), 0);
                num6 = Program.StrToDouble(this.dgvDO.CurrentRow.Cells["Estate_qty"].Value.ToString(), 0);
            }
            FormTransDOEntry entry = new FormTransDOEntry {
                auto_generate_dummy_contract = this.auto_generate_dummy_contract,
                Text = doEntryMode + " DO item",
                RefNo = this.textRefNo.Text,
                refDate = this.textRef_Date.Text,
                doEntryMode = doEntryMode,
                pMode = this.pMode,
                totalVariance = num4,
                totalNet = num2,
                totalNetEstate = num3,
                pComm = this.textCommodity.Text,
                WX = this.WX,
                pTransType = this.comboTransType.Text,
                delivery_note = this.textDN.Text,
                tblTransDO = this.tblTransDO,
                tblDOContainer = this.tblDOContainer,
                tblComm = this.tblComm,
                dgvDO = this.dgvDO,
                dgvCont = this.dgvCont,
                dgvDoCont = this.dgvDOCont,
                dgvBatch = this.dgvBatch,
                nopw = this.checkNOPW.Checked,
                net_estate = this.textNetEstate.Text
            };
            if ((doEntryMode == "EDIT") || (doEntryMode == "EDIT_OPW"))
            {
                entry.dgvDOCurrRow = this.dgvDO.CurrentRow.Index;
                entry.oldComm = this.oldComm;
                entry.textDO.Text = this.dgvDO.CurrentRow.Cells["DO_No"].Value.ToString();
                entry.txtInternalNum.Text = this.dgvDO.CurrentRow.Cells["internal_number"].Value.ToString();
                entry.txtInNumItem.Text = this.dgvDO.CurrentRow.Cells["internal_number_item"].Value.ToString();
                entry.text_do_sap.Text = this.dgvDO.CurrentRow.Cells["do_sap"].Value.ToString();
                entry.text_do_sap_item.Text = this.dgvDO.CurrentRow.Cells["do_sap_item"].Value.ToString();
                entry.text_do_sap_qty.Text = this.dgvDO.CurrentRow.Cells["do_qty"].Value.ToString();
                entry.text_do_sap_unit.Text = this.dgvDO.CurrentRow.Cells["do_uom"].Value.ToString();
                entry.textBoxQtyBaseUOM.Text = this.dgvDO.CurrentRow.Cells["do_base_qty"].Value.ToString();
                entry.textBoxBaseUOM.Text = this.dgvDO.CurrentRow.Cells["do_base_uom"].Value.ToString();
                entry.text_do_sap_qty_kg.Text = this.dgvDO.CurrentRow.Cells["do_qty_kg"].Value.ToString();
                entry.indic = this.dgvDO.CurrentRow.Cells["do_besar"].Value.ToString();
                entry.textSOItem_detail.Text = this.dgvDO.CurrentRow.Cells["so_item_detail"].Value.ToString();
                if (this.dgvDO.CurrentRow.Cells["loading_qty"].Value == null)
                {
                    this.dgvDO.CurrentRow.Cells["loading_qty"].Value = 0;
                }
                if (this.dgvDO.CurrentRow.Cells["loading_qty_opw"].Value == null)
                {
                    this.dgvDO.CurrentRow.Cells["loading_qty_opw"].Value = 0;
                }
                if (this.dgvDO.CurrentRow.Cells["return_qty_kg"].Value == null)
                {
                    this.dgvDO.CurrentRow.Cells["return_qty_kg"].Value = 0;
                }
                if (this.dgvDO.CurrentRow.Cells["return_qty_pack"].Value == null)
                {
                    this.dgvDO.CurrentRow.Cells["return_qty_pack"].Value = 0;
                }
                entry.textBoxLoadingQty.Text = this.dgvDO.CurrentRow.Cells["loading_qty"].Value.ToString();
                entry.text_opw_loading_qty.Text = this.dgvDO.CurrentRow.Cells["loading_qty_opw"].Value.ToString();
                entry.txtReturnKg.Text = this.dgvDO.CurrentRow.Cells["return_qty_kg"].Value.ToString();
                entry.txtReturnPack.Text = this.dgvDO.CurrentRow.Cells["return_qty_pack"].Value.ToString();
                string str = this.dgvDO.CurrentRow.Cells["transaction_code"].Value.ToString();
            }
            if (!(((this.pMode == "1ST") && WBSetting.activeTCS) && this.firstLoadTCS))
            {
                entry.ShowDialog();
            }
            else
            {
                entry.f_load();
                entry.saveDOforFirstTime_TCS();
                this.firstLoadTCS = false;
            }
            if (entry.saved)
            {
                Cursor.Current = Cursors.WaitCursor;
                if (this.CommType != "G")
                {
                    goto TR_0074;
                }
                else if (MessageBox.Show("This will reset delivery letter. Are you sure? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.dgvBatch.Rows.Clear();
                    goto TR_0074;
                }
            }
            return;
        TR_000A:
            if (doEntryMode == "2ND")
            {
                if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    string[] textArray7 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(false) };
                    this.textDN.Text = string.Concat(textArray7);
                }
                else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    string[] textArray8 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(false) };
                    this.textDN.Text = string.Concat(textArray8);
                }
            }
            this.tblComm.OpenTable("wb_comm", "select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.textCommodity.Text.Trim() + "'"), WBData.conn);
            string[] aField = new string[] { "Comm_Code" };
            string[] aFind = new string[] { this.textCommodity.Text.Trim() };
            DataRow data = this.tblComm.GetData(aField, aFind);
            WBCondition condition = new WBCondition();
            DataRow[] dgRows = new DataRow[] { this.rowTransType, data };
            condition.fillParameter("NOPW", dgRows);
            string str2 = condition.getResult() ? "Y" : "N";
            condition.Dispose();
            if ((WBSetting.Field("NOPW") == "Y") && (str2 == "Y"))
            {
                this.checkNOPW.Visible = true;
                this.checkNOPW.Enabled = true;
            }
            else
            {
                this.checkNOPW.Checked = false;
                this.checkNOPW.Visible = false;
                this.checkNOPW.Enabled = false;
            }
            entry.Dispose();
            Cursor.Current = Cursors.Default;
            return;
        TR_0074:
            num8 = entry.dgvDOCurrRow;
            this.ChangeDoCont = entry.ChangeDOCont;
            if (this.ChangeDoCont)
            {
                this.dgvDOCont = entry.dgvDoCont;
            }
            this.lSTO1DO = entry.lSTO1DO;
            this.ChangeDO = true;
            if (doEntryMode != "ADD")
            {
                if (this.dgvDO.CurrentRow.Index > 0)
                {
                    this.dgvDO.Rows[0].Cells["Estate_qty"].Value = (Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString()) - Convert.ToDouble(entry.textOthNet.Text)) + num6;
                    this.dgvDO.Rows[0].Cells["Netto"].Value = (Convert.ToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString()) - Convert.ToDouble(entry.textFactNet.Text)) + num5;
                    this.dgvDO.Rows[0].Cells["Bruto"].Value = (Convert.ToDouble(this.dgvDO.Rows[0].Cells["Tarra"].Value.ToString()) + Convert.ToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString())) + Convert.ToDouble(this.textDeducTotal.Text);
                    if ((this.comboTransType.Text == "JUL") && ((this.dgvDO.Rows[0].Cells["internal_number"].Value.ToString() != "") || (this.dgvDO.Rows[0].Cells["do_sap"].Value.ToString() != "")))
                    {
                        this.tblComm.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + this.dgvDO.Rows[0].Cells["Comm_code"].Value + "' and bulkpack = 'P' and upper(unit) = 'KG'"), WBData.conn);
                        if (this.tblComm.DT.Rows.Count > 0)
                        {
                            this.dgvDO.Rows[0].Cells["loading_qty"].Value = this.dgvDO.Rows[0].Cells["Netto"].Value;
                        }
                    }
                }
            }
            else
            {
                this.dgvDO.Rows.Add();
                num8 = this.dgvDO.Rows.Count - 1;
                if ((this.dgvDO.Rows.Count <= 0) || (num8 <= 0))
                {
                    this.hitungBTN();
                }
                else
                {
                    this.dgvDO.Rows[0].Cells["Estate_qty"].Value = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString()) - Convert.ToDouble(entry.textOthNet.Text);
                    this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString()) - Convert.ToDouble(entry.textFactNet.Text);
                    this.dgvDO.Rows[0].Cells["Bruto"].Value = (Convert.ToDouble(this.dgvDO.Rows[0].Cells["Tarra"].Value.ToString()) + Convert.ToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString())) + Convert.ToDouble(this.textDeducTotal.Text);
                    this.dgvDO.Rows[0].Cells["DeliNo"].Value = this.textDN.Text;
                    if ((this.comboTransType.Text == "JUL") && ((this.dgvDO.Rows[0].Cells["internal_number"].Value.ToString() != "") || (this.dgvDO.Rows[0].Cells["do_sap"].Value.ToString() != "")))
                    {
                        this.tblComm.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + this.dgvDO.Rows[0].Cells["Comm_code"].Value + "' and bulkpack = 'P' and upper(unit) = 'KG'"), WBData.conn);
                        if (this.tblComm.DT.Rows.Count > 0)
                        {
                            this.dgvDO.Rows[0].Cells["loading_qty"].Value = this.dgvDO.Rows[0].Cells["Netto"].Value;
                        }
                    }
                }
            }
            this.dgvDO.Rows[num8].Cells["Coy"].Value = WBData.sCoyCode;
            this.dgvDO.Rows[num8].Cells["Location_Code"].Value = WBData.sLocCode;
            this.dgvDO.Rows[num8].Cells["Transaction_Code"].Value = this.comboTransType.Text;
            this.dgvDO.Rows[num8].Cells["Ref"].Value = this.textRefNo.Text;
            this.dgvDO.Rows[num8].Cells["DeliNo"].Value = entry.txtDeliveryNote.Text;
            this.dgvDO.Rows[num8].Cells["do_sap"].Value = entry.text_do_sap.Text;
            this.dgvDO.Rows[num8].Cells["do_sap_item"].Value = entry.text_do_sap_item.Text;
            this.dgvDO.Rows[num8].Cells["internal_number"].Value = entry.txtInternalNum.Text;
            this.dgvDO.Rows[num8].Cells["internal_number_item"].Value = entry.txtInNumItem.Text;
            this.dgvDO.Rows[num8].Cells["loading_qty_opw"].Value = entry.text_opw_loading_qty.Text;
            this.dgvDO.Rows[num8].Cells["do_qty"].Value = entry.text_do_sap_qty.Text;
            this.dgvDO.Rows[num8].Cells["do_uom"].Value = entry.text_do_sap_unit.Text;
            this.dgvDO.Rows[num8].Cells["do_base_qty"].Value = entry.textBoxQtyBaseUOM.Text;
            this.dgvDO.Rows[num8].Cells["do_base_uom"].Value = entry.textBoxBaseUOM.Text;
            this.dgvDO.Rows[num8].Cells["do_qty_kg"].Value = entry.text_do_sap_qty_kg.Text;
            this.dgvDO.Rows[num8].Cells["do_besar"].Value = entry.indic;
            if (this.pMode == "1ST")
            {
                this.dgvDO.Rows[num8].Cells["Date1"].Value = this.textDate1st.Text;
            }
            else if (this.pMode == "2ND")
            {
                this.dgvDO.Rows[num8].Cells["Date2"].Value = this.textDate2nd.Text;
            }
            else if (this.pMode == "3RD")
            {
                this.dgvDO.Rows[num8].Cells["Date3"].Value = this.textDate3rd.Text;
            }
            else if (this.pMode == "4TH")
            {
                this.dgvDO.Rows[num8].Cells["Date3"].Value = this.textDate3rd.Text;
                this.dgvDO.Rows[num8].Cells["Date4"].Value = this.textDate4th.Text;
            }
            this.dgvDO.Rows[num8].Cells["DO_No"].Value = entry.textDO.Text;
            this.dgvDO.Rows[num8].Cells["Comm_Code"].Value = entry.textComm.Text;
            this.dgvDO.Rows[num8].Cells["Contract"].Value = entry.textCont.Text;
            this.dgvDO.Rows[num8].Cells["Relation_Code"].Value = entry.textRCode.Text;
            this.dgvDO.Rows[num8].Cells["Relation_Name"].Value = entry.textRName.Text;
            this.dgvDO.Rows[num8].Cells["Netto"].Value = Program.StrToDouble(entry.textFactNet.Text, 2);
            if (num8 > 0)
            {
                this.dgvDO.Rows[num8].Cells["Estate_qty"].Value = Program.StrToDouble(entry.textOthNet.Text, 2);
            }
            this.dgvDO.Rows[num8].Cells["Agen"].Value = (entry.labelAgen.Text != "") ? "Y" : "N";
            this.dgvDO.Rows[num8].Cells["Estate"].Value = entry.textEstate.Text;
            this.dgvDO.Rows[num8].Cells["ConvNett"].Value = Program.StrToDouble(entry.textConvNett.Text, 2);
            this.dgvDO.Rows[num8].Cells["ConvUnit"].Value = entry.labelConvUnit.Text;
            this.dgvDO.Rows[num8].Cells["PI_No"].Value = entry.textPI_No.Text;
            this.dgvDO.Rows[num8].Cells["Transporter_Code"].Value = entry.textTransporter.Text;
            this.dgvDO.Rows[num8].Cells["Transaction_Code"].Value = entry.pTransType;
            this.dgvDO.Rows[num8].Cells["Storage_code"].Value = entry.textStorage.Text;
            this.dgvDO.Rows[num8].Cells["STO1X"].Value = entry.text1STO.Text;
            this.dgvDO.Rows[num8].Cells["DO1X"].Value = entry.text1DOSTO.Text;
            this.dgvDO.Rows[num8].Cells["Tolling"].Value = entry.tolling;
            this.dgvDO.Rows[num8].Cells["OSDO"].Value = entry.labelQtyLeft.Text;
            this.dgvDO.Rows[num8].Cells["loading_qty"].Value = entry.textBoxLoadingQty.Text;
            this.dgvDO.Rows[num8].Cells["loading_qty_opw"].Value = entry.text_opw_loading_qty.Text;
            this.dgvDO.Rows[num8].Cells["Return_Qty_KG"].Value = entry.txtReturnKg.Text;
            this.dgvDO.Rows[num8].Cells["Return_Qty_Pack"].Value = entry.txtReturnPack.Text;
            this.dgvDO.Rows[num8].Cells["so_item_detail"].Value = entry.textSOItem_detail.Text;
            if (this.dgvDO.Rows[num8].Cells["so_item_detail"].Value.ToString() == "")
            {
                this.dgvDO.Rows[num8].Cells["so_item_detail"].Value = entry.so_item;
            }
            if ((this.comboTransType.Text == "JUL") && ((this.dgvDO.Rows[num8].Cells["internal_number"].Value.ToString() != "") || (this.dgvDO.Rows[num8].Cells["do_sap"].Value.ToString() != "")))
            {
                this.tblComm.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + this.dgvDO.Rows[num8].Cells["Comm_code"].Value + "' and bulkpack = 'P' and upper(unit) = 'KG'"), WBData.conn);
                if (this.tblComm.DT.Rows.Count > 0)
                {
                    this.dgvDO.Rows[num8].Cells["loading_qty"].Value = this.dgvDO.Rows[num8].Cells["Netto"].Value;
                }
            }
            this.dgvDO.Rows[num8].Cells["WeightPerUnitName"].Value = (this.dgvDO.Rows[num8].Cells["WeightPerUnitName"].Value == null) ? 0 : this.dgvDO.Rows[num8].Cells["WeightPerUnitName"].Value;
            this.dgvDO.Rows[num8].Cells["DeducUnitQty"].Value = (this.dgvDO.Rows[num8].Cells["DeducUnitQty"].Value == null) ? 0 : this.dgvDO.Rows[num8].Cells["DeducUnitQty"].Value;
            this.dgvDO.Rows[num8].Cells["TotalDeducUnit"].Value = (this.dgvDO.Rows[num8].Cells["TotalDeducUnit"].Value == null) ? 0 : this.dgvDO.Rows[num8].Cells["TotalDeducUnit"].Value;
            this.dgvDO.Rows[num8].Cells["Deduction"].Value = (this.dgvDO.Rows[num8].Cells["Deduction"].Value == null) ? 0 : this.dgvDO.Rows[num8].Cells["Deduction"].Value;
            this.dgvDO.Rows[num8].Cells["UnitName"].Value = (this.dgvDO.Rows[num8].Cells["UnitName"].Value == null) ? "" : this.dgvDO.Rows[num8].Cells["UnitName"].Value;
            if (num8 != 0)
            {
                if (num8 > 0)
                {
                    this.dgvDO.Rows[num8].Cells["Bruto"].Value = Convert.ToDouble(this.dgvDO.Rows[num8].Cells["Netto"].Value.ToString());
                    this.dgvDO.Rows[num8].Cells["Tarra"].Value = "0";
                    this.dgvDO.Rows[num8].Cells["Netto"].Value = entry.textFactNet.Text;
                }
                goto TR_000A;
            }
            else
            {
                this.textCommodity.Text = entry.pComm;
                this.comboTransType.Text = entry.pTransType;
                this.TransType();
                this.textCust.Text = entry.textRCode.Text;
                this.textQualityInfo.Text = entry.qualityInfo;
                if (this.textRemarkTicket.Text.Trim() == "")
                {
                    this.textRemarkTicket.Text = entry.remark;
                }
                this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and  comm_code = '" + entry.textComm.Text.Trim() + "'"), WBData.conn);
                string[] textArray1 = new string[] { "Comm_Code" };
                string[] textArray2 = new string[] { entry.textComm.Text };
                DataRow row2 = this.tblComm.GetData(textArray1, textArray2);
                if (row2 != null)
                {
                    this.labelCommName.Text = row2["Comm_Name"].ToString();
                    this.textCommType.Text = row2["Type"].ToString();
                    this.CommType = row2["Type"].ToString();
                    this.use_gunny = row2["Using_Gunny"].ToString();
                    this.is_trade = row2["Trade"].ToString();
                    this.is_bulk = row2["BulkPack"].ToString();
                    this.check_tare_comm = row2["Check_Tare"].ToString();
                    if (this.use_gunny == "Y")
                    {
                        try
                        {
                            this.sGunnyNet = Convert.ToDouble(row2["Netto_Gunny"].ToString().Trim());
                            this.sGunnyMin = Convert.ToDouble(row2["Gross_Min_Gunny"].ToString().Trim());
                            this.sGunnyMax = Convert.ToDouble(row2["Gross_Max_Gunny"].ToString().Trim());
                        }
                        catch
                        {
                            this.sGunnyNet = 0.0;
                            this.sGunnyMax = 0.0;
                            this.sGunnyMin = 0.0;
                        }
                    }
                }
            }
            if (WBSetting.Field("ScanCardSPB").ToString() == "Y")
            {
                if (this.textTransporter.Text.Trim() == "")
                {
                    this.textTransporter.Text = entry.textTransporter.Text;
                    string[] textArray3 = new string[] { "Transporter_Code" };
                    string[] textArray4 = new string[] { this.textTransporter.Text };
                    DataRow row3 = this.tblTransporter.GetData(textArray3, textArray4);
                    this.labelTransporterName.Text = (row3 == null) ? "" : row3["Transporter_Name"].ToString();
                }
            }
            else
            {
                if (entry.textTransporter.Text.Trim() != "")
                {
                    this.textTransporter.Text = entry.textTransporter.Text;
                }
                string[] textArray5 = new string[] { "Transporter_Code" };
                string[] textArray6 = new string[] { this.textTransporter.Text };
                DataRow row4 = this.tblTransporter.GetData(textArray5, textArray6);
                this.labelTransporterName.Text = (row4 == null) ? "" : row4["Transporter_Name"].ToString();
            }
            if (this.tabControl1.TabPages.IndexOf(this.tabPageDeduc) >= 0)
            {
                this.tabControl1.TabPages.Remove(this.tabPageDeduc);
            }
            if (this.tabControl1.TabPages.IndexOf(this.tabPageDivision) >= 0)
            {
                this.tabControl1.TabPages.Remove(this.tabPageDivision);
            }
            if (this.tabControl1.TabPages.IndexOf(this.tabPageQC) >= 0)
            {
                this.tabControl1.TabPages.Remove(this.tabPageQC);
            }
            if (this.tabControl1.TabPages.IndexOf(this.tabPagePorla) >= 0)
            {
                this.tabControl1.TabPages.Remove(this.tabPagePorla);
            }
            if (this.tabControl1.TabPages.IndexOf(this.tabPageCopra) >= 0)
            {
                this.tabControl1.TabPages.Remove(this.tabPageCopra);
            }
            if (this.tabControl1.TabPages.IndexOf(this.tabPageDL) >= 0)
            {
                this.tabControl1.TabPages.Remove(this.tabPageDL);
            }
            if (this.tabControl1.TabPages.IndexOf(this.tabPageDeduc) < 0)
            {
                this.tabControl1.TabPages.Add(this.tabPageDeduc);
            }
            if (this.CommType == "S")
            {
                if (this.tabControl1.TabPages.IndexOf(this.tabPageQC) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPageQC);
                }
                this.panelDeducTBS.Visible = false;
                this.groupBoxTotalBunchFFB.Visible = false;
            }
            else if (this.CommType == "F")
            {
                if (this.tabControl1.TabPages.IndexOf(this.tabPagePorla) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPagePorla);
                }
                if (this.tabControl1.TabPages.IndexOf(this.tabPageDivision) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPageDivision);
                }
                this.panelDeducTBS.Visible = true;
                this.groupBoxTotalBunchFFB.Visible = true;
                this.radioButtonEntryAVG.Visible = true;
                this.radioButtonEntryTotalBunch.Visible = true;
                if (WBSetting.Field("ScanCardSPB") == "Y")
                {
                    this.radioButtonEntryAVG.Checked = false;
                    this.radioButtonEntryTotalBunch.Checked = true;
                }
                else
                {
                    this.radioButtonEntryAVG.Checked = true;
                    this.radioButtonEntryTotalBunch.Checked = false;
                }
                this.checkEntryAVGorTotalBunch();
            }
            else if (this.CommType == "C")
            {
                if (this.tabControl1.TabPages.IndexOf(this.tabPageCopra) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPageCopra);
                }
                this.panelDeducTBS.Visible = false;
            }
            else if (this.CommType == "G")
            {
                if (this.tabControl1.TabPages.IndexOf(this.tabPageDL) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPageDL);
                }
                this.panelDeducTBS.Visible = false;
                if (entry.dIncoterm == "1")
                {
                    this.dgvBatch.Columns["Ref"].Visible = false;
                }
            }
            if (entry.changeComm || ((doEntryMode == "ADD") && (this.dgvDO.Rows.Count == 1)))
            {
                if (this.CommType != "F")
                {
                    this._InitBlankQC(this.dgvDO.Rows[num8].Cells["DO_NO"].Value.ToString());
                }
                else
                {
                    this._InitBlankGrading(this.textCommodity.Text);
                    this._InitBlankGradingPorla(this.textCommodity.Text);
                }
                if (entry.changeComm)
                {
                    this.oldComm = entry.textComm.Text.Trim();
                }
            }
            this.ChangeQC = true;
            this.ChangeDeduc = true;
            this.ChangeDeducPorla = true;
            if (WBSetting.Field("ISCC_Checked") == "Y")
            {
                this.checkISCC.Checked = entry.ISCC == "Y";
                if (entry.ISCC == "Y")
                {
                    this.setISCC();
                    this.textISCC2.Text = (this.textCommodity.Text.Trim().ToUpper() != "CPO") ? "" : this.SetNoISCC(false);
                }
            }
            goto TR_000A;
        }

        private void FormTransaction_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.fCopra.Close();
                this.ThisClose();
            }
        }

        private void FormTransaction_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            Cursor.Current = Cursors.WaitCursor;
            WBSetting.OpenSetting();
            this.enableBySetting();
            this.spMode = this.pMode;
            this.lblOSDO.Text = "";
            this.jtdate = this.textReport_Date.Text;
            this.Copied = this.pMode == "COPY";
            this.pMode = (this.pMode == "COPY") ? "1ST" : this.pMode;
            if (((this.pMode != "1ST") || ((this.pMode == "1ST") & !this.tambahRecord)) & (this.pMode != "MANUAL"))
            {
                this.tblTrans.DR = this.tblTrans.DT.Rows[0];
                this.textRefNo.Text = this.tblTrans.DR["Ref"].ToString();
                if (this.tblTrans.DR["NonContract"].ToString() == "Y")
                {
                    this.checkNonContract.Checked = true;
                    this.typeContract(1);
                }
                else
                {
                    this.checkNonContract.Checked = false;
                    this.typeContract(0);
                }
            }
            if (this.Copied)
            {
                this.tblTrans.DR = this.tblTrans.DT.Rows[0];
                this.textRefNo.Text = this.tblTrans.DR["Ref"].ToString();
                if ((WBSetting.gatepass_registration && WBSetting.activeTCS) && (this.tambahRecord && ((this.pMode == "1ST") || (this.pMode == "MANUAL"))))
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_gatepass", "SELECT * FROM wb_gatepass WHERE " + WBData.CompanyLocation(" AND uniq = " + this.gatepass_uniq), WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        this.WXGatepass = table.DT.Rows[0]["WX"].ToString();
                    }
                    table.Dispose();
                }
            }
            if (((this.pMode == "1ST") || (this.pMode == "2ND")) || (this.pMode == "VIEW"))
            {
                this.textGrade.Enabled = false;
            }
            this.InitTable();
            this.loadDatagrid();
            if (this.pMode != "MANUAL")
            {
                this.Text = this.pMode.Trim() + " WEIGHT TRANSACTION ( " + this.WX.Trim() + " )";
            }
            else if ((WBUser.UserLevel == "1") || (WBSetting.Field("GM") != "Y"))
            {
                this.Text = this.pMode.Trim() + " WEIGHT TRANSACTION ( " + this.WX.Trim() + " )";
            }
            else
            {
                WBTable table2 = new WBTable();
                table2.OpenTable("wb_loc", "select * from wb_location", WBData.conn);
                string str = Program.shoot(table2.DT.Rows[0]["MaxEntry"].ToString(), false);
                string str2 = Program.shoot(table2.DT.Rows[0]["CurrEntry"].ToString(), false);
                string[] textArray1 = new string[] { this.pMode.Trim(), " WEIGHT TRANSACTION ( ", this.WX.Trim(), " ) , Manual Entry Left = ", (Convert.ToDouble(str) - Convert.ToDouble(str2)).ToString() };
                this.Text = string.Concat(textArray1);
                table2.Dispose();
            }
            this.tabControl1.TabPages.Remove(this.tabPageDeduc);
            this.tabControl1.TabPages.Remove(this.tabPageDivision);
            this.tabControl1.TabPages.Remove(this.tabPageQC);
            this.tabControl1.TabPages.Remove(this.tabPagePorla);
            this.tabControl1.TabPages.Remove(this.tabPageCopra);
            this.tabControl1.TabPages.Remove(this.tabPageDL);
            this.fCopra = new FormTransCopraEntry();
            this.buttonSavePrint.Enabled = false;
            this.buttonSavePrint.Enabled = !((this.WX == "2X") & (this.pMode == "2ND")) ? ((this.WX == "4X") & (this.pMode == "4TH")) : true;
            if (((this.WX == "4X") & (this.pMode == "2ND")) & WBSetting.print_on_2nd_weight_4x)
            {
                this.buttonSavePrint.Enabled = true;
            }
            if (((this.WX == "2X") & (this.pMode == "1ST")) & WBSetting.print_loading_advise)
            {
                this.buttonSavePrint.Enabled = true;
            }
            if (((this.WX == "") & (this.pMode == "1ST")) && WBSetting.print_gatepass_advise)
            {
                this.buttonSavePrint.Enabled = true;
            }
            if (this.pMode == "MANUAL")
            {
                this.buttonSavePrint.Enabled = true;
            }
            if (WBSetting.gatepass_registration && ((this.pMode == "1ST") && (((this.WX == "2X") || (this.WX == "4X")) || (this.WX == "1X"))))
            {
                WBTable table3 = new WBTable();
                table3.OpenTable("wb_gatepass", "SELECT * FROM wb_gatepass WHERE " + WBData.CompanyLocation(" AND uniq = " + this.gatepass_uniq), WBData.conn);
                if (table3.DT.Rows.Count > 0)
                {
                    DataRow row = table3.DT.Rows[0];
                    this.textTruck.Text = row["truck_number"].ToString();
                    this.textTanker.Text = row["tanker_no"].ToString();
                    this.textDriverID.Text = row["license_no"].ToString();
                    this.textTransporter.Text = row["transporter_code"].ToString();
                    this.textDN.Text = row["delivery_note"].ToString();
                    this.textSEAL.Text = row["seal"].ToString();
                    this.textRemarkTicket.Text = row["Remark_Ticket"].ToString();
                    this.textRemarkReport.Text = row["Remark_Report"].ToString();
                    this.txtAddInfo.Text = row["Addi_Info"].ToString();
                    this.chk_return.Checked = row["mark_return"].ToString() == "Y";
                    this.text_ref_return.Text = row["return_ref"].ToString();
                    this.checkNOPW.Checked = row["nopw"].ToString() == "Y";
                    this.textWBNo.Text = row["opref"].ToString();
                    this.textGrossEstate.Text = row["gross_estate"].ToString();
                    this.textTareEstate.Text = row["tare_estate"].ToString();
                    this.textNetEstate.Text = row["net_estate"].ToString();
                    this.dateDelivery.Text = row["Delivery_Date"].ToString();
                    this.TimeDelivery.Text = row["Delivery_Time"].ToString();
                    this.TimeRegister.Text = row["in_time"].ToString();
                    this.dateRegister.Text = row["in_date"].ToString();
                    this.register_by = row["create_by"].ToString();
                    this.buttonAddDO.Focus();
                    this.tblDriver.ReOpen();
                    string[] aField = new string[] { "License_No" };
                    string[] aFind = new string[] { this.textDriverID.Text.Trim() };
                    int recNo = this.tblDriver.GetRecNo(aField, aFind);
                    if (recNo > -1)
                    {
                        this.textDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                    }
                    if (this.textTransporter.Text != "")
                    {
                        this.tblTransporter.ReOpen();
                        string[] textArray4 = new string[] { "Transporter_Code" };
                        string[] textArray5 = new string[] { this.textTransporter.Text };
                        DataRow data = this.tblTransporter.GetData(textArray4, textArray5);
                        if (data != null)
                        {
                            this.labelTransporterName.Text = data["Transporter_Name"].ToString().Trim();
                            this.labelTransporterName.Refresh();
                        }
                    }
                }
                table3.Dispose();
            }
            if ((this.spMode != "QTY") && (this.spMode != "EDIT_OPW"))
            {
                goto TR_0218;
            }
            else
            {
                this.pMode = "EDIT";
                foreach (Control control in this.GetOffsprings())
                {
                    if ((control.GetType() != typeof(Label)) || (control.GetType() != typeof(TabControl)))
                    {
                        control.Enabled = false;
                    }
                }
                this.buttonSave.Enabled = true;
                this.buttonCancel.Enabled = true;
                this.groupOtherParty.Enabled = true;
                foreach (Control control2 in this.groupOtherParty.Controls)
                {
                    control2.Enabled = true;
                }
                if (this.spMode == "QTY")
                {
                    this.groupFactoryWeight.Enabled = true;
                    foreach (Control control3 in this.groupFactoryWeight.Controls)
                    {
                        control3.Enabled = true;
                    }
                    this.tabControl1.Enabled = true;
                }
                else
                {
                    this.groupFactoryWeight.Enabled = false;
                    foreach (Control control4 in this.groupFactoryWeight.Controls)
                    {
                        control4.Enabled = false;
                    }
                    this.tabControl1.Enabled = false;
                }
                if (this.spMode != "EDIT_OPW")
                {
                    foreach (Control control7 in this.tabPageDO.Controls)
                    {
                        control7.Enabled = false;
                    }
                    goto TR_0228;
                }
                else
                {
                    this.tabControl1.Enabled = true;
                    this.tabPageDO.Enabled = true;
                    this.panel1.Enabled = true;
                    this.buttonEditDO.Enabled = true;
                    if ((WBData.sRegion == "2") && (WBSetting.locType == "1"))
                    {
                        this.tabPageQC.Enabled = true;
                        this.dgvQC.Enabled = true;
                        this.dgvQC.Enabled = true;
                        this.textQControl.Enabled = false;
                        this.textTankQC.Enabled = false;
                    }
                    else
                    {
                        foreach (Control control5 in this.tabPageQC.Controls)
                        {
                            control5.Enabled = false;
                        }
                    }
                }
            }
            foreach (Control control6 in this.tabPageDeduc.Controls)
            {
                control6.Enabled = false;
            }
            goto TR_0228;
        TR_0218:
            this.textRefNo.ReadOnly = this.pMode != "MANUAL";
            this.textRefNo.BackColor = (this.pMode != "MANUAL") ? Color.LightGray : Color.White;
            this.textRef_Date.ReadOnly = ((this.pMode != "MANUAL") && ((this.spMode != "QTY") && (this.spMode != "EDIT_OPW"))) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textRef_Date.BackColor = (this.pMode != "MANUAL") ? Color.LightGray : Color.White;
            this.textReport_Date.ReadOnly = ((this.pMode != "MANUAL") && ((this.spMode != "QTY") && (this.spMode != "EDIT_OPW"))) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textReport_Date.Enabled = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (this.spMode == "EDIT_OPW"))) || (Convert.ToInt32(WBUser.UserLevel) == 1);
            this.textReport_Date.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || ((this.spMode == "EDIT_OPW") || (Convert.ToInt32(WBUser.UserLevel) == 1)))) ? Color.White : Color.LightGray;
            this.text1st.ReadOnly = (Convert.ToInt32(WBUser.UserLevel) != 1) && (((this.spMode != "QTY") && (this.spMode != "EDIT_OPW")) && (this.pMode != "MANUAL"));
            this.text2nd.ReadOnly = (Convert.ToInt32(WBUser.UserLevel) != 1) && (((this.spMode != "QTY") && (this.spMode != "EDIT_OPW")) && (this.pMode != "MANUAL"));
            this.text3rd.ReadOnly = ((Convert.ToInt32(WBUser.UserLevel) == 1) || ((this.spMode == "QTY") || ((this.spMode == "EDIT_OPW") || (this.pMode == "MANUAL")))) ? (this.WX != "4X") : true;
            this.text4th.ReadOnly = ((Convert.ToInt32(WBUser.UserLevel) == 1) || ((this.spMode == "QTY") || ((this.spMode == "EDIT_OPW") || (this.pMode == "MANUAL")))) ? (this.WX != "4X") : true;
            this.textTime1st.ReadOnly = ((this.pMode != "MANUAL") && ((this.spMode != "QTY") && (this.spMode != "EDIT_OPW"))) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textTime2nd.ReadOnly = ((this.pMode != "MANUAL") && ((this.spMode != "QTY") && (this.spMode != "EDIT_OPW"))) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textTime3rd.ReadOnly = !((((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (this.spMode == "EDIT_OPW"))) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X"));
            this.textTime4th.ReadOnly = !((((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (this.spMode == "EDIT_OPW"))) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X"));
            this.textDate1st.ReadOnly = ((this.pMode != "MANUAL") && ((this.spMode != "QTY") && (this.spMode != "EDIT_OPW"))) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textDate2nd.ReadOnly = ((this.pMode != "MANUAL") && ((this.spMode != "QTY") && (this.spMode != "EDIT_OPW"))) && (Convert.ToInt32(WBUser.UserLevel) != 1);
            this.textDate3rd.ReadOnly = !((((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (this.spMode == "EDIT_OPW"))) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X"));
            this.textDate4th.ReadOnly = !((((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (this.spMode == "EDIT_OPW"))) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X"));
            this.textTime1st.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || ((this.spMode == "EDIT_OPW") || (Convert.ToInt32(WBUser.UserLevel) == 1)))) ? Color.White : Color.LightGray;
            this.textTime2nd.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || ((this.spMode == "EDIT_OPW") || (Convert.ToInt32(WBUser.UserLevel) == 1)))) ? Color.White : Color.LightGray;
            this.textTime3rd.BackColor = !((((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (this.spMode == "EDIT_OPW"))) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X")) ? Color.LightGray : Color.White;
            this.textTime4th.BackColor = !((((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (this.spMode == "EDIT_OPW"))) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X")) ? Color.LightGray : Color.White;
            this.textDate1st.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || ((this.spMode == "EDIT_OPW") || (Convert.ToInt32(WBUser.UserLevel) == 1)))) ? Color.White : Color.LightGray;
            this.textDate2nd.BackColor = ((this.pMode == "MANUAL") || ((this.spMode == "QTY") || ((this.spMode == "EDIT_OPW") || (Convert.ToInt32(WBUser.UserLevel) == 1)))) ? Color.White : Color.LightGray;
            this.textDate3rd.BackColor = !((((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (this.spMode == "EDIT_OPW"))) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X")) ? Color.LightGray : Color.White;
            this.textDate4th.BackColor = !((((this.pMode == "MANUAL") || ((this.spMode == "QTY") || (this.spMode == "EDIT_OPW"))) || (Convert.ToInt32(WBUser.UserLevel) == 1)) & (this.WX == "4X")) ? Color.LightGray : Color.White;
            this.label20.Visible = false;
            this.textQualityInfo.Visible = false;
            if ((this.spMode == "QTY") && (this.WX == "1X"))
            {
                this.textDN.Enabled = false;
                this.textReport_Date.Enabled = false;
                this.textReport_Date.BackColor = Color.LightGray;
                this.groupOtherParty.Enabled = false;
                this.text2nd.Enabled = false;
                this.textDate2nd.Enabled = false;
                this.textDate2nd.BackColor = Color.LightGray;
                this.textTime2nd.Enabled = false;
                this.textTime2nd.BackColor = Color.LightGray;
                this.dateRegister.Enabled = false;
                this.TimeRegister.Enabled = false;
            }
            if (Convert.ToInt16(WBUser.UserLevel) == 1)
            {
                this.textDate1st.Enabled = true;
                this.textTime1st.Enabled = true;
                this.textDate2nd.Enabled = true;
                this.textTime2nd.Enabled = true;
                this.textDate3rd.Enabled = true;
                this.textTime3rd.Enabled = true;
                this.textDate4th.Enabled = true;
                this.textTime4th.Enabled = true;
                this.textReport_Date.Enabled = true;
            }
            this.labelTankerMax.Text = "";
            this.labelStorageName.Text = "";
            this.labelCommName.Text = "";
            this.labelDriverName.Text = "";
            this.labelEstateName.Text = "";
            if (this.TimeRegister.Text == "")
            {
                this.TimeRegister.Text = DateTime.Now.ToShortTimeString();
            }
            this.buttonComm.Enabled = this.dgvDO.Rows.Count <= 0;
            if (this.pMode == "QC")
            {
                this._InitQC(this.dgvDO.Rows[0].Cells["DO_No"].Value.ToString());
                foreach (Control control11 in base.Controls)
                {
                    control11.Enabled = false;
                }
                this.tabControl1.Enabled = true;
                foreach (Control control12 in this.tabPageInfo.Controls)
                {
                    control12.Enabled = false;
                }
                foreach (Control control13 in this.tabPageDO.Controls)
                {
                    control13.Enabled = false;
                }
                foreach (Control control14 in this.tabPageDeduc.Controls)
                {
                    control14.Enabled = false;
                }
                foreach (Control control15 in this.tabPageDivision.Controls)
                {
                    control15.Enabled = false;
                }
                foreach (Control control16 in this.tabPagePorla.Controls)
                {
                    control16.Enabled = false;
                }
                foreach (Control control17 in this.tabPageCopra.Controls)
                {
                    control17.Enabled = false;
                }
                foreach (Control control18 in this.tabPageDL.Controls)
                {
                    control18.Enabled = false;
                }
                this.tabPageQC.Focus();
                this.buttonReadIndicator.Visible = false;
                this.buttonSavePrint.Visible = false;
                this.buttonSave.Enabled = true;
                this.buttonCancel.Enabled = true;
                this.textDN.Enabled = true;
                this.label2.Enabled = true;
            }
            else if (this.pMode == "DL")
            {
                this._InitQC(this.dgvDO.Rows[0].Cells["DO_No"].Value.ToString());
                foreach (Control control19 in base.Controls)
                {
                    control19.Enabled = false;
                }
                this.tabControl1.Enabled = true;
                foreach (Control control20 in this.tabPageInfo.Controls)
                {
                    control20.Enabled = false;
                }
                foreach (Control control21 in this.tabPageDO.Controls)
                {
                    control21.Enabled = true;
                }
                foreach (Control control22 in this.tabPageDeduc.Controls)
                {
                    control22.Enabled = false;
                }
                foreach (Control control23 in this.tabPageDivision.Controls)
                {
                    control23.Enabled = false;
                }
                foreach (Control control24 in this.tabPageQC.Controls)
                {
                    control24.Enabled = false;
                }
                foreach (Control control25 in this.tabPagePorla.Controls)
                {
                    control25.Enabled = false;
                }
                foreach (Control control26 in this.tabPageCopra.Controls)
                {
                    control26.Enabled = false;
                }
                this.tabPageDL.Focus();
                this.buttonReadIndicator.Visible = false;
                this.buttonSavePrint.Visible = false;
                this.buttonSave.Enabled = true;
                this.buttonCancel.Enabled = true;
            }
            else if (this.pMode == "VIEW")
            {
                this.tabControl1.Enabled = true;
                this.buttonSave.Visible = false;
                this.buttonReadIndicator.Visible = false;
                this.buttonSavePrint.Visible = false;
                this.buttonCancel.Enabled = true;
            }
            else if ((this.pMode == "EDIT") || (this.pMode == "CANCEL"))
            {
                this.buttonReadIndicator.Visible = false;
            }
            else if (this.pMode == "SPLIT")
            {
                foreach (Control control27 in base.Controls)
                {
                    control27.Enabled = false;
                }
                this.tabControl1.Enabled = true;
                foreach (Control control28 in this.tabPageInfo.Controls)
                {
                    control28.Enabled = false;
                }
                foreach (Control control29 in this.tabPageDO.Controls)
                {
                    control29.Enabled = true;
                }
                foreach (Control control30 in this.tabPageQC.Controls)
                {
                    control30.Enabled = false;
                }
                foreach (Control control31 in this.tabPageDeduc.Controls)
                {
                    control31.Enabled = false;
                }
                foreach (Control control32 in this.tabPageDivision.Controls)
                {
                    control32.Enabled = false;
                }
                foreach (Control control33 in this.tabPagePorla.Controls)
                {
                    control33.Enabled = false;
                }
                foreach (Control control34 in this.tabPageCopra.Controls)
                {
                    control34.Enabled = false;
                }
                foreach (Control control35 in this.tabPageDL.Controls)
                {
                    control35.Enabled = false;
                }
                this.tabPageDO.Focus();
                this.buttonReadIndicator.Visible = false;
                this.buttonSavePrint.Visible = false;
                this.buttonSave.Enabled = true;
                this.buttonCancel.Enabled = true;
            }
            if (this.pMode != "GRADING")
            {
                if (this.WX == "")
                {
                    this.buttonReadIndicator.Visible = false;
                }
            }
            else
            {
                this.Text = "GRADING & DIVISION/BLOCK (" + this.WX + ")";
                this._InitQC(this.dgvDO.Rows[0].Cells["DO_No"].Value.ToString());
                foreach (Control control36 in base.Controls)
                {
                    control36.Enabled = false;
                }
                this.tabControl1.Enabled = true;
                foreach (Control control37 in this.tabPageDO.Controls)
                {
                    control37.Enabled = false;
                }
                foreach (Control control38 in this.tabPageInfo.Controls)
                {
                    control38.Enabled = false;
                }
                foreach (Control control39 in this.tabPageQC.Controls)
                {
                    control39.Enabled = false;
                }
                foreach (Control control40 in this.tabPagePorla.Controls)
                {
                    control40.Enabled = false;
                }
                foreach (Control control41 in this.tabPageCopra.Controls)
                {
                    control41.Enabled = false;
                }
                foreach (Control control42 in this.tabPageDL.Controls)
                {
                    control42.Enabled = false;
                }
                this.tabPageDeduc.Focus();
                this.buttonReadIndicator.Visible = false;
                this.buttonSavePrint.Visible = false;
                this.buttonSave.Enabled = true;
                this.buttonCancel.Enabled = true;
            }
            if ((((this.pMode == "EDIT") || ((this.pMode == "QC") || (this.pMode == "DL"))) ? !this.tambahRecord : false) && ((this.tblTrans.DR["Split"].ToString() == "X") || (this.tblTrans.DR["Split"].ToString() == "Y")))
            {
                this.panelMainInfo.Enabled = false;
                this.buttonReadIndicator.Visible = false;
                this.buttonReset.Visible = false;
                if (Convert.ToInt16(WBUser.UserLevel) > 1)
                {
                    this.groupOtherParty.Enabled = false;
                    this.groupFactoryWeight.Enabled = false;
                }
            }
            if (this.WX == "1X")
            {
                foreach (Control control43 in this.tabControl1.Controls)
                {
                    control43.Enabled = false;
                }
            }
            this.typeContract(0);
            if ((WBSetting.activeTCS && (this.pMode == "EDIT")) && (Convert.ToInt16(WBUser.UserLevel) > 1))
            {
                this.textTruck.Enabled = false;
                this.buttonTruck.Enabled = false;
                this.textTruck2.Enabled = false;
                this.textDriverID.Enabled = false;
                this.buttonDriver.Enabled = false;
                this.textDriverName.Enabled = false;
                this.textTanker.Enabled = false;
                this.buttonTanker.Enabled = false;
                this.textTransporter.Enabled = false;
                this.buttonTranspt.Enabled = false;
            }
            try
            {
                this.txtMS.Text = (this.tblTrans.DR["materialStuffing"].ToString() != "") ? this.tblTrans.DR["materialStuffing"].ToString() : "0";
            }
            catch
            {
                this.txtMS.Text = "0";
            }
            if (!(((this.pMode != "1ST") || ((this.pMode == "1ST") & !this.tambahRecord)) ? (this.pMode != "MANUAL") : false))
            {
                this.ChangeDO = true;
                this.ChangeDiv = true;
                this.ChangeDeduc = true;
                this.ChangeDeducPorla = true;
                this.textDate1st.Text = DateTime.Now.ToString("dd/MM/yyyy");
                this.textTime1st.Text = DateTime.Now.ToString("HH:mm:ss");
                this.textDate2nd.Text = "";
                this.textTime2nd.Text = "";
                this.textDate3rd.Text = "";
                this.textTime3rd.Text = "";
                this.textDate4th.Text = "";
                this.textTime4th.Text = "";
                this.textRef_Date.Text = DateTime.Now.ToString("dd/MM/yyyy");
                this.checkISCC.Checked = false;
                this.checkISCC.Enabled = false;
                if (this.pMode != "MANUAL")
                {
                    this.textRefNo.Text = (this.WX != "1X") ? this.SetNoref(false) : this.SetNorefTemporary(false);
                }
                else if (WBSetting.Field("GM") == "Y")
                {
                    this.textRefNo.Text = this.SetNorefManual();
                }
                else if (WBSetting.Field("GM") == "N")
                {
                    this.textRefNo.Text = "";
                }
            }
            else
            {
                this.ChangeDO = false;
                this.ChangeDiv = false;
                this.ChangeDeduc = false;
                this.ChangeDeducPorla = false;
                this.ChangeQC = false;
                this.ChangeBatch = false;
                this.tblTrans.DR = this.tblTrans.DT.Rows[0];
                this.textDate1st.Text = (this.tblTrans.DR["Date1"].ToString().Length > 0) ? this.tblTrans.DR["Date1"].ToString().Substring(0, 10) : "";
                this.textTime1st.Text = (this.tblTrans.DR["Time1"].ToString().Length > 0) ? this.tblTrans.DR["time1"].ToString().Substring(0, 8) : "";
                this.textDate2nd.Text = (this.tblTrans.DR["Date2"].ToString().Length > 0) ? this.tblTrans.DR["Date2"].ToString().Substring(0, 10) : "";
                this.textTime2nd.Text = (this.tblTrans.DR["Time2"].ToString().Length > 0) ? this.tblTrans.DR["time2"].ToString().Substring(0, 8) : "";
                this.textDate3rd.Text = (this.tblTrans.DR["Date3"].ToString().Length > 0) ? this.tblTrans.DR["Date3"].ToString().Substring(0, 10) : "";
                this.textTime3rd.Text = (this.tblTrans.DR["Time3"].ToString().Length > 0) ? this.tblTrans.DR["time3"].ToString().Substring(0, 8) : "";
                this.textDate4th.Text = (this.tblTrans.DR["Date4"].ToString().Length > 0) ? this.tblTrans.DR["Date4"].ToString().Substring(0, 10) : "";
                this.textTime4th.Text = (this.tblTrans.DR["Time4"].ToString().Length > 0) ? this.tblTrans.DR["time4"].ToString().Substring(0, 8) : "";
                if (this.tblTrans.DR["Ref_Date"].ToString().Trim() != "")
                {
                    this.textRef_Date.Text = Convert.ToDateTime(this.tblTrans.DR["Ref_Date"].ToString()).ToShortDateString();
                }
                if (this.tblTrans.DR["Report_Date"].ToString().Trim() != "")
                {
                    this.textReport_Date.Text = Convert.ToDateTime(this.tblTrans.DR["Report_Date"].ToString()).ToShortDateString();
                }
                if (WBSetting.gatepass_registration && (this.gatepass_uniq == ""))
                {
                    WBTable table4 = new WBTable();
                    table4.OpenTable("wb_gatepass", "SELECT * FROM wb_gatepass WHERE " + WBData.CompanyLocation(" AND ref = '" + this.tblTrans.DR["Ref"].ToString()) + "'", WBData.conn);
                    if (table4.DT.Rows.Count == 1)
                    {
                        DataRow row4 = table4.DT.Rows[0];
                        this.gatepass_uniq = row4["uniq"].ToString();
                        this.gatepass_no = row4["gatepass_number"].ToString();
                        this.card_no = row4["card_no"].ToString();
                    }
                }
                if (this.pMode == "1ST")
                {
                    this.textDate1st.Text = DateTime.Now.ToShortDateString();
                    this.textTime1st.Text = (DateTime.Now.ToString("HH:mm") != "00:00") ? DateTime.Now.ToString("HH:mm:ss") : DateTime.Now.ToString("HH:01:ss");
                }
                else if (this.pMode == "2ND")
                {
                    this.textDate2nd.Text = DateTime.Now.ToShortDateString();
                    this.textTime2nd.Text = (DateTime.Now.ToString("HH:mm") != "00:00") ? DateTime.Now.ToString("HH:mm:ss") : DateTime.Now.ToString("HH:01:ss");
                    if (!this.checkNonContract.Checked)
                    {
                        if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                        {
                            string[] textArray6 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(true) };
                            this.textDN.Text = string.Concat(textArray6);
                        }
                        else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                        {
                            string[] textArray7 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(true) };
                            this.textDN.Text = string.Concat(textArray7);
                        }
                    }
                }
                else if (this.pMode == "3RD")
                {
                    this.textTruck.ReadOnly = true;
                    this.textTruck2.ReadOnly = false;
                    this.textDate3rd.Text = DateTime.Now.ToShortDateString();
                    this.textTime3rd.Text = DateTime.Now.ToString("HH:mm:ss");
                }
                else if (this.pMode == "4TH")
                {
                    this.textTruck.ReadOnly = true;
                    this.textTruck2.ReadOnly = false;
                    this.textDate4th.Text = DateTime.Now.ToShortDateString();
                    this.textTime4th.Text = DateTime.Now.ToString("HH:mm:ss");
                }
                else if (this.pMode == "EDIT")
                {
                    this.tbl_warning_trace.OpenTable("wb_warning_trace", "select * from wb_warning_trace where " + WBData.CompanyLocation(" and type = 'TRANSACTION'"), WBData.conn);
                    this.tmpTrans = this.tblTrans.DT.Clone();
                    this.transBefore = this.tmpTrans.NewRow();
                    string[] textArray8 = new string[] { "uniq" };
                    string[] textArray9 = new string[] { this.sUniq };
                    this.transBefore.ItemArray = this.tblTrans.GetData(textArray8, textArray9).ItemArray;
                    this.tmpTrans.Rows.Add(this.transBefore);
                    this.tmp_transDO = this.tblTransDO.DT.Clone();
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= this.tblTransDO.DT.Rows.Count)
                        {
                            if ((this.spMode != "QTY") && (this.spMode != "EDIT_OPW"))
                            {
                                this.textRefNo.ReadOnly = this.tblTrans.DR["Manual"].ToString() != "Y";
                                this.textRef_Date.ReadOnly = this.tblTrans.DR["Manual"].ToString() != "Y";
                                this.textReport_Date.ReadOnly = (this.tblTrans.DR["Manual"].ToString() != "Y") && (Convert.ToInt16(WBUser.UserLevel) != 1);
                                this.textRefNo.BackColor = (this.tblTrans.DR["Manual"].ToString() != "Y") ? Color.LightGray : Color.White;
                                this.textRef_Date.BackColor = (this.tblTrans.DR["Manual"].ToString() != "Y") ? Color.LightGray : Color.White;
                                if (WBSetting.Field("GM").ToString() != "Y")
                                {
                                    string str4 = (this.tblTrans.DR["_1ST"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_1ST"]:N0}";
                                    string str5 = (this.tblTrans.DR["_2ND"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_2ND"]:N0}";
                                    string str6 = (this.tblTrans.DR["_3RD"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_3RD"]:N0}";
                                    string str7 = (this.tblTrans.DR["_4TH"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_4TH"]:N0}";
                                    string str8 = this.tblTrans.DR["Report_Date"].ToString();
                                    this.textReport_Date.BackColor = ((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str8 != ""))) ? Color.White : Color.LightGray;
                                    this.textTime1st.ReadOnly = (this.tblTrans.DR["Manual"].ToString() != "Y") && ((Convert.ToInt16(WBUser.UserLevel) != 1) || (str4 == "0"));
                                    this.textTime2nd.ReadOnly = (this.tblTrans.DR["Manual"].ToString() != "Y") && ((Convert.ToInt16(WBUser.UserLevel) != 1) || (str5 == "0"));
                                    this.textTime3rd.ReadOnly = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str6 != "0"))) & (this.WX == "4X"));
                                    this.textTime4th.ReadOnly = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str7 != "0"))) & (this.WX == "4X"));
                                    this.textDate1st.ReadOnly = (this.tblTrans.DR["Manual"].ToString() != "Y") && ((Convert.ToInt16(WBUser.UserLevel) != 1) || (str4 == "0"));
                                    this.textDate2nd.ReadOnly = (this.tblTrans.DR["Manual"].ToString() != "Y") && ((Convert.ToInt16(WBUser.UserLevel) != 1) || (str5 == "0"));
                                    this.textDate3rd.ReadOnly = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str6 != "0"))) & (this.WX == "4X"));
                                    this.textDate4th.ReadOnly = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str7 != "0"))) & (this.WX == "4X"));
                                    this.textTime1st.BackColor = ((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str4 != "0"))) ? Color.White : Color.LightGray;
                                    this.textTime2nd.BackColor = ((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str5 != "0"))) ? Color.White : Color.LightGray;
                                    this.textTime3rd.BackColor = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str6 != "0"))) & (this.WX == "4X")) ? Color.LightGray : Color.White;
                                    this.textTime4th.BackColor = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str7 != "0"))) & (this.WX == "4X")) ? Color.LightGray : Color.White;
                                    this.textDate1st.BackColor = ((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str4 != "0"))) ? Color.White : Color.LightGray;
                                    this.textDate2nd.BackColor = ((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str5 != "0"))) ? Color.White : Color.LightGray;
                                    this.textDate3rd.BackColor = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str6 != "0"))) & (this.WX == "4X")) ? Color.LightGray : Color.White;
                                    this.textDate4th.BackColor = !(((this.tblTrans.DR["Manual"].ToString() == "Y") || ((Convert.ToInt16(WBUser.UserLevel) == 1) && (str7 != "0"))) & (this.WX == "4X")) ? Color.LightGray : Color.White;
                                    str4 = "";
                                    str5 = "";
                                    str6 = "";
                                    str7 = "";
                                    str8 = "";
                                }
                                if (WBUser.UserLevel != "3")
                                {
                                    this.textTruck.ReadOnly = false;
                                    this.textTruck2.ReadOnly = false;
                                }
                                this.buttonSavePrint.Visible = false;
                            }
                            break;
                        }
                        this.transDOBefore = this.tmp_transDO.NewRow();
                        this.tblTransDO.DR = this.tblTransDO.DT.Rows[num3];
                        this.transDOBefore.ItemArray = this.tblTransDO.DR.ItemArray;
                        this.tmp_transDO.Rows.Add(this.transDOBefore);
                        num3++;
                    }
                }
                this.textRefNo.Text = this.tblTrans.DR["Ref"].ToString();
                if (this.WX == "")
                {
                    this.WX = this.tblTrans.DR["WX"].ToString();
                }
                this.dateDelivery.Text = this.tblTrans.DR["Delivery_Date"].ToString();
                this.dateRegister.Text = this.tblTrans.DR["Register_Date"].ToString();
                this.TimeDelivery.Text = this.tblTrans.DR["Delivery_Time"].ToString();
                this.TimeRegister.Text = this.tblTrans.DR["Register_Time"].ToString();
                this.dateDelivery2.Text = this.tblTrans.DR["Delivery_Date2"].ToString();
                this.TimeDelivery2.Text = this.tblTrans.DR["Delivery_Time2"].ToString();
                this.textWBNo.Text = this.tblTrans.DR["Ticket"].ToString();
                this.textCommodity.Text = this.tblTrans.DR["Comm_Code"].ToString();
                this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and  comm_code = '" + this.textCommodity.Text.Trim() + "'"), WBData.conn);
                string[] aField = new string[] { "Comm_Code" };
                string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                DataRow data = this.tblComm.GetData(aField, aFind);
                if (data != null)
                {
                    this.labelCommName.Text = data["Comm_Name"].ToString().Trim();
                    this.textCommType.Text = data["Type"].ToString();
                    this.CommType = data["Type"].ToString();
                    this.is_trade = data["Trade"].ToString();
                    this.use_gunny = data["Using_Gunny"].ToString();
                    this.is_bulk = data["BulkPack"].ToString();
                    this.check_tare_comm = data["check_tare"].ToString();
                    if (this.use_gunny == "Y")
                    {
                        this.sGunnyNet = Convert.ToDouble(data["Netto_Gunny"].ToString().Trim());
                        this.sGunnyMin = Convert.ToDouble(data["Gross_Min_Gunny"].ToString().Trim());
                        this.sGunnyMax = Convert.ToDouble(data["Gross_Max_Gunny"].ToString().Trim());
                    }
                    else
                    {
                        this.sGunnyNet = 0.0;
                        this.sGunnyMax = 0.0;
                        this.sGunnyMin = 0.0;
                    }
                    this.textBox1.Text = this.sGunnyNet.ToString();
                }
                this.textDN.Enabled = !((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))) ? (!((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))) ? !(((this.spMode != "QTY") || (this.WX != "1X")) ? (this.pMode == "GRADING") : true) : false) : false;
                if (this.tblTrans.DR["mark_return"].ToString() == "X")
                {
                    this.chk_return.Checked = true;
                    this.text_ref_return.Text = this.tblTrans.DR["return_ref"].ToString();
                    this.ref_return_valid = true;
                    this.panel_return.Enabled = false;
                }
                this.tabPageShow(this.CommType);
                this.oldComm = this.textCommodity.Text;
                this.textTruck.Text = this.tblTrans.DR["Truck_Number"].ToString();
                this.textTruck2.Text = this.tblTrans.DR["Truck_Number2"].ToString();
                this.textTrailerNo.Text = this.tblTrans.DR["Truck_Trailer_Number"].ToString();
                if (((this.pMode == "VIEW") || ((this.spMode == "QTY") && (this.pMode == "EDIT"))) ? (this.WX != "1X") : true)
                {
                    this.tblDO.OpenTable("tmpDO", "select * from wb_contract where " + WBData.CompanyLocation(" and DO_NO = '" + this.tblTrans.DR["DO_NO"].ToString().Trim() + "'"), WBData.conn);
                    DataRow row5 = this.tblDO.DT.Rows[0];
                    if (row5 != null)
                    {
                        this.textQualityInfo.Text = row5["QualityInfo"].ToString().Trim();
                    }
                    this.tblDO.Close();
                }
                this.textTankQC.Text = this.tblTrans.DR["TankQC"].ToString();
                this.textTanker.Text = this.tblTrans.DR["Tanker"].ToString();
                if (this.textTanker.Text.Trim() != "")
                {
                    this.tblTanker.ReOpen();
                    string[] textArray12 = new string[] { "Tanker_No" };
                    string[] textArray13 = new string[] { this.textTanker.Text };
                    DataRow row6 = this.tblTanker.GetData(textArray12, textArray13);
                    if (row6 != null)
                    {
                        this.labelTankerMax.Text = "Max.Tanker = " + $"{row6["Capacity"]:N0}" + " Kg";
                        this.labelTankerMax.Text = (row6["Check_tanker"].ToString() != "P") ? ((row6["Check_tanker"].ToString() != "K") ? (this.labelTankerMax.Text + " (NOT CHECK)") : (this.labelTankerMax.Text + " (Tolerance : " + row6["CheckTankerKG"].ToString() + " KG)")) : (this.labelTankerMax.Text + " (Tolerance : " + row6["CheckTankerTol"].ToString() + " %)");
                    }
                }
                this.textStorage.Text = this.tblTrans.DR["Storage"].ToString();
                if (this.textStorage.Text.Trim() != "")
                {
                    string[] textArray14 = new string[] { "Storage_Code" };
                    string[] textArray15 = new string[] { this.textStorage.Text };
                    DataRow row7 = this.tblStorage.GetData(textArray14, textArray15);
                    if (row7 != null)
                    {
                        this.labelStorageName.Text = row7["Storage_Name"].ToString();
                    }
                }
                this.textDriverID.Text = this.tblTrans.DR["License_No"].ToString();
                this.labelDriverName.Text = this.tblTrans.DR["Name"].ToString();
                this.textDriverName.Text = this.tblTrans.DR["Name"].ToString();
                this.textTransporter.Text = this.tblTrans.DR["Transporter_Code"].ToString();
                if (this.textTransporter.Text.Length > 0)
                {
                    string[] textArray16 = new string[] { "Transporter_Code" };
                    string[] textArray17 = new string[] { this.textTransporter.Text };
                    DataRow row8 = this.tblTransporter.GetData(textArray16, textArray17);
                    if (row8 != null)
                    {
                        this.labelTransporterName.Text = row8["Transporter_Name"].ToString();
                    }
                }
                this.textDN.Text = this.tblTrans.DR["Delivery_Note"].ToString();
                this.textUnloading.Text = this.tblTrans.DR["Unloading"].ToString();
                this.textRendCPO.Text = this.tblTrans.DR["Rend_CPO"].ToString();
                if (this.textRendCPO.Text.Trim() == "")
                {
                    this.textRendCPO.Text = "0";
                }
                this.textGrade.Text = this.tblTrans.DR["FFB_Grade"].ToString();
                this.textRemarkTicket.Text = this.tblTrans.DR["Remark_Ticket"].ToString();
                this.textRemarkReport.Text = this.tblTrans.DR["Remark_Report"].ToString();
                this.textPL3.Text = this.tblTrans.DR["PL3_No"].ToString();
                this.txtAddInfo.Text = this.tblTrans.DR["Addi_Info"].ToString();
                this.textSEAL.Text = this.tblTrans.DR["Seal"].ToString();
                if (this.tblTrans.DR["Estate"].ToString().Trim() != "")
                {
                    this.textEstate.Text = this.tblTrans.DR["Estate"].ToString();
                    string[] textArray18 = new string[] { "Estate_Code" };
                    string[] textArray19 = new string[] { this.textEstate.Text };
                    DataRow row9 = this.tblEstate.GetData(textArray18, textArray19);
                    if (row9 != null)
                    {
                        this.labelEstateName.Text = row9["Estate_Name"].ToString();
                    }
                }
                this.textGrossEstate.Text = (this.tblTrans.DR["Gross_Estate"].ToString() == "") ? "0" : $"{this.tblTrans.DR["Gross_Estate"]:N0}";
                this.textTareEstate.Text = (this.tblTrans.DR["Tare_Estate"].ToString() == "") ? "0" : $"{this.tblTrans.DR["Tare_Estate"]:N0}";
                this.textNetEstate.Text = (this.tblTrans.DR["Net_Estate"].ToString() == "") ? "0" : $"{this.tblTrans.DR["Net_Estate"]:N0}";
                this.comboTransType.Text = this.tblTrans.DR["Transaction_Code"].ToString();
                this.TransType();
                this.checkNOPW.Checked = this.tblTrans.DR["NOPW"].ToString() == "Y";
                string str3 = "";
                if ((this.rowTransType != null) && (data != null))
                {
                    WBCondition condition = new WBCondition();
                    DataRow[] dgRows = new DataRow[] { this.rowTransType, data };
                    condition.fillParameter("NOPW", dgRows);
                    str3 = condition.getResult() ? "Y" : "N";
                    condition.Dispose();
                }
                if ((WBSetting.Field("NOPW") == "Y") && (str3 == "Y"))
                {
                    this.checkNOPW.Visible = true;
                    this.checkNOPW.Enabled = this.pMode != "VIEW";
                }
                else
                {
                    this.checkNOPW.Checked = false;
                    this.checkNOPW.Visible = false;
                    this.checkNOPW.Enabled = false;
                }
                if (this.MSinTrx == "Y")
                {
                    this.txtMS.ReadOnly = false;
                    this.txtMS.Enabled = (Convert.ToInt32(WBUser.UserLevel) == 1) || (((this.spMode == "QTY") || ((this.pMode == "1ST") || (this.pMode == "2ND"))) || (this.pMode == "MANUAL"));
                }
                else
                {
                    this.txtMS.Enabled = false;
                    this.txtMS.ReadOnly = true;
                }
                this.text1st.Text = (this.tblTrans.DR["_1ST"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_1ST"]:N0}";
                this.text2nd.Text = (this.tblTrans.DR["_2ND"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_2ND"]:N0}";
                this.text3rd.Text = (this.tblTrans.DR["_3RD"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_3RD"]:N0}";
                this.text4th.Text = (this.tblTrans.DR["_4TH"].ToString() == "") ? "0" : $"{this.tblTrans.DR["_4TH"]:N0}";
                this.textDeducTotal.Text = $"{this.tblTrans.DR["Deduction"]:N0}";
                this.textNet.Text = $"{this.tblTrans.DR["Net"]:N0}";
                if (this.tblTransCopra.DT.Rows.Count > 0)
                {
                    this.tblTransCopra.DR = this.tblTransCopra.DT.Rows[0];
                    this.fCopra.textColly1.Text = this.tblTransCopra.DR["Colly1"].ToString();
                    this.fCopra.textColly2.Text = this.tblTransCopra.DR["Colly2"].ToString();
                    this.fCopra.textColly3.Text = this.tblTransCopra.DR["Colly3"].ToString();
                    this.fCopra.textColly4.Text = this.tblTransCopra.DR["Colly4"].ToString();
                    this.fCopra.textColly5.Text = this.tblTransCopra.DR["Colly5"].ToString();
                    this.fCopra.textColly6.Text = this.tblTransCopra.DR["Colly6"].ToString();
                    this.fCopra.textColly7.Text = this.tblTransCopra.DR["Colly7"].ToString();
                    this.fCopra.textColly8.Text = this.tblTransCopra.DR["Colly8"].ToString();
                    this.fCopra.textColly1KG.Text = this.tblTransCopra.DR["NetColly1"].ToString();
                    this.fCopra.textColly2KG.Text = this.tblTransCopra.DR["NetColly2"].ToString();
                    this.fCopra.textColly3KG.Text = this.tblTransCopra.DR["NetColly3"].ToString();
                    this.fCopra.textColly4KG.Text = this.tblTransCopra.DR["NetColly4"].ToString();
                    this.fCopra.textColly5KG.Text = this.tblTransCopra.DR["NetColly5"].ToString();
                    this.fCopra.textColly6KG.Text = this.tblTransCopra.DR["NetColly6"].ToString();
                    this.fCopra.textColly7KG.Text = this.tblTransCopra.DR["NetColly7"].ToString();
                    this.fCopra.textColly8KG.Text = this.tblTransCopra.DR["NetColly8"].ToString();
                    this.fCopra.textJlhColly1.Text = this.tblTransCopra.DR["JlhColly1"].ToString();
                    this.fCopra.textJlhColly2.Text = this.tblTransCopra.DR["JlhColly2"].ToString();
                    this.fCopra.textJlhColly3.Text = this.tblTransCopra.DR["JlhColly3"].ToString();
                    this.fCopra.textJlhColly4.Text = this.tblTransCopra.DR["JlhColly4"].ToString();
                    this.fCopra.textJlhColly5.Text = this.tblTransCopra.DR["JlhColly5"].ToString();
                    this.fCopra.textJlhColly6.Text = this.tblTransCopra.DR["JlhColly6"].ToString();
                    this.fCopra.textJlhColly7.Text = this.tblTransCopra.DR["JlhColly7"].ToString();
                    this.fCopra.textForm1.Text = this.tblTransCopra.DR["Form1"].ToString();
                    this.fCopra.textForm2.Text = this.tblTransCopra.DR["Form2"].ToString();
                    this.fCopra.textForm3.Text = this.tblTransCopra.DR["Form3"].ToString();
                    this.fCopra.textForm4.Text = this.tblTransCopra.DR["Form4"].ToString();
                    this.fCopra.textForm5.Text = this.tblTransCopra.DR["Form5"].ToString();
                    this.fCopra.textForm6.Text = this.tblTransCopra.DR["Form6"].ToString();
                    this.fCopra.textForm7.Text = this.tblTransCopra.DR["Form7"].ToString();
                    this.fCopra.textForm1KG.Text = this.tblTransCopra.DR["NetF1"].ToString();
                    this.fCopra.textForm2KG.Text = this.tblTransCopra.DR["NetF2"].ToString();
                    this.fCopra.textForm3KG.Text = this.tblTransCopra.DR["NetF3"].ToString();
                    this.fCopra.textForm4KG.Text = this.tblTransCopra.DR["NetF4"].ToString();
                    this.fCopra.textForm5KG.Text = this.tblTransCopra.DR["NetF5"].ToString();
                    this.fCopra.textForm6KG.Text = this.tblTransCopra.DR["NetF6"].ToString();
                    this.fCopra.textForm7KG.Text = this.tblTransCopra.DR["NetF7"].ToString();
                    this.fCopra.textPotAbu.Text = (this.tblTransCopra.DR["PotAbu"].ToString().Trim() == "") ? "0" : this.tblTransCopra.DR["PotAbu"].ToString().Trim();
                    this.fCopra.textPotLain.Text = this.tblTransCopra.DR["PotLain"].ToString();
                    this.fCopra.textFormTotalKG.Text = this.tblTransCopra.DR["TPColly"].ToString();
                    this.fCopra.textTPAir.Text = this.tblTransCopra.DR["TPAir"].ToString();
                    this.fCopra.textJlhColly.Text = this.tblTransCopra.DR["JlhColly"].ToString();
                    this.textTotalCopra.Text = this.tblTransCopra.DR["TPCopra"].ToString();
                }
                this.textBunchTotal.Text = this.tblTrans.DR["TotalBunch"].ToString();
                this.textBunchDeduc.Text = this.tblTrans.DR["TotalBunchGrading"].ToString();
                this.labelReject.Text = (this.tblTrans.DR["UnitName"].ToString() == "") ? "Bunch" : this.tblTrans.DR["UnitName"].ToString();
                this.textAvg.Text = this.tblTrans.DR["Average"].ToString();
                this.radioButtonEntryTotalBunch.Checked = false;
                this.radioButtonEntryTotalBunch.Checked = this.tblTrans.DR["EntryAVGorBunch"].ToString() == "1";
                this.radioButtonEntryAVG.Checked = this.tblTrans.DR["EntryAVGorBunch"].ToString() == "0";
                if (WBSetting.Field("ScanCardSPB") == "Y")
                {
                    this.radioButtonEntryAVG.Checked = false;
                    this.radioButtonEntryTotalBunch.Checked = true;
                }
                this.checkEntryAVGorTotalBunch();
                this.checkEstate.Checked = this.tblTrans.DR["Truck_Number2"].ToString() == "Y";
                this.checkEstate.Checked = this.tblTrans.DR["EstateDiff"].ToString() == "Y";
                this.checkNonContract.Checked = this.tblTrans.DR["NonContract"].ToString() == "Y";
                if (this.checkNonContract.Checked)
                {
                    this.typeContract(1);
                }
                else
                {
                    this.typeContract(0);
                }
                this.textCust.Text = this.tblTrans.DR["Relation_code"].ToString();
                this.textFruitsType.Text = this.tblTrans.DR["Fruits_Type"].ToString();
                this.textFruitsType.Refresh();
                this.textTBSReject.Text = (this.tblTrans.DR["Tbs_reject"].ToString().Trim() == "") ? "0" : this.tblTrans.DR["Tbs_reject"].ToString();
                this.textReason.Text = this.tblTrans.DR["Reason"].ToString();
                if (this.tblTrans.DR["ISCC_Checked"].ToString() == "Y")
                {
                    this.checkISCC.Checked = true;
                    this.textISCC.Text = this.tblTrans.DR["ISCC_No"].ToString();
                    this.textISCC2.Text = this.tblTrans.DR["ISCC_No2"].ToString();
                    if (this.tblTrans.DR["ISCC_GC_Checked"].ToString() == "Y")
                    {
                        this.radioGHG1.Checked = true;
                    }
                    else
                    {
                        this.radioGHG2.Checked = true;
                        this.textGHG.Text = this.tblTrans.DR["ISCC_Weight"].ToString();
                    }
                }
                if (this.tblTrans.DR["transWarning"].ToString().Length > 4)
                {
                    this.transIndStableWarning = this.tblTrans.DR["transWarning"].ToString().Substring(0, 4);
                }
                this.HitNet();
                this.HitNetEstate();
            }
            this.buttonReadIndicator.Visible = (this.pMode != "EDIT") && (this.WX.Trim() != "");
            if (this.Copied)
            {
                this.WX = "2X";
                this.comboTransType.Text = this.tblTrans.DR["Transaction_Code"].ToString();
                this.TransType();
                this.textCommodity.Text = this.tblTrans.DR["Comm_Code"].ToString();
                this._InitBlankGrading(this.textCommodity.Text);
                this._InitBlankGradingPorla(this.textCommodity.Text);
                if (this.textCommodity.Text.Length > 0)
                {
                    this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and  comm_code = '" + this.textCommodity.Text.Trim() + "'"), WBData.conn);
                    string[] aField = new string[] { "Comm_Code" };
                    string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                    DataRow data = this.tblComm.GetData(aField, aFind);
                    if (data != null)
                    {
                        this.labelCommName.Text = data["Comm_Name"].ToString().Trim();
                        this.textCommType.Text = data["Type"].ToString();
                        this.CommType = data["Type"].ToString();
                        this.tabPageShow(this.CommType);
                    }
                }
                int num4 = 0;
                while (true)
                {
                    if (num4 >= this.dgvDO.RowCount)
                    {
                        int num5 = 0;
                        while (true)
                        {
                            if (num5 >= this.dgvQC.RowCount)
                            {
                                this.Text = this.pMode.Trim() + " WEIGHT TRANSACTION ( " + this.WX.Trim() + " )";
                                this.buttonReadIndicator.Visible = true;
                                if (this.dgvDO.Rows.Count > 0)
                                {
                                    this._InitBlankQC(this.dgvDO.Rows[0].Cells["DO_NO"].ToString());
                                    this._InitBlankGrading(this.textCommodity.Text);
                                    this._InitBlankGradingPorla(this.textCommodity.Text);
                                }
                                break;
                            }
                            this.dgvQC.Rows[num5].Cells["Ref"].Value = this.textRefNo.Text;
                            num5++;
                        }
                        break;
                    }
                    this.dgvDO.Rows[num4].Cells["Ref"].Value = this.textRefNo.Text;
                    this.dgvDO.Rows[num4].Cells["Netto"].Value = 0;
                    this.dgvDO.Rows[num4].Cells["Estate_qty"].Value = 0;
                    this.dgvDO.Rows[num4].Cells["Bruto"].Value = 0;
                    this.dgvDO.Rows[num4].Cells["Tarra"].Value = 0;
                    this.dgvDO.Rows[num4].Cells["ConvNett"].Value = 0;
                    if (num4 == 0)
                    {
                        this.textTransporter.Text = this.dgvDO.Rows[num4].Cells["Transporter_Code"].Value.ToString();
                    }
                    num4++;
                }
            }
            if (this.pMode == "COPY")
            {
                this.textDriverID.Text = "";
                this.textDN.Text = "";
                this.textRemarkReport.Text = "";
                this.textPL3.Text = "";
                this.textRemarkTicket.Text = "";
                this.textSEAL.Text = "";
                this.txtAddInfo.Text = "";
                this.text1st.Text = "";
                this.text2nd.Text = "";
                this.txtMS.Text = "";
            }
            if ((WBSetting.bGate == "Y") && !WBSetting.activeTCS)
            {
                if (((this.pMode == "1ST") || (this.pMode == "3RD")) & (this.WX != ""))
                {
                    if ((WBSetting.gateType == "1") || (WBSetting.gateType == ""))
                    {
                        WBBarrierGate1.runGate(WBSetting.gate1Open);
                    }
                    else if (WBSetting.gateType == "2")
                    {
                        this.returnGate = WBBarrierGate2.openGate(WBSetting.gate1IP, WBSetting.gate1Port);
                        if (!this.returnGate)
                        {
                            MessageBox.Show("Error open gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            base.Dispose();
                            base.Close();
                        }
                    }
                }
                if (((this.pMode == "2ND") || (this.pMode == "4TH")) & (this.WX != ""))
                {
                    if ((WBSetting.gateType == "1") || (WBSetting.gateType == ""))
                    {
                        WBBarrierGate1.runGate(WBSetting.gate1OpenOut);
                    }
                    else if (WBSetting.gateType == "2")
                    {
                        this.returnGate = WBBarrierGate2.openGate(WBSetting.gate1IPOut, WBSetting.gate1PortOut);
                        if (!this.returnGate)
                        {
                            MessageBox.Show("Error open gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            base.Dispose();
                            base.Close();
                        }
                    }
                }
            }
            this.textNettoBatch_Leave(this, e);
            if (this.pMode == "VIEW")
            {
                this.buttonReadIndicator.Visible = false;
            }
            if (this.spMode == "EDIT_OPW")
            {
                this.textDN.ReadOnly = true;
                this.textReport_Date.ReadOnly = true;
            }
            if (this.chk_return.Checked)
            {
                this.buttonEditDO.Enabled = false;
                this.buttonAddDO.Enabled = false;
            }
            if ((WBData.sRegion == "2") && (WBSetting.locType == "1"))
            {
                this.labelGrade.Visible = true;
                this.textGrade.Visible = true;
                this.label41.Text = "OER";
            }
            if (WBSetting.Field("ScanCardSPB").ToString() != "Y")
            {
                this.buttonScanCard.Visible = false;
            }
            if (((this.WX == "") & (this.pMode == "1ST")) && WBSetting.dummy_contract_on_registration)
            {
                this.auto_generate_dummy_contract = true;
                this.buttonAddDO.PerformClick();
            }
            if ((this.WX == "4X") && (this.pMode == "4TH"))
            {
                this.text3rd.Text = $"{this.tblTrans__.DT.Rows[0]["_1st"].ToString():N0}";
                this.textDate3rd.Text = this.tblTrans__.DT.Rows[0]["date1"].ToString().Substring(0, 10);
                this.textTime3rd.Text = this.tblTrans__.DT.Rows[0]["time1"].ToString().Substring(0, 8);
                this.textTruck2.Text = this.tblTrans__.DT.Rows[0]["truck_number"].ToString();
                this.HitNet();
                this.hitungBTN();
                this.calc_loadstuff();
                if (this.dgvDeduc.Enabled && ((this.dgvDeduc.RowCount > 0) && (this.textDeducTotal.Text != "0")))
                {
                    this.recalc_deduc();
                }
            }
            if (((this.pMode == "1ST") && WBSetting.activeTCS) && (this.dgvDO.RowCount > 0))
            {
                this.entryDO("EDIT");
            }
            if (WBSetting.activeTCS)
            {
                WBTable table5 = new WBTable();
                table5.OpenTable("wb_gatepass", "SELECT WX FROM wb_gatepass WHERE " + WBData.CompanyLocation(" AND gatepass_number = '" + this.gatepass_no + "'"), WBData.conn);
                if (table5.DT.Rows.Count > 0)
                {
                    this.buttonSavePrint.Visible = false;
                }
                table5.Dispose();
                if ((WBSetting.activeTCS && ((this.pMode == "1ST") && this.Copied)) && this.manualCopyfromMainForm)
                {
                    this.buttonReadIndicator.Visible = false;
                }
            }
            Cursor.Current = Cursors.Default;
            return;
        TR_0228:
            foreach (Control control8 in this.tabPageInfo.Controls)
            {
                control8.Enabled = false;
            }
            foreach (Control control9 in this.tabPageCont.Controls)
            {
                control9.Enabled = false;
            }
            foreach (Control control10 in this.tabPageCont.Controls)
            {
                control10.Enabled = false;
            }
            goto TR_0218;
        }

        private void FormTransaction_Shown(object sender, EventArgs e)
        {
            if (WBSetting.Field("ScanCardSPB").ToString() != "Y")
            {
                this.buttonScanCard.Visible = false;
            }
            else if ((this.pMode != "1ST") && (this.WX != ""))
            {
                this.buttonScanCard.Visible = false;
            }
            else
            {
                this.buttonScanCard.Visible = true;
                this.buttonScanCard.Focus();
                this.nfcReader = new WBNFC();
            }
        }

        private double GetDeduc()
        {
            double num = 0.0;
            foreach (DataGridViewRow row in (IEnumerable) this.dgvDeduc.Rows)
            {
                num += (row.Cells["Deduct"].Value.ToString() == "Y") ? Convert.ToDouble(row.Cells["KgDeduc"].Value.ToString()) : 0.0;
            }
            return num;
        }

        private double GetDeducByUnit()
        {
            double num = 0.0;
            foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
            {
                if (row.Cells["TotalDeducUnit"].Value != null)
                {
                    num += Program.StrToDouble(row.Cells["TotalDeducUnit"].Value.ToString(), 0);
                }
            }
            return num;
        }

        private void groupFactoryWeight_Enter(object sender, EventArgs e)
        {
        }

        private void HitNet()
        {
            this.textDeducTotal.Text = $"{((this.GetDeducByUnit() + this.GetDeduc()) + Program.StrToDouble(this.txtMS.Text, 0)) + Program.StrToDouble(this.textTotalCopra.Text, 0):N0}";
            if ((Program.CheckNumeric(this.text1st) && (Program.CheckNumeric(this.text2nd) && (Program.CheckNumeric(this.text3rd) && Program.CheckNumeric(this.text4th)))) && Program.CheckNumeric(this.textDeducTotal))
            {
                double num = Math.Abs((double) (Convert.ToDouble(this.text1st.Text) - Convert.ToDouble(this.text2nd.Text)));
                double num2 = Math.Abs((double) ((num + Convert.ToDouble(this.text3rd.Text)) - Convert.ToDouble(this.text4th.Text)));
                this.textNET1.Text = $"{num:N0}";
                this.textNET2.Text = $"{num2:N0}";
                this.textNet.Text = $"{num2 - Convert.ToDouble(this.textDeducTotal.Text):N0}";
                this.textVariance.Text = Convert.ToString((double) (Convert.ToDouble(this.textNet.Text) - Convert.ToDouble(this.textNetEstate.Text)));
            }
            this.settingTabControl();
        }

        private void HitNetEstate()
        {
            if (Program.CheckNumeric(this.textGrossEstate) && Program.CheckNumeric(this.textTareEstate))
            {
                double num = Math.Abs((double) (Convert.ToDouble(this.textGrossEstate.Text) - Convert.ToDouble(this.textTareEstate.Text)));
                this.textNetEstate.Text = $"{num:N0}";
                this.textVariance.Text = Convert.ToString((double) (Convert.ToDouble(this.textNet.Text) - Convert.ToDouble(this.textNetEstate.Text)));
                if (this.dgvDO.Rows.Count > 0)
                {
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 >= this.dgvDO.Rows.Count)
                        {
                            this.dgvDO.Rows[0].Cells["estate_qty"].Value = num;
                            break;
                        }
                        num -= Convert.ToDouble(this.dgvDO.Rows[num2].Cells["estate_qty"].Value);
                        num2++;
                    }
                }
            }
        }

        private double hitQtyToday(string pRef, string pDate, string pRelation)
        {
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "Select sum(NET) as Net from wb_transaction where relation_code = '", pRelation, "'and report_date <= '", Program.DTOC(Convert.ToDateTime(pDate)), "' and Ref <> '", pRef, "' and (deleted is null or deleted = 'N')  and report_date is not null " };
            table.OpenTable("tmp_transaction", string.Concat(textArray1), WBData.conn);
            return ((table.DT.Rows.Count <= 0) ? 0.0 : Program.StrToDouble(table.DT.Rows[0]["net"].ToString(), 0));
        }

        private void hitungBTN()
        {
            double num2;
            this.text1st.Text = (this.text1st.Text.Trim() == "") ? "0" : this.text1st.Text;
            this.text2nd.Text = (this.text2nd.Text.Trim() == "") ? "0" : this.text2nd.Text;
            double num = num2 = 0.0;
            int num3 = this.dgvDO.RowCount - 1;
            while (true)
            {
                object obj4;
                object obj5;
                if (num3 < 0)
                {
                    if ((this.WX == "2X") || ((this.WX == "4X") && ((this.pMode == "1ST") || (this.pMode == "2ND"))))
                    {
                        if (this.dgvDO.Rows.Count >= 1)
                        {
                            if (Program.StrToDouble(this.text1st.Text, 0) > Program.StrToDouble(this.text2nd.Text, 0))
                            {
                                this.dgvDO.Rows[0].Cells["Netto"].Value = (Program.StrToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString(), 0) + Program.StrToDouble(this.textNet.Text, 0)) - num;
                                this.dgvDO.Rows[0].Cells["Bruto"].Value = (Program.StrToDouble(this.dgvDO.Rows[0].Cells["Bruto"].Value.ToString(), 0) + Program.StrToDouble(this.text1st.Text, 0)) - num2;
                                this.dgvDO.Rows[0].Cells["Tarra"].Value = Program.StrToDouble(this.text2nd.Text, 0);
                                if (((this.dgvDO.Rows[0].Cells["Estate_qty"].Value == null) || (this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString() == "")) || (this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString() == "0"))
                                {
                                    this.dgvDO.Rows[0].Cells["Estate_Qty"].Value = Program.StrToDouble(this.textNetEstate.Text, 0);
                                }
                            }
                            else
                            {
                                this.dgvDO.Rows[0].Cells["Netto"].Value = (Program.StrToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString(), 0) + Program.StrToDouble(this.textNet.Text, 0)) - num;
                                this.dgvDO.Rows[0].Cells["Bruto"].Value = (Program.StrToDouble(this.dgvDO.Rows[0].Cells["Bruto"].Value.ToString(), 0) + Program.StrToDouble(this.text2nd.Text, 0)) - num2;
                                this.dgvDO.Rows[0].Cells["Tarra"].Value = Program.StrToDouble(this.text1st.Text, 0);
                                if (((this.dgvDO.Rows[0].Cells["Estate_qty"].Value == null) || (this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString() == "")) || (this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString() == "0"))
                                {
                                    this.dgvDO.Rows[0].Cells["Estate_Qty"].Value = Program.StrToDouble(this.textNetEstate.Text, 0);
                                }
                            }
                        }
                    }
                    else if (this.dgvDO.Rows.Count >= 1)
                    {
                        if (this.transType == "I")
                        {
                            this.dgvDO.Rows[0].Cells["Netto"].Value = (Program.StrToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString(), 0) + Program.StrToDouble(this.textNet.Text, 0)) - num;
                            this.dgvDO.Rows[0].Cells["Bruto"].Value = (Program.StrToDouble(this.dgvDO.Rows[0].Cells["Bruto"].Value.ToString(), 0) + Program.StrToDouble(this.text1st.Text, 0)) - num2;
                            this.dgvDO.Rows[0].Cells["Tarra"].Value = (Program.StrToDouble(this.text4th.Text, 0) - Program.StrToDouble(this.text3rd.Text, 0)) + Program.StrToDouble(this.text2nd.Text, 0);
                            if (((this.dgvDO.Rows[0].Cells["Estate_qty"].Value == null) || (this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString() == "")) || (this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString() == "0"))
                            {
                                this.dgvDO.Rows[0].Cells["Estate_Qty"].Value = Program.StrToDouble(this.textNetEstate.Text, 0);
                            }
                        }
                        else
                        {
                            this.dgvDO.Rows[0].Cells["Netto"].Value = (Program.StrToDouble(this.dgvDO.Rows[0].Cells["Netto"].Value.ToString(), 0) + Program.StrToDouble(this.textNet.Text, 0)) - num;
                            this.dgvDO.Rows[0].Cells["Bruto"].Value = (Program.StrToDouble(this.dgvDO.Rows[0].Cells["Bruto"].Value.ToString(), 0) + Program.StrToDouble(this.text4th.Text, 0)) - num2;
                            this.dgvDO.Rows[0].Cells["Tarra"].Value = (Program.StrToDouble(this.text1st.Text, 0) - Program.StrToDouble(this.text2nd.Text, 0)) + Program.StrToDouble(this.text3rd.Text, 0);
                            if (((this.dgvDO.Rows[0].Cells["Estate_qty"].Value == null) || (this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString() == "")) || (this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString() == "0"))
                            {
                                this.dgvDO.Rows[0].Cells["Estate_Qty"].Value = Program.StrToDouble(this.textNetEstate.Text, 0);
                            }
                        }
                    }
                    if ((this.text2nd.Text != "") || (this.text2nd.Text != "0"))
                    {
                        try
                        {
                            double num4 = Program.StrToDouble(this.textNET1.Text, 0);
                            if (this.textGunnyBatch.Text == "0")
                            {
                                this.textBox3.Text = "0.00";
                            }
                            else
                            {
                                this.textBox3.Text = (num4 / Program.StrToDouble(this.textGunnyBatch.Text, 0)).ToString("0.00");
                            }
                        }
                        catch
                        {
                            this.textBox3.Text = "0";
                        }
                        this.calc_loadstuff();
                    }
                    return;
                }
                if (this.dgvDO.Rows[num3].Cells["Netto"].Value != null)
                {
                    obj4 = this.dgvDO.Rows[num3].Cells["Netto"].Value;
                }
                else
                {
                    obj4 = this.dgvDO.Rows[num3].Cells["Netto"].Value = "0";
                }
                this.dgvDO.Rows[num3].Cells["Netto"].Value = obj4;
                if (this.dgvDO.Rows[num3].Cells["Bruto"].Value != null)
                {
                    obj5 = this.dgvDO.Rows[num3].Cells["Netto"].Value;
                }
                else
                {
                    obj5 = this.dgvDO.Rows[num3].Cells["Netto"].Value = "0";
                }
                this.dgvDO.Rows[num3].Cells["Bruto"].Value = obj5;
                num += Program.StrToDouble(this.dgvDO.Rows[num3].Cells["Netto"].Value.ToString(), 0);
                num2 += Program.StrToDouble(this.dgvDO.Rows[num3].Cells["Bruto"].Value.ToString(), 0);
                num3--;
            }
        }

        private void InitCombo()
        {
            this.tblTransType.DT.DefaultView.Sort = "Transaction_Code ASC";
            this.tblTransType.DT = this.tblTransType.DT.DefaultView.ToTable();
            this.comboTransType.Items.Clear();
            this.comboTransType.Text = "";
            foreach (DataRow row in this.tblTransType.DT.Rows)
            {
                this.comboTransType.Items.Add(row["Transaction_Code"].ToString());
                if (this.comboTransType.Text == "")
                {
                }
                if (this.comboTransType.Text.Trim() == row["Transaction_Code"].ToString().Trim())
                {
                }
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            DataGridViewCellStyle style4 = new DataGridViewCellStyle();
            DataGridViewCellStyle style5 = new DataGridViewCellStyle();
            DataGridViewCellStyle style6 = new DataGridViewCellStyle();
            DataGridViewCellStyle style7 = new DataGridViewCellStyle();
            DataGridViewCellStyle style8 = new DataGridViewCellStyle();
            DataGridViewCellStyle style9 = new DataGridViewCellStyle();
            DataGridViewCellStyle style10 = new DataGridViewCellStyle();
            DataGridViewCellStyle style11 = new DataGridViewCellStyle();
            DataGridViewCellStyle style12 = new DataGridViewCellStyle();
            DataGridViewCellStyle style13 = new DataGridViewCellStyle();
            DataGridViewCellStyle style14 = new DataGridViewCellStyle();
            DataGridViewCellStyle style15 = new DataGridViewCellStyle();
            DataGridViewCellStyle style16 = new DataGridViewCellStyle();
            DataGridViewCellStyle style17 = new DataGridViewCellStyle();
            DataGridViewCellStyle style18 = new DataGridViewCellStyle();
            DataGridViewCellStyle style19 = new DataGridViewCellStyle();
            DataGridViewCellStyle style20 = new DataGridViewCellStyle();
            DataGridViewCellStyle style21 = new DataGridViewCellStyle();
            this.label1 = new Label();
            this.labTankerNo = new Label();
            this.label3 = new Label();
            this.textTruck2 = new TextBox();
            this.labelDriverName = new Label();
            this.labelTankerMax = new Label();
            this.labelTransporterName = new Label();
            this.label4 = new Label();
            this.label2 = new Label();
            this.textDN = new TextBox();
            this.textUnloading = new TextBox();
            this.label5 = new Label();
            this.textRemarkTicket = new TextBox();
            this.label6 = new Label();
            this.textRemarkReport = new TextBox();
            this.label7 = new Label();
            this.groupOtherParty = new GroupBox();
            this.dateDelivery2 = new DateTimePicker();
            this.TimeDelivery2 = new MaskedTextBox();
            this.label61 = new Label();
            this.textNetEstate = new TextBox();
            this.label10 = new Label();
            this.checkNOPW = new CheckBox();
            this.textWBNo = new TextBox();
            this.labelWBNo = new Label();
            this.textTareEstate = new TextBox();
            this.textGrossEstate = new TextBox();
            this.label9 = new Label();
            this.label8 = new Label();
            this.label25 = new Label();
            this.dateDelivery = new DateTimePicker();
            this.TimeDelivery = new MaskedTextBox();
            this.groupFactoryWeight = new GroupBox();
            this.label57 = new Label();
            this.txtMS = new TextBox();
            this.labelMS = new Label();
            this.panel4X = new Panel();
            this.label16 = new Label();
            this.textTime4th = new TextBox();
            this.label15 = new Label();
            this.textTime3rd = new TextBox();
            this.textNET2 = new TextBox();
            this.label14 = new Label();
            this.text4th = new TextBox();
            this.textDate3rd = new TextBox();
            this.textDate4th = new TextBox();
            this.text3rd = new TextBox();
            this.textDate1st = new TextBox();
            this.textTime2nd = new TextBox();
            this.textNET1 = new TextBox();
            this.textTime1st = new TextBox();
            this.textDate2nd = new TextBox();
            this.text2nd = new TextBox();
            this.text1st = new TextBox();
            this.label11 = new Label();
            this.label12 = new Label();
            this.label13 = new Label();
            this.TimeRegister = new MaskedTextBox();
            this.dateRegister = new DateTimePicker();
            this.label26 = new Label();
            this.textDeducTotal = new TextBox();
            this.label17 = new Label();
            this.textNet = new TextBox();
            this.label18 = new Label();
            this.textSEAL = new TextBox();
            this.label19 = new Label();
            this.tabControl1 = new TabControl();
            this.tabPageDO = new TabPage();
            this.dgvDO = new DataGridView();
            this.panel1 = new Panel();
            this.panel_return = new Panel();
            this.btn_check = new Button();
            this.text_ref_return = new TextBox();
            this.chk_return = new CheckBox();
            this.checkNonContract = new CheckBox();
            this.buttonMergeDO = new Button();
            this.buttonDeleteDO = new Button();
            this.buttonEditDO = new Button();
            this.buttonAddDO = new Button();
            this.tabPageInfo = new TabPage();
            this.buttonStorage = new Button();
            this.textStorage = new TextBox();
            this.labelStorageName = new Label();
            this.labelStorage = new Label();
            this.buttonEstate = new Button();
            this.textEstate = new TextBox();
            this.labelEstateName = new Label();
            this.panel4 = new Panel();
            this.textISCC2 = new TextBox();
            this.groupBox3 = new GroupBox();
            this.label39 = new Label();
            this.textGHG = new TextBox();
            this.radioGHG2 = new RadioButton();
            this.radioGHG1 = new RadioButton();
            this.textISCC = new TextBox();
            this.label38 = new Label();
            this.checkISCC = new CheckBox();
            this.label40 = new Label();
            this.tabPageDeduc = new TabPage();
            this.radioButtonEntryAVG = new RadioButton();
            this.radioButtonEntryTotalBunch = new RadioButton();
            this.buttonEntryDeduc = new Button();
            this.panelDeducTBS = new Panel();
            this.textGrade = new TextBox();
            this.labelGrade = new Label();
            this.label41 = new Label();
            this.label23 = new Label();
            this.label32 = new Label();
            this.textBoxKG = new TextBox();
            this.textFruitsType = new TextBox();
            this.labelFruitsTypeName = new Label();
            this.textRendCPO = new TextBox();
            this.label49 = new Label();
            this.textReason = new TextBox();
            this.label47 = new Label();
            this.labelReject = new Label();
            this.textTBSReject = new TextBox();
            this.groupBoxTotalBunchFFB = new GroupBox();
            this.textBunchTotal = new TextBox();
            this.textBunchDeduc = new TextBox();
            this.label29 = new Label();
            this.label30 = new Label();
            this.textAvg = new TextBox();
            this.label31 = new Label();
            this.buttonDeleteDeduc = new Button();
            this.buttonEditDeduc = new Button();
            this.dgvDeduc = new DataGridView();
            this.buttonAddDeduc = new Button();
            this.shapeContainer2 = new ShapeContainer();
            this.rectangleShape1 = new RectangleShape();
            this.tabPageDivision = new TabPage();
            this.dgvDivBlock = new DataGridView();
            this.panel3 = new Panel();
            this.button15 = new Button();
            this.button16 = new Button();
            this.button17 = new Button();
            this.tabPageQC = new TabPage();
            this.label20 = new Label();
            this.textQualityInfo = new RichTextBox();
            this.dgvQC_All = new DataGridView();
            this.textTankQC = new TextBox();
            this.label44 = new Label();
            this.label43 = new Label();
            this.combodgvDO = new ComboBox();
            this.textQControl = new TextBox();
            this.label42 = new Label();
            this.dgvQC = new DataGridView();
            this.tabPageCont = new TabPage();
            this.dgvCont = new DataGridView();
            this.panel5 = new Panel();
            this.buttonContDelete = new Button();
            this.buttonContEdit = new Button();
            this.buttonContAdd = new Button();
            this.tabPagePorla = new TabPage();
            this.label22 = new Label();
            this.buttonDeletePorla = new Button();
            this.buttonEditPorla = new Button();
            this.dgvDeducPorla = new DataGridView();
            this.buttonAddPorla = new Button();
            this.shapeContainer3 = new ShapeContainer();
            this.rectangleShape2 = new RectangleShape();
            this.tabPageCopra = new TabPage();
            this.buttonEntryCopra = new Button();
            this.label24 = new Label();
            this.textTotalCopra = new TextBox();
            this.label27 = new Label();
            this.tabPageDL = new TabPage();
            this.button19 = new Button();
            this.button20 = new Button();
            this.button18 = new Button();
            this.dgvListDO = new DataGridView();
            this.textNettoBatchLeft = new TextBox();
            this.label51 = new Label();
            this.label53 = new Label();
            this.textGunnyBatchLeft = new TextBox();
            this.label52 = new Label();
            this.buttonAdopt = new Button();
            this.textDL = new TextBox();
            this.label56 = new Label();
            this.textSTO = new TextBox();
            this.groupBox2 = new GroupBox();
            this.label60 = new Label();
            this.textBox3 = new TextBox();
            this.label58 = new Label();
            this.groupBox1 = new GroupBox();
            this.textNettoBatch = new TextBox();
            this.label36 = new Label();
            this.label48 = new Label();
            this.textGunnyBatch = new TextBox();
            this.label50 = new Label();
            this.textBox1 = new TextBox();
            this.label55 = new Label();
            this.label28 = new Label();
            this.dgvBatch = new DataGridView();
            this.textReport_Date = new TextBox();
            this.label37 = new Label();
            this.textRefNo = new TextBox();
            this.textRef_Date = new TextBox();
            this.label35 = new Label();
            this.comboTransType = new ComboBox();
            this.buttonSave = new Button();
            this.buttonSavePrint = new Button();
            this.buttonCancel = new Button();
            this.buttonReset = new Button();
            this.buttonReadIndicator = new Button();
            this.buttonTruck = new Button();
            this.textTruck = new TextBox();
            this.textDriverID = new TextBox();
            this.buttonDriver = new Button();
            this.buttonTranspt = new Button();
            this.textTransporter = new TextBox();
            this.buttonTanker = new Button();
            this.textTanker = new TextBox();
            this.labelComm = new Label();
            this.labelCommName = new Label();
            this.textCommodity = new TextBox();
            this.buttonComm = new Button();
            this.label33 = new Label();
            this.textCommType = new TextBox();
            this.textVariance = new TextBox();
            this.label45 = new Label();
            this.textTrailerNo = new TextBox();
            this.label46 = new Label();
            this.shapeContainer1 = new ShapeContainer();
            this.kotakOS = new RectangleShape();
            this.lblOSDO = new Label();
            this.textDriverName = new TextBox();
            this.labelRelation = new Label();
            this.textCust = new TextBox();
            this.buttonCust = new Button();
            this.labelCustName = new Label();
            this.checkEstate = new CheckBox();
            this.panelMainInfo = new Panel();
            this.buttonScanCard = new Button();
            this.buttonTarraHistory = new Button();
            this.label21 = new Label();
            this.process1 = new Process();
            this.txtAddInfo = new TextBox();
            this.label54 = new Label();
            this.shapeContainer4 = new ShapeContainer();
            this.toolTip1 = new ToolTip(this.components);
            this.label59 = new Label();
            this.textPL3 = new TextBox();
            this.groupOtherParty.SuspendLayout();
            this.groupFactoryWeight.SuspendLayout();
            this.panel4X.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPageDO.SuspendLayout();
            ((ISupportInitialize) this.dgvDO).BeginInit();
            this.panel1.SuspendLayout();
            this.panel_return.SuspendLayout();
            this.tabPageInfo.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPageDeduc.SuspendLayout();
            this.panelDeducTBS.SuspendLayout();
            this.groupBoxTotalBunchFFB.SuspendLayout();
            ((ISupportInitialize) this.dgvDeduc).BeginInit();
            this.tabPageDivision.SuspendLayout();
            ((ISupportInitialize) this.dgvDivBlock).BeginInit();
            this.panel3.SuspendLayout();
            this.tabPageQC.SuspendLayout();
            ((ISupportInitialize) this.dgvQC_All).BeginInit();
            ((ISupportInitialize) this.dgvQC).BeginInit();
            this.tabPageCont.SuspendLayout();
            ((ISupportInitialize) this.dgvCont).BeginInit();
            this.panel5.SuspendLayout();
            this.tabPagePorla.SuspendLayout();
            ((ISupportInitialize) this.dgvDeducPorla).BeginInit();
            this.tabPageCopra.SuspendLayout();
            this.tabPageDL.SuspendLayout();
            ((ISupportInitialize) this.dgvListDO).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((ISupportInitialize) this.dgvBatch).BeginInit();
            this.panelMainInfo.SuspendLayout();
            base.SuspendLayout();
            this.label1.ImageAlign = ContentAlignment.MiddleRight;
            this.label1.Location = new Point(5, 6);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x55, 15);
            this.label1.TabIndex = 0x10;
            this.label1.Text = "Truck No.";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.labTankerNo.AutoSize = true;
            this.labTankerNo.Location = new Point(0x194, 0x20);
            this.labTankerNo.Name = "labTankerNo";
            this.labTankerNo.Size = new Size(0x3d, 13);
            this.labTankerNo.TabIndex = 0x1a;
            this.labTankerNo.Text = "Tanker No.";
            this.label3.Location = new Point(5, 0x1f);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x55, 15);
            this.label3.TabIndex = 0x11;
            this.label3.Text = "Driver ID";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.textTruck2.CharacterCasing = CharacterCasing.Upper;
            this.textTruck2.Location = new Point(0x101, 3);
            this.textTruck2.Name = "textTruck2";
            this.textTruck2.ReadOnly = true;
            this.textTruck2.Size = new Size(0x90, 20);
            this.textTruck2.TabIndex = 6;
            this.textTruck2.Leave += new EventHandler(this.textTruck2_Leave);
            this.labelDriverName.AutoSize = true;
            this.labelDriverName.Location = new Point(0x11a, 0x21);
            this.labelDriverName.Name = "labelDriverName";
            this.labelDriverName.Size = new Size(0x3f, 13);
            this.labelDriverName.TabIndex = 0x18;
            this.labelDriverName.Text = "DriverName";
            this.labelTankerMax.Location = new Point(0x197, 0x38);
            this.labelTankerMax.Name = "labelTankerMax";
            this.labelTankerMax.Size = new Size(150, 30);
            this.labelTankerMax.TabIndex = 0x1b;
            this.labelTankerMax.Text = "Maximum Tanker = ###,###";
            this.labelTransporterName.AutoSize = true;
            this.labelTransporterName.Location = new Point(0xfd, 110);
            this.labelTransporterName.Name = "labelTransporterName";
            this.labelTransporterName.Size = new Size(0x5c, 13);
            this.labelTransporterName.TabIndex = 0x1d;
            this.labelTransporterName.Text = "Transporter Name";
            this.label4.Location = new Point(5, 0x6d);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x55, 15);
            this.label4.TabIndex = 0x15;
            this.label4.Text = "Transporter";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x1c, 0xa9);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x47, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Delivery Note";
            this.textDN.CharacterCasing = CharacterCasing.Upper;
            this.textDN.Location = new Point(0x63, 0xa5);
            this.textDN.MaxLength = 30;
            this.textDN.Name = "textDN";
            this.textDN.Size = new Size(0x92, 20);
            this.textDN.TabIndex = 1;
            this.textDN.Leave += new EventHandler(this.textDN_Leave);
            this.textUnloading.CharacterCasing = CharacterCasing.Upper;
            this.textUnloading.Location = new Point(0x151, 0xa5);
            this.textUnloading.MaxLength = 20;
            this.textUnloading.Name = "textUnloading";
            this.textUnloading.Size = new Size(0x41, 20);
            this.textUnloading.TabIndex = 2;
            this.textUnloading.Visible = false;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0xf9, 0xa8);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x52, 13);
            this.label5.TabIndex = 0x27;
            this.label5.Text = "Unloading Point";
            this.label5.Visible = false;
            this.textRemarkTicket.Location = new Point(0x63, 0xbb);
            this.textRemarkTicket.MaxLength = 100;
            this.textRemarkTicket.Name = "textRemarkTicket";
            this.textRemarkTicket.Size = new Size(0x1a2, 20);
            this.textRemarkTicket.TabIndex = 3;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(10, 190);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x58, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Remark for ticket";
            this.textRemarkReport.Location = new Point(0x63, 0xd1);
            this.textRemarkReport.MaxLength = 100;
            this.textRemarkReport.Name = "textRemarkReport";
            this.textRemarkReport.Size = new Size(0x1a2, 20);
            this.textRemarkReport.TabIndex = 4;
            this.label7.AutoSize = true;
            this.label7.Location = new Point(3, 0xd5);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x5e, 13);
            this.label7.TabIndex = 0x10;
            this.label7.Text = "Remark for Report";
            this.groupOtherParty.Controls.Add(this.dateDelivery2);
            this.groupOtherParty.Controls.Add(this.TimeDelivery2);
            this.groupOtherParty.Controls.Add(this.label61);
            this.groupOtherParty.Controls.Add(this.textNetEstate);
            this.groupOtherParty.Controls.Add(this.label10);
            this.groupOtherParty.Controls.Add(this.checkNOPW);
            this.groupOtherParty.Controls.Add(this.textWBNo);
            this.groupOtherParty.Controls.Add(this.labelWBNo);
            this.groupOtherParty.Controls.Add(this.textTareEstate);
            this.groupOtherParty.Controls.Add(this.textGrossEstate);
            this.groupOtherParty.Controls.Add(this.label9);
            this.groupOtherParty.Controls.Add(this.label8);
            this.groupOtherParty.Controls.Add(this.label25);
            this.groupOtherParty.Controls.Add(this.dateDelivery);
            this.groupOtherParty.Controls.Add(this.TimeDelivery);
            this.groupOtherParty.Location = new Point(14, 0x115);
            this.groupOtherParty.Name = "groupOtherParty";
            this.groupOtherParty.Size = new Size(0x102, 130);
            this.groupOtherParty.TabIndex = 6;
            this.groupOtherParty.TabStop = false;
            this.groupOtherParty.Text = "[ Other Party ]";
            this.dateDelivery2.Format = DateTimePickerFormat.Short;
            this.dateDelivery2.Location = new Point(0x81, 0x2f);
            this.dateDelivery2.Name = "dateDelivery2";
            this.dateDelivery2.Size = new Size(80, 20);
            this.dateDelivery2.TabIndex = 0x66;
            this.TimeDelivery2.Location = new Point(0xd3, 0x2f);
            this.TimeDelivery2.Mask = "00:00";
            this.TimeDelivery2.Name = "TimeDelivery2";
            this.TimeDelivery2.Size = new Size(0x25, 20);
            this.TimeDelivery2.TabIndex = 0x67;
            this.TimeDelivery2.ValidatingType = typeof(DateTime);
            this.label61.AutoSize = true;
            this.label61.Location = new Point(0x69, 50);
            this.label61.Name = "label61";
            this.label61.Size = new Size(0x10, 13);
            this.label61.TabIndex = 0x65;
            this.label61.Text = "In";
            this.textNetEstate.Location = new Point(0x27, 70);
            this.textNetEstate.MaxLength = 15;
            this.textNetEstate.Name = "textNetEstate";
            this.textNetEstate.ReadOnly = true;
            this.textNetEstate.Size = new Size(60, 20);
            this.textNetEstate.TabIndex = 10;
            this.textNetEstate.Text = "0";
            this.textNetEstate.TextAlign = HorizontalAlignment.Right;
            this.label10.AutoSize = true;
            this.label10.Location = new Point(14, 0x49);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x18, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Net";
            this.checkNOPW.AutoSize = true;
            this.checkNOPW.Location = new Point(0x6a, 0x19);
            this.checkNOPW.Name = "checkNOPW";
            this.checkNOPW.Size = new Size(0x86, 0x11);
            this.checkNOPW.TabIndex = 100;
            this.checkNOPW.Text = "No other party WB Slip";
            this.checkNOPW.UseVisualStyleBackColor = true;
            this.checkNOPW.CheckedChanged += new EventHandler(this.CheckedChanged_checkNOPW);
            this.textWBNo.CharacterCasing = CharacterCasing.Upper;
            this.textWBNo.Location = new Point(0x41, 0x62);
            this.textWBNo.MaxLength = 30;
            this.textWBNo.Name = "textWBNo";
            this.textWBNo.Size = new Size(0x95, 20);
            this.textWBNo.TabIndex = 4;
            this.labelWBNo.AutoSize = true;
            this.labelWBNo.Location = new Point(10, 0x65);
            this.labelWBNo.Name = "labelWBNo";
            this.labelWBNo.Size = new Size(0x33, 13);
            this.labelWBNo.TabIndex = 8;
            this.labelWBNo.Text = "WB (Ref)";
            this.textTareEstate.Location = new Point(40, 0x2f);
            this.textTareEstate.MaxLength = 15;
            this.textTareEstate.Name = "textTareEstate";
            this.textTareEstate.Size = new Size(0x3b, 20);
            this.textTareEstate.TabIndex = 1;
            this.textTareEstate.Text = "0";
            this.textTareEstate.TextAlign = HorizontalAlignment.Right;
            this.textTareEstate.Enter += new EventHandler(this.textTareEstate_Enter);
            this.textTareEstate.Leave += new EventHandler(this.textTareEstate_Leave);
            this.textGrossEstate.Location = new Point(40, 0x18);
            this.textGrossEstate.MaxLength = 15;
            this.textGrossEstate.Name = "textGrossEstate";
            this.textGrossEstate.Size = new Size(0x3b, 20);
            this.textGrossEstate.TabIndex = 0;
            this.textGrossEstate.Text = "0";
            this.textGrossEstate.TextAlign = HorizontalAlignment.Right;
            this.textGrossEstate.Enter += new EventHandler(this.textGrossEstate_Enter);
            this.textGrossEstate.Leave += new EventHandler(this.textGrossEstate_Leave);
            this.label9.AutoSize = true;
            this.label9.Location = new Point(9, 0x31);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x1d, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "Tare";
            this.label8.AutoSize = true;
            this.label8.Location = new Point(4, 0x1b);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x22, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Gross";
            this.label25.AutoSize = true;
            this.label25.Location = new Point(0x69, 0x49);
            this.label25.Name = "label25";
            this.label25.Size = new Size(0x18, 13);
            this.label25.TabIndex = 7;
            this.label25.Text = "Out";
            this.dateDelivery.Format = DateTimePickerFormat.Short;
            this.dateDelivery.Location = new Point(0x81, 70);
            this.dateDelivery.Name = "dateDelivery";
            this.dateDelivery.Size = new Size(80, 20);
            this.dateDelivery.TabIndex = 2;
            this.TimeDelivery.Location = new Point(0xd3, 70);
            this.TimeDelivery.Mask = "00:00";
            this.TimeDelivery.Name = "TimeDelivery";
            this.TimeDelivery.Size = new Size(0x25, 20);
            this.TimeDelivery.TabIndex = 3;
            this.TimeDelivery.ValidatingType = typeof(DateTime);
            this.groupFactoryWeight.Controls.Add(this.label57);
            this.groupFactoryWeight.Controls.Add(this.txtMS);
            this.groupFactoryWeight.Controls.Add(this.labelMS);
            this.groupFactoryWeight.Controls.Add(this.panel4X);
            this.groupFactoryWeight.Controls.Add(this.textDate1st);
            this.groupFactoryWeight.Controls.Add(this.textTime2nd);
            this.groupFactoryWeight.Controls.Add(this.textNET1);
            this.groupFactoryWeight.Controls.Add(this.textTime1st);
            this.groupFactoryWeight.Controls.Add(this.textDate2nd);
            this.groupFactoryWeight.Controls.Add(this.text2nd);
            this.groupFactoryWeight.Controls.Add(this.text1st);
            this.groupFactoryWeight.Controls.Add(this.label11);
            this.groupFactoryWeight.Controls.Add(this.label12);
            this.groupFactoryWeight.Controls.Add(this.label13);
            this.groupFactoryWeight.Controls.Add(this.TimeRegister);
            this.groupFactoryWeight.Controls.Add(this.dateRegister);
            this.groupFactoryWeight.Controls.Add(this.label26);
            this.groupFactoryWeight.Location = new Point(0x116, 0x115);
            this.groupFactoryWeight.Name = "groupFactoryWeight";
            this.groupFactoryWeight.Size = new Size(0x1d8, 130);
            this.groupFactoryWeight.TabIndex = 7;
            this.groupFactoryWeight.TabStop = false;
            this.groupFactoryWeight.Text = "[ Factory Weight ]";
            this.groupFactoryWeight.Enter += new EventHandler(this.groupFactoryWeight_Enter);
            this.label57.AutoSize = true;
            this.label57.Cursor = Cursors.Arrow;
            this.label57.Location = new Point(0x1a6, 0x69);
            this.label57.Name = "label57";
            this.label57.Size = new Size(0x16, 13);
            this.label57.TabIndex = 0x68;
            this.label57.Text = "KG";
            this.txtMS.Location = new Point(0x16e, 0x66);
            this.txtMS.MaxLength = 6;
            this.txtMS.Name = "txtMS";
            this.txtMS.Size = new Size(0x37, 20);
            this.txtMS.TabIndex = 0x67;
            this.txtMS.Text = "0";
            this.txtMS.TextAlign = HorizontalAlignment.Right;
            this.txtMS.TextChanged += new EventHandler(this.txtMS_TextChanged);
            this.txtMS.Leave += new EventHandler(this.txtMS_Leave);
            this.labelMS.AutoSize = true;
            this.labelMS.Cursor = Cursors.Arrow;
            this.labelMS.Location = new Point(0x10f, 0x6a);
            this.labelMS.Name = "labelMS";
            this.labelMS.Size = new Size(0x59, 13);
            this.labelMS.TabIndex = 0x66;
            this.labelMS.Text = "Material Stuffing :";
            this.panel4X.Controls.Add(this.label16);
            this.panel4X.Controls.Add(this.textTime4th);
            this.panel4X.Controls.Add(this.label15);
            this.panel4X.Controls.Add(this.textTime3rd);
            this.panel4X.Controls.Add(this.textNET2);
            this.panel4X.Controls.Add(this.label14);
            this.panel4X.Controls.Add(this.text4th);
            this.panel4X.Controls.Add(this.textDate3rd);
            this.panel4X.Controls.Add(this.textDate4th);
            this.panel4X.Controls.Add(this.text3rd);
            this.panel4X.Location = new Point(230, 0x10);
            this.panel4X.Name = "panel4X";
            this.panel4X.Size = new Size(0xe9, 0x4d);
            this.panel4X.TabIndex = 13;
            this.label16.AutoSize = true;
            this.label16.Location = new Point(3, 12);
            this.label16.Name = "label16";
            this.label16.Size = new Size(0x16, 13);
            this.label16.TabIndex = 6;
            this.label16.Text = "3rd";
            this.textTime4th.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textTime4th.Location = new Point(0xac, 30);
            this.textTime4th.MaxLength = 8;
            this.textTime4th.Name = "textTime4th";
            this.textTime4th.ReadOnly = true;
            this.textTime4th.Size = new Size(0x34, 20);
            this.textTime4th.TabIndex = 5;
            this.label15.AutoSize = true;
            this.label15.Location = new Point(3, 0x23);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x16, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "4th";
            this.textTime3rd.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textTime3rd.Location = new Point(0xac, 9);
            this.textTime3rd.MaxLength = 8;
            this.textTime3rd.Name = "textTime3rd";
            this.textTime3rd.ReadOnly = true;
            this.textTime3rd.Size = new Size(0x34, 20);
            this.textTime3rd.TabIndex = 4;
            this.textTime3rd.Leave += new EventHandler(this.textTime3rd_Leave);
            this.textNET2.BackColor = Color.Silver;
            this.textNET2.Location = new Point(0x1f, 0x36);
            this.textNET2.MaxLength = 15;
            this.textNET2.Name = "textNET2";
            this.textNET2.ReadOnly = true;
            this.textNET2.Size = new Size(0x3d, 20);
            this.textNET2.TabIndex = 9;
            this.textNET2.Text = "0";
            this.textNET2.TextAlign = HorizontalAlignment.Right;
            this.textNET2.TextChanged += new EventHandler(this.textNET2_TextChanged);
            this.label14.AutoSize = true;
            this.label14.Location = new Point(3, 0x39);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x18, 13);
            this.label14.TabIndex = 8;
            this.label14.Text = "Net";
            this.text4th.Location = new Point(0x1f, 0x20);
            this.text4th.MaxLength = 15;
            this.text4th.Name = "text4th";
            this.text4th.Size = new Size(0x3d, 20);
            this.text4th.TabIndex = 1;
            this.text4th.Text = "0";
            this.text4th.TextAlign = HorizontalAlignment.Right;
            this.text4th.Leave += new EventHandler(this.text4th_Leave);
            this.textDate3rd.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textDate3rd.Location = new Point(0x62, 9);
            this.textDate3rd.MaxLength = 10;
            this.textDate3rd.Name = "textDate3rd";
            this.textDate3rd.ReadOnly = true;
            this.textDate3rd.Size = new Size(0x44, 20);
            this.textDate3rd.TabIndex = 2;
            this.textDate3rd.Leave += new EventHandler(this.textDate3rd_Leave);
            this.textDate4th.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textDate4th.Location = new Point(0x62, 30);
            this.textDate4th.MaxLength = 10;
            this.textDate4th.Name = "textDate4th";
            this.textDate4th.ReadOnly = true;
            this.textDate4th.Size = new Size(0x44, 20);
            this.textDate4th.TabIndex = 3;
            this.textDate4th.Leave += new EventHandler(this.textDate4th_Leave);
            this.text3rd.Location = new Point(0x1f, 9);
            this.text3rd.MaxLength = 15;
            this.text3rd.Name = "text3rd";
            this.text3rd.Size = new Size(0x3d, 20);
            this.text3rd.TabIndex = 0;
            this.text3rd.Text = "0";
            this.text3rd.TextAlign = HorizontalAlignment.Right;
            this.text3rd.Leave += new EventHandler(this.text3rd_Leave);
            this.textDate1st.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textDate1st.Location = new Point(0x69, 0x18);
            this.textDate1st.MaxLength = 10;
            this.textDate1st.Name = "textDate1st";
            this.textDate1st.ReadOnly = true;
            this.textDate1st.Size = new Size(0x44, 20);
            this.textDate1st.TabIndex = 2;
            this.textDate1st.Text = "08/08/2013";
            this.textDate1st.Leave += new EventHandler(this.textDate1st_Leave);
            this.textTime2nd.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textTime2nd.Location = new Point(0xaf, 0x2e);
            this.textTime2nd.MaxLength = 8;
            this.textTime2nd.Name = "textTime2nd";
            this.textTime2nd.ReadOnly = true;
            this.textTime2nd.Size = new Size(0x34, 20);
            this.textTime2nd.TabIndex = 5;
            this.textTime2nd.Leave += new EventHandler(this.textTime2nd_Leave);
            this.textNET1.BackColor = Color.Silver;
            this.textNET1.Location = new Point(0x29, 0x45);
            this.textNET1.MaxLength = 15;
            this.textNET1.Name = "textNET1";
            this.textNET1.ReadOnly = true;
            this.textNET1.Size = new Size(0x3a, 20);
            this.textNET1.TabIndex = 12;
            this.textNET1.Text = "0";
            this.textNET1.TextAlign = HorizontalAlignment.Right;
            this.textTime1st.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textTime1st.Location = new Point(0xaf, 0x18);
            this.textTime1st.MaxLength = 8;
            this.textTime1st.Name = "textTime1st";
            this.textTime1st.ReadOnly = true;
            this.textTime1st.Size = new Size(0x34, 20);
            this.textTime1st.TabIndex = 4;
            this.textTime1st.Text = "24:59:59";
            this.textTime1st.Leave += new EventHandler(this.textTime1st_Leave);
            this.textDate2nd.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textDate2nd.Location = new Point(0x69, 0x2e);
            this.textDate2nd.MaxLength = 10;
            this.textDate2nd.Name = "textDate2nd";
            this.textDate2nd.ReadOnly = true;
            this.textDate2nd.Size = new Size(0x44, 20);
            this.textDate2nd.TabIndex = 3;
            this.textDate2nd.Leave += new EventHandler(this.textDate2nd_Leave);
            this.text2nd.Location = new Point(0x29, 0x2f);
            this.text2nd.MaxLength = 15;
            this.text2nd.Name = "text2nd";
            this.text2nd.Size = new Size(0x3a, 20);
            this.text2nd.TabIndex = 1;
            this.text2nd.Text = "0";
            this.text2nd.TextAlign = HorizontalAlignment.Right;
            this.text2nd.TextChanged += new EventHandler(this.text2nd_TextChanged);
            this.text2nd.Leave += new EventHandler(this.text2nd_Leave);
            this.text1st.Location = new Point(0x29, 0x18);
            this.text1st.MaxLength = 15;
            this.text1st.Name = "text1st";
            this.text1st.Size = new Size(0x3a, 20);
            this.text1st.TabIndex = 0;
            this.text1st.Text = "0";
            this.text1st.TextAlign = HorizontalAlignment.Right;
            this.text1st.TextChanged += new EventHandler(this.text1st_TextChanged);
            this.text1st.Leave += new EventHandler(this.text1st_Leave);
            this.label11.AutoSize = true;
            this.label11.Location = new Point(14, 0x48);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x18, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Net";
            this.label12.AutoSize = true;
            this.label12.Location = new Point(14, 50);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x19, 13);
            this.label12.TabIndex = 9;
            this.label12.Text = "2nd";
            this.label13.AutoSize = true;
            this.label13.Location = new Point(14, 0x1b);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x15, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = "1st";
            this.TimeRegister.Location = new Point(0xc5, 0x68);
            this.TimeRegister.Mask = "00:00";
            this.TimeRegister.Name = "TimeRegister";
            this.TimeRegister.Size = new Size(0x29, 20);
            this.TimeRegister.TabIndex = 7;
            this.TimeRegister.ValidatingType = typeof(DateTime);
            this.dateRegister.Format = DateTimePickerFormat.Short;
            this.dateRegister.Location = new Point(0x59, 0x68);
            this.dateRegister.Name = "dateRegister";
            this.dateRegister.Size = new Size(0x66, 20);
            this.dateRegister.TabIndex = 6;
            this.label26.AutoSize = true;
            this.label26.Cursor = Cursors.Arrow;
            this.label26.Location = new Point(15, 0x6b);
            this.label26.Name = "label26";
            this.label26.Size = new Size(0x48, 13);
            this.label26.TabIndex = 11;
            this.label26.Text = "Register Date";
            this.textDeducTotal.Location = new Point(810, 0x12d);
            this.textDeducTotal.MaxLength = 15;
            this.textDeducTotal.Name = "textDeducTotal";
            this.textDeducTotal.ReadOnly = true;
            this.textDeducTotal.Size = new Size(0x54, 20);
            this.textDeducTotal.TabIndex = 11;
            this.textDeducTotal.Text = "0";
            this.textDeducTotal.TextAlign = HorizontalAlignment.Right;
            this.label17.AutoSize = true;
            this.label17.Location = new Point(0x2f2, 0x130);
            this.label17.Name = "label17";
            this.label17.Size = new Size(0x38, 13);
            this.label17.TabIndex = 0x17;
            this.label17.Text = "Deduction";
            this.textNet.BackColor = Color.Silver;
            this.textNet.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textNet.Location = new Point(810, 0x147);
            this.textNet.MaxLength = 15;
            this.textNet.Name = "textNet";
            this.textNet.ReadOnly = true;
            this.textNet.Size = new Size(0x54, 0x1d);
            this.textNet.TabIndex = 12;
            this.textNet.Text = "0";
            this.textNet.TextAlign = HorizontalAlignment.Right;
            this.textNet.TextChanged += new EventHandler(this.textNet_TextChanged);
            this.label18.AutoSize = true;
            this.label18.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label18.Location = new Point(0x2fb, 330);
            this.label18.Name = "label18";
            this.label18.Size = new Size(0x31, 0x18);
            this.label18.TabIndex = 0x18;
            this.label18.Text = "NET";
            this.textSEAL.Location = new Point(0x63, 0xe7);
            this.textSEAL.MaxLength = 100;
            this.textSEAL.Name = "textSEAL";
            this.textSEAL.Size = new Size(0x1a2, 20);
            this.textSEAL.TabIndex = 5;
            this.label19.AutoSize = true;
            this.label19.Location = new Point(0x3b, 0xea);
            this.label19.Name = "label19";
            this.label19.Size = new Size(0x22, 13);
            this.label19.TabIndex = 0x11;
            this.label19.Text = "SEAL";
            this.tabControl1.Controls.Add(this.tabPageDO);
            this.tabControl1.Controls.Add(this.tabPageInfo);
            this.tabControl1.Controls.Add(this.tabPageDeduc);
            this.tabControl1.Controls.Add(this.tabPageDivision);
            this.tabControl1.Controls.Add(this.tabPageQC);
            this.tabControl1.Controls.Add(this.tabPageCont);
            this.tabControl1.Controls.Add(this.tabPagePorla);
            this.tabControl1.Controls.Add(this.tabPageCopra);
            this.tabControl1.Controls.Add(this.tabPageDL);
            this.tabControl1.Dock = DockStyle.Bottom;
            this.tabControl1.Location = new Point(0, 0x19b);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new Size(0x38d, 0xed);
            this.tabControl1.TabIndex = 8;
            this.tabControl1.SelectedIndexChanged += new EventHandler(this.tab_changed);
            this.tabControl1.MouseClick += new MouseEventHandler(this.tabControl1_MouseClick);
            this.tabPageDO.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageDO.Controls.Add(this.dgvDO);
            this.tabPageDO.Controls.Add(this.panel1);
            this.tabPageDO.Location = new Point(4, 0x16);
            this.tabPageDO.Name = "tabPageDO";
            this.tabPageDO.Padding = new Padding(3);
            this.tabPageDO.Size = new Size(0x385, 0xd3);
            this.tabPageDO.TabIndex = 1;
            this.tabPageDO.Text = "Contract / DO ";
            this.tabPageDO.UseVisualStyleBackColor = true;
            this.dgvDO.AllowUserToAddRows = false;
            this.dgvDO.AllowUserToDeleteRows = false;
            this.dgvDO.AllowUserToResizeRows = false;
            this.dgvDO.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDO.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgvDO.ColumnHeadersDefaultCellStyle = style;
            this.dgvDO.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgvDO.DefaultCellStyle = style2;
            this.dgvDO.Dock = DockStyle.Fill;
            this.dgvDO.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvDO.Location = new Point(3, 3);
            this.dgvDO.MultiSelect = false;
            this.dgvDO.Name = "dgvDO";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgvDO.RowHeadersDefaultCellStyle = style3;
            this.dgvDO.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDO.Size = new Size(0x37d, 0x94);
            this.dgvDO.TabIndex = 1;
            this.dgvDO.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dgvDO_CellFormatting);
            this.dgvDO.SelectionChanged += new EventHandler(this.dgvDO_SelectionChanged);
            this.panel1.BackColor = SystemColors.Control;
            this.panel1.Controls.Add(this.panel_return);
            this.panel1.Controls.Add(this.chk_return);
            this.panel1.Controls.Add(this.checkNonContract);
            this.panel1.Controls.Add(this.buttonMergeDO);
            this.panel1.Controls.Add(this.buttonDeleteDO);
            this.panel1.Controls.Add(this.buttonEditDO);
            this.panel1.Controls.Add(this.buttonAddDO);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(3, 0x97);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x37d, 0x37);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new PaintEventHandler(this.panel1_Paint);
            this.panel_return.Controls.Add(this.btn_check);
            this.panel_return.Controls.Add(this.text_ref_return);
            this.panel_return.Location = new Point(0x1e2, 0x13);
            this.panel_return.Name = "panel_return";
            this.panel_return.Size = new Size(0x109, 0x20);
            this.panel_return.TabIndex = 6;
            this.panel_return.Visible = false;
            this.btn_check.Location = new Point(0xa4, 4);
            this.btn_check.Name = "btn_check";
            this.btn_check.Size = new Size(0x35, 0x17);
            this.btn_check.TabIndex = 1;
            this.btn_check.Text = "Check";
            this.btn_check.UseVisualStyleBackColor = true;
            this.btn_check.Click += new EventHandler(this.btn_check_Click);
            this.text_ref_return.Location = new Point(3, 7);
            this.text_ref_return.Name = "text_ref_return";
            this.text_ref_return.Size = new Size(0x9e, 20);
            this.text_ref_return.TabIndex = 0;
            this.chk_return.AutoSize = true;
            this.chk_return.Location = new Point(0x1a2, 0x21);
            this.chk_return.Name = "chk_return";
            this.chk_return.Size = new Size(0x3a, 0x11);
            this.chk_return.TabIndex = 5;
            this.chk_return.Text = "Return";
            this.chk_return.UseVisualStyleBackColor = true;
            this.chk_return.CheckedChanged += new EventHandler(this.chk_return_CheckedChanged);
            this.checkNonContract.AutoSize = true;
            this.checkNonContract.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.checkNonContract.Location = new Point(9, 6);
            this.checkNonContract.Name = "checkNonContract";
            this.checkNonContract.Size = new Size(0x74, 20);
            this.checkNonContract.TabIndex = 4;
            this.checkNonContract.Text = "Non Contract";
            this.checkNonContract.UseVisualStyleBackColor = true;
            this.checkNonContract.CheckedChanged += new EventHandler(this.checkNonContract_CheckedChanged);
            this.buttonMergeDO.Location = new Point(0x123, 30);
            this.buttonMergeDO.Name = "buttonMergeDO";
            this.buttonMergeDO.Size = new Size(0x6c, 0x17);
            this.buttonMergeDO.TabIndex = 3;
            this.buttonMergeDO.Text = "Refresh";
            this.buttonMergeDO.UseVisualStyleBackColor = true;
            this.buttonMergeDO.Click += new EventHandler(this.buttonMerge_Click);
            this.buttonDeleteDO.Location = new Point(0xa4, 30);
            this.buttonDeleteDO.Name = "buttonDeleteDO";
            this.buttonDeleteDO.Size = new Size(0x4b, 0x17);
            this.buttonDeleteDO.TabIndex = 2;
            this.buttonDeleteDO.Text = "Delete";
            this.buttonDeleteDO.UseVisualStyleBackColor = true;
            this.buttonDeleteDO.Click += new EventHandler(this.button8_Click);
            this.buttonEditDO.Location = new Point(0x53, 0x1d);
            this.buttonEditDO.Name = "buttonEditDO";
            this.buttonEditDO.Size = new Size(0x4b, 0x17);
            this.buttonEditDO.TabIndex = 1;
            this.buttonEditDO.Text = "&Edit";
            this.buttonEditDO.UseVisualStyleBackColor = true;
            this.buttonEditDO.Click += new EventHandler(this.button7_Click);
            this.buttonAddDO.Location = new Point(2, 0x1d);
            this.buttonAddDO.Name = "buttonAddDO";
            this.buttonAddDO.Size = new Size(0x4b, 0x17);
            this.buttonAddDO.TabIndex = 0;
            this.buttonAddDO.Text = "&Add";
            this.buttonAddDO.UseVisualStyleBackColor = true;
            this.buttonAddDO.Click += new EventHandler(this.buttonAddDO_Click);
            this.tabPageInfo.BackColor = SystemColors.Control;
            this.tabPageInfo.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageInfo.Controls.Add(this.buttonStorage);
            this.tabPageInfo.Controls.Add(this.textStorage);
            this.tabPageInfo.Controls.Add(this.labelStorageName);
            this.tabPageInfo.Controls.Add(this.labelStorage);
            this.tabPageInfo.Controls.Add(this.buttonEstate);
            this.tabPageInfo.Controls.Add(this.textEstate);
            this.tabPageInfo.Controls.Add(this.labelEstateName);
            this.tabPageInfo.Controls.Add(this.panel4);
            this.tabPageInfo.Controls.Add(this.label40);
            this.tabPageInfo.Location = new Point(4, 0x16);
            this.tabPageInfo.Name = "tabPageInfo";
            this.tabPageInfo.Padding = new Padding(3);
            this.tabPageInfo.Size = new Size(0x385, 0xd3);
            this.tabPageInfo.TabIndex = 0;
            this.tabPageInfo.Text = "General Information";
            this.buttonStorage.Location = new Point(0xbb, 0x18);
            this.buttonStorage.Margin = new Padding(0);
            this.buttonStorage.Name = "buttonStorage";
            this.buttonStorage.Size = new Size(0x17, 0x17);
            this.buttonStorage.TabIndex = 10;
            this.buttonStorage.Text = "...";
            this.buttonStorage.UseVisualStyleBackColor = true;
            this.buttonStorage.Click += new EventHandler(this.buttonStorage_Click);
            this.textStorage.CharacterCasing = CharacterCasing.Upper;
            this.textStorage.Location = new Point(0x3d, 0x1b);
            this.textStorage.Name = "textStorage";
            this.textStorage.ReadOnly = true;
            this.textStorage.Size = new Size(0x7b, 20);
            this.textStorage.TabIndex = 9;
            this.labelStorageName.AutoSize = true;
            this.labelStorageName.Location = new Point(0xd4, 0x1d);
            this.labelStorageName.Name = "labelStorageName";
            this.labelStorageName.Size = new Size(0x48, 13);
            this.labelStorageName.TabIndex = 0x3e;
            this.labelStorageName.Text = "StorageName";
            this.labelStorage.AutoSize = true;
            this.labelStorage.Location = new Point(14, 0x1f);
            this.labelStorage.Name = "labelStorage";
            this.labelStorage.Size = new Size(0x2c, 13);
            this.labelStorage.TabIndex = 0x3d;
            this.labelStorage.Text = "Storage";
            this.buttonEstate.Location = new Point(0xbb, 0x33);
            this.buttonEstate.Margin = new Padding(0);
            this.buttonEstate.Name = "buttonEstate";
            this.buttonEstate.Size = new Size(0x17, 0x17);
            this.buttonEstate.TabIndex = 10;
            this.buttonEstate.Text = "...";
            this.buttonEstate.UseVisualStyleBackColor = true;
            this.buttonEstate.Visible = false;
            this.buttonEstate.Click += new EventHandler(this.button4_Click);
            this.textEstate.CharacterCasing = CharacterCasing.Upper;
            this.textEstate.Location = new Point(0x3d, 0x35);
            this.textEstate.Name = "textEstate";
            this.textEstate.ReadOnly = true;
            this.textEstate.Size = new Size(0x7b, 20);
            this.textEstate.TabIndex = 8;
            this.textEstate.Visible = false;
            this.labelEstateName.AutoSize = true;
            this.labelEstateName.Location = new Point(0xd4, 0x38);
            this.labelEstateName.Name = "labelEstateName";
            this.labelEstateName.Size = new Size(0x41, 13);
            this.labelEstateName.TabIndex = 0x36;
            this.labelEstateName.Text = "EstateName";
            this.labelEstateName.Visible = false;
            this.panel4.BorderStyle = BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.textISCC2);
            this.panel4.Controls.Add(this.groupBox3);
            this.panel4.Controls.Add(this.textISCC);
            this.panel4.Controls.Add(this.label38);
            this.panel4.Controls.Add(this.checkISCC);
            this.panel4.Location = new Point(0x1f3, 13);
            this.panel4.Name = "panel4";
            this.panel4.Size = new Size(0x171, 0x79);
            this.panel4.TabIndex = 12;
            this.textISCC2.BackColor = SystemColors.Window;
            this.textISCC2.Enabled = false;
            this.textISCC2.Location = new Point(0x10b, 0x2a);
            this.textISCC2.MaxLength = 50;
            this.textISCC2.Name = "textISCC2";
            this.textISCC2.Size = new Size(0x5f, 20);
            this.textISCC2.TabIndex = 4;
            this.textISCC2.TextAlign = HorizontalAlignment.Right;
            this.groupBox3.Controls.Add(this.label39);
            this.groupBox3.Controls.Add(this.textGHG);
            this.groupBox3.Controls.Add(this.radioGHG2);
            this.groupBox3.Controls.Add(this.radioGHG1);
            this.groupBox3.Location = new Point(3, 0x3a);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(0x167, 0x3a);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "[ GHG Emissions ]";
            this.label39.AutoSize = true;
            this.label39.Location = new Point(0x128, 0x1a);
            this.label39.Name = "label39";
            this.label39.Size = new Size(20, 13);
            this.label39.TabIndex = 0x38;
            this.label39.Text = "Kg";
            this.textGHG.Enabled = false;
            this.textGHG.Location = new Point(0xd7, 0x17);
            this.textGHG.MaxLength = 15;
            this.textGHG.Name = "textGHG";
            this.textGHG.Size = new Size(80, 20);
            this.textGHG.TabIndex = 2;
            this.textGHG.Text = "0.000";
            this.textGHG.TextAlign = HorizontalAlignment.Right;
            this.radioGHG2.AutoSize = true;
            this.radioGHG2.Checked = true;
            this.radioGHG2.Enabled = false;
            this.radioGHG2.Location = new Point(0xc3, 0x19);
            this.radioGHG2.Name = "radioGHG2";
            this.radioGHG2.Size = new Size(14, 13);
            this.radioGHG2.TabIndex = 1;
            this.radioGHG2.TabStop = true;
            this.radioGHG2.UseVisualStyleBackColor = true;
            this.radioGHG2.CheckedChanged += new EventHandler(this.radioGHG2_CheckedChanged);
            this.radioGHG1.AutoSize = true;
            this.radioGHG1.Enabled = false;
            this.radioGHG1.Location = new Point(6, 0x18);
            this.radioGHG1.Name = "radioGHG1";
            this.radioGHG1.Size = new Size(150, 0x11);
            this.radioGHG1.TabIndex = 0;
            this.radioGHG1.Text = "Use of Grandfather Clause";
            this.radioGHG1.UseVisualStyleBackColor = true;
            this.radioGHG1.CheckedChanged += new EventHandler(this.radioGHG1_CheckedChanged);
            this.textISCC.BackColor = SystemColors.Window;
            this.textISCC.Enabled = false;
            this.textISCC.Location = new Point(0x3a, 20);
            this.textISCC.MaxLength = 100;
            this.textISCC.Name = "textISCC";
            this.textISCC.ReadOnly = true;
            this.textISCC.Size = new Size(0x130, 20);
            this.textISCC.TabIndex = 1;
            this.textISCC.Text = "EU-ISCC-Cert-DE999-1234567890";
            this.textISCC.TextAlign = HorizontalAlignment.Right;
            this.label38.AutoSize = true;
            this.label38.Location = new Point(4, 0x17);
            this.label38.Name = "label38";
            this.label38.Size = new Size(0x33, 13);
            this.label38.TabIndex = 0;
            this.label38.Text = "ISCC No.";
            this.checkISCC.AutoSize = true;
            this.checkISCC.Location = new Point(7, 2);
            this.checkISCC.Name = "checkISCC";
            this.checkISCC.Size = new Size(0x62, 0x11);
            this.checkISCC.TabIndex = 11;
            this.checkISCC.Text = "Used ISCC No.";
            this.checkISCC.UseVisualStyleBackColor = true;
            this.checkISCC.CheckedChanged += new EventHandler(this.checkISCC_CheckedChanged);
            this.label40.AutoSize = true;
            this.label40.Location = new Point(0x12, 0x39);
            this.label40.Name = "label40";
            this.label40.Size = new Size(0x25, 13);
            this.label40.TabIndex = 0x35;
            this.label40.Text = "Estate";
            this.label40.Visible = false;
            this.tabPageDeduc.BackColor = SystemColors.Control;
            this.tabPageDeduc.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageDeduc.Controls.Add(this.radioButtonEntryAVG);
            this.tabPageDeduc.Controls.Add(this.radioButtonEntryTotalBunch);
            this.tabPageDeduc.Controls.Add(this.buttonEntryDeduc);
            this.tabPageDeduc.Controls.Add(this.panelDeducTBS);
            this.tabPageDeduc.Controls.Add(this.groupBoxTotalBunchFFB);
            this.tabPageDeduc.Controls.Add(this.buttonDeleteDeduc);
            this.tabPageDeduc.Controls.Add(this.buttonEditDeduc);
            this.tabPageDeduc.Controls.Add(this.dgvDeduc);
            this.tabPageDeduc.Controls.Add(this.buttonAddDeduc);
            this.tabPageDeduc.Controls.Add(this.shapeContainer2);
            this.tabPageDeduc.Location = new Point(4, 0x16);
            this.tabPageDeduc.Name = "tabPageDeduc";
            this.tabPageDeduc.Padding = new Padding(3);
            this.tabPageDeduc.Size = new Size(0x385, 0xd3);
            this.tabPageDeduc.TabIndex = 2;
            this.tabPageDeduc.Text = "Deduction";
            this.tabPageDeduc.Click += new EventHandler(this.tabPageDeduc_Click);
            this.radioButtonEntryAVG.AutoSize = true;
            this.radioButtonEntryAVG.Location = new Point(0x98, 50);
            this.radioButtonEntryAVG.Name = "radioButtonEntryAVG";
            this.radioButtonEntryAVG.Size = new Size(0x4a, 0x11);
            this.radioButtonEntryAVG.TabIndex = 0x83;
            this.radioButtonEntryAVG.Text = "Entry AVG";
            this.radioButtonEntryAVG.UseVisualStyleBackColor = true;
            this.radioButtonEntryAVG.CheckedChanged += new EventHandler(this.radioButtonEntryAVG_CheckedChanged);
            this.radioButtonEntryTotalBunch.AutoSize = true;
            this.radioButtonEntryTotalBunch.Checked = true;
            this.radioButtonEntryTotalBunch.Location = new Point(0x1b, 50);
            this.radioButtonEntryTotalBunch.Name = "radioButtonEntryTotalBunch";
            this.radioButtonEntryTotalBunch.Size = new Size(110, 0x11);
            this.radioButtonEntryTotalBunch.TabIndex = 130;
            this.radioButtonEntryTotalBunch.TabStop = true;
            this.radioButtonEntryTotalBunch.Text = "Entry Total Bunch";
            this.toolTip1.SetToolTip(this.radioButtonEntryTotalBunch, "Entry Total Qty to get Average Weight");
            this.radioButtonEntryTotalBunch.UseVisualStyleBackColor = true;
            this.radioButtonEntryTotalBunch.CheckedChanged += new EventHandler(this.radioButtonEntryTotalBunch_CheckedChanged);
            this.buttonEntryDeduc.Location = new Point(0x21, 6);
            this.buttonEntryDeduc.Name = "buttonEntryDeduc";
            this.buttonEntryDeduc.Size = new Size(0xc5, 0x26);
            this.buttonEntryDeduc.TabIndex = 0x81;
            this.buttonEntryDeduc.Text = "Entry Unit Deduction\r\nPer Contract\r\n";
            this.buttonEntryDeduc.UseVisualStyleBackColor = true;
            this.buttonEntryDeduc.Click += new EventHandler(this.buttonEntryDeduc_Click);
            this.panelDeducTBS.Controls.Add(this.textGrade);
            this.panelDeducTBS.Controls.Add(this.labelGrade);
            this.panelDeducTBS.Controls.Add(this.label41);
            this.panelDeducTBS.Controls.Add(this.label23);
            this.panelDeducTBS.Controls.Add(this.label32);
            this.panelDeducTBS.Controls.Add(this.textBoxKG);
            this.panelDeducTBS.Controls.Add(this.textFruitsType);
            this.panelDeducTBS.Controls.Add(this.labelFruitsTypeName);
            this.panelDeducTBS.Controls.Add(this.textRendCPO);
            this.panelDeducTBS.Controls.Add(this.label49);
            this.panelDeducTBS.Controls.Add(this.textReason);
            this.panelDeducTBS.Controls.Add(this.label47);
            this.panelDeducTBS.Controls.Add(this.labelReject);
            this.panelDeducTBS.Controls.Add(this.textTBSReject);
            this.panelDeducTBS.Location = new Point(0x1b, 0x99);
            this.panelDeducTBS.Name = "panelDeducTBS";
            this.panelDeducTBS.Size = new Size(0x241, 0x37);
            this.panelDeducTBS.TabIndex = 0x16;
            this.panelDeducTBS.Visible = false;
            this.textGrade.CharacterCasing = CharacterCasing.Upper;
            this.textGrade.Location = new Point(0xf7, 6);
            this.textGrade.MaxLength = 1;
            this.textGrade.Name = "textGrade";
            this.textGrade.Size = new Size(0x29, 20);
            this.textGrade.TabIndex = 0x17;
            this.textGrade.Leave += new EventHandler(this.textGrade_Leave);
            this.labelGrade.AutoSize = true;
            this.labelGrade.Location = new Point(0xbc, 10);
            this.labelGrade.Name = "labelGrade";
            this.labelGrade.Size = new Size(0x3a, 13);
            this.labelGrade.TabIndex = 0x16;
            this.labelGrade.Text = "FFB Grade";
            this.label41.AutoSize = true;
            this.label41.Location = new Point(12, 10);
            this.label41.Name = "label41";
            this.label41.Size = new Size(0x2f, 13);
            this.label41.TabIndex = 0x10;
            this.label41.Text = "RV CPO";
            this.label23.AutoSize = true;
            this.label23.Location = new Point(0x216, 8);
            this.label23.Name = "label23";
            this.label23.Size = new Size(0x16, 13);
            this.label23.TabIndex = 0x15;
            this.label23.Text = "KG";
            this.label32.AutoSize = true;
            this.label32.Location = new Point(12, 0x21);
            this.label32.Name = "label32";
            this.label32.Size = new Size(0x3b, 13);
            this.label32.TabIndex = 15;
            this.label32.Text = "Fruits Type";
            this.textBoxKG.Location = new Point(0x1c9, 4);
            this.textBoxKG.MaxLength = 10;
            this.textBoxKG.Name = "textBoxKG";
            this.textBoxKG.Size = new Size(0x49, 20);
            this.textBoxKG.TabIndex = 20;
            this.textBoxKG.Text = "0";
            this.textBoxKG.TextAlign = HorizontalAlignment.Right;
            this.textBoxKG.Leave += new EventHandler(this.textBox1_Leave_1);
            this.textFruitsType.Enabled = false;
            this.textFruitsType.Location = new Point(0x4d, 0x1d);
            this.textFruitsType.MaxLength = 15;
            this.textFruitsType.Name = "textFruitsType";
            this.textFruitsType.ReadOnly = true;
            this.textFruitsType.Size = new Size(0x17, 20);
            this.textFruitsType.TabIndex = 4;
            this.textFruitsType.Text = "R";
            this.labelFruitsTypeName.AutoSize = true;
            this.labelFruitsTypeName.Location = new Point(0x68, 0x21);
            this.labelFruitsTypeName.Name = "labelFruitsTypeName";
            this.labelFruitsTypeName.Size = new Size(0x19, 13);
            this.labelFruitsTypeName.TabIndex = 14;
            this.labelFruitsTypeName.Text = "   ...";
            this.textRendCPO.Location = new Point(0x4d, 6);
            this.textRendCPO.Name = "textRendCPO";
            this.textRendCPO.Size = new Size(0x2f, 20);
            this.textRendCPO.TabIndex = 3;
            this.textRendCPO.Text = "0.00";
            this.textRendCPO.Leave += new EventHandler(this.textRendCPO_Leave);
            this.label49.AutoSize = true;
            this.label49.Location = new Point(0xbc, 0x25);
            this.label49.Name = "label49";
            this.label49.Size = new Size(0x2c, 13);
            this.label49.TabIndex = 11;
            this.label49.Text = "Reason";
            this.textReason.Location = new Point(0xf7, 0x21);
            this.textReason.MaxLength = 150;
            this.textReason.Name = "textReason";
            this.textReason.Size = new Size(0x137, 20);
            this.textReason.TabIndex = 10;
            this.label47.AutoSize = true;
            this.label47.Location = new Point(0x125, 9);
            this.label47.Name = "label47";
            this.label47.Size = new Size(0x3e, 13);
            this.label47.TabIndex = 12;
            this.label47.Text = "TBS Reject";
            this.labelReject.AutoSize = true;
            this.labelReject.Location = new Point(0x19f, 10);
            this.labelReject.Name = "labelReject";
            this.labelReject.Size = new Size(0x26, 13);
            this.labelReject.TabIndex = 13;
            this.labelReject.Text = "Bunch";
            this.textTBSReject.Location = new Point(0x169, 6);
            this.textTBSReject.MaxLength = 10;
            this.textTBSReject.Name = "textTBSReject";
            this.textTBSReject.Size = new Size(50, 20);
            this.textTBSReject.TabIndex = 9;
            this.textTBSReject.Text = "0";
            this.textTBSReject.TextAlign = HorizontalAlignment.Right;
            this.textTBSReject.Leave += new EventHandler(this.textTBSReject_Leave);
            this.groupBoxTotalBunchFFB.Controls.Add(this.textBunchTotal);
            this.groupBoxTotalBunchFFB.Controls.Add(this.textBunchDeduc);
            this.groupBoxTotalBunchFFB.Controls.Add(this.label29);
            this.groupBoxTotalBunchFFB.Controls.Add(this.label30);
            this.groupBoxTotalBunchFFB.Controls.Add(this.textAvg);
            this.groupBoxTotalBunchFFB.Controls.Add(this.label31);
            this.groupBoxTotalBunchFFB.Location = new Point(0x1a, 0x42);
            this.groupBoxTotalBunchFFB.Name = "groupBoxTotalBunchFFB";
            this.groupBoxTotalBunchFFB.Size = new Size(200, 0x54);
            this.groupBoxTotalBunchFFB.TabIndex = 2;
            this.groupBoxTotalBunchFFB.TabStop = false;
            this.groupBoxTotalBunchFFB.Text = "[ Bunch ]";
            this.textBunchTotal.Location = new Point(0x87, 10);
            this.textBunchTotal.MaxLength = 15;
            this.textBunchTotal.Name = "textBunchTotal";
            this.textBunchTotal.Size = new Size(0x39, 20);
            this.textBunchTotal.TabIndex = 0;
            this.textBunchTotal.Text = "0";
            this.textBunchTotal.TextAlign = HorizontalAlignment.Right;
            this.textBunchTotal.Leave += new EventHandler(this.textBunchTotal_Leave);
            this.textBunchDeduc.Location = new Point(0x87, 0x23);
            this.textBunchDeduc.MaxLength = 15;
            this.textBunchDeduc.Name = "textBunchDeduc";
            this.textBunchDeduc.Size = new Size(0x39, 20);
            this.textBunchDeduc.TabIndex = 1;
            this.textBunchDeduc.Text = "0";
            this.textBunchDeduc.TextAlign = HorizontalAlignment.Right;
            this.label29.AutoSize = true;
            this.label29.Location = new Point(0x65, 13);
            this.label29.Name = "label29";
            this.label29.Size = new Size(0x22, 13);
            this.label29.TabIndex = 5;
            this.label29.Text = "Total ";
            this.label30.AutoSize = true;
            this.label30.Location = new Point(12, 0x26);
            this.label30.Name = "label30";
            this.label30.Size = new Size(0x7d, 13);
            this.label30.TabIndex = 4;
            this.label30.Text = "Total for Deduction Calc.";
            this.textAvg.Location = new Point(0x87, 60);
            this.textAvg.MaxLength = 15;
            this.textAvg.Name = "textAvg";
            this.textAvg.Size = new Size(0x39, 20);
            this.textAvg.TabIndex = 2;
            this.textAvg.Text = "0";
            this.textAvg.TextAlign = HorizontalAlignment.Right;
            this.textAvg.Leave += new EventHandler(this.textAvg_Leave);
            this.label31.AutoSize = true;
            this.label31.Location = new Point(0x2d, 60);
            this.label31.Name = "label31";
            this.label31.Size = new Size(0x54, 13);
            this.label31.TabIndex = 3;
            this.label31.Text = "Average Weight";
            this.buttonDeleteDeduc.Location = new Point(0x315, 0x9b);
            this.buttonDeleteDeduc.Name = "buttonDeleteDeduc";
            this.buttonDeleteDeduc.Size = new Size(0x4b, 0x17);
            this.buttonDeleteDeduc.TabIndex = 8;
            this.buttonDeleteDeduc.Text = "Delete";
            this.buttonDeleteDeduc.UseVisualStyleBackColor = true;
            this.buttonDeleteDeduc.Click += new EventHandler(this.button1_Click);
            this.buttonEditDeduc.Location = new Point(0x2c4, 0x9b);
            this.buttonEditDeduc.Name = "buttonEditDeduc";
            this.buttonEditDeduc.Size = new Size(0x4b, 0x17);
            this.buttonEditDeduc.TabIndex = 7;
            this.buttonEditDeduc.Text = "Edit";
            this.buttonEditDeduc.UseVisualStyleBackColor = true;
            this.buttonEditDeduc.Click += new EventHandler(this.button2_Click);
            this.dgvDeduc.AllowUserToAddRows = false;
            this.dgvDeduc.AllowUserToDeleteRows = false;
            this.dgvDeduc.AllowUserToResizeRows = false;
            this.dgvDeduc.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDeduc.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style4.BackColor = SystemColors.Control;
            style4.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style4.ForeColor = SystemColors.WindowText;
            style4.SelectionBackColor = SystemColors.Highlight;
            style4.SelectionForeColor = SystemColors.HighlightText;
            style4.WrapMode = DataGridViewTriState.True;
            this.dgvDeduc.ColumnHeadersDefaultCellStyle = style4;
            this.dgvDeduc.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style5.BackColor = SystemColors.Window;
            style5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style5.ForeColor = SystemColors.ControlText;
            style5.SelectionBackColor = SystemColors.Highlight;
            style5.SelectionForeColor = SystemColors.HighlightText;
            style5.WrapMode = DataGridViewTriState.False;
            this.dgvDeduc.DefaultCellStyle = style5;
            this.dgvDeduc.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvDeduc.Location = new Point(0x112, 3);
            this.dgvDeduc.MultiSelect = false;
            this.dgvDeduc.Name = "dgvDeduc";
            style6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style6.BackColor = SystemColors.Control;
            style6.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style6.ForeColor = SystemColors.WindowText;
            style6.SelectionBackColor = SystemColors.Highlight;
            style6.SelectionForeColor = SystemColors.HighlightText;
            style6.WrapMode = DataGridViewTriState.True;
            this.dgvDeduc.RowHeadersDefaultCellStyle = style6;
            this.dgvDeduc.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDeduc.Size = new Size(0x250, 0x93);
            this.dgvDeduc.TabIndex = 5;
            this.dgvDeduc.CellDoubleClick += new DataGridViewCellEventHandler(this.dgvDeduc_CellDoubleClick);
            this.buttonAddDeduc.Location = new Point(0x273, 0x9b);
            this.buttonAddDeduc.Name = "buttonAddDeduc";
            this.buttonAddDeduc.Size = new Size(0x4b, 0x17);
            this.buttonAddDeduc.TabIndex = 6;
            this.buttonAddDeduc.Text = "Add ";
            this.buttonAddDeduc.UseVisualStyleBackColor = true;
            this.buttonAddDeduc.Click += new EventHandler(this.button3_Click);
            this.shapeContainer2.Location = new Point(3, 3);
            this.shapeContainer2.Margin = new Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            Shape[] shapes = new Shape[] { this.rectangleShape1 };
            this.shapeContainer2.Shapes.AddRange(shapes);
            this.shapeContainer2.Size = new Size(0x37d, 0xcb);
            this.shapeContainer2.TabIndex = 0;
            this.shapeContainer2.TabStop = false;
            this.rectangleShape1.Location = new Point(0x268, 0x91);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new Size(0xf6, 0x21);
            this.tabPageDivision.BackColor = SystemColors.Control;
            this.tabPageDivision.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageDivision.Controls.Add(this.dgvDivBlock);
            this.tabPageDivision.Controls.Add(this.panel3);
            this.tabPageDivision.Location = new Point(4, 0x16);
            this.tabPageDivision.Name = "tabPageDivision";
            this.tabPageDivision.Padding = new Padding(3);
            this.tabPageDivision.Size = new Size(0x385, 0xd3);
            this.tabPageDivision.TabIndex = 3;
            this.tabPageDivision.Text = "Division & Block";
            this.dgvDivBlock.AllowUserToAddRows = false;
            this.dgvDivBlock.AllowUserToDeleteRows = false;
            this.dgvDivBlock.AllowUserToResizeRows = false;
            this.dgvDivBlock.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDivBlock.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style7.BackColor = SystemColors.Control;
            style7.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style7.ForeColor = SystemColors.WindowText;
            style7.SelectionBackColor = SystemColors.Highlight;
            style7.SelectionForeColor = SystemColors.HighlightText;
            style7.WrapMode = DataGridViewTriState.True;
            this.dgvDivBlock.ColumnHeadersDefaultCellStyle = style7;
            this.dgvDivBlock.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style8.BackColor = SystemColors.Window;
            style8.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style8.ForeColor = SystemColors.ControlText;
            style8.SelectionBackColor = SystemColors.Highlight;
            style8.SelectionForeColor = SystemColors.HighlightText;
            style8.WrapMode = DataGridViewTriState.False;
            this.dgvDivBlock.DefaultCellStyle = style8;
            this.dgvDivBlock.Dock = DockStyle.Fill;
            this.dgvDivBlock.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvDivBlock.Location = new Point(3, 3);
            this.dgvDivBlock.MultiSelect = false;
            this.dgvDivBlock.Name = "dgvDivBlock";
            style9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style9.BackColor = SystemColors.Control;
            style9.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style9.ForeColor = SystemColors.WindowText;
            style9.SelectionBackColor = SystemColors.Highlight;
            style9.SelectionForeColor = SystemColors.HighlightText;
            style9.WrapMode = DataGridViewTriState.True;
            this.dgvDivBlock.RowHeadersDefaultCellStyle = style9;
            this.dgvDivBlock.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDivBlock.Size = new Size(0x37d, 0xb2);
            this.dgvDivBlock.TabIndex = 2;
            this.panel3.BackColor = SystemColors.Control;
            this.panel3.Controls.Add(this.button15);
            this.panel3.Controls.Add(this.button16);
            this.panel3.Controls.Add(this.button17);
            this.panel3.Dock = DockStyle.Bottom;
            this.panel3.Location = new Point(3, 0xb5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new Size(0x37d, 0x19);
            this.panel3.TabIndex = 3;
            this.button15.Location = new Point(0xa7, 3);
            this.button15.Name = "button15";
            this.button15.Size = new Size(0x4b, 0x17);
            this.button15.TabIndex = 2;
            this.button15.Text = "Delete";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new EventHandler(this.button15_Click);
            this.button16.Location = new Point(0x56, 2);
            this.button16.Name = "button16";
            this.button16.Size = new Size(0x4b, 0x17);
            this.button16.TabIndex = 1;
            this.button16.Text = "Edit";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new EventHandler(this.button16_Click);
            this.button17.Location = new Point(5, 2);
            this.button17.Name = "button17";
            this.button17.Size = new Size(0x4b, 0x17);
            this.button17.TabIndex = 0;
            this.button17.Text = "Add ";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new EventHandler(this.button17_Click);
            this.tabPageQC.BackColor = SystemColors.Control;
            this.tabPageQC.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageQC.Controls.Add(this.label20);
            this.tabPageQC.Controls.Add(this.textQualityInfo);
            this.tabPageQC.Controls.Add(this.dgvQC_All);
            this.tabPageQC.Controls.Add(this.textTankQC);
            this.tabPageQC.Controls.Add(this.label44);
            this.tabPageQC.Controls.Add(this.label43);
            this.tabPageQC.Controls.Add(this.combodgvDO);
            this.tabPageQC.Controls.Add(this.textQControl);
            this.tabPageQC.Controls.Add(this.label42);
            this.tabPageQC.Controls.Add(this.dgvQC);
            this.tabPageQC.Location = new Point(4, 0x16);
            this.tabPageQC.Name = "tabPageQC";
            this.tabPageQC.Padding = new Padding(3);
            this.tabPageQC.Size = new Size(0x385, 0xd3);
            this.tabPageQC.TabIndex = 4;
            this.tabPageQC.Text = "Quality Control / Yield";
            this.label20.AutoSize = true;
            this.label20.Location = new Point(8, 0x62);
            this.label20.Name = "label20";
            this.label20.Size = new Size(0x42, 13);
            this.label20.TabIndex = 0x17;
            this.label20.Text = "Quality Info :";
            this.textQualityInfo.Enabled = false;
            this.textQualityInfo.Font = new Font("Lucida Console", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textQualityInfo.Location = new Point(6, 0x72);
            this.textQualityInfo.Name = "textQualityInfo";
            this.textQualityInfo.Size = new Size(0xbf, 0x58);
            this.textQualityInfo.TabIndex = 0x16;
            this.textQualityInfo.Text = "";
            this.dgvQC_All.AllowUserToAddRows = false;
            this.dgvQC_All.AllowUserToDeleteRows = false;
            this.dgvQC_All.AllowUserToResizeRows = false;
            this.dgvQC_All.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvQC_All.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style10.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style10.BackColor = SystemColors.Control;
            style10.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style10.ForeColor = SystemColors.WindowText;
            style10.SelectionBackColor = SystemColors.Highlight;
            style10.SelectionForeColor = SystemColors.HighlightText;
            style10.WrapMode = DataGridViewTriState.True;
            this.dgvQC_All.ColumnHeadersDefaultCellStyle = style10;
            this.dgvQC_All.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style11.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style11.BackColor = SystemColors.Window;
            style11.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style11.ForeColor = SystemColors.ControlText;
            style11.SelectionBackColor = SystemColors.Highlight;
            style11.SelectionForeColor = SystemColors.HighlightText;
            style11.WrapMode = DataGridViewTriState.False;
            this.dgvQC_All.DefaultCellStyle = style11;
            this.dgvQC_All.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvQC_All.Location = new Point(0xdd, 0xab);
            this.dgvQC_All.MultiSelect = false;
            this.dgvQC_All.Name = "dgvQC_All";
            style12.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style12.BackColor = SystemColors.Control;
            style12.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style12.ForeColor = SystemColors.WindowText;
            style12.SelectionBackColor = SystemColors.Highlight;
            style12.SelectionForeColor = SystemColors.HighlightText;
            style12.WrapMode = DataGridViewTriState.True;
            this.dgvQC_All.RowHeadersDefaultCellStyle = style12;
            this.dgvQC_All.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvQC_All.Size = new Size(0x1b, 0x20);
            this.dgvQC_All.TabIndex = 4;
            this.dgvQC_All.Visible = false;
            this.textTankQC.CharacterCasing = CharacterCasing.Upper;
            this.textTankQC.Location = new Point(6, 0x45);
            this.textTankQC.MaxLength = 15;
            this.textTankQC.Name = "textTankQC";
            this.textTankQC.Size = new Size(0xbf, 20);
            this.textTankQC.TabIndex = 2;
            this.textTankQC.Leave += new EventHandler(this.textTankQC_Leave);
            this.label44.AutoSize = true;
            this.label44.Location = new Point(5, 0x35);
            this.label44.Name = "label44";
            this.label44.Size = new Size(0x26, 13);
            this.label44.TabIndex = 7;
            this.label44.Text = "Tank :";
            this.label43.AutoSize = true;
            this.label43.Location = new Point(280, 0xab);
            this.label43.Name = "label43";
            this.label43.Size = new Size(0x17, 13);
            this.label43.TabIndex = 5;
            this.label43.Text = "DO";
            this.label43.Visible = false;
            this.combodgvDO.FormattingEnabled = true;
            this.combodgvDO.Location = new Point(0x116, 0xbb);
            this.combodgvDO.Name = "combodgvDO";
            this.combodgvDO.Size = new Size(0xbf, 0x15);
            this.combodgvDO.TabIndex = 0;
            this.combodgvDO.Visible = false;
            this.combodgvDO.SelectedIndexChanged += new EventHandler(this.combodgvDO_SelectedIndexChanged);
            this.combodgvDO.KeyPress += new KeyPressEventHandler(this.combodgvDO_KeyPress);
            this.textQControl.CharacterCasing = CharacterCasing.Upper;
            this.textQControl.Location = new Point(6, 0x19);
            this.textQControl.MaxLength = 20;
            this.textQControl.Name = "textQControl";
            this.textQControl.Size = new Size(0xbf, 20);
            this.textQControl.TabIndex = 1;
            this.textQControl.Leave += new EventHandler(this.textQControl_Leave);
            this.label42.AutoSize = true;
            this.label42.Location = new Point(8, 9);
            this.label42.Name = "label42";
            this.label42.Size = new Size(0x51, 13);
            this.label42.TabIndex = 6;
            this.label42.Text = "Quality Control :";
            this.dgvQC.AllowUserToAddRows = false;
            this.dgvQC.AllowUserToDeleteRows = false;
            this.dgvQC.AllowUserToResizeRows = false;
            this.dgvQC.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvQC.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style13.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style13.BackColor = SystemColors.Control;
            style13.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style13.ForeColor = SystemColors.WindowText;
            style13.SelectionBackColor = SystemColors.Highlight;
            style13.SelectionForeColor = SystemColors.HighlightText;
            style13.WrapMode = DataGridViewTriState.True;
            this.dgvQC.ColumnHeadersDefaultCellStyle = style13;
            this.dgvQC.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style14.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style14.BackColor = SystemColors.Window;
            style14.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style14.ForeColor = SystemColors.ControlText;
            style14.SelectionBackColor = SystemColors.Highlight;
            style14.SelectionForeColor = SystemColors.HighlightText;
            style14.WrapMode = DataGridViewTriState.False;
            this.dgvQC.DefaultCellStyle = style14;
            this.dgvQC.EditMode = DataGridViewEditMode.EditOnKeystroke;
            this.dgvQC.Location = new Point(0xcc, 2);
            this.dgvQC.MultiSelect = false;
            this.dgvQC.Name = "dgvQC";
            style15.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style15.BackColor = SystemColors.Control;
            style15.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style15.ForeColor = SystemColors.WindowText;
            style15.SelectionBackColor = SystemColors.Highlight;
            style15.SelectionForeColor = SystemColors.HighlightText;
            style15.WrapMode = DataGridViewTriState.True;
            this.dgvQC.RowHeadersDefaultCellStyle = style15;
            this.dgvQC.SelectionMode = DataGridViewSelectionMode.CellSelect;
            this.dgvQC.Size = new Size(0x29b, 0xbb);
            this.dgvQC.TabIndex = 3;
            this.dgvQC.CellEndEdit += new DataGridViewCellEventHandler(this.dgvQC_CellEndEdit);
            this.dgvQC.DoubleClick += new EventHandler(this.dgvQC_DoubleClick);
            this.tabPageCont.BackColor = SystemColors.Control;
            this.tabPageCont.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageCont.Controls.Add(this.dgvCont);
            this.tabPageCont.Controls.Add(this.panel5);
            this.tabPageCont.Location = new Point(4, 0x16);
            this.tabPageCont.Name = "tabPageCont";
            this.tabPageCont.Padding = new Padding(3);
            this.tabPageCont.Size = new Size(0x385, 0xd3);
            this.tabPageCont.TabIndex = 5;
            this.tabPageCont.Text = "Container No ";
            this.dgvCont.AllowUserToAddRows = false;
            this.dgvCont.AllowUserToDeleteRows = false;
            this.dgvCont.AllowUserToResizeRows = false;
            this.dgvCont.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvCont.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style16.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style16.BackColor = SystemColors.Control;
            style16.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style16.ForeColor = SystemColors.WindowText;
            style16.SelectionBackColor = SystemColors.Highlight;
            style16.SelectionForeColor = SystemColors.HighlightText;
            style16.WrapMode = DataGridViewTriState.True;
            this.dgvCont.ColumnHeadersDefaultCellStyle = style16;
            this.dgvCont.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style17.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style17.BackColor = SystemColors.Window;
            style17.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style17.ForeColor = SystemColors.ControlText;
            style17.SelectionBackColor = SystemColors.Highlight;
            style17.SelectionForeColor = SystemColors.HighlightText;
            style17.WrapMode = DataGridViewTriState.False;
            this.dgvCont.DefaultCellStyle = style17;
            this.dgvCont.Dock = DockStyle.Fill;
            this.dgvCont.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvCont.Location = new Point(3, 3);
            this.dgvCont.MultiSelect = false;
            this.dgvCont.Name = "dgvCont";
            style18.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style18.BackColor = SystemColors.Control;
            style18.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style18.ForeColor = SystemColors.WindowText;
            style18.SelectionBackColor = SystemColors.Highlight;
            style18.SelectionForeColor = SystemColors.HighlightText;
            style18.WrapMode = DataGridViewTriState.True;
            this.dgvCont.RowHeadersDefaultCellStyle = style18;
            this.dgvCont.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvCont.Size = new Size(0x37d, 0xa3);
            this.dgvCont.TabIndex = 2;
            this.panel5.BackColor = SystemColors.Control;
            this.panel5.Controls.Add(this.buttonContDelete);
            this.panel5.Controls.Add(this.buttonContEdit);
            this.panel5.Controls.Add(this.buttonContAdd);
            this.panel5.Dock = DockStyle.Bottom;
            this.panel5.Location = new Point(3, 0xa6);
            this.panel5.Name = "panel5";
            this.panel5.Size = new Size(0x37d, 40);
            this.panel5.TabIndex = 3;
            this.buttonContDelete.Location = new Point(0xa7, 3);
            this.buttonContDelete.Name = "buttonContDelete";
            this.buttonContDelete.Size = new Size(0x4b, 30);
            this.buttonContDelete.TabIndex = 2;
            this.buttonContDelete.Text = "Delete";
            this.buttonContDelete.UseVisualStyleBackColor = true;
            this.buttonContDelete.Click += new EventHandler(this.buttonContDelete_Click);
            this.buttonContEdit.Location = new Point(0x56, 2);
            this.buttonContEdit.Name = "buttonContEdit";
            this.buttonContEdit.Size = new Size(0x4b, 30);
            this.buttonContEdit.TabIndex = 1;
            this.buttonContEdit.Text = "Edit";
            this.buttonContEdit.UseVisualStyleBackColor = true;
            this.buttonContEdit.Click += new EventHandler(this.buttonContEdit_Click);
            this.buttonContAdd.Location = new Point(5, 2);
            this.buttonContAdd.Name = "buttonContAdd";
            this.buttonContAdd.Size = new Size(0x4b, 30);
            this.buttonContAdd.TabIndex = 0;
            this.buttonContAdd.Text = "Add ";
            this.buttonContAdd.UseVisualStyleBackColor = true;
            this.buttonContAdd.Click += new EventHandler(this.buttonContAdd_Click);
            this.tabPagePorla.BackColor = SystemColors.Control;
            this.tabPagePorla.Controls.Add(this.label22);
            this.tabPagePorla.Controls.Add(this.buttonDeletePorla);
            this.tabPagePorla.Controls.Add(this.buttonEditPorla);
            this.tabPagePorla.Controls.Add(this.dgvDeducPorla);
            this.tabPagePorla.Controls.Add(this.buttonAddPorla);
            this.tabPagePorla.Controls.Add(this.shapeContainer3);
            this.tabPagePorla.Location = new Point(4, 0x16);
            this.tabPagePorla.Name = "tabPagePorla";
            this.tabPagePorla.Padding = new Padding(3);
            this.tabPagePorla.Size = new Size(0x385, 0xd3);
            this.tabPagePorla.TabIndex = 6;
            this.tabPagePorla.Text = "Porla";
            this.label22.AutoSize = true;
            this.label22.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label22.Location = new Point(0x39, 0x10);
            this.label22.Name = "label22";
            this.label22.Size = new Size(0x63, 0x11);
            this.label22.TabIndex = 0x30;
            this.label22.Text = "Entry Porla :";
            this.buttonDeletePorla.Location = new Point(0x148, 0xa7);
            this.buttonDeletePorla.Name = "buttonDeletePorla";
            this.buttonDeletePorla.Size = new Size(0x4b, 0x17);
            this.buttonDeletePorla.TabIndex = 0x1b;
            this.buttonDeletePorla.Text = "Delete";
            this.buttonDeletePorla.UseVisualStyleBackColor = true;
            this.buttonDeletePorla.Click += new EventHandler(this.button5_Click_1);
            this.buttonEditPorla.Location = new Point(0xf7, 0xa7);
            this.buttonEditPorla.Name = "buttonEditPorla";
            this.buttonEditPorla.Size = new Size(0x4b, 0x17);
            this.buttonEditPorla.TabIndex = 0x1a;
            this.buttonEditPorla.Text = "Edit";
            this.buttonEditPorla.UseVisualStyleBackColor = true;
            this.buttonEditPorla.Click += new EventHandler(this.button12_Click_1);
            this.dgvDeducPorla.AllowUserToAddRows = false;
            this.dgvDeducPorla.AllowUserToDeleteRows = false;
            this.dgvDeducPorla.AllowUserToResizeRows = false;
            this.dgvDeducPorla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDeducPorla.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style19.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style19.BackColor = SystemColors.Control;
            style19.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style19.ForeColor = SystemColors.WindowText;
            style19.SelectionBackColor = SystemColors.Highlight;
            style19.SelectionForeColor = SystemColors.HighlightText;
            style19.WrapMode = DataGridViewTriState.True;
            this.dgvDeducPorla.ColumnHeadersDefaultCellStyle = style19;
            this.dgvDeducPorla.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style20.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style20.BackColor = SystemColors.Window;
            style20.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style20.ForeColor = SystemColors.ControlText;
            style20.SelectionBackColor = SystemColors.Highlight;
            style20.SelectionForeColor = SystemColors.HighlightText;
            style20.WrapMode = DataGridViewTriState.False;
            this.dgvDeducPorla.DefaultCellStyle = style20;
            this.dgvDeducPorla.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvDeducPorla.Location = new Point(0xa2, 0x10);
            this.dgvDeducPorla.MultiSelect = false;
            this.dgvDeducPorla.Name = "dgvDeducPorla";
            style21.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style21.BackColor = SystemColors.Control;
            style21.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style21.ForeColor = SystemColors.WindowText;
            style21.SelectionBackColor = SystemColors.Highlight;
            style21.SelectionForeColor = SystemColors.HighlightText;
            style21.WrapMode = DataGridViewTriState.True;
            this.dgvDeducPorla.RowHeadersDefaultCellStyle = style21;
            this.dgvDeducPorla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDeducPorla.Size = new Size(0x250, 0x93);
            this.dgvDeducPorla.TabIndex = 0x18;
            this.dgvDeducPorla.CellDoubleClick += new DataGridViewCellEventHandler(this.dgvDeducPorla_CellDoubleClick);
            this.buttonAddPorla.Location = new Point(0xa6, 0xa7);
            this.buttonAddPorla.Name = "buttonAddPorla";
            this.buttonAddPorla.Size = new Size(0x4b, 0x17);
            this.buttonAddPorla.TabIndex = 0x19;
            this.buttonAddPorla.Text = "Add ";
            this.buttonAddPorla.UseVisualStyleBackColor = true;
            this.buttonAddPorla.Click += new EventHandler(this.button14_Click);
            this.shapeContainer3.Location = new Point(3, 3);
            this.shapeContainer3.Margin = new Padding(0);
            this.shapeContainer3.Name = "shapeContainer3";
            Shape[] shapeArray2 = new Shape[] { this.rectangleShape2 };
            this.shapeContainer3.Shapes.AddRange(shapeArray2);
            this.shapeContainer3.Size = new Size(0x37f, 0xcd);
            this.shapeContainer3.TabIndex = 0x27;
            this.shapeContainer3.TabStop = false;
            this.rectangleShape2.Location = new Point(0x9f, 0x9d);
            this.rectangleShape2.Name = "rectangleShape2";
            this.rectangleShape2.Size = new Size(0xf6, 0x21);
            this.tabPageCopra.BackColor = SystemColors.Control;
            this.tabPageCopra.Controls.Add(this.buttonEntryCopra);
            this.tabPageCopra.Controls.Add(this.label24);
            this.tabPageCopra.Controls.Add(this.textTotalCopra);
            this.tabPageCopra.Controls.Add(this.label27);
            this.tabPageCopra.Location = new Point(4, 0x16);
            this.tabPageCopra.Name = "tabPageCopra";
            this.tabPageCopra.Padding = new Padding(3);
            this.tabPageCopra.Size = new Size(0x385, 0xd3);
            this.tabPageCopra.TabIndex = 7;
            this.tabPageCopra.Text = "Copra";
            this.buttonEntryCopra.Location = new Point(0x13, 0x17);
            this.buttonEntryCopra.Name = "buttonEntryCopra";
            this.buttonEntryCopra.Size = new Size(0x8d, 0x2b);
            this.buttonEntryCopra.TabIndex = 0x8f;
            this.buttonEntryCopra.Text = "Entry Copra Deduction";
            this.buttonEntryCopra.UseVisualStyleBackColor = true;
            this.buttonEntryCopra.Click += new EventHandler(this.buttonEntryCopra_Click);
            this.label24.AutoSize = true;
            this.label24.Location = new Point(0xef, 0x59);
            this.label24.Name = "label24";
            this.label24.Size = new Size(0x16, 13);
            this.label24.TabIndex = 0x8e;
            this.label24.Text = "KG";
            this.textTotalCopra.BackColor = SystemColors.ControlDark;
            this.textTotalCopra.Location = new Point(0x92, 0x56);
            this.textTotalCopra.Name = "textTotalCopra";
            this.textTotalCopra.ReadOnly = true;
            this.textTotalCopra.Size = new Size(0x59, 20);
            this.textTotalCopra.TabIndex = 0x8d;
            this.textTotalCopra.Text = "0";
            this.textTotalCopra.TextAlign = HorizontalAlignment.Right;
            this.label27.AutoSize = true;
            this.label27.Location = new Point(0x19, 0x59);
            this.label27.Name = "label27";
            this.label27.Size = new Size(0x72, 13);
            this.label27.TabIndex = 140;
            this.label27.Text = "Total Copra Deduction";
            this.tabPageDL.BackColor = SystemColors.Control;
            this.tabPageDL.Controls.Add(this.button19);
            this.tabPageDL.Controls.Add(this.button20);
            this.tabPageDL.Controls.Add(this.button18);
            this.tabPageDL.Controls.Add(this.dgvListDO);
            this.tabPageDL.Controls.Add(this.textNettoBatchLeft);
            this.tabPageDL.Controls.Add(this.label51);
            this.tabPageDL.Controls.Add(this.label53);
            this.tabPageDL.Controls.Add(this.textGunnyBatchLeft);
            this.tabPageDL.Controls.Add(this.label52);
            this.tabPageDL.Controls.Add(this.buttonAdopt);
            this.tabPageDL.Controls.Add(this.textDL);
            this.tabPageDL.Controls.Add(this.label56);
            this.tabPageDL.Controls.Add(this.textSTO);
            this.tabPageDL.Controls.Add(this.groupBox2);
            this.tabPageDL.Controls.Add(this.groupBox1);
            this.tabPageDL.Controls.Add(this.label28);
            this.tabPageDL.Controls.Add(this.dgvBatch);
            this.tabPageDL.Location = new Point(4, 0x16);
            this.tabPageDL.Name = "tabPageDL";
            this.tabPageDL.Padding = new Padding(3);
            this.tabPageDL.Size = new Size(0x385, 0xd3);
            this.tabPageDL.TabIndex = 8;
            this.tabPageDL.Text = "Delivery Letter";
            this.button19.Location = new Point(0x25c, 0xae);
            this.button19.Name = "button19";
            this.button19.Size = new Size(0x51, 0x1c);
            this.button19.TabIndex = 0x3a;
            this.button19.Text = "Split Batch";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new EventHandler(this.button19_Click);
            this.button20.Location = new Point(0x1ff, 0xae);
            this.button20.Name = "button20";
            this.button20.Size = new Size(0x51, 0x1c);
            this.button20.TabIndex = 0x30;
            this.button20.Text = "Merge Batch";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new EventHandler(this.button20_Click);
            this.button18.Location = new Point(0x1a0, 0xac);
            this.button18.Name = "button18";
            this.button18.Size = new Size(0x51, 0x1c);
            this.button18.TabIndex = 0x2f;
            this.button18.Text = "Add";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new EventHandler(this.button18_Click);
            this.dgvListDO.AllowUserToAddRows = false;
            this.dgvListDO.AllowUserToDeleteRows = false;
            this.dgvListDO.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListDO.Location = new Point(10, 6);
            this.dgvListDO.Name = "dgvListDO";
            this.dgvListDO.ReadOnly = true;
            this.dgvListDO.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvListDO.Size = new Size(0xa7, 0xc5);
            this.dgvListDO.TabIndex = 0x3b;
            this.dgvListDO.CellContentClick += new DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.textNettoBatchLeft.Enabled = false;
            this.textNettoBatchLeft.Location = new Point(0x2f5, 0xbc);
            this.textNettoBatchLeft.MaxLength = 20;
            this.textNettoBatchLeft.Name = "textNettoBatchLeft";
            this.textNettoBatchLeft.Size = new Size(0x6a, 20);
            this.textNettoBatchLeft.TabIndex = 0x16;
            this.textNettoBatchLeft.Text = "0";
            this.textNettoBatchLeft.Visible = false;
            this.label51.Location = new Point(0x2b5, 0xbf);
            this.label51.Name = "label51";
            this.label51.Size = new Size(60, 13);
            this.label51.TabIndex = 0x17;
            this.label51.Text = "Netto Left";
            this.label51.TextAlign = ContentAlignment.TopRight;
            this.label51.Visible = false;
            this.label53.AutoSize = true;
            this.label53.Location = new Point(0x362, 0xbf);
            this.label53.Name = "label53";
            this.label53.Size = new Size(0x16, 13);
            this.label53.TabIndex = 0x1a;
            this.label53.Text = "KG";
            this.label53.Visible = false;
            this.textGunnyBatchLeft.Enabled = false;
            this.textGunnyBatchLeft.Location = new Point(0x2f5, 0xa8);
            this.textGunnyBatchLeft.MaxLength = 20;
            this.textGunnyBatchLeft.Name = "textGunnyBatchLeft";
            this.textGunnyBatchLeft.Size = new Size(0x39, 20);
            this.textGunnyBatchLeft.TabIndex = 0x18;
            this.textGunnyBatchLeft.Text = "0";
            this.textGunnyBatchLeft.Visible = false;
            this.label52.Location = new Point(0x2b6, 0xab);
            this.label52.Name = "label52";
            this.label52.Size = new Size(0x3b, 13);
            this.label52.TabIndex = 0x19;
            this.label52.Text = "Gunny Left";
            this.label52.TextAlign = ContentAlignment.TopRight;
            this.label52.Visible = false;
            this.buttonAdopt.Location = new Point(0x160, 15);
            this.buttonAdopt.Name = "buttonAdopt";
            this.buttonAdopt.Size = new Size(0x2c, 0x16);
            this.buttonAdopt.TabIndex = 0x39;
            this.buttonAdopt.Text = "&Adopt";
            this.buttonAdopt.UseVisualStyleBackColor = true;
            this.buttonAdopt.Click += new EventHandler(this.buttonAdopt_Click);
            this.textDL.Location = new Point(0x100, 0x10);
            this.textDL.Name = "textDL";
            this.textDL.Size = new Size(0x5c, 20);
            this.textDL.TabIndex = 0x38;
            this.textDL.Leave += new EventHandler(this.textDL_Leave);
            this.label56.AutoSize = true;
            this.label56.Location = new Point(0xb5, 0x13);
            this.label56.Name = "label56";
            this.label56.Size = new Size(0x4b, 13);
            this.label56.TabIndex = 0x37;
            this.label56.Text = "Delivery Letter";
            this.textSTO.Location = new Point(0x105, 0x2f);
            this.textSTO.MaxLength = 20;
            this.textSTO.Name = "textSTO";
            this.textSTO.Size = new Size(0x88, 20);
            this.textSTO.TabIndex = 0x2c;
            this.groupBox2.Controls.Add(this.label60);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.label58);
            this.groupBox2.Location = new Point(0xbc, 0x8a);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0xd1, 0x40);
            this.groupBox2.TabIndex = 50;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "WB Info";
            this.label60.AutoSize = true;
            this.label60.Location = new Point(0xb6, 0x15);
            this.label60.Name = "label60";
            this.label60.Size = new Size(0x16, 13);
            this.label60.TabIndex = 0x1c;
            this.label60.Text = "KG";
            this.textBox3.Location = new Point(0x65, 0x12);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new Size(0x4e, 20);
            this.textBox3.TabIndex = 3;
            this.textBox3.TextAlign = HorizontalAlignment.Right;
            this.label58.AutoSize = true;
            this.label58.Location = new Point(10, 0x15);
            this.label58.Name = "label58";
            this.label58.Size = new Size(0x55, 13);
            this.label58.TabIndex = 1;
            this.label58.Text = "Netto per Gunny";
            this.groupBox1.Controls.Add(this.textNettoBatch);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.label48);
            this.groupBox1.Controls.Add(this.textGunnyBatch);
            this.groupBox1.Controls.Add(this.label50);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label55);
            this.groupBox1.Location = new Point(0xbc, 0x42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0xd1, 0x42);
            this.groupBox1.TabIndex = 0x31;
            this.groupBox1.TabStop = false;
            this.textNettoBatch.Location = new Point(0x2f, 40);
            this.textNettoBatch.MaxLength = 20;
            this.textNettoBatch.Name = "textNettoBatch";
            this.textNettoBatch.ReadOnly = true;
            this.textNettoBatch.Size = new Size(0x6a, 20);
            this.textNettoBatch.TabIndex = 0x2e;
            this.textNettoBatch.Text = "0";
            this.textNettoBatch.Leave += new EventHandler(this.textNettoBatch_Leave);
            this.label36.Location = new Point(3, 0x2b);
            this.label36.Name = "label36";
            this.label36.Size = new Size(0x24, 13);
            this.label36.TabIndex = 0x17;
            this.label36.Text = "Netto";
            this.label36.TextAlign = ContentAlignment.TopRight;
            this.label48.Location = new Point(1, 0x12);
            this.label48.Name = "label48";
            this.label48.Size = new Size(0x2b, 13);
            this.label48.TabIndex = 0x19;
            this.label48.Text = "Gunny";
            this.label48.TextAlign = ContentAlignment.TopRight;
            this.textGunnyBatch.Location = new Point(0x2e, 15);
            this.textGunnyBatch.MaxLength = 20;
            this.textGunnyBatch.Name = "textGunnyBatch";
            this.textGunnyBatch.ReadOnly = true;
            this.textGunnyBatch.Size = new Size(0x39, 20);
            this.textGunnyBatch.TabIndex = 0x2d;
            this.textGunnyBatch.Text = "0";
            this.textGunnyBatch.TextChanged += new EventHandler(this.textGunnyBatch_textChanged);
            this.label50.AutoSize = true;
            this.label50.Location = new Point(0xb6, 0x2b);
            this.label50.Name = "label50";
            this.label50.Size = new Size(0x16, 13);
            this.label50.TabIndex = 0x1a;
            this.label50.Text = "KG";
            this.textBox1.Enabled = false;
            this.textBox1.Location = new Point(0x7a, 15);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(60, 20);
            this.textBox1.TabIndex = 0x34;
            this.label55.AutoSize = true;
            this.label55.Location = new Point(0xb6, 0x12);
            this.label55.Name = "label55";
            this.label55.Size = new Size(0x16, 13);
            this.label55.TabIndex = 0x36;
            this.label55.Text = "KG";
            this.label28.AutoSize = true;
            this.label28.Location = new Point(0xe3, 50);
            this.label28.Name = "label28";
            this.label28.Size = new Size(0x1d, 13);
            this.label28.TabIndex = 0x2d;
            this.label28.Text = "STO";
            this.dgvBatch.AllowUserToAddRows = false;
            this.dgvBatch.AllowUserToDeleteRows = false;
            this.dgvBatch.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBatch.Location = new Point(0x197, 3);
            this.dgvBatch.Name = "dgvBatch";
            this.dgvBatch.ReadOnly = true;
            this.dgvBatch.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvBatch.Size = new Size(0x1dd, 0xa2);
            this.dgvBatch.TabIndex = 0x2f;
            this.dgvBatch.CellBeginEdit += new DataGridViewCellCancelEventHandler(this.dgvBatch_CellBeginEdit);
            this.dgvBatch.CellClick += new DataGridViewCellEventHandler(this.dgvBatch_CellClick);
            this.dgvBatch.CellEndEdit += new DataGridViewCellEventHandler(this.dgvBatch_CellEndEdit);
            this.dgvBatch.RowsAdded += new DataGridViewRowsAddedEventHandler(this.rows_added);
            this.dgvBatch.RowsRemoved += new DataGridViewRowsRemovedEventHandler(this.rows_removed);
            this.textReport_Date.BackColor = Color.White;
            this.textReport_Date.Location = new Point(0x323, 0x3b);
            this.textReport_Date.MaxLength = 10;
            this.textReport_Date.Name = "textReport_Date";
            this.textReport_Date.ReadOnly = true;
            this.textReport_Date.Size = new Size(0x66, 20);
            this.textReport_Date.TabIndex = 7;
            this.textReport_Date.Leave += new EventHandler(this.textReport_Date_Leave);
            this.label37.AutoSize = true;
            this.label37.Location = new Point(0x2de, 0x3e);
            this.label37.Name = "label37";
            this.label37.Size = new Size(0x41, 13);
            this.label37.TabIndex = 14;
            this.label37.Text = "Report Date";
            this.textRefNo.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textRefNo.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textRefNo.Location = new Point(0x2c9, 4);
            this.textRefNo.MaxLength = 0x10;
            this.textRefNo.Name = "textRefNo";
            this.textRefNo.Size = new Size(0xc1, 0x1a);
            this.textRefNo.TabIndex = 0x63;
            this.textRefNo.Text = "PANMNAKTJ0002420A";
            this.textRefNo.TextAlign = HorizontalAlignment.Right;
            this.textRefNo.KeyPress += new KeyPressEventHandler(this.textRefNo_KeyPress);
            this.textRefNo.Leave += new EventHandler(this.textRefNo_Leave);
            this.textRef_Date.BackColor = Color.FromArgb(0xe0, 0xe0, 0xe0);
            this.textRef_Date.Location = new Point(0x323, 0x22);
            this.textRef_Date.Name = "textRef_Date";
            this.textRef_Date.ReadOnly = true;
            this.textRef_Date.Size = new Size(0x66, 20);
            this.textRef_Date.TabIndex = 20;
            this.textRef_Date.Text = "08/08/2013";
            this.label35.AutoSize = true;
            this.label35.Location = new Point(0x2eb, 0x25);
            this.label35.Name = "label35";
            this.label35.Size = new Size(50, 13);
            this.label35.TabIndex = 0x15;
            this.label35.Text = "Ref Date";
            this.comboTransType.Enabled = false;
            this.comboTransType.FormattingEnabled = true;
            this.comboTransType.Location = new Point(0x233, 50);
            this.comboTransType.Name = "comboTransType";
            this.comboTransType.Size = new Size(0x41, 0x15);
            this.comboTransType.TabIndex = 10;
            this.comboTransType.SelectedIndexChanged += new EventHandler(this.comTransType_SelectedIndexChanged);
            this.comboTransType.KeyPress += new KeyPressEventHandler(this.comTransType_KeyPress);
            this.comboTransType.Leave += new EventHandler(this.comTransType_Leave);
            this.buttonSave.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonSave.Location = new Point(0x310, 0x6c);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x79, 30);
            this.buttonSave.TabIndex = 10;
            this.buttonSave.Text = "&Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.buttonSavePrint.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonSavePrint.Location = new Point(0x310, 0x90);
            this.buttonSavePrint.Name = "buttonSavePrint";
            this.buttonSavePrint.Size = new Size(0x79, 30);
            this.buttonSavePrint.TabIndex = 11;
            this.buttonSavePrint.Text = "Save && &Print";
            this.buttonSavePrint.UseVisualStyleBackColor = true;
            this.buttonSavePrint.Click += new EventHandler(this.buttonSavePrint_Click);
            this.buttonCancel.Location = new Point(820, 180);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x55, 30);
            this.buttonCancel.TabIndex = 7;
            this.buttonCancel.Text = "&Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.buttonReset.Location = new Point(0x286, 0x63);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new Size(0x79, 30);
            this.buttonReset.TabIndex = 12;
            this.buttonReset.Text = "Reset &Indicator";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Visible = false;
            this.buttonReset.Click += new EventHandler(this.buttonReset_Click);
            this.buttonReadIndicator.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonReadIndicator.Location = new Point(0x310, 0xd6);
            this.buttonReadIndicator.Name = "buttonReadIndicator";
            this.buttonReadIndicator.Size = new Size(0x79, 0x37);
            this.buttonReadIndicator.TabIndex = 9;
            this.buttonReadIndicator.Text = "&Read Indicator";
            this.buttonReadIndicator.UseVisualStyleBackColor = true;
            this.buttonReadIndicator.Click += new EventHandler(this.button5_Click);
            this.buttonTruck.Location = new Point(0xe0, 1);
            this.buttonTruck.Margin = new Padding(0);
            this.buttonTruck.Name = "buttonTruck";
            this.buttonTruck.Size = new Size(0x17, 0x17);
            this.buttonTruck.TabIndex = 1;
            this.buttonTruck.Text = "...";
            this.buttonTruck.UseVisualStyleBackColor = true;
            this.buttonTruck.Click += new EventHandler(this.button9_Click);
            this.textTruck.CharacterCasing = CharacterCasing.Upper;
            this.textTruck.Location = new Point(0x61, 3);
            this.textTruck.MaxLength = 20;
            this.textTruck.Name = "textTruck";
            this.textTruck.Size = new Size(0x7b, 20);
            this.textTruck.TabIndex = 0;
            this.textTruck.KeyPress += new KeyPressEventHandler(this.textTruck_KeyPress);
            this.textTruck.Leave += new EventHandler(this.textTruck_Leave);
            this.textDriverID.CharacterCasing = CharacterCasing.Upper;
            this.textDriverID.Location = new Point(0x61, 0x1d);
            this.textDriverID.MaxLength = 50;
            this.textDriverID.Name = "textDriverID";
            this.textDriverID.Size = new Size(0x7b, 20);
            this.textDriverID.TabIndex = 4;
            this.textDriverID.Leave += new EventHandler(this.textDriverID_Leave);
            this.buttonDriver.Location = new Point(0xe0, 0x1b);
            this.buttonDriver.Margin = new Padding(0);
            this.buttonDriver.Name = "buttonDriver";
            this.buttonDriver.Size = new Size(0x17, 0x17);
            this.buttonDriver.TabIndex = 5;
            this.buttonDriver.Text = "...";
            this.buttonDriver.UseVisualStyleBackColor = true;
            this.buttonDriver.Click += new EventHandler(this.button10_Click);
            this.buttonTranspt.Location = new Point(0xe0, 0x69);
            this.buttonTranspt.Margin = new Padding(0);
            this.buttonTranspt.Name = "buttonTranspt";
            this.buttonTranspt.Size = new Size(0x17, 0x17);
            this.buttonTranspt.TabIndex = 14;
            this.buttonTranspt.Text = "...";
            this.buttonTranspt.UseVisualStyleBackColor = true;
            this.buttonTranspt.Click += new EventHandler(this.button11_Click);
            this.textTransporter.CharacterCasing = CharacterCasing.Upper;
            this.textTransporter.Location = new Point(0x61, 0x6b);
            this.textTransporter.MaxLength = 20;
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.Size = new Size(0x7b, 20);
            this.textTransporter.TabIndex = 13;
            this.textTransporter.TextChanged += new EventHandler(this.textTransporter_TextChanged);
            this.buttonTanker.Location = new Point(0x25d, 0x1b);
            this.buttonTanker.Margin = new Padding(0);
            this.buttonTanker.Name = "buttonTanker";
            this.buttonTanker.Size = new Size(0x17, 0x17);
            this.buttonTanker.TabIndex = 30;
            this.buttonTanker.Text = "...";
            this.buttonTanker.UseVisualStyleBackColor = true;
            this.buttonTanker.Click += new EventHandler(this.button12_Click);
            this.textTanker.CharacterCasing = CharacterCasing.Upper;
            this.textTanker.Location = new Point(0x1d1, 0x1d);
            this.textTanker.Name = "textTanker";
            this.textTanker.Size = new Size(0x89, 20);
            this.textTanker.TabIndex = 7;
            this.textTanker.KeyPress += new KeyPressEventHandler(this.textTanker_KeyPress);
            this.textTanker.Leave += new EventHandler(this.textTanker_Leave);
            this.labelComm.Cursor = Cursors.Arrow;
            this.labelComm.Location = new Point(5, 0x39);
            this.labelComm.Name = "labelComm";
            this.labelComm.Size = new Size(0x55, 15);
            this.labelComm.TabIndex = 0x12;
            this.labelComm.Text = "Commodity";
            this.labelComm.TextAlign = ContentAlignment.MiddleRight;
            this.labelCommName.AutoSize = true;
            this.labelCommName.Cursor = Cursors.Arrow;
            this.labelCommName.Location = new Point(0xfe, 0x3a);
            this.labelCommName.MaximumSize = new Size(350, 0);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x5c, 13);
            this.labelCommName.TabIndex = 0x17;
            this.labelCommName.Text = "Commodity Name ";
            this.textCommodity.BackColor = SystemColors.Window;
            this.textCommodity.CharacterCasing = CharacterCasing.Upper;
            this.textCommodity.Location = new Point(0x61, 0x37);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0x7b, 20);
            this.textCommodity.TabIndex = 8;
            this.textCommodity.KeyPress += new KeyPressEventHandler(this.textCommodity_KeyPress);
            this.buttonComm.Location = new Point(0xe0, 0x35);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 9;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.button13_Click);
            this.label33.AutoSize = true;
            this.label33.Cursor = Cursors.Arrow;
            this.label33.Location = new Point(0x30f, 0x56);
            this.label33.Name = "label33";
            this.label33.Size = new Size(0x55, 13);
            this.label33.TabIndex = 0x12;
            this.label33.Text = "Commodity Type";
            this.label33.Visible = false;
            this.textCommType.CharacterCasing = CharacterCasing.Upper;
            this.textCommType.Location = new Point(0x36a, 0x53);
            this.textCommType.Name = "textCommType";
            this.textCommType.ReadOnly = true;
            this.textCommType.Size = new Size(0x15, 20);
            this.textCommType.TabIndex = 0x2e;
            this.textCommType.Visible = false;
            this.textVariance.Location = new Point(810, 0x16a);
            this.textVariance.MaxLength = 15;
            this.textVariance.Name = "textVariance";
            this.textVariance.ReadOnly = true;
            this.textVariance.Size = new Size(0x54, 20);
            this.textVariance.TabIndex = 13;
            this.textVariance.Text = "0";
            this.textVariance.TextAlign = HorizontalAlignment.Right;
            this.label45.AutoSize = true;
            this.label45.Location = new Point(0x30f, 0x16d);
            this.label45.Name = "label45";
            this.label45.Size = new Size(0x15, 13);
            this.label45.TabIndex = 0x19;
            this.label45.Text = "+/-";
            this.textTrailerNo.CharacterCasing = CharacterCasing.Upper;
            this.textTrailerNo.Location = new Point(0x1d1, 5);
            this.textTrailerNo.MaxLength = 20;
            this.textTrailerNo.Name = "textTrailerNo";
            this.textTrailerNo.Size = new Size(0x89, 20);
            this.textTrailerNo.TabIndex = 3;
            this.label46.AutoSize = true;
            this.label46.Location = new Point(0x196, 6);
            this.label46.Name = "label46";
            this.label46.Size = new Size(0x38, 13);
            this.label46.TabIndex = 0x19;
            this.label46.Text = "Trailer No.";
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Size = new Size(0x38d, 0x288);
            this.shapeContainer1.TabIndex = 5;
            this.shapeContainer1.TabStop = false;
            this.kotakOS.Location = new Point(0x225, 0xf6);
            this.kotakOS.Name = "kotakOS";
            this.kotakOS.Size = new Size(0xb0, 0x18);
            this.kotakOS.Visible = false;
            this.lblOSDO.AutoSize = true;
            this.lblOSDO.Cursor = Cursors.Arrow;
            this.lblOSDO.Location = new Point(0x2fe, 0x184);
            this.lblOSDO.Name = "lblOSDO";
            this.lblOSDO.Size = new Size(0x83, 13);
            this.lblOSDO.TabIndex = 0x2c;
            this.lblOSDO.Text = "O/S DO : 100,888,999 Kg";
            this.lblOSDO.Visible = false;
            this.textDriverName.CharacterCasing = CharacterCasing.Upper;
            this.textDriverName.Location = new Point(0x100, 0x1d);
            this.textDriverName.MaxLength = 50;
            this.textDriverName.Name = "textDriverName";
            this.textDriverName.Size = new Size(0x91, 20);
            this.textDriverName.TabIndex = 2;
            this.textDriverName.Leave += new EventHandler(this.textDriverName_Leave);
            this.labelRelation.Location = new Point(5, 0x53);
            this.labelRelation.Name = "labelRelation";
            this.labelRelation.Size = new Size(0x55, 15);
            this.labelRelation.TabIndex = 20;
            this.labelRelation.Text = "Vendor ";
            this.labelRelation.TextAlign = ContentAlignment.MiddleRight;
            this.textCust.CharacterCasing = CharacterCasing.Upper;
            this.textCust.Location = new Point(0x61, 0x51);
            this.textCust.MaxLength = 50;
            this.textCust.Name = "textCust";
            this.textCust.Size = new Size(0x7b, 20);
            this.textCust.TabIndex = 11;
            this.textCust.Leave += new EventHandler(this.textCust_Leave);
            this.buttonCust.Location = new Point(0xe0, 0x4f);
            this.buttonCust.Margin = new Padding(0);
            this.buttonCust.Name = "buttonCust";
            this.buttonCust.Size = new Size(0x17, 0x17);
            this.buttonCust.TabIndex = 12;
            this.buttonCust.Text = "...";
            this.buttonCust.UseVisualStyleBackColor = true;
            this.buttonCust.Click += new EventHandler(this.buttonCust_Click);
            this.labelCustName.AutoSize = true;
            this.labelCustName.Location = new Point(0xfe, 0x54);
            this.labelCustName.Name = "labelCustName";
            this.labelCustName.Size = new Size(0x52, 13);
            this.labelCustName.TabIndex = 0x1c;
            this.labelCustName.Text = "Customer Name";
            this.checkEstate.AutoSize = true;
            this.checkEstate.Location = new Point(0x198, 0xa8);
            this.checkEstate.Name = "checkEstate";
            this.checkEstate.Size = new Size(0x6d, 0x11);
            this.checkEstate.TabIndex = 12;
            this.checkEstate.Text = "Estate is Different";
            this.checkEstate.UseVisualStyleBackColor = true;
            this.panelMainInfo.Controls.Add(this.buttonScanCard);
            this.panelMainInfo.Controls.Add(this.label1);
            this.panelMainInfo.Controls.Add(this.labTankerNo);
            this.panelMainInfo.Controls.Add(this.label3);
            this.panelMainInfo.Controls.Add(this.textTruck2);
            this.panelMainInfo.Controls.Add(this.labelCustName);
            this.panelMainInfo.Controls.Add(this.buttonCust);
            this.panelMainInfo.Controls.Add(this.labelTankerMax);
            this.panelMainInfo.Controls.Add(this.buttonTranspt);
            this.panelMainInfo.Controls.Add(this.textTransporter);
            this.panelMainInfo.Controls.Add(this.textCust);
            this.panelMainInfo.Controls.Add(this.labelRelation);
            this.panelMainInfo.Controls.Add(this.comboTransType);
            this.panelMainInfo.Controls.Add(this.textDriverName);
            this.panelMainInfo.Controls.Add(this.labelComm);
            this.panelMainInfo.Controls.Add(this.textTrailerNo);
            this.panelMainInfo.Controls.Add(this.labelCommName);
            this.panelMainInfo.Controls.Add(this.label46);
            this.panelMainInfo.Controls.Add(this.textCommodity);
            this.panelMainInfo.Controls.Add(this.buttonComm);
            this.panelMainInfo.Controls.Add(this.buttonTruck);
            this.panelMainInfo.Controls.Add(this.textTruck);
            this.panelMainInfo.Controls.Add(this.buttonTanker);
            this.panelMainInfo.Controls.Add(this.textDriverID);
            this.panelMainInfo.Controls.Add(this.textTanker);
            this.panelMainInfo.Controls.Add(this.buttonDriver);
            this.panelMainInfo.Controls.Add(this.label4);
            this.panelMainInfo.Controls.Add(this.labelTransporterName);
            this.panelMainInfo.Controls.Add(this.labelDriverName);
            this.panelMainInfo.Location = new Point(3, 3);
            this.panelMainInfo.Name = "panelMainInfo";
            this.panelMainInfo.Size = new Size(640, 0x87);
            this.panelMainInfo.TabIndex = 0;
            this.buttonScanCard.Location = new Point(510, 0x59);
            this.buttonScanCard.Name = "buttonScanCard";
            this.buttonScanCard.Size = new Size(0x7f, 0x2a);
            this.buttonScanCard.TabIndex = 0x1f;
            this.buttonScanCard.Text = "SCAN CARD";
            this.buttonScanCard.UseVisualStyleBackColor = true;
            this.buttonScanCard.Click += new EventHandler(this.buttonScanCard_Click);
            this.buttonTarraHistory.Location = new Point(0x1ba, 0x8b);
            this.buttonTarraHistory.Name = "buttonTarraHistory";
            this.buttonTarraHistory.Size = new Size(0x4b, 0x17);
            this.buttonTarraHistory.TabIndex = 15;
            this.buttonTarraHistory.Text = "&Tarre History";
            this.buttonTarraHistory.UseVisualStyleBackColor = true;
            this.buttonTarraHistory.Click += new EventHandler(this.buttonTarraHistory_Click);
            this.label21.AutoSize = true;
            this.label21.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label21.Location = new Point(0x287, 8);
            this.label21.Name = "label21";
            this.label21.Size = new Size(60, 0x10);
            this.label21.TabIndex = 0x2f;
            this.label21.Text = "Ref No.";
            this.process1.StartInfo.Domain = "";
            this.process1.StartInfo.LoadUserProfile = false;
            this.process1.StartInfo.Password = null;
            this.process1.StartInfo.StandardErrorEncoding = null;
            this.process1.StartInfo.StandardOutputEncoding = null;
            this.process1.StartInfo.UserName = "";
            this.process1.SynchronizingObject = this;
            this.txtAddInfo.Location = new Point(0x63, 0xfd);
            this.txtAddInfo.MaxLength = 100;
            this.txtAddInfo.Name = "txtAddInfo";
            this.txtAddInfo.Size = new Size(0xff, 20);
            this.txtAddInfo.TabIndex = 6;
            this.label54.AutoSize = true;
            this.label54.Location = new Point(0x17, 0x100);
            this.label54.Name = "label54";
            this.label54.Size = new Size(0x4a, 13);
            this.label54.TabIndex = 0x65;
            this.label54.Text = "Additional Info";
            this.shapeContainer4.Location = new Point(0, 0);
            this.shapeContainer4.Margin = new Padding(0);
            this.shapeContainer4.Name = "shapeContainer4";
            Shape[] shapeArray3 = new Shape[] { this.kotakOS };
            this.shapeContainer4.Shapes.AddRange(shapeArray3);
            this.shapeContainer4.Size = new Size(0x38d, 0x288);
            this.shapeContainer4.TabIndex = 5;
            this.shapeContainer4.TabStop = false;
            this.label59.AutoSize = true;
            this.label59.Location = new Point(0x16a, 0x100);
            this.label59.Name = "label59";
            this.label59.Size = new Size(0x2b, 13);
            this.label59.TabIndex = 0x66;
            this.label59.Text = "PL3 No";
            this.textPL3.CharacterCasing = CharacterCasing.Upper;
            this.textPL3.Location = new Point(0x198, 0xfd);
            this.textPL3.MaxLength = 30;
            this.textPL3.Name = "textPL3";
            this.textPL3.Size = new Size(0x6d, 20);
            this.textPL3.TabIndex = 0x67;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x38d, 0x288);
            base.ControlBox = false;
            base.Controls.Add(this.textPL3);
            base.Controls.Add(this.buttonTarraHistory);
            base.Controls.Add(this.label59);
            base.Controls.Add(this.label54);
            base.Controls.Add(this.txtAddInfo);
            base.Controls.Add(this.textReport_Date);
            base.Controls.Add(this.label37);
            base.Controls.Add(this.label21);
            base.Controls.Add(this.textRefNo);
            base.Controls.Add(this.panelMainInfo);
            base.Controls.Add(this.checkEstate);
            base.Controls.Add(this.textRef_Date);
            base.Controls.Add(this.label35);
            base.Controls.Add(this.lblOSDO);
            base.Controls.Add(this.textVariance);
            base.Controls.Add(this.label45);
            base.Controls.Add(this.textCommType);
            base.Controls.Add(this.label33);
            base.Controls.Add(this.buttonReadIndicator);
            base.Controls.Add(this.buttonReset);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSavePrint);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.tabControl1);
            base.Controls.Add(this.textSEAL);
            base.Controls.Add(this.label19);
            base.Controls.Add(this.textNet);
            base.Controls.Add(this.label18);
            base.Controls.Add(this.textDeducTotal);
            base.Controls.Add(this.label17);
            base.Controls.Add(this.groupFactoryWeight);
            base.Controls.Add(this.groupOtherParty);
            base.Controls.Add(this.textRemarkReport);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.textRemarkTicket);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.textUnloading);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.textDN);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.shapeContainer1);
            base.Name = "FormTransactionMsia";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Transaction Entry";
            base.Load += new EventHandler(this.FormTransaction_Load);
            base.Shown += new EventHandler(this.FormTransaction_Shown);
            base.KeyPress += new KeyPressEventHandler(this.FormTransaction_KeyPress);
            this.groupOtherParty.ResumeLayout(false);
            this.groupOtherParty.PerformLayout();
            this.groupFactoryWeight.ResumeLayout(false);
            this.groupFactoryWeight.PerformLayout();
            this.panel4X.ResumeLayout(false);
            this.panel4X.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPageDO.ResumeLayout(false);
            ((ISupportInitialize) this.dgvDO).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel_return.ResumeLayout(false);
            this.panel_return.PerformLayout();
            this.tabPageInfo.ResumeLayout(false);
            this.tabPageInfo.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPageDeduc.ResumeLayout(false);
            this.tabPageDeduc.PerformLayout();
            this.panelDeducTBS.ResumeLayout(false);
            this.panelDeducTBS.PerformLayout();
            this.groupBoxTotalBunchFFB.ResumeLayout(false);
            this.groupBoxTotalBunchFFB.PerformLayout();
            ((ISupportInitialize) this.dgvDeduc).EndInit();
            this.tabPageDivision.ResumeLayout(false);
            ((ISupportInitialize) this.dgvDivBlock).EndInit();
            this.panel3.ResumeLayout(false);
            this.tabPageQC.ResumeLayout(false);
            this.tabPageQC.PerformLayout();
            ((ISupportInitialize) this.dgvQC_All).EndInit();
            ((ISupportInitialize) this.dgvQC).EndInit();
            this.tabPageCont.ResumeLayout(false);
            ((ISupportInitialize) this.dgvCont).EndInit();
            this.panel5.ResumeLayout(false);
            this.tabPagePorla.ResumeLayout(false);
            this.tabPagePorla.PerformLayout();
            ((ISupportInitialize) this.dgvDeducPorla).EndInit();
            this.tabPageCopra.ResumeLayout(false);
            this.tabPageCopra.PerformLayout();
            this.tabPageDL.ResumeLayout(false);
            this.tabPageDL.PerformLayout();
            ((ISupportInitialize) this.dgvListDO).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((ISupportInitialize) this.dgvBatch).EndInit();
            this.panelMainInfo.ResumeLayout(false);
            this.panelMainInfo.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void InitTable()
        {
            string str = ((this.pMode != "1ST") || (!this.tambahRecord || (this.WX != ""))) ? this.textRefNo.Text.Trim() : "~SZ~";
            if (!(this.tambahRecord && ((this.pMode == "1ST") || (this.pMode == "MANUAL"))))
            {
                if (((this.tblTrans.DR["report_date"] == null) || (this.tblTrans.DR["report_date"].ToString() == "")) || (this.pMode == "SPLIT"))
                {
                    this.tblTransDeduc.OpenTable("wb_TransactionD", "Select * from wb_TransactionD where Ref like '" + str + "%' and right(ref,1) <> 'T'", WBData.conn);
                    this.tblTransDeducPorla.OpenTable("wb_TransactionPorla", "Select * from wb_TransactionPorla where Ref like '" + str + "%' and right(ref,1) <> 'T'", WBData.conn);
                    this.tblTransCopra.OpenTable("wb_TransCopra", "Select * from wb_TransCopra where Ref like '" + str + "%' and right(ref,1) <> 'T'", WBData.conn);
                    this.tblTransDO.OpenTable("wb_transDO", "Select * from wb_transDO where " + WBData.CompanyLocation(" And Ref like '" + str + "%' and right(ref,1) <> 'T' ORDER BY uniq"), WBData.conn);
                    this.tblTransQC.OpenTable("wb_TransQC", "Select * from wb_TransQC where " + WBData.CompanyLocation(" And Ref like '" + str + "%' and right(ref,1) <> 'T'"), WBData.conn);
                    this.tblTransDiv.OpenTable("wb_transDivision", "Select * from wb_transDivision where " + WBData.CompanyLocation(" And Ref like '" + str + "%' and right(ref,1) <> 'T'"), WBData.conn);
                    this.tblTransContainer.OpenTable("wb_transContainer", "Select * from wb_transContainer where " + WBData.CompanyLocation(" And Ref like '" + str + "%' and right(ref,1) <> 'T'"), WBData.conn);
                    this.tblDOContainer.OpenTable("wb_transDo_container", "select * from wb_transDO_Container where Ref like  '" + str + "%' and right(ref,1) <> 'T'", WBData.conn);
                    this.tblTransBatch.OpenTable("wb_transBatch", "SELECT * FROM wb_transBatch WHERE Ref like '" + str + "%' and right(ref,1) <> 'T'", WBData.conn);
                    this.tblTrans__.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref = '" + this.tblTrans.DT.Rows[0]["linked"].ToString() + "' "), WBData.conn);
                }
                else
                {
                    this.tblTransDeduc.OpenTable("wb_TransactionD", "Select * from wb_TransactionD where Ref='" + str + "'", WBData.conn);
                    this.tblTransDeducPorla.OpenTable("wb_TransactionPorla", "Select * from wb_TransactionPorla where Ref='" + str + "'", WBData.conn);
                    this.tblTransCopra.OpenTable("wb_TransCopra", "Select * from wb_TransCopra where Ref='" + str + "'", WBData.conn);
                    this.tblTransDO.OpenTable("wb_transDO", "Select * from wb_transDO where " + WBData.CompanyLocation(" And Ref='" + str + "' ORDER BY uniq"), WBData.conn);
                    this.tblTransQC.OpenTable("wb_TransQC", "Select * from wb_TransQC where " + WBData.CompanyLocation(" And Ref='" + str + "'"), WBData.conn);
                    this.tblTransDiv.OpenTable("wb_transDivision", "Select * from wb_transDivision where " + WBData.CompanyLocation(" And Ref='" + str + "'"), WBData.conn);
                    this.tblTransContainer.OpenTable("wb_transContainer", "Select * from wb_transContainer where " + WBData.CompanyLocation(" And Ref='" + str + "'"), WBData.conn);
                    this.tblDOContainer.OpenTable("wb_transDo_container", "select * from wb_transDO_Container where Ref = '" + str + "'", WBData.conn);
                    string[] textArray2 = new string[] { "SELECT * FROM wb_transBatch WHERE ( Ref like '", str, "' Or Ref like '", str, "-%')" };
                    this.tblTransBatch.OpenTable("wb_transBatch", string.Concat(textArray2), WBData.conn);
                    this.tblTrans__.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref = '" + this.tblTrans.DT.Rows[0]["linked"].ToString() + "' "), WBData.conn);
                }
            }
            else
            {
                if (!(WBSetting.activeTCS && (this.pMode == "1ST")))
                {
                    this.tblTransDO.OpenTable("wb_transDO", "Select * from wb_transDO where " + WBData.CompanyLocation(" And Ref='" + str + "' ORDER BY uniq"), WBData.conn);
                    this.tblTransQC.OpenTable("wb_TransQC", "Select * from wb_TransQC where " + WBData.CompanyLocation(" And Ref='" + str + "'"), WBData.conn);
                    this.tblTransContainer.OpenTable("wb_TransContainer", "Select * from wb_TransContainer where " + WBData.CompanyLocation(" And Ref='" + str + "'"), WBData.conn);
                    this.tblDOContainer.OpenTable("wb_Transdo_Container", "Select * from wb_Transdo_Container where " + WBData.CompanyLocation(" And Ref='" + str + "'"), WBData.conn);
                }
                else if (this.WXGatepass != "1")
                {
                    this.tblTransDO.OpenTable("wb_transDO", "Select * from wb_transDO where " + WBData.CompanyLocation(" And gatepass_number='" + this.gatepass_no + "' ORDER BY uniq"), WBData.conn);
                    this.tblTransQC.OpenTable("wb_TransQC", "Select * from wb_TransQC where " + WBData.CompanyLocation(" And gatepass_number='" + this.gatepass_no + "'"), WBData.conn);
                    this.tblTransContainer.OpenTable("wb_TransContainer", "Select * from wb_TransContainer where " + WBData.CompanyLocation(" And gatepass_number='" + this.gatepass_no + "'"), WBData.conn);
                    this.tblDOContainer.OpenTable("wb_Transdo_Container", "Select * from wb_Transdo_Container where " + WBData.CompanyLocation(" And gatepass_number='" + this.gatepass_no + "'"), WBData.conn);
                }
                else
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_gatepass", "SELECT TOP 1 * FROM wb_transaction WHERE gatepass_number = '" + this.gatepass_no + "' AND (split = 'Y' OR split = '' OR split IS NULL) AND (deleted IS NULL OR deleted = 'N' OR deleted = '') ORDER BY uniq DESC", WBData.conn);
                    string str2 = table.DT.Rows[0]["ref"].ToString();
                    this.tblTransDO.OpenTable("wb_transDO", "Select * from wb_transDO where " + WBData.CompanyLocation(" And ref like '" + str2 + "%' ORDER BY uniq"), WBData.conn);
                    this.tblTransQC.OpenTable("wb_TransQC", "Select * from wb_TransQC where 1 = 2", WBData.conn);
                    this.tblTransContainer.OpenTable("wb_TransContainer", "Select * from wb_TransContainer where 1 = 2", WBData.conn);
                    this.tblDOContainer.OpenTable("wb_Transdo_Container", "Select * from wb_Transdo_Container where 1 = 2", WBData.conn);
                    table.Dispose();
                }
                this.tblTransDeduc.OpenTable("wb_TransactionD", "Select * from wb_TransactionD where Ref='" + str + "'", WBData.conn);
                this.tblTransDeducPorla.OpenTable("wb_TransactionPorla", "Select * from wb_TransactionPorla where Ref='" + str + "'", WBData.conn);
                this.tblTransCopra.OpenTable("wb_TransCopra", "Select * from wb_TransCopra where Ref='" + str + "'", WBData.conn);
                this.tblTransDiv.OpenTable("wb_transDivision", "Select * from wb_transDivision where " + WBData.CompanyLocation(" And Ref='" + str + "'"), WBData.conn);
                string[] textArray1 = new string[] { "SELECT * FROM wb_transBatch WHERE ( Ref like '", str, "' Or Ref like '", str, "-%')" };
                this.tblTransBatch.OpenTable("wb_transBatch", string.Concat(textArray1), WBData.conn);
            }
            this.tblTruck.OpenTable("wb_truck", "Select * from wb_truck", WBData.conn);
            this.tblCommD.OpenTable("wb_commodity_detail", "Select * from wb_commodity_detail", WBData.conn);
            this.tblDriver.OpenTable("wb_driver", "Select * from wb_driver WHERE " + WBData.CompanyLocation(" and (Deleted IS NULL OR Deleted <> 'Y') "), WBData.conn);
            this.tblTransporter.OpenTable("wb_transporter", "Select * from wb_transporter", WBData.conn);
            this.tblEstate.OpenTable("wb_estate", "Select * from wb_estate", WBData.conn);
            this.tblStorage.OpenTable("wb_storage", "Select * from wb_storage", WBData.conn);
            this.tblGrading.OpenTable("wb_grading", "Select * from wb_grading", WBData.conn);
            this.tblQC.OpenTable("wb_yield", "Select * from wb_yield", WBData.conn);
            this.tblTanker.OpenTable("wb_tanker", "Select * from wb_tanker", WBData.conn);
            this.tblTransType.OpenTable("wb_transaction_type", "Select * from wb_transaction_type", WBData.conn);
            Program.AutoComp(this.tblTruck, "Truck_Number", this.textTruck);
            Program.AutoComp(this.tblTruck, "Truck_Number", this.textTruck2);
            Program.AutoComp(this.tblDriver, "License_No", this.textDriverID);
            Program.AutoComp(this.tblDriver, "Name", this.textDriverName);
            Program.AutoComp(this.tblTransporter, "Transporter_Code", this.textTransporter);
            Program.AutoComp(this.tblTanker, "Tanker_no", this.textTanker);
        }

        private void loadDatagrid()
        {
            this.dgvDivBlock.ColumnCount = this.tblTransDiv.DT.Columns.Count;
            int num2 = 0;
            while (true)
            {
                if (num2 >= this.tblTransDiv.DT.Columns.Count)
                {
                    this.dgvDivBlock.Columns["Coy"].Visible = false;
                    this.dgvDivBlock.Columns["Location_Code"].Visible = false;
                    this.dgvDivBlock.Columns["SAP_Code"].Visible = false;
                    this.dgvDivBlock.Columns["Uniq"].Visible = false;
                    this.dgvDivBlock.Columns["UnitName"].Visible = false;
                    this.dgvDivBlock.Columns["Estate_Code"].HeaderText = "Estate Code";
                    this.dgvDivBlock.Columns["Estate_Name"].HeaderText = "Estate Name";
                    this.dgvDivBlock.Columns["Division_Code"].HeaderText = "Division Code";
                    this.dgvDivBlock.Columns["Division_Name"].HeaderText = "Division Name";
                    this.dgvDivBlock.Columns["Block_Code"].HeaderText = "Block Code";
                    this.dgvDivBlock.Columns["Estate_Name"].HeaderText = "Estate Name";
                    this.dgvDivBlock.Columns["UnitName"].HeaderText = "Unit Name";
                    this.dgvDivBlock.Columns["Bunch"].HeaderText = "Qty of Unit Name";
                    this.dgvDivBlock.Columns["Bunch"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDivBlock.Columns["Weight"].HeaderText = "Weight (Kg)";
                    this.dgvDivBlock.Columns["Weight"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgvDivBlock = this.tblTransDiv.ToDGV(this.dgvDivBlock);
                    this.dgvCont.ColumnCount = this.tblTransContainer.DT.Columns.Count;
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= this.tblTransContainer.DT.Columns.Count)
                        {
                            int num4 = 0;
                            while (true)
                            {
                                if (num4 >= this.dgvCont.Columns.Count)
                                {
                                    this.dgvCont.Columns["Container"].Visible = true;
                                    this.dgvCont.Columns["Container"].HeaderText = "Container No.";
                                    this.dgvCont.Columns["Seal"].Visible = true;
                                    this.dgvCont.Columns["Seal"].HeaderText = "Seal No.";
                                    this.dgvCont = this.tblTransContainer.ToDGV(this.dgvCont);
                                    this.dgvQC.ColumnCount = this.tblTransQC.DT.Columns.Count;
                                    this.dgvQC_All.ColumnCount = this.tblTransQC.DT.Columns.Count;
                                    int num5 = 0;
                                    while (true)
                                    {
                                        if (num5 >= this.tblTransQC.DT.Columns.Count)
                                        {
                                            int num6 = 0;
                                            while (true)
                                            {
                                                if (num6 >= this.dgvQC.Columns.Count)
                                                {
                                                    this.dgvQC.Columns["QCode"].Visible = true;
                                                    this.dgvQC.Columns["QCode"].HeaderText = "Q.C. Code";
                                                    this.dgvQC.Columns["QCode"].ReadOnly = true;
                                                    this.dgvQC.Columns["QCode"].DefaultCellStyle.BackColor = Color.LightGray;
                                                    this.dgvQC.Columns["QCode"].DisplayIndex = 0;
                                                    this.dgvQC.Columns["QName"].Visible = true;
                                                    this.dgvQC.Columns["QName"].HeaderText = "Quality Control Name";
                                                    this.dgvQC.Columns["QName"].ReadOnly = true;
                                                    this.dgvQC.Columns["QName"].DefaultCellStyle.BackColor = Color.LightGray;
                                                    this.dgvQC.Columns["QName"].DisplayIndex = 1;
                                                    this.dgvQC.Columns["SAP_Value"].Visible = true;
                                                    this.dgvQC.Columns["SAP_Value"].HeaderText = "Contract Specification";
                                                    this.dgvQC.Columns["SAP_Value"].ReadOnly = true;
                                                    this.dgvQC.Columns["SAP_Value"].DefaultCellStyle.BackColor = Color.LightGray;
                                                    this.dgvQC.Columns["SAP_Value"].DisplayIndex = 2;
                                                    this.dgvQC.Columns["Estate"].Visible = true;
                                                    this.dgvQC.Columns["Estate"].HeaderText = "Other Party";
                                                    this.dgvQC.Columns["Estate"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                    this.dgvQC.Columns["Estate"].DefaultCellStyle.Format = "N3";
                                                    this.dgvQC.Columns["Estate"].DisplayIndex = 3;
                                                    this.dgvQC.Columns["Factory"].Visible = true;
                                                    this.dgvQC.Columns["Factory"].HeaderText = "Factory";
                                                    if (this.spMode == "EDIT_OPW")
                                                    {
                                                        this.dgvQC.Columns["Factory"].ReadOnly = true;
                                                        this.dgvQC.Columns["Factory"].DefaultCellStyle.BackColor = Color.LightGray;
                                                    }
                                                    this.dgvQC.Columns["Factory"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                    this.dgvQC.Columns["Factory"].DefaultCellStyle.Format = "N3";
                                                    this.dgvQC.Columns["Factory"].DisplayIndex = 4;
                                                    this.dgvQC_All = this.tblTransQC.ToDGV(this.dgvQC_All);
                                                    this.dgvQC = this.tblTransQC.ToDGV(this.dgvQC);
                                                    if (this.dgvQC.Rows.Count > 0)
                                                    {
                                                        WBTable table = new WBTable();
                                                        foreach (DataGridViewRow row in (IEnumerable) this.dgvQC.Rows)
                                                        {
                                                            string[] textArray1 = new string[9];
                                                            textArray1[0] = "SELECT * FROM wb_contract_detail a, wb_yield b WHERE a.SAP_code = b.SAP_code AND b.Coy = '";
                                                            textArray1[1] = WBData.sCoyCode;
                                                            textArray1[2] = "' AND b.Location_Code = '";
                                                            textArray1[3] = WBData.sLocCode;
                                                            textArray1[4] = "' AND a.Do_No = '";
                                                            textArray1[5] = row.Cells["DO_NO"].Value.ToString();
                                                            textArray1[6] = "' AND b.Yield_Code = '";
                                                            textArray1[7] = row.Cells["QCode"].Value.ToString();
                                                            textArray1[8] = "' ";
                                                            string sqltext = string.Concat(textArray1);
                                                            table.OpenTable("wb_contract_detail", sqltext, WBData.conn);
                                                            if (table.DT.Rows.Count <= 0)
                                                            {
                                                                row.Cells["SAP_Value"].Value = "0";
                                                                continue;
                                                            }
                                                            if (row.Cells["SAP_Value"].Value.ToString() != table.DT.Rows[0]["SAP_Value"].ToString())
                                                            {
                                                                row.Cells["SAP_Value"].Value = table.DT.Rows[0]["SAP_Value"].ToString();
                                                            }
                                                        }
                                                        table.Dispose();
                                                    }
                                                    this.dgvDO.ColumnCount = this.tblTransDO.DT.Columns.Count + 1;
                                                    this.dgvDO.ColumnCount++;
                                                    int num = 0;
                                                    while (true)
                                                    {
                                                        if (num >= this.tblTransDO.DT.Columns.Count)
                                                        {
                                                            this.dgvDO.Columns[num].Name = "DeliNo";
                                                            this.dgvDO.Columns[num + 1].Name = "OSDO";
                                                            foreach (DataGridViewColumn column2 in this.dgvDO.Columns)
                                                            {
                                                                column2.Visible = false;
                                                            }
                                                            this.dgvDO.Columns["Do_No"].Visible = true;
                                                            this.dgvDO.Columns["Contract"].Visible = true;
                                                            this.dgvDO.Columns["Comm_Code"].Visible = true;
                                                            this.dgvDO.Columns["Transaction_Code"].Visible = true;
                                                            this.dgvDO.Columns["Transporter_Code"].Visible = true;
                                                            this.dgvDO.Columns["Relation_Code"].Visible = true;
                                                            this.dgvDO.Columns["Relation_Name"].Visible = true;
                                                            this.dgvDO.Columns["Netto"].Visible = true;
                                                            this.dgvDO.Columns["Estate_qty"].Visible = true;
                                                            this.dgvDO.Columns["Bruto"].Visible = true;
                                                            this.dgvDO.Columns["Tarra"].Visible = true;
                                                            if (WBSetting.locType == "1")
                                                            {
                                                                this.dgvDO.Columns["DeliNo"].Visible = true;
                                                            }
                                                            this.dgvDO.Columns["PI_No"].Visible = true;
                                                            this.dgvDO.Columns["OSDO"].Visible = true;
                                                            this.dgvDO.Columns["do_sap"].Visible = true;
                                                            this.dgvDO.Columns["do_sap_item"].Visible = true;
                                                            this.dgvDO.Columns["internal_number"].Visible = true;
                                                            this.dgvDO.Columns["internal_number_item"].Visible = true;
                                                            this.dgvDO.Columns["loading_qty"].Visible = true;
                                                            this.dgvDO.Columns["loading_qty"].HeaderText = "Load Qty";
                                                            this.dgvDO.Columns["so_item_detail"].Visible = true;
                                                            this.dgvDO.Columns["so_item_detail"].HeaderText = "SO Item";
                                                            this.dgvDO.Columns["Do_No"].HeaderText = "DO No.";
                                                            this.dgvDO.Columns["PI_No"].HeaderText = "PI/SI No.";
                                                            this.dgvDO.Columns["Comm_Code"].HeaderText = "Commodity";
                                                            this.dgvDO.Columns["Transaction_Code"].HeaderText = "Tx";
                                                            this.dgvDO.Columns["Transporter_Code"].HeaderText = "Transporter Code";
                                                            this.dgvDO.Columns["Relation_Code"].HeaderText = "R.Code";
                                                            this.dgvDO.Columns["Relation_Name"].HeaderText = "Relation Name";
                                                            this.dgvDO.Columns["Relation_Name"].Width = 300;
                                                            this.dgvDO.Columns["Relation_Code"].HeaderText = "R.Code";
                                                            this.dgvDO.Columns["do_sap"].HeaderText = "DO SAP";
                                                            this.dgvDO.Columns["do_sap_item"].HeaderText = "Item DO SAP";
                                                            this.dgvDO.Columns["internal_number"].HeaderText = "Internal No.";
                                                            this.dgvDO.Columns["internal_number_item"].HeaderText = "Item Internal No.";
                                                            this.dgvDO.Columns["Netto"].HeaderText = "Factory Net";
                                                            this.dgvDO.Columns["Netto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                            this.dgvDO.Columns["Netto"].DefaultCellStyle.Format = "N0";
                                                            this.dgvDO.Columns["Estate_qty"].HeaderText = "Other Party Net";
                                                            this.dgvDO.Columns["Estate_qty"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                            this.dgvDO.Columns["Estate_qty"].DefaultCellStyle.Format = "N0";
                                                            this.dgvDO.Columns["Bruto"].HeaderText = "Factory Bruto";
                                                            this.dgvDO.Columns["Bruto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                            this.dgvDO.Columns["Bruto"].DefaultCellStyle.Format = "N0";
                                                            this.dgvDO.Columns["Tarra"].HeaderText = "Factory Tarra";
                                                            this.dgvDO.Columns["Tarra"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                            this.dgvDO.Columns["Tarra"].DefaultCellStyle.Format = "N0";
                                                            this.dgvDO.Columns["ConvNett"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                            this.dgvDO.Columns["ConvNett"].DefaultCellStyle.Format = "N0";
                                                            this.dgvDO.Columns["DeliNo"].HeaderText = "Delivery No";
                                                            this.dgvDO.Columns["DeliNo"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                            this.dgvDO.Columns["DeliNo"].DefaultCellStyle.Format = "N0";
                                                            this.dgvDO.Columns["OSDO"].HeaderText = "O/S DO";
                                                            this.dgvDO.Columns["Contract"].DisplayIndex = this.dgvDO.Columns["Contract"].Index + 2;
                                                            this.dgvDO.Columns["OSDO"].DisplayIndex = this.dgvDO.Columns["Do_No"].Index + 2;
                                                            this.dgvDO.Columns["OSDO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                            this.dgvDO.Columns["OSDO"].DefaultCellStyle.Format = "N0";
                                                            this.dgvDO = this.tblTransDO.ToDGV(this.dgvDO);
                                                            if (this.dgvDO.Rows.Count > 0)
                                                            {
                                                                WBTable table2 = new WBTable();
                                                                foreach (DataGridViewRow row2 in (IEnumerable) this.dgvDO.Rows)
                                                                {
                                                                    row2.Cells["OSDO"].Value = 0;
                                                                    table2.OpenTable("wb_tmpDO", "Select * from wb_contract where " + WBData.CompanyLocation(" and do_no = '" + row2.Cells["do_no"].Value.ToString() + "'"), WBData.conn);
                                                                    if (table2.DT.Rows.Count > 0)
                                                                    {
                                                                        table2.DR = table2.DT.Rows[0];
                                                                        row2.Cells["OSDO"].Value = Math.Floor(this.countQtyLeft(row2.Cells["do_no"].Value.ToString(), table2.DR, "N"));
                                                                    }
                                                                    if (this.spMode == "COPY")
                                                                    {
                                                                        row2.Cells["loading_qty"].Value = "0";
                                                                    }
                                                                }
                                                                table2.Dispose();
                                                            }
                                                            DataGridViewColumn dataGridViewColumn = new DataGridViewTextBoxColumn {
                                                                HeaderText = "Do No",
                                                                Name = "Do_No"
                                                            };
                                                            this.dgvListDO.Columns.Add(dataGridViewColumn);
                                                            dataGridViewColumn = new DataGridViewTextBoxColumn {
                                                                HeaderText = "transaction_code",
                                                                Name = "transaction_code",
                                                                Visible = false
                                                            };
                                                            this.dgvListDO.Columns.Add(dataGridViewColumn);
                                                            foreach (DataGridViewColumn column3 in this.dgvDO.Columns)
                                                            {
                                                                column3.SortMode = DataGridViewColumnSortMode.NotSortable;
                                                            }
                                                            foreach (DataGridViewColumn column4 in this.dgvQC.Columns)
                                                            {
                                                                column4.SortMode = DataGridViewColumnSortMode.NotSortable;
                                                            }
                                                            this.dgvDOCont.ColumnCount = this.tblDOContainer.DT.Columns.Count;
                                                            int num8 = 0;
                                                            while (true)
                                                            {
                                                                if (num8 >= this.tblDOContainer.DT.Columns.Count)
                                                                {
                                                                    this.dgvDOCont.Rows.Clear();
                                                                    this.dgvDOCont.AllowUserToAddRows = false;
                                                                    this.dgvDOCont = this.tblDOContainer.ToDGV(this.dgvDOCont);
                                                                    if (this.dgvDO.Rows.Count > 0)
                                                                    {
                                                                        if (this.use_gunny == "Y")
                                                                        {
                                                                            this.label41.Hide();
                                                                            this.textRendCPO.Hide();
                                                                            this.label32.Hide();
                                                                            this.textFruitsType.Hide();
                                                                            this.labelFruitsTypeName.Hide();
                                                                            this.label47.Hide();
                                                                            this.labelReject.Hide();
                                                                            this.textTBSReject.Hide();
                                                                            this.textBoxKG.Hide();
                                                                            this.label23.Hide();
                                                                            this.label49.Hide();
                                                                            this.textReason.Hide();
                                                                            this.dgvDeduc.Hide();
                                                                            this.rectangleShape1.Hide();
                                                                            this.buttonAddDeduc.Hide();
                                                                            this.buttonEditDeduc.Hide();
                                                                            this.buttonDeleteDeduc.Hide();
                                                                            this.labelGrade.Hide();
                                                                            this.textGrade.Hide();
                                                                            this.textAvg.Enabled = false;
                                                                        }
                                                                        else
                                                                        {
                                                                            this.label41.Show();
                                                                            this.textRendCPO.Show();
                                                                            this.label32.Show();
                                                                            this.textFruitsType.Show();
                                                                            this.labelFruitsTypeName.Show();
                                                                            this.label47.Show();
                                                                            this.labelReject.Show();
                                                                            this.textTBSReject.Show();
                                                                            this.textBoxKG.Show();
                                                                            this.label23.Show();
                                                                            this.label49.Show();
                                                                            this.textReason.Show();
                                                                            this.dgvDeduc.Show();
                                                                            this.rectangleShape1.Show();
                                                                            this.buttonAddDeduc.Show();
                                                                            this.buttonEditDeduc.Show();
                                                                            this.buttonDeleteDeduc.Show();
                                                                            this.labelGrade.Show();
                                                                            this.textGrade.Show();
                                                                            this.textAvg.Enabled = true;
                                                                        }
                                                                    }
                                                                    this.dgvBatch.ColumnCount = this.tblTransBatch.DT.Columns.Count;
                                                                    int num9 = 0;
                                                                    while (true)
                                                                    {
                                                                        if (num9 >= this.dgvBatch.ColumnCount)
                                                                        {
                                                                            this.dgvBatch.Columns["Uniq"].Visible = false;
                                                                            this.dgvBatch.Columns["Coy"].Visible = false;
                                                                            this.dgvBatch.Columns["Location_Code"].Visible = false;
                                                                            this.dgvBatch.Columns["SO_No"].Visible = false;
                                                                            this.dgvBatch.Columns["Do_No"].Visible = false;
                                                                            this.dgvBatch.Columns["Adopted"].Visible = false;
                                                                            this.dgvBatch.Columns["Approved"].Visible = false;
                                                                            this.dgvBatch.Columns["Num_of_Gunny"].HeaderText = "Num of Gunny";
                                                                            this.dgvBatch = this.tblTransBatch.ToDGV(this.dgvBatch);
                                                                            foreach (DataGridViewColumn column5 in this.dgvBatch.Columns)
                                                                            {
                                                                                column5.SortMode = DataGridViewColumnSortMode.NotSortable;
                                                                            }
                                                                            if (this.dgvBatch.Rows.Count > 0)
                                                                            {
                                                                                int num10 = 0;
                                                                                this.textDL.Text = this.dgvBatch.Rows[0].Cells["Do_No"].Value.ToString();
                                                                                this.textSTO.Text = this.dgvBatch.Rows[0].Cells["STO_No"].Value.ToString();
                                                                                this.SJAdopted = this.dgvBatch.Rows[0].Cells["Adopted"].Value.ToString() == "Y";
                                                                                foreach (DataGridViewRow row3 in (IEnumerable) this.dgvBatch.Rows)
                                                                                {
                                                                                    num10 += Convert.ToInt32(row3.Cells["Netto"].Value);
                                                                                }
                                                                                this.textNettoBatch.Text = num10.ToString();
                                                                                this.textNettoBatch_Leave(this, this.e);
                                                                            }
                                                                            if (!WBUser.CheckTrustee("DL_ADOPT", "V"))
                                                                            {
                                                                                this.textDL.ReadOnly = true;
                                                                                this.textSTO.ReadOnly = true;
                                                                                this.dgvBatch.ReadOnly = true;
                                                                                this.button18.Enabled = false;
                                                                                this.buttonAdopt.Enabled = false;
                                                                                this.button19.Enabled = false;
                                                                                this.button20.Enabled = false;
                                                                            }
                                                                            this.dgvDeduc.ColumnCount = this.tblTransDeduc.DT.Columns.Count;
                                                                            int num11 = 0;
                                                                            while (true)
                                                                            {
                                                                                if (num11 >= this.tblTransDeduc.DT.Columns.Count)
                                                                                {
                                                                                    this.dgvDeduc.Columns["Coy"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Location_Code"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Ref"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Type"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Formula"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Variable"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Uniq"].Visible = false;
                                                                                    this.dgvDeduc.Columns["comm_code"].Visible = false;
                                                                                    this.dgvDeduc.Columns["Deduc_by"].HeaderText = "D";
                                                                                    this.dgvDeduc.Columns["Deduc_by"].Width = 20;
                                                                                    this.dgvDeduc.Columns["KgDeduc"].HeaderText = "Deduction (Kg)";
                                                                                    this.dgvDeduc.Columns["KgDeduc"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                                                    this.dgvDeduc.Columns["KgDeduc"].DefaultCellStyle.Format = "N0";
                                                                                    this.dgvDeduc.Columns["PDeduc"].HeaderText = " % ";
                                                                                    this.dgvDeduc.Columns["PDeduc"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                                                    this.dgvDeduc.Columns["PDeduc"].DefaultCellStyle.Format = "N2";
                                                                                    this.dgvDeduc.Columns["QtyBunch"].HeaderText = " Qty of Unit";
                                                                                    this.dgvDeduc.Columns["QtyBunch"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                                                    this.dgvDeduc.Columns["QtyBunch"].DefaultCellStyle.Format = "N0";
                                                                                    this.dgvDeduc = this.tblTransDeduc.ToDGV(this.dgvDeduc);
                                                                                    if (WBSetting.activeTCS && ((this.pMode == "1ST") && (this.CommType == "F")))
                                                                                    {
                                                                                        this._InitBlankGrading(this.dgvDO.Rows[0].Cells["Comm_Code"].Value.ToString());
                                                                                    }
                                                                                    this.dgvDeducPorla.ColumnCount = this.tblTransDeducPorla.DT.Columns.Count;
                                                                                    int num12 = 0;
                                                                                    while (true)
                                                                                    {
                                                                                        if (num12 >= this.tblTransDeducPorla.DT.Columns.Count)
                                                                                        {
                                                                                            this.dgvDeducPorla.Columns["Coy"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Location_Code"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Ref"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Type"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Formula"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Variable"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Uniq"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["comm_code"].Visible = false;
                                                                                            this.dgvDeducPorla.Columns["Deduc_by"].HeaderText = "D";
                                                                                            this.dgvDeducPorla.Columns["Deduc_by"].Width = 20;
                                                                                            this.dgvDeducPorla.Columns["KgDeduc"].HeaderText = "Deduction (Kg)";
                                                                                            this.dgvDeducPorla.Columns["KgDeduc"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                                                            this.dgvDeducPorla.Columns["KgDeduc"].DefaultCellStyle.Format = "N0";
                                                                                            this.dgvDeducPorla.Columns["PDeduc"].HeaderText = " % ";
                                                                                            this.dgvDeducPorla.Columns["PDeduc"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                                                            this.dgvDeducPorla.Columns["PDeduc"].DefaultCellStyle.Format = "N2";
                                                                                            this.dgvDeducPorla.Columns["QtyBunch"].HeaderText = " Qty of Unit";
                                                                                            this.dgvDeducPorla.Columns["QtyBunch"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                                                                                            this.dgvDeducPorla.Columns["QtyBunch"].DefaultCellStyle.Format = "N0";
                                                                                            this.dgvDeducPorla = this.tblTransDeducPorla.ToDGV(this.dgvDeducPorla);
                                                                                            return;
                                                                                        }
                                                                                        this.dgvDeducPorla.Columns[num12].Name = this.tblTransDeducPorla.DT.Columns[num12].ColumnName;
                                                                                        num12++;
                                                                                    }
                                                                                }
                                                                                this.dgvDeduc.Columns[num11].Name = this.tblTransDeduc.DT.Columns[num11].ColumnName;
                                                                                num11++;
                                                                            }
                                                                        }
                                                                        this.dgvBatch.Columns[num9].Name = this.tblTransBatch.DT.Columns[num9].ColumnName;
                                                                        num9++;
                                                                    }
                                                                }
                                                                this.dgvDOCont.Columns[num8].Name = this.tblDOContainer.DT.Columns[num8].ColumnName;
                                                                num8++;
                                                            }
                                                        }
                                                        this.dgvDO.Columns[num].Name = this.tblTransDO.DT.Columns[num].ColumnName;
                                                        num++;
                                                    }
                                                }
                                                this.dgvQC.Columns[num6].Visible = false;
                                                num6++;
                                            }
                                        }
                                        this.dgvQC.Columns[num5].Name = this.tblTransQC.DT.Columns[num5].ColumnName;
                                        this.dgvQC_All.Columns[num5].Name = this.tblTransQC.DT.Columns[num5].ColumnName;
                                        num5++;
                                    }
                                }
                                this.dgvCont.Columns[num4].Visible = false;
                                num4++;
                            }
                        }
                        this.dgvCont.Columns[num3].Name = this.tblTransContainer.DT.Columns[num3].ColumnName;
                        num3++;
                    }
                }
                this.dgvDivBlock.Columns[num2].Name = this.tblTransDiv.DT.Columns[num2].ColumnName;
                num2++;
            }
        }

        private bool overGrossLossTolerance(double grossEstate, double grossFactory)
        {
            bool flag = false;
            double num = grossFactory - grossEstate;
            if (Math.Abs(num) > WBSetting.toleranceForOverLossControlbyGross)
            {
                object[] objArray1 = new object[] { "OVER GROSS LOSS TOLERANCE!\n\nDifference between other party gross and factory gross is ", num, " KG\nLoss tolerance is ", WBSetting.toleranceForOverLossControlbyGross, " KG\n\nApproval is needed to continue saving transaction. Do you want to continue?" };
                if (MessageBox.Show(string.Concat(objArray1), "NOTIFICATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                {
                    flag = true;
                }
                else
                {
                    this.hasil = this.tblComm.tokenOrApp(this.gatepass_no, "", "OVER_GROSS_LOSS_TOLERANCE", "TOKEN_OVER_GROSS_LOSS_TOLERANCE", "OVER_GROSS_LOSS_TOLERANCE", "E", "", null);
                    if (this.hasil[0] != "completed")
                    {
                        flag = true;
                    }
                    else
                    {
                        this.approve = "Y";
                        this.approveBy1 = this.hasil[1];
                        this.ApproveReason = this.hasil[2];
                        this.approve_type = "OVER_GROSS_LOSS_TOLERANCE";
                        flag = false;
                    }
                }
            }
            return flag;
        }

        private bool overNetLossTolerance(double loss, double netEstate)
        {
            bool flag = false;
            double num = Program.RoundbyTen((WBSetting.toleranceForOverLossControlbyNet / 100.0) * netEstate);
            if (Math.Abs(loss) > num)
            {
                object[] objArray1 = new object[] { "OVER NET LOSS TOLERANCE!\n\nNet loss is ", loss, " KG\nTolerance (", WBSetting.toleranceForOverLossControlbyNet, "%) is ", num, " KG.\n\nApproval is needed to continue saving transaction. Do you want to continue?" };
                if (MessageBox.Show(string.Concat(objArray1), "NOTIFICATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                {
                    flag = true;
                }
                else
                {
                    this.hasil = this.tblComm.tokenOrApp(this.tblTrans.DT.Rows[0]["Ref"].ToString().Trim(), "", "OVER_NET_LOSS_TOLERANCE", "TOKEN_OVER_NET_LOSS_TOLERANCE", "OVER_NET_LOSS_TOLERANCE", "E", "", null);
                    if (this.hasil[0] != "completed")
                    {
                        flag = true;
                    }
                    else
                    {
                        this.approve = "Y";
                        this.approveBy1 = this.hasil[1];
                        this.ApproveReason = this.hasil[2];
                        this.approve_type = "OVER_NET_LOSS_TOLERANCE";
                        flag = false;
                    }
                }
            }
            return flag;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void print(string refno, ReportDocument cryRpt)
        {
            string[] paramName = new string[2];
            string[] paramValue = new string[] { refno, WBUser.UserName };
            paramName[0] = "ref";
            paramName[1] = "user";
            cryRpt.Refresh();
            cryRpt = Program.setParam2(this.ticket2Rpt, paramName, paramValue);
            this.fRpt.setReport(cryRpt);
            if (WBSetting.sCheckDirect == "Y")
            {
                cryRpt.PrintToPrinter(1, false, 0, 0);
                this.fRpt.crystalReportViewer1.ShowPrintButton = false;
                this.fRpt.ShowDialog();
            }
            else
            {
                this.fRpt.setDoPrint(false);
                this.fRpt.ShowDialog();
                if (this.fRpt.doPrint)
                {
                    this.updatePrinted();
                    cryRpt.PrintToPrinter(1, true, 0, 0);
                }
            }
        }

        private void print(string refno, string Do_No, ReportDocument cryRpt)
        {
            string[] paramName = new string[4];
            string[] paramValue = new string[] { refno, Do_No, WBUser.UserName, Program.getSplitGross(refno) };
            paramName[0] = "ref";
            paramName[1] = "Do_No";
            paramName[2] = "user";
            paramName[3] = "Total_Split_DO";
            cryRpt.Refresh();
            cryRpt = Program.setParam2(cryRpt, paramName, paramValue);
            this.fRpt.setReport(cryRpt);
            if (WBSetting.sCheckDirect == "Y")
            {
                cryRpt.PrintToPrinter(1, false, 0, 0);
                this.fRpt.crystalReportViewer1.ShowPrintButton = false;
                this.fRpt.ShowDialog();
            }
            else
            {
                this.fRpt.setDoPrint(false);
                this.fRpt.ShowDialog();
                if (this.fRpt.doPrint)
                {
                    this.updatePrinted();
                    cryRpt.PrintToPrinter(1, true, 0, 0);
                }
            }
        }

        private void proportionateReceivingbyOPW()
        {
            if (((this.text2nd.Text != "") && ((this.text2nd.Text != "0") && (this.text1st.Text != ""))) && (this.text1st.Text != "0"))
            {
                bool flag2 = true;
                int num = 1;
                while (true)
                {
                    if (num < this.tblTransDO.DT.Rows.Count)
                    {
                        DataRow row = this.tblTransDO.DT.Rows[num];
                        if ((row["Netto"].ToString() == "") || (row["Netto"].ToString() == "0"))
                        {
                            num++;
                            continue;
                        }
                        flag2 = false;
                    }
                    if ((this.transType == "I") & flag2)
                    {
                        int num2 = 0;
                        int num3 = this.dgvDO.RowCount - 1;
                        while (true)
                        {
                            if (num3 <= 0)
                            {
                                if (this.WX == "2X")
                                {
                                    if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text2nd.Text))
                                    {
                                        this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text1st.Text) - num2;
                                        this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text) - num2;
                                    }
                                    else
                                    {
                                        this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text2nd.Text) - num2;
                                        this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text) - num2;
                                    }
                                }
                                else if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text4th.Text))
                                {
                                    this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text1st.Text) - num2;
                                    this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text) - num2;
                                }
                                else
                                {
                                    this.dgvDO.Rows[0].Cells["Bruto"].Value = Convert.ToDouble(this.text4th.Text) - num2;
                                    this.dgvDO.Rows[0].Cells["Netto"].Value = Convert.ToDouble(this.textNet.Text) - num2;
                                }
                                break;
                            }
                            double num4 = 0.0;
                            if ((this.textNetEstate.Text != "0") && (this.textNetEstate.Text != ""))
                            {
                                num4 = (Program.StrToDouble(this.dgvDO.Rows[num3].Cells["Estate_qty"].Value.ToString(), 0) / Program.StrToDouble(this.textNetEstate.Text, 0)) * Program.StrToDouble(this.textNet.Text, 0);
                            }
                            this.dgvDO.Rows[num3].Cells["Bruto"].Value = Convert.ToInt32(num4).ToString();
                            this.dgvDO.Rows[num3].Cells["Netto"].Value = this.dgvDO.Rows[num3].Cells["Bruto"].Value;
                            num2 += Convert.ToInt32(Program.StrToDouble(this.dgvDO.Rows[num3].Cells["Bruto"].Value.ToString(), 0));
                            num3--;
                        }
                    }
                    break;
                }
            }
        }

        private void radioButtonEntryAVG_CheckedChanged(object sender, EventArgs e)
        {
            this.checkEntryAVGorTotalBunch();
        }

        private void radioButtonEntryTotalBunch_CheckedChanged(object sender, EventArgs e)
        {
            this.checkEntryAVGorTotalBunch();
        }

        private void radioGHG1_CheckedChanged(object sender, EventArgs e)
        {
            this.textGHG.Enabled = false;
        }

        private void radioGHG2_CheckedChanged(object sender, EventArgs e)
        {
            this.textGHG.Enabled = true;
            this.textGHG.Focus();
        }

        private void recalc_deduc()
        {
            FormTransDeducEntry entry = new FormTransDeducEntry {
                pMode = "EDIT",
                textNET2 = this.textNET2.Text.Trim(),
                textBunchDeduc = this.textBunchDeduc.Text
            };
            double num = 0.0;
            this.ChangeDeduc = true;
            foreach (DataGridViewRow row in (IEnumerable) this.dgvDeduc.Rows)
            {
                Cursor.Current = Cursors.WaitCursor;
                entry.Text = "Edit Deduction Item";
                entry.comboDeducBy.Text = row.Cells["Deduc_by"].Value.ToString();
                entry.textDeducCode.Text = row.Cells["Code"].Value.ToString();
                entry.oldDeducCode = row.Cells["Code"].Value.ToString();
                entry.textDeducName.Text = row.Cells["Name"].Value.ToString();
                entry.textFormula.Text = row.Cells["Formula"].Value.ToString();
                entry.textDeducVar.Text = row.Cells["Variable"].Value.ToString();
                entry.textDeducPercent.Text = row.Cells["PDeduc"].Value.ToString();
                entry.textDeducKG.Text = row.Cells["KgDeduc"].Value.ToString();
                entry.textDeducQtyUnit.Text = row.Cells["QtyBunch"].Value.ToString();
                entry.checkDeducReturn.Checked = row.Cells["Retur"].Value.ToString() == "Y";
                entry.labelKgUnit.Text = "BUNCH";
                entry.dataGridView1 = this.dgvDeduc;
                entry.tblTransD = this.tblTransDeduc;
                entry.CalcDeduc();
                row.Cells["Coy"].Value = WBData.sCoyCode;
                row.Cells["Location_Code"].Value = WBData.sLocCode;
                row.Cells["Ref"].Value = this.textRefNo.Text;
                row.Cells["Type"].Value = this.CommType;
                row.Cells["Deduc_by"].Value = entry.comboDeducBy.Text;
                row.Cells["Code"].Value = entry.textDeducCode.Text;
                row.Cells["Name"].Value = entry.textDeducName.Text;
                row.Cells["Formula"].Value = entry.textFormula.Text;
                row.Cells["Variable"].Value = entry.textDeducVar.Text;
                row.Cells["PDeduc"].Value = Convert.ToDouble(entry.textDeducPercent.Text.Trim());
                row.Cells["KgDeduc"].Value = Convert.ToDouble(entry.textDeducKG.Text.Trim());
                row.Cells["QtyBunch"].Value = Convert.ToDouble(entry.textDeducQtyUnit.Text.Trim());
                row.Cells["Retur"].Value = entry.checkDeducReturn.Checked ? "Y" : " ";
                num += (row.Cells["Retur"].Value.ToString() == "Y") ? 0.0 : Convert.ToDouble(row.Cells["KgDeduc"].Value.ToString());
            }
            this.dgvDeduc.Refresh();
            try
            {
                if (this.txtMS.Text == "")
                {
                    this.txtMS.Text = "0";
                }
            }
            catch
            {
                this.txtMS.Text = "0";
            }
            num += Convert.ToDouble(this.txtMS.Text);
            this.textDeducTotal.Text = $"{num:N0}";
            this.HitNet();
            if (this.dgvDO.Rows.Count == 1)
            {
                if ((this.pMode == "2ND") && !(Convert.ToDouble(this.textNet.Text) == 0.0))
                {
                    if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text2nd.Text))
                    {
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text1st.Text;
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = this.text2nd.Text;
                    }
                    else
                    {
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text2nd.Text;
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = this.text1st.Text;
                    }
                    this.dgvDO.Rows[0].Cells["Netto"].Value = this.textNet.Text;
                    this.dgvDO.Refresh();
                    this.ChangeDO = true;
                }
                else if ((this.pMode == "4TH") && !(Convert.ToDouble(this.textNet.Text) == 0.0))
                {
                    if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text4th.Text))
                    {
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text1st.Text;
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = ((Program.StrToDouble(this.text1st.Text, 0) - Program.StrToDouble(this.text2nd.Text, 0)) - Program.StrToDouble(this.text3rd.Text, 0)) - Program.StrToDouble(this.text4th.Text, 0);
                    }
                    else
                    {
                        this.dgvDO.Rows[0].Cells["Bruto"].Value = this.text4th.Text;
                        this.dgvDO.Rows[0].Cells["Tarra"].Value = ((Program.StrToDouble(this.text4th.Text, 0) - Program.StrToDouble(this.text2nd.Text, 0)) - Program.StrToDouble(this.text3rd.Text, 0)) - Program.StrToDouble(this.text1st.Text, 0);
                    }
                    this.dgvDO.Rows[0].Cells["Netto"].Value = this.textNet.Text;
                    this.dgvDO.Refresh();
                    this.ChangeDO = true;
                }
            }
            Cursor.Current = Cursors.Default;
            entry.Dispose();
        }

        private void recalc_division()
        {
            FormTransDivision division = new FormTransDivision {
                jTandan = Convert.ToInt32(this.textBunchTotal.Text)
            };
            this.ChangeDiv = true;
            foreach (DataGridViewRow row in (IEnumerable) this.dgvDivBlock.Rows)
            {
                division.dgvDiv = this.dgvDivBlock;
                division.refDate = this.textRef_Date.Text;
                division.textEstate.Text = row.Cells["Estate_Code"].Value.ToString();
                division.textEstateName.Text = row.Cells["Estate_Name"].Value.ToString();
                division.textDiv.Text = row.Cells["Division_Code"].Value.ToString();
                division.textDivName.Text = row.Cells["Division_Name"].Value.ToString();
                division.textBlockCode.Text = row.Cells["Block_Code"].Value.ToString();
                division.textBlockName.Text = row.Cells["Block_Name"].Value.ToString();
                division.maskedAVG.Text = this.textAvg.Text;
                division.textBunch.Text = row.Cells["Bunch"].Value.ToString();
                division.textWeight.Text = row.Cells["Weight"].Value.ToString();
                division.textYear.Text = row.Cells["yearPlanting"].Value.ToString();
                division.textWeight.Text = division.calcDivisionWeight(division.maskedAVG.Text, division.textBunch.Text);
                row.Cells["Coy"].Value = WBData.sCoyCode;
                row.Cells["Location_Code"].Value = WBData.sLocCode;
                row.Cells["Ref"].Value = this.textRefNo.Text;
                row.Cells["Estate_Code"].Value = division.textEstate.Text;
                row.Cells["Estate_Name"].Value = division.textEstateName.Text;
                row.Cells["Division_Code"].Value = division.textDiv.Text;
                row.Cells["Division_Name"].Value = division.textDivName.Text;
                row.Cells["Block_Code"].Value = division.textBlockCode.Text;
                row.Cells["Block_Name"].Value = division.textBlockName.Text;
                row.Cells["Average"].Value = division.maskedAVG.Text;
                row.Cells["Bunch"].Value = Convert.ToDouble(division.textBunch.Text);
                row.Cells["Weight"].Value = Convert.ToDouble(division.textWeight.Text);
                row.Cells["YearPlanting"].Value = Convert.ToDouble(division.textYear.Text);
            }
            this.dgvDivBlock.Refresh();
            division.Dispose();
        }

        private DataRow ReplaceDOitem(string[] pArg) => 
            this.tblTransDO.DR;

        private void rows_added(object sender, DataGridViewRowsAddedEventArgs e)
        {
            this.button20.Text = "Merge";
        }

        private void rows_removed(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            this.button20.Text = (this.dgvBatch.Rows.Count != 1) ? "Merge" : "Delete";
        }

        private void saveTransSplit(string pUniq)
        {
            int num = 0x40;
            string str = "";
            string keyField = "";
            WBTable table = new WBTable();
            table.OpenTable("wb_transaction", "Select * From wb_transaction where Uniq=" + pUniq.Trim(), WBData.conn);
            DataRow row = table.DT.Rows[0];
            str = row["Ref"].ToString();
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_transSplit", "Select * From wb_transSplit where " + WBData.CompanyLocation(" and ref = '" + row["Ref"].ToString() + "'"), WBData.conn);
            if (table2.DT.Rows.Count > 0)
            {
                keyField = table2.DT.Rows[0]["uniq"].ToString();
                table2.DT.Rows[0].Delete();
                table2.Save();
                table2.ReOpen();
                string[] textArray1 = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] textArray2 = new string[] { this.logMode, WBUser.UserID, this.logReason };
                Program.updateLogHeader("wb_transSplit", keyField, textArray1, textArray2);
            }
            table2.DR = table2.DT.NewRow();
            foreach (DataColumn column in table2.DT.Columns)
            {
                if (column.ColumnName.ToUpper() != "UNIQ")
                {
                    table2.DR[column.ColumnName] = row[column.ColumnName];
                }
            }
            table2.DT.Rows.Add(table2.DR);
            table2.Save();
            table2.Dispose();
            string sqltext = (((((("SELECT uniq FROM wb_transSplit WHERE " + WBData.CompanyLocation("")) + " AND Ref = '" + row["Ref"].ToString() + "'") + " AND Do_No = '" + row["Do_No"].ToString() + "'") + " AND Gross = '" + row["Gross"].ToString() + "'") + " AND Tare = '" + row["Tare"].ToString() + "'") + " AND Received = '" + row["Received"].ToString() + "'") + " AND Net = '" + row["Net"].ToString() + "'";
            WBTable table3 = new WBTable();
            table3.OpenTable("wb_transSplit", sqltext, WBData.conn);
            keyField = table3.DT.Rows[0]["uniq"].ToString();
            table3.Dispose();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { this.logMode, WBUser.UserID, this.logReason };
            Program.updateLogHeader("wb_transSplit", keyField, logField, logValue);
            int num2 = 0;
            while (true)
            {
                if (num2 >= this.dgvDO.Rows.Count)
                {
                    table.Dispose();
                    return;
                }
                keyField = "";
                if (num2 == 0)
                {
                    if ((((this.WX == "2X") && (this.pMode == "2ND")) || (((this.WX == "4X") && (this.pMode == "4TH")) || (this.pMode == "SPLIT"))) || (((this.pMode == "EDIT") && (this.spMode == "EDIT")) && (this.textReport_Date.Text != "")))
                    {
                        table.DR = table.DT.Rows[num2];
                        table.DR.BeginEdit();
                        table.DR["Split"] = !(((this.text2nd.Text == "") || ((this.text2nd.Text == "0") || (this.WX != "2X"))) ? (((this.text4th.Text != "") && (this.text4th.Text != "0")) && (this.WX == "4X")) : true) ? "N" : "Y";
                        int num3 = 0;
                        int num4 = this.dgvBatch.RowCount - 1;
                        while (true)
                        {
                            if (num4 < 0)
                            {
                                table.DR["TotalGunny"] = num3;
                                if (table.DR["WX"].ToString() == "2X")
                                {
                                    if (Program.StrToDouble(table.DR["_1ST"].ToString(), 0) > Program.StrToDouble(table.DR["_2ND"].ToString(), 0))
                                    {
                                        table.DR["_1ST"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                                    }
                                    else
                                    {
                                        table.DR["_2ND"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                                    }
                                }
                                else if ((table.DR["WX"].ToString() == "4X") && ((this.pMode == "4TH") || (this.pMode == "SPLIT")))
                                {
                                    if (Program.StrToDouble(table.DR["_1ST"].ToString(), 0) > Program.StrToDouble(table.DR["_4TH"].ToString(), 0))
                                    {
                                        table.DR["_1ST"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                                    }
                                    else
                                    {
                                        table.DR["_4TH"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                                    }
                                }
                                table.DR["Gross_estate"] = Program.StrToDouble(table.DR["Tare_Estate"].ToString(), 0) + Program.StrToDouble(this.dgvDO.Rows[num2].Cells["estate_qty"].Value.ToString(), 0);
                                table.DR["net_estate"] = this.dgvDO.Rows[num2].Cells["estate_qty"].Value.ToString();
                                table.DR["Gross"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                                table.DR["Tare"] = this.dgvDO.Rows[num2].Cells["Tarra"].Value.ToString();
                                table.DR["MaterialStuffing"] = Convert.ToInt32(this.txtMS.Text);
                                table.DR["Received"] = Convert.ToString((double) (Convert.ToDouble(this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString()) - Convert.ToDouble(this.dgvDO.Rows[num2].Cells["Tarra"].Value.ToString())));
                                table.DR["Net"] = Program.StrToDouble(table.DR["Received"].ToString(), 0) - (((Program.StrToDouble(this.dgvDO.Rows[num2].Cells["TotalDeducUnit"].Value.ToString(), 0) + this.GetDeduc()) + Program.StrToDouble(this.txtMS.Text, 0)) + Program.StrToDouble(this.textTotalCopra.Text, 0));
                                table.DR["Deduction"] = Program.StrToDouble(table.DR["Received"].ToString(), 0) - Program.StrToDouble(table.DR["Net"].ToString(), 0);
                                this.dgvDO.Rows[num2].Cells["WeightPerUnitName"].Value = ((this.dgvDO.Rows[num2].Cells["WeightPerUnitName"].Value == null) || (this.dgvDO.Rows[num2].Cells["WeightPerUnitName"].Value.ToString() == "")) ? "0" : this.dgvDO.Rows[num2].Cells["WeightPerUnitName"].Value.ToString();
                                this.dgvDO.Rows[num2].Cells["DeducUnitQty"].Value = ((this.dgvDO.Rows[num2].Cells["DeducUnitQty"].Value == null) || (this.dgvDO.Rows[num2].Cells["DeducUnitQty"].Value.ToString() == "")) ? "0" : this.dgvDO.Rows[num2].Cells["DeducUnitQty"].Value.ToString();
                                table.DR["WeightPerUnitName"] = this.dgvDO.Rows[num2].Cells["WeightPerUnitName"].Value.ToString();
                                table.DR["TotalBunch"] = this.dgvDO.Rows[num2].Cells["DeducUnitQty"].Value.ToString();
                                table.DR["UnitName"] = this.dgvDO.Rows[num2].Cells["UnitName"].Value.ToString();
                                table.DR["posted"] = "N";
                                table.DR["checksum"] = table.Checksum(table.DR);
                                table.DR.EndEdit();
                                table.Save();
                                keyField = table.DR["uniq"].ToString();
                                break;
                            }
                            DataGridViewRow row2 = this.dgvBatch.Rows[num4];
                            if (row2.Cells["SO_No"].Value.ToString().Trim() == table.DR["DO_NO"].ToString().Trim())
                            {
                                num3 += Convert.ToInt32(row2.Cells["Num_of_gunny"].Value);
                            }
                            num4--;
                        }
                    }
                }
                else if (((this.text2nd.Text == "") || ((this.text2nd.Text == "0") || (this.WX != "2X"))) ? (((this.text4th.Text != "") && (this.text4th.Text != "0")) && (this.WX == "4X")) : true)
                {
                    table.ReOpen();
                    row = table.DT.Rows[0];
                    table.DR = table.DT.NewRow();
                    table.DR = table.DT.NewRow();
                    int num6 = 0;
                    while (true)
                    {
                        if (num6 >= table.DT.Columns.Count)
                        {
                            table.DR["Split"] = "X";
                            if (table.DR["WX"].ToString() == "2X")
                            {
                                if (Program.StrToDouble(table.DR["_1ST"].ToString(), 0) > Program.StrToDouble(table.DR["_2ND"].ToString(), 0))
                                {
                                    table.DR["_1ST"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                                    table.DR["_2ND"] = "0";
                                }
                                else
                                {
                                    table.DR["_1ST"] = "0";
                                    table.DR["_2ND"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                                }
                            }
                            else if (table.DR["WX"].ToString() == "4X")
                            {
                                table.DR["_2ND"] = "0";
                                table.DR["_3RD"] = "0";
                                if (Program.StrToDouble(table.DR["_1ST"].ToString(), 0) > Program.StrToDouble(table.DR["_4TH"].ToString(), 0))
                                {
                                    table.DR["_1ST"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                                    table.DR["_4TH"] = "0";
                                }
                                else
                                {
                                    table.DR["_1ST"] = "0";
                                    table.DR["_4TH"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                                }
                            }
                            num++;
                            this.tblDO.OpenTable("tmpDO", "select * from wb_contract where " + WBData.CompanyLocation(" and DO_NO = '" + this.dgvDO.Rows[num2].Cells["DO_NO"].Value.ToString() + "'"), WBData.conn);
                            DataRow row3 = this.tblDO.DT.Rows[0];
                            table.DR["Transaction_Code"] = row3["Transaction_Code"].ToString().Trim();
                            table.DR["Delivery_Note"] = (this.dgvDO.Rows[num2].Cells["DeliNo"].Value != null) ? this.dgvDO.Rows[num2].Cells["DeliNo"].Value.ToString() : row["Delivery_Note"].ToString();
                            this.tblComm.OpenTable("tmpComm", "select * from wb_commodity where " + WBData.CompanyLocation(" and comm_Code = '" + row3["Comm_code"].ToString() + "'"), WBData.conn);
                            DataRow row4 = this.tblComm.DT.Rows[0];
                            if ((row4["type"].ToString().Trim() == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                            {
                                string[] textArray5 = new string[] { WBData.sCoyCode.Trim(), "/", row3["comm_code"].ToString().Trim(), "/", this.SetNoSPB(true) };
                                table.DR["Delivery_Note"] = string.Concat(textArray5);
                            }
                            else if ((row4["type"].ToString().Trim() == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                            {
                                string[] textArray6 = new string[] { WBData.sCoyCode.Trim(), "/", row3["comm_code"].ToString().Trim(), "/", this.SetNoSPB(true) };
                                table.DR["Delivery_Note"] = string.Concat(textArray6);
                            }
                            table.DR["Ref"] = str + Convert.ToChar(num).ToString();
                            table.DR["Comm_Code"] = this.dgvDO.Rows[num2].Cells["Comm_Code"].Value.ToString();
                            table.DR["Gross_estate"] = this.dgvDO.Rows[num2].Cells["estate_qty"].Value.ToString();
                            table.DR["DO_No"] = this.dgvDO.Rows[num2].Cells["DO_No"].Value.ToString();
                            table.DR["PI_No"] = this.dgvDO.Rows[num2].Cells["PI_No"].Value.ToString();
                            int num5 = 0;
                            int num7 = this.dgvBatch.RowCount - 1;
                            while (true)
                            {
                                if (num7 < 0)
                                {
                                    table.DR["TotalGunny"] = num5;
                                    if (WBSetting.checkISCC == "Y")
                                    {
                                        if (row3["ISCC"].ToString() != "Y")
                                        {
                                            table.DR["ISCC_Checked"] = "N";
                                            table.DR["ISCC_No"] = "";
                                            table.DR["ISCC_No2"] = "";
                                            table.DR["ISCC_Weight"] = Convert.ToDouble(0);
                                            table.DR["ISCC_GC_Checked"] = "N";
                                        }
                                        else
                                        {
                                            table.DR["ISCC_Checked"] = "Y";
                                            this.setISCC();
                                            table.DR["ISCC_No"] = this.textISCC.Text.Trim();
                                            table.DR["ISCC_No2"] = this.textISCC2.Text;
                                            table.DR["ISCC_Weight"] = Convert.ToDouble(this.textGHG.Text);
                                            table.DR["ISCC_GC_Checked"] = this.radioGHG1.Checked ? "Y" : "N";
                                        }
                                    }
                                    table.DR["net_estate"] = this.dgvDO.Rows[num2].Cells["estate_qty"].Value.ToString();
                                    table.DR["Tare_estate"] = "0";
                                    table.DR["Relation_Code"] = this.dgvDO.Rows[num2].Cells["Relation_Code"].Value.ToString();
                                    table.DR["Gross"] = this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString();
                                    table.DR["Tare"] = this.dgvDO.Rows[num2].Cells["Tarra"].Value.ToString();
                                    table.DR["Printed"] = "0";
                                    table.DR["Received"] = Convert.ToString((double) (Program.StrToDouble(this.dgvDO.Rows[num2].Cells["Bruto"].Value.ToString(), 0) - Program.StrToDouble(this.dgvDO.Rows[num2].Cells["Tarra"].Value.ToString(), 0)));
                                    table.DR["Net"] = this.dgvDO.Rows[num2].Cells["Netto"].Value.ToString();
                                    table.DR["Net"] = Program.StrToDouble(this.dgvDO.Rows[num2].Cells["Netto"].Value.ToString(), 0) - Program.StrToDouble(this.dgvDO.Rows[num2].Cells["TotalDeducUnit"].Value.ToString(), 0);
                                    table.DR["Deduction"] = Program.StrToDouble(table.DR["Received"].ToString(), 0) - Program.StrToDouble(table.DR["Net"].ToString(), 0);
                                    this.dgvDO.Rows[num2].Cells["WeightPerUnitName"].Value = ((this.dgvDO.Rows[num2].Cells["WeightPerUnitName"].Value == null) || (this.dgvDO.Rows[num2].Cells["WeightPerUnitName"].Value.ToString() == "")) ? "0" : this.dgvDO.Rows[num2].Cells["WeightPerUnitName"].Value.ToString();
                                    this.dgvDO.Rows[num2].Cells["DeducUnitQty"].Value = ((this.dgvDO.Rows[num2].Cells["DeducUnitQty"].Value == null) || (this.dgvDO.Rows[num2].Cells["DeducUnitQty"].Value.ToString() == "")) ? "0" : this.dgvDO.Rows[num2].Cells["DeducUnitQty"].Value.ToString();
                                    table.DR["WeightPerUnitName"] = this.dgvDO.Rows[num2].Cells["WeightPerUnitName"].Value.ToString();
                                    table.DR["TotalBunch"] = this.dgvDO.Rows[num2].Cells["DeducUnitQty"].Value.ToString();
                                    table.DR["UnitName"] = this.dgvDO.Rows[num2].Cells["UnitName"].Value.ToString();
                                    table.DR["posted"] = "N";
                                    table.DR["MaterialStuffing"] = "0";
                                    table.DR["checksum"] = table.Checksum(table.DR);
                                    table.DT.Rows.Add(table.DR);
                                    table.Save();
                                    WBTable table4 = new WBTable();
                                    table4.OpenTable("wb_transaction", "SELECT uniq FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Ref = '" + table.DR["Ref"].ToString() + "'"), WBData.conn);
                                    keyField = table4.DT.Rows[0]["uniq"].ToString();
                                    table4.Dispose();
                                    break;
                                }
                                DataGridViewRow row5 = this.dgvBatch.Rows[num7];
                                if (row5.Cells["SO_No"].Value.ToString().Trim() == table.DR["DO_NO"].ToString().Trim())
                                {
                                    num5 += Convert.ToInt32(row5.Cells["Num_of_gunny"].Value);
                                }
                                num7--;
                            }
                            break;
                        }
                        bool flag13 = table.DT.Columns[num6].ColumnName.ToUpper() != "UNIQ";
                        if (flag13 && (row[num6].ToString().Trim() != ""))
                        {
                            table.DR[table.DT.Columns[num6].ColumnName] = row[num6].ToString();
                        }
                        num6++;
                    }
                }
                string[] textArray7 = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] textArray8 = new string[] { this.logMode, WBUser.UserID, this.logReason };
                Program.updateLogHeader("wb_transaction", keyField, textArray7, textArray8);
                num2++;
            }
        }

        private void SetDeducByUnit()
        {
            this.textDeducTotal.Text = $"{this.GetDeducByUnit() + this.GetDeduc():N0}";
            this.HitNet();
        }

        private void setISCC()
        {
            if (!this.checkISCC.Checked)
            {
                this.textISCC.Enabled = false;
                this.radioGHG1.Enabled = false;
                this.radioGHG2.Enabled = false;
                this.textGHG.Text = "0.000";
                this.textGHG.Enabled = false;
            }
            else
            {
                this.textISCC.Text = (this.textCommodity.Text != "6.0110000") ? WBSetting.Field("ISCC_No").ToString().Trim() : (((WBSetting.Field("ISCC_No_Add") != null) && (WBSetting.Field("ISCC_No_Add").ToString() != "")) ? WBSetting.Field("ISCC_No_Add").ToString().Trim() : WBSetting.Field("ISCC_No").ToString().Trim());
                this.radioGHG1.Enabled = true;
                this.radioGHG2.Enabled = true;
                if (WBSetting.Field("ISCC_GC_Checked").ToString() == "Y")
                {
                    this.radioGHG1.Checked = true;
                    this.textGHG.Text = "0";
                }
                else
                {
                    this.textGHG.Text = (this.CommType == "") ? "0.000" : WBSetting.Field("ISCC_Weight_" + this.CommType);
                    this.textGHG.Enabled = true;
                    this.textISCC.Enabled = true;
                }
            }
        }

        private string SetNoISCC(bool pSave)
        {
            string str = "";
            DateTime time = DateTime.Parse(this.textDate1st.Text);
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "Select * From wb_ref where ", WBData.CompanyLocation(""), " and Ref_Code = 'ISCC' and Ref_Year ='", DateTime.Now.Year.ToString(), "' and Ref_Month = '", DateTime.Now.Month.ToString(), "'" };
            table.OpenTable("wb_ref", string.Concat(textArray1), WBData.conn);
            if (table.DT.Rows.Count == 0)
            {
                table.DR = table.DT.NewRow();
                table.DR["Coy"] = WBData.sCoyCode;
                table.DR["Location_code"] = WBData.sLocCode;
                table.DR["Ref_Code"] = "ISCC";
                table.DR["Ref_Year"] = DateTime.Now.Year.ToString();
                table.DR["Ref_Month"] = DateTime.Now.Month.ToString();
                table.DR["Ref_No"] = "0";
                table.DT.Rows.Add(table.DR);
                table.Save();
                table.ReOpen();
            }
            DataRow row = table.DT.Rows[0];
            string str2 = row["Ref_No"].ToString();
            this.nRef = Convert.ToInt32(str2) + 1;
            str = this.nRef.ToString().Trim().PadLeft(4, '0');
            str = row["Ref_Year"].ToString().PadLeft(2, '0') + row["Ref_month"].ToString().PadLeft(2, '0') + "-" + str;
            if (pSave)
            {
                table.ReOpen();
                table.DR = table.DT.Rows[0];
                table.DR.BeginEdit();
                table.DR["Ref_No"] = this.nRef.ToString();
                table.DR.EndEdit();
                table.Save();
            }
            table.Close();
            table.Dispose();
            return str;
        }

        private string SetNoref(bool pSave)
        {
            string str = "";
            int totalWidth = 7;
            DateTime time = DateTime.Parse(this.textDate1st.Text);
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_location", "Select * From wb_location Where " + WBData.CompanyLocation(""), WBData.conn);
            DataRow row = table2.DT.Rows[0];
            if (pSave)
            {
                string keyField = "";
                bool flag2 = true;
                bool flag3 = false;
                string str4 = "";
                while (true)
                {
                    if (!flag2)
                    {
                        break;
                    }
                    table2.OpenTable("wb_location", "Select * From wb_location Where " + WBData.CompanyLocation(""), WBData.conn);
                    row = table2.DT.Rows[0];
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 < 5)
                        {
                            table2.ReOpen();
                            row = table2.DT.Rows[0];
                            keyField = row["uniq"].ToString();
                            if ((row["ref_lock"].ToString().Trim().ToUpper() != "N") && (row["ref_lock"].ToString().Trim() != ""))
                            {
                                str4 = row["ref_lockBy"].ToString().Trim().ToUpper();
                                flag3 = true;
                                num2++;
                                continue;
                            }
                            row.BeginEdit();
                            row["ref_lock"] = "Y";
                            row["ref_lockBy"] = WBSetting.WBCode;
                            row["checksum"] = table2.Checksum(row);
                            row.EndEdit();
                            table2.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "REFLOCK", WBUser.UserID, "Lock reference no when weighing" };
                            Program.updateLogHeader("wb_location", keyField, logField, logValue);
                            table2.ReOpen();
                            row = table2.DT.Rows[0];
                            flag3 = false;
                            flag2 = false;
                        }
                        if (flag3 && (MessageBox.Show(" Save Transaction Data Failed, Reference Table Locked by WBCODE = " + str4 + ".\n Retry Save Data? \n\n ( If Retry Failed for a few times please contact Administrator...) ", "R E T R Y...", MessageBoxButtons.OK, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK))
                        {
                            flag2 = true;
                        }
                        break;
                    }
                }
            }
            string str2 = (row["Ref_No"].ToString().Trim() == "") ? "0" : row["Ref_No"].ToString().Trim();
            if ((WBSetting.Ref6 == "Y") && (WBSetting.date6 != ""))
            {
                try
                {
                    if (Convert.ToDateTime(Convert.ToDateTime(this.textRef_Date.Text).ToShortDateString()) >= Convert.ToDateTime(Convert.ToDateTime(WBSetting.date6).ToShortDateString()))
                    {
                        totalWidth = 6;
                    }
                }
                catch
                {
                    totalWidth = 7;
                }
            }
            while (true)
            {
                this.nRef = Convert.ToInt32(str2) + 1;
                str = this.nRef.ToString().Trim().PadLeft(totalWidth, '0');
                str = WBData.sCoyCode.Trim() + WBData.sLocCode.Trim() + str;
                str2 = this.nRef.ToString().Trim();
                table.OpenTable("wb_transaction", "Select Ref From wb_transaction Where " + WBData.CompanyLocation(" AND Ref='" + str + "'"), WBData.conn);
                if (table.DT.Rows.Count == 0)
                {
                    if (pSave)
                    {
                        string keyField = "";
                        table2.ReOpen();
                        table2.DR = table2.DT.Rows[0];
                        keyField = table2.DR["uniq"].ToString();
                        table2.DR.BeginEdit();
                        table2.DR["Ref_No"] = this.nRef.ToString();
                        table2.DR["Ref_Lock"] = "N";
                        table2.DR["Ref_LockBy"] = "";
                        table2.DR["checksum"] = table2.Checksum(table2.DR);
                        table2.DR.EndEdit();
                        table2.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "REFLOCK", WBUser.UserID, "Unlock reference no when weighing" };
                        Program.updateLogHeader("wb_location", keyField, logField, logValue);
                    }
                    table2.Close();
                    table2.Dispose();
                    return str;
                }
            }
        }

        private string SetNorefManual()
        {
            string str = "";
            int totalWidth = 7;
            DateTime time = DateTime.Parse(this.textDate1st.Text);
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_location", "Select * From wb_location Where " + WBData.CompanyLocation(""), WBData.conn);
            DataRow row = table2.DT.Rows[0];
            string str2 = (Convert.ToDouble((row["StartRef"].ToString().Trim() == "") ? "0" : Program.shoot(row["StartRef"].ToString().Trim(), false)) + Convert.ToDouble(Program.shoot(row["CurrEntry"].ToString().Trim(), false))).ToString();
            if ((WBSetting.Ref6 == "Y") && (WBSetting.date6 != ""))
            {
                try
                {
                    if (Convert.ToDateTime(Convert.ToDateTime(this.textRef_Date.Text).ToShortDateString()) >= Convert.ToDateTime(Convert.ToDateTime(WBSetting.date6).ToShortDateString()))
                    {
                        totalWidth = 6;
                    }
                }
                catch
                {
                    totalWidth = 7;
                }
            }
            while (true)
            {
                this.nRef = Convert.ToInt32(str2) + 1;
                str = this.nRef.ToString().Trim().PadLeft(totalWidth, '0');
                str = WBData.sCoyCode.Trim() + WBData.sLocCode.Trim() + str;
                str2 = this.nRef.ToString().Trim();
                table.OpenTable("wb_transaction", "Select Ref From wb_transaction Where " + WBData.CompanyLocation(" AND Ref='" + str + "'"), WBData.conn);
                if (table.DT.Rows.Count == 0)
                {
                    table2.Close();
                    table2.Dispose();
                    return str;
                }
            }
        }

        private string SetNorefTemporary(bool pSave)
        {
            string str = "";
            int totalWidth = 7;
            DateTime time = DateTime.Parse(this.textDate1st.Text);
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_Ref", "Select * From wb_Ref Where ref_code = 'TEMPORARY_CONTAINER'", WBData.conn);
            DataRow row = table2.DT.Rows[0];
            if (pSave)
            {
                bool flag2 = true;
                bool flag3 = false;
                string str4 = "";
                while (true)
                {
                    if (!flag2)
                    {
                        break;
                    }
                    table2.OpenTable("wb_location", "Select * From wb_ref Where ref_code = 'TEMPORARY_CONTAINER'", WBData.conn);
                    row = table2.DT.Rows[0];
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 < 5)
                        {
                            table2.ReOpen();
                            row = table2.DT.Rows[0];
                            if ((row["locked"].ToString().Trim().ToUpper() != "N") && (row["locked"].ToString().Trim() != ""))
                            {
                                str4 = row["lockedBy"].ToString().Trim().ToUpper();
                                flag3 = true;
                                num2++;
                                continue;
                            }
                            row.BeginEdit();
                            row["locked"] = "Y";
                            row["lockedBy"] = WBSetting.WBCode;
                            row["locked_date"] = DateTime.Now;
                            row.EndEdit();
                            table2.Save();
                            table2.ReOpen();
                            row = table2.DT.Rows[0];
                            flag3 = false;
                            flag2 = false;
                        }
                        if (flag3 && (MessageBox.Show(" Save Transaction Data Failed, Reference Table Locked by WBCODE = " + str4 + ".\n Retry Save Data? \n\n ( If Retry Failed for a few times please contact Administrator...) ", "R E T R Y...", MessageBoxButtons.OK, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK))
                        {
                            flag2 = true;
                        }
                        break;
                    }
                }
            }
            string str2 = (row["Ref_No"].ToString().Trim() == "") ? "0" : row["Ref_No"].ToString().Trim();
            totalWidth = 7;
            while (true)
            {
                this.nRef = Convert.ToInt32(str2) + 1;
                str = this.nRef.ToString().Trim().PadLeft(totalWidth, '0');
                str = "X" + str;
                str2 = this.nRef.ToString().Trim();
                table.OpenTable("wb_transaction", "Select Ref From wb_transaction Where Ref='" + str + "'", WBData.conn);
                if (table.DT.Rows.Count == 0)
                {
                    if (pSave)
                    {
                        table2.ReOpen();
                        table2.DR = table2.DT.Rows[0];
                        table2.DR.BeginEdit();
                        table2.DR["Ref_No"] = this.nRef.ToString();
                        table2.DR["Locked"] = "N";
                        table2.DR["LockedBy"] = "";
                        table2.DR["Locked_Date"] = DBNull.Value;
                        table2.DR.EndEdit();
                        table2.Save();
                    }
                    table2.Close();
                    table2.Dispose();
                    return str;
                }
            }
        }

        private string SetNoSPB(bool pSave)
        {
            string str = "";
            DateTime time = DateTime.Parse(this.textDate1st.Text);
            WBTable table = new WBTable();
            string[] textArray1 = new string[9];
            textArray1[0] = "Select * From wb_ref where ";
            textArray1[1] = WBData.CompanyLocation("");
            textArray1[2] = " and Ref_Code = 'AUTOSPB";
            textArray1[3] = this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim();
            textArray1[4] = "' and Ref_Year ='";
            textArray1[5] = DateTime.Now.Year.ToString();
            textArray1[6] = "' and Ref_Month = '";
            textArray1[7] = DateTime.Now.Month.ToString();
            textArray1[8] = "'";
            table.OpenTable("wb_ref", string.Concat(textArray1), WBData.conn);
            if (table.DT.Rows.Count == 0)
            {
                table.DR = table.DT.NewRow();
                table.DR["Coy"] = WBData.sCoyCode;
                table.DR["Location_code"] = WBData.sLocCode;
                table.DR["Ref_Code"] = "AUTOSPB" + this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim();
                table.DR["Ref_Year"] = DateTime.Now.Year.ToString();
                table.DR["Ref_Month"] = DateTime.Now.Month.ToString();
                table.DR["Ref_No"] = "0";
                table.DT.Rows.Add(table.DR);
                table.Save();
                table.ReOpen();
            }
            string str2 = table.DT.Rows[0]["Ref_No"].ToString();
            this.nRef = Convert.ToInt32(str2) + 1;
            str = this.nRef.ToString().Trim().PadLeft(4, '0');
            if (pSave)
            {
                table.ReOpen();
                table.DR = table.DT.Rows[0];
                table.DR.BeginEdit();
                table.DR["Ref_No"] = this.nRef.ToString();
                table.DR.EndEdit();
                table.Save();
            }
            table.Close();
            table.Dispose();
            return str;
        }

        private void settingTabControl()
        {
            if ((Convert.ToInt16(this.textBunchTotal.Text.Trim()) > 0) && (this.dgvBatch.Rows.Count <= 0))
            {
                this.textGunnyBatchLeft.Text = this.textBunchTotal.Text;
                this.textNettoBatchLeft.Text = this.textNet.Text.Replace(",", "");
            }
            else if (this.dgvBatch.Rows.Count > 0)
            {
                int num = 0;
                int num2 = 0;
                foreach (DataGridViewRow row in (IEnumerable) this.dgvBatch.Rows)
                {
                    num += Convert.ToInt32(row.Cells["Num_of_Gunny"].Value);
                    num2 += Convert.ToInt32(row.Cells["Netto"].Value);
                }
                this.textGunnyBatchLeft.Text = (Convert.ToInt32(this.textBunchTotal.Text) - num);
                this.textNettoBatchLeft.Text = (Convert.ToInt32(this.textNet.Text.Replace(",", "")) - num2);
            }
            if ((((this.pMode != "VIEW") && (this.pMode != "QC")) && (this.pMode != "DL")) && ((this.pMode != "VIEW") && (this.pMode != "QC")))
            {
                this.comboTransType.Enabled = this.dgvDO.Rows.Count <= 0;
                this.combodgvDO.Items.Clear();
                this.combodgvDO.Text = "";
                foreach (DataGridViewRow row2 in (IEnumerable) this.dgvDO.Rows)
                {
                    this.combodgvDO.Items.Add(row2.Cells["DO_No"].Value.ToString());
                    if (this.combodgvDO.Text == "")
                    {
                        this.combodgvDO.Text = row2.Cells["DO_No"].Value.ToString();
                    }
                }
                if (WBSetting.locType == "1")
                {
                    this.dgvDivBlock.Columns["UnitName"].HeaderText = "BUNCH";
                    this.dgvDivBlock.Columns["Bunch"].HeaderText = "Qty of BUNCH";
                    if (WBUser.UserLevel != "3")
                    {
                        if (this.text2nd.Text.Trim() == "0")
                        {
                            this.dgvDeduc.Enabled = false;
                            this.buttonDeleteDeduc.Enabled = false;
                            this.buttonEditDeduc.Enabled = false;
                            this.buttonAddDeduc.Enabled = false;
                            this.textBunchDeduc.Enabled = false;
                            this.textBunchTotal.Enabled = false;
                            this.textAvg.Enabled = false;
                            this.dgvDeducPorla.Enabled = false;
                            this.buttonAddPorla.Enabled = false;
                            this.buttonEditPorla.Enabled = false;
                            this.buttonDeletePorla.Enabled = false;
                        }
                        else
                        {
                            this.dgvDeduc.Enabled = true;
                            this.buttonDeleteDeduc.Enabled = true;
                            this.buttonEditDeduc.Enabled = true;
                            this.buttonAddDeduc.Enabled = true;
                            this.textBunchDeduc.Enabled = true;
                            this.textBunchTotal.Enabled = true;
                            this.textAvg.Enabled = true;
                            this.dgvDeducPorla.Enabled = true;
                            this.buttonAddPorla.Enabled = true;
                            this.buttonEditPorla.Enabled = true;
                            this.buttonDeletePorla.Enabled = true;
                        }
                    }
                    else
                    {
                        bool flag1;
                        if ((((this.pMode == "2ND") || (this.pMode == "1ST")) && (this.text2nd.Text.Trim() == "0")) || (((this.pMode == "EDIT") && ((this.spMode == "QTY") || (this.spMode == "EDIT_OPW"))) && (this.text2nd.Text.Trim() == "0")))
                        {
                            flag1 = true;
                        }
                        else
                        {
                            flag1 = this.WX == "1X";
                        }
                        if (flag1)
                        {
                            this.dgvDeduc.Enabled = false;
                            this.buttonDeleteDeduc.Enabled = false;
                            this.buttonEditDeduc.Enabled = false;
                            this.buttonAddDeduc.Enabled = false;
                            this.textBunchDeduc.Enabled = false;
                            this.textBunchTotal.Enabled = false;
                            this.textAvg.Enabled = false;
                            this.dgvDeducPorla.Enabled = false;
                            this.buttonAddPorla.Enabled = false;
                            this.buttonEditPorla.Enabled = false;
                            this.buttonDeletePorla.Enabled = false;
                            this.radioButtonEntryAVG.Enabled = false;
                            this.radioButtonEntryTotalBunch.Enabled = false;
                        }
                        else
                        {
                            this.dgvDeduc.Enabled = true;
                            this.buttonDeleteDeduc.Enabled = true;
                            this.buttonEditDeduc.Enabled = true;
                            this.buttonAddDeduc.Enabled = true;
                            this.textBunchDeduc.Enabled = true;
                            this.textBunchTotal.Enabled = true;
                            this.textAvg.Enabled = true;
                            this.dgvDeducPorla.Enabled = true;
                            this.buttonAddPorla.Enabled = true;
                            this.buttonEditPorla.Enabled = true;
                            this.buttonDeletePorla.Enabled = true;
                            this.radioButtonEntryAVG.Enabled = true;
                            this.radioButtonEntryTotalBunch.Enabled = true;
                        }
                    }
                    if ((this.textBunchTotal.Text.Trim() != "") && (this.labelFruitsTypeName.Text.Trim() == ""))
                    {
                        this.BJR();
                    }
                }
            }
        }

        private bool Simpan()
        {
            string str2;
            int num2;
            int num3;
            bool flag5;
            int num6;
            DateTime now;
            char ch;
            using (IEnumerator enumerator = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                    bool flag2 = current.Cells["do_sap"].Value != null;
                    if (flag2 && !string.IsNullOrEmpty(current.Cells["do_sap"].Value.ToString()))
                    {
                        WBTable table3 = new WBTable();
                        string[] textArray1 = new string[] { "SELECT Do.Ref as Ref FROM wb_transdo do LEFT JOIN wb_transaction trans ON trans.ref = Do.ref WHERE Do.ref <> '", current.Cells["ref"].Value.ToString().Trim(), "' AND do_sap = '", current.Cells["do_sap"].Value.ToString().Trim(), "' AND do_sap_item = '", current.Cells["do_sap_item"].Value.ToString().Trim(), "' AND Do.DO_BESAR <> 'X' AND ((mark_accident IS NULL OR mark_accident = '') AND (Deleted IS NULL OR Deleted = ''))" };
                        table3.OpenTable("wb_transDo", string.Concat(textArray1), WBData.conn);
                        if (table3.DT.Rows.Count > 0)
                        {
                            MessageBox.Show("DO KECIL SAP has been used in Ref " + table3.DT.Rows[0]["Ref"].ToString() + ".\nPlease check again, or use another DO SAP.\nThank you.", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            return false;
                        }
                    }
                    if ((current.Cells["internal_number"].Value != null) && !string.IsNullOrEmpty(current.Cells["internal_number"].Value.ToString()))
                    {
                        WBTable table4 = new WBTable();
                        string[] textArray2 = new string[11];
                        textArray2[0] = "SELECT * FROM wb_transdo as DO inner join wb_transaction as TS on TS.ref = DO.ref WHERE DO.internal_number = '";
                        textArray2[1] = current.Cells["internal_number"].Value.ToString().Trim();
                        textArray2[2] = "' and DO.internal_number_item = '";
                        textArray2[3] = current.Cells["internal_number_item"].Value.ToString().Trim();
                        textArray2[4] = "'  and do.ref <> '";
                        textArray2[5] = current.Cells["ref"].Value.ToString().Trim();
                        textArray2[6] = "' and (TS.deleted = 'N' or TS.deleted is null) and (TS.Mark_accident = 'N' or TS.Mark_accident is null) and TS.coy = '";
                        textArray2[7] = WBData.sCoyCode;
                        textArray2[8] = "' and TS.location_code = '";
                        textArray2[9] = WBData.sLocCode;
                        textArray2[10] = "'";
                        table4.OpenTable("wb_transdo", string.Concat(textArray2), WBData.conn);
                        if (table4.DT.Rows.Count > 0)
                        {
                            string[] textArray3 = new string[] { "Internal Number [ ", current.Cells["internal_number"].Value.ToString().Trim(), " ] has been used in Ref [ ", table4.DT.Rows[0]["ref"].ToString(), " ] \nPlease use another Internal Number.\nThank you." };
                            MessageBox.Show(string.Concat(textArray3), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return false;
                        }
                    }
                }
            }
            if (WBSetting.activeTCS && (this.pMode == "1ST"))
            {
                int num4 = 0;
                bool flag10 = false;
                using (IEnumerator enumerator2 = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
                {
                    while (true)
                    {
                        if (!enumerator2.MoveNext())
                        {
                            break;
                        }
                        DataGridViewRow current = (DataGridViewRow) enumerator2.Current;
                        this.tblDO.OpenTable("wb_contract", "SELECT * FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + current.Cells["DO_NO"].Value.ToString() + "'"), WBData.conn);
                        this.tblComm.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + current.Cells["Comm_Code"].Value.ToString() + "'"), WBData.conn);
                        if (this.tblDO.DT.Rows.Count > 0)
                        {
                            DataRow row3 = this.tblDO.DT.Rows[0];
                            DataRow row4 = this.tblComm.DT.Rows[0];
                            string[] aField = new string[] { "Do_No", "PI_No" };
                            string[] textArray5 = new string[] { current.Cells["DO_NO"].Value.ToString(), current.Cells["PI_NO"].Value.ToString() };
                            if (ReferenceEquals(this.tblDO.GetData(aField, textArray5), null))
                            {
                                object[] objArray1 = new object[] { "PI No for DO ", num4 + 1, " is not found! Please check DO ", num4 + 1, " before save transaction!" };
                                MessageBox.Show(string.Concat(objArray1), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                flag10 = true;
                            }
                            if ((WBSetting.Field("GM") == "Y") && !flag10)
                            {
                                WBTable table5 = new WBTable();
                                table5.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(" AND ( Token_Code ='NOT_ADOPTSAP' and completed = 'N' and key_1 = '" + current.Cells["DO_NO"].Value.ToString() + "' )"), WBData.conn);
                                if (table5.DT.Rows.Count > 0)
                                {
                                    object[] objArray2 = new object[] { "DO ", num4 + 1, " hasn't been approved to not adopt from SAP! Please check DO ", num4 + 1, " before save transaction!" };
                                    MessageBox.Show(string.Concat(objArray2), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    flag10 = true;
                                }
                                table5.Dispose();
                            }
                            if ((!this.chk_return.Checked && !flag10) && (((Program.getFieldValue("wb_transaction_type", "trx_require_internal_no", "transaction_code", current.Cells["DO_NO"].Value.ToString()) == "Y") && (row4["Type"].ToString() == "S")) && (row4["Trade"].ToString() == "T")))
                            {
                                if (((current.Cells["do_sap"].Value.ToString().Trim() == "") || (current.Cells["do_sap_item"].Value.ToString().Trim() == "")) && ((current.Cells["internal_number"].Value.ToString().Trim() == "") || (current.Cells["internal_number_item"].Value.ToString().Trim() == "")))
                                {
                                    MessageBox.Show("Please Fill DO SAP / Internal Number for DO " + (num4 + 1) + " before save transaction!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    flag10 = true;
                                }
                                if ((current.Cells["do_sap"].Value.ToString().Trim() != "") && (current.Cells["do_sap_item"].Value.ToString().Trim().Length < 2))
                                {
                                    MessageBox.Show("Invalid DO SAP Item for DO " + (num4 + 1) + "! Please check before save transaction!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    flag10 = true;
                                }
                                if ((current.Cells["internal_number"].Value.ToString().Trim() != "") && (current.Cells["internal_number_item"].Value.ToString().Trim().Length < 2))
                                {
                                    MessageBox.Show("Invalid Internal No Item for DO " + (num4 + 1) + "! Please check before save transaction!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    flag10 = true;
                                }
                                if (current.Cells["do_qty"].Value.ToString().Trim() == "")
                                {
                                    MessageBox.Show("Quantity DO SAP for DO " + (num4 + 1) + " is 0! Please contact SAP!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    flag10 = true;
                                }
                            }
                            if ((((row3["check_qty"].ToString() == "Y") && ((row4["bulkpack"].ToString() != "P") && ((current.Cells["loading_qty"].Value.ToString() != "0") || (current.Cells["loading_qty"].Value.ToString() != "")))) && (current.Cells["internal_number"].Value.ToString() == "")) && !flag10)
                            {
                                double num5 = this.countQtyLeft(current.Cells["do_no"].Value.ToString(), row3, "Y");
                                if (!(num5 != 0.0))
                                {
                                    MessageBox.Show("Cannot Use DO " + (num4 + 1) + ", Outstanding DO is 0! Please check before save transaction!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    flag10 = true;
                                }
                                if ((num4 > 0) && !flag10)
                                {
                                    if (row3["deductedBy"].ToString() == "0")
                                    {
                                        if ((((row4["type"].ToString() == "S") || (row4["type"].ToString() == "F")) || (row4["type"].ToString() == "C")) && (Program.StrToDouble(current.Cells["netto"].Value.ToString(), 0) > num5))
                                        {
                                            MessageBox.Show("Factory net for DO " + (num4 + 1) + " is over quantity tolerance! Please check before save transaction!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                            flag10 = true;
                                        }
                                    }
                                    else if ((row3["deductedBy"].ToString() == "1") && (Program.StrToDouble(current.Cells["estate_qty"].Value.ToString(), 0) > num5))
                                    {
                                        MessageBox.Show("Other party quantity for DO " + (num4 + 1) + " is over quantity tolerance! Please check before save transaction!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        flag10 = true;
                                    }
                                }
                            }
                            if (flag10)
                            {
                                break;
                            }
                            num4++;
                            continue;
                        }
                        object[] objArray3 = new object[] { "DO ", num4 + 1, " (", current.Cells["DO_NO"].Value.ToString(), ") is not found! Please check DO ", num4 + 1, " before save transaction!" };
                        MessageBox.Show(string.Concat(objArray3), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        return false;
                    }
                }
                if (flag10)
                {
                    this.tabControl1.SelectedTab = this.tabPageDO;
                    this.dgvDO.CurrentCell = this.dgvDO.Rows[num4].Cells["do_no"];
                    this.dgvDO.Rows[num4].Selected = true;
                    return false;
                }
            }
            TextBox[] aText = new TextBox[] { this.textDriverID, this.textTruck };
            if (!Program.CheckEmpty(aText))
            {
                if (this.validTruck())
                {
                    if (this.validTransporter())
                    {
                        if ((((this.pMode != "1ST") && ((this.pMode != "2ND") && ((this.pMode != "3RD") && (this.pMode != "4TH")))) && (this.WX != "")) || !this.checkTruckinYard(this.textTruck.Text, this.textTruck2.Text))
                        {
                            if (this.validDriverID())
                            {
                                if (((this.pMode == "2ND") || (this.pMode == "4TH")) && (this.dgvDO.Rows.Count > 1))
                                {
                                    using (IEnumerator enumerator3 = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
                                    {
                                        while (true)
                                        {
                                            if (!enumerator3.MoveNext())
                                            {
                                                break;
                                            }
                                            DataGridViewRow current = (DataGridViewRow) enumerator3.Current;
                                            this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and  comm_code = '" + current.Cells["comm_code"].Value.ToString() + "'"), WBData.conn);
                                            string[] aField = new string[] { "comm_code" };
                                            string[] textArray7 = new string[] { current.Cells["comm_code"].Value.ToString() };
                                            DataRow data = this.tblComm.GetData(aField, textArray7);
                                            bool flag44 = data != null;
                                            if (flag44 && (((data["bulkpack"].ToString().Trim() == "B") || (data["bulkpack"].ToString().Trim() == "")) && (current.Cells["Netto"].Value.ToString() == "0")))
                                            {
                                                MessageBox.Show("Please Entry Netto for DO/Contract " + current.Cells["DO_NO"].Value.ToString());
                                                return false;
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("Driver ID Not Yet Registered in Driver Master.", "WARNING....");
                                this.textDriverID.SelectAll();
                                this.textDriverID.Focus();
                                return false;
                            }
                        }
                        else
                        {
                            if (((this.pMode == "1ST") || (this.pMode == "2ND")) || (this.WX == ""))
                            {
                                this.textTruck.SelectAll();
                                this.textTruck.Focus();
                            }
                            else if ((this.pMode == "3RD") || (this.pMode == "4TH"))
                            {
                                this.textTruck2.SelectAll();
                                this.textTruck2.Focus();
                            }
                            return false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Transporter Not Yet Registered in Transporter Master.", "WARNING....");
                        this.textTransporter.SelectAll();
                        this.textTransporter.Focus();
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("Truck Not Yet Registered in Truck Master.", "WARNING....");
                    this.textTruck.SelectAll();
                    this.textTruck.Focus();
                    return false;
                }
            }
            else
            {
                return false;
            }
            if ((this.dgvDO.Rows.Count != 0) || (this.WX == "1X"))
            {
                if (((this.WX != "") && ((this.pMode == "1ST") || (this.pMode == "2ND"))) && WBSetting.dummy_contract_on_registration)
                {
                    using (IEnumerator enumerator4 = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
                    {
                        while (true)
                        {
                            if (!enumerator4.MoveNext())
                            {
                                break;
                            }
                            DataGridViewRow current = (DataGridViewRow) enumerator4.Current;
                            if (current.Cells["Do_No"].Value.ToString() == WBSetting.dummy_contract)
                            {
                                MessageBox.Show("Please choose the correct DO", "WARNING....");
                                this.buttonEditDO.PerformClick();
                                return false;
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please Add DO", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }
            if (this.dgvDO.Rows.Count > 1)
            {
                string[] source = new string[this.dgvDO.Rows.Count];
                int index = 0;
                bool flag51 = false;
                foreach (DataGridViewRow row9 in (IEnumerable) this.dgvDO.Rows)
                {
                    if (source.Contains<string>(row9.Cells["Do_No"].Value.ToString()))
                    {
                        flag51 = true;
                        break;
                    }
                    source[index] = row9.Cells["Do_No"].Value.ToString();
                    index++;
                }
                if (flag51 && (MessageBox.Show("There are two or more same DO No. Do you want to continue?", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No))
                {
                    return false;
                }
            }
            if ((this.dgvDO.Rows.Count > 1) && ((!WBSetting.activeTCS || !this.Copied) || !this.manualCopyfromMainForm))
            {
                using (IEnumerator enumerator6 = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
                {
                    while (true)
                    {
                        if (!enumerator6.MoveNext())
                        {
                            break;
                        }
                        DataGridViewRow current = (DataGridViewRow) enumerator6.Current;
                        if (Program.StrToDouble(current.Cells["Netto"].Value.ToString(), 0) < 0.0)
                        {
                            string[] textArray8 = new string[] { "DO : ", current.Cells["DO_NO"].Value.ToString(), " Netto is MINUS (", current.Cells["Netto"].Value.ToString(), ")\nPlease ReCheck !!! " };
                            MessageBox.Show(string.Concat(textArray8), "WARNING!!!!");
                            return false;
                        }
                    }
                }
            }
            if (this.textRemarkTicket.TextLength <= 100)
            {
                if (this.chk_return.Checked)
                {
                    if (this.text_ref_return.Text.Trim() != "")
                    {
                        if (this.ref_return_valid)
                        {
                            if ((this.textNetEstate.Text.Trim() == "") || (this.textNetEstate.Text.Trim() == "0"))
                            {
                                MessageBox.Show("Please Fill in Other Party Quantity", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                this.textGrossEstate.Focus();
                                return false;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please Click Check for Return Transaction", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            this.btn_check.Focus();
                            return false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Fill in Return Ref Transaction", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.text_ref_return.Focus();
                        return false;
                    }
                }
                DateTime time = Convert.ToDateTime(this.textRef_Date.Text.ToString());
                if ((this.dateDelivery.Value.Date <= time.Date) || (this.sIO != "I"))
                {
                    if (((this.dgvDO.Rows.Count > 0) || ((this.WX == "") || (this.WX == "1X"))) || this.checkNonContract.Checked)
                    {
                        bool flag = false;
                        int num8 = this.dgvBatch.RowCount - 1;
                        while (true)
                        {
                            if (num8 >= 0)
                            {
                                DataGridViewRow dataGridViewRow = this.dgvBatch.Rows[num8];
                                if (dataGridViewRow.Cells["SO_No"].Value.ToString().Trim() == "")
                                {
                                    this.dgvBatch.Rows.Remove(dataGridViewRow);
                                }
                                else
                                {
                                    flag = false;
                                    int num9 = this.dgvDO.RowCount - 1;
                                    while (true)
                                    {
                                        if (num9 < 0)
                                        {
                                            if (!flag)
                                            {
                                                this.dgvBatch.Rows.Remove(dataGridViewRow);
                                            }
                                            break;
                                        }
                                        if (dataGridViewRow.Cells["SO_No"].Value.ToString().Trim() == this.dgvDO.Rows[num9].Cells["Do_No"].Value.ToString().Trim())
                                        {
                                            flag = true;
                                        }
                                        num9--;
                                    }
                                }
                                num8--;
                                continue;
                            }
                            if ((this.sReq_Tanker != "Y") || (this.textTanker.Text.Trim() != ""))
                            {
                                if (this.pMode != "1ST")
                                {
                                    if (this.pMode != "2ND")
                                    {
                                        if (this.pMode != "3RD")
                                        {
                                            if (this.pMode != "4TH")
                                            {
                                                if (this.pMode != "MANUAL")
                                                {
                                                    if (this.pMode != "SPLIT")
                                                    {
                                                        if ((this.pMode != "EDIT") || (this.spMode == "QTY"))
                                                        {
                                                            if (((this.pMode == "EDIT") && (this.spMode == "QTY")) && this.checkOverQty())
                                                            {
                                                                return false;
                                                            }
                                                        }
                                                        else if ((((this.WX != "2X") || (Program.StrToDouble(this.text2nd.Text, 0) <= 0.0)) ? ((this.WX == "4X") && (Program.StrToDouble(this.text4th.Text, 0) > 0.0)) : true) && this.checkOverQty())
                                                        {
                                                            return false;
                                                        }
                                                    }
                                                    else if (this.dgvDO.Rows.Count != 1)
                                                    {
                                                        if (this.checkOverQty())
                                                        {
                                                            return false;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        MessageBox.Show("Transaction Not Yet Splitted, Please Check DO...", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                        return false;
                                                    }
                                                }
                                                else if (this.textDate1st.Text.Trim() != "")
                                                {
                                                    if (this.textDate2nd.Text.Trim() != "")
                                                    {
                                                        if (this.textTime1st.Text.Trim() != "")
                                                        {
                                                            if (this.textTime2nd.Text.Trim() != "")
                                                            {
                                                                if (this.textReport_Date.Text.Trim() != "")
                                                                {
                                                                    if (this.textRef_Date.Text.Trim() != "")
                                                                    {
                                                                        if (this.textRefNo.Text.Trim() != "")
                                                                        {
                                                                            if (this.text1st.Text.Trim() != "")
                                                                            {
                                                                                if (this.text2nd.Text.Trim() != "")
                                                                                {
                                                                                    if (this.WX == "4X")
                                                                                    {
                                                                                        if (this.textDate3rd.Text.Trim() != "")
                                                                                        {
                                                                                            if (this.textDate4th.Text.Trim() != "")
                                                                                            {
                                                                                                if (this.textTime3rd.Text.Trim() != "")
                                                                                                {
                                                                                                    if (this.textTime4th.Text.Trim() != "")
                                                                                                    {
                                                                                                        if (this.text3rd.Text.Trim() != "")
                                                                                                        {
                                                                                                            if (this.text4th.Text.Trim() == "")
                                                                                                            {
                                                                                                                MessageBox.Show("Please input 4th Weight for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                                                this.text4th.Focus();
                                                                                                                return false;
                                                                                                            }
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                            MessageBox.Show("Please input 3rd Weight for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                                            this.text3rd.Focus();
                                                                                                            return false;
                                                                                                        }
                                                                                                    }
                                                                                                    else
                                                                                                    {
                                                                                                        MessageBox.Show("Please input Time 4th for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                                        this.textTime4th.Focus();
                                                                                                        return false;
                                                                                                    }
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    MessageBox.Show("Please input Time 3rd for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                                    this.textTime3rd.Focus();
                                                                                                    return false;
                                                                                                }
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                MessageBox.Show("Please input Date 4th for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                                this.textDate4th.Focus();
                                                                                                return false;
                                                                                            }
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            MessageBox.Show("Please input Date 3rd for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                            this.textDate3rd.Focus();
                                                                                            return false;
                                                                                        }
                                                                                    }
                                                                                }
                                                                                else
                                                                                {
                                                                                    MessageBox.Show("Please input 2nd Weight for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                    this.text2nd.Focus();
                                                                                    return false;
                                                                                }
                                                                            }
                                                                            else
                                                                            {
                                                                                MessageBox.Show("Please input 1st Weight for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                                this.text1st.Focus();
                                                                                return false;
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            MessageBox.Show("Please input Ref Number for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                            this.textRefNo.Focus();
                                                                            return false;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        MessageBox.Show("Please input Ref Date for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                        this.textRef_Date.Focus();
                                                                        return false;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    MessageBox.Show("Please input Report Date for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                    this.textRef_Date.Focus();
                                                                    return false;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                MessageBox.Show("Please input Time 2nd for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                                this.textTime2nd.Focus();
                                                                return false;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            MessageBox.Show("Please input Time 1st for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                            this.textTime1st.Focus();
                                                            return false;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        MessageBox.Show("Please input Date 2nd for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                        this.textDate2nd.Focus();
                                                        return false;
                                                    }
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Please input Date 1st for Manual Entry", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                    this.textDate1st.Focus();
                                                    return false;
                                                }
                                            }
                                            else if (Convert.ToDouble(this.text4th.Text.Trim()) != 0.0)
                                            {
                                                this.tblComm.OpenTable("wb_comm", "select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.textCommodity.Text.Trim() + "'"), WBData.conn);
                                                string[] aField = new string[] { "Comm_Code" };
                                                string[] textArray12 = new string[] { this.textCommodity.Text.Trim() };
                                                DataRow data = this.tblComm.GetData(aField, textArray12);
                                                WBCondition condition2 = new WBCondition();
                                                DataRow[] dgRows = new DataRow[] { this.rowTransType, data };
                                                condition2.fillParameter("NOPW", dgRows);
                                                string str9 = condition2.getResult() ? "Y" : "N";
                                                condition2.Dispose();
                                                if (((WBSetting.Field("NOPW") != "Y") || (str9 != "Y")) || (this.checkNOPW.Checked || ((this.textGrossEstate.Text != "0") && (this.textGrossEstate.Text != ""))))
                                                {
                                                    if (this.checkOverQty())
                                                    {
                                                        return false;
                                                    }
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Please fill in weight of other party or tick no other party weight checkbox.", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                    return false;
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show(" Result of Weight is Zero.\nPlease 'Read Indicator' again !", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                return false;
                                            }
                                        }
                                        else if (Convert.ToDouble(this.text3rd.Text.Trim()) != 0.0)
                                        {
                                            if (this.textTruck2.Text.Trim() == "")
                                            {
                                                MessageBox.Show("Please enter truck number 2! ", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                this.textTruck2.Focus();
                                                return false;
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show(" Result of Weight is Zero.\nPlease 'Read Indicator' again !", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                            return false;
                                        }
                                    }
                                    else if (Convert.ToDouble(this.text2nd.Text.Trim()) != 0.0)
                                    {
                                        if (this.is_vessel != "Y")
                                        {
                                            this.tblComm.OpenTable("wb_comm", "select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.textCommodity.Text.Trim() + "'"), WBData.conn);
                                            string[] aField = new string[] { "Comm_Code" };
                                            string[] textArray10 = new string[] { this.textCommodity.Text.Trim() };
                                            DataRow data = this.tblComm.GetData(aField, textArray10);
                                            WBCondition condition = new WBCondition();
                                            DataRow[] dgRows = new DataRow[] { this.rowTransType, data };
                                            condition.fillParameter("NOPW", dgRows);
                                            string str8 = condition.getResult() ? "Y" : "N";
                                            condition.Dispose();
                                            if ((((WBSetting.Field("NOPW") == "Y") && (str8 == "Y")) && (this.WX == "2X")) && (!this.checkNOPW.Checked && ((this.textGrossEstate.Text == "0") || (this.textGrossEstate.Text == ""))))
                                            {
                                                MessageBox.Show("Please fill in weight of other party or tick no other party weight checkbox.", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                return false;
                                            }
                                        }
                                        if (this.checkOverQty())
                                        {
                                            return false;
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show(" Result of Weight is Zero.\nPlease 'Read Indicator' again !", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        return false;
                                    }
                                }
                                else if (((this.WX == "") || (Convert.ToDouble(this.text1st.Text.Trim()) != 0.0)) || (WBSetting.activeTCS && (this.Copied & this.manualCopyfromMainForm)))
                                {
                                    using (IEnumerator enumerator7 = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
                                    {
                                        while (true)
                                        {
                                            if (!enumerator7.MoveNext())
                                            {
                                                break;
                                            }
                                            DataGridViewRow current = (DataGridViewRow) enumerator7.Current;
                                            if ((current.Cells["internal_number"].Value == null) || (current.Cells["internal_number"].Value.ToString() == ""))
                                            {
                                                this.tblDO.OpenTable("tmpDO", "select * from wb_contract where " + WBData.CompanyLocation(" and DO_NO = '" + current.Cells["DO_NO"].Value.ToString() + "'"), WBData.conn);
                                                if (this.tblDO.DT.Rows.Count > 0)
                                                {
                                                    this.tblDO.DR = this.tblDO.DT.Rows[0];
                                                    if (this.tblDO.DR["closed"].ToString() == "X")
                                                    {
                                                        MessageBox.Show("DO no " + current.Cells["DO_NO"].Value.ToString() + " is closed !", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                        flag5 = false;
                                                    }
                                                    else
                                                    {
                                                        if (this.tblDO.DR["check_qty"].ToString() != "Y")
                                                        {
                                                            continue;
                                                        }
                                                        double num10 = this.countQtyLeft(current.Cells["do_no"].Value.ToString(), this.tblDO.DR, "Y");
                                                        if (num10 != 0.0)
                                                        {
                                                            if ((this.tblDO.DR["deductedBy"].ToString() != "1") || (Program.StrToDouble(current.Cells["estate_qty"].Value.ToString(), 0) <= num10))
                                                            {
                                                                continue;
                                                            }
                                                            MessageBox.Show("Other party quantity for DO " + current.Cells["DO_NO"].Value.ToString() + " is over quantity tolerance! Please check before save transaction!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                            flag5 = false;
                                                        }
                                                        else
                                                        {
                                                            object[] objArray4 = new object[] { "OS for DO no ", current.Cells["DO_NO"].Value.ToString(), " is ", num10, " !" };
                                                            MessageBox.Show(string.Concat(objArray4), "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                            flag5 = false;
                                                        }
                                                    }
                                                    return flag5;
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(" Result of Weight is Zero.\nPlease 'Read Indicator' again !", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    return false;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Tanker Number is Required, Please Maintain Tanker in Master Data Truck!!!", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                return false;
                            }
                            break;
                        }
                    }
                    else
                    {
                        MessageBox.Show(" Please entry DO item ! ", "ERROR ON DO LIST", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.tabControl1.Focus();
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show(" Delivery Date is greater than Ref Date ", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.textRef_Date.Focus();
                    return false;
                }
            }
            else
            {
                MessageBox.Show("Remark for ticket is too long", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.textRemarkTicket.Focus();
                return false;
            }
            if ((this.textReport_Date.Text.Trim() != "") && (((this.pMode == "SPLIT") || ((this.pMode == "MANUAL") || (this.pMode == "EDIT"))) || (this.pMode == "QTY")))
            {
                this.tblComm.OpenTable("wb_comm", "select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.textCommodity.Text.Trim() + "'"), WBData.conn);
                string[] aField = new string[] { "Comm_Code" };
                string[] textArray14 = new string[] { this.textCommodity.Text.Trim() };
                DataRow data = this.tblComm.GetData(aField, textArray14);
                WBCondition condition3 = new WBCondition();
                DataRow[] dgRows = new DataRow[] { this.rowTransType, data };
                condition3.fillParameter("NOPW", dgRows);
                string str10 = condition3.getResult() ? "Y" : "N";
                condition3.Dispose();
                if (((WBSetting.Field("NOPW") != "Y") || (str10 != "Y")) || (this.checkNOPW.Checked || ((this.textGrossEstate.Text != "0") && (this.textGrossEstate.Text != ""))))
                {
                    using (IEnumerator enumerator8 = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
                    {
                        while (true)
                        {
                            if (!enumerator8.MoveNext())
                            {
                                break;
                            }
                            DataGridViewRow current = (DataGridViewRow) enumerator8.Current;
                            WBTable table6 = new WBTable();
                            WBTable table7 = new WBTable();
                            WBCondition condition4 = new WBCondition();
                            table6.OpenTable("wb_Commodity", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + current.Cells["comm_code"].Value.ToString() + "'"), WBData.conn);
                            table7.OpenTable("wb_Transaction_Type", "Select * from Wb_transaction_Type where " + WBData.CompanyLocation(" and transaction_code = '" + current.Cells["transaction_code"].Value.ToString() + "'"), WBData.conn);
                            if ((table6.DT.Rows.Count > 0) && (table7.DT.Rows.Count > 0))
                            {
                                table6.DR = table6.DT.Rows[0];
                                table7.DR = table7.DT.Rows[0];
                                DataRow[] rowArray4 = new DataRow[] { table6.DR, table7.DR };
                                condition4.fillParameter("TRANS_LOADING_QTY", rowArray4);
                                if ((condition4.getResult() && (table6.DR["Unit"].ToString().ToUpper() != "KG")) && ((current.Cells["loading_qty"].Value.ToString() == "") || (current.Cells["loading_qty"].Value.ToString() == "0")))
                                {
                                    char[] separator = new char[] { '/' };
                                    string[] strArray2 = current.Cells["do_no"].Value.ToString().Split(separator);
                                    object[] objArray5 = new object[] { "Please fill in loading qty for DO ", strArray2[0], " item ", Program.StrToDouble(current.Cells["so_item_detail"].Value.ToString(), 0) };
                                    MessageBox.Show(string.Concat(objArray5), "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    return false;
                                }
                            }
                            condition4.Dispose();
                            table7.Dispose();
                            table6.Dispose();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please fill in weight of other party or tick no other party weight checkbox.", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return false;
                }
            }
            if (((this.dgvDO.Rows.Count <= 1) || (this.WX != "2X")) || this.checkQtySplitDO())
            {
                if (WBSetting.locType == "1")
                {
                    if (this.textCust.Text != "")
                    {
                        double num11 = 0.0;
                        this.tblCust.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" and relation_code = '" + this.textCust.Text.Trim() + "' and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
                        string[] aField = new string[] { "Relation_Code" };
                        string[] textArray16 = new string[] { this.textCust.Text.Trim() };
                        this.tblCust.DR = this.tblCust.GetData(aField, textArray16);
                        if ((this.tblCust.DR != null) && (this.tblCust.DR["DailyQuantity"].ToString() == "Y"))
                        {
                            if (this.tblCust.DR["Quantity"].ToString().Trim() != "")
                            {
                                num11 = Program.StrToDouble(this.tblCust.DR["Quantity"].ToString(), 0);
                            }
                            if (num11 > (this.hitQtyToday(this.textRefNo.Text, this.textRef_Date.Text, this.textCust.Text) + Program.StrToDouble(this.textNet.Text, 0)))
                            {
                                MessageBox.Show("Warning. Over Daily Quantity for Relation " + this.textCust.Text + "\n Daily Quantity = " + num11.ToString(), "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            }
                        }
                    }
                    if (!WBSetting.CheckSPB() || !(this.checkDoubleSPB() & (this.textDN.Text.Length > 0)))
                    {
                        if ((WBSetting.Field("DeliveryNote") == "Y") && (this.WX != "1x"))
                        {
                            if (!((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))))
                            {
                                if (!((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))))
                                {
                                    if (this.textDN.Text.Trim() == "")
                                    {
                                        MessageBox.Show("Please Fill Delivery Note", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        this.textDN.Focus();
                                        return false;
                                    }
                                }
                                else
                                {
                                    this.textDN.Enabled = false;
                                }
                            }
                            else
                            {
                                this.textDN.Enabled = false;
                            }
                            if (this.textDN.Text.Trim() != "-")
                            {
                                if (this.dgvDO.Rows.Count <= 0)
                                {
                                    MessageBox.Show("Please input DO first", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    this.textDN.Text = "";
                                    return false;
                                }
                                else if (!((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))))
                                {
                                    if (!((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3"))))
                                    {
                                        if ((this.CommType == "F") && !this.CheckSPB())
                                        {
                                            MessageBox.Show("Invalid Delivery Note", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            this.textDN.Focus();
                                            return false;
                                        }
                                    }
                                    else
                                    {
                                        this.textDN.Enabled = false;
                                    }
                                }
                                else
                                {
                                    this.textDN.Enabled = false;
                                }
                            }
                        }
                        if ((((this.pMode == "2ND") || ((this.pMode == "4X") || (this.pMode == "EDIT"))) || (this.pMode == "QTY")) && ((this.CommType == "F") && (this.dgvDivBlock.RowCount > 0)))
                        {
                            double num13 = 0.0;
                            foreach (DataGridViewRow row17 in (IEnumerable) this.dgvDivBlock.Rows)
                            {
                                num13 += Program.StrToDouble(row17.Cells["Bunch"].Value.ToString(), 0);
                            }
                            if (!(num13 == Program.StrToDouble(this.textBunchTotal.Text, 0)))
                            {
                                object[] objArray6 = new object[] { "Total of bunch in Deduction is not as same as total of bunch in Division.Total of bunch in Deduction: ", this.textBunchTotal.Text, "\nTotal of bunch in Division: ", num13, "\n\nPlease check before save transaction!" };
                                MessageBox.Show(string.Concat(objArray6), "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("DOUBLE SPB FOR TODAY TRANSACTION", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        return false;
                    }
                }
                if (!(((this.CommType == "G") & (this.sIO == "O")) & (this.pMode == "2ND")) || (this.dgvBatch.Rows.Count > 0))
                {
                    string str = "";
                    int num = 0;
                    foreach (DataGridViewRow row18 in (IEnumerable) this.dgvDO.Rows)
                    {
                        if (Convert.ToDouble(row18.Cells["Netto"].Value.ToString()) > 0.0)
                        {
                            this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity where " + WBData.CompanyLocation(" and  comm_code = '" + row18.Cells["Comm_Code"].Value.ToString() + "'"), WBData.conn);
                            string[] aField = new string[] { "Comm_Code" };
                            string[] textArray18 = new string[] { row18.Cells["Comm_Code"].Value.ToString() };
                            this.tblComm.DR = this.tblComm.GetData(aField, textArray18);
                            if ((this.tblComm.DR != null) && ((this.tblComm.DR["ConvertionCheck"].ToString() == "Y") && (Convert.ToDouble((row18.Cells["ConvNett"].Value.ToString().Trim() == "") ? "0" : row18.Cells["ConvNett"].Value.ToString()) > 0.0)))
                            {
                                double num14 = Convert.ToDouble(row18.Cells["ConvNett"].Value.ToString()) * Convert.ToDouble(this.tblComm.DR["Convertion"].ToString());
                                double num15 = (num14 / 1000.0) * Convert.ToDouble(this.tblComm.DR["ConvertionTolerance"].ToString());
                                double num18 = Convert.ToDouble(row18.Cells["Netto"].Value.ToString());
                                double num16 = Math.Round((double) (num14 - num15), 0);
                                double num17 = Math.Round((double) (num14 + num15), 0);
                                if ((num18 < num16) || (num18 > num17))
                                {
                                    str = ((row18.Cells["Comm_Code"].Value.ToString() + " : ") + "Minimum Weight is " + $"{num16:N0}") + " Kg and Maximum Weight is " + $"{num17:N0}" + " Kg";
                                }
                                this.dgvDO.Rows[num].Cells["ConvTolerance"].Value = num15;
                            }
                        }
                        if (str != "")
                        {
                            str = str + "\n";
                        }
                        num++;
                    }
                    if (str == "")
                    {
                        this.needApproval = false;
                        if (!(((this.pMode != "2ND") || (this.WX != "2X")) ? ((this.pMode == "4TH") && (this.WX == "4X")) : true))
                        {
                            if (this.pMode == "EDIT")
                            {
                                if ((this.use_gunny == "Y") && (this.is_bulk == "P"))
                                {
                                    double num20;
                                    try
                                    {
                                        num20 = Convert.ToDouble(this.textBox3.Text);
                                    }
                                    catch
                                    {
                                        num20 = 0.0;
                                    }
                                    if ((num20 > this.sGunnyMax) || (num20 < this.sGunnyMin))
                                    {
                                        string[] textArray20 = new string[] { "Net per Gunny is beyond Tolerance ( ", this.sGunnyMin.ToString().Trim(), " - ", this.sGunnyMax.ToString().Trim(), " )\n will need Manager Approval to save this transaction " };
                                        MessageBox.Show(string.Concat(textArray20), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        this.needApproval = true;
                                    }
                                }
                                if (this.textReport_Date.Text.Trim() != "")
                                {
                                    if ((this.spMode != "QTY") || this.cek_grossWeight())
                                    {
                                        if (((this.spMode == "QTY") && (this.pMode == "EDIT")) && ((((WBSetting.Field("check_tanker") == "P") || (WBSetting.Field("check_tanker") == "K")) && ((this.CommType == "S") && (this.is_trade == "T"))) && (this.is_bulk == "B")))
                                        {
                                            if (this.sReq_Tanker != "Y")
                                            {
                                                if ((this.sReq_Tanker == "N") && ((this.textTanker.Text.Trim() != "") && !this.check_TankerCapacity()))
                                                {
                                                    return false;
                                                }
                                            }
                                            else if (!this.check_TankerCapacity())
                                            {
                                                return false;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        return false;
                                    }
                                }
                            }
                        }
                        else if ((this.pMode != "4TH") || (this.dgvDOCont.RowCount > 0))
                        {
                            if ((this.use_gunny == "Y") && (this.is_bulk == "P"))
                            {
                                double num19;
                                try
                                {
                                    num19 = Convert.ToDouble(this.textBox3.Text);
                                }
                                catch
                                {
                                    num19 = 0.0;
                                }
                                if ((num19 > this.sGunnyMax) || (num19 < this.sGunnyMin))
                                {
                                    string[] textArray19 = new string[] { "Net per Gunny is beyond Tolerance ( ", this.sGunnyMin.ToString().Trim(), " - ", this.sGunnyMax.ToString().Trim(), " )\n will need Manager Approval to save this transaction " };
                                    MessageBox.Show(string.Concat(textArray19), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    this.needApproval = true;
                                }
                            }
                            if (this.cek_grossWeight())
                            {
                                if ((((WBSetting.Field("check_tanker") == "P") || (WBSetting.Field("check_tanker") == "K")) && ((this.CommType == "S") && (this.is_trade == "T"))) && (this.is_bulk == "B"))
                                {
                                    if (this.sReq_Tanker != "Y")
                                    {
                                        if ((this.sReq_Tanker == "N") && ((this.textTanker.Text.Trim() != "") && !this.check_TankerCapacity()))
                                        {
                                            return false;
                                        }
                                    }
                                    else if (!this.check_TankerCapacity())
                                    {
                                        return false;
                                    }
                                }
                            }
                            else
                            {
                                return false;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please Fill in DO Container");
                            return false;
                        }
                        if (this.needApproval)
                        {
                            this.approve = "N";
                            this.approval = Program.fillApproval(this.msgApprove, "", "");
                            this.approve = this.approval[0];
                            this.approveBy1 = this.approval[1];
                            this.approveBy2 = this.approval[2];
                            if (this.approve == "N")
                            {
                                MessageBox.Show("This Transaction not approved.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                return false;
                            }
                        }
                        if (WBSetting.Field("Check_tare") == "Y")
                        {
                            if ((this.transType == "I") && (this.check_tare_comm == "Y"))
                            {
                                if (((this.pMode == "2ND") || (this.pMode == "4TH")) && !this.checkTare())
                                {
                                    string[] textArray21 = new string[] { "Tare is Beyond Tolerance ( ", this.minTare, " - ", this.maxTare, " )\n please ask for Manager Approval " };
                                    MessageBox.Show(string.Concat(textArray21), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    this.needApproval = true;
                                }
                            }
                            else if ((this.transType == "O") && (((this.pMode == "1ST") && (this.check_tare_comm == "Y")) && !this.checkTare()))
                            {
                                string[] textArray22 = new string[] { "Tare is Beyond Tolerance ( ", this.minTare, " - ", this.maxTare, " )\n please ask for Manager Approval " };
                                MessageBox.Show(string.Concat(textArray22), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.needApproval = true;
                            }
                            if (this.needApproval)
                            {
                                this.hasil = this.tblComm.tokenOrApp(this.textTruck.Text, "", "OVER_TARE", "TOKEN_OVER_TARE", "OVER_TARE", "E", "", null);
                                if (this.hasil[0] != "completed")
                                {
                                    this.approve = "N";
                                    MessageBox.Show("This Transaction Tare not approved.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    return false;
                                }
                                else
                                {
                                    this.approve = "Y";
                                    this.approveBy1 = this.hasil[1];
                                    this.ApproveReason = this.hasil[2];
                                    this.approve_type = "OVER_TARE";
                                }
                            }
                        }
                        if ((this.pMode == "1ST") && ((WBSetting.grossHistoryControl == "Y") && (((this.CommType == "F") && (this.transType == "I")) && !this.checkGrossHistoryControl())))
                        {
                            this.hasil = this.tblComm.tokenOrApp(this.textTruck.Text, "", "OVER_GROSS_FFB", "TOKEN_GROSS_FFB", "OVER_GROSS_FFB", "E", "", null);
                            if (this.hasil[0] != "completed")
                            {
                                this.approve = "N";
                                MessageBox.Show("This Transaction Gross not approved.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                return false;
                            }
                            else
                            {
                                this.approve = "Y";
                                this.approveBy1 = this.hasil[1];
                                this.ApproveReason = this.hasil[2];
                                this.approve_type = "OVER_GROSS_FFB";
                            }
                        }
                        if (WBSetting.activeOverLossToleranceControlbyNet && (((this.WX != "2X") || (this.pMode != "2ND")) ? (this.spMode == "QTY") : true))
                        {
                            double netEstate = Program.StrToDouble(this.textNetEstate.Text.Trim(), 0);
                            double num22 = Program.StrToDouble(this.textNET1.Text.Trim(), 0);
                            double loss = (netEstate == 0.0) ? 0.0 : (num22 - netEstate);
                            if ((loss < 0.0) && this.overNetLossTolerance(loss, netEstate))
                            {
                                return false;
                            }
                        }
                        if (WBSetting.activeOverLossToleranceControlbyGross && (((this.WX != "2X") || (((this.sIO != "O") || (this.pMode != "2ND")) && ((this.sIO != "I") || (this.pMode != "1ST")))) ? (this.spMode == "QTY") : true))
                        {
                            double grossEstate = Program.StrToDouble(this.textGrossEstate.Text.Trim(), 0);
                            double grossFactory = (this.sIO == "O") ? Program.StrToDouble(this.text2nd.Text.Trim(), 0) : Program.StrToDouble(this.text1st.Text.Trim(), 0);
                            if (((grossEstate > 0.0) && (grossEstate > grossFactory)) && this.overGrossLossTolerance(grossEstate, grossFactory))
                            {
                                return false;
                            }
                        }
                        if (((this.spMode != "COPY") && (this.spMode != "QTY")) && (this.spMode != "EDIT_OPW"))
                        {
                            this.pMode = this.spMode;
                        }
                        if (!(((this.pMode != "1ST") || !this.tambahRecord) ? (this.pMode == "MANUAL") : true))
                        {
                            if (((this.pMode != "EDIT") && (this.pMode != "QTY")) && (this.pMode != "CANCEL"))
                            {
                                goto TR_026F;
                            }
                            else
                            {
                                FormTransCancel cancel = new FormTransCancel {
                                    textRefNo = { Text = this.textRefNo.Text }
                                };
                                if (this.pMode == "EDIT")
                                {
                                    cancel.Text = "CHANGE REASON";
                                    cancel.label2.Text = "Change Reason : ";
                                }
                                else if (this.pMode == "QTY")
                                {
                                    cancel.Text = "CHANGE QTY REASON";
                                    cancel.label2.Text = "Change QTY Reason : ";
                                }
                                else
                                {
                                    cancel.Text = "CANCEL REASON";
                                    cancel.label2.Text = "Cancel Reason : ";
                                }
                                cancel.textReason.Text = this.mChangeReason;
                                cancel.textReason.Focus();
                                cancel.ShowDialog();
                                if (cancel.Saved)
                                {
                                    this.mChangeReason = cancel.textReason.Text;
                                    cancel.Dispose();
                                    goto TR_026F;
                                }
                                else
                                {
                                    flag5 = false;
                                }
                            }
                        }
                        else
                        {
                            if (this.pMode == "1ST")
                            {
                                this.textRefNo.Text = (this.WX != "1X") ? this.SetNoref(true) : this.SetNorefTemporary(true);
                            }
                            this.tblTrans.DR = this.tblTrans.DT.NewRow();
                            goto TR_0269;
                        }
                    }
                    else
                    {
                        MessageBox.Show("\nCONVERTION WEIGH \n\n" + (str + "\nTransaction will be cancelled . . !\n"), "TRANSACTION BLOCK", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        flag5 = false;
                    }
                }
                else
                {
                    MessageBox.Show("Please Adopt / Input Delivery Letter First", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    flag5 = false;
                }
            }
            else
            {
                flag5 = false;
            }
            return flag5;
        TR_0149:
            foreach (DataGridViewRow row26 in (IEnumerable) this.dgvDO.Rows)
            {
                this.tblTransDO.DR = this.tblTransDO.DT.NewRow();
                int num34 = 0;
                while (true)
                {
                    if (num34 >= this.tblTransDO.DT.Columns.Count)
                    {
                        this.tblTransDO.DR["Coy"] = WBData.sCoyCode;
                        this.tblTransDO.DR["Location_Code"] = WBData.sLocCode;
                        this.tblTransDO.DR["estate_qty"] = row26.Cells["estate_qty"].Value.ToString();
                        this.tblTransDO.DR["Netto"] = row26.Cells["Netto"].Value.ToString();
                        if ((this.pMode == "1ST") || (this.pMode == "2ND"))
                        {
                            this.tblTransDO.DR["loading_qty_opw"] = 0;
                        }
                        if (num3 == 0)
                        {
                            this.tblTransDO.DR["Ref"] = this.textRefNo.Text;
                        }
                        else
                        {
                            ch = Convert.ToChar(num2);
                            this.tblTransDO.DR["Ref"] = this.textRefNo.Text + ch.ToString();
                        }
                        this.tblTransDO.DR["Gatepass_Number"] = this.gatepass_no;
                        this.tblTransDO.DT.Rows.Add(this.tblTransDO.DR);
                        this.tblTransDO.Save();
                        num3++;
                        num2++;
                        break;
                    }
                    str2 = this.tblTransDO.DT.Columns[num34].ColumnName.ToString();
                    bool flag324 = str2.ToUpper() != "UNIQ".ToUpper();
                    if (flag324 && ((row26.Cells[str2].Value != null) && (row26.Cells[str2].Value.ToString().Trim() != "")))
                    {
                        this.tblTransDO.DR[str2] = row26.Cells[str2].Value;
                    }
                    num34++;
                }
            }
            WBTable table = new WBTable();
            foreach (DataRow row27 in this.tblTransDO.DT.Rows)
            {
                if (row27["STO1X"].ToString().Trim() != "")
                {
                    table.OpenTable("wb_contract", "update wb_contract set [STO1DO]='Y' Where " + WBData.CompanyLocation(" AND Do_No='" + row27["Do_No"].ToString().Trim() + "'"), WBData.conn);
                    string[] textArray40 = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] textArray41 = new string[] { this.logMode, WBUser.UserID, "Generated from transaction" };
                    Program.updateLogHeader("wb_contract", row27["Do_No"].ToString().Trim(), textArray40, textArray41);
                }
            }
            table.Dispose();
            if (this.ChangeDoCont || ((this.pMode == "1ST") || (this.pMode == "MANUAL")))
            {
                int num35 = 0;
                while (true)
                {
                    if (num35 >= this.dgvDOCont.RowCount)
                    {
                        this.tblDOContainer.AddFromDGV_new(this.dgvDOCont, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                        this.tblDOContainer.ReOpen();
                        break;
                    }
                    if (this.dgvDOCont.Rows[num35].Cells["Ref"].Value == null)
                    {
                        this.dgvDOCont.Rows[num35].Cells["Ref"].Value = this.textRefNo.Text;
                    }
                    if (this.dgvDOCont.Rows[num35].Cells["gatepass_number"].Value == null)
                    {
                        this.dgvDOCont.Rows[num35].Cells["gatepass_number"].Value = this.gatepass_no;
                    }
                    num35++;
                }
            }
            if (this.ChangeDiv)
            {
                if (this.dgvDivBlock.Rows.Count > 0)
                {
                    if (this.dgvDivBlock.Rows.Count == 1)
                    {
                        DataGridViewRow row28 = this.dgvDivBlock.Rows[0];
                        if (((row28.Cells["Bunch"].Value.ToString() != "0") && (row28.Cells["Weight"].Value.ToString() != "0")) && (Convert.ToInt32(row28.Cells["Weight"].Value.ToString()) != Convert.ToInt32(Program.StrToDouble(this.textNET2.Text, 0))))
                        {
                            row28.Cells["Weight"].Value = this.textNET2.Text;
                        }
                    }
                    else
                    {
                        int num36 = 0;
                        int num37 = 0;
                        int num38 = 0;
                        while (true)
                        {
                            if (num38 >= this.dgvDivBlock.Rows.Count)
                            {
                                break;
                            }
                            DataGridViewRow row29 = this.dgvDivBlock.Rows[num38];
                            if ((row29.Cells["Bunch"].Value.ToString() != "0") && (row29.Cells["Weight"].Value.ToString() != "0"))
                            {
                                if (num36 == (this.dgvDivBlock.Rows.Count - 1))
                                {
                                    row29.Cells["Weight"].Value = Convert.ToInt32(Program.StrToDouble(this.textNET2.Text, 0)) - num37;
                                }
                                num37 += Convert.ToInt32(row29.Cells["Weight"].Value.ToString());
                                num36++;
                            }
                            num38++;
                        }
                    }
                }
                this.tblTransDiv.AddFromDGV_new(this.dgvDivBlock, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                this.tblTransDiv.ReOpen();
            }
            if (this.ChangeDeduc)
            {
                this.tblTransDeduc.AddFromDGV_new(this.dgvDeduc, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                this.tblTransDeduc.ReOpen();
            }
            if (this.ChangeDeducPorla)
            {
                this.tblTransDeducPorla.AddFromDGV_new(this.dgvDeducPorla, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                this.tblTransDeducPorla.ReOpen();
            }
            if (this.ChangeBatch)
            {
                int num39 = 0;
                while (true)
                {
                    if (num39 >= this.dgvBatch.RowCount)
                    {
                        this.tblTransBatch.AddFromDGV_new(this.dgvBatch, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                        this.tblTransBatch.ReOpen();
                        break;
                    }
                    if (this.dgvBatch.Rows[num39].Cells["Num_of_Gunny"].Value == null)
                    {
                        this.dgvBatch.Rows[num39].Cells["Num_of_Gunny"].Value = "0";
                    }
                    if (this.dgvBatch.Rows[num39].Cells["Netto"].Value == null)
                    {
                        this.dgvBatch.Rows[num39].Cells["Netto"].Value = "0";
                    }
                    num39++;
                }
            }
            int num40 = 0;
            while (true)
            {
                if (num40 >= this.dgvQC_All.RowCount)
                {
                    this.tblTransQC.AddFromDGV_new(this.dgvQC_All, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                    this.tblTransQC.ReOpen();
                    if (((((this.pMode == "2ND") && (this.WX == "2X")) || ((this.pMode == "4TH") && (this.WX == "4X"))) || (this.pMode == "SPLIT")) && (this.dgvDO.Rows.Count > 0))
                    {
                        int num41 = 1;
                        while (true)
                        {
                            if (num41 >= this.dgvDO.Rows.Count)
                            {
                                break;
                            }
                            ch = Convert.ToChar((int) (0x40 + num41));
                            string pVal = this.textRefNo.Text + ch.ToString();
                            WBTable table15 = new WBTable();
                            table15.OpenTable("wb_transQC", "SELECT * FROM wb_transQC WHERE " + WBData.CompanyLocation(" AND ref = '" + pVal + "'"), WBData.conn);
                            table15.AddFromDGV_new(this.dgvQC_All, "Ref", pVal, this.logMode, this.logReason);
                            table15.ReOpen();
                            table15.Dispose();
                            num6 = num41;
                            num41 = num6 + 1;
                        }
                    }
                    if (this.ChangeContainer || ((this.pMode == "1ST") || (this.pMode == "MANUAL")))
                    {
                        int num42 = 0;
                        while (true)
                        {
                            if (num42 >= this.dgvCont.RowCount)
                            {
                                this.tblTransContainer.AddFromDGV_new(this.dgvCont, "Ref", this.textRefNo.Text, this.logMode, this.logReason);
                                this.tblTransContainer.ReOpen();
                                break;
                            }
                            if (this.dgvCont.Rows[num42].Cells["Ref"].Value == null)
                            {
                                this.dgvCont.Rows[num42].Cells["Ref"].Value = this.textRefNo.Text;
                            }
                            if (this.dgvCont.Rows[num42].Cells["gatepass_number"].Value == null)
                            {
                                this.dgvCont.Rows[num42].Cells["gatepass_number"].Value = this.gatepass_no;
                            }
                            num42++;
                        }
                    }
                    this.tblTransCopra.ReOpen();
                    string keyField = "";
                    if (this.tblTransCopra.DT.Rows.Count <= 0)
                    {
                        this.tblTransCopra.DR = this.tblTransCopra.DT.NewRow();
                    }
                    else
                    {
                        this.tblTransCopra.DR = this.tblTransCopra.DT.Rows[0];
                        keyField = this.tblTransCopra.DR["uniq"].ToString();
                        this.tblTransCopra.DR.BeginEdit();
                    }
                    this.tblTransCopra.DR["Coy"] = WBData.sCoyCode;
                    this.tblTransCopra.DR["Location_code"] = WBData.sLocCode;
                    this.tblTransCopra.DR["Ref"] = this.textRefNo.Text;
                    this.tblTransCopra.DR["Colly1"] = (this.fCopra.textColly1.Text == "") ? "0" : this.fCopra.textColly1.Text;
                    this.tblTransCopra.DR["Colly2"] = (this.fCopra.textColly2.Text == "") ? "0" : this.fCopra.textColly2.Text;
                    this.tblTransCopra.DR["Colly3"] = (this.fCopra.textColly3.Text == "") ? "0" : this.fCopra.textColly3.Text;
                    this.tblTransCopra.DR["Colly4"] = (this.fCopra.textColly4.Text == "") ? "0" : this.fCopra.textColly4.Text;
                    this.tblTransCopra.DR["Colly5"] = (this.fCopra.textColly5.Text == "") ? "0" : this.fCopra.textColly5.Text;
                    this.tblTransCopra.DR["Colly6"] = (this.fCopra.textColly6.Text == "") ? "0" : this.fCopra.textColly6.Text;
                    this.tblTransCopra.DR["Colly7"] = (this.fCopra.textColly7.Text == "") ? "0" : this.fCopra.textColly7.Text;
                    this.tblTransCopra.DR["Colly8"] = (this.fCopra.textColly8.Text == "") ? "0" : this.fCopra.textColly8.Text;
                    this.tblTransCopra.DR["NetColly1"] = (this.fCopra.textColly1KG.Text == "") ? "0" : this.fCopra.textColly1KG.Text;
                    this.tblTransCopra.DR["NetColly2"] = (this.fCopra.textColly2KG.Text == "") ? "0" : this.fCopra.textColly2KG.Text;
                    this.tblTransCopra.DR["NetColly3"] = (this.fCopra.textColly3KG.Text == "") ? "0" : this.fCopra.textColly3KG.Text;
                    this.tblTransCopra.DR["NetColly4"] = (this.fCopra.textColly4KG.Text == "") ? "0" : this.fCopra.textColly4KG.Text;
                    this.tblTransCopra.DR["NetColly5"] = (this.fCopra.textColly5KG.Text == "") ? "0" : this.fCopra.textColly5KG.Text;
                    this.tblTransCopra.DR["NetColly6"] = (this.fCopra.textColly6KG.Text == "") ? "0" : this.fCopra.textColly6KG.Text;
                    this.tblTransCopra.DR["NetColly7"] = (this.fCopra.textColly7KG.Text == "") ? "0" : this.fCopra.textColly7KG.Text;
                    this.tblTransCopra.DR["NetColly8"] = (this.fCopra.textColly8KG.Text == "") ? "0" : this.fCopra.textColly8KG.Text;
                    this.tblTransCopra.DR["JlhColly1"] = (this.fCopra.textJlhColly1.Text == "") ? "0" : this.fCopra.textJlhColly1.Text;
                    this.tblTransCopra.DR["JlhColly2"] = (this.fCopra.textJlhColly2.Text == "") ? "0" : this.fCopra.textJlhColly2.Text;
                    this.tblTransCopra.DR["JlhColly3"] = (this.fCopra.textJlhColly3.Text == "") ? "0" : this.fCopra.textJlhColly3.Text;
                    this.tblTransCopra.DR["JlhColly4"] = (this.fCopra.textJlhColly4.Text == "") ? "0" : this.fCopra.textJlhColly4.Text;
                    this.tblTransCopra.DR["JlhColly5"] = (this.fCopra.textJlhColly5.Text == "") ? "0" : this.fCopra.textJlhColly5.Text;
                    this.tblTransCopra.DR["JlhColly6"] = (this.fCopra.textJlhColly6.Text == "") ? "0" : this.fCopra.textJlhColly6.Text;
                    this.tblTransCopra.DR["JlhColly7"] = (this.fCopra.textJlhColly7.Text == "") ? "0" : this.fCopra.textJlhColly7.Text;
                    this.tblTransCopra.DR["Form1"] = (this.fCopra.textForm1.Text == "") ? "0" : this.fCopra.textForm1.Text;
                    this.tblTransCopra.DR["Form2"] = (this.fCopra.textForm2.Text == "") ? "0" : this.fCopra.textForm2.Text;
                    this.tblTransCopra.DR["Form3"] = (this.fCopra.textForm3.Text == "") ? "0" : this.fCopra.textForm3.Text;
                    this.tblTransCopra.DR["Form4"] = (this.fCopra.textForm4.Text == "") ? "0" : this.fCopra.textForm4.Text;
                    this.tblTransCopra.DR["Form5"] = (this.fCopra.textForm5.Text == "") ? "0" : this.fCopra.textForm5.Text;
                    this.tblTransCopra.DR["Form6"] = (this.fCopra.textForm6.Text == "") ? "0" : this.fCopra.textForm6.Text;
                    this.tblTransCopra.DR["Form7"] = (this.fCopra.textForm7.Text == "") ? "0" : this.fCopra.textForm7.Text;
                    this.tblTransCopra.DR["NetF1"] = (this.fCopra.textForm1KG.Text == "") ? "0" : this.fCopra.textForm1KG.Text;
                    this.tblTransCopra.DR["NetF2"] = (this.fCopra.textForm2KG.Text == "") ? "0" : this.fCopra.textForm2KG.Text;
                    this.tblTransCopra.DR["NetF3"] = (this.fCopra.textForm3KG.Text == "") ? "0" : this.fCopra.textForm3KG.Text;
                    this.tblTransCopra.DR["NetF4"] = (this.fCopra.textForm4KG.Text == "") ? "0" : this.fCopra.textForm4KG.Text;
                    this.tblTransCopra.DR["NetF5"] = (this.fCopra.textForm5KG.Text == "") ? "0" : this.fCopra.textForm5KG.Text;
                    this.tblTransCopra.DR["NetF6"] = (this.fCopra.textForm6KG.Text == "") ? "0" : this.fCopra.textForm6KG.Text;
                    this.tblTransCopra.DR["NetF7"] = (this.fCopra.textForm7KG.Text == "") ? "0" : this.fCopra.textForm7KG.Text;
                    this.tblTransCopra.DR["PotAbu"] = (this.fCopra.textPotAbu.Text == "") ? "0" : this.fCopra.textPotAbu.Text;
                    this.tblTransCopra.DR["PotLain"] = (this.fCopra.textPotLain.Text == "") ? "0" : this.fCopra.textPotLain.Text;
                    this.tblTransCopra.DR["TPColly"] = (this.fCopra.textFormTotalKG.Text == "") ? "0" : this.fCopra.textFormTotalKG.Text;
                    this.tblTransCopra.DR["TPAir"] = (this.fCopra.textTPAir.Text == "") ? "0" : this.fCopra.textTPAir.Text;
                    this.tblTransCopra.DR["JlhColly"] = (this.fCopra.textJlhColly.Text == "") ? "0" : this.fCopra.textJlhColly.Text;
                    this.tblTransCopra.DR["TPCopra"] = (this.fCopra.textTotalCopra.Text == "") ? "0" : this.fCopra.textTotalCopra.Text;
                    if (this.tblTransCopra.DT.Rows.Count > 0)
                    {
                        this.tblTransCopra.DR.EndEdit();
                    }
                    else
                    {
                        this.tblTransCopra.DT.Rows.Add(this.tblTransCopra.DR);
                    }
                    this.tblTransCopra.Save();
                    if (keyField == "")
                    {
                        string sqltext = ("SELECT uniq FROM wb_transCopra WHERE " + WBData.CompanyLocation(" ")) + " AND Ref = '" + this.tblTransCopra.DR["Ref"].ToString() + "'";
                        WBTable table16 = new WBTable();
                        table16.OpenTable("wb_transCopra", sqltext, WBData.conn);
                        keyField = table16.DT.Rows[0]["uniq"].ToString();
                        table16.Dispose();
                    }
                    string[] textArray42 = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] textArray43 = new string[] { this.logMode, WBUser.UserID, this.logReason };
                    Program.updateLogHeader("wb_transCopra", keyField, textArray42, textArray43);
                    if ((this.CommType == "G") && ((this.SJAdopted && ((this.pMode == "2ND") || (this.pMode == "EDIT"))) && (this.sIO == "O")))
                    {
                        try
                        {
                            WBSetting.OpenSetting();
                            if (!WBSAP.connect())
                            {
                                this.rptdate = Convert.ToDateTime(this.textReport_Date.Text);
                            }
                            WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_AFTER_WEIGH");
                            IRfcStructure structure = WBSAP.rfcFunction.GetStructure("WA_RECORD");
                            structure.SetValue("VBELN", this.textDL.Text.Trim());
                            structure.SetValue("ZDVR", this.textDriverName.Text.Trim());
                            structure.SetValue("ZDID", this.textDriverID.Text.Trim());
                            structure.SetValue("ZCPN", this.textTruck.Text.Trim());
                            structure.SetValue("WADAT_IST", this.rptdate.ToString("yyyymmdd"));
                            structure.SetValue("LFIMG", this.textNet.Text.Trim());
                            WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                            string text = WBSAP.rfcFunction.GetValue("MSG").ToString();
                            if (text != "")
                            {
                                MessageBox.Show(text);
                            }
                        }
                        catch (RfcInvalidParameterException exception)
                        {
                            MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "E R R O R <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        catch (RfcCommunicationException exception2)
                        {
                            if (WBUser.UserLevel == "1")
                            {
                                MessageBox.Show(exception2.ToString(), "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                        }
                        catch (RfcBaseException exception3)
                        {
                            if (WBUser.UserLevel == "1")
                            {
                                MessageBox.Show(exception3.ToString(), "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                        }
                        catch (Exception exception4)
                        {
                            MessageBox.Show("Error " + exception4.ToString(), "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                    break;
                }
                if (this.dgvQC_All.Rows[num40].Cells["Ref"].Value == null)
                {
                    this.dgvQC_All.Rows[num40].Cells["Ref"].Value = this.textRefNo.Text;
                }
                if (this.dgvQC_All.Rows[num40].Cells["gatepass_number"].Value == null)
                {
                    this.dgvQC_All.Rows[num40].Cells["gatepass_number"].Value = this.gatepass_no;
                }
                num40++;
            }
            WBTable table2 = new WBTable();
            table2.OpenTable("tollingContract", "SELECT Coy_Tolling FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + ((this.dgvDO.Rows.Count > 0) ? this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString() : "") + "'"), WBData.conn);
            string sCoyTolling = (table2.DT.Rows.Count > 0) ? table2.DT.Rows[0][0].ToString() : "";
            table2.Dispose();
            if (this.textReport_Date.Text != "")
            {
                this.simpanTimbun(this.dgvDO.Rows[0].Cells["tolling"].Value.ToString(), sCoyTolling);
            }
            if (((((this.pMode == "1ST") || ((this.pMode == "2ND") || ((this.pMode == "3RD") || (this.pMode == "4TH")))) && (this.WX != "")) && ((!WBSetting.activeTCS || !this.Copied) || !this.manualCopyfromMainForm)) && (WBSetting.WB_Type == "5"))
            {
                this.wbIndicator.updateCheck0();
            }
            if (WBSetting.gatepass_registration)
            {
                WBTable table17 = new WBTable();
                table17.OpenTable("wb_gatepass", "SELECT * FROM wb_gatepass WHERE " + WBData.CompanyLocation(" AND uniq = '" + this.gatepass_uniq + "'"), WBData.conn);
                if (table17.DT.Rows.Count > 0)
                {
                    DataRow row30 = table17.DT.Rows[0];
                    if ((((row30["WX"].ToString() != "1") || (row30["ref"].ToString() == "")) || (row30["ref"].ToString() == this.textRefNo.Text)) && ((row30["WX"].ToString() != "3") || (this.pMode != "4TH")))
                    {
                        row30.BeginEdit();
                        row30["ref"] = this.textRefNo.Text;
                        row30["Truck_Number"] = this.textTruck.Text;
                        row30["tanker_no"] = this.textTanker.Text;
                        row30["Transporter_Code"] = this.textTransporter.Text;
                        row30["License_No"] = this.textDriverID.Text;
                        if ((row30["WX"].ToString() != "1") || ((row30["WX"].ToString() == "1") && (row30["ref"].ToString() == this.textRefNo.Text)))
                        {
                            row30["delivery_note"] = this.textDN.Text;
                            row30["seal"] = this.textSEAL.Text;
                            row30["remark_ticket"] = this.textRemarkTicket.Text.Trim();
                            row30["remark_report"] = this.textRemarkReport.Text.Trim();
                            row30["addi_info"] = this.txtAddInfo.Text.Trim();
                            row30["nopw"] = this.checkNOPW.Checked ? "Y" : "N";
                            row30["opref"] = this.textWBNo.Text;
                            row30["gross_estate"] = this.textGrossEstate.Text;
                            row30["tare_estate"] = this.textTareEstate.Text;
                            row30["net_estate"] = this.textNetEstate.Text;
                            row30["Delivery_Date"] = this.dateDelivery.Value;
                            row30["Delivery_Time"] = this.TimeDelivery.Text;
                            row30["mark_return"] = this.chk_return.Checked ? "Y" : "N";
                            row30["return_ref"] = this.text_ref_return.Text;
                        }
                        row30.EndEdit();
                        table17.Save();
                        string[] textArray44 = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] textArray45 = new string[] { this.pMode, WBUser.UserID, this.logReason };
                        Program.updateLogHeader("wb_gatepass", row30["uniq"].ToString(), textArray44, textArray45);
                    }
                }
                table17.Dispose();
            }
            if ((this.pMode == "EDIT") && (WBSetting.Field("Check_Email").Trim() == "Y"))
            {
                if (this.editWarning())
                {
                    string[] textArray46 = new string[5];
                    textArray46[0] = ("Dear All,<br><br>This email is to notify you that the following transaction has been edited :<table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name");
                    textArray46[1] = "</tr><tr class='bd'><td nowrap>Date & Time</td><td nowrap> : ";
                    now = DateTime.Now;
                    textArray46[2] = now.ToShortDateString();
                    textArray46[3] = " ";
                    now = DateTime.Now;
                    textArray46[4] = now.ToString("HH:mm:ss");
                    string[] textArray47 = new string[] { (((string.Concat(textArray46) + "</tr><tr class='bd'><td nowrap>Ref Number</td><td nowrap> : " + this.textRefNo.Text) + "</tr><tr class='bd'><td nowrap>Truck Number</td><td nowrap> : " + this.textTruck.Text.Trim()) + "</tr><tr class='bd'><td nowrap>Commodity Code</td><td nowrap> : " + this.textCommodity.Text.Trim()) + "</tr><tr class='bd'><td nowrap>Change Reason</td><td nowrap> : " + this.mChangeReason, "</tr><tr class='bd'><td nowrap>WB User</td><td nowrap> : ", WBUser.UserGroup.Trim(), " ( ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " ) " };
                    string str18 = (((string.Concat(textArray47) + "</tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : " + WBData.sWBCode) + "</tr></table><br><br>~Changes on Data~               ") + "<table border=1 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Field</td><td nowrap>Before Edit</td><td nowrap>After Edit</td></tr>" + this.editTrace) + "</tr></table><br><br>";
                    if (this.editDoTrace.Length > 0)
                    {
                        str18 = str18 + "~Changes On DO No~               <table border=1 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>&nbsp</td><td nowrap>DO No.</td><td nowrap>Quantity Nett</td></tr>" + this.editDoTrace + "</table>";
                    }
                    WBMail mail = new WBMail();
                    mail.SendMail_Edit(str18 + "<br>Thank you.");
                    mail.Dispose();
                }
                WBTable table18 = new WBTable();
                now = DateTime.Now;
                table18.OpenTable("wb_email", "select * from wb_email where " + WBData.CompanyLocation(" and email_code = 'TRANSLOG' and email_date = '" + now.ToString("yyyy-MM-dd") + " 00:00:00' "), WBData.conn);
                if (table18.DT.Rows.Count > 0)
                {
                    if (table18.DT.Rows[0]["Status"].ToString() == "Y")
                    {
                        table18.DR = table18.DT.Rows[0];
                        table18.DR.BeginEdit();
                        table18.DR["Status"] = "N";
                        table18.DR.EndEdit();
                        table18.Save();
                    }
                }
                else
                {
                    table18.DR = table18.DT.NewRow();
                    table18.DR["COY"] = WBData.sCoyCode;
                    table18.DR["LOCATION_CODE"] = WBData.sLocCode;
                    table18.DR["Email_code"] = "TRANSLOG";
                    now = DateTime.Now;
                    table18.DR["Email_date"] = now.ToString("dd/MM/yyyy");
                    table18.DR["Status"] = "N";
                    table18.DT.Rows.Add(table18.DR);
                    table18.Save();
                }
                table18.Dispose();
            }
            if (((this.pMode == "1ST") || ((this.pMode == "2ND") || ((this.pMode == "3RD") || (this.pMode == "4TH")))) ? ((this.indStableWarning == "1") || (this.indStableWarning == "2")) : false)
            {
                WBTable table19 = new WBTable();
                now = DateTime.Now;
                table19.OpenTable("wb_email", "select * from wb_email where " + WBData.CompanyLocation(" and email_code = 'INDICATOR_STABILITY' and email_date = '" + now.ToString("yyyy-MM-dd") + " 00:00:00' "), WBData.conn);
                if (table19.DT.Rows.Count > 0)
                {
                    if (table19.DT.Rows[0]["Status"].ToString() == "Y")
                    {
                        table19.DR = table19.DT.Rows[0];
                        table19.DR.BeginEdit();
                        table19.DR["Status"] = "N";
                        table19.DR.EndEdit();
                        table19.Save();
                    }
                }
                else
                {
                    table19.DR = table19.DT.NewRow();
                    table19.DR["COY"] = WBData.sCoyCode;
                    table19.DR["LOCATION_CODE"] = WBData.sLocCode;
                    table19.DR["Email_code"] = "INDICATOR_STABILITY";
                    table19.DR["Email_date"] = DateTime.Now.ToString("dd/MM/yyyy");
                    table19.DR["Status"] = "N";
                    table19.DT.Rows.Add(table19.DR);
                    table19.Save();
                }
                table19.Dispose();
            }
            string refno = "";
            if (this.printTicket)
            {
                if (this.checkNonContract.Checked)
                {
                    this.print(this.textRefNo.Text.Trim(), this.ticket2Rpt);
                }
                else
                {
                    int num43 = 0;
                    while (true)
                    {
                        if (num43 >= this.dgvDO.Rows.Count)
                        {
                            break;
                        }
                        string str5 = this.dgvDO.Rows[num43].Cells["Do_No"].Value.ToString().Trim();
                        if (num43 <= 0)
                        {
                            refno = this.textRefNo.Text;
                        }
                        else
                        {
                            refno = this.textRefNo.Text + Convert.ToChar((int) (0x40 + num43)).ToString();
                        }
                        if (this.pMode == "1ST")
                        {
                            this.print(refno, str5, this.rpt_advise);
                        }
                        else
                        {
                            this.print(refno, str5, this.ticketRpt);
                        }
                        num43++;
                    }
                }
            }
            if (((this.pMode == "1ST") || ((this.pMode == "2ND") || (this.pMode == "3RD"))) || (this.pMode == "4TH"))
            {
                WBCard.insertToCardLogforWB(this.gatepass_no, this.card_no, this.logRef, this.pMode);
            }
            if (((WBSetting.bGate == "Y") & (this.pMode != "EDIT")) & (this.WX != ""))
            {
                if (WBSetting.activeTCS)
                {
                    WBBarrierGate3.openGate("1");
                }
                else
                {
                    if (((this.pMode == "1ST") || (this.pMode == "3RD")) & (this.WX != ""))
                    {
                        if ((WBSetting.gateType == "1") || (WBSetting.gateType == ""))
                        {
                            WBBarrierGate1.runGate(WBSetting.gate2Open);
                        }
                        else if (WBSetting.gateType == "2")
                        {
                            this.returnGate = false;
                            while (true)
                            {
                                if (this.returnGate)
                                {
                                    break;
                                }
                                Cursor.Current = Cursors.WaitCursor;
                                this.returnGate = WBBarrierGate2.openGate(WBSetting.gate2IP, WBSetting.gate2Port);
                                if (!this.returnGate)
                                {
                                    MessageBox.Show("Error open gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                            }
                        }
                    }
                    if (((this.pMode == "2ND") || (this.pMode == "4TH")) & (this.WX != ""))
                    {
                        if ((WBSetting.gateType == "1") || (WBSetting.gateType == ""))
                        {
                            WBBarrierGate1.runGate(WBSetting.gate2OpenOut);
                        }
                        else if (WBSetting.gateType == "2")
                        {
                            this.returnGate = false;
                            while (true)
                            {
                                if (this.returnGate)
                                {
                                    break;
                                }
                                Cursor.Current = Cursors.WaitCursor;
                                this.returnGate = WBBarrierGate2.openGate(WBSetting.gate2IPOut, WBSetting.gate2PortOut);
                                if (!this.returnGate)
                                {
                                    MessageBox.Show("Error open gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                            }
                        }
                    }
                }
                if ((this.pMode != "QC") && !WBSetting.activeTCS)
                {
                    while (true)
                    {
                        MessageBox.Show("Close Barrier Gate? ", "B A R R I E R   G A T E", MessageBoxButtons.OK);
                        if (WBSetting.WB_Type == "5")
                        {
                            this.wbIndicator.Init();
                            this.wbIndicator.checkStatus();
                            if (!this.wbIndicator.check0())
                            {
                                MessageBox.Show("Can't close gate due to indicator is not 0 (truck is still on weighbridge)!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                continue;
                            }
                        }
                        else
                        {
                            this.nKg = -999;
                            this.nKg = WBSetting.CheckZero();
                            if (this.nKg != 0)
                            {
                                MessageBox.Show("Can't close gate due to indicator is not 0 (truck is still on weighbridge)!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                continue;
                            }
                        }
                        break;
                    }
                }
                if ((((this.pMode == "1ST") || (this.pMode == "3RD")) & (this.WX != "")) && !WBSetting.activeTCS)
                {
                    if ((WBSetting.gateType == "1") || (WBSetting.gateType == ""))
                    {
                        WBBarrierGate1.runGate(WBSetting.gate2Close);
                    }
                    else if (WBSetting.gateType == "2")
                    {
                        this.returnGate = false;
                        while (true)
                        {
                            if (this.returnGate)
                            {
                                break;
                            }
                            Cursor.Current = Cursors.WaitCursor;
                            this.returnGate = WBBarrierGate2.closeGate(WBSetting.gate2IP, WBSetting.gate2Port);
                            if (!this.returnGate)
                            {
                                MessageBox.Show("Error close gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                        }
                    }
                }
                if ((((this.pMode == "2ND") || (this.pMode == "4TH")) & (this.WX != "")) && !WBSetting.activeTCS)
                {
                    if ((WBSetting.gateType == "1") || (WBSetting.gateType == ""))
                    {
                        WBBarrierGate1.runGate(WBSetting.gate2CloseOut);
                    }
                    else if (WBSetting.gateType == "2")
                    {
                        this.returnGate = false;
                        while (true)
                        {
                            if (this.returnGate)
                            {
                                break;
                            }
                            Cursor.Current = Cursors.WaitCursor;
                            this.returnGate = WBBarrierGate2.closeGate(WBSetting.gate2IPOut, WBSetting.gate2PortOut);
                            if (!this.returnGate)
                            {
                                MessageBox.Show("Error close gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                        }
                    }
                }
            }
            this.Cursor = Cursors.Default;
            return this.Saved;
        TR_01AB:
            if (this.spMode == "EDIT")
            {
                WBTable table11 = new WBTable();
                table11.OpenTable("wb_templateSAP", "SELECT distinct Table_Name, Field_Wb FROM wb_templateSAP WHERE " + WBData.CompanyLocation(" and modul = 'ZWB' and (important = 'N') and Table_Name = 'wb_transaction'"), WBData.conn);
                bool flag285 = false;
                foreach (DataRow row23 in table11.DT.Rows)
                {
                    try
                    {
                        if (this.transBefore[row23["Field_Wb"].ToString().Trim()].ToString().Trim() != this.tblTrans.DR[row23["Field_Wb"].ToString().Trim()].ToString().Trim())
                        {
                            flag285 = true;
                        }
                    }
                    catch (Exception)
                    {
                    }
                }
                this.tblTrans.DR["reposted"] = !flag285 ? "Y" : "N";
            }
            if (this.pMode == "1ST")
            {
                this.tblTrans.DR["transWarning"] = this.indStableWarning + "000";
            }
            else if (this.pMode == "2ND")
            {
                if (this.tblTrans.DR["transWarning"].ToString().Length == 0)
                {
                    this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString() + "0000";
                }
                if (this.tblTrans.DR["transWarning"].ToString().Length == 1)
                {
                    this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString() + "000";
                }
                this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString().Remove(1, 1).Insert(1, this.indStableWarning);
            }
            else if (this.pMode == "3RD")
            {
                if (this.tblTrans.DR["transWarning"].ToString().Length < 3)
                {
                    this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString() + "00";
                }
                this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString().Remove(2, 1).Insert(2, this.indStableWarning);
            }
            else if (this.pMode == "4TH")
            {
                string str11 = this.tblTrans__.DT.Rows[0]["transWarning"].ToString().Substring(0, 1);
                if (this.tblTrans.DR["transWarning"].ToString().Length < 3)
                {
                    this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString() + "00";
                }
                this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString().Remove(2, 1).Insert(2, str11);
                if (this.tblTrans.DR["transWarning"].ToString().Length < 4)
                {
                    this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString() + "0";
                }
                this.tblTrans.DR["transWarning"] = this.tblTrans.DR["transWarning"].ToString().Remove(3, 1).Insert(3, this.indStableWarning);
            }
            if (this.CloseDO != null)
            {
                Program.AutoCloseDO(this.CloseDO);
            }
            now = Convert.ToDateTime(this.tblTrans.DR["Date1"].ToString());
            this.logDate1 = now.ToString("yyyy-MM-dd HH:mm:ss");
            this.logTime1 = this.tblTrans.DR["Time1"].ToString();
            this.logRef = this.tblTrans.DR["Ref"].ToString();
            this.tblTrans.Save();
            this.logKeyField = this.sUniq;
            if (((this.pMode != "1ST") || !this.tambahRecord) ? (this.pMode == "MANUAL") : true)
            {
                string sqltext = ((((("" + "SELECT uniq FROM wb_transaction WHERE " + WBData.CompanyLocation("")) + " AND Ref = '" + this.logRef + "' ") + " AND Date1 = '" + this.logDate1 + "' ") + " AND Time1 = '" + this.logTime1 + "' ") + " AND Create_by = '" + WBUser.UserID + "' ") + " AND WBCode1 = '" + WBData.sWBCode + "' ";
                WBTable table12 = new WBTable();
                table12.OpenTable("wb_transaction", sqltext, WBData.conn);
                this.logKeyField = table12.DT.Rows[0]["uniq"].ToString();
                table12.Dispose();
                this.sUniq = this.logKeyField;
            }
            this.logMode = this.pMode;
            if ((this.spMode == "QTY") || (this.spMode == "EDIT_OPW"))
            {
                this.logMode = this.spMode;
            }
            this.logReason = this.mChangeReason;
            if (this.logMode == "SPLIT")
            {
                this.logReason = "Split Transaction";
            }
            else if (this.logMode == "QC")
            {
                this.logReason = "Entry Quality Control";
            }
            else if (this.logMode == "GRADING")
            {
                this.logReason = "Entry Grading & Division/Block";
            }
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { this.logMode, WBUser.UserID, this.logReason };
            Program.updateLogHeader("wb_transaction", this.logKeyField, logField, logValue);
            if (this.dgvDO.Rows.Count > 1)
            {
                this.saveTransSplit(this.sUniq);
            }
            this.Saved = true;
            if (((WBSetting.checkOutSpec == "Y") && (this.transType == "I")) && (((this.pMode == "EDIT") || (this.spMode == "QTY")) || (this.pMode == "QC")))
            {
                WBTable table13 = new WBTable();
                table13.OpenTable("wb_transQC", "SELECT * FROM wb_transQC WHERE " + WBData.CompanyLocation(" AND ref='" + this.textRefNo.Text + "'"), WBData.conn);
                if (this.textReport_Date.Text != "")
                {
                    bool flag306 = false;
                    int num29 = 0;
                    while (true)
                    {
                        if (num29 >= this.dgvQC_All.Rows.Count)
                        {
                            break;
                        }
                        string[] aField = new string[] { "Coy", "Location_Code", "Comm_Code", "QCode" };
                        string[] textArray35 = new string[] { WBData.sCoyCode, WBData.sLocCode, this.dgvQC.Rows[num29].Cells["Comm_Code"].Value.ToString(), this.dgvQC.Rows[num29].Cells["QCode"].Value.ToString() };
                        DataRow data = this.tblCommD.GetData(aField, textArray35);
                        if (Convert.ToBoolean(data["checked"].ToString()))
                        {
                            double num30 = Program.StrToDouble(this.dgvQC.Rows[num29].Cells["Factory"].Value.ToString(), 3);
                            double num31 = Program.StrToDouble(this.dgvQC.Rows[num29].Cells["SAP_Value"].Value.ToString(), 3);
                            if ((table13.DT.Rows[num29]["Factory"].ToString() != this.dgvQC.Rows[num29].Cells["Factory"].Value.ToString()) && ((num30 > num31) && !(num31 == 0.0)))
                            {
                                flag306 = true;
                                break;
                            }
                        }
                        num29++;
                    }
                    if (flag306)
                    {
                        now = Convert.ToDateTime(this.textReport_Date.Text);
                        this.tblEmail.OpenTable("wb_email", "SELECT * FROM wb_email WHERE " + WBData.CompanyLocation(" AND email_code = 'REP_QC' AND Email_Date = '" + now.ToString("yyyy-MM-dd") + "'"), WBData.conn);
                        if (this.tblEmail.DT.Rows.Count > 0)
                        {
                            if (this.tblEmail.DT.Rows[0]["Status"].ToString() == "Y")
                            {
                                this.tblEmail.DR = this.tblEmail.DT.Rows[0];
                                this.tblEmail.DR.BeginEdit();
                                this.tblEmail.DR["Status"] = "N";
                                this.tblEmail.DR.EndEdit();
                                this.tblEmail.Save();
                            }
                        }
                        else
                        {
                            this.tblEmail.DR = this.tblEmail.DT.NewRow();
                            this.tblEmail.DR["Coy"] = WBData.sCoyCode;
                            this.tblEmail.DR["Location_Code"] = WBData.sLocCode;
                            this.tblEmail.DR["Email_code"] = "REP_QC";
                            now = Convert.ToDateTime(this.textReport_Date.Text);
                            this.tblEmail.DR["Email_date"] = now.ToString("yyyy-MM-dd");
                            this.tblEmail.DR["Status"] = "N";
                            this.tblEmail.DT.Rows.Add(this.tblEmail.DR);
                            this.tblEmail.Save();
                        }
                    }
                    this.tblEmail.Dispose();
                }
                table13.Dispose();
            }
            if (((WBUser.UserLevel != "1") && (WBSetting.Field("GM") == "Y")) && (this.pMode == "MANUAL"))
            {
                WBTable table14 = new WBTable();
                table14.OpenTable("wb_loc", "select coy, location_code, tokenManual, maxEntry, currEntry, checksum, uniq from wb_location", WBData.conn);
                if (table14.DT.Rows.Count > 0)
                {
                    table14.DR = table14.DT.Rows[0];
                    string str13 = "";
                    str13 = Program.shoot(table14.DR["CurrEntry"].ToString(), false);
                    table14.DR = table14.DT.Rows[0];
                    table14.DR.BeginEdit();
                    table14.DR["CurrEntry"] = Program.shoot((Convert.ToDouble(str13) + 1.0).ToString(), true);
                    table14.DR["checksum"] = table14.Checksum(table14.DR);
                    table14.DR.EndEdit();
                    table14.Save();
                }
                table14.Dispose();
            }
            this.tblTransDO.ReOpen();
            str2 = "";
            num2 = 0x40;
            num3 = 0;
            if (this.tblTransDO.DT.Rows.Count > 0)
            {
                string[] aField = new string[] { "ref" };
                string[] textArray37 = new string[] { this.textRefNo.Text + "A" };
                this.tblTrans.DR = this.tblTrans.GetData(aField, textArray37);
                using (IEnumerator enumerator15 = this.tblTransDO.DT.Rows.GetEnumerator())
                {
                    DataRow current;
                    int num33;
                    goto TR_015C;
                TR_014E:
                    num33 = (num33 + Convert.ToInt16(WBData.sCoyCode.Trim().ToString().Length)) + Convert.ToInt16(WBData.sLocCode.Trim().ToString().Length);
                    if (current["Ref"].ToString().Substring(0, num33) == this.textRefNo.Text)
                    {
                        current.Delete();
                    }
                TR_015C:
                    while (true)
                    {
                        if (enumerator15.MoveNext())
                        {
                            current = (DataRow) enumerator15.Current;
                            if (current["Ref"].ToString() == this.textRefNo.Text)
                            {
                                current.Delete();
                                continue;
                            }
                            if (current["Ref"].ToString() == "")
                            {
                                current.Delete();
                                continue;
                            }
                            if (this.tblTrans.DR != null)
                            {
                                continue;
                            }
                            num33 = 7;
                            if ((WBSetting.Ref6 == "Y") && (WBSetting.date6 != ""))
                            {
                                try
                                {
                                    now = Convert.ToDateTime(this.textRef_Date.Text);
                                    now = Convert.ToDateTime(WBSetting.date6);
                                    if (Convert.ToDateTime(now.ToShortDateString()) >= Convert.ToDateTime(now.ToShortDateString()))
                                    {
                                        num33 = 6;
                                    }
                                }
                                catch
                                {
                                    num33 = 7;
                                }
                            }
                        }
                        else
                        {
                            this.tblTransDO.Save();
                            string[] textArray38 = new string[] { "ref" };
                            string[] textArray39 = new string[] { this.textRefNo.Text };
                            this.tblTrans.DR = this.tblTrans.GetData(textArray38, textArray39);
                            goto TR_0149;
                        }
                        break;
                    }
                    goto TR_014E;
                }
            }
            goto TR_0149;
        TR_0269:
            this.tblTrans.DR["Coy"] = WBData.sCoyCode;
            this.tblTrans.DR["Location_Code"] = WBData.sLocCode;
            this.tblTrans.DR["Ref"] = this.textRefNo.Text.Trim();
            if (this.pMode == "1ST")
            {
                if ((this.text1st.Text.Trim() == "0") && ((!WBSetting.activeTCS || !this.Copied) || !this.manualCopyfromMainForm))
                {
                    this.WX = "";
                }
                this.tblTrans.DR["WX"] = this.WX;
                this.tblTrans.DR["Date1"] = this.textDate1st.Text;
                this.tblTrans.DR["Time1"] = this.textTime1st.Text;
                this.tblTrans.DR["_1st"] = this.text1st.Text;
                this.tblTrans.DR["WBCode1"] = WBSetting.WBCode;
                this.tblTrans.DR["Ref_Date"] = Convert.ToDateTime(this.textRef_Date.Text);
                this.tblTrans.DR["_2nd"] = "0";
                this.tblTrans.DR["_3rd"] = "0";
                this.tblTrans.DR["_4th"] = "0";
                if (this.TimeRegister.Text != "")
                {
                    if (!((WBSetting.activeTCS && this.Copied) && this.manualCopyfromMainForm))
                    {
                        this.tblTrans.DR["Register_Time"] = this.TimeRegister.Text;
                    }
                    else
                    {
                        now = DateTime.Now;
                        this.tblTrans.DR["Register_Time"] = now.ToShortTimeString();
                    }
                }
                if (this.dateRegister.Text != "")
                {
                    if (!((WBSetting.activeTCS && this.Copied) && this.manualCopyfromMainForm))
                    {
                        this.tblTrans.DR["Register_Date"] = this.dateRegister.Text;
                    }
                    else
                    {
                        now = DateTime.Now;
                        this.tblTrans.DR["Register_Date"] = now.ToShortDateString();
                    }
                }
                if (this.tblTrans.DR["Register_By"].ToString() == "")
                {
                    this.tblTrans.DR["Register_By"] = WBUser.UserID;
                }
                if ((((this.WX == "2X") || (this.WX == "4X")) || (this.WX == "1X")) & WBSetting.gatepass_registration)
                {
                    this.tblTrans.DR["gatepass_number"] = this.gatepass_no;
                    this.tblTrans.DR["Register_By"] = this.register_by;
                }
            }
            else if (this.pMode == "2ND")
            {
                this.tblTrans.DR["Date2"] = this.textDate2nd.Text;
                this.tblTrans.DR["Time2"] = this.textTime2nd.Text;
                this.tblTrans.DR["_2nd"] = this.text2nd.Text;
                this.tblTrans.DR["WBCode2"] = WBSetting.WBCode;
                if (this.WX == "2X")
                {
                    this.textReport_Date.Text = WBSetting.WorkingTime(this.textDate2nd.Text, this.textTime2nd.Text);
                    this.tblTrans.DR["Report_Date"] = this.textReport_Date.Text;
                }
                if (!this.checkNonContract.Checked)
                {
                    if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                    {
                        string[] textArray25 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(true) };
                        this.textDN.Text = string.Concat(textArray25);
                    }
                    else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                    {
                        string[] textArray26 = new string[] { WBData.sCoyCode.Trim(), "/", this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString().Trim(), "/", this.SetNoSPB(true) };
                        this.textDN.Text = string.Concat(textArray26);
                    }
                }
            }
            else if (this.pMode == "3RD")
            {
                this.tblTrans.DR["Date3"] = this.textDate3rd.Text;
                this.tblTrans.DR["Time3"] = this.textTime3rd.Text;
                this.tblTrans.DR["_3rd"] = this.text3rd.Text;
                this.tblTrans.DR["WBCode3"] = WBSetting.WBCode;
            }
            else if (this.pMode == "4TH")
            {
                this.tblTrans.DR["Date3"] = this.textDate3rd.Text;
                this.tblTrans.DR["Time3"] = this.textTime3rd.Text;
                this.tblTrans.DR["_3rd"] = this.text3rd.Text;
                this.tblTrans.DR["WBCode3"] = this.tblTrans__.DT.Rows[0]["WBCode1"].ToString();
                this.tblTrans.DR["Date4"] = this.textDate4th.Text;
                this.tblTrans.DR["Time4"] = this.textTime4th.Text;
                this.tblTrans.DR["_4th"] = this.text4th.Text;
                this.tblTrans.DR["WBCode4"] = WBSetting.WBCode;
                this.tblTrans.DR["Report_Date"] = WBSetting.WorkingTime(this.textDate4th.Text, this.textTime4th.Text);
            }
            else if (this.pMode == "EDIT")
            {
                if (this.textDate1st.Text != "")
                {
                    this.tblTrans.DR["Date1"] = this.textDate1st.Text;
                }
                this.tblTrans.DR["Time1"] = this.textTime1st.Text;
                if (this.textDate2nd.Text != "")
                {
                    this.tblTrans.DR["Date2"] = this.textDate2nd.Text;
                }
                this.tblTrans.DR["Time2"] = this.textTime2nd.Text;
                if (this.textDate3rd.Text != "")
                {
                    this.tblTrans.DR["Date3"] = this.textDate3rd.Text;
                }
                this.tblTrans.DR["Time3"] = this.textTime3rd.Text;
                if (this.textDate4th.Text != "")
                {
                    this.tblTrans.DR["Date4"] = this.textDate4th.Text;
                }
                this.tblTrans.DR["Time4"] = this.textTime4th.Text;
                this.tblTrans.DR["_1st"] = this.text1st.Text;
                this.tblTrans.DR["_2nd"] = this.text2nd.Text;
                this.tblTrans.DR["_3rd"] = this.text3rd.Text;
                this.tblTrans.DR["_4th"] = this.text4th.Text;
                if (this.textReport_Date.Text.Trim() != "")
                {
                    this.tblTrans.DR["Report_Date"] = this.textReport_Date.Text;
                }
                else if (((this.textDate2nd.Text.Trim() == "") || (this.WX != "2X")) ? ((this.textDate4th.Text.Trim() != "") && (this.WX == "4X")) : true)
                {
                    this.tblTrans.DR["Report_Date"] = WBSetting.WorkingTime(this.textDate2nd.Text, this.textTime2nd.Text);
                    this.textReport_Date.Text = this.tblTrans.DR["Report_Date"].ToString();
                }
            }
            else if (this.pMode == "MANUAL")
            {
                this.tblTrans.DR["WX"] = this.WX;
                this.tblTrans.DR["Ref"] = this.textRefNo.Text.Trim();
                this.tblTrans.DR["Date1"] = this.textDate1st.Text;
                this.tblTrans.DR["Time1"] = this.textTime1st.Text;
                this.tblTrans.DR["_1st"] = this.text1st.Text;
                this.tblTrans.DR["WBCode1"] = WBSetting.WBCode;
                this.tblTrans.DR["WBCode2"] = WBSetting.WBCode;
                this.tblTrans.DR["Ref_Date"] = Convert.ToDateTime(this.textRef_Date.Text);
                this.tblTrans.DR["Manual"] = "Y";
                if (this.TimeRegister.Text != "")
                {
                    this.tblTrans.DR["Register_Time"] = this.TimeRegister.Text;
                }
                if (this.dateRegister.Text != "")
                {
                    this.tblTrans.DR["Register_Date"] = this.dateRegister.Text;
                }
                if (this.textDate1st.Text != "")
                {
                    this.tblTrans.DR["Date1"] = this.textDate1st.Text;
                }
                this.tblTrans.DR["Time1"] = this.textTime1st.Text;
                if (this.textDate2nd.Text != "")
                {
                    this.tblTrans.DR["Date2"] = this.textDate2nd.Text;
                }
                this.tblTrans.DR["Time2"] = this.textTime2nd.Text;
                if (this.textDate3rd.Text != "")
                {
                    this.tblTrans.DR["Date3"] = this.textDate3rd.Text;
                }
                this.tblTrans.DR["Time3"] = this.textTime3rd.Text;
                if (this.textDate4th.Text != "")
                {
                    this.tblTrans.DR["Date4"] = this.textDate4th.Text;
                }
                this.tblTrans.DR["Time4"] = this.textTime4th.Text;
                this.tblTrans.DR["_1st"] = this.text1st.Text;
                this.tblTrans.DR["_2nd"] = this.text2nd.Text;
                this.tblTrans.DR["_3rd"] = this.text3rd.Text;
                this.tblTrans.DR["_4th"] = this.text4th.Text;
                if (this.textReport_Date.Text.Trim() != "")
                {
                    this.tblTrans.DR["Report_Date"] = this.textReport_Date.Text;
                }
                else if (((this.textDate2nd.Text.Trim() == "") || (this.WX != "2X")) ? ((this.textDate4th.Text.Trim() != "") && (this.WX == "4X")) : true)
                {
                    this.tblTrans.DR["Report_Date"] = WBSetting.WorkingTime(this.textDate2nd.Text, this.textTime2nd.Text);
                    this.textReport_Date.Text = this.tblTrans.DR["Report_Date"].ToString();
                }
            }
            if (!this.checkISCC.Checked)
            {
                this.tblTrans.DR["ISCC_Checked"] = 'N';
                this.tblTrans.DR["ISCC_No"] = "";
                this.tblTrans.DR["ISCC_GC_Checked"] = 'N';
                this.tblTrans.DR["ISCC_Weight"] = 0;
            }
            else if (this.pMode == "1ST")
            {
                this.tblTrans.DR["ISCC_Checked"] = "Y";
                this.tblTrans.DR["ISCC_No"] = this.textISCC.Text;
                this.tblTrans.DR["ISCC_GC_Checked"] = this.radioGHG1.Checked ? "Y" : "N";
                if (this.radioGHG2.Checked)
                {
                    this.tblTrans.DR["ISCC_Weight"] = Convert.ToDouble(this.textGHG.Text);
                }
            }
            else if ((this.pMode != "1ST") && (this.pMode != "CANCEL"))
            {
                this.tblTrans.DR["ISCC_Checked"] = "Y";
                if (this.tblTrans.DR["ISCC_No"].ToString().Trim() == "")
                {
                    this.tblTrans.DR["ISCC_No"] = this.textISCC.Text.Trim();
                }
                if ((this.tblTrans.DR["ISCC_No2"].ToString().Trim() == "") && (this.textCommodity.Text.Trim().ToUpper() == "CPO"))
                {
                    this.tblTrans.DR["ISCC_No2"] = this.SetNoISCC(true);
                    this.textISCC2.Text = this.tblTrans.DR["ISCC_No2"].ToString();
                }
                this.tblTrans.DR["ISCC_GC_Checked"] = this.radioGHG1.Checked ? "Y" : "N";
                if (this.radioGHG2.Checked)
                {
                    this.tblTrans.DR["ISCC_Weight"] = Convert.ToDouble(this.textGHG.Text);
                }
            }
            this.tblTrans.DR["Approve"] = this.approve;
            this.tblTrans.DR["approveBy1"] = this.approveBy1;
            this.tblTrans.DR["approveBy2"] = this.approveBy2;
            this.tblTrans.DR["Approve_Reason"] = this.ApproveReason;
            this.tblTrans.DR["Approve_type"] = this.approve_type;
            if (!((WBSetting.activeTCS && this.Copied) && this.manualCopyfromMainForm))
            {
                this.tblTrans.DR["Delivery_Date"] = this.dateDelivery.Value;
                this.tblTrans.DR["Delivery_Time"] = this.TimeDelivery.Text;
                this.tblTrans.DR["Delivery_Date2"] = this.dateDelivery2.Value;
                this.tblTrans.DR["Delivery_Time2"] = this.TimeDelivery2.Text;
            }
            else
            {
                now = DateTime.Now;
                this.tblTrans.DR["Delivery_Date"] = now.ToShortDateString();
                now = DateTime.Now;
                this.tblTrans.DR["Delivery_Time"] = now.ToShortTimeString();
                now = DateTime.Now;
                this.tblTrans.DR["Delivery_Date2"] = now.ToShortDateString();
                this.tblTrans.DR["Delivery_Time2"] = DateTime.Now.ToShortTimeString();
            }
            this.tblTrans.DR["EstateDiff"] = this.checkEstate.Checked ? "Y" : "N";
            this.tblTrans.DR["Comm_Code"] = this.textCommodity.Text;
            this.tblTrans.DR["DO_NO"] = (this.dgvDO.Rows.Count > 0) ? this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString() : "";
            this.tblTrans.DR["PI_NO"] = (this.dgvDO.Rows.Count > 0) ? this.dgvDO.Rows[0].Cells["PI_NO"].Value.ToString() : "";
            this.tblTrans.DR["tolling"] = (this.dgvDO.Rows.Count > 0) ? this.dgvDO.Rows[0].Cells["tolling"].Value.ToString() : "N";
            this.tblTrans.DR["zAuto"] = "N";
            this.tblTrans.DR["Transaction_Code"] = this.comboTransType.Text;
            this.tblTrans.DR["relation_Code"] = this.textCust.Text;
            this.tblTrans.DR["Truck_Number"] = this.textTruck.Text;
            this.tblTrans.DR["Truck_Number2"] = this.textTruck2.Text;
            this.tblTrans.DR["Truck_Trailer_Number"] = this.textTrailerNo.Text;
            this.tblTrans.DR["Tanker"] = this.textTanker.Text;
            this.tblTrans.DR["TankQC"] = this.textTankQC.Text;
            this.tblTrans.DR["Storage"] = this.textStorage.Text;
            this.tblTrans.DR["Rend_CPO"] = this.textRendCPO.Text;
            this.tblTrans.DR["FFB_Grade"] = this.textGrade.Text;
            this.tblTrans.DR["License_No"] = this.textDriverID.Text;
            this.tblTrans.DR["Name"] = this.labelDriverName.Text;
            this.tblTrans.DR["Transporter_Code"] = this.textTransporter.Text;
            this.tblTrans.DR["Delivery_Note"] = this.textDN.Text;
            this.tblTrans.DR["Unloading"] = this.textUnloading.Text;
            this.tblTrans.DR["Remark_Ticket"] = this.textRemarkTicket.Text;
            this.tblTrans.DR["Remark_Report"] = this.textRemarkReport.Text;
            this.tblTrans.DR["PL3_No"] = this.textPL3.Text;
            this.tblTrans.DR["Addi_Info"] = this.txtAddInfo.Text;
            this.tblTrans.DR["Seal"] = this.textSEAL.Text;
            this.tblTrans.DR["Estate"] = this.textEstate.Text;
            this.tblTrans.DR["Ticket"] = this.textWBNo.Text;
            this.tblTrans.DR["NonContract"] = this.checkNonContract.Checked ? "Y" : "N";
            this.tblTrans.DR["NOPW"] = this.checkNOPW.Checked ? "Y" : "N";
            this.tblTrans.DR["TBS_Reject"] = this.textTBSReject.Text;
            this.tblTrans.DR["Reason"] = this.textReason.Text;
            this.tblTrans.DR["TotalGunny"] = Convert.ToDouble(this.textGunnyBatch.Text);
            this.tblTrans.DR["MaterialStuffing"] = Convert.ToInt32(this.txtMS.Text);
            if (this.printTicket)
            {
                this.tblTrans.DR["printed"] = "1";
            }
            this.tblTrans.DR["Gross_Estate"] = Convert.ToDouble(this.textGrossEstate.Text);
            this.tblTrans.DR["Tare_Estate"] = Convert.ToDouble(this.textTareEstate.Text);
            this.tblTrans.DR["Net_Estate"] = Convert.ToDouble(this.textNetEstate.Text);
            if (this.chk_return.Checked)
            {
                this.tblTrans.DR["mark_return"] = "X";
                this.tblTrans.DR["return_ref"] = this.text_ref_return.Text.Trim();
            }
            if ((this.WX == "2X") || ((this.WX == "4X") && ((this.pMode == "1ST") || (this.pMode == "2ND"))))
            {
                if (Convert.ToDouble(this.text1st.Text) > Convert.ToDouble(this.text2nd.Text))
                {
                    this.tblTrans.DR["Gross"] = Convert.ToDouble(this.text1st.Text);
                    this.tblTrans.DR["Tare"] = Convert.ToDouble(this.text2nd.Text);
                }
                else
                {
                    this.tblTrans.DR["Gross"] = Convert.ToDouble(this.text2nd.Text);
                    this.tblTrans.DR["Tare"] = Convert.ToDouble(this.text1st.Text);
                }
            }
            else
            {
                this.sTransType = "";
                if (this.comboTransType.Text != "")
                {
                    string[] aField = new string[] { "Transaction_Code" };
                    string[] textArray28 = new string[] { this.comboTransType.Text };
                    this.sTransType = this.tblTransType.GetData(aField, textArray28)["IO"].ToString();
                }
                if (this.sTransType == "I")
                {
                    this.tblTrans.DR["Gross"] = Convert.ToDouble(this.text1st.Text);
                    this.tblTrans.DR["Tare"] = (Convert.ToDouble(this.text4th.Text) - Convert.ToDouble(this.text3rd.Text)) + Convert.ToDouble(this.text2nd.Text);
                }
                else
                {
                    this.tblTrans.DR["Gross"] = Convert.ToDouble(this.text4th.Text);
                    this.tblTrans.DR["Tare"] = (Convert.ToDouble(this.text1st.Text) - Convert.ToDouble(this.text2nd.Text)) + Convert.ToDouble(this.text3rd.Text);
                }
            }
            this.tblTrans.DR["Received"] = Convert.ToDouble(this.textNET2.Text);
            this.tblTrans.DR["Deduction"] = Convert.ToDouble(this.textDeducTotal.Text);
            this.tblTrans.DR["Net"] = Convert.ToDouble(this.textNet.Text);
            this.tblTrans.DR["TotalBunch"] = Convert.ToDouble(this.textBunchTotal.Text);
            this.tblTrans.DR["TotalBunchGrading"] = Convert.ToDouble(this.textBunchDeduc.Text);
            if (this.WX != "1X")
            {
                this.dgvDO.Rows[0].Cells["DeducUnitQty"].Value = (this.dgvDO.Rows[0].Cells["DeducUnitQty"].Value == null) ? "0" : this.dgvDO.Rows[0].Cells["DeducUnitQty"].Value;
                if (Program.StrToDouble(this.dgvDO.Rows[0].Cells["DeducUnitQty"].Value.ToString(), 2) > 0.0)
                {
                    this.tblTrans.DR["TotalBunch"] = this.dgvDO.Rows[0].Cells["DeducUnitQty"].Value.ToString();
                    this.tblTrans.DR["TotalBunchGrading"] = this.dgvDO.Rows[0].Cells["DeducUnitQty"].Value.ToString();
                    this.tblTrans.DR["WeightPerUnitName"] = this.dgvDO.Rows[0].Cells["WeightPerUnitName"].Value.ToString();
                    this.tblTrans.DR["UnitName"] = this.dgvDO.Rows[0].Cells["UnitName"].Value.ToString();
                }
            }
            this.tblTrans.DR["Average"] = Convert.ToDouble(this.textAvg.Text);
            this.tblTrans.DR["Fruits_Type"] = this.textFruitsType.Text;
            this.tblTrans.DR["entryAVGorBunch"] = this.radioButtonEntryTotalBunch.Checked ? "1" : "0";
            if (this.weighDifferent)
            {
                this.tblTrans.DR["ChangeReason"] = this.mChangeReason;
            }
            if ((this.pMode == "1ST") || (this.pMode == "MANUAL"))
            {
                this.tblTrans.DR["Create_By"] = WBUser.UserID;
                this.tblTrans.DR["Create_Date"] = DateTime.Now;
                if (this.tambahRecord)
                {
                    this.tblTrans.DT.Rows.Add(this.tblTrans.DR);
                }
                else
                {
                    this.tblTrans.DR.EndEdit();
                }
            }
            else
            {
                if (this.pMode == "EDIT")
                {
                    this.tblTrans.DR["ChangeReason"] = this.mChangeReason;
                    this.tblTrans.DR["Edit_By"] = WBUser.UserID;
                    this.tblTrans.DR["Edit_Date"] = DateTime.Now;
                    if ((this.pMode == "EDIT") && (this.spMode != "QTY"))
                    {
                        this.tblTrans.DR["Edit_Data"] = (this.tblTrans.DR["Edit_Data"].ToString() != "") ? (Convert.ToInt16(this.tblTrans.DR["Edit_Data"].ToString()) + 1).ToString() : "1";
                    }
                    else if ((this.pMode == "EDIT") && (this.spMode == "QTY"))
                    {
                        this.tblTrans.DR["Edit_Qty"] = (this.tblTrans.DR["Edit_Qty"].ToString() != "") ? (Convert.ToInt16(this.tblTrans.DR["Edit_Qty"].ToString()) + 1).ToString() : "1";
                    }
                }
                else if (((this.pMode == "QC") || (this.pMode == "SPLIT")) || (this.pMode == "GRADING"))
                {
                    this.tblTrans.DR["Edit_By"] = WBUser.UserID;
                    this.tblTrans.DR["Edit_Date"] = DateTime.Now;
                }
                else if (this.pMode != "CANCEL")
                {
                    this.tblTrans.DR["Change_By"] = WBUser.UserID;
                    this.tblTrans.DR["Change_Date"] = DateTime.Now;
                }
                else
                {
                    this.tblTrans.DR["ChangeReason"] = this.mChangeReason;
                    this.tblTrans.DR["Deleted"] = "Y";
                    this.tblTrans.DR["Delete_By"] = WBUser.UserID;
                    this.tblTrans.DR["Delete_Date"] = Program.DTOC(DateTime.Now);
                }
                this.tblTrans.DR.EndEdit();
            }
            this.tblTrans.DR["checksum"] = this.tblTrans.Checksum(this.tblTrans.DR);
            if (this.spMode != "EDIT_OPW")
            {
                if (this.pMode != "QC")
                {
                    if (WBSetting.zwb == "Y")
                    {
                        WBTable table8 = new WBTable();
                        table8.OpenTable("wb_templateSAP", "SELECT distinct Table_Name, Field_Wb FROM wb_templateSAP WHERE " + WBData.CompanyLocation(" and modul = 'ZWB' and (important is null or important = '' or important = 'Y') and Table_Name = 'wb_transaction' and field_wb is not null"), WBData.conn);
                        bool flag272 = false;
                        foreach (DataRow row19 in table8.DT.Rows)
                        {
                            if (this.tblTrans.DR["posted"].ToString() == "N")
                            {
                                flag272 = true;
                            }
                            else
                            {
                                if (!ReferenceEquals(this.transBefore, null))
                                {
                                    try
                                    {
                                        if (this.transBefore[row19["Field_Wb"].ToString().Trim()].ToString().Trim() != this.tblTrans.DR[row19["Field_Wb"].ToString().Trim()].ToString().Trim())
                                        {
                                            flag272 = true;
                                        }
                                    }
                                    catch (Exception)
                                    {
                                    }
                                    continue;
                                }
                                flag272 = true;
                            }
                            break;
                        }
                        if (!flag272)
                        {
                            this.tblTrans.DR["posted"] = "Y";
                        }
                        else
                        {
                            this.tblTrans.DR["posted"] = "N";
                            this.tblTrans.DR["reposted"] = "N";
                        }
                    }
                    else
                    {
                        this.tblTrans.DR["posted"] = "N";
                        this.tblTrans.DR["reposted"] = "N";
                    }
                }
                else
                {
                    this.tblTrans.DR["reposted"] = "N";
                    goto TR_01AB;
                }
            }
            else
            {
                this.tblTrans.DR["posted_opw"] = "N";
                goto TR_01AB;
            }
            if (this.tblTrans.DR["posted"].ToString() != "N")
            {
                WBTable table10 = new WBTable();
                table10.OpenTable("wb_templateSAP", "SELECT distinct Table_Name, Field_Wb FROM wb_templateSAP WHERE " + WBData.CompanyLocation(" and modul = 'ZWB' and (important is null or important = '' or important = 'Y') and Table_Name = 'wb_transDO' and field_wb is not null"), WBData.conn);
                bool flag279 = false;
                int num28 = 0;
                while (true)
                {
                    if (num28 >= this.dgvDO.Rows.Count)
                    {
                        break;
                    }
                    try
                    {
                        DataRow row21 = this.tmp_transDO.Rows[num28];
                        foreach (DataRow row22 in table10.DT.Rows)
                        {
                            if (this.dgvDO.Rows[num28].Cells[row22["Field_Wb"].ToString().Trim()].Value.ToString().Trim() != row21[row22["Field_Wb"].ToString().Trim()].ToString().Trim())
                            {
                                flag279 = true;
                                break;
                            }
                        }
                        if (flag279)
                        {
                            break;
                        }
                    }
                    catch
                    {
                    }
                    num28++;
                }
                if (flag279)
                {
                    this.tblTrans.DR["posted"] = "N";
                    this.tblTrans.DR["reposted"] = "N";
                }
                table10.Dispose();
            }
            else
            {
                WBTable table9 = new WBTable();
                string[] textArray29 = new string[] { "SELECT * FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND ref like '", this.tblTrans.DR["ref"].ToString(), "%'  AND ref != '", this.tblTrans.DR["ref"].ToString(), "' " };
                table9.OpenTable("wb_transaction", string.Concat(textArray29), WBData.conn);
                string[] strArray3 = new string[table9.DT.Rows.Count];
                int index = 0;
                foreach (DataRow row20 in table9.DT.Rows)
                {
                    strArray3[index] = row20["uniq"].ToString();
                    row20.BeginEdit();
                    row20["posted"] = "N";
                    row20["reposted"] = "N";
                    row20["checksum"] = table9.Checksum(row20);
                    row20.EndEdit();
                    num6 = index;
                    index = num6 + 1;
                }
                table9.Save();
                table9.Dispose();
                int num27 = 0;
                while (true)
                {
                    if (num27 >= strArray3.Length)
                    {
                        break;
                    }
                    string[] textArray30 = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] textArray31 = new string[] { "EDIT", WBUser.UserID, this.mChangeReason + " (Edit main transaction)" };
                    Program.updateLogHeader("wb_transaction", strArray3[num27], textArray30, textArray31);
                    num6 = num27;
                    num27 = num6 + 1;
                }
            }
            goto TR_01AB;
        TR_026F:
            string[] textArray23 = new string[] { "uniq" };
            string[] aFind = new string[] { this.sUniq };
            this.nCurrRow = this.tblTrans.GetRecNo(textArray23, aFind);
            this.tblTrans.DR = this.tblTrans.DT.Rows[0];
            this.tblTrans.DR.BeginEdit();
            goto TR_0269;
        }

        private void simpanTimbun(string sTol, string sCoyTolling)
        {
            if (this.sUniq.Trim() != "")
            {
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                WBTable table3 = new WBTable();
                WBTable table4 = new WBTable();
                WBTable table5 = new WBTable();
                table2.OpenTable("wb_trans", "select * from wb_transaction where " + WBData.CompanyLocation(" and ref like '" + this.textRefNo.Text.Trim() + "%T' and zAuto = 'Y'"), WBData.conn);
                if (table2.DT.Rows.Count > 0)
                {
                    table2.DR = table2.DT.Rows[0];
                    table2.DR.Delete();
                    table2.Save();
                }
                table3.OpenTable("wb_transDO", "select * from wb_transDO where " + WBData.CompanyLocation(" and ref like '" + this.textRefNo.Text.Trim() + "%T'"), WBData.conn);
                if (table3.DT.Rows.Count > 0)
                {
                    foreach (DataRow row2 in table3.DT.Rows)
                    {
                        row2.Delete();
                    }
                    table3.Save();
                }
                table4.OpenTable("wb_transQC", "select * from wb_transQC where " + WBData.CompanyLocation(" and ref like '" + this.textRefNo.Text.Trim() + "%T'"), WBData.conn);
                if (table4.DT.Rows.Count > 0)
                {
                    foreach (DataRow row3 in table4.DT.Rows)
                    {
                        row3.Delete();
                    }
                    table4.Save();
                }
                table.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and Ref like '" + this.textRefNo.Text + "%'"), WBData.conn);
                foreach (DataRow row4 in table.DT.Rows)
                {
                    table3.OpenTable("wb_transDO", "select * from wb_transDO where " + WBData.CompanyLocation(" and ref like '" + row4["Ref"].ToString() + "'"), WBData.conn);
                    if (table3.DT.Rows.Count > 0)
                    {
                        WBTable table6 = new WBTable();
                        table6.OpenTable("wb_contract", "SELECT * FROM wb_contract WHERE " + WBData.CompanyLocation(" AND Do_No = '" + this.dgvDO.Rows[0].Cells["DO_NO"].Value.ToString() + "'"), WBData.conn);
                        table6.DR = table6.DT.Rows[0];
                        string str2 = table6.DR["Tolling2"].ToString();
                        table6.Dispose();
                        DataRow row = table3.DT.Rows[0];
                        if ((row["tolling"].ToString() == "6") && (str2 != "Y"))
                        {
                            table2.DR = table2.DT.NewRow();
                            foreach (DataColumn column in table2.DT.Columns)
                            {
                                if (column.ColumnName.ToUpper() != "UNIQ")
                                {
                                    table2.DR[column.ColumnName] = row4[column.ColumnName];
                                }
                            }
                            WBTable table7 = new WBTable();
                            table7.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Ref = '" + row4["Ref"].ToString() + "T' AND zauto = 'Y'"), WBData.conn);
                            if (table7.DT.Rows.Count > 0)
                            {
                                foreach (DataRow row5 in table7.DT.Rows)
                                {
                                    row5.Delete();
                                }
                                table7.Save();
                                WBTable table9 = new WBTable();
                                table9.OpenTable("wb_transDo", "SELECT * FROM wb_transDo WHERE " + WBData.CompanyLocation(" AND Ref = '" + row4["Ref"].ToString() + "T'"), WBData.conn);
                                foreach (DataRow row6 in table9.DT.Rows)
                                {
                                    row6.Delete();
                                }
                                table9.Save();
                            }
                            table2.DR["ref"] = table2.DR["ref"].ToString() + "T";
                            table2.DR["DO_NO"] = table2.DR["DO_NO"].ToString() + "T";
                            string str = row4["DO_NO"].ToString();
                            table5.OpenTable("wb_timbunDO", "select * from wb_contract where " + WBData.CompanyLocation(" and DO_NO = '" + str + "T' and zAuto = 'Y'"), WBData.conn);
                            table5.DR = table5.DT.Rows[0];
                            table2.DR["Transaction_Code"] = table5.DR["transaction_Code"].ToString();
                            table2.DR["relation_code"] = table5.DR["relation_code"].ToString();
                            table2.DR["tolling"] = table5.DR["tolling"].ToString();
                            table2.DR["zAuto"] = "Y";
                            table2.DR["checksum"] = table2.Checksum(table2.DR);
                            table2.DT.Rows.Add(table2.DR);
                            table2.Save();
                            table3.DR = table3.DT.NewRow();
                            foreach (DataColumn column2 in table3.DT.Columns)
                            {
                                if (column2.ColumnName.ToUpper() != "UNIQ")
                                {
                                    table3.DR[column2.ColumnName] = row[column2.ColumnName];
                                }
                            }
                            table3.DR["Transaction_Code"] = table5.DR["transaction_Code"].ToString();
                            table3.DR["ref"] = table3.DR["ref"].ToString() + "T";
                            table3.DR["DO_NO"] = table3.DR["DO_NO"].ToString() + "T";
                            table3.DR["tolling"] = table5.DR["tolling"].ToString();
                            table3.DT.Rows.Add(table3.DR);
                            table3.Save();
                            WBTable table8 = new WBTable();
                            table8.OpenTable("wb_transQC", "SELECT * FROM wb_transQC WHERE " + WBData.CompanyLocation(" AND ref = '" + row4["REF"].ToString() + "T'"), WBData.conn);
                            table8.AddFromDGV_new(this.dgvQC_All, "Ref", row4["REF"].ToString() + "T", this.logMode, this.logReason);
                            table8.ReOpen();
                            table8.Dispose();
                        }
                    }
                }
                table.Dispose();
                table2.Dispose();
                table3.Dispose();
                table4.Dispose();
            }
        }

        private void tab_changed(object sender, EventArgs e)
        {
            if (this.tabControl1.SelectedTab.Text == "Delivery Letter")
            {
                this.dgvListDO.Rows.Clear();
                int num = 0;
                while (true)
                {
                    if (num >= this.dgvDO.Rows.Count)
                    {
                        this.dgvListDO.Refresh();
                        int num2 = this.dgvBatch.RowCount - 1;
                        while (true)
                        {
                            if (num2 < 0)
                            {
                                break;
                            }
                            DataGridViewRow row = this.dgvBatch.Rows[num2];
                            bool flag3 = row.Cells["SO_No"].Value.ToString().Trim() == this.dgvListDO.Rows[0].Cells["Do_No"].Value.ToString().Trim();
                            this.dgvBatch.Rows[num2].Visible = flag3;
                            num2--;
                        }
                        break;
                    }
                    string[] values = new string[] { this.dgvDO.Rows[num].Cells["Do_No"].Value.ToString(), this.dgvDO.Rows[num].Cells["transaction_code"].Value.ToString() };
                    this.dgvListDO.Rows.Add(values);
                    num++;
                }
            }
        }

        private void tabControl1_MouseClick(object sender, MouseEventArgs e)
        {
            this.settingTabControl();
        }

        private void tabPageDeduc_Click(object sender, EventArgs e)
        {
        }

        private void tabPageShow(string pCommType)
        {
            if ((this.WX != "1X") && (this.tabControl1.TabPages.IndexOf(this.tabPageDeduc) < 0))
            {
                this.tabControl1.TabPages.Add(this.tabPageDeduc);
            }
            if (pCommType == "S")
            {
                if (this.tabControl1.TabPages.IndexOf(this.tabPageQC) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPageQC);
                }
                if (WBSetting.locType == "1")
                {
                    this.tabControl1.TabPages.Remove(this.tabPageDeduc);
                }
                this.groupBoxTotalBunchFFB.Visible = false;
                this.radioButtonEntryAVG.Visible = false;
                this.radioButtonEntryTotalBunch.Visible = false;
            }
            else if (pCommType != "F")
            {
                if (pCommType == "C")
                {
                    if (this.tabControl1.TabPages.IndexOf(this.tabPageCopra) < 0)
                    {
                        this.tabControl1.TabPages.Add(this.tabPageCopra);
                    }
                    this.radioButtonEntryAVG.Visible = false;
                    this.radioButtonEntryTotalBunch.Visible = false;
                }
                else if (pCommType == "G")
                {
                    if (this.tabControl1.TabPages.IndexOf(this.tabPageDL) < 0)
                    {
                        this.tabControl1.TabPages.Add(this.tabPageDL);
                    }
                    this.radioButtonEntryAVG.Visible = false;
                    this.radioButtonEntryTotalBunch.Visible = false;
                }
            }
            else
            {
                if (this.tabControl1.TabPages.IndexOf(this.tabPageDeduc) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPageDeduc);
                }
                this.tabControl1.TabPages["tabPageDeduc"].Text = "Deduction";
                this.panelDeducTBS.Visible = true;
                if (this.tabControl1.TabPages.IndexOf(this.tabPagePorla) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPagePorla);
                }
                if (this.tabControl1.TabPages.IndexOf(this.tabPageDivision) < 0)
                {
                    this.tabControl1.TabPages.Add(this.tabPageDivision);
                }
                this.groupBoxTotalBunchFFB.Visible = true;
                this.radioButtonEntryAVG.Visible = true;
                this.radioButtonEntryTotalBunch.Visible = true;
                if (WBSetting.Field("ScanCardSPB") == "Y")
                {
                    this.radioButtonEntryAVG.Checked = false;
                    this.radioButtonEntryTotalBunch.Checked = true;
                }
                else
                {
                    this.radioButtonEntryAVG.Checked = true;
                    this.radioButtonEntryTotalBunch.Checked = false;
                }
                this.checkEntryAVGorTotalBunch();
            }
        }

        private void text1st_Leave(object sender, EventArgs e)
        {
            this.HitNet();
            if (this.dgvDeduc.Enabled || this.dgvDivBlock.Enabled)
            {
                if (this.dgvDeduc.RowCount > 0)
                {
                    this.recalc_deduc();
                }
                if (this.dgvDivBlock.RowCount > 0)
                {
                    this.recalc_division();
                }
            }
        }

        private void text1st_TextChanged(object sender, EventArgs e)
        {
            this.checkEntryDOforManual(this.text1st);
            this.hitungBTN();
        }

        private void text2nd_Leave(object sender, EventArgs e)
        {
            this.HitNet();
            if (this.dgvDeduc.Enabled || this.dgvDivBlock.Enabled)
            {
                if (this.dgvDeduc.RowCount > 0)
                {
                    this.recalc_deduc();
                }
                if (this.dgvDivBlock.RowCount > 0)
                {
                    this.recalc_division();
                }
            }
        }

        private void text2nd_TextChanged(object sender, EventArgs e)
        {
            try
            {
                this.checkEntryDOforManual(this.text2nd);
                this.hitungBTN();
            }
            catch
            {
            }
        }

        private void text3rd_Leave(object sender, EventArgs e)
        {
            this.HitNet();
            if (this.dgvDeduc.Enabled || this.dgvDivBlock.Enabled)
            {
                if (this.dgvDeduc.RowCount > 0)
                {
                    this.recalc_deduc();
                }
                if (this.dgvDivBlock.RowCount > 0)
                {
                    this.recalc_division();
                }
            }
        }

        private void text4th_Leave(object sender, EventArgs e)
        {
            this.HitNet();
            if (this.dgvDeduc.Enabled || this.dgvDivBlock.Enabled)
            {
                if (this.dgvDeduc.RowCount > 0)
                {
                    this.recalc_deduc();
                }
                if (this.dgvDivBlock.RowCount > 0)
                {
                    this.recalc_division();
                }
            }
        }

        private void textAvg_Leave(object sender, EventArgs e)
        {
            if (this.textAvg.Enabled && Program.CheckNumeric(this.textAvg))
            {
                if ((Program.StrToDouble(this.textNET1.Text, 0) > 0.0) & (Program.StrToDouble(this.textAvg.Text, 0) > 0.0))
                {
                    this.textBunchTotal.Text = Convert.ToString((double) (Program.StrToDouble(this.textNET1.Text, 2) / Program.StrToDouble(this.textAvg.Text, 2)));
                    this.textBunchTotal.Text = Math.Round(Program.StrToDouble(this.textBunchTotal.Text, 2), 0).ToString();
                    this.textBunchDeduc.Text = this.textBunchTotal.Text;
                }
                this.BJR();
                this.recalc_division();
            }
        }

        private void textBox1_Leave_1(object sender, EventArgs e)
        {
            if (Program.CheckNumeric(this.textBoxKG) && ((Program.StrToDouble(this.textAvg.Text, 2) > 0.0) & (Program.StrToDouble(this.textBoxKG.Text, 2) > 0.0)))
            {
                this.textTBSReject.Text = $"{Program.StrToDouble(this.textBoxKG.Text, 2) / Program.StrToDouble(this.textAvg.Text, 2):N2}";
            }
        }

        private void textBunchTotal_Leave(object sender, EventArgs e)
        {
            if (Program.CheckNumeric(this.textBunchTotal))
            {
                this.HitNet();
                this.BJR();
                if (this.use_gunny == "Y")
                {
                    double num = Convert.ToDouble(this.textAvg.Text);
                    if ((num < this.sGunnyMin) || (num > this.sGunnyMax))
                    {
                        MessageBox.Show("Netto per Gunny is not in Min and Max Range.\nPlease refill Gunny!.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        this.textAvg.Text = "0";
                        this.textBunchTotal.Text = "0";
                        this.textBunchDeduc.Text = "0";
                        return;
                    }
                }
                if ((this.textBunchDeduc.Text.Trim() == "0") || (this.textBunchDeduc.Text.Trim() == ""))
                {
                    this.textBunchDeduc.Text = this.textBunchTotal.Text;
                }
                this.recalc_division();
            }
        }

        private void textCommodity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\b')
            {
                this.textCommodity.Text = "";
            }
        }

        private void textCust_Leave(object sender, EventArgs e)
        {
            if (this.textCust.Text != "")
            {
                this.tblCust.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" and relation_code = '" + this.textCust.Text.Trim() + "' and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
                string[] aField = new string[] { "Relation_Code" };
                string[] aFind = new string[] { this.textCust.Text };
                DataRow data = this.tblCust.GetData(aField, aFind);
                if (data != null)
                {
                    this.labelCustName.Text = data["Relation_name"].ToString().Trim();
                    this.labelCustName.Refresh();
                }
                else
                {
                    this.buttonCust.PerformClick();
                    this.textCust.Focus();
                }
            }
        }

        private void textDate1st_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textTime1st.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textDate1st.Text).ToShortDateString());
                }
                catch
                {
                    MessageBox.Show("INVALID DATE ENTRY DD/MM/YYYY", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textDate1st.Focus();
                }
            }
        }

        private void textDate2nd_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textDate2nd.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textDate2nd.Text).ToShortDateString());
                }
                catch
                {
                    MessageBox.Show("INVALID DATE ENTRY DD/MM/YYYY", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textDate2nd.Focus();
                }
            }
        }

        private void textDate3rd_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textDate3rd.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textDate3rd.Text).ToShortDateString());
                }
                catch
                {
                    MessageBox.Show("INVALID DATE ENTRY DD/MM/YYYY", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textDate3rd.Focus();
                }
            }
        }

        private void textDate4th_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textDate4th.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textDate4th.Text).ToShortDateString());
                }
                catch
                {
                    MessageBox.Show("INVALID DATE ENTRY DD/MM/YYYY", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textDate4th.Focus();
                }
            }
        }

        private void textDL_Leave(object sender, EventArgs e)
        {
            if (this.textDL.Text.Trim() != "")
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_transBatch", "Select * from wb_transBatch where Do_No ='" + this.textDL.Text.Trim() + "'", WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    int num = 0;
                    while (true)
                    {
                        if (num >= table.DT.Rows.Count)
                        {
                            break;
                        }
                        table.DR = table.DT.Rows[num];
                        string zValue = table.DR["Ref"].ToString().Trim();
                        string str2 = Program.getFieldValue("wb_transaction", "Deleted", "Ref", zValue);
                        if (!((str2 != "Y") & (zValue != this.textRefNo.Text.Trim())))
                        {
                            num++;
                            continue;
                        }
                        MessageBox.Show("Delivery letter " + this.textDL.Text.Trim() + " have been used previously");
                        this.textDL.Focus();
                        this.textDL.SelectAll();
                        table.Dispose();
                        return;
                    }
                }
                table.Dispose();
            }
        }

        private void textDN_Leave(object sender, EventArgs e)
        {
            if (((WBSetting.Field("DeliveryNote") == "Y") && (this.WX != "1X")) && (this.textDN.Text.Trim() != "-"))
            {
                if (this.dgvDO.Rows.Count <= 0)
                {
                    MessageBox.Show("Please input DO first", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textDN.Text = "";
                }
                else if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    this.textDN.Enabled = false;
                }
                else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    this.textDN.Enabled = false;
                }
                else if ((this.CommType == "F") && !this.CheckSPB())
                {
                    MessageBox.Show("Invalid Delivery Note", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.textDN.Focus();
                }
            }
        }

        private void textDriverID_Leave(object sender, EventArgs e)
        {
            if (this.textDriverID.Text.Trim() != "")
            {
                this.tblDriver.ReOpen();
                string[] aField = new string[] { "License_No" };
                string[] aFind = new string[] { this.textDriverID.Text.Trim() };
                int recNo = this.tblDriver.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.buttonDriver.PerformClick();
                    this.textDriverID.Focus();
                }
                else
                {
                    this.labelDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                    this.textDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                    if (this.textTruck.Text.Trim() == "")
                    {
                        this.textTruck.Text = this.tblDriver.DT.Rows[recNo]["Truck_Number"].ToString();
                        this.textTruck.Focus();
                    }
                    if (this.pMode != "EDIT")
                    {
                        string str = "";
                        WBTable table = new WBTable();
                        table.OpenTable("wb_driver", "SELECT * FROM wb_driver WHERE " + WBData.CompanyLocation("AND License_No = '" + this.textDriverID.Text.Trim() + "' and (Deleted IS NULL OR Deleted <> 'Y') "), WBData.conn);
                        str = table.DT.Rows[0]["Black_List"].ToString();
                        table.Dispose();
                        if (str == "Y")
                        {
                            MessageBox.Show(Resource.Mes_610, Resource.Title_002);
                            this.textDriverID.Focus();
                        }
                    }
                }
            }
        }

        private void textDriverName_Leave(object sender, EventArgs e)
        {
            if (this.textDriverName.Text.Trim() != "")
            {
                this.tblDriver.ReOpen();
                string[] aField = new string[] { "Name" };
                string[] aFind = new string[] { this.textDriverName.Text.Trim() };
                int recNo = this.tblDriver.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.buttonDriver.PerformClick();
                    this.textDriverID.Focus();
                }
                else
                {
                    this.textDriverID.Text = this.tblDriver.DT.Rows[recNo]["License_No"].ToString();
                    this.labelDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                    this.textDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                    if (this.textTruck.Text.Trim() == "")
                    {
                        this.textTruck.Text = this.tblDriver.DT.Rows[recNo]["Truck_Number"].ToString();
                        this.textTruck.Focus();
                    }
                }
            }
        }

        private void textGrade_Leave(object sender, EventArgs e)
        {
        }

        private void textGrossEstate_Enter(object sender, EventArgs e)
        {
            this.textGrossEstate.SelectAll();
        }

        private void textGrossEstate_Leave(object sender, EventArgs e)
        {
            this.HitNetEstate();
        }

        private void textGrossEstate_TextChanged(object sender, EventArgs e)
        {
        }

        private void textGunnyBatch_textChanged(object sender, EventArgs e)
        {
            if ((this.text2nd.Text != "") || (this.text2nd.Text != "0"))
            {
                try
                {
                    double num = Convert.ToDouble(this.textNET1.Text);
                    if (this.textGunnyBatch.Text == "0")
                    {
                        this.textBox3.Text = "0.00";
                    }
                    else
                    {
                        this.textBox3.Text = (num / Convert.ToDouble(this.textGunnyBatch.Text)).ToString("0.00");
                    }
                }
                catch
                {
                    this.textBox3.Text = "0";
                }
            }
            this.calc_dl();
        }

        private void textNet_TextChanged(object sender, EventArgs e)
        {
            this.hitungBTN();
            if (this.CommType == "F")
            {
                this.BJR();
            }
            if (this.dgvBatch.RowCount > 1)
            {
                this.calc_dl();
            }
            else
            {
                this.calc_loadstuff();
            }
        }

        private void textNET2_TextChanged(object sender, EventArgs e)
        {
            if (this.CommType == "F")
            {
                this.BJR();
            }
        }

        private void textNettoBatch_Leave(object sender, EventArgs e)
        {
            try
            {
                double num = Convert.ToInt32(this.textNettoBatch.Text) / Convert.ToInt32(this.sGunnyNet);
                this.textGunnyBatch.Text = Math.Round(num, 0);
            }
            catch
            {
                this.textGunnyBatch.Text = "0";
            }
        }

        private void textQControl_Leave(object sender, EventArgs e)
        {
            this._QC_SaveTankQC();
        }

        private void textRefNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textRefNo_Leave(object sender, EventArgs e)
        {
            if ((this.pMode == "MANUAL") && (this.textRefNo.Text.Trim() != ""))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_transaction", "Select Ref From wb_transaction Where " + WBData.CompanyLocation(" AND Ref='" + this.textRefNo.Text.Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count != 0)
                {
                    MessageBox.Show("No Ref " + this.textRefNo.Text.Trim() + " already exist", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textRefNo.Focus();
                }
            }
        }

        private void textRendCPO_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textRendCPO);
        }

        private void textReport_Date_Leave(object sender, EventArgs e)
        {
            if ((this.pMode == "MANUAL") && (this.textReport_Date.Text.Trim() != ""))
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textReport_Date.Text).ToShortDateString());
                }
                catch
                {
                    MessageBox.Show("INVALID DATE ENTRY DD/MM/YYYY", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textReport_Date.Focus();
                }
            }
        }

        private void textTanker_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\b')
            {
                this.textTanker.Text = "";
                this.labelTankerMax.Text = "";
            }
        }

        private void textTanker_Leave(object sender, EventArgs e)
        {
            if (this.textTanker.Text != "")
            {
                this.tblTanker.ReOpen();
                string[] aField = new string[] { "Tanker_No" };
                string[] aFind = new string[] { this.textTanker.Text.Trim() };
                int recNo = this.tblTanker.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.buttonTanker.PerformClick();
                    this.textTanker.Focus();
                }
                else
                {
                    this.textTanker.Text = this.tblTanker.DT.Rows[recNo]["Tanker_No"].ToString().Trim();
                    this.labelTankerMax.Text = "Max.Tanker = " + $"{this.tblTanker.DT.Rows[recNo]["Capacity"].ToString().Trim():N0}" + " Kg";
                    this.labelTankerMax.Text = (this.tblTanker.DT.Rows[recNo]["Check_tanker"].ToString() != "P") ? ((this.tblTanker.DT.Rows[recNo]["Check_tanker"].ToString() != "K") ? (this.labelTankerMax.Text + " (NOT CHECK)") : (this.labelTankerMax.Text + " (Tolerance : " + this.tblTanker.DT.Rows[recNo]["CheckTankerKG"].ToString() + " KG)")) : (this.labelTankerMax.Text + " (Tolerance : " + this.tblTanker.DT.Rows[recNo]["CheckTankerTol"].ToString() + " %)");
                }
            }
        }

        private void textTankQC_Leave(object sender, EventArgs e)
        {
            this._QC_SaveTankQC();
        }

        private void textTareEstate_Enter(object sender, EventArgs e)
        {
            this.textTareEstate.SelectAll();
        }

        private void textTareEstate_Leave(object sender, EventArgs e)
        {
            this.HitNetEstate();
        }

        private void textTareEstate_TextChanged(object sender, EventArgs e)
        {
            this.HitNetEstate();
        }

        private void textTBSReject_Leave(object sender, EventArgs e)
        {
            if (Program.CheckNumeric(this.textTBSReject) && ((Program.StrToDouble(this.textAvg.Text, 2) > 0.0) & (Program.StrToDouble(this.textTBSReject.Text, 2) > 0.0)))
            {
                this.textBoxKG.Text = $"{Program.StrToDouble(this.textAvg.Text, 2) * Program.StrToDouble(this.textTBSReject.Text, 2):N2}";
            }
        }

        private void textTime1st_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textTime1st.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textTime1st.Text).ToShortTimeString());
                }
                catch
                {
                    MessageBox.Show("INVALID DATE ENTRY HH:MM:SS", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textTime1st.Focus();
                }
            }
        }

        private void textTime2nd_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textTime2nd.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textTime2nd.Text).ToShortTimeString());
                }
                catch
                {
                    MessageBox.Show("INVALID DATE ENTRY HH:MM:SS", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textTime2nd.Focus();
                }
            }
        }

        private void textTime3rd_Leave(object sender, EventArgs e)
        {
            if (((this.pMode == "MANUAL") || (this.spMode == "QTY")) ? (this.textTime3rd.Text.Trim() != "") : false)
            {
                try
                {
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(this.textTime3rd.Text).ToShortTimeString());
                }
                catch
                {
                    MessageBox.Show("INVALID DATE ENTRY HH:MM:SS", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textTime3rd.Focus();
                }
            }
        }

        private void textTransporter_TextChanged(object sender, EventArgs e)
        {
            if (this.textTransporter.Text != "")
            {
                string[] aField = new string[] { "Transporter_Code" };
                string[] aFind = new string[] { this.textTransporter.Text };
                DataRow data = this.tblTransporter.GetData(aField, aFind);
                if (data == null)
                {
                    this.labelTransporterName.Text = "";
                }
                else
                {
                    this.labelTransporterName.Text = data["Transporter_Name"].ToString().Trim();
                    this.labelTransporterName.Refresh();
                }
            }
        }

        private void textTruck_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTruck_Leave(object sender, EventArgs e)
        {
            if (this.textTruck.Text.Trim() != "")
            {
                this.tblTruck.ReOpen();
                string[] aField = new string[] { "Truck_Number" };
                string[] aFind = new string[] { this.textTruck.Text.Trim() };
                int recNo = this.tblTruck.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.buttonTruck.PerformClick();
                    this.textTruck.Focus();
                }
                else
                {
                    this.textTruck.Text = this.tblTruck.DT.Rows[recNo]["Truck_Number"].ToString().Trim();
                    if (this.textTanker.Text.Trim() == "")
                    {
                        this.textTanker.Text = this.tblTruck.DT.Rows[recNo]["Tanker_no"].ToString().Trim();
                    }
                    this.tblTanker.ReOpen();
                    string[] textArray3 = new string[] { "Tanker_No" };
                    string[] textArray4 = new string[] { this.textTanker.Text.Trim() };
                    int num2 = this.tblTanker.GetRecNo(textArray3, textArray4);
                    if (num2 <= -1)
                    {
                        this.labelTankerMax.Text = "Max.Tanker = -";
                    }
                    else
                    {
                        this.labelTankerMax.Text = "Max.Tanker = " + $"{this.tblTanker.DT.Rows[num2]["Capacity"].ToString().Trim():N0}" + " Kg";
                        this.labelTankerMax.Text = (this.tblTanker.DT.Rows[num2]["Check_tanker"].ToString() != "P") ? ((this.tblTanker.DT.Rows[num2]["Check_tanker"].ToString() != "K") ? (this.labelTankerMax.Text + " (NOT CHECK)") : (this.labelTankerMax.Text + " (Tolerance : " + this.tblTanker.DT.Rows[num2]["CheckTankerKG"].ToString() + " KG)")) : (this.labelTankerMax.Text + " (Tolerance : " + this.tblTanker.DT.Rows[num2]["CheckTankerTol"].ToString() + " %)");
                    }
                    if (this.textTransporter.Text == "")
                    {
                        this.textTransporter.Text = this.tblTruck.DT.Rows[recNo]["Transporter_Code"].ToString().Trim();
                        string[] textArray5 = new string[] { "Transporter_Code" };
                        string[] textArray6 = new string[] { this.textTransporter.Text };
                        DataRow data = this.tblTransporter.GetData(textArray5, textArray6);
                        if (data != null)
                        {
                            this.labelTransporterName.Text = data["Transporter_Name"].ToString().Trim();
                        }
                    }
                    this.maxTare = this.tblTruck.DT.Rows[recNo]["max_Tare"].ToString().Trim();
                    this.minTare = this.tblTruck.DT.Rows[recNo]["min_Tare"].ToString().Trim();
                    if ((((this.pMode == "1ST") || ((this.pMode == "2ND") || ((this.pMode == "3RD") || (this.pMode == "4TH")))) || (this.WX == "")) && this.checkTruckinYard(this.textTruck.Text, this.textTruck2.Text))
                    {
                        if (((this.pMode == "1ST") || (this.pMode == "2ND")) || (this.WX == ""))
                        {
                            this.textTruck.SelectAll();
                            this.textTruck.Focus();
                        }
                        else if ((this.pMode == "3RD") || (this.pMode == "4TH"))
                        {
                            this.textTruck2.SelectAll();
                            this.textTruck2.Focus();
                        }
                    }
                    if (this.pMode != "EDIT")
                    {
                        string str = "";
                        WBTable table = new WBTable();
                        table.OpenTable("wb_truck", "SELECT * FROM wb_truck WHERE " + WBData.CompanyLocation("AND Truck_Number = '" + this.textTruck.Text.Trim() + "'"), WBData.conn);
                        str = table.DT.Rows[0]["Black_List"].ToString();
                        table.Dispose();
                        if (str == "Y")
                        {
                            MessageBox.Show(Resource.Mes_611, Resource.Title_002);
                            this.textTruck.Focus();
                        }
                    }
                }
            }
        }

        private void textTruck2_Leave(object sender, EventArgs e)
        {
            if ((((this.pMode == "1ST") || ((this.pMode == "2ND") || ((this.pMode == "3RD") || (this.pMode == "4TH")))) || (this.WX == "")) && this.checkTruckinYard(this.textTruck.Text, this.textTruck2.Text))
            {
                if (((this.pMode == "1ST") || (this.pMode == "2ND")) || (this.WX == ""))
                {
                    this.textTruck.SelectAll();
                    this.textTruck.Focus();
                }
                else if ((this.pMode == "3RD") || (this.pMode == "4TH"))
                {
                    this.textTruck2.SelectAll();
                    this.textTruck2.Focus();
                }
            }
        }

        private void ThisClose()
        {
            this.nKg = -999;
            if ((this.pMode == "VIEW") || (MessageBox.Show("\n Entry transaction will be cancelled...!\n\n         Are you sure ?\n", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes))
            {
                if ((WBSetting.bGate == "Y") & (this.WX != ""))
                {
                    if (!WBSetting.activeTCS)
                    {
                        if (((this.pMode == "1ST") || (this.pMode == "3RD")) & (this.WX != ""))
                        {
                            if ((WBSetting.gateType != "1") && (WBSetting.gateType != ""))
                            {
                                if (WBSetting.gateType == "2")
                                {
                                    this.returnGate = WBBarrierGate2.openGate(WBSetting.gate1IP, WBSetting.gate1Port);
                                    if (!this.returnGate)
                                    {
                                        MessageBox.Show("Error open gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        return;
                                    }
                                }
                            }
                            else
                            {
                                WBBarrierGate1.runGate(WBSetting.gate1Open);
                            }
                            while (true)
                            {
                                MessageBox.Show("Close Barrier Gate? ", "B A R R I E R   G A T E", MessageBoxButtons.OK);
                                if (WBSetting.WB_Type == "5")
                                {
                                    this.wbIndicator.Init();
                                    this.wbIndicator.checkStatus();
                                    if (!this.wbIndicator.check0())
                                    {
                                        continue;
                                    }
                                }
                                else
                                {
                                    this.nKg = -999;
                                    this.nKg = WBSetting.CheckZero();
                                    if (this.nKg != 0)
                                    {
                                        continue;
                                    }
                                }
                                if ((WBSetting.gateType != "1") && (WBSetting.gateType != ""))
                                {
                                    if (WBSetting.gateType == "2")
                                    {
                                        this.returnGate = WBBarrierGate2.closeGate(WBSetting.gate1IP, WBSetting.gate1Port);
                                        if (!this.returnGate)
                                        {
                                            MessageBox.Show("Error close gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                            return;
                                        }
                                    }
                                }
                                else
                                {
                                    WBBarrierGate1.runGate(WBSetting.gate1Close);
                                }
                                break;
                            }
                        }
                        if (((this.pMode == "2ND") || (this.pMode == "4TH")) & (this.WX != ""))
                        {
                            if ((WBSetting.gateType != "1") && (WBSetting.gateType != ""))
                            {
                                if (WBSetting.gateType == "2")
                                {
                                    this.returnGate = WBBarrierGate2.openGate(WBSetting.gate2IP, WBSetting.gate2Port);
                                    if (!this.returnGate)
                                    {
                                        MessageBox.Show("Error open gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        return;
                                    }
                                }
                            }
                            else
                            {
                                WBBarrierGate1.runGate(WBSetting.gate2Open);
                            }
                            while (true)
                            {
                                MessageBox.Show("Close Barrier Gate? ", "B A R R I E R   G A T E", MessageBoxButtons.OK);
                                if (WBSetting.WB_Type == "5")
                                {
                                    this.wbIndicator.Init();
                                    this.wbIndicator.checkStatus();
                                    if (!this.wbIndicator.check0())
                                    {
                                        continue;
                                    }
                                }
                                else
                                {
                                    this.nKg = -999;
                                    this.nKg = WBSetting.CheckZero();
                                    if (this.nKg != 0)
                                    {
                                        continue;
                                    }
                                }
                                if ((WBSetting.gateType != "1") && (WBSetting.gateType != ""))
                                {
                                    if (WBSetting.gateType == "2")
                                    {
                                        this.returnGate = WBBarrierGate2.closeGate(WBSetting.gate2IP, WBSetting.gate2Port);
                                        if (!this.returnGate)
                                        {
                                            MessageBox.Show("Error close gate!\n" + WBBarrierGate2.strMsg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                            return;
                                        }
                                    }
                                }
                                else
                                {
                                    WBBarrierGate1.runGate(WBSetting.gate2Close);
                                }
                                break;
                            }
                        }
                    }
                    else
                    {
                        WBBarrierGate3.openGate("0");
                    }
                }
                base.Close();
            }
        }

        private void TransToLog(string pUniq, string pmode)
        {
            WBTable table = new WBTable();
            if (pUniq.Trim() != "")
            {
                table.OpenTable("wb_transaction", "Select * From wb_transaction where Uniq=" + pUniq.Trim(), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_trans_log", "Select * From wb_trans_log where 1=2", WBData.conn);
                    table2.DR = table2.DT.NewRow();
                    foreach (DataColumn column in table2.DT.Columns)
                    {
                        try
                        {
                            if (((column.ColumnName.ToUpper() != "UNIQ") && (column.ColumnName.ToUpper() != "LOG_DATE".ToUpper())) && (column.ColumnName.ToUpper() != "LOG_TIME".ToUpper()))
                            {
                                table2.DR[column.ColumnName] = table.DT.Rows[0][column.ColumnName];
                            }
                        }
                        catch
                        {
                        }
                    }
                    table2.DR["log_Date"] = DateTime.Now.Date;
                    table2.DR["log_time"] = DateTime.Now.ToString("HH:mm");
                    if (pmode == "EDIT")
                    {
                        table2.DR["Edit_By"] = WBUser.UserID;
                        table2.DR["Edit_Date"] = DateTime.Now;
                    }
                    else if (pmode == "PRINT")
                    {
                        table2.DR["Printed_By"] = WBUser.UserID.Trim();
                        table2.DR["Printed_Date"] = DateTime.Now;
                    }
                    table2.DT.Rows.Add(table2.DR);
                    table2.Save();
                    table2.Dispose();
                }
            }
            else
            {
                return;
            }
            table.Dispose();
        }

        private void TransType()
        {
            string[] aField = new string[] { "Transaction_Code" };
            string[] aFind = new string[] { this.comboTransType.Text };
            this.rowTransType = this.tblTransType.GetData(aField, aFind);
            if (this.rowTransType != null)
            {
                WBCondition condition = new WBCondition();
                DataRow[] dgRows = new DataRow[] { this.rowTransType };
                condition.fillParameter("TRANS_TANKERNO", dgRows);
                this.sReq_Tanker = condition.getResult() ? "Y" : "N";
                condition.Dispose();
                this.sIO = this.rowTransType["IO"].ToString();
                if (this.sReq_Tanker != "Y")
                {
                    if ((this.textTanker.Text.Trim() == "") && ((!WBSetting.activeTCS || (this.pMode != "EDIT")) || (Convert.ToInt16(WBUser.UserLevel) <= 1)))
                    {
                        this.textTanker.Text = "";
                    }
                    this.textTanker.ReadOnly = false;
                    this.buttonTanker.Enabled = true;
                }
                else
                {
                    this.textTanker.ReadOnly = true;
                    this.buttonTanker.Enabled = false;
                    string[] textArray3 = new string[] { "Truck_Number" };
                    string[] textArray4 = new string[] { this.textTruck.Text.Trim() };
                    int recNo = this.tblTruck.GetRecNo(textArray3, textArray4);
                    if (recNo > -1)
                    {
                        if (this.textTanker.Text.Trim() == "")
                        {
                            this.textTanker.Text = this.tblTruck.DT.Rows[recNo]["Tanker_no"].ToString().Trim();
                        }
                        this.tblTanker.ReOpen();
                        string[] textArray5 = new string[] { "Tanker_No" };
                        string[] textArray6 = new string[] { this.textTanker.Text.Trim() };
                        int num2 = this.tblTanker.GetRecNo(textArray5, textArray6);
                        if (num2 <= -1)
                        {
                            this.labelTankerMax.Text = "Max Tanker = - ";
                        }
                        else
                        {
                            this.labelTankerMax.Text = "Max.Tanker = " + $"{this.tblTanker.DT.Rows[num2]["Capacity"].ToString().Trim():N0}" + " Kg";
                            this.labelTankerMax.Text = (this.tblTanker.DT.Rows[num2]["Check_tanker"].ToString() != "P") ? ((this.tblTanker.DT.Rows[num2]["Check_tanker"].ToString() != "K") ? (this.labelTankerMax.Text + " (NOT CHECK) ") : (this.labelTankerMax.Text + " (Tolerance : " + this.tblTanker.DT.Rows[num2]["CheckTankerKG"].ToString() + " KG)")) : (this.labelTankerMax.Text + " (Tolerance : " + this.tblTanker.DT.Rows[num2]["CheckTankerTol"].ToString() + " %)");
                        }
                    }
                }
                this.labelRelation.Text = (this.sIO != "I") ? "Customer" : "Vendor";
                this.transType = this.rowTransType["IO"].ToString().Trim();
                this.is_vessel = this.rowTransType["is_vessel"].ToString().Trim();
                this.checkNOPW.Visible = this.is_vessel != "Y";
                this.MSinTrx = this.rowTransType["MS_in_Trx"].ToString().Trim();
            }
        }

        private void txtMS_Leave(object sender, EventArgs e)
        {
            if (!Regex.IsMatch(this.txtMS.Text, "[^0-9]"))
            {
                this.HitNet();
            }
            else
            {
                MessageBox.Show("Please enter only numbers.");
                this.txtMS.Text.Remove(this.txtMS.Text.Length - 1);
                this.txtMS.Focus();
            }
        }

        private void txtMS_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(this.txtMS.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                this.txtMS.Text.Remove(this.txtMS.Text.Length - 1);
                this.txtMS.Focus();
            }
        }

        private void typeContract(int cMode)
        {
            if (cMode != 0)
            {
                this.textCommodity.Visible = true;
                this.comboTransType.Visible = true;
                this.textCust.Visible = true;
                this.textCommodity.Enabled = true;
                this.comboTransType.Enabled = true;
                this.textCust.Enabled = true;
                this.buttonCust.Enabled = true;
                this.buttonComm.Enabled = true;
                this.textCommodity.Visible = true;
                this.comboTransType.Visible = true;
                this.textCust.Visible = true;
                this.buttonCust.Visible = true;
                this.buttonComm.Visible = true;
                this.labelComm.Visible = true;
                this.labelCommName.Visible = true;
                this.labelRelation.Visible = true;
                this.labelCustName.Visible = true;
                this.buttonAddDO.Enabled = false;
                this.buttonEditDO.Enabled = false;
                this.buttonDeleteDO.Enabled = false;
                this.buttonMergeDO.Enabled = false;
            }
            else
            {
                this.textCommodity.Visible = true;
                this.comboTransType.Visible = true;
                this.textCust.Visible = true;
                this.textCommodity.Enabled = false;
                this.comboTransType.Enabled = false;
                this.textCust.Enabled = false;
                this.buttonCust.Enabled = false;
                this.buttonComm.Enabled = false;
                this.textCommodity.Visible = false;
                this.comboTransType.Visible = false;
                this.textCust.Visible = false;
                this.buttonCust.Visible = false;
                this.buttonComm.Visible = false;
                this.labelComm.Visible = false;
                this.labelCommName.Visible = false;
                this.labelRelation.Visible = false;
                this.labelCustName.Visible = false;
                this.buttonAddDO.Enabled = true;
                if ((this.pMode != "SPLIT") && (this.pMode != "DL"))
                {
                    this.buttonEditDO.Enabled = true;
                }
                this.buttonDeleteDO.Enabled = true;
                this.buttonMergeDO.Enabled = true;
                if ((((this.pMode == "EDIT") || (this.pMode == "QC")) || (this.pMode == "DL")) && ((this.tblTrans.DR["Split"].ToString() == "X") || (this.tblTrans.DR["Split"].ToString() == "Y")))
                {
                    this.buttonAddDO.Enabled = false;
                }
            }
            if (this.spMode == "EDIT_OPW")
            {
                this.buttonAddDO.Enabled = false;
                this.buttonDeleteDO.Enabled = false;
                this.buttonMergeDO.Enabled = false;
                if (((this.pMode == "EDIT") || ((this.pMode == "QC") || ((this.pMode == "DL") || (this.pMode == "EDIT_OPW")))) || (this.pMode == "ADD_RETUR"))
                {
                    this.buttonAddDO.Enabled = false;
                }
            }
        }

        private void updatePrinted()
        {
            int num = 0;
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "Select * from wb_transaction Where ref='", this.textRefNo.Text, "' and coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "'" };
            table.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
            table.DR = table.DT.Rows[0];
            num = (table.DR["printed"].ToString().Trim() == "") ? 0 : Convert.ToInt32(table.DR["printed"].ToString());
            table.DR.BeginEdit();
            num++;
            table.DR["printed"] = num;
            table.DR["Printed_By"] = WBUser.UserID.Trim();
            table.DR["Printed_Date"] = DateTime.Now;
            table.DR["checksum"] = table.Checksum_Main(table.DR);
            table.DR.EndEdit();
            table.Save();
            table.Dispose();
        }

        private bool validDriverID()
        {
            bool flag = false;
            if (this.textDriverID.Text.Trim() != "")
            {
                this.tblDriver.ReOpen();
                string[] aField = new string[] { "License_No" };
                string[] aFind = new string[] { this.textDriverID.Text.Trim() };
                int recNo = this.tblDriver.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    flag = false;
                }
                else
                {
                    this.labelDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                    this.textDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                    flag = true;
                }
            }
            return flag;
        }

        private bool validDriverName()
        {
            bool flag = true;
            if (this.textDriverName.Text.Trim() != "")
            {
                this.tblDriver.ReOpen();
                string[] aField = new string[] { "Name" };
                string[] aFind = new string[] { this.textDriverName.Text.Trim() };
                int recNo = this.tblDriver.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    flag = false;
                }
                else
                {
                    this.textDriverID.Text = this.tblDriver.DT.Rows[recNo]["License_No"].ToString();
                    this.labelDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                    this.textDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                    flag = true;
                }
            }
            return flag;
        }

        private bool validTransporter()
        {
            bool flag = true;
            if (this.textTransporter.Text != "")
            {
                this.tblTransporter.ReOpen();
                string[] aField = new string[] { "Transporter_Code" };
                string[] aFind = new string[] { this.textTransporter.Text };
                DataRow data = this.tblTransporter.GetData(aField, aFind);
                if (data == null)
                {
                    this.labelTransporterName.Text = "";
                    flag = false;
                }
                else
                {
                    this.labelTransporterName.Text = data["Transporter_Name"].ToString().Trim();
                    this.labelTransporterName.Refresh();
                    flag = true;
                }
            }
            return flag;
        }

        private bool validTruck()
        {
            bool flag = false;
            if (this.textTruck.Text.Trim() != "")
            {
                this.tblTruck.ReOpen();
                string[] aField = new string[] { "Truck_Number" };
                string[] aFind = new string[] { this.textTruck.Text.Trim() };
                int recNo = this.tblTruck.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    flag = false;
                }
                else
                {
                    this.textTruck.Text = this.tblTruck.DT.Rows[recNo]["Truck_Number"].ToString().Trim();
                    if (this.textTanker.Text.Trim() == "")
                    {
                        this.textTanker.Text = this.tblTruck.DT.Rows[recNo]["Tanker_no"].ToString().Trim();
                    }
                    this.tblTanker.ReOpen();
                    string[] textArray3 = new string[] { "Tanker_No" };
                    string[] textArray4 = new string[] { this.textTanker.Text.Trim() };
                    int num2 = this.tblTanker.GetRecNo(textArray3, textArray4);
                    if (num2 <= -1)
                    {
                        this.labelTankerMax.Text = "Max.Tanker = -";
                    }
                    else
                    {
                        this.labelTankerMax.Text = "Max.Tanker = " + $"{this.tblTanker.DT.Rows[num2]["Capacity"].ToString().Trim():N0}" + " Kg";
                        this.labelTankerMax.Text = (this.tblTanker.DT.Rows[num2]["Check_tanker"].ToString() != "P") ? ((this.tblTanker.DT.Rows[num2]["Check_tanker"].ToString() != "K") ? (this.labelTankerMax.Text + " (NOT CHECK)") : (this.labelTankerMax.Text + " (Tolerance : " + this.tblTanker.DT.Rows[num2]["CheckTankerKG"].ToString() + " KG)")) : (this.labelTankerMax.Text + " (Tolerance : " + this.tblTanker.DT.Rows[num2]["CheckTankerTol"].ToString() + " %)");
                    }
                    if (this.textTransporter.Text == "")
                    {
                        this.textTransporter.Text = this.tblTruck.DT.Rows[recNo]["Transporter_Code"].ToString().Trim();
                        string[] textArray5 = new string[] { "Transporter_Code" };
                        string[] textArray6 = new string[] { this.textTransporter.Text };
                        DataRow data = this.tblTransporter.GetData(textArray5, textArray6);
                        if (data != null)
                        {
                            this.labelTransporterName.Text = data["Transporter_Name"].ToString().Trim();
                        }
                    }
                    this.maxTare = this.tblTruck.DT.Rows[recNo]["max_Tare"].ToString().Trim();
                    this.minTare = this.tblTruck.DT.Rows[recNo]["min_Tare"].ToString().Trim();
                    flag = true;
                }
            }
            return flag;
        }
    }
}

