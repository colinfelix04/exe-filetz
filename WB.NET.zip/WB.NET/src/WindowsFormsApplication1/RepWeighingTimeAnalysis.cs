﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.Text;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class RepWeighingTimeAnalysis : Form
    {
        public string zAuto = "0";
        public double intervalTime = Program.StrToDouble(WBSetting.weighingAnalysis, 0);
        private WBTable tblComm = new WBTable();
        private WBTable tblTransType = new WBTable();
        private WBTable tblTransporter = new WBTable();
        private DataRow[] rComm;
        private DataRow[] rTransporter;
        private DataRow[] rTransType;
        private IContainer components = null;
        public GroupBox groupBox3;
        public DateTimePicker monthCalendar1;
        public Label labelFromDate;
        public Label labelToDate;
        public DateTimePicker monthCalendar2;
        public Label labelProses2;
        public Label labelProses1;
        public Label labelHeader;
        public Button buttonClose;
        public Button buttonProcess;

        public RepWeighingTimeAnalysis()
        {
            this.InitializeComponent();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.intervalTime == 0.0)
            {
                MessageBox.Show("Weighing analysis time hasn't been maintained yet! Please contact administrator!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (Math.Abs((this.monthCalendar1.Value - this.monthCalendar2.Value).Days) > Math.Abs(14))
            {
                MessageBox.Show("Date interval must be less than 2 weeks", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                this.labelProses1.Visible = true;
                this.labelProses2.Visible = true;
                HTML html = new HTML();
                html = this.generateRep(this.monthCalendar1.Value, this.monthCalendar2.Value, WBData.sCoyCode, WBData.sLocCode, this.zAuto);
                if (html != null)
                {
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + html.File) }
                    };
                    report.ShowDialog();
                    html.Dispose();
                    report.Dispose();
                }
                this.labelProses1.Text = "";
                this.labelProses1.Refresh();
                this.labelProses2.Text = "";
                this.labelProses2.Refresh();
            }
        }

        public bool checkUntolerance(DateTime dateFrom, DateTime dateTo, string coy, string loc)
        {
            bool flag = false;
            WBTable table = this.getQuery(dateFrom, dateTo, coy, loc);
            int num = 0;
            while (true)
            {
                if (num < (table.DT.Rows.Count - 1))
                {
                    DataRow row = table.DT.Rows[num];
                    DataRow row2 = table.DT.Rows[num + 1];
                    DateTime time = Convert.ToDateTime(Convert.ToDateTime(row["_date"].ToString()).ToShortDateString() + " " + row["_time"].ToString());
                    DateTime time2 = Convert.ToDateTime(Convert.ToDateTime(row2["_date"].ToString()).ToShortDateString() + " " + row2["_time"].ToString());
                    TimeSpan span = (TimeSpan) (time2 - time);
                    double num2 = Math.Abs(span.TotalSeconds);
                    if (((num2 <= 0.0) || (num2 > this.intervalTime)) || (row["_wbcode"].ToString() != row2["_wbcode"].ToString()))
                    {
                        num++;
                        continue;
                    }
                    flag = true;
                }
                table.Dispose();
                return flag;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public HTML generateRep(DateTime dateFrom, DateTime dateTo, string coy, string loc, string zAuto)
        {
            HTML html2;
            string[] textArray1 = new string[] { "SELECT comm_code, comm_name FROM wb_commodity WHERE coy = '", coy, "' AND location_code = '", loc, "'" };
            this.tblComm.OpenTable("wb_commodity", string.Concat(textArray1), WBData.conn);
            string[] textArray2 = new string[] { "SELECT transporter_code, transporter_name FROM wb_transporter WHERE coy = '", coy, "' AND location_code = '", loc, "'" };
            this.tblTransporter.OpenTable("wb_transporter", string.Concat(textArray2), WBData.conn);
            string[] textArray3 = new string[] { "SELECT transaction_code, transaction_name FROM wb_transaction_type WHERE coy = '", coy, "' AND location_code = '", loc, "'" };
            this.tblTransType.OpenTable("wb_transaction_type", string.Concat(textArray3), WBData.conn);
            WBTable table = this.getQuery(dateFrom, dateTo, coy, loc);
            if (table.DT.Rows.Count <= 1)
            {
                if (zAuto != "1")
                {
                    MessageBox.Show("No records found!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                html2 = null;
            }
            else
            {
                HTML html = new HTML();
                string path = html.File + @"\LogReport";
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                HTML html3 = html;
                string[] textArray4 = new string[] { html3.File, @"\LogReport\", coy, loc, "WEIGHING_ANALYSIS_", dateFrom.ToString("ddMMyyyy"), ".htm" };
                html3.File = string.Concat(textArray4);
                html.Title = "Weighbridge Indicator Stability Report";
                html.Open();
                html.Write(html.Style());
                StringBuilder builder = new StringBuilder();
                WBTable table2 = new WBTable();
                WBTable table3 = new WBTable();
                string[] textArray5 = new string[] { "SELECT location_name FROM wb_location WHERE coy = '", coy, "' AND location_code = '", loc, "'" };
                table2.OpenTable("wb_location", string.Concat(textArray5), WBData.conn);
                string[] textArray6 = new string[] { "SELECT Coy_Name, Coy_Addr1, Coy_Addr2, Coy_Addr3 FROM wb_setting WHERE coy = '", coy, "' AND location_code = '", loc, "' and usedForWeighing = 'Y'" };
                table3.OpenTable("wb_setting", string.Concat(textArray6), WBData.conn);
                string str2 = "";
                if (this.intervalTime < 60.0)
                {
                    str2 = this.intervalTime + " second(s)";
                }
                else if ((this.intervalTime % 60.0) == 0.0)
                {
                    str2 = Convert.ToInt16((double) (this.intervalTime / 60.0)) + " minute(s)";
                }
                else
                {
                    object[] objArray1 = new object[] { Convert.ToInt16((double) (this.intervalTime / 60.0)), " minute(s) ", Convert.ToInt16((double) (this.intervalTime % 60.0)), " second(s)" };
                    str2 = string.Concat(objArray1);
                }
                builder.Append("<br><font size=5><b>WEIGHING TIME ANALYSIS REPORT</b></font><br>");
                builder.Append("<br><font size=3>List of transactions which Interval of Weighing Time is Less than or Equals to " + str2 + "</font><br><br>");
                string[] textArray7 = new string[] { "<br><font size=4>", table3.DT.Rows[0]["Coy_Name"].ToString(), " (", coy, ")</font>" };
                builder.Append(string.Concat(textArray7));
                string[] textArray8 = new string[] { "<br><font size=4>", table2.DT.Rows[0]["Location_Name"].ToString(), " (", loc, ")</font><br>" };
                builder.Append(string.Concat(textArray8));
                if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                {
                    builder.Append("<font size=2>" + table3.DT.Rows[0]["Coy_Addr1"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                {
                    builder.Append("<font size=2>" + table3.DT.Rows[0]["Coy_Addr2"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                {
                    builder.Append("<font size=2>" + table3.DT.Rows[0]["Coy_Addr3"].ToString() + "</font><br>");
                }
                table2.Dispose();
                table3.Dispose();
                builder.Append("<br><br>");
                builder.Append("<table border='0'>");
                builder.Append("<tr class=bd>");
                builder.Append("<td>Selected Date</td>");
                string[] textArray9 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                builder.Append(string.Concat(textArray9));
                builder.Append("</tr>");
                builder.Append("<tr class=bd>");
                builder.Append("<td>Report Date</td>");
                builder.Append("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                builder.Append("</tr>");
                builder.Append("</table>");
                builder.Append("<br/><br/><br/>");
                builder.Append("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                builder.Append("<tr class=bd>");
                builder.Append("<th>No.</th>");
                builder.Append("<th>Weighing Date</th>");
                builder.Append("<th>WB Code</th>");
                builder.Append("<th>Truck No</th>");
                builder.Append("<th>Transaction Code</th>");
                builder.Append("<th>Reference No</th>");
                builder.Append("<th>WX</th>");
                builder.Append("<th>Weighing</th>");
                builder.Append("<th>Weighing Time</th>");
                builder.Append("<th style='background-color:#ffff00'>Time Difference</th>");
                builder.Append("<th>Gross</th>");
                builder.Append("<th>Tare</th>");
                builder.Append("<th>Net</th>");
                builder.Append("<th>Transporter</th>");
                builder.Append("<th>Driver Name</th>");
                builder.Append("<th>Commodity</th>");
                builder.Append("</tr>");
                int num = 1;
                bool flag = false;
                int num2 = 0;
                while (true)
                {
                    if (num2 >= (table.DT.Rows.Count - 1))
                    {
                        if (flag)
                        {
                            html.Write(builder.ToString());
                            html.Write("</table>");
                            html.Write("<br>");
                            html.Write("<br>");
                            builder.Clear();
                            table.Dispose();
                            html.Close();
                            html2 = html;
                        }
                        else
                        {
                            if (zAuto != "1")
                            {
                                MessageBox.Show("No records found!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            }
                            builder.Clear();
                            table.Dispose();
                            html.Close();
                            html2 = null;
                        }
                        break;
                    }
                    DataRow row = table.DT.Rows[num2];
                    DataRow row2 = table.DT.Rows[num2 + 1];
                    DateTime time2 = Convert.ToDateTime(Convert.ToDateTime(row["_date"].ToString()).ToShortDateString() + " " + row["_time"].ToString());
                    DateTime time3 = Convert.ToDateTime(Convert.ToDateTime(row2["_date"].ToString()).ToShortDateString() + " " + row2["_time"].ToString());
                    TimeSpan span = (TimeSpan) (time3 - time2);
                    double num3 = Math.Abs(span.TotalSeconds);
                    if (((num3 > 0.0) && (num3 <= this.intervalTime)) && (row["_wbcode"].ToString() == row2["_wbcode"].ToString()))
                    {
                        flag = true;
                        this.labelProses1.Text = num.ToString();
                        this.labelProses1.Refresh();
                        this.labelProses2.Text = row["ref"].ToString();
                        this.labelProses2.Refresh();
                        this.rComm = this.tblComm.DT.Select("comm_code = '" + row["comm_code"].ToString() + "'");
                        this.rTransType = this.tblTransType.DT.Select("transaction_code = '" + row["transaction_code"].ToString() + "'");
                        this.rTransporter = this.tblTransporter.DT.Select("transporter_code = '" + row["transporter_code"].ToString() + "'");
                        builder.Append("<tr class=bd>");
                        builder.Append("<td nowrap align='center' rowspan='2'>" + num + "</td>");
                        builder.Append("<td nowrap rowspan='2'>" + Convert.ToDateTime(row["_date"].ToString()).ToShortDateString() + "</td>");
                        builder.Append("<td nowrap align='center' rowspan='2'>" + row["_wbcode"].ToString() + "</td>");
                        builder.Append("<td nowrap>" + row["truck_number"].ToString() + "</td>");
                        if (this.rTransType.Length != 0)
                        {
                            builder.Append("<td nowrap>" + this.rTransType[0]["transaction_name"].ToString() + "</td>");
                        }
                        else
                        {
                            builder.Append("<td nowrap>&nbsp;</td>");
                        }
                        builder.Append("<td nowrap>" + row["ref"].ToString() + "</td>");
                        builder.Append("<td nowrap align='center'>" + row["wx"].ToString() + "</td>");
                        if (row["idp"].ToString() == "1")
                        {
                            builder.Append("<td nowrap align='center'>" + row["idp"].ToString() + "st</td>");
                        }
                        else if (row["idp"].ToString() == "2")
                        {
                            builder.Append("<td nowrap align='center'>" + row["idp"].ToString() + "nd</td>");
                        }
                        else if (row["idp"].ToString() == "3")
                        {
                            builder.Append("<td nowrap align='center'>" + row["idp"].ToString() + "rd</td>");
                        }
                        else if (row["idp"].ToString() == "4")
                        {
                            builder.Append("<td nowrap align='center'>" + row["idp"].ToString() + "th</td>");
                        }
                        builder.Append("<td nowrap align='center'>" + row["_time"].ToString() + "</td>");
                        object[] objArray2 = new object[] { "<td nowrap align='center' rowspan='2'  style='background-color:#ffff00'>", Math.Truncate((double) (num3 / 60.0)), "m  ", num3 % 60.0, "s</td>" };
                        builder.Append(string.Concat(objArray2));
                        builder.Append("<td nowrap align='right'>" + row["gross"].ToString() + "</td>");
                        builder.Append("<td nowrap align='right'>" + row["tare"].ToString() + "</td>");
                        builder.Append("<td nowrap align='right'>" + row["net"].ToString() + "</td>");
                        if (this.rTransporter.Length != 0)
                        {
                            builder.Append("<td nowrap>" + this.rTransporter[0]["transporter_name"].ToString() + "</td>");
                        }
                        else
                        {
                            builder.Append("<td nowrap>&nbsp;</td>");
                        }
                        builder.Append("<td nowrap>" + row["name"].ToString() + "</td>");
                        if (this.rComm.Length == 0)
                        {
                            builder.Append("<td nowrap>" + row["comm_code"].ToString() + "</td>");
                        }
                        else
                        {
                            string[] textArray10 = new string[] { "<td nowrap>", row["comm_code"].ToString(), " (", this.rComm[0]["comm_name"].ToString(), ")</td>" };
                            builder.Append(string.Concat(textArray10));
                        }
                        builder.Append("</tr>");
                        this.rComm = this.tblComm.DT.Select("comm_code = '" + row2["comm_code"].ToString() + "'");
                        this.rTransType = this.tblTransType.DT.Select("transaction_code = '" + row2["transaction_code"].ToString() + "'");
                        this.rTransporter = this.tblTransporter.DT.Select("transporter_code = '" + row2["transporter_code"].ToString() + "'");
                        builder.Append("<tr class=bd>");
                        builder.Append("<td nowrap>" + row2["truck_number"].ToString() + "</td>");
                        if (this.rTransType.Length != 0)
                        {
                            builder.Append("<td nowrap>" + this.rTransType[0]["transaction_name"].ToString() + "</td>");
                        }
                        else
                        {
                            builder.Append("<td nowrap>&nbsp;</td>");
                        }
                        builder.Append("<td nowrap>" + row2["ref"].ToString() + "</td>");
                        builder.Append("<td nowrap align='center'>" + row2["wx"].ToString() + "</td>");
                        if (row2["idp"].ToString() == "1")
                        {
                            builder.Append("<td nowrap align='center'>" + row2["idp"].ToString() + "st</td>");
                        }
                        else if (row2["idp"].ToString() == "2")
                        {
                            builder.Append("<td nowrap align='center'>" + row2["idp"].ToString() + "nd</td>");
                        }
                        else if (row2["idp"].ToString() == "3")
                        {
                            builder.Append("<td nowrap align='center'>" + row2["idp"].ToString() + "rd</td>");
                        }
                        else if (row2["idp"].ToString() == "4")
                        {
                            builder.Append("<td nowrap align='center'>" + row2["idp"].ToString() + "th</td>");
                        }
                        builder.Append("<td nowrap align='center'>" + row2["_time"].ToString() + "</td>");
                        builder.Append("<td nowrap align='right'>" + row2["gross"].ToString() + "</td>");
                        builder.Append("<td nowrap align='right'>" + row2["tare"].ToString() + "</td>");
                        builder.Append("<td nowrap align='right'>" + row2["net"].ToString() + "</td>");
                        if (this.rTransporter.Length != 0)
                        {
                            builder.Append("<td nowrap>" + this.rTransporter[0]["transporter_name"].ToString() + "</td>");
                        }
                        else
                        {
                            builder.Append("<td nowrap>&nbsp;</td>");
                        }
                        builder.Append("<td nowrap>" + row2["name"].ToString() + "</td>");
                        if (this.rComm.Length == 0)
                        {
                            builder.Append("<td nowrap>" + row2["comm_code"].ToString() + "</td>");
                        }
                        else
                        {
                            string[] textArray11 = new string[] { "<td nowrap>", row2["comm_code"].ToString(), " (", this.rComm[0]["comm_name"].ToString(), ")</td>" };
                            builder.Append(string.Concat(textArray11));
                        }
                        builder.Append("</tr>");
                        num++;
                        this.tblComm.Dispose();
                        this.tblTransporter.Dispose();
                        this.tblTransType.Dispose();
                    }
                    num2++;
                }
            }
            return html2;
        }

        private WBTable getQuery(DateTime dateFrom, DateTime dateTo, string coy, string loc)
        {
            WBTable table = new WBTable();
            string sqltext = "";
            string[] textArray1 = new string[0x1b];
            textArray1[0] = " SELECT ref_date, truck_number, ref, transaction_code, wx, idp, _time, _date, _wbcode, transporter_code, name, comm_code, gross, tare, net, split, deleted  FROM  (    SELECT ref_date, truck_number, ref, transaction_code, wx, _timef, _time, _date, _wbcode, transporter_code, name, comm_code, gross, tare, net, split, deleted,           idp = SUBSTRING(_timef, LEN(_timef) - PATINDEX('%[^0-9]%', REVERSE(_timef)) + 2, 32),           idpt = SUBSTRING(_datef, LEN(_datef) - PATINDEX('%[^0-9]%', REVERSE(_datef)) + 2, 32),           idptt = SUBSTRING(_wbcodef, LEN(_wbcodef) - PATINDEX('%[^0-9]%', REVERSE(_wbcodef)) + 2, 32)    FROM    (        SELECT ref_date, truck_number, ref, transaction_code, wx,                time1, time2, time3, time4,                date1, date2, date3, date4,                wbcode1, wbcode2, wbcode3, wbcode4,                transporter_code, name, comm_code, gross, tare, net, split, deleted         FROM wb_transaction         WHERE((date1 >= '";
            textArray1[1] = this.monthCalendar1.Value.ToString("yyyy-MM-dd");
            textArray1[2] = "' and date1 <= '";
            textArray1[3] = this.monthCalendar2.Value.ToString("yyyy-MM-dd");
            textArray1[4] = "') or               (date2 >= '";
            textArray1[5] = this.monthCalendar1.Value.ToString("yyyy-MM-dd");
            textArray1[6] = "' and date2 <= '";
            textArray1[7] = this.monthCalendar2.Value.ToString("yyyy-MM-dd");
            textArray1[8] = "') or               (date3 >= '";
            textArray1[9] = this.monthCalendar1.Value.ToString("yyyy-MM-dd");
            textArray1[10] = "' and date3 <= '";
            textArray1[11] = this.monthCalendar2.Value.ToString("yyyy-MM-dd");
            textArray1[12] = "') or               (date4 >= '";
            textArray1[13] = this.monthCalendar1.Value.ToString("yyyy-MM-dd");
            textArray1[14] = "' and date4 <= '";
            textArray1[15] = this.monthCalendar2.Value.ToString("yyyy-MM-dd");
            textArray1[0x10] = "'))         and(wx is not null and wx != '')         and coy = '";
            textArray1[0x11] = coy;
            textArray1[0x12] = "' and location_code = '";
            textArray1[0x13] = loc;
            textArray1[20] = "'    ) AS p    UNPIVOT    (        _time for _timef IN (time1, time2, time3, time4)    ) AS unpvt1    UNPIVOT    (        _date for _datef IN (date1, date2, date3, date4)    ) AS unpvt2    UNPIVOT    (        _wbcode for _wbcodef IN (wbcode1, wbcode2, wbcode3, wbcode4)    ) AS unpvt3  ) AS x  WHERE idp = idpt  AND idpt = idptt  AND idptt = idp  AND (_date >= '";
            textArray1[0x15] = this.monthCalendar1.Value.ToString("yyyy-MM-dd");
            textArray1[0x16] = "' and _date <= '";
            textArray1[0x17] = this.monthCalendar2.Value.ToString("yyyy-MM-dd");
            textArray1[0x18] = "')  AND ((split IS NULL OR split != 'X') AND ref NOT LIKE '%";
            textArray1[0x19] = Constant.TITIP_TIMBUN_POSTFIX;
            textArray1[0x1a] = "' AND ref NOT LIKE 'X%')  AND (deleted IS NULL OR deleted != 'Y')  ORDER BY _wbcode, _date, _time ";
            sqltext = string.Concat(textArray1);
            table.OpenTable("wb_transaction", sqltext, WBData.conn);
            return table;
        }

        private void InitializeComponent()
        {
            this.groupBox3 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.labelFromDate = new Label();
            this.labelToDate = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.labelProses2 = new Label();
            this.labelProses1 = new Label();
            this.labelHeader = new Label();
            this.buttonClose = new Button();
            this.buttonProcess = new Button();
            this.groupBox3.SuspendLayout();
            base.SuspendLayout();
            this.groupBox3.Controls.Add(this.monthCalendar1);
            this.groupBox3.Controls.Add(this.labelFromDate);
            this.groupBox3.Controls.Add(this.labelToDate);
            this.groupBox3.Controls.Add(this.monthCalendar2);
            this.groupBox3.Location = new Point(0x19, 0x3d);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(0x1b7, 0x45);
            this.groupBox3.TabIndex = 80;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Filter by Weighing Date";
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x63, 0x1a);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.labelFromDate.AutoSize = true;
            this.labelFromDate.Location = new Point(0x1b, 0x1d);
            this.labelFromDate.Name = "labelFromDate";
            this.labelFromDate.Size = new Size(0x3e, 13);
            this.labelFromDate.TabIndex = 3;
            this.labelFromDate.Text = "From Date :";
            this.labelToDate.AutoSize = true;
            this.labelToDate.Location = new Point(0xee, 0x1d);
            this.labelToDate.Name = "labelToDate";
            this.labelToDate.Size = new Size(0x34, 13);
            this.labelToDate.TabIndex = 4;
            this.labelToDate.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x128, 0x1a);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0x13a, 30);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(150, 13);
            this.labelProses2.TabIndex = 0x67;
            this.labelProses2.Text = "Progress . . . . . . . . . . ";
            this.labelProses2.TextAlign = ContentAlignment.MiddleRight;
            this.labelProses2.Visible = false;
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(0x13d, 0x11);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(150, 13);
            this.labelProses1.TabIndex = 0x68;
            this.labelProses1.Text = "1/88888";
            this.labelProses1.TextAlign = ContentAlignment.MiddleRight;
            this.labelProses1.Visible = false;
            this.labelHeader.AutoSize = true;
            this.labelHeader.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelHeader.Location = new Point(0x15, 0x12);
            this.labelHeader.Name = "labelHeader";
            this.labelHeader.Size = new Size(0x116, 20);
            this.labelHeader.TabIndex = 0x66;
            this.labelHeader.Text = "Report of Weighing Time Analysis";
            this.labelHeader.TextAlign = ContentAlignment.TopCenter;
            this.buttonClose.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonClose.Location = new Point(0x165, 150);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new Size(110, 0x22);
            this.buttonClose.TabIndex = 0x6b;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new EventHandler(this.buttonClose_Click);
            this.buttonProcess.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonProcess.Location = new Point(0xf1, 150);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(110, 0x22);
            this.buttonProcess.TabIndex = 0x6a;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1ec, 0xce);
            base.Controls.Add(this.groupBox3);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.labelHeader);
            base.Controls.Add(this.buttonClose);
            base.Controls.Add(this.buttonProcess);
            base.Name = "RepWeighingTimeAnalysis";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Weighing Time Analysis Report";
            base.Load += new EventHandler(this.RepWeighingTimeAnalysis_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void RepWeighingTimeAnalysis_Load(object sender, EventArgs e)
        {
        }
    }
}

