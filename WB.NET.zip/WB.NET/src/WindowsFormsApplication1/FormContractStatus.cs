﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormContractStatus : Form
    {
        private WBTable zTable = new WBTable();
        public string noRef;
        public string doNo;
        public string sUniq;
        public string logKey = "";
        public bool saved = false;
        private string PO;
        private string PO_Item;
        private string SO;
        private string SO_Item;
        private string STO;
        private string STO_Item;
        private string GR_Cust;
        private bool checkClosed = false;
        private bool checkNotClosed = false;
        private IContainer components = null;
        private Button buttonCancel;
        private Button buttonSave;
        private Label label9;
        private Label textDO;
        private Label labelStatus;
        private Label label3;
        private RadioButton radioOpen;
        private RadioButton radioClose;
        private DateTimePicker dateDOClose;
        private ShapeContainer shapeContainer1;
        private RectangleShape rectangleShape1;

        public FormContractStatus()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (!this.radioClose.Checked)
            {
                this.zTable.DR.BeginEdit();
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR["closed"] = "";
                this.zTable.DR["closed_Date"] = this.dateDOClose.Value;
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
                this.zTable.Save();
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Open DO" };
                Program.updateLogHeader("wb_contract", this.logKey, logField, logValue);
                this.saved = true;
                WBTable table2 = new WBTable();
                table2.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and zauto = 'Y' and Do_No LIKE '" + this.zTable.DR["DO_NO"].ToString() + Constant.TITIP_TIMBUN_POSTFIX + "'"), WBData.conn);
                if (table2.DT.Rows.Count == 1)
                {
                    table2.DR = table2.DT.Rows[0];
                    table2.DR.BeginEdit();
                    table2.DR["closed"] = "";
                    table2.DR["closed_Date"] = DateTime.Now;
                    table2.DR["Change_By"] = WBUser.UserID;
                    table2.DR["Change_Date"] = DateTime.Now;
                    table2.DR.EndEdit();
                    table2.Save();
                }
                table2.Dispose();
            }
            else if (MessageBox.Show(Resource.Mes_116 + " " + this.doNo, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
            {
                return;
            }
            else
            {
                this.zTable.DR.BeginEdit();
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR["closed"] = "X";
                this.zTable.DR["closed_by"] = WBUser.UserID;
                this.zTable.DR["closed_Date"] = this.dateDOClose.Value;
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
                this.zTable.Save();
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Close DO" };
                Program.updateLogHeader("wb_contract", this.logKey, logField, logValue);
                this.saved = true;
                WBTable table = new WBTable();
                table.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and zauto = 'Y' and Do_No LIKE '" + this.zTable.DR["DO_NO"].ToString() + Constant.TITIP_TIMBUN_POSTFIX + "'"), WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.logKey = table.DR["uniq"].ToString();
                    table.DR.BeginEdit();
                    table.DR["closed"] = "X";
                    table.DR["closed_by"] = WBUser.UserID;
                    table.DR["closed_Date"] = DateTime.Now;
                    table.DR["Change_By"] = WBUser.UserID;
                    table.DR["Change_Date"] = DateTime.Now;
                    table.DR.EndEdit();
                    table.Save();
                    string[] textArray3 = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] textArray4 = new string[] { "EDIT", WBUser.UserID, "Close/Open DO" };
                    Program.updateLogHeader("wb_contract", this.logKey, textArray3, textArray4);
                }
                table.Dispose();
            }
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormContractStatus_Load(object sender, EventArgs e)
        {
            this.textDO.Text = this.doNo;
            this.zTable.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and uniq = '" + this.sUniq + "'"), WBData.conn);
            this.zTable.DR = this.zTable.DT.Rows[0];
            this.textDO.Text = this.zTable.DR["Do_NO"].ToString();
            this.PO = this.zTable.DR["PO"].ToString();
            this.PO_Item = this.zTable.DR["PO_Item"].ToString();
            this.SO = this.zTable.DR["SO"].ToString();
            this.SO_Item = this.zTable.DR["SO_Item"].ToString();
            this.STO = this.zTable.DR["STO"].ToString();
            this.STO_Item = this.zTable.DR["STO_Item"].ToString();
            this.GR_Cust = this.zTable.DR["GR_Cust"].ToString();
            this.radioClose.Checked = this.zTable.DR["closed"].ToString() == "X";
            this.radioOpen.Checked = this.zTable.DR["closed"].ToString() != "X";
            this.dateDOClose.Value = (this.zTable.DR["closed_Date"].ToString() == "") ? DateTime.Now : Convert.ToDateTime(this.zTable.DR["closed_Date"].ToString());
        }

        private void InitializeComponent()
        {
            this.buttonCancel = new Button();
            this.buttonSave = new Button();
            this.label9 = new Label();
            this.textDO = new Label();
            this.labelStatus = new Label();
            this.label3 = new Label();
            this.radioOpen = new RadioButton();
            this.radioClose = new RadioButton();
            this.dateDOClose = new DateTimePicker();
            this.shapeContainer1 = new ShapeContainer();
            this.rectangleShape1 = new RectangleShape();
            base.SuspendLayout();
            this.buttonCancel.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonCancel.Location = new Point(0xc2, 0x9f);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(80, 0x22);
            this.buttonCancel.TabIndex = 15;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.buttonSave.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonSave.Location = new Point(0x5f, 0x9e);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(80, 0x22);
            this.buttonSave.TabIndex = 14;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x12, 0x12);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x26, 13);
            this.label9.TabIndex = 0x13;
            this.label9.Text = "Do No";
            this.textDO.AutoSize = true;
            this.textDO.Location = new Point(0x59, 0x12);
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0x26, 13);
            this.textDO.TabIndex = 20;
            this.textDO.Text = "Do No";
            this.textDO.Click += new EventHandler(this.label1_Click);
            this.labelStatus.AutoSize = true;
            this.labelStatus.Location = new Point(0x12, 0x34);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new Size(0x25, 13);
            this.labelStatus.TabIndex = 0x15;
            this.labelStatus.Text = "Status";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x12, 110);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x3b, 13);
            this.label3.TabIndex = 0x16;
            this.label3.Text = "Close Date";
            this.radioOpen.AutoSize = true;
            this.radioOpen.Location = new Point(110, 0x49);
            this.radioOpen.Name = "radioOpen";
            this.radioOpen.Size = new Size(0x37, 0x11);
            this.radioOpen.TabIndex = 0x17;
            this.radioOpen.TabStop = true;
            this.radioOpen.Text = "OPEN";
            this.radioOpen.UseVisualStyleBackColor = true;
            this.radioClose.AutoSize = true;
            this.radioClose.Location = new Point(110, 50);
            this.radioClose.Name = "radioClose";
            this.radioClose.Size = new Size(60, 0x11);
            this.radioClose.TabIndex = 0x18;
            this.radioClose.TabStop = true;
            this.radioClose.Text = "CLOSE";
            this.radioClose.UseVisualStyleBackColor = true;
            this.dateDOClose.Format = DateTimePickerFormat.Short;
            this.dateDOClose.Location = new Point(0x5b, 0x6b);
            this.dateDOClose.Name = "dateDOClose";
            this.dateDOClose.Size = new Size(0x6b, 20);
            this.dateDOClose.TabIndex = 0x98;
            this.dateDOClose.Value = new DateTime(0x7dc, 8, 30, 0, 0, 0, 0);
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.rectangleShape1 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(370, 0xd8);
            this.shapeContainer1.TabIndex = 0x99;
            this.shapeContainer1.TabStop = false;
            this.rectangleShape1.Location = new Point(0x59, 0x26);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new Size(0x69, 60);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(370, 0xd8);
            base.ControlBox = false;
            base.Controls.Add(this.dateDOClose);
            base.Controls.Add(this.radioClose);
            base.Controls.Add(this.radioOpen);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.labelStatus);
            base.Controls.Add(this.textDO);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.shapeContainer1);
            base.Name = "FormContractStatus";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Close / Open DO";
            base.Load += new EventHandler(this.FormContractStatus_Load);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void translate()
        {
            this.label9.Text = Resource.Trans_082;
            this.textDO.Text = Resource.Trans_082;
            this.labelStatus.Text = Resource.Lbl_Status;
            this.label3.Text = Resource.Lbl_Close_Date;
            this.radioOpen.Text = Resource.Rdb_Open;
            this.radioClose.Text = Resource.Rdb_Close;
            this.buttonCancel.Text = Resource.Menu_Cancel;
            this.buttonSave.Text = Resource.Save;
            this.Text = Resource.Title_Contract_Status;
        }
    }
}

