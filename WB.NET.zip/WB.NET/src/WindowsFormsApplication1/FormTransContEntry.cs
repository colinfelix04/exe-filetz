﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTransContEntry : Form
    {
        public WBTable getSimilarContainertblTransCont = new WBTable();
        public DataGridView dgvCont;
        public string pMode;
        public string OldContainer = "";
        public bool pSave = false;
        public bool pEditContainerNo = false;
        private IContainer components = null;
        public Label label1;
        public TextBox textBox1;
        public Button button2;
        public Button button1;
        public TextBox textBox2;
        public Label label2;

        public FormTransContEntry()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool flag;
            TextBox[] aText = new TextBox[] { this.textBox1 };
            if (!Program.CheckEmpty(aText))
            {
                flag = false;
                if (!this.OldContainer.Equals(this.textBox1.Text.Trim()))
                {
                    foreach (DataGridViewRow row in (IEnumerable) this.dgvCont.Rows)
                    {
                        if (row.Cells["Container"].Value.ToString().Trim() == this.textBox1.Text.Trim())
                        {
                            flag = true;
                        }
                    }
                }
            }
            else
            {
                return;
            }
            string[] textArray1 = new string[] { "SELECT c.gatepass_number, c.Ref, c.Container, c.Seal  FROM dbo.wb_transContainer c LEFT OUTER JOIN dbo.wb_transaction t  ON c.Coy = t.Coy AND c.Location_Code = t.Location_Code AND c.Ref = t.Ref  LEFT OUTER JOIN dbo.wb_gatepass g  ON c.Coy = g.Coy AND c.Location_Code = g.Location_Code AND c.gatepass_number = g.Gatepass_Number WHERE (g.Deleted IS NULL OR g.Deleted <> 'Y') AND (t.Deleted IS NULL OR t.Deleted <> 'Y')  AND (t.Report_Date IS NULL)  AND c.coy = '", WBData.sCoyCode, "'  AND c.location_code = '", WBData.sLocCode, "'  AND c.container = '", this.textBox1.Text.Trim(), "'" };
            string sqltext = string.Concat(textArray1);
            WBTable table = new WBTable();
            table.OpenTable("wb_transContainer", sqltext, WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                table.Dispose();
                if (!(flag && (this.pMode == "ADD")))
                {
                    if (this.pMode.Equals("EDIT") && !this.textBox1.Text.Trim().Equals(this.OldContainer))
                    {
                        if (MessageBox.Show(Resource.Mes_Edit_Container_No, Resource.Mes_Warning, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                        {
                            return;
                        }
                        else
                        {
                            this.pEditContainerNo = true;
                        }
                    }
                    this.pSave = true;
                    base.Close();
                }
                else
                {
                    MessageBox.Show("The Container Number already exist . . ! ", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.textBox1.Focus();
                }
            }
            else
            {
                table.DR = table.DT.Rows[0];
                string str2 = table.DR["gatepass_number"].ToString();
                string str3 = table.DR["ref"].ToString();
                string[] textArray2 = new string[8];
                textArray2[0] = Resource.Gatepass_070;
                textArray2[1] = " ";
                textArray2[2] = table.DR["container"].ToString();
                textArray2[3] = " ";
                textArray2[4] = Resource.Mes_094;
                textArray2[5] = "\n";
                textArray2[6] = (str2 == "") ? "" : (Resource.Gatepass_001 + " " + str2 + "\n");
                string[] local1 = textArray2;
                string[] local2 = textArray2;
                local2[7] = (str3 == "") ? "" : (Resource.Gatepass_057 + " " + str3);
                string text = string.Concat(local2);
                if (table.DR["REF"].ToString() != "")
                {
                    MessageBox.Show(text, Resource.Mes_Warning, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    string[] textArray3 = new string[9];
                    textArray3[0] = Resource.Gatepass_070;
                    textArray3[1] = " ";
                    textArray3[2] = table.DR["container"].ToString();
                    textArray3[3] = " ";
                    textArray3[4] = Resource.Mes_094;
                    textArray3[5] = "\n";
                    textArray3[6] = Resource.Gatepass_001;
                    textArray3[7] = " ";
                    textArray3[8] = table.DR["gatepass_number"].ToString();
                    MessageBox.Show(string.Concat(textArray3), Resource.Mes_Warning, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                table.Dispose();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransContEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTransContEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            string str = (this.pMode == "ADD") ? Resource.Trans_055 : ((this.pMode == "EDIT") ? Resource.Trans_056 : ((this.pMode == "DELETE") ? Resource.Trans_057 : ""));
            this.Text = str + " " + Resource.Trans_028;
            this.translate();
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.textBox1 = new TextBox();
            this.button2 = new Button();
            this.button1 = new Button();
            this.textBox2 = new TextBox();
            this.label2 = new Label();
            base.SuspendLayout();
            this.label1.Location = new Point(0x1c, 0x1b);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x4b, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Container No.";
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(0x6d, 0x18);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0x97, 20);
            this.textBox1.TabIndex = 0;
            this.button2.Location = new Point(0xa2, 0x6d);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 3;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x51, 0x6d);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 2;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBox2.CharacterCasing = CharacterCasing.Upper;
            this.textBox2.Location = new Point(0x6d, 50);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x97, 20);
            this.textBox2.TabIndex = 1;
            this.label2.Location = new Point(0x1c, 0x35);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x4b, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Seal No.";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x138, 0x94);
            base.ControlBox = false;
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label1);
            base.KeyPreview = true;
            base.Name = "FormTransContEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Entry Container No.";
            base.Load += new EventHandler(this.FormTransContEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransContEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label1.Text = Resource.Gatepass_070;
            this.label2.Text = Resource.Gatepass_062;
            this.button1.Text = Resource.Btn_Save;
            this.button2.Text = Resource.Btn_Cancel;
        }
    }
}

