﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormReasonInput : Form
    {
        public string purpose;
        public bool ok = false;
        public WBTable t_reason = new WBTable();
        private IContainer components = null;
        private Label lbl_title;
        private Label lbl_desc;
        public ComboBox cb_reason;
        private Button btn_ok;
        private Button btn_cancel;

        public FormReasonInput()
        {
            this.InitializeComponent();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            if (this.cb_reason.Text == "")
            {
                MessageBox.Show("Please Input Reason", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                this.ok = true;
                base.Close();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormReasonInput_Load(object sender, EventArgs e)
        {
            if (this.purpose.Equals("REASON_REPRINT_TICKET"))
            {
                this.lbl_title.Text = "Reprint Ticket";
                this.lbl_desc.Text = "Reason for Reprint";
            }
            this.t_reason.OpenTable("wb_reason", "SELECT reason FROM wb_reason WHERE " + WBData.CompanyLocation(" and ( purpose ='" + this.purpose + "' and (deleted is null or deleted = '') ) ORDER BY reason"), WBData.conn);
            foreach (DataRow row in this.t_reason.DT.Rows)
            {
                this.cb_reason.Items.Add(row["reason"].ToString());
            }
        }

        private void InitializeComponent()
        {
            this.lbl_title = new Label();
            this.lbl_desc = new Label();
            this.cb_reason = new ComboBox();
            this.btn_ok = new Button();
            this.btn_cancel = new Button();
            base.SuspendLayout();
            this.lbl_title.AutoSize = true;
            this.lbl_title.Font = new Font("Microsoft Sans Serif", 12.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.lbl_title.Location = new Point(8, 0x12);
            this.lbl_title.Name = "lbl_title";
            this.lbl_title.Size = new Size(0x35, 20);
            this.lbl_title.TabIndex = 0;
            this.lbl_title.Text = "label1";
            this.lbl_desc.AutoSize = true;
            this.lbl_desc.Font = new Font("Microsoft Sans Serif", 12.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.lbl_desc.Location = new Point(8, 0x41);
            this.lbl_desc.Name = "lbl_desc";
            this.lbl_desc.Size = new Size(0x35, 20);
            this.lbl_desc.TabIndex = 1;
            this.lbl_desc.Text = "label2";
            this.cb_reason.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cb_reason.FormattingEnabled = true;
            this.cb_reason.Location = new Point(12, 0x74);
            this.cb_reason.Name = "cb_reason";
            this.cb_reason.Size = new Size(0x1dc, 0x15);
            this.cb_reason.TabIndex = 2;
            this.btn_ok.Location = new Point(0x14c, 160);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new Size(0x4b, 0x17);
            this.btn_ok.TabIndex = 3;
            this.btn_ok.Text = "&OK";
            this.btn_ok.UseVisualStyleBackColor = true;
            this.btn_ok.Click += new EventHandler(this.btn_ok_Click);
            this.btn_cancel.Location = new Point(0x19d, 160);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new Size(0x4b, 0x17);
            this.btn_cancel.TabIndex = 4;
            this.btn_cancel.Text = "&Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new EventHandler(this.btn_cancel_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1f7, 0xc7);
            base.ControlBox = false;
            base.Controls.Add(this.btn_cancel);
            base.Controls.Add(this.btn_ok);
            base.Controls.Add(this.cb_reason);
            base.Controls.Add(this.lbl_desc);
            base.Controls.Add(this.lbl_title);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormReasonInput";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Input Reason";
            base.Load += new EventHandler(this.FormReasonInput_Load);
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

