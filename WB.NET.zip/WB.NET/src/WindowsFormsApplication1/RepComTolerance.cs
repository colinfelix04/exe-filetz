﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class RepComTolerance : Form
    {
        private WBTable tblComm = new WBTable();
        private IContainer components = null;
        private Label labelComm;
        private TextBox boxComm;
        private TextBox boxInc;
        private Button buttonSearch;
        public Button buttonCancel;
        public Button buttonProcess;
        private RadioButton radioInc;
        private RadioButton radioExc;
        private TextBox boxExc;
        private Label label1;
        private Label label2;
        private GroupBox groupBox1;
        private Label label3;
        private TextBox boxComm2;
        private Button buttonSearch2;
        private GroupBox groupBox2;
        private CheckBox checkAll;
        public Label label4;
        public Label labelRecNo;
        public Label labelProcess;

        public RepComTolerance()
        {
            this.InitializeComponent();
        }

        private void boxInc_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (!char.IsDigit(e.KeyChar) && (e.KeyChar != '\b')) && (e.KeyChar != '.');
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            string sqltext = "SELECT coy, location_code, comm_code, comm_name, unit, Tolerance, Gross_Weight, Netto_Weight FROM wb_commodity WHERE 1=1 ";
            if (!this.checkAll.Checked)
            {
                string[] textArray1 = new string[] { sqltext, "AND Coy = '", WBData.sCoyCode, "' and Location_Code = '", WBData.sLocCode, "' " };
                sqltext = string.Concat(textArray1);
            }
            if (this.boxComm2.Text != "")
            {
                if (this.boxComm.Text != "")
                {
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE comm_code = '" + this.boxComm.Text + "'", WBData.conn);
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE comm_code = '" + this.boxComm2.Text + "'", WBData.conn);
                    if ((table2.DT.Rows.Count <= 0) || (table3.DT.Rows.Count <= 0))
                    {
                        this.labelRecNo.Text = "0 / 0";
                        this.labelRecNo.Refresh();
                        MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        return;
                    }
                    else
                    {
                        string[] textArray2 = new string[] { sqltext, "AND comm_code >= '", this.boxComm.Text, "' and comm_code <= '", this.boxComm2.Text, "'" };
                        sqltext = string.Concat(textArray2);
                    }
                }
                else
                {
                    this.labelRecNo.Text = "0 / 0";
                    this.labelRecNo.Refresh();
                    MessageBox.Show("Please fill Field Commodity From");
                    this.boxComm.Focus();
                    return;
                }
            }
            else if (this.boxComm.Text != "")
            {
                sqltext = sqltext + "AND comm_code = '" + this.boxComm.Text + "' ";
            }
            if (this.radioInc.Checked && (this.boxInc.Text != ""))
            {
                sqltext = sqltext + "AND tolerance = '" + this.boxInc.Text + "' ";
            }
            if (this.radioExc.Checked && (this.boxExc.Text != ""))
            {
                sqltext = sqltext + "AND tolerance != '" + this.boxExc.Text + "' ";
            }
            sqltext = sqltext + "ORDER BY coy, location_code, comm_code";
            WBTable table = new WBTable();
            table.OpenTable("wb_commodity", sqltext, WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                this.labelRecNo.Text = "0 / 0";
                this.labelRecNo.Refresh();
                MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                this.Cursor = Cursors.WaitCursor;
                this.labelProcess.Visible = true;
                this.labelRecNo.Visible = true;
                this.labelProcess.Refresh();
                this.labelRecNo.Refresh();
                HTML html = new HTML();
                html.File = html.File + @"\" + WBUser.UserID + "_commodityTolerance.htm";
                html.Title = "List of Commodity Tolerance";
                html.Open();
                html.Write(html.Style());
                html.Write("<br><font size=5><b>COMMODITY TOLERANCE REPORT</b></font><br>");
                string[] textArray3 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                html.Write(string.Concat(textArray3));
                string[] textArray4 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                html.Write(string.Concat(textArray4));
                if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                {
                    html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                {
                    html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                {
                    html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                }
                html.Write("<br><br>");
                html.Write("<font size=3>");
                if (this.checkAll.Checked)
                {
                    html.Write("<br>FOR ALL COMPANY</b>");
                }
                html.Write("</font><br><br>");
                html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                if ((this.boxComm.Text != "") && (this.boxComm2.Text == ""))
                {
                    html.Write("<tr class=bd>");
                    html.Write("<td>Commodity</td>");
                    html.Write("<td>: <b>" + this.boxComm.Text + "</b></td>");
                    html.Write("</tr>");
                }
                if ((this.boxComm.Text != "") && (this.boxComm2.Text != ""))
                {
                    html.Write("<tr class=bd>");
                    html.Write("<td>Commodity</td>");
                    string[] textArray5 = new string[] { "<td>: <b>", this.boxComm.Text, "</b> to <b>", this.boxComm2.Text, "</b></td>" };
                    html.Write(string.Concat(textArray5));
                    html.Write("</tr>");
                }
                if (this.radioInc.Checked && (this.boxInc.Text != ""))
                {
                    html.Write("<tr class=bd>");
                    html.Write("<td>Tolerance (Include)</td>");
                    html.Write("<td>: <b>" + this.boxInc.Text + "</b></td>");
                    html.Write("</tr>");
                }
                if (this.radioExc.Checked && (this.boxExc.Text != ""))
                {
                    html.Write("<tr class=bd>");
                    html.Write("<td>Tolerance (Exclude)</td>");
                    html.Write("<td>: <b>" + this.boxExc.Text + "</b></td>");
                    html.Write("</tr>");
                }
                html.Write("<tr class=bd>");
                html.Write("<td>Report Date</td>");
                html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                html.Write("</tr>");
                html.Write("</table>");
                html.Write("<br/><br/><br/>");
                html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1><tr>");
                html.Write("<td align=center><b>No.</b></td>");
                html.Write("<td align=center><b>Company</b></td>");
                html.Write("<td align=center><b>Location</b></td>");
                html.Write("<td align=center><b>Commodity Code</b></td>");
                html.Write("<td align=center><b>Commodity Name</b></td>");
                html.Write("<td align=center><b>UOM</b></td>");
                html.Write("<td align=center><b>Tolerance (%)</b></td>");
                html.Write("<td align=center><b>Gross Weight (KG)</b></td>");
                html.Write("<td align=center><b>Net Weight (KG)</b></td>");
                html.Write("</tr>");
                int num = 1;
                int num2 = 0;
                double count = table.DT.Rows.Count;
                foreach (DataRow row in table.DT.Rows)
                {
                    num2++;
                    this.labelRecNo.Text = num2.ToString() + " / " + count.ToString();
                    this.labelRecNo.Refresh();
                    html.Write("<tr class='bd'>");
                    html.Write("<td align=center>" + num + "</td>");
                    html.Write("<td align=center>" + row["Coy"].ToString() + "</td>");
                    html.Write("<td align=center>" + row["Location_Code"].ToString() + "</td>");
                    html.Write("<td>" + row["comm_code"].ToString() + "</td>");
                    html.Write("<td>" + row["comm_name"].ToString() + "</td>");
                    if (row["unit"].ToString() == "")
                    {
                        html.Write("<td align=center>-</td>");
                    }
                    else
                    {
                        html.Write("<td align=center>" + row["unit"].ToString() + "</td>");
                    }
                    html.Write("<td align=right>" + row["tolerance"].ToString() + "</td>");
                    html.Write("<td align=right>" + row["gross_weight"].ToString() + "</td>");
                    html.Write("<td align=right>" + row["netto_weight"].ToString() + "</td>");
                    html.Write("</tr>");
                    num++;
                }
                html.Write("</table>");
                html.Write("<br><br><br>");
                html.writeSign();
                html.Close();
                new ViewReport { webBrowser1 = { Url = new Uri(html.File) } }.ShowDialog();
                this.Cursor = Cursors.Default;
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.boxComm.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.boxComm.Focus();
            }
            commodity.Dispose();
        }

        private void buttonSearch2_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.boxComm2.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.boxComm2.Focus();
            }
            commodity.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.labelComm = new Label();
            this.boxComm = new TextBox();
            this.boxInc = new TextBox();
            this.buttonSearch = new Button();
            this.buttonCancel = new Button();
            this.buttonProcess = new Button();
            this.radioInc = new RadioButton();
            this.radioExc = new RadioButton();
            this.boxExc = new TextBox();
            this.label1 = new Label();
            this.label2 = new Label();
            this.groupBox1 = new GroupBox();
            this.label3 = new Label();
            this.boxComm2 = new TextBox();
            this.buttonSearch2 = new Button();
            this.groupBox2 = new GroupBox();
            this.checkAll = new CheckBox();
            this.label4 = new Label();
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            base.SuspendLayout();
            this.labelComm.AutoSize = true;
            this.labelComm.Location = new Point(6, 0x1b);
            this.labelComm.Name = "labelComm";
            this.labelComm.Size = new Size(30, 13);
            this.labelComm.TabIndex = 0x48;
            this.labelComm.Text = "From";
            this.boxComm.Location = new Point(0x2d, 0x18);
            this.boxComm.Name = "boxComm";
            this.boxComm.Size = new Size(0xb3, 20);
            this.boxComm.TabIndex = 0x49;
            this.boxInc.Location = new Point(0x54, 0x13);
            this.boxInc.MaxLength = 7;
            this.boxInc.Name = "boxInc";
            this.boxInc.Size = new Size(70, 20);
            this.boxInc.TabIndex = 0x4c;
            this.boxInc.KeyPress += new KeyPressEventHandler(this.boxInc_KeyPress);
            this.buttonSearch.Location = new Point(230, 0x16);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new Size(0x17, 0x17);
            this.buttonSearch.TabIndex = 0x4d;
            this.buttonSearch.Text = "..";
            this.buttonSearch.UseVisualStyleBackColor = true;
            this.buttonSearch.Click += new EventHandler(this.buttonSearch_Click);
            this.buttonCancel.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonCancel.Location = new Point(0x160, 0x6a);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(110, 0x22);
            this.buttonCancel.TabIndex = 0x4f;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.buttonProcess.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonProcess.Location = new Point(0x160, 0x3e);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(110, 0x22);
            this.buttonProcess.TabIndex = 80;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.radioInc.AutoSize = true;
            this.radioInc.Checked = true;
            this.radioInc.Location = new Point(10, 20);
            this.radioInc.Name = "radioInc";
            this.radioInc.Size = new Size(60, 0x11);
            this.radioInc.TabIndex = 0x51;
            this.radioInc.TabStop = true;
            this.radioInc.Text = "Include";
            this.radioInc.UseVisualStyleBackColor = true;
            this.radioInc.CheckedChanged += new EventHandler(this.radioInc_CheckedChanged);
            this.radioExc.AutoSize = true;
            this.radioExc.Location = new Point(10, 0x2d);
            this.radioExc.Name = "radioExc";
            this.radioExc.Size = new Size(0x3f, 0x11);
            this.radioExc.TabIndex = 0x52;
            this.radioExc.Text = "Exclude";
            this.radioExc.UseVisualStyleBackColor = true;
            this.radioExc.CheckedChanged += new EventHandler(this.radioExc_CheckedChanged);
            this.boxExc.Location = new Point(0x54, 0x2c);
            this.boxExc.MaxLength = 7;
            this.boxExc.Name = "boxExc";
            this.boxExc.Size = new Size(70, 20);
            this.boxExc.TabIndex = 0x53;
            this.boxExc.Visible = false;
            this.boxExc.KeyPress += new KeyPressEventHandler(this.boxInc_KeyPress);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x9d, 0x16);
            this.label1.Name = "label1";
            this.label1.Size = new Size(15, 13);
            this.label1.TabIndex = 0x54;
            this.label1.Text = "%";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x9d, 0x2f);
            this.label2.Name = "label2";
            this.label2.Size = new Size(15, 13);
            this.label2.TabIndex = 0x55;
            this.label2.Text = "%";
            this.label2.Visible = false;
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.boxComm2);
            this.groupBox1.Controls.Add(this.buttonSearch2);
            this.groupBox1.Controls.Add(this.labelComm);
            this.groupBox1.Controls.Add(this.boxComm);
            this.groupBox1.Controls.Add(this.buttonSearch);
            this.groupBox1.Location = new Point(0x16, 0x38);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x124, 0x55);
            this.groupBox1.TabIndex = 0x56;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Commodity";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(6, 0x35);
            this.label3.Name = "label3";
            this.label3.Size = new Size(20, 13);
            this.label3.TabIndex = 0x4e;
            this.label3.Text = "To";
            this.boxComm2.Location = new Point(0x2d, 50);
            this.boxComm2.Name = "boxComm2";
            this.boxComm2.Size = new Size(0xb3, 20);
            this.boxComm2.TabIndex = 0x4f;
            this.buttonSearch2.Location = new Point(230, 0x30);
            this.buttonSearch2.Name = "buttonSearch2";
            this.buttonSearch2.Size = new Size(0x17, 0x17);
            this.buttonSearch2.TabIndex = 80;
            this.buttonSearch2.Text = "..";
            this.buttonSearch2.UseVisualStyleBackColor = true;
            this.buttonSearch2.Click += new EventHandler(this.buttonSearch2_Click);
            this.groupBox2.Controls.Add(this.boxInc);
            this.groupBox2.Controls.Add(this.radioInc);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.radioExc);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.boxExc);
            this.groupBox2.Location = new Point(0x15, 0x93);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0x124, 0x4a);
            this.groupBox2.TabIndex = 0x57;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tolerance";
            this.checkAll.AutoSize = true;
            this.checkAll.Checked = true;
            this.checkAll.CheckState = CheckState.Checked;
            this.checkAll.ForeColor = SystemColors.ControlText;
            this.checkAll.Location = new Point(0x15, 0xee);
            this.checkAll.Name = "checkAll";
            this.checkAll.Size = new Size(0xd1, 0x11);
            this.checkAll.TabIndex = 0x58;
            this.checkAll.Text = "Show from all company and all location";
            this.checkAll.UseVisualStyleBackColor = true;
            this.label4.AutoSize = true;
            this.label4.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label4.Location = new Point(0x11, 14);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0xf1, 20);
            this.label4.TabIndex = 0x59;
            this.label4.Text = "Commodity Tolerance Report";
            this.label4.TextAlign = ContentAlignment.TopCenter;
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x183, 0xef);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 0x5b;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x10b, 0xef);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 90;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1e6, 0x10a);
            base.ControlBox = false;
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.checkAll);
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.buttonProcess);
            base.Controls.Add(this.buttonCancel);
            base.Name = "RepComTolerance";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Commodity Tolerance Report";
            base.Load += new EventHandler(this.WindowsFormsApplication1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void radioExc_CheckedChanged(object sender, EventArgs e)
        {
            this.boxExc.Visible = true;
            this.boxExc.Text = "";
            this.label2.Visible = true;
            this.boxInc.Visible = false;
            this.label1.Visible = false;
        }

        private void radioInc_CheckedChanged(object sender, EventArgs e)
        {
            this.boxInc.Visible = true;
            this.boxInc.Text = "";
            this.label1.Visible = true;
            this.boxExc.Visible = false;
            this.label2.Visible = false;
        }

        private void WindowsFormsApplication1_Load(object sender, EventArgs e)
        {
            this.tblComm.OpenTable("wb_comm", "Select * from wb_commodity", WBData.conn);
            Program.AutoComp(this.tblComm, "Comm_code", this.boxComm);
            Program.AutoComp(this.tblComm, "Comm_code", this.boxComm2);
        }
    }
}

