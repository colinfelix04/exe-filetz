﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic;
    using SAP.Middleware.Connector;
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.IO.Ports;
    using System.Windows.Forms;
    using WindowsFormsApplication1.E_Grading;

    public class FormSetting : Form
    {
        public bool perubahan = false;
        private DataTable tmpTrans;
        private DataTable tmpSetting;
        private DataRow transBefore;
        private DataRow settingBefore;
        public WBTable tSetting = new WBTable();
        public WBTable tLocation = new WBTable();
        public WBTable tCompany = new WBTable();
        public WBTable t_camera = new WBTable();
        public WBTable tbl_warning_trace;
        public int nRowSetting = -1;
        public SerialPort serialPort1 = new SerialPort();
        private char schSAP = 'F';
        private bool check_tanker;
        private string grCUstReq = "N";
        private string grCustReq2 = "N";
        private string OnOff = "OFF";
        public string result = "";
        public string logKey = "";
        public string pMode = "";
        private WBTable tblTrans = new WBTable();
        public bool reloadTicket = false;
        public bool saved = false;
        public bool grCustSynch = false;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private WBIndicator_File wbIndicator = new WBIndicator_File();
        private IContainer components = null;
        private TabControl tabGate;
        private TabPage tabPage1;
        private Button button2;
        private Button button3;
        private TabPage tabPage3;
        private TextBox textAdress3;
        private TextBox textAdress2;
        private TextBox textAdress1;
        private TextBox textLocCode;
        private TextBox textCoyCode;
        private TextBox textCoyName;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textWBCode;
        private Label label5;
        private TabControl tabControl2;
        private TabPage tabPage5;
        private TabPage tabPage6;
        private TabPage tabPage4;
        private Label label46;
        private TextBox textEmailEditSubject;
        private Label label47;
        private TextBox textEmailEditCC;
        private Label label48;
        private TextBox textEmailEditTO;
        private Label label49;
        private Label label42;
        private TextBox textEmailTankerSubject;
        private Label label45;
        private TextBox textEmailTankerCC;
        private Label label44;
        private TextBox textEmailTankerTO;
        private Label label43;
        private TextBox textSender_Name;
        private TextBox textSMTP_Server;
        private Label label25;
        private CheckBox checkEmailAllow;
        private Label label51;
        private TextBox textSignApproved;
        private Label label20;
        private TextBox textSignChecked;
        private Label label19;
        private TextBox textSignCreate;
        private Label label18;
        private Label label53;
        private Label label39;
        private TextBox textScout2;
        private Label label40;
        private TextBox textScout1;
        private Label label37;
        private TextBox textLoose2;
        private Label label38;
        private TextBox textLoose1;
        private Label label35;
        private TextBox textSmall2;
        private Label label36;
        private TextBox textSmall1;
        private Label label33;
        private TextBox textMid2;
        private Label label34;
        private TextBox textMid1;
        private Label label32;
        private TextBox textLarge2;
        private Label label31;
        private TextBox textLarge1;
        private Label label54;
        private Label label58;
        private Panel panel8;
        private TextBox textSO_Item;
        private TextBox textStorage_Supp;
        private TextBox textPlant_Supp;
        private TextBox textMov_Type;
        private TextBox textBatch;
        private TextBox textUoM;
        private TextBox textStorage_Rcv;
        private TextBox textPlant_Rcv;
        private Label label67;
        private Label label66;
        private Label label65;
        private Label label64;
        private Label label63;
        private Label label62;
        private Label label61;
        private Label label60;
        private TextBox textBill_Lading;
        private Label label59;
        private Label label57;
        private Panel panel7;
        private TextBox textSAPServer;
        private Button button5;
        private TextBox textSAPPassword;
        private Label label55;
        private Label label56;
        private TextBox textSAPLoginID;
        private TextBox textSTO_Item;
        private TextBox textGR_Discharge;
        private TextBox textTransport_Type;
        private TextBox textGR_Storage;
        private TextBox textGI_Batch;
        private TextBox textGI_Storage;
        private Label label70;
        private Label label71;
        private Label label72;
        private Label label73;
        private Label label74;
        private Label label75;
        private TextBox textTransit_Storage;
        private Label label76;
        private TextBox textLine;
        private Label label69;
        private TextBox textUpload_Type;
        private Label label68;
        private Label label78;
        private RadioButton radioReportOUT;
        private RadioButton radioReportIN;
        private TabPage tabPage7;
        private CheckBox checkISCC;
        private GroupBox groupBoxGHG;
        private Label label79;
        private TextBox textGHG_F;
        private RadioButton radioGHG2;
        private RadioButton radioGHG1;
        private TextBox textISCC;
        private Label label80;
        private Label label81;
        private Label label83;
        private Label label84;
        private TextBox textGHG_S;
        private Label label82;
        private Button buttonTestOpen;
        private Label label86;
        private Label label85;
        private TextBox textSender_Pass;
        private OpenFileDialog openFileDialog1;
        private TabPage tabPage8;
        private DataGridView dgWarningTrace;
        private DataGridViewTextBoxColumn Type;
        private DataGridViewTextBoxColumn FieldName;
        private DataGridViewCheckBoxColumn traceOnly;
        private DataGridViewCheckBoxColumn Selected;
        private DataGridViewTextBoxColumn Uniq;
        private TextBox textCompanyCode;
        private Label label24;
        private GroupBox GBoxAutoSPB;
        private RadioButton RdoSPBFFbStd;
        private RadioButton RdoSPBStd;
        private RadioButton RdoSPBFFB;
        private RadioButton RdoSPBNo;
        private Label label102;
        private Label label105;
        private Label label106;
        private TextBox textFormISO;
        private Label label101;
        private TabPage tabPageSystem;
        private RadioButton radioTypeRefinery;
        private RadioButton radioTypePOM;
        private Label label27;
        private Button buttonTicket1;
        private TextBox textTicket;
        private Button button8;
        private Label label50;
        private CheckBox checkContainer;
        private CheckBox checkTrailer;
        private CheckBox checkWBNo;
        private CheckBox checkStorage;
        private Label label29;
        private Panel panelPOMSetting;
        private Label label107;
        private Label label108;
        private CheckBox checkRef6;
        private Label label109;
        private DateTimePicker dateRef6;
        private CheckBox checkNonContract;
        private Label label117;
        private DateTimePicker dtValidISCC;
        private SerialPort serialPort2;
        private CheckBox checkDirect;
        private Label label118;
        private RadioButton radioIndonesia;
        private RadioButton radioAfrica;
        private Button buttonTest;
        private GroupBox GrpInfo;
        private Label label126;
        private TextBox textNumOfWb;
        private Label label125;
        private TextBox textTolerance;
        private Label label124;
        private TextBox textCapacity;
        private Label label123;
        private TextBox textBrand;
        private Label label128;
        private Label label127;
        private Label labelBrand;
        private Label labelPort;
        private CheckBox cbSSL;
        private TextBox textPort;
        private GroupBox groupBox2;
        private RadioButton radioAuto1;
        private RadioButton radioAuto0;
        private Label labelCode;
        private Label labelGatepassCode;
        private TextBox textGatepassCode;
        private Label labelTACode;
        private TextBox textTACode;
        private Label label129;
        private RadioButton radioTrans1;
        private RadioButton radioTrans3;
        private RadioButton radioTrans2;
        private RadioButton radioLoadNo;
        private RadioButton radioLoadYes;
        private Label labelLoadUnload;
        private Button buttonGatepass;
        private TextBox textGatepass;
        private Label label130;
        private TextBox textIso3;
        private Label labeliso3;
        private TextBox textIso2;
        private Label labeliso2;
        private Label labelTktSign;
        private TextBox textApproved;
        private Label labelApproved;
        private TabPage tabTool;
        private Button buttonOpenLockRecord;
        private Button buttonOpenLockTrans;
        private Button btnReset_EditQty;
        private Button btnReset_EditRec;
        private TextBox txtRef;
        private Label label17;
        private GroupBox groupBox4;
        private Label label137;
        private CheckBox checkTareAllComm;
        private TextBox textMinTrans;
        private CheckBox checkTare;
        private Label label22;
        private Label label136;
        private Label label135;
        private TextBox textBoxGrossHistoryVariance;
        private Label label134;
        private TextBox textBoxGrossHistoryMinute;
        private Label label133;
        private TextBox numericInterval;
        private MaskedTextBox textSAPTime;
        private Label label89;
        private RadioButton rboScheduleNo;
        private Label label90;
        private RadioButton rboScheduleYes;
        private Label label96;
        private Panel panelZWB;
        private Label label23;
        private RadioButton rboCpNo;
        private RadioButton rboCpYes;
        private RadioButton radioZWBNo;
        private RadioButton radioZWBYes;
        private Label label92;
        private Label labelLang;
        private RadioButton radioLangEnglish;
        private RadioButton radioLangFrench;
        private TextBox textBoxToTesting;
        private Label label21;
        private Label labelRemarkEmailTesting;
        private CheckBox checkBoxPrintGatepass;
        private RadioButton radioMalaysia;
        private Button btn_advise;
        private TextBox text_advise;
        private Label label52;
        private CheckBox checkBoxEnableScanCardSPB;
        private ToolTip toolTip1;
        private Label labelDomain;
        private TextBox textDomain;
        private PageSetupDialog pageSetupDialog1;
        private Label labelDescWarningField;
        private TextBox textISCC_F_Remark;
        private Label labelRemark_FFB;
        private Label labelGHG_FFB;
        private TextBox textISCC_S_Remark;
        private Label labelRemark_S;
        private Label labelGHG_S;
        private TextBox textISCC2;
        private Label label_ISCC_Add;
        private Label label26;
        private CheckBox checkBoxDailyLog;
        private GroupBox groupFlagColor;
        private Label labelFlag3rd;
        private Label labelFlag2nd;
        private Label labelFlag1st;
        private Label labelFlagRegistration;
        private TextBox textFlag3rd;
        private TextBox textFlag2nd;
        private TextBox textFlag1st;
        private TextBox textFlagRegistration;
        private Label labelChangeColor;
        private ComboBox comboTable;
        private Label labelTable;
        private GroupBox panelLanguage;
        private GroupBox panelCode;
        private GroupBox panel23;
        private GroupBox panelLoadUnload;
        private GroupBox panel21;
        private GroupBox panel15;
        private GroupBox panel3;
        private GroupBox panel17;
        private GroupBox panel20;
        private GroupBox panel18;
        private GroupBox panel14;
        private GroupBox panel16;
        private Label label91;
        private GroupBox groupBox1;
        private GroupBox groupBox3;
        private Panel panel12;
        private Label labelGHG1;
        private GroupBox groupBox6;
        private GroupBox groupBox5;
        private GroupBox groupBox7;
        private GroupBox panel24;
        private GroupBox panel4;
        private GroupBox panel9;
        private Label label6;
        private GroupBox panelControlGrossHistory;
        private GroupBox panelCheckTare;
        private GroupBox panel6;
        private Label label7;
        private GroupBox groupBox8;
        private Label label8;
        private CheckBox checkGrossHistoryControl;
        private Label label104;
        private Label label103;
        private TabPage tabPage2;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Button btnEG_connect;
        private RadioButton radioLangInd;
        private Label label14;
        private TextBox txtIntg;
        private Button button1;
        private GroupBox groupBox9;
        private GroupBox groupISCCAdd;
        private TextBox textUpstream;
        private TextBox textTransportDist;
        private Label labelUpstream;
        private Label labelTransportDist;
        private TextBox textCPOAllocation;
        private Label labelCPOAllocation;
        private Label label15;
        private Label label13;
        private CheckBox cBoxGHG;
        private Label label28;
        private Label label30;
        private TextBox textSAPLogonGroup;
        private TextBox textSAPMSSPort;
        private Label label41;
        private TextBox textSAPLogonSystemID;
        private Label label16;
        private TextBox textSAPClient;
        private GroupBox groupBox10;
        private Label label87;
        private Label label77;
        private ComboBox comboBoxTruckRegion;

        public FormSetting()
        {
            this.InitializeComponent();
        }

        private void btn_advise_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.Filter = "Rpt file (*.rpt)|*.rpt";
            this.openFileDialog1.ShowDialog();
            if (this.openFileDialog1.FileName.Trim() != "")
            {
                this.text_advise.Text = Path.GetFileName(this.openFileDialog1.FileName);
            }
        }

        private void btnChkSum_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_loc", "Select * from wb_location where " + WBData.CompanyLocation(""), WBData.conn);
            table.DR = table.DT.Rows[0];
            table.DR.BeginEdit();
            table.DR["checksum"] = table.Checksum(table.DR);
            table.DR.EndEdit();
            table.Save();
            table.Dispose();
            MessageBox.Show("Repair checksum Succeed...", "FINISH");
        }

        private void btnEG_connect_Click(object sender, EventArgs e)
        {
            WBData data = new WBData();
            EGrading_DBIntg intg = new EGrading_DBIntg {
                sServer = this.textBox1.Text,
                sDatabase = this.textBox2.Text,
                sUserID = this.textBox3.Text,
                sPassword = this.textBox4.Text
            };
            if (intg.TestConnect())
            {
                MessageBox.Show("Connection to E-Grading successful");
            }
            else
            {
                MessageBox.Show("Connection to E-Grading Unsuccessful");
            }
            intg.Dispose();
        }

        private void btnReset_EditQty_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("This will Reset Edit Quantity count. Are you sure? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                string[] aField = new string[] { "Ref" };
                string[] aFind = new string[] { this.txtRef.Text };
                int recNo = this.tblTrans.GetRecNo(aField, aFind);
                if (recNo < 0)
                {
                    MessageBox.Show("This Ref hasn't reach max Edit Qty count yet", "WARNING...");
                }
                else
                {
                    this.tblTrans.DR = this.tblTrans.DT.Rows[recNo];
                    this.tblTrans.DR.BeginEdit();
                    this.tblTrans.DR["edit_qty"] = "0";
                    this.tblTrans.DR["checksum"] = this.tblTrans.Checksum(this.tblTrans.DR);
                    this.tblTrans.DR.EndEdit();
                    this.tblTrans.Save();
                    this.tblTrans.ReOpen();
                }
            }
        }

        private void btnReset_EditRec_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("This will Reset Edit record count. Are you sure? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                string[] aField = new string[] { "Ref" };
                string[] aFind = new string[] { this.txtRef.Text };
                int recNo = this.tblTrans.GetRecNo(aField, aFind);
                if (recNo < 0)
                {
                    MessageBox.Show("This Ref hasn't reach max Edit Record count yet", "WARNING...");
                }
                else
                {
                    this.tblTrans.DR = this.tblTrans.DT.Rows[recNo];
                    this.tblTrans.DR.BeginEdit();
                    this.tblTrans.DR["edit_data"] = "0";
                    this.tblTrans.DR["checksum"] = this.tblTrans.Checksum(this.tblTrans.DR);
                    this.tblTrans.DR.EndEdit();
                    this.tblTrans.Save();
                    this.tblTrans.ReOpen();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBData data = new WBData();
            EGrading_DBIntg intg = new EGrading_DBIntg {
                sIntg_Server = this.txtIntg.Text
            };
            if (intg.TestConnect_intg())
            {
                MessageBox.Show("Connection to Database Integrator successful");
            }
            else
            {
                MessageBox.Show("Connection to Database Integrator Unsuccessful");
            }
            intg.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.serialPort1.Close();
            this.serialPort2.Close();
            if (!this.radioTrans3.Checked)
            {
                if (this.radioTrans2.Checked && (this.textGatepassCode.Text == ""))
                {
                    MessageBox.Show("Please input Gatepass Code", "WARNING...");
                    this.textGatepassCode.Focus();
                    return;
                }
            }
            else if (this.textTACode.Text != "")
            {
                if (this.textGatepassCode.Text == "")
                {
                    MessageBox.Show("Please input Gatepass Code", "WARNING...");
                    this.textGatepassCode.Focus();
                    return;
                }
            }
            else
            {
                MessageBox.Show("Please input Truck Arrival Code", "WARNING...");
                this.textTACode.Focus();
                return;
            }
            this.result = Interaction.InputBox("Change Reasons", "Change Reasons", "", 150, 150);
            if (this.result != "")
            {
                this.f_save();
            }
            else
            {
                MessageBox.Show("Please Fill In Reason", "W A R N I N G ! !");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.ThisClose();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                RfcConfigParameters parameters = new RfcConfigParameters();
                parameters.Add("NAME", "TEST_SAP");
                parameters.Add("MSHOST", this.textSAPServer.Text);
                parameters.Add("MSSERV", this.textSAPMSSPort.Text);
                parameters.Add("CLIENT", this.textSAPClient.Text);
                parameters.Add("GROUP", this.textSAPLogonGroup.Text);
                parameters.Add("USER", this.textSAPLoginID.Text);
                parameters.Add("PASSWD", this.textSAPPassword.Text);
                parameters.Add("SYSNR", "00");
                parameters.Add("SYSID", this.textSAPLogonSystemID.Text);
                RfcDestinationManager.GetDestination(parameters).Ping();
                MessageBox.Show("Connecting is successful...!");
            }
            catch (RfcInvalidParameterException exception2)
            {
                MessageBox.Show($"{exception2.GetType().Name} : {exception2.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception4)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception4.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception5)
            {
                MessageBox.Show("Error " + exception5.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            Cursor.Current = Cursors.Default;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.Filter = "Rpt file (*.rpt)|*.rpt";
            this.openFileDialog1.ShowDialog();
            if (this.openFileDialog1.FileName.Trim() != "")
            {
                this.textTicket.Text = Path.GetFileName(this.openFileDialog1.FileName);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.reloadTicket = true;
            MessageBox.Show(" Ticket Will be Reloaded after Save The Setting", "Information...");
        }

        private void buttonEmail_Click(object sender, EventArgs e)
        {
            WBMail mail = new WBMail();
            WBTable table = new WBTable();
            table.OpenTable("wb_email_master", "SELECT Subject, Email_To, Email_CC, coy, location_code FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND ( Email_Code ='EDIT_WARNING')"), WBData.conn);
            int num = 0;
            while (true)
            {
                if (num >= table.DT.Rows.Count)
                {
                    string[] textArray1 = new string[] { "TESTING TOKEN ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
                    mail.Subject = string.Concat(textArray1);
                    mail.Body = "Dear All, <br><br>Testing Email<br>Thank You. ";
                    mail.SendMail();
                    return;
                }
                DataRow row = table.DT.Rows[num];
                mail.To = row[1].ToString().Trim();
                mail.CC = row[2].ToString().Trim();
                num++;
            }
        }

        private void buttonGatepass_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.Filter = "Rpt file (*.rpt)|*.rpt";
            this.openFileDialog1.ShowDialog();
            if (this.openFileDialog1.FileName.Trim() != "")
            {
                this.textGatepass.Text = Path.GetFileName(this.openFileDialog1.FileName);
            }
        }

        private void buttonOpenLockRecord_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_rlock", "Select * from wb_rlock where status = 'L' ", WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                row.Delete();
            }
            table.Save();
            table.Dispose();
            MessageBox.Show("All Locked Record Open Succeed...", "FINISH");
        }

        private void buttonOpenLockTrans_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_loc", "Select * from wb_location where " + WBData.CompanyLocation(""), WBData.conn);
            table.DR = table.DT.Rows[0];
            if (table.DR["Ref_lock"].ToString().Trim().ToUpper() == "Y")
            {
                table.DR.BeginEdit();
                table.DR["Ref_lockBy"] = "";
                table.DR["Ref_lock"] = "N";
                table.DR["checksum"] = table.Checksum(table.DR);
                table.DR.EndEdit();
                table.Save();
            }
            table.Dispose();
            MessageBox.Show("Locked Transaction Open Succeed...", "FINISH");
        }

        private void buttonSynch_Click(object sender, EventArgs e)
        {
            this.grCustSynch = true;
            MessageBox.Show("Synchronize Finish...", "Finish...");
        }

        private void buttonTest_Click(object sender, EventArgs e)
        {
            WBMail mail = new WBMail {
                To = this.textBoxToTesting.Text
            };
            string[] textArray1 = new string[] { "TESTING EMAIL ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
            mail.Subject = string.Concat(textArray1);
            mail.Body = "TESTING EMAIL SEND BY " + WBUser.UserID + "-" + WBUser.UserName;
            if (mail.SendMail())
            {
                MessageBox.Show("EMAIL SEND SUCCESS");
            }
            else
            {
                MessageBox.Show("EMAIL SEND FAILED");
            }
            mail.Dispose();
        }

        private void buttonTestOpen_Click(object sender, EventArgs e)
        {
            new FormSAP_Test().ShowDialog();
        }

        private void buttonTicket1_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.Filter = "Rpt file (*.rpt)|*.rpt";
            this.openFileDialog1.ShowDialog();
        }

        private void checkEmailAllow_CheckedChanged(object sender, EventArgs e)
        {
            this.textSMTP_Server.Enabled = this.checkEmailAllow.Checked;
            this.textSender_Name.Enabled = this.checkEmailAllow.Checked;
            this.textSender_Pass.Enabled = this.checkEmailAllow.Checked;
            this.textDomain.Enabled = this.checkEmailAllow.Checked;
            this.textEmailTankerTO.Enabled = this.checkEmailAllow.Checked && this.check_tanker;
            this.textEmailTankerCC.Enabled = this.checkEmailAllow.Checked && this.check_tanker;
            this.textEmailTankerSubject.Enabled = this.checkEmailAllow.Checked && this.check_tanker;
            this.textEmailEditTO.Enabled = this.checkEmailAllow.Checked;
            this.textEmailEditCC.Enabled = this.checkEmailAllow.Checked;
            this.textEmailEditSubject.Enabled = this.checkEmailAllow.Checked;
            this.textPort.Enabled = this.checkEmailAllow.Checked;
            this.cbSSL.Enabled = this.checkEmailAllow.Checked;
        }

        private void checkISCC_CheckedChanged(object sender, EventArgs e)
        {
            this.textISCC.Enabled = this.checkISCC.Checked;
            this.textISCC2.Enabled = this.checkISCC.Checked;
            this.radioGHG1.Enabled = this.checkISCC.Checked;
            this.radioGHG2.Enabled = this.checkISCC.Checked;
            this.textGHG_F.Enabled = this.checkISCC.Checked;
            this.textGHG_S.Enabled = this.checkISCC.Checked;
            if (!this.checkISCC.Checked)
            {
                this.cBoxGHG.Checked = false;
            }
            this.cBoxGHG.Enabled = this.checkISCC.Checked;
            this.textISCC_F_Remark.Enabled = this.checkISCC.Checked;
            this.textISCC_S_Remark.Enabled = this.checkISCC.Checked;
            this.dtValidISCC.Enabled = this.checkISCC.Checked;
            this.groupISCCAdd.Enabled = this.checkISCC.Checked;
        }

        private void comboTable_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in (IEnumerable) this.dgWarningTrace.Rows)
            {
                bool flag = row.Cells["Type"].Value.ToString().Trim() == this.comboTable.Text.Trim();
                row.Visible = flag;
            }
        }

        private void dgWarningTrace_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if ((e.RowIndex >= 0) && (e.ColumnIndex == 2))
            {
                if (this.dgWarningTrace.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString() == "True")
                {
                    this.dgWarningTrace.Rows[e.RowIndex].Cells[3].Value = "False";
                }
            }
            else if (((e.RowIndex >= 0) && (e.ColumnIndex == 3)) && (this.dgWarningTrace.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString() == "True"))
            {
                this.dgWarningTrace.Rows[e.RowIndex].Cells[2].Value = "False";
            }
        }

        private void dgWarningTrace_OnCellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (((e.ColumnIndex == this.traceOnly.Index) || (e.ColumnIndex == this.Selected.Index)) ? (e.RowIndex != -1) : false)
            {
                this.dgWarningTrace.EndEdit();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public void f_load()
        {
            DataRow row3;
            WBTable table;
            string sCoyCode = WBData.sCoyCode;
            string sLocCode = WBData.sLocCode;
            string sWBCode = WBData.sWBCode;
            this.tCompany.OpenTable("wb_Company", "Select * From wb_company where Coy_Code = '" + sCoyCode + "'", WBData.conn);
            this.tSetting.OpenTable("wb_setting", "Select * From wb_setting where " + WBData.CompanyLocation(" and wbCode = '" + sWBCode + "'"), WBData.conn);
            if (this.tSetting.DT.Rows.Count == 0)
            {
                this.tSetting.OpenTable("wb_setting", "SELECT TOP(1) * FROM wb_setting WHERE wbCode = '" + sWBCode + "'", WBData.conn);
            }
            if (this.tSetting.DT.Rows.Count > 0)
            {
                DataRow row = this.tSetting.DT.Rows[0];
                this.tmpSetting = this.tSetting.DT.Clone();
                this.settingBefore = this.tmpSetting.NewRow();
                this.settingBefore.ItemArray = this.tSetting.DT.Rows[0].ItemArray;
                this.tmpSetting.Rows.Add(this.settingBefore);
            }
            foreach (DataRow row2 in this.tSetting.DT.Rows)
            {
                this.nRowSetting = this.tSetting.DT.Rows.IndexOf(row2);
                this.textCoyCode.Text = row2["Coy"].ToString();
                this.textCoyName.Text = this.tCompany.DT.Rows[0]["Coy_Name"].ToString();
                this.textLocCode.Text = row2["Location_Code"].ToString();
                this.textWBCode.Text = WBData.sWBCode;
                if (row2["schSAP"].ToString() == "Y")
                {
                    this.rboCpYes.Checked = true;
                }
                else
                {
                    this.rboCpNo.Checked = true;
                }
                this.rboCpNo.Checked = (row2["autoRun"].ToString() == "N") || (row2["autoRun"].ToString() == "");
                this.rboCpYes.Checked = row2["autoRun"].ToString() == "Y";
                this.checkDirect.Checked = row2["directToPrinter"].ToString() == "Y";
                this.checkBoxDailyLog.Checked = row2["GMSend"].ToString() == "Y";
            }
            if (this.nRowSetting == -1)
            {
                this.textCoyCode.Text = WBData.sCoyCode;
                this.textLocCode.Text = WBData.sLocCode;
                this.textCoyName.Text = WBData.sCoyName;
                this.textWBCode.Text = WBData.sWBCode;
            }
            this.tLocation.OpenTable("wb_location", "Select * From wb_location where " + WBData.CompanyLocation(""), WBData.conn);
            if (this.tLocation.DT.Rows.Count != 0)
            {
                row3 = this.tLocation.DT.Rows[0];
                this.tmpTrans = this.tLocation.DT.Clone();
                this.textAdress1.Text = row3["Coy_Addr1"].ToString();
                this.textAdress2.Text = row3["Coy_Addr2"].ToString();
                this.textAdress3.Text = row3["Coy_Addr3"].ToString();
                this.transBefore = this.tmpTrans.NewRow();
                this.transBefore.ItemArray = this.tLocation.DT.Rows[0].ItemArray;
                this.tmpTrans.Rows.Add(this.transBefore);
                this.checkNonContract.Checked = row3["NonContract"].ToString() == "Y";
                this.textBrand.Text = row3["Brand"].ToString();
                this.textCapacity.Text = row3["Capacity"].ToString();
                this.textTolerance.Text = row3["Tolerance"].ToString();
                this.textNumOfWb.Text = row3["Num_of_WB"].ToString();
                this.checkStorage.Checked = row3["Check_Storage"].ToString() == "Y";
                this.checkWBNo.Checked = row3["WB_Ref"].ToString() == "Y";
                this.textFormISO.Text = row3["FormISO"].ToString();
                this.textIso2.Text = row3["FormISO2"].ToString();
                this.textIso3.Text = row3["FormISO3"].ToString();
                this.radioTypePOM.Checked = row3["location_type"].ToString() == "1";
                this.radioTypeRefinery.Checked = row3["location_type"].ToString() == "0";
                this.checkRef6.Checked = row3["Ref6"].ToString() == "Y";
                if (this.checkRef6.Checked)
                {
                    this.dateRef6.Value = (row3["DateRef6"].ToString().Trim() == "") ? DateTime.Now : Convert.ToDateTime(row3["DateRef6"].ToString());
                }
                if (this.radioTypePOM.Checked)
                {
                    this.panelPOMSetting.Visible = true;
                    this.panelZWB.Visible = false;
                }
                else
                {
                    this.panelPOMSetting.Visible = false;
                    this.panelZWB.Visible = true;
                }
                this.RdoSPBNo.Checked = (row3["AutoSPB"].ToString() == "0") || (row3["AutoSPB"].ToString() == "");
                this.RdoSPBFFB.Checked = row3["AutoSPB"].ToString() == "1";
                this.RdoSPBStd.Checked = row3["AutoSPB"].ToString() == "2";
                this.RdoSPBFFbStd.Checked = row3["AutoSPB"].ToString() == "3";
                if (WBSetting.integrationIDSYS)
                {
                    this.radioZWBYes.Checked = (row3["zwb"].ToString() == "N") || (row3["zwb"].ToString() == "");
                    this.radioZWBNo.Checked = row3["zwb"].ToString() == "Y";
                }
                else
                {
                    this.radioZWBYes.Checked = row3["zwb"].ToString() == "Y";
                    this.radioZWBNo.Checked = (row3["zwb"].ToString() == "N") || (row3["zwb"].ToString() == "");
                }
                if (row3["Language"].ToString() == "1")
                {
                    this.radioLangFrench.Checked = true;
                }
                else if (row3["Language"].ToString() == "2")
                {
                    this.radioLangInd.Checked = true;
                }
                else
                {
                    this.radioLangEnglish.Checked = true;
                }
                this.radioIndonesia.Checked = row3["Region"].ToString() == "0";
                this.radioAfrica.Checked = row3["Region"].ToString() == "1";
                this.radioMalaysia.Checked = row3["Region"].ToString() == "2";
                if (this.radioAfrica.Checked)
                {
                    this.panelLoadUnload.Visible = true;
                    this.labelLoadUnload.Visible = true;
                    this.radioLoadNo.Visible = true;
                    this.radioLoadYes.Visible = true;
                }
                else
                {
                    this.panelLoadUnload.Visible = false;
                    this.labelLoadUnload.Visible = false;
                    this.radioLoadNo.Visible = false;
                    this.radioLoadYes.Visible = false;
                }
                if ((row3["transFlow"].ToString() == "") || (row3["transFlow"].ToString() == "1"))
                {
                    this.radioTrans1.Checked = true;
                    this.radioTrans2.Checked = false;
                    this.radioTrans3.Checked = false;
                }
                else if (row3["transFlow"].ToString() == "2")
                {
                    this.radioTrans1.Checked = false;
                    this.radioTrans2.Checked = true;
                    this.radioTrans3.Checked = false;
                }
                else if (row3["transFlow"].ToString() == "3")
                {
                    this.radioTrans1.Checked = false;
                    this.radioTrans2.Checked = false;
                    this.radioTrans3.Checked = true;
                }
                this.showCode();
                this.textGatepassCode.Text = row3["GatepassCode"].ToString();
                this.text_advise.Text = row3["Loading_Advise"].ToString();
                this.textTACode.Text = row3["TACode"].ToString();
                if (row3["LoadUnload"].ToString() == "Y")
                {
                    this.radioLoadYes.Checked = true;
                    this.radioLoadNo.Checked = false;
                }
                else if (row3["LoadUnload"].ToString() == "N")
                {
                    this.radioLoadYes.Checked = false;
                    this.radioLoadNo.Checked = true;
                }
                this.grCUstReq = row3["GRCustRequired"].ToString();
                this.checkContainer.Checked = row3["Container"].ToString() == "Y";
                this.checkTrailer.Checked = row3["Trailer"].ToString() == "Y";
                this.textCompanyCode.Text = row3["CoySAP"].ToString();
                this.textSignCreate.Text = row3["Created_By"].ToString();
                this.textSignChecked.Text = row3["Check_By"].ToString();
                this.textSignApproved.Text = row3["Appr_By"].ToString();
                this.textApproved.Text = row3["Apprv_By"].ToString();
                this.textLarge1.Text = row3["Big_Fruit1"].ToString();
                this.textLarge2.Text = row3["Big_Fruit2"].ToString();
                this.textMid1.Text = row3["Mid_Fruit1"].ToString();
                this.textMid2.Text = row3["Mid_Fruit2"].ToString();
                this.textSmall1.Text = row3["Sml_Fruit1"].ToString();
                this.textSmall2.Text = row3["Sml_Fruit2"].ToString();
                this.textLoose1.Text = row3["Loose1"].ToString();
                this.textLoose2.Text = row3["Loose2"].ToString();
                this.textScout1.Text = row3["Scout1"].ToString();
                this.textScout2.Text = row3["Scout2"].ToString();
                this.checkEmailAllow.Checked = row3["Check_Email"].ToString() == "Y";
                this.textSMTP_Server.Enabled = this.checkEmailAllow.Checked;
                this.textSMTP_Server.Text = row3["SMTP_Server"].ToString();
                this.textSender_Name.Enabled = this.checkEmailAllow.Checked;
                this.textSender_Name.Text = row3["Sender_Name"].ToString();
                this.textSender_Pass.Enabled = this.checkEmailAllow.Checked;
                this.textSender_Pass.Text = Program.shoot(row3["Sender_Pass"].ToString().Trim(), false);
                this.textPort.Text = ((row3["Port"].ToString() != null) && (row3["Port"].ToString() != "")) ? row3["Port"].ToString() : "25";
                this.textDomain.Enabled = this.checkEmailAllow.Checked;
                this.textDomain.Text = row3["Domain"].ToString();
                this.cbSSL.Checked = row3["SSL"].ToString() == "Y";
                this.textEmailTankerTO.Text = row3["Recipient_Email"].ToString();
                this.textEmailTankerTO.Enabled = this.checkEmailAllow.Checked;
                this.textEmailTankerCC.Text = row3["CC_Email"].ToString();
                this.textEmailTankerCC.Enabled = this.checkEmailAllow.Checked;
                this.textEmailTankerSubject.Text = row3["Subject_Email"].ToString();
                this.textEmailTankerSubject.Enabled = this.checkEmailAllow.Checked;
                this.textEmailEditTO.Text = row3["Recipient_Email2"].ToString();
                this.textEmailEditTO.Enabled = this.checkEmailAllow.Checked;
                this.textEmailEditCC.Text = row3["CC_Email2"].ToString();
                this.textEmailEditCC.Enabled = this.checkEmailAllow.Checked;
                this.textEmailEditSubject.Text = row3["Subject_Email2"].ToString();
                this.textEmailEditSubject.Enabled = this.checkEmailAllow.Checked;
                table = new WBTable();
                table.OpenTable("wb_warning_trace", "SELECT DISTINCT(Type) FROM wb_warning_trace WHERE " + WBData.CompanyLocation(" ORDER BY Type"), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    foreach (DataRow row4 in table.DT.Rows)
                    {
                        this.comboTable.Items.Add(row4["Type"].ToString().Trim());
                    }
                }
            }
            else
            {
                this.tLocation.Close();
                this.tLocation.ReOpen();
                this.tLocation.DR = this.tLocation.DT.NewRow();
                this.tLocation.DR["Coy"] = sCoyCode;
                this.tLocation.DR["Location_Code"] = sLocCode;
                this.tLocation.DR["WBCode"] = sWBCode;
                this.tLocation.DR["checksum"] = this.tLocation.Checksum(this.tLocation.DR);
                this.tLocation.DT.Rows.Add(this.tLocation.DR);
                this.textAdress1.Text = this.tLocation.DR["Coy_Addr1"].ToString();
                this.textAdress2.Text = this.tLocation.DR["Coy_Addr2"].ToString();
                this.textAdress3.Text = this.tLocation.DR["Coy_Addr3"].ToString();
                this.tLocation.Save();
                this.tLocation.Close();
                this.tLocation.ReOpen();
                goto TR_001F;
            }
            table.Dispose();
            this.tbl_warning_trace = new WBTable();
            this.tbl_warning_trace.OpenTable("wb_warning_trace", "select * from wb_warning_trace", WBData.conn);
            foreach (DataRow row5 in this.tbl_warning_trace.DT.Rows)
            {
                string str4 = "False";
                string str5 = "False";
                if (row5["Selected"].ToString() == "Y")
                {
                    str4 = "True";
                }
                if (row5["traceOnly"].ToString() == "Y")
                {
                    str5 = "True";
                }
                string[] values = new string[] { row5["Type"].ToString(), row5["Name"].ToString(), str5, str4, row5["uniq"].ToString() };
                this.dgWarningTrace.Rows.Add(values);
            }
            if (this.comboTable.Items.Count > 0)
            {
                this.comboTable.SelectedIndex = 0;
            }
            this.radioReportIN.Checked = row3["Report_Type"].ToString() == "I";
            this.radioReportOUT.Checked = row3["Report_Type"].ToString() == "O";
            this.textSAPServer.Text = row3["SAPServer"].ToString();
            this.textSAPLoginID.Text = row3["SAPLoginID"].ToString();
            this.textSAPPassword.Text = Program.shoot(row3["SAPPassword"].ToString(), false);
            this.textSAPMSSPort.Text = row3["SAPMSSPort"].ToString();
            this.textSAPClient.Text = row3["SAPClient"].ToString();
            this.textSAPLogonGroup.Text = row3["SAPLogonGroup"].ToString();
            this.textSAPLogonSystemID.Text = row3["SAPLogonSystemID"].ToString();
            this.textBill_Lading.Text = row3["Bill_Lading"].ToString();
            this.textPlant_Rcv.Text = row3["Plant_Rcv"].ToString();
            this.textStorage_Rcv.Text = row3["Storage_Rcv"].ToString();
            this.textUoM.Text = row3["Uom"].ToString();
            this.textBatch.Text = row3["Batch"].ToString();
            this.textMov_Type.Text = row3["Mov_Type"].ToString();
            this.textPlant_Supp.Text = row3["Plant_Supp"].ToString();
            this.textStorage_Supp.Text = row3["Storage_Supp"].ToString();
            this.textSO_Item.Text = row3["SO_Item"].ToString();
            this.textTransit_Storage.Text = row3["Transit_Storage"].ToString();
            this.textUpload_Type.Text = row3["Upload_Type"].ToString();
            this.textLine.Text = row3["Line"].ToString();
            this.textGI_Storage.Text = row3["GI_Storage"].ToString();
            this.textGI_Batch.Text = row3["GI_Batch"].ToString();
            this.textGR_Storage.Text = row3["GR_Storage"].ToString();
            this.textTransport_Type.Text = row3["Transport_Type"].ToString();
            this.textGR_Discharge.Text = row3["GR_Discharge"].ToString();
            this.textSTO_Item.Text = row3["STO_Item"].ToString();
            this.textISCC.Enabled = row3["ISCC_Checked"].ToString() == "Y";
            this.textISCC2.Enabled = row3["ISCC_Checked"].ToString() == "Y";
            this.radioGHG1.Enabled = row3["ISCC_Checked"].ToString() == "Y";
            this.radioGHG2.Enabled = row3["ISCC_Checked"].ToString() == "Y";
            this.cBoxGHG.Enabled = row3["ISCC_Checked"].ToString() == "Y";
            this.textGHG_F.Enabled = row3["ISCC_Checked"].ToString() == "Y";
            this.textGHG_S.Enabled = row3["ISCC_Checked"].ToString() == "Y";
            this.textISCC_F_Remark.Enabled = row3["ISCC_Checked"].ToString() == "Y";
            this.textISCC_S_Remark.Enabled = row3["ISCC_Checked"].ToString() == "Y";
            this.groupISCCAdd.Enabled = row3["ISCC_Checked"].ToString() == "Y";
            this.textTicket.Text = row3["Ticket"].ToString();
            this.text_advise.Text = row3["Loading_Advise"].ToString();
            this.textGatepass.Text = row3["TicketGatepass"].ToString();
            this.rboScheduleYes.Checked = row3["SAPSchedule"].ToString() == "Y";
            this.rboScheduleNo.Checked = row3["SAPSchedule"].ToString() != "Y";
            this.textSAPTime.Text = row3["sapTime"].ToString();
            this.numericInterval.Text = row3["sapInterval"].ToString();
            if (this.numericInterval.Text == "")
            {
                this.numericInterval.Text = "0";
            }
            if (row3["ISCC_Checked"].ToString() != "Y")
            {
                this.checkISCC.Checked = false;
                this.cBoxGHG.Checked = false;
            }
            else
            {
                this.checkISCC.Checked = true;
                this.cBoxGHG.Checked = row3["GHG_Checked"].ToString() == "Y";
                this.textISCC.Text = row3["ISCC_No"].ToString();
                this.textISCC2.Text = row3["ISCC_No_Add"].ToString();
                this.dtValidISCC.Value = (row3["ISCC_Valid_Date"].ToString() == "") ? DateTime.Now : Convert.ToDateTime(row3["ISCC_Valid_Date"].ToString());
                if (row3["ISCC_GC_Checked"].ToString() == "Y")
                {
                    this.radioGHG1.Checked = true;
                }
                else
                {
                    this.radioGHG2.Checked = true;
                    this.textGHG_F.Text = row3["ISCC_Weight_F"].ToString();
                    this.textGHG_S.Text = row3["ISCC_Weight_S"].ToString();
                    this.textISCC_F_Remark.Text = row3["ISCC_Remark_F"].ToString();
                    this.textISCC_S_Remark.Text = row3["ISCC_Remark_S"].ToString();
                }
                this.textUpstream.Text = row3["ISCC_Upstream"].ToString();
                this.textCPOAllocation.Text = row3["ISCC_Allocation"].ToString();
                this.textTransportDist.Text = row3["ISCC_Transport"].ToString();
            }
            this.checkTare.Checked = row3["Check_Tare"].ToString() == "Y";
            this.checkTareAllComm.Checked = row3["Check_Tare_All_Comm"].ToString() == "Y";
            this.textMinTrans.Text = row3["Check_Tare_MinTrans"].ToString();
            this.checkGrossHistoryControl.Checked = row3["GrossHistoryControl"].ToString() == "Y";
            this.textBoxGrossHistoryVariance.Text = row3["GrossHistoryVariance"].ToString();
            this.textBoxGrossHistoryMinute.Text = row3["GrossHistoryMinute"].ToString();
            this.checkBoxPrintGatepass.Checked = row3["GatepassPrint"].ToString() == "1";
            this.checkBoxEnableScanCardSPB.Checked = row3["ScanCardSPB"].ToString() == "Y";
            if ((row3["rangeFlagColor"].ToString() == null) || (row3["rangeFlagColor"].ToString() == ""))
            {
                this.textFlagRegistration.Text = "0";
                this.textFlag1st.Text = "0";
                this.textFlag2nd.Text = "0";
                this.textFlag3rd.Text = "0";
            }
            else
            {
                char[] separator = new char[] { '-' };
                string[] strArray2 = row3["rangeFlagColor"].ToString().Split(separator);
                this.textFlagRegistration.Text = strArray2[0];
                this.textFlag1st.Text = strArray2[1];
                this.textFlag2nd.Text = strArray2[2];
                this.textFlag3rd.Text = strArray2[3];
            }
            this.textBox1.Text = row3["EGrading_IP"].ToString();
            this.textBox2.Text = row3["EGrading_Database"].ToString();
            this.textBox3.Text = row3["EGrading_UserID"].ToString();
            this.textBox4.Text = Program.shoot(row3["EGrading_Pass"].ToString(), false);
            this.txtIntg.Text = row3["Intg_Database"].ToString();
            this.comboBoxTruckRegion.SelectedIndex = !string.IsNullOrEmpty(row3["Truck_Region"].ToString()) ? Convert.ToInt16(row3["Truck_Region"].ToString()) : 0;
        TR_001F:
            if (Convert.ToInt16(WBUser.UserLevel) > 1)
            {
                foreach (Control control in this.tabPageSystem.Controls)
                {
                    control.Enabled = false;
                }
            }
            if (!WBUser.CheckTrustee("CTR_GROSSHISTORY", "V"))
            {
                this.panelControlGrossHistory.Visible = false;
            }
            else
            {
                this.panelControlGrossHistory.Visible = true;
                this.panelControlGrossHistory.Enabled = WBUser.CheckTrustee("CTR_GROSSHISTORY", "A") || WBUser.CheckTrustee("CTR_GROSSHISTORY", "E");
            }
            if (!WBUser.CheckTrustee("CTR_CHECKTARE", "V"))
            {
                this.panelCheckTare.Visible = false;
            }
            else
            {
                this.panelCheckTare.Visible = true;
                this.panelCheckTare.Enabled = WBUser.CheckTrustee("CTR_CHECKTARE", "A") || WBUser.CheckTrustee("CTR_CHECKTARE", "E");
            }
            if (!WBUser.CheckTrustee("RST_EDITCOUNT", "V"))
            {
                this.groupBox4.Visible = false;
            }
            else
            {
                this.groupBox4.Visible = true;
                this.btnReset_EditRec.Visible = true;
                this.btnReset_EditQty.Visible = true;
                if (!(WBUser.CheckTrustee("RST_EDITCOUNT", "A") || WBUser.CheckTrustee("RST_EDITCOUNT", "E")))
                {
                    this.groupBox4.Enabled = false;
                    this.btnReset_EditRec.Enabled = false;
                    this.btnReset_EditQty.Enabled = false;
                }
                else
                {
                    this.groupBox4.Enabled = true;
                    this.btnReset_EditRec.Enabled = true;
                    this.btnReset_EditQty.Enabled = true;
                    this.tblTrans.OpenTable("wb_transaction", "select * from wb_transaction where" + WBData.CompanyLocation(" and (edit_data = '5' or edit_qty = '5')"), WBData.conn);
                    Program.AutoComp(this.tblTrans, "ref", this.txtRef);
                }
            }
            if (!WBUser.CheckTrustee("CTR_SCANCARDSPB", "V"))
            {
                this.checkBoxEnableScanCardSPB.Visible = false;
            }
            else
            {
                this.checkBoxEnableScanCardSPB.Visible = true;
                this.checkBoxEnableScanCardSPB.Enabled = WBUser.CheckTrustee("CTR_SCANCARDSPB", "A") || WBUser.CheckTrustee("CTR_SCANCARDSPB", "E");
            }
            if (WBSetting.integrationIDSYS)
            {
                this.tabPage4.Text = "IDSYS Connection";
                this.label58.Text = "IDSYS Information";
                this.label24.Text = "IDSYS Location Code";
                this.panel7.Enabled = false;
                this.textBill_Lading.Text = "";
                this.textPlant_Rcv.Text = "";
                this.textPlant_Rcv.Text = "";
                this.textStorage_Rcv.Text = "";
                this.textUoM.Text = "";
                this.textBatch.Text = "";
                this.textMov_Type.Text = "";
                this.textPlant_Supp.Text = "";
                this.textStorage_Supp.Text = "";
                this.textSO_Item.Text = "";
                this.textTransit_Storage.Text = "";
                this.textUpload_Type.Text = "";
                this.textLine.Text = "";
                this.textGI_Storage.Text = "";
                this.textGI_Batch.Text = "";
                this.textGR_Storage.Text = "";
                this.textTransport_Type.Text = "";
                this.textGR_Discharge.Text = "";
                this.textSTO_Item.Text = "";
                this.buttonTestOpen.Visible = false;
                this.textBill_Lading.Enabled = false;
                this.textPlant_Rcv.Enabled = false;
                this.textStorage_Rcv.Enabled = false;
                this.textUoM.Enabled = false;
                this.textBatch.Enabled = false;
                this.textMov_Type.Enabled = false;
                this.textPlant_Supp.Enabled = false;
                this.textStorage_Supp.Enabled = false;
                this.textSO_Item.Enabled = false;
                this.textTransit_Storage.Enabled = false;
                this.textUpload_Type.Enabled = false;
                this.textLine.Enabled = false;
                this.textGI_Storage.Enabled = false;
                this.textGI_Batch.Enabled = false;
                this.textGR_Storage.Enabled = false;
                this.textTransport_Type.Enabled = false;
                this.textGR_Discharge.Enabled = false;
                this.textSTO_Item.Enabled = false;
            }
        }

        public void f_save()
        {
            Cursor.Current = Cursors.WaitCursor;
            this.tSetting.OpenTable("wb_setting", "Select * From wb_setting where " + WBData.CompanyLocation(" and wbCode = '" + WBData.sWBCode + "'"), WBData.conn);
            this.tCompany.OpenTable("wb_setting", "Select * From wb_company where Coy_Code ='" + WBData.sCoyCode + "'", WBData.conn);
            this.tLocation.OpenTable("wb_location", "Select * From wb_location where " + WBData.CompanyLocation(""), WBData.conn);
            this.nRowSetting = (this.tSetting.DT.Rows.Count <= 0) ? -1 : 0;
            if (this.tCompany.DT.Rows.Count > 0)
            {
                this.tCompany.DR = this.tCompany.DT.Rows[0];
            }
            if (this.tLocation.DT.Rows.Count > 0)
            {
                this.tLocation.DR = this.tLocation.DT.Rows[0];
                this.tLocation.DR["Coy_Addr1"] = this.textAdress1.Text;
                this.tLocation.DR["Coy_Addr2"] = this.textAdress2.Text;
                this.tLocation.DR["Coy_Addr3"] = this.textAdress3.Text;
                this.tLocation.Save();
            }
            if (this.nRowSetting == -1)
            {
                this.pMode = "ADD";
                this.tSetting.DR = this.tSetting.DT.NewRow();
                this.tSetting.DR["Coy"] = WBData.sCoyCode;
                this.tSetting.DR["Coy_Name"] = "";
                this.tCompany.DR["Coy_Name"] = this.textCoyName.Text;
                this.tSetting.DR["Location_Code"] = WBData.sLocCode;
            }
            else
            {
                this.pMode = "EDIT";
                this.tSetting.DR = this.tSetting.DT.Rows[this.nRowSetting];
                this.tSetting.DR.BeginEdit();
                this.logKey = this.tSetting.DR["uniq"].ToString();
                this.tSetting.DR["Coy"] = this.textCoyCode.Text;
                this.tSetting.DR["Coy_Name"] = this.textCoyName.Text;
                this.tCompany.DR["Coy_Name"] = this.textCoyName.Text;
                this.tSetting.DR["Location_Code"] = this.textLocCode.Text;
            }
            this.tSetting.DR["WBCode"] = this.textWBCode.Text;
            this.tSetting.DR["Coy_Addr1"] = this.textAdress1.Text;
            this.tSetting.DR["Coy_Addr2"] = this.textAdress2.Text;
            this.tSetting.DR["Coy_Addr3"] = this.textAdress3.Text;
            this.tSetting.DR["SchSAP"] = this.rboCpYes.Checked ? "Y" : "N";
            this.tSetting.DR["autoRun"] = this.rboCpNo.Checked ? "N" : "Y";
            this.tSetting.DR["autoRun"] = this.rboCpYes.Checked ? "Y" : "N";
            this.tSetting.DR["directToPrinter"] = this.checkDirect.Checked ? "Y" : "N";
            this.tSetting.DR["GMSend"] = this.checkBoxDailyLog.Checked ? "Y" : "N";
            if (this.nRowSetting != -1)
            {
                this.tSetting.DR.EndEdit();
            }
            else
            {
                this.tSetting.DT.Rows.Add(this.tSetting.DR);
            }
            this.tSetting.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_setting", "SELECT uniq FROM wb_setting WHERE " + WBData.CompanyLocation(" AND wbcode = '" + this.textWBCode.Text + "'"), WBData.conn);
                    this.logKey = table.DT.Rows[0]["uniq"].ToString();
                    table.Dispose();
                }
                string[] textArray1 = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] textArray2 = new string[] { this.pMode, WBUser.UserID, this.result };
                Program.updateLogHeader("wb_setting", this.logKey, textArray1, textArray2);
            }
            this.tLocation.ReOpen();
            DataRow row = this.tLocation.DT.Rows[0];
            string str = row["uniq"].ToString();
            row.BeginEdit();
            this.logKey = row["uniq"].ToString();
            row["Region"] = this.radioIndonesia.Checked ? "0" : (this.radioAfrica.Checked ? "1" : (this.radioMalaysia.Checked ? "2" : "0"));
            row["TransFlow"] = this.radioTrans3.Checked ? "3" : (this.radioTrans2.Checked ? "2" : (this.radioTrans1.Checked ? "1" : "1"));
            row["LoadUnload"] = this.radioLoadYes.Checked ? "Y" : "N";
            row["GatepassCode"] = this.textGatepassCode.Text;
            row["Loading_Advise"] = this.text_advise.Text;
            row["TACode"] = this.textTACode.Text;
            row["Container"] = this.checkContainer.Checked ? "Y" : "N";
            row["Trailer"] = this.checkTrailer.Checked ? "Y" : "N";
            row["AutoSPB"] = this.RdoSPBNo.Checked ? "0" : (this.RdoSPBFFB.Checked ? "1" : (this.RdoSPBStd.Checked ? "2" : (this.RdoSPBFFbStd.Checked ? "3" : "")));
            row["CoySAP"] = this.textCompanyCode.Text;
            row["Check_Storage"] = this.checkStorage.Checked ? "Y" : "N";
            row["WB_Ref"] = this.checkWBNo.Checked ? "Y" : "N";
            row["FORMISO"] = this.textFormISO.Text;
            row["FORMISO2"] = this.textIso2.Text;
            row["FORMISO3"] = this.textIso3.Text;
            row["location_type"] = this.radioTypePOM.Checked ? "1" : "0";
            row["language"] = this.radioLangEnglish.Checked ? "0" : (this.radioLangFrench.Checked ? "1" : (this.radioLangInd.Checked ? "2" : "0"));
            row["Ref6"] = this.checkRef6.Checked ? "Y" : "N";
            row["DateRef6"] = this.dateRef6.Value.ToShortDateString();
            row["Ticket"] = this.textTicket.Text;
            row["TicketGatepass"] = this.textGatepass.Text;
            row["Loading_Advise"] = this.text_advise.Text;
            row["NonContract"] = this.checkNonContract.Checked ? "Y" : "N";
            row["Created_By"] = this.textSignCreate.Text.Trim();
            row["Check_By"] = this.textSignChecked.Text.Trim();
            row["Appr_By"] = this.textSignApproved.Text.Trim();
            row["Apprv_By"] = this.textApproved.Text.Trim();
            row["Big_Fruit1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textLarge1.Text == "") ? "0" : this.textLarge1.Text)), 2);
            row["Big_Fruit2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textLarge2.Text == "") ? "0" : this.textLarge2.Text)), 2);
            row["Mid_Fruit1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textMid1.Text == "") ? "0" : this.textMid1.Text)), 2);
            row["Mid_Fruit2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textMid2.Text == "") ? "0" : this.textMid2.Text)), 2);
            row["Sml_Fruit1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textSmall1.Text == "") ? "0" : this.textSmall1.Text)), 2);
            row["Sml_Fruit2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textSmall2.Text == "") ? "0" : this.textSmall2.Text)), 2);
            row["Loose1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textLoose1.Text == "") ? "0" : this.textLoose1.Text)), 2);
            row["Loose2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textLoose2.Text == "") ? "0" : this.textLoose2.Text)), 2);
            row["Scout1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textScout1.Text == "") ? "0" : this.textScout1.Text)), 2);
            row["Scout2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textScout2.Text == "") ? "0" : this.textScout2.Text)), 2);
            row["zwb"] = !WBSetting.integrationIDSYS ? (this.radioZWBYes.Checked ? 'Y' : 'N') : (this.radioZWBYes.Checked ? 'N' : 'Y');
            row["SAPInterval"] = this.numericInterval.Text;
            row["Check_Email"] = this.checkEmailAllow.Checked ? "Y" : "N";
            if (this.checkEmailAllow.Checked)
            {
                row["SMTP_Server"] = this.textSMTP_Server.Text.Trim();
                row["Sender_Name"] = this.textSender_Name.Text.Trim();
                row["Sender_Pass"] = Program.shoot(this.textSender_Pass.Text.Trim(), true);
                row["Domain"] = this.textDomain.Text.Trim();
                row["Port"] = this.textPort.Text;
                row["SSL"] = !this.cbSSL.Checked ? "N" : "Y";
                row["Recipient_Email"] = this.textEmailTankerTO.Text.Trim();
                row["CC_Email"] = this.textEmailTankerCC.Text.Trim();
                row["Subject_Email"] = this.textEmailTankerSubject.Text.Trim();
                row["Recipient_Email2"] = this.textEmailEditTO.Text.Trim();
                row["CC_Email2"] = this.textEmailEditCC.Text.Trim();
                row["Subject_Email2"] = this.textEmailEditSubject.Text.Trim();
            }
            foreach (DataGridViewRow row2 in (IEnumerable) this.dgWarningTrace.Rows)
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { row2.Cells["uniq"].Value.ToString() };
                int recNo = this.tbl_warning_trace.GetRecNo(aField, aFind);
                this.tbl_warning_trace.DR = this.tbl_warning_trace.DT.Rows[recNo];
                this.tbl_warning_trace.DR.BeginEdit();
                this.tbl_warning_trace.DR["traceOnly"] = (row2.Cells["traceOnly"].Value.ToString() == "True") ? "Y" : "N";
                this.tbl_warning_trace.DR["Selected"] = (row2.Cells["Selected"].Value.ToString() == "True") ? "Y" : "N";
                this.tbl_warning_trace.DR.EndEdit();
            }
            this.tbl_warning_trace.Save();
            row["Report_Type"] = !this.radioReportIN.Checked ? "O" : "I";
            row["Brand"] = this.textBrand.Text;
            row["Capacity"] = this.textCapacity.Text;
            row["Tolerance"] = this.textTolerance.Text;
            row["Num_of_WB"] = this.textNumOfWb.Text;
            row["SAPServer"] = this.textSAPServer.Text.Trim();
            row["SAPLoginID"] = this.textSAPLoginID.Text.Trim();
            row["SAPPassword"] = Program.shoot(this.textSAPPassword.Text.Trim(), true);
            row["SAPMSSPort"] = this.textSAPMSSPort.Text.Trim();
            row["SAPClient"] = this.textSAPClient.Text.Trim();
            row["SAPLogonGroup"] = this.textSAPLogonGroup.Text.Trim();
            row["SAPLogonSystemID"] = this.textSAPLogonSystemID.Text.Trim();
            row["Bill_Lading"] = this.textBill_Lading.Text.Trim();
            row["Plant_Rcv"] = this.textPlant_Rcv.Text.Trim();
            row["Storage_Rcv"] = this.textStorage_Rcv.Text.Trim();
            row["Uom"] = this.textUoM.Text.Trim();
            row["Batch"] = this.textBatch.Text.Trim();
            row["Mov_Type"] = this.textMov_Type.Text.Trim();
            row["Plant_Supp"] = this.textPlant_Supp.Text.Trim();
            row["Storage_Supp"] = this.textStorage_Supp.Text.Trim();
            row["SO_Item"] = this.textSO_Item.Text.Trim();
            row["Transit_Storage"] = this.textTransit_Storage.Text.Trim();
            row["Upload_Type"] = this.textUpload_Type.Text.Trim();
            row["Line"] = this.textLine.Text.Trim();
            row["GI_Storage"] = this.textGI_Storage.Text.Trim();
            row["GI_Batch"] = this.textGI_Batch.Text.Trim();
            row["GR_Storage"] = this.textGR_Storage.Text.Trim();
            row["Transport_Type"] = this.textTransport_Type.Text.Trim();
            row["GR_Discharge"] = this.textGR_Discharge.Text.Trim();
            row["STO_Item"] = this.textSTO_Item.Text.Trim();
            row["SAPSchedule"] = this.schSAP;
            row["SAPtime"] = this.textSAPTime.Text;
            if (!this.checkISCC.Checked)
            {
                row["ISCC_Checked"] = 'N';
                row["ISCC_No"] = "";
                row["ISCC_GC_Checked"] = 'N';
            }
            else
            {
                row["ISCC_Checked"] = 'Y';
                row["ISCC_No"] = this.textISCC.Text;
                row["ISCC_No_Add"] = this.textISCC2.Text;
                row["ISCC_GC_Checked"] = this.radioGHG1.Checked ? 'Y' : 'N';
                row["ISCC_Valid_Date"] = this.dtValidISCC.Value.ToString();
                if (this.radioGHG2.Checked)
                {
                    row["ISCC_Weight_F"] = this.textGHG_F.Text;
                    row["ISCC_Weight_S"] = this.textGHG_S.Text;
                    row["ISCC_Remark_F"] = this.textISCC_F_Remark.Text;
                    row["ISCC_Remark_S"] = this.textISCC_S_Remark.Text;
                }
                row["ISCC_Upstream"] = this.textUpstream.Text.Trim();
                row["ISCC_Allocation"] = this.textCPOAllocation.Text.Trim();
                row["ISCC_Transport"] = this.textTransportDist.Text.Trim();
            }
            row["GHG_Checked"] = this.cBoxGHG.Checked ? 'Y' : 'N';
            row["Reason"] = this.result.Trim();
            row["checksum"] = this.tLocation.Checksum(row);
            this.check_tanker = row["Check_Tanker"].ToString() != "";
            row["Check_Tare"] = this.checkTare.Checked ? "Y" : "N";
            row["Check_Tare_All_Comm"] = this.checkTareAllComm.Checked ? "Y" : "N";
            row["Check_Tare_MinTrans"] = this.textMinTrans.Text;
            row["GrossHistoryControl"] = this.checkGrossHistoryControl.Checked ? "Y" : "N";
            row["GrossHistoryVariance"] = (this.textBoxGrossHistoryVariance.Text.Trim() != "") ? ((object) this.textBoxGrossHistoryVariance.Text) : ((object) 0);
            row["GrossHistoryMinute"] = (this.textBoxGrossHistoryMinute.Text.Trim() != "") ? ((object) this.textBoxGrossHistoryMinute.Text) : ((object) 0);
            row["GatepassPrint"] = this.checkBoxPrintGatepass.Checked ? "1" : "0";
            row["ScanCardSPB"] = this.checkBoxEnableScanCardSPB.Checked ? "Y" : "N";
            string str2 = (this.textFlagRegistration.Text.Trim() == "") ? "0" : this.textFlagRegistration.Text.Trim();
            string str3 = (this.textFlag1st.Text.Trim() == "") ? "0" : this.textFlag1st.Text.Trim();
            string str4 = (this.textFlag2nd.Text.Trim() == "") ? "0" : this.textFlag2nd.Text.Trim();
            string str5 = (this.textFlag3rd.Text.Trim() == "") ? "0" : this.textFlag3rd.Text.Trim();
            string[] textArray5 = new string[] { str2, "-", str3, "-", str4, "-", str5 };
            row["rangeFlagColor"] = string.Concat(textArray5);
            row["EGrading_IP"] = this.textBox1.Text;
            row["EGrading_Database"] = this.textBox2.Text;
            row["EGrading_UserID"] = this.textBox3.Text;
            row["EGrading_Pass"] = Program.shoot(this.textBox4.Text, true);
            row["Intg_Database"] = this.txtIntg.Text;
            row["Truck_Region"] = this.comboBoxTruckRegion.SelectedIndex.ToString();
            row.EndEdit();
            this.tLocation.DR = row;
            this.tLocation.Save();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { "EDIT", WBUser.UserID, this.result };
            Program.updateLogHeader("wb_location", this.logKey, logField, logValue);
            WBSetting.OpenSetting();
            FormDeepSetting setting = new FormDeepSetting();
            this.tSetting.ReOpen();
            string str6 = this.tSetting.DT.Rows[0]["uniq"].ToString();
            WBData.sCheckDirect = this.checkDirect.Checked ? "Y" : "N";
            this.saved = true;
            Cursor.Current = Cursors.Default;
            base.Close();
        }

        private void FormSetting_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.serialPort1.Close();
            this.serialPort2.Close();
            this.tSetting.Close();
        }

        private void FormSetting_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.ThisClose();
            }
        }

        private void FormSetting_Load(object sender, EventArgs e)
        {
            this.translate();
            this.f_load();
            this.buttonTestOpen.Text = this.sapIDSYS + this.buttonTestOpen.Text;
            this.label57.Text = this.sapIDSYS + this.label57.Text;
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            ComponentResourceManager manager = new ComponentResourceManager(typeof(FormSetting));
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.tabGate = new TabControl();
            this.tabPage1 = new TabPage();
            this.GrpInfo = new GroupBox();
            this.labelBrand = new Label();
            this.label128 = new Label();
            this.label127 = new Label();
            this.label126 = new Label();
            this.textNumOfWb = new TextBox();
            this.label125 = new Label();
            this.textTolerance = new TextBox();
            this.label124 = new Label();
            this.textCapacity = new TextBox();
            this.textBrand = new TextBox();
            this.textWBCode = new TextBox();
            this.label5 = new Label();
            this.textAdress3 = new TextBox();
            this.textAdress2 = new TextBox();
            this.textAdress1 = new TextBox();
            this.textLocCode = new TextBox();
            this.textCoyCode = new TextBox();
            this.textCoyName = new TextBox();
            this.label4 = new Label();
            this.label3 = new Label();
            this.label2 = new Label();
            this.label1 = new Label();
            this.tabPage3 = new TabPage();
            this.tabControl2 = new TabControl();
            this.tabPage5 = new TabPage();
            this.panelControlGrossHistory = new GroupBox();
            this.checkGrossHistoryControl = new CheckBox();
            this.label136 = new Label();
            this.label135 = new Label();
            this.label133 = new Label();
            this.textBoxGrossHistoryVariance = new TextBox();
            this.textBoxGrossHistoryMinute = new TextBox();
            this.label134 = new Label();
            this.panelCheckTare = new GroupBox();
            this.label137 = new Label();
            this.checkTare = new CheckBox();
            this.checkTareAllComm = new CheckBox();
            this.label22 = new Label();
            this.textMinTrans = new TextBox();
            this.panel9 = new GroupBox();
            this.radioReportOUT = new RadioButton();
            this.label78 = new Label();
            this.radioReportIN = new RadioButton();
            this.panel24 = new GroupBox();
            this.textApproved = new TextBox();
            this.labelTktSign = new Label();
            this.labelApproved = new Label();
            this.panel4 = new GroupBox();
            this.textSignApproved = new TextBox();
            this.label51 = new Label();
            this.label20 = new Label();
            this.textSignCreate = new TextBox();
            this.textSignChecked = new TextBox();
            this.label18 = new Label();
            this.label19 = new Label();
            this.groupFlagColor = new GroupBox();
            this.label7 = new Label();
            this.labelFlag3rd = new Label();
            this.labelFlag2nd = new Label();
            this.labelFlag1st = new Label();
            this.labelFlagRegistration = new Label();
            this.textFlag3rd = new TextBox();
            this.textFlag2nd = new TextBox();
            this.textFlag1st = new TextBox();
            this.textFlagRegistration = new TextBox();
            this.labelChangeColor = new Label();
            this.panelPOMSetting = new Panel();
            this.panel6 = new GroupBox();
            this.label104 = new Label();
            this.label103 = new Label();
            this.label102 = new Label();
            this.label53 = new Label();
            this.label39 = new Label();
            this.textLarge1 = new TextBox();
            this.label31 = new Label();
            this.textScout2 = new TextBox();
            this.textLarge2 = new TextBox();
            this.label105 = new Label();
            this.label32 = new Label();
            this.label40 = new Label();
            this.textMid1 = new TextBox();
            this.label106 = new Label();
            this.label34 = new Label();
            this.textScout1 = new TextBox();
            this.textLoose1 = new TextBox();
            this.label37 = new Label();
            this.textMid2 = new TextBox();
            this.label35 = new Label();
            this.label33 = new Label();
            this.textSmall2 = new TextBox();
            this.label38 = new Label();
            this.textLoose2 = new TextBox();
            this.textSmall1 = new TextBox();
            this.label36 = new Label();
            this.groupBox8 = new GroupBox();
            this.checkBoxEnableScanCardSPB = new CheckBox();
            this.GBoxAutoSPB = new GroupBox();
            this.label8 = new Label();
            this.RdoSPBFFbStd = new RadioButton();
            this.RdoSPBStd = new RadioButton();
            this.RdoSPBFFB = new RadioButton();
            this.RdoSPBNo = new RadioButton();
            this.groupBox2 = new GroupBox();
            this.label6 = new Label();
            this.radioAuto1 = new RadioButton();
            this.radioAuto0 = new RadioButton();
            this.tabPage6 = new TabPage();
            this.groupBox7 = new GroupBox();
            this.textEmailEditSubject = new TextBox();
            this.label46 = new Label();
            this.label47 = new Label();
            this.textEmailEditTO = new TextBox();
            this.textEmailEditCC = new TextBox();
            this.label49 = new Label();
            this.label48 = new Label();
            this.groupBox6 = new GroupBox();
            this.textEmailTankerSubject = new TextBox();
            this.label42 = new Label();
            this.label45 = new Label();
            this.textEmailTankerTO = new TextBox();
            this.textEmailTankerCC = new TextBox();
            this.label43 = new Label();
            this.label44 = new Label();
            this.groupBox5 = new GroupBox();
            this.textSMTP_Server = new TextBox();
            this.buttonTest = new Button();
            this.label85 = new Label();
            this.labelRemarkEmailTesting = new Label();
            this.textSender_Pass = new TextBox();
            this.textDomain = new TextBox();
            this.label86 = new Label();
            this.labelDomain = new Label();
            this.label25 = new Label();
            this.textBoxToTesting = new TextBox();
            this.textPort = new TextBox();
            this.label21 = new Label();
            this.textSender_Name = new TextBox();
            this.labelPort = new Label();
            this.cbSSL = new CheckBox();
            this.checkEmailAllow = new CheckBox();
            this.tabPage8 = new TabPage();
            this.comboTable = new ComboBox();
            this.labelTable = new Label();
            this.labelDescWarningField = new Label();
            this.dgWarningTrace = new DataGridView();
            this.Type = new DataGridViewTextBoxColumn();
            this.FieldName = new DataGridViewTextBoxColumn();
            this.traceOnly = new DataGridViewCheckBoxColumn();
            this.Selected = new DataGridViewCheckBoxColumn();
            this.Uniq = new DataGridViewTextBoxColumn();
            this.tabPage7 = new TabPage();
            this.groupISCCAdd = new GroupBox();
            this.label15 = new Label();
            this.label13 = new Label();
            this.textUpstream = new TextBox();
            this.textTransportDist = new TextBox();
            this.labelUpstream = new Label();
            this.labelTransportDist = new Label();
            this.textCPOAllocation = new TextBox();
            this.labelCPOAllocation = new Label();
            this.groupBox3 = new GroupBox();
            this.panel12 = new Panel();
            this.textISCC2 = new TextBox();
            this.label81 = new Label();
            this.label_ISCC_Add = new Label();
            this.label80 = new Label();
            this.label117 = new Label();
            this.textISCC = new TextBox();
            this.dtValidISCC = new DateTimePicker();
            this.groupBoxGHG = new GroupBox();
            this.cBoxGHG = new CheckBox();
            this.labelGHG1 = new Label();
            this.textISCC_S_Remark = new TextBox();
            this.labelRemark_S = new Label();
            this.labelGHG_S = new Label();
            this.label83 = new Label();
            this.textISCC_F_Remark = new TextBox();
            this.labelRemark_FFB = new Label();
            this.label84 = new Label();
            this.labelGHG_FFB = new Label();
            this.label82 = new Label();
            this.textGHG_S = new TextBox();
            this.label79 = new Label();
            this.textGHG_F = new TextBox();
            this.radioGHG2 = new RadioButton();
            this.radioGHG1 = new RadioButton();
            this.checkISCC = new CheckBox();
            this.groupBox1 = new GroupBox();
            this.textFormISO = new TextBox();
            this.textIso3 = new TextBox();
            this.label101 = new Label();
            this.labeliso3 = new Label();
            this.textIso2 = new TextBox();
            this.labeliso2 = new Label();
            this.label108 = new Label();
            this.tabPage4 = new TabPage();
            this.buttonTestOpen = new Button();
            this.label58 = new Label();
            this.panel8 = new Panel();
            this.textCompanyCode = new TextBox();
            this.label24 = new Label();
            this.textLine = new TextBox();
            this.label69 = new Label();
            this.textUpload_Type = new TextBox();
            this.label68 = new Label();
            this.textSTO_Item = new TextBox();
            this.textGR_Discharge = new TextBox();
            this.textTransport_Type = new TextBox();
            this.textGR_Storage = new TextBox();
            this.textGI_Batch = new TextBox();
            this.textGI_Storage = new TextBox();
            this.label70 = new Label();
            this.label71 = new Label();
            this.label72 = new Label();
            this.label73 = new Label();
            this.label74 = new Label();
            this.label75 = new Label();
            this.textTransit_Storage = new TextBox();
            this.label76 = new Label();
            this.textSO_Item = new TextBox();
            this.textStorage_Supp = new TextBox();
            this.textPlant_Supp = new TextBox();
            this.textMov_Type = new TextBox();
            this.textBatch = new TextBox();
            this.textUoM = new TextBox();
            this.textStorage_Rcv = new TextBox();
            this.textPlant_Rcv = new TextBox();
            this.label67 = new Label();
            this.label66 = new Label();
            this.label65 = new Label();
            this.label64 = new Label();
            this.label63 = new Label();
            this.label62 = new Label();
            this.label61 = new Label();
            this.label60 = new Label();
            this.textBill_Lading = new TextBox();
            this.label59 = new Label();
            this.label57 = new Label();
            this.panel7 = new Panel();
            this.label16 = new Label();
            this.textSAPClient = new TextBox();
            this.label41 = new Label();
            this.textSAPLogonSystemID = new TextBox();
            this.label30 = new Label();
            this.textSAPLogonGroup = new TextBox();
            this.textSAPMSSPort = new TextBox();
            this.label28 = new Label();
            this.textSAPServer = new TextBox();
            this.button5 = new Button();
            this.label54 = new Label();
            this.textSAPPassword = new TextBox();
            this.label55 = new Label();
            this.label56 = new Label();
            this.textSAPLoginID = new TextBox();
            this.tabPageSystem = new TabPage();
            this.groupBox10 = new GroupBox();
            this.label77 = new Label();
            this.comboBoxTruckRegion = new ComboBox();
            this.label87 = new Label();
            this.panel18 = new GroupBox();
            this.rboCpNo = new RadioButton();
            this.label92 = new Label();
            this.rboCpYes = new RadioButton();
            this.panel17 = new GroupBox();
            this.dateRef6 = new DateTimePicker();
            this.label109 = new Label();
            this.checkRef6 = new CheckBox();
            this.panel20 = new GroupBox();
            this.btn_advise = new Button();
            this.label29 = new Label();
            this.text_advise = new TextBox();
            this.textTicket = new TextBox();
            this.label52 = new Label();
            this.buttonTicket1 = new Button();
            this.buttonGatepass = new Button();
            this.button8 = new Button();
            this.textGatepass = new TextBox();
            this.label27 = new Label();
            this.label130 = new Label();
            this.checkDirect = new CheckBox();
            this.panel3 = new GroupBox();
            this.checkBoxDailyLog = new CheckBox();
            this.label50 = new Label();
            this.checkBoxPrintGatepass = new CheckBox();
            this.checkStorage = new CheckBox();
            this.checkNonContract = new CheckBox();
            this.checkWBNo = new CheckBox();
            this.checkContainer = new CheckBox();
            this.checkTrailer = new CheckBox();
            this.panelLanguage = new GroupBox();
            this.radioLangInd = new RadioButton();
            this.radioLangEnglish = new RadioButton();
            this.radioLangFrench = new RadioButton();
            this.labelLang = new Label();
            this.panelCode = new GroupBox();
            this.labelGatepassCode = new Label();
            this.labelCode = new Label();
            this.textGatepassCode = new TextBox();
            this.labelTACode = new Label();
            this.textTACode = new TextBox();
            this.panel23 = new GroupBox();
            this.radioTrans1 = new RadioButton();
            this.label129 = new Label();
            this.radioTrans3 = new RadioButton();
            this.radioTrans2 = new RadioButton();
            this.panelLoadUnload = new GroupBox();
            this.radioLoadNo = new RadioButton();
            this.labelLoadUnload = new Label();
            this.radioLoadYes = new RadioButton();
            this.panel21 = new GroupBox();
            this.radioMalaysia = new RadioButton();
            this.label118 = new Label();
            this.radioIndonesia = new RadioButton();
            this.radioAfrica = new RadioButton();
            this.panel15 = new GroupBox();
            this.radioTypeRefinery = new RadioButton();
            this.radioTypePOM = new RadioButton();
            this.label26 = new Label();
            this.panelZWB = new Panel();
            this.panel14 = new GroupBox();
            this.numericInterval = new TextBox();
            this.label96 = new Label();
            this.rboScheduleYes = new RadioButton();
            this.label91 = new Label();
            this.textSAPTime = new MaskedTextBox();
            this.rboScheduleNo = new RadioButton();
            this.label89 = new Label();
            this.label90 = new Label();
            this.panel16 = new GroupBox();
            this.radioZWBNo = new RadioButton();
            this.radioZWBYes = new RadioButton();
            this.label23 = new Label();
            this.label107 = new Label();
            this.tabTool = new TabPage();
            this.groupBox4 = new GroupBox();
            this.txtRef = new TextBox();
            this.btnReset_EditQty = new Button();
            this.label17 = new Label();
            this.btnReset_EditRec = new Button();
            this.buttonOpenLockRecord = new Button();
            this.buttonOpenLockTrans = new Button();
            this.tabPage2 = new TabPage();
            this.groupBox9 = new GroupBox();
            this.textBox2 = new TextBox();
            this.btnEG_connect = new Button();
            this.label12 = new Label();
            this.textBox3 = new TextBox();
            this.label11 = new Label();
            this.textBox4 = new TextBox();
            this.label10 = new Label();
            this.textBox1 = new TextBox();
            this.label9 = new Label();
            this.button1 = new Button();
            this.label14 = new Label();
            this.txtIntg = new TextBox();
            this.button2 = new Button();
            this.button3 = new Button();
            this.openFileDialog1 = new OpenFileDialog();
            this.serialPort2 = new SerialPort(this.components);
            this.toolTip1 = new ToolTip(this.components);
            this.pageSetupDialog1 = new PageSetupDialog();
            this.tabGate.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.GrpInfo.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panelControlGrossHistory.SuspendLayout();
            this.panelCheckTare.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupFlagColor.SuspendLayout();
            this.panelPOMSetting.SuspendLayout();
            this.panel6.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.GBoxAutoSPB.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage8.SuspendLayout();
            ((ISupportInitialize) this.dgWarningTrace).BeginInit();
            this.tabPage7.SuspendLayout();
            this.groupISCCAdd.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel12.SuspendLayout();
            this.groupBoxGHG.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tabPageSystem.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panelLanguage.SuspendLayout();
            this.panelCode.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panelLoadUnload.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panelZWB.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel16.SuspendLayout();
            this.tabTool.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox9.SuspendLayout();
            base.SuspendLayout();
            this.tabGate.Controls.Add(this.tabPage1);
            this.tabGate.Controls.Add(this.tabPage3);
            this.tabGate.Controls.Add(this.tabPage4);
            this.tabGate.Controls.Add(this.tabPageSystem);
            this.tabGate.Controls.Add(this.tabTool);
            this.tabGate.Controls.Add(this.tabPage2);
            this.tabGate.Location = new Point(12, 12);
            this.tabGate.Name = "tabGate";
            this.tabGate.SelectedIndex = 0;
            this.tabGate.Size = new Size(0x3af, 0x1e2);
            this.tabGate.TabIndex = 0;
            this.tabPage1.BackColor = SystemColors.ButtonFace;
            this.tabPage1.BorderStyle = BorderStyle.Fixed3D;
            this.tabPage1.Controls.Add(this.GrpInfo);
            this.tabPage1.Controls.Add(this.textWBCode);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.textAdress3);
            this.tabPage1.Controls.Add(this.textAdress2);
            this.tabPage1.Controls.Add(this.textAdress1);
            this.tabPage1.Controls.Add(this.textLocCode);
            this.tabPage1.Controls.Add(this.textCoyCode);
            this.tabPage1.Controls.Add(this.textCoyName);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new Point(4, 0x16);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new Padding(3);
            this.tabPage1.Size = new Size(0x3a7, 0x1c8);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Company Profile";
            this.GrpInfo.Controls.Add(this.labelBrand);
            this.GrpInfo.Controls.Add(this.label128);
            this.GrpInfo.Controls.Add(this.label127);
            this.GrpInfo.Controls.Add(this.label126);
            this.GrpInfo.Controls.Add(this.textNumOfWb);
            this.GrpInfo.Controls.Add(this.label125);
            this.GrpInfo.Controls.Add(this.textTolerance);
            this.GrpInfo.Controls.Add(this.label124);
            this.GrpInfo.Controls.Add(this.textCapacity);
            this.GrpInfo.Controls.Add(this.textBrand);
            this.GrpInfo.Location = new Point(0x17, 0xe5);
            this.GrpInfo.Name = "GrpInfo";
            this.GrpInfo.Size = new Size(0x2cf, 0x8a);
            this.GrpInfo.TabIndex = 3;
            this.GrpInfo.TabStop = false;
            this.GrpInfo.Text = "Weighbridge Information";
            this.labelBrand.Location = new Point(6, 0x16);
            this.labelBrand.Name = "labelBrand";
            this.labelBrand.Size = new Size(0x8f, 0x11);
            this.labelBrand.TabIndex = 20;
            this.labelBrand.Text = "Brand";
            this.labelBrand.TextAlign = ContentAlignment.TopRight;
            this.label128.AutoSize = true;
            this.label128.Location = new Point(0x105, 0x4a);
            this.label128.Name = "label128";
            this.label128.Size = new Size(0x16, 13);
            this.label128.TabIndex = 0x13;
            this.label128.Text = "KG";
            this.label127.AutoSize = true;
            this.label127.Location = new Point(0x105, 0x30);
            this.label127.Name = "label127";
            this.label127.Size = new Size(0x16, 13);
            this.label127.TabIndex = 0x12;
            this.label127.Text = "KG";
            this.label126.Location = new Point(9, 100);
            this.label126.Name = "label126";
            this.label126.Size = new Size(140, 0x11);
            this.label126.TabIndex = 0x11;
            this.label126.Text = "Number of WB";
            this.label126.TextAlign = ContentAlignment.TopRight;
            this.textNumOfWb.Location = new Point(0x9b, 0x61);
            this.textNumOfWb.MaxLength = 50;
            this.textNumOfWb.Name = "textNumOfWb";
            this.textNumOfWb.Size = new Size(100, 20);
            this.textNumOfWb.TabIndex = 0x10;
            this.label125.Location = new Point(9, 0x4a);
            this.label125.Name = "label125";
            this.label125.Size = new Size(140, 0x11);
            this.label125.TabIndex = 15;
            this.label125.Text = "Tolerance";
            this.label125.TextAlign = ContentAlignment.TopRight;
            this.textTolerance.Location = new Point(0x9b, 0x47);
            this.textTolerance.MaxLength = 50;
            this.textTolerance.Name = "textTolerance";
            this.textTolerance.Size = new Size(100, 20);
            this.textTolerance.TabIndex = 14;
            this.label124.Location = new Point(9, 0x30);
            this.label124.Name = "label124";
            this.label124.Size = new Size(140, 0x11);
            this.label124.TabIndex = 13;
            this.label124.Text = "Capacity";
            this.label124.TextAlign = ContentAlignment.TopRight;
            this.textCapacity.Location = new Point(0x9b, 0x2d);
            this.textCapacity.MaxLength = 50;
            this.textCapacity.Name = "textCapacity";
            this.textCapacity.Size = new Size(100, 20);
            this.textCapacity.TabIndex = 12;
            this.textBrand.Location = new Point(0x9b, 0x13);
            this.textBrand.MaxLength = 50;
            this.textBrand.Name = "textBrand";
            this.textBrand.Size = new Size(0x1d0, 20);
            this.textBrand.TabIndex = 0;
            this.textWBCode.Location = new Point(0xb2, 0xb8);
            this.textWBCode.Name = "textWBCode";
            this.textWBCode.ReadOnly = true;
            this.textWBCode.Size = new Size(0x31, 20);
            this.textWBCode.TabIndex = 11;
            this.label5.Location = new Point(0x1a, 0xbb);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x92, 0x11);
            this.label5.TabIndex = 10;
            this.label5.Text = "Weigh Indicator Code";
            this.label5.TextAlign = ContentAlignment.TopRight;
            this.textAdress3.Location = new Point(0xb2, 0x8b);
            this.textAdress3.Name = "textAdress3";
            this.textAdress3.Size = new Size(0x25e, 20);
            this.textAdress3.TabIndex = 9;
            this.textAdress2.Location = new Point(0xb2, 0x71);
            this.textAdress2.Name = "textAdress2";
            this.textAdress2.Size = new Size(0x25e, 20);
            this.textAdress2.TabIndex = 8;
            this.textAdress1.Location = new Point(0xb2, 0x58);
            this.textAdress1.Name = "textAdress1";
            this.textAdress1.Size = new Size(0x25e, 20);
            this.textAdress1.TabIndex = 7;
            this.textLocCode.Location = new Point(0xb2, 0x3f);
            this.textLocCode.Name = "textLocCode";
            this.textLocCode.ReadOnly = true;
            this.textLocCode.Size = new Size(0x62, 20);
            this.textLocCode.TabIndex = 6;
            this.textCoyCode.Location = new Point(0xb2, 40);
            this.textCoyCode.Name = "textCoyCode";
            this.textCoyCode.ReadOnly = true;
            this.textCoyCode.Size = new Size(0x62, 20);
            this.textCoyCode.TabIndex = 5;
            this.textCoyName.Location = new Point(0xb2, 0x10);
            this.textCoyName.Name = "textCoyName";
            this.textCoyName.ReadOnly = true;
            this.textCoyName.Size = new Size(0x1ce, 20);
            this.textCoyName.TabIndex = 4;
            this.label4.Location = new Point(0x17, 0x5b);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x95, 0x11);
            this.label4.TabIndex = 3;
            this.label4.Text = "Address";
            this.label4.TextAlign = ContentAlignment.TopRight;
            this.label3.Location = new Point(0x17, 0x42);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x95, 0x11);
            this.label3.TabIndex = 2;
            this.label3.Text = "Location Code";
            this.label3.TextAlign = ContentAlignment.TopRight;
            this.label2.Location = new Point(0x17, 0x2b);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x95, 0x11);
            this.label2.TabIndex = 1;
            this.label2.Text = "Company Code";
            this.label2.TextAlign = ContentAlignment.TopRight;
            this.label1.Location = new Point(0x17, 0x13);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x95, 0x11);
            this.label1.TabIndex = 0;
            this.label1.Text = "Company Name";
            this.label1.TextAlign = ContentAlignment.TopRight;
            this.tabPage3.BackColor = SystemColors.ButtonFace;
            this.tabPage3.BorderStyle = BorderStyle.Fixed3D;
            this.tabPage3.Controls.Add(this.tabControl2);
            this.tabPage3.Location = new Point(4, 0x16);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new Padding(3);
            this.tabPage3.Size = new Size(0x3a7, 0x1c8);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Configuration";
            this.tabPage3.Click += new EventHandler(this.tabPage3_Click);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Location = new Point(6, 6);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new Size(0x397, 440);
            this.tabControl2.TabIndex = 0;
            this.tabControl2.MouseClick += new MouseEventHandler(this.tabControl2_MouseClick);
            this.tabPage5.BackColor = SystemColors.ButtonFace;
            this.tabPage5.Controls.Add(this.panelControlGrossHistory);
            this.tabPage5.Controls.Add(this.panelCheckTare);
            this.tabPage5.Controls.Add(this.panel9);
            this.tabPage5.Controls.Add(this.panel24);
            this.tabPage5.Controls.Add(this.panel4);
            this.tabPage5.Controls.Add(this.groupFlagColor);
            this.tabPage5.Controls.Add(this.panelPOMSetting);
            this.tabPage5.Controls.Add(this.groupBox2);
            this.tabPage5.Location = new Point(4, 0x16);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new Padding(3);
            this.tabPage5.Size = new Size(0x38f, 0x19e);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "General Settings";
            this.panelControlGrossHistory.Controls.Add(this.checkGrossHistoryControl);
            this.panelControlGrossHistory.Controls.Add(this.label136);
            this.panelControlGrossHistory.Controls.Add(this.label135);
            this.panelControlGrossHistory.Controls.Add(this.label133);
            this.panelControlGrossHistory.Controls.Add(this.textBoxGrossHistoryVariance);
            this.panelControlGrossHistory.Controls.Add(this.textBoxGrossHistoryMinute);
            this.panelControlGrossHistory.Controls.Add(this.label134);
            this.panelControlGrossHistory.Location = new Point(0x265, 0x48);
            this.panelControlGrossHistory.Name = "panelControlGrossHistory";
            this.panelControlGrossHistory.Size = new Size(0x11b, 0x6c);
            this.panelControlGrossHistory.TabIndex = 0x5b;
            this.panelControlGrossHistory.TabStop = false;
            this.checkGrossHistoryControl.AutoSize = true;
            this.checkGrossHistoryControl.Location = new Point(11, 0x15);
            this.checkGrossHistoryControl.Name = "checkGrossHistoryControl";
            this.checkGrossHistoryControl.Size = new Size(0xfe, 0x11);
            this.checkGrossHistoryControl.TabIndex = 0x1a;
            this.checkGrossHistoryControl.Text = "Activate Gross History Control for FFB Receiving";
            this.checkGrossHistoryControl.UseVisualStyleBackColor = true;
            this.label136.AutoSize = true;
            this.label136.Location = new Point(0xa8, 0x4b);
            this.label136.Name = "label136";
            this.label136.Size = new Size(0x16, 13);
            this.label136.TabIndex = 0x15;
            this.label136.Text = "KG";
            this.label135.AutoSize = true;
            this.label135.Location = new Point(0xa8, 50);
            this.label135.Name = "label135";
            this.label135.Size = new Size(0x27, 13);
            this.label135.TabIndex = 20;
            this.label135.Text = "Minute";
            this.label133.AutoSize = true;
            this.label133.Location = new Point(0x11, 50);
            this.label133.Name = "label133";
            this.label133.Size = new Size(0x3d, 13);
            this.label133.TabIndex = 4;
            this.label133.Text = "Check Last";
            this.textBoxGrossHistoryVariance.Location = new Point(0x6f, 0x48);
            this.textBoxGrossHistoryVariance.Name = "textBoxGrossHistoryVariance";
            this.textBoxGrossHistoryVariance.Size = new Size(0x33, 20);
            this.textBoxGrossHistoryVariance.TabIndex = 0x13;
            this.textBoxGrossHistoryVariance.Text = "0";
            this.textBoxGrossHistoryVariance.TextAlign = HorizontalAlignment.Right;
            this.textBoxGrossHistoryMinute.Location = new Point(0x6f, 0x2f);
            this.textBoxGrossHistoryMinute.Name = "textBoxGrossHistoryMinute";
            this.textBoxGrossHistoryMinute.Size = new Size(0x33, 20);
            this.textBoxGrossHistoryMinute.TabIndex = 0x11;
            this.textBoxGrossHistoryMinute.Text = "0";
            this.textBoxGrossHistoryMinute.TextAlign = HorizontalAlignment.Right;
            this.label134.AutoSize = true;
            this.label134.Location = new Point(0x11, 0x4b);
            this.label134.Name = "label134";
            this.label134.Size = new Size(0x56, 13);
            this.label134.TabIndex = 0x12;
            this.label134.Text = "Weight Variance";
            this.panelCheckTare.Controls.Add(this.label137);
            this.panelCheckTare.Controls.Add(this.checkTare);
            this.panelCheckTare.Controls.Add(this.checkTareAllComm);
            this.panelCheckTare.Controls.Add(this.label22);
            this.panelCheckTare.Controls.Add(this.textMinTrans);
            this.panelCheckTare.Location = new Point(0x192, 0x48);
            this.panelCheckTare.Name = "panelCheckTare";
            this.panelCheckTare.Size = new Size(200, 0x6c);
            this.panelCheckTare.TabIndex = 1;
            this.panelCheckTare.TabStop = false;
            this.label137.AutoSize = true;
            this.label137.Location = new Point(0x17, 50);
            this.label137.Name = "label137";
            this.label137.Size = new Size(0x1b, 13);
            this.label137.TabIndex = 0x1b;
            this.label137.Text = "Min.";
            this.checkTare.AutoSize = true;
            this.checkTare.Location = new Point(13, 0x15);
            this.checkTare.Name = "checkTare";
            this.checkTare.Size = new Size(0x9b, 0x11);
            this.checkTare.TabIndex = 1;
            this.checkTare.Text = "Activate Check Truck Tare";
            this.checkTare.UseVisualStyleBackColor = true;
            this.checkTareAllComm.AutoSize = true;
            this.checkTareAllComm.Location = new Point(0x1a, 0x47);
            this.checkTareAllComm.Name = "checkTareAllComm";
            this.checkTareAllComm.Size = new Size(0x84, 0x11);
            this.checkTareAllComm.TabIndex = 0x1a;
            this.checkTareAllComm.Text = "Apply to All Commodity";
            this.checkTareAllComm.UseVisualStyleBackColor = true;
            this.label22.AutoSize = true;
            this.label22.Location = new Point(0x60, 50);
            this.label22.Name = "label22";
            this.label22.Size = new Size(0x44, 13);
            this.label22.TabIndex = 0x16;
            this.label22.Text = "Transactions";
            this.textMinTrans.Location = new Point(0x38, 0x2f);
            this.textMinTrans.Name = "textMinTrans";
            this.textMinTrans.Size = new Size(0x22, 20);
            this.textMinTrans.TabIndex = 0x10;
            this.textMinTrans.Text = "5";
            this.textMinTrans.TextAlign = HorizontalAlignment.Right;
            this.panel9.Controls.Add(this.radioReportOUT);
            this.panel9.Controls.Add(this.label78);
            this.panel9.Controls.Add(this.radioReportIN);
            this.panel9.Location = new Point(0x2ac, 2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new Size(0xd4, 0x44);
            this.panel9.TabIndex = 90;
            this.panel9.TabStop = false;
            this.radioReportOUT.AutoSize = true;
            this.radioReportOUT.Checked = true;
            this.radioReportOUT.Location = new Point(0x79, 0x26);
            this.radioReportOUT.Name = "radioReportOUT";
            this.radioReportOUT.Size = new Size(0x44, 0x11);
            this.radioReportOUT.TabIndex = 1;
            this.radioReportOUT.TabStop = true;
            this.radioReportOUT.Text = "Out Date";
            this.radioReportOUT.UseVisualStyleBackColor = true;
            this.label78.AutoSize = true;
            this.label78.Location = new Point(11, 0x10);
            this.label78.Name = "label78";
            this.label78.Size = new Size(0x42, 13);
            this.label78.TabIndex = 13;
            this.label78.Text = "Report Base";
            this.radioReportIN.AutoSize = true;
            this.radioReportIN.Location = new Point(0x24, 0x26);
            this.radioReportIN.Name = "radioReportIN";
            this.radioReportIN.Size = new Size(60, 0x11);
            this.radioReportIN.TabIndex = 0;
            this.radioReportIN.Text = "In Date";
            this.radioReportIN.UseVisualStyleBackColor = true;
            this.panel24.Controls.Add(this.textApproved);
            this.panel24.Controls.Add(this.labelTktSign);
            this.panel24.Controls.Add(this.labelApproved);
            this.panel24.Location = new Point(10, 0x74);
            this.panel24.Name = "panel24";
            this.panel24.Size = new Size(0x17f, 0x40);
            this.panel24.TabIndex = 0x59;
            this.panel24.TabStop = false;
            this.textApproved.Location = new Point(0x75, 0x23);
            this.textApproved.MaxLength = 40;
            this.textApproved.Name = "textApproved";
            this.textApproved.Size = new Size(250, 20);
            this.textApproved.TabIndex = 2;
            this.labelTktSign.AutoSize = true;
            this.labelTktSign.Location = new Point(11, 0x10);
            this.labelTktSign.Name = "labelTktSign";
            this.labelTktSign.Size = new Size(0x55, 13);
            this.labelTktSign.TabIndex = 0x19;
            this.labelTktSign.Text = "Ticket Signature";
            this.labelApproved.AutoSize = true;
            this.labelApproved.Location = new Point(0x1d, 0x26);
            this.labelApproved.Name = "labelApproved";
            this.labelApproved.Size = new Size(0x43, 13);
            this.labelApproved.TabIndex = 10;
            this.labelApproved.Text = "Approved by";
            this.panel4.Controls.Add(this.textSignApproved);
            this.panel4.Controls.Add(this.label51);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.textSignCreate);
            this.panel4.Controls.Add(this.textSignChecked);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Location = new Point(10, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new Size(0x17f, 0x70);
            this.panel4.TabIndex = 0x58;
            this.panel4.TabStop = false;
            this.textSignApproved.Location = new Point(0x6f, 0x51);
            this.textSignApproved.MaxLength = 40;
            this.textSignApproved.Name = "textSignApproved";
            this.textSignApproved.Size = new Size(250, 20);
            this.textSignApproved.TabIndex = 2;
            this.label51.AutoSize = true;
            this.label51.Location = new Point(11, 0x10);
            this.label51.Name = "label51";
            this.label51.Size = new Size(0x57, 13);
            this.label51.TabIndex = 8;
            this.label51.Text = "Report Signature";
            this.label20.Location = new Point(0x1d, 0x54);
            this.label20.Name = "label20";
            this.label20.Size = new Size(0x4b, 0x11);
            this.label20.TabIndex = 10;
            this.label20.Text = "Approved by";
            this.textSignCreate.Location = new Point(0x6f, 0x23);
            this.textSignCreate.MaxLength = 40;
            this.textSignCreate.Name = "textSignCreate";
            this.textSignCreate.Size = new Size(250, 20);
            this.textSignCreate.TabIndex = 0;
            this.textSignChecked.Location = new Point(0x6f, 0x3a);
            this.textSignChecked.MaxLength = 40;
            this.textSignChecked.Name = "textSignChecked";
            this.textSignChecked.Size = new Size(250, 20);
            this.textSignChecked.TabIndex = 1;
            this.label18.Location = new Point(0x1d, 0x26);
            this.label18.Name = "label18";
            this.label18.Size = new Size(0x4b, 0x11);
            this.label18.TabIndex = 6;
            this.label18.Text = "Create by";
            this.label19.Location = new Point(0x1d, 0x3d);
            this.label19.Name = "label19";
            this.label19.Size = new Size(0x4b, 0x11);
            this.label19.TabIndex = 8;
            this.label19.Text = "Checked by";
            this.groupFlagColor.Controls.Add(this.label7);
            this.groupFlagColor.Controls.Add(this.labelFlag3rd);
            this.groupFlagColor.Controls.Add(this.labelFlag2nd);
            this.groupFlagColor.Controls.Add(this.labelFlag1st);
            this.groupFlagColor.Controls.Add(this.labelFlagRegistration);
            this.groupFlagColor.Controls.Add(this.textFlag3rd);
            this.groupFlagColor.Controls.Add(this.textFlag2nd);
            this.groupFlagColor.Controls.Add(this.textFlag1st);
            this.groupFlagColor.Controls.Add(this.textFlagRegistration);
            this.groupFlagColor.Controls.Add(this.labelChangeColor);
            this.groupFlagColor.Cursor = Cursors.Default;
            this.groupFlagColor.ForeColor = SystemColors.ControlText;
            this.groupFlagColor.Location = new Point(0x285, 0xb7);
            this.groupFlagColor.Name = "groupFlagColor";
            this.groupFlagColor.RightToLeft = RightToLeft.No;
            this.groupFlagColor.Size = new Size(0xfb, 0xa7);
            this.groupFlagColor.TabIndex = 0x57;
            this.groupFlagColor.TabStop = false;
            this.label7.AutoSize = true;
            this.label7.Location = new Point(11, 0x10);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x36, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Flag Color";
            this.labelFlag3rd.AutoSize = true;
            this.labelFlag3rd.BackColor = Color.Orange;
            this.labelFlag3rd.Location = new Point(0x47, 130);
            this.labelFlag3rd.Name = "labelFlag3rd";
            this.labelFlag3rd.Size = new Size(120, 13);
            this.labelFlag3rd.TabIndex = 8;
            this.labelFlag3rd.Text = "hours after 3rd weighing";
            this.labelFlag2nd.AutoSize = true;
            this.labelFlag2nd.BackColor = Color.Plum;
            this.labelFlag2nd.Location = new Point(0x47, 0x6b);
            this.labelFlag2nd.Name = "labelFlag2nd";
            this.labelFlag2nd.Size = new Size(0x7b, 13);
            this.labelFlag2nd.TabIndex = 7;
            this.labelFlag2nd.Text = "hours after 2nd weighing";
            this.labelFlag1st.AutoSize = true;
            this.labelFlag1st.BackColor = Color.BurlyWood;
            this.labelFlag1st.Location = new Point(70, 0x54);
            this.labelFlag1st.Name = "labelFlag1st";
            this.labelFlag1st.Size = new Size(0x77, 13);
            this.labelFlag1st.TabIndex = 6;
            this.labelFlag1st.Text = "hours after 1st weighing";
            this.labelFlagRegistration.AutoSize = true;
            this.labelFlagRegistration.BackColor = Color.GreenYellow;
            this.labelFlagRegistration.Location = new Point(70, 0x3d);
            this.labelFlagRegistration.Name = "labelFlagRegistration";
            this.labelFlagRegistration.Size = new Size(0x6f, 13);
            this.labelFlagRegistration.TabIndex = 5;
            this.labelFlagRegistration.Text = "hours after registration";
            this.textFlag3rd.Location = new Point(0x1b, 0x7f);
            this.textFlag3rd.MaxLength = 5;
            this.textFlag3rd.Name = "textFlag3rd";
            this.textFlag3rd.Size = new Size(0x24, 20);
            this.textFlag3rd.TabIndex = 4;
            this.textFlag3rd.Text = "0";
            this.textFlag3rd.TextAlign = HorizontalAlignment.Right;
            this.textFlag2nd.Location = new Point(0x1b, 0x68);
            this.textFlag2nd.MaxLength = 5;
            this.textFlag2nd.Name = "textFlag2nd";
            this.textFlag2nd.Size = new Size(0x24, 20);
            this.textFlag2nd.TabIndex = 3;
            this.textFlag2nd.Text = "0";
            this.textFlag2nd.TextAlign = HorizontalAlignment.Right;
            this.textFlag1st.Location = new Point(0x1b, 0x51);
            this.textFlag1st.MaxLength = 5;
            this.textFlag1st.Name = "textFlag1st";
            this.textFlag1st.Size = new Size(0x24, 20);
            this.textFlag1st.TabIndex = 2;
            this.textFlag1st.Text = "0";
            this.textFlag1st.TextAlign = HorizontalAlignment.Right;
            this.textFlagRegistration.Location = new Point(0x1b, 0x3a);
            this.textFlagRegistration.MaxLength = 5;
            this.textFlagRegistration.Name = "textFlagRegistration";
            this.textFlagRegistration.Size = new Size(0x24, 20);
            this.textFlagRegistration.TabIndex = 1;
            this.textFlagRegistration.Text = "0";
            this.textFlagRegistration.TextAlign = HorizontalAlignment.Right;
            this.labelChangeColor.AutoSize = true;
            this.labelChangeColor.Location = new Point(0x18, 0x24);
            this.labelChangeColor.Name = "labelChangeColor";
            this.labelChangeColor.Size = new Size(0xb9, 13);
            this.labelChangeColor.TabIndex = 0;
            this.labelChangeColor.Text = "Change transaction background color";
            this.panelPOMSetting.Controls.Add(this.panel6);
            this.panelPOMSetting.Controls.Add(this.groupBox8);
            this.panelPOMSetting.Controls.Add(this.GBoxAutoSPB);
            this.panelPOMSetting.Location = new Point(3, 0xb5);
            this.panelPOMSetting.Name = "panelPOMSetting";
            this.panelPOMSetting.Size = new Size(0x27c, 180);
            this.panelPOMSetting.TabIndex = 20;
            this.panel6.Controls.Add(this.label104);
            this.panel6.Controls.Add(this.label103);
            this.panel6.Controls.Add(this.label102);
            this.panel6.Controls.Add(this.label53);
            this.panel6.Controls.Add(this.label39);
            this.panel6.Controls.Add(this.textLarge1);
            this.panel6.Controls.Add(this.label31);
            this.panel6.Controls.Add(this.textScout2);
            this.panel6.Controls.Add(this.textLarge2);
            this.panel6.Controls.Add(this.label105);
            this.panel6.Controls.Add(this.label32);
            this.panel6.Controls.Add(this.label40);
            this.panel6.Controls.Add(this.textMid1);
            this.panel6.Controls.Add(this.label106);
            this.panel6.Controls.Add(this.label34);
            this.panel6.Controls.Add(this.textScout1);
            this.panel6.Controls.Add(this.textLoose1);
            this.panel6.Controls.Add(this.label37);
            this.panel6.Controls.Add(this.textMid2);
            this.panel6.Controls.Add(this.label35);
            this.panel6.Controls.Add(this.label33);
            this.panel6.Controls.Add(this.textSmall2);
            this.panel6.Controls.Add(this.label38);
            this.panel6.Controls.Add(this.textLoose2);
            this.panel6.Controls.Add(this.textSmall1);
            this.panel6.Controls.Add(this.label36);
            this.panel6.Location = new Point(250, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new Size(0x17a, 0xa7);
            this.panel6.TabIndex = 0x5c;
            this.panel6.TabStop = false;
            this.label104.AutoSize = true;
            this.label104.ImageAlign = ContentAlignment.TopLeft;
            this.label104.Location = new Point(0x37, 0x6d);
            this.label104.Name = "label104";
            this.label104.Size = new Size(0x85, 13);
            this.label104.TabIndex = 0x5c;
            this.label104.Text = "Small Size / Buah Kecil (K)";
            this.label104.TextAlign = ContentAlignment.TopRight;
            this.label103.AutoSize = true;
            this.label103.Location = new Point(0x58, 0x85);
            this.label103.Name = "label103";
            this.label103.Size = new Size(100, 13);
            this.label103.TabIndex = 0x5c;
            this.label103.Text = "Scout / Krastasi (R)";
            this.label102.AutoSize = true;
            this.label102.Font = new Font("Microsoft Sans Serif", 8.25f);
            this.label102.Location = new Point(0x1f, 0x27);
            this.label102.Name = "label102";
            this.label102.Size = new Size(0x9e, 13);
            this.label102.TabIndex = 0x5d;
            this.label102.Text = "Pure Fruit / Brondolan Murni (M)";
            this.label53.AutoSize = true;
            this.label53.Location = new Point(9, 0x10);
            this.label53.Name = "label53";
            this.label53.Size = new Size(0xb5, 13);
            this.label53.TabIndex = 12;
            this.label53.Text = "Type of Fruits ( Value Range in Kg ) :";
            this.label39.AutoSize = true;
            this.label39.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label39.Location = new Point(0x151, 0x85);
            this.label39.Name = "label39";
            this.label39.Size = new Size(20, 13);
            this.label39.TabIndex = 0x6d;
            this.label39.Text = "Kg";
            this.textLarge1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textLarge1.Location = new Point(0xcd, 0x3a);
            this.textLarge1.MaxLength = 15;
            this.textLarge1.Name = "textLarge1";
            this.textLarge1.Size = new Size(0x35, 0x15);
            this.textLarge1.TabIndex = 0;
            this.textLarge1.TextAlign = HorizontalAlignment.Right;
            this.label31.AutoSize = true;
            this.label31.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label31.Location = new Point(0x108, 0x3d);
            this.label31.Name = "label31";
            this.label31.Size = new Size(11, 15);
            this.label31.TabIndex = 0x5b;
            this.label31.Text = "-";
            this.textScout2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textScout2.Location = new Point(0x119, 0x80);
            this.textScout2.MaxLength = 15;
            this.textScout2.Name = "textScout2";
            this.textScout2.Size = new Size(0x35, 0x15);
            this.textScout2.TabIndex = 9;
            this.textScout2.TextAlign = HorizontalAlignment.Right;
            this.textLarge2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textLarge2.Location = new Point(0x119, 0x3a);
            this.textLarge2.MaxLength = 15;
            this.textLarge2.Name = "textLarge2";
            this.textLarge2.Size = new Size(0x35, 0x15);
            this.textLarge2.TabIndex = 1;
            this.textLarge2.TextAlign = HorizontalAlignment.Right;
            this.label105.AutoSize = true;
            this.label105.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label105.Location = new Point(0x1d, 0x56);
            this.label105.Name = "label105";
            this.label105.Size = new Size(0x9f, 13);
            this.label105.TabIndex = 0x5b;
            this.label105.Text = "Medium Size / Buah Sedang (S)";
            this.label32.AutoSize = true;
            this.label32.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label32.Location = new Point(0x151, 0x3f);
            this.label32.Name = "label32";
            this.label32.Size = new Size(20, 13);
            this.label32.TabIndex = 0x5d;
            this.label32.Text = "Kg";
            this.label40.AutoSize = true;
            this.label40.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label40.Location = new Point(0x108, 0x83);
            this.label40.Name = "label40";
            this.label40.Size = new Size(11, 15);
            this.label40.TabIndex = 0x6b;
            this.label40.Text = "-";
            this.textMid1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textMid1.Location = new Point(0xcd, 0x51);
            this.textMid1.MaxLength = 15;
            this.textMid1.Name = "textMid1";
            this.textMid1.Size = new Size(0x35, 0x15);
            this.textMid1.TabIndex = 2;
            this.textMid1.TextAlign = HorizontalAlignment.Right;
            this.label106.AutoSize = true;
            this.label106.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label106.Location = new Point(0x3d, 0x3f);
            this.label106.Name = "label106";
            this.label106.Size = new Size(0x7f, 13);
            this.label106.TabIndex = 90;
            this.label106.Text = "Big Size / Buah Besar (B)";
            this.label34.AutoSize = true;
            this.label34.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label34.Location = new Point(0x108, 0x54);
            this.label34.Name = "label34";
            this.label34.Size = new Size(11, 15);
            this.label34.TabIndex = 0x5f;
            this.label34.Text = "-";
            this.textScout1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textScout1.Location = new Point(0xcd, 0x80);
            this.textScout1.MaxLength = 15;
            this.textScout1.Name = "textScout1";
            this.textScout1.Size = new Size(0x35, 0x15);
            this.textScout1.TabIndex = 8;
            this.textScout1.TextAlign = HorizontalAlignment.Right;
            this.textLoose1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textLoose1.Location = new Point(0xcd, 0x23);
            this.textLoose1.MaxLength = 15;
            this.textLoose1.Name = "textLoose1";
            this.textLoose1.Size = new Size(0x35, 0x15);
            this.textLoose1.TabIndex = 6;
            this.textLoose1.TextAlign = HorizontalAlignment.Right;
            this.label37.AutoSize = true;
            this.label37.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label37.Location = new Point(0x151, 0x27);
            this.label37.Name = "label37";
            this.label37.Size = new Size(20, 13);
            this.label37.TabIndex = 0x69;
            this.label37.Text = "Kg";
            this.textMid2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textMid2.Location = new Point(0x119, 0x51);
            this.textMid2.MaxLength = 15;
            this.textMid2.Name = "textMid2";
            this.textMid2.Size = new Size(0x35, 0x15);
            this.textMid2.TabIndex = 3;
            this.textMid2.TextAlign = HorizontalAlignment.Right;
            this.label35.AutoSize = true;
            this.label35.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label35.Location = new Point(0x151, 0x6b);
            this.label35.Name = "label35";
            this.label35.Size = new Size(20, 13);
            this.label35.TabIndex = 0x65;
            this.label35.Text = "Kg";
            this.label33.AutoSize = true;
            this.label33.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label33.Location = new Point(0x151, 0x56);
            this.label33.Name = "label33";
            this.label33.Size = new Size(20, 13);
            this.label33.TabIndex = 0x61;
            this.label33.Text = "Kg";
            this.textSmall2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textSmall2.Location = new Point(0x119, 0x68);
            this.textSmall2.MaxLength = 15;
            this.textSmall2.Name = "textSmall2";
            this.textSmall2.Size = new Size(0x35, 0x15);
            this.textSmall2.TabIndex = 5;
            this.textSmall2.TextAlign = HorizontalAlignment.Right;
            this.label38.AutoSize = true;
            this.label38.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label38.Location = new Point(0x108, 0x26);
            this.label38.Name = "label38";
            this.label38.Size = new Size(11, 15);
            this.label38.TabIndex = 0x67;
            this.label38.Text = "-";
            this.textLoose2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textLoose2.Location = new Point(0x119, 0x23);
            this.textLoose2.MaxLength = 15;
            this.textLoose2.Name = "textLoose2";
            this.textLoose2.Size = new Size(0x35, 0x15);
            this.textLoose2.TabIndex = 7;
            this.textLoose2.TextAlign = HorizontalAlignment.Right;
            this.textSmall1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textSmall1.Location = new Point(0xcd, 0x68);
            this.textSmall1.MaxLength = 15;
            this.textSmall1.Name = "textSmall1";
            this.textSmall1.Size = new Size(0x35, 0x15);
            this.textSmall1.TabIndex = 4;
            this.textSmall1.TextAlign = HorizontalAlignment.Right;
            this.label36.AutoSize = true;
            this.label36.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label36.Location = new Point(0x108, 0x6b);
            this.label36.Name = "label36";
            this.label36.Size = new Size(11, 15);
            this.label36.TabIndex = 0x63;
            this.label36.Text = "-";
            this.groupBox8.Controls.Add(this.checkBoxEnableScanCardSPB);
            this.groupBox8.Location = new Point(7, 0x81);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new Size(230, 40);
            this.groupBox8.TabIndex = 0x5d;
            this.groupBox8.TabStop = false;
            this.checkBoxEnableScanCardSPB.AutoSize = true;
            this.checkBoxEnableScanCardSPB.Location = new Point(11, 14);
            this.checkBoxEnableScanCardSPB.Name = "checkBoxEnableScanCardSPB";
            this.checkBoxEnableScanCardSPB.Size = new Size(0xce, 0x11);
            this.checkBoxEnableScanCardSPB.TabIndex = 20;
            this.checkBoxEnableScanCardSPB.Text = "Enable Scan Card SPB in Transaction";
            this.toolTip1.SetToolTip(this.checkBoxEnableScanCardSPB, "Enable feature scan card e-SPB to retrieve truck information.\r\nThis setting have authorization object for View, and Edit to change setting");
            this.checkBoxEnableScanCardSPB.UseVisualStyleBackColor = true;
            this.GBoxAutoSPB.Controls.Add(this.label8);
            this.GBoxAutoSPB.Controls.Add(this.RdoSPBFFbStd);
            this.GBoxAutoSPB.Controls.Add(this.RdoSPBStd);
            this.GBoxAutoSPB.Controls.Add(this.RdoSPBFFB);
            this.GBoxAutoSPB.Controls.Add(this.RdoSPBNo);
            this.GBoxAutoSPB.Cursor = Cursors.Default;
            this.GBoxAutoSPB.ForeColor = SystemColors.ControlText;
            this.GBoxAutoSPB.Location = new Point(7, 2);
            this.GBoxAutoSPB.Name = "GBoxAutoSPB";
            this.GBoxAutoSPB.RightToLeft = RightToLeft.No;
            this.GBoxAutoSPB.Size = new Size(230, 0x7d);
            this.GBoxAutoSPB.TabIndex = 0x13;
            this.GBoxAutoSPB.TabStop = false;
            this.toolTip1.SetToolTip(this.GBoxAutoSPB, "Auto set Delivery Note Number in Transaction\r\n\r\nFormat : \r\nCompanyCode\\CommodityCode\\RunningNumber\r\n\r\nThe running Number will reset back to Zero per Month");
            this.label8.AutoSize = true;
            this.label8.Location = new Point(11, 0x10);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x88, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Auto Delivery Note Number";
            this.RdoSPBFFbStd.AutoSize = true;
            this.RdoSPBFFbStd.Location = new Point(0x17, 0x5e);
            this.RdoSPBFFbStd.Name = "RdoSPBFFbStd";
            this.RdoSPBFFbStd.Size = new Size(0x7b, 0x11);
            this.RdoSPBFFbStd.TabIndex = 3;
            this.RdoSPBFFbStd.Text = "Yes. FFB && Standard";
            this.RdoSPBFFbStd.UseVisualStyleBackColor = true;
            this.RdoSPBStd.AutoSize = true;
            this.RdoSPBStd.Checked = true;
            this.RdoSPBStd.Location = new Point(0x17, 0x4c);
            this.RdoSPBStd.Name = "RdoSPBStd";
            this.RdoSPBStd.Size = new Size(0x74, 0x11);
            this.RdoSPBStd.TabIndex = 2;
            this.RdoSPBStd.TabStop = true;
            this.RdoSPBStd.Text = "Yes. Standard Only";
            this.RdoSPBStd.UseVisualStyleBackColor = true;
            this.RdoSPBFFB.AutoSize = true;
            this.RdoSPBFFB.Location = new Point(0x17, 0x3a);
            this.RdoSPBFFB.Name = "RdoSPBFFB";
            this.RdoSPBFFB.Size = new Size(0x5c, 0x11);
            this.RdoSPBFFB.TabIndex = 1;
            this.RdoSPBFFB.Text = "Yes. FFB Only";
            this.RdoSPBFFB.UseVisualStyleBackColor = true;
            this.RdoSPBNo.AutoSize = true;
            this.RdoSPBNo.Location = new Point(0x17, 0x27);
            this.RdoSPBNo.Name = "RdoSPBNo";
            this.RdoSPBNo.Size = new Size(0x2a, 0x11);
            this.RdoSPBNo.TabIndex = 0;
            this.RdoSPBNo.Text = "No.";
            this.RdoSPBNo.UseVisualStyleBackColor = true;
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.radioAuto1);
            this.groupBox2.Controls.Add(this.radioAuto0);
            this.groupBox2.Location = new Point(0x192, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0x110, 0x44);
            this.groupBox2.TabIndex = 0x17;
            this.groupBox2.TabStop = false;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(11, 0x10);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0xf4, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Auto run && login on this computer using SCH Login";
            this.radioAuto1.AutoSize = true;
            this.radioAuto1.Location = new Point(0x93, 0x26);
            this.radioAuto1.Name = "radioAuto1";
            this.radioAuto1.Size = new Size(0x2b, 0x11);
            this.radioAuto1.TabIndex = 3;
            this.radioAuto1.Text = "Yes";
            this.radioAuto1.UseVisualStyleBackColor = true;
            this.radioAuto0.AutoSize = true;
            this.radioAuto0.Checked = true;
            this.radioAuto0.Location = new Point(0x25, 0x26);
            this.radioAuto0.Name = "radioAuto0";
            this.radioAuto0.Size = new Size(0x27, 0x11);
            this.radioAuto0.TabIndex = 2;
            this.radioAuto0.TabStop = true;
            this.radioAuto0.Text = "No";
            this.radioAuto0.UseVisualStyleBackColor = true;
            this.tabPage6.BackColor = SystemColors.ButtonFace;
            this.tabPage6.Controls.Add(this.groupBox7);
            this.tabPage6.Controls.Add(this.groupBox6);
            this.tabPage6.Controls.Add(this.groupBox5);
            this.tabPage6.Controls.Add(this.checkEmailAllow);
            this.tabPage6.Location = new Point(4, 0x16);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new Padding(3);
            this.tabPage6.Size = new Size(0x38f, 0x19e);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Email Setting";
            this.groupBox7.Controls.Add(this.textEmailEditSubject);
            this.groupBox7.Controls.Add(this.label46);
            this.groupBox7.Controls.Add(this.label47);
            this.groupBox7.Controls.Add(this.textEmailEditTO);
            this.groupBox7.Controls.Add(this.textEmailEditCC);
            this.groupBox7.Controls.Add(this.label49);
            this.groupBox7.Controls.Add(this.label48);
            this.groupBox7.Location = new Point(0x1d0, 0xf2);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new Size(0x1a9, 0x94);
            this.groupBox7.TabIndex = 14;
            this.groupBox7.TabStop = false;
            this.groupBox7.Visible = false;
            this.textEmailEditSubject.Location = new Point(0x3d, 0x62);
            this.textEmailEditSubject.MaxLength = 250;
            this.textEmailEditSubject.Name = "textEmailEditSubject";
            this.textEmailEditSubject.Size = new Size(0x134, 20);
            this.textEmailEditSubject.TabIndex = 2;
            this.textEmailEditSubject.Visible = false;
            this.label46.AutoSize = true;
            this.label46.ForeColor = SystemColors.ControlText;
            this.label46.Location = new Point(0x10, 0x10);
            this.label46.Name = "label46";
            this.label46.Size = new Size(0x94, 13);
            this.label46.TabIndex = 8;
            this.label46.Text = "for Edit Transaction Warning :";
            this.label46.Visible = false;
            this.label47.AutoSize = true;
            this.label47.ForeColor = SystemColors.ControlText;
            this.label47.Location = new Point(12, 0x65);
            this.label47.Name = "label47";
            this.label47.Size = new Size(0x2b, 13);
            this.label47.TabIndex = 11;
            this.label47.Text = "Subject";
            this.label47.Visible = false;
            this.textEmailEditTO.Location = new Point(0x3d, 0x2e);
            this.textEmailEditTO.MaxLength = 250;
            this.textEmailEditTO.Name = "textEmailEditTO";
            this.textEmailEditTO.Size = new Size(0x134, 20);
            this.textEmailEditTO.TabIndex = 0;
            this.textEmailEditTO.Visible = false;
            this.textEmailEditCC.Location = new Point(0x3d, 0x48);
            this.textEmailEditCC.MaxLength = 250;
            this.textEmailEditCC.Name = "textEmailEditCC";
            this.textEmailEditCC.Size = new Size(0x134, 20);
            this.textEmailEditCC.TabIndex = 1;
            this.textEmailEditCC.Visible = false;
            this.label49.AutoSize = true;
            this.label49.ForeColor = SystemColors.ControlText;
            this.label49.Location = new Point(0x23, 0x31);
            this.label49.Name = "label49";
            this.label49.Size = new Size(20, 13);
            this.label49.TabIndex = 7;
            this.label49.Text = "To";
            this.label49.Visible = false;
            this.label48.AutoSize = true;
            this.label48.ForeColor = SystemColors.ControlText;
            this.label48.Location = new Point(0x22, 0x4b);
            this.label48.Name = "label48";
            this.label48.Size = new Size(0x15, 13);
            this.label48.TabIndex = 9;
            this.label48.Text = "CC";
            this.label48.Visible = false;
            this.groupBox6.Controls.Add(this.textEmailTankerSubject);
            this.groupBox6.Controls.Add(this.label42);
            this.groupBox6.Controls.Add(this.label45);
            this.groupBox6.Controls.Add(this.textEmailTankerTO);
            this.groupBox6.Controls.Add(this.textEmailTankerCC);
            this.groupBox6.Controls.Add(this.label43);
            this.groupBox6.Controls.Add(this.label44);
            this.groupBox6.Location = new Point(20, 0xf2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new Size(0x1a9, 0x94);
            this.groupBox6.TabIndex = 15;
            this.groupBox6.TabStop = false;
            this.groupBox6.Visible = false;
            this.textEmailTankerSubject.Location = new Point(0x42, 0x62);
            this.textEmailTankerSubject.MaxLength = 250;
            this.textEmailTankerSubject.Name = "textEmailTankerSubject";
            this.textEmailTankerSubject.Size = new Size(0x134, 20);
            this.textEmailTankerSubject.TabIndex = 2;
            this.label42.AutoSize = true;
            this.label42.ForeColor = SystemColors.ControlText;
            this.label42.Location = new Point(0x10, 0x10);
            this.label42.Name = "label42";
            this.label42.Size = new Size(0x70, 13);
            this.label42.TabIndex = 6;
            this.label42.Text = "for Tanker Over Limit :";
            this.label42.Visible = false;
            this.label45.AutoSize = true;
            this.label45.ForeColor = SystemColors.ControlText;
            this.label45.Location = new Point(0x12, 0x65);
            this.label45.Name = "label45";
            this.label45.Size = new Size(0x2b, 13);
            this.label45.TabIndex = 11;
            this.label45.Text = "Subject";
            this.textEmailTankerTO.Location = new Point(0x42, 0x2e);
            this.textEmailTankerTO.MaxLength = 250;
            this.textEmailTankerTO.Name = "textEmailTankerTO";
            this.textEmailTankerTO.Size = new Size(0x134, 20);
            this.textEmailTankerTO.TabIndex = 0;
            this.textEmailTankerCC.Location = new Point(0x42, 0x48);
            this.textEmailTankerCC.MaxLength = 250;
            this.textEmailTankerCC.Name = "textEmailTankerCC";
            this.textEmailTankerCC.Size = new Size(0x134, 20);
            this.textEmailTankerCC.TabIndex = 1;
            this.textEmailTankerCC.Text = " ";
            this.label43.AutoSize = true;
            this.label43.ForeColor = SystemColors.ControlText;
            this.label43.Location = new Point(0x29, 0x31);
            this.label43.Name = "label43";
            this.label43.Size = new Size(20, 13);
            this.label43.TabIndex = 7;
            this.label43.Text = "To";
            this.label44.AutoSize = true;
            this.label44.ForeColor = SystemColors.ControlText;
            this.label44.Location = new Point(40, 0x4b);
            this.label44.Name = "label44";
            this.label44.Size = new Size(0x15, 13);
            this.label44.TabIndex = 9;
            this.label44.Text = "CC";
            this.groupBox5.Controls.Add(this.textSMTP_Server);
            this.groupBox5.Controls.Add(this.buttonTest);
            this.groupBox5.Controls.Add(this.label85);
            this.groupBox5.Controls.Add(this.labelRemarkEmailTesting);
            this.groupBox5.Controls.Add(this.textSender_Pass);
            this.groupBox5.Controls.Add(this.textDomain);
            this.groupBox5.Controls.Add(this.label86);
            this.groupBox5.Controls.Add(this.labelDomain);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.textBoxToTesting);
            this.groupBox5.Controls.Add(this.textPort);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.textSender_Name);
            this.groupBox5.Controls.Add(this.labelPort);
            this.groupBox5.Controls.Add(this.cbSSL);
            this.groupBox5.Location = new Point(20, 0x27);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new Size(0x365, 0xc5);
            this.groupBox5.TabIndex = 14;
            this.groupBox5.TabStop = false;
            this.textSMTP_Server.Location = new Point(0x88, 0x13);
            this.textSMTP_Server.MaxLength = 50;
            this.textSMTP_Server.Name = "textSMTP_Server";
            this.textSMTP_Server.Size = new Size(0x146, 20);
            this.textSMTP_Server.TabIndex = 1;
            this.buttonTest.ForeColor = SystemColors.ControlText;
            this.buttonTest.Location = new Point(0x183, 0x9b);
            this.buttonTest.Name = "buttonTest";
            this.buttonTest.Size = new Size(0x4b, 0x17);
            this.buttonTest.TabIndex = 9;
            this.buttonTest.Text = "Test Email";
            this.buttonTest.UseVisualStyleBackColor = true;
            this.buttonTest.Click += new EventHandler(this.buttonTest_Click);
            this.label85.ForeColor = SystemColors.ControlText;
            this.label85.Location = new Point(15, 0x30);
            this.label85.Name = "label85";
            this.label85.Size = new Size(0x73, 0x11);
            this.label85.TabIndex = 4;
            this.label85.Text = "Email Address";
            this.label85.TextAlign = ContentAlignment.TopRight;
            this.labelRemarkEmailTesting.AutoSize = true;
            this.labelRemarkEmailTesting.ForeColor = SystemColors.ControlText;
            this.labelRemarkEmailTesting.Location = new Point(0x16, 160);
            this.labelRemarkEmailTesting.Name = "labelRemarkEmailTesting";
            this.labelRemarkEmailTesting.Size = new Size(0x12a, 13);
            this.labelRemarkEmailTesting.TabIndex = 11;
            this.labelRemarkEmailTesting.Text = "Please Save Setting to Apply Current Setting Email for Testing";
            this.textSender_Pass.Location = new Point(0x88, 0x47);
            this.textSender_Pass.MaxLength = 50;
            this.textSender_Pass.Name = "textSender_Pass";
            this.textSender_Pass.Size = new Size(0x146, 20);
            this.textSender_Pass.TabIndex = 3;
            this.textSender_Pass.UseSystemPasswordChar = true;
            this.textDomain.Location = new Point(0x25e, 15);
            this.textDomain.MaxLength = 50;
            this.textDomain.Name = "textDomain";
            this.textDomain.Size = new Size(0xca, 20);
            this.textDomain.TabIndex = 12;
            this.label86.ForeColor = SystemColors.ControlText;
            this.label86.Location = new Point(15, 0x4a);
            this.label86.Name = "label86";
            this.label86.Size = new Size(0x73, 0x11);
            this.label86.TabIndex = 5;
            this.label86.Text = "Password";
            this.label86.TextAlign = ContentAlignment.TopRight;
            this.labelDomain.ForeColor = SystemColors.ControlText;
            this.labelDomain.Location = new Point(0x1fc, 0x12);
            this.labelDomain.Name = "labelDomain";
            this.labelDomain.Size = new Size(0x5c, 0x11);
            this.labelDomain.TabIndex = 13;
            this.labelDomain.Text = "Domain (O365)";
            this.labelDomain.TextAlign = ContentAlignment.TopRight;
            this.toolTip1.SetToolTip(this.labelDomain, "For office365 :\r\n1. SSL checked\r\n2. smtp.office365.com\r\n3. Port : 587\r\n4. Domain required");
            this.label25.ForeColor = SystemColors.ControlText;
            this.label25.Location = new Point(0x16, 0x16);
            this.label25.Name = "label25";
            this.label25.Size = new Size(0x6c, 13);
            this.label25.TabIndex = 1;
            this.label25.Text = "Host ( SMTP Server )";
            this.label25.TextAlign = ContentAlignment.TopRight;
            this.textBoxToTesting.Location = new Point(0x88, 0x7b);
            this.textBoxToTesting.MaxLength = 250;
            this.textBoxToTesting.Name = "textBoxToTesting";
            this.textBoxToTesting.Size = new Size(0x146, 20);
            this.textBoxToTesting.TabIndex = 9;
            this.textPort.Location = new Point(0x88, 0x61);
            this.textPort.MaxLength = 50;
            this.textPort.Name = "textPort";
            this.textPort.Size = new Size(0x83, 20);
            this.textPort.TabIndex = 6;
            this.label21.AutoSize = true;
            this.label21.ForeColor = SystemColors.ControlText;
            this.label21.Location = new Point(110, 0x7e);
            this.label21.Name = "label21";
            this.label21.Size = new Size(20, 13);
            this.label21.TabIndex = 10;
            this.label21.Text = "To";
            this.textSender_Name.Location = new Point(0x88, 0x2d);
            this.textSender_Name.MaxLength = 50;
            this.textSender_Name.Name = "textSender_Name";
            this.textSender_Name.Size = new Size(0x146, 20);
            this.textSender_Name.TabIndex = 2;
            this.labelPort.ForeColor = SystemColors.ControlText;
            this.labelPort.Location = new Point(15, 100);
            this.labelPort.Name = "labelPort";
            this.labelPort.Size = new Size(0x73, 0x11);
            this.labelPort.TabIndex = 7;
            this.labelPort.Text = "Port";
            this.labelPort.TextAlign = ContentAlignment.TopRight;
            this.cbSSL.AutoSize = true;
            this.cbSSL.ForeColor = SystemColors.ControlText;
            this.cbSSL.Location = new Point(0x111, 100);
            this.cbSSL.Name = "cbSSL";
            this.cbSSL.Size = new Size(0x2e, 0x11);
            this.cbSSL.TabIndex = 8;
            this.cbSSL.Text = "SSL";
            this.cbSSL.UseVisualStyleBackColor = true;
            this.checkEmailAllow.AutoSize = true;
            this.checkEmailAllow.ForeColor = SystemColors.ControlText;
            this.checkEmailAllow.Location = new Point(20, 0x10);
            this.checkEmailAllow.Name = "checkEmailAllow";
            this.checkEmailAllow.Size = new Size(0x4f, 0x11);
            this.checkEmailAllow.TabIndex = 0;
            this.checkEmailAllow.Text = "Allow Email";
            this.checkEmailAllow.UseVisualStyleBackColor = true;
            this.checkEmailAllow.Visible = false;
            this.checkEmailAllow.CheckedChanged += new EventHandler(this.checkEmailAllow_CheckedChanged);
            this.tabPage8.BackColor = SystemColors.ButtonFace;
            this.tabPage8.Controls.Add(this.comboTable);
            this.tabPage8.Controls.Add(this.labelTable);
            this.tabPage8.Controls.Add(this.labelDescWarningField);
            this.tabPage8.Controls.Add(this.dgWarningTrace);
            this.tabPage8.Location = new Point(4, 0x16);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new Padding(3);
            this.tabPage8.Size = new Size(0x38f, 0x19e);
            this.tabPage8.TabIndex = 3;
            this.tabPage8.Text = "Email Warning Field";
            this.comboTable.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboTable.FormattingEnabled = true;
            this.comboTable.Location = new Point(0x63, 0x62);
            this.comboTable.Name = "comboTable";
            this.comboTable.Size = new Size(0x9c, 0x15);
            this.comboTable.TabIndex = 3;
            this.comboTable.SelectedIndexChanged += new EventHandler(this.comboTable_SelectedIndexChanged);
            this.labelTable.AutoSize = true;
            this.labelTable.Location = new Point(0x18, 0x65);
            this.labelTable.Name = "labelTable";
            this.labelTable.Size = new Size(0x45, 13);
            this.labelTable.TabIndex = 2;
            this.labelTable.Text = "Table name :";
            this.labelDescWarningField.AutoSize = true;
            this.labelDescWarningField.Location = new Point(0x18, 20);
            this.labelDescWarningField.Name = "labelDescWarningField";
            this.labelDescWarningField.Size = new Size(0x23f, 0x41);
            this.labelDescWarningField.TabIndex = 1;
            this.labelDescWarningField.Text = manager.GetString("labelDescWarningField.Text");
            this.dgWarningTrace.AllowUserToAddRows = false;
            this.dgWarningTrace.AllowUserToDeleteRows = false;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgWarningTrace.ColumnHeadersDefaultCellStyle = style;
            this.dgWarningTrace.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridViewColumn[] dataGridViewColumns = new DataGridViewColumn[] { this.Type, this.FieldName, this.traceOnly, this.Selected, this.Uniq };
            this.dgWarningTrace.Columns.AddRange(dataGridViewColumns);
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ActiveCaptionText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgWarningTrace.DefaultCellStyle = style2;
            this.dgWarningTrace.Location = new Point(0x1b, 0x81);
            this.dgWarningTrace.Name = "dgWarningTrace";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgWarningTrace.RowHeadersDefaultCellStyle = style3;
            this.dgWarningTrace.Size = new Size(0x216, 0x10b);
            this.dgWarningTrace.TabIndex = 0;
            this.dgWarningTrace.CellMouseUp += new DataGridViewCellMouseEventHandler(this.dgWarningTrace_OnCellMouseUp);
            this.dgWarningTrace.CellValueChanged += new DataGridViewCellEventHandler(this.dgWarningTrace_CellValueChanged);
            this.Type.HeaderText = "Type";
            this.Type.Name = "Type";
            this.Type.ReadOnly = true;
            this.FieldName.HeaderText = "Name";
            this.FieldName.MinimumWidth = 170;
            this.FieldName.Name = "FieldName";
            this.FieldName.ReadOnly = true;
            this.FieldName.Width = 170;
            this.traceOnly.HeaderText = "Trace Only";
            this.traceOnly.Name = "traceOnly";
            this.Selected.HeaderText = "Trace & Send Email";
            this.Selected.MinimumWidth = 120;
            this.Selected.Name = "Selected";
            this.Selected.Width = 120;
            this.Uniq.HeaderText = "Uniq";
            this.Uniq.Name = "Uniq";
            this.Uniq.ReadOnly = true;
            this.Uniq.Visible = false;
            this.tabPage7.BackColor = SystemColors.ButtonFace;
            this.tabPage7.Controls.Add(this.groupISCCAdd);
            this.tabPage7.Controls.Add(this.groupBox3);
            this.tabPage7.Controls.Add(this.groupBox1);
            this.tabPage7.Controls.Add(this.label108);
            this.tabPage7.Location = new Point(4, 0x16);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new Padding(3);
            this.tabPage7.Size = new Size(0x38f, 0x19e);
            this.tabPage7.TabIndex = 2;
            this.tabPage7.Text = "Certification";
            this.toolTip1.SetToolTip(this.tabPage7, "If use only 1 ISCC No for all commodities, then no need to maintain additional ISCC No for FFB\r\n");
            this.groupISCCAdd.Controls.Add(this.label15);
            this.groupISCCAdd.Controls.Add(this.label13);
            this.groupISCCAdd.Controls.Add(this.textUpstream);
            this.groupISCCAdd.Controls.Add(this.textTransportDist);
            this.groupISCCAdd.Controls.Add(this.labelUpstream);
            this.groupISCCAdd.Controls.Add(this.labelTransportDist);
            this.groupISCCAdd.Controls.Add(this.textCPOAllocation);
            this.groupISCCAdd.Controls.Add(this.labelCPOAllocation);
            this.groupISCCAdd.Location = new Point(0x1d8, 160);
            this.groupISCCAdd.Name = "groupISCCAdd";
            this.groupISCCAdd.Size = new Size(0x19c, 0x73);
            this.groupISCCAdd.TabIndex = 0x41;
            this.groupISCCAdd.TabStop = false;
            this.groupISCCAdd.Text = "Additional ISCC Statement";
            this.groupISCCAdd.Visible = false;
            this.label15.AutoSize = true;
            this.label15.Location = new Point(0xc6, 0x54);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x15, 13);
            this.label15.TabIndex = 0x41;
            this.label15.Text = "km";
            this.label13.AutoSize = true;
            this.label13.Location = new Point(0xc6, 0x1f);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x8b, 13);
            this.label13.TabIndex = 0x40;
            this.label13.Text = "kgCO2eq / MT FFB (actual)";
            this.textUpstream.BackColor = SystemColors.Window;
            this.textUpstream.Location = new Point(120, 0x1b);
            this.textUpstream.MaxLength = 50;
            this.textUpstream.Name = "textUpstream";
            this.textUpstream.Size = new Size(0x48, 20);
            this.textUpstream.TabIndex = 0x3a;
            this.textUpstream.Text = "0.000";
            this.textUpstream.TextAlign = HorizontalAlignment.Right;
            this.textTransportDist.BackColor = SystemColors.Window;
            this.textTransportDist.Location = new Point(120, 80);
            this.textTransportDist.MaxLength = 50;
            this.textTransportDist.Name = "textTransportDist";
            this.textTransportDist.Size = new Size(0x48, 20);
            this.textTransportDist.TabIndex = 0x3f;
            this.textTransportDist.Text = "0.000";
            this.textTransportDist.TextAlign = HorizontalAlignment.Right;
            this.labelUpstream.AutoSize = true;
            this.labelUpstream.Location = new Point(0x12, 0x1f);
            this.labelUpstream.Name = "labelUpstream";
            this.labelUpstream.Size = new Size(0x60, 13);
            this.labelUpstream.TabIndex = 0x39;
            this.labelUpstream.Text = "Upstream Emission";
            this.labelTransportDist.AutoSize = true;
            this.labelTransportDist.Location = new Point(0x12, 0x54);
            this.labelTransportDist.Name = "labelTransportDist";
            this.labelTransportDist.Size = new Size(0x61, 13);
            this.labelTransportDist.TabIndex = 0x3e;
            this.labelTransportDist.Text = "Transport Distance";
            this.textCPOAllocation.BackColor = SystemColors.Window;
            this.textCPOAllocation.Location = new Point(120, 0x36);
            this.textCPOAllocation.MaxLength = 50;
            this.textCPOAllocation.Name = "textCPOAllocation";
            this.textCPOAllocation.Size = new Size(0x48, 20);
            this.textCPOAllocation.TabIndex = 0x3d;
            this.textCPOAllocation.Text = "0.000";
            this.textCPOAllocation.TextAlign = HorizontalAlignment.Right;
            this.labelCPOAllocation.AutoSize = true;
            this.labelCPOAllocation.Location = new Point(0x12, 0x3a);
            this.labelCPOAllocation.Name = "labelCPOAllocation";
            this.labelCPOAllocation.Size = new Size(0x4e, 13);
            this.labelCPOAllocation.TabIndex = 60;
            this.labelCPOAllocation.Text = "CPO Allocation";
            this.groupBox3.Controls.Add(this.panel12);
            this.groupBox3.Controls.Add(this.checkISCC);
            this.groupBox3.Location = new Point(0x11, 15);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(0x1b7, 0x17f);
            this.groupBox3.TabIndex = 0x41;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ISCC";
            this.panel12.Controls.Add(this.textISCC2);
            this.panel12.Controls.Add(this.label81);
            this.panel12.Controls.Add(this.label_ISCC_Add);
            this.panel12.Controls.Add(this.label80);
            this.panel12.Controls.Add(this.label117);
            this.panel12.Controls.Add(this.textISCC);
            this.panel12.Controls.Add(this.dtValidISCC);
            this.panel12.Controls.Add(this.groupBoxGHG);
            this.panel12.Location = new Point(6, 0x2a);
            this.panel12.Name = "panel12";
            this.panel12.Size = new Size(0x1ab, 0x14d);
            this.panel12.TabIndex = 0x42;
            this.textISCC2.Location = new Point(0x97, 0x4e);
            this.textISCC2.MaxLength = 100;
            this.textISCC2.Name = "textISCC2";
            this.textISCC2.Size = new Size(0xf4, 20);
            this.textISCC2.TabIndex = 0x40;
            this.toolTip1.SetToolTip(this.textISCC2, "If use 1 ISCC No for all commodities, then no need to maintain additional ISCC for FFB");
            this.label81.AutoSize = true;
            this.label81.Location = new Point(8, 8);
            this.label81.Name = "label81";
            this.label81.Size = new Size(0x4c, 13);
            this.label81.TabIndex = 0x38;
            this.label81.Text = "Default value :";
            this.label_ISCC_Add.AutoSize = true;
            this.label_ISCC_Add.Location = new Point(7, 0x51);
            this.label_ISCC_Add.Name = "label_ISCC_Add";
            this.label_ISCC_Add.Size = new Size(0x8a, 13);
            this.label_ISCC_Add.TabIndex = 0x3f;
            this.label_ISCC_Add.Text = "Use additional ISCC for FFB";
            this.label80.AutoSize = true;
            this.label80.Location = new Point(8, 0x1d);
            this.label80.Name = "label80";
            this.label80.Size = new Size(0x33, 13);
            this.label80.TabIndex = 0x36;
            this.label80.Text = "ISCC No.";
            this.label117.AutoSize = true;
            this.label117.Location = new Point(8, 0x33);
            this.label117.Name = "label117";
            this.label117.Size = new Size(0x38, 13);
            this.label117.TabIndex = 0x3e;
            this.label117.Text = "Valid Date";
            this.textISCC.BackColor = SystemColors.Window;
            this.textISCC.Location = new Point(0x48, 0x19);
            this.textISCC.Name = "textISCC";
            this.textISCC.Size = new Size(0x143, 20);
            this.textISCC.TabIndex = 0x36;
            this.textISCC.Text = "EU-ISCC-Cert-DE999-1234567890";
            this.dtValidISCC.Format = DateTimePickerFormat.Short;
            this.dtValidISCC.Location = new Point(0x48, 0x2f);
            this.dtValidISCC.Name = "dtValidISCC";
            this.dtValidISCC.Size = new Size(0x74, 20);
            this.dtValidISCC.TabIndex = 0x3d;
            this.groupBoxGHG.Controls.Add(this.cBoxGHG);
            this.groupBoxGHG.Controls.Add(this.labelGHG1);
            this.groupBoxGHG.Controls.Add(this.textISCC_S_Remark);
            this.groupBoxGHG.Controls.Add(this.labelRemark_S);
            this.groupBoxGHG.Controls.Add(this.labelGHG_S);
            this.groupBoxGHG.Controls.Add(this.label83);
            this.groupBoxGHG.Controls.Add(this.textISCC_F_Remark);
            this.groupBoxGHG.Controls.Add(this.labelRemark_FFB);
            this.groupBoxGHG.Controls.Add(this.label84);
            this.groupBoxGHG.Controls.Add(this.labelGHG_FFB);
            this.groupBoxGHG.Controls.Add(this.label82);
            this.groupBoxGHG.Controls.Add(this.textGHG_S);
            this.groupBoxGHG.Controls.Add(this.label79);
            this.groupBoxGHG.Controls.Add(this.textGHG_F);
            this.groupBoxGHG.Controls.Add(this.radioGHG2);
            this.groupBoxGHG.Controls.Add(this.radioGHG1);
            this.groupBoxGHG.Location = new Point(11, 0x6d);
            this.groupBoxGHG.Name = "groupBoxGHG";
            this.groupBoxGHG.Size = new Size(0x195, 0xd3);
            this.groupBoxGHG.TabIndex = 0x37;
            this.groupBoxGHG.TabStop = false;
            this.groupBoxGHG.Text = "GHG";
            this.cBoxGHG.AutoSize = true;
            this.cBoxGHG.Checked = true;
            this.cBoxGHG.CheckState = CheckState.Checked;
            this.cBoxGHG.Location = new Point(14, 0x13);
            this.cBoxGHG.Name = "cBoxGHG";
            this.cBoxGHG.Size = new Size(80, 0x11);
            this.cBoxGHG.TabIndex = 0x42;
            this.cBoxGHG.Text = "Show GHG";
            this.cBoxGHG.UseVisualStyleBackColor = true;
            this.labelGHG1.AutoSize = true;
            this.labelGHG1.Location = new Point(0x1f, 0x2e);
            this.labelGHG1.Name = "labelGHG1";
            this.labelGHG1.Size = new Size(0x84, 13);
            this.labelGHG1.TabIndex = 0x45;
            this.labelGHG1.Text = "Use of Grandfather Clause";
            this.textISCC_S_Remark.BackColor = SystemColors.Window;
            this.textISCC_S_Remark.Location = new Point(0x23, 0x98);
            this.textISCC_S_Remark.MaxLength = 200;
            this.textISCC_S_Remark.Multiline = true;
            this.textISCC_S_Remark.Name = "textISCC_S_Remark";
            this.textISCC_S_Remark.Size = new Size(0x15d, 0x31);
            this.textISCC_S_Remark.TabIndex = 0x44;
            this.labelRemark_S.AutoSize = true;
            this.labelRemark_S.Location = new Point(340, 20);
            this.labelRemark_S.Name = "labelRemark_S";
            this.labelRemark_S.Size = new Size(0x2c, 13);
            this.labelRemark_S.TabIndex = 0x43;
            this.labelRemark_S.Text = "Remark";
            this.labelRemark_S.Visible = false;
            this.labelGHG_S.AutoSize = true;
            this.labelGHG_S.Location = new Point(0x146, 0x13);
            this.labelGHG_S.Name = "labelGHG_S";
            this.labelGHG_S.Size = new Size(0x1f, 13);
            this.labelGHG_S.TabIndex = 0x42;
            this.labelGHG_S.Text = "GHG";
            this.labelGHG_S.Visible = false;
            this.label83.AutoSize = true;
            this.label83.Location = new Point(0x1f, 0x87);
            this.label83.Name = "label83";
            this.label83.Size = new Size(50, 13);
            this.label83.TabIndex = 60;
            this.label83.Text = "Standard";
            this.textISCC_F_Remark.BackColor = SystemColors.Window;
            this.textISCC_F_Remark.Location = new Point(0x23, 80);
            this.textISCC_F_Remark.MaxLength = 200;
            this.textISCC_F_Remark.Multiline = true;
            this.textISCC_F_Remark.Name = "textISCC_F_Remark";
            this.textISCC_F_Remark.Size = new Size(0x15d, 0x31);
            this.textISCC_F_Remark.TabIndex = 0x41;
            this.labelRemark_FFB.AutoSize = true;
            this.labelRemark_FFB.Location = new Point(0x146, 0x13);
            this.labelRemark_FFB.Name = "labelRemark_FFB";
            this.labelRemark_FFB.Size = new Size(0x2c, 13);
            this.labelRemark_FFB.TabIndex = 0x3b;
            this.labelRemark_FFB.Text = "Remark";
            this.labelRemark_FFB.Visible = false;
            this.label84.AutoSize = true;
            this.label84.Location = new Point(0x15d, 0x13);
            this.label84.Name = "label84";
            this.label84.Size = new Size(20, 13);
            this.label84.TabIndex = 0x3b;
            this.label84.Text = "Kg";
            this.label84.Visible = false;
            this.labelGHG_FFB.AutoSize = true;
            this.labelGHG_FFB.Location = new Point(0x16b, 0x13);
            this.labelGHG_FFB.Name = "labelGHG_FFB";
            this.labelGHG_FFB.Size = new Size(0x1f, 13);
            this.labelGHG_FFB.TabIndex = 0x3a;
            this.labelGHG_FFB.Text = "GHG";
            this.labelGHG_FFB.Visible = false;
            this.label82.AutoSize = true;
            this.label82.Location = new Point(0x20, 0x42);
            this.label82.Name = "label82";
            this.label82.Size = new Size(0x20, 13);
            this.label82.TabIndex = 0x39;
            this.label82.Text = "F F B";
            this.textGHG_S.Enabled = false;
            this.textGHG_S.Location = new Point(0x13b, 0x10);
            this.textGHG_S.MaxLength = 15;
            this.textGHG_S.Name = "textGHG_S";
            this.textGHG_S.Size = new Size(80, 20);
            this.textGHG_S.TabIndex = 0x3a;
            this.textGHG_S.Text = "0.000";
            this.textGHG_S.TextAlign = HorizontalAlignment.Right;
            this.textGHG_S.Visible = false;
            this.label79.AutoSize = true;
            this.label79.Location = new Point(0x15d, 0x13);
            this.label79.Name = "label79";
            this.label79.Size = new Size(20, 13);
            this.label79.TabIndex = 0x38;
            this.label79.Text = "Kg";
            this.label79.Visible = false;
            this.textGHG_F.Enabled = false;
            this.textGHG_F.Location = new Point(0x13b, 0x10);
            this.textGHG_F.MaxLength = 15;
            this.textGHG_F.Name = "textGHG_F";
            this.textGHG_F.Size = new Size(80, 20);
            this.textGHG_F.TabIndex = 0x36;
            this.textGHG_F.Text = "0.000";
            this.textGHG_F.TextAlign = HorizontalAlignment.Right;
            this.textGHG_F.Visible = false;
            this.radioGHG2.AutoSize = true;
            this.radioGHG2.Checked = true;
            this.radioGHG2.Enabled = false;
            this.radioGHG2.Location = new Point(15, 0x42);
            this.radioGHG2.Name = "radioGHG2";
            this.radioGHG2.Size = new Size(14, 13);
            this.radioGHG2.TabIndex = 1;
            this.radioGHG2.TabStop = true;
            this.radioGHG2.UseVisualStyleBackColor = true;
            this.radioGHG2.CheckedChanged += new EventHandler(this.radioGHG2_CheckedChanged);
            this.radioGHG1.AutoSize = true;
            this.radioGHG1.Enabled = false;
            this.radioGHG1.Location = new Point(15, 0x2e);
            this.radioGHG1.Name = "radioGHG1";
            this.radioGHG1.Size = new Size(14, 13);
            this.radioGHG1.TabIndex = 0;
            this.radioGHG1.UseVisualStyleBackColor = true;
            this.radioGHG1.CheckedChanged += new EventHandler(this.radioGHG1_CheckedChanged);
            this.checkISCC.AutoSize = true;
            this.checkISCC.Checked = true;
            this.checkISCC.CheckState = CheckState.Checked;
            this.checkISCC.Location = new Point(0x12, 0x13);
            this.checkISCC.Name = "checkISCC";
            this.checkISCC.Size = new Size(0x5f, 0x11);
            this.checkISCC.TabIndex = 0x37;
            this.checkISCC.Text = "Used ISCC No";
            this.checkISCC.UseVisualStyleBackColor = true;
            this.checkISCC.CheckedChanged += new EventHandler(this.checkISCC_CheckedChanged);
            this.groupBox1.Controls.Add(this.textFormISO);
            this.groupBox1.Controls.Add(this.textIso3);
            this.groupBox1.Controls.Add(this.label101);
            this.groupBox1.Controls.Add(this.labeliso3);
            this.groupBox1.Controls.Add(this.textIso2);
            this.groupBox1.Controls.Add(this.labeliso2);
            this.groupBox1.Location = new Point(0x1d8, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x19c, 0x73);
            this.groupBox1.TabIndex = 0x40;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ISO";
            this.textFormISO.BackColor = SystemColors.Window;
            this.textFormISO.Location = new Point(0x55, 0x1b);
            this.textFormISO.MaxLength = 50;
            this.textFormISO.Name = "textFormISO";
            this.textFormISO.Size = new Size(0x120, 20);
            this.textFormISO.TabIndex = 0x3a;
            this.textFormISO.Text = "EU-ISCC-Cert-DE999-1234567890";
            this.textIso3.BackColor = SystemColors.Window;
            this.textIso3.Location = new Point(0x55, 80);
            this.textIso3.MaxLength = 50;
            this.textIso3.Name = "textIso3";
            this.textIso3.Size = new Size(0x120, 20);
            this.textIso3.TabIndex = 0x3f;
            this.label101.AutoSize = true;
            this.label101.Location = new Point(0x12, 0x1f);
            this.label101.Name = "label101";
            this.label101.Size = new Size(0x39, 13);
            this.label101.TabIndex = 0x39;
            this.label101.Text = "ISO Line 1";
            this.labeliso3.AutoSize = true;
            this.labeliso3.Location = new Point(0x12, 0x54);
            this.labeliso3.Name = "labeliso3";
            this.labeliso3.Size = new Size(0x39, 13);
            this.labeliso3.TabIndex = 0x3e;
            this.labeliso3.Text = "ISO Line 3";
            this.textIso2.BackColor = SystemColors.Window;
            this.textIso2.Location = new Point(0x55, 0x36);
            this.textIso2.MaxLength = 50;
            this.textIso2.Name = "textIso2";
            this.textIso2.Size = new Size(0x120, 20);
            this.textIso2.TabIndex = 0x3d;
            this.labeliso2.AutoSize = true;
            this.labeliso2.Location = new Point(0x12, 0x3a);
            this.labeliso2.Name = "labeliso2";
            this.labeliso2.Size = new Size(0x39, 13);
            this.labeliso2.TabIndex = 60;
            this.labeliso2.Text = "ISO Line 2";
            this.label108.AutoSize = true;
            this.label108.Location = new Point(0x2f2, 0x181);
            this.label108.Name = "label108";
            this.label108.Size = new Size(0x97, 13);
            this.label108.TabIndex = 0x3b;
            this.label108.Text = "*Printed in Weighbridge Ticket";
            this.tabPage4.BackColor = SystemColors.ButtonFace;
            this.tabPage4.BorderStyle = BorderStyle.Fixed3D;
            this.tabPage4.Controls.Add(this.buttonTestOpen);
            this.tabPage4.Controls.Add(this.label58);
            this.tabPage4.Controls.Add(this.panel8);
            this.tabPage4.Controls.Add(this.label57);
            this.tabPage4.Controls.Add(this.panel7);
            this.tabPage4.Location = new Point(4, 0x16);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new Padding(3);
            this.tabPage4.Size = new Size(0x3a7, 0x1c8);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = " Connection";
            this.tabPage4.Click += new EventHandler(this.tabPage4_Click);
            this.buttonTestOpen.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonTestOpen.Location = new Point(0x68, 0x137);
            this.buttonTestOpen.Name = "buttonTestOpen";
            this.buttonTestOpen.Size = new Size(0xec, 0x2d);
            this.buttonTestOpen.TabIndex = 7;
            this.buttonTestOpen.Text = " Company List";
            this.buttonTestOpen.UseVisualStyleBackColor = true;
            this.buttonTestOpen.Click += new EventHandler(this.buttonTestOpen_Click);
            this.label58.AutoSize = true;
            this.label58.Location = new Point(0x188, 20);
            this.label58.Name = "label58";
            this.label58.Size = new Size(0x41, 13);
            this.label58.TabIndex = 10;
            this.label58.Text = " Information ";
            this.panel8.BorderStyle = BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.textCompanyCode);
            this.panel8.Controls.Add(this.label24);
            this.panel8.Controls.Add(this.textLine);
            this.panel8.Controls.Add(this.label69);
            this.panel8.Controls.Add(this.textUpload_Type);
            this.panel8.Controls.Add(this.label68);
            this.panel8.Controls.Add(this.textSTO_Item);
            this.panel8.Controls.Add(this.textGR_Discharge);
            this.panel8.Controls.Add(this.textTransport_Type);
            this.panel8.Controls.Add(this.textGR_Storage);
            this.panel8.Controls.Add(this.textGI_Batch);
            this.panel8.Controls.Add(this.textGI_Storage);
            this.panel8.Controls.Add(this.label70);
            this.panel8.Controls.Add(this.label71);
            this.panel8.Controls.Add(this.label72);
            this.panel8.Controls.Add(this.label73);
            this.panel8.Controls.Add(this.label74);
            this.panel8.Controls.Add(this.label75);
            this.panel8.Controls.Add(this.textTransit_Storage);
            this.panel8.Controls.Add(this.label76);
            this.panel8.Controls.Add(this.textSO_Item);
            this.panel8.Controls.Add(this.textStorage_Supp);
            this.panel8.Controls.Add(this.textPlant_Supp);
            this.panel8.Controls.Add(this.textMov_Type);
            this.panel8.Controls.Add(this.textBatch);
            this.panel8.Controls.Add(this.textUoM);
            this.panel8.Controls.Add(this.textStorage_Rcv);
            this.panel8.Controls.Add(this.textPlant_Rcv);
            this.panel8.Controls.Add(this.label67);
            this.panel8.Controls.Add(this.label66);
            this.panel8.Controls.Add(this.label65);
            this.panel8.Controls.Add(this.label64);
            this.panel8.Controls.Add(this.label63);
            this.panel8.Controls.Add(this.label62);
            this.panel8.Controls.Add(this.label61);
            this.panel8.Controls.Add(this.label60);
            this.panel8.Controls.Add(this.textBill_Lading);
            this.panel8.Controls.Add(this.label59);
            this.panel8.Location = new Point(0x18b, 0x24);
            this.panel8.Name = "panel8";
            this.panel8.Size = new Size(0x209, 0x124);
            this.panel8.TabIndex = 0;
            this.textCompanyCode.Location = new Point(0x9a, 0x12);
            this.textCompanyCode.MaxLength = 15;
            this.textCompanyCode.Name = "textCompanyCode";
            this.textCompanyCode.Size = new Size(0x6c, 20);
            this.textCompanyCode.TabIndex = 0x27;
            this.label24.Location = new Point(3, 0x15);
            this.label24.Name = "label24";
            this.label24.Size = new Size(0x95, 13);
            this.label24.TabIndex = 40;
            this.label24.Text = " Location Code";
            this.label24.TextAlign = ContentAlignment.TopRight;
            this.textLine.Location = new Point(0x18d, 0x60);
            this.textLine.MaxLength = 20;
            this.textLine.Name = "textLine";
            this.textLine.Size = new Size(0x6c, 20);
            this.textLine.TabIndex = 11;
            this.label69.Location = new Point(0x10f, 0x63);
            this.label69.Name = "label69";
            this.label69.Size = new Size(120, 13);
            this.label69.TabIndex = 0x26;
            this.label69.Text = "Line";
            this.label69.TextAlign = ContentAlignment.TopRight;
            this.textUpload_Type.Location = new Point(0x18d, 70);
            this.textUpload_Type.MaxLength = 20;
            this.textUpload_Type.Name = "textUpload_Type";
            this.textUpload_Type.Size = new Size(0x6c, 20);
            this.textUpload_Type.TabIndex = 10;
            this.label68.Location = new Point(0x10f, 0x49);
            this.label68.Name = "label68";
            this.label68.Size = new Size(0x7b, 13);
            this.label68.TabIndex = 0x24;
            this.label68.Text = "Upload Type";
            this.label68.TextAlign = ContentAlignment.TopRight;
            this.textSTO_Item.Location = new Point(0x18d, 0xfc);
            this.textSTO_Item.MaxLength = 20;
            this.textSTO_Item.Name = "textSTO_Item";
            this.textSTO_Item.Size = new Size(0x6c, 20);
            this.textSTO_Item.TabIndex = 0x11;
            this.textGR_Discharge.Location = new Point(0x18d, 0xe0);
            this.textGR_Discharge.MaxLength = 20;
            this.textGR_Discharge.Name = "textGR_Discharge";
            this.textGR_Discharge.Size = new Size(0x6c, 20);
            this.textGR_Discharge.TabIndex = 0x10;
            this.textTransport_Type.Location = new Point(0x18d, 0xc6);
            this.textTransport_Type.MaxLength = 20;
            this.textTransport_Type.Name = "textTransport_Type";
            this.textTransport_Type.Size = new Size(0x6c, 20);
            this.textTransport_Type.TabIndex = 15;
            this.textGR_Storage.Location = new Point(0x18d, 0xae);
            this.textGR_Storage.MaxLength = 20;
            this.textGR_Storage.Name = "textGR_Storage";
            this.textGR_Storage.Size = new Size(0x6c, 20);
            this.textGR_Storage.TabIndex = 14;
            this.textGI_Batch.Location = new Point(0x18d, 0x94);
            this.textGI_Batch.MaxLength = 20;
            this.textGI_Batch.Name = "textGI_Batch";
            this.textGI_Batch.Size = new Size(0x6c, 20);
            this.textGI_Batch.TabIndex = 13;
            this.textGI_Storage.Location = new Point(0x18d, 0x7a);
            this.textGI_Storage.MaxLength = 20;
            this.textGI_Storage.Name = "textGI_Storage";
            this.textGI_Storage.Size = new Size(0x6c, 20);
            this.textGI_Storage.TabIndex = 12;
            this.label70.Location = new Point(0x10f, 0xff);
            this.label70.Name = "label70";
            this.label70.Size = new Size(0x7b, 13);
            this.label70.TabIndex = 0x1b;
            this.label70.Text = "STO Item";
            this.label70.TextAlign = ContentAlignment.TopRight;
            this.label71.Location = new Point(0x10f, 0xe5);
            this.label71.Name = "label71";
            this.label71.Size = new Size(0x7b, 15);
            this.label71.TabIndex = 0x1a;
            this.label71.Text = "GR Discharge";
            this.label71.TextAlign = ContentAlignment.TopRight;
            this.label72.Location = new Point(0x10f, 0xc9);
            this.label72.Name = "label72";
            this.label72.Size = new Size(0x7b, 0x11);
            this.label72.TabIndex = 0x19;
            this.label72.Text = "Transport Type";
            this.label72.TextAlign = ContentAlignment.TopRight;
            this.label73.Location = new Point(0x10f, 0xb1);
            this.label73.Name = "label73";
            this.label73.Size = new Size(0x7b, 13);
            this.label73.TabIndex = 0x18;
            this.label73.Text = "GR Storage";
            this.label73.TextAlign = ContentAlignment.TopRight;
            this.label74.Location = new Point(0x10f, 0x98);
            this.label74.Name = "label74";
            this.label74.Size = new Size(0x7b, 13);
            this.label74.TabIndex = 0x17;
            this.label74.Text = "GI Batch";
            this.label74.TextAlign = ContentAlignment.TopRight;
            this.label75.Location = new Point(0x10f, 0x7e);
            this.label75.Name = "label75";
            this.label75.Size = new Size(0x7b, 0x10);
            this.label75.TabIndex = 0x16;
            this.label75.Text = "GI Storage";
            this.label75.TextAlign = ContentAlignment.TopRight;
            this.textTransit_Storage.Location = new Point(0x18d, 0x2b);
            this.textTransit_Storage.MaxLength = 20;
            this.textTransit_Storage.Name = "textTransit_Storage";
            this.textTransit_Storage.Size = new Size(0x6c, 20);
            this.textTransit_Storage.TabIndex = 9;
            this.label76.Location = new Point(0x10c, 0x2e);
            this.label76.Name = "label76";
            this.label76.Size = new Size(0x7e, 14);
            this.label76.TabIndex = 20;
            this.label76.Text = "Transit Storage";
            this.label76.TextAlign = ContentAlignment.TopRight;
            this.textSO_Item.Location = new Point(0x9a, 0xfc);
            this.textSO_Item.MaxLength = 10;
            this.textSO_Item.Name = "textSO_Item";
            this.textSO_Item.Size = new Size(0x6c, 20);
            this.textSO_Item.TabIndex = 8;
            this.textStorage_Supp.Location = new Point(0x9a, 0xe2);
            this.textStorage_Supp.MaxLength = 10;
            this.textStorage_Supp.Name = "textStorage_Supp";
            this.textStorage_Supp.Size = new Size(0x6c, 20);
            this.textStorage_Supp.TabIndex = 7;
            this.textPlant_Supp.Location = new Point(0x9a, 0xc9);
            this.textPlant_Supp.MaxLength = 10;
            this.textPlant_Supp.Name = "textPlant_Supp";
            this.textPlant_Supp.Size = new Size(0x6c, 20);
            this.textPlant_Supp.TabIndex = 6;
            this.textMov_Type.Location = new Point(0x9a, 0xad);
            this.textMov_Type.MaxLength = 3;
            this.textMov_Type.Name = "textMov_Type";
            this.textMov_Type.Size = new Size(0x6c, 20);
            this.textMov_Type.TabIndex = 5;
            this.textBatch.Location = new Point(0x9a, 0x93);
            this.textBatch.MaxLength = 10;
            this.textBatch.Name = "textBatch";
            this.textBatch.Size = new Size(0x6c, 20);
            this.textBatch.TabIndex = 4;
            this.textUoM.Location = new Point(0x9a, 0x7b);
            this.textUoM.MaxLength = 10;
            this.textUoM.Name = "textUoM";
            this.textUoM.Size = new Size(0x6c, 20);
            this.textUoM.TabIndex = 3;
            this.textStorage_Rcv.Location = new Point(0x9a, 0x61);
            this.textStorage_Rcv.MaxLength = 10;
            this.textStorage_Rcv.Name = "textStorage_Rcv";
            this.textStorage_Rcv.Size = new Size(0x6c, 20);
            this.textStorage_Rcv.TabIndex = 2;
            this.textPlant_Rcv.Location = new Point(0x9a, 0x47);
            this.textPlant_Rcv.MaxLength = 10;
            this.textPlant_Rcv.Name = "textPlant_Rcv";
            this.textPlant_Rcv.Size = new Size(0x6c, 20);
            this.textPlant_Rcv.TabIndex = 1;
            this.label67.Location = new Point(6, 0xff);
            this.label67.Name = "label67";
            this.label67.Size = new Size(0x92, 13);
            this.label67.TabIndex = 11;
            this.label67.Text = "SO Item";
            this.label67.TextAlign = ContentAlignment.TopRight;
            this.label66.Location = new Point(9, 0xe5);
            this.label66.Name = "label66";
            this.label66.Size = new Size(0x8f, 15);
            this.label66.TabIndex = 10;
            this.label66.Text = "Storage ( Supplying )";
            this.label66.TextAlign = ContentAlignment.TopRight;
            this.label65.Location = new Point(6, 0xcc);
            this.label65.Name = "label65";
            this.label65.Size = new Size(0x92, 14);
            this.label65.TabIndex = 9;
            this.label65.Text = "Plant ( Supplying )";
            this.label65.TextAlign = ContentAlignment.TopRight;
            this.label64.Location = new Point(9, 0xb2);
            this.label64.Name = "label64";
            this.label64.Size = new Size(0x8f, 0x10);
            this.label64.TabIndex = 8;
            this.label64.Text = "Movement Type";
            this.label64.TextAlign = ContentAlignment.TopRight;
            this.label63.Location = new Point(6, 150);
            this.label63.Name = "label63";
            this.label63.Size = new Size(0x92, 15);
            this.label63.TabIndex = 7;
            this.label63.Text = "Batch";
            this.label63.TextAlign = ContentAlignment.TopRight;
            this.label62.Location = new Point(12, 0x7e);
            this.label62.Name = "label62";
            this.label62.Size = new Size(140, 0x11);
            this.label62.TabIndex = 6;
            this.label62.Text = "UoM";
            this.label62.TextAlign = ContentAlignment.TopRight;
            this.label61.Location = new Point(6, 100);
            this.label61.Name = "label61";
            this.label61.Size = new Size(0x92, 0x10);
            this.label61.TabIndex = 5;
            this.label61.Text = "Storage ( Receiving )";
            this.label61.TextAlign = ContentAlignment.TopRight;
            this.label60.Location = new Point(6, 0x4a);
            this.label60.Name = "label60";
            this.label60.Size = new Size(0x92, 0x10);
            this.label60.TabIndex = 4;
            this.label60.Text = "Plant ( Receiving )";
            this.label60.TextAlign = ContentAlignment.TopRight;
            this.textBill_Lading.Location = new Point(0x9a, 0x2c);
            this.textBill_Lading.MaxLength = 15;
            this.textBill_Lading.Name = "textBill_Lading";
            this.textBill_Lading.Size = new Size(0x6c, 20);
            this.textBill_Lading.TabIndex = 0;
            this.label59.Location = new Point(6, 0x2f);
            this.label59.Name = "label59";
            this.label59.Size = new Size(0x92, 0x10);
            this.label59.TabIndex = 2;
            this.label59.Text = "Bill of Lading";
            this.label59.TextAlign = ContentAlignment.TopRight;
            this.label57.AutoSize = true;
            this.label57.Location = new Point(0x11, 20);
            this.label57.Name = "label57";
            this.label57.Size = new Size(0x40, 13);
            this.label57.TabIndex = 8;
            this.label57.Text = " Connection";
            this.panel7.BorderStyle = BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.label16);
            this.panel7.Controls.Add(this.textSAPClient);
            this.panel7.Controls.Add(this.label41);
            this.panel7.Controls.Add(this.textSAPLogonSystemID);
            this.panel7.Controls.Add(this.label30);
            this.panel7.Controls.Add(this.textSAPLogonGroup);
            this.panel7.Controls.Add(this.textSAPMSSPort);
            this.panel7.Controls.Add(this.label28);
            this.panel7.Controls.Add(this.textSAPServer);
            this.panel7.Controls.Add(this.button5);
            this.panel7.Controls.Add(this.label54);
            this.panel7.Controls.Add(this.textSAPPassword);
            this.panel7.Controls.Add(this.label55);
            this.panel7.Controls.Add(this.label56);
            this.panel7.Controls.Add(this.textSAPLoginID);
            this.panel7.Location = new Point(12, 0x24);
            this.panel7.Name = "panel7";
            this.panel7.Size = new Size(0x148, 0x100);
            this.panel7.TabIndex = 7;
            this.label16.Location = new Point(7, 0x76);
            this.label16.Name = "label16";
            this.label16.Size = new Size(0x86, 0x11);
            this.label16.TabIndex = 0x10;
            this.label16.Text = "Client";
            this.label16.TextAlign = ContentAlignment.TopRight;
            this.textSAPClient.Location = new Point(0x93, 0x74);
            this.textSAPClient.MaxLength = 50;
            this.textSAPClient.Name = "textSAPClient";
            this.textSAPClient.Size = new Size(0x9f, 20);
            this.textSAPClient.TabIndex = 7;
            this.label41.Location = new Point(7, 0xa7);
            this.label41.Name = "label41";
            this.label41.Size = new Size(0x86, 0x11);
            this.label41.TabIndex = 14;
            this.label41.Text = "SAP Logon System ID";
            this.label41.TextAlign = ContentAlignment.TopRight;
            this.textSAPLogonSystemID.Location = new Point(0x93, 0xa5);
            this.textSAPLogonSystemID.MaxLength = 50;
            this.textSAPLogonSystemID.Name = "textSAPLogonSystemID";
            this.textSAPLogonSystemID.Size = new Size(0x9f, 20);
            this.textSAPLogonSystemID.TabIndex = 9;
            this.label30.Location = new Point(7, 0x8d);
            this.label30.Name = "label30";
            this.label30.Size = new Size(0x86, 0x11);
            this.label30.TabIndex = 12;
            this.label30.Text = "SAP Logon Group";
            this.label30.TextAlign = ContentAlignment.TopRight;
            this.textSAPLogonGroup.Location = new Point(0x93, 0x8d);
            this.textSAPLogonGroup.MaxLength = 50;
            this.textSAPLogonGroup.Name = "textSAPLogonGroup";
            this.textSAPLogonGroup.Size = new Size(0x9f, 20);
            this.textSAPLogonGroup.TabIndex = 8;
            this.textSAPMSSPort.Location = new Point(0x93, 0x5c);
            this.textSAPMSSPort.MaxLength = 5;
            this.textSAPMSSPort.Name = "textSAPMSSPort";
            this.textSAPMSSPort.Size = new Size(0x9f, 20);
            this.textSAPMSSPort.TabIndex = 6;
            this.label28.Location = new Point(7, 0x5d);
            this.label28.Name = "label28";
            this.label28.Size = new Size(0x86, 0x11);
            this.label28.TabIndex = 9;
            this.label28.Text = "SAP MSS Port";
            this.label28.TextAlign = ContentAlignment.TopRight;
            this.textSAPServer.Location = new Point(0x93, 14);
            this.textSAPServer.MaxLength = 50;
            this.textSAPServer.Name = "textSAPServer";
            this.textSAPServer.Size = new Size(0x9f, 20);
            this.textSAPServer.TabIndex = 1;
            this.button5.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button5.Location = new Point(0x93, 0xc3);
            this.button5.Name = "button5";
            this.button5.Size = new Size(0x9f, 0x2d);
            this.button5.TabIndex = 10;
            this.button5.Text = "Test Connection";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new EventHandler(this.button5_Click);
            this.label54.Location = new Point(7, 0x11);
            this.label54.Name = "label54";
            this.label54.Size = new Size(0x86, 0x11);
            this.label54.TabIndex = 0;
            this.label54.Text = "SAP MSS Host";
            this.label54.TextAlign = ContentAlignment.TopRight;
            this.textSAPPassword.Location = new Point(0x93, 0x42);
            this.textSAPPassword.MaxLength = 50;
            this.textSAPPassword.Name = "textSAPPassword";
            this.textSAPPassword.Size = new Size(0x9f, 20);
            this.textSAPPassword.TabIndex = 5;
            this.textSAPPassword.UseSystemPasswordChar = true;
            this.label55.Location = new Point(7, 0x2b);
            this.label55.Name = "label55";
            this.label55.Size = new Size(0x86, 0x10);
            this.label55.TabIndex = 2;
            this.label55.Text = " Login ID";
            this.label55.TextAlign = ContentAlignment.TopRight;
            this.label56.Location = new Point(7, 0x45);
            this.label56.Name = "label56";
            this.label56.Size = new Size(0x86, 0x11);
            this.label56.TabIndex = 4;
            this.label56.Text = " Password";
            this.label56.TextAlign = ContentAlignment.TopRight;
            this.textSAPLoginID.Location = new Point(0x93, 40);
            this.textSAPLoginID.MaxLength = 50;
            this.textSAPLoginID.Name = "textSAPLoginID";
            this.textSAPLoginID.Size = new Size(0x9f, 20);
            this.textSAPLoginID.TabIndex = 3;
            this.tabPageSystem.BackColor = SystemColors.ButtonFace;
            this.tabPageSystem.Controls.Add(this.groupBox10);
            this.tabPageSystem.Controls.Add(this.panel18);
            this.tabPageSystem.Controls.Add(this.panel17);
            this.tabPageSystem.Controls.Add(this.panel20);
            this.tabPageSystem.Controls.Add(this.panel3);
            this.tabPageSystem.Controls.Add(this.panelLanguage);
            this.tabPageSystem.Controls.Add(this.panelCode);
            this.tabPageSystem.Controls.Add(this.panel23);
            this.tabPageSystem.Controls.Add(this.panelLoadUnload);
            this.tabPageSystem.Controls.Add(this.panel21);
            this.tabPageSystem.Controls.Add(this.panel15);
            this.tabPageSystem.Controls.Add(this.panelZWB);
            this.tabPageSystem.Controls.Add(this.label107);
            this.tabPageSystem.Location = new Point(4, 0x16);
            this.tabPageSystem.Name = "tabPageSystem";
            this.tabPageSystem.Padding = new Padding(3);
            this.tabPageSystem.Size = new Size(0x3a7, 0x1c8);
            this.tabPageSystem.TabIndex = 5;
            this.tabPageSystem.Text = "System";
            this.groupBox10.Controls.Add(this.label77);
            this.groupBox10.Controls.Add(this.comboBoxTruckRegion);
            this.groupBox10.Controls.Add(this.label87);
            this.groupBox10.Location = new Point(0x19c, 0xad);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new Size(0xe3, 0x4f);
            this.groupBox10.TabIndex = 0x5e;
            this.groupBox10.TabStop = false;
            this.label77.AutoSize = true;
            this.label77.Location = new Point(20, 0x26);
            this.label77.Name = "label77";
            this.label77.Size = new Size(0x29, 13);
            this.label77.TabIndex = 0x52;
            this.label77.Text = "Region";
            this.comboBoxTruckRegion.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboBoxTruckRegion.FormattingEnabled = true;
            object[] items = new object[] { "0 - Indonesia", "1 - Afrika", "2 - Malaysia", "3 - Bangladesh", "4 - Myanmar" };
            this.comboBoxTruckRegion.Items.AddRange(items);
            this.comboBoxTruckRegion.Location = new Point(0x4c, 0x23);
            this.comboBoxTruckRegion.Name = "comboBoxTruckRegion";
            this.comboBoxTruckRegion.Size = new Size(0x70, 0x15);
            this.comboBoxTruckRegion.TabIndex = 0x52;
            this.label87.AutoSize = true;
            this.label87.Location = new Point(9, 15);
            this.label87.Name = "label87";
            this.label87.Size = new Size(0x48, 13);
            this.label87.TabIndex = 0x51;
            this.label87.Text = "Truck Region";
            this.panel18.Controls.Add(this.rboCpNo);
            this.panel18.Controls.Add(this.label92);
            this.panel18.Controls.Add(this.rboCpYes);
            this.panel18.Location = new Point(0x284, 0xea);
            this.panel18.Name = "panel18";
            this.panel18.Size = new Size(0x11a, 60);
            this.panel18.TabIndex = 0x62;
            this.panel18.TabStop = false;
            this.rboCpNo.AutoSize = true;
            this.rboCpNo.Checked = true;
            this.rboCpNo.Location = new Point(0x21, 0x24);
            this.rboCpNo.Name = "rboCpNo";
            this.rboCpNo.Size = new Size(0x27, 0x11);
            this.rboCpNo.TabIndex = 0x2c;
            this.rboCpNo.TabStop = true;
            this.rboCpNo.Text = "No";
            this.rboCpNo.UseVisualStyleBackColor = true;
            this.label92.AutoSize = true;
            this.label92.Location = new Point(11, 0x10);
            this.label92.Name = "label92";
            this.label92.Size = new Size(0xb2, 13);
            this.label92.TabIndex = 0x34;
            this.label92.Text = "Automatic Sync Using this Computer";
            this.rboCpYes.AutoSize = true;
            this.rboCpYes.Location = new Point(0x92, 0x24);
            this.rboCpYes.Name = "rboCpYes";
            this.rboCpYes.Size = new Size(0x2b, 0x11);
            this.rboCpYes.TabIndex = 0x2b;
            this.rboCpYes.Text = "Yes";
            this.rboCpYes.UseVisualStyleBackColor = true;
            this.panel17.Controls.Add(this.dateRef6);
            this.panel17.Controls.Add(this.label109);
            this.panel17.Controls.Add(this.checkRef6);
            this.panel17.Location = new Point(20, 360);
            this.panel17.Name = "panel17";
            this.panel17.Size = new Size(0x182, 0x45);
            this.panel17.TabIndex = 0x61;
            this.panel17.TabStop = false;
            this.dateRef6.Location = new Point(0x70, 0x27);
            this.dateRef6.Name = "dateRef6";
            this.dateRef6.Size = new Size(0xda, 20);
            this.dateRef6.TabIndex = 1;
            this.label109.AutoSize = true;
            this.label109.Location = new Point(11, 0x10);
            this.label109.Name = "label109";
            this.label109.Size = new Size(0x4a, 13);
            this.label109.TabIndex = 0x48;
            this.label109.Text = "Ref No 6 Digit";
            this.checkRef6.AutoSize = true;
            this.checkRef6.Location = new Point(0x16, 0x29);
            this.checkRef6.Name = "checkRef6";
            this.checkRef6.Size = new Size(0x41, 0x11);
            this.checkRef6.TabIndex = 0;
            this.checkRef6.Text = "Activate";
            this.checkRef6.UseVisualStyleBackColor = true;
            this.panel20.Controls.Add(this.btn_advise);
            this.panel20.Controls.Add(this.label29);
            this.panel20.Controls.Add(this.text_advise);
            this.panel20.Controls.Add(this.textTicket);
            this.panel20.Controls.Add(this.label52);
            this.panel20.Controls.Add(this.buttonTicket1);
            this.panel20.Controls.Add(this.buttonGatepass);
            this.panel20.Controls.Add(this.button8);
            this.panel20.Controls.Add(this.textGatepass);
            this.panel20.Controls.Add(this.label27);
            this.panel20.Controls.Add(this.label130);
            this.panel20.Controls.Add(this.checkDirect);
            this.panel20.Location = new Point(0x13, 0xcd);
            this.panel20.Name = "panel20";
            this.panel20.Size = new Size(0x182, 150);
            this.panel20.TabIndex = 0x60;
            this.panel20.TabStop = false;
            this.btn_advise.Location = new Point(0x150, 0x54);
            this.btn_advise.Name = "btn_advise";
            this.btn_advise.Size = new Size(0x19, 0x17);
            this.btn_advise.TabIndex = 0x4a;
            this.btn_advise.Text = "...";
            this.btn_advise.UseVisualStyleBackColor = true;
            this.btn_advise.Click += new EventHandler(this.btn_advise_Click);
            this.label29.AutoSize = true;
            this.label29.Location = new Point(11, 0x10);
            this.label29.Name = "label29";
            this.label29.Size = new Size(0x38, 13);
            this.label29.TabIndex = 0x45;
            this.label29.Text = "Ticket File";
            this.text_advise.Location = new Point(0x70, 0x56);
            this.text_advise.Name = "text_advise";
            this.text_advise.Size = new Size(0xda, 20);
            this.text_advise.TabIndex = 0x49;
            this.textTicket.Location = new Point(0x70, 0x26);
            this.textTicket.Name = "textTicket";
            this.textTicket.Size = new Size(0xda, 20);
            this.textTicket.TabIndex = 60;
            this.label52.AutoSize = true;
            this.label52.Location = new Point(0x16, 0x59);
            this.label52.Name = "label52";
            this.label52.Size = new Size(0x27, 13);
            this.label52.TabIndex = 0x48;
            this.label52.Text = "Advise";
            this.buttonTicket1.Location = new Point(0x150, 0x24);
            this.buttonTicket1.Name = "buttonTicket1";
            this.buttonTicket1.Size = new Size(0x19, 0x17);
            this.buttonTicket1.TabIndex = 0x3d;
            this.buttonTicket1.Text = "...";
            this.buttonTicket1.UseVisualStyleBackColor = true;
            this.buttonTicket1.Click += new EventHandler(this.button7_Click);
            this.buttonGatepass.Location = new Point(0x150, 60);
            this.buttonGatepass.Name = "buttonGatepass";
            this.buttonGatepass.Size = new Size(0x19, 0x17);
            this.buttonGatepass.TabIndex = 0x47;
            this.buttonGatepass.Text = "...";
            this.buttonGatepass.UseVisualStyleBackColor = true;
            this.buttonGatepass.Click += new EventHandler(this.buttonGatepass_Click);
            this.button8.Location = new Point(0xf7, 0x71);
            this.button8.Name = "button8";
            this.button8.Size = new Size(0x72, 0x1c);
            this.button8.TabIndex = 0x3e;
            this.button8.Text = "Reload File";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new EventHandler(this.button8_Click);
            this.textGatepass.Location = new Point(0x70, 0x3e);
            this.textGatepass.Name = "textGatepass";
            this.textGatepass.Size = new Size(0xda, 20);
            this.textGatepass.TabIndex = 70;
            this.label27.AutoSize = true;
            this.label27.Location = new Point(0x16, 0x29);
            this.label27.Name = "label27";
            this.label27.Size = new Size(0x3f, 13);
            this.label27.TabIndex = 0x3b;
            this.label27.Text = "Main Ticket";
            this.label130.AutoSize = true;
            this.label130.Location = new Point(0x16, 0x41);
            this.label130.Name = "label130";
            this.label130.Size = new Size(0x34, 13);
            this.label130.TabIndex = 0x45;
            this.label130.Text = "Gatepass";
            this.checkDirect.AutoSize = true;
            this.checkDirect.Location = new Point(0x19, 120);
            this.checkDirect.Name = "checkDirect";
            this.checkDirect.Size = new Size(0x86, 0x11);
            this.checkDirect.TabIndex = 0x44;
            this.checkDirect.Text = "Direct to default Printer";
            this.checkDirect.UseVisualStyleBackColor = true;
            this.panel3.Controls.Add(this.checkBoxDailyLog);
            this.panel3.Controls.Add(this.label50);
            this.panel3.Controls.Add(this.checkBoxPrintGatepass);
            this.panel3.Controls.Add(this.checkStorage);
            this.panel3.Controls.Add(this.checkNonContract);
            this.panel3.Controls.Add(this.checkWBNo);
            this.panel3.Controls.Add(this.checkContainer);
            this.panel3.Controls.Add(this.checkTrailer);
            this.panel3.Location = new Point(0x284, 0x34);
            this.panel3.Name = "panel3";
            this.panel3.Size = new Size(0x11a, 0xb7);
            this.panel3.TabIndex = 0x5f;
            this.panel3.TabStop = false;
            this.checkBoxDailyLog.AutoSize = true;
            this.checkBoxDailyLog.Location = new Point(0x16, 0x9e);
            this.checkBoxDailyLog.Name = "checkBoxDailyLog";
            this.checkBoxDailyLog.Size = new Size(0xc0, 0x11);
            this.checkBoxDailyLog.TabIndex = 0x1c;
            this.checkBoxDailyLog.Text = "Send Daily Log Email Using this PC";
            this.checkBoxDailyLog.UseVisualStyleBackColor = true;
            this.label50.AutoSize = true;
            this.label50.Location = new Point(11, 0x10);
            this.label50.Name = "label50";
            this.label50.Size = new Size(40, 13);
            this.label50.TabIndex = 0x40;
            this.label50.Text = "Control";
            this.checkBoxPrintGatepass.AutoSize = true;
            this.checkBoxPrintGatepass.Location = new Point(0x16, 0x8a);
            this.checkBoxPrintGatepass.Name = "checkBoxPrintGatepass";
            this.checkBoxPrintGatepass.Size = new Size(0xca, 0x11);
            this.checkBoxPrintGatepass.TabIndex = 0x1b;
            this.checkBoxPrintGatepass.Text = "Allow Print Gatepass After 1st Weight";
            this.checkBoxPrintGatepass.UseVisualStyleBackColor = true;
            this.checkStorage.AutoSize = true;
            this.checkStorage.Location = new Point(0x16, 0x27);
            this.checkStorage.Name = "checkStorage";
            this.checkStorage.Size = new Size(110, 0x11);
            this.checkStorage.TabIndex = 4;
            this.checkStorage.Text = "The Storage Field";
            this.checkStorage.UseVisualStyleBackColor = true;
            this.checkNonContract.AutoSize = true;
            this.checkNonContract.Location = new Point(0x16, 0x76);
            this.checkNonContract.Name = "checkNonContract";
            this.checkNonContract.Size = new Size(0x94, 0x11);
            this.checkNonContract.TabIndex = 0x19;
            this.checkNonContract.Text = "Non Contract Transaction";
            this.checkNonContract.UseVisualStyleBackColor = true;
            this.checkWBNo.AutoSize = true;
            this.checkWBNo.Location = new Point(0x16, 0x3b);
            this.checkWBNo.Name = "checkWBNo";
            this.checkWBNo.Size = new Size(0x77, 0x11);
            this.checkWBNo.TabIndex = 6;
            this.checkWBNo.Text = "The WB Reference";
            this.checkWBNo.UseVisualStyleBackColor = true;
            this.checkContainer.AutoSize = true;
            this.checkContainer.Location = new Point(0x16, 0x62);
            this.checkContainer.Name = "checkContainer";
            this.checkContainer.Size = new Size(0x6c, 0x11);
            this.checkContainer.TabIndex = 0x18;
            this.checkContainer.Text = "Weight Container";
            this.checkContainer.UseVisualStyleBackColor = true;
            this.checkTrailer.AutoSize = true;
            this.checkTrailer.Location = new Point(0x16, 0x4e);
            this.checkTrailer.Name = "checkTrailer";
            this.checkTrailer.Size = new Size(0x7a, 0x11);
            this.checkTrailer.TabIndex = 0x17;
            this.checkTrailer.Text = "Trailer Number Entry";
            this.checkTrailer.UseVisualStyleBackColor = true;
            this.panelLanguage.Controls.Add(this.radioLangInd);
            this.panelLanguage.Controls.Add(this.radioLangEnglish);
            this.panelLanguage.Controls.Add(this.radioLangFrench);
            this.panelLanguage.Controls.Add(this.labelLang);
            this.panelLanguage.Location = new Point(20, 0x71);
            this.panelLanguage.Name = "panelLanguage";
            this.panelLanguage.Size = new Size(190, 0x56);
            this.panelLanguage.TabIndex = 0x5e;
            this.panelLanguage.TabStop = false;
            this.radioLangInd.AutoSize = true;
            this.radioLangInd.Location = new Point(0x16, 0x39);
            this.radioLangInd.Name = "radioLangInd";
            this.radioLangInd.Size = new Size(0x4d, 0x11);
            this.radioLangInd.TabIndex = 0x59;
            this.radioLangInd.Text = "Indonesian";
            this.radioLangInd.UseVisualStyleBackColor = true;
            this.radioLangEnglish.AutoSize = true;
            this.radioLangEnglish.Checked = true;
            this.radioLangEnglish.Location = new Point(0x16, 0x22);
            this.radioLangEnglish.Name = "radioLangEnglish";
            this.radioLangEnglish.Size = new Size(0x3b, 0x11);
            this.radioLangEnglish.TabIndex = 50;
            this.radioLangEnglish.TabStop = true;
            this.radioLangEnglish.Text = "English";
            this.radioLangEnglish.UseVisualStyleBackColor = true;
            this.radioLangFrench.AutoSize = true;
            this.radioLangFrench.Location = new Point(0x68, 0x22);
            this.radioLangFrench.Name = "radioLangFrench";
            this.radioLangFrench.Size = new Size(0x3a, 0x11);
            this.radioLangFrench.TabIndex = 0x33;
            this.radioLangFrench.Text = "French";
            this.radioLangFrench.UseVisualStyleBackColor = true;
            this.labelLang.AutoSize = true;
            this.labelLang.Location = new Point(11, 0x10);
            this.labelLang.Name = "labelLang";
            this.labelLang.Size = new Size(0x37, 13);
            this.labelLang.TabIndex = 0x58;
            this.labelLang.Text = "Language";
            this.panelCode.Controls.Add(this.labelGatepassCode);
            this.panelCode.Controls.Add(this.labelCode);
            this.panelCode.Controls.Add(this.textGatepassCode);
            this.panelCode.Controls.Add(this.labelTACode);
            this.panelCode.Controls.Add(this.textTACode);
            this.panelCode.Location = new Point(0x19c, 0xfc);
            this.panelCode.Name = "panelCode";
            this.panelCode.Size = new Size(0xe3, 0x5d);
            this.panelCode.TabIndex = 0x5d;
            this.panelCode.TabStop = false;
            this.labelGatepassCode.AutoSize = true;
            this.labelGatepassCode.Location = new Point(20, 0x3d);
            this.labelGatepassCode.Name = "labelGatepassCode";
            this.labelGatepassCode.Size = new Size(80, 13);
            this.labelGatepassCode.TabIndex = 3;
            this.labelGatepassCode.Text = "Gatepass Code";
            this.labelCode.AutoSize = true;
            this.labelCode.Location = new Point(9, 15);
            this.labelCode.Name = "labelCode";
            this.labelCode.Size = new Size(0x20, 13);
            this.labelCode.TabIndex = 0x51;
            this.labelCode.Text = "Code";
            this.textGatepassCode.Location = new Point(0x81, 0x3a);
            this.textGatepassCode.MaxLength = 2;
            this.textGatepassCode.Name = "textGatepassCode";
            this.textGatepassCode.Size = new Size(30, 20);
            this.textGatepassCode.TabIndex = 2;
            this.textGatepassCode.KeyPress += new KeyPressEventHandler(this.textGatepassCode_KeyPress);
            this.textGatepassCode.Leave += new EventHandler(this.textGatepassCode_Leave);
            this.labelTACode.AutoSize = true;
            this.labelTACode.Location = new Point(20, 0x24);
            this.labelTACode.Name = "labelTACode";
            this.labelTACode.Size = new Size(0x5f, 13);
            this.labelTACode.TabIndex = 1;
            this.labelTACode.Text = "Truck Arrival Code";
            this.textTACode.Location = new Point(0x81, 0x20);
            this.textTACode.MaxLength = 2;
            this.textTACode.Name = "textTACode";
            this.textTACode.Size = new Size(30, 20);
            this.textTACode.TabIndex = 0;
            this.textTACode.KeyPress += new KeyPressEventHandler(this.textTACode_KeyPress);
            this.textTACode.Leave += new EventHandler(this.textTACode_Leave);
            this.panel23.Controls.Add(this.radioTrans1);
            this.panel23.Controls.Add(this.label129);
            this.panel23.Controls.Add(this.radioTrans3);
            this.panel23.Controls.Add(this.radioTrans2);
            this.panel23.Location = new Point(0x19c, 0x34);
            this.panel23.Name = "panel23";
            this.panel23.Size = new Size(0xe2, 0x79);
            this.panel23.TabIndex = 0x5c;
            this.panel23.TabStop = false;
            this.radioTrans1.AutoSize = true;
            this.radioTrans1.Checked = true;
            this.radioTrans1.Location = new Point(0x16, 0x57);
            this.radioTrans1.Name = "radioTrans1";
            this.radioTrans1.Size = new Size(0x3a, 0x11);
            this.radioTrans1.TabIndex = 0x34;
            this.radioTrans1.TabStop = true;
            this.radioTrans1.Text = "Normal";
            this.radioTrans1.UseVisualStyleBackColor = true;
            this.radioTrans1.CheckedChanged += new EventHandler(this.radioTrans1_CheckedChanged);
            this.label129.AutoSize = true;
            this.label129.Location = new Point(11, 0x10);
            this.label129.Name = "label129";
            this.label129.Size = new Size(0x58, 13);
            this.label129.TabIndex = 80;
            this.label129.Text = "Transaction Flow";
            this.radioTrans3.AutoSize = true;
            this.radioTrans3.Location = new Point(0x16, 0x27);
            this.radioTrans3.Name = "radioTrans3";
            this.radioTrans3.Size = new Size(0xbb, 0x11);
            this.radioTrans3.TabIndex = 50;
            this.radioTrans3.Text = "Truck Arrival + Gatepass + Normal";
            this.radioTrans3.UseVisualStyleBackColor = true;
            this.radioTrans3.CheckedChanged += new EventHandler(this.radioTrans3_CheckedChanged);
            this.radioTrans2.AutoSize = true;
            this.radioTrans2.Location = new Point(0x16, 0x3f);
            this.radioTrans2.Name = "radioTrans2";
            this.radioTrans2.Size = new Size(0x73, 0x11);
            this.radioTrans2.TabIndex = 0x33;
            this.radioTrans2.Text = "Gatepass + Normal";
            this.radioTrans2.UseVisualStyleBackColor = true;
            this.radioTrans2.CheckedChanged += new EventHandler(this.radioTrans2_CheckedChanged);
            this.panelLoadUnload.Controls.Add(this.radioLoadNo);
            this.panelLoadUnload.Controls.Add(this.labelLoadUnload);
            this.panelLoadUnload.Controls.Add(this.radioLoadYes);
            this.panelLoadUnload.Location = new Point(0x19d, 0x159);
            this.panelLoadUnload.Name = "panelLoadUnload";
            this.panelLoadUnload.Size = new Size(0xe2, 60);
            this.panelLoadUnload.TabIndex = 0x5b;
            this.panelLoadUnload.TabStop = false;
            this.radioLoadNo.AutoSize = true;
            this.radioLoadNo.Checked = true;
            this.radioLoadNo.Location = new Point(0x16, 0x23);
            this.radioLoadNo.Name = "radioLoadNo";
            this.radioLoadNo.Size = new Size(0x27, 0x11);
            this.radioLoadNo.TabIndex = 1;
            this.radioLoadNo.TabStop = true;
            this.radioLoadNo.Text = "No";
            this.radioLoadNo.UseVisualStyleBackColor = true;
            this.labelLoadUnload.AutoSize = true;
            this.labelLoadUnload.Location = new Point(11, 0x10);
            this.labelLoadUnload.Name = "labelLoadUnload";
            this.labelLoadUnload.Size = new Size(70, 13);
            this.labelLoadUnload.TabIndex = 0x52;
            this.labelLoadUnload.Text = "Load/Unload";
            this.radioLoadYes.AutoSize = true;
            this.radioLoadYes.Location = new Point(0x73, 0x23);
            this.radioLoadYes.Name = "radioLoadYes";
            this.radioLoadYes.Size = new Size(0x2b, 0x11);
            this.radioLoadYes.TabIndex = 0;
            this.radioLoadYes.Text = "Yes";
            this.radioLoadYes.UseVisualStyleBackColor = true;
            this.panel21.Controls.Add(this.radioMalaysia);
            this.panel21.Controls.Add(this.label118);
            this.panel21.Controls.Add(this.radioIndonesia);
            this.panel21.Controls.Add(this.radioAfrica);
            this.panel21.Location = new Point(0xd8, 0x34);
            this.panel21.Name = "panel21";
            this.panel21.Size = new Size(190, 0x79);
            this.panel21.TabIndex = 90;
            this.panel21.TabStop = false;
            this.radioMalaysia.AutoSize = true;
            this.radioMalaysia.Location = new Point(0x16, 0x56);
            this.radioMalaysia.Name = "radioMalaysia";
            this.radioMalaysia.Size = new Size(0x42, 0x11);
            this.radioMalaysia.TabIndex = 0x34;
            this.radioMalaysia.Text = "Malaysia";
            this.radioMalaysia.UseVisualStyleBackColor = true;
            this.label118.AutoSize = true;
            this.label118.Location = new Point(11, 0x10);
            this.label118.Name = "label118";
            this.label118.Size = new Size(0x29, 13);
            this.label118.TabIndex = 0x4a;
            this.label118.Text = "Region";
            this.radioIndonesia.AutoSize = true;
            this.radioIndonesia.Checked = true;
            this.radioIndonesia.Location = new Point(0x16, 0x27);
            this.radioIndonesia.Name = "radioIndonesia";
            this.radioIndonesia.Size = new Size(0x47, 0x11);
            this.radioIndonesia.TabIndex = 50;
            this.radioIndonesia.TabStop = true;
            this.radioIndonesia.Text = "Indonesia";
            this.radioIndonesia.UseVisualStyleBackColor = true;
            this.radioAfrica.AutoSize = true;
            this.radioAfrica.Location = new Point(0x16, 0x3e);
            this.radioAfrica.Name = "radioAfrica";
            this.radioAfrica.Size = new Size(0x34, 0x11);
            this.radioAfrica.TabIndex = 0x33;
            this.radioAfrica.Text = "Africa";
            this.radioAfrica.UseVisualStyleBackColor = true;
            this.panel15.Controls.Add(this.radioTypeRefinery);
            this.panel15.Controls.Add(this.radioTypePOM);
            this.panel15.Controls.Add(this.label26);
            this.panel15.Location = new Point(20, 0x34);
            this.panel15.Name = "panel15";
            this.panel15.Size = new Size(190, 60);
            this.panel15.TabIndex = 0x59;
            this.panel15.TabStop = false;
            this.radioTypeRefinery.AutoSize = true;
            this.radioTypeRefinery.Checked = true;
            this.radioTypeRefinery.Location = new Point(0x16, 0x22);
            this.radioTypeRefinery.Name = "radioTypeRefinery";
            this.radioTypeRefinery.Size = new Size(0x40, 0x11);
            this.radioTypeRefinery.TabIndex = 50;
            this.radioTypeRefinery.TabStop = true;
            this.radioTypeRefinery.Text = "Refinery";
            this.radioTypeRefinery.UseVisualStyleBackColor = true;
            this.radioTypePOM.AutoSize = true;
            this.radioTypePOM.Location = new Point(0x68, 0x22);
            this.radioTypePOM.Name = "radioTypePOM";
            this.radioTypePOM.Size = new Size(0x31, 0x11);
            this.radioTypePOM.TabIndex = 0x33;
            this.radioTypePOM.Text = "POM";
            this.radioTypePOM.UseVisualStyleBackColor = true;
            this.label26.AutoSize = true;
            this.label26.Location = new Point(11, 0x10);
            this.label26.Name = "label26";
            this.label26.Size = new Size(0x4b, 13);
            this.label26.TabIndex = 0x38;
            this.label26.Text = "Location Type";
            this.panelZWB.Controls.Add(this.panel14);
            this.panelZWB.Controls.Add(this.panel16);
            this.panelZWB.Location = new Point(0x27f, 0x126);
            this.panelZWB.Name = "panelZWB";
            this.panelZWB.Size = new Size(0x125, 0x9c);
            this.panelZWB.TabIndex = 0x54;
            this.panel14.Controls.Add(this.numericInterval);
            this.panel14.Controls.Add(this.label96);
            this.panel14.Controls.Add(this.rboScheduleYes);
            this.panel14.Controls.Add(this.label91);
            this.panel14.Controls.Add(this.textSAPTime);
            this.panel14.Controls.Add(this.rboScheduleNo);
            this.panel14.Controls.Add(this.label89);
            this.panel14.Controls.Add(this.label90);
            this.panel14.Location = new Point(5, 60);
            this.panel14.Name = "panel14";
            this.panel14.Size = new Size(0x11a, 0x58);
            this.panel14.TabIndex = 100;
            this.panel14.TabStop = false;
            this.numericInterval.Location = new Point(0xbd, 0x3b);
            this.numericInterval.Name = "numericInterval";
            this.numericInterval.Size = new Size(0x2c, 20);
            this.numericInterval.TabIndex = 0x31;
            this.numericInterval.Text = "0";
            this.label96.AutoSize = true;
            this.label96.Location = new Point(0x13, 15);
            this.label96.Name = "label96";
            this.label96.Size = new Size(0x6a, 13);
            this.label96.TabIndex = 0x2a;
            this.label96.Text = "Automatic Upload to ";
            this.rboScheduleYes.AutoSize = true;
            this.rboScheduleYes.Location = new Point(0x92, 0x23);
            this.rboScheduleYes.Name = "rboScheduleYes";
            this.rboScheduleYes.Size = new Size(0x2b, 0x11);
            this.rboScheduleYes.TabIndex = 0x2b;
            this.rboScheduleYes.Text = "Yes";
            this.rboScheduleYes.UseVisualStyleBackColor = true;
            this.rboScheduleYes.CheckedChanged += new EventHandler(this.rboScheduleYes_CheckedChanged);
            this.label91.AutoSize = true;
            this.label91.Location = new Point(0x20, 0x3e);
            this.label91.Name = "label91";
            this.label91.Size = new Size(0x29, 13);
            this.label91.TabIndex = 0x30;
            this.label91.Text = "Start at";
            this.textSAPTime.Location = new Point(0x4f, 0x3b);
            this.textSAPTime.Mask = "00:00";
            this.textSAPTime.Name = "textSAPTime";
            this.textSAPTime.Size = new Size(0x24, 20);
            this.textSAPTime.TabIndex = 0x2d;
            this.textSAPTime.Text = "0800";
            this.rboScheduleNo.AutoSize = true;
            this.rboScheduleNo.Checked = true;
            this.rboScheduleNo.Location = new Point(0x22, 0x23);
            this.rboScheduleNo.Name = "rboScheduleNo";
            this.rboScheduleNo.Size = new Size(0x27, 0x11);
            this.rboScheduleNo.TabIndex = 0x2c;
            this.rboScheduleNo.TabStop = true;
            this.rboScheduleNo.Text = "No";
            this.rboScheduleNo.UseVisualStyleBackColor = true;
            this.rboScheduleNo.CheckedChanged += new EventHandler(this.rboScheduleNo_CheckedChanged);
            this.label89.AutoSize = true;
            this.label89.Location = new Point(0xef, 0x3e);
            this.label89.Name = "label89";
            this.label89.Size = new Size(0x1c, 13);
            this.label89.TabIndex = 0x2e;
            this.label89.Text = "hour";
            this.label90.AutoSize = true;
            this.label90.Location = new Point(0x8d, 0x3e);
            this.label90.Name = "label90";
            this.label90.Size = new Size(0x2a, 13);
            this.label90.TabIndex = 0x2a;
            this.label90.Text = "Interval";
            this.panel16.Controls.Add(this.radioZWBNo);
            this.panel16.Controls.Add(this.radioZWBYes);
            this.panel16.Controls.Add(this.label23);
            this.panel16.Location = new Point(5, 1);
            this.panel16.Name = "panel16";
            this.panel16.Size = new Size(0x11a, 60);
            this.panel16.TabIndex = 0x63;
            this.panel16.TabStop = false;
            this.radioZWBNo.AutoSize = true;
            this.radioZWBNo.Checked = true;
            this.radioZWBNo.Location = new Point(0x22, 0x24);
            this.radioZWBNo.Name = "radioZWBNo";
            this.radioZWBNo.Size = new Size(0x27, 0x11);
            this.radioZWBNo.TabIndex = 0x2c;
            this.radioZWBNo.TabStop = true;
            this.radioZWBNo.Text = "No";
            this.radioZWBNo.UseVisualStyleBackColor = true;
            this.radioZWBYes.AutoSize = true;
            this.radioZWBYes.Location = new Point(0x92, 0x24);
            this.radioZWBYes.Name = "radioZWBYes";
            this.radioZWBYes.Size = new Size(0x2b, 0x11);
            this.radioZWBYes.TabIndex = 0x2b;
            this.radioZWBYes.Text = "Yes";
            this.radioZWBYes.UseVisualStyleBackColor = true;
            this.label23.AutoSize = true;
            this.label23.Location = new Point(0x12, 0x10);
            this.label23.Name = "label23";
            this.label23.Size = new Size(80, 13);
            this.label23.TabIndex = 0x2a;
            this.label23.Text = "Synchronize to ";
            this.label107.AutoSize = true;
            this.label107.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label107.Location = new Point(0x1a, 14);
            this.label107.Name = "label107";
            this.label107.Size = new Size(0x93, 0x10);
            this.label107.TabIndex = 70;
            this.label107.Text = "Set by Administrator";
            this.tabTool.BackColor = SystemColors.ButtonFace;
            this.tabTool.Controls.Add(this.groupBox4);
            this.tabTool.Controls.Add(this.buttonOpenLockRecord);
            this.tabTool.Controls.Add(this.buttonOpenLockTrans);
            this.tabTool.Location = new Point(4, 0x16);
            this.tabTool.Name = "tabTool";
            this.tabTool.Padding = new Padding(3);
            this.tabTool.Size = new Size(0x3a7, 0x1c8);
            this.tabTool.TabIndex = 6;
            this.tabTool.Text = "Tool";
            this.groupBox4.Controls.Add(this.txtRef);
            this.groupBox4.Controls.Add(this.btnReset_EditQty);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.btnReset_EditRec);
            this.groupBox4.Location = new Point(0x22, 0xb0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new Size(0x1cf, 0x4d);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Reset Count Edit Transaction && Edit Quantity Transaction if Already in Max 5 Times (TOKEN)";
            this.txtRef.Location = new Point(90, 0x21);
            this.txtRef.Name = "txtRef";
            this.txtRef.Size = new Size(0xa2, 20);
            this.txtRef.TabIndex = 3;
            this.btnReset_EditQty.Location = new Point(0x16f, 0x17);
            this.btnReset_EditQty.Name = "btnReset_EditQty";
            this.btnReset_EditQty.Size = new Size(0x4e, 0x27);
            this.btnReset_EditQty.TabIndex = 1;
            this.btnReset_EditQty.Text = "Reset Count Edit Quantity";
            this.btnReset_EditQty.UseVisualStyleBackColor = true;
            this.btnReset_EditQty.Click += new EventHandler(this.btnReset_EditQty_Click);
            this.label17.AutoSize = true;
            this.label17.Location = new Point(14, 0x24);
            this.label17.Name = "label17";
            this.label17.Size = new Size(0x2f, 13);
            this.label17.TabIndex = 3;
            this.label17.Text = "Ref. No.";
            this.btnReset_EditRec.Location = new Point(0x10c, 0x17);
            this.btnReset_EditRec.Name = "btnReset_EditRec";
            this.btnReset_EditRec.Size = new Size(0x53, 0x27);
            this.btnReset_EditRec.TabIndex = 0;
            this.btnReset_EditRec.Text = "Reset Count Edit Record";
            this.btnReset_EditRec.UseVisualStyleBackColor = true;
            this.btnReset_EditRec.Click += new EventHandler(this.btnReset_EditRec_Click);
            this.buttonOpenLockRecord.Location = new Point(0x22, 0x1d);
            this.buttonOpenLockRecord.Name = "buttonOpenLockRecord";
            this.buttonOpenLockRecord.Size = new Size(0x98, 0x2f);
            this.buttonOpenLockRecord.TabIndex = 1;
            this.buttonOpenLockRecord.Text = "Open All Locked Record";
            this.buttonOpenLockRecord.UseVisualStyleBackColor = true;
            this.buttonOpenLockRecord.Click += new EventHandler(this.buttonOpenLockRecord_Click);
            this.buttonOpenLockTrans.Location = new Point(0x22, 100);
            this.buttonOpenLockTrans.Name = "buttonOpenLockTrans";
            this.buttonOpenLockTrans.Size = new Size(0x98, 0x38);
            this.buttonOpenLockTrans.TabIndex = 0;
            this.buttonOpenLockTrans.Text = "Open Locked Reference No. When Save Transaction";
            this.buttonOpenLockTrans.UseVisualStyleBackColor = true;
            this.buttonOpenLockTrans.Click += new EventHandler(this.buttonOpenLockTrans_Click);
            this.tabPage2.BackColor = SystemColors.ButtonFace;
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.txtIntg);
            this.tabPage2.Location = new Point(4, 0x16);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new Padding(3);
            this.tabPage2.Size = new Size(0x3a7, 0x1c8);
            this.tabPage2.TabIndex = 7;
            this.tabPage2.Text = "E-Grading";
            this.groupBox9.Controls.Add(this.textBox2);
            this.groupBox9.Controls.Add(this.btnEG_connect);
            this.groupBox9.Controls.Add(this.label12);
            this.groupBox9.Controls.Add(this.textBox3);
            this.groupBox9.Controls.Add(this.label11);
            this.groupBox9.Controls.Add(this.textBox4);
            this.groupBox9.Controls.Add(this.label10);
            this.groupBox9.Controls.Add(this.textBox1);
            this.groupBox9.Controls.Add(this.label9);
            this.groupBox9.Location = new Point(0x10, 0x13);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new Size(0x202, 0x8a);
            this.groupBox9.TabIndex = 0x1c;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "E-Grading";
            this.textBox2.Location = new Point(0x85, 0x2e);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0xc6, 20);
            this.textBox2.TabIndex = 15;
            this.btnEG_connect.Location = new Point(0x177, 0x2d);
            this.btnEG_connect.Name = "btnEG_connect";
            this.btnEG_connect.Size = new Size(0x72, 0x2f);
            this.btnEG_connect.TabIndex = 0x16;
            this.btnEG_connect.Text = "Connect E-Grading";
            this.btnEG_connect.UseVisualStyleBackColor = true;
            this.btnEG_connect.Click += new EventHandler(this.btnEG_connect_Click);
            this.label12.Location = new Point(10, 0x12);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x75, 0x11);
            this.label12.TabIndex = 0x12;
            this.label12.Text = "Server";
            this.label12.TextAlign = ContentAlignment.TopRight;
            this.textBox3.Location = new Point(0x85, 0x4e);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Size(0x85, 20);
            this.textBox3.TabIndex = 0x10;
            this.textBox3.UseSystemPasswordChar = true;
            this.label11.Location = new Point(13, 0x30);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x72, 0x11);
            this.label11.TabIndex = 0x13;
            this.label11.Text = "Database Name";
            this.label11.TextAlign = ContentAlignment.TopRight;
            this.textBox4.Location = new Point(0x85, 0x6d);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Size(0x85, 20);
            this.textBox4.TabIndex = 0x11;
            this.textBox4.UseSystemPasswordChar = true;
            this.label10.Location = new Point(0x10, 0x51);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x6f, 0x11);
            this.label10.TabIndex = 20;
            this.label10.Text = "User ID";
            this.label10.TextAlign = ContentAlignment.TopRight;
            this.textBox1.Location = new Point(0x85, 15);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0xc6, 20);
            this.textBox1.TabIndex = 14;
            this.label9.Location = new Point(0x13, 0x70);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x6c, 0x10);
            this.label9.TabIndex = 0x15;
            this.label9.Text = "Password";
            this.label9.TextAlign = ContentAlignment.TopRight;
            this.button1.Location = new Point(0x187, 0xa8);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x72, 0x2f);
            this.button1.TabIndex = 0x1a;
            this.button1.Text = "Connect Integrator";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.label14.Location = new Point(0x16, 0xb9);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x6f, 0x11);
            this.label14.TabIndex = 0x19;
            this.label14.Text = "Integrator";
            this.label14.TextAlign = ContentAlignment.TopRight;
            this.txtIntg.Location = new Point(0x95, 0xb6);
            this.txtIntg.Name = "txtIntg";
            this.txtIntg.Size = new Size(0xc6, 20);
            this.txtIntg.TabIndex = 0x18;
            this.button2.Location = new Point(0x26d, 500);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x92, 0x1f);
            this.button2.TabIndex = 1;
            this.button2.Text = "&Save && Apply Setting";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button3.Location = new Point(0x31c, 500);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x5f, 0x1f);
            this.button3.TabIndex = 2;
            this.button3.Text = "&Close";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.openFileDialog1.FileName = "openFileDialog1";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x3c7, 0x21f);
            base.ControlBox = false;
            base.Controls.Add(this.button3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.tabGate);
            this.ForeColor = SystemColors.ActiveCaptionText;
            base.Icon = (Icon) manager.GetObject("$this.Icon");
            base.Name = "FormSetting";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "WeighBridge Setting & Configuration";
            base.FormClosing += new FormClosingEventHandler(this.FormSetting_FormClosing);
            base.Load += new EventHandler(this.FormSetting_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormSetting_KeyPress);
            this.tabGate.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.GrpInfo.ResumeLayout(false);
            this.GrpInfo.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.panelControlGrossHistory.ResumeLayout(false);
            this.panelControlGrossHistory.PerformLayout();
            this.panelCheckTare.ResumeLayout(false);
            this.panelCheckTare.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupFlagColor.ResumeLayout(false);
            this.groupFlagColor.PerformLayout();
            this.panelPOMSetting.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.GBoxAutoSPB.ResumeLayout(false);
            this.GBoxAutoSPB.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((ISupportInitialize) this.dgWarningTrace).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.groupISCCAdd.ResumeLayout(false);
            this.groupISCCAdd.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.groupBoxGHG.ResumeLayout(false);
            this.groupBoxGHG.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.tabPageSystem.ResumeLayout(false);
            this.tabPageSystem.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panelLanguage.ResumeLayout(false);
            this.panelLanguage.PerformLayout();
            this.panelCode.ResumeLayout(false);
            this.panelCode.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panelLoadUnload.ResumeLayout(false);
            this.panelLoadUnload.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panelZWB.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.tabTool.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            base.ResumeLayout(false);
        }

        private void numericInterval_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.numericInterval);
        }

        private void radioGHG1_CheckedChanged(object sender, EventArgs e)
        {
            this.textGHG_F.Enabled = false;
            this.textGHG_S.Enabled = false;
            this.textISCC_F_Remark.Enabled = false;
            this.textISCC_S_Remark.Enabled = false;
        }

        private void radioGHG2_CheckedChanged(object sender, EventArgs e)
        {
            this.textGHG_F.Enabled = true;
            this.textGHG_S.Enabled = true;
            this.textISCC_F_Remark.Enabled = true;
            this.textISCC_S_Remark.Enabled = true;
        }

        private void radioTrans1_CheckedChanged(object sender, EventArgs e)
        {
            this.showCode();
        }

        private void radioTrans2_CheckedChanged(object sender, EventArgs e)
        {
            this.showCode();
        }

        private void radioTrans3_CheckedChanged(object sender, EventArgs e)
        {
            this.showCode();
        }

        private void rboScheduleNo_CheckedChanged(object sender, EventArgs e)
        {
            this.schSAP = 'N';
            this.textSAPTime.Enabled = false;
        }

        private void rboScheduleYes_CheckedChanged(object sender, EventArgs e)
        {
            this.schSAP = 'Y';
            this.textSAPTime.Enabled = true;
        }

        private void showCode()
        {
            if (this.radioTrans3.Checked)
            {
                this.panelCode.Visible = true;
                this.labelCode.Visible = true;
                this.textTACode.Visible = true;
                this.labelTACode.Visible = true;
                this.labelGatepassCode.Visible = true;
                this.textGatepassCode.Visible = true;
            }
            else if (this.radioTrans2.Checked)
            {
                this.panelCode.Visible = true;
                this.labelCode.Visible = true;
                this.textTACode.Visible = false;
                this.labelTACode.Visible = false;
                this.labelGatepassCode.Visible = true;
                this.textGatepassCode.Visible = true;
            }
            else if (this.radioTrans1.Checked)
            {
                this.panelCode.Visible = false;
                this.labelCode.Visible = false;
                this.textTACode.Visible = false;
                this.labelTACode.Visible = false;
                this.labelGatepassCode.Visible = false;
                this.textGatepassCode.Visible = false;
            }
        }

        private void tabControl2_MouseClick(object sender, MouseEventArgs e)
        {
            this.textEmailTankerCC.Enabled = this.check_tanker;
            this.textEmailTankerTO.Enabled = this.check_tanker;
            this.textEmailTankerSubject.Enabled = this.check_tanker;
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {
        }

        private void textGatepassCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textGatepassCode_Leave(object sender, EventArgs e)
        {
            if (this.textGatepassCode.Text.Length < 2)
            {
                MessageBox.Show("Please insert 2 Character for Gatepass Code", "WARNING...");
                this.textGatepassCode.Focus();
            }
            if (((this.textTACode.Text != "") && (this.textGatepassCode.Text != "")) && (this.textTACode.Text == this.textGatepassCode.Text))
            {
                MessageBox.Show("Please Use Different Code from Truck Arrival and Gatepass", "WARNING...");
                this.textGatepassCode.Focus();
            }
            if (this.textGatepassCode.Text == WBData.sCoyCode)
            {
                MessageBox.Show("Cannot use the same code with Coy", "WARNING...");
                this.textGatepassCode.Focus();
            }
        }

        private void textTACode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTACode_Leave(object sender, EventArgs e)
        {
            if (this.textTACode.Text.Length < 2)
            {
                MessageBox.Show("Please insert 2 Character for Truck Arrival Code", "WARNING...");
                this.textTACode.Focus();
            }
            if (((this.textTACode.Text != "") && (this.textGatepassCode.Text != "")) && (this.textTACode.Text == this.textGatepassCode.Text))
            {
                MessageBox.Show("Please Use Different Code from Truck Arrival and Gatepass", "WARNING...");
                this.textTACode.Focus();
            }
            if (this.textTACode.Text == WBData.sCoyCode)
            {
                MessageBox.Show("Cannot use the same code with Coy", "WARNING...");
                this.textTACode.Focus();
            }
        }

        private void ThisClose()
        {
            if (MessageBox.Show(" Are you sure to close ?\n\n < If any changes will not be saved. >", "A L E R T", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                base.Close();
            }
        }

        private void translate()
        {
            this.tabPage1.Text = Resource.Setting_001;
            this.label1.Text = Resource.Setting_002;
            this.label2.Text = Resource.Setting_003;
            this.label3.Text = Resource.Setting_004;
            this.label4.Text = Resource.Setting_005;
            this.label5.Text = Resource.Setting_006;
            this.GrpInfo.Text = Resource.Setting_007;
            this.labelBrand.Text = Resource.Setting_008;
            this.label124.Text = Resource.Setting_009;
            this.label125.Text = Resource.Setting_010;
            this.label126.Text = Resource.Setting_011;
            this.tabPage3.Text = Resource.Setting_027;
            this.tabPage5.Text = Resource.Setting_028;
            this.label18.Text = Resource.Setting_029;
            this.label19.Text = Resource.Setting_030;
            this.labelApproved.Text = Resource.Setting_031;
            this.radioAuto0.Text = Resource.Setting_033;
            this.radioAuto1.Text = Resource.Setting_034;
            this.label78.Text = Resource.Setting_038;
            this.radioReportIN.Text = Resource.Setting_039;
            this.radioReportOUT.Text = Resource.Setting_040;
            this.tabPage6.Text = Resource.Setting_044;
            this.checkEmailAllow.Text = Resource.Setting_045;
            this.label25.Text = Resource.Setting_047;
            this.label85.Text = Resource.Setting_048;
            this.label86.Text = Resource.Setting_049;
            this.labelPort.Text = Resource.Setting_050;
            this.cbSSL.Text = Resource.Setting_051;
            this.label42.Text = Resource.Setting_052;
            this.label43.Text = Resource.Setting_053;
            this.label44.Text = Resource.Setting_054;
            this.label45.Text = Resource.Setting_055;
            this.label46.Text = Resource.Setting_056;
            this.tabPage7.Text = Resource.Setting_060;
            this.checkISCC.Text = Resource.Setting_062;
            this.label81.Text = Resource.Setting_063;
            this.label117.Text = Resource.Setting_064;
            this.groupBoxGHG.Text = Resource.Setting_065;
            this.labelGHG1.Text = Resource.Setting_066;
            this.label82.Text = Resource.Setting_067;
            this.label83.Text = Resource.Setting_068;
            this.label49.Text = Resource.Setting_053;
            this.label48.Text = Resource.Setting_054;
            this.label47.Text = Resource.Setting_055;
            this.tabPage4.Text = this.sapIDSYS + Resource.Setting_069;
            this.label54.Text = this.sapIDSYS + Resource.Setting_070;
            this.label55.Text = this.sapIDSYS + Resource.Setting_071;
            this.label56.Text = this.sapIDSYS + Resource.Setting_072;
            this.button5.Text = Resource.Setting_073;
            this.label58.Text = this.sapIDSYS + Resource.Setting_074;
            this.label24.Text = this.sapIDSYS + Resource.Setting_075;
            this.label59.Text = Resource.Setting_076;
            this.label60.Text = Resource.Setting_077;
            this.label61.Text = Resource.Setting_078;
            this.label62.Text = Resource.Setting_079;
            this.label63.Text = Resource.Setting_080;
            this.label64.Text = Resource.Setting_081;
            this.label65.Text = Resource.Setting_082;
            this.label66.Text = Resource.Setting_083;
            this.label67.Text = Resource.Setting_084;
            this.label76.Text = Resource.Setting_085;
            this.label68.Text = Resource.Setting_086;
            this.label75.Text = Resource.Setting_087;
            this.label73.Text = Resource.Setting_088;
            this.label72.Text = Resource.Setting_089;
            this.label71.Text = Resource.Setting_090;
            this.label70.Text = Resource.Setting_091;
            this.label23.Text = Resource.Setting_092 + this.sapIDSYS;
            this.label92.Text = Resource.Setting_093;
            this.radioZWBNo.Text = Resource.Setting_094;
            this.radioZWBYes.Text = Resource.Setting_095;
            this.label96.Text = Resource.Setting_097 + this.sapIDSYS;
            this.label90.Text = Resource.Setting_098;
            this.label17.Text = Resource.Main_013;
            this.label89.Text = Resource.Setting_100;
            this.label107.Text = Resource.Setting_112;
            this.label26.Text = Resource.Setting_113;
            this.radioTypeRefinery.Text = Resource.Setting_114;
            this.radioTypePOM.Text = Resource.Setting_115;
            this.label129.Text = Resource.Setting_116;
            this.radioTrans3.Text = Resource.Setting_117;
            this.radioTrans2.Text = Resource.Setting_118;
            this.radioTrans1.Text = Resource.Setting_119;
            this.labelCode.Text = Resource.Setting_120;
            this.labelTACode.Text = Resource.Setting_121;
            this.labelGatepassCode.Text = Resource.Setting_122;
            this.label118.Text = Resource.Setting_123;
            this.radioIndonesia.Text = Resource.Setting_124;
            this.radioAfrica.Text = Resource.Setting_125;
            this.labelLoadUnload.Text = Resource.Setting_128;
            this.label29.Text = Resource.Setting_129;
            this.label27.Text = Resource.Setting_130;
            this.label130.Text = Resource.Setting_131;
            this.checkDirect.Text = Resource.Setting_132;
            this.button8.Text = Resource.Setting_133;
            this.label109.Text = Resource.Setting_134;
            this.checkRef6.Text = Resource.Setting_135;
            this.label50.Text = Resource.Setting_136;
            this.checkTare.Text = Resource.Setting_138;
            this.checkStorage.Text = Resource.Setting_141;
            this.checkWBNo.Text = Resource.Setting_143;
            this.checkTrailer.Text = Resource.Setting_145;
            this.checkContainer.Text = Resource.Setting_146;
            this.checkNonContract.Text = Resource.Setting_147;
            this.buttonTest.Text = Resource.Setting_154;
            this.button2.Text = Resource.Setting_155;
            this.button3.Text = Resource.Menu_Close;
        }
    }
}

