﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic;
    using SAP.Middleware.Connector;
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormContractEntryAfrica : Form
    {
        public WBTable zTable;
        public string pMode;
        public string spMode;
        public string qst = "";
        public int nCurrRow;
        public int SO_ITEM_COUNT;
        public bool saved = false;
        public bool ReplaceAll = false;
        public bool HasBeenClosed = false;
        public DataGridView dataGridView1;
        public string OldCode = "";
        public string changeReason = "";
        public string logKey = "";
        private WBTable tmpContract = new WBTable();
        private DataRow contractBefore;
        private DataRow row_comm;
        public WBTable tblTransType = new WBTable();
        public WBTable tblComm = new WBTable();
        public WBTable tblRelation = new WBTable();
        public WBTable tblEstate = new WBTable();
        public WBTable tblTransporter = new WBTable();
        public WBTable tblRefCode = new WBTable();
        public WBTable tblLocation = new WBTable();
        public WBTable tbl_batch = new WBTable();
        public WBTable tblContract_log = new WBTable();
        public WBTable tblIncoterm = new WBTable();
        public WBTable tblUploadType = new WBTable();
        public WBTable tblDeductedBy = new WBTable();
        public string needAdoptNego = "N";
        public string close = "N";
        public string adopt = "N";
        private IRfcStructure ISReturn;
        private IRfcTable ISReturnCTR;
        private IRfcTable ISReturnVDR;
        private IRfcTable ISReturnCUST;
        private IRfcTable ISReturnINCO1;
        private IRfcTable ISReturnINCO2;
        private IRfcTable ISReturnTRP;
        private IRfcTable ISReturnCOMM;
        private string oldDo = "";
        private string oldComm = "";
        private string oldrelation = "";
        private string oldTransporter = "";
        private string oldEstate = "";
        private string oldTransType = "";
        private string sapComm = "";
        private string sapVend = "";
        private string sapTranspt = "";
        private string sapEstate = "";
        private string screen = "";
        private string GRPO_Cust = "";
        private string IO = "";
        private string trade = "T";
        private string Std;
        private string Bulk;
        private bool IsSugar = false;
        private IContainer components = null;
        private Label label1;
        public TextBox textDO;
        private Label label2;
        private DateTimePicker dateTimeDO;
        private DateTimePicker dateTimeContract;
        private Label label3;
        private TextBox textContract;
        private Label label4;
        private Label label7;
        private Label label8;
        private Label relationName;
        private Label CommodityName;
        private Label label9;
        private Label label10;
        private CheckBox checkQuantity;
        private TabControl tabControl1;
        private TabPage tabPageRef;
        private TabPage tabPagePOM;
        private Label label15;
        private TextBox textVessel;
        private Label label14;
        private Label label12;
        private Label label23;
        private TextBox textNEGO;
        private Label label25;
        private TextBox textRemark;
        private Button buttonSave;
        private Button buttonCancel;
        private Label label39;
        private TextBox textScout2;
        private Label label40;
        private TextBox textScout1;
        private Label label37;
        private TextBox textLoose2;
        private Label label38;
        private TextBox textLoose1;
        private Label label35;
        private TextBox textSmall2;
        private Label label36;
        private TextBox textSmall1;
        private Label label33;
        private TextBox textMid2;
        private Label label34;
        private TextBox textMid1;
        private Label label32;
        private TextBox textLarge2;
        private Label label31;
        private TextBox textLarge1;
        private Label label45;
        private CheckBox checkISCC;
        private Label labelEstateADM;
        private Button btnAdopt;
        private Label labelPO;
        private TextBox textPO;
        private Label label46;
        private TextBox textTransporter;
        private TextBox textType;
        private Button buttonType;
        private TextBox textCommodity;
        private Button button1;
        private Button button2;
        private Button button3;
        private Label TransporterName;
        private Label labelTransTypeName;
        private CheckBox checkBerikat;
        private GroupBox groupBoxConversion;
        public Label labelConvValue;
        public TextBox textConvValue;
        public Label label50;
        public TextBox textConvUnit;
        public Label label51;
        private Label label49;
        private Label labelUploadType;
        private TextBox textTolerance;
        private Label label53;
        private Button btnEstate;
        private TextBox textQuantity;
        private Label labelSTO1slash;
        private TextBox textSTO1Item;
        private GroupBox groupBox4;
        private RadioButton radioRamp;
        private RadioButton radioKebAgen;
        private RadioButton radioAgen;
        private RadioButton radioOthers;
        private RadioButton radioOtherGroup;
        private RadioButton radioGroupEstate;
        private DateTimePicker dateDO_period;
        private CheckBox checkPeriod;
        private TabPage tabPage3;
        private TextBox textSTO1;
        private Label label13;
        private CheckBox checkAgen;
        private Label labelRefDes;
        private Label labelWBRef;
        private ComboBox comboRefCode;
        private ComboBox comboBillOfLading;
        private Label labelBillOfLading;
        private Label label43;
        private Label labelFactoryOpening;
        private Label labelKG3rd;
        private Label label3rdOpening;
        private TextBox textOpnEntryEstate;
        private TextBox textOpnEntryFactory;
        private GroupBox groupBoxFruit;
        private GroupBox groupBoxEntry;
        private TextBox textEstate;
        private CheckBox checkTolling;
        private Button buttonAdopt2;
        private ToolTip toolTip1;
        private TabPage tabPageOpening;
        private TextBox textPO1;
        private RadioButton radioFactoryQty;
        private RadioButton radioOtherQty;
        private GroupBox groupBoxDeducted;
        private Label label44;
        private Label label42;
        private Label label19;
        private Label labelQualityInfo;
        private RichTextBox textQualityInfo;
        private TextBox textToken;
        private Label label47;
        private TextBox textBox2;
        private Label label55;
        private Label label56;
        private TextBox textOSQty;
        private Button buttonOSQty;
        private ComboBox comboGIBatch;
        private Label labelGIBatch;
        private Label labelGRBatch;
        private ComboBox comboGRBatch;
        private Label labelIncotermCode;
        private ComboBox comboIncoterm;
        private Label labelPOSlash;
        private TextBox textPOItem;
        private Label labelPO1Slash;
        private TextBox textPO1Item;
        public TextBox textVend;
        private TextBox textUploadType;
        private ComboBox comboUploadType;
        private TextBox textSTOItem;
        private Label labelSTOSlash;
        private TextBox textSTO;
        private Label labelSTO;
        private Label labelPO1;
        private Label label30;
        private Label label29;
        private Label label28;
        private Label label27;
        private Label label26;
        private ComboBox comboBagGIBatch;
        private Label labelBagGIBatch;
        private Label labelBagGRBatch;
        private ComboBox comboBagGRBatch;

        public FormContractEntryAfrica()
        {
            this.InitializeComponent();
        }

        private void actTrade()
        {
            this.textPO.ReadOnly = (WBSetting.zwb == "Y") && ((this.trade == "T") && (this.labelPO.Text != "SO"));
        }

        private void adoptDataAfrica()
        {
            try
            {
                WBSetting.OpenSetting();
                if (WBSAP.connect())
                {
                    DateTime now;
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_WB_CONTRACT");
                    string[] strArray = new string[3];
                    IRfcTable table = WBSAP.rfcFunction.GetTable("CONTRACT");
                    table.Append();
                    table.SetValue("TYPE", (this.IO == "I") ? "P" : "S");
                    if (WBSetting.locType == "0")
                    {
                        table.SetValue("DOCUMENT", this.textPO.Text.Trim());
                        table.SetValue("ITEM", this.textPOItem.Text.Trim());
                    }
                    else
                    {
                        table.SetValue("DOCUMENT", this.textPO1.Text.Trim());
                        table.SetValue("ITEM", this.textPO1Item.Text.Trim());
                    }
                    WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                    this.ISReturnCTR = WBSAP.rfcFunction.GetTable("CTRDATA");
                    this.ISReturnVDR = WBSAP.rfcFunction.GetTable("CTRVDR");
                    this.ISReturnCUST = WBSAP.rfcFunction.GetTable("CTRCUST");
                    this.ISReturnCOMM = WBSAP.rfcFunction.GetTable("CTRCOMM");
                    this.ISReturnINCO1 = WBSAP.rfcFunction.GetTable("CTRINCO1");
                    this.ISReturnINCO2 = WBSAP.rfcFunction.GetTable("CTRINCO2");
                    this.ISReturnTRP = WBSAP.rfcFunction.GetTable("CTRTRP");
                    this.textVend.Text = this.ISReturnCTR[0].GetString("VENCUST");
                    this.comboIncoterm.Text = this.ISReturnCTR[0].GetString("INCO1");
                    this.textEstate.Text = this.ISReturnCTR[0].GetString("INCO2");
                    this.textQuantity.Text = this.ISReturnCTR[0].GetString("QTY");
                    this.textTolerance.Text = this.ISReturnCTR[0].GetString("UEBTO");
                    try
                    {
                        now = Convert.ToDateTime(this.ISReturnCTR[0].GetString("DCDAT"));
                    }
                    catch
                    {
                        now = DateTime.Now;
                    }
                    this.dateTimeDO.Value = now;
                    this.textCommodity.Text = this.ISReturnCTR[0].GetString("MATNR");
                    if (this.ISReturnINCO1.RowCount > 0)
                    {
                        this.ChkInco(false, true);
                    }
                    if (this.ISReturnINCO2.RowCount > 0)
                    {
                        this.ChkEstate(0);
                    }
                    if (this.ISReturnCOMM.RowCount > 0)
                    {
                        this.ChkComm(0);
                    }
                    if ((this.ISReturnVDR.RowCount > 0) || (this.ISReturnCUST.RowCount > 0))
                    {
                        this.ChkVend(0);
                    }
                    if (this.ISReturnTRP.RowCount > 0)
                    {
                        this.ChkTransporter(0);
                    }
                    MessageBox.Show(Resource.Mes_086, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "E R R O R <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show(Resource.Title_003 + " " + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void bacaNego()
        {
            try
            {
                WBSetting.OpenSetting();
                if (WBSAP.connect())
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZWB_GET_NEGO");
                    WBSAP.rfcFunction.SetValue("NEGNR", this.textNEGO.Text);
                    WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                    IRfcStructure structure = WBSAP.rfcFunction.GetStructure("ZPOM_NEGO_H");
                    string str = structure.GetString("LIFNR");
                    string str2 = structure.GetString("MATNR");
                    string str3 = structure.GetString("NEGMG");
                    string str4 = structure.GetString("INCO1");
                    string str5 = structure.GetString("agen");
                    string str6 = structure.GetString("DTYPE");
                    string str7 = structure.GetString("FIXMG");
                    this.checkQuantity.Enabled = true;
                    this.textQuantity.Enabled = true;
                    if ((str6 == "K") && (str7 == "X"))
                    {
                        this.checkQuantity.Enabled = false;
                        this.textQuantity.Enabled = false;
                    }
                    this.textQuantity.Text = str3;
                    this.textVend.Text = this.getData("wb_relation", "sap_code", str, "relation_code");
                    this.ChkVend(0);
                    this.sapVend = str;
                    this.sapComm = str2;
                    this.textCommodity.Text = this.getData("wb_commodity", "material", str2, "comm_code");
                    this.ChkComm(0);
                    this.dateTimeDO.Value = Convert.ToDateTime(structure.GetString("NEGDT"));
                    this.textTolerance.Text = "3";
                    this.checkAgen.Checked = str5 == "X";
                    this.checkQuantity.Checked = str7 == "X";
                    this.comboIncoterm.Text = str4;
                    this.textVend.Enabled = this.textCommodity.Enabled = false;
                    MessageBox.Show(Resource.Mes_087, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.needAdoptNego = "N";
                    this.textQuantity.ReadOnly = true;
                    this.textTolerance.ReadOnly = true;
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show(Resource.Title_003 + " " + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void bacaPOSO()
        {
            bool flag = false;
            try
            {
                WBSetting.OpenSetting();
                if (WBSAP.connect())
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZWB_GET_POSO");
                    IRfcStructure structure = WBSAP.rfcFunction.GetStructure("DOCNO");
                    if (WBSetting.locType == "0")
                    {
                        structure.SetValue(0, this.textSTO.Text);
                        structure.SetValue(1, "");
                        structure.SetValue(3, this.textNEGO.Text);
                        if (this.IO == "I")
                        {
                            structure.SetValue(2, this.textPO.Text);
                            structure.SetValue(4, "");
                        }
                        else if (this.IO == "O")
                        {
                            structure.SetValue(2, "");
                            structure.SetValue(4, this.textPO.Text);
                        }
                        structure.SetValue(5, this.textPOItem.Text);
                        structure.SetValue(6, this.textSTOItem.Text);
                    }
                    else
                    {
                        structure.SetValue(0, this.textSTO1.Text);
                        structure.SetValue(1, "");
                        structure.SetValue(3, this.textNEGO.Text);
                        if (this.IO == "I")
                        {
                            structure.SetValue(2, this.textPO1.Text);
                            structure.SetValue(4, "");
                        }
                        else if (this.IO == "O")
                        {
                            structure.SetValue(2, "");
                            structure.SetValue(4, this.textPO1.Text);
                        }
                        structure.SetValue(5, this.textPO1Item.Text);
                        structure.SetValue(6, this.textSTO1Item.Text);
                    }
                    WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                    IRfcStructure structure2 = WBSAP.rfcFunction.GetStructure("DOC_DETAIL");
                    string str = "";
                    string str2 = "";
                    string str3 = "";
                    string str4 = "";
                    string str5 = "";
                    string str6 = "";
                    string str7 = "";
                    string str8 = "";
                    string str9 = "";
                    string incoterm = "";
                    string str11 = "";
                    string str12 = "";
                    string str13 = "";
                    string str14 = "";
                    if (structure2.GetString("NOT_EXIST") == "X")
                    {
                        MessageBox.Show("Adopt Failed. No Data From SAP");
                    }
                    else
                    {
                        str = structure2.GetString("TYPE");
                        str2 = structure2.GetString("DOCNO");
                        str4 = structure2.GetString("MATNR");
                        str3 = structure2.GetString("relation");
                        str5 = structure2.GetString("TRANSPORTER");
                        str6 = structure2.GetString("QTY");
                        str7 = structure2.GetString("UEBTO");
                        str8 = structure2.GetString("UEBTK");
                        str9 = structure2.GetString("UNTTO");
                        str11 = structure2.GetString("KB");
                        str12 = structure2.GetString("AGENT");
                        incoterm = structure2.GetString("INCO1").ToUpper();
                        str13 = structure2.GetString("MILL").ToUpper();
                        try
                        {
                            str14 = structure2.GetString("POSNR").ToUpper();
                        }
                        catch
                        {
                            str14 = "";
                        }
                        this.textQuantity.Text = str6;
                        this.checkBerikat.Checked = str11 == "X";
                        this.checkAgen.Checked = str12 == "X";
                        this.textTolerance.Text = str7;
                        this.checkQuantity.Checked = str8 != "X";
                        this.comboIncoterm.Text = incoterm;
                        this.cekinco(incoterm, this.textType.Text);
                        this.qst = structure2.GetString("ZZISCC");
                        this.SO_ITEM_COUNT = structure2.GetInt("SO_ITEM_COUNT");
                        if (this.textPOItem.Text.Trim() == "")
                        {
                            this.textPOItem.Text = str14;
                        }
                        if (str4 != "")
                        {
                            this.textCommodity.Text = this.getData("wb_commodity", "material", str4, "comm_code");
                            flag = this.getData("wb_commodity", "comm_code", this.textCommodity.Text.Trim(), "Trade") != "N";
                            this.ChkComm(0);
                            this.textVend.Text = this.getData("wb_relation", "sap_code", str3, "relation_code");
                            this.ChkVend(0);
                            if ((this.IO != "O") || (((this.comboIncoterm.Text != "LCO") && (this.comboIncoterm.Text != "FOB")) && (this.comboIncoterm.Text != "CIF")))
                            {
                                this.textTransporter.Text = this.getData("wb_transporter", "sap_code", str5, "transporter_code");
                                this.ChkTransporter(0);
                            }
                            else if (this.textTransporter.Text.Trim() == "")
                            {
                                this.textTransporter.Text = this.getData("wb_transporter", "sap_code", str5, "transporter_code");
                                this.ChkTransporter(0);
                            }
                        }
                        this.adopt = "Y";
                        if ((str4 != "") && (str4.Substring(0, 2) == "7."))
                        {
                            string str15 = this.getData("wb_commodity", "comm_code", this.textCommodity.Text.Trim(), "Gross_Weight");
                            string str16 = this.getData("wb_commodity", "comm_code", this.textCommodity.Text.Trim(), "Netto_Weight");
                            string str17 = this.getData("wb_commodity", "comm_code", this.textCommodity.Text.Trim(), "Tolerance");
                            if (((str15 == "0") || ((str15 == "") || ((str16 == "") || ((str16 == "0") || (str17 == ""))))) || (str17 == ""))
                            {
                                MessageBox.Show("\nCONVERTION WEIGHT \n" + (((this.textCommodity.Text.Trim() + " : ") + ("\n Gross Weight is " + str15) + ("\n Netto Weight is " + str16)) + ("\n Tolerance is " + str17) + "\n\n This Commodity do not have maintain Gross, Netto Weight & Tolerance"), "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.textCommodity.Text = "";
                                this.CommodityName.Text = "";
                                this.adopt = "N";
                            }
                        }
                        if (this.adopt == "Y")
                        {
                            MessageBox.Show("Adopt Finish", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                        if (((this.labelPO.Text == "SO") && (this.SO_ITEM_COUNT < 2)) && (this.textPO.Text != ""))
                        {
                            this.textDO.Text = this.textPO.Text;
                            this.textDO.ReadOnly = true;
                            this.textPO.ReadOnly = true;
                        }
                    }
                    if (this.SO_ITEM_COUNT <= 1)
                    {
                        this.textQuantity.ReadOnly = true;
                        this.textTolerance.ReadOnly = true;
                        this.checkQuantity.Enabled = false;
                    }
                    else
                    {
                        this.textQuantity.ReadOnly = false;
                        this.textTolerance.ReadOnly = false;
                        this.checkQuantity.Enabled = true;
                        this.checkQuantity.Checked = true;
                        this.textQuantity.Text = "0";
                        this.textTolerance.Text = "0";
                    }
                    this.comboIncoterm.Enabled = false;
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show("Error " + exception4.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void btnAdopt_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.adoptDataAfrica();
            Cursor.Current = Cursors.Default;
        }

        private void btnAdopt1_Click(object sender, EventArgs e)
        {
            if ((this.textNEGO.Text.Length > 0) && (this.textSTO1.Text.Length <= 0))
            {
                this.bacaNego();
            }
            else if ((this.textPO1.Text.Length > 0) || (this.textSTO1.Text.Length > 0))
            {
                this.adoptDataAfrica();
            }
        }

        private void btnEstate_Click(object sender, EventArgs e)
        {
            FormEstate estate = new FormEstate {
                pMode = "CHOOSE",
                pFind = this.textEstate.Text
            };
            estate.ShowDialog();
            if (estate.ReturnRow != null)
            {
                this.textEstate.Text = estate.ReturnRow["Estate_Code"].ToString();
                this.labelEstateADM.Text = estate.ReturnRow["Estate_Name"].ToString();
            }
            estate.Dispose();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE",
                pFind = this.textCommodity.Text.Trim()
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.CommodityName.Text = commodity.ReturnRow["comm_name"].ToString();
                this.trade = commodity.ReturnRow["Trade"].ToString();
            }
            commodity.Dispose();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            FormTransType type = new FormTransType {
                pMode = "CHOOSE"
            };
            type.ShowDialog();
            if (type.ReturnRow != null)
            {
                this.textType.Text = type.ReturnRow["Transaction_Code"].ToString();
                this.labelTransTypeName.Text = type.ReturnRow["Transaction_Name"].ToString();
                this.IO = type.ReturnRow["IO"].ToString();
                if (this.IO == "I")
                {
                    this.labelPO.Text = "PO";
                    this.labelPO1.Text = "PO";
                }
                else if (this.IO == "O")
                {
                    this.labelPO.Text = "SO";
                    this.labelPO1.Text = "SO";
                }
            }
            this.tblTransType.ReOpen();
            type.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE",
                pFind = this.textVend.Text.Trim()
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textVend.Text = vendor.ReturnRow["relation_code"].ToString();
                this.relationName.Text = vendor.ReturnRow["relation_name"].ToString();
                this.checkISCC.Checked = vendor.ReturnRow["ISCC"].ToString() == "Y";
                this.checkISCC.Enabled = vendor.ReturnRow["ISCC"].ToString() == "Y";
            }
            vendor.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE",
                pFind = this.textTransporter.Text.Trim()
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransporter.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.TransporterName.Text = transporter.ReturnRow["Transporter_Name"].ToString();
                this.textTransporter.Focus();
            }
            transporter.Dispose();
        }

        private void buttonOSQty_Click(object sender, EventArgs e)
        {
            if (this.textDO.Text.Trim() != "")
            {
                this.textOSQty.Text = Convert.ToDouble($"{Program.checkOS(this.textDO.Text, "", "", "N"):N0}").ToString();
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            this.f_Save();
        }

        private void cekinco(string incoterm, string transtype)
        {
            if (incoterm == "")
            {
                this.radioOtherQty.Checked = false;
                this.radioFactoryQty.Checked = false;
            }
            if ((WBSetting.locType != "") && (incoterm != ""))
            {
                string[] aField = new string[] { "Incoterm_code" };
                string[] aFind = new string[] { incoterm };
                this.tblIncoterm.DR = this.tblIncoterm.GetData(aField, aFind);
                if (this.tblIncoterm.DR == null)
                {
                    this.tblIncoterm.DR = this.tblIncoterm.DT.NewRow();
                    this.tblIncoterm.DR["Coy"] = WBData.sCoyCode;
                    this.tblIncoterm.DR["Location_code"] = WBData.sLocCode;
                    this.tblIncoterm.DR["incoterm_code"] = incoterm;
                    this.tblIncoterm.DR["incoterm_desc"] = incoterm;
                    this.tblIncoterm.DT.Rows.Add(this.tblIncoterm.DR);
                    this.tblIncoterm.Save();
                    this.tblIncoterm.ReOpen();
                    this.labelIncotermCode.Text = incoterm;
                    this.radioFactoryQty.Checked = false;
                    this.radioOtherQty.Checked = false;
                }
                else
                {
                    this.labelIncotermCode.Text = this.tblIncoterm.DR["Incoterm_desc"].ToString();
                    string[] textArray3 = new string[] { "transaction_code", "Incoterm_code" };
                    string[] textArray4 = new string[] { transtype, incoterm };
                    this.tblDeductedBy.DR = this.tblDeductedBy.GetData(textArray3, textArray4);
                    if (this.tblDeductedBy.DR != null)
                    {
                        this.radioOtherQty.Checked = this.tblDeductedBy.DR["DeductedBy"].ToString() == "1";
                        this.radioFactoryQty.Checked = this.tblDeductedBy.DR["DeductedBy"].ToString() == "0";
                    }
                    else
                    {
                        this.radioOtherQty.Checked = false;
                        this.radioFactoryQty.Checked = false;
                    }
                }
                this.comboIncoterm.Text = incoterm;
            }
        }

        private void checkPeriod_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkPeriod.Checked)
            {
                this.dateDO_period.Visible = true;
                this.dateDO_period.Enabled = true;
            }
            else
            {
                this.dateDO_period.Visible = false;
                this.dateDO_period.Enabled = false;
            }
        }

        private bool ChkComm(int err)
        {
            bool flag3;
            string sqltext = "select * from wb_commodity where " + WBData.CompanyLocation("");
            this.tblComm.OpenTable("wb_commodity", sqltext, WBData.conn);
            string[] aField = new string[] { "Comm_Code" };
            string[] aFind = new string[] { this.textCommodity.Text.Trim() };
            this.tblComm.DR = this.tblComm.GetData(aField, aFind);
            if (ReferenceEquals(this.tblComm.DR, null))
            {
                if (err == 1)
                {
                    MessageBox.Show(Resource.Mes_101, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.CommodityName.Text = "";
                flag3 = false;
            }
            else
            {
                this.CommodityName.Text = this.tblComm.DR["Comm_Name"].ToString();
                this.textConvUnit.Text = this.tblComm.DR["ConvertionUnit"].ToString();
                this.textConvValue.Text = this.tblComm.DR["Convertion"].ToString();
                this.trade = this.tblComm.DR["Trade"].ToString();
                this.IsSugar = this.tblComm.DR["Type"].ToString().Trim() == "G";
                this.Bulk = this.tblComm.DR["BulkPack"].ToString();
                this.Std = this.tblComm.DR["Type"].ToString();
                this.actTrade();
                this.row_comm = this.tblComm.DT.NewRow();
                this.row_comm.ItemArray = this.tblComm.DR.ItemArray;
                flag3 = true;
            }
            return flag3;
        }

        private bool ChkEstate(int err)
        {
            bool flag3;
            string sqltext = "";
            sqltext = "select * from wb_Estate where " + WBData.CompanyLocation("");
            this.tblEstate.OpenTable("wb_Estate", sqltext, WBData.conn);
            string[] aField = new string[] { "Estate_Code" };
            string[] aFind = new string[] { this.textEstate.Text.Trim() };
            this.tblEstate.DR = this.tblEstate.GetData(aField, aFind);
            if (!ReferenceEquals(this.tblEstate.DR, null))
            {
                this.labelEstateADM.Text = this.tblEstate.DR["Estate_Name"].ToString();
                flag3 = true;
            }
            else
            {
                if (err == 1)
                {
                    MessageBox.Show(Resource.Mes_105, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.labelEstateADM.Text = "";
                flag3 = false;
            }
            return flag3;
        }

        private bool ChkInco(bool showErr, bool upd)
        {
            bool flag4;
            string sqltext = "select * from wb_Incoterm where " + WBData.CompanyLocation(" order by incoterm_Code desc ");
            this.tblIncoterm.OpenTable("wb_Incoterm", sqltext, WBData.conn);
            this.tblIncoterm.DR = this.tblIncoterm.DT.Rows[0];
            string[] aField = new string[] { "Incoterm_Code" };
            string[] aFind = new string[] { this.comboIncoterm.Text.Trim() };
            this.tblIncoterm.DR = this.tblIncoterm.GetData(aField, aFind);
            if (!ReferenceEquals(this.tblIncoterm.DR, null))
            {
                this.comboIncoterm.Text = this.tblIncoterm.DR["incoterm_Code"].ToString();
                this.labelIncotermCode.Text = this.tblIncoterm.DR["incoterm_Desc"].ToString();
                flag4 = true;
            }
            else
            {
                if (showErr)
                {
                    MessageBox.Show(Resource.Mes_107, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.labelIncotermCode.Text = "";
                if (upd && (this.comboIncoterm.Text.Trim() != ""))
                {
                    this.tblIncoterm.DR = this.tblIncoterm.DT.NewRow();
                    this.tblIncoterm.DR["Coy"] = WBData.sCoyCode;
                    this.tblIncoterm.DR["Location_Code"] = WBData.sLocCode;
                    this.tblIncoterm.DR["incoterm_code"] = this.ISReturnINCO1[0].GetString("CODE").ToString();
                    this.tblIncoterm.DR["incoterm_desc"] = this.ISReturnINCO1[0].GetString("NAME").ToString();
                    this.tblIncoterm.DR["CREATE_BY"] = "SYSTEM";
                    this.tblIncoterm.DR["CREATE_DATE"] = DateTime.Now.ToShortDateString();
                    this.tblIncoterm.DT.Rows.Add(this.tblIncoterm.DR);
                    this.tblIncoterm.Save();
                    this.tblIncoterm.ReOpen();
                    this.ChkInco(false, false);
                }
                flag4 = false;
            }
            return flag4;
        }

        private bool ChkTransporter(int err)
        {
            bool flag3;
            string sqltext = "select * from wb_transporter where " + WBData.CompanyLocation("");
            this.tblTransporter.OpenTable("wb_transporter", sqltext, WBData.conn);
            string[] aField = new string[] { "transporter_Code" };
            string[] aFind = new string[] { this.textTransporter.Text.Trim() };
            this.tblTransporter.DR = this.tblTransporter.GetData(aField, aFind);
            if (!ReferenceEquals(this.tblTransporter.DR, null))
            {
                this.TransporterName.Text = this.tblTransporter.DR["Transporter_Name"].ToString();
                flag3 = true;
            }
            else
            {
                if (err == 1)
                {
                    MessageBox.Show(Resource.Mes_109, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.TransporterName.Text = "";
                flag3 = false;
            }
            return flag3;
        }

        private bool ChkVend(int err)
        {
            bool flag3;
            string sqltext = "select * from wb_relation where " + WBData.CompanyLocation("");
            this.tblRelation.OpenTable("wb_relation", sqltext, WBData.conn);
            string[] aField = new string[] { "Relation_Code" };
            string[] aFind = new string[] { this.textVend.Text.Trim() };
            this.tblRelation.DR = this.tblRelation.GetData(aField, aFind);
            if (ReferenceEquals(this.tblRelation.DR, null))
            {
                if ((err == 1) || (err == 2))
                {
                    MessageBox.Show(Resource.Mes_108, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.relationName.Text = "";
                flag3 = false;
            }
            else if (err == 2)
            {
                flag3 = true;
            }
            else
            {
                this.relationName.Text = this.tblRelation.DR["Relation_Name"].ToString();
                this.checkISCC.Checked = this.tblRelation.DR["ISCC"].ToString() == "Y";
                this.checkISCC.Enabled = this.tblRelation.DR["ISCC"].ToString() == "Y";
                flag3 = true;
            }
            return flag3;
        }

        private void comboBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void comboBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void comboIncoterm_Leave(object sender, EventArgs e)
        {
        }

        private void comboIncoterm_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] aField = new string[] { "Incoterm_Code" };
            string[] aFind = new string[] { this.comboIncoterm.Text };
            this.tblIncoterm.DR = this.tblIncoterm.GetData(aField, aFind);
            if (this.tblIncoterm.DR == null)
            {
                this.labelIncotermCode.Text = "";
                this.radioFactoryQty.Checked = true;
            }
            else
            {
                this.labelIncotermCode.Text = this.tblIncoterm.DR["Incoterm_Desc"].ToString();
                this.radioFactoryQty.Checked = this.tblIncoterm.DR["DeductedBy"].ToString() == "0";
                this.radioOtherQty.Checked = this.tblIncoterm.DR["DeductedBy"].ToString() == "1";
            }
        }

        private void comboRefCode_TextChanged(object sender, EventArgs e)
        {
            if (this.comboRefCode.Text.Trim() != "")
            {
                string[] aField = new string[] { "refCode" };
                string[] aFind = new string[] { this.comboRefCode.Text };
                this.tblRefCode.DR = this.tblRefCode.GetData(aField, aFind);
                this.labelRefDes.Text = this.tblRefCode.DR["Description"].ToString();
            }
        }

        private void CompareAll(string commCode)
        {
            int count = this.dataGridView1.Rows.Count;
            try
            {
                WBSetting.OpenSetting();
                if (WBSAP.connect())
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_EXTRACT_COMM");
                    if (commCode != "")
                    {
                        WBSAP.rfcFunction.SetValue("P_COMM", commCode.ToUpper());
                    }
                    WBSAP.sendZWB();
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_COMM");
                    FormCommodityCompare compare = new FormCommodityCompare {
                        rfcTable = WBSAP.rfcTable
                    };
                    compare.Compare();
                    MessageBox.Show(compare.inserted + " " + Resource.Mes_032);
                    compare.Dispose();
                    this.Refresh();
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "E R R O R <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show(Resource.Title_003 + " " + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void ContractToLog(WBTable tLog, DataRow aRow)
        {
            tLog.DR = tLog.DT.NewRow();
            using (IEnumerator enumerator = tLog.DT.Columns.GetEnumerator())
            {
                DataColumn current;
                goto TR_0010;
            TR_000A:
                if (current.ColumnName.ToUpper() == "log_Date".ToUpper())
                {
                    tLog.DR[current.ColumnName] = DateTime.Now.ToString("dd/MM/yyyy");
                }
                else if (current.ColumnName.ToUpper() == "log_time".ToUpper())
                {
                    tLog.DR[current.ColumnName] = DateTime.Now.ToString("HH:mm:ss");
                }
                else if (current.ColumnName.ToUpper() == "sUniq".ToUpper())
                {
                    tLog.DR[current.ColumnName] = aRow["uniq"];
                }
            TR_0010:
                while (true)
                {
                    if (enumerator.MoveNext())
                    {
                        current = (DataColumn) enumerator.Current;
                        if (current.ColumnName.ToUpper() != "UNIQ")
                        {
                            try
                            {
                                tLog.DR[current.ColumnName] = aRow[current.ColumnName];
                            }
                            catch
                            {
                            }
                        }
                    }
                    else
                    {
                        goto TR_0004;
                    }
                    break;
                }
                goto TR_000A;
            }
        TR_0004:
            tLog.DT.Rows.Add(tLog.DR);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public void f_Load()
        {
            this.labelUploadType.Visible = true;
            this.checkBerikat.Visible = false;
            this.labelGRBatch.Visible = true;
            this.labelGIBatch.Visible = true;
            this.comboGRBatch.Visible = true;
            this.comboGIBatch.Visible = true;
            this.labelBagGIBatch.Visible = true;
            this.labelBagGRBatch.Visible = true;
            this.comboBagGRBatch.Visible = true;
            this.comboBagGIBatch.Visible = true;
            this.comboUploadType.Visible = true;
            this.labelWBRef.Visible = true;
            this.comboRefCode.Visible = true;
            this.labelRefDes.Visible = true;
            this.labelBillOfLading.Visible = true;
            this.comboBillOfLading.Visible = true;
            this.checkBerikat.Visible = false;
            this.checkBerikat.Checked = false;
            this.labelQualityInfo.Visible = false;
            this.textQualityInfo.Visible = false;
            if (WBSetting.locType == "1")
            {
                this.tabControl1.TabPages.Remove(this.tabPageRef);
            }
            else if (WBSetting.locType == "0")
            {
                this.tabControl1.TabPages.Remove(this.tabPagePOM);
            }
            if (WBSetting.Field("Multiline").ToString() == "Y")
            {
                this.textPOItem.ReadOnly = true;
            }
            else
            {
                this.textPOItem.Text = WBSetting.Field("Line").ToString();
                this.textPOItem.ReadOnly = false;
            }
            Cursor.Current = Cursors.WaitCursor;
            FormProgress progress = new FormProgress();
            base.KeyPreview = true;
            this.relationName.Text = "";
            this.CommodityName.Text = "";
            this.labelEstateADM.Text = "";
            this.TransporterName.Text = "";
            this.labelRefDes.Text = "";
            this.dateTimeDO.Value = DateTime.Now;
            this.dateTimeContract.Value = DateTime.Now;
            this.initCombo();
            this.checkISCC.Enabled = false;
            this.checkISCC.Checked = false;
            this.InitTable();
            if (this.pMode == "ADD")
            {
                this.dateDO_period.Text = "";
                this.dateDO_period.Enabled = this.checkPeriod.Checked;
                this.radioFactoryQty.Checked = true;
            }
            else
            {
                string[] aField = new string[] { "Transaction_Code" };
                string[] aFind = new string[] { this.zTable.DT.Rows[this.nCurrRow]["Transaction_Code"].ToString().Trim() };
                this.tblTransType.DR = this.tblTransType.GetData(aField, aFind);
                this.textType.Text = this.tblTransType.DR["Transaction_Code"].ToString();
                this.labelTransTypeName.Text = this.tblTransType.DR["Transaction_Name"].ToString();
                this.IO = this.tblTransType.DR["IO"].ToString();
                this.textDO.Text = this.zTable.DT.Rows[this.nCurrRow]["Do_No"].ToString();
                this.OldCode = this.textDO.Text;
                this.dateTimeDO.Text = this.zTable.DT.Rows[this.nCurrRow]["Do_Date"].ToString();
                this.textContract.Text = this.zTable.DT.Rows[this.nCurrRow]["Contract"].ToString();
                this.dateTimeContract.Text = this.zTable.DT.Rows[this.nCurrRow]["Contract_Date"].ToString();
                this.textCommodity.Text = this.zTable.DT.Rows[this.nCurrRow]["Comm_Code"].ToString();
                this.ChkComm(0);
                this.textTransporter.Text = this.zTable.DT.Rows[this.nCurrRow]["Transporter_Code"].ToString();
                this.textQuantity.Text = this.zTable.DT.Rows[this.nCurrRow]["Quantity"].ToString();
                this.textTolerance.Text = this.zTable.DT.Rows[this.nCurrRow]["Tolerance"].ToString();
                if (this.textTolerance.Text.Length <= 0)
                {
                    this.textTolerance.Text = "0";
                }
                this.textEstate.Text = this.zTable.DT.Rows[this.nCurrRow]["Estate1_Code"].ToString();
                this.textVessel.Text = this.zTable.DT.Rows[this.nCurrRow]["Vessel"].ToString();
                this.textVend.Text = this.zTable.DT.Rows[this.nCurrRow]["Relation_code"].ToString();
                this.ChkVend(0);
                if (this.textTransporter.Text.Length > 0)
                {
                    this.ChkTransporter(0);
                }
                this.comboIncoterm.Text = this.zTable.DT.Rows[this.nCurrRow]["Franco"].ToString();
                string[] textArray3 = new string[] { "incoterm_code" };
                string[] textArray4 = new string[] { this.comboIncoterm.Text.Trim() };
                this.tblIncoterm.DR = this.tblIncoterm.GetData(textArray3, textArray4);
                this.labelIncotermCode.Text = (this.tblIncoterm.DR == null) ? "" : this.tblIncoterm.DR["incoterm_Desc"].ToString();
                this.radioOtherQty.Checked = this.zTable.DT.Rows[this.nCurrRow]["DeductedBy"].ToString() == "1";
                this.radioFactoryQty.Checked = this.zTable.DT.Rows[this.nCurrRow]["DeductedBy"].ToString() == "0";
                this.textOpnEntryEstate.Text = this.zTable.DT.Rows[this.nCurrRow]["Entry_Est"].ToString();
                this.textOpnEntryFactory.Text = this.zTable.DT.Rows[this.nCurrRow]["Entry_Fact"].ToString();
                if (this.textOpnEntryEstate.Text == "")
                {
                    this.textOpnEntryEstate.Text = "0";
                }
                if (this.textOpnEntryFactory.Text == "")
                {
                    this.textOpnEntryFactory.Text = "0";
                }
                this.checkQuantity.Checked = this.zTable.DT.Rows[this.nCurrRow]["check_qty"].ToString() == "Y";
                this.checkISCC.Checked = this.zTable.DT.Rows[this.nCurrRow]["ISCC"].ToString() == "Y";
                this.checkISCC.Enabled = this.zTable.DT.Rows[this.nCurrRow]["ISCC"].ToString() == "Y";
                this.textRemark.Text = this.zTable.DT.Rows[this.nCurrRow]["Remark"].ToString();
                string str = this.zTable.DT.Rows[this.nCurrRow]["closed"].ToString().Trim();
                this.dateDO_period.Enabled = false;
                this.dateDO_period.Visible = false;
                this.checkPeriod.Checked = this.zTable.DT.Rows[this.nCurrRow]["CheckPeriod"].ToString() == "Y";
                this.dateDO_period.Text = !this.checkPeriod.Checked ? "" : this.zTable.DT.Rows[this.nCurrRow]["Do_Date2"].ToString();
                this.dateDO_period.Enabled = this.checkPeriod.Checked;
                this.dateDO_period.Visible = this.checkPeriod.Checked;
                this.radioGroupEstate.Checked = this.zTable.DT.Rows[this.nCurrRow]["Group_Type"].ToString() == "0";
                this.radioOtherGroup.Checked = this.zTable.DT.Rows[this.nCurrRow]["Group_Type"].ToString() == "1";
                this.radioOthers.Checked = this.zTable.DT.Rows[this.nCurrRow]["Group_Type"].ToString() == "2";
                this.radioAgen.Checked = this.zTable.DT.Rows[this.nCurrRow]["Group_Type"].ToString() == "3";
                this.radioKebAgen.Checked = this.zTable.DT.Rows[this.nCurrRow]["Group_Type"].ToString() == "4";
                this.radioRamp.Checked = this.zTable.DT.Rows[this.nCurrRow]["Group_Type"].ToString() == "5";
                this.textNEGO.Text = this.zTable.DT.Rows[this.nCurrRow]["NEGO"].ToString();
                this.textLarge1.Text = this.zTable.DT.Rows[this.nCurrRow]["Big_Fruit1"].ToString();
                this.textLarge2.Text = this.zTable.DT.Rows[this.nCurrRow]["Big_Fruit2"].ToString();
                this.textMid1.Text = this.zTable.DT.Rows[this.nCurrRow]["Mid_Fruit1"].ToString();
                this.textMid2.Text = this.zTable.DT.Rows[this.nCurrRow]["Mid_Fruit2"].ToString();
                this.textSmall1.Text = this.zTable.DT.Rows[this.nCurrRow]["Sml_Fruit1"].ToString();
                this.textSmall2.Text = this.zTable.DT.Rows[this.nCurrRow]["Sml_Fruit2"].ToString();
                this.textLoose1.Text = this.zTable.DT.Rows[this.nCurrRow]["Loose1"].ToString();
                this.textLoose2.Text = this.zTable.DT.Rows[this.nCurrRow]["Loose2"].ToString();
                this.textScout1.Text = this.zTable.DT.Rows[this.nCurrRow]["Scout1"].ToString();
                this.textScout2.Text = this.zTable.DT.Rows[this.nCurrRow]["Scout2"].ToString();
                this.checkAgen.Checked = this.zTable.DT.Rows[this.nCurrRow]["Agen"].ToString() == "Y";
                this.checkTolling.Checked = this.zTable.DT.Rows[this.nCurrRow]["Tolling"].ToString() == "Y";
                this.comboGIBatch.Text = this.zTable.DT.Rows[this.nCurrRow]["Batch_GI"].ToString();
                this.comboGRBatch.Text = this.zTable.DT.Rows[this.nCurrRow]["Batch_GR"].ToString();
                this.comboBagGIBatch.Text = this.zTable.DT.Rows[this.nCurrRow]["Bag_Batch_GI"].ToString();
                this.comboBagGRBatch.Text = this.zTable.DT.Rows[this.nCurrRow]["Bag_Batch_GR"].ToString();
                this.comboUploadType.Text = this.zTable.DT.Rows[this.nCurrRow]["Upload_Type"].ToString();
                if (this.IO == "O")
                {
                    if (WBSetting.locType == "0")
                    {
                        this.textPO.Text = this.zTable.DT.Rows[this.nCurrRow]["SO"].ToString();
                        this.textPOItem.Text = this.zTable.DT.Rows[this.nCurrRow]["SO_Item"].ToString();
                    }
                    else if (WBSetting.locType == "1")
                    {
                        this.textPO1.Text = this.zTable.DT.Rows[this.nCurrRow]["SO"].ToString();
                        this.textPO1Item.Text = this.zTable.DT.Rows[this.nCurrRow]["SO_Item"].ToString();
                    }
                }
                else if (this.IO == "I")
                {
                    if (WBSetting.locType == "0")
                    {
                        this.textPO.Text = this.zTable.DT.Rows[this.nCurrRow]["PO"].ToString();
                        this.textPOItem.Text = this.zTable.DT.Rows[this.nCurrRow]["PO_Item"].ToString();
                    }
                    else if (WBSetting.locType == "1")
                    {
                        this.textPO1.Text = this.zTable.DT.Rows[this.nCurrRow]["PO"].ToString();
                        this.textPO1Item.Text = this.zTable.DT.Rows[this.nCurrRow]["PO_Item"].ToString();
                    }
                }
                this.textQualityInfo.Text = this.zTable.DT.Rows[this.nCurrRow]["QualityInfo"].ToString();
                this.checkBerikat.Checked = this.zTable.DT.Rows[this.nCurrRow]["Berikat"].ToString().Trim() == "Y";
                this.checkBerikat.Enabled = true;
                this.textConvValue.Text = this.zTable.DT.Rows[this.nCurrRow]["Convertion"].ToString();
                this.textConvUnit.Text = this.zTable.DT.Rows[this.nCurrRow]["ConvertionUnit"].ToString();
                this.tblTransType.ReOpen();
                string[] textArray5 = new string[] { "Transaction_Code" };
                string[] textArray6 = new string[] { this.textType.Text.Trim() };
                DataRow data = this.tblTransType.GetData(textArray5, textArray6);
                if (data != null)
                {
                    if (data["IO"].ToString() == "I")
                    {
                        this.labelPO.Text = "PO";
                        this.labelPO1.Text = "PO";
                    }
                    else
                    {
                        this.labelPO.Text = "SO";
                        this.labelPO1.Text = "SO";
                    }
                }
                this.oldComm = this.textCommodity.Text;
                this.oldTransporter = this.textTransporter.Text;
                this.oldTransType = this.textType.Text;
                this.oldrelation = this.textVend.Text;
                this.oldDo = this.textDO.Text;
                this.oldEstate = this.textEstate.Text;
            }
            if (WBSetting.locType == "0")
            {
                foreach (Control control in this.tabPagePOM.Controls)
                {
                    control.Enabled = false;
                }
                this.tabControl1.SelectedTab = this.tabPageRef;
            }
            else
            {
                foreach (Control control2 in this.tabPageRef.Controls)
                {
                    control2.Enabled = false;
                }
                this.tabControl1.SelectedTab = this.tabPagePOM;
                this.groupBoxFruit.Enabled = WBUser.CheckTrustee("FRUIT_TYPE", "V");
            }
            if (this.pMode == "EDIT")
            {
                this.tmpContract.DT = this.zTable.DT.Clone();
                this.contractBefore = this.tmpContract.DT.NewRow();
                this.contractBefore.ItemArray = this.zTable.DT.Rows[this.nCurrRow].ItemArray;
                this.tmpContract.DT.Rows.Add(this.contractBefore);
            }
            if (this.pMode == "VIEW")
            {
                this.buttonSave.Visible = false;
            }
            Cursor.Current = Cursors.Default;
        }

        public void f_Save()
        {
            WBTable table2;
            Cursor.Current = Cursors.WaitCursor;
            if (!this.checkQuantity.Checked || (Program.StrToDouble(this.textQuantity.Text, 0) != 0.0))
            {
                TextBox[] aText = new TextBox[] { this.textDO, this.textType };
                if (!Program.CheckEmpty(aText))
                {
                    if (this.comboIncoterm.Text.Trim() != "")
                    {
                        this.tblComm.ReOpen();
                        string[] aField = new string[] { "Comm_Code" };
                        string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                        this.tblComm.DR = this.tblComm.GetData(aField, aFind);
                        if (!ReferenceEquals(this.tblComm.DR, null))
                        {
                            if ((WBSetting.locType != "0") || ((this.tblComm.DR["postSAP"].ToString() != "Y") || (this.textPO.Text.Trim() != "")))
                            {
                                if (!this.ChkVend(1) || ((this.comboIncoterm.Text == "LCO") && !this.ChkTransporter(1)))
                                {
                                    return;
                                }
                                else if (this.ChkEstate(1))
                                {
                                    WBTable table = new WBTable();
                                    table.OpenTable("wb_contract", "SELECT do_no,tolling,uniq FROM wb_contract Where " + WBData.CompanyLocation(" and (Do_No='" + this.textDO.Text.Trim() + "')"), WBData.conn);
                                    if ((table.DT.Rows.Count <= 0) || (((this.pMode != "ADD") && (this.pMode != "COPY")) && ((this.pMode != "EDIT") || (this.zTable.uniq.Trim() == table.DT.Rows[0]["uniq"].ToString().Trim()))))
                                    {
                                        table.Dispose();
                                        if (WBSetting.locType == "0")
                                        {
                                            if (this.comboGRBatch.Text.Trim() != "")
                                            {
                                                if ((this.comboUploadType.Text.Trim() == "UST") && (this.comboGIBatch.Text == ""))
                                                {
                                                    MessageBox.Show(Resource.Mes_096, Resource.Title_002);
                                                    this.comboGIBatch.Focus();
                                                    return;
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show(Resource.Mes_097, Resource.Title_002);
                                                this.comboGRBatch.Focus();
                                                return;
                                            }
                                        }
                                        if (this.pMode == "EDIT")
                                        {
                                            this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                                        }
                                        if (this.pMode != "EDIT")
                                        {
                                            goto TR_002A;
                                        }
                                        else
                                        {
                                            table2 = new WBTable();
                                            table2.OpenTable("wb_transDO", "Select ref From wb_transDO where " + WBData.CompanyLocation(" and DO_No='" + this.zTable.DT.Rows[this.nCurrRow]["Do_No"].ToString() + "'"), WBData.conn);
                                            if (table2.DT.Rows.Count <= 0)
                                            {
                                                goto TR_002B;
                                            }
                                            else
                                            {
                                                string[] textArray3 = new string[] { Resource.Mes_104, " (", table2.DT.Rows.Count.ToString(), " ", Resource.Mes_047B, ")\n", Resource.Msg_Continue };
                                                if (MessageBox.Show(string.Concat(textArray3), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                                {
                                                    int num2 = 0;
                                                    while (true)
                                                    {
                                                        if (num2 < table2.DT.Rows.Count)
                                                        {
                                                            table2.DR = table2.DT.Rows[num2];
                                                            WBTable table3 = new WBTable();
                                                            table3.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and Ref='" + table2.DR["Ref"].ToString() + "'"), WBData.conn);
                                                            if (table3.DT.Rows.Count > 0)
                                                            {
                                                                table3.DR = table3.DT.Rows[0];
                                                                if (table3.Locked(table3.DR["uniq"].ToString(), '0'))
                                                                {
                                                                    MessageBox.Show(Resource.Mes_037 + table2.DR["Ref"].ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                                    table3.Dispose();
                                                                    break;
                                                                }
                                                            }
                                                            num2++;
                                                            continue;
                                                        }
                                                        this.ReplaceAll = true;
                                                        goto TR_002B;
                                                    }
                                                }
                                                else
                                                {
                                                    this.ReplaceAll = false;
                                                    this.textDO.Focus();
                                                }
                                            }
                                        }
                                        return;
                                    }
                                    else
                                    {
                                        table.Dispose();
                                        MessageBox.Show(Resource.Mes_103, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        this.textDO.Focus();
                                        return;
                                    }
                                }
                                else
                                {
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_099, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                this.textPO.Focus();
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_101, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            this.textCommodity.Focus();
                            this.CommodityName.Text = "";
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_098, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        return;
                    }
                }
                else
                {
                    return;
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_090, Resource.Title_006);
                return;
            }
            goto TR_002B;
        TR_002A:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "DO No" },
                    textRefNo = { Text = this.textDO.Text },
                    Text = "CHANGE REASON",
                    label2 = { Text = "Change Reason : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            if ((this.pMode == "ADD") || (this.pMode == "COPY"))
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Transaction_Code"] = this.textType.Text.Trim();
            this.zTable.DR["Do_No"] = this.textDO.Text.Trim();
            this.zTable.DR["Do_Date"] = this.dateTimeDO.Value;
            this.zTable.DR["CheckPeriod"] = this.checkPeriod.Checked ? "Y" : "N";
            if (this.checkPeriod.Checked)
            {
                this.zTable.DR["Do_Date2"] = this.dateDO_period.Value;
            }
            this.dateDO_period.Text = "";
            this.dateDO_period.Enabled = this.checkPeriod.Checked;
            this.zTable.DR["Contract"] = this.textContract.Text.Trim();
            this.zTable.DR["Contract_Date"] = this.dateTimeContract.Value;
            this.zTable.DR["Comm_Code"] = this.textCommodity.Text.Trim();
            this.zTable.DR["Relation_Code"] = this.textVend.Text.Trim();
            this.zTable.DR["Transporter_Code"] = this.textTransporter.Text.Trim();
            this.zTable.DR["Estate1_Code"] = this.textEstate.Text.Trim();
            this.zTable.DR["Vessel"] = this.textVessel.Text.Trim();
            this.zTable.DR["Remark"] = this.textRemark.Text.Trim();
            this.zTable.DR["Convertion"] = (this.textConvValue.Text.Trim() == "") ? 0.0 : Convert.ToDouble(this.textConvValue.Text);
            this.zTable.DR["ConvertionUnit"] = this.textConvUnit.Text.Trim();
            this.zTable.DR["ISCC"] = this.checkISCC.Checked ? "Y" : "N";
            this.zTable.DR["Quantity"] = this.textQuantity.Text.Trim();
            this.zTable.DR["Entry_Fact"] = this.textOpnEntryFactory.Text.Trim();
            this.zTable.DR["Entry_est"] = this.textOpnEntryEstate.Text.Trim();
            this.zTable.DR["Tolerance"] = this.textTolerance.Text.Trim();
            this.zTable.DR["Franco"] = this.comboIncoterm.Text.Trim();
            this.zTable.DR["DeductedBy"] = this.radioFactoryQty.Checked ? "0" : "1";
            this.zTable.DR["check_qty"] = this.checkQuantity.Checked ? "Y" : "N";
            if (this.IO == "I")
            {
                if (WBSetting.locType == "0")
                {
                    this.zTable.DR["PO"] = this.textPO.Text.Trim();
                    this.zTable.DR["PO_Item"] = this.textPOItem.Text.Trim();
                }
                else if (WBSetting.locType == "1")
                {
                    this.zTable.DR["PO"] = this.textPO1.Text.Trim();
                    this.zTable.DR["PO_Item"] = this.textPO1Item.Text.Trim();
                }
            }
            if (this.IO == "O")
            {
                if (WBSetting.locType == "0")
                {
                    this.zTable.DR["SO"] = this.textPO.Text.Trim();
                    this.zTable.DR["SO_Item"] = this.textPOItem.Text.Trim();
                }
                else if (WBSetting.locType == "1")
                {
                    this.zTable.DR["SO"] = this.textPO1.Text.Trim();
                    this.zTable.DR["SO_Item"] = this.textPO1Item.Text.Trim();
                }
            }
            this.zTable.DR["STO"] = this.textSTO1.Text.Trim();
            this.zTable.DR["STO_Item"] = this.textSTO1Item.Text.Trim();
            this.zTable.DR["zwb"] = "N";
            this.zTable.DR["QualityInfo"] = this.textQualityInfo.Text.Trim();
            this.zTable.DR["zAuto"] = "N";
            this.zTable.DR["Berikat"] = this.checkBerikat.Checked ? "Y" : "N";
            this.zTable.DR["Batch_GR"] = this.comboGRBatch.Text;
            this.zTable.DR["Batch_GI"] = this.comboGIBatch.Text;
            this.zTable.DR["Bag_Batch_GR"] = this.comboBagGRBatch.Text;
            this.zTable.DR["Bag_Batch_GI"] = this.comboBagGIBatch.Text;
            this.zTable.DR["Upload_Type"] = this.comboUploadType.Text;
            this.zTable.DR["NEGO"] = this.textNEGO.Text.Trim();
            this.zTable.DR["Agen"] = this.checkAgen.Checked ? "Y" : "N";
            this.zTable.DR["Group_Type"] = this.radioGroupEstate.Checked ? "0" : (this.radioOtherGroup.Checked ? "1" : (this.radioOthers.Checked ? "2" : (this.radioAgen.Checked ? "3" : (this.radioKebAgen.Checked ? "4" : (this.radioRamp.Checked ? "5" : "")))));
            this.zTable.DR["Big_Fruit1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textLarge1.Text == "") ? "0" : this.textLarge1.Text)), 2);
            this.zTable.DR["Big_Fruit2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textLarge2.Text == "") ? "0" : this.textLarge2.Text)), 2);
            this.zTable.DR["Mid_Fruit1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textMid1.Text == "") ? "0" : this.textMid1.Text)), 2);
            this.zTable.DR["Mid_Fruit2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textMid2.Text == "") ? "0" : this.textMid2.Text)), 2);
            this.zTable.DR["Sml_Fruit1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textSmall1.Text == "") ? "0" : this.textSmall1.Text)), 2);
            this.zTable.DR["Sml_Fruit2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textSmall2.Text == "") ? "0" : this.textSmall2.Text)), 2);
            this.zTable.DR["Loose1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textLoose1.Text == "") ? "0" : this.textLoose1.Text)), 2);
            this.zTable.DR["Loose2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textLoose2.Text == "") ? "0" : this.textLoose2.Text)), 2);
            this.zTable.DR["Scout1"] = Math.Round((double) ((float) Convert.ToDecimal((this.textScout1.Text == "") ? "0" : this.textScout1.Text)), 2);
            this.zTable.DR["Scout2"] = Math.Round((double) ((float) Convert.ToDecimal((this.textScout2.Text == "") ? "0" : this.textScout2.Text)), 2);
            this.zTable.DR["zadp"] = this.adopt;
            if ((this.pMode == "ADD") || (this.pMode == "COPY"))
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if (((this.pMode == "ADD") || (this.pMode == "EDIT")) || (this.pMode == "COPY"))
            {
                if ((this.pMode == "ADD") || (this.pMode == "COPY"))
                {
                    WBTable table4 = new WBTable();
                    table4.OpenTable("wb_contract", "SELECT uniq FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + this.textDO.Text + "'"), WBData.conn);
                    this.logKey = table4.DT.Rows[0]["uniq"].ToString();
                    table4.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_contract", this.logKey, logField, logValue);
            }
            if (((this.pMode == "EDIT") && this.ReplaceAll) && (((this.textDO.Text.Trim() != this.oldDo.Trim()) || ((this.textVend.Text.Trim() != this.oldrelation.Trim()) || ((this.textEstate.Text.Trim() != this.oldEstate.Trim()) || ((this.textTransporter.Text.Trim() != this.oldTransporter.Trim()) || (this.textType.Text.Trim() != this.oldTransType.Trim()))))) || (this.textCommodity.Text.Trim() != this.oldComm.Trim())))
            {
                string[] aField = new string[] { "Do_No", "Contract", "relation_code", "Comm_Code", "Transaction_Code", "Estate" };
                string[] aNewValue = new string[] { this.textDO.Text.Trim(), this.textContract.Text.Trim(), this.textVend.Text.Trim(), this.textCommodity.Text.Trim(), this.textType.Text.Trim(), this.textEstate.Text.Trim() };
                Program.ReplaceAll("wb_transDO", aField, aNewValue, " Do_No='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit contract master data)");
                string[] textArray8 = new string[] { "transporter_code", "Do_No", "relation_code", "Comm_Code", "Transaction_Code", "estate_code", "edit_by", "edit_Date" };
                string[] textArray9 = new string[] { this.textTransporter.Text.Trim(), this.textDO.Text.Trim(), this.textVend.Text.Trim(), this.textCommodity.Text.Trim(), this.textType.Text.Trim(), this.textEstate.Text.Trim(), WBUser.UserID, DateTime.Now.ToString() };
                Program.ReplaceAllExceptTransporter("wb_transaction", textArray8, textArray9, " Do_No='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit contract master data)");
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            base.Close();
            return;
        TR_002B:
            table2.Dispose();
            goto TR_002A;
        }

        private void FormContractEntry_CursorChanged(object sender, EventArgs e)
        {
            MessageBox.Show(base.ActiveControl.Name);
        }

        private void FormContractEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormContractEntry_Load(object sender, EventArgs e)
        {
            this.f_Load();
            this.translate();
        }

        private string getData(string tbl, string field, string value, string sfield)
        {
            string str2;
            if (value.Trim() == "")
            {
                str2 = "";
            }
            else
            {
                WBTable table = new WBTable();
                string str = "";
                string[] textArray1 = new string[] { "select * from ", tbl, " where ", field, " = '", value, "'" };
                table.OpenTable(tbl, string.Concat(textArray1), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    table.DR = table.DT.Rows[0];
                    str = table.DR[sfield].ToString();
                }
                else
                {
                    str = value;
                    string[] textArray2 = new string[] { Resource.Mes_100, " - ", tbl, " - ", value };
                    MessageBox.Show(string.Concat(textArray2));
                    if ((tbl == "wb_commodity") && (field == "material"))
                    {
                        string commCode = Interaction.InputBox("Entry Commodity Code", "Get Data From ZWB", "", 300, 300);
                        if (commCode != "")
                        {
                            this.CompareAll(commCode);
                            this.tblComm.ReOpen();
                            string[] textArray3 = new string[] { "select * from ", tbl, " where ", field, " = '", value, "'" };
                            table.OpenTable(tbl, string.Concat(textArray3), WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                table.DR = table.DT.Rows[0];
                                str = table.DR[sfield].ToString();
                            }
                        }
                    }
                }
                str2 = str;
            }
            return str2;
        }

        private string getQualityInfo(IRfcStructure ISReturn)
        {
            string str = "";
            if (ISReturn.GetString("FFA").Trim() != "")
            {
                string[] textArray1 = new string[] { str, "FFA".PadRight(5, ' '), ":", ISReturn.GetString("FFA").Trim(), " " };
                str = (string.Concat(textArray1) + ISReturn.GetString("FFA_MAX").Trim() + " ") + "\n";
            }
            if (ISReturn.GetString("MNI").Trim() != "")
            {
                string[] textArray2 = new string[] { str, "MNI".PadRight(5, ' '), ":", ISReturn.GetString("MNI").Trim(), " " };
                str = string.Concat(textArray2) + ISReturn.GetString("MNI_MAX").Trim() + "\n";
            }
            if (ISReturn.GetString("DNS").Trim() != "")
            {
                string[] textArray3 = new string[] { str, "DNS".PadRight(5, ' '), ":", ISReturn.GetString("DNS").Trim(), " " };
                str = string.Concat(textArray3) + ISReturn.GetString("DNS_MAX").Trim() + "\n";
            }
            if (ISReturn.GetString("MOIS").Trim() != "")
            {
                str = (str + "MOIS".PadRight(5, ' ') + ":" + ISReturn.GetString("MOIS").Trim()) + "\n";
            }
            if (ISReturn.GetString("IV").Trim() != "")
            {
                str = (str + "IV".PadRight(5, ' ') + ":" + ISReturn.GetString("IV").Trim()) + "\n";
            }
            if (ISReturn.GetString("DOBI").Trim() != "")
            {
                str = (str + "DOBI".PadRight(5, ' ') + ":" + ISReturn.GetString("DOBI").Trim()) + "\n";
            }
            if (ISReturn.GetString("COLOR").Trim() != "")
            {
                str = (str + "COLOR".PadRight(5, ' ') + ":" + ISReturn.GetString("COLOR").Trim()) + "\n";
            }
            if (ISReturn.GetString("OC").Trim() != "")
            {
                str = (str + "OC".PadRight(5, ' ') + ":" + ISReturn.GetString("OC").Trim()) + "\n";
            }
            if (ISReturn.GetString("MP").Trim() != "")
            {
                str = (str + "MP".PadRight(5, ' ') + ":" + ISReturn.GetString("MP").Trim()) + "\n";
            }
            if (ISReturn.GetString("CP").Trim() != "")
            {
                str = (str + "CP".PadRight(5, ' ') + ":" + ISReturn.GetString("CP").Trim()) + "\n";
            }
            if (ISReturn.GetString("PRFAT").Trim() != "")
            {
                str = (str + "PRFAT".PadRight(5, ' ') + ":" + ISReturn.GetString("PRFAT").Trim()) + "\n";
            }
            if (ISReturn.GetString("AV").Trim() != "")
            {
                str = (str + "AV".PadRight(5, ' ') + ":" + ISReturn.GetString("AV").Trim()) + "\n";
            }
            if (ISReturn.GetString("PV").Trim() != "")
            {
                str = (str + "PV".PadRight(5, ' ') + ":" + ISReturn.GetString("PV").Trim()) + "\n";
            }
            if (ISReturn.GetString("SV").Trim() != "")
            {
                str = (str + "SV".PadRight(5, ' ') + ":" + ISReturn.GetString("SV").Trim()) + "\n";
            }
            if (ISReturn.GetString("SM").Trim() != "")
            {
                str = (str + "SM".PadRight(5, ' ') + ":" + ISReturn.GetString("SM").Trim()) + "\n";
            }
            if (ISReturn.GetString("TASTE").Trim() != "")
            {
                str = str + "TASTE".PadRight(5, ' ') + ":" + ISReturn.GetString("TASTE").Trim();
            }
            return str;
        }

        private void getUploadType(string pStr)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_UploadType", "Select * from wb_upload_type", WBData.conn);
            int num = 0;
            string str = "";
            this.textUploadType.Text = (this.textType.Text.Trim() != "S") ? "" : "UGI";
            foreach (DataRow row in table.DT.Rows)
            {
                try
                {
                    num = Convert.ToInt16(row["digit"].ToString());
                }
                catch
                {
                    num = 0;
                }
                str = row["digit_value"].ToString();
                if (pStr.Substring(num - 1, 1) == str)
                {
                    this.textUploadType.Text = row["upload_Type"].ToString();
                }
            }
            table.Dispose();
        }

        private void initCombo()
        {
            this.tblIncoterm.OpenTable("wb_Incoterm", "select * from wb_Incoterm", WBData.conn);
            foreach (DataRow row in this.tblIncoterm.DT.Rows)
            {
                this.comboIncoterm.Items.Add(row["Incoterm_Code"].ToString());
            }
            this.comboIncoterm.Text = this.tblIncoterm.DT.Rows[0]["Incoterm_Code"].ToString();
            if (this.comboIncoterm.Text.Trim() != "")
            {
                string[] aField = new string[] { "Incoterm_Code" };
                string[] aFind = new string[] { this.comboIncoterm.Text.Trim() };
                this.tblIncoterm.DR = this.tblIncoterm.GetData(aField, aFind);
                if (this.tblIncoterm.DR == null)
                {
                    this.labelIncotermCode.Text = "";
                    this.radioFactoryQty.Checked = true;
                }
                else
                {
                    this.labelIncotermCode.Text = this.tblIncoterm.DR["Incoterm_Desc"].ToString();
                    this.radioFactoryQty.Checked = this.tblIncoterm.DR["DeductedBy"].ToString() == "0";
                    this.radioOtherQty.Checked = this.tblIncoterm.DR["DeductedBy"].ToString() == "1";
                }
            }
            this.tbl_batch.OpenTable("wb_batch", "select * from wb_batch", WBData.conn);
            foreach (DataRow row2 in this.tbl_batch.DT.Rows)
            {
                this.comboGRBatch.Items.Add(row2["Batch"].ToString());
                this.comboGIBatch.Items.Add(row2["Batch"].ToString());
                this.comboBagGRBatch.Items.Add(row2["Batch"].ToString());
                this.comboBagGIBatch.Items.Add(row2["Batch"].ToString());
            }
            this.tblUploadType.OpenTable("wb_upload_type", "SELECT * FROM wb_upload_type WHERE " + WBData.CompanyLocation(""), WBData.conn);
            foreach (DataRow row3 in this.tblUploadType.DT.Rows)
            {
                this.comboUploadType.Items.Add(row3["Upload_Type"].ToString());
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.label1 = new Label();
            this.textDO = new TextBox();
            this.label2 = new Label();
            this.dateTimeDO = new DateTimePicker();
            this.dateTimeContract = new DateTimePicker();
            this.label3 = new Label();
            this.textContract = new TextBox();
            this.label4 = new Label();
            this.label7 = new Label();
            this.label8 = new Label();
            this.relationName = new Label();
            this.CommodityName = new Label();
            this.label9 = new Label();
            this.label10 = new Label();
            this.checkQuantity = new CheckBox();
            this.tabControl1 = new TabControl();
            this.tabPageRef = new TabPage();
            this.textSTOItem = new TextBox();
            this.labelSTOSlash = new Label();
            this.textSTO = new TextBox();
            this.labelSTO = new Label();
            this.comboUploadType = new ComboBox();
            this.textUploadType = new TextBox();
            this.labelPOSlash = new Label();
            this.textPOItem = new TextBox();
            this.comboGIBatch = new ComboBox();
            this.labelGIBatch = new Label();
            this.labelGRBatch = new Label();
            this.comboGRBatch = new ComboBox();
            this.labelRefDes = new Label();
            this.textQualityInfo = new RichTextBox();
            this.labelWBRef = new Label();
            this.labelQualityInfo = new Label();
            this.comboRefCode = new ComboBox();
            this.comboBillOfLading = new ComboBox();
            this.labelBillOfLading = new Label();
            this.btnAdopt = new Button();
            this.labelPO = new Label();
            this.textPO = new TextBox();
            this.labelUploadType = new Label();
            this.checkBerikat = new CheckBox();
            this.tabPagePOM = new TabPage();
            this.labelPO1 = new Label();
            this.labelPO1Slash = new Label();
            this.textPO1Item = new TextBox();
            this.textPO1 = new TextBox();
            this.buttonAdopt2 = new Button();
            this.checkTolling = new CheckBox();
            this.groupBoxFruit = new GroupBox();
            this.label30 = new Label();
            this.label29 = new Label();
            this.label28 = new Label();
            this.label27 = new Label();
            this.label26 = new Label();
            this.label39 = new Label();
            this.textLarge1 = new TextBox();
            this.label31 = new Label();
            this.textScout2 = new TextBox();
            this.textLarge2 = new TextBox();
            this.label40 = new Label();
            this.label32 = new Label();
            this.textMid1 = new TextBox();
            this.textScout1 = new TextBox();
            this.label34 = new Label();
            this.label37 = new Label();
            this.textMid2 = new TextBox();
            this.textLoose2 = new TextBox();
            this.label33 = new Label();
            this.label38 = new Label();
            this.textSmall1 = new TextBox();
            this.textLoose1 = new TextBox();
            this.label36 = new Label();
            this.label35 = new Label();
            this.textSmall2 = new TextBox();
            this.checkAgen = new CheckBox();
            this.label13 = new Label();
            this.textSTO1 = new TextBox();
            this.groupBox4 = new GroupBox();
            this.label44 = new Label();
            this.label42 = new Label();
            this.label19 = new Label();
            this.radioRamp = new RadioButton();
            this.radioKebAgen = new RadioButton();
            this.radioAgen = new RadioButton();
            this.radioOthers = new RadioButton();
            this.radioOtherGroup = new RadioButton();
            this.radioGroupEstate = new RadioButton();
            this.labelSTO1slash = new Label();
            this.textSTO1Item = new TextBox();
            this.label23 = new Label();
            this.textNEGO = new TextBox();
            this.tabPage3 = new TabPage();
            this.groupBoxConversion = new GroupBox();
            this.labelConvValue = new Label();
            this.textConvValue = new TextBox();
            this.label50 = new Label();
            this.textConvUnit = new TextBox();
            this.label51 = new Label();
            this.tabPageOpening = new TabPage();
            this.groupBoxEntry = new GroupBox();
            this.textOpnEntryFactory = new TextBox();
            this.label43 = new Label();
            this.textOpnEntryEstate = new TextBox();
            this.label3rdOpening = new Label();
            this.labelFactoryOpening = new Label();
            this.labelKG3rd = new Label();
            this.btnEstate = new Button();
            this.labelEstateADM = new Label();
            this.label15 = new Label();
            this.textVessel = new TextBox();
            this.label14 = new Label();
            this.label12 = new Label();
            this.checkISCC = new CheckBox();
            this.label25 = new Label();
            this.textRemark = new TextBox();
            this.buttonSave = new Button();
            this.buttonCancel = new Button();
            this.label45 = new Label();
            this.label46 = new Label();
            this.textTransporter = new TextBox();
            this.textType = new TextBox();
            this.buttonType = new Button();
            this.textCommodity = new TextBox();
            this.button1 = new Button();
            this.textVend = new TextBox();
            this.button2 = new Button();
            this.button3 = new Button();
            this.TransporterName = new Label();
            this.labelTransTypeName = new Label();
            this.label49 = new Label();
            this.textTolerance = new TextBox();
            this.label53 = new Label();
            this.textQuantity = new TextBox();
            this.dateDO_period = new DateTimePicker();
            this.checkPeriod = new CheckBox();
            this.textEstate = new TextBox();
            this.toolTip1 = new ToolTip(this.components);
            this.groupBoxDeducted = new GroupBox();
            this.radioOtherQty = new RadioButton();
            this.radioFactoryQty = new RadioButton();
            this.textBox2 = new TextBox();
            this.textOSQty = new TextBox();
            this.textToken = new TextBox();
            this.label47 = new Label();
            this.label55 = new Label();
            this.label56 = new Label();
            this.buttonOSQty = new Button();
            this.labelIncotermCode = new Label();
            this.comboIncoterm = new ComboBox();
            this.comboBagGIBatch = new ComboBox();
            this.labelBagGIBatch = new Label();
            this.labelBagGRBatch = new Label();
            this.comboBagGRBatch = new ComboBox();
            this.tabControl1.SuspendLayout();
            this.tabPageRef.SuspendLayout();
            this.tabPagePOM.SuspendLayout();
            this.groupBoxFruit.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBoxConversion.SuspendLayout();
            this.tabPageOpening.SuspendLayout();
            this.groupBoxEntry.SuspendLayout();
            this.groupBoxDeducted.SuspendLayout();
            base.SuspendLayout();
            this.label1.Location = new Point(0x10, 0x30);
            this.label1.Margin = new Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x85, 0x10);
            this.label1.TabIndex = 0x15;
            this.label1.Text = "Delivery Order No.";
            this.label1.TextAlign = ContentAlignment.TopRight;
            this.textDO.Location = new Point(0x9f, 0x2b);
            this.textDO.Margin = new Padding(4, 5, 4, 5);
            this.textDO.MaxLength = 100;
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0x111, 0x16);
            this.textDO.TabIndex = 1;
            this.textDO.TextChanged += new EventHandler(this.textDO_TextChanged);
            this.textDO.KeyPress += new KeyPressEventHandler(this.textBox1_KeyPress);
            this.label2.Location = new Point(0x1b9, 0x2c);
            this.label2.Margin = new Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x7c, 0x12);
            this.label2.TabIndex = 0x1f;
            this.label2.Text = "Date";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.dateTimeDO.Format = DateTimePickerFormat.Short;
            this.dateTimeDO.Location = new Point(0x23f, 0x2a);
            this.dateTimeDO.Margin = new Padding(4, 5, 4, 5);
            this.dateTimeDO.Name = "dateTimeDO";
            this.dateTimeDO.Size = new Size(0x71, 0x16);
            this.dateTimeDO.TabIndex = 2;
            this.dateTimeDO.Value = new DateTime(0x7dc, 8, 30, 0, 0, 0, 0);
            this.dateTimeContract.Format = DateTimePickerFormat.Short;
            this.dateTimeContract.Location = new Point(0x23f, 0x4a);
            this.dateTimeContract.Margin = new Padding(4, 5, 4, 5);
            this.dateTimeContract.Name = "dateTimeContract";
            this.dateTimeContract.Size = new Size(0x71, 0x16);
            this.dateTimeContract.TabIndex = 6;
            this.dateTimeContract.Value = new DateTime(0x7dc, 8, 30, 0, 0, 0, 0);
            this.label3.Location = new Point(0x1bb, 0x4e);
            this.label3.Margin = new Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x7c, 0x10);
            this.label3.TabIndex = 0x20;
            this.label3.Text = "Date";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.textContract.Location = new Point(0x9f, 0x4b);
            this.textContract.Margin = new Padding(4, 5, 4, 5);
            this.textContract.MaxLength = 50;
            this.textContract.Name = "textContract";
            this.textContract.Size = new Size(0x111, 0x16);
            this.textContract.TabIndex = 5;
            this.textContract.TextChanged += new EventHandler(this.textContract_TextChanged);
            this.textContract.KeyPress += new KeyPressEventHandler(this.textBox2_KeyPress);
            this.label4.Location = new Point(0x10, 80);
            this.label4.Margin = new Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x85, 0x10);
            this.label4.TabIndex = 0x16;
            this.label4.Text = "Contract No.";
            this.label4.TextAlign = ContentAlignment.TopRight;
            this.label7.Location = new Point(0x10, 0x71);
            this.label7.Margin = new Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x85, 0x10);
            this.label7.TabIndex = 0x17;
            this.label7.Text = "Commodity";
            this.label7.TextAlign = ContentAlignment.TopRight;
            this.label8.Location = new Point(0x10, 0x92);
            this.label8.Margin = new Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x85, 0x10);
            this.label8.TabIndex = 0x18;
            this.label8.Text = "Vendor / Customer";
            this.label8.TextAlign = ContentAlignment.TopRight;
            this.relationName.AutoSize = true;
            this.relationName.Location = new Point(0x17f, 0x92);
            this.relationName.Margin = new Padding(4, 0, 4, 0);
            this.relationName.Name = "relationName";
            this.relationName.Size = new Size(0x61, 0x11);
            this.relationName.TabIndex = 0x24;
            this.relationName.Text = "RelationName";
            this.CommodityName.AutoSize = true;
            this.CommodityName.Location = new Point(0x17f, 0x71);
            this.CommodityName.Margin = new Padding(4, 0, 4, 0);
            this.CommodityName.Name = "CommodityName";
            this.CommodityName.Size = new Size(0x72, 0x11);
            this.CommodityName.TabIndex = 0x22;
            this.CommodityName.Text = "CommodityName";
            this.label9.Location = new Point(0x10, 14);
            this.label9.Margin = new Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x85, 0x10);
            this.label9.TabIndex = 20;
            this.label9.Text = "Transaction Type";
            this.label9.TextAlign = ContentAlignment.TopRight;
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0x31f, 0x110);
            this.label10.Margin = new Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x3d, 0x11);
            this.label10.TabIndex = 0x2b;
            this.label10.Text = "Quantity";
            this.checkQuantity.AutoSize = true;
            this.checkQuantity.Checked = true;
            this.checkQuantity.CheckState = CheckState.Checked;
            this.checkQuantity.Location = new Point(0x415, 270);
            this.checkQuantity.Margin = new Padding(4, 5, 4, 5);
            this.checkQuantity.Name = "checkQuantity";
            this.checkQuantity.Size = new Size(0x7e, 0x15);
            this.checkQuantity.TabIndex = 15;
            this.checkQuantity.Text = "Check Quantity\r\n";
            this.checkQuantity.UseVisualStyleBackColor = true;
            this.tabControl1.Controls.Add(this.tabPageRef);
            this.tabControl1.Controls.Add(this.tabPagePOM);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPageOpening);
            this.tabControl1.Location = new Point(0x1b, 0x162);
            this.tabControl1.Margin = new Padding(4, 5, 4, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new Size(0x369, 0x169);
            this.tabControl1.TabIndex = 0x11;
            this.tabPageRef.BackColor = Color.WhiteSmoke;
            this.tabPageRef.BorderStyle = BorderStyle.FixedSingle;
            this.tabPageRef.Controls.Add(this.comboBagGIBatch);
            this.tabPageRef.Controls.Add(this.labelBagGIBatch);
            this.tabPageRef.Controls.Add(this.labelBagGRBatch);
            this.tabPageRef.Controls.Add(this.comboBagGRBatch);
            this.tabPageRef.Controls.Add(this.textSTOItem);
            this.tabPageRef.Controls.Add(this.labelSTOSlash);
            this.tabPageRef.Controls.Add(this.textSTO);
            this.tabPageRef.Controls.Add(this.labelSTO);
            this.tabPageRef.Controls.Add(this.comboUploadType);
            this.tabPageRef.Controls.Add(this.textUploadType);
            this.tabPageRef.Controls.Add(this.labelPOSlash);
            this.tabPageRef.Controls.Add(this.textPOItem);
            this.tabPageRef.Controls.Add(this.comboGIBatch);
            this.tabPageRef.Controls.Add(this.labelGIBatch);
            this.tabPageRef.Controls.Add(this.labelGRBatch);
            this.tabPageRef.Controls.Add(this.comboGRBatch);
            this.tabPageRef.Controls.Add(this.labelRefDes);
            this.tabPageRef.Controls.Add(this.textQualityInfo);
            this.tabPageRef.Controls.Add(this.labelWBRef);
            this.tabPageRef.Controls.Add(this.labelQualityInfo);
            this.tabPageRef.Controls.Add(this.comboRefCode);
            this.tabPageRef.Controls.Add(this.comboBillOfLading);
            this.tabPageRef.Controls.Add(this.labelBillOfLading);
            this.tabPageRef.Controls.Add(this.btnAdopt);
            this.tabPageRef.Controls.Add(this.labelPO);
            this.tabPageRef.Controls.Add(this.textPO);
            this.tabPageRef.Controls.Add(this.labelUploadType);
            this.tabPageRef.Controls.Add(this.checkBerikat);
            this.tabPageRef.Location = new Point(4, 0x19);
            this.tabPageRef.Margin = new Padding(4, 5, 4, 5);
            this.tabPageRef.Name = "tabPageRef";
            this.tabPageRef.Padding = new Padding(4, 5, 4, 5);
            this.tabPageRef.Size = new Size(0x361, 0x14c);
            this.tabPageRef.TabIndex = 0;
            this.tabPageRef.Text = "   Refinery   ";
            this.tabPageRef.Click += new EventHandler(this.tabPageRef_Click);
            this.textSTOItem.Location = new Point(320, 0x3b);
            this.textSTOItem.Margin = new Padding(4, 4, 4, 4);
            this.textSTOItem.MaxLength = 2;
            this.textSTOItem.Name = "textSTOItem";
            this.textSTOItem.Size = new Size(0x2d, 0x16);
            this.textSTOItem.TabIndex = 0x37;
            this.labelSTOSlash.AutoSize = true;
            this.labelSTOSlash.Location = new Point(300, 0x3f);
            this.labelSTOSlash.Margin = new Padding(4, 0, 4, 0);
            this.labelSTOSlash.Name = "labelSTOSlash";
            this.labelSTOSlash.Size = new Size(12, 0x11);
            this.labelSTOSlash.TabIndex = 0x36;
            this.labelSTOSlash.Text = "/";
            this.textSTO.Location = new Point(0x94, 0x3b);
            this.textSTO.Margin = new Padding(4, 5, 4, 5);
            this.textSTO.MaxLength = 10;
            this.textSTO.Name = "textSTO";
            this.textSTO.Size = new Size(0x91, 0x16);
            this.textSTO.TabIndex = 0x35;
            this.labelSTO.Location = new Point(0x19, 0x3b);
            this.labelSTO.Margin = new Padding(4, 0, 4, 0);
            this.labelSTO.Name = "labelSTO";
            this.labelSTO.Size = new Size(0x73, 0x19);
            this.labelSTO.TabIndex = 0x34;
            this.labelSTO.Text = "STO";
            this.labelSTO.TextAlign = ContentAlignment.MiddleRight;
            this.comboUploadType.FormattingEnabled = true;
            this.comboUploadType.Location = new Point(0x22b, 0x1c);
            this.comboUploadType.Margin = new Padding(4, 4, 4, 4);
            this.comboUploadType.Name = "comboUploadType";
            this.comboUploadType.Size = new Size(0x9b, 0x18);
            this.comboUploadType.TabIndex = 0x33;
            this.textUploadType.Location = new Point(0x2cf, 0x125);
            this.textUploadType.Margin = new Padding(4, 4, 4, 4);
            this.textUploadType.Name = "textUploadType";
            this.textUploadType.ReadOnly = true;
            this.textUploadType.Size = new Size(0x84, 0x16);
            this.textUploadType.TabIndex = 50;
            this.textUploadType.Visible = false;
            this.labelPOSlash.AutoSize = true;
            this.labelPOSlash.Location = new Point(300, 0x20);
            this.labelPOSlash.Margin = new Padding(4, 0, 4, 0);
            this.labelPOSlash.Name = "labelPOSlash";
            this.labelPOSlash.Size = new Size(12, 0x11);
            this.labelPOSlash.TabIndex = 0x24;
            this.labelPOSlash.Text = "/";
            this.labelPOSlash.Click += new EventHandler(this.labelPOSlash_Click);
            this.textPOItem.Location = new Point(320, 0x1c);
            this.textPOItem.Margin = new Padding(4, 4, 4, 4);
            this.textPOItem.MaxLength = 2;
            this.textPOItem.Name = "textPOItem";
            this.textPOItem.Size = new Size(0x2d, 0x16);
            this.textPOItem.TabIndex = 0x23;
            this.textPOItem.TextChanged += new EventHandler(this.textPOItem_TextChanged);
            this.comboGIBatch.FormattingEnabled = true;
            this.comboGIBatch.Location = new Point(0x94, 0x5b);
            this.comboGIBatch.Margin = new Padding(4, 4, 4, 4);
            this.comboGIBatch.Name = "comboGIBatch";
            this.comboGIBatch.Size = new Size(0x91, 0x18);
            this.comboGIBatch.TabIndex = 0x20;
            this.labelGIBatch.Location = new Point(0x19, 0x5b);
            this.labelGIBatch.Margin = new Padding(4, 0, 4, 0);
            this.labelGIBatch.Name = "labelGIBatch";
            this.labelGIBatch.Size = new Size(0x73, 0x19);
            this.labelGIBatch.TabIndex = 30;
            this.labelGIBatch.Text = "GI Batch";
            this.labelGIBatch.TextAlign = ContentAlignment.MiddleRight;
            this.labelGRBatch.Location = new Point(0x13, 0x7c);
            this.labelGRBatch.Margin = new Padding(4, 0, 4, 0);
            this.labelGRBatch.Name = "labelGRBatch";
            this.labelGRBatch.Size = new Size(0x79, 0x19);
            this.labelGRBatch.TabIndex = 0x1f;
            this.labelGRBatch.Text = "GR Batch";
            this.labelGRBatch.TextAlign = ContentAlignment.MiddleRight;
            this.labelGRBatch.Click += new EventHandler(this.label59_Click);
            this.comboGRBatch.FormattingEnabled = true;
            this.comboGRBatch.Location = new Point(0x94, 0x7e);
            this.comboGRBatch.Margin = new Padding(4, 4, 4, 4);
            this.comboGRBatch.Name = "comboGRBatch";
            this.comboGRBatch.Size = new Size(0x91, 0x18);
            this.comboGRBatch.TabIndex = 0x21;
            this.labelRefDes.AutoSize = true;
            this.labelRefDes.Location = new Point(0x2d4, 0x66);
            this.labelRefDes.Margin = new Padding(4, 0, 4, 0);
            this.labelRefDes.Name = "labelRefDes";
            this.labelRefDes.Size = new Size(0x75, 0x11);
            this.labelRefDes.TabIndex = 0x19;
            this.labelRefDes.Text = "Short Description";
            this.textQualityInfo.Enabled = false;
            this.textQualityInfo.Font = new Font("Lucida Console", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textQualityInfo.Location = new Point(0x1c5, 0xae);
            this.textQualityInfo.Margin = new Padding(4, 5, 4, 5);
            this.textQualityInfo.Name = "textQualityInfo";
            this.textQualityInfo.Size = new Size(0xfd, 0x6b);
            this.textQualityInfo.TabIndex = 0x31;
            this.textQualityInfo.Text = " ";
            this.labelWBRef.AutoSize = true;
            this.labelWBRef.Location = new Point(0x1e1, 0x65);
            this.labelWBRef.Margin = new Padding(4, 0, 4, 0);
            this.labelWBRef.Name = "labelWBRef";
            this.labelWBRef.Size = new Size(0x38, 0x11);
            this.labelWBRef.TabIndex = 0x18;
            this.labelWBRef.Text = "WB.Ref";
            this.labelQualityInfo.AutoSize = true;
            this.labelQualityInfo.Location = new Point(0x1c3, 150);
            this.labelQualityInfo.Margin = new Padding(4, 0, 4, 0);
            this.labelQualityInfo.Name = "labelQualityInfo";
            this.labelQualityInfo.Size = new Size(0x6d, 0x11);
            this.labelQualityInfo.TabIndex = 0x30;
            this.labelQualityInfo.Text = "Contract Quality";
            this.comboRefCode.FormattingEnabled = true;
            this.comboRefCode.Location = new Point(0x22b, 0x61);
            this.comboRefCode.Margin = new Padding(4, 5, 4, 5);
            this.comboRefCode.Name = "comboRefCode";
            this.comboRefCode.Size = new Size(0x9b, 0x18);
            this.comboRefCode.TabIndex = 13;
            this.comboRefCode.TextChanged += new EventHandler(this.comboRefCode_TextChanged);
            this.comboBillOfLading.FormattingEnabled = true;
            this.comboBillOfLading.Location = new Point(0x22b, 0x3f);
            this.comboBillOfLading.Margin = new Padding(4, 5, 4, 5);
            this.comboBillOfLading.Name = "comboBillOfLading";
            this.comboBillOfLading.Size = new Size(0x9b, 0x18);
            this.comboBillOfLading.TabIndex = 12;
            this.labelBillOfLading.AutoSize = true;
            this.labelBillOfLading.Location = new Point(0x1c1, 0x41);
            this.labelBillOfLading.Margin = new Padding(4, 0, 4, 0);
            this.labelBillOfLading.Name = "labelBillOfLading";
            this.labelBillOfLading.Size = new Size(0x5c, 0x11);
            this.labelBillOfLading.TabIndex = 0x17;
            this.labelBillOfLading.Text = "Bill Of Lading";
            this.btnAdopt.Location = new Point(0xa3, 0x106);
            this.btnAdopt.Margin = new Padding(4, 5, 4, 5);
            this.btnAdopt.Name = "btnAdopt";
            this.btnAdopt.Size = new Size(0x8b, 0x35);
            this.btnAdopt.TabIndex = 8;
            this.btnAdopt.Text = "&Adopt from SAP";
            this.toolTip1.SetToolTip(this.btnAdopt, "Adopt Data from SAP");
            this.btnAdopt.UseVisualStyleBackColor = true;
            this.btnAdopt.Click += new EventHandler(this.btnAdopt_Click);
            this.labelPO.Location = new Point(9, 0x1a);
            this.labelPO.Margin = new Padding(4, 0, 4, 0);
            this.labelPO.Name = "labelPO";
            this.labelPO.Size = new Size(0x83, 0x19);
            this.labelPO.TabIndex = 15;
            this.labelPO.Text = "SAP Doc. No.";
            this.labelPO.TextAlign = ContentAlignment.MiddleRight;
            this.labelPO.Click += new EventHandler(this.labelPO_Click);
            this.textPO.Location = new Point(0x94, 0x1c);
            this.textPO.Margin = new Padding(4, 5, 4, 5);
            this.textPO.MaxLength = 10;
            this.textPO.Name = "textPO";
            this.textPO.Size = new Size(0x91, 0x16);
            this.textPO.TabIndex = 0;
            this.textPO.Leave += new EventHandler(this.textPO_Leave);
            this.labelUploadType.AutoSize = true;
            this.labelUploadType.Location = new Point(0x1c3, 0x20);
            this.labelUploadType.Margin = new Padding(4, 0, 4, 0);
            this.labelUploadType.Name = "labelUploadType";
            this.labelUploadType.Size = new Size(0x59, 0x11);
            this.labelUploadType.TabIndex = 0x16;
            this.labelUploadType.Text = "Upload Type";
            this.checkBerikat.AutoSize = true;
            this.checkBerikat.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.checkBerikat.Location = new Point(0x1c7, 0x127);
            this.checkBerikat.Margin = new Padding(4, 5, 4, 5);
            this.checkBerikat.Name = "checkBerikat";
            this.checkBerikat.Size = new Size(150, 0x15);
            this.checkBerikat.TabIndex = 10;
            this.checkBerikat.Text = "Kawasan Berikat";
            this.checkBerikat.UseVisualStyleBackColor = true;
            this.tabPagePOM.BackColor = Color.WhiteSmoke;
            this.tabPagePOM.BorderStyle = BorderStyle.FixedSingle;
            this.tabPagePOM.Controls.Add(this.labelPO1);
            this.tabPagePOM.Controls.Add(this.labelPO1Slash);
            this.tabPagePOM.Controls.Add(this.textPO1Item);
            this.tabPagePOM.Controls.Add(this.textPO1);
            this.tabPagePOM.Controls.Add(this.buttonAdopt2);
            this.tabPagePOM.Controls.Add(this.checkTolling);
            this.tabPagePOM.Controls.Add(this.groupBoxFruit);
            this.tabPagePOM.Controls.Add(this.checkAgen);
            this.tabPagePOM.Controls.Add(this.label13);
            this.tabPagePOM.Controls.Add(this.textSTO1);
            this.tabPagePOM.Controls.Add(this.groupBox4);
            this.tabPagePOM.Controls.Add(this.labelSTO1slash);
            this.tabPagePOM.Controls.Add(this.textSTO1Item);
            this.tabPagePOM.Controls.Add(this.label23);
            this.tabPagePOM.Controls.Add(this.textNEGO);
            this.tabPagePOM.Location = new Point(4, 0x19);
            this.tabPagePOM.Margin = new Padding(4, 5, 4, 5);
            this.tabPagePOM.Name = "tabPagePOM";
            this.tabPagePOM.Padding = new Padding(4, 5, 4, 5);
            this.tabPagePOM.Size = new Size(0x361, 0x14c);
            this.tabPagePOM.TabIndex = 1;
            this.tabPagePOM.Text = "   POM   ";
            this.tabPagePOM.Click += new EventHandler(this.tabPagePOM_Click);
            this.labelPO1.Location = new Point(-3, 0x55);
            this.labelPO1.Margin = new Padding(4, 0, 4, 0);
            this.labelPO1.Name = "labelPO1";
            this.labelPO1.Size = new Size(0x79, 0x19);
            this.labelPO1.TabIndex = 0x41;
            this.labelPO1.Text = "SAP Doc. No.";
            this.labelPO1.TextAlign = ContentAlignment.MiddleRight;
            this.labelPO1Slash.AutoSize = true;
            this.labelPO1Slash.Location = new Point(0x10d, 90);
            this.labelPO1Slash.Margin = new Padding(4, 0, 4, 0);
            this.labelPO1Slash.Name = "labelPO1Slash";
            this.labelPO1Slash.Size = new Size(12, 0x11);
            this.labelPO1Slash.TabIndex = 0x10;
            this.labelPO1Slash.Text = "/";
            this.textPO1Item.Location = new Point(0x120, 0x55);
            this.textPO1Item.Margin = new Padding(4, 5, 4, 5);
            this.textPO1Item.MaxLength = 2;
            this.textPO1Item.Name = "textPO1Item";
            this.textPO1Item.Size = new Size(0x2c, 0x16);
            this.textPO1Item.TabIndex = 15;
            this.textPO1.Location = new Point(0x7d, 0x55);
            this.textPO1.Margin = new Padding(4, 5, 4, 5);
            this.textPO1.MaxLength = 10;
            this.textPO1.Name = "textPO1";
            this.textPO1.Size = new Size(140, 0x16);
            this.textPO1.TabIndex = 3;
            this.textPO1.TextChanged += new EventHandler(this.textPO1_TextChanged);
            this.textPO1.Leave += new EventHandler(this.textPO1_Leave);
            this.buttonAdopt2.Location = new Point(0x164, 0x2e);
            this.buttonAdopt2.Margin = new Padding(4, 5, 4, 5);
            this.buttonAdopt2.Name = "buttonAdopt2";
            this.buttonAdopt2.Size = new Size(0x5c, 0x40);
            this.buttonAdopt2.TabIndex = 5;
            this.buttonAdopt2.Text = "&Adopt from SAP";
            this.toolTip1.SetToolTip(this.buttonAdopt2, "Adopt from SAP");
            this.buttonAdopt2.UseVisualStyleBackColor = true;
            this.buttonAdopt2.Click += new EventHandler(this.btnAdopt1_Click);
            this.checkTolling.AutoSize = true;
            this.checkTolling.Location = new Point(0x301, 0x12a);
            this.checkTolling.Margin = new Padding(4, 5, 4, 5);
            this.checkTolling.Name = "checkTolling";
            this.checkTolling.Size = new Size(0x48, 0x15);
            this.checkTolling.TabIndex = 14;
            this.checkTolling.Text = "Tolling";
            this.checkTolling.UseVisualStyleBackColor = true;
            this.checkTolling.Visible = false;
            this.groupBoxFruit.Controls.Add(this.label30);
            this.groupBoxFruit.Controls.Add(this.label29);
            this.groupBoxFruit.Controls.Add(this.label28);
            this.groupBoxFruit.Controls.Add(this.label27);
            this.groupBoxFruit.Controls.Add(this.label26);
            this.groupBoxFruit.Controls.Add(this.label39);
            this.groupBoxFruit.Controls.Add(this.textLarge1);
            this.groupBoxFruit.Controls.Add(this.label31);
            this.groupBoxFruit.Controls.Add(this.textScout2);
            this.groupBoxFruit.Controls.Add(this.textLarge2);
            this.groupBoxFruit.Controls.Add(this.label40);
            this.groupBoxFruit.Controls.Add(this.label32);
            this.groupBoxFruit.Controls.Add(this.textMid1);
            this.groupBoxFruit.Controls.Add(this.textScout1);
            this.groupBoxFruit.Controls.Add(this.label34);
            this.groupBoxFruit.Controls.Add(this.label37);
            this.groupBoxFruit.Controls.Add(this.textMid2);
            this.groupBoxFruit.Controls.Add(this.textLoose2);
            this.groupBoxFruit.Controls.Add(this.label33);
            this.groupBoxFruit.Controls.Add(this.label38);
            this.groupBoxFruit.Controls.Add(this.textSmall1);
            this.groupBoxFruit.Controls.Add(this.textLoose1);
            this.groupBoxFruit.Controls.Add(this.label36);
            this.groupBoxFruit.Controls.Add(this.label35);
            this.groupBoxFruit.Controls.Add(this.textSmall2);
            this.groupBoxFruit.Location = new Point(0x27, 0x90);
            this.groupBoxFruit.Margin = new Padding(4, 5, 4, 5);
            this.groupBoxFruit.Name = "groupBoxFruit";
            this.groupBoxFruit.Padding = new Padding(4, 5, 4, 5);
            this.groupBoxFruit.Size = new Size(0x178, 0xaf);
            this.groupBoxFruit.TabIndex = 6;
            this.groupBoxFruit.TabStop = false;
            this.groupBoxFruit.Text = "Fruit Types";
            this.toolTip1.SetToolTip(this.groupBoxFruit, "This Range will only\r\nbe Applied for this DO");
            this.label30.Location = new Point(8, 0x8f);
            this.label30.Margin = new Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new Size(0x6f, 0x17);
            this.label30.TabIndex = 70;
            this.label30.Text = "Scout";
            this.label30.TextAlign = ContentAlignment.MiddleRight;
            this.label29.Location = new Point(8, 0x72);
            this.label29.Margin = new Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new Size(0x6f, 0x17);
            this.label29.TabIndex = 0x45;
            this.label29.Text = "Loose Fruit";
            this.label29.TextAlign = ContentAlignment.MiddleRight;
            this.label28.Location = new Point(8, 0x56);
            this.label28.Margin = new Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new Size(0x6f, 0x17);
            this.label28.TabIndex = 0x44;
            this.label28.Text = "Small";
            this.label28.TextAlign = ContentAlignment.MiddleRight;
            this.label27.Location = new Point(8, 0x3a);
            this.label27.Margin = new Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new Size(0x6f, 0x17);
            this.label27.TabIndex = 0x43;
            this.label27.Text = "Medium";
            this.label27.TextAlign = ContentAlignment.MiddleRight;
            this.label26.Location = new Point(8, 30);
            this.label26.Margin = new Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new Size(0x6f, 0x17);
            this.label26.TabIndex = 0x42;
            this.label26.Text = "Large";
            this.label26.TextAlign = ContentAlignment.MiddleRight;
            this.label39.AutoSize = true;
            this.label39.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label39.Location = new Point(0x12f, 0x90);
            this.label39.Margin = new Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new Size(0x1a, 0x12);
            this.label39.TabIndex = 0x18;
            this.label39.Text = "Kg";
            this.textLarge1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textLarge1.Location = new Point(0x7f, 0x1b);
            this.textLarge1.Margin = new Padding(4, 5, 4, 5);
            this.textLarge1.MaxLength = 15;
            this.textLarge1.Name = "textLarge1";
            this.textLarge1.Size = new Size(0x45, 0x18);
            this.textLarge1.TabIndex = 0;
            this.textLarge1.Text = "0";
            this.textLarge1.TextAlign = HorizontalAlignment.Right;
            this.textLarge1.Leave += new EventHandler(this.textLarge1_Leave);
            this.label31.AutoSize = true;
            this.label31.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label31.Location = new Point(0xcd, 0x1f);
            this.label31.Margin = new Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new Size(13, 0x12);
            this.label31.TabIndex = 15;
            this.label31.Text = "-";
            this.textScout2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textScout2.Location = new Point(0xe4, 0x8b);
            this.textScout2.Margin = new Padding(4, 5, 4, 5);
            this.textScout2.MaxLength = 15;
            this.textScout2.Name = "textScout2";
            this.textScout2.Size = new Size(0x45, 0x18);
            this.textScout2.TabIndex = 9;
            this.textScout2.Text = "0";
            this.textScout2.TextAlign = HorizontalAlignment.Right;
            this.textScout2.Leave += new EventHandler(this.textScout2_Leave);
            this.textLarge2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textLarge2.Location = new Point(0xe4, 0x1b);
            this.textLarge2.Margin = new Padding(4, 5, 4, 5);
            this.textLarge2.MaxLength = 15;
            this.textLarge2.Name = "textLarge2";
            this.textLarge2.Size = new Size(0x45, 0x18);
            this.textLarge2.TabIndex = 5;
            this.textLarge2.Text = "0";
            this.textLarge2.TextAlign = HorizontalAlignment.Right;
            this.textLarge2.Leave += new EventHandler(this.textLarge2_Leave);
            this.label40.AutoSize = true;
            this.label40.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label40.Location = new Point(0xcd, 0x90);
            this.label40.Margin = new Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new Size(13, 0x12);
            this.label40.TabIndex = 0x13;
            this.label40.Text = "-";
            this.label32.AutoSize = true;
            this.label32.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label32.Location = new Point(0x12f, 0x1f);
            this.label32.Margin = new Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new Size(0x1a, 0x12);
            this.label32.TabIndex = 20;
            this.label32.Text = "Kg";
            this.textMid1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textMid1.Location = new Point(0x7f, 0x37);
            this.textMid1.Margin = new Padding(4, 5, 4, 5);
            this.textMid1.MaxLength = 15;
            this.textMid1.Name = "textMid1";
            this.textMid1.Size = new Size(0x45, 0x18);
            this.textMid1.TabIndex = 1;
            this.textMid1.Text = "0";
            this.textMid1.TextAlign = HorizontalAlignment.Right;
            this.textMid1.Leave += new EventHandler(this.textMid1_Leave);
            this.textScout1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textScout1.Location = new Point(0x7f, 0x8b);
            this.textScout1.Margin = new Padding(4, 5, 4, 5);
            this.textScout1.MaxLength = 15;
            this.textScout1.Name = "textScout1";
            this.textScout1.Size = new Size(0x45, 0x18);
            this.textScout1.TabIndex = 4;
            this.textScout1.Text = "0";
            this.textScout1.TextAlign = HorizontalAlignment.Right;
            this.textScout1.Leave += new EventHandler(this.textScout1_Leave);
            this.label34.AutoSize = true;
            this.label34.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label34.Location = new Point(0xcd, 0x3b);
            this.label34.Margin = new Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new Size(13, 0x12);
            this.label34.TabIndex = 0x10;
            this.label34.Text = "-";
            this.label37.AutoSize = true;
            this.label37.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label37.Location = new Point(0x12f, 0x75);
            this.label37.Margin = new Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new Size(0x1a, 0x12);
            this.label37.TabIndex = 0x17;
            this.label37.Text = "Kg";
            this.textMid2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textMid2.Location = new Point(0xe4, 0x37);
            this.textMid2.Margin = new Padding(4, 5, 4, 5);
            this.textMid2.MaxLength = 15;
            this.textMid2.Name = "textMid2";
            this.textMid2.Size = new Size(0x45, 0x18);
            this.textMid2.TabIndex = 6;
            this.textMid2.Text = "0";
            this.textMid2.TextAlign = HorizontalAlignment.Right;
            this.textMid2.Leave += new EventHandler(this.textMid2_Leave);
            this.textLoose2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textLoose2.Location = new Point(0xe4, 0x70);
            this.textLoose2.Margin = new Padding(4, 5, 4, 5);
            this.textLoose2.MaxLength = 15;
            this.textLoose2.Name = "textLoose2";
            this.textLoose2.Size = new Size(0x45, 0x18);
            this.textLoose2.TabIndex = 8;
            this.textLoose2.Text = "0";
            this.textLoose2.TextAlign = HorizontalAlignment.Right;
            this.textLoose2.Leave += new EventHandler(this.textLoose2_Leave);
            this.label33.AutoSize = true;
            this.label33.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label33.Location = new Point(0x12f, 0x3b);
            this.label33.Margin = new Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new Size(0x1a, 0x12);
            this.label33.TabIndex = 0x15;
            this.label33.Text = "Kg";
            this.label38.AutoSize = true;
            this.label38.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label38.Location = new Point(0xcd, 0x75);
            this.label38.Margin = new Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new Size(13, 0x12);
            this.label38.TabIndex = 0x12;
            this.label38.Text = "-";
            this.textSmall1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textSmall1.Location = new Point(0x7f, 0x55);
            this.textSmall1.Margin = new Padding(4, 5, 4, 5);
            this.textSmall1.MaxLength = 15;
            this.textSmall1.Name = "textSmall1";
            this.textSmall1.Size = new Size(0x45, 0x18);
            this.textSmall1.TabIndex = 2;
            this.textSmall1.Text = "0";
            this.textSmall1.TextAlign = HorizontalAlignment.Right;
            this.textSmall1.Leave += new EventHandler(this.textSmall1_Leave);
            this.textLoose1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textLoose1.Location = new Point(0x7f, 0x70);
            this.textLoose1.Margin = new Padding(4, 5, 4, 5);
            this.textLoose1.MaxLength = 15;
            this.textLoose1.Name = "textLoose1";
            this.textLoose1.Size = new Size(0x45, 0x18);
            this.textLoose1.TabIndex = 3;
            this.textLoose1.Text = "0";
            this.textLoose1.TextAlign = HorizontalAlignment.Right;
            this.textLoose1.Leave += new EventHandler(this.textLoose1_Leave);
            this.label36.AutoSize = true;
            this.label36.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label36.Location = new Point(0xcd, 0x57);
            this.label36.Margin = new Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new Size(13, 0x12);
            this.label36.TabIndex = 0x11;
            this.label36.Text = "-";
            this.label35.AutoSize = true;
            this.label35.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label35.Location = new Point(0x12f, 0x57);
            this.label35.Margin = new Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new Size(0x1a, 0x12);
            this.label35.TabIndex = 0x16;
            this.label35.Text = "Kg";
            this.textSmall2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textSmall2.Location = new Point(0xe4, 0x55);
            this.textSmall2.Margin = new Padding(4, 5, 4, 5);
            this.textSmall2.MaxLength = 15;
            this.textSmall2.Name = "textSmall2";
            this.textSmall2.Size = new Size(0x45, 0x18);
            this.textSmall2.TabIndex = 7;
            this.textSmall2.Text = "0";
            this.textSmall2.TextAlign = HorizontalAlignment.Right;
            this.textSmall2.Leave += new EventHandler(this.textSmall2_Leave);
            this.checkAgen.AutoSize = true;
            this.checkAgen.Location = new Point(0x2a4, 0x12a);
            this.checkAgen.Margin = new Padding(4, 5, 4, 5);
            this.checkAgen.Name = "checkAgen";
            this.checkAgen.Size = new Size(0x3f, 0x15);
            this.checkAgen.TabIndex = 13;
            this.checkAgen.Text = "Agen";
            this.checkAgen.UseVisualStyleBackColor = true;
            this.checkAgen.Visible = false;
            this.label13.AutoSize = true;
            this.label13.Location = new Point(0x4f, 0x3a);
            this.label13.Margin = new Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x25, 0x11);
            this.label13.TabIndex = 9;
            this.label13.Text = "STO";
            this.label13.Click += new EventHandler(this.label13_Click);
            this.textSTO1.Location = new Point(0x7d, 0x35);
            this.textSTO1.Margin = new Padding(4, 5, 4, 5);
            this.textSTO1.MaxLength = 10;
            this.textSTO1.Name = "textSTO1";
            this.textSTO1.Size = new Size(140, 0x16);
            this.textSTO1.TabIndex = 1;
            this.groupBox4.Controls.Add(this.label44);
            this.groupBox4.Controls.Add(this.label42);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.radioRamp);
            this.groupBox4.Controls.Add(this.radioKebAgen);
            this.groupBox4.Controls.Add(this.radioAgen);
            this.groupBox4.Controls.Add(this.radioOthers);
            this.groupBox4.Controls.Add(this.radioOtherGroup);
            this.groupBox4.Controls.Add(this.radioGroupEstate);
            this.groupBox4.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.groupBox4.ForeColor = SystemColors.ControlText;
            this.groupBox4.ImeMode = ImeMode.Off;
            this.groupBox4.Location = new Point(0x210, 0x15);
            this.groupBox4.Margin = new Padding(4, 5, 4, 5);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new Padding(4, 5, 4, 5);
            this.groupBox4.Size = new Size(0x13d, 0xfb);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "[ From Estate ]";
            this.label44.AutoSize = true;
            this.label44.Location = new Point(0x19, 0xb2);
            this.label44.Margin = new Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new Size(0x34, 0x11);
            this.label44.TabIndex = 8;
            this.label44.Text = "Type 3";
            this.label42.AutoSize = true;
            this.label42.Location = new Point(0x19, 0x79);
            this.label42.Margin = new Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new Size(0x34, 0x11);
            this.label42.TabIndex = 7;
            this.label42.Text = "Type 2";
            this.label19.AutoSize = true;
            this.label19.Location = new Point(0x19, 0x1a);
            this.label19.Margin = new Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new Size(0x34, 0x11);
            this.label19.TabIndex = 6;
            this.label19.Text = "Type 1";
            this.radioRamp.AutoSize = true;
            this.radioRamp.Location = new Point(0x1d, 0xc9);
            this.radioRamp.Margin = new Padding(4, 5, 4, 5);
            this.radioRamp.Name = "radioRamp";
            this.radioRamp.Size = new Size(0x42, 0x15);
            this.radioRamp.TabIndex = 5;
            this.radioRamp.TabStop = true;
            this.radioRamp.Text = "Ramp";
            this.radioRamp.UseVisualStyleBackColor = true;
            this.radioKebAgen.AutoSize = true;
            this.radioKebAgen.Location = new Point(0xa7, 80);
            this.radioKebAgen.Margin = new Padding(4, 5, 4, 5);
            this.radioKebAgen.Name = "radioKebAgen";
            this.radioKebAgen.Size = new Size(0x7a, 0x15);
            this.radioKebAgen.TabIndex = 2;
            this.radioKebAgen.TabStop = true;
            this.radioKebAgen.Text = "Pekebun Agen";
            this.radioKebAgen.UseVisualStyleBackColor = true;
            this.radioAgen.AutoSize = true;
            this.radioAgen.Location = new Point(0x1b, 0x4f);
            this.radioAgen.Margin = new Padding(4, 5, 4, 5);
            this.radioAgen.Name = "radioAgen";
            this.radioAgen.Size = new Size(0x3e, 0x15);
            this.radioAgen.TabIndex = 1;
            this.radioAgen.TabStop = true;
            this.radioAgen.Text = "Agen";
            this.radioAgen.UseVisualStyleBackColor = true;
            this.radioOthers.AutoSize = true;
            this.radioOthers.Location = new Point(0xa7, 50);
            this.radioOthers.Margin = new Padding(4, 5, 4, 5);
            this.radioOthers.Name = "radioOthers";
            this.radioOthers.Size = new Size(0x55, 0x15);
            this.radioOthers.TabIndex = 4;
            this.radioOthers.Text = "Pekebun";
            this.radioOthers.UseVisualStyleBackColor = true;
            this.radioOtherGroup.AutoSize = true;
            this.radioOtherGroup.Location = new Point(0x1b, 50);
            this.radioOtherGroup.Margin = new Padding(4, 5, 4, 5);
            this.radioOtherGroup.Name = "radioOtherGroup";
            this.radioOtherGroup.Size = new Size(0x6d, 0x15);
            this.radioOtherGroup.TabIndex = 3;
            this.radioOtherGroup.Text = "Other Group";
            this.radioOtherGroup.UseVisualStyleBackColor = true;
            this.radioGroupEstate.AutoSize = true;
            this.radioGroupEstate.Checked = true;
            this.radioGroupEstate.Location = new Point(0x1d, 0x8b);
            this.radioGroupEstate.Margin = new Padding(4, 5, 4, 5);
            this.radioGroupEstate.Name = "radioGroupEstate";
            this.radioGroupEstate.Size = new Size(0x71, 0x15);
            this.radioGroupEstate.TabIndex = 0;
            this.radioGroupEstate.TabStop = true;
            this.radioGroupEstate.Text = "Group Estate";
            this.radioGroupEstate.UseVisualStyleBackColor = true;
            this.labelSTO1slash.AutoSize = true;
            this.labelSTO1slash.Location = new Point(0x10d, 0x3a);
            this.labelSTO1slash.Margin = new Padding(4, 0, 4, 0);
            this.labelSTO1slash.Name = "labelSTO1slash";
            this.labelSTO1slash.Size = new Size(12, 0x11);
            this.labelSTO1slash.TabIndex = 12;
            this.labelSTO1slash.Text = "/";
            this.textSTO1Item.Location = new Point(0x120, 0x35);
            this.textSTO1Item.Margin = new Padding(4, 5, 4, 5);
            this.textSTO1Item.MaxLength = 2;
            this.textSTO1Item.Name = "textSTO1Item";
            this.textSTO1Item.Size = new Size(0x2c, 0x16);
            this.textSTO1Item.TabIndex = 2;
            this.label23.AutoSize = true;
            this.label23.Location = new Point(0x49, 0x1a);
            this.label23.Margin = new Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new Size(0x31, 0x11);
            this.label23.TabIndex = 8;
            this.label23.Text = "NEGO";
            this.textNEGO.Location = new Point(0x7d, 0x15);
            this.textNEGO.Margin = new Padding(4, 5, 4, 5);
            this.textNEGO.MaxLength = 10;
            this.textNEGO.Name = "textNEGO";
            this.textNEGO.Size = new Size(140, 0x16);
            this.textNEGO.TabIndex = 0;
            this.textNEGO.TextChanged += new EventHandler(this.textNEGO_TextChanged);
            this.tabPage3.BackColor = Color.WhiteSmoke;
            this.tabPage3.Controls.Add(this.groupBoxConversion);
            this.tabPage3.Location = new Point(4, 0x19);
            this.tabPage3.Margin = new Padding(4, 5, 4, 5);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new Padding(4, 5, 4, 5);
            this.tabPage3.Size = new Size(0x361, 0x14c);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "   Additional Control   ";
            this.groupBoxConversion.Controls.Add(this.labelConvValue);
            this.groupBoxConversion.Controls.Add(this.textConvValue);
            this.groupBoxConversion.Controls.Add(this.label50);
            this.groupBoxConversion.Controls.Add(this.textConvUnit);
            this.groupBoxConversion.Controls.Add(this.label51);
            this.groupBoxConversion.Location = new Point(0x15, 0x1f);
            this.groupBoxConversion.Margin = new Padding(4, 5, 4, 5);
            this.groupBoxConversion.Name = "groupBoxConversion";
            this.groupBoxConversion.Padding = new Padding(4, 5, 4, 5);
            this.groupBoxConversion.Size = new Size(0x341, 0x5e);
            this.groupBoxConversion.TabIndex = 0;
            this.groupBoxConversion.TabStop = false;
            this.groupBoxConversion.Text = "[ Do Conversion ]";
            this.labelConvValue.AutoSize = true;
            this.labelConvValue.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.labelConvValue.Location = new Point(0x173, 60);
            this.labelConvValue.Margin = new Padding(4, 0, 4, 0);
            this.labelConvValue.Name = "labelConvValue";
            this.labelConvValue.Size = new Size(0xf4, 0x11);
            this.labelConvValue.TabIndex = 4;
            this.labelConvValue.Text = "( in Kg ),  1 \"Convertion Unit\" = xxx Kg";
            this.textConvValue.Location = new Point(0xaf, 0x37);
            this.textConvValue.Margin = new Padding(4, 5, 4, 5);
            this.textConvValue.Name = "textConvValue";
            this.textConvValue.Size = new Size(0x91, 0x16);
            this.textConvValue.TabIndex = 1;
            this.textConvValue.Text = "0";
            this.textConvValue.TextAlign = HorizontalAlignment.Right;
            this.label50.AutoSize = true;
            this.label50.Location = new Point(0x17, 0x3b);
            this.label50.Margin = new Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new Size(0x74, 0x11);
            this.label50.TabIndex = 2;
            this.label50.Text = "Convertion Value";
            this.textConvUnit.Location = new Point(0xaf, 0x19);
            this.textConvUnit.Margin = new Padding(4, 5, 4, 5);
            this.textConvUnit.MaxLength = 20;
            this.textConvUnit.Name = "textConvUnit";
            this.textConvUnit.Size = new Size(0x91, 0x16);
            this.textConvUnit.TabIndex = 0;
            this.textConvUnit.TextChanged += new EventHandler(this.textConvUnit_TextChanged);
            this.label51.AutoSize = true;
            this.label51.Location = new Point(0x17, 0x1c);
            this.label51.Margin = new Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new Size(0x6d, 0x11);
            this.label51.TabIndex = 3;
            this.label51.Text = "Convertion Unit ";
            this.tabPageOpening.BackColor = Color.WhiteSmoke;
            this.tabPageOpening.Controls.Add(this.groupBoxEntry);
            this.tabPageOpening.Location = new Point(4, 0x19);
            this.tabPageOpening.Margin = new Padding(4, 5, 4, 5);
            this.tabPageOpening.Name = "tabPageOpening";
            this.tabPageOpening.Padding = new Padding(4, 5, 4, 5);
            this.tabPageOpening.Size = new Size(0x361, 0x14c);
            this.tabPageOpening.TabIndex = 3;
            this.tabPageOpening.Text = "Opening";
            this.groupBoxEntry.Controls.Add(this.textOpnEntryFactory);
            this.groupBoxEntry.Controls.Add(this.label43);
            this.groupBoxEntry.Controls.Add(this.textOpnEntryEstate);
            this.groupBoxEntry.Controls.Add(this.label3rdOpening);
            this.groupBoxEntry.Controls.Add(this.labelFactoryOpening);
            this.groupBoxEntry.Controls.Add(this.labelKG3rd);
            this.groupBoxEntry.Location = new Point(0x20, 30);
            this.groupBoxEntry.Margin = new Padding(4, 5, 4, 5);
            this.groupBoxEntry.Name = "groupBoxEntry";
            this.groupBoxEntry.Padding = new Padding(4, 5, 4, 5);
            this.groupBoxEntry.Size = new Size(0x31c, 0x5f);
            this.groupBoxEntry.TabIndex = 0;
            this.groupBoxEntry.TabStop = false;
            this.groupBoxEntry.Text = "Opening Entry";
            this.toolTip1.SetToolTip(this.groupBoxEntry, "Opening Entry for this DO");
            this.groupBoxEntry.UseCompatibleTextRendering = true;
            this.textOpnEntryFactory.Location = new Point(0x74, 0x37);
            this.textOpnEntryFactory.Margin = new Padding(4, 5, 4, 5);
            this.textOpnEntryFactory.MaxLength = 20;
            this.textOpnEntryFactory.Name = "textOpnEntryFactory";
            this.textOpnEntryFactory.Size = new Size(0x83, 0x16);
            this.textOpnEntryFactory.TabIndex = 1;
            this.textOpnEntryFactory.Text = "0";
            this.textOpnEntryFactory.TextAlign = HorizontalAlignment.Right;
            this.textOpnEntryFactory.Leave += new EventHandler(this.textOpnEntryFactory_Leave_1);
            this.label43.AutoSize = true;
            this.label43.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label43.Location = new Point(0x100, 0x3a);
            this.label43.Margin = new Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new Size(0x1a, 0x12);
            this.label43.TabIndex = 5;
            this.label43.Text = "Kg";
            this.textOpnEntryEstate.Location = new Point(0x74, 0x1a);
            this.textOpnEntryEstate.Margin = new Padding(4, 5, 4, 5);
            this.textOpnEntryEstate.MaxLength = 20;
            this.textOpnEntryEstate.Name = "textOpnEntryEstate";
            this.textOpnEntryEstate.Size = new Size(0x83, 0x16);
            this.textOpnEntryEstate.TabIndex = 0;
            this.textOpnEntryEstate.Text = "0";
            this.textOpnEntryEstate.TextAlign = HorizontalAlignment.Right;
            this.textOpnEntryEstate.Leave += new EventHandler(this.textOpnEntryEstate_Leave_1);
            this.label3rdOpening.AutoSize = true;
            this.label3rdOpening.Location = new Point(0x11, 0x1f);
            this.label3rdOpening.Margin = new Padding(4, 0, 4, 0);
            this.label3rdOpening.Name = "label3rdOpening";
            this.label3rdOpening.Size = new Size(0x42, 0x11);
            this.label3rdOpening.TabIndex = 3;
            this.label3rdOpening.Text = "3rd Party";
            this.labelFactoryOpening.AutoSize = true;
            this.labelFactoryOpening.Location = new Point(0x11, 0x3b);
            this.labelFactoryOpening.Margin = new Padding(4, 0, 4, 0);
            this.labelFactoryOpening.Name = "labelFactoryOpening";
            this.labelFactoryOpening.Size = new Size(0x37, 0x11);
            this.labelFactoryOpening.TabIndex = 2;
            this.labelFactoryOpening.Text = "Factory";
            this.labelKG3rd.AutoSize = true;
            this.labelKG3rd.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelKG3rd.Location = new Point(0x100, 0x1c);
            this.labelKG3rd.Margin = new Padding(4, 0, 4, 0);
            this.labelKG3rd.Name = "labelKG3rd";
            this.labelKG3rd.Size = new Size(0x1a, 0x12);
            this.labelKG3rd.TabIndex = 4;
            this.labelKG3rd.Text = "Kg";
            this.btnEstate.Location = new Point(0x158, 0xcf);
            this.btnEstate.Margin = new Padding(0);
            this.btnEstate.Name = "btnEstate";
            this.btnEstate.Size = new Size(0x1f, 0x1b);
            this.btnEstate.TabIndex = 0x27;
            this.btnEstate.Text = "...";
            this.toolTip1.SetToolTip(this.btnEstate, "Browse Estate");
            this.btnEstate.UseVisualStyleBackColor = true;
            this.btnEstate.Click += new EventHandler(this.btnEstate_Click);
            this.labelEstateADM.AutoSize = true;
            this.labelEstateADM.Location = new Point(0x17f, 0xd5);
            this.labelEstateADM.Margin = new Padding(4, 0, 4, 0);
            this.labelEstateADM.Name = "labelEstateADM";
            this.labelEstateADM.Size = new Size(0x55, 0x11);
            this.labelEstateADM.TabIndex = 40;
            this.labelEstateADM.Text = "EstateName";
            this.label15.AutoSize = true;
            this.label15.Location = new Point(0x31c, 0xee);
            this.label15.Margin = new Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x3e, 0x11);
            this.label15.TabIndex = 0x2a;
            this.label15.Text = "Incoterm";
            this.textVessel.Location = new Point(0x9f, 0xf1);
            this.textVessel.Margin = new Padding(4, 5, 4, 5);
            this.textVessel.MaxLength = 20;
            this.textVessel.Name = "textVessel";
            this.textVessel.Size = new Size(0xaf, 0x16);
            this.textVessel.TabIndex = 11;
            this.label14.Location = new Point(0x10, 0xf5);
            this.label14.Margin = new Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x85, 0x10);
            this.label14.TabIndex = 0x1b;
            this.label14.Text = "Vessel";
            this.label14.TextAlign = ContentAlignment.TopRight;
            this.label14.Click += new EventHandler(this.label14_Click);
            this.label12.Location = new Point(0x10, 0xd5);
            this.label12.Margin = new Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x85, 0x10);
            this.label12.TabIndex = 0x1a;
            this.label12.Text = "Estate";
            this.label12.TextAlign = ContentAlignment.TopRight;
            this.checkISCC.AutoSize = true;
            this.checkISCC.Location = new Point(0x2d1, 0x4e);
            this.checkISCC.Margin = new Padding(4, 5, 4, 5);
            this.checkISCC.Name = "checkISCC";
            this.checkISCC.Size = new Size(0x75, 0x15);
            this.checkISCC.TabIndex = 0x29;
            this.checkISCC.Text = "ISCC-Certified";
            this.toolTip1.SetToolTip(this.checkISCC, "Indicator for ISCC Certified");
            this.checkISCC.UseVisualStyleBackColor = true;
            this.label25.Location = new Point(0x10, 0x115);
            this.label25.Margin = new Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new Size(0x85, 0x10);
            this.label25.TabIndex = 0x1c;
            this.label25.Text = "Remark";
            this.label25.TextAlign = ContentAlignment.TopRight;
            this.textRemark.Location = new Point(0x9f, 0x111);
            this.textRemark.Margin = new Padding(4, 5, 4, 5);
            this.textRemark.MaxLength = 100;
            this.textRemark.Multiline = true;
            this.textRemark.Name = "textRemark";
            this.textRemark.Size = new Size(0x1f5, 0x2e);
            this.textRemark.TabIndex = 12;
            this.toolTip1.SetToolTip(this.textRemark, "This Remark will Show in\r\ntransaction remark for ticket\r\n*editable");
            this.textRemark.TextChanged += new EventHandler(this.textRemark_TextChanged);
            this.buttonSave.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonSave.Location = new Point(0x3f3, 0x24f);
            this.buttonSave.Margin = new Padding(4, 5, 4, 5);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0xb3, 0x39);
            this.buttonSave.TabIndex = 0x12;
            this.buttonSave.Text = "&Save";
            this.toolTip1.SetToolTip(this.buttonSave, "Save this DO");
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.buttonCancel.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonCancel.Location = new Point(0x3f4, 0x28e);
            this.buttonCancel.Margin = new Padding(4, 5, 4, 5);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0xb3, 0x39);
            this.buttonCancel.TabIndex = 0x13;
            this.buttonCancel.Text = "&Cancel";
            this.toolTip1.SetToolTip(this.buttonCancel, "Cancel");
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.button2_Click);
            this.label45.AutoSize = true;
            this.label45.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label45.Location = new Point(0x3f0, 0x10b);
            this.label45.Margin = new Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new Size(0x1a, 0x12);
            this.label45.TabIndex = 0x2e;
            this.label45.Text = "Kg";
            this.label46.Location = new Point(0x10, 0xb5);
            this.label46.Margin = new Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new Size(0x85, 0x10);
            this.label46.TabIndex = 0x19;
            this.label46.Text = "Transporter";
            this.label46.TextAlign = ContentAlignment.TopRight;
            this.textTransporter.Location = new Point(0x9f, 0xaf);
            this.textTransporter.Margin = new Padding(4, 5, 4, 5);
            this.textTransporter.MaxLength = 20;
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.Size = new Size(0xad, 0x16);
            this.textTransporter.TabIndex = 9;
            this.textTransporter.TextChanged += new EventHandler(this.textTransporter_TextChanged);
            this.textTransporter.KeyPress += new KeyPressEventHandler(this.textTransporter_KeyPress);
            this.textTransporter.Leave += new EventHandler(this.textTransporter_Leave);
            this.textType.CharacterCasing = CharacterCasing.Upper;
            this.textType.Location = new Point(0x9f, 9);
            this.textType.Margin = new Padding(4, 5, 4, 5);
            this.textType.MaxLength = 20;
            this.textType.Name = "textType";
            this.textType.Size = new Size(0x55, 0x16);
            this.textType.TabIndex = 0;
            this.textType.TextChanged += new EventHandler(this.textType_TextChanged);
            this.textType.KeyPress += new KeyPressEventHandler(this.textType_KeyPress_1);
            this.textType.Leave += new EventHandler(this.textType_Leave_1);
            this.buttonType.Location = new Point(0xfc, 7);
            this.buttonType.Margin = new Padding(0);
            this.buttonType.Name = "buttonType";
            this.buttonType.Size = new Size(0x1f, 0x1b);
            this.buttonType.TabIndex = 0x1d;
            this.buttonType.Text = "...";
            this.toolTip1.SetToolTip(this.buttonType, "Browse Transaction Type");
            this.buttonType.UseVisualStyleBackColor = true;
            this.buttonType.Click += new EventHandler(this.button13_Click);
            this.textCommodity.Location = new Point(0x9f, 0x6b);
            this.textCommodity.Margin = new Padding(4, 5, 4, 5);
            this.textCommodity.MaxLength = 20;
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0xad, 0x16);
            this.textCommodity.TabIndex = 7;
            this.textCommodity.TextChanged += new EventHandler(this.textCommodity_TextChanged_1);
            this.textCommodity.KeyPress += new KeyPressEventHandler(this.textCommodity_KeyPress_1);
            this.textCommodity.Leave += new EventHandler(this.textCommodity_Leave);
            this.button1.Location = new Point(0x158, 0x6b);
            this.button1.Margin = new Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x1f, 0x1b);
            this.button1.TabIndex = 0x21;
            this.button1.Text = "...";
            this.toolTip1.SetToolTip(this.button1, "Browse Commodity");
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click_1);
            this.textVend.Location = new Point(0x9f, 0x8e);
            this.textVend.Margin = new Padding(4, 5, 4, 5);
            this.textVend.MaxLength = 20;
            this.textVend.Name = "textVend";
            this.textVend.Size = new Size(0xad, 0x16);
            this.textVend.TabIndex = 8;
            this.textVend.TextChanged += new EventHandler(this.textVend_TextChanged);
            this.textVend.KeyPress += new KeyPressEventHandler(this.textVend_KeyPress);
            this.textVend.Leave += new EventHandler(this.textVend_Leave);
            this.button2.Location = new Point(0x158, 0x8b);
            this.button2.Margin = new Padding(0);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x1f, 0x1b);
            this.button2.TabIndex = 0x23;
            this.button2.Text = "...";
            this.toolTip1.SetToolTip(this.button2, "Browse Vendor/Supplier");
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click_1);
            this.button3.Location = new Point(0x158, 0xae);
            this.button3.Margin = new Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x1f, 0x1b);
            this.button3.TabIndex = 0x25;
            this.button3.Text = "...";
            this.toolTip1.SetToolTip(this.button3, "Browse Transporter");
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.TransporterName.AutoSize = true;
            this.TransporterName.Location = new Point(0x17f, 0xb5);
            this.TransporterName.Margin = new Padding(4, 0, 4, 0);
            this.TransporterName.Name = "TransporterName";
            this.TransporterName.Size = new Size(120, 0x11);
            this.TransporterName.TabIndex = 0x26;
            this.TransporterName.Text = "TransporterName";
            this.labelTransTypeName.AutoSize = true;
            this.labelTransTypeName.Location = new Point(0x120, 14);
            this.labelTransTypeName.Margin = new Padding(4, 0, 4, 0);
            this.labelTransTypeName.Name = "labelTransTypeName";
            this.labelTransTypeName.Size = new Size(0x72, 0x11);
            this.labelTransTypeName.TabIndex = 30;
            this.labelTransTypeName.Text = "TransTypeName";
            this.label49.AutoSize = true;
            this.label49.Location = new Point(0x313, 0x12f);
            this.label49.Margin = new Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new Size(0x48, 0x11);
            this.label49.TabIndex = 0x2c;
            this.label49.Text = "Tolerance";
            this.textTolerance.Location = new Point(0x364, 0x12a);
            this.textTolerance.Margin = new Padding(4, 5, 4, 5);
            this.textTolerance.MaxLength = 5;
            this.textTolerance.Name = "textTolerance";
            this.textTolerance.Size = new Size(0x39, 0x16);
            this.textTolerance.TabIndex = 0x10;
            this.textTolerance.Text = "0";
            this.textTolerance.TextAlign = HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textTolerance, "Over Quantity Tolerance");
            this.textTolerance.Leave += new EventHandler(this.textTolerance_Leave);
            this.label53.AutoSize = true;
            this.label53.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label53.Location = new Point(0x3a7, 0x12e);
            this.label53.Margin = new Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new Size(0x15, 0x12);
            this.label53.TabIndex = 0x2d;
            this.label53.Text = "%";
            this.textQuantity.Location = new Point(0x364, 0x10b);
            this.textQuantity.Margin = new Padding(4, 5, 4, 5);
            this.textQuantity.MaxLength = 20;
            this.textQuantity.Name = "textQuantity";
            this.textQuantity.Size = new Size(0x83, 0x16);
            this.textQuantity.TabIndex = 14;
            this.textQuantity.Text = "0";
            this.textQuantity.TextAlign = HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textQuantity, "Quantity");
            this.textQuantity.Leave += new EventHandler(this.textQuantity_Leave);
            this.dateDO_period.Format = DateTimePickerFormat.Short;
            this.dateDO_period.Location = new Point(0x357, 0x2a);
            this.dateDO_period.Margin = new Padding(4, 5, 4, 5);
            this.dateDO_period.Name = "dateDO_period";
            this.dateDO_period.Size = new Size(0x71, 0x16);
            this.dateDO_period.TabIndex = 4;
            this.toolTip1.SetToolTip(this.dateDO_period, "DO date Period");
            this.dateDO_period.Value = new DateTime(0x7dc, 8, 30, 0, 0, 0, 0);
            this.checkPeriod.AutoSize = true;
            this.checkPeriod.Location = new Point(0x2d1, 0x2b);
            this.checkPeriod.Margin = new Padding(4, 5, 4, 5);
            this.checkPeriod.Name = "checkPeriod";
            this.checkPeriod.Size = new Size(0x72, 0x15);
            this.checkPeriod.TabIndex = 3;
            this.checkPeriod.Text = "Check Period";
            this.toolTip1.SetToolTip(this.checkPeriod, "If Checked system will show warning if Contract is over period in transaction");
            this.checkPeriod.UseVisualStyleBackColor = true;
            this.checkPeriod.CheckedChanged += new EventHandler(this.checkPeriod_CheckedChanged);
            this.textEstate.Location = new Point(0x9f, 0xd0);
            this.textEstate.Margin = new Padding(4, 5, 4, 5);
            this.textEstate.MaxLength = 20;
            this.textEstate.Name = "textEstate";
            this.textEstate.Size = new Size(0xad, 0x16);
            this.textEstate.TabIndex = 10;
            this.textEstate.TextChanged += new EventHandler(this.textEstate_TextChanged);
            this.textEstate.KeyPress += new KeyPressEventHandler(this.textEstate_KeyPress);
            this.textEstate.Leave += new EventHandler(this.textEstate_Leave);
            this.groupBoxDeducted.Controls.Add(this.radioOtherQty);
            this.groupBoxDeducted.Controls.Add(this.radioFactoryQty);
            this.groupBoxDeducted.Location = new Point(0x323, 0x71);
            this.groupBoxDeducted.Margin = new Padding(4, 5, 4, 5);
            this.groupBoxDeducted.Name = "groupBoxDeducted";
            this.groupBoxDeducted.Padding = new Padding(4, 5, 4, 5);
            this.groupBoxDeducted.Size = new Size(0x14c, 0x62);
            this.groupBoxDeducted.TabIndex = 9;
            this.groupBoxDeducted.TabStop = false;
            this.groupBoxDeducted.Text = "Outstanding Calculation By";
            this.toolTip1.SetToolTip(this.groupBoxDeducted, "Deduction method for Quantity\r\nBuyer Quantity = Factory Quantity\r\nSeller Quantity = 3rd Party / Estate Quantity");
            this.radioOtherQty.AutoSize = true;
            this.radioOtherQty.Location = new Point(0x11, 0x3a);
            this.radioOtherQty.Margin = new Padding(4, 5, 4, 5);
            this.radioOtherQty.Name = "radioOtherQty";
            this.radioOtherQty.Size = new Size(0x5b, 0x15);
            this.radioOtherQty.TabIndex = 1;
            this.radioOtherQty.TabStop = true;
            this.radioOtherQty.Text = "Other Qty";
            this.radioOtherQty.UseVisualStyleBackColor = true;
            this.radioFactoryQty.AutoSize = true;
            this.radioFactoryQty.Checked = true;
            this.radioFactoryQty.Location = new Point(0x11, 0x1b);
            this.radioFactoryQty.Margin = new Padding(4, 5, 4, 5);
            this.radioFactoryQty.Name = "radioFactoryQty";
            this.radioFactoryQty.Size = new Size(0x66, 0x15);
            this.radioFactoryQty.TabIndex = 0;
            this.radioFactoryQty.TabStop = true;
            this.radioFactoryQty.Text = "Factory Qty";
            this.radioFactoryQty.UseVisualStyleBackColor = true;
            this.textBox2.Location = new Point(0x41f, 0x199);
            this.textBox2.Margin = new Padding(4, 4, 4, 4);
            this.textBox2.MaxLength = 20;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new Size(0x71, 0x16);
            this.textBox2.TabIndex = 60;
            this.textBox2.Text = "0";
            this.textBox2.TextAlign = HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textBox2, "Quantity");
            this.textOSQty.Location = new Point(0x41f, 0x17a);
            this.textOSQty.Margin = new Padding(4, 4, 4, 4);
            this.textOSQty.MaxLength = 20;
            this.textOSQty.Name = "textOSQty";
            this.textOSQty.ReadOnly = true;
            this.textOSQty.Size = new Size(0x71, 0x16);
            this.textOSQty.TabIndex = 0x39;
            this.textOSQty.Text = "0";
            this.textOSQty.TextAlign = HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textOSQty, "Quantity");
            this.textToken.BackColor = SystemColors.Control;
            this.textToken.BorderStyle = BorderStyle.None;
            this.textToken.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textToken.Location = new Point(0x323, 11);
            this.textToken.Margin = new Padding(4, 4, 4, 4);
            this.textToken.Name = "textToken";
            this.textToken.Size = new Size(0x187, 0x17);
            this.textToken.TabIndex = 0x34;
            this.textToken.Text = " Token No.";
            this.textToken.TextAlign = HorizontalAlignment.Right;
            this.textToken.Visible = false;
            this.label47.AutoSize = true;
            this.label47.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label47.Location = new Point(0x491, 0x19e);
            this.label47.Margin = new Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new Size(0x1a, 0x12);
            this.label47.TabIndex = 0x3d;
            this.label47.Text = "Kg";
            this.label55.Location = new Point(0x387, 0x19f);
            this.label55.Margin = new Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new Size(0x90, 15);
            this.label55.TabIndex = 0x3b;
            this.label55.Text = "Include In Yard";
            this.label55.TextAlign = ContentAlignment.TopRight;
            this.label56.AutoSize = true;
            this.label56.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label56.Location = new Point(0x491, 380);
            this.label56.Margin = new Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new Size(0x1a, 0x12);
            this.label56.TabIndex = 0x3a;
            this.label56.Text = "Kg";
            this.buttonOSQty.Location = new Point(0x399, 0x17a);
            this.buttonOSQty.Margin = new Padding(4, 4, 4, 4);
            this.buttonOSQty.Name = "buttonOSQty";
            this.buttonOSQty.Size = new Size(100, 0x1c);
            this.buttonOSQty.TabIndex = 0x38;
            this.buttonOSQty.Text = "OS Quantity";
            this.buttonOSQty.UseVisualStyleBackColor = true;
            this.buttonOSQty.Click += new EventHandler(this.buttonOSQty_Click);
            this.labelIncotermCode.AutoSize = true;
            this.labelIncotermCode.Location = new Point(0x3f0, 0xee);
            this.labelIncotermCode.Margin = new Padding(4, 0, 4, 0);
            this.labelIncotermCode.Name = "labelIncotermCode";
            this.labelIncotermCode.Size = new Size(0x7d, 0x11);
            this.labelIncotermCode.TabIndex = 0x40;
            this.labelIncotermCode.Text = "labelIncotermCode";
            this.comboIncoterm.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboIncoterm.FormattingEnabled = true;
            this.comboIncoterm.Location = new Point(0x364, 0xea);
            this.comboIncoterm.Margin = new Padding(4, 4, 4, 4);
            this.comboIncoterm.Name = "comboIncoterm";
            this.comboIncoterm.Size = new Size(0x83, 0x18);
            this.comboIncoterm.TabIndex = 0x3f;
            this.comboIncoterm.SelectedIndexChanged += new EventHandler(this.comboIncoterm_SelectedIndexChanged);
            this.comboIncoterm.Leave += new EventHandler(this.comboIncoterm_Leave);
            this.comboBagGIBatch.FormattingEnabled = true;
            this.comboBagGIBatch.Location = new Point(0x94, 0xa1);
            this.comboBagGIBatch.Margin = new Padding(4);
            this.comboBagGIBatch.Name = "comboBagGIBatch";
            this.comboBagGIBatch.Size = new Size(0x91, 0x18);
            this.comboBagGIBatch.TabIndex = 0x3e;
            this.labelBagGIBatch.Location = new Point(0x19, 0xa1);
            this.labelBagGIBatch.Margin = new Padding(4, 0, 4, 0);
            this.labelBagGIBatch.Name = "labelBagGIBatch";
            this.labelBagGIBatch.Size = new Size(0x73, 0x19);
            this.labelBagGIBatch.TabIndex = 60;
            this.labelBagGIBatch.Text = "Bag GI Batch";
            this.labelBagGIBatch.TextAlign = ContentAlignment.MiddleRight;
            this.labelBagGRBatch.Location = new Point(0x13, 0xc2);
            this.labelBagGRBatch.Margin = new Padding(4, 0, 4, 0);
            this.labelBagGRBatch.Name = "labelBagGRBatch";
            this.labelBagGRBatch.Size = new Size(0x79, 0x19);
            this.labelBagGRBatch.TabIndex = 0x3d;
            this.labelBagGRBatch.Text = "Bag GR Batch";
            this.labelBagGRBatch.TextAlign = ContentAlignment.MiddleRight;
            this.comboBagGRBatch.FormattingEnabled = true;
            this.comboBagGRBatch.Location = new Point(0x94, 0xc4);
            this.comboBagGRBatch.Margin = new Padding(4);
            this.comboBagGRBatch.Name = "comboBagGRBatch";
            this.comboBagGRBatch.Size = new Size(0x91, 0x18);
            this.comboBagGRBatch.TabIndex = 0x3f;
            base.AutoScaleDimensions = new SizeF(8f, 16f);
            base.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = SystemColors.Control;
            base.ClientSize = new Size(0x4b9, 0x2f2);
            base.ControlBox = false;
            base.Controls.Add(this.labelIncotermCode);
            base.Controls.Add(this.comboIncoterm);
            base.Controls.Add(this.label47);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.label55);
            base.Controls.Add(this.label56);
            base.Controls.Add(this.textOSQty);
            base.Controls.Add(this.buttonOSQty);
            base.Controls.Add(this.textToken);
            base.Controls.Add(this.textEstate);
            base.Controls.Add(this.groupBoxDeducted);
            base.Controls.Add(this.dateDO_period);
            base.Controls.Add(this.dateTimeContract);
            base.Controls.Add(this.btnEstate);
            base.Controls.Add(this.checkPeriod);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.checkISCC);
            base.Controls.Add(this.textContract);
            base.Controls.Add(this.labelEstateADM);
            base.Controls.Add(this.checkQuantity);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textVessel);
            base.Controls.Add(this.textQuantity);
            base.Controls.Add(this.dateTimeDO);
            base.Controls.Add(this.label14);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.textDO);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.label45);
            base.Controls.Add(this.label12);
            base.Controls.Add(this.label15);
            base.Controls.Add(this.label53);
            base.Controls.Add(this.textTolerance);
            base.Controls.Add(this.label49);
            base.Controls.Add(this.labelTransTypeName);
            base.Controls.Add(this.TransporterName);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.textVend);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.buttonType);
            base.Controls.Add(this.textType);
            base.Controls.Add(this.textTransporter);
            base.Controls.Add(this.label46);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.textRemark);
            base.Controls.Add(this.label25);
            base.Controls.Add(this.tabControl1);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.CommodityName);
            base.Controls.Add(this.relationName);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label7);
            base.Margin = new Padding(4, 5, 4, 5);
            base.Name = "FormContractEntryAfrica";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Weighbridge Contract Entry";
            base.Load += new EventHandler(this.FormContractEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormContractEntry_KeyPress);
            this.tabControl1.ResumeLayout(false);
            this.tabPageRef.ResumeLayout(false);
            this.tabPageRef.PerformLayout();
            this.tabPagePOM.ResumeLayout(false);
            this.tabPagePOM.PerformLayout();
            this.groupBoxFruit.ResumeLayout(false);
            this.groupBoxFruit.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBoxConversion.ResumeLayout(false);
            this.groupBoxConversion.PerformLayout();
            this.tabPageOpening.ResumeLayout(false);
            this.groupBoxEntry.ResumeLayout(false);
            this.groupBoxEntry.PerformLayout();
            this.groupBoxDeducted.ResumeLayout(false);
            this.groupBoxDeducted.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void InitTable()
        {
            this.tblContract_log.OpenTable("wb_contract_log", "Select * from wb_Contract_log where " + WBData.CompanyLocation(" and 1=2"), WBData.conn);
            this.tblIncoterm.OpenTable("wb_incoterm", "Select * from wb_incoterm", WBData.conn);
            this.tblDeductedBy.OpenTable("wb_deductedBy", "Select * from wb_deductedBy", WBData.conn);
            this.tblTransType.OpenTable("wb_transaction_type", "Select * from wb_transaction_type", WBData.conn);
            this.tblComm.OpenTable("wb_commodity", "Select * from wb_commodity", WBData.conn);
            this.tblRelation.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblEstate.OpenTable("wb_estate", "Select * from wb_estate", WBData.conn);
            this.tblTransporter.OpenTable("wb_transporter", "Select * from wb_transporter where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            Program.AutoComp(this.tblTransType, "Transaction_Code", this.textType);
            Program.AutoComp(this.tblComm, "Comm_Code", this.textCommodity);
            Program.AutoComp(this.tblRelation, "Relation_code", this.textVend);
            Program.AutoComp(this.tblTransporter, "Transporter_Code", this.textTransporter);
            Program.AutoComp(this.tblEstate, "Estate_Code", this.textEstate);
            if (WBSetting.locType == "0")
            {
                this.tblRefCode.OpenTable("wb_RefCode", "Select * from wb_refCode where 1=1", WBData.conn);
                Program.AutoCompCombo(this.tblRefCode, "RefCode", this.comboRefCode);
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {
        }

        private void label14_Click(object sender, EventArgs e)
        {
        }

        private void label59_Click(object sender, EventArgs e)
        {
        }

        private void labelEstateLAB_Click(object sender, EventArgs e)
        {
        }

        private void labelPO_Click(object sender, EventArgs e)
        {
        }

        private void labelPOSlash_Click(object sender, EventArgs e)
        {
        }

        private void process1_Exited(object sender, EventArgs e)
        {
        }

        private void tabPagePOM_Click(object sender, EventArgs e)
        {
        }

        private void tabPageRef_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textTolerance);
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textCommodity_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textCommodity_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textCommodity_Leave(object sender, EventArgs e)
        {
            if (this.textCommodity.Text.Trim() == "")
            {
                this.CommodityName.Text = "";
            }
            else
            {
                this.tblComm.ReOpen();
                string[] aField = new string[] { "Comm_Code" };
                string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                this.tblComm.DR = this.tblComm.GetData(aField, aFind);
                if (ReferenceEquals(this.tblComm.DR, null))
                {
                    MessageBox.Show(Resource.Mes_091, Resource.Title_002);
                    this.textCommodity.Text = "";
                    this.tblComm.Close();
                }
                else if (this.tblComm.DR["Deleted"].ToString() == "Y")
                {
                    MessageBox.Show(Resource.Mes_088, Resource.Title_002);
                    this.textCommodity.Text = "";
                    this.tblComm.Close();
                }
                else
                {
                    this.CommodityName.Text = this.tblComm.DR["Comm_Name"].ToString();
                    this.textConvUnit.Text = this.tblComm.DR["ConvertionUnit"].ToString();
                    this.textConvValue.Text = this.tblComm.DR["Convertion"].ToString();
                    this.trade = this.tblComm.DR["Trade"].ToString();
                    this.IsSugar = this.tblComm.DR["Type"].ToString().Trim() == "G";
                    this.tblComm.Close();
                }
            }
        }

        private void textCommodity_TextChanged(object sender, EventArgs e)
        {
            this.ChkComm(0);
        }

        private void textCommodity_TextChanged_1(object sender, EventArgs e)
        {
            this.adopt = "N";
        }

        private void textContract_TextChanged(object sender, EventArgs e)
        {
            this.adopt = "N";
        }

        private void textConvUnit_TextChanged(object sender, EventArgs e)
        {
            this.labelConvValue.Text = (this.textConvUnit.Text != "") ? (" ( in Kg ),  1 " + this.textConvUnit.Text + " = xxx Kg") : "";
        }

        private void textDO_TextChanged(object sender, EventArgs e)
        {
            this.adopt = "N";
        }

        private void textEstate_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textEstate_Leave(object sender, EventArgs e)
        {
            if (((this.textEstate.Text.Trim() == "") || this.ChkEstate(1)) && (this.textEstate.Text.Trim() == ""))
            {
                this.labelEstateADM.Text = "";
            }
        }

        private void textEstate_TextChanged(object sender, EventArgs e)
        {
        }

        private void textGRPO_Cust_Leave(object sender, EventArgs e)
        {
        }

        private void textGRPO_Cust_TextChanged(object sender, EventArgs e)
        {
        }

        private void textLarge1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textLarge1);
        }

        private void textLarge2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textLarge2);
        }

        private void textLoose1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textLoose1);
        }

        private void textLoose2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textLoose2);
        }

        private void textMid1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textMid1);
        }

        private void textMid2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textMid2);
        }

        private void textNEGO_TextChanged(object sender, EventArgs e)
        {
            this.needAdoptNego = (this.textNEGO.Text == "") ? "N" : "Y";
        }

        private void textOpnEntryEstate_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textOpnEntryEstate);
        }

        private void textOpnEntryEstate_Leave_1(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textOpnEntryFactory);
        }

        private void textOpnEntryFactory_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textOpnEntryFactory);
        }

        private void textOpnEntryFactory_Leave_1(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textOpnEntryFactory);
        }

        private void textPO_Leave(object sender, EventArgs e)
        {
        }

        private void textPO_TextChanged(object sender, EventArgs e)
        {
        }

        private void textPO1_Leave(object sender, EventArgs e)
        {
            this.textPO.Text = this.textPO1.Text;
        }

        private void textPO1_TextChanged(object sender, EventArgs e)
        {
        }

        private void textPOItem_TextChanged(object sender, EventArgs e)
        {
        }

        private void textQty_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textOpnEntryFactory);
            if (!(Convert.ToDouble(this.textQuantity.Text) != 0.0))
            {
                this.textQuantity.Text = this.textOpnEntryFactory.Text;
            }
        }

        private void textQuantity_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textQuantity);
        }

        private void textRemark_TextChanged(object sender, EventArgs e)
        {
        }

        private void textScout1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textScout1);
        }

        private void textScout2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textScout2);
        }

        private void textSmall1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textSmall1);
        }

        private void textSmall2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textSmall2);
        }

        private void textTolerance_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textTolerance);
        }

        private void textTransporter_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransporter_Leave(object sender, EventArgs e)
        {
            if (((this.textTransporter.Text.Trim() == "") || this.ChkTransporter(1)) && (this.textTransporter.Text.Trim() == ""))
            {
                this.TransporterName.Text = "";
            }
        }

        private void textTransporter_TextChanged(object sender, EventArgs e)
        {
            if ((this.IO != "O") && (this.comboIncoterm.Text == "LCO"))
            {
                this.adopt = "N";
            }
        }

        private void textType_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textType_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textType_Leave_1(object sender, EventArgs e)
        {
            string[] aField = new string[] { "Transaction_Code" };
            string[] aFind = new string[] { this.textType.Text.Trim() };
            DataRow data = this.tblTransType.GetData(aField, aFind);
            if (data == null)
            {
                this.buttonType.PerformClick();
                this.textType.Focus();
            }
            else
            {
                this.textType.Text = data["Transaction_Code"].ToString();
                this.labelTransTypeName.Text = data["Transaction_Name"].ToString();
                this.IO = data["IO"].ToString();
                if (this.IO == "I")
                {
                    this.labelPO.Text = "PO";
                    this.labelPO1.Text = "PO";
                }
                else if (this.IO == "O")
                {
                    this.labelPO.Text = "SO";
                    this.labelPO1.Text = "SO";
                }
            }
            if (this.textType.Text.Trim() == "S")
            {
                this.comboUploadType.Text = "UGI";
            }
            else if ((this.textType.Text.Trim() != "S") && (this.comboUploadType.Text.Trim() == ""))
            {
                this.comboUploadType.Text = "";
            }
        }

        private void textType_TextChanged(object sender, EventArgs e)
        {
            this.adopt = "N";
        }

        private void textVend_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textVend_Leave(object sender, EventArgs e)
        {
            if (((this.textVend.Text.Trim() == "") || this.ChkVend(1)) && (this.textVend.Text.Trim() == ""))
            {
                this.relationName.Text = "";
            }
        }

        private void textVend_TextChanged(object sender, EventArgs e)
        {
            this.adopt = "N";
        }

        private void translate()
        {
            this.checkPeriod.Text = Resource.ContractE_001;
            this.groupBoxDeducted.Text = Resource.ContractE_002;
            this.radioFactoryQty.Text = Resource.ContractE_003;
            this.radioOtherQty.Text = Resource.ContractE_004;
            this.label15.Text = Resource.ContractE_005;
            this.label10.Text = Resource.ContractE_006;
            this.checkQuantity.Text = Resource.ContractE_007;
            this.label49.Text = Resource.ContractE_008;
            this.buttonOSQty.Text = Resource.ContractE_009;
            this.label55.Text = Resource.ContractE_010;
            this.tabPagePOM.Text = Resource.ContractE_011;
            this.label23.Text = Resource.ContractE_012;
            this.groupBoxFruit.Text = Resource.ContractE_015;
            this.label26.Text = Resource.ContractE_016;
            this.label27.Text = Resource.ContractE_017;
            this.label28.Text = Resource.ContractE_018;
            this.label29.Text = Resource.ContractE_019;
            this.label30.Text = Resource.ContractE_020;
            this.groupBox4.Text = Resource.ContractE_021;
            this.label19.Text = Resource.ContractE_022;
            this.label42.Text = Resource.ContractE_023;
            this.label44.Text = Resource.ContractE_024;
            this.radioOtherGroup.Text = Resource.ContractE_025;
            this.radioAgen.Text = Resource.ContractE_026;
            this.radioOthers.Text = Resource.ContractE_027;
            this.radioKebAgen.Text = Resource.ContractE_028;
            this.radioGroupEstate.Text = Resource.ContractE_029;
            this.radioRamp.Text = Resource.ContractE_030;
            this.tabPage3.Text = Resource.ContractE_031;
            this.groupBoxConversion.Text = Resource.ContractE_032;
            this.label51.Text = Resource.ContractE_033;
            this.label50.Text = Resource.ContractE_034;
            this.tabPageOpening.Text = Resource.ContractE_035;
            this.groupBoxEntry.Text = Resource.ContractE_036;
            this.label3rdOpening.Text = Resource.ContractE_037;
            this.labelFactoryOpening.Text = Resource.ContractE_038;
            this.btnAdopt.Text = Resource.ContractE_039;
            this.label9.Text = Resource.Report05_012;
            this.label1.Text = Resource.Contract_002;
            this.label2.Text = Resource.Contract_003;
            this.label3.Text = Resource.Contract_011;
            this.label7.Text = Resource.Contract_004;
            this.label8.Text = Resource.Contract_006;
            this.label4.Text = Resource.Contract_010;
            this.label46.Text = Resource.Contract_017;
            this.label14.Text = Resource.Contract_018;
            this.label25.Text = Resource.Contract_030;
            this.label12.Text = Resource.Contract_031;
            this.buttonSave.Text = Resource.Save;
            this.buttonCancel.Text = Resource.Menu_Cancel;
        }
    }
}

