﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormContractDiag : Form
    {
        private IContainer components = null;
        public Label label1;
        public TextBox textBox1;
        public TextBox textBox2;
        public Label label2;
        public CheckBox checkBox1;
        public Button button1;
        public Button button2;
        public Label labelProses;
        public Label labelRec;

        public FormContractDiag()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string pStr = "";
            bool flag = false;
            if (!this.checkBox1.Checked)
            {
                string[] textArray1 = new string[] { " and (Do_No>='", this.textBox1.Text.Trim(), "' and Do_No<='", this.textBox2.Text, "')" };
                pStr = string.Concat(textArray1);
            }
            pStr = "Select * From wb_contract Where " + WBData.CompanyLocation(pStr);
            WBTable table = new WBTable();
            table.OpenTable("wb_contract", pStr, WBData.conn);
            HTML html = new HTML {
                File = Application.StartupPath + @"\diag.htm"
            };
            html.Open();
            html.WriteLine("DIAGNOSTIC<br>Masterdata of DO<br><br>");
            WBTable table2 = new WBTable();
            int num = 1;
            foreach (DataRow row in table.DT.Rows)
            {
                this.labelProses.Text = "DO : " + row["Do_No"].ToString();
                this.labelProses.Refresh();
                this.labelRec.Text = num.ToString() + "/" + table.DT.Rows.Count.ToString();
                this.labelRec.Refresh();
                num++;
                flag = false;
                bool flag2 = false;
                bool flag3 = false;
                bool flag4 = false;
                bool flag5 = false;
                table2.OpenTable("sz", "Select * From wb_transaction_type where " + WBData.CompanyLocation(" and Transaction_Code='" + row["Transaction_Code"] + "'"), WBData.conn);
                flag2 = table2.DT.Rows.Count <= 0;
                if (!flag)
                {
                    flag = flag2;
                }
                table2.OpenTable("sz", "Select * From wb_commodity where " + WBData.CompanyLocation(" and Comm_Code='" + row["Comm_Code"] + "'"), WBData.conn);
                flag3 = table2.DT.Rows.Count <= 0;
                if (!flag)
                {
                    flag = flag3;
                }
                table2.OpenTable("sz", "Select * From wb_relation where " + WBData.CompanyLocation(" and Relation_Code='" + row["Relation_Code"] + "'"), WBData.conn);
                flag4 = table2.DT.Rows.Count <= 0;
                if (!flag)
                {
                    flag = flag4;
                }
                table2.OpenTable("sz", "Select * From wb_estate where " + WBData.CompanyLocation(" and Estate_Code='" + row["Estate1_Code"] + "'"), WBData.conn);
                flag5 = table2.DT.Rows.Count <= 0;
                if (!flag)
                {
                    flag = flag5;
                }
                if (flag)
                {
                    html.Write("DO NO : " + row["Do_No"].ToString() + " <br>");
                    if (flag2)
                    {
                        html.Write("<br>_______________ Trans.Type__: " + row["Transaction_Code"].ToString());
                    }
                    if (flag3)
                    {
                        html.Write("<br>_______________ Commodity___: " + row["Comm_Code"].ToString());
                    }
                    if (flag4)
                    {
                        html.Write("<br>_______________ Vendor/Rel._: " + row["Relation_Code"].ToString());
                    }
                    if (flag5)
                    {
                        html.Write("<br>_______________ Estate______: " + row["Estate1_Code"].ToString());
                    }
                    html.Write("<br><br>*************<br><br>");
                    flag = false;
                }
            }
            this.labelProses.Text = "";
            html.Close();
            ViewReport report = new ViewReport {
                webBrowser1 = { Url = new Uri("file:///" + html.File) }
            };
            report.ShowDialog();
            html.Dispose();
            report.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            this.textBox1.Enabled = !this.checkBox1.Checked;
            this.textBox2.Enabled = !this.checkBox1.Checked;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormContractDiag_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormContractDiag_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.labelProses.Text = "";
            this.labelRec.Text = "";
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.textBox1 = new TextBox();
            this.textBox2 = new TextBox();
            this.label2 = new Label();
            this.checkBox1 = new CheckBox();
            this.button1 = new Button();
            this.button2 = new Button();
            this.labelProses = new Label();
            this.labelRec = new Label();
            base.SuspendLayout();
            this.label1.Location = new Point(10, 0x13);
            this.label1.Name = "label1";
            this.label1.Size = new Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "From DO :";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.textBox1.Location = new Point(0x56, 0x10);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0xcd, 20);
            this.textBox1.TabIndex = 1;
            this.textBox2.Location = new Point(0x56, 0x2a);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0xcd, 20);
            this.textBox2.TabIndex = 3;
            this.label2.Location = new Point(10, 0x2d);
            this.label2.Name = "label2";
            this.label2.Size = new Size(70, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "to :";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new Point(0x56, 80);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new Size(0x44, 0x11);
            this.checkBox1.TabIndex = 4;
            this.checkBox1.Text = "All of DO";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new EventHandler(this.checkBox1_CheckedChanged);
            this.button1.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x13c, 0x13);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x2b);
            this.button1.TabIndex = 5;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x13c, 80);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x1a);
            this.button2.TabIndex = 6;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.labelProses.AutoSize = true;
            this.labelProses.Location = new Point(12, 0x76);
            this.labelProses.Name = "labelProses";
            this.labelProses.Size = new Size(0x3a, 13);
            this.labelProses.TabIndex = 7;
            this.labelProses.Text = "Proses DO";
            this.labelRec.AutoSize = true;
            this.labelRec.Location = new Point(12, 0x69);
            this.labelRec.Name = "labelRec";
            this.labelRec.Size = new Size(0x3a, 13);
            this.labelRec.TabIndex = 8;
            this.labelRec.Text = "Proses DO";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1a7, 140);
            base.Controls.Add(this.labelRec);
            base.Controls.Add(this.labelProses);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.checkBox1);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label1);
            base.KeyPreview = true;
            base.Name = "FormContractDiag";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "`";
            base.Load += new EventHandler(this.FormContractDiag_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormContractDiag_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label1.Text = Resource.Lbl_From_DO + " :";
            this.label2.Text = Resource.Main_029 + " :";
            this.labelProses.Text = Resource.Lbl_DO_Process;
            this.labelRec.Text = Resource.Lbl_DO_Process;
            this.checkBox1.Text = Resource.Chk_All_DO;
            this.button1.Text = Resource.Btn_Process;
            this.button2.Text = Resource.Btn_Cancel;
        }
    }
}

