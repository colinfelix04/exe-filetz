﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormContainerEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode;
        public string nlastCheck;
        public string minTare;
        public string maxTare;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public WBTable trans = new WBTable();
        private IContainer components = null;
        private TextBox textReason;
        private Label label8;
        private Button buttonCancel;
        private Button buttonSave;
        private CheckBox checkBlackList;
        private TextBox textDesc;
        public TextBox textContainer;
        private Label label9;
        private Label label3;
        private Label label1;

        public FormContainerEntry()
        {
            this.InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            TextBox[] aText = new TextBox[] { this.textContainer };
            if (!Program.CheckEmpty(aText))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_Container", "Select Uniq From wb_Container Where  " + WBData.CompanyLocation(" and ( Container_Number='" + this.textContainer.Text + "')"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    Cursor.Current = Cursors.WaitCursor;
                    this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                    if (this.pMode == "EDIT")
                    {
                        Cursor.Current = Cursors.Default;
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = "Container No" },
                            textRefNo = { Text = this.textContainer.Text },
                            Text = "CHANGE REASON",
                            label2 = { Text = "Change Reason : " }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                        }
                        else
                        {
                            return;
                        }
                    }
                    Cursor.Current = Cursors.WaitCursor;
                    this.zTable.ReOpen();
                    if (this.pMode == "ADD")
                    {
                        this.zTable.DR = this.zTable.DT.NewRow();
                    }
                    else
                    {
                        this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                        this.logKey = this.zTable.DR["uniq"].ToString();
                        this.zTable.DR.BeginEdit();
                    }
                    this.zTable.DR["Coy"] = WBData.sCoyCode;
                    this.zTable.DR["Location_Code"] = WBData.sLocCode;
                    this.zTable.DR["Container_Number"] = this.textContainer.Text;
                    this.zTable.DR["Description"] = this.textDesc.Text;
                    this.zTable.DR["Reason"] = this.textReason.Text;
                    this.zTable.DR["Black_List"] = this.checkBlackList.Checked ? "Y" : "N";
                    if (this.pMode == "ADD")
                    {
                        this.zTable.DR["Create_By"] = WBUser.UserID;
                        this.zTable.DR["Create_Date"] = DateTime.Now;
                        this.zTable.DT.Rows.Add(this.zTable.DR);
                    }
                    else
                    {
                        this.zTable.DR["Change_By"] = WBUser.UserID;
                        this.zTable.DR["Change_Date"] = DateTime.Now;
                        this.zTable.DR.EndEdit();
                    }
                    this.zTable.Save();
                    if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
                    {
                        if (this.pMode == "ADD")
                        {
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_container", "SELECT uniq FROM wb_container WHERE " + WBData.CompanyLocation(" AND container_number = '" + this.textContainer.Text.Trim() + "'"), WBData.conn);
                            this.logKey = table2.DT.Rows[0]["uniq"].ToString();
                            table2.Dispose();
                        }
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_container", this.logKey, logField, logValue);
                    }
                    if ((this.pMode == "EDIT") && this.ReplaceAll)
                    {
                        string[] aField = new string[] { "Container_Number" };
                        string[] aNewValue = new string[] { this.textContainer.Text.Trim() };
                        Program.ReplaceAll("wb_transaction", aField, aNewValue, " Container_Number='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit container master data)");
                    }
                    Cursor.Current = Cursors.Default;
                    this.saved = true;
                    base.Close();
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_058);
                    this.textContainer.Focus();
                }
            }
        }

        private void checkBlackList_CheckedChanged(object sender, EventArgs e)
        {
            this.textReason.Enabled = this.checkBlackList.Checked;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormContainerEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormContainerEntry_Load(object sender, EventArgs e)
        {
            if (this.pMode != "ADD")
            {
                this.textContainer.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Transporter_Code"].Value.ToString();
                this.textDesc.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Description"].Value.ToString();
                this.textReason.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Reason"].Value.ToString();
                this.checkBlackList.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Black_List"].Value.ToString() == "Y";
                this.checkBlackList.Enabled = WBUser.CheckTrustee("BLACK_LIST", "E");
                this.textReason.Enabled = this.checkBlackList.Enabled && this.checkBlackList.Checked;
                this.OldCode = this.textContainer.Text.Trim();
            }
            if (this.pMode == "VIEW")
            {
                this.buttonSave.Visible = false;
                this.buttonCancel.Text = " &Closed ";
            }
        }

        private void InitializeComponent()
        {
            this.textReason = new TextBox();
            this.label8 = new Label();
            this.buttonCancel = new Button();
            this.buttonSave = new Button();
            this.checkBlackList = new CheckBox();
            this.textDesc = new TextBox();
            this.textContainer = new TextBox();
            this.label9 = new Label();
            this.label3 = new Label();
            this.label1 = new Label();
            base.SuspendLayout();
            this.textReason.CharacterCasing = CharacterCasing.Upper;
            this.textReason.Enabled = false;
            this.textReason.Location = new Point(0x70, 0x95);
            this.textReason.MaxLength = 100;
            this.textReason.Multiline = true;
            this.textReason.Name = "textReason";
            this.textReason.Size = new Size(0x182, 40);
            this.textReason.TabIndex = 0x3f;
            this.label8.AutoSize = true;
            this.label8.Location = new Point(20, 0x98);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x56, 13);
            this.label8.TabIndex = 0x49;
            this.label8.Text = "Blacklist Reason";
            this.buttonCancel.Location = new Point(310, 0xd1);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x4b, 0x17);
            this.buttonCancel.TabIndex = 0x41;
            this.buttonCancel.Text = "&Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.button2_Click);
            this.buttonSave.Location = new Point(0xd3, 0xd1);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x4b, 0x17);
            this.buttonSave.TabIndex = 0x40;
            this.buttonSave.Text = "&Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.checkBlackList.AutoSize = true;
            this.checkBlackList.Location = new Point(0x70, 0x80);
            this.checkBlackList.Name = "checkBlackList";
            this.checkBlackList.Size = new Size(0x41, 0x11);
            this.checkBlackList.TabIndex = 0x3e;
            this.checkBlackList.Text = "Blocked";
            this.checkBlackList.UseVisualStyleBackColor = true;
            this.checkBlackList.CheckedChanged += new EventHandler(this.checkBlackList_CheckedChanged);
            this.textDesc.Location = new Point(0x70, 0x22);
            this.textDesc.MaxLength = 150;
            this.textDesc.Multiline = true;
            this.textDesc.Name = "textDesc";
            this.textDesc.Size = new Size(0x182, 0x2e);
            this.textDesc.TabIndex = 0x3b;
            this.textDesc.KeyPress += new KeyPressEventHandler(this.textDesc_KeyPress);
            this.textContainer.CharacterCasing = CharacterCasing.Upper;
            this.textContainer.Location = new Point(0x70, 8);
            this.textContainer.MaxLength = 20;
            this.textContainer.Name = "textContainer";
            this.textContainer.Size = new Size(0x8b, 20);
            this.textContainer.TabIndex = 0x3a;
            this.textContainer.KeyPress += new KeyPressEventHandler(this.textContainer_KeyPress);
            this.label9.AutoSize = true;
            this.label9.Location = new Point(60, 0x80);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x2e, 13);
            this.label9.TabIndex = 70;
            this.label9.Text = "Blacklist";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x2e, 0x22);
            this.label3.Name = "label3";
            this.label3.Size = new Size(60, 13);
            this.label3.TabIndex = 0x43;
            this.label3.Text = "Description";
            this.label1.AutoSize = true;
            this.label1.Location = new Point(14, 11);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x5c, 13);
            this.label1.TabIndex = 0x42;
            this.label1.Text = "Container Number";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(530, 0xf2);
            base.ControlBox = false;
            base.Controls.Add(this.textReason);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.checkBlackList);
            base.Controls.Add(this.textDesc);
            base.Controls.Add(this.textContainer);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label1);
            base.KeyPreview = true;
            base.Name = "FormContainerEntry";
            this.Text = "Form Container Entry";
            base.Load += new EventHandler(this.FormContainerEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormContainerEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textContainer_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDesc_KeyPress(object sender, KeyPressEventArgs e)
        {
        }
    }
}

