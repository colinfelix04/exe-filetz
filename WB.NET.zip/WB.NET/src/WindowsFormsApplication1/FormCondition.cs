﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCondition : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private IContainer components = null;
        private DataGridView dataGridView1;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        public ToolStripMenuItem closeToolStripMenuItem;
        public TextBox TextFind;
        public Panel panel1;
        public Button buttonFind;
        private ToolStripMenuItem chooseStripMenuItem1;
        private ProgressBar progressBar1;
        private ToolStripMenuItem disableConditionToolStripMenuItem;
        private ToolStripMenuItem clearDisableFeatureTokenToolStripMenuItem;

        public FormCondition()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void clearDisableFeatureTokenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string sqltext = "";
            string str2 = "";
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            WBTable table3 = new WBTable();
            str2 = this.dataGridView1.Rows[this.dataGridView1.CurrentCell.RowIndex].Cells["Condition_Code"].Value.ToString();
            sqltext = "select * from wb_condition\r\n                            where Condition_code = '" + str2 + "' and (allow_disable is not null and allow_disable = 'Y')";
            table.OpenTable("wb_condition", sqltext, WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                MessageBox.Show(Resource.Mes_No_Allowed_to_be_disabled_condition_found, Resource.Mes_Error_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                sqltext = "select * from wb_token where key_1 = '" + str2 + "' and token_code = 'DISABLE_CONDITION' and (completed is null or completed = 'N')";
                table2.OpenTable("wb_token", sqltext, WBData.conn);
                if (table2.DT.Rows.Count <= 0)
                {
                    MessageBox.Show(Resource.Mes_No_Token_data_found, Resource.Mes_Error_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    sqltext = "select * from wb_token_disable_detail\r\n                    where Token_No in (select Token_No from wb_token\r\n                    where key_1 = '" + str2 + "' and token_code = 'DISABLE_CONDITION' and (completed is null or completed = 'N'))";
                    table3.OpenTable("wb_token_disable_detail", sqltext, WBData.conn);
                    if (MessageBox.Show(Resource.Mes_Are_you_sure_want_to_disable_feature, Resource.Mes_Warning_With_Spaces, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
                    {
                        try
                        {
                            foreach (DataRow row in table2.DT.Rows)
                            {
                                row.Delete();
                            }
                            table2.Save();
                            foreach (DataRow row2 in table3.DT.Rows)
                            {
                                row2.Delete();
                            }
                            table3.Save();
                            MessageBox.Show(Resource.Mes_Clear_Token_Disable_Feature_Success, Resource.Mes_Success_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                        catch (Exception exception1)
                        {
                            MessageBox.Show(exception1.Message.ToString(), Resource.Mes_Error_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                }
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (this.pMode == "DISABLE_CONDITION")
            {
                this.f_disableCondition();
            }
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.chooseStripMenuItem1.PerformClick();
            }
        }

        private void disableConditionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.f_disableCondition();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void f_disableCondition()
        {
            FormSelectLocationDisable disable = new FormSelectLocationDisable {
                ToBeDisabledCondition = this.dataGridView1.Rows[this.dataGridView1.CurrentCell.RowIndex].Cells["Condition_Code"].Value.ToString()
            };
            disable.ShowDialog();
            if (disable.submitted)
            {
                this.dataGridView1.Rows[this.dataGridView1.CurrentCell.RowIndex].Cells["start_inactive_time"].Value = disable.start_inactive_time;
                this.dataGridView1.Rows[this.dataGridView1.CurrentCell.RowIndex].Cells["end_inactive_time"].Value = disable.end_inactive_time;
            }
            disable.Dispose();
        }

        private void FormCondition_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormCondition_Load(object sender, EventArgs e)
        {
            this.progressBar1.Visible = false;
            string str = "uniq,Coy,Location_Code,Condition_Code,Description,start_inactive_time,end_inactive_time,allow_disable";
            if (this.pMode != "DISABLE_CONDITION")
            {
                if (this.pFilter == "")
                {
                    this.ztable.OpenTable("wb_condition", "SELECT " + str + " FROM wb_condition", WBData.conn);
                }
                else
                {
                    string text3 = "SELECT " + str + " FROM wb_condition Where " + WBData.CompanyLocation(this.pFilter);
                    string sqltext = text3;
                    if (text3 == null)
                    {
                        string local3 = text3;
                        sqltext = "";
                    }
                    this.ztable.OpenTable("wb_condition", sqltext, WBData.conn);
                }
            }
            else if (!string.IsNullOrEmpty(this.pFilter))
            {
                string text1 = "SELECT " + str + " FROM wb_condition Where " + WBData.CompanyLocation(this.pFilter);
                string sqltext = text1;
                if (text1 == null)
                {
                    string local1 = text1;
                    sqltext = "";
                }
                this.ztable.OpenTable("wb_condition", sqltext, WBData.conn);
            }
            else
            {
                string text2 = "SELECT " + str + " FROM wb_condition Where " + WBData.CompanyLocation(" AND allow_disable = 'Y'");
                string sqltext = text2;
                if (text2 == null)
                {
                    string local2 = text2;
                    sqltext = "";
                }
                this.ztable.OpenTable("wb_condition", sqltext, WBData.conn);
            }
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Condition_Code"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["allow_disable"].Visible = false;
            this.dataGridView1.Columns["Condition_Code"].HeaderText = Resource.Condition_001;
            this.dataGridView1.Columns["Description"].HeaderText = Resource.Condition_002;
            this.dataGridView1.Columns["start_inactive_time"].HeaderText = Resource.Condition_003;
            this.dataGridView1.Columns["end_inactive_time"].HeaderText = Resource.Condition_004;
            this.dataGridView1.Columns["Condition_Code"].Width = 200;
            this.dataGridView1.Columns["Description"].Width = 0x1f0;
            this.dataGridView1.Columns["start_inactive_time"].Width = 180;
            this.dataGridView1.Columns["end_inactive_time"].Width = 180;
            this.dataGridView1.Columns["Condition_Code"].DisplayIndex = 0;
            this.dataGridView1.Columns["Description"].DisplayIndex = 1;
            this.dataGridView1.Columns["start_inactive_time"].DisplayIndex = 2;
            this.dataGridView1.Columns["end_inactive_time"].DisplayIndex = 3;
            base.KeyPreview = true;
            if ((this.pMode != "") && (this.pFind.Trim() != ""))
            {
                this.TextFind.Text = this.pFind;
                this.buttonFind.PerformClick();
            }
            this.chooseStripMenuItem1.Visible = (this.pMode != "") && (this.pMode != "DISABLE_CONDITION");
            if (this.dataGridView1.RowCount == 0)
            {
                this.disableConditionToolStripMenuItem.Enabled = false;
                this.clearDisableFeatureTokenToolStripMenuItem.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.disableConditionToolStripMenuItem = new ToolStripMenuItem();
            this.clearDisableFeatureTokenToolStripMenuItem = new ToolStripMenuItem();
            this.chooseStripMenuItem1 = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.buttonFind = new Button();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x1c);
            this.dataGridView1.Margin = new Padding(4);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x449, 0x1b7);
            this.dataGridView1.TabIndex = 10;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            this.menuStrip1.ImageScalingSize = new Size(20, 20);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseStripMenuItem1, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new Size(0x449, 0x1c);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.disableConditionToolStripMenuItem, this.clearDisableFeatureTokenToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x51, 0x18);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.disableConditionToolStripMenuItem.Name = "disableConditionToolStripMenuItem";
            this.disableConditionToolStripMenuItem.Size = new Size(0x11f, 0x1a);
            this.disableConditionToolStripMenuItem.Text = "Disable Feature";
            this.disableConditionToolStripMenuItem.Click += new EventHandler(this.disableConditionToolStripMenuItem_Click);
            this.clearDisableFeatureTokenToolStripMenuItem.Name = "clearDisableFeatureTokenToolStripMenuItem";
            this.clearDisableFeatureTokenToolStripMenuItem.Size = new Size(0x11f, 0x1a);
            this.clearDisableFeatureTokenToolStripMenuItem.Text = "Clear Token of Disable Feature";
            this.clearDisableFeatureTokenToolStripMenuItem.Click += new EventHandler(this.clearDisableFeatureTokenToolStripMenuItem_Click);
            this.chooseStripMenuItem1.Name = "chooseStripMenuItem1";
            this.chooseStripMenuItem1.Size = new Size(70, 0x18);
            this.chooseStripMenuItem1.Text = "Choose";
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x39, 0x18);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.TextFind.Location = new Point(7, 6);
            this.TextFind.Margin = new Padding(4);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xf4, 0x16);
            this.TextFind.TabIndex = 3;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x1d3);
            this.panel1.Margin = new Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x449, 0x29);
            this.panel1.TabIndex = 11;
            this.progressBar1.Location = new Point(0x367, 10);
            this.progressBar1.Margin = new Padding(4);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xdf, 0x16);
            this.progressBar1.TabIndex = 5;
            this.buttonFind.Location = new Point(260, 5);
            this.buttonFind.Margin = new Padding(4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(100, 0x1c);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            base.AutoScaleDimensions = new SizeF(8f, 16f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x449, 0x1fc);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.Margin = new Padding(4);
            base.Name = "FormCondition";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of Feature";
            base.Load += new EventHandler(this.FormCondition_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormCondition_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseStripMenuItem1.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.disableConditionToolStripMenuItem.Text = Resource.Menu_Disable_Feature;
            this.clearDisableFeatureTokenToolStripMenuItem.Text = Resource.Menu_Clear_Token_Disable_Feature;
            this.buttonFind.Text = Resource.Menu_Find;
            this.Text = Resource.Title_Feature;
        }
    }
}

