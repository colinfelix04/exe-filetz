﻿namespace WindowsFormsApplication1
{
    using Encryption.Utility;
    using System;
    using System.ComponentModel;
    using System.IO;
    using System.IO.Ports;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class WBSetting : Component
    {
        public static WBTable tblSetting;
        public static WBTable tblLocation;
        public static string CommPort;
        public static string sLocName;
        public static string BaudRate;
        public static string DataBits;
        public static string parity;
        public static string Stopbits;
        public static string WB_Type;
        public static string WBCode;
        public static string CoySAP;
        public static int Start_Get = 0;
        public static int Length = 0;
        public static int Buffer = 0xbb8;
        public static int Check_Tare;
        public static int Check_Tare_MinTrans;
        public static int beforeKG = 1;
        public static string bGate;
        public static string gate1Open;
        public static string gate1Close;
        public static string gate2Open;
        public static string gate2Close;
        public static string gate1OpenOut;
        public static string gate1CloseOut;
        public static string gate2OpenOut;
        public static string gate2CloseOut;
        public static string gateType;
        public static string gate1IP;
        public static string gate1Port;
        public static string gate2IP;
        public static string gate2Port;
        public static string gate1IPOut;
        public static string gate1PortOut;
        public static string gate2IPOut;
        public static string gate2PortOut;
        public static string appCode = "01";
        public static string sCheckDirect = "N";
        public static string cam1 = "";
        public static string cam1_type = "";
        public static string cam1_web = "";
        public static string cam1_ip_name = "";
        public static string cam2 = "";
        public static string cam2_type = "";
        public static string cam2_web = "";
        public static string cam2_ip_name = "";
        public static string cam3 = "";
        public static string cam3_type = "";
        public static string cam3_web = "";
        public static string cam3_ip_name = "";
        public static string cam4 = "";
        public static string cam4_type = "";
        public static string cam4_web = "";
        public static string cam4_ip_name = "";
        public static string cam5 = "";
        public static string cam5_type = "";
        public static string cam5_web = "";
        public static string cam5_ip_name = "";
        public static string reg_Line = "";
        public static string reg_feedback = "";
        public static string start_address = "";
        public static string reg_length = "";
        public static string ticket;
        public static string ticket2;
        public static string ticketGatepass;
        public static string loading_advise;
        public static string copyToLoc;
        public static string AutoCloseDO;
        public static string locType;
        public static string NonContract = "N";
        public static string KB;
        public static string Container;
        public static string Trailer;
        public static string Ref6 = "N";
        public static string date6 = "";
        public static string startTime;
        public static string SAPsch;
        public static string SAPTime;
        public static string SAPInterval;
        public static string AutoSyncInterval;
        public static string zwb;
        public static string cpuSAP;
        public static string Check_Zero;
        public static string colour;
        public static string GMSend = "N";
        public static string checkOutSpec;
        public static string checkISCC;
        public static string GrCustRequired;
        public static string IntegrationSAP;
        public static DateTime validDateISCC;
        public static string region = "0";
        public static string transflow = "1";
        public static string sTACode;
        public static string sGatepassCode;
        public static string GrossWeightControl;
        public static string OutgoingTransControl;
        public static string chkZeroMode = "";
        public static string grossHistoryControl = "N";
        public static double grossHistoryVariance = 0.0;
        public static int grossHistoryMinute = 0;
        public static string camera_feature = "N";
        public static string camera_path = "";
        public static string camera_domain = "";
        public static string camera_username = "";
        public static string camera_password = "";
        public static string PLC_IP;
        public static string PLC_Port;
        public static string rangeFlagColor;
        public static string EG_Server;
        public static string EG_Database;
        public static string EG_usID;
        public static string EG_password;
        public static string Intg_Database;
        public static string mulesoft_ID = "";
        public static string mulesoft_Key = "";
        public static bool print_loading_advise = false;
        public static bool print_gatepass_advise = false;
        public static bool print_on_2nd_weight_4x = false;
        public static bool default_delivery_note_for_split = false;
        public static bool wb_filling_location = false;
        public static bool wb_control_valve = false;
        public static bool reason_reprint_ticket = false;
        public static bool dummy_contract_on_registration = false;
        public static bool gatepass_registration = false;
        public static bool gatepassWithoutCard = false;
        public static bool gatepass_auto_submit = false;
        public static bool Allow_Entry_Tandan = false;
        public static bool SAP_Application_Server = false;
        public static bool SAP_Group_Server = false;
        public static bool unlockWeighingMenu = false;
        public static string token_path = "";
        public static string dummy_contract = "-";
        public static string dummy_comm_code = "-";
        public static bool AutoCapture = false;
        public static bool adopt_zdotrx = false;
        public static bool activeTCS = false;
        public static bool getQCfromTCS = false;
        public static bool activeEGrading = false;
        public static bool activeSMSToken = false;
        public static bool activeBC = false;
        public static bool activeEncryptExport = false;
        public static string encryptRecipient = "";
        public static bool loginWithActiveDirectory = false;
        public static string ADPath = "";
        public static string ADPrincipal = "";
        public static string ADChangePasswordLink = "";
        public static bool activeMulesoftIntegration = false;
        public static bool Cut_Off_Location = false;
        public static bool activeRegistrationRequireLicensePhoto = false;
        public static string licensePhoto_path = "";
        public static bool activeOverLossToleranceControlbyNet = false;
        public static bool activeOverLossToleranceControlbyGross = false;
        public static double toleranceForOverLossControlbyNet = 0.0;
        public static double toleranceForOverLossControlbyGross = 0.0;
        public static string ticket_MultiLine1;
        public static string ticket_MultiLine2;
        public static string ticketLangsir;
        public static string ticketLangsir2;
        public static string weighingAnalysis = "";
        public static bool integrationIDSYS = false;
        public static bool folderErrorOccurWhenLoadPhotos = false;
        public static bool allowDecimalLoadingQty = false;
        public static bool over_tare_for_nx = false;
        public static string max_tare_for_nx = "0";
        public static int DeliveryNoteExpiredDuration;
        public static bool DeliveryNoteCutOff;
        public static DateTime DeliveryNoteCutOffDate;
        public static bool AllowUseOldDN;

        public static bool checkCutOffDeliveryNote()
        {
            if (DeliveryNoteCutOff)
            {
                AllowUseOldDN = Convert.ToDateTime(WBUtility.GetServerDatetime()) < DeliveryNoteCutOffDate;
            }
            return AllowUseOldDN;
        }

        public static bool CheckSPB() => 
            tblLocation.DR["Check_DN"].ToString() == "Y";

        public static bool CheckTare() => 
            tblSetting.DR["Check_Tare"].ToString() == "Y";

        public static void checkVersion(string ver)
        {
            string str = tblSetting.DR["version"].ToString();
            if (ver.ToUpper().Trim() != str.ToUpper().Trim())
            {
                tblSetting.DR.BeginEdit();
                tblSetting.DR["version"] = ver;
                tblSetting.DR.EndEdit();
                tblSetting.Save();
                tblSetting.ReOpen();
                tblSetting.DR = tblSetting.DT.Rows[0];
            }
        }

        public static int CheckZero()
        {
            int num;
            if (Check_Zero != "N")
            {
                SerialPort port = new SerialPort();
                port = Program.InitPort();
                num = -999;
                try
                {
                    port.Open();
                    string pStr = port.ReadLine();
                    port.Close();
                    try
                    {
                        num = getValue(pStr);
                    }
                    catch
                    {
                        return num;
                    }
                }
                catch (Exception exception)
                {
                    MessageBox.Show(Resource.Title_003 + ": " + exception.Message + " ");
                    if (port.IsOpen)
                    {
                        port.Close();
                    }
                    return num;
                }
            }
            else
            {
                return 0;
            }
            return num;
        }

        public static void Close()
        {
            tblLocation.Close();
            tblSetting.Close();
        }

        public static double ContractTolerance() => 
            Convert.ToDouble(tblLocation.DR["Tol_Trans"].ToString());

        public static string Field(string pField) => 
            tblLocation.DR[pField].ToString();

        public static string[] FruitsType(string pVal, string pDO_NO)
        {
            string[] strArray = new string[2];
            if (pVal == "")
            {
                pVal = "999";
            }
            double num = Convert.ToDouble(pVal);
            WBTable table = new WBTable();
            table.OpenTable("Wb_Contract", "Select * from WB_Contract where DO_NO ='" + pDO_NO + "'", WBData.conn);
            if (table.DT.Rows.Count != 0)
            {
                table.DR = table.DT.Rows[0];
            }
            if ((table.DT.Rows.Count != 0) & !(Convert.ToDouble(table.DR["Big_Fruit1"].ToString()) == 0.0))
            {
                if ((num >= Convert.ToDouble(table.DR["Loose1"].ToString())) & (num <= Convert.ToDouble(table.DR["Loose2"].ToString())))
                {
                    strArray[0] = "M";
                    strArray[1] = "Pure Fruit";
                }
                else if ((num >= Convert.ToDouble(table.DR["Big_Fruit1"].ToString())) & (num <= Convert.ToDouble(table.DR["Big_Fruit2"].ToString())))
                {
                    strArray[0] = "B";
                    strArray[1] = "Big Size";
                }
                else if ((num >= Convert.ToDouble(table.DR["Mid_Fruit1"].ToString())) & (num <= Convert.ToDouble(table.DR["Mid_Fruit2"].ToString())))
                {
                    strArray[0] = "S";
                    strArray[1] = "Medium Size";
                }
                else if ((num >= Convert.ToDouble(table.DR["Sml_Fruit1"].ToString())) & (num <= Convert.ToDouble(table.DR["Sml_Fruit2"].ToString())))
                {
                    strArray[0] = "K";
                    strArray[1] = "Small Size";
                }
                else if ((num >= Convert.ToDouble(table.DR["Scout1"].ToString())) & (num <= Convert.ToDouble(table.DR["Scout2"].ToString())))
                {
                    strArray[0] = "R";
                    strArray[1] = "Krastasi";
                }
            }
            else if ((num >= Convert.ToDouble(tblLocation.DR["Loose1"].ToString())) & (num <= Convert.ToDouble(tblLocation.DR["Loose2"].ToString())))
            {
                strArray[0] = "M";
                strArray[1] = "Pure Fruit";
            }
            else if ((num >= Convert.ToDouble(tblLocation.DR["Big_Fruit1"].ToString())) & (num <= Convert.ToDouble(tblLocation.DR["Big_Fruit2"].ToString())))
            {
                strArray[0] = "B";
                strArray[1] = "Big Size";
            }
            else if ((num >= Convert.ToDouble(tblLocation.DR["Mid_Fruit1"].ToString())) & (num <= Convert.ToDouble(tblLocation.DR["Mid_Fruit2"].ToString())))
            {
                strArray[0] = "S";
                strArray[1] = "Medium Size";
            }
            else if ((num >= Convert.ToDouble(tblLocation.DR["Sml_Fruit1"].ToString())) & (num <= Convert.ToDouble(tblLocation.DR["Sml_Fruit2"].ToString())))
            {
                strArray[0] = "K";
                strArray[1] = "Small Size";
            }
            else if ((num >= Convert.ToDouble(tblLocation.DR["Scout1"].ToString())) & (num <= Convert.ToDouble(tblLocation.DR["Scout2"].ToString())))
            {
                strArray[0] = "R";
                strArray[1] = "Krastasi";
            }
            table.Dispose();
            return strArray;
        }

        public static void GetADChangePasswordLink()
        {
            ADChangePasswordLink = new WBCondition().getConditionValueWithoutCoyLoc("SUPPORT_AD_RECOVERY_PATH", "description");
        }

        public static void GetConditionAD()
        {
            WBCondition condition = new WBCondition();
            loginWithActiveDirectory = condition.getSettingConditionWithoutCoyLoc("LOGIN_WITH_ACTIVE_DIRECTORY");
            ADPath = condition.getConditionValueWithoutCoyLoc("LOGIN_WITH_ACTIVE_DIRECTORY", "description");
            ADPrincipal = condition.getConditionValueWithoutCoyLoc("ACTIVE_DIRECTORY_PRINCIPAL", "description");
            if ((ADPath == null) || (ADPath == ""))
            {
                ADPath = "LDAP://wil.local";
            }
        }

        private static int getValue(string pStr)
        {
            int num;
            try
            {
                int length = Length;
                if (pStr.ToUpper().IndexOf("KG", 0) <= -1)
                {
                    num = Convert.ToInt32(pStr.Substring(Start_Get - 1, Length));
                }
                else
                {
                    int startIndex = (pStr.ToUpper().IndexOf("KG", 0) - beforeKG) - length;
                    num = Convert.ToInt32(pStr.Substring(startIndex, length));
                }
            }
            catch
            {
                return -999;
            }
            return num;
        }

        public static void OpenSetting()
        {
            tblSetting = new WBTable();
            tblLocation = new WBTable();
            tblSetting.OpenTable("wb_setting", "Select * from wb_setting where " + WBData.CompanyLocation(" and wbCode = '" + WBData.sWBCode + "'"), WBData.conn);
            tblLocation.OpenTable("wb_location", "Select * From wb_location where " + WBData.CompanyLocation(""), WBData.conn);
            tblLocation.DR = tblLocation.DT.Rows[0];
            tblSetting.DR = tblSetting.DT.Rows[0];
            SetorVar();
        }

        public static void OpenSetting(bool reset)
        {
            tblSetting = new WBTable();
            tblLocation = new WBTable();
            tblSetting.OpenTable("wb_setting", "Select * from wb_setting where " + WBData.CompanyLocation(" and wbCode = '" + WBData.sWBCode + "'"), WBData.conn);
            tblLocation.OpenTable("wb_location", "Select * From wb_location where " + WBData.CompanyLocation(""), WBData.conn);
            if (tblSetting.DT.Rows.Count > 0)
            {
                tblLocation.DR = tblLocation.DT.Rows[0];
                tblSetting.DR = tblSetting.DT.Rows[0];
                SetorVar();
            }
            else
            {
                FormSetting setting = new FormSetting();
                setting.f_load();
                setting.f_save();
                setting.Dispose();
                OpenSetting();
            }
        }

        public static void ReOpen()
        {
            tblLocation.ReOpen();
            tblSetting.ReOpen();
            tblLocation.DR = tblLocation.DT.Rows[0];
            tblSetting.DR = tblSetting.DT.Rows[0];
            SetorVar();
        }

        private static void SetorVar()
        {
            CommPort = tblSetting.DR["Comm_Port"].ToString();
            BaudRate = tblSetting.DR["Baudrate"].ToString();
            DataBits = tblSetting.DR["Data_Bit"].ToString();
            parity = tblSetting.DR["Parity"].ToString();
            Stopbits = tblSetting.DR["Stop_Bit"].ToString();
            cpuSAP = tblSetting.DR["schSAP"].ToString();
            try
            {
                Start_Get = Convert.ToInt32(tblSetting.DR["Start_Get"].ToString().Trim());
                Length = Convert.ToInt32(tblSetting.DR["Length"].ToString().Trim());
                Buffer = Convert.ToInt32(tblSetting.DR["Buffer"].ToString().Trim());
                beforeKG = Convert.ToInt32(tblSetting.DR["BeforeKG"].ToString().Trim());
            }
            catch
            {
            }
            WB_Type = "5";
            WBCode = tblSetting.DR["WBCode"].ToString();
            GrCustRequired = tblLocation.DR["GrCustRequired"].ToString();
            bGate = tblSetting.DR["barrierGate"].ToString();
            gate1Close = tblSetting.DR["Barrier1Close"].ToString();
            gate1Open = tblSetting.DR["Barrier1Open"].ToString();
            gate2Open = tblSetting.DR["Barrier2Open"].ToString();
            gate2Close = tblSetting.DR["Barrier2Close"].ToString();
            gate1CloseOut = tblSetting.DR["Barrier1CloseOut"].ToString();
            gate1OpenOut = tblSetting.DR["Barrier1OpenOut"].ToString();
            gate2OpenOut = tblSetting.DR["Barrier2OpenOut"].ToString();
            gate2CloseOut = tblSetting.DR["Barrier2CloseOut"].ToString();
            gateType = tblSetting.DR["BarrierType"].ToString();
            gate1IP = tblSetting.DR["barrierIP1"].ToString();
            gate1Port = tblSetting.DR["barrierPort1"].ToString();
            gate2IP = tblSetting.DR["barrierIP2"].ToString();
            gate2Port = tblSetting.DR["barrierPort2"].ToString();
            gate1IPOut = tblSetting.DR["barrierIP1Out"].ToString();
            gate1PortOut = tblSetting.DR["barrierPort1Out"].ToString();
            gate2IPOut = tblSetting.DR["barrierIP2Out"].ToString();
            gate2PortOut = tblSetting.DR["barrierPort2Out"].ToString();
            GMSend = tblSetting.DR["GMSend"].ToString();
            sCheckDirect = tblSetting.DR["directToPrinter"].ToString();
            cam1 = tblSetting.DR["cam1"].ToString();
            cam1_type = tblSetting.DR["cam1_type"].ToString();
            cam1_web = tblSetting.DR["cam1_web"].ToString();
            cam1_ip_name = tblSetting.DR["cam1_ip_name"].ToString();
            cam2 = tblSetting.DR["cam2"].ToString();
            cam2_type = tblSetting.DR["cam2_type"].ToString();
            cam2_web = tblSetting.DR["cam2_web"].ToString();
            cam2_ip_name = tblSetting.DR["cam2_ip_name"].ToString();
            cam3 = tblSetting.DR["cam3"].ToString();
            cam3_type = tblSetting.DR["cam3_type"].ToString();
            cam3_web = tblSetting.DR["cam3_web"].ToString();
            cam3_ip_name = tblSetting.DR["cam3_ip_name"].ToString();
            cam4 = tblSetting.DR["cam4"].ToString();
            cam4_type = tblSetting.DR["cam4_type"].ToString();
            cam4_web = tblSetting.DR["cam4_web"].ToString();
            cam4_ip_name = tblSetting.DR["cam4_ip_name"].ToString();
            cam5 = tblSetting.DR["cam5"].ToString();
            cam5_type = tblSetting.DR["cam5_type"].ToString();
            cam5_web = tblSetting.DR["cam5_web"].ToString();
            cam5_ip_name = tblSetting.DR["cam5_ip_name"].ToString();
            reg_Line = tblSetting.DR["reg_Line"].ToString();
            reg_feedback = tblSetting.DR["reg_feedback"].ToString();
            reg_length = tblSetting.DR["Reg_Length"].ToString();
            start_address = tblSetting.DR["Start_Address"].ToString();
            colour = tblLocation.DR["Colour"].ToString();
            zwb = tblLocation.DR["zwb"].ToString();
            sLocName = tblLocation.DR["Location_Name"].ToString();
            SAPsch = tblLocation.DR["SAPSchedule"].ToString();
            SAPTime = tblLocation.DR["SAPtime"].ToString();
            Check_Tare_MinTrans = (tblLocation.DR["Check_Tare_MinTrans"].ToString() == "") ? 0 : Convert.ToInt32(tblLocation.DR["Check_Tare_MinTrans"].ToString());
            CoySAP = tblLocation.DR["CoySAP"].ToString();
            SAPInterval = tblLocation.DR["SAPINterval"].ToString();
            AutoSyncInterval = tblLocation.DR["AutoSyncInterval"].ToString();
            startTime = tblLocation.DR["Time_Begin"].ToString();
            ticket = Application.StartupPath.ToString() + @"\Report\" + tblLocation.DR["ticket"].ToString();
            loading_advise = Application.StartupPath.ToString() + @"\Report\" + tblLocation.DR["loading_advise"].ToString();
            ticketGatepass = Application.StartupPath.ToString() + @"\Report\" + tblLocation.DR["ticketGatepass"].ToString();
            if (File.Exists(Application.StartupPath.ToString() + @"\Report\TicketRefinery_MultiLine1.rpt") && File.Exists(Application.StartupPath.ToString() + @"\Report\TicketRefinery_MultiLine2.rpt"))
            {
                ticket_MultiLine1 = Application.StartupPath.ToString() + @"\Report\TicketRefinery_MultiLine1.rpt";
                ticket_MultiLine2 = Application.StartupPath.ToString() + @"\Report\TicketRefinery_MultiLine2.rpt";
            }
            ticketLangsir = Application.StartupPath.ToString() + @"\Report\TicketLangsir.rpt";
            ticketLangsir2 = Application.StartupPath.ToString() + @"\Report\TicketLangsir2.rpt";
            locType = tblLocation.DR["location_type"].ToString();
            copyToLoc = tblLocation.DR["CopyToLoc"].ToString();
            AutoCloseDO = tblLocation.DR["AutoCloseDO"].ToString();
            Check_Zero = tblLocation.DR["Indicator"].ToString();
            Container = tblLocation.DR["Container"].ToString();
            Trailer = tblLocation.DR["Trailer"].ToString();
            NonContract = (tblLocation.DR["NonContract"].ToString() == "Y") ? "Y" : "N";
            Ref6 = tblLocation.DR["Ref6"].ToString();
            region = (tblLocation.DR["Region"].ToString() == "") ? "0" : tblLocation.DR["Region"].ToString();
            transflow = (tblLocation.DR["transflow"].ToString() == "") ? "1" : tblLocation.DR["transflow"].ToString();
            KB = tblLocation.DR["KB"].ToString();
            sTACode = tblLocation.DR["TACode"].ToString();
            sGatepassCode = tblLocation.DR["GatepassCode"].ToString();
            GrossWeightControl = tblLocation.DR["GrossWeightControl"].ToString();
            OutgoingTransControl = tblLocation.DR["OutgoingTransControl"].ToString();
            chkZeroMode = tblLocation.DR["checkIndMode"].ToString();
            grossHistoryControl = (tblLocation.DR["GrossHistoryControl"].ToString() == "Y") ? "Y" : "N";
            grossHistoryVariance = Program.StrToDouble(tblLocation.DR["GrossHistoryVariance"].ToString(), 0);
            grossHistoryMinute = (int) Program.StrToDouble(tblLocation.DR["GrossHistoryMinute"].ToString(), 0);
            checkOutSpec = tblLocation.DR["checkOutSpec"].ToString();
            camera_feature = (tblLocation.DR["camera_feature"].ToString() == "Y") ? "Y" : "N";
            camera_path = tblLocation.DR["camera_path"].ToString();
            camera_domain = tblLocation.DR["cameraDomainFolder"].ToString();
            camera_username = tblLocation.DR["cameraUsernameFolder"].ToString();
            camera_password = WBEncryption.Decrypt(tblLocation.DR["cameraPasswordFolder"].ToString());
            PLC_IP = tblLocation.DR["PLC_IP"].ToString();
            PLC_Port = tblLocation.DR["PLC_Port"].ToString();
            weighingAnalysis = (tblLocation.DR["BM"].ToString() == "") ? "0" : tblLocation.DR["BM"].ToString();
            rangeFlagColor = tblLocation.DR["rangeFlagColor"].ToString();
            EG_Server = tblLocation.DR["EGrading_IP"].ToString();
            EG_Database = tblLocation.DR["EGrading_Database"].ToString();
            Intg_Database = tblLocation.DR["Intg_Database"].ToString();
            EG_usID = tblLocation.DR["EGrading_UserID"].ToString();
            EG_password = Program.shoot(tblLocation.DR["EGrading_Pass"].ToString(), false);
            mulesoft_ID = tblLocation.DR["client_id"].ToString();
            mulesoft_Key = tblLocation.DR["client_key"].ToString();
            WBCondition condition = new WBCondition();
            print_loading_advise = condition.getSettingCondition("PRINT_LOADING_ADVISE");
            print_gatepass_advise = condition.getSettingCondition("PRINT_GATEPASS_ADVISE");
            print_on_2nd_weight_4x = condition.getSettingCondition("PRINT_ON_2ND_WEIGHT_4X");
            default_delivery_note_for_split = condition.getSettingCondition("DEFAULT_DELIVERY_NOTE_FOR_SPLIT");
            wb_filling_location = condition.getSettingCondition("WB_FILLING_LOCATION");
            wb_control_valve = condition.getSettingCondition("WB_CONTROL_VALVE");
            reason_reprint_ticket = condition.getSettingCondition("REASON_REPRINT_TICKET");
            over_tare_for_nx = condition.getSettingConditionWithoutCoyLoc("OVER_TARE_FOR_NX_TRANSACTION");
            max_tare_for_nx = condition.getConditionValueWithoutCoyLoc("OVER_TARE_FOR_NX_TRANSACTION", "description");
            dummy_contract_on_registration = condition.getSettingCondition("DUMMY_CONTRACT_ON_REGISTRATION");
            if (dummy_contract_on_registration)
            {
                dummy_contract = condition.getConditionValue("DUMMY_CONTRACT_ON_REGISTRATION", "do_no");
                dummy_comm_code = condition.getConditionValue("DUMMY_CONTRACT_ON_REGISTRATION", "comm_code");
            }
            AutoCapture = condition.getSettingCondition("AUTO_CAPTURE");
            adopt_zdotrx = condition.getSettingCondition("ACTIVE_ADOPT_ZDOTRX");
            gatepass_registration = condition.getSettingCondition("GATEPASS_REGISTRATION");
            gatepassWithoutCard = condition.getSettingCondition("GATEPASS_WITHOUT_CARD");
            unlockWeighingMenu = condition.getSettingCondition("UNLOCK_WEIGHING_MENU");
            IntegrationSAP = condition.getSettingCondition("IntegrationSAP") ? "Y" : "N";
            Allow_Entry_Tandan = condition.getSettingCondition("ALLOW_ENTRY_TANDAN");
            gatepass_auto_submit = condition.getSettingCondition("GATEPASS_AUTO_SUBMIT");
            SAP_Application_Server = condition.getSettingCondition("SAP_APPLICATION_SERVER");
            SAP_Group_Server = condition.getSettingCondition("SAP_GROUP_SERVER");
            activeTCS = condition.getSettingCondition("ACTIVE_TCS");
            getQCfromTCS = condition.getSettingCondition("GET_QC_FROM_TCS");
            activeEGrading = condition.getSettingCondition("EGrading");
            activeSMSToken = condition.getSettingCondition("SMS_TOKEN");
            activeBC = condition.getSettingCondition("ACTIVE_BC");
            activeEncryptExport = condition.getSettingCondition("ACTIVE_ENCRYPT_EXPORT");
            encryptRecipient = condition.getConditionValue("ACTIVE_ENCRYPT_EXPORT", "Description");
            activeMulesoftIntegration = condition.getSettingCondition("ACTIVE_MULESOFT_INTEGRATION");
            token_path = condition.getConditionValue("SMS_TOKEN", "Description");
            Cut_Off_Location = condition.getSettingCondition("CUT_OFF_LOCATION");
            activeRegistrationRequireLicensePhoto = condition.getSettingConditionWithoutCoyLoc("ACTIVE_REGISTRATION_REQUIRE_LICENSE_PHOTO");
            licensePhoto_path = condition.getConditionValueWithoutCoyLoc("ACTIVE_REGISTRATION_REQUIRE_LICENSE_PHOTO", "description");
            integrationIDSYS = condition.getSettingCondition("INTEGRATION_IDSYS");
            if (integrationIDSYS)
            {
            }
            string str = "";
            activeOverLossToleranceControlbyNet = condition.getSettingCondition("CHECK_OVER_LOSS_TOLERANCE_BY_NET");
            str = condition.getConditionValue("CHECK_OVER_LOSS_TOLERANCE_BY_NET", "Description");
            toleranceForOverLossControlbyNet = (str == "") ? 0.0 : Convert.ToDouble(str);
            activeOverLossToleranceControlbyGross = condition.getSettingCondition("CHECK_OVER_LOSS_TOLERANCE_BY_GROSS");
            str = condition.getConditionValue("CHECK_OVER_LOSS_TOLERANCE_BY_GROSS", "Description");
            toleranceForOverLossControlbyGross = (str == "") ? 0.0 : Convert.ToDouble(str);
            allowDecimalLoadingQty = condition.getSettingCondition("ALLOW_DECIMAL_LOADING_QTY");
            condition.Dispose();
            if ((Check_Zero == "Y") && (chkZeroMode == ""))
            {
                chkZeroMode = "12";
            }
            if (Ref6 == "Y")
            {
                date6 = tblLocation.DR["DateRef6"].ToString();
            }
            checkISCC = tblLocation.DR["ISCC_Checked"].ToString();
            if (checkISCC == "Y")
            {
                validDateISCC = Convert.ToDateTime(tblLocation.DR["ISCC_Valid_Date"].ToString());
            }
            DeliveryNoteExpiredDuration = Convert.ToInt32(string.IsNullOrEmpty(tblLocation.DR["dn_expired_duration"].ToString()) ? "3" : tblLocation.DR["dn_expired_duration"].ToString());
            DeliveryNoteCutOff = condition.getSettingCondition("CUT_OFF_DELIVERY_NOTE");
            if (DeliveryNoteCutOff)
            {
                DeliveryNoteCutOffDate = Convert.ToDateTime(condition.getConditionValue("CUT_OFF_DELIVERY_NOTE", "description").ToString());
            }
        }

        public static bool Tanker() => 
            tblSetting.DR["Check_Tanker"].ToString() != "";

        public static double TareTolerance() => 
            Convert.ToDouble(tblLocation.DR["Tol_Tare"].ToString());

        public static string WBType() => 
            tblSetting.DR["WB_Type"].ToString();

        public static string WorkingTime(string pDate, string pTime)
        {
            string str = pDate;
            if ((Field("Time_Default") == "N") && (Convert.ToDateTime(pTime) < Convert.ToDateTime(Field("Time_Begin"))))
            {
                str = Convert.ToDateTime(pDate).AddDays(-1.0).ToString();
            }
            return str;
        }
    }
}

