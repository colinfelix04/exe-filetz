﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormYieldEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        private IContainer components = null;
        private Button button2;
        private Button button1;
        private TextBox textBox2;
        private Label label2;
        private Label label1;
        private Label label3;
        private ShapeContainer shapeContainer1;
        private ToolTip toolTip1;
        public TextBox textBox1;
        private RadioButton radioChar;
        private RadioButton radioNumber;
        private RectangleShape rectangleShape1;
        private Label label4;
        public TextBox textSAP;

        public FormYieldEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            TextBox[] aText = new TextBox[] { this.textBox1, this.textBox2 };
            if (!Program.CheckEmpty(aText))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_yield", "Select Uniq From wb_yield Where " + WBData.CompanyLocation(" and (yield_Code='" + this.textBox1.Text.Trim() + "')"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    Cursor.Current = Cursors.WaitCursor;
                    this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                    if ((this.pMode != "EDIT") || (this.textBox1.Text.Trim() == this.OldCode.Trim()))
                    {
                        goto TR_0016;
                    }
                    else
                    {
                        table2 = new WBTable();
                        table2.OpenTable("wb_commodity_detail", "Select uniq From wb_commodity_detail where " + WBData.CompanyLocation(" and ( QCode='" + this.OldCode.Trim() + "')"), WBData.conn);
                        WBTable table3 = new WBTable();
                        table3.OpenTable("wb_TransactionD", "Select uniq From wb_TransactionD where " + WBData.CompanyLocation(" and ( Code='" + this.OldCode.Trim() + "') and (Type='0' or Type='S')"), WBData.conn);
                        Cursor.Current = Cursors.Default;
                        if ((table2.DT.Rows.Count <= 0) && (table3.DT.Rows.Count <= 0))
                        {
                            goto TR_0017;
                        }
                        else
                        {
                            string[] textArray1 = new string[0x11];
                            textArray1[0] = Resource.Mes_489;
                            textArray1[1] = " ";
                            textArray1[2] = this.OldCode;
                            textArray1[3] = " -> ";
                            textArray1[4] = this.textBox1.Text;
                            textArray1[5] = "\n\n";
                            textArray1[6] = Resource.Msg_Replace_Warning;
                            textArray1[7] = "  - ";
                            textArray1[8] = table2.DT.Rows.Count.ToString();
                            textArray1[9] = " ";
                            textArray1[10] = Resource.Mes_Records_In_Master;
                            textArray1[11] = "\n  - ";
                            textArray1[12] = table3.DT.Rows.Count.ToString();
                            textArray1[13] = " ";
                            textArray1[14] = Resource.Mes_Records_In_Transaction;
                            textArray1[15] = "\n\n";
                            textArray1[0x10] = Resource.Msg_Continue;
                            if (MessageBox.Show(string.Concat(textArray1), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.ReplaceAll = true;
                                goto TR_0017;
                            }
                            else
                            {
                                this.ReplaceAll = false;
                                this.textBox1.Focus();
                            }
                        }
                    }
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_240);
                    this.textBox1.Focus();
                }
            }
            return;
        TR_0016:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.Lbl_Yield_Code },
                    textRefNo = { Text = this.textBox1.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            this.zTable.ReOpen();
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Yield_Code"] = this.textBox1.Text;
            this.zTable.DR["Yield_Name"] = this.textBox2.Text;
            this.zTable.DR["Type"] = this.radioNumber.Checked ? "1" : "0";
            this.zTable.DR["SAP_Code"] = this.textSAP.Text;
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table4 = new WBTable();
                    table4.OpenTable("wb_yield", "SELECT uniq FROM wb_yield WHERE " + WBData.CompanyLocation(" AND yield_code = '" + this.textBox1.Text + "'"), WBData.conn);
                    this.logKey = table4.DT.Rows[0]["uniq"].ToString();
                    table4.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_yield", this.logKey, logField, logValue);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string[] aField = new string[] { "QCode", "QName" };
                string[] aNewValue = new string[] { this.textBox1.Text, this.textBox2.Text };
                Program.ReplaceAll("wb_commodity_detail", aField, aNewValue, " QCode='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit yield master data)");
                string[] textArray6 = new string[] { "Code", "Name" };
                string[] textArray7 = new string[] { this.textBox1.Text, this.textBox2.Text };
                Program.ReplaceAll("wb_TransactionD", textArray6, textArray7, " (Code='" + this.OldCode.Trim() + "') and (Type='0' or Type='S')", this.changeReason + " (Edit yield master data)");
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            base.Close();
            return;
        TR_0017:
            table2.Dispose();
            goto TR_0016;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormYieldEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormYieldEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.pMode == "ADD")
            {
                this.textSAP.Enabled = WBUser.UserGroup == "ADMIN";
            }
            else
            {
                this.textBox1.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Yield_Code"].Value.ToString();
                this.OldCode = this.textBox1.Text;
                this.textBox2.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Yield_Name"].Value.ToString();
                if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Type"].Value.ToString() == "1")
                {
                    this.radioNumber.Checked = true;
                }
                else if (this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Type"].Value.ToString() == "0")
                {
                    this.radioChar.Checked = true;
                }
                this.textSAP.Enabled = WBUser.UserGroup == "ADMIN";
                this.textSAP.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["SAP_Code"].Value.ToString();
            }
            if (this.pMode == "VIEW")
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.button2.Enabled = true;
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.button2 = new Button();
            this.button1 = new Button();
            this.textBox2 = new TextBox();
            this.textBox1 = new TextBox();
            this.label2 = new Label();
            this.label1 = new Label();
            this.label3 = new Label();
            this.shapeContainer1 = new ShapeContainer();
            this.rectangleShape1 = new RectangleShape();
            this.toolTip1 = new ToolTip(this.components);
            this.radioChar = new RadioButton();
            this.radioNumber = new RadioButton();
            this.label4 = new Label();
            this.textSAP = new TextBox();
            base.SuspendLayout();
            this.button2.Location = new Point(0x157, 0xa5);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 4;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0xf4, 0xa5);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 3;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBox2.Location = new Point(0x55, 0x31);
            this.textBox2.MaxLength = 50;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x14d, 20);
            this.textBox2.TabIndex = 1;
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(0x55, 0x16);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0xa5, 20);
            this.textBox1.TabIndex = 0;
            this.label2.Location = new Point(12, 0x34);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x43, 13);
            this.label2.TabIndex = 0x48;
            this.label2.Text = "QC Name";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.label1.Location = new Point(12, 0x19);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x43, 13);
            this.label1.TabIndex = 0x47;
            this.label1.Text = "QC Code";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.label3.Location = new Point(12, 0x52);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x43, 13);
            this.label3.TabIndex = 0x4a;
            this.label3.Text = "QC Type";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.label3, "1 = Number Value, 0 = Char Value");
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.rectangleShape1 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(0x1c7, 200);
            this.shapeContainer1.TabIndex = 0x4b;
            this.shapeContainer1.TabStop = false;
            this.rectangleShape1.Location = new Point(0x56, 0x4a);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new Size(0x65, 0x33);
            this.radioChar.AutoSize = true;
            this.radioChar.Location = new Point(0x62, 80);
            this.radioChar.Name = "radioChar";
            this.radioChar.Size = new Size(0x4c, 0x11);
            this.radioChar.TabIndex = 0x4c;
            this.radioChar.TabStop = true;
            this.radioChar.Text = "Characters";
            this.toolTip1.SetToolTip(this.radioChar, "Support Characters");
            this.radioChar.UseVisualStyleBackColor = true;
            this.radioNumber.AutoSize = true;
            this.radioNumber.Location = new Point(0x62, 0x67);
            this.radioNumber.Name = "radioNumber";
            this.radioNumber.Size = new Size(0x3e, 0x11);
            this.radioNumber.TabIndex = 0x4d;
            this.radioNumber.TabStop = true;
            this.radioNumber.Text = "Number";
            this.toolTip1.SetToolTip(this.radioNumber, "Support only number ##.###");
            this.radioNumber.UseVisualStyleBackColor = true;
            this.label4.Location = new Point(12, 0x86);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x43, 13);
            this.label4.TabIndex = 0x4e;
            this.label4.Text = "SAP Code";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.label4, "1 = Number Value, 0 = Char Value");
            this.textSAP.CharacterCasing = CharacterCasing.Upper;
            this.textSAP.Enabled = false;
            this.textSAP.Location = new Point(0x55, 0x83);
            this.textSAP.MaxLength = 20;
            this.textSAP.Name = "textSAP";
            this.textSAP.Size = new Size(0xa5, 20);
            this.textSAP.TabIndex = 0x4f;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1c7, 200);
            base.ControlBox = false;
            base.Controls.Add(this.textSAP);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.radioNumber);
            base.Controls.Add(this.radioChar);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.shapeContainer1);
            base.Name = "FormYieldEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormYieldEntry";
            base.Load += new EventHandler(this.FormYieldEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormYieldEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label3.Text = Resource.Yield_001;
            this.label1.Text = Resource.Yield_002;
            this.label2.Text = Resource.Yield_003;
            this.radioNumber.Text = Resource.Yield_004;
            this.radioChar.Text = Resource.Yield_005;
            this.label4.Text = Resource.Block_008;
            this.button2.Text = Resource.Btn_Cancel;
            this.button1.Text = Resource.Btn_Save;
        }
    }
}

