﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTemplateSAPPosition : Form
    {
        private string sqlText;
        private string strA;
        private string strB;
        private string changeReason = "";
        private string[] logKey;
        private WBTable tbl_templateSAP = new WBTable();
        private int[,] pos;
        private int rcount;
        private IContainer components = null;
        public NumericUpDown numericBoxType;
        private Label label9;
        private Label label8;
        public ComboBox comboBoxModuleName;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        public ToolStripMenuItem menuClose;
        private Button buttonUp;
        private Button buttonDown;
        private ListBox listBox1;

        public FormTemplateSAPPosition()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void activitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.simpan();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int selectedIndex = this.listBox1.SelectedIndex;
            if ((selectedIndex - 1) >= 0)
            {
                this.strA = this.listBox1.Items[selectedIndex - 1].ToString();
                this.strB = this.listBox1.Items[selectedIndex].ToString();
                string str = this.strA.Substring(0, 3);
                string str2 = this.strB.Substring(0, 3);
                this.strA = str2 + this.strA.Substring(3, this.strA.Length - 3);
                this.strB = str + this.strB.Substring(3, this.strB.Length - 3);
                this.listBox1.Items[selectedIndex - 1] = this.strB;
                this.listBox1.Items[selectedIndex] = this.strA;
                this.listBox1.SelectedIndex = selectedIndex - 1;
                int num2 = this.pos[selectedIndex, 1];
                this.pos[selectedIndex, 1] = this.pos[selectedIndex - 1, 1];
                this.pos[selectedIndex - 1, 1] = num2;
            }
        }

        private void buttonDown_Click(object sender, EventArgs e)
        {
            int selectedIndex = this.listBox1.SelectedIndex;
            if ((selectedIndex + 1) <= (this.listBox1.Items.Count - 1))
            {
                this.strA = this.listBox1.Items[selectedIndex].ToString();
                this.strB = this.listBox1.Items[selectedIndex + 1].ToString();
                string str = this.strA.Substring(0, 3);
                string str2 = this.strB.Substring(0, 3);
                this.strA = str2 + this.strA.Substring(3, this.strA.Length - 3);
                this.strB = str + this.strB.Substring(3, this.strB.Length - 3);
                this.listBox1.Items[selectedIndex] = this.strB;
                this.listBox1.Items[selectedIndex + 1] = this.strA;
                this.listBox1.SelectedIndex = selectedIndex + 1;
                this.pos[selectedIndex, 0] = Convert.ToInt16(str.Trim());
                this.pos[selectedIndex + 1, 0] = Convert.ToInt16(str2.Trim());
                int num2 = this.pos[selectedIndex, 1];
                this.pos[selectedIndex, 1] = this.pos[selectedIndex + 1, 1];
                this.pos[selectedIndex + 1, 1] = num2;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTemplateSAPPosition_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.menuClose.PerformClick();
            }
        }

        private void FormTemplateSAPPosition_Load(object sender, EventArgs e)
        {
            this.comboBoxModuleName.Enabled = false;
            this.numericBoxType.Enabled = false;
            string[] textArray1 = new string[] { "Select * From wb_templateSAP where ", WBData.CompanyLocation(""), " and modul = '", this.comboBoxModuleName.Text, "'  and type = '", this.numericBoxType.Value.ToString().Trim(), "' order by column_numbering" };
            this.sqlText = string.Concat(textArray1);
            this.tbl_templateSAP.OpenTable("wb_templateSAP", this.sqlText, WBData.conn);
            this.rcount = this.tbl_templateSAP.DT.Rows.Count;
            this.pos = new int[this.rcount, 2];
            int num2 = 0;
            while (true)
            {
                if (num2 >= this.rcount)
                {
                    this.listBox1.SelectedIndex = 0;
                    return;
                }
                this.tbl_templateSAP.DR = this.tbl_templateSAP.DT.Rows[num2];
                this.listBox1.Items.Add(this.tbl_templateSAP.DR["column_numbering"].ToString().PadLeft(3, ' ') + ".".PadRight(3, ' ') + this.tbl_templateSAP.DR["title_excel"].ToString().Trim().ToUpper());
                this.pos[num2, 0] = Convert.ToInt16(this.tbl_templateSAP.DR["column_numbering"].ToString());
                this.pos[num2, 1] = Convert.ToInt16(this.tbl_templateSAP.DR["uniq"].ToString());
                num2++;
            }
        }

        private void InitializeComponent()
        {
            this.numericBoxType = new NumericUpDown();
            this.label9 = new Label();
            this.label8 = new Label();
            this.comboBoxModuleName = new ComboBox();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.menuClose = new ToolStripMenuItem();
            this.buttonUp = new Button();
            this.buttonDown = new Button();
            this.listBox1 = new ListBox();
            this.numericBoxType.BeginInit();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.numericBoxType.Location = new Point(170, 0x35);
            this.numericBoxType.Name = "numericBoxType";
            this.numericBoxType.Size = new Size(0x37, 20);
            this.numericBoxType.TabIndex = 0x10;
            int[] bits = new int[4];
            bits[0] = 1;
            this.numericBoxType.Value = new decimal(bits);
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0xa7, 0x22);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x1f, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Type";
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0x16, 0x22);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x2a, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Module";
            this.comboBoxModuleName.FormattingEnabled = true;
            object[] items = new object[] { "MM", "SD" };
            this.comboBoxModuleName.Items.AddRange(items);
            this.comboBoxModuleName.Location = new Point(0x19, 0x34);
            this.comboBoxModuleName.Name = "comboBoxModuleName";
            this.comboBoxModuleName.Size = new Size(0x79, 0x15);
            this.comboBoxModuleName.TabIndex = 13;
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.menuClose };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x193, 0x18);
            this.menuStrip1.TabIndex = 0x17;
            this.menuStrip1.Text = "menuStrip1";
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x2b, 20);
            this.activitiesToolStripMenuItem.Text = "&Save";
            this.activitiesToolStripMenuItem.Click += new EventHandler(this.activitiesToolStripMenuItem_Click);
            this.menuClose.Name = "menuClose";
            this.menuClose.Size = new Size(0x30, 20);
            this.menuClose.Text = "&Close";
            this.menuClose.Click += new EventHandler(this.menuClose_Click);
            this.buttonUp.Location = new Point(0x13a, 0x4f);
            this.buttonUp.Name = "buttonUp";
            this.buttonUp.Size = new Size(0x4b, 0x2b);
            this.buttonUp.TabIndex = 0x19;
            this.buttonUp.Text = "Up";
            this.buttonUp.UseVisualStyleBackColor = true;
            this.buttonUp.Click += new EventHandler(this.button1_Click);
            this.buttonDown.Location = new Point(0x13a, 0x9b);
            this.buttonDown.Name = "buttonDown";
            this.buttonDown.Size = new Size(0x4b, 0x2b);
            this.buttonDown.TabIndex = 0x1a;
            this.buttonDown.Text = "Down";
            this.buttonDown.UseVisualStyleBackColor = true;
            this.buttonDown.Click += new EventHandler(this.buttonDown_Click);
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new Point(0x1a, 0x4f);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new Size(0x11a, 0x1d8);
            this.listBox1.TabIndex = 0x1b;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x193, 0x246);
            base.ControlBox = false;
            base.Controls.Add(this.listBox1);
            base.Controls.Add(this.buttonDown);
            base.Controls.Add(this.buttonUp);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.numericBoxType);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.comboBoxModuleName);
            base.KeyPreview = true;
            base.Name = "FormTemplateSAPPosition";
            this.Text = "formtra";
            base.Load += new EventHandler(this.FormTemplateSAPPosition_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTemplateSAPPosition_KeyPress);
            this.numericBoxType.EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void menuClose_Click(object sender, EventArgs e)
        {
            this.tbl_templateSAP.Dispose();
            base.Close();
        }

        private void simpan()
        {
            Cursor.Current = Cursors.Default;
            FormTransCancel cancel = new FormTransCancel {
                label1 = { Text = Resource.Lbl_Module },
                textRefNo = { Text = this.comboBoxModuleName.Text },
                Text = Resource.Title_Change_Reason,
                label2 = { Text = Resource.Lbl_Change_Reason + " : " }
            };
            cancel.textReason.Focus();
            cancel.ShowDialog();
            if (cancel.Saved)
            {
                this.changeReason = cancel.textReason.Text;
                cancel.Dispose();
                this.logKey = new string[this.rcount];
                int index = 0;
                while (true)
                {
                    if (index >= this.rcount)
                    {
                        this.tbl_templateSAP.Save();
                        int num3 = 0;
                        while (true)
                        {
                            if (num3 >= this.logKey.Length)
                            {
                                this.tbl_templateSAP.Dispose();
                                base.Close();
                                break;
                            }
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "EDIT", WBUser.UserID, this.changeReason };
                            Program.updateLogHeader("wb_templateSAP", this.logKey[num3], logField, logValue);
                            num3++;
                        }
                        break;
                    }
                    string[] aField = new string[] { "uniq" };
                    string[] aFind = new string[] { this.pos[index, 1].ToString() };
                    int recNo = this.tbl_templateSAP.GetRecNo(aField, aFind);
                    this.tbl_templateSAP.DR = this.tbl_templateSAP.DT.Rows[recNo];
                    this.tbl_templateSAP.DR.BeginEdit();
                    this.logKey[index] = this.tbl_templateSAP.DR["uniq"].ToString();
                    this.tbl_templateSAP.DR["column_numbering"] = this.pos[index, 0];
                    this.tbl_templateSAP.DR.EndEdit();
                    index++;
                }
            }
        }

        private void translate()
        {
            this.label9.Text = Resource.Setting_057;
            this.label8.Text = Resource.Lbl_Module;
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Save;
            this.menuClose.Text = Resource.Btn_Close;
            this.buttonUp.Text = Resource.Btn_Up;
            this.buttonDown.Text = Resource.Btn_Down;
            this.Text = WBSetting.integrationIDSYS ? Resource.Title_Template_SAP_Position_IDSYS : Resource.Title_Template_SAP_Position;
        }
    }
}

