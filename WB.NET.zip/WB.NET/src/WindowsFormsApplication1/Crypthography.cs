﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.IO;
    using System.Security.Cryptography;
    using System.Text;

    public class Crypthography : Component
    {
        private string filePath = (Application.StartupPath + @"\winSysUtils.dll");
        private string fileString = null;
        private string fileString2 = null;

        public bool checkFile() => 
            File.Exists(this.filePath);

        public string decrypt() => 
            this.decryptData();

        public string decryptData()
        {
            string str;
            try
            {
                this.fileString = null;
                if (File.Exists(this.filePath))
                {
                    string[] strArray = File.ReadAllLines(this.filePath);
                    this.fileString = strArray[0];
                    this.fileString2 = strArray[1];
                }
                if (!File.Exists(this.filePath))
                {
                    str = "";
                }
                else
                {
                    int dwKeySize = 0x800;
                    if (this.fileString == null)
                    {
                        str = "";
                    }
                    else
                    {
                        RSACryptoServiceProvider provider = new RSACryptoServiceProvider(dwKeySize);
                        provider.FromXmlString("<RSAKeyValue><Modulus>" + this.fileString2 + "</D></RSAKeyValue>");
                        int length = (((dwKeySize / 8) % 3) != 0) ? ((((dwKeySize / 8) / 3) * 4) + 4) : (((dwKeySize / 8) / 3) * 4);
                        int num4 = this.fileString.Length / length;
                        ArrayList list = new ArrayList();
                        int num5 = 0;
                        while (true)
                        {
                            if (num5 >= num4)
                            {
                                str = Encoding.UTF32.GetString(list.ToArray(Type.GetType("System.Byte")) as byte[]);
                                break;
                            }
                            byte[] array = Convert.FromBase64String(this.fileString.Substring(length * num5, length));
                            Array.Reverse(array);
                            list.AddRange(provider.Decrypt(array, true));
                            num5++;
                        }
                    }
                }
            }
            catch (Exception)
            {
                str = "";
            }
            return str;
        }
    }
}

