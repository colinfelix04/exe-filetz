﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormProgress : Form
    {
        private IContainer components = null;
        public ProgressBar progressBar1;

        public FormProgress()
        {
            this.InitializeComponent();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormProgress_Load(object sender, EventArgs e)
        {
            this.progressBar1.Minimum = 1;
            this.progressBar1.Maximum = 100;
        }

        private void InitializeComponent()
        {
            this.progressBar1 = new ProgressBar();
            base.SuspendLayout();
            this.progressBar1.Dock = DockStyle.Fill;
            this.progressBar1.Location = new Point(0, 0);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(290, 0x12);
            this.progressBar1.TabIndex = 0;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(290, 0x12);
            base.ControlBox = false;
            base.Controls.Add(this.progressBar1);
            base.FormBorderStyle = FormBorderStyle.None;
            base.Name = "FormProgress";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "FormProgress";
            base.Load += new EventHandler(this.FormProgress_Load);
            base.ResumeLayout(false);
        }

        public void step(int lvl)
        {
            this.progressBar1.Step = lvl;
        }
    }
}

