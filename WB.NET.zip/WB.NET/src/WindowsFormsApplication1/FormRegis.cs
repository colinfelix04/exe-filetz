﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormRegis : Form
    {
        public string pCode = "";
        public bool pReturn = false;
        private IContainer components = null;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textBox1;
        private TextBox textBox2;
        private Button button1;
        private Button button2;

        public FormRegis()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textBox2.Text.Trim() == Program.GPK(this.textBox1.Text.Trim()))
            {
                this.pReturn = true;
                base.Close();
            }
            else
            {
                MessageBox.Show(Resource.Mes_196, Resource.Title_003);
                this.pReturn = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.pReturn = false;
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormRegis_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormRegis_Load(object sender, EventArgs e)
        {
            this.textBox1.Text = this.pCode;
            this.textBox1.ReadOnly = true;
            base.KeyPreview = true;
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.textBox1 = new TextBox();
            this.textBox2 = new TextBox();
            this.button1 = new Button();
            this.button2 = new Button();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0xf5, 0x18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please enter registration key";
            this.label2.AutoSize = true;
            this.label2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label2.Location = new Point(0x1f, 0x39);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x5e, 0x10);
            this.label2.TabIndex = 1;
            this.label2.Text = "Registry Code";
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(20, 0x5f);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x69, 0x10);
            this.label3.TabIndex = 2;
            this.label3.Text = "Registration key";
            this.textBox1.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBox1.Location = new Point(0x83, 0x39);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0x103, 0x16);
            this.textBox1.TabIndex = 3;
            this.textBox2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBox2.Location = new Point(0x83, 0x5c);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x103, 0x16);
            this.textBox2.TabIndex = 4;
            this.button1.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0xd1, 130);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 5;
            this.button1.Text = "Ok";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x13b, 130);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 6;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x19e, 0xae);
            base.ControlBox = false;
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Name = "FormRegis";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "WB System - Registration Key";
            base.Load += new EventHandler(this.FormRegis_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormRegis_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

