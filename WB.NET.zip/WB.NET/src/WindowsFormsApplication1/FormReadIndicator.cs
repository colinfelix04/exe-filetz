﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.IO.Ports;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Windows.Forms;

    public class FormReadIndicator : Form
    {
        public string Hasil = "";
        public string cline = "";
        public bool ok = false;
        public bool CheckZero = false;
        public string tmpValue = "0";
        private int nqty;
        private WBIndicator_File wbIndicator = new WBIndicator_File();
        private List<string> listIndValues = new List<string>();
        private List<string> listIndValues2 = new List<string>();
        private int lastPosListInd = 0;
        private string mostCommon = "0";
        private int mostCommonCount = 0;
        public string indStableWarning = "0";
        private float scd = 0f;
        private WBTable tbl_token = new WBTable();
        private string sqlToken = "";
        private DateTime startTime;
        private DateTime currTime;
        private TimeSpan elapsTime;
        private IContainer components = null;
        private TextBox textBox1;
        private Button button1;
        private Timer timer1;
        public SerialPort serialPort2;
        public SerialPort serialPort1;
        public RichTextBox richTextBox1;
        private ListBox listBoxBuffer;
        private ListBox listBoxTmpRead;
        private Label labelAutoMode;
        private Label labelET;

        public FormReadIndicator()
        {
            this.InitializeComponent();
        }

        private bool analyzeAutoCapture()
        {
            bool flag = false;
            int num = 0;
            if ((this.scd / 1000f) == 3f)
            {
                this.lastPosListInd = this.listIndValues.Count - 1;
                num = Convert.ToInt32(this.listIndValues[this.lastPosListInd]);
                Func<string, string> keySelector = <>c.<>9__24_0;
                if (<>c.<>9__24_0 == null)
                {
                    Func<string, string> local1 = <>c.<>9__24_0;
                    keySelector = <>c.<>9__24_0 = i => i;
                }
                Func<IGrouping<string, string>, int> func3 = <>c.<>9__24_1;
                if (<>c.<>9__24_1 == null)
                {
                    Func<IGrouping<string, string>, int> local2 = <>c.<>9__24_1;
                    func3 = <>c.<>9__24_1 = grp => grp.Count<string>();
                }
                Func<IGrouping<string, string>, string> selector = <>c.<>9__24_2;
                if (<>c.<>9__24_2 == null)
                {
                    Func<IGrouping<string, string>, string> local3 = <>c.<>9__24_2;
                    selector = <>c.<>9__24_2 = grp => grp.Key;
                }
                this.mostCommon = this.listIndValues.GroupBy<string, string>(keySelector).OrderByDescending<IGrouping<string, string>, int>(func3).Select<IGrouping<string, string>, string>(selector).First<string>();
                this.mostCommonCount = this.listIndValues.Count<string>(x => x == this.mostCommon);
                flag = (this.mostCommonCount >= 4) && (Program.StrToDouble(this.mostCommon, 0) == num);
            }
            if ((this.scd / 1000f) == 6f)
            {
                this.listIndValues2.Clear();
                int lastPosListInd = this.lastPosListInd;
                while (true)
                {
                    if (lastPosListInd >= this.listIndValues.Count)
                    {
                        num = Convert.ToInt32(this.listIndValues[this.lastPosListInd]);
                        Func<string, string> keySelector = <>c.<>9__24_4;
                        if (<>c.<>9__24_4 == null)
                        {
                            Func<string, string> local4 = <>c.<>9__24_4;
                            keySelector = <>c.<>9__24_4 = i => i;
                        }
                        Func<IGrouping<string, string>, int> func5 = <>c.<>9__24_5;
                        if (<>c.<>9__24_5 == null)
                        {
                            Func<IGrouping<string, string>, int> local5 = <>c.<>9__24_5;
                            func5 = <>c.<>9__24_5 = grp => grp.Count<string>();
                        }
                        Func<IGrouping<string, string>, string> selector = <>c.<>9__24_6;
                        if (<>c.<>9__24_6 == null)
                        {
                            Func<IGrouping<string, string>, string> local6 = <>c.<>9__24_6;
                            selector = <>c.<>9__24_6 = grp => grp.Key;
                        }
                        this.mostCommon = this.listIndValues2.GroupBy<string, string>(keySelector).OrderByDescending<IGrouping<string, string>, int>(func5).Select<IGrouping<string, string>, string>(selector).First<string>();
                        this.mostCommonCount = this.listIndValues2.Count<string>(x => x == this.mostCommon);
                        flag = (this.mostCommonCount >= 4) && ((this.mostCommon != num.ToString()) ? (Program.StrToDouble(this.mostCommon, 0) == num) : true);
                        break;
                    }
                    this.listIndValues2.Add(this.listIndValues[lastPosListInd]);
                    lastPosListInd++;
                }
            }
            return flag;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.serialPort1.Close();
            this.serialPort2.Close();
            this.timer1.Enabled = false;
            this.ok = true;
            if ((WBSetting.WB_Type == "3") || (WBSetting.WB_Type == "4"))
            {
                try
                {
                    this.Hasil = this.nqty.ToString();
                }
                catch
                {
                    this.Hasil = "0";
                }
            }
            else if ((WBSetting.WB_Type == "1") || (WBSetting.WB_Type == "2"))
            {
                try
                {
                    this.Hasil = Convert.ToString(this.getValue(this.cline));
                }
                catch
                {
                    this.Hasil = this.tmpValue;
                }
            }
            else if (WBSetting.WB_Type == "5")
            {
                try
                {
                    this.Hasil = this.nqty.ToString();
                }
                catch
                {
                    this.Hasil = "0";
                }
            }
            base.Close();
        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.serialPort1.Close();
                this.serialPort2.Close();
                this.ok = false;
                base.Close();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormReadIndicator_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!WBSetting.AutoCapture)
            {
                if (e.KeyChar == '\x001b')
                {
                    this.serialPort1.Close();
                    this.serialPort2.Close();
                    this.ok = false;
                    base.Close();
                }
                if (e.KeyChar == '\r')
                {
                    this.button1.PerformClick();
                }
            }
        }

        private void FormReadIndicator_Load(object sender, EventArgs e)
        {
            if ((WBSetting.WB_Type != "3") && (WBSetting.WB_Type != "4"))
            {
                if ((WBSetting.WB_Type != "1") && (WBSetting.WB_Type != "2"))
                {
                    if (WBSetting.WB_Type == "5")
                    {
                        this.wbIndicator.Init();
                        this.wbIndicator.checkStatus();
                        if (this.wbIndicator.msgStatus.Trim().ToUpper() != "Unavailable".Trim().ToUpper())
                        {
                            this.timer1.Enabled = true;
                        }
                        else
                        {
                            MessageBox.Show("System can't get weight from indicator!\nPlease ask IT to check: \n- Indicator type \n- Instalation of VWB", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            base.Dispose();
                            return;
                        }
                    }
                }
                else
                {
                    if (this.serialPort1.IsOpen)
                    {
                        this.serialPort1.Close();
                    }
                    base.KeyPreview = true;
                    WBSetting.OpenSetting();
                    this.textBox1.Text = "0 Kg";
                    this.tmpValue = "0";
                    this.cline = "";
                    this.serialPort1 = Program.InitPort();
                    try
                    {
                        this.serialPort1.Open();
                        this.serialPort1.Close();
                    }
                    catch (TimeoutException exception8)
                    {
                        MessageBox.Show(exception8.Message, "Receive Data Error. Read Timeout", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    catch (Exception exception4)
                    {
                        if (this.serialPort1.IsOpen)
                        {
                            this.serialPort1.Close();
                        }
                        MessageBox.Show(exception4.Message + "\n\nPlease check indicator connection or WeighBridge Setting menu.");
                        base.Close();
                    }
                    if (WBSetting.WB_Type == "1")
                    {
                        int num = 0;
                        try
                        {
                            num = this.ReadIndicator();
                        }
                        catch (TimeoutException exception10)
                        {
                            MessageBox.Show(exception10.Message, "Receive Data Error. Read Timeout", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        catch (Exception exception11)
                        {
                            MessageBox.Show(exception11.Message + "\n\nPlease check indicator connection or WeighBridge Setting menu.");
                            base.Close();
                        }
                        if (this.CheckZero && (num != 0))
                        {
                            MessageBox.Show("Weighing cannot continue until the indicator Zero first . . !");
                            this.ok = false;
                            base.Close();
                        }
                        this.timer1.Enabled = true;
                    }
                }
                if (!(WBSetting.AutoCapture && (WBSetting.WB_Type == "5")))
                {
                    this.labelAutoMode.Visible = false;
                    this.button1.Visible = true;
                    base.Size = new Size(0x25c, 0x103);
                    this.labelET.Visible = false;
                }
                else
                {
                    this.labelAutoMode.Visible = true;
                    this.listIndValues.Clear();
                    this.listIndValues2.Clear();
                    this.button1.Visible = false;
                    base.Size = new Size(0x25c, 0xb8);
                    this.Text = "Reading Indicator InProgress......";
                    if (WBUser.UserLevel == "1")
                    {
                        this.labelET.Visible = true;
                    }
                }
            }
            else
            {
                this.timer1.Stop();
                this.timer1.Enabled = false;
                WBSetting.OpenSetting();
                this.richTextBox1.Clear();
                this.serialPort1.Close();
                this.serialPort2.Close();
                this.serialPort2.PortName = WBSetting.CommPort;
                this.serialPort1.DtrEnable = true;
                this.serialPort1.RtsEnable = true;
                this.serialPort2.BaudRate = Convert.ToInt32(WBSetting.BaudRate);
                this.serialPort2.DataBits = Convert.ToInt32(WBSetting.DataBits);
                this.serialPort2.Parity = (WBSetting.parity == "None") ? Parity.None : ((WBSetting.parity == "Even") ? Parity.Even : Parity.Odd);
                this.serialPort2.StopBits = (WBSetting.Stopbits == "One") ? StopBits.One : StopBits.Two;
                this.serialPort2.RtsEnable = true;
                this.serialPort2.DtrEnable = true;
                try
                {
                    this.serialPort2.Open();
                }
                catch (TimeoutException exception1)
                {
                    MessageBox.Show(exception1.Message, "Receive Data Error. Read Timeout", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (Exception exception7)
                {
                    MessageBox.Show(exception7.Message);
                }
            }
        }

        private int getValue(string pStr)
        {
            int num;
            try
            {
                int length = WBSetting.Length;
                if (pStr.ToUpper().IndexOf("KG", 0) <= -1)
                {
                    num = Convert.ToInt32(this.cline.Substring(WBSetting.Start_Get - 1, WBSetting.Length));
                }
                else
                {
                    int startIndex = (pStr.ToUpper().IndexOf("KG", 0) - WBSetting.beforeKG) - length;
                    num = Convert.ToInt32(pStr.Substring(startIndex, length));
                }
            }
            catch
            {
                return Convert.ToInt32(this.tmpValue);
            }
            return num;
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.textBox1 = new TextBox();
            this.button1 = new Button();
            this.serialPort1 = new SerialPort(this.components);
            this.timer1 = new Timer(this.components);
            this.richTextBox1 = new RichTextBox();
            this.serialPort2 = new SerialPort(this.components);
            this.listBoxBuffer = new ListBox();
            this.listBoxTmpRead = new ListBox();
            this.labelAutoMode = new Label();
            this.labelET = new Label();
            base.SuspendLayout();
            this.textBox1.BackColor = Color.Black;
            this.textBox1.Cursor = Cursors.No;
            this.textBox1.Font = new Font("Microsoft Sans Serif", 72f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textBox1.ForeColor = Color.Lime;
            this.textBox1.Location = new Point(0x19, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new Size(0x227, 0x74);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "0 Kg";
            this.textBox1.TextAlign = HorizontalAlignment.Right;
            this.textBox1.TextChanged += new EventHandler(this.textBox1_TextChanged);
            this.textBox1.KeyPress += new KeyPressEventHandler(this.textBox1_KeyPress);
            this.button1.Font = new Font("Microsoft Sans Serif", 24f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0xe5, 0x92);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x8b, 0x41);
            this.button1.TabIndex = 0;
            this.button1.Text = "Ok";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button1.KeyPress += new KeyPressEventHandler(this.button1_KeyPress);
            this.timer1.Interval = 500;
            this.timer1.Tick += new EventHandler(this.timer1_Tick);
            this.richTextBox1.Location = new Point(0x1a, 0x115);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new Size(550, 0x60);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new EventHandler(this.richTextBox1_TextChanged);
            this.serialPort2.DataReceived += new SerialDataReceivedEventHandler(this.serialPort2_DataReceived);
            this.listBoxBuffer.FormattingEnabled = true;
            this.listBoxBuffer.Location = new Point(0x16b, 300);
            this.listBoxBuffer.Name = "listBoxBuffer";
            this.listBoxBuffer.Size = new Size(0xe1, 0x86);
            this.listBoxBuffer.TabIndex = 6;
            this.listBoxTmpRead.FormattingEnabled = true;
            this.listBoxTmpRead.Location = new Point(0x29, 300);
            this.listBoxTmpRead.Name = "listBoxTmpRead";
            this.listBoxTmpRead.Size = new Size(0x13c, 0x86);
            this.listBoxTmpRead.TabIndex = 5;
            this.labelAutoMode.AutoSize = true;
            this.labelAutoMode.Location = new Point(0x1f, 0x83);
            this.labelAutoMode.Name = "labelAutoMode";
            this.labelAutoMode.Size = new Size(0xa5, 13);
            this.labelAutoMode.TabIndex = 8;
            this.labelAutoMode.Text = "AUTO CAPTURE MODE ON";
            this.labelAutoMode.Visible = false;
            this.labelET.AutoSize = true;
            this.labelET.Location = new Point(0x219, 0x83);
            this.labelET.Name = "labelET";
            this.labelET.Size = new Size(0x15, 13);
            this.labelET.TabIndex = 9;
            this.labelET.Text = "00";
            this.labelET.Visible = false;
            base.AutoScaleDimensions = new SizeF(7f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x24c, 0xdd);
            base.ControlBox = false;
            base.Controls.Add(this.labelET);
            base.Controls.Add(this.labelAutoMode);
            base.Controls.Add(this.listBoxBuffer);
            base.Controls.Add(this.listBoxTmpRead);
            base.Controls.Add(this.richTextBox1);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textBox1);
            this.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            base.Name = "FormReadIndicator";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Read buffers from indicator. . . . . . . . . ( press ESC to cancel )";
            base.Load += new EventHandler(this.FormReadIndicator_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormReadIndicator_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private int ReadIndicator()
        {
            try
            {
                this.serialPort1.Open();
                this.cline = this.serialPort1.ReadLine();
                this.serialPort1.Close();
                return this.getValue(this.cline);
            }
            catch
            {
                if (this.serialPort1.IsOpen)
                {
                    this.serialPort1.Close();
                }
                return Convert.ToInt32(this.tmpValue);
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            string item = "";
            if (WBSetting.WB_Type != "4")
            {
                if (this.richTextBox1.Lines.Count<string>() >= 2)
                {
                    item = this.richTextBox1.Lines[this.richTextBox1.Lines.Count<string>() - 2];
                }
                else
                {
                    return;
                }
            }
            else if (this.listBoxTmpRead.Items.Count > 0)
            {
                item = this.listBoxTmpRead.Items[this.listBoxTmpRead.Items.Count - 1].ToString();
                this.listBoxBuffer.Items.Add(item);
            }
            else
            {
                return;
            }
            int length = WBSetting.Length;
            int index = item.ToUpper().IndexOf("KG", 0);
            if (!(((index <= -1) || (index <= length)) ? (WBSetting.beforeKG != 0) : false))
            {
                if ((index <= -1) && (WBSetting.beforeKG == 0))
                {
                    try
                    {
                        this.nqty = Convert.ToInt32(item.Substring(WBSetting.Start_Get - 1, length));
                        this.CheckZero = this.nqty == 0;
                    }
                    catch
                    {
                        this.nqty = 0;
                    }
                }
                else
                {
                    int startIndex = (index - WBSetting.beforeKG) - length;
                    try
                    {
                        this.nqty = Convert.ToInt32(item.Substring(startIndex, length));
                        this.CheckZero = this.nqty == 0;
                    }
                    catch
                    {
                        this.nqty = 0;
                    }
                }
            }
            else
            {
                return;
            }
            this.textBox1.Text = $"{this.nqty:N0}" + " KG";
        }

        private void serialPort2_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string cbuff = this.serialPort2.ReadExisting();
                if (WBSetting.WB_Type == "3")
                {
                    base.BeginInvoke(() => this.richTextBox1.AppendText(cbuff));
                }
                else if (WBSetting.WB_Type == "4")
                {
                    base.BeginInvoke(() => this.listBoxTmpRead.Items.Add(cbuff));
                    this.richTextBox1.AppendText(this.listBoxTmpRead.Items[this.listBoxTmpRead.Items.Count - 1].ToString());
                }
            }
            catch
            {
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.serialPort1.Close();
                this.serialPort2.Close();
                this.ok = false;
                base.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int num;
            if ((WBSetting.WB_Type == "1") || (WBSetting.WB_Type == "2"))
            {
                try
                {
                    num = this.ReadIndicator();
                    this.tmpValue = Convert.ToString(num);
                    this.textBox1.Text = $"{num:N0}" + " Kg";
                }
                catch (TimeoutException exception1)
                {
                    MessageBox.Show(exception1.Message, "Receive Data Error. Read Timeout", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                catch (Exception exception2)
                {
                    this.timer1.Stop();
                    this.timer1.Enabled = false;
                    MessageBox.Show(exception2.Message);
                    this.ok = false;
                    base.Close();
                }
            }
            else if (WBSetting.WB_Type == "5")
            {
                this.wbIndicator.readValue();
                num = Convert.ToInt32(this.wbIndicator.wbValue);
                this.nqty = Convert.ToInt32(this.wbIndicator.wbValue);
                this.textBox1.Text = $"{num:N0}" + " Kg";
                if (WBSetting.AutoCapture)
                {
                    this.scd += 500f;
                    this.labelET.Text = Convert.ToString((float) (this.scd / 1000f)).PadLeft(2, '0');
                    this.listIndValues.Add(this.wbIndicator.wbValue);
                    if (((this.scd / 1000f) == 3f) && this.analyzeAutoCapture())
                    {
                        num = Convert.ToInt32(this.mostCommon);
                        this.Hasil = num.ToString();
                        this.textBox1.Text = $"{num:N0}" + " Kg";
                        this.indStableWarning = "0";
                        this.ok = true;
                        base.Close();
                    }
                    if ((this.scd / 1000f) == 6f)
                    {
                        if (this.analyzeAutoCapture())
                        {
                            num = Convert.ToInt32(this.mostCommon);
                            this.Hasil = num.ToString();
                            this.textBox1.Text = $"{num:N0}" + " Kg";
                            this.indStableWarning = "1";
                            this.ok = true;
                            base.Close();
                        }
                        else
                        {
                            this.ok = false;
                            this.sqlToken = "Select * from wb_token where Token_Code = 'CAPTURE_NOT_STABLE'";
                            this.tbl_token.OpenTable("wb_token", this.sqlToken, WBData.conn);
                            if (this.tbl_token.DT.Rows.Count <= 0)
                            {
                                MessageBox.Show("WEIGHBRIDGE NOT STABLE...\nPlease RETRY Read Indicator or Contact IT...", "INDICATOR NOT STABLE");
                                base.Close();
                            }
                            else
                            {
                                this.tbl_token.DR = this.tbl_token.DT.Rows[0];
                                if (this.tbl_token.DR["key_1"].ToString() != "Y")
                                {
                                    MessageBox.Show("WEIGHBRIDGE NOT STABLE...\nPlease RETRY Read Indicator or Contact IT...", "INDICATOR NOT STABLE");
                                    base.Close();
                                }
                                else
                                {
                                    this.startTime = Convert.ToDateTime(this.tbl_token.DR["key_2"].ToString().Trim());
                                    this.currTime = DateTime.Now;
                                    this.elapsTime = (TimeSpan) (this.currTime - this.startTime);
                                    if (this.elapsTime.TotalSeconds > 86400.0)
                                    {
                                        this.tbl_token.DR.BeginEdit();
                                        this.tbl_token.DR["key_1"] = "N";
                                        this.tbl_token.DR.EndEdit();
                                        this.tbl_token.Save();
                                        MessageBox.Show("WEIGHBRIDGE NOT STABLE...\nPlease RETRY Read Indicator or Contact IT...", "INDICATOR NOT STABLE");
                                        base.Close();
                                    }
                                    else
                                    {
                                        num = Convert.ToInt32(this.mostCommon);
                                        this.Hasil = num.ToString();
                                        this.textBox1.Text = $"{num:N0}" + " Kg";
                                        this.indStableWarning = "9";
                                        this.ok = true;
                                        base.Close();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        [Serializable, CompilerGenerated]
        private sealed class <>c
        {
            public static readonly FormReadIndicator.<>c <>9 = new FormReadIndicator.<>c();
            public static Func<string, string> <>9__24_0;
            public static Func<IGrouping<string, string>, int> <>9__24_1;
            public static Func<IGrouping<string, string>, string> <>9__24_2;
            public static Func<string, string> <>9__24_4;
            public static Func<IGrouping<string, string>, int> <>9__24_5;
            public static Func<IGrouping<string, string>, string> <>9__24_6;

            internal string <analyzeAutoCapture>b__24_0(string i) => 
                i;

            internal int <analyzeAutoCapture>b__24_1(IGrouping<string, string> grp) => 
                grp.Count<string>();

            internal string <analyzeAutoCapture>b__24_2(IGrouping<string, string> grp) => 
                grp.Key;

            internal string <analyzeAutoCapture>b__24_4(string i) => 
                i;

            internal int <analyzeAutoCapture>b__24_5(IGrouping<string, string> grp) => 
                grp.Count<string>();

            internal string <analyzeAutoCapture>b__24_6(IGrouping<string, string> grp) => 
                grp.Key;
        }
    }
}

