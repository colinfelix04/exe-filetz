﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormPlasmaRules : Form
    {
        private IContainer components = null;
        private TextBox textSTO;
        private Label label5;
        private GroupBox groupBox2;
        private Label PlasmaSAP;
        private Label TypeSAP;
        private Label Plasma;
        private Label label4;
        private CheckBox checkBoxPlasma;
        private RadioButton radioRamp;
        private RadioButton radioKebAgen;
        private RadioButton radioAgen;
        private RadioButton radioOthers;
        private RadioButton radioOtherGroup;
        private RadioButton radioGroupEstate;
        private Label label3;
        private Label label2;
        private Label label1;
        private GroupBox groupBox1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem closeToolStripMenuItem;

        public FormPlasmaRules()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void checkBoxPlasma_Click(object sender, EventArgs e)
        {
            if (this.checkBoxPlasma.Checked)
            {
                if (this.textSTO.Text.Length != 0)
                {
                    this.PlasmaSAP.Text = "";
                    this.TypeSAP.Text = "A03";
                }
                else if ((this.radioOthers.Checked || (this.radioAgen.Checked || this.radioKebAgen.Checked)) || this.radioRamp.Checked)
                {
                    this.PlasmaSAP.Text = "-";
                    this.TypeSAP.Text = "-";
                }
                else if (this.radioOtherGroup.Checked)
                {
                    this.PlasmaSAP.Text = "2";
                    this.TypeSAP.Text = "A01";
                }
                else if (this.radioGroupEstate.Checked)
                {
                    this.PlasmaSAP.Text = "2";
                    this.TypeSAP.Text = "A02";
                }
            }
            else if (this.textSTO.Text.Length != 0)
            {
                this.PlasmaSAP.Text = "";
                this.TypeSAP.Text = "A03";
            }
            else if ((this.radioOthers.Checked || (this.radioAgen.Checked || this.radioKebAgen.Checked)) || this.radioRamp.Checked)
            {
                this.PlasmaSAP.Text = "";
                this.TypeSAP.Text = "A01";
            }
            else if (this.radioOtherGroup.Checked)
            {
                this.PlasmaSAP.Text = "1";
                this.TypeSAP.Text = "A01";
            }
            else if (this.radioGroupEstate.Checked)
            {
                this.PlasmaSAP.Text = "1";
                this.TypeSAP.Text = "A02";
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.textSTO = new TextBox();
            this.label5 = new Label();
            this.groupBox2 = new GroupBox();
            this.PlasmaSAP = new Label();
            this.TypeSAP = new Label();
            this.Plasma = new Label();
            this.label4 = new Label();
            this.checkBoxPlasma = new CheckBox();
            this.radioRamp = new RadioButton();
            this.radioKebAgen = new RadioButton();
            this.radioAgen = new RadioButton();
            this.radioOthers = new RadioButton();
            this.radioOtherGroup = new RadioButton();
            this.radioGroupEstate = new RadioButton();
            this.label3 = new Label();
            this.label2 = new Label();
            this.label1 = new Label();
            this.groupBox1 = new GroupBox();
            this.menuStrip1 = new MenuStrip();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.textSTO.Location = new Point(0x29, 0x18);
            this.textSTO.Name = "textSTO";
            this.textSTO.Size = new Size(100, 20);
            this.textSTO.TabIndex = 15;
            this.textSTO.Leave += new EventHandler(this.textSTO_Leave);
            this.label5.AutoSize = true;
            this.label5.Location = new Point(6, 0x1b);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x1d, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "STO";
            this.groupBox2.BackColor = SystemColors.ControlLightLight;
            this.groupBox2.Controls.Add(this.PlasmaSAP);
            this.groupBox2.Controls.Add(this.TypeSAP);
            this.groupBox2.Controls.Add(this.Plasma);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.groupBox2.Location = new Point(0x70, 0x7e);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0x76, 0x8e);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Upload SAP";
            this.PlasmaSAP.AutoSize = true;
            this.PlasmaSAP.Location = new Point(6, 0x37);
            this.PlasmaSAP.Name = "PlasmaSAP";
            this.PlasmaSAP.Size = new Size(11, 13);
            this.PlasmaSAP.TabIndex = 3;
            this.PlasmaSAP.Text = ".";
            this.TypeSAP.AutoSize = true;
            this.TypeSAP.Location = new Point(6, 0x72);
            this.TypeSAP.Name = "TypeSAP";
            this.TypeSAP.Size = new Size(11, 13);
            this.TypeSAP.TabIndex = 2;
            this.TypeSAP.Text = ".";
            this.Plasma.AutoSize = true;
            this.Plasma.Location = new Point(6, 0x1f);
            this.Plasma.Name = "Plasma";
            this.Plasma.Size = new Size(0x2f, 13);
            this.Plasma.TabIndex = 1;
            this.Plasma.Text = "Plasma";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(6, 0x5c);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x3b, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "TypeSAP";
            this.checkBoxPlasma.AutoSize = true;
            this.checkBoxPlasma.Location = new Point(6, 0xfb);
            this.checkBoxPlasma.Name = "checkBoxPlasma";
            this.checkBoxPlasma.Size = new Size(60, 0x11);
            this.checkBoxPlasma.TabIndex = 12;
            this.checkBoxPlasma.Text = "Plasma";
            this.checkBoxPlasma.UseVisualStyleBackColor = true;
            this.checkBoxPlasma.Click += new EventHandler(this.checkBoxPlasma_Click);
            this.radioRamp.AutoSize = true;
            this.radioRamp.Location = new Point(9, 0xd6);
            this.radioRamp.Margin = new Padding(3, 4, 3, 4);
            this.radioRamp.Name = "radioRamp";
            this.radioRamp.Size = new Size(0x35, 0x11);
            this.radioRamp.TabIndex = 11;
            this.radioRamp.TabStop = true;
            this.radioRamp.Text = "Ramp";
            this.radioRamp.UseVisualStyleBackColor = true;
            this.radioRamp.Click += new EventHandler(this.radioRamp_Click);
            this.radioKebAgen.AutoSize = true;
            this.radioKebAgen.Location = new Point(0x71, 0x60);
            this.radioKebAgen.Margin = new Padding(3, 4, 3, 4);
            this.radioKebAgen.Name = "radioKebAgen";
            this.radioKebAgen.Size = new Size(0x60, 0x11);
            this.radioKebAgen.TabIndex = 8;
            this.radioKebAgen.TabStop = true;
            this.radioKebAgen.Text = "Pekebun Agen";
            this.radioKebAgen.UseVisualStyleBackColor = true;
            this.radioKebAgen.Click += new EventHandler(this.radioKebAgen_Click);
            this.radioAgen.AutoSize = true;
            this.radioAgen.Location = new Point(8, 0x5f);
            this.radioAgen.Margin = new Padding(3, 4, 3, 4);
            this.radioAgen.Name = "radioAgen";
            this.radioAgen.Size = new Size(50, 0x11);
            this.radioAgen.TabIndex = 7;
            this.radioAgen.TabStop = true;
            this.radioAgen.Text = "Agen";
            this.radioAgen.UseVisualStyleBackColor = true;
            this.radioAgen.Click += new EventHandler(this.radioAgen_Click);
            this.radioOthers.AutoSize = true;
            this.radioOthers.Location = new Point(0x71, 0x48);
            this.radioOthers.Margin = new Padding(3, 4, 3, 4);
            this.radioOthers.Name = "radioOthers";
            this.radioOthers.Size = new Size(0x44, 0x11);
            this.radioOthers.TabIndex = 10;
            this.radioOthers.Text = "Pekebun";
            this.radioOthers.UseVisualStyleBackColor = true;
            this.radioOthers.Click += new EventHandler(this.radioOthers_Click);
            this.radioOtherGroup.AutoSize = true;
            this.radioOtherGroup.Location = new Point(8, 0x48);
            this.radioOtherGroup.Margin = new Padding(3, 4, 3, 4);
            this.radioOtherGroup.Name = "radioOtherGroup";
            this.radioOtherGroup.Size = new Size(0x53, 0x11);
            this.radioOtherGroup.TabIndex = 9;
            this.radioOtherGroup.Text = "Other Group";
            this.radioOtherGroup.UseVisualStyleBackColor = true;
            this.radioOtherGroup.Click += new EventHandler(this.radioOtherGroup_Click);
            this.radioGroupEstate.AutoSize = true;
            this.radioGroupEstate.Checked = true;
            this.radioGroupEstate.Location = new Point(9, 0x99);
            this.radioGroupEstate.Margin = new Padding(3, 4, 3, 4);
            this.radioGroupEstate.Name = "radioGroupEstate";
            this.radioGroupEstate.Size = new Size(0x57, 0x11);
            this.radioGroupEstate.TabIndex = 6;
            this.radioGroupEstate.TabStop = true;
            this.radioGroupEstate.Text = "Group Estate";
            this.radioGroupEstate.UseVisualStyleBackColor = true;
            this.radioGroupEstate.Click += new EventHandler(this.radioGroupEstate_Click);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(6, 0xbb);
            this.label3.Name = "label3";
            this.label3.Size = new Size(40, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Type 3";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(6, 0x7e);
            this.label2.Name = "label2";
            this.label2.Size = new Size(40, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Type 2";
            this.label1.AutoSize = true;
            this.label1.Location = new Point(6, 0x36);
            this.label1.Name = "label1";
            this.label1.Size = new Size(40, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Type 1";
            this.groupBox1.Controls.Add(this.textSTO);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.checkBoxPlasma);
            this.groupBox1.Controls.Add(this.radioRamp);
            this.groupBox1.Controls.Add(this.radioKebAgen);
            this.groupBox1.Controls.Add(this.radioAgen);
            this.groupBox1.Controls.Add(this.radioOthers);
            this.groupBox1.Controls.Add(this.radioOtherGroup);
            this.groupBox1.Controls.Add(this.radioGroupEstate);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new Point(0x19, 0x1f);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(250, 0x123);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "[ From Estate ]";
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x12d, 0x18);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x12d, 0x14f);
            base.ControlBox = false;
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.groupBox1);
            base.Name = "FormPlasmaRules";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Form Plasma";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void radioAgen_Click(object sender, EventArgs e)
        {
            if (this.textSTO.Text.Length != 0)
            {
                this.PlasmaSAP.Text = "";
                this.TypeSAP.Text = "A03";
            }
            else if (this.checkBoxPlasma.Checked)
            {
                this.PlasmaSAP.Text = "-";
                this.TypeSAP.Text = "-";
            }
            else
            {
                this.PlasmaSAP.Text = "";
                this.TypeSAP.Text = "A01";
            }
        }

        private void radioGroupEstate_Click(object sender, EventArgs e)
        {
            if (this.textSTO.Text.Length != 0)
            {
                this.PlasmaSAP.Text = "";
                this.TypeSAP.Text = "A03";
            }
            else if (this.checkBoxPlasma.Checked)
            {
                this.PlasmaSAP.Text = "2";
                this.TypeSAP.Text = "A02";
            }
            else
            {
                this.PlasmaSAP.Text = "1";
                this.TypeSAP.Text = "A02";
            }
        }

        private void radioKebAgen_Click(object sender, EventArgs e)
        {
            if (this.textSTO.Text.Length != 0)
            {
                this.PlasmaSAP.Text = "";
                this.TypeSAP.Text = "A03";
            }
            else if (this.checkBoxPlasma.Checked)
            {
                this.PlasmaSAP.Text = "-";
                this.TypeSAP.Text = "-";
            }
            else
            {
                this.PlasmaSAP.Text = "";
                this.TypeSAP.Text = "A01";
            }
        }

        private void radioOtherGroup_Click(object sender, EventArgs e)
        {
            if (this.textSTO.Text.Length != 0)
            {
                this.PlasmaSAP.Text = "";
                this.TypeSAP.Text = "A03";
            }
            else if (this.checkBoxPlasma.Checked)
            {
                this.PlasmaSAP.Text = "2";
                this.TypeSAP.Text = "A01";
            }
            else
            {
                this.PlasmaSAP.Text = "1";
                this.TypeSAP.Text = "A01";
            }
        }

        private void radioOthers_Click(object sender, EventArgs e)
        {
            if (this.textSTO.Text.Length != 0)
            {
                this.PlasmaSAP.Text = "";
                this.TypeSAP.Text = "A03";
            }
            else if (this.checkBoxPlasma.Checked)
            {
                this.PlasmaSAP.Text = "-";
                this.TypeSAP.Text = "-";
            }
            else
            {
                this.PlasmaSAP.Text = "";
                this.TypeSAP.Text = "A01";
            }
        }

        private void radioRamp_Click(object sender, EventArgs e)
        {
            if (this.textSTO.Text.Length != 0)
            {
                this.PlasmaSAP.Text = "";
                this.TypeSAP.Text = "A03";
            }
            else if (this.checkBoxPlasma.Checked)
            {
                this.PlasmaSAP.Text = "-";
                this.TypeSAP.Text = "-";
            }
            else
            {
                this.PlasmaSAP.Text = "";
                this.TypeSAP.Text = "A01";
            }
        }

        private void textSTO_Leave(object sender, EventArgs e)
        {
            this.PlasmaSAP.Text = "";
            this.TypeSAP.Text = "A03";
        }

        private void translate()
        {
            this.groupBox1.Text = "[ " + Resource.ContractE_021 + " ]";
            this.label5.Text = Resource.Contract_019;
            this.label3.Text = Resource.ContractE_024;
            this.label2.Text = Resource.ContractE_023;
            this.label1.Text = Resource.ContractE_022;
            this.radioRamp.Text = Resource.Rdb_Ramp;
            this.radioKebAgen.Text = Resource.ContractE_028;
            this.radioAgen.Text = Resource.Contract_013;
            this.radioOthers.Text = Resource.ContractE_027;
            this.radioOtherGroup.Text = Resource.ContractE_025;
            this.radioGroupEstate.Text = Resource.Rdb_Group_Estate;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
        }
    }
}

