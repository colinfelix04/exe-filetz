﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCompositEntry : Form
    {
        public WBTable zTable;
        public WBTable tblEst = new WBTable();
        public WBTable tblRelation = new WBTable();
        public WBTable tblComm = new WBTable();
        public string pMode;
        public string OldCode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        private IContainer components = null;
        private DateTimePicker date;
        private Button button4;
        private Button button5;
        public Label label1;
        public TextBox textComm;
        public Button button1;
        public Label labelCommName;
        public Label labelRelationName;
        public Button button2;
        public TextBox textRelation;
        public Label label3;
        public Label labelEstateName;
        public Button button3;
        public TextBox textEstate;
        public Label label5;
        public TextBox textYield;
        public TextBox textValue;
        public Label labelYieldName;
        public Button button6;
        public Label label2;
        public Label label4;

        public FormCompositEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textComm.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
            }
            commodity.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textRelation.Text = vendor.ReturnRow["Relation_Code"].ToString();
                this.labelRelationName.Text = vendor.ReturnRow["Relation_Name"].ToString();
            }
            vendor.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormEstate estate = new FormEstate {
                pMode = "CHOOSE"
            };
            estate.ShowDialog();
            if (estate.ReturnRow != null)
            {
                this.textEstate.Text = estate.ReturnRow["Estate_Code"].ToString();
                this.labelEstateName.Text = estate.ReturnRow["Estate_Name"].ToString();
            }
            estate.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            TextBox[] aText = new TextBox[] { this.textComm, this.textEstate, this.textRelation, this.textYield };
            if (!Program.CheckEmpty(aText))
            {
                string str = Program.DTOC(this.date.Value);
                string[] textArray1 = new string[11];
                textArray1[0] = " and (yield_Code='";
                textArray1[1] = this.textYield.Text.Trim();
                textArray1[2] = "' and Comm_Code='";
                textArray1[3] = this.textComm.Text.Trim();
                textArray1[4] = "' and Relation_Code='";
                textArray1[5] = this.textRelation.Text.Trim();
                textArray1[6] = "' and Estate_Code='";
                textArray1[7] = this.textEstate.Text.Trim();
                textArray1[8] = "' and da='";
                textArray1[9] = str;
                textArray1[10] = "')";
                string pStr = string.Concat(textArray1);
                WBTable table = new WBTable();
                table.OpenTable("wb_yieldComposit", "Select Uniq From wb_yieldComposit Where " + WBData.CompanyLocation(pStr), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode == "EDIT") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    if (this.pMode == "EDIT")
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = Resource.Composite_005 },
                            textRefNo = { Text = this.textYield.Text },
                            Text = Resource.Title_Change_Reason,
                            label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                        }
                        else
                        {
                            return;
                        }
                    }
                    Cursor.Current = Cursors.WaitCursor;
                    this.zTable.ReOpen();
                    this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                    this.zTable.ReOpen();
                    if (this.pMode != "EDIT")
                    {
                        this.zTable.DR = this.zTable.DT.NewRow();
                    }
                    else
                    {
                        this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                        this.logKey = this.zTable.DR["uniq"].ToString();
                        this.zTable.DR.BeginEdit();
                    }
                    this.zTable.DR["Coy"] = WBData.sCoyCode;
                    this.zTable.DR["Location_Code"] = WBData.sLocCode;
                    this.zTable.DR["Yield_Code"] = this.textYield.Text;
                    this.zTable.DR["Yield_Name"] = this.labelYieldName.Text;
                    this.zTable.DR["Value"] = Convert.ToDouble(this.textValue.Text.Trim());
                    this.zTable.DR["Comm_Code"] = this.textComm.Text;
                    this.zTable.DR["Relation_Code"] = this.textRelation.Text;
                    this.zTable.DR["Estate_Code"] = this.textEstate.Text;
                    this.zTable.DR["Da"] = this.date.Text;
                    string str3 = this.zTable.DR["Da"].ToString();
                    if (this.pMode != "EDIT")
                    {
                        this.zTable.DR["Create_By"] = WBUser.UserID;
                        this.zTable.DR["Create_Date"] = DateTime.Now;
                        this.zTable.DT.Rows.Add(this.zTable.DR);
                    }
                    else
                    {
                        this.zTable.DR["Change_By"] = WBUser.UserID;
                        this.zTable.DR["Change_Date"] = DateTime.Now;
                        this.zTable.DR.EndEdit();
                    }
                    this.zTable.Save();
                    if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
                    {
                        if (this.pMode == "ADD")
                        {
                            string sqltext = ((((("SELECT uniq FROM wb_yieldComposit WHERE " + WBData.CompanyLocation("")) + " AND yield_code = '" + this.textYield.Text + "'") + " AND comm_code = '" + this.textComm.Text + "'") + " AND relation_code = '" + this.textRelation.Text + "'") + " AND estate_code = '" + this.textEstate.Text + "'") + " AND da = '" + str3 + "'";
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_yieldComposit", sqltext, WBData.conn);
                            this.logKey = table2.DT.Rows[0]["uniq"].ToString();
                            table2.Dispose();
                        }
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_yieldComposit", this.logKey, logField, logValue);
                    }
                    Cursor.Current = Cursors.Default;
                    this.saved = true;
                    base.Close();
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_048);
                    this.textComm.Focus();
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FormYield yield = new FormYield {
                pMode = "CHOOSE"
            };
            yield.ShowDialog();
            if (yield.ReturnRow != null)
            {
                this.textYield.Text = yield.ReturnRow["Yield_Code"].ToString();
                this.labelYieldName.Text = yield.ReturnRow["Yield_Name"].ToString();
            }
            yield.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormYieldDetailEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormYieldDetailEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.labelCommName.Text = "";
            this.labelRelationName.Text = "";
            this.labelEstateName.Text = "";
            this.labelYieldName.Text = "";
            this.textValue.Text = "0.000";
            this.date.Value = DateTime.Now;
            this.tblEst.OpenTable("wb_estate", "Select * From wb_estate", WBData.conn);
            this.tblRelation.OpenTable("wb_relation", "Select * From wb_relation", WBData.conn);
            this.tblComm.OpenTable("wb_commodity", "Select * From wb_commodity", WBData.conn);
            if (this.pMode != "ADD")
            {
                this.date.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Da"].Value.ToString();
                this.textComm.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Comm_Code"].Value.ToString();
                string[] aField = new string[] { "Comm_Code" };
                string[] aFind = new string[] { this.textComm.Text };
                DataRow data = this.tblComm.GetData(aField, aFind);
                if (data != null)
                {
                    this.labelCommName.Text = data["Comm_Name"].ToString();
                }
                this.textRelation.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Relation_Code"].Value.ToString();
                string[] textArray3 = new string[] { "Relation_Code" };
                string[] textArray4 = new string[] { this.textRelation.Text };
                data = this.tblRelation.GetData(textArray3, textArray4);
                if (data != null)
                {
                    this.labelRelationName.Text = data["Relation_Name"].ToString();
                }
                this.textEstate.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Estate_Code"].Value.ToString();
                string[] textArray5 = new string[] { "Estate_Code" };
                string[] textArray6 = new string[] { this.textEstate.Text };
                data = this.tblEst.GetData(textArray5, textArray6);
                if (data != null)
                {
                    this.labelEstateName.Text = data["Estate_Name"].ToString();
                }
                if (this.pMode == "EDIT")
                {
                    this.textYield.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Yield_Code"].Value.ToString();
                    this.labelYieldName.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Yield_Name"].Value.ToString();
                    this.textValue.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Value"].Value.ToString();
                }
            }
            if (this.pMode == "VIEW")
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.button4.Text = Resource.Btn_Close;
                this.button4.Enabled = true;
            }
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.textComm = new TextBox();
            this.button1 = new Button();
            this.labelCommName = new Label();
            this.labelRelationName = new Label();
            this.button2 = new Button();
            this.textRelation = new TextBox();
            this.label3 = new Label();
            this.labelEstateName = new Label();
            this.button3 = new Button();
            this.textEstate = new TextBox();
            this.label5 = new Label();
            this.date = new DateTimePicker();
            this.textYield = new TextBox();
            this.textValue = new TextBox();
            this.labelYieldName = new Label();
            this.button4 = new Button();
            this.button5 = new Button();
            this.button6 = new Button();
            this.label2 = new Label();
            this.label4 = new Label();
            base.SuspendLayout();
            this.label1.Location = new Point(12, 0x29);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3d, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Commodity";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.textComm.Location = new Point(0x4f, 0x26);
            this.textComm.Name = "textComm";
            this.textComm.ReadOnly = true;
            this.textComm.Size = new Size(0x83, 20);
            this.textComm.TabIndex = 1;
            this.button1.Location = new Point(210, 0x25);
            this.button1.Margin = new Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x1f, 0x17);
            this.button1.TabIndex = 2;
            this.button1.Text = "...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.labelCommName.AutoSize = true;
            this.labelCommName.Location = new Point(0xf4, 0x29);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x56, 13);
            this.labelCommName.TabIndex = 3;
            this.labelCommName.Text = "CommodityName";
            this.labelRelationName.AutoSize = true;
            this.labelRelationName.Location = new Point(0xf4, 0x45);
            this.labelRelationName.Name = "labelRelationName";
            this.labelRelationName.Size = new Size(0x4a, 13);
            this.labelRelationName.TabIndex = 7;
            this.labelRelationName.Text = "RelationName";
            this.button2.Location = new Point(210, 0x41);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x1f, 0x17);
            this.button2.TabIndex = 6;
            this.button2.Text = "...";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.textRelation.Location = new Point(0x4f, 0x42);
            this.textRelation.Name = "textRelation";
            this.textRelation.ReadOnly = true;
            this.textRelation.Size = new Size(0x83, 20);
            this.textRelation.TabIndex = 5;
            this.label3.Location = new Point(12, 70);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x3d, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Relation";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.labelEstateName.AutoSize = true;
            this.labelEstateName.Location = new Point(0xf4, 0x61);
            this.labelEstateName.Name = "labelEstateName";
            this.labelEstateName.Size = new Size(0x41, 13);
            this.labelEstateName.TabIndex = 11;
            this.labelEstateName.Text = "EstateName";
            this.button3.Location = new Point(210, 0x5d);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x1f, 0x17);
            this.button3.TabIndex = 10;
            this.button3.Text = "...";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.textEstate.Location = new Point(0x4f, 0x5e);
            this.textEstate.Name = "textEstate";
            this.textEstate.ReadOnly = true;
            this.textEstate.Size = new Size(0x83, 20);
            this.textEstate.TabIndex = 9;
            this.label5.Location = new Point(12, 0x61);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x3d, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Estate";
            this.label5.TextAlign = ContentAlignment.MiddleRight;
            this.date.Format = DateTimePickerFormat.Short;
            this.date.Location = new Point(0x4f, 12);
            this.date.Name = "date";
            this.date.Size = new Size(0x66, 20);
            this.date.TabIndex = 14;
            this.textYield.Location = new Point(0x4f, 0x7a);
            this.textYield.Name = "textYield";
            this.textYield.ReadOnly = true;
            this.textYield.Size = new Size(0x83, 20);
            this.textYield.TabIndex = 14;
            this.textValue.Location = new Point(0xf7, 0x7a);
            this.textValue.Name = "textValue";
            this.textValue.Size = new Size(0x33, 20);
            this.textValue.TabIndex = 15;
            this.textValue.Text = "0.000";
            this.textValue.TextAlign = HorizontalAlignment.Right;
            this.textValue.Leave += new EventHandler(this.textValue_Leave);
            this.labelYieldName.AutoSize = true;
            this.labelYieldName.Location = new Point(0x4c, 0x91);
            this.labelYieldName.Name = "labelYieldName";
            this.labelYieldName.Size = new Size(0x3a, 13);
            this.labelYieldName.TabIndex = 0x10;
            this.labelYieldName.Text = "YieldName";
            this.button4.Location = new Point(0x1f0, 0xae);
            this.button4.Name = "button4";
            this.button4.Size = new Size(0x4b, 0x17);
            this.button4.TabIndex = 0x48;
            this.button4.Text = "&Cancel";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new EventHandler(this.button4_Click);
            this.button5.Location = new Point(0x18d, 0xae);
            this.button5.Name = "button5";
            this.button5.Size = new Size(0x4b, 0x17);
            this.button5.TabIndex = 0x47;
            this.button5.Text = "&Save";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new EventHandler(this.button5_Click);
            this.button6.Location = new Point(210, 120);
            this.button6.Name = "button6";
            this.button6.Size = new Size(0x1f, 0x17);
            this.button6.TabIndex = 0x49;
            this.button6.Text = "...";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new EventHandler(this.button6_Click);
            this.label2.Location = new Point(12, 15);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x3d, 13);
            this.label2.TabIndex = 0x4a;
            this.label2.Text = "Date";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.label4.Location = new Point(12, 0x7d);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x3d, 13);
            this.label4.TabIndex = 0x4b;
            this.label4.Text = "QC Code";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x25c, 0xce);
            base.ControlBox = false;
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.button6);
            base.Controls.Add(this.button4);
            base.Controls.Add(this.date);
            base.Controls.Add(this.button5);
            base.Controls.Add(this.labelYieldName);
            base.Controls.Add(this.textValue);
            base.Controls.Add(this.textYield);
            base.Controls.Add(this.labelEstateName);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.textEstate);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.labelRelationName);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.textRelation);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textComm);
            base.Controls.Add(this.label1);
            base.KeyPreview = true;
            base.Name = "FormCompositEntry";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Entry Detail Composite";
            base.Load += new EventHandler(this.FormYieldDetailEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormYieldDetailEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textValue_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textValue);
        }

        private void translate()
        {
            this.label2.Text = Resource.Composite_001;
            this.label3.Text = Resource.Composite_002;
            this.label5.Text = Resource.Composite_003;
            this.label1.Text = Resource.Composite_004;
            this.label4.Text = Resource.Composite_005;
            this.button5.Text = Resource.Save;
            this.button4.Text = Resource.Menu_Cancel;
            this.Text = Resource.Title_Composite_Entry;
        }
    }
}

