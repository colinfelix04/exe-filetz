﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormComposit : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable zTable = new WBTable();
        private IContainer components = null;
        public ToolStripMenuItem editCommodityToolStripMenuItem;
        public ToolStripMenuItem deleteToolStripMenuItem;
        public ToolStripMenuItem addCommodityItemToolStripMenuItem;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        public TextBox TextFind;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem closeToolStripMenuItem;
        public Panel panel1;
        public Button buttonFind;
        private DataGridView dataGridView1;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem viewRecordToolStripMenuItem;

        public FormComposit()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void addCommodityItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Entry("ADD", Resource.Title_Add_Composite);
            if (this.dataGridView1.RowCount > 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = true;
                this.editCommodityToolStripMenuItem.Enabled = true;
                this.deleteToolStripMenuItem.Enabled = true;
                this.toolStripMenuItem1.Enabled = true;
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.zTable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void copyStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Entry("COPY", Resource.Title_Copy_Composite);
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.zTable.BeforeEdit(this.dataGridView1, "DELETE"))
            {
                this.nCurrRow = this.zTable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                string[] textArray1 = new string[] { this.zTable.DT.Rows[this.nCurrRow]["Yield_Code"].ToString(), " - ", this.zTable.DT.Rows[this.nCurrRow]["Yield_Name"].ToString(), ".\n\n", Resource.Mes_006 };
                if (MessageBox.Show(string.Concat(textArray1), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    FormTransCancel cancel = new FormTransCancel {
                        label1 = { Text = Resource.Composite_005 },
                        textRefNo = { Text = this.zTable.DT.Rows[this.nCurrRow]["Yield_Code"].ToString() },
                        Text = Resource.Form_Delete_Reason,
                        label2 = { Text = Resource.Lbl_Delete_Reason }
                    };
                    cancel.textReason.Focus();
                    cancel.ShowDialog();
                    if (cancel.Saved)
                    {
                        this.changeReason = cancel.textReason.Text;
                        cancel.Dispose();
                        this.zTable.ReOpen();
                        this.logKey = this.zTable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                        this.zTable.DT.Rows[this.nCurrRow].Delete();
                        this.zTable.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_yieldComposit", this.logKey, logField, logValue);
                        this.zTable.ReOpen();
                        this.zTable.AfterEdit("DELETE");
                    }
                    else
                    {
                        return;
                    }
                }
                this.zTable.UnLock();
                if (this.dataGridView1.RowCount == 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = false;
                    this.editCommodityToolStripMenuItem.Enabled = false;
                    this.deleteToolStripMenuItem.Enabled = false;
                    this.toolStripMenuItem1.Enabled = false;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editCommodityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Entry("EDIT", Resource.Title_Edit_Composite);
        }

        private void Entry(string pMod, string formText)
        {
            if (this.zTable.BeforeEdit(this.dataGridView1, pMod))
            {
                FormCompositEntry entry = new FormCompositEntry {
                    pMode = pMod,
                    zTable = this.zTable,
                    Text = formText,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.zTable.ReOpen();
                    this.dataGridView1 = this.zTable.AfterEdit(entry.pMode);
                }
                entry.Dispose();
                this.zTable.UnLock();
            }
        }

        private void FormYieldDetail_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormYieldDetail_Load(object sender, EventArgs e)
        {
            this.zTable.OpenTable("wb_yieldComposit", "Select * From wb_yieldComposit", WBData.conn);
            this.dataGridView1.DataSource = this.zTable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Da"], ListSortDirection.Descending);
            if (this.zTable.DT.Rows.Count > 0)
            {
                foreach (DataColumn column in this.zTable.DT.Columns)
                {
                    this.zTable.DR = this.zTable.DT.Rows[0];
                    if (column.ColumnName.ToString().ToUpper() == "NET")
                    {
                    }
                    if (this.zTable.DR[column.ColumnName].GetType().ToString() == "System.Double")
                    {
                        this.dataGridView1.Columns[column.ColumnName].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                        this.dataGridView1.Columns[column.ColumnName].DefaultCellStyle.Format = "N3";
                    }
                }
            }
            this.dataGridView1.Refresh();
            this.dataGridView1.Focus();
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["Delete_By"].Visible = false;
            this.dataGridView1.Columns["Delete_Date"].Visible = false;
            this.dataGridView1.Columns["Create_By"].Visible = false;
            this.dataGridView1.Columns["Create_Date"].Visible = false;
            this.dataGridView1.Columns["Change_By"].Visible = false;
            this.dataGridView1.Columns["Change_Date"].Visible = false;
            this.dataGridView1.Columns["deleted"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["Comm_Code"].HeaderText = Resource.Composite_004;
            this.dataGridView1.Columns["Relation_Code"].HeaderText = Resource.Contract_006;
            this.dataGridView1.Columns["Estate_Code"].HeaderText = Resource.Composite_003;
            this.dataGridView1.Columns["Da"].HeaderText = Resource.Composite_001;
            this.dataGridView1.Columns["Yield_Code"].Width = 100;
            this.dataGridView1.Columns["Yield_Code"].HeaderText = Resource.Composite_005;
            this.dataGridView1.Columns["Yield_Name"].Width = 400;
            this.dataGridView1.Columns["Yield_Name"].HeaderText = Resource.Composite_007;
            base.KeyPreview = true;
            if (this.dataGridView1.RowCount == 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = false;
                this.editCommodityToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
                this.toolStripMenuItem1.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.editCommodityToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.addCommodityItemToolStripMenuItem = new ToolStripMenuItem();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.menuStrip1 = new MenuStrip();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.panel1 = new Panel();
            this.buttonFind = new Button();
            this.dataGridView1 = new DataGridView();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            base.SuspendLayout();
            this.editCommodityToolStripMenuItem.Name = "editCommodityToolStripMenuItem";
            this.editCommodityToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editCommodityToolStripMenuItem.Text = "&Edit  Record";
            this.editCommodityToolStripMenuItem.Click += new EventHandler(this.editCommodityToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "&Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.addCommodityItemToolStripMenuItem.Name = "addCommodityItemToolStripMenuItem";
            this.addCommodityItemToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addCommodityItemToolStripMenuItem.Text = "&Add New Record";
            this.addCommodityItemToolStripMenuItem.Click += new EventHandler(this.addCommodityItemToolStripMenuItem_Click);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.addCommodityItemToolStripMenuItem, this.viewRecordToolStripMenuItem, this.toolStripMenuItem1, this.editCommodityToolStripMenuItem, this.deleteToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(toolStripItems);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0xa3, 0x16);
            this.toolStripMenuItem1.Text = "&Copy";
            this.toolStripMenuItem1.Click += new EventHandler(this.copyStripMenuItem1_Click);
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 0;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(itemArray2);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x284, 0x18);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x15a);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x284, 0x21);
            this.panel1.TabIndex = 4;
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 1;
            this.buttonFind.Text = "&Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x284, 0x142);
            this.dataGridView1.TabIndex = 0;
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x284, 0x17b);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.KeyPreview = true;
            base.Name = "FormComposit";
            this.Text = "Detail Composite";
            base.Load += new EventHandler(this.FormYieldDetail_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormYieldDetail_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addCommodityItemToolStripMenuItem.Text = Resource.Menu_Add;
            this.editCommodityToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
            this.toolStripMenuItem1.Text = Resource.Menu_Copy;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.Text = Resource.Title_Composite;
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.zTable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormCompositEntry entry = new FormCompositEntry {
                    pMode = "VIEW",
                    zTable = this.zTable,
                    Text = Resource.Title_View_Composite,
                    nCurrRow = this.zTable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                this.zTable.UnLock();
                entry.Dispose();
            }
        }
    }
}

