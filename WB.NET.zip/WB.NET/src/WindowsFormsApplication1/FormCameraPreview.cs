﻿namespace WindowsFormsApplication1
{
    using Camera.Utility;
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCameraPreview : Form
    {
        public string camera_code;
        public string camera_type;
        public string ip_address;
        public string username;
        public string password;
        public string web_url;
        public string webcam_name;
        public string path;
        public bool can_stream = false;
        private WBCamera camera = new WBCamera();
        private IContainer components = null;
        public PictureBox pic_box;

        public FormCameraPreview()
        {
            this.InitializeComponent();
            this.translate();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormCameraPreview_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.camera.CloseCurrentVideoSource();
        }

        private void FormCameraPreview_Load(object sender, EventArgs e)
        {
            if (this.camera_type == "IP_CAMERA")
            {
                Cursor.Current = Cursors.WaitCursor;
                this.can_stream = this.camera.getHttpRequest(this.web_url, this.username, this.password, this.pic_box, this.camera_code);
            }
            else if (this.camera_type == "WEB_CAMERA")
            {
                this.can_stream = this.camera.streamWebCamera(this.webcam_name, this.pic_box);
            }
            else if (this.camera_type == "PREVIEW_IMAGE")
            {
                this.can_stream = true;
            }
            else
            {
                this.can_stream = true;
                base.Close();
            }
            if (!this.can_stream && (this.camera_type != "IP_CAMERA"))
            {
                MessageBox.Show(Resource.Camera_002, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else if (!this.can_stream)
            {
                base.Close();
            }
        }

        private void InitializeComponent()
        {
            this.pic_box = new PictureBox();
            ((ISupportInitialize) this.pic_box).BeginInit();
            base.SuspendLayout();
            this.pic_box.Location = new Point(12, 12);
            this.pic_box.Name = "pic_box";
            this.pic_box.Size = new Size(600, 450);
            this.pic_box.SizeMode = PictureBoxSizeMode.StretchImage;
            this.pic_box.TabIndex = 9;
            this.pic_box.TabStop = false;
            this.pic_box.Click += new EventHandler(this.pic_box_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x275, 0x1df);
            base.Controls.Add(this.pic_box);
            base.FormBorderStyle = FormBorderStyle.FixedSingle;
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormCameraPreview";
            base.ShowInTaskbar = false;
            base.SizeGripStyle = SizeGripStyle.Hide;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Camera Preview";
            base.FormClosing += new FormClosingEventHandler(this.FormCameraPreview_FormClosing);
            base.Load += new EventHandler(this.FormCameraPreview_Load);
            ((ISupportInitialize) this.pic_box).EndInit();
            base.ResumeLayout(false);
        }

        private void pic_box_Click(object sender, EventArgs e)
        {
            this.camera.CloseCurrentVideoSource();
            base.Close();
        }

        private void translate()
        {
            this.Text = Resource.Title_Camera_Preview;
        }
    }
}

