﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormTruckEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode;
        public string minTare;
        public string maxTare;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public int nCurrRowD;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public WBTable trans = new WBTable();
        private WBTable tblTanker = new WBTable();
        private string Box1;
        private string Box2;
        private string Box3;
        private string oldTransporter;
        private IContainer components = null;
        private Button button2;
        private Button button1;
        private CheckBox checkBox1;
        private TextBox textBox2;
        public TextBox textBox1;
        private Label label9;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label1;
        private Label label6;
        private Label label7;
        private TextBox textBox3;
        private TextBox textBox4;
        private Label label8;
        private TextBox textBox5;
        private Button button11;
        private TextBox textTransporter;
        private Label labelTransporterName;
        private Label label10;
        private CheckBox checkKuning;
        public TextBox textBoxTanker;
        private Label labelTanker;
        private Button buttonTanker;
        private TextBox txtAreaCode;
        private TextBox txtDigit;
        private TextBox txtLastCode;
        private Label label2;
        private Label label11;
        private Label label12;

        public FormTruckEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            if (WBSetting.region != "1")
            {
                TextBox[] aText = new TextBox[] { this.textBox1, this.textTransporter };
                if (Program.CheckEmpty(aText))
                {
                    return;
                }
            }
            else
            {
                TextBox[] aText = new TextBox[] { this.textBox1 };
                if (Program.CheckEmpty(aText))
                {
                    return;
                }
            }
            if (this.checkTransporter())
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_truck", "Select Uniq,deleted From wb_truck Where  " + WBData.CompanyLocation(" and ( Truck_Number='" + this.textBox1.Text + "')"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                    if ((this.pMode != "EDIT") || (this.textBox1.Text.Trim() == this.OldCode.Trim()))
                    {
                        goto TR_001F;
                    }
                    else
                    {
                        table2 = new WBTable();
                        table2.OpenTable("wb_transaction", "Select ref From wb_transaction where  " + WBData.Company(" and ( Truck_Number='" + this.zTable.DT.Rows[this.nCurrRow]["Truck_Number"].ToString() + "')"), WBData.conn);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            goto TR_0020;
                        }
                        else
                        {
                            string[] textArray1 = new string[13];
                            textArray1[0] = Resource.Mes_430;
                            textArray1[1] = " ";
                            textArray1[2] = this.OldCode;
                            textArray1[3] = " -> ";
                            textArray1[4] = this.textBox1.Text;
                            textArray1[5] = "\n\n";
                            textArray1[6] = Resource.Msg_Replace_Warning;
                            textArray1[7] = "( ";
                            textArray1[8] = table2.DT.Rows.Count.ToString();
                            textArray1[9] = " ";
                            textArray1[10] = Resource.Mes_047B;
                            textArray1[11] = " )\n\n";
                            textArray1[12] = Resource.Msg_Continue;
                            if (MessageBox.Show(string.Concat(textArray1), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.ReplaceAll = true;
                                goto TR_0020;
                            }
                            else
                            {
                                this.ReplaceAll = false;
                                this.textBox1.Focus();
                            }
                        }
                    }
                }
                else if (table.DT.Rows[0]["deleted"].ToString() == "Y")
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_623, Resource.Title_007, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_429, Resource.Title_007, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.textBox1.Focus();
                }
            }
            return;
        TR_001F:
            if (this.pMode == "EDIT")
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.Gatepass_003 },
                    textRefNo = { Text = this.textBox1.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            this.nCurrRowD = this.zTable.GetPosRec(this.zTable.uniq);
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRowD];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Truck_Number"] = this.textBox1.Text.ToString().Trim();
            this.zTable.DR["Description"] = this.textBox2.Text.ToString().Trim();
            this.zTable.DR["Transporter_Code"] = this.textTransporter.Text.ToString().Trim();
            this.zTable.DR["Tanker_No"] = this.textBoxTanker.Text;
            this.zTable.DR["Min_Tare"] = this.textBox3.Text;
            this.zTable.DR["Max_Tare"] = this.textBox4.Text;
            this.zTable.DR["Reason"] = this.textBox5.Text;
            this.zTable.DR["Black_List"] = this.checkBox1.Checked ? "Y" : "N";
            this.zTable.DR["Tipe"] = this.checkKuning.Checked ? "K" : "H";
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_truck", "SELECT uniq FROM wb_truck WHERE " + WBData.CompanyLocation(" AND truck_number = '" + this.textBox1.Text + "'"), WBData.conn);
                    this.logKey = table3.DT.Rows[0]["uniq"].ToString();
                    table3.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_truck", this.logKey, logField, logValue);
            }
            string str = "";
            if (this.pMode == "ADD")
            {
                string[] textArray4 = new string[] { "(Triggered add new truck in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                str = string.Concat(textArray4);
            }
            else if (this.pMode == "EDIT")
            {
                string[] textArray5 = new string[] { "(Triggered edit truck type in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                str = string.Concat(textArray5);
            }
            Program.copyToLoc("wb_truck", this.textBox1.Text, 0, this.changeReason + " " + str);
            if ((this.pMode == "EDIT") && (this.textBox1.Text != this.OldCode))
            {
                Program.copyToLoc("wb_truck", this.OldCode, 0, this.changeReason + " " + str);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
            }
            this.saved = true;
            Cursor.Current = Cursors.Default;
            base.Close();
            return;
        TR_0020:
            table2.Dispose();
            goto TR_001F;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransporter.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.labelTransporterName.Text = transporter.ReturnRow["Transporter_Name"].ToString();
                this.textTransporter.Focus();
            }
            transporter.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonTanker_Click(object sender, EventArgs e)
        {
            FormTanker tanker = new FormTanker {
                pMode = "CHOOSE"
            };
            tanker.ShowDialog();
            if (tanker.ReturnRow != null)
            {
                this.textBoxTanker.Text = tanker.ReturnRow["Tanker_No"].ToString();
                this.textBoxTanker.Focus();
            }
            tanker.Dispose();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            this.textBox5.Enabled = this.checkBox1.Checked;
            if (this.checkBox1.Checked)
            {
                this.textBox5.Focus();
            }
        }

        private bool checkTransporter()
        {
            bool flag10;
            this.trans.ReOpen();
            this.labelTransporterName.Text = "";
            string[] aField = new string[] { "transporter_code" };
            string[] aFind = new string[] { this.textTransporter.Text };
            int recNo = this.trans.GetRecNo(aField, aFind);
            if (recNo <= -1)
            {
                this.button11.PerformClick();
                this.textTransporter.Focus();
                flag10 = false;
            }
            else
            {
                bool flag2 = false;
                if (this.pMode == "EDIT")
                {
                    if (this.oldTransporter != this.textTransporter.Text.Trim())
                    {
                        flag2 = true;
                    }
                }
                else if (this.pMode == "ADD")
                {
                    flag2 = true;
                }
                if (flag2)
                {
                    bool flag7 = this.trans.DT.Rows[recNo]["deleted"].ToString() == "Y";
                    bool flag8 = this.trans.DT.Rows[recNo]["black_list"].ToString() == "Y";
                    if (!flag7)
                    {
                        if (flag8)
                        {
                            MessageBox.Show(Resource.Mes_612, Resource.Title_002);
                            this.textTransporter.Focus();
                            return false;
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_626, Resource.Title_002);
                        this.textTransporter.Focus();
                        return false;
                    }
                }
                this.textTransporter.Text = this.trans.DT.Rows[recNo]["Transporter_Code"].ToString().Trim();
                this.labelTransporterName.Text = this.trans.DT.Rows[recNo]["Transporter_Name"].ToString().Trim();
                flag10 = true;
            }
            return flag10;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTruckEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTruckEntry_Load(object sender, EventArgs e)
        {
            if (this.pMode == "EDIT")
            {
                this.txtAreaCode.Enabled = false;
                this.txtDigit.Enabled = false;
                this.txtLastCode.Enabled = false;
            }
            if (WBData.sTruckRegion == "2")
            {
                this.txtAreaCode.MaxLength = 3;
                this.label2.Text = "ex: AAA - 1234 - ZZZ";
            }
            else if (WBData.sTruckRegion == "3")
            {
                this.txtAreaCode.MaxLength = 3;
                this.txtDigit.MaxLength = 2;
                this.txtLastCode.MaxLength = 4;
                this.label2.Text = "ex: AAA - 12 - 1234";
            }
            else if (WBData.sTruckRegion != "4")
            {
                this.txtLastCode.MaxLength = 3;
            }
            else
            {
                this.txtAreaCode.MaxLength = 3;
                this.txtDigit.MaxLength = 2;
                this.txtLastCode.MaxLength = 4;
                this.label2.Text = "ex: AAA - 1A - 1234";
            }
            base.KeyPreview = true;
            this.labelTransporterName.Text = "";
            this.trans.OpenTable("wb_transporter", "Select Transporter_Code,Transporter_Name,Uniq,deleted,black_list From wb_transporter", WBData.conn);
            Program.AutoComp(this.trans, "Transporter_Code", this.textTransporter);
            this.tblTanker.OpenTable("wb_tanker", "Select Tanker_No, uniq from wb_tanker", WBData.conn);
            Program.AutoComp(this.tblTanker, "Tanker_No", this.textBoxTanker);
            this.minTare = "0";
            this.maxTare = "0";
            if (this.pMode != "ADD")
            {
                this.textTransporter.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Transporter_Code"].Value.ToString();
                this.textBoxTanker.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Tanker_No"].Value.ToString();
                this.textBox1.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Truck_Number"].Value.ToString();
                this.OldCode = this.textBox1.Text;
                this.textBox2.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Description"].Value.ToString();
                this.textBox3.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Min_Tare"].Value.ToString();
                this.textBox4.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Max_Tare"].Value.ToString();
                this.textBox5.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Reason"].Value.ToString();
                this.checkKuning.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Tipe"].Value.ToString() == "K";
                this.checkBox1.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Black_List"].Value.ToString() == "Y";
                this.checkBox1.Enabled = !this.checkBox1.Checked ? WBUser.CheckTrustee("BLACKLIST_TRUCK", "A") : WBUser.CheckTrustee("BLACKLIST_TRUCK", "E");
                this.textBox5.Enabled = this.checkBox1.Enabled && this.checkBox1.Checked;
                this.oldTransporter = this.textTransporter.Text;
            }
            if (this.pMode == "VIEW")
            {
                if (this.checkBox1.Checked)
                {
                    this.label9.Visible = true;
                    this.checkBox1.Visible = true;
                    this.label8.Visible = true;
                    this.textBox5.Visible = true;
                }
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.button2.Text = Resource.Btn_Close;
                this.button2.Enabled = true;
            }
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.checkBox1 = new CheckBox();
            this.textBox2 = new TextBox();
            this.textBox1 = new TextBox();
            this.label9 = new Label();
            this.label5 = new Label();
            this.label4 = new Label();
            this.label3 = new Label();
            this.label1 = new Label();
            this.label6 = new Label();
            this.label7 = new Label();
            this.textBox3 = new TextBox();
            this.textBox4 = new TextBox();
            this.label8 = new Label();
            this.textBox5 = new TextBox();
            this.button11 = new Button();
            this.textTransporter = new TextBox();
            this.labelTransporterName = new Label();
            this.label10 = new Label();
            this.checkKuning = new CheckBox();
            this.textBoxTanker = new TextBox();
            this.labelTanker = new Label();
            this.buttonTanker = new Button();
            this.txtAreaCode = new TextBox();
            this.txtDigit = new TextBox();
            this.txtLastCode = new TextBox();
            this.label2 = new Label();
            this.label11 = new Label();
            this.label12 = new Label();
            base.SuspendLayout();
            this.button2.Location = new Point(0x287, 380);
            this.button2.Margin = new Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new Size(100, 0x3a);
            this.button2.TabIndex = 9;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x203, 380);
            this.button1.Margin = new Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new Size(100, 0x3a);
            this.button1.TabIndex = 8;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.checkBox1.AutoSize = true;
            this.checkBox1.Enabled = false;
            this.checkBox1.Location = new Point(0xe8, 0x11b);
            this.checkBox1.Margin = new Padding(4, 4, 4, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new Size(80, 0x15);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "Blocked";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.Visible = false;
            this.checkBox1.CheckedChanged += new EventHandler(this.checkBox1_CheckedChanged);
            this.textBox2.Location = new Point(0xe8, 0x95);
            this.textBox2.Margin = new Padding(4, 4, 4, 4);
            this.textBox2.MaxLength = 150;
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x201, 0x38);
            this.textBox2.TabIndex = 3;
            this.textBox2.KeyPress += new KeyPressEventHandler(this.textBox2_KeyPress);
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(0xe8, 0x36);
            this.textBox1.Margin = new Padding(4, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0xdf, 0x16);
            this.textBox1.TabIndex = 2;
            this.textBox1.KeyPress += new KeyPressEventHandler(this.textBox1_KeyPress);
            this.label9.Enabled = false;
            this.label9.Location = new Point(0x18, 0x11c);
            this.label9.Margin = new Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new Size(200, 0x10);
            this.label9.TabIndex = 0x1c;
            this.label9.Text = "Blacklist";
            this.label9.TextAlign = ContentAlignment.MiddleRight;
            this.label9.Visible = false;
            this.label5.Location = new Point(0x18, 250);
            this.label5.Margin = new Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new Size(200, 0x10);
            this.label5.TabIndex = 0x18;
            this.label5.Text = "Maximum Tare";
            this.label5.TextAlign = ContentAlignment.MiddleRight;
            this.label4.Location = new Point(0x18, 0xd9);
            this.label4.Margin = new Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new Size(200, 0x10);
            this.label4.TabIndex = 0x17;
            this.label4.Text = "Minimum Tare";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            this.label3.Location = new Point(0x18, 0x99);
            this.label3.Margin = new Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new Size(200, 0x10);
            this.label3.TabIndex = 0x16;
            this.label3.Text = "Description";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.label1.Location = new Point(0x18, 0x31);
            this.label1.Margin = new Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new Size(200, 0x19);
            this.label1.TabIndex = 20;
            this.label1.Text = "Truck/Vehicle Number";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x165, 0xdb);
            this.label6.Margin = new Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x1c, 0x11);
            this.label6.TabIndex = 0x2e;
            this.label6.Text = "KG";
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0x165, 0xfc);
            this.label7.Margin = new Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x1c, 0x11);
            this.label7.TabIndex = 0x2f;
            this.label7.Text = "KG";
            this.textBox3.CharacterCasing = CharacterCasing.Upper;
            this.textBox3.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBox3.Location = new Point(0xe8, 0xd5);
            this.textBox3.Margin = new Padding(4, 4, 4, 4);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.RightToLeft = RightToLeft.No;
            this.textBox3.Size = new Size(0x74, 0x1a);
            this.textBox3.TabIndex = 4;
            this.textBox3.TabStop = false;
            this.textBox3.Text = "0";
            this.textBox3.TextAlign = HorizontalAlignment.Right;
            this.textBox3.KeyPress += new KeyPressEventHandler(this.textBox3_KeyPress);
            this.textBox3.Validating += new CancelEventHandler(this.textBox3_Validating);
            this.textBox4.CharacterCasing = CharacterCasing.Upper;
            this.textBox4.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBox4.Location = new Point(0xe8, 0xf6);
            this.textBox4.Margin = new Padding(4, 4, 4, 4);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.RightToLeft = RightToLeft.No;
            this.textBox4.Size = new Size(0x74, 0x1a);
            this.textBox4.TabIndex = 5;
            this.textBox4.TabStop = false;
            this.textBox4.Text = "0";
            this.textBox4.TextAlign = HorizontalAlignment.Right;
            this.textBox4.KeyPress += new KeyPressEventHandler(this.textBox4_KeyPress);
            this.label8.Enabled = false;
            this.label8.Location = new Point(0x18, 0x13a);
            this.label8.Margin = new Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new Size(200, 0x10);
            this.label8.TabIndex = 0x30;
            this.label8.Text = "Blacklist Reason";
            this.label8.TextAlign = ContentAlignment.MiddleRight;
            this.label8.Visible = false;
            this.textBox5.CharacterCasing = CharacterCasing.Upper;
            this.textBox5.Enabled = false;
            this.textBox5.Location = new Point(0xe8, 310);
            this.textBox5.Margin = new Padding(4, 4, 4, 4);
            this.textBox5.MaxLength = 100;
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new Size(0x201, 0x30);
            this.textBox5.TabIndex = 7;
            this.textBox5.Visible = false;
            this.textBox5.KeyPress += new KeyPressEventHandler(this.textBox5_KeyPress);
            this.button11.Location = new Point(0x1d4, 14);
            this.button11.Margin = new Padding(0);
            this.button11.Name = "button11";
            this.button11.Size = new Size(0x1f, 0x1c);
            this.button11.TabIndex = 1;
            this.button11.Text = "...";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new EventHandler(this.button11_Click);
            this.textTransporter.CharacterCasing = CharacterCasing.Upper;
            this.textTransporter.Location = new Point(0xe8, 15);
            this.textTransporter.Margin = new Padding(4, 4, 4, 4);
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.Size = new Size(0xdf, 0x16);
            this.textTransporter.TabIndex = 0;
            this.textTransporter.KeyPress += new KeyPressEventHandler(this.textTransporter_KeyPress);
            this.textTransporter.Leave += new EventHandler(this.textTransporter_Leave);
            this.labelTransporterName.AutoSize = true;
            this.labelTransporterName.Location = new Point(0x1f7, 20);
            this.labelTransporterName.Margin = new Padding(4, 0, 4, 0);
            this.labelTransporterName.Name = "labelTransporterName";
            this.labelTransporterName.Size = new Size(120, 0x11);
            this.labelTransporterName.TabIndex = 0x34;
            this.labelTransporterName.Text = "TransporterName";
            this.label10.Location = new Point(0x18, 20);
            this.label10.Margin = new Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new Size(200, 0x10);
            this.label10.TabIndex = 0x31;
            this.label10.Text = "Transporter";
            this.label10.TextAlign = ContentAlignment.MiddleRight;
            this.checkKuning.AutoSize = true;
            this.checkKuning.Location = new Point(0x204, 0x76);
            this.checkKuning.Margin = new Padding(4, 4, 4, 4);
            this.checkKuning.Name = "checkKuning";
            this.checkKuning.Size = new Size(0xe0, 0x15);
            this.checkKuning.TabIndex = 0x37;
            this.checkKuning.Text = "Yellow plate of Vehicle License";
            this.checkKuning.UseVisualStyleBackColor = true;
            this.textBoxTanker.CharacterCasing = CharacterCasing.Upper;
            this.textBoxTanker.Location = new Point(0xe8, 0x72);
            this.textBoxTanker.Margin = new Padding(4, 4, 4, 4);
            this.textBoxTanker.MaxLength = 20;
            this.textBoxTanker.Name = "textBoxTanker";
            this.textBoxTanker.Size = new Size(0xdf, 0x16);
            this.textBoxTanker.TabIndex = 0x48;
            this.textBoxTanker.KeyPress += new KeyPressEventHandler(this.textBoxTanker_KeyPress);
            this.textBoxTanker.Leave += new EventHandler(this.textBoxTanker_Leave);
            this.labelTanker.Location = new Point(0x18, 0x76);
            this.labelTanker.Margin = new Padding(4, 0, 4, 0);
            this.labelTanker.Name = "labelTanker";
            this.labelTanker.Size = new Size(200, 0x10);
            this.labelTanker.TabIndex = 0x49;
            this.labelTanker.Text = "Tanker No.";
            this.labelTanker.TextAlign = ContentAlignment.MiddleRight;
            this.buttonTanker.Location = new Point(0x1d5, 0x70);
            this.buttonTanker.Margin = new Padding(0);
            this.buttonTanker.Name = "buttonTanker";
            this.buttonTanker.Size = new Size(0x1f, 0x1c);
            this.buttonTanker.TabIndex = 0x4a;
            this.buttonTanker.Text = "...";
            this.buttonTanker.UseVisualStyleBackColor = true;
            this.buttonTanker.Click += new EventHandler(this.buttonTanker_Click);
            this.txtAreaCode.Location = new Point(0x2f, 0x18e);
            this.txtAreaCode.Margin = new Padding(4, 4, 4, 4);
            this.txtAreaCode.MaxLength = 2;
            this.txtAreaCode.Name = "txtAreaCode";
            this.txtAreaCode.ShortcutsEnabled = false;
            this.txtAreaCode.Size = new Size(0x2b, 0x16);
            this.txtAreaCode.TabIndex = 0x4b;
            this.txtAreaCode.Visible = false;
            this.txtAreaCode.TextChanged += new EventHandler(this.txtAreaCode_TextChanged);
            this.txtAreaCode.KeyPress += new KeyPressEventHandler(this.txtAreaCode_KeyPress);
            this.txtDigit.Location = new Point(0x76, 0x18e);
            this.txtDigit.Margin = new Padding(4, 4, 4, 4);
            this.txtDigit.MaxLength = 4;
            this.txtDigit.Name = "txtDigit";
            this.txtDigit.ShortcutsEnabled = false;
            this.txtDigit.Size = new Size(0x3f, 0x16);
            this.txtDigit.TabIndex = 0x4c;
            this.txtDigit.Visible = false;
            this.txtDigit.TextChanged += new EventHandler(this.txtDigit_TextChanged);
            this.txtDigit.KeyPress += new KeyPressEventHandler(this.txtDigit_KeyPress);
            this.txtLastCode.Location = new Point(0xd0, 0x18e);
            this.txtLastCode.Margin = new Padding(4, 4, 4, 4);
            this.txtLastCode.MaxLength = 4;
            this.txtLastCode.Name = "txtLastCode";
            this.txtLastCode.ShortcutsEnabled = false;
            this.txtLastCode.Size = new Size(0x3d, 0x16);
            this.txtLastCode.TabIndex = 0x4d;
            this.txtLastCode.Visible = false;
            this.txtLastCode.TextChanged += new EventHandler(this.txtLastCode_TextChanged);
            this.txtLastCode.KeyPress += new KeyPressEventHandler(this.txtLastCode_KeyPress);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x115, 0x192);
            this.label2.Margin = new Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x85, 0x11);
            this.label2.TabIndex = 0x4e;
            this.label2.Text = "ex: AA - 1234 - ZZZ";
            this.label2.Visible = false;
            this.label11.AutoSize = true;
            this.label11.Location = new Point(0x62, 0x192);
            this.label11.Margin = new Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new Size(13, 0x11);
            this.label11.TabIndex = 0x4f;
            this.label11.Text = "-";
            this.label11.Visible = false;
            this.label12.AutoSize = true;
            this.label12.Location = new Point(0xbc, 0x192);
            this.label12.Margin = new Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new Size(13, 0x11);
            this.label12.TabIndex = 80;
            this.label12.Text = "-";
            this.label12.Visible = false;
            base.AutoScaleDimensions = new SizeF(8f, 16f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x309, 0x1d2);
            base.ControlBox = false;
            base.Controls.Add(this.label12);
            base.Controls.Add(this.label11);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.txtLastCode);
            base.Controls.Add(this.txtDigit);
            base.Controls.Add(this.txtAreaCode);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.buttonTanker);
            base.Controls.Add(this.textBoxTanker);
            base.Controls.Add(this.labelTanker);
            base.Controls.Add(this.checkKuning);
            base.Controls.Add(this.button11);
            base.Controls.Add(this.textTransporter);
            base.Controls.Add(this.labelTransporterName);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.textBox5);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.textBox4);
            base.Controls.Add(this.textBox3);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.checkBox1);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label1);
            base.Margin = new Padding(4, 4, 4, 4);
            base.Name = "FormTruckEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormTruckEntry";
            base.Load += new EventHandler(this.FormTruckEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTruckEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                e.Handled = (!char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar)) && !char.IsWhiteSpace(e.KeyChar);
            }
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "0123456789-+.".IndexOfAny(anyOf) <= -1;
            }
        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "0123456789-+.".IndexOfAny(anyOf) <= -1;
            }
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBoxTanker_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textBoxTanker_Leave(object sender, EventArgs e)
        {
            if (this.textBoxTanker.Text.Trim() != "")
            {
                this.tblTanker.ReOpen();
                string[] aField = new string[] { "Tanker_No" };
                string[] aFind = new string[] { this.textBoxTanker.Text };
                int recNo = this.tblTanker.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.textBoxTanker.Text = this.tblTanker.DT.Rows[recNo]["Tanker_No"].ToString().Trim();
                }
                else
                {
                    this.buttonTanker.PerformClick();
                    this.textBoxTanker.Focus();
                }
            }
        }

        private void textTransporter_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransporter_Leave(object sender, EventArgs e)
        {
            this.checkTransporter();
        }

        private void translate()
        {
            this.label10.Text = Resource.TruckEntry_001;
            this.label1.Text = Resource.TruckEntry_002;
            this.label3.Text = Resource.TruckEntry_003;
            this.checkKuning.Text = Resource.TruckEntry_004;
            this.label4.Text = Resource.TruckEntry_005;
            this.label5.Text = Resource.TruckEntry_006;
            this.label9.Text = Resource.TruckEntry_008;
            this.checkBox1.Text = Resource.TruckEntry_009;
            this.label8.Text = Resource.TruckEntry_010;
            this.button1.Text = Resource.Save;
            this.button2.Text = Resource.Menu_Cancel;
            this.labelTanker.Text = Resource.Lbl_Tanker_No;
        }

        private void TruckNumber()
        {
            this.Box1 = this.txtAreaCode.Text;
            this.Box2 = this.txtDigit.Text;
            this.Box3 = this.txtLastCode.Text;
            string[] textArray1 = new string[] { this.Box1, " ", this.Box2, " ", this.Box3 };
            this.textBox1.Text = string.Concat(textArray1);
        }

        private void txtAreaCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            WBUtility.CheckInput(e, "A");
        }

        private void txtAreaCode_TextChanged(object sender, EventArgs e)
        {
            this.TruckNumber();
        }

        private void txtDigit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (WBData.sTruckRegion == "0")
            {
                WBUtility.CheckInput(e, "N");
            }
            else if (WBData.sTruckRegion == "1")
            {
                WBUtility.CheckInput(e, "N");
            }
            else if (WBData.sTruckRegion == "2")
            {
                WBUtility.CheckInput(e, "N");
            }
            else if (WBData.sTruckRegion == "3")
            {
                WBUtility.CheckInput(e, "N");
            }
            else if (WBData.sTruckRegion == "4")
            {
                WBUtility.CheckInput(e, "A|N");
            }
        }

        private void txtDigit_TextChanged(object sender, EventArgs e)
        {
            this.TruckNumber();
        }

        private void txtLastCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (WBData.sTruckRegion == "2")
            {
                WBUtility.CheckInput(e, "A|N");
            }
            else if (WBData.sTruckRegion == "3")
            {
                WBUtility.CheckInput(e, "N");
            }
            else if (WBData.sTruckRegion == "4")
            {
                WBUtility.CheckInput(e, "N");
            }
            else
            {
                WBUtility.CheckInput(e, "A");
            }
        }

        private void txtLastCode_TextChanged(object sender, EventArgs e)
        {
            this.TruckNumber();
        }
    }
}

