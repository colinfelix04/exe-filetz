﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTransactionTarraHistory : Form
    {
        private string cField = "";
        public string truck_number = "";
        private WBTable tblTrans = new WBTable();
        private IContainer components = null;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem closeToolStripMenuItem;
        private DataGridView dataGridView1;
        public Panel panel1;
        private CheckBox cb_include_split;

        public FormTransactionTarraHistory()
        {
            this.InitializeComponent();
        }

        private void cb_include_split_CheckedChanged(object sender, EventArgs e)
        {
            string[] textArray1 = new string[] { "select top (100) ", this.cField, " from vw_trans where ", WBData.CompanyLocation(" and truck_number = '" + this.truck_number.Trim() + "'  and (report_Date is not null or report_date <> '')"), " and (deleted is null or deleted = 'N') " };
            string sqltext = string.Concat(textArray1);
            if (!this.cb_include_split.Checked)
            {
                sqltext = sqltext + " and (split = 'N' or split = 'Y' or split = '' or split is null) ";
            }
            sqltext = sqltext + " order by report_Date desc";
            this.tblTrans.OpenTable("vw_trans", sqltext, WBData.conn);
            this.dataGridView1.DataSource = this.tblTrans.DV;
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1.Rows[e.RowIndex].Cells["TARE"].Value.ToString() == "0")
            {
                e.CellStyle.BackColor = Color.LightPink;
                e.CellStyle.SelectionBackColor = Color.LightCoral;
                e.CellStyle.SelectionForeColor = Color.Firebrick;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransactionTarraHistory_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTransactionTarraHistory_Load(object sender, EventArgs e)
        {
            this.Text = "Tare History for Truck : " + this.truck_number;
            this.cField = "Transaction_Code,Ref, Truck_Number, Report_Date,Comm_Name,Gross,Tare,Received,Deduction,Net";
            string[] textArray1 = new string[] { "select top (100) ", this.cField, " from vw_trans where ", WBData.CompanyLocation(" and truck_number = '" + this.truck_number.Trim() + "'  and (report_Date is not null or report_date <> '')"), " and (deleted is null or deleted = 'N') " };
            string sqltext = string.Concat(textArray1);
            if (!this.cb_include_split.Checked)
            {
                sqltext = sqltext + " and (split = 'N' or split = 'Y' or split = '' or split is null) ";
            }
            sqltext = sqltext + " order by report_Date desc";
            this.tblTrans.OpenTable("wb_transaction", sqltext, WBData.conn);
            this.dataGridView1.DataSource = this.tblTrans.DV;
            this.dataGridView1.Columns["Transaction_Code"].HeaderText = "Tx";
            this.dataGridView1.Columns["Truck_Number"].HeaderText = "Truck No.";
            this.dataGridView1.Columns["Comm_Name"].HeaderText = "Commodity";
            this.dataGridView1.Columns["ref"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridView1.Columns["Truck_Number"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridView1.Columns["Gross"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dataGridView1.Columns["Received"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dataGridView1.Columns["Tare"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dataGridView1.Columns["Tare"].DefaultCellStyle.Format = "N0";
            this.dataGridView1.Columns["Deduction"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dataGridView1.Columns["Deduction"].DefaultCellStyle.Format = "N0";
            this.dataGridView1.Columns["Net"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dataGridView1.Columns["Net"].DefaultCellStyle.Format = "N0";
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.menuStrip1 = new MenuStrip();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.panel1 = new Panel();
            this.cb_include_split = new CheckBox();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x321, 0x18);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x48, 20);
            this.closeToolStripMenuItem.Text = "&Close (Esc)";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = style;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = style2;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = style3;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x321, 350);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.cb_include_split);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x15c);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x321, 0x1a);
            this.panel1.TabIndex = 0x12;
            this.cb_include_split.AutoSize = true;
            this.cb_include_split.Location = new Point(12, 3);
            this.cb_include_split.Name = "cb_include_split";
            this.cb_include_split.Size = new Size(0x8f, 0x11);
            this.cb_include_split.TabIndex = 0;
            this.cb_include_split.Text = "Include Split Transaction";
            this.cb_include_split.UseVisualStyleBackColor = true;
            this.cb_include_split.CheckedChanged += new EventHandler(this.cb_include_split_CheckedChanged);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x321, 0x176);
            base.ControlBox = false;
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "FormTransactionTarraHistory";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Tarra History";
            base.Load += new EventHandler(this.FormTransactionTarraHistory_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransactionTarraHistory_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

