﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormRendemen : Form
    {
        private WBTable tbl_Rendemen = new WBTable();
        private WBTable tbl_Location = new WBTable();
        private IContainer components = null;
        private Label label1;
        private GroupBox groupBox2;
        private Button button3;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label3;
        private TextBox textFormula;
        private DataGridView dataGridView1;
        private TextBox textBJR;
        private TextBox textCPO;
        private TextBox textPK;
        private Button buttonDelete;
        private Button buttonAdd;
        private Label label2;
        private Label label4;
        private Label label11;
        private Button buttonSave;
        private Button buttonCancel;
        private Label label14;
        private Label label12;

        public FormRendemen()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ExpressionVariabel owner = new ExpressionVariabel();
            string pStr = (this.textFormula.Text.Trim() + " ~").ToUpper().Replace("Rend1".ToUpper(), "1").ToUpper().Replace("Rend2".ToUpper(), "1").ToUpper().Replace("BJR".ToUpper(), "1").Replace("~", "");
            owner.NET = 1.0;
            if (Program.eval(pStr, owner) == -999999999.0)
            {
                this.textFormula.Focus();
            }
            else
            {
                MessageBox.Show(Resource.Mes_170);
                this.button3.Focus();
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "BJR" };
            string[] aFind = new string[] { this.textBJR.Text.Trim() };
            if (this.tbl_Rendemen.GetRecNo(aField, aFind) > -1)
            {
                MessageBox.Show(Resource.Mes_198, Resource.Title_002);
            }
            else
            {
                this.tbl_Rendemen.DR = this.tbl_Rendemen.DT.NewRow();
                this.tbl_Rendemen.DR["Coy"] = WBData.sCoyCode;
                this.tbl_Rendemen.DR["Location_Code"] = WBData.sLocCode;
                this.tbl_Rendemen.DR["BJR"] = this.textBJR.Text;
                this.tbl_Rendemen.DR["Rend_CPO"] = this.textCPO.Text;
                this.tbl_Rendemen.DR["Rend_PK"] = this.textPK.Text;
                this.tbl_Rendemen.DT.Rows.Add(this.tbl_Rendemen.DR);
                this.tbl_Rendemen.Save();
                this.dataGridView1.Refresh();
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && (MessageBox.Show(Resource.Mes_197 + " " + this.dataGridView1.CurrentRow.Cells["BJR"].Value.ToString(), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes))
            {
                int posRec = this.tbl_Rendemen.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                this.tbl_Rendemen.ReOpen();
                this.tbl_Rendemen.DT.Rows[posRec].Delete();
                this.tbl_Rendemen.Save();
                this.tbl_Rendemen.ReOpen();
                this.dataGridView1.DataSource = this.tbl_Rendemen.DV;
                this.dataGridView1.Refresh();
                MessageBox.Show(Resource.Mes_199, Resource.Title_007);
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            this.tbl_Location.DR = this.tbl_Location.DT.Rows[0];
            this.tbl_Location.DR.BeginEdit();
            this.tbl_Location.DR["FormulaRendemen"] = this.textFormula.Text;
            this.tbl_Location.DR["checksum"] = this.tbl_Location.Checksum(this.tbl_Location.DR);
            this.tbl_Location.DR.EndEdit();
            this.tbl_Location.Save();
            WBSetting.ReOpen();
            base.Close();
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            this.tbl_Rendemen.Save();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormRendemen_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormRendemen_Load(object sender, EventArgs e)
        {
            this.tbl_Rendemen.OpenTable("wb_rendemen", "select * from wb_rendemen where " + WBData.CompanyLocation("") + " order by BJR asc", WBData.conn);
            this.tbl_Location.OpenTable("Wb_location", "select * from wb_location", WBData.conn);
            this.dataGridView1.DataSource = this.tbl_Rendemen.DV;
            this.textFormula.Text = WBSetting.Field("FormulaRendemen").ToString();
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["coy"].Visible = false;
            this.dataGridView1.Columns["location_code"].Visible = false;
            this.dataGridView1.Columns["BJR"].DefaultCellStyle.Format = "N2";
            this.dataGridView1.Columns["Rend_CPO"].DefaultCellStyle.Format = "N2";
            this.dataGridView1.Columns["Rend_PK"].DefaultCellStyle.Format = "N2";
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.groupBox2 = new GroupBox();
            this.label14 = new Label();
            this.label12 = new Label();
            this.button3 = new Button();
            this.label10 = new Label();
            this.label9 = new Label();
            this.label8 = new Label();
            this.label7 = new Label();
            this.label6 = new Label();
            this.label5 = new Label();
            this.label3 = new Label();
            this.textFormula = new TextBox();
            this.dataGridView1 = new DataGridView();
            this.textBJR = new TextBox();
            this.textCPO = new TextBox();
            this.textPK = new TextBox();
            this.buttonDelete = new Button();
            this.buttonAdd = new Button();
            this.label2 = new Label();
            this.label4 = new Label();
            this.label11 = new Label();
            this.buttonSave = new Button();
            this.buttonCancel = new Button();
            this.groupBox2.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x1aa, 9);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x2c, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Formula";
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new Point(0x1ad, 0x5d);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(410, 0xfb);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.label14.Location = new Point(0x2c, 0x52);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0xc4, 13);
            this.label14.TabIndex = 10;
            this.label14.Text = "~ Rend2 = % BJR Bulat ke Bawah";
            this.label14.Click += new EventHandler(this.label14_Click);
            this.label12.Location = new Point(0x2c, 60);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0xc4, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "~ Rend1 = % BJR Bulat ke Atas";
            this.button3.Location = new Point(0x142, 11);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x4b, 0x26);
            this.button3.TabIndex = 7;
            this.button3.Text = "Test Formula";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0x1d, 0xdd);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x14e, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "~ Logical  :   And,  Or,   Xor,   Not,   =,  <>,  >,  <,  >=,  <=,  true,  false";
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x1d, 0xc7);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0xb0, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "~ Arithmetic  :   +,  -,  *,  /,  ^,  %,  ( )";
            this.label8.AutoSize = true;
            this.label8.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label8.Location = new Point(6, 0xb1);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x4e, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "[ Operators ]";
            this.label7.AutoSize = true;
            this.label7.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label7.Location = new Point(6, 0x10);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x8b, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "[ Function && Variabels ]";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x2c, 0x85);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x8e, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "~ IF( Condition, Exp1, Exp2 )";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x2c, 110);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x71, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "~ ROUND( Exp, Dec )";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x2c, 0x24);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x99, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "~ BJR = Berat Jenis Rata-Rata";
            this.textFormula.Location = new Point(0x1ad, 30);
            this.textFormula.MaxLength = 100;
            this.textFormula.Name = "textFormula";
            this.textFormula.Size = new Size(410, 20);
            this.textFormula.TabIndex = 5;
            this.textFormula.Text = "Rend1+(BJR-Round(BJR,0))*(Rend2-Rend1)";
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new Point(0x18, 0x90);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new Size(0x178, 390);
            this.dataGridView1.TabIndex = 7;
            this.dataGridView1.CellEndEdit += new DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
            this.textBJR.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR.Location = new Point(0x4f, 12);
            this.textBJR.Name = "textBJR";
            this.textBJR.Size = new Size(0x39, 0x16);
            this.textBJR.TabIndex = 8;
            this.textBJR.Text = "0";
            this.textBJR.TextAlign = HorizontalAlignment.Right;
            this.textBJR.Leave += new EventHandler(this.textBJR_Leave);
            this.textCPO.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textCPO.Location = new Point(0x4f, 40);
            this.textCPO.Name = "textCPO";
            this.textCPO.Size = new Size(0x39, 0x16);
            this.textCPO.TabIndex = 9;
            this.textCPO.Text = "0";
            this.textCPO.TextAlign = HorizontalAlignment.Right;
            this.textCPO.Leave += new EventHandler(this.textCPO_Leave);
            this.textPK.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textPK.Location = new Point(0x4f, 0x44);
            this.textPK.Name = "textPK";
            this.textPK.Size = new Size(0x39, 0x16);
            this.textPK.TabIndex = 10;
            this.textPK.Text = "0";
            this.textPK.TextAlign = HorizontalAlignment.Right;
            this.textPK.Leave += new EventHandler(this.textPK_Leave);
            this.buttonDelete.Location = new Point(0x145, 0x5e);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new Size(0x4b, 0x2c);
            this.buttonDelete.TabIndex = 12;
            this.buttonDelete.Text = "DELETE";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new EventHandler(this.buttonDelete_Click);
            this.buttonAdd.Location = new Point(0xe7, 0x5e);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new Size(0x4b, 0x2c);
            this.buttonAdd.TabIndex = 13;
            this.buttonAdd.Text = "ADD";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new EventHandler(this.buttonAdd_Click);
            this.label2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label2.Location = new Point(12, 15);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x3d, 0x10);
            this.label2.TabIndex = 14;
            this.label2.Text = "BJR";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.label2.Click += new EventHandler(this.label2_Click);
            this.label4.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label4.Location = new Point(12, 0x2b);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x3d, 0x10);
            this.label4.TabIndex = 15;
            this.label4.Text = "CPO (%)";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            this.label11.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label11.Location = new Point(12, 0x47);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x3d, 0x10);
            this.label11.TabIndex = 0x10;
            this.label11.Text = "PK (%)";
            this.label11.TextAlign = ContentAlignment.MiddleRight;
            this.buttonSave.Location = new Point(0x2d5, 0x197);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x72, 0x2c);
            this.buttonSave.TabIndex = 0x11;
            this.buttonSave.Text = "&SAVE";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.buttonCancel.Location = new Point(0x2d5, 0x1d3);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x71, 0x2c);
            this.buttonCancel.TabIndex = 0x12;
            this.buttonCancel.Text = "&EXIT";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x367, 0x222);
            base.ControlBox = false;
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.label11);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.buttonAdd);
            base.Controls.Add(this.buttonDelete);
            base.Controls.Add(this.textPK);
            base.Controls.Add(this.textCPO);
            base.Controls.Add(this.textBJR);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.textFormula);
            base.Controls.Add(this.label1);
            base.KeyPreview = true;
            base.Name = "FormRendemen";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Formula Rendemen";
            base.Load += new EventHandler(this.FormRendemen_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormRendemen_KeyPress);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void label14_Click(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void textBJR_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR);
            this.textBJR.Text = $"{Program.StrToDouble(this.textBJR.Text, 2):N2}";
        }

        private void textCPO_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textCPO);
        }

        private void textPK_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textPK);
        }

        private void translate()
        {
            this.label1.Text = Resource.Grade_004;
            this.label14.Text = "~ Rend2 = % " + Resource.Lbl_BJR_Round_Down;
            this.label12.Text = "~ Rend1 = % " + Resource.Lbl_BJR_Round_Up;
            this.label10.Text = "~ " + Resource.Lbl_Logical + "  :   And,  Or,   Xor,   Not,   =,  <>,  >,  <,  >=,  <=,  true,  false";
            this.label9.Text = "~ " + Resource.Lbl_Arithmetic + "  :   +,  -,  *,  /,  ^,  %,  ( )";
            this.label8.Text = "[ " + Resource.Lbl_Operators + " ]";
            this.label7.Text = "[ " + Resource.Lbl_Functions_Variables + " ]";
            this.label3.Text = "~ " + Resource.DivBlock_005 + " = " + Resource.Lbl_BJR_Full;
            this.label2.Text = Resource.DivBlock_005;
            this.label4.Text = Resource.Lbl_CPO + " (%)";
            this.label11.Text = Resource.Lbl_PK + " (%)";
            this.button3.Text = Resource.Grade_006;
            this.buttonDelete.Text = Resource.Trans_057;
            this.buttonAdd.Text = Resource.Trans_055;
            this.buttonSave.Text = Resource.Menu_Save;
            this.buttonCancel.Text = Resource.Menu_Exit;
            this.Text = Resource.Menu_043;
        }
    }
}

