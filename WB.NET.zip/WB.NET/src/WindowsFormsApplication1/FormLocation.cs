﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormLocation : Form
    {
        public WBTable ztable = new WBTable();
        public string pMode;
        public string pCoy;
        public int nCurrRow;
        public DataRow ReturnRow;
        private IContainer components = null;
        public ToolStripMenuItem closeToolStripMenuItem;
        public MenuStrip menuStrip1;
        private ToolStripMenuItem toolStripMenuItem1;
        private DataGridView dataGridView1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem aDDToolStripMenuItem;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem viewRecordToolStripMenuItem;

        public FormLocation()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void aDDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormLocationEntry entry = new FormLocationEntry();
            if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                entry.pMode = "ADD";
                entry.zTable = this.ztable;
                entry.Text = Resource.Title_Add_Location;
                entry.dataGridView1 = this.dataGridView1;
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                    string[] aField = new string[] { "coy", "location_Code" };
                    string[] aFind = new string[] { entry.textCoyCode.Text, entry.textLocCode.Text };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                entry.Dispose();
                this.ztable.UnLock();
                if (this.dataGridView1.RowCount > 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = true;
                    this.editToolStripMenuItem.Enabled = true;
                    this.deleteToolStripMenuItem.Enabled = true;
                    this.toolStripMenuItem1.Enabled = true;
                }
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.toolStripMenuItem1.PerformClick();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.toolStripMenuItem1.PerformClick();
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt16(WBUser.UserLevel) > 2)
            {
                MessageBox.Show(Resource.Mes_180, Resource.Title_002);
            }
            else
            {
                WBTable table = new WBTable();
                string[] textArray1 = new string[] { "select * from wb_transaction where coy = '", this.dataGridView1.CurrentRow.Cells["Coy"].Value.ToString().Trim(), "' and location_code = '", this.dataGridView1.CurrentRow.Cells["Location_code"].Value.ToString().Trim(), "'" };
                table.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    MessageBox.Show(Resource.Mes_179 + " " + table.DT.Rows.Count.ToString(), Resource.Title_002);
                }
                else if (this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
                {
                    this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                    if (MessageBox.Show(this.ztable.DT.Rows[this.nCurrRow]["Coy"].ToString() + ".\n\n " + Resource.Mes_006, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        this.ztable.ReOpen();
                        this.ztable.DT.Rows[this.nCurrRow].Delete();
                        this.ztable.Save();
                        this.ztable.ReOpen();
                        this.ztable.AfterEdit("DELETE");
                    }
                    if (this.dataGridView1.RowCount == 0)
                    {
                        this.viewRecordToolStripMenuItem.Enabled = false;
                        this.editToolStripMenuItem.Enabled = false;
                        this.deleteToolStripMenuItem.Enabled = false;
                        this.toolStripMenuItem1.Enabled = false;
                    }
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.ztable.DT.Rows.Count != 0) && this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                FormLocationEntry entry = new FormLocationEntry {
                    pMode = "EDIT",
                    zTable = this.ztable,
                    Text = Resource.Title_Edit_Location,
                    nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                    string[] aField = new string[] { "Coy", "Location_Code" };
                    string[] aFind = new string[] { entry.textCoyCode.Text, entry.textLocCode.Text };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                entry.Dispose();
                this.ztable.UnLock();
            }
        }

        private void FormLocation_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormLocation_Load(object sender, EventArgs e)
        {
            string sqltext = "SELECT * FROM wb_location";
            if (this.pMode == "CHOOSE")
            {
                sqltext = "SELECT Coy, Location_Code, Location_Name, CoySAP, Uniq FROM wb_location where Coy='" + this.pCoy + "' ORDER BY Coy, Location_Code";
            }
            this.ztable.OpenTable("wb_location", sqltext, WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Coy"], ListSortDirection.Ascending);
            if (this.pMode == "CHOOSE")
            {
                this.dataGridView1.Columns["Coy"].Visible = false;
                this.dataGridView1.Columns["Uniq"].Visible = false;
                this.dataGridView1.Columns["Location_Code"].HeaderText = Resource.Setting_004;
                this.dataGridView1.Columns["Location_Name"].HeaderText = Resource.Col_Location_Name;
            }
            this.toolStripMenuItem1.Visible = this.pMode == "CHOOSE";
            this.dataGridView1.ReadOnly = this.pMode == "CHOOSE";
            base.KeyPreview = true;
            if (this.dataGridView1.RowCount == 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = false;
                this.editToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
                this.toolStripMenuItem1.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.aDDToolStripMenuItem = new ToolStripMenuItem();
            this.editToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            base.SuspendLayout();
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.toolStripMenuItem1, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x1f2, 0x18);
            this.menuStrip1.TabIndex = 0x15;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.aDDToolStripMenuItem, this.viewRecordToolStripMenuItem, this.editToolStripMenuItem, this.deleteToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.aDDToolStripMenuItem.Name = "aDDToolStripMenuItem";
            this.aDDToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.aDDToolStripMenuItem.Text = "Add New Record";
            this.aDDToolStripMenuItem.Click += new EventHandler(this.aDDToolStripMenuItem_Click);
            this.editToolStripMenuItem.Enabled = false;
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Click += new EventHandler(this.editToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0x3b, 20);
            this.toolStripMenuItem1.Text = "Choose";
            this.toolStripMenuItem1.Click += new EventHandler(this.toolStripMenuItem1_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x1f2, 0x11c);
            this.dataGridView1.TabIndex = 0x19;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1f2, 0x134);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.Name = "FormLocation";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Form Location";
            base.Load += new EventHandler(this.FormLocation_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormLocation_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.toolStripMenuItem1.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.aDDToolStripMenuItem.Text = Resource.Menu_Add;
            this.editToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.Text = Resource.Title_Location;
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormLocationEntry entry = new FormLocationEntry {
                    pMode = "VIEW",
                    zTable = this.ztable,
                    Text = Resource.Title_View_Location,
                    nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                this.ztable.UnLock();
                entry.Dispose();
            }
        }
    }
}

