﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormVendor : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private DataTable updTable = new DataTable();
        private DataTable retTable = new DataTable();
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private string[] zwbResult = new string[3];
        private string[] zwbRow = new string[20];
        private IContainer components = null;
        private DataGridView dataGridView1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        public TextBox TextFind;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem closeToolStripMenuItem;
        public Panel panel1;
        public Button buttonFind;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem printToolStripMenuItem;
        private ToolStripMenuItem chooseToolStripMenuItem;
        private ToolStripMenuItem zWBToolStripMenuItem;
        private ToolStripMenuItem synchronizeToZWBToolStripMenuItem;
        private ToolStripMenuItem synchronizeAllToolStripMenuItem;
        private ProgressBar progressBar1;
        private ToolStripMenuItem negoNumberToolStripMenuItemPOM;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem copyToAllLocationsToolStripMenuItem;
        private ToolStripMenuItem copyThisVendorToolStripMenuItem;
        private ToolStripMenuItem copyAllVendorsToolStripMenuItem;
        private ToolStripMenuItem viewRecordToolStripMenuItem;

        public FormVendor()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void activitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            WBSetting.OpenSetting();
            this.zWBToolStripMenuItem.Visible = WBSetting.zwb == "Y";
            this.negoNumberToolStripMenuItemPOM.Visible = WBSetting.locType != "0";
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormVendorEntry entry = new FormVendorEntry {
                    pMode = "ADD",
                    zTable = this.ztable,
                    Text = Resource.Title_Add_Relation,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                    string[] aField = new string[] { "Relation_code" };
                    string[] aFind = new string[] { entry.textBoxRelationCode.Text };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                this.ztable.UnLock();
                entry.Dispose();
                if (this.dataGridView1.RowCount > 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = true;
                    this.editRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_VENDOR", "E");
                    this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_VENDOR", "D");
                    this.printToolStripMenuItem.Enabled = true;
                    this.zWBToolStripMenuItem.Enabled = !WBSetting.integrationIDSYS;
                    this.negoNumberToolStripMenuItemPOM.Enabled = true;
                    this.copyToAllLocationsToolStripMenuItem.Enabled = true;
                    this.chooseToolStripMenuItem.Enabled = true;
                }
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void copyAllVendorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this.dataGridView1.Rows.Count + " " + Resource.Mes_Confirm_Copy_Relation, Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Program.copyToLoc("wb_relation", "", 1, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                MessageBox.Show(Resource.Mes_Relation_Copied);
            }
        }

        private void copyThisVendorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string key = this.dataGridView1.CurrentRow.Cells["relation_code"].Value.ToString().Trim();
            string str = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString().Trim();
            if (MessageBox.Show(key + ": " + Resource.Mes_Confirm_Copy, Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Program.copyToLoc("wb_relation", key, 0, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                MessageBox.Show(Resource.Mes_Copied_All_Location);
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseToolStripMenuItem.PerformClick();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1.Rows[e.RowIndex].Cells["black_list"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Red;
                e.CellStyle.SelectionBackColor = Color.HotPink;
            }
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.chooseToolStripMenuItem.PerformClick();
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count > 0)
            {
                this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                WBTable table = new WBTable();
                table.OpenTable("wb_transaction", "Select ref From wb_transDO where " + WBData.Company(" and ( Relation_Code='" + this.ztable.DT.Rows[this.nCurrRow]["Relation_Code"].ToString() + "')"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    string[] textArray2 = new string[] { this.ztable.DT.Rows[this.nCurrRow]["Relation_Code"].ToString(), " - ", this.ztable.DT.Rows[this.nCurrRow]["Relation_Name"].ToString(), ".\n\n ", Resource.Mes_006 };
                    if (MessageBox.Show(string.Concat(textArray2), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        if (this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
                        {
                            FormTransCancel cancel = new FormTransCancel {
                                label1 = { Text = Resource.VendorE_001 },
                                textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Relation_Code"].ToString() },
                                Text = Resource.Form_Delete_Reason,
                                label2 = { Text = Resource.Lbl_Delete_Reason }
                            };
                            cancel.textReason.Focus();
                            cancel.ShowDialog();
                            if (cancel.Saved)
                            {
                                this.changeReason = cancel.textReason.Text;
                                cancel.Dispose();
                                this.ztable.ReOpen();
                                this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                                this.ztable.DT.Rows[this.nCurrRow].Delete();
                                this.ztable.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                                Program.updateLogHeader("wb_relation", this.logKey, logField, logValue);
                                this.ztable.ReOpen();
                                this.ztable.AfterEdit("DELETE");
                            }
                            else
                            {
                                return;
                            }
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                else
                {
                    string[] textArray1 = new string[] { Resource.Mes_047A, "\n ( ", table.DT.Rows.Count.ToString(), " ", Resource.Mes_047B, ")" };
                    MessageBox.Show(string.Concat(textArray1), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.ztable.UnLock();
                table.Dispose();
                if (this.dataGridView1.RowCount == 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = false;
                    this.editRecordToolStripMenuItem.Enabled = false;
                    this.deleteToolStripMenuItem.Enabled = false;
                    this.printToolStripMenuItem.Enabled = false;
                    this.zWBToolStripMenuItem.Enabled = false;
                    this.negoNumberToolStripMenuItemPOM.Enabled = false;
                    this.copyToAllLocationsToolStripMenuItem.Enabled = false;
                    this.chooseToolStripMenuItem.Enabled = false;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                FormVendorEntry entry = new FormVendorEntry {
                    pMode = "EDIT",
                    zTable = this.ztable,
                    Text = Resource.Title_Edit_Relation,
                    dataGridView1 = this.dataGridView1,
                    nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString())
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                }
                this.ztable.UnLock();
                entry.Dispose();
            }
        }

        private void FormVendor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormVendor_Load(object sender, EventArgs e)
        {
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 20)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    this.retTable.Columns.Add(column);
                    column.Dispose();
                    this.progressBar1.Visible = false;
                    string str = "Coy,Location_Code,Relation_Code,Relation_Type,Relation_Name,Address,City,Phone,Fax,Contact_Person,Estate_Code,SAP_Code,Nego,ISCC,Black_List,DailyQuantity,Quantity,Create_By,Create_Date,Change_By,Change_Date,Delete_By,Delete_Date,Deleted,zwb,token,uniq,completed";
                    if (this.pFilter != "")
                    {
                        this.ztable.OpenTable("wb_relation", "SELECT " + str + " FROM wb_relation Where " + WBData.CompanyLocation(this.pFilter), WBData.conn);
                    }
                    else
                    {
                        this.ztable.OpenTable("wb_relation", "SELECT " + str + " FROM wb_relation", WBData.conn);
                    }
                    this.dataGridView1.DataSource = this.ztable.DT;
                    this.dataGridView1.Sort(this.dataGridView1.Columns["Relation_Code"], ListSortDirection.Ascending);
                    this.dataGridView1.Columns["Coy"].Visible = false;
                    this.dataGridView1.Columns["Location_Code"].Visible = false;
                    this.dataGridView1.Columns["Delete_By"].Visible = false;
                    this.dataGridView1.Columns["Delete_Date"].Visible = false;
                    this.dataGridView1.Columns["uniq"].Visible = false;
                    this.dataGridView1.Columns["Estate_Code"].Visible = false;
                    this.dataGridView1.Columns["Nego"].Visible = false;
                    this.dataGridView1.Columns["deleted"].Visible = false;
                    this.dataGridView1.Columns["token"].Visible = true;
                    this.dataGridView1.Columns["completed"].Visible = true;
                    this.dataGridView1.Columns["Relation_Code"].HeaderText = Resource.VendorE_001;
                    this.dataGridView1.Columns["Relation_Name"].HeaderText = Resource.VendorE_002;
                    this.dataGridView1.Columns["Address"].HeaderText = Resource.VendorE_003;
                    this.dataGridView1.Columns["City"].HeaderText = Resource.VendorE_004;
                    this.dataGridView1.Columns["Phone"].HeaderText = Resource.VendorE_005;
                    this.dataGridView1.Columns["Fax"].HeaderText = Resource.VendorE_006;
                    this.dataGridView1.Columns["Contact_Person"].HeaderText = Resource.VendorE_007;
                    this.dataGridView1.Columns["SAP_Code"].HeaderText = this.sapIDSYS + Resource.VendorE_008;
                    this.dataGridView1.Columns["Black_List"].HeaderText = Resource.VendorE_009;
                    this.dataGridView1.Columns["Relation_Type"].HeaderText = Resource.VendorE_011;
                    base.KeyPreview = true;
                    if (!WBUser.CheckTrustee("MD_VENDOR", "A"))
                    {
                        this.addNewRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_VENDOR", "E"))
                    {
                        this.editRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_VENDOR", "D"))
                    {
                        this.deleteToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_VENDOR", "P"))
                    {
                        this.printToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_SYNCH", "A"))
                    {
                        this.zWBToolStripMenuItem.Enabled = false;
                    }
                    if ((this.pMode != "") && (this.pFind.Trim() != ""))
                    {
                        this.TextFind.Text = this.pFind;
                        this.buttonFind.PerformClick();
                    }
                    this.chooseToolStripMenuItem.Visible = this.pMode != "";
                    this.copyToAllLocationsToolStripMenuItem.Enabled = (WBSetting.copyToLoc == "Y") && (WBUser.CheckTrustee("MD_VENDOR", "A") || WBUser.CheckTrustee("MD_VENDOR", "E"));
                    if (this.dataGridView1.RowCount == 0)
                    {
                        this.viewRecordToolStripMenuItem.Enabled = false;
                        this.editRecordToolStripMenuItem.Enabled = false;
                        this.deleteToolStripMenuItem.Enabled = false;
                        this.printToolStripMenuItem.Enabled = false;
                        this.zWBToolStripMenuItem.Enabled = false;
                        this.negoNumberToolStripMenuItemPOM.Enabled = false;
                        this.copyToAllLocationsToolStripMenuItem.Enabled = false;
                        this.chooseToolStripMenuItem.Enabled = false;
                    }
                    return;
                }
                column = new DataColumn();
                this.updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        private void InitializeComponent()
        {
            this.dataGridView1 = new DataGridView();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.printToolStripMenuItem = new ToolStripMenuItem();
            this.zWBToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeToZWBToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeAllToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator1 = new ToolStripSeparator();
            this.negoNumberToolStripMenuItemPOM = new ToolStripMenuItem();
            this.copyToAllLocationsToolStripMenuItem = new ToolStripMenuItem();
            this.copyThisVendorToolStripMenuItem = new ToolStripMenuItem();
            this.copyAllVendorsToolStripMenuItem = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.menuStrip1 = new MenuStrip();
            this.chooseToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.buttonFind = new Button();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x337, 0x164);
            this.dataGridView1.TabIndex = 7;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            ToolStripItem[] toolStripItems = new ToolStripItem[9];
            toolStripItems[0] = this.addNewRecordToolStripMenuItem;
            toolStripItems[1] = this.viewRecordToolStripMenuItem;
            toolStripItems[2] = this.editRecordToolStripMenuItem;
            toolStripItems[3] = this.deleteToolStripMenuItem;
            toolStripItems[4] = this.printToolStripMenuItem;
            toolStripItems[5] = this.zWBToolStripMenuItem;
            toolStripItems[6] = this.toolStripSeparator1;
            toolStripItems[7] = this.negoNumberToolStripMenuItemPOM;
            toolStripItems[8] = this.copyToAllLocationsToolStripMenuItem;
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(toolStripItems);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.activitiesToolStripMenuItem.Click += new EventHandler(this.activitiesToolStripMenuItem_Click);
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(190, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(190, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(190, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new Size(190, 0x16);
            this.printToolStripMenuItem.Text = "Print";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.synchronizeToZWBToolStripMenuItem, this.synchronizeAllToolStripMenuItem };
            this.zWBToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.zWBToolStripMenuItem.Name = "zWBToolStripMenuItem";
            this.zWBToolStripMenuItem.Size = new Size(190, 0x16);
            this.zWBToolStripMenuItem.Text = "ZWB";
            this.synchronizeToZWBToolStripMenuItem.Name = "synchronizeToZWBToolStripMenuItem";
            this.synchronizeToZWBToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeToZWBToolStripMenuItem.Text = "Synchronize";
            this.synchronizeToZWBToolStripMenuItem.Click += new EventHandler(this.synchronizeToZWBToolStripMenuItem_Click);
            this.synchronizeAllToolStripMenuItem.Name = "synchronizeAllToolStripMenuItem";
            this.synchronizeAllToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeAllToolStripMenuItem.Text = "Synchronize All";
            this.synchronizeAllToolStripMenuItem.Click += new EventHandler(this.synchronizeAllToolStripMenuItem_Click);
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new Size(0xbb, 6);
            this.negoNumberToolStripMenuItemPOM.Name = "negoNumberToolStripMenuItemPOM";
            this.negoNumberToolStripMenuItemPOM.Size = new Size(190, 0x16);
            this.negoNumberToolStripMenuItemPOM.Text = "Nego Number";
            this.negoNumberToolStripMenuItemPOM.Click += new EventHandler(this.negoNumberToolStripMenuItem_Click);
            ToolStripItem[] itemArray3 = new ToolStripItem[] { this.copyThisVendorToolStripMenuItem, this.copyAllVendorsToolStripMenuItem };
            this.copyToAllLocationsToolStripMenuItem.DropDownItems.AddRange(itemArray3);
            this.copyToAllLocationsToolStripMenuItem.Name = "copyToAllLocationsToolStripMenuItem";
            this.copyToAllLocationsToolStripMenuItem.Size = new Size(190, 0x16);
            this.copyToAllLocationsToolStripMenuItem.Text = "Copy To All Locations";
            this.copyThisVendorToolStripMenuItem.Name = "copyThisVendorToolStripMenuItem";
            this.copyThisVendorToolStripMenuItem.Size = new Size(0xa8, 0x16);
            this.copyThisVendorToolStripMenuItem.Text = "Copy This Vendor";
            this.copyThisVendorToolStripMenuItem.Click += new EventHandler(this.copyThisVendorToolStripMenuItem_Click);
            this.copyAllVendorsToolStripMenuItem.Name = "copyAllVendorsToolStripMenuItem";
            this.copyAllVendorsToolStripMenuItem.Size = new Size(0xa8, 0x16);
            this.copyAllVendorsToolStripMenuItem.Text = "Copy All Vendors";
            this.copyAllVendorsToolStripMenuItem.Click += new EventHandler(this.copyAllVendorsToolStripMenuItem_Click);
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] itemArray4 = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(itemArray4);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x337, 0x18);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            this.chooseToolStripMenuItem.Name = "chooseToolStripMenuItem";
            this.chooseToolStripMenuItem.Size = new Size(0x3b, 20);
            this.chooseToolStripMenuItem.Text = "Choose";
            this.chooseToolStripMenuItem.Click += new EventHandler(this.chooseToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 380);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x337, 0x21);
            this.panel1.TabIndex = 8;
            this.progressBar1.Location = new Point(0x290, 9);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xa7, 0x11);
            this.progressBar1.TabIndex = 10;
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(190, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x337, 0x19d);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.KeyPreview = true;
            base.Name = "FormVendor";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of Relation ( Customer/Vendor)";
            base.Load += new EventHandler(this.FormVendor_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormVendor_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void negoNumberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.Rows.Count <= 0)
            {
                MessageBox.Show(Resource.Mes_469, Resource.Title_007);
            }
            else
            {
                FormVendorNego nego = new FormVendorNego {
                    rCode = this.dataGridView1.CurrentRow.Cells["Relation_code"].Value.ToString()
                };
                nego.ShowDialog();
                nego.Dispose();
            }
        }

        private void synchronizeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int count = this.dataGridView1.Rows.Count;
            this.updTable.Rows.Clear();
            this.retTable.Rows.Clear();
            if (MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_035_IDSYS : Resource.Mes_035, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.progressBar1.Visible = true;
                this.progressBar1.Maximum = count;
                if (WBSetting.activeMulesoftIntegration)
                {
                    Sync.sync_relation_with_mulesoft(WBData.CompanyLocation(""));
                }
                else
                {
                    Sync.sync_relation(WBData.CompanyLocation(""));
                }
                this.progressBar1.Visible = false;
            }
        }

        private void synchronizeToZWBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str2 = this.dataGridView1.CurrentRow.Cells["Relation_Code"].Value.ToString().Trim();
            string str = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString().Trim();
            if (MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_034_IDSYS : (Resource.Mes_034 + " " + str2), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                if (WBSetting.activeMulesoftIntegration)
                {
                    Sync.sync_relation_with_mulesoft("uniq = '" + str + "'");
                }
                else
                {
                    Sync.sync_relation("uniq = '" + str + "'");
                }
            }
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseToolStripMenuItem.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
            this.printToolStripMenuItem.Text = Resource.Menu_016;
            this.zWBToolStripMenuItem.Text = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.Contract_068;
            this.synchronizeToZWBToolStripMenuItem.Text = Resource.Menu_Synchronize;
            this.synchronizeAllToolStripMenuItem.Text = Resource.Menu_Synchronize_All;
            this.negoNumberToolStripMenuItemPOM.Text = Resource.Menu_Nego_No;
            this.copyToAllLocationsToolStripMenuItem.Text = Resource.Menu_Copy_To_All_Locations;
            this.copyThisVendorToolStripMenuItem.Text = Resource.Menu_Copy_Vendor;
            this.copyAllVendorsToolStripMenuItem.Text = Resource.Menu_Copy_All_Vendor;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.Text = Resource.Title_Relation;
            if (WBSetting.integrationIDSYS)
            {
                this.zWBToolStripMenuItem.Text = "IDSYS";
                this.zWBToolStripMenuItem.Enabled = false;
            }
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormVendorEntry entry = new FormVendorEntry {
                    pMode = "VIEW",
                    zTable = this.ztable,
                    Text = Resource.Title_View_Relation,
                    nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                this.ztable.UnLock();
                entry.Dispose();
            }
        }
    }
}

