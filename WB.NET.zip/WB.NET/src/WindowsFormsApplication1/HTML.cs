﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.IO;

    public class HTML : Component
    {
        public string Title = "WB.NET - HTML Report";
        public string File = Application.UserAppDataPath;
        public StreamWriter txt;

        public void Close()
        {
            this.txt.Close();
        }

        public void Open()
        {
            this.txt = new StreamWriter(this.File);
        }

        public string space(int nbr)
        {
            string str = "&nbsp";
            for (int i = 0; i < nbr; i++)
            {
                str = str + "&nbsp";
            }
            return str;
        }

        public string spaceLeft(string text, int nbr)
        {
            nbr -= text.Length;
            for (int i = 0; i < nbr; i++)
            {
                text = "&nbsp" + text;
            }
            return text;
        }

        public string spaceRight(string text, int nbr)
        {
            nbr -= text.Length;
            for (int i = 0; i < nbr; i++)
            {
                text = text + "&nbsp";
            }
            return text;
        }

        public string strq(string pStr) => 
            (pStr.Trim() != "") ? pStr : "&nbsp";

        public string strz(string pText, int pSpace)
        {
            string str = "";
            int num = 0;
            while (true)
            {
                if (num >= pSpace)
                {
                    str = str + pText;
                    for (int i = 0; i < pSpace; i++)
                    {
                        str = str + "&nbsp";
                    }
                    return str;
                }
                str = str + "&nbsp";
                num++;
            }
        }

        public string Style() => 
            (((((((((((((((((((((((((((((((((((("<title>" + this.Title + "</title>\n") + "<meta name='generator' http-equiv='content-type' content='text/html'>") + "<style type='text/css'>" + "      table.onlyLine {") + "        border-color=white;" + "        border-collapse : collapse;") + "      }" + "      table.onlyLine td, th, tr {") + "          border-width: 1px;" + "          border-style: solid;") + "          border-color: black;" + "      }") + "      table.onlyLine.bd {" + "        background-color: #FFFFFF;") + "        color: #004080;" + "        font-family: Verdana;") + "        font-size: 12px;" + "      }") + "      body {" + "        background-color: #FFFFFF;") + "        color: #004080;" + "        font-family: Verdana;") + "        font-size: 12px;" + "      }") + "      .bd {" + "        background-color: #FFFFFF;") + "        color: #004080;" + "        font-family: Verdana;") + "        font-size: 12px;" + "      }") + "      a:link { " + "        background-color: #FFFFFF01;") + "        color: #000000;" + "        font-family: Verdana;") + "        font-size: 12px;" + "        text-decoration:none") + "      }" + "      a:active { ") + "        color: #000000;" + "        font-family:  Verdana;") + "        font-size: 12px;" + "        text-decoration:none") + "      }" + "      a:visited { ") + "        color: #000000;" + "        font-family: Verdana;") + "        font-size: 12px;" + "        text-decoration:none") + "      }" + "      a:hover {font-family:Verdana; font-size:12px; color:#0000FF; text-decoration:none}") + "      .hr {" + "        background-color: #068FE6;") + "        color: #FFFFE0;" + "        font-family: Verdana;") + "        font-size: 12px;" + "      }") + "      a.hr:link {" + "        color: #FFFFE0;") + "        font-family: Verdana;" + "        font-size: 12px;") + "      }" + "      a.hr:active {") + "        color: #FFFFE0;" + "        font-family: Verdana;") + "        font-size: 12px;" + "      }") + "      a.hr:visited {" + "        color: #FFFFE0;") + "        font-family: Verdana;" + "        font-size: 12px;") + "      }" + "    </style>";

        public void Write(string pText)
        {
            this.txt.Write(pText);
            this.txt.Flush();
        }

        public void WriteLine(string pText)
        {
            if (pText == "")
            {
                pText = "&nbsp";
            }
            this.txt.WriteLine(pText);
            this.txt.Flush();
        }

        public void writeSign()
        {
            this.Write("<table border=0 rules=all cellpadding=3 cellspacing=-1>");
            this.Write("<tr class='bd'>");
            this.Write("<td align=center nowrap><b>" + this.strz(Resource.Menu_Created_By, 30) + "</b></td>");
            this.Write("<td align=center nowrap><b>" + this.strz(Resource.Menu_Checked_By, 30) + "</b></td>");
            this.Write("<td align=center nowrap><b>" + this.strz(Resource.Lab_032, 30) + "</b></td>");
            this.Write("</tr>");
            int num = 1;
            while (true)
            {
                if (num > 5)
                {
                    this.Write("<tr class='bd'>");
                    this.Write("<td align=center nowrap>___________________</td>");
                    this.Write("<td align=center  nowrap>___________________</td>");
                    this.Write("<td align=center nowrap>___________________</td>");
                    this.Write("</tr>");
                    this.Write("<tr class='bd'>");
                    this.Write("<td align=center nowrap><b>" + WBUser.UserName + "</b></td>");
                    this.Write("<td align=center nowrap><b>" + WBSetting.Field("Check_by") + "</b></td>");
                    this.Write("<td align=center nowrap><b>" + WBSetting.Field("Appr_by") + "</b></td>");
                    this.Write("</tr>");
                    this.Write("</table>");
                    return;
                }
                this.Write("<tr class='bd'>");
                this.Write("<td nowrap>&nbsp</td>");
                this.Write("<td nowrap>&nbsp</td>");
                this.Write("<td nowrap>&nbsp</td>");
                this.Write("</tr>");
                num++;
            }
        }
    }
}

