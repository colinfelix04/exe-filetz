﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic;
    using SAP.Middleware.Connector;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormCommodity : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable tblComm = new WBTable();
        public WBTable tblCommDetail = new WBTable();
        public WBTable tblCommGrading = new WBTable();
        public WBTable tblQC = new WBTable();
        private DataTable updTable = new DataTable();
        private DataTable retTable = new DataTable();
        public DataRow ReturnRow;
        public DataRow tmpRow;
        private string[] zwbResult = new string[3];
        private string[] zwbRow = new string[20];
        private string sqlSelectComm = "";
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.Menu_ZWB);
        public IContainer components = null;
        public Button buttonFind;
        public TextBox TextFind;
        public Panel panel1;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        public ToolStripMenuItem addCommodityItemToolStripMenuItem;
        public ToolStripMenuItem editCommodityToolStripMenuItem;
        public ToolStripMenuItem deleteToolStripMenuItem;
        public ToolStripMenuItem printToolStripMenuItem;
        public ToolStripMenuItem closeToolStripMenuItem;
        private DataGridView dataGridView1;
        private ToolStripMenuItem chooseStripMenuItem1;
        private ToolStripMenuItem zWBToolStripMenuItem;
        private ToolStripMenuItem sendToZWBToolStripMenuItem;
        private ToolStripMenuItem synchronizeAllToolStripMenuItem;
        private ProgressBar progressBar1;
        private ToolStripMenuItem comparePatchToolStripMenuItem;
        private ToolStripMenuItem getDataToolStripMenuItem;
        private ToolStripMenuItem setQualityToolStripMenuItem;
        private ToolStripMenuItem copyToAllLocationsToolStripMenuItem;
        private ToolStripMenuItem copyThisCommodityToolStripMenuItem;
        private ToolStripMenuItem copyAllCommoditiesToolStripMenuItem;
        private ToolStripMenuItem setToleranceToolStripMenuItem;
        private ToolStripMenuItem viewRecordToolStripMenuItem;

        public FormCommodity()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void activitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            WBSetting.OpenSetting();
            if (WBSetting.zwb == "Y")
            {
                this.zWBToolStripMenuItem.Visible = true;
            }
            else if (!WBSetting.integrationIDSYS)
            {
                this.zWBToolStripMenuItem.Visible = false;
            }
            else
            {
                this.zWBToolStripMenuItem.Visible = true;
                this.sendToZWBToolStripMenuItem.Visible = false;
                this.synchronizeAllToolStripMenuItem.Visible = false;
            }
        }

        private void addCommodityItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.tblComm.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormCommodityEntry entry = new FormCommodityEntry {
                    Text = Resource.Title_Add_Commodity,
                    pMode = "ADD",
                    tblComm = this.tblComm
                };
                this.tblCommDetail.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail", WBData.conn);
                entry.tblCommDetail = this.tblCommDetail;
                this.tblCommGrading.OpenTable("wb_commodity_grading", "Select * From wb_commodity_grading", WBData.conn);
                entry.tblCommGrading = this.tblCommGrading;
                this.tblQC.OpenTable("wb_yield", "Select Yield_Code, Yield_Name From wb_yield", WBData.conn);
                entry.tblQC = this.tblQC;
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.tblComm.ReOpen();
                    this.tblCommDetail.ReOpen();
                    this.tblCommGrading.ReOpen();
                    this.dataGridView1 = this.tblComm.AfterEdit("ADD");
                    string[] aField = new string[] { "comm_code" };
                    string[] aFind = new string[] { entry.textCode.Text };
                    this.tblComm.SetCursor(this.dataGridView1, this.tblComm.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                this.tblComm.UnLock();
                entry.Dispose();
                if (this.dataGridView1.RowCount > 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = true;
                    this.setQualityToolStripMenuItem.Enabled = true;
                    this.setToleranceToolStripMenuItem.Enabled = WBUser.CheckTrustee("TOLERANCE_COMM", "E");
                    this.editCommodityToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_STOCK", "E");
                    this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_STOCK", "D");
                    this.printToolStripMenuItem.Enabled = true;
                    this.deleteToolStripMenuItem.Enabled = true;
                    this.printToolStripMenuItem.Enabled = true;
                    this.copyToAllLocationsToolStripMenuItem.Enabled = true;
                    this.chooseStripMenuItem1.Enabled = true;
                }
            }
        }

        public void adoptDataIDSYS(string commCode)
        {
            try
            {
                WBIDSYSIntegrator integrator = new WBIDSYSIntegrator();
                string url = integrator.getURL("IDSYS_ADOPT_COMMODITY");
                if (url != "")
                {
                    string[] textArray1 = new string[] { "{coy:'", WBSetting.CoySAP, "',comm_code:'", commCode, "'}" };
                    bool err = false;
                    Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                    dictionary = integrator.getDataFromIDSYS(url, string.Concat(textArray1), out err);
                    if (!err)
                    {
                        if (dictionary.Count <= 0)
                        {
                            MessageBox.Show("Commodity is not found!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        else
                        {
                            int count = this.dataGridView1.Rows.Count;
                            this.progressBar1.Visible = true;
                            this.progressBar1.Maximum = count;
                            if (this.tblComm.BeforeEdit(this.dataGridView1, "ADD"))
                            {
                                try
                                {
                                    FormCommodityCompare compare = new FormCommodityCompare {
                                        p1 = this.progressBar1,
                                        adoptTable = dictionary
                                    };
                                    if (Convert.ToInt16(WBUser.UserLevel) == 1)
                                    {
                                        compare.ShowDialog();
                                    }
                                    else
                                    {
                                        compare.Compare();
                                        object[] objArray1 = new object[11];
                                        objArray1[0] = Resource.Mes_Inserted;
                                        objArray1[1] = " : ";
                                        objArray1[2] = compare.inserted;
                                        objArray1[3] = " ";
                                        objArray1[4] = Resource.Mes_Rows;
                                        objArray1[5] = Environment.NewLine;
                                        objArray1[6] = Resource.Mes_Updated;
                                        objArray1[7] = " : ";
                                        objArray1[8] = compare.updated;
                                        objArray1[9] = " ";
                                        objArray1[10] = Resource.Mes_Rows;
                                        MessageBox.Show(string.Concat(objArray1));
                                    }
                                    compare.Dispose();
                                    this.tblComm.ReOpen();
                                    this.tblCommDetail.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail", WBData.conn);
                                    this.tblCommGrading.OpenTable("wb_commodity_grading", "select * from wb_commodity_grading", WBData.conn);
                                    this.dataGridView1 = this.tblComm.AfterEdit("ADD");
                                }
                                catch (Exception exception)
                                {
                                    MessageBox.Show(Resource.Title_003 + "/n" + exception.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                Cursor.Current = Cursors.Default;
                            }
                        }
                    }
                }
            }
            catch (Exception exception2)
            {
                MessageBox.Show(Resource.Title_003 + " " + exception2.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.tblComm.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void chooseStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["Deleted"].Value.ToString() == "Y")
            {
                MessageBox.Show(Resource.Mes_024, Resource.Title_002);
            }
            else
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
                this.nCurrRow = this.tblComm.GetRecNo(aField, aFind);
                this.ReturnRow = this.tblComm.DT.Rows[this.nCurrRow];
                base.Close();
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ThisClose();
        }

        public void CompareAll(string commCode)
        {
            if (!WBSetting.activeMulesoftIntegration)
            {
                if (WBSetting.integrationIDSYS)
                {
                    this.adoptDataIDSYS(commCode);
                }
                else
                {
                    int count = this.dataGridView1.Rows.Count;
                    this.progressBar1.Visible = true;
                    this.progressBar1.Maximum = count;
                    if (this.tblComm.BeforeEdit(this.dataGridView1, "ADD"))
                    {
                        try
                        {
                            WBSetting.OpenSetting();
                            if (WBSAP.connect())
                            {
                                WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_EXTRACT_COMM");
                                if (commCode != "")
                                {
                                    WBSAP.rfcFunction.SetValue("P_COMM", commCode);
                                    WBSAP.rfcFunction.SetValue("P_LOC", WBSetting.CoySAP);
                                }
                                else
                                {
                                    WBSAP.rfcFunction.SetValue("P_COMM", "");
                                    WBSAP.rfcFunction.SetValue("P_LOC", WBSetting.CoySAP);
                                }
                                WBSAP.sendZWB();
                                WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_COMM");
                                WBSAP.rfcTable2 = WBSAP.rfcFunction.GetTable("I_COMMD");
                                if (WBSAP.rfcTable.RowCount < 1)
                                {
                                    MessageBox.Show(WBSAP.rfcFunction.GetValue("MSG_ERROR").ToString(), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }
                                else
                                {
                                    FormCommodityCompare compare2 = new FormCommodityCompare {
                                        rfcTable = WBSAP.rfcTable,
                                        rfcTableD = WBSAP.rfcTable2,
                                        p1 = this.progressBar1
                                    };
                                    if (Convert.ToInt16(WBUser.UserLevel) == 1)
                                    {
                                        compare2.ShowDialog();
                                    }
                                    else
                                    {
                                        compare2.Compare();
                                        object[] objArray2 = new object[11];
                                        objArray2[0] = Resource.Mes_Inserted;
                                        objArray2[1] = " : ";
                                        objArray2[2] = compare2.inserted;
                                        objArray2[3] = " ";
                                        objArray2[4] = Resource.Mes_Rows;
                                        objArray2[5] = Environment.NewLine;
                                        objArray2[6] = Resource.Mes_Updated;
                                        objArray2[7] = " : ";
                                        objArray2[8] = compare2.updated;
                                        objArray2[9] = " ";
                                        objArray2[10] = Resource.Mes_Rows;
                                        MessageBox.Show(string.Concat(objArray2));
                                    }
                                    compare2.Dispose();
                                    WBSAP.SyncCommTrx();
                                    this.tblComm.ReOpen();
                                    this.tblCommDetail.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail", WBData.conn);
                                    this.tblCommGrading.OpenTable("wb_commodity_grading", "select * from wb_commodity_grading", WBData.conn);
                                    this.dataGridView1 = this.tblComm.AfterEdit("ADD");
                                }
                            }
                        }
                        catch (RfcInvalidParameterException exception2)
                        {
                            MessageBox.Show($"{exception2.GetType().Name} : {exception2.Message}", Resource.Mes_Error_With_Spaces + " <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        catch (RfcCommunicationException exception3)
                        {
                            if (WBUser.UserLevel == "1")
                            {
                                MessageBox.Show(exception3.ToString(), Resource.Mes_Error_With_Spaces + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, Resource.Mes_Error_With_Spaces + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                        }
                        catch (RfcBaseException exception4)
                        {
                            if (WBUser.UserLevel == "1")
                            {
                                MessageBox.Show(exception4.ToString(), Resource.Mes_Error_With_Spaces + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, Resource.Mes_Error_With_Spaces + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                        }
                        catch (Exception exception5)
                        {
                            MessageBox.Show(Resource.Title_003 + "/n" + exception5.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                }
                return;
            }
            else
            {
                WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                string str = integrator.getURL("ZRFC_DNET_WB_EXTRACT_COMM");
                if (str != "")
                {
                    string[] textArray1 = new string[] { str, "?p_comm=", commCode, "&p_loc=", WBSetting.CoySAP };
                    bool err = false;
                    Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                    string[] resultHeaderName = new string[] { "ERRORS", "I_COMM", "I_COMMD", "MSG_ERROR", "MESSAGE_ID" };
                    dictionary = integrator.getDataFromMulesoft(string.Concat(textArray1), resultHeaderName, out err);
                    if (!err)
                    {
                        if (dictionary["ERRORS"].Count > 0)
                        {
                            MessageBox.Show("Error from SAP : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            int count = this.dataGridView1.Rows.Count;
                            this.progressBar1.Visible = true;
                            this.progressBar1.Maximum = count;
                            if (this.tblComm.BeforeEdit(this.dataGridView1, "ADD"))
                            {
                                try
                                {
                                    if (dictionary["I_COMM"].Count >= 1)
                                    {
                                        FormCommodityCompare compare = new FormCommodityCompare {
                                            p1 = this.progressBar1,
                                            adoptTable = dictionary
                                        };
                                        if (Convert.ToInt16(WBUser.UserLevel) == 1)
                                        {
                                            compare.ShowDialog();
                                        }
                                        else
                                        {
                                            compare.Compare();
                                            object[] objArray1 = new object[11];
                                            objArray1[0] = Resource.Mes_Inserted;
                                            objArray1[1] = " : ";
                                            objArray1[2] = compare.inserted;
                                            objArray1[3] = " ";
                                            objArray1[4] = Resource.Mes_Rows;
                                            objArray1[5] = Environment.NewLine;
                                            objArray1[6] = Resource.Mes_Updated;
                                            objArray1[7] = " : ";
                                            objArray1[8] = compare.updated;
                                            objArray1[9] = " ";
                                            objArray1[10] = Resource.Mes_Rows;
                                            MessageBox.Show(string.Concat(objArray1));
                                        }
                                        compare.Dispose();
                                        WBSAP.SyncCommTrx();
                                        this.tblComm.ReOpen();
                                        this.tblCommDetail.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail", WBData.conn);
                                        this.tblCommGrading.OpenTable("wb_commodity_grading", "select * from wb_commodity_grading", WBData.conn);
                                        this.dataGridView1 = this.tblComm.AfterEdit("ADD");
                                    }
                                    else
                                    {
                                        MessageBox.Show(dictionary["MSG_ERROR"][0]["VALUE"], "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        return;
                                    }
                                }
                                catch (Exception exception)
                                {
                                    MessageBox.Show(Resource.Title_003 + "/n" + exception.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                            }
                            else
                            {
                                return;
                            }
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void comparePatchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_028_IDSYS : Resource.Mes_028, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.CompareAll("");
            }
        }

        private void copyAllCommoditiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this.dataGridView1.Rows.Count + Resource.Mes_Confirm_Copy_Commodity, Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Program.copyToLoc("wb_commodity", "", 1, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                MessageBox.Show(Resource.Mes_Commodity_Copied);
            }
        }

        private void copyThisCommodityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string key = this.dataGridView1.CurrentRow.Cells["comm_code"].Value.ToString().Trim();
            string str = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString().Trim();
            if (MessageBox.Show(key + " : " + Resource.Mes_Confirm_Copy_All_Company_Location, Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Program.copyToLoc("wb_commodity", key, 0, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                MessageBox.Show(Resource.Mes_Record_Copied);
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseStripMenuItem1.PerformClick();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1.Rows[e.RowIndex].Cells["Deleted"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Gray;
                e.CellStyle.SelectionBackColor = Color.Black;
            }
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.chooseStripMenuItem1.PerformClick();
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["Deleted"].Value.ToString() != "Y")
            {
                if (this.tblComm.BeforeEdit(this.dataGridView1, "DELETE"))
                {
                    this.nCurrRow = this.tblComm.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                    WBTable table = new WBTable();
                    table.OpenTable("wb_transaction", "Select ref From wb_transdo where" + WBData.Company(" and ( comm_code='" + this.tblComm.DT.Rows[this.nCurrRow]["Comm_Code"].ToString() + "')"), WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        if (MessageBox.Show(Resource.Mes_027 + this.tblComm.DT.Rows[this.nCurrRow]["Comm_Code"].ToString() + "?", Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                        {
                            FormTransCancel cancel = new FormTransCancel {
                                label1 = { Text = Resource.CommE_001 },
                                textRefNo = { Text = this.tblComm.DT.Rows[this.nCurrRow]["Comm_Code"].ToString() },
                                Text = Resource.Form_Delete_Reason,
                                label2 = { Text = Resource.Lbl_Delete_Reason }
                            };
                            cancel.textReason.Focus();
                            cancel.ShowDialog();
                            if (cancel.Saved)
                            {
                                this.changeReason = cancel.textReason.Text;
                                cancel.Dispose();
                                string str = this.tblComm.DT.Rows[this.nCurrRow]["comm_code"].ToString();
                                this.tblComm.ReOpen();
                                this.logKey = this.tblComm.DT.Rows[this.nCurrRow]["uniq"].ToString();
                                this.tblComm.DT.Rows[this.nCurrRow].Delete();
                                this.tblComm.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                                Program.updateLogHeader("wb_commodity", this.logKey, logField, logValue);
                                WBTable table2 = new WBTable();
                                table2.OpenTable("wb_commodity_detail", "select * From wb_commodity_detail Where " + WBData.CompanyLocation("and (Comm_Code='" + str.Trim() + "')"), WBData.conn);
                                string[] strArray = new string[table2.DT.Rows.Count];
                                int index = 0;
                                while (true)
                                {
                                    if (index >= table2.DT.Rows.Count)
                                    {
                                        table2.Save();
                                        table2.Dispose();
                                        int num3 = 0;
                                        while (true)
                                        {
                                            if (num3 >= strArray.Length)
                                            {
                                                table2.OpenTable("wb_commodity_grading", "select * From wb_commodity_grading Where " + WBData.CompanyLocation("and (Comm_Code='" + str.Trim() + "')"), WBData.conn);
                                                string[] strArray2 = new string[table2.DT.Rows.Count];
                                                int num4 = 0;
                                                while (true)
                                                {
                                                    if (num4 >= table2.DT.Rows.Count)
                                                    {
                                                        table2.Save();
                                                        table2.Dispose();
                                                        int num5 = 0;
                                                        while (true)
                                                        {
                                                            if (num5 >= strArray2.Length)
                                                            {
                                                                this.tblComm.ReOpen();
                                                                this.tblComm.AfterEdit("DELETE");
                                                                break;
                                                            }
                                                            string[] textArray6 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                            string[] textArray7 = new string[] { "DELETE", WBUser.UserID, this.changeReason + " (Delete commodity master data)" };
                                                            Program.updateLogHeader("wb_commodity_grading", strArray2[num5], textArray6, textArray7);
                                                            num5++;
                                                        }
                                                        break;
                                                    }
                                                    strArray2[num4] = table2.DT.Rows[num4]["uniq"].ToString();
                                                    table2.DT.Rows[num4].Delete();
                                                    num4++;
                                                }
                                                break;
                                            }
                                            string[] textArray4 = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] textArray5 = new string[] { "DELETE", WBUser.UserID, this.changeReason + " (Delete commodity master data)" };
                                            Program.updateLogHeader("wb_commodity_detail", strArray[num3], textArray4, textArray5);
                                            num3++;
                                        }
                                        break;
                                    }
                                    strArray[index] = table2.DT.Rows[index]["uniq"].ToString();
                                    table2.DT.Rows[index].Delete();
                                    index++;
                                }
                            }
                            else
                            {
                                return;
                            }
                        }
                    }
                    else
                    {
                        string[] textArray1 = new string[] { Resource.Mes_047A, "\n (", table.DT.Rows.Count.ToString(), " ", Resource.Mes_047B, ")" };
                        MessageBox.Show(string.Concat(textArray1), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    this.tblComm.UnLock();
                    table.Dispose();
                    if (this.dataGridView1.RowCount == 0)
                    {
                        this.viewRecordToolStripMenuItem.Enabled = false;
                        this.setQualityToolStripMenuItem.Enabled = false;
                        this.setToleranceToolStripMenuItem.Enabled = false;
                        this.editCommodityToolStripMenuItem.Enabled = false;
                        this.deleteToolStripMenuItem.Enabled = false;
                        this.printToolStripMenuItem.Enabled = false;
                        this.deleteToolStripMenuItem.Enabled = false;
                        this.printToolStripMenuItem.Enabled = false;
                        this.copyToAllLocationsToolStripMenuItem.Enabled = false;
                        this.chooseStripMenuItem1.Enabled = false;
                    }
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_025, Resource.Title_002);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editCommodityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["Deleted"].Value.ToString() == "Y")
            {
                MessageBox.Show(Resource.Mes_026, Resource.Title_002);
            }
            else if (this.tblComm.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                FormCommodityEntry entry = new FormCommodityEntry {
                    Text = Resource.Title_Edit_Commodity,
                    pMode = "EDIT",
                    nCurrRow = this.tblComm.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    tblComm = this.tblComm
                };
                this.tblCommDetail.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail", WBData.conn);
                entry.tblCommDetail = this.tblCommDetail;
                this.tblCommGrading.OpenTable("wb_commodity_grading", "Select * From wb_commodity_grading", WBData.conn);
                entry.tblCommGrading = this.tblCommGrading;
                this.tblQC.OpenTable("wb_yield", "Select Yield_Code, Yield_Name From wb_yield", WBData.conn);
                entry.tblQC = this.tblQC;
                this.tblComm.DR = this.tblComm.DT.Rows[entry.nCurrRow];
                entry.textCode.Text = this.tblComm.DR["Comm_Code"].ToString();
                entry.OldCode = this.tblComm.DR["Comm_Code"].ToString();
                entry.textName.Text = this.tblComm.DR["Comm_Name"].ToString();
                entry.textFormISO.Text = this.tblComm.DR["Form_Iso"].ToString();
                entry.textUnit.Text = this.tblComm.DR["Unit"].ToString();
                entry.textSAPCode.Text = this.tblComm.DR["Material"].ToString();
                if (this.tblComm.DR["Material_type"].ToString() == "SOLD")
                {
                    entry.radioSolid.Checked = true;
                }
                else
                {
                    entry.radioLiquid.Checked = true;
                }
                entry.textConvValue.Text = this.tblComm.DR["Convertion"].ToString();
                entry.textConvUnit.Text = this.tblComm.DR["ConvertionUnit"].ToString();
                entry.textConvTolerance.Text = this.tblComm.DR["ConvertionTolerance"].ToString();
                entry.checkConvert.Checked = this.tblComm.DR["ConvertionCheck"].ToString() == "Y";
                entry.textGrossMin.Text = this.tblComm.DR["gross_min_gunny"].ToString();
                entry.textGrossMax.Text = this.tblComm.DR["gross_max_gunny"].ToString();
                entry.textNetto.Text = this.tblComm.DR["netto_gunny"].ToString();
                entry.textGrossW.Text = this.tblComm.DR["gross_weight"].ToString();
                entry.textNettW.Text = this.tblComm.DR["netto_weight"].ToString();
                entry.textTolerance.Text = this.tblComm.DR["tolerance"].ToString();
                if ((this.tblComm.DR["Type"].ToString() == "S") || (this.tblComm.DR["Type"].ToString() == "0"))
                {
                    entry.radioStandard.Checked = true;
                }
                else if ((this.tblComm.DR["Type"].ToString() == "F") || (this.tblComm.DR["Type"].ToString() == "1"))
                {
                    entry.radioFFB.Checked = true;
                }
                else if ((this.tblComm.DR["Type"].ToString() == "C") || (this.tblComm.DR["Type"].ToString() == "2"))
                {
                    entry.radioCopra.Checked = true;
                }
                else if ((this.tblComm.DR["Type"].ToString() == "G") || (this.tblComm.DR["Type"].ToString() == "3"))
                {
                    entry.radioSugar.Checked = true;
                }
                if ((this.tblComm.DR["Trade"].ToString() == "T") || (this.tblComm.DR["Trade"].ToString() == "0"))
                {
                    entry.radioTrade.Checked = true;
                }
                else
                {
                    entry.radioNonTrade.Checked = true;
                }
                if (this.tblComm.DR["BulkPack"].ToString() == "B")
                {
                    entry.radioBulk.Checked = true;
                }
                else
                {
                    entry.radioNonBulk.Checked = true;
                }
                if ((this.tblComm.DR["Check_Grading"].ToString() == "Y") || (this.tblComm.DR["Check_Grading"].ToString() == "0"))
                {
                    entry.radioGradingYes.Checked = true;
                }
                else
                {
                    entry.radioGradingNo.Checked = true;
                }
                if ((this.tblComm.DR["Using_Gunny"].ToString() == "Y") || (this.tblComm.DR["Using_Gunny"].ToString() == "0"))
                {
                    entry.radioGunnyYes.Checked = true;
                }
                else
                {
                    entry.radioGunnyNo.Checked = true;
                }
                if ((this.tblComm.DR["PostSAP"].ToString() == "Y") || (this.tblComm.DR["PostSAP"].ToString() == "0"))
                {
                    entry.radioPostYes.Checked = true;
                }
                else
                {
                    entry.radioPostNo.Checked = true;
                }
                if (this.tblComm.DR["QCApprove"].ToString() == "Y")
                {
                    entry.radioConYes.Checked = true;
                }
                else
                {
                    entry.radioConNo.Checked = true;
                }
                if ((WBSetting.zwb == "Y") || ((WBSetting.zwb != "Y") && WBSetting.integrationIDSYS))
                {
                    entry.groupType.Enabled = false;
                    entry.radioBulk.Enabled = false;
                    entry.radioNonBulk.Enabled = false;
                    entry.radioTrade.Enabled = false;
                    entry.radioNonTrade.Enabled = false;
                    entry.textGrossW.Enabled = false;
                    entry.textNettW.Enabled = false;
                    entry.textTolerance.Enabled = false;
                }
                else
                {
                    entry.groupType.Enabled = true;
                    entry.radioBulk.Enabled = true;
                    entry.radioNonBulk.Enabled = true;
                    entry.radioTrade.Enabled = true;
                    entry.radioNonTrade.Enabled = true;
                    entry.textGrossW.Enabled = true;
                    entry.textNettW.Enabled = true;
                    entry.textTolerance.Enabled = true;
                }
                try
                {
                    entry.textBATCH.Text = this.tblComm.DR["Material_Batch"].ToString();
                    entry.checkTare.Checked = this.tblComm.DR["Check_tare"].ToString() == "Y";
                }
                catch
                {
                }
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.tblComm.ReOpen();
                    this.tblCommDetail.ReOpen();
                    this.tblCommGrading.ReOpen();
                    this.dataGridView1 = this.tblComm.AfterEdit("EDIT");
                }
                this.tblComm.UnLock();
                entry.Dispose();
            }
        }

        private void FormCommodity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.ThisClose();
            }
        }

        private void FormCommodity_Load(object sender, EventArgs e)
        {
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 20)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    this.retTable.Columns.Add(column);
                    column.Dispose();
                    this.progressBar1.Visible = false;
                    this.sqlSelectComm = (this.pFilter == "") ? "SELECT* FROM wb_commodity" : ("SELECT * FROM wb_commodity Where " + WBData.CompanyLocation(this.pFilter));
                    this.tblComm.OpenTable("wb_commodity", this.sqlSelectComm, WBData.conn);
                    this.dataGridView1.DataSource = this.tblComm.DT;
                    this.dataGridView1.Sort(this.dataGridView1.Columns["Comm_Code"], ListSortDirection.Ascending);
                    this.dataGridView1.Columns["Coy"].Visible = false;
                    this.dataGridView1.Columns["Location_Code"].Visible = false;
                    this.dataGridView1.Columns["Delete_By"].Visible = false;
                    this.dataGridView1.Columns["Delete_Date"].Visible = false;
                    this.dataGridView1.Columns["uniq"].Visible = false;
                    this.dataGridView1.Columns["token"].Visible = true;
                    this.dataGridView1.Columns["completed"].Visible = true;
                    this.dataGridView1.Columns["Comm_Code"].HeaderText = Resource.CommE_001;
                    this.dataGridView1.Columns["Check_Grading"].HeaderText = Resource.Grade_001;
                    this.dataGridView1.Columns["Using_Gunny"].HeaderText = Resource.CommE_014;
                    this.dataGridView1.Columns["Comm_Name"].HeaderText = Resource.CommE_003;
                    this.dataGridView1.Columns["Form_Iso"].HeaderText = Resource.CommE_005;
                    this.dataGridView1.Columns["Material"].HeaderText = this.sapIDSYS + Resource.CommE_010;
                    this.dataGridView1.Columns["Convertion"].HeaderText = Resource.CommE_007;
                    this.dataGridView1.Columns["Convertion"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dataGridView1.Columns["ConvertionUnit"].HeaderText = Resource.CommE_006;
                    this.dataGridView1.Columns["ConvertionTolerance"].HeaderText = Resource.Contract_055;
                    this.dataGridView1.Columns["ConvertionTolerance"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dataGridView1.Columns["ConvertionCheck"].HeaderText = Resource.CommE_009;
                    this.dataGridView1.Columns["Gross_Weight"].HeaderText = Resource.Mes_Gross_Weight;
                    this.dataGridView1.Columns["Netto_Weight"].HeaderText = Resource.Col_Netto_Weight;
                    this.dataGridView1.Columns["Tolerance"].HeaderText = Resource.ContractE_008 + " (%)";
                    base.KeyPreview = true;
                    int displayIndex = this.dataGridView1.Columns["comm_code"].DisplayIndex;
                    this.dataGridView1.Columns["Tolerance"].DisplayIndex = displayIndex + 3;
                    this.dataGridView1.Columns["Netto_Weight"].DisplayIndex = displayIndex + 4;
                    this.dataGridView1.Columns["Gross_Weight"].DisplayIndex = displayIndex + 5;
                    if (!WBUser.CheckTrustee("MD_STOCK", "A"))
                    {
                        this.addCommodityItemToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_STOCK", "E"))
                    {
                        this.editCommodityToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_STOCK", "D"))
                    {
                        this.deleteToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("TOLERANCE_COMM", "E"))
                    {
                        this.setToleranceToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_STOCK", "P"))
                    {
                        this.printToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_SYNCH_COMM", "A"))
                    {
                        this.zWBToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_SYNCH_COMM", "E"))
                    {
                        this.comparePatchToolStripMenuItem.Enabled = false;
                    }
                    this.synchronizeAllToolStripMenuItem.Enabled = WBUser.UserLevel == "1";
                    this.comparePatchToolStripMenuItem.Enabled = WBUser.UserLevel == "1";
                    if ((this.pMode != "") && (this.pFind.Trim() != ""))
                    {
                        this.TextFind.Text = this.pFind;
                        this.buttonFind.PerformClick();
                    }
                    this.chooseStripMenuItem1.Visible = this.pMode != "";
                    this.copyToAllLocationsToolStripMenuItem.Enabled = (WBSetting.copyToLoc == "Y") && (WBUser.CheckTrustee("MD_STOCK", "A") || WBUser.CheckTrustee("MD_STOCK", "E"));
                    if (this.dataGridView1.RowCount == 0)
                    {
                        this.viewRecordToolStripMenuItem.Enabled = false;
                        this.setQualityToolStripMenuItem.Enabled = false;
                        this.setToleranceToolStripMenuItem.Enabled = false;
                        this.editCommodityToolStripMenuItem.Enabled = false;
                        this.deleteToolStripMenuItem.Enabled = false;
                        this.printToolStripMenuItem.Enabled = false;
                        this.deleteToolStripMenuItem.Enabled = false;
                        this.printToolStripMenuItem.Enabled = false;
                        this.copyToAllLocationsToolStripMenuItem.Enabled = false;
                        this.chooseStripMenuItem1.Enabled = false;
                    }
                    if (WBSetting.integrationIDSYS)
                    {
                        this.zWBToolStripMenuItem.Text = "IDSYS";
                        this.sendToZWBToolStripMenuItem.Visible = true;
                        this.synchronizeAllToolStripMenuItem.Visible = false;
                        this.getDataToolStripMenuItem.Text = "Get Commodity From &IDSYS";
                        this.comparePatchToolStripMenuItem.Text = "Compare All Commodity to IDSYS  (ADMIN)";
                    }
                    return;
                }
                column = new DataColumn();
                this.updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        private void getDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str = "";
            str = !WBSetting.integrationIDSYS ? Interaction.InputBox(Resource.Mes_Entry_Commodity_Code, Resource.Mes_Get_Data_ZWB + this.sapIDSYS, "", 300, 300) : Interaction.InputBox(Resource.Mes_Entry_Commodity_Code, "Get Data From IDSYS", "", 300, 300);
            if (str != "")
            {
                this.CompareAll(str.ToUpper());
            }
        }

        public void InitializeComponent()
        {
            this.buttonFind = new Button();
            this.TextFind = new TextBox();
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addCommodityItemToolStripMenuItem = new ToolStripMenuItem();
            this.setQualityToolStripMenuItem = new ToolStripMenuItem();
            this.setToleranceToolStripMenuItem = new ToolStripMenuItem();
            this.editCommodityToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.printToolStripMenuItem = new ToolStripMenuItem();
            this.zWBToolStripMenuItem = new ToolStripMenuItem();
            this.sendToZWBToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeAllToolStripMenuItem = new ToolStripMenuItem();
            this.getDataToolStripMenuItem = new ToolStripMenuItem();
            this.comparePatchToolStripMenuItem = new ToolStripMenuItem();
            this.copyToAllLocationsToolStripMenuItem = new ToolStripMenuItem();
            this.copyThisCommodityToolStripMenuItem = new ToolStripMenuItem();
            this.copyAllCommoditiesToolStripMenuItem = new ToolStripMenuItem();
            this.chooseStripMenuItem1 = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            base.SuspendLayout();
            this.buttonFind.Location = new Point(0xc3, 3);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.TextFind.Location = new Point(5, 4);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x1be);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x3c3, 0x21);
            this.panel1.TabIndex = 5;
            this.progressBar1.Location = new Point(0x319, 6);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xa7, 0x12);
            this.progressBar1.TabIndex = 6;
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseStripMenuItem1, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x3c3, 0x18);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            ToolStripItem[] itemArray2 = new ToolStripItem[9];
            itemArray2[0] = this.addCommodityItemToolStripMenuItem;
            itemArray2[1] = this.viewRecordToolStripMenuItem;
            itemArray2[2] = this.setQualityToolStripMenuItem;
            itemArray2[3] = this.setToleranceToolStripMenuItem;
            itemArray2[4] = this.editCommodityToolStripMenuItem;
            itemArray2[5] = this.deleteToolStripMenuItem;
            itemArray2[6] = this.printToolStripMenuItem;
            itemArray2[7] = this.zWBToolStripMenuItem;
            itemArray2[8] = this.copyToAllLocationsToolStripMenuItem;
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "&Activities";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.activitiesToolStripMenuItem.Click += new EventHandler(this.activitiesToolStripMenuItem_Click);
            this.addCommodityItemToolStripMenuItem.Name = "addCommodityItemToolStripMenuItem";
            this.addCommodityItemToolStripMenuItem.Size = new Size(190, 0x16);
            this.addCommodityItemToolStripMenuItem.Text = "Add New Record";
            this.addCommodityItemToolStripMenuItem.Click += new EventHandler(this.addCommodityItemToolStripMenuItem_Click);
            this.setQualityToolStripMenuItem.Name = "setQualityToolStripMenuItem";
            this.setQualityToolStripMenuItem.Size = new Size(190, 0x16);
            this.setQualityToolStripMenuItem.Text = "Set Quality";
            this.setQualityToolStripMenuItem.Click += new EventHandler(this.setQualityToolStripMenuItem_Click);
            this.setToleranceToolStripMenuItem.Name = "setToleranceToolStripMenuItem";
            this.setToleranceToolStripMenuItem.Size = new Size(190, 0x16);
            this.setToleranceToolStripMenuItem.Text = "Set Tolerance";
            this.setToleranceToolStripMenuItem.Click += new EventHandler(this.setToleranceToolStripMenuItem_Click);
            this.editCommodityToolStripMenuItem.Name = "editCommodityToolStripMenuItem";
            this.editCommodityToolStripMenuItem.Size = new Size(190, 0x16);
            this.editCommodityToolStripMenuItem.Text = "Edit  Record";
            this.editCommodityToolStripMenuItem.Click += new EventHandler(this.editCommodityToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(190, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new Size(190, 0x16);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new EventHandler(this.printToolStripMenuItem_Click);
            ToolStripItem[] itemArray3 = new ToolStripItem[] { this.sendToZWBToolStripMenuItem, this.synchronizeAllToolStripMenuItem, this.getDataToolStripMenuItem, this.comparePatchToolStripMenuItem };
            this.zWBToolStripMenuItem.DropDownItems.AddRange(itemArray3);
            this.zWBToolStripMenuItem.Name = "zWBToolStripMenuItem";
            this.zWBToolStripMenuItem.Size = new Size(190, 0x16);
            this.zWBToolStripMenuItem.Text = "&ZWB";
            this.zWBToolStripMenuItem.Click += new EventHandler(this.zWBToolStripMenuItem_Click);
            this.sendToZWBToolStripMenuItem.Name = "sendToZWBToolStripMenuItem";
            this.sendToZWBToolStripMenuItem.Size = new Size(0x12e, 0x16);
            this.sendToZWBToolStripMenuItem.Text = "Send Commodity to ";
            this.sendToZWBToolStripMenuItem.Click += new EventHandler(this.sendToZWBToolStripMenuItem_Click);
            this.synchronizeAllToolStripMenuItem.Name = "synchronizeAllToolStripMenuItem";
            this.synchronizeAllToolStripMenuItem.Size = new Size(0x12e, 0x16);
            this.synchronizeAllToolStripMenuItem.Text = "Send All Commodity to ZWB (ADMIN)";
            this.synchronizeAllToolStripMenuItem.Click += new EventHandler(this.synchronizeAllToolStripMenuItem_Click);
            this.getDataToolStripMenuItem.Name = "getDataToolStripMenuItem";
            this.getDataToolStripMenuItem.Size = new Size(0x12e, 0x16);
            this.getDataToolStripMenuItem.Text = "Get Commodity From &ZWB";
            this.getDataToolStripMenuItem.Click += new EventHandler(this.getDataToolStripMenuItem_Click);
            this.comparePatchToolStripMenuItem.Name = "comparePatchToolStripMenuItem";
            this.comparePatchToolStripMenuItem.Size = new Size(0x12e, 0x16);
            this.comparePatchToolStripMenuItem.Text = "Compare All Commodity to ZWB  (ADMIN)";
            this.comparePatchToolStripMenuItem.Click += new EventHandler(this.comparePatchToolStripMenuItem_Click);
            ToolStripItem[] itemArray4 = new ToolStripItem[] { this.copyThisCommodityToolStripMenuItem, this.copyAllCommoditiesToolStripMenuItem };
            this.copyToAllLocationsToolStripMenuItem.DropDownItems.AddRange(itemArray4);
            this.copyToAllLocationsToolStripMenuItem.Name = "copyToAllLocationsToolStripMenuItem";
            this.copyToAllLocationsToolStripMenuItem.Size = new Size(190, 0x16);
            this.copyToAllLocationsToolStripMenuItem.Text = "Copy To All Locations";
            this.copyThisCommodityToolStripMenuItem.Name = "copyThisCommodityToolStripMenuItem";
            this.copyThisCommodityToolStripMenuItem.Size = new Size(0xc2, 0x16);
            this.copyThisCommodityToolStripMenuItem.Text = "Copy This Commodity";
            this.copyThisCommodityToolStripMenuItem.Click += new EventHandler(this.copyThisCommodityToolStripMenuItem_Click);
            this.copyAllCommoditiesToolStripMenuItem.Name = "copyAllCommoditiesToolStripMenuItem";
            this.copyAllCommoditiesToolStripMenuItem.Size = new Size(0xc2, 0x16);
            this.copyAllCommoditiesToolStripMenuItem.Text = "Copy All Commodities";
            this.copyAllCommoditiesToolStripMenuItem.Click += new EventHandler(this.copyAllCommoditiesToolStripMenuItem_Click);
            this.chooseStripMenuItem1.Name = "chooseStripMenuItem1";
            this.chooseStripMenuItem1.Size = new Size(0x3b, 20);
            this.chooseStripMenuItem1.Text = "Choose";
            this.chooseStripMenuItem1.Click += new EventHandler(this.chooseStripMenuItem1_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x3c3, 0x1a6);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(190, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x3c3, 0x1df);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "FormCommodity";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Commodity List";
            base.Load += new EventHandler(this.FormCommodity_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormCommodity_KeyPress);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void sendToZWBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString().Trim();
            if (MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_034_IDSYS : Resource.Mes_034, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                if (WBSetting.activeMulesoftIntegration)
                {
                    Sync.sync_commodity_with_mulesoft("uniq = '" + str + "'");
                }
                else
                {
                    Sync.sync_commodity("uniq = '" + str + "'");
                }
            }
        }

        private void setQualityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCommodityEntry entry;
            if (this.tblComm.BeforeEdit(this.dataGridView1, "DETAIL"))
            {
                entry = new FormCommodityEntry {
                    Text = Resource.Title_Enter_Commodity_Quality,
                    pMode = "Quality",
                    nCurrRow = this.tblComm.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    tblComm = this.tblComm
                };
                this.tblCommDetail.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail", WBData.conn);
                entry.tblCommDetail = this.tblCommDetail;
                this.tblCommGrading.OpenTable("wb_commodity_grading", "select * from wb_commodity_grading", WBData.conn);
                entry.tblCommGrading = this.tblCommGrading;
                this.tblQC.OpenTable("wb_yield", "Select Yield_Code, Yield_Name From wb_yield", WBData.conn);
                entry.tblQC = this.tblQC;
                this.tblComm.DR = this.tblComm.DT.Rows[entry.nCurrRow];
                entry.textCode.Text = this.tblComm.DR["Comm_Code"].ToString();
                entry.OldCode = this.tblComm.DR["Comm_Code"].ToString();
                entry.textName.Text = this.tblComm.DR["Comm_Name"].ToString();
                entry.textFormISO.Text = this.tblComm.DR["Form_Iso"].ToString();
                entry.textUnit.Text = this.tblComm.DR["Unit"].ToString();
                entry.textSAPCode.Text = this.tblComm.DR["Material"].ToString();
                if (this.tblComm.DR["Material_type"].ToString() == "SOLD")
                {
                    entry.radioSolid.Checked = true;
                }
                else
                {
                    entry.radioLiquid.Checked = true;
                }
                entry.textConvValue.Text = this.tblComm.DR["Convertion"].ToString();
                entry.textConvUnit.Text = this.tblComm.DR["ConvertionUnit"].ToString();
                entry.textConvTolerance.Text = this.tblComm.DR["ConvertionTolerance"].ToString();
                entry.checkConvert.Checked = this.tblComm.DR["ConvertionCheck"].ToString() == "Y";
                entry.textGrossMin.Text = this.tblComm.DR["gross_min_gunny"].ToString();
                entry.textGrossMax.Text = this.tblComm.DR["gross_max_gunny"].ToString();
                entry.textNetto.Text = this.tblComm.DR["netto_gunny"].ToString();
                if ((this.tblComm.DR["Type"].ToString() == "S") || (this.tblComm.DR["Type"].ToString() == "0"))
                {
                    entry.radioStandard.Checked = true;
                }
                else if ((this.tblComm.DR["Type"].ToString() == "F") || (this.tblComm.DR["Type"].ToString() == "1"))
                {
                    entry.radioFFB.Checked = true;
                }
                else if ((this.tblComm.DR["Type"].ToString() == "C") || (this.tblComm.DR["Type"].ToString() == "2"))
                {
                    entry.radioCopra.Checked = true;
                }
                else if ((this.tblComm.DR["Type"].ToString() == "G") || (this.tblComm.DR["Type"].ToString() == "3"))
                {
                    entry.radioSugar.Checked = true;
                }
                if ((this.tblComm.DR["Trade"].ToString() == "T") || (this.tblComm.DR["Trade"].ToString() == "0"))
                {
                    entry.radioTrade.Checked = true;
                }
                else
                {
                    entry.radioNonTrade.Checked = true;
                }
                if (this.tblComm.DR["BulkPack"].ToString() == "B")
                {
                    entry.radioBulk.Checked = true;
                }
                else
                {
                    entry.radioNonBulk.Checked = true;
                }
                if ((this.tblComm.DR["Check_Grading"].ToString() == "Y") || (this.tblComm.DR["Check_Grading"].ToString() == "0"))
                {
                    entry.radioGradingYes.Checked = true;
                }
                else
                {
                    entry.radioGradingNo.Checked = true;
                }
                if ((this.tblComm.DR["Using_Gunny"].ToString() == "Y") || (this.tblComm.DR["Using_Gunny"].ToString() == "0"))
                {
                    entry.radioGunnyYes.Checked = true;
                }
                else
                {
                    entry.radioGunnyNo.Checked = true;
                }
                if ((this.tblComm.DR["PostSAP"].ToString() == "Y") || (this.tblComm.DR["PostSAP"].ToString() == "0"))
                {
                    entry.radioPostYes.Checked = true;
                }
                else
                {
                    entry.radioPostNo.Checked = true;
                }
                foreach (Control control in entry.Controls)
                {
                    if (control.GetType() != typeof(Label))
                    {
                        control.Enabled = false;
                    }
                    entry.buttonSave.Enabled = true;
                    entry.buttonGrading.Enabled = true;
                    entry.buttonQuality.Enabled = true;
                    entry.buttonCancel.Enabled = true;
                }
            }
            else
            {
                return;
            }
            try
            {
                entry.textBATCH.Text = this.tblComm.DR["Material_Batch"].ToString();
                entry.checkTare.Checked = this.tblComm.DR["Check_tare"].ToString() == "Y";
            }
            catch
            {
            }
            entry.ShowDialog();
            if (entry.saved)
            {
                this.tblComm.ReOpen();
                this.tblCommDetail.ReOpen();
                this.tblCommGrading.ReOpen();
                this.dataGridView1 = this.tblComm.AfterEdit("DETAIL");
            }
            this.tblComm.UnLock();
            entry.Dispose();
        }

        private void setToleranceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str;
            if (this.dataGridView1.CurrentRow.Cells["Deleted"].Value.ToString() != "Y")
            {
                str = "";
                if (this.dataGridView1.CurrentRow.Cells["Tolerance"].Value.ToString() == "")
                {
                    this.dataGridView1.CurrentRow.Cells["Tolerance"].Value = "0";
                }
                if (Convert.ToDouble(this.dataGridView1.CurrentRow.Cells["Tolerance"].Value) > 0.0)
                {
                    if (WBSetting.Field("GM") != "N")
                    {
                        str = "Using Token";
                        if (!this.tblComm.BeforeEdit(this.dataGridView1, "TOLERANCE_COMM"))
                        {
                            return;
                        }
                    }
                    else
                    {
                        if (Convert.ToInt16(WBUser.UserLevel) <= 1)
                        {
                            if (this.tblComm.BeforeEdit(this.dataGridView1, "TOLERANCE_COMM"))
                            {
                                goto TR_0032;
                            }
                        }
                        else
                        {
                            string[] strArray = new string[3];
                            str = "Set Tolerance";
                            strArray = Program.fillApproval(str, "", "");
                            string str3 = strArray[1];
                            string str4 = strArray[2];
                            if (strArray[0] != "N")
                            {
                                goto TR_0032;
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_326, Resource.Mes_Notice, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            }
                        }
                        return;
                    }
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_026, Resource.Mes_Warning);
                return;
            }
        TR_0032:
            this.tblComm.uniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString();
            FormCommodityEntry entry = new FormCommodityEntry {
                Text = Resource.Title_Edit_Commodity_Tolerance,
                pMode = "EDIT",
                nCurrRow = this.tblComm.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                tblComm = this.tblComm
            };
            this.tblCommDetail.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail", WBData.conn);
            entry.tblCommDetail = this.tblCommDetail;
            this.tblCommGrading.OpenTable("wb_commodity_grading", "select * from wb_commodity_grading", WBData.conn);
            entry.tblCommGrading = this.tblCommGrading;
            this.tblQC.OpenTable("wb_yield", "Select Yield_Code, Yield_Name From wb_yield", WBData.conn);
            entry.tblQC = this.tblQC;
            this.tblComm.DR = this.tblComm.DT.Rows[entry.nCurrRow];
            entry.textCode.Text = this.tblComm.DR["Comm_Code"].ToString();
            entry.OldCode = this.tblComm.DR["Comm_Code"].ToString();
            entry.textName.Text = this.tblComm.DR["Comm_Name"].ToString();
            entry.textFormISO.Text = this.tblComm.DR["Form_Iso"].ToString();
            entry.textUnit.Text = this.tblComm.DR["Unit"].ToString();
            entry.textSAPCode.Text = this.tblComm.DR["Material"].ToString();
            if (this.tblComm.DR["Material_type"].ToString() == "SOLD")
            {
                entry.radioSolid.Checked = true;
            }
            else
            {
                entry.radioLiquid.Checked = true;
            }
            entry.textConvValue.Text = this.tblComm.DR["Convertion"].ToString();
            entry.textConvUnit.Text = this.tblComm.DR["ConvertionUnit"].ToString();
            entry.textConvTolerance.Text = this.tblComm.DR["ConvertionTolerance"].ToString();
            entry.checkConvert.Checked = this.tblComm.DR["ConvertionCheck"].ToString() == "Y";
            entry.textGrossMin.Text = this.tblComm.DR["gross_min_gunny"].ToString();
            entry.textGrossMax.Text = this.tblComm.DR["gross_max_gunny"].ToString();
            entry.textNetto.Text = this.tblComm.DR["netto_gunny"].ToString();
            entry.textGrossW.Text = this.tblComm.DR["gross_weight"].ToString();
            entry.textNettW.Text = this.tblComm.DR["netto_weight"].ToString();
            entry.textTolerance.Text = this.tblComm.DR["Tolerance"].ToString();
            if ((this.tblComm.DR["Type"].ToString() == "S") || (this.tblComm.DR["Type"].ToString() == "0"))
            {
                entry.radioStandard.Checked = true;
            }
            else if ((this.tblComm.DR["Type"].ToString() == "F") || (this.tblComm.DR["Type"].ToString() == "1"))
            {
                entry.radioFFB.Checked = true;
            }
            else if ((this.tblComm.DR["Type"].ToString() == "C") || (this.tblComm.DR["Type"].ToString() == "2"))
            {
                entry.radioCopra.Checked = true;
            }
            else if ((this.tblComm.DR["Type"].ToString() == "G") || (this.tblComm.DR["Type"].ToString() == "3"))
            {
                entry.radioSugar.Checked = true;
            }
            if ((this.tblComm.DR["Trade"].ToString() == "T") || (this.tblComm.DR["Trade"].ToString() == "0"))
            {
                entry.radioTrade.Checked = true;
            }
            else
            {
                entry.radioNonTrade.Checked = true;
            }
            if (this.tblComm.DR["BulkPack"].ToString() == "B")
            {
                entry.radioBulk.Checked = true;
            }
            else
            {
                entry.radioNonBulk.Checked = true;
            }
            if ((this.tblComm.DR["Check_Grading"].ToString() == "Y") || (this.tblComm.DR["Check_Grading"].ToString() == "0"))
            {
                entry.radioGradingYes.Checked = true;
            }
            else
            {
                entry.radioGradingNo.Checked = true;
            }
            if ((this.tblComm.DR["Using_Gunny"].ToString() == "Y") || (this.tblComm.DR["Using_Gunny"].ToString() == "0"))
            {
                entry.radioGunnyYes.Checked = true;
            }
            else
            {
                entry.radioGunnyNo.Checked = true;
            }
            if ((this.tblComm.DR["PostSAP"].ToString() == "Y") || (this.tblComm.DR["PostSAP"].ToString() == "0"))
            {
                entry.radioPostYes.Checked = true;
            }
            else
            {
                entry.radioPostNo.Checked = true;
            }
            foreach (Control control in entry.Controls)
            {
                if (control.GetType() != typeof(Label))
                {
                    control.Enabled = false;
                }
                entry.buttonSave.Enabled = true;
                entry.buttonCancel.Enabled = true;
                entry.tabControl1.Enabled = true;
                entry.textGrossW.Enabled = false;
                entry.textNettW.Enabled = false;
                entry.textTolerance.Enabled = true;
                entry.textSAPCode.Enabled = false;
                entry.textFormISO.Enabled = false;
                entry.radioSolid.Enabled = false;
                entry.radioLiquid.Enabled = false;
                entry.textBATCH.Enabled = false;
                entry.btnAdopt.Enabled = false;
                entry.textGrossMin.Enabled = false;
                entry.textGrossMax.Enabled = false;
                entry.textNetto.Enabled = false;
            }
            try
            {
                entry.textBATCH.Text = this.tblComm.DR["Material_Batch"].ToString();
                entry.checkTare.Checked = this.tblComm.DR["Check_tare"].ToString() == "Y";
            }
            catch
            {
            }
            entry.ShowDialog();
            if (entry.saved)
            {
                this.tblComm.ReOpen();
                this.tblCommDetail.ReOpen();
                this.tblCommGrading.ReOpen();
                if (str == "Using Token")
                {
                    this.dataGridView1 = this.tblComm.AfterEdit("EDIT");
                }
                else
                {
                    this.dataGridView1.DataSource = this.tblComm.DT;
                    this.dataGridView1.Sort(this.dataGridView1.Columns["Comm_code"], ListSortDirection.Ascending);
                }
            }
            this.tblComm.UnLock();
            entry.Dispose();
        }

        private void synchronizeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int count = this.dataGridView1.Rows.Count;
            this.updTable.Rows.Clear();
            this.retTable.Rows.Clear();
            if (MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_035_IDSYS : Resource.Mes_035, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.progressBar1.Visible = true;
                this.progressBar1.Maximum = count;
                if (WBSetting.activeMulesoftIntegration)
                {
                    Sync.sync_commodity_with_mulesoft(WBData.CompanyLocation(""));
                }
                else
                {
                    Sync.sync_commodity(WBData.CompanyLocation(""));
                }
                this.progressBar1.Visible = false;
            }
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        public void ThisClose()
        {
            base.Close();
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseStripMenuItem1.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addCommodityItemToolStripMenuItem.Text = Resource.Menu_Add;
            this.editCommodityToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
            this.setQualityToolStripMenuItem.Text = Resource.Menu_Set_Quality;
            this.setToleranceToolStripMenuItem.Text = Resource.Menu_Set_Tolerance;
            this.printToolStripMenuItem.Text = Resource.Menu_016;
            this.zWBToolStripMenuItem.Text = this.sapIDSYS;
            this.sendToZWBToolStripMenuItem.Text = Resource.Menu_Send_Commodity_ZWB + this.sapIDSYS;
            this.synchronizeAllToolStripMenuItem.Text = WBSetting.integrationIDSYS ? Resource.Menu_Send_All_Commodity_ZWB_IDSYS : Resource.Menu_Send_All_Commodity_ZWB;
            this.getDataToolStripMenuItem.Text = Resource.Menu_Get_Commodity_ZWB + this.sapIDSYS;
            this.comparePatchToolStripMenuItem.Text = WBSetting.integrationIDSYS ? Resource.Menu_Compare_All_Commodity_ZWB_IDSYS : Resource.Menu_Compare_All_Commodity_ZWB;
            this.copyToAllLocationsToolStripMenuItem.Text = Resource.Menu_Copy_To_All_Locations;
            this.copyThisCommodityToolStripMenuItem.Text = Resource.Menu_Copy_Commodity;
            this.copyAllCommoditiesToolStripMenuItem.Text = Resource.Menu_Copy_All_Commodity;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.Text = Resource.Title_Commodity_List;
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["Deleted"].Value.ToString() == "Y")
            {
                MessageBox.Show(Resource.Mes_026a, Resource.Title_002);
            }
            else if (this.tblComm.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormCommodityEntry entry = new FormCommodityEntry {
                    Text = Resource.Title_View_Commodity,
                    pMode = "VIEW",
                    nCurrRow = this.tblComm.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    tblComm = this.tblComm
                };
                this.tblCommDetail.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail", WBData.conn);
                entry.tblCommDetail = this.tblCommDetail;
                this.tblCommGrading.OpenTable("wb_commodity_grading", "select * from wb_commodity_grading", WBData.conn);
                entry.tblCommGrading = this.tblCommGrading;
                this.tblQC.OpenTable("wb_yield", "Select Yield_Code, Yield_Name From wb_yield", WBData.conn);
                entry.tblQC = this.tblQC;
                this.tblComm.DR = this.tblComm.DT.Rows[entry.nCurrRow];
                entry.textCode.Text = this.tblComm.DR["Comm_Code"].ToString();
                entry.OldCode = this.tblComm.DR["Comm_Code"].ToString();
                entry.textName.Text = this.tblComm.DR["Comm_Name"].ToString();
                entry.textFormISO.Text = this.tblComm.DR["Form_Iso"].ToString();
                entry.textUnit.Text = this.tblComm.DR["Unit"].ToString();
                entry.textSAPCode.Text = this.tblComm.DR["Material"].ToString();
                if (this.tblComm.DR["Material_type"].ToString() == "SOLD")
                {
                    entry.radioSolid.Checked = true;
                }
                else
                {
                    entry.radioLiquid.Checked = true;
                }
                entry.textConvValue.Text = this.tblComm.DR["Convertion"].ToString();
                entry.textConvUnit.Text = this.tblComm.DR["ConvertionUnit"].ToString();
                entry.textConvTolerance.Text = this.tblComm.DR["ConvertionTolerance"].ToString();
                entry.checkConvert.Checked = this.tblComm.DR["ConvertionCheck"].ToString() == "Y";
                entry.textGrossMin.Text = this.tblComm.DR["gross_min_gunny"].ToString();
                entry.textGrossMax.Text = this.tblComm.DR["gross_max_gunny"].ToString();
                entry.textNetto.Text = this.tblComm.DR["netto_gunny"].ToString();
                entry.textGrossW.Text = this.tblComm.DR["gross_weight"].ToString();
                entry.textNettW.Text = this.tblComm.DR["netto_weight"].ToString();
                entry.textTolerance.Text = this.tblComm.DR["tolerance"].ToString();
                if ((this.tblComm.DR["Type"].ToString() == "S") || (this.tblComm.DR["Type"].ToString() == "0"))
                {
                    entry.radioStandard.Checked = true;
                }
                else if ((this.tblComm.DR["Type"].ToString() == "F") || (this.tblComm.DR["Type"].ToString() == "1"))
                {
                    entry.radioFFB.Checked = true;
                }
                else if ((this.tblComm.DR["Type"].ToString() == "C") || (this.tblComm.DR["Type"].ToString() == "2"))
                {
                    entry.radioCopra.Checked = true;
                }
                else if ((this.tblComm.DR["Type"].ToString() == "G") || (this.tblComm.DR["Type"].ToString() == "3"))
                {
                    entry.radioSugar.Checked = true;
                }
                if ((this.tblComm.DR["Trade"].ToString() == "T") || (this.tblComm.DR["Trade"].ToString() == "0"))
                {
                    entry.radioTrade.Checked = true;
                }
                else
                {
                    entry.radioNonTrade.Checked = true;
                }
                if (this.tblComm.DR["BulkPack"].ToString() == "B")
                {
                    entry.radioBulk.Checked = true;
                }
                else
                {
                    entry.radioNonBulk.Checked = true;
                }
                if ((this.tblComm.DR["Check_Grading"].ToString() == "Y") || (this.tblComm.DR["Check_Grading"].ToString() == "0"))
                {
                    entry.radioGradingYes.Checked = true;
                }
                else
                {
                    entry.radioGradingNo.Checked = true;
                }
                if ((this.tblComm.DR["Using_Gunny"].ToString() == "Y") || (this.tblComm.DR["Using_Gunny"].ToString() == "0"))
                {
                    entry.radioGunnyYes.Checked = true;
                }
                else
                {
                    entry.radioGunnyNo.Checked = true;
                }
                if ((this.tblComm.DR["PostSAP"].ToString() == "Y") || (this.tblComm.DR["PostSAP"].ToString() == "0"))
                {
                    entry.radioPostYes.Checked = true;
                }
                else
                {
                    entry.radioPostNo.Checked = true;
                }
                if (this.tblComm.DR["QCApprove"].ToString() == "Y")
                {
                    entry.radioConYes.Checked = true;
                }
                else
                {
                    entry.radioConNo.Checked = true;
                }
                if (((this.tblComm.DR["Trade"].ToString() != "T") || (this.tblComm.DR["Type"].ToString() != "S")) || (Convert.ToInt16(WBUser.UserLevel) <= 1))
                {
                    entry.groupType.Enabled = true;
                    entry.radioBulk.Enabled = true;
                    entry.radioNonBulk.Enabled = true;
                    entry.radioTrade.Enabled = true;
                    entry.radioNonTrade.Enabled = true;
                }
                else
                {
                    entry.groupType.Enabled = false;
                    entry.radioBulk.Enabled = false;
                    entry.radioNonBulk.Enabled = false;
                    entry.radioTrade.Enabled = false;
                    entry.radioNonTrade.Enabled = false;
                    if ((this.tblComm.DR["BulkPack"].ToString() == "B") && (WBSetting.IntegrationSAP != "Y"))
                    {
                        entry.groupType.Enabled = true;
                        entry.radioBulk.Enabled = true;
                        entry.radioNonBulk.Enabled = true;
                        entry.radioTrade.Enabled = true;
                        entry.radioNonTrade.Enabled = true;
                    }
                }
                if (WBUser.UserLevel != "1")
                {
                    entry.textGrossW.Enabled = false;
                    entry.textNettW.Enabled = false;
                    entry.textTolerance.Enabled = false;
                }
                try
                {
                    entry.textBATCH.Text = this.tblComm.DR["Material_Batch"].ToString();
                    entry.checkTare.Checked = this.tblComm.DR["Check_tare"].ToString() == "Y";
                }
                catch
                {
                }
                entry.ShowDialog();
                this.tblComm.UnLock();
                entry.Dispose();
            }
        }

        private void zWBToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
    }
}

