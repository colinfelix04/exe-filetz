﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class Progress : Component
    {
        public static ProgressBar progressBar1;

        public static void Close()
        {
            progressBar1.Hide();
            progressBar1.Dispose();
        }

        public static void Init()
        {
            progressBar1 = new ProgressBar();
            progressBar1.Location = new Point(0xf4, 0x222);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(100, 11);
            progressBar1.Minimum = 1;
            progressBar1.Maximum = 100;
            progressBar1.Show();
        }

        public static void Step(int step)
        {
            progressBar1.Step = step;
            progressBar1.Refresh();
        }
    }
}

