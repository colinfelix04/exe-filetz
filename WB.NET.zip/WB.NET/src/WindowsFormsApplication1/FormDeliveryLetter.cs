﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormDeliveryLetter : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string flagTimbun = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private DataTable updTable = new DataTable();
        private DataTable retTable = new DataTable();
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        public string sField;
        private IContainer components = null;
        private DataGridView dataGridView1;
        private MenuStrip menuStrip1;
        private Panel panel1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem chooseToolStripMenuItem;
        private ToolStripMenuItem closeToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem viewRecordToolStripMenuItem;
        private ToolStripMenuItem deleteRecordToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem closeToolStripMenuItem1;
        private Button buttonFind;
        private TextBox textFind;

        public FormDeliveryLetter()
        {
            this.InitializeComponent();
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDeliveryLetterEntry entry = new FormDeliveryLetterEntry();
            this.ztable.BeforeEdit(this.dataGridView1, "ADD");
            entry.wbdl = this.ztable;
            entry.pMode = "ADD";
            entry.textSIM.Clear();
            entry.textDLN.Clear();
            entry.textDO.Clear();
            entry.textSAP_DL.Clear();
            entry.textSO.Clear();
            entry.textTruckNo.Clear();
            entry.labelNMSupir.Text = "";
            entry.lSave = false;
            entry.ShowDialog();
            if (entry.lSave)
            {
                this.ztable.ReOpen();
                this.dataGridView1 = this.ztable.AfterEdit("ADD");
            }
            entry.Dispose();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void deleteRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
            {
                this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                WBTable table = new WBTable();
                if (MessageBox.Show(this.ztable.DT.Rows[this.nCurrRow]["SJ_NO"].ToString() + " - .\n\n Are you sure to deleted this record ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.ztable.ReOpen();
                    this.ztable.DT.Rows[this.nCurrRow].Delete();
                    this.ztable.Save();
                    this.ztable.ReOpen();
                    this.ztable.AfterEdit("DELETE");
                }
                table.Dispose();
                this.ztable.UnLock();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                FormDeliveryLetterEntry entry = new FormDeliveryLetterEntry {
                    wbdl = this.ztable,
                    pMode = "EDIT",
                    lSave = false,
                    textSIM = { Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["Driver_Lic"].Value.ToString() },
                    textDLN = { Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["SJ_No"].Value.ToString() },
                    textDO = { Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["Do_No"].Value.ToString() },
                    textSAP_DL = { Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["SJ_No_SAP"].Value.ToString() },
                    textSO = { Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["SO_No"].Value.ToString() },
                    textTruckNo = { Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["Truck_No"].Value.ToString() },
                    labelNMSupir = { Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["Driver_Name"].Value.ToString() },
                    pUniq = this.dataGridView1.CurrentRow.Index
                };
                entry.ShowDialog();
                if (entry.lSave)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit("EDIT");
                }
                entry.Dispose();
            }
        }

        private void FormDeliveryLetter_Load(object sender, EventArgs e)
        {
            this.ztable.OpenTable("wb_DeliveryLetterH", "Select * from wb_DeliveryLetterH Where " + WBData.CompanyLocation(""), WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Do_No"], ListSortDirection.Descending);
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["Do_No"].HeaderText = "DO No";
            this.dataGridView1.Columns["SJ_No"].HeaderText = "Delivery Letter No";
            this.dataGridView1.Columns["SO_No"].HeaderText = "SO No";
            this.dataGridView1.Columns["SJ_No_SAP"].HeaderText = this.sapIDSYS + " Delivery Letter";
            this.dataGridView1.Columns["Truck_No"].HeaderText = "Truck No";
            this.dataGridView1.Columns["Driver_Lic"].HeaderText = "Driver License No";
            this.dataGridView1.Columns["Driver_Name"].HeaderText = "Driver Name";
            this.dataGridView1.Columns["uniq"].Visible = false;
        }

        private void InitializeComponent()
        {
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteRecordToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripMenuItem1 = new ToolStripSeparator();
            this.closeToolStripMenuItem1 = new ToolStripMenuItem();
            this.chooseToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.panel1 = new Panel();
            this.buttonFind = new Button();
            this.textFind = new TextBox();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x2fc, 0x207);
            this.dataGridView1.TabIndex = 0;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x2fc, 0x18);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.viewRecordToolStripMenuItem, this.deleteRecordToolStripMenuItem, this.toolStripMenuItem1, this.closeToolStripMenuItem1 };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            this.deleteRecordToolStripMenuItem.Name = "deleteRecordToolStripMenuItem";
            this.deleteRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteRecordToolStripMenuItem.Text = "Delete Record";
            this.deleteRecordToolStripMenuItem.Click += new EventHandler(this.deleteRecordToolStripMenuItem_Click);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(160, 6);
            this.closeToolStripMenuItem1.Name = "closeToolStripMenuItem1";
            this.closeToolStripMenuItem1.Size = new Size(0xa3, 0x16);
            this.closeToolStripMenuItem1.Text = "Close";
            this.chooseToolStripMenuItem.Name = "chooseToolStripMenuItem";
            this.chooseToolStripMenuItem.Size = new Size(0x3b, 20);
            this.chooseToolStripMenuItem.Text = "Choose";
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Controls.Add(this.textFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x1f1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x2fc, 0x2e);
            this.panel1.TabIndex = 2;
            this.buttonFind.Location = new Point(0x107, 12);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 1;
            this.buttonFind.Text = "&Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.textFind.Location = new Point(12, 12);
            this.textFind.Name = "textFind";
            this.textFind.Size = new Size(0xeb, 20);
            this.textFind.TabIndex = 0;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x2fc, 0x21f);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "FormDeliveryLetter";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List Of Delivery Letter";
            base.Load += new EventHandler(this.FormDeliveryLetter_Load);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDeliveryLetterEntry entry = new FormDeliveryLetterEntry {
                textSIM = { 
                    Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["Driver_Lic"].Value.ToString(),
                    ReadOnly = true
                },
                textDLN = { 
                    Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["SJ_No"].Value.ToString(),
                    ReadOnly = true
                },
                textDO = { 
                    Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["Do_No"].Value.ToString(),
                    ReadOnly = true
                },
                textSAP_DL = { 
                    Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["SJ_No_SAP"].Value.ToString(),
                    ReadOnly = true
                },
                textSO = { 
                    Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["SO_No"].Value.ToString(),
                    ReadOnly = true
                },
                textTruckNo = { 
                    Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["Truck_No"].Value.ToString(),
                    ReadOnly = true
                },
                labelNMSupir = { Text = this.dataGridView1.Rows[this.ztable.dataGridPosRow].Cells["Driver_Name"].Value.ToString() }
            };
            entry.buttonAdopt.Hide();
            entry.buttonSave.Hide();
            entry.buttonCancel.Text = "&Close";
            entry.buttonAdd.Hide();
            entry.buttonEdit.Hide();
            entry.buttonDelete.Hide();
            entry.ShowDialog();
            entry.Dispose();
        }
    }
}

