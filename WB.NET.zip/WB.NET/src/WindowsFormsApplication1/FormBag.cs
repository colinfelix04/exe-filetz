﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormBag : Form
    {
        public WBTable ztable = new WBTable();
        private int idxFind = 0;
        public string pMode = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public DataRow ReturnRow;
        private IContainer components = null;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem synchronizeAllToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem synchronizeToolStripMenuItem;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem viewToolStripMenuItem;
        private ToolStripMenuItem zWBToolStripMenuItem;
        private DataGridView dgBag;
        public ToolStripMenuItem closeToolStripMenuItem;
        public TextBox TextFind;
        private ToolStripMenuItem chooseToolStripMenuItem;
        public Panel panel1;
        private ProgressBar progressBar1;
        public Button buttonFind;
        public MenuStrip menuStrip1;

        public FormBag()
        {
            this.InitializeComponent();
        }

        private void activitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormBagEntry entry = new FormBagEntry();
            this.ztable.BeforeEdit(this.dgBag, "ADD");
            entry.pMode = "ADD";
            entry.zTable = this.ztable;
            entry.Text = "Add New Record of Bag";
            entry.dataGridView1 = this.dgBag;
            entry.ShowDialog();
            if (entry.saved)
            {
                this.ztable.ReOpen();
                this.dgBag = this.ztable.AfterEdit(entry.pMode);
                string[] aField = new string[] { "Bag_Code" };
                string[] aFind = new string[] { entry.textBagCode.Text };
                this.ztable.SetCursor(this.dgBag, this.ztable.GetCurrentRow(this.dgBag, aField, aFind));
            }
            this.ztable.UnLock();
            entry.Dispose();
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dgBag.CurrentRow.Cells["Deleted"].Value.ToString() != "Y")
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.dgBag.CurrentRow.Cells["uniq"].Value.ToString() };
                this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
                this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
                base.Close();
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ztable.BeforeEdit(this.dgBag, "DELETE");
            this.nCurrRow = this.ztable.GetPosRec(this.dgBag.CurrentRow.Cells["uniq"].Value.ToString());
            if (MessageBox.Show(this.ztable.DT.Rows[this.nCurrRow]["Bag_Code"].ToString() + " - " + this.ztable.DT.Rows[this.nCurrRow]["Description"].ToString() + ".\n\n Are you sure to deleted this record ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "Bag Code" },
                    textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Bag_Code"].ToString() },
                    Text = "DELETE REASON",
                    label2 = { Text = "Delete Reason : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                    this.ztable.ReOpen();
                    this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                    this.ztable.DT.Rows[this.nCurrRow].Delete();
                    this.ztable.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                    Program.updateLogHeader("wb_bag", this.logKey, logField, logValue);
                    this.ztable.ReOpen();
                    this.ztable.AfterEdit("DELETE");
                }
            }
        }

        private void dgBag_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (this.pMode == "CHOOSE")
            {
                this.chooseToolStripMenuItem.PerformClick();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dgBag.Rows.Count > 0)
            {
                FormBagEntry entry = new FormBagEntry();
                this.ztable.BeforeEdit(this.dgBag, "EDIT");
                entry.pMode = "EDIT";
                entry.zTable = this.ztable;
                entry.Text = "Edit Record of Bag ";
                entry.dataGridView1 = this.dgBag;
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dgBag = this.ztable.AfterEdit(entry.pMode);
                }
                this.ztable.UnLock();
                entry.Dispose();
            }
        }

        private void FormBag_Load(object sender, EventArgs e)
        {
            this.translate();
            this.ztable.OpenTable("wb_BAG", "SELECT *FROM wb_bag", WBData.conn);
            this.dgBag.DataSource = this.ztable.DT;
            this.dgBag.Sort(this.dgBag.Columns["Bag_Code"], ListSortDirection.Ascending);
            this.dgBag.Columns["Coy"].Visible = false;
            this.dgBag.Columns["Location_Code"].Visible = false;
            this.dgBag.Columns["uniq"].Visible = false;
            this.dgBag.Columns["deleted"].Visible = false;
            this.dgBag.Columns["Create_by"].Visible = false;
            this.dgBag.Columns["Create_date"].Visible = false;
            this.dgBag.Columns["Change_by"].Visible = false;
            this.dgBag.Columns["Change_date"].Visible = false;
            this.dgBag.Columns["Delete_by"].Visible = false;
            this.dgBag.Columns["Delete_date"].Visible = false;
            this.dgBag.Columns["Bag_Code"].HeaderText = "Bag Code";
            this.dgBag.Columns["Comm_Type"].HeaderText = "Comm. Type";
            this.dgBag.Columns["Weight"].HeaderText = "Bag Weight";
            this.dgBag.Columns["Description"].HeaderText = "Desc.";
            this.dgBag.Columns["SAP_Code"].HeaderText = WBSetting.integrationIDSYS ? "IDSYS Code" : "SAP Code";
            base.KeyPreview = true;
            if (!WBUser.CheckTrustee("MD_BAG", "A"))
            {
                this.addNewRecordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_BAG", "E"))
            {
                this.editRecordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_BAG", "D"))
            {
                this.deleteToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_BAG", "V"))
            {
                this.viewToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("MD_SYNCH", "A"))
            {
                this.zWBToolStripMenuItem.Enabled = false;
            }
            if ((this.pMode != "") && (this.pFind.Trim() != ""))
            {
                this.TextFind.Text = this.pFind;
                this.buttonFind.PerformClick();
            }
            this.chooseToolStripMenuItem.Visible = this.pMode != "";
        }

        private void InitializeComponent()
        {
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeAllToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator1 = new ToolStripSeparator();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeToolStripMenuItem = new ToolStripMenuItem();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.viewToolStripMenuItem = new ToolStripMenuItem();
            this.zWBToolStripMenuItem = new ToolStripMenuItem();
            this.dgBag = new DataGridView();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.chooseToolStripMenuItem = new ToolStripMenuItem();
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.buttonFind = new Button();
            this.menuStrip1 = new MenuStrip();
            ((ISupportInitialize) this.dgBag).BeginInit();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.synchronizeAllToolStripMenuItem.Name = "synchronizeAllToolStripMenuItem";
            this.synchronizeAllToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeAllToolStripMenuItem.Text = "Synchronize All";
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new Size(160, 6);
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.synchronizeToolStripMenuItem.Name = "synchronizeToolStripMenuItem";
            this.synchronizeToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeToolStripMenuItem.Text = "Synchronize";
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem, this.viewToolStripMenuItem, this.toolStripSeparator1, this.zWBToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(toolStripItems);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.activitiesToolStripMenuItem.Click += new EventHandler(this.activitiesToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewToolStripMenuItem.Text = "View";
            this.viewToolStripMenuItem.Click += new EventHandler(this.viewToolStripMenuItem_Click);
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.synchronizeToolStripMenuItem, this.synchronizeAllToolStripMenuItem };
            this.zWBToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.zWBToolStripMenuItem.Name = "zWBToolStripMenuItem";
            this.zWBToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.zWBToolStripMenuItem.Text = "ZWB";
            this.zWBToolStripMenuItem.Visible = false;
            this.dgBag.AllowUserToAddRows = false;
            this.dgBag.AllowUserToDeleteRows = false;
            this.dgBag.AllowUserToResizeRows = false;
            this.dgBag.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgBag.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dgBag.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgBag.Dock = DockStyle.Fill;
            this.dgBag.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgBag.Location = new Point(0, 0x18);
            this.dgBag.MultiSelect = false;
            this.dgBag.Name = "dgBag";
            this.dgBag.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgBag.Size = new Size(0x1cb, 0xd7);
            this.dgBag.TabIndex = 0x10;
            this.dgBag.CellDoubleClick += new DataGridViewCellEventHandler(this.dgBag_CellDoubleClick);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.chooseToolStripMenuItem.Name = "chooseToolStripMenuItem";
            this.chooseToolStripMenuItem.Size = new Size(0x3b, 20);
            this.chooseToolStripMenuItem.Text = "Choose";
            this.chooseToolStripMenuItem.ToolTipText = "Choose this record & close this browser";
            this.chooseToolStripMenuItem.Click += new EventHandler(this.chooseToolStripMenuItem_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0xef);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x1cb, 0x21);
            this.panel1.TabIndex = 0x11;
            this.progressBar1.Location = new Point(0x25c, 8);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xa6, 0x10);
            this.progressBar1.TabIndex = 0x10;
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] itemArray3 = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(itemArray3);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x1cb, 0x18);
            this.menuStrip1.TabIndex = 0x12;
            this.menuStrip1.Text = "menuStrip1";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1cb, 0x110);
            base.ControlBox = false;
            base.Controls.Add(this.dgBag);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.menuStrip1);
            base.Name = "FormBag";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Form Bag";
            base.Load += new EventHandler(this.FormBag_Load);
            ((ISupportInitialize) this.dgBag).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseToolStripMenuItem.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
        }

        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormBagEntry entry = new FormBagEntry();
            this.ztable.BeforeEdit(this.dgBag, "EDIT");
            entry.pMode = "VIEW";
            entry.zTable = this.ztable;
            entry.Text = "View Record of Bag ";
            entry.dataGridView1 = this.dgBag;
            entry.ShowDialog();
        }
    }
}

