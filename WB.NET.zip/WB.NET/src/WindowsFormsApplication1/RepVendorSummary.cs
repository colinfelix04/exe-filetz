﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Text;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class RepVendorSummary : Form
    {
        public WBTable tblComm = new WBTable();
        public WBTable tblDO = new WBTable();
        private double totalgross;
        private double totalnetto;
        private double totaltarra;
        private double totalreceive;
        private double totaldeduct;
        private double totalunit;
        private double totaloercpo;
        private double totaltandan;
        private double totalreceiveAVG;
        private double totalnetSDHI;
        private double unit;
        private double tunit;
        private double netSDHI;
        private double tnetSDHI;
        private double gross;
        private double tandan;
        private double ttandan;
        private double tarra;
        private double receive;
        private double receiveAVG;
        private double treceiveAVG;
        private double deduct;
        private double netto;
        private double tgross;
        private double treceive;
        private double ttarra;
        private double tnetto;
        private double tdeduct;
        private double avg;
        private double tavg;
        private double oercpo;
        private double toercpo;
        private double rvcpo;
        private double trvcpo;
        private double grossDate;
        private double nettoDate;
        private double tarraDate;
        private double receiveDate;
        private double deductDate;
        private double unitDate;
        private double oercpoDate;
        private double tandanDate;
        private double receiveAVGDate;
        private double netSDHIDate;
        private double tmpgunny;
        private double gunny;
        private double gunnyDate;
        private double tgunny;
        private string Retur_masuk;
        private string Retur_keluar;
        private double ReturInKgDate;
        private double ReturInPackDate;
        private double LossInKgDate;
        private double LossInPackDate;
        private double LoadingQtyDate;
        private double ReturInKg;
        private double ReturInPack;
        private double tReturInKg;
        private double tReturInPack;
        private double LossInKg;
        private double LossInPack;
        private double tLossInKg;
        private double tLossInPack;
        private double LoadingQty;
        private double tLoadingQty;
        private IContainer components = null;
        public Button button2;
        public Button button1;
        public DateTimePicker monthCalendar2;
        public Label label2;
        public Label labelRecNo;
        public Label labelProcess;
        public DateTimePicker monthCalendar1;
        public Label label1;
        public Label label5;
        public Button buttonComm;
        public Label labelCommName;
        public TextBox textCommodity;
        public Label labelcommodity;
        private LineShape lineShape1;
        private ShapeContainer shapeContainer1;
        public Button button3;
        public TextBox textDO;
        public Label label3;
        public TextBox textPO;
        public Label label4;
        private GroupBox groupBox1;
        private RadioButton radioButton1;
        private RadioButton radioPO;
        private RadioButton radioDetails;
        private GroupBox groupBox2;
        private CheckBox cbGunny;
        private CheckBox checkRVCPO;
        private CheckBox checkDeduc;
        private CheckBox checkBJR;
        private CheckBox checkUnit;
        private GroupBox groupBox3;
        private RadioButton rbDNS;
        private RadioButton rbSNUTMC;
        private RadioButton rbSNUT;
        private CheckBox cBoxLossInPack;
        private CheckBox cBoxLossInKg;
        private CheckBox cBoxReturInPack;
        private CheckBox cBoxReturInKg;
        private CheckBox cBoxLoadingQty;

        public RepVendorSummary()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                this.labelProcess.Visible = true;
                this.labelRecNo.Visible = true;
                this.labelProcess.Refresh();
                this.labelRecNo.Refresh();
                this.printreport();
                this.labelProcess.Visible = false;
                this.labelRecNo.Visible = false;
                this.labelProcess.Text = "";
                this.labelRecNo.Text = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFind = this.textDO.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDO.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
                this.textCommodity.Focus();
            }
            commodity.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void initHeader(HTML rep)
        {
            rep.Write("<tr class='bd'>");
            rep.Write("<td align=center><b>No</b></td>");
            rep.Write("<td align=center><b>" + Resource.Composite_002 + "</b></td>");
            rep.Write("<td align=center><b>Relation Name</b></td>");
            if (this.radioPO.Checked)
            {
                rep.Write("<td align=center><b>PO/SO</b></td>");
            }
            if (this.checkUnit.Checked)
            {
                rep.Write("<td align=center><b>Unit</b></td>");
            }
            if (this.checkBJR.Checked)
            {
                rep.Write("<td align=center><b>BJR</b></td>");
            }
            if (this.checkRVCPO.Checked)
            {
                rep.Write("<td align=center><b>RV.CPO</b></td>");
            }
            rep.Write("<td align=center><b>" + Resource.Main_019 + "</b></td>");
            rep.Write("<td align=center><b>" + Resource.Main_020 + "</b></td>");
            rep.Write("<td align=center><b>" + Resource.Main_021 + "</b></td>");
            if (this.checkDeduc.Checked)
            {
                rep.Write("<td align=center><b>" + Resource.Main_022 + "</b></td>");
            }
            if (this.cbGunny.Checked)
            {
                rep.Write("<td align=center><b>Gunny</b></td>");
            }
            rep.Write("<td align=center><b>" + Resource.Main_023 + "</b></td>");
            if (!this.rbDNS.Checked)
            {
                rep.Write("<td align=center><b>Net u/ Today</b></td>");
            }
            if (this.cBoxReturInKg.Checked)
            {
                rep.Write("<td align=center width=80><b>Return (Kg)</b></td>");
            }
            if (this.cBoxReturInPack.Checked)
            {
                rep.Write("<td align=center width=80><b>Return (Pack)</b></td>");
            }
            if (this.cBoxLossInKg.Checked)
            {
                rep.Write("<td align=center width=100><b>Loss(-)/Gain(+) (Kg)</b></td>");
            }
            if (this.cBoxLossInPack.Checked)
            {
                rep.Write("<td align=center width=100><b>Loss(-)/Gain(+) (Pack)</b></td>");
            }
            if (this.cBoxLoadingQty.Checked)
            {
                rep.Write("<td align=center width=100><b>Loading Qty</b></td>");
            }
            rep.Write("</tr>");
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.monthCalendar2 = new DateTimePicker();
            this.label2 = new Label();
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.monthCalendar1 = new DateTimePicker();
            this.label1 = new Label();
            this.label5 = new Label();
            this.buttonComm = new Button();
            this.labelCommName = new Label();
            this.textCommodity = new TextBox();
            this.labelcommodity = new Label();
            this.lineShape1 = new LineShape();
            this.shapeContainer1 = new ShapeContainer();
            this.button3 = new Button();
            this.textDO = new TextBox();
            this.label3 = new Label();
            this.textPO = new TextBox();
            this.label4 = new Label();
            this.groupBox1 = new GroupBox();
            this.radioButton1 = new RadioButton();
            this.radioPO = new RadioButton();
            this.radioDetails = new RadioButton();
            this.groupBox2 = new GroupBox();
            this.cBoxLossInPack = new CheckBox();
            this.cBoxLossInKg = new CheckBox();
            this.cBoxReturInPack = new CheckBox();
            this.cBoxReturInKg = new CheckBox();
            this.cbGunny = new CheckBox();
            this.checkRVCPO = new CheckBox();
            this.checkDeduc = new CheckBox();
            this.checkBJR = new CheckBox();
            this.checkUnit = new CheckBox();
            this.groupBox3 = new GroupBox();
            this.rbDNS = new RadioButton();
            this.rbSNUTMC = new RadioButton();
            this.rbSNUT = new RadioButton();
            this.cBoxLoadingQty = new CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            base.SuspendLayout();
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x16a, 0x1ee);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x58, 0x20);
            this.button2.TabIndex = 6;
            this.button2.Text = "&Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x10c, 0x1ee);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x58, 0x21);
            this.button1.TabIndex = 5;
            this.button1.Text = "&Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(100, 0x69);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x83, 20);
            this.monthCalendar2.TabIndex = 2;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x49, 0x6d);
            this.label2.Name = "label2";
            this.label2.Size = new Size(20, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "To";
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(390, 0x12);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(60, 13);
            this.labelRecNo.TabIndex = 13;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.TextAlign = ContentAlignment.TopRight;
            this.labelRecNo.Visible = false;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(260, 0x12);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x7c, 13);
            this.labelProcess.TabIndex = 12;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(100, 0x4f);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x83, 20);
            this.monthCalendar1.TabIndex = 1;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x3f, 0x53);
            this.label1.Name = "label1";
            this.label1.Size = new Size(30, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "From";
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(0x17, 0x12);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x70, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Vendor Summary 1";
            this.buttonComm.Location = new Point(0x114, 0x34);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 14;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.labelCommName.AutoSize = true;
            this.labelCommName.Location = new Point(0x12e, 0x39);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x3a, 13);
            this.labelCommName.TabIndex = 15;
            this.labelCommName.Text = "Commodity";
            this.textCommodity.CharacterCasing = CharacterCasing.Upper;
            this.textCommodity.Location = new Point(100, 0x35);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0xad, 20);
            this.textCommodity.TabIndex = 0;
            this.textCommodity.Leave += new EventHandler(this.textCommodity_Leave);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x23, 0x39);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3a, 13);
            this.labelcommodity.TabIndex = 9;
            this.labelcommodity.Text = "Commodity";
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 0x10;
            this.lineShape1.X2 = 0x1cd;
            this.lineShape1.Y1 = 0x29;
            this.lineShape1.Y2 = 0x29;
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.lineShape1 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(0x1e3, 0x21e);
            this.shapeContainer1.TabIndex = 7;
            this.shapeContainer1.TabStop = false;
            this.button3.Location = new Point(0x114, 130);
            this.button3.Margin = new Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x17, 0x17);
            this.button3.TabIndex = 0x12;
            this.button3.Text = "...";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.textDO.CharacterCasing = CharacterCasing.Upper;
            this.textDO.Location = new Point(100, 0x83);
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0xad, 20);
            this.textDO.TabIndex = 0x10;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x36, 0x87);
            this.label3.Name = "label3";
            this.label3.Size = new Size(40, 13);
            this.label3.TabIndex = 0x11;
            this.label3.Text = "DO No";
            this.textPO.CharacterCasing = CharacterCasing.Upper;
            this.textPO.Location = new Point(100, 0x9d);
            this.textPO.Name = "textPO";
            this.textPO.Size = new Size(0xad, 20);
            this.textPO.TabIndex = 0x13;
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x23, 0xa1);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x3b, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "PO/SO No";
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Controls.Add(this.radioPO);
            this.groupBox1.Controls.Add(this.radioDetails);
            this.groupBox1.Location = new Point(0x63, 0xb7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(200, 0x58);
            this.groupBox1.TabIndex = 0x17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Report Details";
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new Point(6, 0x13);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new Size(0x45, 0x11);
            this.radioButton1.TabIndex = 0x19;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "No Detail";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new EventHandler(this.radioButton1_CheckedChanged);
            this.radioPO.AutoSize = true;
            this.radioPO.Location = new Point(6, 0x41);
            this.radioPO.Name = "radioPO";
            this.radioPO.Size = new Size(0x83, 0x11);
            this.radioPO.TabIndex = 0x18;
            this.radioPO.Text = "Show PO / SO Details";
            this.radioPO.UseVisualStyleBackColor = true;
            this.radioPO.CheckedChanged += new EventHandler(this.radioPO_CheckedChanged);
            this.radioDetails.AutoSize = true;
            this.radioDetails.Location = new Point(6, 0x2a);
            this.radioDetails.Name = "radioDetails";
            this.radioDetails.Size = new Size(0xac, 0x11);
            this.radioDetails.TabIndex = 0x17;
            this.radioDetails.Text = "Show Details by Selected Date";
            this.radioDetails.UseVisualStyleBackColor = true;
            this.radioDetails.CheckedChanged += new EventHandler(this.radioDetails_CheckedChanged);
            this.groupBox2.Controls.Add(this.cBoxLoadingQty);
            this.groupBox2.Controls.Add(this.cBoxLossInPack);
            this.groupBox2.Controls.Add(this.cBoxLossInKg);
            this.groupBox2.Controls.Add(this.cBoxReturInPack);
            this.groupBox2.Controls.Add(this.cBoxReturInKg);
            this.groupBox2.Controls.Add(this.cbGunny);
            this.groupBox2.Controls.Add(this.checkRVCPO);
            this.groupBox2.Controls.Add(this.checkDeduc);
            this.groupBox2.Controls.Add(this.checkBJR);
            this.groupBox2.Controls.Add(this.checkUnit);
            this.groupBox2.Location = new Point(0x63, 0x115);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0x14e, 0x75);
            this.groupBox2.TabIndex = 0x18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Report Options";
            this.cBoxLossInPack.AutoSize = true;
            this.cBoxLossInPack.Location = new Point(0x6c, 0x54);
            this.cBoxLossInPack.Name = "cBoxLossInPack";
            this.cBoxLossInPack.Size = new Size(0x57, 0x11);
            this.cBoxLossInPack.TabIndex = 0xb3;
            this.cBoxLossInPack.Text = "Loss in Pack";
            this.cBoxLossInPack.UseVisualStyleBackColor = true;
            this.cBoxLossInKg.AutoSize = true;
            this.cBoxLossInKg.Location = new Point(0x6c, 0x3e);
            this.cBoxLossInKg.Name = "cBoxLossInKg";
            this.cBoxLossInKg.Size = new Size(0x4d, 0x11);
            this.cBoxLossInKg.TabIndex = 180;
            this.cBoxLossInKg.Text = "Loss in KG";
            this.cBoxLossInKg.UseVisualStyleBackColor = true;
            this.cBoxReturInPack.AutoSize = true;
            this.cBoxReturInPack.Location = new Point(8, 0x55);
            this.cBoxReturInPack.Name = "cBoxReturInPack";
            this.cBoxReturInPack.Size = new Size(0x61, 0x11);
            this.cBoxReturInPack.TabIndex = 0xb1;
            this.cBoxReturInPack.Text = "Return in Pack";
            this.cBoxReturInPack.UseVisualStyleBackColor = true;
            this.cBoxReturInKg.AutoSize = true;
            this.cBoxReturInKg.Location = new Point(8, 0x3f);
            this.cBoxReturInKg.Name = "cBoxReturInKg";
            this.cBoxReturInKg.Size = new Size(0x57, 0x11);
            this.cBoxReturInKg.TabIndex = 0xb2;
            this.cBoxReturInKg.Text = "Return in KG";
            this.cBoxReturInKg.UseVisualStyleBackColor = true;
            this.cbGunny.AutoSize = true;
            this.cbGunny.Location = new Point(0xd6, 0x13);
            this.cbGunny.Name = "cbGunny";
            this.cbGunny.Size = new Size(0x39, 0x11);
            this.cbGunny.TabIndex = 80;
            this.cbGunny.Text = "Gunny";
            this.cbGunny.UseVisualStyleBackColor = true;
            this.checkRVCPO.AutoSize = true;
            this.checkRVCPO.Location = new Point(0x6c, 0x13);
            this.checkRVCPO.Name = "checkRVCPO";
            this.checkRVCPO.Size = new Size(0x42, 0x11);
            this.checkRVCPO.TabIndex = 0x4e;
            this.checkRVCPO.Text = "RV CPO";
            this.checkRVCPO.TextAlign = ContentAlignment.MiddleCenter;
            this.checkRVCPO.UseVisualStyleBackColor = true;
            this.checkDeduc.AutoSize = true;
            this.checkDeduc.Location = new Point(0x6c, 40);
            this.checkDeduc.Name = "checkDeduc";
            this.checkDeduc.Size = new Size(0x4b, 0x11);
            this.checkDeduc.TabIndex = 0x4f;
            this.checkDeduc.Text = "Deduction";
            this.checkDeduc.UseVisualStyleBackColor = true;
            this.checkBJR.AutoSize = true;
            this.checkBJR.Location = new Point(8, 0x29);
            this.checkBJR.Name = "checkBJR";
            this.checkBJR.Size = new Size(0x2e, 0x11);
            this.checkBJR.TabIndex = 0x4d;
            this.checkBJR.Text = "BJR";
            this.checkBJR.UseVisualStyleBackColor = true;
            this.checkUnit.AutoSize = true;
            this.checkUnit.Location = new Point(8, 0x13);
            this.checkUnit.Name = "checkUnit";
            this.checkUnit.Size = new Size(0x2d, 0x11);
            this.checkUnit.TabIndex = 0x4c;
            this.checkUnit.Text = "Unit";
            this.checkUnit.UseVisualStyleBackColor = true;
            this.groupBox3.Controls.Add(this.rbDNS);
            this.groupBox3.Controls.Add(this.rbSNUTMC);
            this.groupBox3.Controls.Add(this.rbSNUT);
            this.groupBox3.Location = new Point(100, 400);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(0xec, 0x58);
            this.groupBox3.TabIndex = 0x19;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Net Until Today ";
            this.rbDNS.AutoSize = true;
            this.rbDNS.Checked = true;
            this.rbDNS.Location = new Point(6, 0x13);
            this.rbDNS.Name = "rbDNS";
            this.rbDNS.Size = new Size(0x59, 0x11);
            this.rbDNS.TabIndex = 0x19;
            this.rbDNS.TabStop = true;
            this.rbDNS.Text = "Do Not Show";
            this.rbDNS.UseVisualStyleBackColor = true;
            this.rbSNUTMC.AutoSize = true;
            this.rbSNUTMC.Location = new Point(6, 0x41);
            this.rbSNUTMC.Name = "rbSNUTMC";
            this.rbSNUTMC.Size = new Size(0xc9, 0x11);
            this.rbSNUTMC.TabIndex = 0x18;
            this.rbSNUTMC.Text = "Show Net Until Today (Monthly cum.)";
            this.rbSNUTMC.UseVisualStyleBackColor = true;
            this.rbSNUT.AutoSize = true;
            this.rbSNUT.Enabled = false;
            this.rbSNUT.Location = new Point(6, 0x2a);
            this.rbSNUT.Name = "rbSNUT";
            this.rbSNUT.Size = new Size(0x81, 0x11);
            this.rbSNUT.TabIndex = 0x17;
            this.rbSNUT.Text = "Show Net Until Today";
            this.rbSNUT.UseVisualStyleBackColor = true;
            this.cBoxLoadingQty.AutoSize = true;
            this.cBoxLoadingQty.Location = new Point(0xd6, 40);
            this.cBoxLoadingQty.Name = "cBoxLoadingQty";
            this.cBoxLoadingQty.Size = new Size(0x53, 0x11);
            this.cBoxLoadingQty.TabIndex = 0xb5;
            this.cBoxLoadingQty.Text = "Loading Qty";
            this.cBoxLoadingQty.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1e3, 0x21e);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox3);
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.textPO);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.textDO);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.monthCalendar2);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.monthCalendar1);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.shapeContainer1);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "RepVendorSummary";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Vendor Summary Report";
            base.Load += new EventHandler(this.RepVendorSummary_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepVendorSummary_KeyPress);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void printreport()
        {
            HTML rep = new HTML();
            rep.File = rep.File + @"\" + WBUser.UserID + "repsummary.htm";
            rep.Title = "VENDOR SUMMARY REPORT";
            rep.Open();
            rep.Write(rep.Style());
            rep.Write("<br><font size=5><b>VENDOR SUMMARY REPORT</b></font>");
            if (this.radioDetails.Checked)
            {
                rep.Write("<br><font size=4>Details By Date</font>");
            }
            if (this.radioPO.Checked)
            {
                rep.Write("<br><font size=4>Details By PO/SO</font>");
            }
            string[] textArray1 = new string[] { "<br><br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
            rep.Write(string.Concat(textArray1));
            string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
            rep.Write(string.Concat(textArray2));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            rep.Write("<br><br>");
            rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
            rep.Write("<tr class=bd>");
            rep.Write("<td>Selected Date</td>");
            string[] textArray3 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
            rep.Write(string.Concat(textArray3));
            rep.Write("</tr>");
            rep.Write("<tr class=bd>");
            rep.Write("<td>Report Date</td>");
            rep.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
            rep.Write("</tr>");
            rep.Write("</table>");
            rep.Write("<br/><br/>");
            WBTable table = new WBTable();
            table.OpenTable("wb_transaction_type", "Select top 1 * from wb_transaction_type where " + WBData.CompanyLocation("and is_return = 'Y' and IO = 'I'"), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                this.Retur_masuk = table.DT.Rows[0]["transaction_code"].ToString();
            }
            table.OpenTable("wb_transaction_type", "Select top 1 * from wb_transaction_type where " + WBData.CompanyLocation("and is_return = 'Y' and IO = 'O'"), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                this.Retur_keluar = table.DT.Rows[0]["transaction_code"].ToString();
            }
            WBTable table2 = new WBTable();
            string sqltext = "SELECT comm_code, comm_name, Relation_Code, relation_name, Report_Date, SUM(netto) as netto, SUM(Tarra) as Tarra, SUM(bruto) as bruto, SUM (CASE WHEN TotalBunch < 1 THEN Bruto Else 0 END) AS BrutoBunchNol, SUM (CASE WHEN TotalBunch < 1 THEN Tarra Else 0 END) AS TarraBunchNol, SUM (return_qty_kg) as ReturInKg, SUM (return_qty_pack) as ReturInPack,SUM (loading_qty_opw) as loading_qty_opw, sum (estate_qty) as estate_qty,SUM (case when deductedBy = '1' and (Unit <> 'KG' or bulkpack = 'P') then (loading_qty - loading_qty_opw - return_qty_pack) * -1 else 0 end) as lossinpack,SUM (case when deductedBy = '1' and Unit = 'KG' then (netto - estate_qty - return_qty_kg) * -1 else 0 end) as lossinkg, SUM(TotalBunch) as TotalBunch, SUM(Rend_CPO) as Rend_CPO, SUM(Rend_CPO * Netto / 100) AS oercpoDate, SUM(TotalBunch * WeightPerUnitName) as Gunny, SUM(Deduction) as deduction, COUNT(Report_Date) as unit , SUM(LOADING_QTY) as Loading_Qty ";
            if (this.radioPO.Checked)
            {
                sqltext = sqltext + ", PO,SO, transaction_code ";
            }
            sqltext = sqltext + "FROM VW_TRANS WHERE ";
            sqltext = !this.rbSNUTMC.Checked ? (!this.rbSNUT.Checked ? ((sqltext + WBData.CompanyLocation(" and ((report_Date>='" + this.monthCalendar1.Value.ToString("yyyy/MM/dd") + " 00:00:00'")) + " and report_Date<='" + this.monthCalendar2.Value.ToString("yyyy/MM/dd") + " 00:00:00'))") : (sqltext + WBData.CompanyLocation("and report_Date<='" + this.monthCalendar2.Value.ToString("yyyy/MM/dd") + " 00:00:00'"))) : ((sqltext + WBData.CompanyLocation(" and ((report_Date>='" + this.monthCalendar1.Value.ToString("yyyy/MM") + "/01 00:00:00'")) + " and report_Date<='" + this.monthCalendar2.Value.ToString("yyyy/MM/dd") + " 00:00:00'))");
            sqltext = sqltext + " and (deleted is null or deleted = 'N') ";
            string[] textArray4 = new string[] { sqltext, " and (transaction_code <> '", this.Retur_masuk, "' and transaction_code <> '", this.Retur_keluar, "') " };
            sqltext = string.Concat(textArray4) + " and (Report_Date is not null) ";
            if (this.textCommodity.Text != "")
            {
                sqltext = sqltext + " and (Comm_Code = '" + this.textCommodity.Text + "') ";
            }
            if (this.textDO.Text != "")
            {
                sqltext = sqltext + " and (DO_NO = '" + this.textDO.Text + "') ";
            }
            if (this.textPO.Text != "")
            {
                sqltext = sqltext + " and (PO = '" + this.textPO.Text + "') ";
            }
            sqltext = (sqltext + " and (NOT(REF like '%" + Constant.TITIP_TIMBUN_POSTFIX + "'))") + " and (NOT(REF like '%T'))" + " GROUP BY comm_code, comm_name, relation_code, relation_name, Report_Date ";
            if (this.radioPO.Checked)
            {
                sqltext = sqltext + ", PO,SO, transaction_code ";
            }
            sqltext = sqltext + "ORDER BY comm_code, relation_code, Report_Date";
            table2.OpenTable("vw_trans", sqltext, WBData.conn);
            this.gross = 0.0;
            this.netto = 0.0;
            this.tarra = 0.0;
            this.receive = 0.0;
            this.deduct = 0.0;
            this.tgross = 0.0;
            this.tnetto = 0.0;
            this.ttarra = 0.0;
            this.treceive = 0.0;
            this.tdeduct = 0.0;
            this.tandan = 0.0;
            this.tunit = 0.0;
            this.ttandan = 0.0;
            this.ReturInKg = 0.0;
            this.ReturInPack = 0.0;
            this.LossInKg = 0.0;
            this.LossInPack = 0.0;
            this.LoadingQty = 0.0;
            this.tReturInKg = 0.0;
            this.tReturInPack = 0.0;
            this.tLossInKg = 0.0;
            this.tLossInPack = 0.0;
            this.tLoadingQty = 0.0;
            this.rvcpo = 0.0;
            this.toercpo = 0.0;
            this.trvcpo = 0.0;
            this.oercpo = 0.0;
            this.avg = 0.0;
            this.tavg = 0.0;
            this.unit = 0.0;
            this.netSDHI = 0.0;
            this.tnetSDHI = 0.0;
            this.grossDate = 0.0;
            this.nettoDate = 0.0;
            this.tarraDate = 0.0;
            this.receiveDate = 0.0;
            this.deductDate = 0.0;
            this.unitDate = 0.0;
            this.oercpoDate = 0.0;
            this.tandanDate = 0.0;
            this.receiveAVGDate = 0.0;
            this.netSDHIDate = 0.0;
            this.ReturInKgDate = 0.0;
            this.ReturInPackDate = 0.0;
            this.LossInKgDate = 0.0;
            this.LossInPackDate = 0.0;
            this.LoadingQtyDate = 0.0;
            this.gunny = 0.0;
            this.tgunny = 0.0;
            int num = 0;
            if (table2.DT.Rows.Count == 0.0)
            {
                MessageBox.Show(Resource.Mes_348, Resource.Title_006, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                rep.Close();
                rep.Dispose();
            }
            else
            {
                table2.DR = table2.DT.Rows[0];
                string pStr = table2.DR["relation_code"].ToString();
                string str3 = table2.DR["relation_name"].ToString();
                string objA = "";
                string str5 = "";
                if (this.radioPO.Checked)
                {
                    if (table2.DR["PO"].ToString() != "")
                    {
                        objA = table2.DR["PO"].ToString();
                        str5 = table2.DR["PO"].ToString();
                    }
                    else
                    {
                        objA = table2.DR["SO"].ToString();
                        str5 = table2.DR["SO"].ToString();
                    }
                }
                string str6 = table2.DR["relation_code"].ToString();
                string str7 = table2.DR["comm_code"].ToString();
                DateTime time = Convert.ToDateTime("01/01/1970 00:00:00");
                StringBuilder builder = new StringBuilder();
                string[] textArray5 = new string[] { "<br><b><font size =2 >Commodity : ", str7, " - ", table2.DR["comm_name"].ToString(), "</font></b>" };
                rep.Write(string.Concat(textArray5));
                rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                this.initHeader(rep);
                int num3 = 0;
                int count = table2.DT.Rows.Count;
                string str8 = "";
                string str9 = "";
                foreach (DataRow row in table2.DT.Rows)
                {
                    string str10 = row["relation_Code"].ToString();
                    this.grossDate += Program.StrToDouble(row["bruto"].ToString(), 0);
                    this.nettoDate += Program.StrToDouble(row["netto"].ToString(), 0);
                    this.tarraDate += Program.StrToDouble(row["tarra"].ToString(), 0);
                    this.receiveDate += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                    this.tmpgunny = Program.StrToDouble(row["Gunny"].ToString(), 2);
                    this.tmpgunny = Program.StrToDouble($"{this.tmpgunny:N0}", 0);
                    this.gunnyDate += this.tmpgunny;
                    this.deductDate += Program.StrToDouble(row["Deduction"].ToString(), 0);
                    this.oercpoDate += Program.StrToDouble(row["oercpodate"].ToString(), 2);
                    this.tandanDate += Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                    this.netSDHIDate += Program.StrToDouble(row["Netto"].ToString(), 0);
                    this.ReturInPackDate += Program.StrToDouble(row["ReturInPack"].ToString(), 0);
                    this.ReturInKgDate += Program.StrToDouble(row["ReturInKg"].ToString(), 0);
                    this.LossInPackDate += Program.StrToDouble(row["lossInPack"].ToString(), 0);
                    this.LossInKgDate += Program.StrToDouble(row["lossInKg"].ToString(), 0);
                    this.LoadingQtyDate += Program.StrToDouble(row["Loading_Qty"].ToString(), 0);
                    if (row["comm_code"].ToString() != str7)
                    {
                        num++;
                        rep.Write("<tr class='bd'>");
                        rep.Write("<td align=right>" + rep.strq(num.ToString()) + "</td>");
                        rep.Write("<td align=left>" + rep.strq(pStr) + "</td>");
                        rep.Write("<td align=left>" + rep.strq(str3) + "</td>");
                        str8 = !((objA == "") || ReferenceEquals(objA, null)) ? objA : "&nbsp;";
                        if (this.radioPO.Checked)
                        {
                            rep.Write("<td align=right>" + str8 + "</td>");
                        }
                        if (this.checkUnit.Checked)
                        {
                            rep.Write("<td align=right>" + this.unit + "</td>");
                        }
                        if (this.checkBJR.Checked)
                        {
                            rep.Write("<td align=right>" + rep.strq($"{this.receiveAVG / this.tandan:N2}") + "</td>");
                        }
                        this.rvcpo = (this.oercpo * 100.0) / this.netto;
                        if (this.checkRVCPO.Checked)
                        {
                            rep.Write("<td align=center>" + rep.strq($"{this.rvcpo:N2}") + "</td>");
                        }
                        rep.Write("<td align=right>" + rep.strq($"{this.gross:N0}") + "</td>");
                        rep.Write("<td align=right>" + rep.strq($"{this.tarra:N0}") + "</td>");
                        rep.Write("<td align=right>" + rep.strq($"{this.receive:N0}") + "</td>");
                        this.deduct -= this.cbGunny.Checked ? this.gunny : 0.0;
                        if (this.checkDeduc.Checked)
                        {
                            rep.Write("<td align=right>" + rep.strq($"{this.deduct:N0}") + "</td>");
                        }
                        if (this.cbGunny.Checked)
                        {
                            rep.Write("<td align=right>" + rep.strq($"{this.gunny:N0}") + "</td>");
                        }
                        rep.Write("<td align=right>" + rep.strq($"{this.netto:N0}") + "</td>");
                        if (!this.rbDNS.Checked)
                        {
                            rep.Write("<td align=right>" + rep.strq($"{this.netSDHI:N0}") + "</td>");
                        }
                        if (this.cBoxReturInKg.Checked)
                        {
                            rep.Write("<td align=right>" + rep.strq($"{this.ReturInKg:N0}") + "</td>");
                        }
                        if (this.cBoxReturInPack.Checked)
                        {
                            rep.Write("<td align=right>" + rep.strq($"{this.ReturInPack:N0}") + "</td>");
                        }
                        if (this.cBoxLossInKg.Checked)
                        {
                            rep.Write("<td align=right>" + rep.strq($"{this.LossInKg:N0}") + "</td>");
                        }
                        if (this.cBoxLossInPack.Checked)
                        {
                            rep.Write("<td align=right>" + rep.strq($"{this.LossInPack:N0}") + "</td>");
                        }
                        if (this.cBoxLoadingQty.Checked)
                        {
                            rep.Write("<td align=right>" + rep.strq($"{this.LoadingQty:N0}") + "</td>");
                        }
                        rep.Write("</tr>");
                        if (this.radioDetails.Checked)
                        {
                            rep.Write(builder.ToString());
                        }
                        builder.Clear();
                        rep.Write("<tr class='bd'>");
                        if (this.radioPO.Checked)
                        {
                            rep.Write("<td colspan=4 align=CENTER><b>TOTAL</b></td>");
                        }
                        else
                        {
                            rep.Write("<td colspan=3 align=CENTER><b>TOTAL</b></td>");
                        }
                        if (this.checkUnit.Checked)
                        {
                            rep.Write("<td align=right><b>" + this.tunit + "</b></td>");
                        }
                        if (this.checkBJR.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.treceiveAVG / this.ttandan:N2}") + "</b></td>");
                        }
                        this.rvcpo = (this.toercpo * 100.0) / this.tnetto;
                        if (this.checkRVCPO.Checked)
                        {
                            rep.Write("<td align=center><b>" + rep.strq($"{this.rvcpo:N2}") + "</b></td>");
                        }
                        rep.Write("<td align=right><b>" + rep.strq($"{this.tgross:N0}") + "</b></td>");
                        rep.Write("<td align=right><b>" + rep.strq($"{this.ttarra:N0}") + "</b></td>");
                        rep.Write("<td align=right><b>" + rep.strq($"{this.treceive:N0}") + "</b></td>");
                        this.tdeduct -= this.cbGunny.Checked ? this.tgunny : 0.0;
                        if (this.checkDeduc.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tdeduct:N0}") + "</b></td>");
                        }
                        if (this.cbGunny.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tgunny:N0}") + "</b></td>");
                        }
                        rep.Write("<td align=right><b>" + rep.strq($"{this.tnetto:N0}") + "</b></td>");
                        if (!this.rbDNS.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tnetSDHI:N0}") + "</b></td>");
                        }
                        if (this.cBoxReturInKg.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tReturInKg:N0}") + "</b></td>");
                        }
                        if (this.cBoxReturInPack.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tReturInPack:N0}") + "</b></td>");
                        }
                        if (this.cBoxLossInKg.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tLossInKg:N0}") + "</b></td>");
                        }
                        if (this.cBoxLossInPack.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tLossInPack:N0}") + "</b></td>");
                        }
                        if (this.cBoxLoadingQty.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tLoadingQty:N0}") + "</b></td>");
                        }
                        rep.Write("</tr>");
                        rep.Write("</table>");
                        this.tunit = 0.0;
                        this.treceive = 0.0;
                        this.ttandan = 0.0;
                        this.toercpo = 0.0;
                        this.tnetto = 0.0;
                        this.tgross = 0.0;
                        this.ttarra = 0.0;
                        this.treceive = 0.0;
                        this.tdeduct = 0.0;
                        this.tgunny = 0.0;
                        this.tnetto = 0.0;
                        this.tnetSDHI = 0.0;
                        this.tReturInKg = 0.0;
                        this.tReturInPack = 0.0;
                        this.tLossInKg = 0.0;
                        this.tLossInPack = 0.0;
                        this.tLoadingQty = 0.0;
                        this.gross = 0.0;
                        this.netto = 0.0;
                        this.tarra = 0.0;
                        this.receive = 0.0;
                        this.deduct = 0.0;
                        this.gunny = 0.0;
                        this.unit = 0.0;
                        this.oercpo = 0.0;
                        this.tandan = 0.0;
                        this.receiveAVG = 0.0;
                        this.netSDHI = 0.0;
                        this.LossInKg = 0.0;
                        this.LossInPack = 0.0;
                        this.LoadingQty = 0.0;
                        this.ReturInKg = 0.0;
                        this.ReturInPack = 0.0;
                        num = 0;
                        rep.Write("<br>");
                        string[] textArray6 = new string[] { "<b><font size =3 >", Resource.Menu_021, " : ", row["comm_code"].ToString(), " - ", row["comm_Name"].ToString(), "</font></b>" };
                        rep.Write(string.Concat(textArray6));
                        rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                        this.initHeader(rep);
                        str7 = row["comm_code"].ToString();
                        str6 = pStr;
                        pStr = row["relation_code"].ToString();
                        str3 = row["relation_name"].ToString();
                        str5 = objA;
                        if (this.radioPO.Checked)
                        {
                            objA = (row["PO"].ToString() == "") ? row["SO"].ToString() : row["PO"].ToString();
                        }
                        time = Convert.ToDateTime("01/01/1970 00:00:00");
                    }
                    else
                    {
                        string str11 = "";
                        if (this.radioPO.Checked)
                        {
                            str11 = (row["PO"].ToString() == "") ? row["SO"].ToString() : row["PO"].ToString();
                        }
                        if ((this.radioPO.Checked || (row["relation_code"].ToString() == pStr)) ? ((this.radioPO.Checked && (row["relation_code"].ToString() == pStr)) && (str11 != objA)) : true)
                        {
                            num++;
                            this.labelRecNo.Refresh();
                            str9 = pStr;
                            rep.Write("<tr class='bd'>");
                            rep.Write("<td align=right>" + rep.strq(num.ToString()) + "</td>");
                            rep.Write("<td align=left>" + rep.strq(pStr) + "</td>");
                            rep.Write("<td align=left>" + rep.strq(str3) + "</td>");
                            str8 = !((objA == "") || ReferenceEquals(objA, null)) ? objA : "&nbsp;";
                            if (this.radioPO.Checked)
                            {
                                rep.Write("<td align=right>" + str8 + "</td>");
                            }
                            if (this.checkUnit.Checked)
                            {
                                rep.Write("<td align=right>" + this.unit + "</td>");
                            }
                            if (this.checkBJR.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.receive / this.tandan:N2}") + "</td>");
                            }
                            this.rvcpo = (this.oercpo * 100.0) / this.netto;
                            if (this.checkRVCPO.Checked)
                            {
                                rep.Write("<td align=center>" + rep.strq($"{this.rvcpo:N2}") + "</td>");
                            }
                            rep.Write("<td align=right>" + rep.strq($"{this.gross:N0}") + "</td>");
                            rep.Write("<td align=right>" + rep.strq($"{this.tarra:N0}") + "</td>");
                            rep.Write("<td align=right>" + rep.strq($"{this.receive:N0}") + "</td>");
                            this.deduct -= this.cbGunny.Checked ? this.gunny : 0.0;
                            if (this.checkDeduc.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.deduct:N0}") + "</td>");
                            }
                            if (this.cbGunny.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.gunny:N0}") + "</td>");
                            }
                            rep.Write("<td align=right>" + rep.strq($"{this.netto:N0}") + "</td>");
                            if (!this.rbDNS.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.netSDHI:N0}") + "</td>");
                            }
                            if (this.cBoxReturInKg.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.ReturInKg:N0}") + "</td>");
                            }
                            if (this.cBoxReturInPack.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.ReturInPack:N0}") + "</td>");
                            }
                            if (this.cBoxLossInKg.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.LossInKg:N0}") + "</td>");
                            }
                            if (this.cBoxLossInPack.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.LossInPack:N0}") + "</td>");
                            }
                            if (this.cBoxLoadingQty.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.LoadingQty:N0}") + "</td>");
                            }
                            rep.Write("</tr>");
                            if (this.radioDetails.Checked)
                            {
                                rep.Write(builder.ToString());
                            }
                            builder.Clear();
                            pStr = row["relation_code"].ToString();
                            str3 = row["relation_name"].ToString();
                            if (this.radioPO.Checked)
                            {
                                objA = (row["PO"].ToString() == "") ? row["SO"].ToString() : row["PO"].ToString();
                            }
                            str6 = pStr;
                            time = Convert.ToDateTime("01/01/1970 00:00:00");
                            this.gross = 0.0;
                            this.netto = 0.0;
                            this.tarra = 0.0;
                            this.receive = 0.0;
                            this.gunny = 0.0;
                            this.deduct = 0.0;
                            this.unit = 0.0;
                            this.oercpo = 0.0;
                            this.tandan = 0.0;
                            this.receiveAVG = 0.0;
                            this.netSDHI = 0.0;
                            this.ReturInKg = 0.0;
                            this.ReturInPack = 0.0;
                            this.LossInKg = 0.0;
                            this.LossInPack = 0.0;
                            this.LoadingQty = 0.0;
                        }
                        else if ((row["relation_code"].ToString() != pStr) && this.radioPO.Checked)
                        {
                            this.labelRecNo.Refresh();
                            rep.Write("<tr class='bd'>");
                            if (pStr == str9)
                            {
                                rep.Write("<td align=right>&nbsp;</td>");
                            }
                            else
                            {
                                num++;
                                rep.Write("<td align=right>" + rep.strq(num.ToString()) + "</td>");
                            }
                            rep.Write("<td align=left>" + rep.strq(pStr) + "</td>");
                            rep.Write("<td align=left>" + rep.strq(str3) + "</td>");
                            str8 = !((objA == "") || ReferenceEquals(objA, null)) ? objA : "&nbsp;";
                            if (this.radioPO.Checked)
                            {
                                rep.Write("<td align=right>" + str8 + "</td>");
                            }
                            if (this.checkUnit.Checked)
                            {
                                rep.Write("<td align=right>" + this.unit + "</td>");
                            }
                            if (this.checkBJR.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.receive / this.tandan:N2}") + "</td>");
                            }
                            this.rvcpo = (this.oercpo * 100.0) / this.netto;
                            if (this.checkRVCPO.Checked)
                            {
                                rep.Write("<td align=center>" + rep.strq($"{this.rvcpo:N2}") + "</td>");
                            }
                            rep.Write("<td align=right>" + rep.strq($"{this.gross:N0}") + "</td>");
                            rep.Write("<td align=right>" + rep.strq($"{this.tarra:N0}") + "</td>");
                            rep.Write("<td align=right>" + rep.strq($"{this.receive:N0}") + "</td>");
                            this.deduct -= this.cbGunny.Checked ? this.gunny : 0.0;
                            if (this.checkDeduc.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.deduct:N0}") + "</td>");
                            }
                            if (this.cbGunny.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.gunny:N0}") + "</td>");
                            }
                            rep.Write("<td align=right>" + rep.strq($"{this.netto:N0}") + "</td>");
                            if (!this.rbDNS.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.netSDHI:N0}") + "</td>");
                            }
                            if (this.cBoxReturInKg.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.ReturInKg:N0}") + "</td>");
                            }
                            if (this.cBoxReturInPack.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.ReturInPack:N0}") + "</td>");
                            }
                            if (this.cBoxLossInKg.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.LossInKg:N0}") + "</td>");
                            }
                            if (this.cBoxLossInPack.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.LossInPack:N0}") + "</td>");
                            }
                            if (this.cBoxLoadingQty.Checked)
                            {
                                rep.Write("<td align=right>" + rep.strq($"{this.LoadingQty:N0}") + "</td>");
                            }
                            rep.Write("</tr>");
                            if (this.radioDetails.Checked)
                            {
                                rep.Write(builder.ToString());
                            }
                            builder.Clear();
                            pStr = row["relation_code"].ToString();
                            str3 = row["relation_name"].ToString();
                            if (this.radioPO.Checked)
                            {
                                objA = (row["PO"].ToString() == "") ? row["SO"].ToString() : row["PO"].ToString();
                            }
                            str6 = pStr;
                            time = Convert.ToDateTime("01/01/1970 00:00:00");
                            this.gross = 0.0;
                            this.netto = 0.0;
                            this.tarra = 0.0;
                            this.receive = 0.0;
                            this.gunny = 0.0;
                            this.deduct = 0.0;
                            this.unit = 0.0;
                            this.oercpo = 0.0;
                            this.tandan = 0.0;
                            this.receiveAVG = 0.0;
                            this.netSDHI = 0.0;
                            this.ReturInKg = 0.0;
                            this.ReturInPack = 0.0;
                            this.LossInKg = 0.0;
                            this.LossInPack = 0.0;
                            this.LoadingQty = 0.0;
                        }
                    }
                    this.unit += Program.StrToDouble(row["unit"].ToString(), 0);
                    this.tunit += Program.StrToDouble(row["unit"].ToString(), 0);
                    this.unitDate += Program.StrToDouble(row["unit"].ToString(), 0);
                    if (Program.StrToDouble(row["TotalBunch"].ToString(), 0) > 0.0)
                    {
                        this.receiveAVGDate += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                    }
                    builder.Append("<tr class='bd'>");
                    builder.Append("<td align=right>&nbsp;</td>");
                    builder.Append("<td colspan=2 align=right>" + Convert.ToDateTime(row["report_date"].ToString()).ToShortDateString() + "</td>");
                    str8 = !((objA == "") || ReferenceEquals(objA, null)) ? objA : "&nbsp;";
                    if (this.radioPO.Checked)
                    {
                        builder.Append("<td align=right>" + str8 + "</td>");
                    }
                    if (this.checkUnit.Checked)
                    {
                        builder.Append("<td align=right>" + this.unitDate + "</td>");
                    }
                    if (this.checkBJR.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.receiveAVGDate / this.tandanDate:N2}") + "</td>");
                    }
                    this.rvcpo = (this.oercpoDate * 100.0) / this.nettoDate;
                    if (this.checkRVCPO.Checked)
                    {
                        builder.Append("<td align=center>" + rep.strq($"{this.rvcpo:N2}") + "</td>");
                    }
                    builder.Append("<td align=right>" + rep.strq($"{this.grossDate:N0}") + "</td>");
                    builder.Append("<td align=right>" + rep.strq($"{this.tarraDate:N0}") + "</td>");
                    builder.Append("<td align=right>" + rep.strq($"{this.receiveDate:N0}") + "</td>");
                    this.deductDate -= this.cbGunny.Checked ? this.gunnyDate : 0.0;
                    if (this.checkDeduc.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.deductDate:N0}") + "</td>");
                    }
                    if (this.cbGunny.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.gunnyDate:N0}") + "</td>");
                    }
                    builder.Append("<td align=right>" + rep.strq($"{this.nettoDate:N0}") + "</td>");
                    if (!this.rbDNS.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.netSDHIDate:N0}") + "</td>");
                    }
                    if (this.cBoxReturInKg.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.ReturInKgDate:N0}") + "</td>");
                    }
                    if (this.cBoxReturInPack.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.ReturInPackDate:N0}") + "</td>");
                    }
                    if (this.cBoxLossInKg.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.LossInKgDate:N0}") + "</td>");
                    }
                    if (this.cBoxLossInPack.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.LossInPackDate:N0}") + "</td>");
                    }
                    if (this.cBoxLoadingQty.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.LoadingQtyDate:N0}") + "</td>");
                    }
                    builder.Append("</tr>");
                    time = Convert.ToDateTime(row["report_date"].ToString());
                    this.grossDate = 0.0;
                    this.nettoDate = 0.0;
                    this.tarraDate = 0.0;
                    this.receiveDate = 0.0;
                    this.deductDate = 0.0;
                    this.gunnyDate = 0.0;
                    this.unitDate = 0.0;
                    this.oercpoDate = 0.0;
                    this.tandanDate = 0.0;
                    this.receiveAVGDate = 0.0;
                    this.netSDHIDate = 0.0;
                    this.ReturInKgDate = 0.0;
                    this.ReturInPackDate = 0.0;
                    this.LossInKgDate = 0.0;
                    this.LossInPackDate = 0.0;
                    this.LoadingQtyDate = 0.0;
                    this.tandan += Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                    if (Program.StrToDouble(row["TotalBunch"].ToString(), 0) > 0.0)
                    {
                        this.receiveAVG += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                        this.treceiveAVG += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                    }
                    this.oercpo += Program.StrToDouble(row["oercpodate"].ToString(), 2);
                    this.toercpo += Program.StrToDouble(row["oercpodate"].ToString(), 2);
                    this.ttandan += Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                    this.gross += Program.StrToDouble(row["bruto"].ToString(), 0);
                    this.tarra += Program.StrToDouble(row["tarra"].ToString(), 0);
                    this.netto += Program.StrToDouble(row["netto"].ToString(), 0);
                    this.receive += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                    this.ReturInKg += Program.StrToDouble(row["ReturInKg"].ToString(), 0);
                    this.ReturInPack += Program.StrToDouble(row["ReturInPack"].ToString(), 0);
                    this.LossInKg += Program.StrToDouble(row["LossInKg"].ToString(), 0);
                    this.LossInPack += Program.StrToDouble(row["LossInPack"].ToString(), 0);
                    this.LoadingQty += Program.StrToDouble(row["Loading_Qty"].ToString(), 0);
                    this.tmpgunny = Program.StrToDouble(row["Gunny"].ToString(), 2);
                    this.tmpgunny = Program.StrToDouble($"{this.tmpgunny:N0}", 0);
                    this.gunny += this.tmpgunny;
                    this.deduct += Program.StrToDouble(row["Deduction"].ToString(), 0);
                    this.tgunny += this.tmpgunny;
                    this.tdeduct += Program.StrToDouble(row["Deduction"].ToString(), 0);
                    this.tgross += Program.StrToDouble(row["bruto"].ToString(), 0);
                    this.ttarra += Program.StrToDouble(row["tarra"].ToString(), 0);
                    this.tnetto += Program.StrToDouble(row["netto"].ToString(), 0);
                    this.treceive += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                    this.tnetSDHI += Program.StrToDouble(row["Netto"].ToString(), 0);
                    this.netSDHI += Program.StrToDouble(row["Netto"].ToString(), 0);
                    this.tReturInKg += Program.StrToDouble(row["ReturInKg"].ToString(), 0);
                    this.tReturInPack += Program.StrToDouble(row["ReturInPack"].ToString(), 0);
                    this.tLossInKg += Program.StrToDouble(row["LossInKg"].ToString(), 0);
                    this.tLossInPack += Program.StrToDouble(row["LossInPack"].ToString(), 0);
                    this.tLoadingQty += Program.StrToDouble(row["Loading_Qty"].ToString(), 0);
                    this.labelRecNo.Text = num3++ + "/" + count;
                    this.labelRecNo.Refresh();
                }
                this.labelRecNo.Text = num3++ + "/" + count;
                this.labelRecNo.Refresh();
                num++;
                rep.Write("<tr class='bd'>");
                rep.Write("<td align=right>" + rep.strq(num.ToString()) + "</td>");
                rep.Write("<td align=left>" + rep.strq(pStr) + "</td>");
                rep.Write("<td align=left>" + rep.strq(str3) + "</td>");
                str8 = !((objA == "") || ReferenceEquals(objA, null)) ? objA : "&nbsp;";
                if (this.radioPO.Checked)
                {
                    rep.Write("<td align=right>" + str8 + "</td>");
                }
                if (this.checkUnit.Checked)
                {
                    rep.Write("<td align=right>" + this.unit + "</td>");
                }
                if (this.checkBJR.Checked)
                {
                    rep.Write("<td align=right>" + rep.strq($"{this.receiveAVG / this.tandan:N2}") + "</td>");
                }
                this.rvcpo = (this.oercpo * 100.0) / this.netto;
                if (this.checkRVCPO.Checked)
                {
                    rep.Write("<td align=center>" + rep.strq($"{this.rvcpo:N2}") + "</td>");
                }
                rep.Write("<td align=right>" + rep.strq($"{this.gross:N0}") + "</td>");
                rep.Write("<td align=right>" + rep.strq($"{this.tarra:N0}") + "</td>");
                rep.Write("<td align=right>" + rep.strq($"{this.receive:N0}") + "</td>");
                this.deduct -= this.cbGunny.Checked ? this.gunny : 0.0;
                if (this.checkDeduc.Checked)
                {
                    rep.Write("<td align=right>" + rep.strq($"{this.deduct:N0}") + "</td>");
                }
                if (this.cbGunny.Checked)
                {
                    rep.Write("<td align=right>" + rep.strq($"{this.gunny:N0}") + "</td>");
                }
                rep.Write("<td align=right>" + rep.strq($"{this.netto:N0}") + "</td>");
                if (!this.rbDNS.Checked)
                {
                    rep.Write("<td align=right>" + rep.strq($"{this.netSDHI:N0}") + "</td>");
                }
                if (this.cBoxReturInKg.Checked)
                {
                    rep.Write("<td align=right>" + rep.strq($"{this.ReturInKg:N0}") + "</td>");
                }
                if (this.cBoxReturInPack.Checked)
                {
                    rep.Write("<td align=right>" + rep.strq($"{this.ReturInPack:N0}") + "</td>");
                }
                if (this.cBoxLossInKg.Checked)
                {
                    rep.Write("<td align=right>" + rep.strq($"{this.LossInKg:N0}") + "</td>");
                }
                if (this.cBoxLossInPack.Checked)
                {
                    rep.Write("<td align=right>" + rep.strq($"{this.LossInPack:N0}") + "</td>");
                }
                if (this.cBoxLoadingQty.Checked)
                {
                    rep.Write("<td align=right>" + rep.strq($"{this.LoadingQty:N0}") + "</td>");
                }
                rep.Write("</tr>");
                if (this.radioDetails.Checked)
                {
                    rep.Write(builder.ToString());
                }
                builder.Clear();
                rep.Write("<tr class='bd'>");
                if (this.radioPO.Checked)
                {
                    rep.Write("<td colspan=4 align=CENTER><b>TOTAL</b></td>");
                }
                else
                {
                    rep.Write("<td colspan=3 align=CENTER><b>TOTAL</b></td>");
                }
                if (this.checkUnit.Checked)
                {
                    rep.Write("<td align=right><b>" + this.tunit + "</b></td>");
                }
                if (this.checkBJR.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.treceiveAVG / this.ttandan:N2}") + "</b></td>");
                }
                this.rvcpo = (this.toercpo * 100.0) / this.tnetto;
                if (this.checkRVCPO.Checked)
                {
                    rep.Write("<td align=center><b>" + rep.strq($"{this.rvcpo:N2}") + "</b></td>");
                }
                rep.Write("<td align=right><b>" + rep.strq($"{this.tgross:N0}") + "</b></td>");
                rep.Write("<td align=right><b>" + rep.strq($"{this.ttarra:N0}") + "</b></td>");
                rep.Write("<td align=right><b>" + rep.strq($"{this.treceive:N0}") + "</b></td>");
                this.tdeduct -= this.cbGunny.Checked ? this.tgunny : 0.0;
                if (this.checkDeduc.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tdeduct:N0}") + "</b></td>");
                }
                if (this.cbGunny.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tgunny:N0}") + "</b></td>");
                }
                rep.Write("<td align=right><b>" + rep.strq($"{this.tnetto:N0}") + "</b></td>");
                if (!this.rbDNS.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tnetSDHI:N0}") + "</b></td>");
                }
                if (this.cBoxReturInKg.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tReturInKg:N0}") + "</b></td>");
                }
                if (this.cBoxReturInPack.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tReturInPack:N0}") + "</b></td>");
                }
                if (this.cBoxLossInKg.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tLossInKg:N0}") + "</b></td>");
                }
                if (this.cBoxLossInPack.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tLossInPack:N0}") + "</b></td>");
                }
                if (this.cBoxLoadingQty.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tLoadingQty:N0}") + "</b></td>");
                }
                rep.Write("</tr>");
                rep.Write("</table>");
                rep.Write("<br><br><br>");
                rep.writeSign();
                rep.Close();
                ViewReport report = new ViewReport {
                    webBrowser1 = { Url = new Uri("file:///" + rep.File) }
                };
                report.ShowDialog();
                rep.Dispose();
                report.Dispose();
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton1.Checked)
            {
                this.rbDNS.Checked = true;
                this.rbSNUT.Checked = false;
                this.rbSNUTMC.Checked = false;
                this.rbSNUT.Enabled = false;
                this.rbSNUTMC.Enabled = true;
            }
            else if (this.radioDetails.Checked)
            {
                this.rbDNS.Checked = true;
                this.rbSNUT.Checked = false;
                this.rbSNUTMC.Checked = false;
                this.rbSNUT.Enabled = false;
                this.rbSNUTMC.Enabled = false;
            }
            else
            {
                this.rbDNS.Checked = true;
                this.rbSNUT.Checked = false;
                this.rbSNUTMC.Checked = false;
                this.rbSNUT.Enabled = true;
                this.rbSNUTMC.Enabled = false;
            }
        }

        private void radioDetails_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton1.Checked)
            {
                this.rbDNS.Checked = true;
                this.rbSNUT.Checked = false;
                this.rbSNUTMC.Checked = false;
                this.rbSNUT.Enabled = false;
                this.rbSNUTMC.Enabled = true;
            }
            else if (this.radioDetails.Checked)
            {
                this.rbDNS.Checked = true;
                this.rbSNUT.Checked = false;
                this.rbSNUTMC.Checked = false;
                this.rbSNUT.Enabled = false;
                this.rbSNUTMC.Enabled = false;
            }
            else
            {
                this.rbDNS.Checked = true;
                this.rbSNUT.Checked = false;
                this.rbSNUTMC.Checked = false;
                this.rbSNUT.Enabled = true;
                this.rbSNUTMC.Enabled = false;
            }
        }

        private void radioPO_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton1.Checked)
            {
                this.rbDNS.Checked = true;
                this.rbSNUT.Checked = false;
                this.rbSNUTMC.Checked = false;
                this.rbSNUT.Enabled = false;
                this.rbSNUTMC.Enabled = true;
            }
            else if (this.radioDetails.Checked)
            {
                this.rbDNS.Checked = true;
                this.rbSNUT.Checked = false;
                this.rbSNUTMC.Checked = false;
                this.rbSNUT.Enabled = false;
                this.rbSNUTMC.Enabled = false;
            }
            else
            {
                this.rbDNS.Checked = true;
                this.rbSNUT.Checked = false;
                this.rbSNUTMC.Checked = false;
                this.rbSNUT.Enabled = true;
                this.rbSNUTMC.Enabled = false;
            }
        }

        private void RepVendorSummary_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepVendorSummary_Load(object sender, EventArgs e)
        {
            this.translate();
            base.KeyPreview = true;
            this.labelProcess.Text = "";
            this.labelRecNo.Text = "";
            this.labelCommName.Text = "";
            this.tblComm.OpenTable("wb_commodity", "Select * From wb_commodity", WBData.conn);
            Program.AutoComp(this.tblComm, "comm_code", this.textCommodity);
            this.tblDO.OpenTable("wb_contract", "Select * From wb_contract", WBData.conn);
            Program.AutoComp(this.tblDO, "do_no", this.textDO);
        }

        private void textCommodity_Leave(object sender, EventArgs e)
        {
            this.labelCommName.Text = "";
            if (this.textCommodity.Text.Trim() != "")
            {
                this.tblComm.ReOpen();
                string[] aField = new string[] { "Comm_code" };
                string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                int recNo = this.tblComm.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelCommName.Text = this.tblComm.DT.Rows[recNo]["Comm_name"].ToString().Trim();
                }
                else
                {
                    this.labelCommName.Text = "";
                    this.buttonComm.PerformClick();
                    this.textCommodity.Focus();
                }
            }
        }

        private void translate()
        {
            this.Text = Resource.Report08_001;
            this.label5.Text = Resource.Report08_002;
            this.labelcommodity.Text = Resource.Report08_003;
            this.label1.Text = Resource.Report08_004;
            this.label2.Text = Resource.Report08_005;
            this.radioDetails.Text = Resource.Report08_006;
            this.checkUnit.Text = Resource.Report08_007;
            this.checkRVCPO.Text = Resource.Report08_008;
            this.cbGunny.Text = Resource.Report08_009;
            this.checkBJR.Text = Resource.Report08_010;
            this.checkDeduc.Text = Resource.Report08_011;
            this.button1.Text = Resource.Rep01_042;
            this.button2.Text = Resource.Menu_Close;
        }
    }
}

