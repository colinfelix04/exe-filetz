﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.Text;
    using System.Windows.Forms;

    public class RepIndicator : Form
    {
        public string zAuto = "0";
        private IContainer components = null;
        public Label label3;
        public GroupBox groupBox1;
        public DateTimePicker monthCalendar1;
        public Label label5;
        public Label label6;
        public DateTimePicker monthCalendar2;
        public CheckBox checkDate;
        public TextBox textRef;
        public Label labelcommodity;
        public Button button2;
        public Button button1;
        public Label labelProses2;
        public Label labelProses1;

        public RepIndicator()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if ((!this.checkDate.Checked && (this.textRef.Text == "")) && (this.zAuto == "0"))
            {
                MessageBox.Show("Please enter reference number!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.textRef.Focus();
            }
            else
            {
                HTML html = new HTML();
                html = this.generateRep(this.checkDate.Checked, this.monthCalendar1.Value, this.monthCalendar2.Value, this.textRef.Text, WBData.sCoyCode, WBData.sLocCode, this.zAuto);
                if (html != null)
                {
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + html.File) }
                    };
                    report.ShowDialog();
                    html.Dispose();
                    report.Dispose();
                }
                this.labelProses1.Text = "";
                this.labelProses1.Refresh();
                this.labelProses2.Text = "";
                this.labelProses2.Refresh();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void checkDate_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkDate.Checked)
            {
                this.textRef.Enabled = false;
                this.monthCalendar1.Enabled = true;
                this.monthCalendar2.Enabled = true;
            }
            else
            {
                this.textRef.Enabled = true;
                this.monthCalendar1.Enabled = false;
                this.monthCalendar2.Enabled = false;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public HTML generateRep(bool byDate, DateTime dateFrom, DateTime dateTo, string refNo, string coy, string loc, string zAuto)
        {
            HTML html2;
            WBTable table = this.getQuery(byDate, dateFrom, dateTo, refNo, coy, loc, false);
            if ((table.DT.Rows.Count <= 0) && (zAuto == "0"))
            {
                MessageBox.Show("No records found!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                html2 = null;
            }
            else
            {
                HTML html = new HTML();
                string path = html.File + @"\LogReport";
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                HTML html3 = html;
                string[] textArray1 = new string[] { html3.File, @"\LogReport\", coy, loc, "INDICATOR_STABILITY_", dateFrom.ToString("ddMMyyyy"), ".htm" };
                html3.File = string.Concat(textArray1);
                html.Title = "Weighbridge Indicator Stability Report";
                html.Open();
                html.Write(html.Style());
                WBTable table2 = new WBTable();
                WBTable table3 = new WBTable();
                string[] textArray2 = new string[] { "SELECT location_name FROM wb_location WHERE coy = '", coy, "' AND location_code = '", loc, "'" };
                table2.OpenTable("wb_location", string.Concat(textArray2), WBData.conn);
                string[] textArray3 = new string[] { "SELECT Coy_Name, Coy_Addr1, Coy_Addr2, Coy_Addr3 FROM wb_setting WHERE coy = '", coy, "' AND location_code = '", loc, "' and usedForWeighing = 'Y'" };
                table3.OpenTable("wb_setting", string.Concat(textArray3), WBData.conn);
                html.Write("<br><font size=5><b>WEIGHBRIDGE INDICATOR STABILITY REPORT</b></font><br>");
                string[] textArray4 = new string[] { "<br><font size=4>", table3.DT.Rows[0]["Coy_Name"].ToString(), " (", coy, ")</font>" };
                html.Write(string.Concat(textArray4));
                string[] textArray5 = new string[] { "<br><font size=4>", table2.DT.Rows[0]["Location_Name"].ToString(), " (", loc, ")</font><br>" };
                html.Write(string.Concat(textArray5));
                if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                {
                    html.Write("<font size=2>" + table3.DT.Rows[0]["Coy_Addr1"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                {
                    html.Write("<font size=2>" + table3.DT.Rows[0]["Coy_Addr2"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                {
                    html.Write("<font size=2>" + table3.DT.Rows[0]["Coy_Addr3"].ToString() + "</font><br>");
                }
                table2.Dispose();
                table3.Dispose();
                html.Write("<br><br>");
                html.Write("<table border=0>");
                if (!this.checkDate.Checked && (this.textRef.Text.Trim() != ""))
                {
                    html.Write("<tr class=bd>");
                    html.Write("<td>Reference No</td>");
                    html.Write("<td>: <b>" + this.textRef.Text + "</b></td>");
                    html.Write("</tr>");
                }
                else if (this.checkDate.Checked)
                {
                    html.Write("<tr class=bd>");
                    html.Write("<td>Selected Date</td>");
                    string[] textArray6 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                    html.Write(string.Concat(textArray6));
                    html.Write("</tr>");
                }
                html.Write("<tr class=bd>");
                html.Write("<td>Report Date</td>");
                html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                html.Write("</tr>");
                html.Write("</table>");
                html.Write("<br/><br/><br/>");
                html.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
                html.Write("<tr class=bd>");
                html.Write("<th>No.</th>");
                html.Write("<th>Reference No</th>");
                html.Write("<th>Truck No</th>");
                html.Write("<th>Gross</th>");
                html.Write("<th>Tare</th>");
                html.Write("<th>Received</th>");
                html.Write("<th>Net</th>");
                html.Write("<th>Weighing</th>");
                html.Write("<th>Date</th>");
                html.Write("<th>Time</th>");
                html.Write("<th>WB Code</th>");
                html.Write("<th>Computer Name</th>");
                html.Write("<th>Warning Level</th>");
                html.Write("</tr>");
                WBTable table4 = new WBTable();
                table4.OpenTable("wb_setting", "SELECT DISTINCT(wbcode) AS wbcode FROM wb_setting WHERE " + WBData.CompanyLocation(""), WBData.conn);
                string[,] strArray = new string[table4.DT.Rows.Count, 4];
                int num = 0;
                foreach (DataRow row in table4.DT.Rows)
                {
                    strArray[num, 0] = row["wbcode"].ToString();
                    strArray[num, 1] = "0";
                    strArray[num, 2] = "0";
                    strArray[num, 3] = "0";
                    num++;
                }
                table4.Dispose();
                int num2 = 1;
                int num3 = 0;
                int num4 = 0;
                char[] chArray = null;
                StringBuilder builder = new StringBuilder();
                foreach (DataRow row2 in table.DT.Rows)
                {
                    this.labelProses1.Text = table.DT.Rows.Count.ToString();
                    this.labelProses1.Refresh();
                    this.labelProses2.Text = row2["ref"].ToString();
                    this.labelProses2.Refresh();
                    num3 = 0;
                    if (row2["wx"].ToString() == "2X")
                    {
                        num4 = 2;
                        chArray = new char[num4];
                        int num7 = 0;
                        if (row2["transWarning"].ToString().Length > 2)
                        {
                            foreach (char ch in row2["transWarning"].ToString().Substring(0, 2))
                            {
                                chArray[num7] = ch;
                                num7++;
                            }
                        }
                        else
                        {
                            foreach (char ch2 in row2["transWarning"].ToString())
                            {
                                chArray[num7] = ch2;
                                num7++;
                            }
                        }
                    }
                    if (row2["wx"].ToString() == "4X")
                    {
                        num4 = 4;
                        chArray = new char[num4];
                        int num10 = 0;
                        foreach (char ch3 in row2["transWarning"].ToString())
                        {
                            chArray[num10] = ch3;
                            num10++;
                        }
                    }
                    builder.Append("<tr class=bd>");
                    builder.Append("<td align='right' rowspan=Rspan valign='top'>" + num2 + "</td>");
                    builder.Append("<td rowspan=Rspan valign='top'>" + row2["ref"].ToString() + "</td>");
                    builder.Append("<td rowspan=Rspan valign='top'>" + row2["truck_number"].ToString() + "</td>");
                    builder.Append("<td align='right' rowspan=Rspan valign='top'>" + row2["gross"].ToString() + "</td>");
                    builder.Append("<td align='right' rowspan=Rspan valign='top'>" + row2["tare"].ToString() + "</td>");
                    builder.Append("<td align='right' rowspan=Rspan valign='top'>" + row2["received"].ToString() + "</td>");
                    builder.Append("<td align='right' rowspan=Rspan valign='top'>" + row2["net"].ToString() + "</td>");
                    bool flag8 = true;
                    int index = 0;
                    while (true)
                    {
                        if (index >= num4)
                        {
                            builder.Replace("Rspan", num3);
                            num2++;
                            break;
                        }
                        string str6 = "";
                        if (index == 0)
                        {
                            str6 = "1ST";
                        }
                        else if (index == 1)
                        {
                            str6 = "2ND";
                        }
                        else if (index == 2)
                        {
                            str6 = "3RD";
                        }
                        else if (index == 3)
                        {
                            str6 = "4TH";
                        }
                        if ((chArray[index].ToString() != "\0") && (chArray[index].ToString() != "0"))
                        {
                            num3++;
                            if (!flag8)
                            {
                                builder.Append("<tr class=bd>");
                            }
                            builder.Append("<td align='center'>" + str6 + "</td>");
                            builder.Append("<td>" + row2["date" + (index + 1)].ToString().Substring(0, 10) + "</td>");
                            builder.Append("<td>" + row2["time" + (index + 1)].ToString() + "</td>");
                            builder.Append("<td align='center'>" + row2["wbcode" + (index + 1)].ToString() + "</td>");
                            WBTable table6 = new WBTable();
                            table6.OpenTable("wb_setting", "SELECT * FROM wb_setting WHERE " + WBData.CompanyLocation(" AND wbcode = '" + row2["wbcode" + (index + 1)].ToString() + "'"), WBData.conn);
                            if (table6.DT.Rows.Count > 0)
                            {
                                builder.Append("<td align='center'>" + table6.DT.Rows[0]["CompName"].ToString() + "</td>");
                            }
                            else
                            {
                                builder.Append("<td>&nbsp;</td>");
                            }
                            table6.Dispose();
                            if (chArray[index].ToString() == "1")
                            {
                                builder.Append("<td align=center><font color=black>1</font></td>");
                            }
                            else if (chArray[index].ToString() == "2")
                            {
                                builder.Append("<td align=center><font color=red>2</font></td>");
                            }
                            builder.Append("</tr>");
                            flag8 = false;
                        }
                        index++;
                    }
                }
                html.Write(builder.ToString());
                html.Write("</table>");
                int num5 = 0;
                WBTable table5 = this.getQuery(byDate, dateFrom, dateTo, refNo, coy, loc, true);
                num2 = 1;
                num3 = 0;
                num4 = 0;
                chArray = null;
                string str2 = "";
                foreach (DataRow row3 in table5.DT.Rows)
                {
                    bool flag22 = (num2 % 3) == 1;
                    str2 = !flag22 ? (((num2 % 3) != 2) ? "..." : ".. ") : ".  ";
                    this.labelProses2.Text = "Gathering summary" + str2;
                    this.labelProses2.Refresh();
                    num3 = 0;
                    if (row3["wx"].ToString() == "2X")
                    {
                        num5 += 2;
                        num4 = 2;
                        chArray = new char[num4];
                        int num13 = 0;
                        if (row3["transWarning"].ToString().Length > 2)
                        {
                            foreach (char ch4 in row3["transWarning"].ToString().Substring(0, 2))
                            {
                                if (num13 < num4)
                                {
                                    chArray[num13] = ch4;
                                    num13++;
                                }
                            }
                        }
                        else
                        {
                            foreach (char ch5 in row3["transWarning"].ToString())
                            {
                                if (num13 < num4)
                                {
                                    chArray[num13] = ch5;
                                    num13++;
                                }
                            }
                        }
                    }
                    if (row3["wx"].ToString() == "4X")
                    {
                        num5 += 4;
                        num4 = 4;
                        chArray = new char[num4];
                        int num16 = 0;
                        foreach (char ch6 in row3["transWarning"].ToString())
                        {
                            if (num16 < num4)
                            {
                                chArray[num16] = ch6;
                                num16++;
                            }
                        }
                    }
                    int index = 0;
                    while (true)
                    {
                        if (index >= num4)
                        {
                            num2++;
                            break;
                        }
                        if (chArray[index].ToString() == "1")
                        {
                            int num19 = 0;
                            while (true)
                            {
                                if (num19 < strArray.GetLength(0))
                                {
                                    if (strArray[num19, 0] != row3["wbcode" + (index + 1)].ToString())
                                    {
                                        num19++;
                                        continue;
                                    }
                                    strArray[num19, 1] = (Program.StrToDouble(strArray[num19, 1], 0) + 1.0).ToString();
                                    strArray[num19, 3] = (Program.StrToDouble(strArray[num19, 3], 0) + 1.0).ToString();
                                }
                                break;
                            }
                        }
                        else if (chArray[index].ToString() != "2")
                        {
                            int num22 = 0;
                            while (true)
                            {
                                if (num22 < strArray.GetLength(0))
                                {
                                    if (strArray[num22, 0] != row3["wbcode" + (index + 1)].ToString())
                                    {
                                        num22++;
                                        continue;
                                    }
                                    strArray[num22, 3] = (Program.StrToDouble(strArray[num22, 3], 0) + 1.0).ToString();
                                }
                                break;
                            }
                        }
                        else
                        {
                            int num21 = 0;
                            while (true)
                            {
                                if (num21 < strArray.GetLength(0))
                                {
                                    if (strArray[num21, 0] != row3["wbcode" + (index + 1)].ToString())
                                    {
                                        num21++;
                                        continue;
                                    }
                                    strArray[num21, 2] = (Program.StrToDouble(strArray[num21, 2], 0) + 1.0).ToString();
                                    strArray[num21, 3] = (Program.StrToDouble(strArray[num21, 3], 0) + 1.0).ToString();
                                }
                                break;
                            }
                        }
                        index++;
                    }
                }
                html.Write("<br><br><font size=3><b>Summary of Indicator Stability</b></font><br>");
                html.Write("<table cellpadding=3 cellspacing=-1>");
                html.Write("<tr class=bd>");
                html.Write("<td>Total of all transaction</td>");
                html.Write("<td>: " + table5.DT.Rows.Count + " transaction</td>");
                html.Write("</tr>");
                html.Write("<tr class=bd>");
                html.Write("<td>Total of all weighing</td>");
                html.Write("<td>: " + num5 + " weighing</td>");
                html.Write("</tr>");
                html.Write("<tr class=bd><td>&nbsp;</td></tr>");
                int num23 = 0;
                while (true)
                {
                    if (num23 >= strArray.GetLength(0))
                    {
                        html.Write("</table>");
                        html.Write("<br><br><font size=3><b>Legend of Warning Level</b></font><br>");
                        html.Write("<table cellpadding=3 cellspacing=-1>");
                        html.Write("<tr class=bd>");
                        html.Write("<td>1</td>");
                        html.Write("<td>: Not Stable</td>");
                        html.Write("</tr>");
                        html.Write("</table>");
                        html.Write("<br>");
                        html.Write("<br>");
                        html.writeSign();
                        html.Close();
                        html2 = html;
                        break;
                    }
                    if (Program.StrToDouble(strArray[num23, 3].ToString(), 0) > 0.0)
                    {
                        WBTable table7 = new WBTable();
                        table7.OpenTable("wb_setting", "SELECT * FROM wb_setting WHERE " + WBData.CompanyLocation(" AND wbcode = '" + strArray[num23, 0].ToString() + "'"), WBData.conn);
                        html.Write("<tr class=bd>");
                        string[] textArray7 = new string[] { "<td><u>", strArray[num23, 0].ToString(), " (", table7.DT.Rows[0]["compname"].ToString(), ")</u></td>" };
                        html.Write(string.Concat(textArray7));
                        html.Write("</tr>");
                        html.Write("<tr class=bd>");
                        html.Write("<td>Total of weighing</td>");
                        html.Write("<td>: " + strArray[num23, 3].ToString() + " weighing</td>");
                        html.Write("</tr>");
                        html.Write("<tr class=bd>");
                        html.Write("<td>Stable weighing</td>");
                        html.Write("<td>: " + ((Program.StrToDouble(strArray[num23, 3].ToString(), 0) - Program.StrToDouble(strArray[num23, 2].ToString(), 0)) - Program.StrToDouble(strArray[num23, 1].ToString(), 0)).ToString() + " weighing</td>");
                        html.Write("</tr>");
                        html.Write("<tr class=bd>");
                        html.Write("<td>Weighing with warning level 1 (NOT STABLE)</td>");
                        html.Write("<td>: " + strArray[num23, 1].ToString() + " weighing</td>");
                        html.Write("</tr>");
                        html.Write("<tr class=bd><td>&nbsp;</td></tr>");
                        table7.Dispose();
                    }
                    num23++;
                }
            }
            return html2;
        }

        private WBTable getQuery(bool byDate, DateTime dateFrom, DateTime dateTo, string refNo, string coy, string loc, bool stable)
        {
            WBTable table = new WBTable();
            string sqltext = "";
            sqltext = (("SELECT * FROM wb_transaction " + " WHERE Coy = '" + coy + "' ") + " AND Location_Code = '" + loc + "' ") + " AND (report_date is not null OR report_date != '') ";
            if (!byDate)
            {
                sqltext = sqltext + " AND ref = '" + refNo + "'";
            }
            else
            {
                string[] textArray1 = new string[] { sqltext, " AND report_date >= '", dateFrom.ToString("yyyy-MM-dd"), "' AND report_date <= '", dateTo.ToString("yyyy-MM-dd"), "'" };
                sqltext = string.Concat(textArray1);
            }
            if (!stable)
            {
                sqltext = sqltext + " AND (transWarning LIKE '%1%' OR transWarning LIKE '%2%') ";
            }
            sqltext = sqltext + " ORDER BY ref ASC";
            table.OpenTable("wb_transaction", sqltext, WBData.conn);
            return table;
        }

        private void InitializeComponent()
        {
            this.label3 = new Label();
            this.groupBox1 = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label5 = new Label();
            this.label6 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.checkDate = new CheckBox();
            this.textRef = new TextBox();
            this.labelcommodity = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.labelProses2 = new Label();
            this.labelProses1 = new Label();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(0x10, 0x10);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0xd1, 20);
            this.label3.TabIndex = 0x58;
            this.label3.Text = "Indicator Stability Report";
            this.label3.TextAlign = ContentAlignment.TopCenter;
            this.groupBox1.Controls.Add(this.monthCalendar1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.monthCalendar2);
            this.groupBox1.Location = new Point(20, 0x4b);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x182, 0x33);
            this.groupBox1.TabIndex = 0x59;
            this.groupBox1.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(80, 0x12);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(8, 0x15);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x3e, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "From Date :";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xc6, 0x15);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x34, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x100, 0x12);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.checkDate.AutoSize = true;
            this.checkDate.Checked = true;
            this.checkDate.CheckState = CheckState.Checked;
            this.checkDate.Location = new Point(20, 0x3d);
            this.checkDate.Name = "checkDate";
            this.checkDate.Size = new Size(0x40, 0x11);
            this.checkDate.TabIndex = 90;
            this.checkDate.Text = "By Date";
            this.checkDate.UseVisualStyleBackColor = true;
            this.checkDate.CheckedChanged += new EventHandler(this.checkDate_CheckedChanged);
            this.textRef.CharacterCasing = CharacterCasing.Upper;
            this.textRef.Enabled = false;
            this.textRef.Location = new Point(0x67, 0x92);
            this.textRef.Name = "textRef";
            this.textRef.Size = new Size(0x8b, 20);
            this.textRef.TabIndex = 0x5b;
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x11, 0x95);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(80, 13);
            this.labelcommodity.TabIndex = 0x5c;
            this.labelcommodity.Text = "Reference No :";
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x123, 0xbc);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x22);
            this.button2.TabIndex = 0x5e;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0xaf, 0xbc);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x22);
            this.button1.TabIndex = 0x5d;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0xfd, 0x1d);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0x9d, 13);
            this.labelProses2.TabIndex = 0x5f;
            this.labelProses2.Text = "Progress. . . . . . . . . . ";
            this.labelProses2.TextAlign = ContentAlignment.MiddleRight;
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(260, 0x10);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0x92, 13);
            this.labelProses1.TabIndex = 0x60;
            this.labelProses1.Text = "1/88888";
            this.labelProses1.TextAlign = ContentAlignment.MiddleRight;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1ac, 0x101);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textRef);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.checkDate);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.label3);
            base.Name = "RepIndicator";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Indicator Stability Report";
            base.Load += new EventHandler(this.RepIndicator_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void RepIndicator_Load(object sender, EventArgs e)
        {
        }
    }
}

