﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Properties;

    public class FormTransactionContainerOut : Form
    {
        private int idxFindOut = 0;
        private int nCurrRow;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public string sUniq = "";
        public WBTable ztableOut = new WBTable();
        public WBTable ztableIn = new WBTable();
        public DataRow ReturnRow;
        private IContainer components = null;
        private DataGridView dgvTransContainerOut;
        private CheckBox checkLinkedOut;
        private CheckBox checkDeletedOut;
        private DateTimePicker dateTimePickerOut2;
        private DateTimePicker dateTimePickerOut1;
        private Label label3;
        private Label label4;
        private Button buttonFilterOut;
        private GroupBox panelDate;
        private Button buttonFindOut;
        private TextBox textFindOut;
        private DataGridView dgvTransContainerIn;
        private Label label7;
        private Label label1;
        private GroupBox gbContOut;
        private GroupBox gbContIn;
        private Button buttonCancelOut;
        private Button buttonViewOut;
        private Button buttonFilterIn;
        private Label label2;
        private Button buttonLink;
        private Label label8;
        private TextBox textContainerIn;
        private TextBox textPIIn;
        private Label label6;
        private TextBox textDOIn;
        private Label label5;
        private Button buttonUnfilterIn;
        public Button buttonDO;
        private Button buttonUnlink;
        private Button buttonEntryLoadQty;
        private Button buttonViewLinked;
        private GroupBox groupBox1;
        private Button buttonRefresh;

        public FormTransactionContainerOut()
        {
            this.InitializeComponent();
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.viewForLinked();
            this.setDGVOut((this.dgvTransContainerOut.Rows.Count > 0) ? this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() : "");
            this.setDGVIn("");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MN_LOADING_ENTRY", "A"))
            {
                MessageBox.Show(Resource.ContainerOut_031, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_transaction", "SELECT linked FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref = '" + this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() + "' "), WBData.conn);
                string str = table.DT.Rows[0]["linked"].ToString();
                table.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref = '" + str + "' "), WBData.conn);
                table.DR = table.DT.Rows[0];
                WBTable table2 = new WBTable();
                WBTable table3 = new WBTable();
                WBCondition condition = new WBCondition();
                table2.OpenTable("wb_checkComm", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + table.DR["comm_code"].ToString() + "'"), WBData.conn);
                table3.OpenTable("wb_checkTransType", "Select * from Wb_transaction_Type where " + WBData.CompanyLocation(" and transaction_code = '" + table.DR["transaction_code"].ToString() + "'"), WBData.conn);
                if (table2.DT.Rows.Count <= 0)
                {
                    MessageBox.Show("Commodity is not found! Please check commodity master data!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    table2.DR = table2.DT.Rows[0];
                    table3.DR = table3.DT.Rows[0];
                    DataRow[] dgRows = new DataRow[] { table2.DR, table3.DR };
                    condition.fillParameter("TRANS_LOADING_QTY", dgRows);
                    if (!(condition.getResult() && (table2.DR["Unit"].ToString().ToUpper() != "KG")))
                    {
                        MessageBox.Show("Loading Qty is for STANDARD PACK commodity only!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        table.RLock(table.DR["uniq"].ToString(), true);
                        FormLoadingInfo info = new FormLoadingInfo {
                            txtRefNo = { Text = table.DR["ref"].ToString() },
                            textRef_Date = { Text = Convert.ToDateTime(table.DR["ref_date"].ToString()).ToShortDateString() },
                            oldComm = table.DR["comm_code"].ToString()
                        };
                        info.ShowDialog();
                        info.Dispose();
                        table.RLock(table.DR["uniq"].ToString(), false);
                        table2.Dispose();
                        condition.Dispose();
                        table.Dispose();
                        this.setDGVOut((this.dgvTransContainerOut.Rows.Count > 0) ? this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() : "");
                        this.setDGVIn("");
                    }
                }
            }
        }

        private void buttonCancelOut_Click(object sender, EventArgs e)
        {
            if (this.dgvTransContainerOut.CurrentRow.Cells["linked"].Value.ToString() != "")
            {
                MessageBox.Show(Resource.ContainerOut_035, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else if (this.dgvTransContainerOut.CurrentRow.Cells["deleted"].Value.ToString() == "Y")
            {
                MessageBox.Show(Resource.ContainerOut_036, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else if (MessageBox.Show(Resource.ContainerOut_037 + " " + this.dgvTransContainerOut.CurrentRow.Cells["Ref"].Value.ToString() + "? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                string str = "";
                int recNo = 0;
                str = this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString();
                string[] aField = new string[] { "Uniq" };
                string[] aFind = new string[] { this.dgvTransContainerOut.CurrentRow.Cells["Uniq"].Value.ToString() };
                recNo = this.ztableOut.GetRecNo(aField, aFind);
                WBTable table = new WBTable();
                table.OpenTable("wb_transaction", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() + "'"), WBData.conn);
                if ((this.dgvTransContainerOut.Rows.Count > 0) && (table.DT.Rows[0]["Deleted"].ToString() != "Y"))
                {
                    string str3 = "";
                    string reason = "";
                    string str5 = "Y";
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_cancel_type", "Select * from wb_cancel_type where cancel_type = 'C'", WBData.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        str5 = (table2.DT.Rows[0]["require_token"].ToString() == "Y") ? "Y" : "N";
                    }
                    if (WBSetting.Field("GM") != "Y")
                    {
                        FormMessageEntry entry3 = new FormMessageEntry {
                            lblHeader = { Text = "Cancel Transaction" },
                            lblDetail = { Text = "Reason for Cancel Transaction" }
                        };
                        entry3.ShowDialog();
                        reason = entry3.reason;
                        if (reason != "")
                        {
                            this.update_all(reason, str3);
                        }
                    }
                    else
                    {
                        if (str5 != "Y")
                        {
                            FormMessageEntry entry2 = new FormMessageEntry {
                                lblHeader = { Text = "Cancel Transaction" },
                                lblDetail = { Text = "Reason for Cancel Transaction" }
                            };
                            entry2.ShowDialog();
                            reason = entry2.reason;
                        }
                        else if (!table.BeforeEdit(this.dgvTransContainerOut, "CANCEL"))
                        {
                            str3 = "Y";
                        }
                        else
                        {
                            FormMessageEntry entry = new FormMessageEntry {
                                lblHeader = { Text = "Cancel Transaction" },
                                lblDetail = { Text = "Reason for Cancel Transaction" }
                            };
                            entry.ShowDialog();
                            reason = entry.reason;
                        }
                        this.update_all(reason, str3);
                    }
                }
            }
        }

        private void buttonDO_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE"
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDOIn.Text = contract.ReturnRow["DO_No"].ToString();
            }
            contract.Dispose();
        }

        private void buttonFilter_Click(object sender, EventArgs e)
        {
            this.setDGVOut("");
        }

        private void buttonFilterIn_Click(object sender, EventArgs e)
        {
            if (((this.textDOIn.Text.Trim() != "") || (this.textPIIn.Text.Trim() != "")) || (this.textContainerIn.Text.Trim() != ""))
            {
                string sqltext = "SELECT * FROM vw_Container WHERE " + WBData.CompanyLocation(" ");
                if (this.textDOIn.Text.Trim() != "")
                {
                    sqltext = sqltext + " AND Do_No = '" + this.textDOIn.Text.Trim() + "' ";
                }
                if (this.textPIIn.Text.Trim() != "")
                {
                    sqltext = sqltext + " AND PI_No = '" + this.textPIIn.Text.Trim() + "' ";
                }
                if (this.textContainerIn.Text.Trim() != "")
                {
                    sqltext = sqltext + " AND Container like '%" + this.textContainerIn.Text.Trim() + "%'";
                }
                sqltext = ((sqltext + " AND (Deleted IS NULL OR Deleted = '' OR Deleted = 'N') ") + " AND (mark_return = '' OR mark_return IS null OR mark_return = 'N')" + " AND (linked IS NULL OR linked = '') ") + " AND (wx = '4X') " + " AND (_3rd = '' OR _3rd = '0') ";
                this.ztableIn.OpenTable("vw_Container", sqltext, WBData.conn);
                this.dgvTransContainerIn.DataSource = this.ztableIn.DT;
                this.dgvTransContainerInFormat();
                Program.AutoComp(this.ztableIn, "DO_No", this.textDOIn);
                Program.AutoComp(this.ztableIn, "PI_No", this.textPIIn);
                Program.AutoComp(this.ztableIn, "Container", this.textContainerIn);
                if (this.ztableIn.DT.Rows.Count <= 0)
                {
                    MessageBox.Show(Resource.ContainerOut_034, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFindOut = this.ztableOut.NextFindSqlForDoubleData(this.dgvTransContainerOut, this.textFindOut.Text, this.idxFindOut);
        }

        private void buttonLink_Click(object sender, EventArgs e)
        {
            if ((this.dgvTransContainerOut.RowCount > 0) && (this.dgvTransContainerIn.RowCount > 0))
            {
                if (WBUser.CheckTrustee("MN_LOADING_ENTRY", "A"))
                {
                    WBTable table = new WBTable();
                    WBTable table2 = new WBTable();
                    string[] textArray1 = new string[] { " SELECT t.ref, t.linked, t.deleted, g.source_code FROM wb_transaction t LEFT OUTER JOIN wb_gatepass_destination g  ON t.gatepass_number = g.gatepass_number  AND t.coy = g.coy AND t.location_code = g.location_code  WHERE t.coy = '", WBData.sCoyCode, "' AND t.location_code = '", WBData.sLocCode, "'  AND t.ref = '", this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString(), "'" };
                    table.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
                    string[] textArray2 = new string[] { " SELECT t.ref, t.linked, t.deleted, g.source_code FROM wb_transaction t LEFT OUTER JOIN wb_gatepass_destination g  ON t.gatepass_number = g.gatepass_number  AND t.coy = g.coy AND t.location_code = g.location_code  WHERE t.coy = '", WBData.sCoyCode, "' AND t.location_code = '", WBData.sLocCode, "'  AND t.ref = '", this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString(), "'" };
                    table2.OpenTable("wb_transaction", string.Concat(textArray2), WBData.conn);
                    bool flag = false;
                    foreach (DataRow row in table.DT.Rows)
                    {
                        foreach (DataRow row2 in table2.DT.Rows)
                        {
                            if ((row["source_code"].ToString() == row2["source_code"].ToString()) || (row2["source_code"].ToString() == ""))
                            {
                                flag = true;
                                break;
                            }
                        }
                        if (flag)
                        {
                            break;
                        }
                    }
                    if (flag)
                    {
                        table.DR = table.DT.Rows[0];
                        table2.DR = table2.DT.Rows[0];
                        if (table.DR["linked"].ToString() == "")
                        {
                            if (table.DR["linked"].ToString() != "")
                            {
                                if (table.DR["deleted"].ToString() != "Y")
                                {
                                    if (table2.DR["linked"].ToString() == "")
                                    {
                                        if (table2.DR["deleted"].ToString() == "Y")
                                        {
                                            string[] textArray8 = new string[] { Resource.ContainerOut_008, " ", this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString(), " ", Resource.ContainerOut_033 };
                                            MessageBox.Show(string.Concat(textArray8), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                            this.setDGVOut((this.dgvTransContainerOut.Rows.Count > 0) ? this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() : "");
                                            this.setDGVIn((this.dgvTransContainerIn.Rows.Count > 0) ? this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() : "");
                                            table2.Dispose();
                                            table.Dispose();
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        string[] textArray7 = new string[] { Resource.ContainerOut_008, " ", this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString(), " ", Resource.ContainerOut_032 };
                                        MessageBox.Show(string.Concat(textArray7), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        this.setDGVOut((this.dgvTransContainerOut.Rows.Count > 0) ? this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() : "");
                                        this.setDGVIn((this.dgvTransContainerIn.Rows.Count > 0) ? this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() : "");
                                        table2.Dispose();
                                        table.Dispose();
                                        return;
                                    }
                                }
                                else
                                {
                                    string[] textArray6 = new string[] { Resource.ContainerOut_008, " ", this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString(), " ", Resource.ContainerOut_033 };
                                    MessageBox.Show(string.Concat(textArray6), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    this.setDGVOut((this.dgvTransContainerOut.Rows.Count > 0) ? this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() : "");
                                    this.setDGVIn((this.dgvTransContainerIn.Rows.Count > 0) ? this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() : "");
                                    table2.Dispose();
                                    table.Dispose();
                                    return;
                                }
                            }
                            else
                            {
                                WBTable table4 = new WBTable();
                                string[] textArray4 = new string[] { " SELECT ref, _4th, uniq FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND linked = '", table.DR["ref"].ToString(), "'" };
                                table4.OpenTable("wb_transaction", string.Concat(textArray4), WBData.conn);
                                if (table4.DT.Rows.Count <= 0)
                                {
                                    table4.Dispose();
                                }
                                else
                                {
                                    string[] textArray5 = new string[] { Resource.ContainerOut_008, " ", table.DR["ref"].ToString(), " ", Resource.ContainerOut_038 };
                                    MessageBox.Show(string.Concat(textArray5), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    this.setDGVOut((this.dgvTransContainerOut.Rows.Count > 0) ? this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() : "");
                                    this.setDGVIn((this.dgvTransContainerIn.Rows.Count > 0) ? this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() : "");
                                    table2.Dispose();
                                    table.Dispose();
                                    table4.Dispose();
                                    return;
                                }
                            }
                            string str = "";
                            string str2 = "";
                            int num = 0;
                            WBTable table3 = new WBTable();
                            table3.OpenTable("wb_transContainer", "SELECT * FROM wb_transcontainer WHERE " + WBData.CompanyLocation(" AND ref = '" + this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() + "'"), WBData.conn);
                            foreach (DataRow row3 in table3.DT.Rows)
                            {
                                if (table3.DT.Rows.Count == 1)
                                {
                                    str = str + row3["container"].ToString();
                                    str2 = str2 + row3["seal"].ToString();
                                }
                                else if (num < (table3.DT.Rows.Count - 1))
                                {
                                    str = str + row3["container"].ToString() + ", ";
                                    str2 = str2 + row3["seal"].ToString() + ", ";
                                }
                                else
                                {
                                    str = str + row3["container"].ToString();
                                    str2 = str2 + row3["seal"].ToString();
                                }
                                num++;
                            }
                            table3.Dispose();
                            if ((str2.Trim() == "") || (str2.Trim() == ","))
                            {
                                str2 = "-";
                            }
                            string[] textArray9 = new string[0x1b];
                            textArray9[0] = Resource.ContainerOut_001;
                            textArray9[1] = " ";
                            textArray9[2] = this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString();
                            textArray9[3] = " ";
                            textArray9[4] = Resource.ContainerOut_002;
                            textArray9[5] = "\n";
                            textArray9[6] = Resource.ContainerOut_003;
                            textArray9[7] = " ";
                            textArray9[8] = this.dgvTransContainerOut.CurrentRow.Cells["RegCard_No"].Value.ToString();
                            textArray9[9] = "\n";
                            textArray9[10] = Resource.ContainerOut_004;
                            textArray9[11] = " ";
                            textArray9[12] = this.dgvTransContainerOut.CurrentRow.Cells["Truck_Number"].Value.ToString();
                            textArray9[13] = "\n\n";
                            textArray9[14] = Resource.ContainerOut_005;
                            textArray9[15] = " ";
                            textArray9[0x10] = this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString();
                            textArray9[0x11] = " ";
                            textArray9[0x12] = Resource.ContainerOut_002;
                            textArray9[0x13] = "\n";
                            textArray9[20] = Resource.ContainerOut_006;
                            textArray9[0x15] = " ";
                            textArray9[0x16] = str;
                            textArray9[0x17] = "\n";
                            textArray9[0x18] = Resource.ContainerOut_007;
                            textArray9[0x19] = " ";
                            textArray9[0x1a] = str2;
                            if (MessageBox.Show(string.Concat(textArray9), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.linkRef(true);
                                string[] textArray10 = new string[30];
                                textArray10[0] = Resource.ContainerOut_008;
                                textArray10[1] = " ";
                                textArray10[2] = this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString();
                                textArray10[3] = " ";
                                textArray10[4] = Resource.ContainerOut_002;
                                textArray10[5] = "\n";
                                textArray10[6] = Resource.ContainerOut_003;
                                textArray10[7] = " ";
                                textArray10[8] = this.dgvTransContainerOut.CurrentRow.Cells["RegCard_No"].Value.ToString();
                                textArray10[9] = "\n";
                                textArray10[10] = Resource.ContainerOut_004;
                                textArray10[11] = " ";
                                textArray10[12] = this.dgvTransContainerOut.CurrentRow.Cells["Truck_Number"].Value.ToString();
                                textArray10[13] = "\n\n";
                                textArray10[14] = Resource.ContainerOut_009;
                                textArray10[15] = " ";
                                textArray10[0x10] = this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString();
                                textArray10[0x11] = " ";
                                textArray10[0x12] = Resource.ContainerOut_002;
                                textArray10[0x13] = "\n";
                                textArray10[20] = Resource.ContainerOut_006;
                                textArray10[0x15] = " ";
                                textArray10[0x16] = str;
                                textArray10[0x17] = "\n";
                                textArray10[0x18] = Resource.ContainerOut_007;
                                textArray10[0x19] = " ";
                                textArray10[0x1a] = str2;
                                textArray10[0x1b] = "\n\n";
                                textArray10[0x1c] = Resource.ContainerOut_010;
                                textArray10[0x1d] = "!";
                                MessageBox.Show(string.Concat(textArray10), "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                WBTable table5 = new WBTable();
                                WBTable table6 = new WBTable();
                                WBCondition condition = new WBCondition();
                                table5.OpenTable("wb_checkComm", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.dgvTransContainerIn.CurrentRow.Cells["comm_code"].Value.ToString() + "'"), WBData.conn);
                                table6.OpenTable("wb_checkTransType", "Select * from Wb_transaction_Type where " + WBData.CompanyLocation(" and transaction_code = '" + this.dgvTransContainerIn.CurrentRow.Cells["transaction_code"].Value.ToString() + "'"), WBData.conn);
                                if ((table5.DT.Rows.Count > 0) && (table6.DT.Rows.Count > 0))
                                {
                                    table5.DR = table5.DT.Rows[0];
                                    table6.DR = table6.DT.Rows[0];
                                    DataRow[] dgRows = new DataRow[] { table5.DR, table6.DR };
                                    condition.fillParameter("TRANS_LOADING_QTY", dgRows);
                                    if (condition.getResult() && (table5.DR["Unit"].ToString().ToUpper() != "KG"))
                                    {
                                        WBTable table7 = new WBTable();
                                        table7.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref = '" + this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() + "'"), WBData.conn);
                                        table7.RLock(this.dgvTransContainerIn.CurrentRow.Cells["uniq"].Value.ToString(), true);
                                        FormLoadingInfo info = new FormLoadingInfo {
                                            txtRefNo = { Text = this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() },
                                            textRef_Date = { Text = Convert.ToDateTime(this.dgvTransContainerIn.CurrentRow.Cells["ref_date"].Value.ToString()).ToShortDateString() },
                                            oldComm = this.dgvTransContainerIn.CurrentRow.Cells["comm_code"].Value.ToString()
                                        };
                                        info.ShowDialog();
                                        info.Dispose();
                                        table7.RLock(this.dgvTransContainerIn.CurrentRow.Cells["uniq"].Value.ToString(), false);
                                        table7.Dispose();
                                    }
                                }
                                table5.Dispose();
                                table6.Dispose();
                                condition.Dispose();
                            }
                            this.setDGVOut((this.dgvTransContainerOut.Rows.Count > 0) ? this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() : "");
                            this.setDGVIn((this.dgvTransContainerIn.Rows.Count > 0) ? this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() : "");
                            table2.Dispose();
                            table.Dispose();
                        }
                        else
                        {
                            string[] textArray3 = new string[] { Resource.ContainerOut_008, " ", this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString(), " ", Resource.ContainerOut_032 };
                            MessageBox.Show(string.Concat(textArray3), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            this.setDGVOut((this.dgvTransContainerOut.Rows.Count > 0) ? this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() : "");
                            this.setDGVIn((this.dgvTransContainerIn.Rows.Count > 0) ? this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() : "");
                            table2.Dispose();
                            table.Dispose();
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.ContainerOut_042, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.setDGVOut((this.dgvTransContainerOut.Rows.Count > 0) ? this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() : "");
                        this.setDGVIn((this.dgvTransContainerIn.Rows.Count > 0) ? this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() : "");
                        table2.Dispose();
                        table.Dispose();
                    }
                }
                else
                {
                    MessageBox.Show(Resource.ContainerOut_031, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.setDGVOut("");
            this.setDGVIn("");
            Cursor.Current = Cursors.Default;
        }

        private void buttonUnfilterIn_Click(object sender, EventArgs e)
        {
            this.setDGVIn("");
        }

        private void buttonUnlink_Click(object sender, EventArgs e)
        {
            if (this.dgvTransContainerOut.RowCount > 0)
            {
                if (WBUser.CheckTrustee("MN_LOADING_ENTRY", "A"))
                {
                    WBTable table = new WBTable();
                    WBTable table2 = new WBTable();
                    string[] textArray1 = new string[] { " SELECT ref, linked FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND ref = '", this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString(), "'" };
                    table.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
                    table.DR = table.DT.Rows[0];
                    string[] textArray2 = new string[] { " SELECT ref, _4th, uniq FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND linked = '", table.DR["ref"].ToString(), "'" };
                    table2.OpenTable("wb_transaction", string.Concat(textArray2), WBData.conn);
                    if (table.DR["linked"].ToString() != "")
                    {
                        if ((table2.DT.Rows[0]["_4th"].ToString() != "0") && (table2.DT.Rows[0]["_4th"].ToString() != ""))
                        {
                            string[] textArray4 = new string[9];
                            textArray4[0] = Resource.ContainerOut_039;
                            textArray4[1] = " ";
                            textArray4[2] = table.DR["ref"].ToString();
                            textArray4[3] = " ";
                            textArray4[4] = Resource.ContainerOut_018;
                            textArray4[5] = " ";
                            textArray4[6] = table2.DT.Rows[0]["ref"].ToString();
                            textArray4[7] = " ";
                            textArray4[8] = Resource.ContainerOut_040;
                            MessageBox.Show(string.Concat(textArray4), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            this.setDGVOut((this.dgvTransContainerOut.Rows.Count > 0) ? this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() : "");
                            this.setDGVIn((this.dgvTransContainerIn.Rows.Count > 0) ? this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() : "");
                            table2.Dispose();
                            table.Dispose();
                            return;
                        }
                    }
                    else if (table2.DT.Rows.Count <= 0)
                    {
                        string[] textArray3 = new string[] { Resource.ContainerOut_008, " ", table.DR["ref"].ToString(), " ", Resource.ContainerOut_038 };
                        MessageBox.Show(string.Concat(textArray3), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.setDGVOut((this.dgvTransContainerOut.Rows.Count > 0) ? this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() : "");
                        this.setDGVIn((this.dgvTransContainerIn.Rows.Count > 0) ? this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() : "");
                        table2.Dispose();
                        table.Dispose();
                        return;
                    }
                    string str = "";
                    string str2 = "";
                    int num = 0;
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_transContainer", "SELECT * FROM wb_transcontainer WHERE " + WBData.CompanyLocation(" AND ref = '" + table2.DT.Rows[0]["ref"].ToString() + "'"), WBData.conn);
                    foreach (DataRow row in table3.DT.Rows)
                    {
                        if (table3.DT.Rows.Count == 1)
                        {
                            str = str + row["container"].ToString();
                            str2 = str2 + row["seal"].ToString();
                        }
                        else if (num < (table3.DT.Rows.Count - 1))
                        {
                            str = str + row["container"].ToString() + ", ";
                            str2 = str2 + row["seal"].ToString() + ", ";
                        }
                        else
                        {
                            str = str + row["container"].ToString();
                            str2 = str2 + row["seal"].ToString();
                        }
                        num++;
                    }
                    table3.Dispose();
                    if ((str2.Trim() == "") || (str2.Trim() == ","))
                    {
                        str2 = "-";
                    }
                    string[] textArray5 = new string[0x1d];
                    textArray5[0] = Resource.ContainerOut_011;
                    textArray5[1] = " ";
                    textArray5[2] = this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString();
                    textArray5[3] = " ";
                    textArray5[4] = Resource.ContainerOut_002;
                    textArray5[5] = "\n";
                    textArray5[6] = Resource.ContainerOut_003;
                    textArray5[7] = " ";
                    textArray5[8] = this.dgvTransContainerOut.CurrentRow.Cells["RegCard_No"].Value.ToString();
                    textArray5[9] = "\n";
                    textArray5[10] = Resource.ContainerOut_004;
                    textArray5[11] = " ";
                    textArray5[12] = this.dgvTransContainerOut.CurrentRow.Cells["Truck_Number"].Value.ToString();
                    textArray5[13] = "\n\n";
                    textArray5[14] = Resource.ContainerOut_005;
                    textArray5[15] = " ";
                    textArray5[0x10] = table2.DT.Rows[0]["ref"].ToString();
                    textArray5[0x11] = " ";
                    textArray5[0x12] = Resource.ContainerOut_002;
                    textArray5[0x13] = "\n";
                    textArray5[20] = Resource.ContainerOut_006;
                    textArray5[0x15] = " ";
                    textArray5[0x16] = str;
                    textArray5[0x17] = "\n";
                    textArray5[0x18] = Resource.ContainerOut_007;
                    textArray5[0x19] = " ";
                    textArray5[0x1a] = str2;
                    textArray5[0x1b] = "\n\n";
                    textArray5[0x1c] = Resource.ContainerOut_041;
                    if (MessageBox.Show(string.Concat(textArray5), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        this.linkRef(false);
                        WBTable table4 = new WBTable();
                        table4.OpenTable("wb_transaction", "SELECT * FROM wb_transDO WHERE " + WBData.CompanyLocation(" AND ref like '" + this.dgvTransContainerOut.CurrentRow.Cells["linked"].Value.ToString() + "%'"), WBData.conn);
                        foreach (DataRow row2 in table4.DT.Rows)
                        {
                            row2.BeginEdit();
                            row2["loading_qty"] = "0";
                            row2.EndEdit();
                        }
                        table4.Save();
                        table4.Dispose();
                        string[] textArray6 = new string[30];
                        textArray6[0] = Resource.ContainerOut_008;
                        textArray6[1] = " ";
                        textArray6[2] = this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString();
                        textArray6[3] = " ";
                        textArray6[4] = Resource.ContainerOut_002;
                        textArray6[5] = "\n";
                        textArray6[6] = Resource.ContainerOut_003;
                        textArray6[7] = " ";
                        textArray6[8] = this.dgvTransContainerOut.CurrentRow.Cells["RegCard_No"].Value.ToString();
                        textArray6[9] = "\n";
                        textArray6[10] = Resource.ContainerOut_004;
                        textArray6[11] = " ";
                        textArray6[12] = this.dgvTransContainerOut.CurrentRow.Cells["Truck_Number"].Value.ToString();
                        textArray6[13] = "\n\n";
                        textArray6[14] = Resource.ContainerOut_009;
                        textArray6[15] = " ";
                        textArray6[0x10] = table2.DT.Rows[0]["ref"].ToString();
                        textArray6[0x11] = " ";
                        textArray6[0x12] = Resource.ContainerOut_002;
                        textArray6[0x13] = "\n";
                        textArray6[20] = Resource.ContainerOut_006;
                        textArray6[0x15] = " ";
                        textArray6[0x16] = str;
                        textArray6[0x17] = "\n";
                        textArray6[0x18] = Resource.ContainerOut_007;
                        textArray6[0x19] = " ";
                        textArray6[0x1a] = str2;
                        textArray6[0x1b] = "\n\n";
                        textArray6[0x1c] = Resource.ContainerOut_012;
                        textArray6[0x1d] = "!";
                        MessageBox.Show(string.Concat(textArray6), "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    this.setDGVOut((this.dgvTransContainerOut.Rows.Count > 0) ? this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() : "");
                    this.setDGVIn((this.dgvTransContainerIn.Rows.Count > 0) ? this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() : "");
                    table2.Dispose();
                    table.Dispose();
                }
                else
                {
                    MessageBox.Show(Resource.ContainerOut_031, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        private void buttonViewOut_Click(object sender, EventArgs e)
        {
            this.viewForTemp();
        }

        private void checkDeleted_CheckedChanged_2(object sender, EventArgs e)
        {
            this.setDGVOut("");
        }

        private void checkLinked_CheckedChanged(object sender, EventArgs e)
        {
            this.setDGVOut("");
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dgvTransContainerOut.RowCount > 0)
            {
                if (this.dgvTransContainerOut.CurrentRow.Cells["linked"].Value.ToString() != "")
                {
                    MessageBox.Show(Resource.ContainerOut_027, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else if (this.dgvTransContainerOut.CurrentRow.Cells["deleted"].Value.ToString() == "Y")
                {
                    MessageBox.Show(Resource.ContainerOut_028, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    string[] aField = new string[] { "uniq" };
                    string[] aFind = new string[] { this.dgvTransContainerOut.CurrentRow.Cells["uniq"].Value.ToString() };
                    this.nCurrRow = this.ztableOut.GetRecNo(aField, aFind);
                    this.ReturnRow = this.ztableOut.DT.Rows[this.nCurrRow];
                    base.Close();
                }
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dgvSAPDest_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dgvTransContainerOut.Rows[e.RowIndex].Cells["deleted"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Red;
                e.CellStyle.SelectionBackColor = Color.Pink;
            }
            else if (this.dgvTransContainerOut.Rows[e.RowIndex].Cells["Linked"].Value.ToString() != "")
            {
                e.CellStyle.BackColor = Color.DarkTurquoise;
                e.CellStyle.SelectionBackColor = Color.PaleTurquoise;
                e.CellStyle.SelectionForeColor = Color.Gray;
            }
        }

        private void dgvTransContainerInFormat()
        {
            foreach (DataGridViewRow row in (IEnumerable) this.dgvTransContainerIn.Rows)
            {
                row.Cells["Description"].Value = row.Cells["Description"].Value.ToString().Replace("WAREHOUSE", "WH").Replace("TRADE", "TRD").Replace("TEXTURING", "TEXT");
            }
            this.dgvTransContainerIn.Sort(this.dgvTransContainerIn.Columns["Ref"], ListSortDirection.Ascending);
        }

        private void dgvTransContainerOut_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (this.dgvTransContainerOut.CurrentRow.Cells["linked"].Value.ToString() != "")
            {
                this.buttonViewLinked.Enabled = true;
                this.buttonEntryLoadQty.Enabled = true;
            }
            else
            {
                this.buttonViewLinked.Enabled = false;
                this.buttonEntryLoadQty.Enabled = false;
            }
        }

        private void dgvTransContainerOutFormat()
        {
            foreach (DataGridViewRow row in (IEnumerable) this.dgvTransContainerOut.Rows)
            {
                row.Cells["Description"].Value = row.Cells["Description"].Value.ToString().Replace("WAREHOUSE", "WH").Replace("TRADE", "TRD").Replace("TEXTURING", "TEXT");
            }
            this.dgvTransContainerOut.Sort(this.dgvTransContainerOut.Columns["Truck_Number"], ListSortDirection.Ascending);
            if (this.dgvTransContainerOut.RowCount > 0)
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.dgvTransContainerOut.CurrentRow.Cells["uniq"].Value.ToString() };
                this.ztableOut.SetCursor(this.dgvTransContainerOut, this.ztableOut.GetCurrentRow(this.dgvTransContainerOut, aField, aFind));
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransactionContainerOut_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTransactionContainerOut_Load(object sender, EventArgs e)
        {
            this.translate();
            string sqltext = "";
            if (this.checkDeletedOut.Checked)
            {
                string[] textArray1 = new string[] { "SELECT * FROM vw_containerout  WHERE coy = '", WBData.sCoyCode, "'  AND location_code = '", WBData.sLocCode, "' " };
                sqltext = string.Concat(textArray1);
            }
            else
            {
                string[] textArray2 = new string[] { "SELECT * FROM vw_containerout  WHERE coy = '", WBData.sCoyCode, "'  AND location_code = '", WBData.sLocCode, "'  AND (deleted IS NULL OR deleted != 'Y') " };
                sqltext = string.Concat(textArray2);
            }
            if (!this.checkLinkedOut.Checked)
            {
                sqltext = sqltext + " AND (linked IS NULL OR linked = '')";
            }
            if (!(this.checkLinkedOut.Checked || this.checkDeletedOut.Checked))
            {
                this.panelDate.Enabled = false;
            }
            else
            {
                this.panelDate.Enabled = true;
                string[] textArray3 = new string[] { sqltext, " AND (Ref_Date >= '", this.dateTimePickerOut1.Value.ToString(), "' AND Ref_Date <= '", this.dateTimePickerOut1.Value.ToString(), "')" };
                sqltext = string.Concat(textArray3);
            }
            this.ztableOut.OpenTable("vw_containerout", sqltext, WBData.conn);
            this.dgvTransContainerOut.DataSource = this.ztableOut.DT;
            this.dgvTransContainerOut.Columns["uniq"].Visible = false;
            this.dgvTransContainerOut.Columns["coy"].Visible = false;
            this.dgvTransContainerOut.Columns["location_code"].Visible = false;
            this.dgvTransContainerOut.Columns["deleted"].Visible = false;
            this.dgvTransContainerOut.Columns["Gatepass_Number"].Visible = false;
            this.dgvTransContainerOut.Columns["completed"].Visible = false;
            this.dgvTransContainerOut.Columns["Ref_Date"].HeaderText = "Weighing Date";
            this.dgvTransContainerOut.Columns["Description"].HeaderText = "Destination";
            this.dgvTransContainerOut.Columns["RegCard_No"].HeaderText = "Card No";
            this.dgvTransContainerOut.Columns["Ref"].HeaderText = "Temporary Weighing Ticket";
            this.dgvTransContainerOut.Columns["Truck_Number"].HeaderText = "Truck No";
            this.dgvTransContainerOut.Columns["Linked"].HeaderText = "Container Weighing Ticket";
            this.dgvTransContainerOut.Columns["Container"].HeaderText = "Container No";
            this.dgvTransContainerOut.Columns["Ref_Date"].MinimumWidth = 70;
            this.dgvTransContainerOut.Columns["Description"].MinimumWidth = 80;
            this.dgvTransContainerOut.Columns["RegCard_No"].MinimumWidth = 50;
            this.dgvTransContainerOut.Columns["Ref"].MinimumWidth = 70;
            this.dgvTransContainerOut.Columns["Truck_Number"].MinimumWidth = 70;
            this.dgvTransContainerOut.Columns["Linked"].MinimumWidth = 100;
            this.dgvTransContainerOut.Columns["Container"].MinimumWidth = 90;
            if (this.dgvTransContainerOut.Rows.Count > 0)
            {
                this.dgvTransContainerOut.CurrentCell = this.dgvTransContainerOut.Rows[0].Cells["Truck_Number"];
            }
            this.dgvTransContainerOutFormat();
            string str2 = " SELECT * FROM vw_container WHERE " + WBData.CompanyLocation("") + " AND (Deleted IS NULL OR Deleted = '' OR Deleted = 'N')  AND (mark_return = '' OR mark_return IS null) AND (linked IS NULL OR linked = '')  AND (wx = '4X')  AND (_2nd != '' AND _2nd != '0')  AND (_3rd = '' OR _3rd = '0') ";
            this.ztableIn.OpenTable("vw_container", str2, WBData.conn);
            this.dgvTransContainerIn.DataSource = this.ztableIn.DT;
            int num = 0;
            while (true)
            {
                if (num >= this.dgvTransContainerIn.ColumnCount)
                {
                    this.dgvTransContainerIn.Columns["Ref_Date"].Visible = true;
                    this.dgvTransContainerIn.Columns["Description"].Visible = true;
                    this.dgvTransContainerIn.Columns["Ref"].Visible = true;
                    this.dgvTransContainerIn.Columns["Truck_Number"].Visible = false;
                    this.dgvTransContainerIn.Columns["Container"].Visible = true;
                    this.dgvTransContainerIn.Columns["Seal"].Visible = true;
                    this.dgvTransContainerIn.Columns["PI_No"].Visible = true;
                    this.dgvTransContainerIn.Columns["DO_No"].Visible = true;
                    this.dgvTransContainerIn.Columns["Ref_Date"].HeaderText = "Weighing Date";
                    this.dgvTransContainerIn.Columns["Description"].HeaderText = "Destination";
                    this.dgvTransContainerIn.Columns["Ref"].HeaderText = "Container Weighing Ticket";
                    this.dgvTransContainerIn.Columns["Truck_Number"].HeaderText = "Truck No";
                    this.dgvTransContainerIn.Columns["Container"].HeaderText = "Container No";
                    this.dgvTransContainerIn.Columns["Seal"].HeaderText = "Seal No";
                    this.dgvTransContainerIn.Columns["PI_No"].HeaderText = "PI No";
                    this.dgvTransContainerIn.Columns["DO_No"].HeaderText = "WB DO";
                    this.dgvTransContainerIn.Columns["Ref_Date"].MinimumWidth = 70;
                    this.dgvTransContainerIn.Columns["Description"].MinimumWidth = 80;
                    this.dgvTransContainerIn.Columns["Ref"].MinimumWidth = 70;
                    this.dgvTransContainerIn.Columns["Truck_Number"].MinimumWidth = 70;
                    this.dgvTransContainerIn.Columns["Container"].MinimumWidth = 90;
                    this.dgvTransContainerIn.Columns["Seal"].MinimumWidth = 70;
                    this.dgvTransContainerIn.Columns["PI_No"].MinimumWidth = 70;
                    this.dgvTransContainerIn.Columns["DO_No"].MinimumWidth = 70;
                    if (this.dgvTransContainerIn.Rows.Count > 0)
                    {
                        this.dgvTransContainerIn.CurrentCell = this.dgvTransContainerIn.Rows[0].Cells["Ref"];
                    }
                    this.dgvTransContainerInFormat();
                    Program.AutoComp(this.ztableIn, "DO_No", this.textDOIn);
                    Program.AutoComp(this.ztableIn, "PI_No", this.textPIIn);
                    Program.AutoComp(this.ztableIn, "Container", this.textContainerIn);
                    this.buttonViewLinked.Enabled = false;
                    this.buttonEntryLoadQty.Enabled = false;
                    return;
                }
                this.dgvTransContainerIn.Columns[num].Visible = false;
                num++;
            }
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            DataGridViewCellStyle style4 = new DataGridViewCellStyle();
            DataGridViewCellStyle style5 = new DataGridViewCellStyle();
            DataGridViewCellStyle style6 = new DataGridViewCellStyle();
            this.dgvTransContainerOut = new DataGridView();
            this.buttonFindOut = new Button();
            this.textFindOut = new TextBox();
            this.checkDeletedOut = new CheckBox();
            this.checkLinkedOut = new CheckBox();
            this.panelDate = new GroupBox();
            this.dateTimePickerOut2 = new DateTimePicker();
            this.buttonFilterOut = new Button();
            this.dateTimePickerOut1 = new DateTimePicker();
            this.label4 = new Label();
            this.label3 = new Label();
            this.dgvTransContainerIn = new DataGridView();
            this.label7 = new Label();
            this.label1 = new Label();
            this.gbContOut = new GroupBox();
            this.groupBox1 = new GroupBox();
            this.buttonCancelOut = new Button();
            this.buttonEntryLoadQty = new Button();
            this.buttonViewOut = new Button();
            this.buttonViewLinked = new Button();
            this.gbContIn = new GroupBox();
            this.buttonDO = new Button();
            this.label8 = new Label();
            this.textContainerIn = new TextBox();
            this.textPIIn = new TextBox();
            this.label6 = new Label();
            this.textDOIn = new TextBox();
            this.label5 = new Label();
            this.buttonUnfilterIn = new Button();
            this.buttonFilterIn = new Button();
            this.label2 = new Label();
            this.buttonLink = new Button();
            this.buttonUnlink = new Button();
            this.buttonRefresh = new Button();
            ((ISupportInitialize) this.dgvTransContainerOut).BeginInit();
            this.panelDate.SuspendLayout();
            ((ISupportInitialize) this.dgvTransContainerIn).BeginInit();
            this.gbContOut.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbContIn.SuspendLayout();
            base.SuspendLayout();
            this.dgvTransContainerOut.AllowUserToAddRows = false;
            this.dgvTransContainerOut.AllowUserToDeleteRows = false;
            this.dgvTransContainerOut.AllowUserToOrderColumns = true;
            this.dgvTransContainerOut.AllowUserToResizeRows = false;
            this.dgvTransContainerOut.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader;
            this.dgvTransContainerOut.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgvTransContainerOut.ColumnHeadersDefaultCellStyle = style;
            this.dgvTransContainerOut.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgvTransContainerOut.DefaultCellStyle = style2;
            this.dgvTransContainerOut.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvTransContainerOut.Location = new Point(8, 0x2e);
            this.dgvTransContainerOut.MultiSelect = false;
            this.dgvTransContainerOut.Name = "dgvTransContainerOut";
            this.dgvTransContainerOut.ReadOnly = true;
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgvTransContainerOut.RowHeadersDefaultCellStyle = style3;
            this.dgvTransContainerOut.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvTransContainerOut.Size = new Size(0x25d, 0x175);
            this.dgvTransContainerOut.TabIndex = 12;
            this.dgvTransContainerOut.CellClick += new DataGridViewCellEventHandler(this.dgvTransContainerOut_CellClick);
            this.dgvTransContainerOut.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dgvSAPDest_CellFormatting);
            this.buttonFindOut.Location = new Point(0xca, 20);
            this.buttonFindOut.Name = "buttonFindOut";
            this.buttonFindOut.Size = new Size(0x2d, 0x1b);
            this.buttonFindOut.TabIndex = 15;
            this.buttonFindOut.Text = "Find";
            this.buttonFindOut.UseVisualStyleBackColor = true;
            this.buttonFindOut.Click += new EventHandler(this.buttonFind_Click);
            this.textFindOut.CharacterCasing = CharacterCasing.Upper;
            this.textFindOut.Location = new Point(0x10, 0x18);
            this.textFindOut.Name = "textFindOut";
            this.textFindOut.Size = new Size(180, 20);
            this.textFindOut.TabIndex = 0;
            this.textFindOut.TextChanged += new EventHandler(this.textFind_TextChanged);
            this.textFindOut.KeyPress += new KeyPressEventHandler(this.textFind_KeyPress);
            this.checkDeletedOut.AutoSize = true;
            this.checkDeletedOut.Location = new Point(0x171, 0x67);
            this.checkDeletedOut.Name = "checkDeletedOut";
            this.checkDeletedOut.Size = new Size(0x99, 0x11);
            this.checkDeletedOut.TabIndex = 0x16;
            this.checkDeletedOut.Text = "Inc. Cancelled Transaction";
            this.checkDeletedOut.UseVisualStyleBackColor = true;
            this.checkDeletedOut.CheckedChanged += new EventHandler(this.checkDeleted_CheckedChanged_2);
            this.checkLinkedOut.AutoSize = true;
            this.checkLinkedOut.Location = new Point(0x171, 0x79);
            this.checkLinkedOut.Name = "checkLinkedOut";
            this.checkLinkedOut.Size = new Size(0x8a, 0x11);
            this.checkLinkedOut.TabIndex = 0x15;
            this.checkLinkedOut.Text = "Inc. Linked Transaction";
            this.checkLinkedOut.UseVisualStyleBackColor = true;
            this.checkLinkedOut.CheckedChanged += new EventHandler(this.checkLinked_CheckedChanged);
            this.panelDate.Controls.Add(this.dateTimePickerOut2);
            this.panelDate.Controls.Add(this.buttonFilterOut);
            this.panelDate.Controls.Add(this.dateTimePickerOut1);
            this.panelDate.Controls.Add(this.label4);
            this.panelDate.Controls.Add(this.label3);
            this.panelDate.Location = new Point(8, 0x5b);
            this.panelDate.Name = "panelDate";
            this.panelDate.Size = new Size(0x158, 50);
            this.panelDate.TabIndex = 14;
            this.panelDate.TabStop = false;
            this.dateTimePickerOut2.Format = DateTimePickerFormat.Short;
            this.dateTimePickerOut2.Location = new Point(0xb3, 0x12);
            this.dateTimePickerOut2.Name = "dateTimePickerOut2";
            this.dateTimePickerOut2.Size = new Size(0x62, 20);
            this.dateTimePickerOut2.TabIndex = 14;
            this.buttonFilterOut.Location = new Point(0x11c, 14);
            this.buttonFilterOut.Name = "buttonFilterOut";
            this.buttonFilterOut.Size = new Size(0x2d, 0x1b);
            this.buttonFilterOut.TabIndex = 10;
            this.buttonFilterOut.Text = "Filter";
            this.buttonFilterOut.UseVisualStyleBackColor = true;
            this.buttonFilterOut.Click += new EventHandler(this.buttonFilter_Click);
            this.dateTimePickerOut1.Format = DateTimePickerFormat.Short;
            this.dateTimePickerOut1.Location = new Point(0x3e, 0x12);
            this.dateTimePickerOut1.Name = "dateTimePickerOut1";
            this.dateTimePickerOut1.Size = new Size(0x5f, 20);
            this.dateTimePickerOut1.TabIndex = 13;
            this.label4.AutoSize = true;
            this.label4.Location = new Point(7, 20);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x34, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Filter from";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0xa1, 20);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x10, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "to";
            this.dgvTransContainerIn.AllowUserToAddRows = false;
            this.dgvTransContainerIn.AllowUserToDeleteRows = false;
            this.dgvTransContainerIn.AllowUserToOrderColumns = true;
            this.dgvTransContainerIn.AllowUserToResizeRows = false;
            this.dgvTransContainerIn.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader;
            this.dgvTransContainerIn.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style4.BackColor = SystemColors.Control;
            style4.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style4.ForeColor = SystemColors.WindowText;
            style4.SelectionBackColor = SystemColors.Highlight;
            style4.SelectionForeColor = SystemColors.HighlightText;
            style4.WrapMode = DataGridViewTriState.True;
            this.dgvTransContainerIn.ColumnHeadersDefaultCellStyle = style4;
            this.dgvTransContainerIn.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style5.BackColor = SystemColors.Window;
            style5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style5.ForeColor = SystemColors.ControlText;
            style5.SelectionBackColor = SystemColors.Highlight;
            style5.SelectionForeColor = SystemColors.HighlightText;
            style5.WrapMode = DataGridViewTriState.False;
            this.dgvTransContainerIn.DefaultCellStyle = style5;
            this.dgvTransContainerIn.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvTransContainerIn.Location = new Point(0x26d, 0x2e);
            this.dgvTransContainerIn.MultiSelect = false;
            this.dgvTransContainerIn.Name = "dgvTransContainerIn";
            this.dgvTransContainerIn.ReadOnly = true;
            style6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style6.BackColor = SystemColors.Control;
            style6.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style6.ForeColor = SystemColors.WindowText;
            style6.SelectionBackColor = SystemColors.Highlight;
            style6.SelectionForeColor = SystemColors.HighlightText;
            style6.WrapMode = DataGridViewTriState.True;
            this.dgvTransContainerIn.RowHeadersDefaultCellStyle = style6;
            this.dgvTransContainerIn.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvTransContainerIn.Size = new Size(0x25d, 0x175);
            this.dgvTransContainerIn.TabIndex = 14;
            this.label7.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.label7.AutoSize = true;
            this.label7.BackColor = Color.Transparent;
            this.label7.Font = new Font("Microsoft Sans Serif", 15f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label7.ForeColor = Color.Black;
            this.label7.Location = new Point(0x87, 12);
            this.label7.Margin = new Padding(0);
            this.label7.Name = "label7";
            this.label7.RightToLeft = RightToLeft.Yes;
            this.label7.Size = new Size(0x145, 0x19);
            this.label7.TabIndex = 15;
            this.label7.Text = "List of Transaction for Container Out";
            this.label7.TextAlign = ContentAlignment.TopCenter;
            this.label1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = Color.Transparent;
            this.label1.Font = new Font("Microsoft Sans Serif", 15f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.ForeColor = Color.Black;
            this.label1.Location = new Point(0x301, 12);
            this.label1.Margin = new Padding(0);
            this.label1.Name = "label1";
            this.label1.RightToLeft = RightToLeft.Yes;
            this.label1.Size = new Size(0x135, 0x19);
            this.label1.TabIndex = 0x10;
            this.label1.Text = "List of Transaction for Container In";
            this.label1.TextAlign = ContentAlignment.TopCenter;
            this.gbContOut.Controls.Add(this.groupBox1);
            this.gbContOut.Controls.Add(this.buttonCancelOut);
            this.gbContOut.Controls.Add(this.checkLinkedOut);
            this.gbContOut.Controls.Add(this.panelDate);
            this.gbContOut.Controls.Add(this.buttonEntryLoadQty);
            this.gbContOut.Controls.Add(this.buttonViewOut);
            this.gbContOut.Controls.Add(this.buttonViewLinked);
            this.gbContOut.Controls.Add(this.checkDeletedOut);
            this.gbContOut.Location = new Point(8, 0x1b4);
            this.gbContOut.Name = "gbContOut";
            this.gbContOut.Size = new Size(0x25d, 0x97);
            this.gbContOut.TabIndex = 0x11;
            this.gbContOut.TabStop = false;
            this.gbContOut.Text = "Menu for Transaction for Container Out";
            this.groupBox1.Controls.Add(this.textFindOut);
            this.groupBox1.Controls.Add(this.buttonFindOut);
            this.groupBox1.Location = new Point(0x151, 0x13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x106, 0x3f);
            this.groupBox1.TabIndex = 0x17;
            this.groupBox1.TabStop = false;
            this.buttonCancelOut.Image = Resources.cancel_24px;
            this.buttonCancelOut.ImageAlign = ContentAlignment.MiddleLeft;
            this.buttonCancelOut.Location = new Point(160, 0x16);
            this.buttonCancelOut.Name = "buttonCancelOut";
            this.buttonCancelOut.Size = new Size(0xa5, 0x1b);
            this.buttonCancelOut.TabIndex = 0x19;
            this.buttonCancelOut.Text = "Cancel Temp Transaction";
            this.buttonCancelOut.TextAlign = ContentAlignment.MiddleRight;
            this.buttonCancelOut.UseVisualStyleBackColor = true;
            this.buttonCancelOut.Click += new EventHandler(this.buttonCancelOut_Click);
            this.buttonEntryLoadQty.BackgroundImage = Resources.edit_16px;
            this.buttonEntryLoadQty.BackgroundImageLayout = ImageLayout.None;
            this.buttonEntryLoadQty.Location = new Point(160, 0x37);
            this.buttonEntryLoadQty.Name = "buttonEntryLoadQty";
            this.buttonEntryLoadQty.Size = new Size(0xa5, 0x1b);
            this.buttonEntryLoadQty.TabIndex = 0x1b;
            this.buttonEntryLoadQty.Text = "Entry Loading Quantity";
            this.buttonEntryLoadQty.TextAlign = ContentAlignment.MiddleRight;
            this.buttonEntryLoadQty.UseVisualStyleBackColor = true;
            this.buttonEntryLoadQty.Click += new EventHandler(this.button2_Click);
            this.buttonViewOut.BackgroundImage = Resources.search_16px;
            this.buttonViewOut.BackgroundImageLayout = ImageLayout.None;
            this.buttonViewOut.Location = new Point(8, 0x16);
            this.buttonViewOut.Name = "buttonViewOut";
            this.buttonViewOut.Size = new Size(0x95, 0x1b);
            this.buttonViewOut.TabIndex = 0x10;
            this.buttonViewOut.Text = "View Temp Transaction";
            this.buttonViewOut.TextAlign = ContentAlignment.MiddleRight;
            this.buttonViewOut.UseVisualStyleBackColor = true;
            this.buttonViewOut.Click += new EventHandler(this.buttonViewOut_Click);
            this.buttonViewLinked.BackgroundImage = Resources.search_pink_16px;
            this.buttonViewLinked.BackgroundImageLayout = ImageLayout.None;
            this.buttonViewLinked.Location = new Point(8, 0x37);
            this.buttonViewLinked.Name = "buttonViewLinked";
            this.buttonViewLinked.Size = new Size(150, 0x1b);
            this.buttonViewLinked.TabIndex = 0x1a;
            this.buttonViewLinked.Text = "View Linked Transaction";
            this.buttonViewLinked.TextAlign = ContentAlignment.MiddleRight;
            this.buttonViewLinked.UseVisualStyleBackColor = true;
            this.buttonViewLinked.Click += new EventHandler(this.button1_Click);
            this.gbContIn.Controls.Add(this.buttonDO);
            this.gbContIn.Controls.Add(this.label8);
            this.gbContIn.Controls.Add(this.textContainerIn);
            this.gbContIn.Controls.Add(this.textPIIn);
            this.gbContIn.Controls.Add(this.label6);
            this.gbContIn.Controls.Add(this.textDOIn);
            this.gbContIn.Controls.Add(this.label5);
            this.gbContIn.Controls.Add(this.buttonUnfilterIn);
            this.gbContIn.Controls.Add(this.buttonFilterIn);
            this.gbContIn.Controls.Add(this.label2);
            this.gbContIn.Location = new Point(0x26d, 0x1b4);
            this.gbContIn.Name = "gbContIn";
            this.gbContIn.Size = new Size(0x25d, 0x97);
            this.gbContIn.TabIndex = 0x12;
            this.gbContIn.TabStop = false;
            this.gbContIn.Text = "Menu for Transaction for Container In";
            this.buttonDO.Location = new Point(0x110, 0x2c);
            this.buttonDO.Margin = new Padding(0);
            this.buttonDO.Name = "buttonDO";
            this.buttonDO.Size = new Size(0x17, 0x17);
            this.buttonDO.TabIndex = 0x16;
            this.buttonDO.Text = "...";
            this.buttonDO.UseVisualStyleBackColor = true;
            this.buttonDO.Click += new EventHandler(this.buttonDO_Click);
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0x22, 0x65);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x45, 13);
            this.label8.TabIndex = 0x15;
            this.label8.Text = "Container No";
            this.textContainerIn.CharacterCasing = CharacterCasing.Upper;
            this.textContainerIn.Location = new Point(110, 0x62);
            this.textContainerIn.Name = "textContainerIn";
            this.textContainerIn.Size = new Size(0xb9, 20);
            this.textContainerIn.TabIndex = 20;
            this.textPIIn.CharacterCasing = CharacterCasing.Upper;
            this.textPIIn.Location = new Point(110, 0x48);
            this.textPIIn.Name = "textPIIn";
            this.textPIIn.Size = new Size(0xb9, 20);
            this.textPIIn.TabIndex = 0x13;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x22, 0x4b);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x22, 13);
            this.label6.TabIndex = 0x12;
            this.label6.Text = "PI No";
            this.textDOIn.CharacterCasing = CharacterCasing.Upper;
            this.textDOIn.Location = new Point(110, 0x2e);
            this.textDOIn.Name = "textDOIn";
            this.textDOIn.Size = new Size(0x9f, 20);
            this.textDOIn.TabIndex = 0x11;
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x22, 0x31);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x2c, 13);
            this.label5.TabIndex = 0x10;
            this.label5.Text = "WB DO";
            this.buttonUnfilterIn.Location = new Point(0x17d, 0x5b);
            this.buttonUnfilterIn.Name = "buttonUnfilterIn";
            this.buttonUnfilterIn.Size = new Size(50, 0x1b);
            this.buttonUnfilterIn.TabIndex = 15;
            this.buttonUnfilterIn.Text = "Unfilter";
            this.buttonUnfilterIn.UseVisualStyleBackColor = true;
            this.buttonUnfilterIn.Click += new EventHandler(this.buttonUnfilterIn_Click);
            this.buttonFilterIn.Location = new Point(0x145, 0x5b);
            this.buttonFilterIn.Name = "buttonFilterIn";
            this.buttonFilterIn.Size = new Size(50, 0x1b);
            this.buttonFilterIn.TabIndex = 10;
            this.buttonFilterIn.Text = "Filter";
            this.buttonFilterIn.UseVisualStyleBackColor = true;
            this.buttonFilterIn.Click += new EventHandler(this.buttonFilterIn_Click);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x11, 0x16);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x2b, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Filter by";
            this.buttonLink.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonLink.Location = new Point(0x1c7, 0x25b);
            this.buttonLink.Name = "buttonLink";
            this.buttonLink.Size = new Size(0x9e, 0x2e);
            this.buttonLink.TabIndex = 0x10;
            this.buttonLink.Text = "Link Transaction";
            this.buttonLink.UseVisualStyleBackColor = true;
            this.buttonLink.Click += new EventHandler(this.buttonLink_Click);
            this.buttonUnlink.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonUnlink.Location = new Point(0x26d, 0x25b);
            this.buttonUnlink.Name = "buttonUnlink";
            this.buttonUnlink.Size = new Size(0x9e, 0x2e);
            this.buttonUnlink.TabIndex = 0x13;
            this.buttonUnlink.Text = "Unlink Transaction";
            this.buttonUnlink.UseVisualStyleBackColor = true;
            this.buttonUnlink.Click += new EventHandler(this.buttonUnlink_Click);
            this.buttonRefresh.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonRefresh.Location = new Point(0x42c, 0x25b);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new Size(0x9e, 0x2e);
            this.buttonRefresh.TabIndex = 20;
            this.buttonRefresh.Text = "Refresh All Data";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            this.buttonRefresh.Click += new EventHandler(this.buttonRefresh_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x4d2, 0x295);
            base.Controls.Add(this.buttonRefresh);
            base.Controls.Add(this.buttonUnlink);
            base.Controls.Add(this.buttonLink);
            base.Controls.Add(this.gbContIn);
            base.Controls.Add(this.gbContOut);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.dgvTransContainerIn);
            base.Controls.Add(this.dgvTransContainerOut);
            base.KeyPreview = true;
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormTransactionContainerOut";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of Transaction for Container Out (4X)";
            base.Load += new EventHandler(this.FormTransactionContainerOut_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransactionContainerOut_KeyPress);
            ((ISupportInitialize) this.dgvTransContainerOut).EndInit();
            this.panelDate.ResumeLayout(false);
            this.panelDate.PerformLayout();
            ((ISupportInitialize) this.dgvTransContainerIn).EndInit();
            this.gbContOut.ResumeLayout(false);
            this.gbContOut.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbContIn.ResumeLayout(false);
            this.gbContIn.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void linkRef(bool link)
        {
            Cursor.Current = Cursors.WaitCursor;
            string keyField = "";
            string str2 = this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString();
            string str3 = link ? this.dgvTransContainerIn.CurrentRow.Cells["ref"].Value.ToString() : this.dgvTransContainerOut.CurrentRow.Cells["linked"].Value.ToString();
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "SELECT * FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND (mark_return = '' OR mark_return IS null OR mark_return = 'N')  AND (deleted = '' OR deleted IS null OR deleted = 'N') AND ref = '", str3, "'" };
            table.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                table.DR = table.DT.Rows[0];
                keyField = table.DR["uniq"].ToString();
                table.DR.BeginEdit();
                table.DR["linked"] = link ? str2 : "";
                table.DR["checksum"] = table.Checksum(table.DR);
                table.DR.EndEdit();
                table.Save();
                try
                {
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, link ? ("Link to reference " + str2) : ("Unlink to reference " + str2) };
                    Program.updateLogHeader("wb_transaction", keyField, logField, logValue);
                }
                catch
                {
                }
            }
            table.Dispose();
            WBTable table2 = new WBTable();
            string[] textArray4 = new string[] { "SELECT * FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND (mark_return = '' OR mark_return IS null OR mark_return = 'N')  AND (deleted = '' OR deleted IS null OR deleted = 'N') and ref = '", str2, "'" };
            table2.OpenTable("wb_transaction", string.Concat(textArray4), WBData.conn);
            if (table2.DT.Rows.Count > 0)
            {
                table2.DR = table2.DT.Rows[0];
                keyField = table2.DR["uniq"].ToString();
                table2.DR.BeginEdit();
                table2.DR["linked"] = link ? str3 : "";
                table2.DR["checksum"] = table2.Checksum(table2.DR);
                table2.DR.EndEdit();
                table2.Save();
                try
                {
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, link ? ("Link to reference " + str3) : ("Unlink to reference " + str3) };
                    Program.updateLogHeader("wb_transaction", keyField, logField, logValue);
                }
                catch
                {
                }
            }
            table2.Dispose();
            Cursor.Current = Cursors.Default;
        }

        private void setDGVIn(string ref_)
        {
            this.textDOIn.Text = "";
            this.textPIIn.Text = "";
            this.textContainerIn.Text = "";
            string sqltext = " SELECT * FROM vw_container WHERE " + WBData.CompanyLocation("") + " AND (Deleted IS NULL OR Deleted = '' OR Deleted = 'N')  AND (mark_return = '' OR mark_return IS null) AND (linked IS NULL OR linked = '')  AND (wx = '4X')  AND (_3rd = '' OR _3rd = '0') ";
            this.ztableIn.OpenTable("vw_Container", sqltext, WBData.conn);
            this.dgvTransContainerIn.DataSource = this.ztableIn.DT;
            this.dgvTransContainerInFormat();
            Program.AutoComp(this.ztableIn, "DO_No", this.textDOIn);
            Program.AutoComp(this.ztableIn, "PI_No", this.textPIIn);
            Program.AutoComp(this.ztableIn, "Container", this.textContainerIn);
            this.dgvTransContainerIn.Update();
            this.dgvTransContainerIn.Refresh();
            if (this.dgvTransContainerIn.Rows.Count > 0)
            {
                string[] aField = new string[] { "Ref" };
                string[] aFind = new string[] { ref_ };
                this.ztableIn.SetCursor(this.dgvTransContainerIn, this.ztableIn.GetCurrentRow(this.dgvTransContainerIn, aField, aFind));
            }
        }

        private void setDGVOut(string ref_)
        {
            string sqltext = "";
            if (this.checkDeletedOut.Checked)
            {
                string[] textArray1 = new string[] { "SELECT * FROM vw_containerout  WHERE coy = '", WBData.sCoyCode, "'  AND location_code = '", WBData.sLocCode, "' " };
                sqltext = string.Concat(textArray1);
            }
            else
            {
                string[] textArray2 = new string[] { "SELECT * FROM vw_containerout  WHERE coy = '", WBData.sCoyCode, "'  AND location_code = '", WBData.sLocCode, "'  AND (deleted IS NULL OR deleted != 'Y') " };
                sqltext = string.Concat(textArray2);
            }
            if (!this.checkLinkedOut.Checked)
            {
                sqltext = sqltext + " AND (linked IS NULL OR linked = '')";
            }
            if (!(this.checkLinkedOut.Checked || this.checkDeletedOut.Checked))
            {
                this.panelDate.Enabled = false;
            }
            else
            {
                this.panelDate.Enabled = true;
                string str2 = Program.DTOC(this.dateTimePickerOut1.Value) + " 00:00:00";
                string str3 = Program.DTOC(this.dateTimePickerOut2.Value) + " 00:00:00";
                string[] textArray3 = new string[] { sqltext, " AND (Ref_Date >= '", str2, "' AND Ref_Date <= '", str3, "')" };
                sqltext = string.Concat(textArray3);
            }
            this.ztableOut.OpenTable("vw_containerout", sqltext, WBData.conn);
            this.dgvTransContainerOut.DataSource = this.ztableOut.DT;
            this.dgvTransContainerOutFormat();
            this.dgvTransContainerOut.Update();
            this.dgvTransContainerOut.Refresh();
            if (this.dgvTransContainerOut.Rows.Count > 0)
            {
                string[] aField = new string[] { "Ref" };
                string[] aFind = new string[] { ref_ };
                this.ztableOut.SetCursor(this.dgvTransContainerOut, this.ztableOut.GetCurrentRow(this.dgvTransContainerOut, aField, aFind));
            }
            if ((this.dgvTransContainerOut.RowCount > 0) && (this.dgvTransContainerOut.CurrentRow.Cells["linked"].Value.ToString() != ""))
            {
                this.buttonViewLinked.Enabled = true;
                this.buttonEntryLoadQty.Enabled = true;
            }
            else
            {
                this.buttonViewLinked.Enabled = false;
                this.buttonEntryLoadQty.Enabled = false;
            }
        }

        private void setLocationDGVs()
        {
            this.dgvTransContainerOut.Columns["Ref_Date"].DisplayIndex = 0;
            this.dgvTransContainerOut.Columns["Description"].DisplayIndex = 1;
            this.dgvTransContainerOut.Columns["RegCard_No"].DisplayIndex = 2;
            this.dgvTransContainerOut.Columns["Ref"].DisplayIndex = 3;
            this.dgvTransContainerOut.Columns["Truck_Number"].DisplayIndex = 4;
            this.dgvTransContainerOut.Columns["Linked"].DisplayIndex = 5;
            this.dgvTransContainerOut.Columns["Container"].DisplayIndex = 6;
            this.dgvTransContainerOut.Sort(this.dgvTransContainerOut.Columns["Truck_Number"], ListSortDirection.Ascending);
            if (this.ztableOut.DT.Rows.Count > 0)
            {
                foreach (DataColumn column in this.ztableOut.DT.Columns)
                {
                    this.ztableOut.DR = this.ztableOut.DT.Rows[0];
                    if (this.ztableOut.DR[column.ColumnName].GetType().ToString() == "System.Double")
                    {
                        this.dgvTransContainerOut.Columns[column.ColumnName].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                        this.dgvTransContainerOut.Columns[column.ColumnName].DefaultCellStyle.Format = "N0";
                    }
                }
            }
            if (this.dgvTransContainerOut.RowCount > 0)
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.dgvTransContainerOut.CurrentRow.Cells["uniq"].Value.ToString() };
                this.ztableOut.SetCursor(this.dgvTransContainerOut, this.ztableOut.GetCurrentRow(this.dgvTransContainerOut, aField, aFind));
            }
        }

        private void textFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFindOut.PerformClick();
            }
        }

        private void textFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFindOut = 0;
        }

        private void translate()
        {
            this.Text = Resource.ContainerOut_013 + " (4X)";
            this.label7.Text = Resource.ContainerOut_013;
            this.label1.Text = Resource.ContainerOut_014;
            this.gbContOut.Text = Resource.ContainerOut_015;
            this.label4.Text = Resource.ContainerOut_017;
            this.label3.Text = Resource.ContainerOut_018;
            this.checkDeletedOut.Text = Resource.ContainerOut_019;
            this.checkLinkedOut.Text = Resource.ContainerOut_020;
            this.gbContIn.Text = Resource.ContainerOut_016;
            this.label2.Text = Resource.ContainerOut_021;
            this.label5.Text = Resource.ContainerOut_022;
            this.label6.Text = Resource.ContainerOut_023;
            this.label8.Text = Resource.ContainerOut_024;
            this.buttonLink.Text = Resource.ContainerOut_025;
            this.buttonUnlink.Text = Resource.ContainerOut_026;
        }

        private void update_all(string reason, string token_in_progress)
        {
            string str = "";
            string str2 = "";
            bool flag = false;
            WBTable table = new WBTable();
            table.OpenTable("wb_transaction", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + this.dgvTransContainerOut.CurrentRow.Cells["Ref"].Value.ToString() + "'"), WBData.conn);
            int num = 0;
            while (true)
            {
                if (num >= table.DT.Rows.Count)
                {
                    table.Dispose();
                    if ((WBSetting.Field("Check_Email").Trim() == "Y") & flag)
                    {
                        string[] textArray9 = new string[] { ("Dear All,<br><br>This email is to notify you that the following transaction has been cancelled :<table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name"), "</tr><tr class='bd'><td nowrap>Date & Time</td><td nowrap> : ", DateTime.Now.ToShortDateString(), " ", DateTime.Now.ToString("HH:mm:ss") };
                        string[] textArray10 = new string[] { ((string.Concat(textArray9) + "</tr><tr class='bd'><td nowrap>Ref Number</td><td nowrap> : " + str) + "</tr><tr class='bd'><td nowrap>Truck Number</td><td nowrap> : " + str2) + "</tr><tr class='bd'><td nowrap>Change Reason</td><td nowrap> : " + reason, "</tr><tr class='bd'><td nowrap>WB User</td><td nowrap> : ", WBUser.UserGroup.Trim(), " ( ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " ) " };
                        WBMail mail = new WBMail();
                        mail.SendMail_Cancel((string.Concat(textArray10) + "</tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : " + WBData.sWBCode) + "</tr></table><br>Thank you.");
                        mail.Dispose();
                        WBTable table4 = new WBTable();
                        table4.OpenTable("wb_email", "select * from wb_email where " + WBData.CompanyLocation(" and email_code = 'TRANSLOG' and email_date = '" + DateTime.Now.ToString("yyyy-MM-dd") + " 00:00:00' "), WBData.conn);
                        if (table4.DT.Rows.Count <= 0)
                        {
                            table4.DR = table4.DT.NewRow();
                            table4.DR["COY"] = WBData.sCoyCode;
                            table4.DR["LOCATION_CODE"] = WBData.sLocCode;
                            table4.DR["Email_code"] = "TRANSLOG";
                            table4.DR["Email_date"] = DateTime.Now.ToString("dd/MM/yyyy");
                            table4.DR["Status"] = "N";
                            table4.DT.Rows.Add(table4.DR);
                            table4.Save();
                        }
                        else if (table4.DT.Rows[0]["Status"].ToString() == "Y")
                        {
                            table4.DR = table4.DT.Rows[0];
                            table4.DR.BeginEdit();
                            table4.DR["Status"] = "N";
                            table4.DR.EndEdit();
                            table4.Save();
                        }
                        table4.Dispose();
                    }
                    this.ztableOut.ReOpen();
                    this.dgvTransContainerOut.DataSource = this.ztableOut.DT;
                    this.dgvTransContainerOutFormat();
                    this.dgvTransContainerOut.Refresh();
                    return;
                }
                if (num == 0)
                {
                    str = table.DT.Rows[num]["ref"].ToString();
                    str2 = table.DT.Rows[num]["truck_number"].ToString();
                }
                table.DT.Rows[num].BeginEdit();
                if (WBSetting.Field("GM") != "Y")
                {
                    if (WBSetting.gatepass_registration)
                    {
                        string keyField = "";
                        WBTable table3 = new WBTable();
                        table3.OpenTable("wb_gatepass", "SELECT * FROM wb_gatepass WHERE gatepass_number = '" + this.dgvTransContainerOut.CurrentRow.Cells["gatepass_number"].Value.ToString() + "'", WBData.conn);
                        if (table3.DT.Rows.Count == 1)
                        {
                            table3.DR = table3.DT.Rows[0];
                            keyField = table3.DR["uniq"].ToString();
                            table3.DR.BeginEdit();
                            table3.DR["ref"] = "";
                            table3.DR["Change_By"] = WBUser.UserID;
                            table3.DR["Change_Date"] = DateTime.Now;
                            table3.DR.EndEdit();
                        }
                        table3.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Delete reference no because it's been cancelled" };
                        Program.updateLogHeader("wb_gatepass", keyField, logField, logValue);
                        table3.Dispose();
                    }
                    Program.unblock_os_bc(table.DT.Rows[num]["do_no"].ToString().Trim(), table.DT.Rows[num]["ref"].ToString().Trim());
                    table.DT.Rows[num]["deleted"] = "Y";
                    table.DT.Rows[num]["posted"] = "N";
                    table.DT.Rows[num]["cancel_type"] = "C";
                    table.DT.Rows[num]["cancel_reason"] = reason;
                    table.DT.Rows[num]["Delete_By"] = WBUser.UserID.Trim();
                    table.DT.Rows[num]["Delete_Date"] = Program.DTOC(DateTime.Now);
                    table.DT.Rows[num]["ChangeReason"] = reason;
                    table.DT.Rows[num]["checksum"] = table.Checksum_Main(table.DT.Rows[num]);
                    table.DT.Rows[num].EndEdit();
                    table.Save();
                    flag = true;
                }
                else if ((token_in_progress != "Y") && (reason != ""))
                {
                    if (WBSetting.gatepass_registration)
                    {
                        string keyField = "";
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_gatepass", "SELECT * FROM wb_gatepass WHERE gatepass_number = '" + this.dgvTransContainerOut.CurrentRow.Cells["gatepass_number"].Value.ToString() + "'", WBData.conn);
                        if (table2.DT.Rows.Count == 1)
                        {
                            table2.DR = table2.DT.Rows[0];
                            keyField = table2.DR["uniq"].ToString();
                            table2.DR.BeginEdit();
                            table2.DR["ref"] = "";
                            table2.DR["Change_By"] = WBUser.UserID;
                            table2.DR["Change_Date"] = DateTime.Now;
                            table2.DR.EndEdit();
                        }
                        table2.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Delete reference no because it's been cancelled" };
                        Program.updateLogHeader("wb_gatepass", keyField, logField, logValue);
                        table2.Dispose();
                    }
                    table.DT.Rows[num]["deleted"] = "Y";
                    table.DT.Rows[num]["posted"] = "N";
                    table.DT.Rows[num]["cancel_type"] = "C";
                    table.DT.Rows[num]["cancel_reason"] = reason;
                    table.DT.Rows[num]["ChangeReason"] = reason;
                    table.DT.Rows[num]["Delete_By"] = WBUser.UserID.Trim();
                    table.DT.Rows[num]["Delete_Date"] = Program.DTOC(DateTime.Now);
                    table.DT.Rows[num]["checksum"] = table.Checksum_Main(table.DT.Rows[num]);
                    table.DT.Rows[num].EndEdit();
                    table.Save();
                    flag = true;
                }
                table.RLock(table.DT.Rows[num]["Uniq"].ToString().Trim(), false);
                if (flag)
                {
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "CANCEL", WBUser.UserID, reason };
                    Program.updateLogHeader("wb_transaction", table.DT.Rows[num]["uniq"].ToString(), logField, logValue);
                }
                else
                {
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Cancel transaction is cancelled" };
                    Program.updateLogHeader("wb_transaction", table.DT.Rows[num]["uniq"].ToString(), logField, logValue);
                }
                num++;
            }
        }

        private void viewForLinked()
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_transaction", "SELECT linked FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref = '" + this.dgvTransContainerOut.CurrentRow.Cells["ref"].Value.ToString() + "' "), WBData.conn);
            string str = table.DT.Rows[0]["linked"].ToString();
            table.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref = '" + str + "' "), WBData.conn);
            table.DR = table.DT.Rows[0];
            this.nCurrRow = 0;
            this.sUniq = table.DR["uniq"].ToString();
            if (this.ztableOut.BeforeEdit(this.dgvTransContainerOut, "VIEW"))
            {
                FormTransaction transaction = new FormTransaction {
                    nCurrRow = this.nCurrRow,
                    sUniq = this.sUniq
                };
                WBTable table2 = new WBTable();
                table2.OpenTable("wb_gatepass", "SELECT uniq, card_no FROM wb_gatepass WHERE " + WBData.CompanyLocation(" AND gatepass_number = '" + table.DR["gatepass_number"].ToString() + "'"), WBData.conn);
                if (table2.DT.Rows.Count > 0)
                {
                    transaction.gatepass_uniq = table2.DT.Rows[0]["uniq"].ToString();
                    transaction.gatepass_no = table.DR["gatepass_number"].ToString();
                    transaction.card_no = table2.DT.Rows[0]["card_no"].ToString();
                }
                table2.Dispose();
                transaction.tblTrans = table;
                transaction.pMode = "VIEW";
                transaction.dgvTrans = this.dgvTransContainerOut;
                transaction.WX = "3X";
                transaction.tambahRecord = false;
                transaction.ShowDialog();
                transaction.Dispose();
                table.Dispose();
            }
        }

        private void viewForTemp()
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dgvTransContainerOut.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztableOut.GetRecNo(aField, aFind);
            this.sUniq = this.dgvTransContainerOut.CurrentRow.Cells["uniq"].Value.ToString();
            if (this.ztableOut.BeforeEdit(this.dgvTransContainerOut, "VIEW"))
            {
                FormTransaction transaction = new FormTransaction {
                    nCurrRow = this.nCurrRow,
                    sUniq = this.sUniq
                };
                WBTable table = new WBTable();
                table.OpenTable("wb_gatepass", "SELECT uniq, card_no FROM wb_gatepass WHERE " + WBData.CompanyLocation(" AND gatepass_number = '" + this.dgvTransContainerOut.CurrentRow.Cells["gatepass_number"].Value.ToString() + "'"), WBData.conn);
                transaction.gatepass_uniq = table.DT.Rows[0]["uniq"].ToString();
                transaction.gatepass_no = this.dgvTransContainerOut.CurrentRow.Cells["gatepass_number"].Value.ToString();
                transaction.card_no = table.DT.Rows[0]["card_no"].ToString();
                table.Dispose();
                WBTable table2 = new WBTable();
                if (this.ztableOut.DT.Rows.Count == 0)
                {
                    table2.OpenTable("wb_transaction", "select * from wb_transaction where 1 = 2", WBData.conn);
                }
                else
                {
                    DataRow row = this.ztableOut.DT.Rows[this.nCurrRow];
                    string sqltext = "select * from wb_transaction where uniq = '" + row["uniq"].ToString() + "'";
                    table2.OpenTable("wb_transaction", sqltext, WBData.conn);
                }
                transaction.tblTrans = table2;
                transaction.pMode = "VIEW";
                transaction.dgvTrans = this.dgvTransContainerOut;
                transaction.WX = "1X";
                transaction.tambahRecord = false;
                transaction.ShowDialog();
                if (transaction.Saved)
                {
                    this.ztableOut.ReOpen();
                    this.dgvTransContainerOut = this.ztableOut.AfterEdit("VIEW");
                    string[] textArray3 = new string[] { "Ref" };
                    string[] textArray4 = new string[] { transaction.textRefNo.Text };
                    this.ztableOut.SetCursor(this.dgvTransContainerOut, this.ztableOut.GetCurrentRow(this.dgvTransContainerOut, textArray3, textArray4));
                }
                this.ztableOut.UnLock();
                transaction.Dispose();
                Cursor.Current = Cursors.Default;
            }
        }
    }
}

