﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormLocationEntry : Form
    {
        public DataGridView dataGridView1;
        public WBTable zTable;
        public WBTable tbl_location;
        public string pMode;
        public bool saved = false;
        public int nCurrRow;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private Label label3;
        private Label label2;
        private Button button3;
        private Button buttonSave;
        private Label label58;
        private Panel panel8;
        private TextBox textCompanyCode;
        private Label label24;
        private TextBox textLine;
        private Label label69;
        private TextBox textUpload_Type;
        private Label label68;
        private TextBox textSTO_Item;
        private TextBox textGR_Discharge;
        private TextBox textTransport_Type;
        private TextBox textGR_Storage;
        private TextBox textGI_Batch;
        private TextBox textGI_Storage;
        private Label label70;
        private Label label71;
        private Label label72;
        private Label label73;
        private Label label74;
        private Label label75;
        private TextBox textTransit_Storage;
        private Label label76;
        private TextBox textSO_Item;
        private TextBox textStorage_Supp;
        private TextBox textPlant_Supp;
        private TextBox textMov_Type;
        private TextBox textBatch;
        private TextBox textUoM;
        private TextBox textStorage_Rcv;
        private TextBox textPlant_Rcv;
        private Label label67;
        private Label label66;
        private Label label65;
        private Label label64;
        private Label label63;
        private Label label62;
        private Label label61;
        private Label label60;
        private TextBox textBill_Lading;
        private Label label59;
        public TextBox textCoyCode;
        private TextBox textLocName;
        private Label label4;
        public TextBox textLocCode;

        public FormLocationEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
            this.zTable.ReOpen();
            if (this.pMode != "ADD")
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.zTable.DR.BeginEdit();
            }
            else if (!this.checkExist())
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                MessageBox.Show(Resource.Mes_182, Resource.Title_002);
                return;
            }
            this.zTable.DR["Coy"] = this.textCoyCode.Text;
            this.zTable.DR["Location_Code"] = this.textLocCode.Text;
            this.zTable.DR["Location_Name"] = this.textLocName.Text;
            this.zTable.DR["CoySAP"] = this.textCompanyCode.Text;
            this.zTable.DR["Bill_Lading"] = this.textBill_Lading.Text.Trim();
            this.zTable.DR["Plant_Rcv"] = this.textPlant_Rcv.Text.Trim();
            this.zTable.DR["Storage_Rcv"] = this.textStorage_Rcv.Text.Trim();
            this.zTable.DR["Uom"] = this.textUoM.Text.Trim();
            this.zTable.DR["Batch"] = this.textBatch.Text.Trim();
            this.zTable.DR["Mov_Type"] = this.textMov_Type.Text.Trim();
            this.zTable.DR["Plant_Supp"] = this.textPlant_Supp.Text.Trim();
            this.zTable.DR["Storage_Supp"] = this.textStorage_Supp.Text.Trim();
            this.zTable.DR["SO_Item"] = this.textSO_Item.Text.Trim();
            this.zTable.DR["Transit_Storage"] = this.textTransit_Storage.Text.Trim();
            this.zTable.DR["Upload_Type"] = this.textUpload_Type.Text.Trim();
            this.zTable.DR["Line"] = this.textLine.Text.Trim();
            this.zTable.DR["GI_Storage"] = this.textGI_Storage.Text.Trim();
            this.zTable.DR["GI_Batch"] = this.textGI_Batch.Text.Trim();
            this.zTable.DR["GR_Storage"] = this.textGR_Storage.Text.Trim();
            this.zTable.DR["Transport_Type"] = this.textTransport_Type.Text.Trim();
            this.zTable.DR["GR_Discharge"] = this.textGR_Discharge.Text.Trim();
            this.zTable.DR["STO_Item"] = this.textSTO_Item.Text.Trim();
            if ((this.pMode == "ADD") || (this.pMode == "COPY"))
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DR["checksum"] = this.zTable.Checksum(this.zTable.DR);
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR["checksum"] = this.zTable.Checksum(this.zTable.DR);
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            this.saved = true;
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private bool checkExist()
        {
            bool flag2;
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { "select * from wb_location where coy='", this.textCoyCode.Text, "' and location_code ='", this.textLocCode.Text, "'" };
            table.OpenTable("wb_location", string.Concat(textArray1), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                table.Dispose();
                flag2 = true;
            }
            else
            {
                table.Dispose();
                flag2 = false;
            }
            return flag2;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormLocationEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormLocationEntry_Load(object sender, EventArgs e)
        {
            if (this.pMode == "ADD")
            {
                this.textCoyCode.Text = WBData.sCoyCode;
            }
            else
            {
                this.tbl_location = new WBTable();
                this.tbl_location.OpenTable("wb_Loc", "select * from wb_location where uniq = '" + this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Uniq"].Value.ToString() + "'", WBData.conn);
                this.tbl_location.DR = this.tbl_location.DT.Rows[0];
                this.textCoyCode.Text = this.tbl_location.DR["Coy"].ToString();
                this.textLocCode.Text = this.tbl_location.DR["Location_Code"].ToString();
                this.textLocName.Text = this.tbl_location.DR["Location_Name"].ToString();
                this.textCompanyCode.Text = this.tbl_location.DR["CoySAP"].ToString();
                this.textBill_Lading.Text = this.tbl_location.DR["Bill_Lading"].ToString();
                this.textPlant_Rcv.Text = this.tbl_location.DR["Plant_Rcv"].ToString();
                this.textStorage_Rcv.Text = this.tbl_location.DR["Storage_Rcv"].ToString();
                this.textUoM.Text = this.tbl_location.DR["Uom"].ToString();
                this.textBatch.Text = this.tbl_location.DR["Batch"].ToString();
                this.textMov_Type.Text = this.tbl_location.DR["Mov_Type"].ToString();
                this.textPlant_Supp.Text = this.tbl_location.DR["Plant_Supp"].ToString();
                this.textStorage_Supp.Text = this.tbl_location.DR["Storage_Supp"].ToString();
                this.textSO_Item.Text = this.tbl_location.DR["SO_Item"].ToString();
                this.textTransit_Storage.Text = this.tbl_location.DR["Transit_Storage"].ToString();
                this.textUpload_Type.Text = this.tbl_location.DR["Upload_Type"].ToString();
                this.textLine.Text = this.tbl_location.DR["Line"].ToString();
                this.textGI_Storage.Text = this.tbl_location.DR["GI_Storage"].ToString();
                this.textGI_Batch.Text = this.tbl_location.DR["GI_Batch"].ToString();
                this.textGR_Storage.Text = this.tbl_location.DR["GR_Storage"].ToString();
                this.textTransport_Type.Text = this.tbl_location.DR["Transport_Type"].ToString();
                this.textGR_Discharge.Text = this.tbl_location.DR["GR_Discharge"].ToString();
                this.textSTO_Item.Text = this.tbl_location.DR["STO_Item"].ToString();
                this.tbl_location.Dispose();
            }
            if (this.pMode == "VIEW")
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.button3.Text = Resource.Btn_Close;
                this.button3.Enabled = true;
            }
        }

        private void InitializeComponent()
        {
            this.textLocCode = new TextBox();
            this.textCoyCode = new TextBox();
            this.label3 = new Label();
            this.label2 = new Label();
            this.button3 = new Button();
            this.buttonSave = new Button();
            this.label58 = new Label();
            this.panel8 = new Panel();
            this.textCompanyCode = new TextBox();
            this.label24 = new Label();
            this.textLine = new TextBox();
            this.label69 = new Label();
            this.textUpload_Type = new TextBox();
            this.label68 = new Label();
            this.textSTO_Item = new TextBox();
            this.textGR_Discharge = new TextBox();
            this.textTransport_Type = new TextBox();
            this.textGR_Storage = new TextBox();
            this.textGI_Batch = new TextBox();
            this.textGI_Storage = new TextBox();
            this.label70 = new Label();
            this.label71 = new Label();
            this.label72 = new Label();
            this.label73 = new Label();
            this.label74 = new Label();
            this.label75 = new Label();
            this.textTransit_Storage = new TextBox();
            this.label76 = new Label();
            this.textSO_Item = new TextBox();
            this.textStorage_Supp = new TextBox();
            this.textPlant_Supp = new TextBox();
            this.textMov_Type = new TextBox();
            this.textBatch = new TextBox();
            this.textUoM = new TextBox();
            this.textStorage_Rcv = new TextBox();
            this.textPlant_Rcv = new TextBox();
            this.label67 = new Label();
            this.label66 = new Label();
            this.label65 = new Label();
            this.label64 = new Label();
            this.label63 = new Label();
            this.label62 = new Label();
            this.label61 = new Label();
            this.label60 = new Label();
            this.textBill_Lading = new TextBox();
            this.label59 = new Label();
            this.textLocName = new TextBox();
            this.label4 = new Label();
            this.panel8.SuspendLayout();
            base.SuspendLayout();
            this.textLocCode.Location = new Point(0x99, 0x2c);
            this.textLocCode.Name = "textLocCode";
            this.textLocCode.Size = new Size(0x62, 20);
            this.textLocCode.TabIndex = 12;
            this.textLocCode.KeyPress += new KeyPressEventHandler(this.textLocCode_KeyPress);
            this.textCoyCode.Location = new Point(0x99, 0x11);
            this.textCoyCode.Name = "textCoyCode";
            this.textCoyCode.ReadOnly = true;
            this.textCoyCode.Size = new Size(0x62, 20);
            this.textCoyCode.TabIndex = 11;
            this.label3.Location = new Point(15, 0x2e);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x87, 0x12);
            this.label3.TabIndex = 9;
            this.label3.Text = "Location Code";
            this.label3.TextAlign = ContentAlignment.TopRight;
            this.label2.Location = new Point(12, 0x13);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x8a, 0x12);
            this.label2.TabIndex = 8;
            this.label2.Text = "Company Code";
            this.label2.TextAlign = ContentAlignment.TopRight;
            this.button3.Location = new Point(0x148, 0x72);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x4b, 0x1f);
            this.button3.TabIndex = 14;
            this.button3.Text = "&Close";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.buttonSave.Location = new Point(0xc4, 0x72);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x59, 0x1f);
            this.buttonSave.TabIndex = 13;
            this.buttonSave.Text = "&Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.button2_Click);
            this.label58.AutoSize = true;
            this.label58.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label58.Location = new Point(0x12, 160);
            this.label58.Name = "label58";
            this.label58.Size = new Size(0x66, 13);
            this.label58.TabIndex = 0x10;
            this.label58.Text = "SAP Information ";
            this.label58.Visible = false;
            this.panel8.BorderStyle = BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.textCompanyCode);
            this.panel8.Controls.Add(this.label24);
            this.panel8.Controls.Add(this.textLine);
            this.panel8.Controls.Add(this.label69);
            this.panel8.Controls.Add(this.textUpload_Type);
            this.panel8.Controls.Add(this.label68);
            this.panel8.Controls.Add(this.textSTO_Item);
            this.panel8.Controls.Add(this.textGR_Discharge);
            this.panel8.Controls.Add(this.textTransport_Type);
            this.panel8.Controls.Add(this.textGR_Storage);
            this.panel8.Controls.Add(this.textGI_Batch);
            this.panel8.Controls.Add(this.textGI_Storage);
            this.panel8.Controls.Add(this.label70);
            this.panel8.Controls.Add(this.label71);
            this.panel8.Controls.Add(this.label72);
            this.panel8.Controls.Add(this.label73);
            this.panel8.Controls.Add(this.label74);
            this.panel8.Controls.Add(this.label75);
            this.panel8.Controls.Add(this.textTransit_Storage);
            this.panel8.Controls.Add(this.label76);
            this.panel8.Controls.Add(this.textSO_Item);
            this.panel8.Controls.Add(this.textStorage_Supp);
            this.panel8.Controls.Add(this.textPlant_Supp);
            this.panel8.Controls.Add(this.textMov_Type);
            this.panel8.Controls.Add(this.textBatch);
            this.panel8.Controls.Add(this.textUoM);
            this.panel8.Controls.Add(this.textStorage_Rcv);
            this.panel8.Controls.Add(this.textPlant_Rcv);
            this.panel8.Controls.Add(this.label67);
            this.panel8.Controls.Add(this.label66);
            this.panel8.Controls.Add(this.label65);
            this.panel8.Controls.Add(this.label64);
            this.panel8.Controls.Add(this.label63);
            this.panel8.Controls.Add(this.label62);
            this.panel8.Controls.Add(this.label61);
            this.panel8.Controls.Add(this.label60);
            this.panel8.Controls.Add(this.textBill_Lading);
            this.panel8.Controls.Add(this.label59);
            this.panel8.Location = new Point(0x15, 0xb0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new Size(0x21a, 0x124);
            this.panel8.TabIndex = 15;
            this.panel8.Visible = false;
            this.textCompanyCode.Location = new Point(0x83, 0x12);
            this.textCompanyCode.MaxLength = 15;
            this.textCompanyCode.Name = "textCompanyCode";
            this.textCompanyCode.Size = new Size(0x6c, 20);
            this.textCompanyCode.TabIndex = 0x27;
            this.textCompanyCode.KeyPress += new KeyPressEventHandler(this.textCompanyCode_KeyPress);
            this.label24.AutoSize = true;
            this.label24.Location = new Point(0x19, 0x15);
            this.label24.Name = "label24";
            this.label24.Size = new Size(100, 13);
            this.label24.TabIndex = 40;
            this.label24.Text = "SAP Location Code";
            this.textLine.Location = new Point(360, 0x61);
            this.textLine.MaxLength = 20;
            this.textLine.Name = "textLine";
            this.textLine.Size = new Size(0x6c, 20);
            this.textLine.TabIndex = 11;
            this.label69.AutoSize = true;
            this.label69.Location = new Point(0x147, 100);
            this.label69.Name = "label69";
            this.label69.Size = new Size(0x1b, 13);
            this.label69.TabIndex = 0x26;
            this.label69.Text = "Line";
            this.textUpload_Type.Location = new Point(360, 0x47);
            this.textUpload_Type.MaxLength = 20;
            this.textUpload_Type.Name = "textUpload_Type";
            this.textUpload_Type.Size = new Size(0x6c, 20);
            this.textUpload_Type.TabIndex = 10;
            this.label68.AutoSize = true;
            this.label68.Location = new Point(0x121, 0x4a);
            this.label68.Name = "label68";
            this.label68.Size = new Size(0x44, 13);
            this.label68.TabIndex = 0x24;
            this.label68.Text = "Upload Type";
            this.textSTO_Item.Location = new Point(360, 0xfd);
            this.textSTO_Item.MaxLength = 20;
            this.textSTO_Item.Name = "textSTO_Item";
            this.textSTO_Item.Size = new Size(0x6c, 20);
            this.textSTO_Item.TabIndex = 0x11;
            this.textGR_Discharge.Location = new Point(360, 0xe1);
            this.textGR_Discharge.MaxLength = 20;
            this.textGR_Discharge.Name = "textGR_Discharge";
            this.textGR_Discharge.Size = new Size(0x6c, 20);
            this.textGR_Discharge.TabIndex = 0x10;
            this.textTransport_Type.Location = new Point(360, 0xc7);
            this.textTransport_Type.MaxLength = 20;
            this.textTransport_Type.Name = "textTransport_Type";
            this.textTransport_Type.Size = new Size(0x6c, 20);
            this.textTransport_Type.TabIndex = 15;
            this.textGR_Storage.Location = new Point(360, 0xaf);
            this.textGR_Storage.MaxLength = 20;
            this.textGR_Storage.Name = "textGR_Storage";
            this.textGR_Storage.Size = new Size(0x6c, 20);
            this.textGR_Storage.TabIndex = 14;
            this.textGI_Batch.Location = new Point(360, 0x95);
            this.textGI_Batch.MaxLength = 20;
            this.textGI_Batch.Name = "textGI_Batch";
            this.textGI_Batch.Size = new Size(0x6c, 20);
            this.textGI_Batch.TabIndex = 13;
            this.textGI_Storage.Location = new Point(360, 0x7b);
            this.textGI_Storage.MaxLength = 20;
            this.textGI_Storage.Name = "textGI_Storage";
            this.textGI_Storage.Size = new Size(0x6c, 20);
            this.textGI_Storage.TabIndex = 12;
            this.label70.AutoSize = true;
            this.label70.Location = new Point(0x131, 0x100);
            this.label70.Name = "label70";
            this.label70.Size = new Size(0x34, 13);
            this.label70.TabIndex = 0x1b;
            this.label70.Text = "STO Item";
            this.label71.AutoSize = true;
            this.label71.Location = new Point(0x11b, 230);
            this.label71.Name = "label71";
            this.label71.Size = new Size(0x4a, 13);
            this.label71.TabIndex = 0x1a;
            this.label71.Text = "GR Discharge";
            this.label72.AutoSize = true;
            this.label72.Location = new Point(0x116, 0xca);
            this.label72.Name = "label72";
            this.label72.Size = new Size(0x4f, 13);
            this.label72.TabIndex = 0x19;
            this.label72.Text = "Transport Type";
            this.label73.AutoSize = true;
            this.label73.Location = new Point(0x126, 0xb2);
            this.label73.Name = "label73";
            this.label73.Size = new Size(0x3f, 13);
            this.label73.TabIndex = 0x18;
            this.label73.Text = "GR Storage";
            this.label74.AutoSize = true;
            this.label74.Location = new Point(0x134, 0x99);
            this.label74.Name = "label74";
            this.label74.Size = new Size(0x31, 13);
            this.label74.TabIndex = 0x17;
            this.label74.Text = "GI Batch";
            this.label75.AutoSize = true;
            this.label75.Location = new Point(0x12b, 0x7f);
            this.label75.Name = "label75";
            this.label75.Size = new Size(0x3a, 13);
            this.label75.TabIndex = 0x16;
            this.label75.Text = "GI Storage";
            this.textTransit_Storage.Location = new Point(360, 0x2c);
            this.textTransit_Storage.MaxLength = 20;
            this.textTransit_Storage.Name = "textTransit_Storage";
            this.textTransit_Storage.Size = new Size(0x6c, 20);
            this.textTransit_Storage.TabIndex = 9;
            this.label76.AutoSize = true;
            this.label76.Location = new Point(0x116, 0x2f);
            this.label76.Name = "label76";
            this.label76.Size = new Size(0x4f, 13);
            this.label76.TabIndex = 20;
            this.label76.Text = "Transit Storage";
            this.textSO_Item.Location = new Point(0x83, 0xfc);
            this.textSO_Item.MaxLength = 10;
            this.textSO_Item.Name = "textSO_Item";
            this.textSO_Item.Size = new Size(0x6c, 20);
            this.textSO_Item.TabIndex = 8;
            this.textStorage_Supp.Location = new Point(0x83, 0xe2);
            this.textStorage_Supp.MaxLength = 10;
            this.textStorage_Supp.Name = "textStorage_Supp";
            this.textStorage_Supp.Size = new Size(0x6c, 20);
            this.textStorage_Supp.TabIndex = 7;
            this.textPlant_Supp.Location = new Point(0x83, 0xc9);
            this.textPlant_Supp.MaxLength = 10;
            this.textPlant_Supp.Name = "textPlant_Supp";
            this.textPlant_Supp.Size = new Size(0x6c, 20);
            this.textPlant_Supp.TabIndex = 6;
            this.textMov_Type.Location = new Point(0x83, 0xad);
            this.textMov_Type.MaxLength = 3;
            this.textMov_Type.Name = "textMov_Type";
            this.textMov_Type.Size = new Size(0x6c, 20);
            this.textMov_Type.TabIndex = 5;
            this.textBatch.Location = new Point(0x83, 0x93);
            this.textBatch.MaxLength = 10;
            this.textBatch.Name = "textBatch";
            this.textBatch.Size = new Size(0x6c, 20);
            this.textBatch.TabIndex = 4;
            this.textUoM.Location = new Point(0x83, 0x7b);
            this.textUoM.MaxLength = 10;
            this.textUoM.Name = "textUoM";
            this.textUoM.Size = new Size(0x6c, 20);
            this.textUoM.TabIndex = 3;
            this.textStorage_Rcv.Location = new Point(0x83, 0x61);
            this.textStorage_Rcv.MaxLength = 10;
            this.textStorage_Rcv.Name = "textStorage_Rcv";
            this.textStorage_Rcv.Size = new Size(0x6c, 20);
            this.textStorage_Rcv.TabIndex = 2;
            this.textPlant_Rcv.Location = new Point(0x83, 0x47);
            this.textPlant_Rcv.MaxLength = 10;
            this.textPlant_Rcv.Name = "textPlant_Rcv";
            this.textPlant_Rcv.Size = new Size(0x6c, 20);
            this.textPlant_Rcv.TabIndex = 1;
            this.label67.AutoSize = true;
            this.label67.Location = new Point(0x54, 0xff);
            this.label67.Name = "label67";
            this.label67.Size = new Size(0x2d, 13);
            this.label67.TabIndex = 11;
            this.label67.Text = "SO Item";
            this.label66.AutoSize = true;
            this.label66.Location = new Point(0x18, 0xe5);
            this.label66.Name = "label66";
            this.label66.Size = new Size(0x69, 13);
            this.label66.TabIndex = 10;
            this.label66.Text = "Storage ( Supplying )";
            this.label65.AutoSize = true;
            this.label65.Location = new Point(0x25, 0xcc);
            this.label65.Name = "label65";
            this.label65.Size = new Size(0x5c, 13);
            this.label65.TabIndex = 9;
            this.label65.Text = "Plant ( Supplying )";
            this.label64.AutoSize = true;
            this.label64.Location = new Point(0x2d, 0xb2);
            this.label64.Name = "label64";
            this.label64.Size = new Size(0x54, 13);
            this.label64.TabIndex = 8;
            this.label64.Text = "Movement Type";
            this.label63.AutoSize = true;
            this.label63.Location = new Point(0x5e, 150);
            this.label63.Name = "label63";
            this.label63.Size = new Size(0x23, 13);
            this.label63.TabIndex = 7;
            this.label63.Text = "Batch";
            this.label62.AutoSize = true;
            this.label62.Location = new Point(0x63, 0x7e);
            this.label62.Name = "label62";
            this.label62.Size = new Size(30, 13);
            this.label62.TabIndex = 6;
            this.label62.Text = "UoM";
            this.label61.AutoSize = true;
            this.label61.Location = new Point(0x16, 100);
            this.label61.Name = "label61";
            this.label61.Size = new Size(0x6b, 13);
            this.label61.TabIndex = 5;
            this.label61.Text = "Storage ( Receiving )";
            this.label60.AutoSize = true;
            this.label60.Location = new Point(0x23, 0x4a);
            this.label60.Name = "label60";
            this.label60.Size = new Size(0x5e, 13);
            this.label60.TabIndex = 4;
            this.label60.Text = "Plant ( Receiving )";
            this.textBill_Lading.Location = new Point(0x83, 0x2c);
            this.textBill_Lading.MaxLength = 15;
            this.textBill_Lading.Name = "textBill_Lading";
            this.textBill_Lading.Size = new Size(0x6c, 20);
            this.textBill_Lading.TabIndex = 0;
            this.label59.AutoSize = true;
            this.label59.Location = new Point(0x3e, 0x2f);
            this.label59.Name = "label59";
            this.label59.Size = new Size(0x43, 13);
            this.label59.TabIndex = 2;
            this.label59.Text = "Bill of Lading";
            this.textLocName.Location = new Point(0x99, 70);
            this.textLocName.Name = "textLocName";
            this.textLocName.Size = new Size(250, 20);
            this.textLocName.TabIndex = 0x12;
            this.label4.Location = new Point(0x12, 70);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x84, 20);
            this.label4.TabIndex = 0x11;
            this.label4.Text = "Location Name";
            this.label4.TextAlign = ContentAlignment.TopRight;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1a7, 0x9d);
            base.ControlBox = false;
            base.Controls.Add(this.textLocName);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label58);
            base.Controls.Add(this.panel8);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.textLocCode);
            base.Controls.Add(this.textCoyCode);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.KeyPreview = true;
            base.Name = "FormLocationEntry";
            this.Text = "Form Location Entry";
            base.Load += new EventHandler(this.FormLocationEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormLocationEntry_KeyPress);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textCompanyCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textLocCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.label2.Text = Resource.Setting_003;
            this.label3.Text = Resource.Setting_004;
            this.label58.Text = this.sapIDSYS + Resource.Setting_074;
            this.label24.Text = this.sapIDSYS + Resource.Setting_075;
            this.label69.Text = Resource.Lbl_Line;
            this.label68.Text = Resource.Setting_086;
            this.label70.Text = Resource.Setting_091;
            this.label71.Text = Resource.Setting_090;
            this.label72.Text = Resource.Setting_089;
            this.label73.Text = Resource.Setting_088;
            this.label74.Text = Resource.Lbl_GI_Batch;
            this.label75.Text = Resource.Setting_087;
            this.label76.Text = Resource.Setting_085;
            this.label67.Text = Resource.Setting_084;
            this.label66.Text = Resource.Setting_083;
            this.label65.Text = Resource.Setting_082;
            this.label64.Text = Resource.Setting_081;
            this.label63.Text = Resource.Setting_080;
            this.label62.Text = Resource.Setting_079;
            this.label61.Text = Resource.Setting_078;
            this.label60.Text = Resource.Setting_077;
            this.label59.Text = Resource.Setting_076;
            this.label4.Text = Resource.Col_Location_Name;
            this.buttonSave.Text = Resource.Save;
            this.button3.Text = Resource.Menu_Cancel;
            this.Text = Resource.Title_Location_Entry;
        }
    }
}

