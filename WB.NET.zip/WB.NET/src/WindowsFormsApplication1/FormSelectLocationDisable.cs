﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Globalization;
    using System.Windows.Forms;

    public class FormSelectLocationDisable : Form
    {
        private const int DISABLE_TIME_INTERVAL = 30;
        public const string separator = "|";
        private string requested_Token_No = "";
        public string ToBeDisabledCondition = "";
        public bool submitted = false;
        public string start_inactive_time = "";
        public string end_inactive_time = "";
        public List<string> appliedLocationList = new List<string>();
        private string[] hasil = new string[3];
        private string approve;
        private string approve_type;
        private string approveBy1;
        private string approveBy2;
        private string Approve_Reason;
        private IContainer components = null;
        private DataGridView dgvCopy;
        private CheckBox checkAll;
        private Button buttonProcess;
        private Button buttonCancel;
        public Label label1;
        private Label label2;
        private Label label3;
        private DateTimePicker dtp_start_inactive_date;
        private DateTimePicker dtp_end_inactive_date;
        public Label label4;
        private ComboBox comboBox_start_inactive_time;
        private ComboBox comboBox_end_inactive_time;
        private DataGridViewCheckBoxColumn Selected;
        private DataGridViewTextBoxColumn coy_;
        private DataGridViewTextBoxColumn loc_;

        public FormSelectLocationDisable()
        {
            this.InitializeComponent();
            List<string> listTimeByInterval = this.GetListTimeByInterval(30);
            List<string> list2 = this.GetListTimeByInterval(30);
            this.comboBox_start_inactive_time.DataSource = listTimeByInterval;
            this.comboBox_end_inactive_time.DataSource = list2;
        }

        private void append_data()
        {
            bool flag = false;
            string sqltext = "";
            WBTable table = new WBTable();
            sqltext = "select b.uniq, b.Coy, b.Location_Code, b.Token_No, b.requested_start_inactive_time, b.requested_end_inactive_time from (select TOP 1 * from wb_token \r\n                    where ((completed is null or completed = 'N') and Token_Code = 'DISABLE_CONDITION' and key_1 = '" + this.ToBeDisabledCondition + "')\r\n                    order by uniq desc) a\r\n                    inner join\r\n                    wb_token_disable_detail b\r\n                    on a.Token_No = b.Token_No";
            table.OpenTable("wb_token", sqltext, WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                foreach (DataRow row in table.DT.Rows)
                {
                    int num = 0;
                    while (true)
                    {
                        if (num >= this.dgvCopy.Rows.Count)
                        {
                            break;
                        }
                        if ((this.dgvCopy.Rows[num].Cells["coy_"].Value.ToString() == row["Coy"].ToString()) && (this.dgvCopy.Rows[num].Cells["loc_"].Value.ToString() == row["Location_Code"].ToString()))
                        {
                            this.requested_Token_No = row["Token_No"].ToString();
                            this.dgvCopy.Rows[num].Cells["selected"].Value = true;
                            this.dtp_start_inactive_date.Value = Convert.ToDateTime(row["requested_start_inactive_time"]);
                            this.dtp_end_inactive_date.Value = Convert.ToDateTime(row["requested_end_inactive_time"]);
                            this.comboBox_start_inactive_time.SelectedIndex = this.comboBox_start_inactive_time.FindStringExact(Convert.ToDateTime(row["requested_start_inactive_time"]).ToString("HH:mm"));
                            this.comboBox_end_inactive_time.SelectedIndex = this.comboBox_end_inactive_time.FindStringExact(Convert.ToDateTime(row["requested_end_inactive_time"]).ToString("HH:mm"));
                            flag = true;
                        }
                        num++;
                    }
                }
                if (flag)
                {
                    this.dgvCopy.Enabled = false;
                    this.dgvCopy.ForeColor = Color.Gray;
                    this.dgvCopy.ColumnHeadersDefaultCellStyle.ForeColor = Color.Gray;
                    this.dgvCopy.EnableHeadersVisualStyles = false;
                    this.dgvCopy.ColumnHeadersDefaultCellStyle.ForeColor = SystemColors.ControlDark;
                    this.checkAll.Enabled = false;
                    this.dtp_start_inactive_date.Enabled = false;
                    this.dtp_end_inactive_date.Enabled = false;
                    this.comboBox_start_inactive_time.Enabled = false;
                    this.comboBox_end_inactive_time.Enabled = false;
                }
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            this.start_inactive_time = this.dtp_start_inactive_date.Value.ToString("yyyy-MM-dd") + " " + this.comboBox_start_inactive_time.SelectedValue.ToString() + ":00";
            this.end_inactive_time = this.dtp_end_inactive_date.Value.ToString("yyyy-MM-dd") + " " + this.comboBox_end_inactive_time.SelectedValue.ToString() + ":00";
            this.appliedLocationList = this.getAppliedLocationListString();
            bool flag = false;
            int num = 0;
            while (true)
            {
                if (num < this.dgvCopy.Rows.Count)
                {
                    if (this.dgvCopy.Rows[num].Cells["selected"].Value.ToString() != "True")
                    {
                        num++;
                        continue;
                    }
                    flag = true;
                }
                if (!flag)
                {
                    MessageBox.Show("Please choose at least 1 location!", Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    DateTime time = DateTime.ParseExact(this.comboBox_start_inactive_time.SelectedValue.ToString() + ":00", "HH:mm:00", CultureInfo.InvariantCulture);
                    DateTime time2 = DateTime.ParseExact(this.comboBox_end_inactive_time.SelectedValue.ToString() + ":00", "HH:mm:00", CultureInfo.InvariantCulture);
                    DateTime now = DateTime.Now;
                    if (this.dtp_start_inactive_date.Value.ToString() == this.dtp_end_inactive_date.Value.ToString())
                    {
                        if ((time >= time2) || ((now > time) && (now > time2)))
                        {
                            MessageBox.Show("Please choose time based on one of the following criterias:\na. Start Time must not be greater than End Time.\nb. Start Time and End Time must not be greater than Current Time.\nc. Start Date or End Date must not be lower than Current Date.", Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            break;
                        }
                    }
                    else if ((this.dtp_start_inactive_date.Value < DateTime.Now.Date) || (this.dtp_end_inactive_date.Value < DateTime.Now.Date))
                    {
                        MessageBox.Show("Please choose time based on one of the following criterias:\na. Start Time must not be greater than End Time.\nb. Start Time and End Time must not be greater than Current Time.\nc. Start Date or End Date must not be lower than Current Date.", Resource.Mes_Warning_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        break;
                    }
                    Dictionary<string, object> dictionary = new Dictionary<string, object>();
                    WBTable table = new WBTable();
                    dictionary.Add("appliedLocation", this.appliedLocationList);
                    dictionary.Add("requested_start_inactive_time", this.dtp_start_inactive_date.Value.ToString("yyyy-MM-dd") + " " + this.comboBox_start_inactive_time.SelectedValue.ToString());
                    dictionary.Add("requested_end_inactive_time", this.dtp_end_inactive_date.Value.ToString("yyyy-MM-dd") + " " + this.comboBox_end_inactive_time.SelectedValue.ToString());
                    dictionary.Add("ToBeDisabledCondition", this.ToBeDisabledCondition);
                    dictionary.Add("disableSeparator", "|");
                    this.hasil = table.tokenOrApp(this.ToBeDisabledCondition, "", "DISABLE_CONDITION", "TOKEN_DISABLE_CONDITION", "DISABLE_CONDITION", "E", "", dictionary);
                    if ((this.hasil[0] == "completed") || (this.hasil[0] == "process"))
                    {
                        this.approve_type = "DISABLE_CONDITION";
                        this.approveBy1 = this.hasil[1];
                        this.Approve_Reason = this.hasil[2];
                        if (this.hasil[0] != "completed")
                        {
                            this.start_inactive_time = "";
                            this.end_inactive_time = "";
                        }
                        this.submitted = true;
                        Cursor.Current = Cursors.Default;
                        base.Close();
                    }
                }
                break;
            }
        }

        private void checkAll_CheckedChanged(object sender, EventArgs e)
        {
            if (this.dgvCopy.Rows.Count > 0)
            {
                if (this.checkAll.Checked)
                {
                    int num = 0;
                    while (true)
                    {
                        if (num >= this.dgvCopy.Rows.Count)
                        {
                            break;
                        }
                        this.dgvCopy.Rows[num].Cells["selected"].Value = true;
                        num++;
                    }
                }
                else
                {
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= this.dgvCopy.Rows.Count)
                        {
                            break;
                        }
                        this.dgvCopy.Rows[num2].Cells["selected"].Value = false;
                        num2++;
                    }
                }
            }
        }

        private void dgvCopy_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if ((e.ColumnIndex == this.Selected.Index) && (e.RowIndex != -1))
            {
                this.dgvCopy.EndEdit();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void f_load()
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_warning_trace", "select distinct Coy, Location_code as location_code from wb_Condition where Condition_code = '" + this.ToBeDisabledCondition + "' and(allow_disable is not null and allow_disable = 'Y') ORDER BY coy, location_code", WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                string str = "False";
                string[] values = new string[] { str, row["Coy"].ToString(), row["Location_code"].ToString() };
                this.dgvCopy.Rows.Add(values);
            }
            this.dtp_start_inactive_date.Value = DateTime.Now;
            this.dtp_end_inactive_date.Value = DateTime.Now;
        }

        private void FormSelectLocationDisable_Load(object sender, EventArgs e)
        {
            this.f_load();
            this.append_data();
        }

        private List<string> getAppliedLocationListString()
        {
            List<string> list = new List<string>();
            if (this.dgvCopy.Rows.Count > 0)
            {
                int num = 0;
                while (true)
                {
                    if (num >= this.dgvCopy.Rows.Count)
                    {
                        break;
                    }
                    if (this.dgvCopy.Rows[num].Cells["selected"].Value.ToString() == "True")
                    {
                        list.Add(this.dgvCopy.Rows[num].Cells["coy_"].Value.ToString() + "-" + this.dgvCopy.Rows[num].Cells["loc_"].Value.ToString());
                    }
                    num++;
                }
            }
            return list;
        }

        private List<string> GetListTimeByInterval(int minutes)
        {
            DateTime time = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
            DateTime time2 = time.AddDays(1.0);
            List<string> list = new List<string>();
            while (true)
            {
                list.Add(time.ToString("HH:mm"));
                time = time.AddMinutes((double) minutes);
                if (time >= time2)
                {
                    return list;
                }
            }
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.dgvCopy = new DataGridView();
            this.Selected = new DataGridViewCheckBoxColumn();
            this.coy_ = new DataGridViewTextBoxColumn();
            this.loc_ = new DataGridViewTextBoxColumn();
            this.checkAll = new CheckBox();
            this.buttonProcess = new Button();
            this.buttonCancel = new Button();
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.dtp_start_inactive_date = new DateTimePicker();
            this.dtp_end_inactive_date = new DateTimePicker();
            this.label4 = new Label();
            this.comboBox_start_inactive_time = new ComboBox();
            this.comboBox_end_inactive_time = new ComboBox();
            ((ISupportInitialize) this.dgvCopy).BeginInit();
            base.SuspendLayout();
            this.dgvCopy.AllowUserToAddRows = false;
            this.dgvCopy.AllowUserToDeleteRows = false;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgvCopy.ColumnHeadersDefaultCellStyle = style;
            this.dgvCopy.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridViewColumn[] dataGridViewColumns = new DataGridViewColumn[] { this.Selected, this.coy_, this.loc_ };
            this.dgvCopy.Columns.AddRange(dataGridViewColumns);
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ActiveCaptionText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgvCopy.DefaultCellStyle = style2;
            this.dgvCopy.Location = new Point(0x10, 70);
            this.dgvCopy.Margin = new Padding(4);
            this.dgvCopy.MultiSelect = false;
            this.dgvCopy.Name = "dgvCopy";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgvCopy.RowHeadersDefaultCellStyle = style3;
            this.dgvCopy.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvCopy.Size = new Size(0x211, 320);
            this.dgvCopy.TabIndex = 1;
            this.dgvCopy.CellMouseUp += new DataGridViewCellMouseEventHandler(this.dgvCopy_CellMouseUp);
            this.Selected.HeaderText = "Select";
            this.Selected.Name = "Selected";
            this.Selected.Width = 0x44;
            this.coy_.HeaderText = "Company Code";
            this.coy_.Name = "coy_";
            this.coy_.ReadOnly = true;
            this.coy_.Width = 210;
            this.loc_.HeaderText = "Location Code";
            this.loc_.Name = "loc_";
            this.loc_.ReadOnly = true;
            this.loc_.Width = 210;
            this.checkAll.AutoSize = true;
            this.checkAll.Location = new Point(0x10, 0x2a);
            this.checkAll.Margin = new Padding(4);
            this.checkAll.Name = "checkAll";
            this.checkAll.Size = new Size(0x58, 0x15);
            this.checkAll.TabIndex = 2;
            this.checkAll.Text = "Select All";
            this.checkAll.UseVisualStyleBackColor = true;
            this.checkAll.CheckedChanged += new EventHandler(this.checkAll_CheckedChanged);
            this.buttonProcess.Location = new Point(0x139, 0x1ff);
            this.buttonProcess.Margin = new Padding(4);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(0x70, 0x26);
            this.buttonProcess.TabIndex = 3;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.buttonCancel.Location = new Point(0x1b1, 0x1ff);
            this.buttonCancel.Margin = new Padding(4);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x70, 0x26);
            this.buttonCancel.TabIndex = 4;
            this.buttonCancel.Text = "Close";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(12, 15);
            this.label1.Margin = new Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0xf2, 0x11);
            this.label1.TabIndex = 5;
            this.label1.Text = "Select location to disable the feature:";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(12, 0x1b6);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x49, 0x11);
            this.label2.TabIndex = 6;
            this.label2.Text = "Start Time";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(13, 0x1d4);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x44, 0x11);
            this.label3.TabIndex = 7;
            this.label3.Text = "End Time";
            this.dtp_start_inactive_date.Format = DateTimePickerFormat.Short;
            this.dtp_start_inactive_date.Location = new Point(130, 0x1b4);
            this.dtp_start_inactive_date.Name = "dtp_start_inactive_date";
            this.dtp_start_inactive_date.Size = new Size(0x76, 0x16);
            this.dtp_start_inactive_date.TabIndex = 8;
            this.dtp_start_inactive_date.Value = new DateTime(0x7e2, 4, 0x11, 0, 0, 0, 0);
            this.dtp_end_inactive_date.Format = DateTimePickerFormat.Short;
            this.dtp_end_inactive_date.Location = new Point(130, 0x1d2);
            this.dtp_end_inactive_date.Name = "dtp_end_inactive_date";
            this.dtp_end_inactive_date.Size = new Size(0x76, 0x16);
            this.dtp_end_inactive_date.TabIndex = 9;
            this.dtp_end_inactive_date.Value = new DateTime(0x7e2, 4, 0x11, 0, 0, 0, 0);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(12, 0x199);
            this.label4.Margin = new Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0xdb, 0x11);
            this.label4.TabIndex = 10;
            this.label4.Text = "Select time to disable the feature:";
            this.comboBox_start_inactive_time.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboBox_start_inactive_time.FormattingEnabled = true;
            this.comboBox_start_inactive_time.Location = new Point(0x108, 0x1b3);
            this.comboBox_start_inactive_time.Name = "comboBox_start_inactive_time";
            this.comboBox_start_inactive_time.Size = new Size(0x5d, 0x18);
            this.comboBox_start_inactive_time.TabIndex = 11;
            this.comboBox_end_inactive_time.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboBox_end_inactive_time.FormattingEnabled = true;
            this.comboBox_end_inactive_time.Location = new Point(0x108, 0x1d1);
            this.comboBox_end_inactive_time.Name = "comboBox_end_inactive_time";
            this.comboBox_end_inactive_time.Size = new Size(0x5d, 0x18);
            this.comboBox_end_inactive_time.TabIndex = 12;
            base.AutoScaleDimensions = new SizeF(8f, 16f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x22e, 0x232);
            base.ControlBox = false;
            base.Controls.Add(this.comboBox_end_inactive_time);
            base.Controls.Add(this.comboBox_start_inactive_time);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.dtp_end_inactive_date);
            base.Controls.Add(this.dtp_start_inactive_date);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonProcess);
            base.Controls.Add(this.checkAll);
            base.Controls.Add(this.dgvCopy);
            base.Margin = new Padding(4);
            base.Name = "FormSelectLocationDisable";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Select Location to Disable Feature";
            base.Load += new EventHandler(this.FormSelectLocationDisable_Load);
            ((ISupportInitialize) this.dgvCopy).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

