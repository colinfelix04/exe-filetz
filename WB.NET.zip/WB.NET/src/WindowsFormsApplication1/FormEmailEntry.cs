﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormEmailEntry : Form
    {
        public WBTable zTable;
        public WBTable TableEmailCode;
        public string pMode;
        public string OldCode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public WBTable trans = new WBTable();
        private IContainer components = null;
        public ComboBox cbEmail_Code;
        private Label label1;
        private TextBox txtSubject;
        private Label label2;
        private TextBox txtTo;
        private Label label3;
        private Label label4;
        private TextBox txtCC;
        private Button butCancel;
        private Button butSave;
        private Button btnTest;
        private TextBox textDepartment;
        private Label labelDepartment;

        public FormEmailEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            WBMail mail = new WBMail {
                To = this.txtTo.Text,
                CC = this.txtCC.Text
            };
            string[] textArray1 = new string[] { "TESTING ", this.cbEmail_Code.Text, " ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
            mail.Subject = string.Concat(textArray1);
            mail.Body = "Dear All, <br><br>This is testing email. Please ignore.<br>Thank You. ";
            mail.SendMail();
            MessageBox.Show(Resource.Mes_143);
        }

        private void butCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void butSave_Click(object sender, EventArgs e)
        {
            if (this.cbEmail_Code.Text != "")
            {
                WBTable table = new WBTable();
                string[] textArray1 = new string[] { " AND Department = '", this.textDepartment.Text.Trim(), "' AND ( Email_Code ='", this.cbEmail_Code.Text.Trim(), "')" };
                table.OpenTable("wb_email_master", "SELECT Uniq FROM wb_email_master WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || (this.pMode != "ADD"))
                {
                    table.Dispose();
                    if (this.pMode == "EDIT")
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = Resource.Col_Email_Code },
                            textRefNo = { Text = this.cbEmail_Code.Text },
                            Text = Resource.Title_Change_Reason,
                            label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                        }
                        else
                        {
                            return;
                        }
                    }
                    Cursor.Current = Cursors.WaitCursor;
                    this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                    this.zTable.ReOpen();
                    if (this.pMode == "ADD")
                    {
                        this.zTable.DR = this.zTable.DT.NewRow();
                    }
                    else
                    {
                        this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                        this.logKey = this.zTable.DR["uniq"].ToString();
                        this.zTable.DR.BeginEdit();
                    }
                    this.zTable.DR["Coy"] = WBData.sCoyCode;
                    this.zTable.DR["Location_Code"] = WBData.sLocCode;
                    this.zTable.DR["Email_Code"] = this.cbEmail_Code.Text;
                    this.zTable.DR["Subject"] = this.txtSubject.Text;
                    this.zTable.DR["Email_To"] = this.txtTo.Text;
                    this.zTable.DR["Email_CC"] = this.txtCC.Text;
                    this.zTable.DR["Department"] = this.textDepartment.Text.Trim();
                    if (this.pMode == "ADD")
                    {
                        this.zTable.DT.Rows.Add(this.zTable.DR);
                    }
                    else
                    {
                        this.zTable.DR.EndEdit();
                    }
                    this.zTable.Save();
                    if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
                    {
                        if (this.pMode == "ADD")
                        {
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_email_master", "SELECT uniq FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND email_code = '" + this.cbEmail_Code.Text + "'"), WBData.conn);
                            this.logKey = table2.DT.Rows[0]["uniq"].ToString();
                            table2.Dispose();
                        }
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_email_master", this.logKey, logField, logValue);
                    }
                    this.saved = true;
                    Cursor.Current = Cursors.Default;
                    base.Close();
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_142);
                    this.cbEmail_Code.Focus();
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormEmailEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormEmailEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (WBSetting.region == "0")
            {
                this.labelDepartment.Visible = false;
                this.textDepartment.Text = "";
            }
            WBTable table = new WBTable();
            table.OpenTable("wb_email_code", "SELECT * FROM wb_email_code WHERE 1 = 1", WBData.conn);
            this.cbEmail_Code.Items.Clear();
            int num = 0;
            while (true)
            {
                if (num >= table.DT.Rows.Count)
                {
                    if (this.pMode == "ADD")
                    {
                        this.cbEmail_Code.Enabled = true;
                    }
                    else
                    {
                        this.cbEmail_Code.Enabled = false;
                        this.cbEmail_Code.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Email_Code"].Value.ToString();
                        this.txtSubject.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Subject"].Value.ToString();
                        this.txtTo.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Email_To"].Value.ToString();
                        this.txtCC.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Email_CC"].Value.ToString();
                        this.textDepartment.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Department"].Value.ToString();
                    }
                    if (this.pMode == "VIEW")
                    {
                        foreach (Control control in base.Controls)
                        {
                            control.Enabled = false;
                        }
                        this.butCancel.Text = Resource.Btn_Close;
                        this.butCancel.Enabled = true;
                    }
                    return;
                }
                DataRow row = table.DT.Rows[num];
                this.cbEmail_Code.Items.Add(row[0].ToString().Trim());
                num++;
            }
        }

        private void InitializeComponent()
        {
            this.cbEmail_Code = new ComboBox();
            this.label1 = new Label();
            this.txtSubject = new TextBox();
            this.label2 = new Label();
            this.txtTo = new TextBox();
            this.label3 = new Label();
            this.label4 = new Label();
            this.txtCC = new TextBox();
            this.butCancel = new Button();
            this.butSave = new Button();
            this.btnTest = new Button();
            this.textDepartment = new TextBox();
            this.labelDepartment = new Label();
            base.SuspendLayout();
            this.cbEmail_Code.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbEmail_Code.FormattingEnabled = true;
            this.cbEmail_Code.Location = new Point(0x4e, 12);
            this.cbEmail_Code.Name = "cbEmail_Code";
            this.cbEmail_Code.Size = new Size(0x9c, 0x15);
            this.cbEmail_Code.TabIndex = 0;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(60, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Email Code";
            this.txtSubject.Location = new Point(0x4e, 0x27);
            this.txtSubject.Name = "txtSubject";
            this.txtSubject.Size = new Size(0x19c, 20);
            this.txtSubject.TabIndex = 2;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(12, 0x2a);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x2b, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Subject";
            this.txtTo.Location = new Point(0x4e, 0x41);
            this.txtTo.Multiline = true;
            this.txtTo.Name = "txtTo";
            this.txtTo.Size = new Size(0x19c, 70);
            this.txtTo.TabIndex = 4;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(12, 0x44);
            this.label3.Name = "label3";
            this.label3.Size = new Size(20, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "To";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(12, 0x90);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x15, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "CC";
            this.txtCC.Location = new Point(0x4e, 0x8d);
            this.txtCC.Multiline = true;
            this.txtCC.Name = "txtCC";
            this.txtCC.Size = new Size(0x19c, 70);
            this.txtCC.TabIndex = 6;
            this.butCancel.Location = new Point(0x19f, 0xd9);
            this.butCancel.Name = "butCancel";
            this.butCancel.Size = new Size(0x4b, 0x17);
            this.butCancel.TabIndex = 11;
            this.butCancel.Text = "&Cancel";
            this.butCancel.UseVisualStyleBackColor = true;
            this.butCancel.Click += new EventHandler(this.butCancel_Click);
            this.butSave.Location = new Point(0x13c, 0xd9);
            this.butSave.Name = "butSave";
            this.butSave.Size = new Size(0x4b, 0x17);
            this.butSave.TabIndex = 10;
            this.butSave.Text = "&Save";
            this.butSave.UseVisualStyleBackColor = true;
            this.butSave.Click += new EventHandler(this.butSave_Click);
            this.btnTest.Location = new Point(12, 0xd9);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new Size(0x4b, 0x17);
            this.btnTest.TabIndex = 12;
            this.btnTest.Text = "Test Send";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new EventHandler(this.btnTest_Click);
            this.textDepartment.Location = new Point(0x159, 12);
            this.textDepartment.MaxLength = 50;
            this.textDepartment.Name = "textDepartment";
            this.textDepartment.Size = new Size(0x91, 20);
            this.textDepartment.TabIndex = 0x11;
            this.textDepartment.KeyPress += new KeyPressEventHandler(this.textDepartment_KeyPress);
            this.labelDepartment.AutoSize = true;
            this.labelDepartment.Location = new Point(0x10c, 15);
            this.labelDepartment.Name = "labelDepartment";
            this.labelDepartment.Size = new Size(0x3e, 13);
            this.labelDepartment.TabIndex = 0x10;
            this.labelDepartment.Text = "Department";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1fb, 0xf9);
            base.ControlBox = false;
            base.Controls.Add(this.textDepartment);
            base.Controls.Add(this.labelDepartment);
            base.Controls.Add(this.btnTest);
            base.Controls.Add(this.butCancel);
            base.Controls.Add(this.butSave);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.txtCC);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.txtTo);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.txtSubject);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.cbEmail_Code);
            base.Name = "FormEmailEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormEmailEntry";
            base.Load += new EventHandler(this.FormEmailEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormEmailEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textDepartment_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.label1.Text = Resource.Col_Email_Code;
            this.label2.Text = Resource.Setting_055;
            this.label3.Text = Resource.Setting_053;
            this.label4.Text = Resource.Setting_054;
            this.labelDepartment.Text = Resource.Col_Department;
            this.butCancel.Text = Resource.Btn_Cancel;
            this.butSave.Text = Resource.Btn_Save;
            this.btnTest.Text = Resource.Btn_Test_Send;
        }
    }
}

