﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormCommodityEntry : Form
    {
        public string pMode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool needcheck = false;
        public bool ReplaceAll = false;
        public string OldCode;
        public WBTable tblComm;
        public WBTable tblCommDetail;
        public WBTable tblQC;
        public WBTable tblCommGrading;
        private string[] zwbRow = new string[20];
        private string[] zwbResult = new string[3];
        private string[] hasil = new string[3];
        private DataGridView grading;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private string code = "";
        private string name = "";
        private string uom = "";
        private string m_type = "";
        private string t_type = "";
        private string gw = "";
        private string nw = "";
        private string tol = "";
        public Label label1;
        public Label label2;
        public TextBox textCode;
        public TextBox textName;
        public GroupBox groupType;
        public RadioButton radioFFB;
        public RadioButton radioStandard;
        public GroupBox groupBox2;
        public GroupBox groupTrade;
        public RadioButton radioNonTrade;
        public RadioButton radioTrade;
        public GroupBox groupGunny;
        public RadioButton radioGunnyNo;
        public RadioButton radioGunnyYes;
        public GroupBox groupGrading;
        public RadioButton radioGradingNo;
        public RadioButton radioGradingYes;
        public GroupBox groupBox8;
        public Button buttonSave;
        public Button buttonCancel;
        public Button buttonQuality;
        public GroupBox groupBox1;
        public Label label6;
        public TextBox textConvUnit;
        public TextBox textConvValue;
        public Label label7;
        public Label labelConvValue;
        public TextBox textConvTolerance;
        public Label label9;
        public CheckBox checkConvert;
        public Label labelConvTolerance;
        public GroupBox groupBox3;
        public RadioButton radioPostNo;
        public RadioButton radioPostYes;
        public Button buttonGrading;
        public RadioButton radioCopra;
        private TabPage tabPage1;
        public Label label4;
        public TextBox textFormISO;
        public Label label5;
        public TextBox textSAPCode;
        public Label label8;
        private TabPage tabPage2;
        public Label label10;
        public TextBox textNetto;
        public Label label11;
        public Label label12;
        public TextBox textGrossMax;
        public Label label13;
        public Label label14;
        public TextBox textGrossMin;
        public Label label15;
        private Label label16;
        public TextBox textBATCH;
        public CheckBox checkTare;
        public RadioButton radioSugar;
        public GroupBox groupBoxBulk;
        public RadioButton radioNonBulk;
        public RadioButton radioBulk;
        private TabPage tabPage3;
        public Label label17;
        public TextBox textNettW;
        public Label lblNettW;
        public Label lblTol;
        public Label label21;
        public TextBox textGrossW;
        public Label lblGrossW;
        private Label labelpersen;
        public TextBox textTolerance;
        public TabControl tabControl1;
        public Button btnAdopt;
        public Label label3;
        public TextBox textUnit;
        private ToolTip toolTipInformation;
        private IContainer components;
        public GroupBox groupBox4;
        public RadioButton radioConNo;
        public RadioButton radioConYes;
        public RadioButton radioSolid;
        public RadioButton radioLiquid;

        public FormCommodityEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        public void adoptDataIDSYS()
        {
            try
            {
                WBIDSYSIntegrator integrator = new WBIDSYSIntegrator();
                string url = integrator.getURL("IDSYS_ADOPT_COMMODITY");
                if (url != "")
                {
                    string[] textArray1 = new string[] { "{coy:'", WBSetting.CoySAP, "',comm_code:'", this.textSAPCode.Text, "'}" };
                    bool err = false;
                    Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                    dictionary = integrator.getDataFromIDSYS(url, string.Concat(textArray1), out err);
                    if (!err)
                    {
                        if (dictionary["data"].Count <= 0)
                        {
                            MessageBox.Show(Resource.IDSY_Adopt_Failled, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            foreach (Dictionary<string, string> dictionary2 in dictionary["data"])
                            {
                                this.code = dictionary2["code"];
                                this.name = dictionary2["name"];
                                this.uom = dictionary2["uom"];
                                this.m_type = dictionary2["m_type"];
                                this.t_type = dictionary2["t_type"];
                                this.gw = dictionary2["gw"];
                                this.nw = dictionary2["nw"];
                                this.tol = dictionary2["tol"];
                            }
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    return;
                }
                this.textCode.Text = this.code;
                this.textName.Text = this.name;
                this.textUnit.Text = this.uom;
                this.textGrossW.Text = this.gw;
                this.textNettW.Text = this.nw;
                this.textTolerance.Text = this.tol;
                if (this.t_type == "T")
                {
                    this.radioTrade.Checked = true;
                }
                else
                {
                    this.radioNonTrade.Checked = true;
                }
                if (this.m_type == "BULK")
                {
                    this.radioBulk.Checked = true;
                }
                else
                {
                    this.radioNonBulk.Checked = true;
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Resource.Title_003 + " " + exception.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void btnAdopt_Click(object sender, EventArgs e)
        {
            if (!WBSetting.activeMulesoftIntegration)
            {
                if (WBSetting.integrationIDSYS)
                {
                    this.adoptDataIDSYS();
                }
                else
                {
                    try
                    {
                        WBSetting.OpenSetting();
                        RfcConfigParameters parameters = new RfcConfigParameters();
                        parameters.Add("NAME", "TEST_SAP");
                        parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                        parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                        parameters.Add("SYSNR", "00");
                        parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                        parameters.Add("IDLE_TIMEOUT", "10");
                        parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                        parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                        parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                        parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                        RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                        string str4 = "EN";
                        IRfcFunction function = destination.Repository.CreateFunction("ZWB_GET_MATNR");
                        function.SetValue("MATNR", this.textSAPCode.Text.Trim());
                        function.SetValue("SPRAS", str4);
                        function.Invoke(destination);
                        string str2 = function.GetString("MATNR");
                        str4 = function.GetString("SPRAS");
                        string str3 = function.GetString("MAKTX");
                        this.textName.Text = str3;
                        this.needcheck = false;
                    }
                    catch (RfcInvalidParameterException exception)
                    {
                        MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", Resource.Mes_Error_Caps + " <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    catch (RfcCommunicationException exception2)
                    {
                        if (WBUser.UserLevel == "1")
                        {
                            MessageBox.Show(exception2.ToString(), Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                    catch (RfcBaseException exception3)
                    {
                        if (WBUser.UserLevel == "1")
                        {
                            MessageBox.Show(exception3.ToString(), Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                    catch (Exception exception4)
                    {
                        MessageBox.Show(Resource.Title_003 + " " + exception4.ToString(), Resource.Mes_Error_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                return;
            }
            else
            {
                WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                string str = integrator.getURL("ZWB_GET_MATNR");
                if (str != "")
                {
                    string[] textArray1 = new string[] { str, "?matnr=", this.textSAPCode.Text, "&zwb_loc=", WBSetting.CoySAP };
                    bool err = false;
                    Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                    string[] resultHeaderName = new string[] { "ERRORS", "I_MATNR", "MESSAGE_ID" };
                    dictionary = integrator.getDataFromMulesoft(string.Concat(textArray1), resultHeaderName, out err);
                    if (!err)
                    {
                        if (dictionary["ERRORS"].Count > 0)
                        {
                            MessageBox.Show("Error from SAP : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            foreach (Dictionary<string, string> dictionary2 in dictionary["I_MATNR"])
                            {
                                this.textName.Text = dictionary2["MAKTX"];
                            }
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormCommodityEntryGrading grading = new FormCommodityEntryGrading {
                comm_code = this.textCode.Text,
                tblCommGrading = this.tblCommGrading
            };
            if (this.pMode == "VIEW")
            {
                grading.view = true;
            }
            grading.ShowDialog();
            this.changeReason = grading.changeReason;
            this.tblCommGrading = grading.tblCommGrading;
            grading.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.thisclose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_commodity", "Select * From wb_commodity where " + WBData.CompanyLocation(" and ( Comm_Code='" + this.textCode.Text.Trim() + "' )"), WBData.conn);
            FormCommodityEntryAdvanced advanced = new FormCommodityEntryAdvanced();
            if (table.DT.Rows.Count > 0)
            {
                advanced.Get_From_SAP = table.DT.Rows[0]["Get_From_SAP"].ToString();
            }
            advanced.CommCode = this.textCode.Text;
            advanced.CommStandard = this.radioStandard.Checked;
            advanced.CommCopra = this.radioCopra.Checked;
            advanced.UsingGunny = this.radioGunnyYes.Checked;
            advanced.tblComm = this.tblComm;
            advanced.tblCommDetail = this.tblCommDetail;
            advanced.tblQC = this.tblQC;
            table.Close();
            table.Dispose();
            if (this.pMode == "VIEW")
            {
                advanced.view = true;
            }
            advanced.ShowDialog();
            this.tblCommDetail = advanced.tblCommDetail;
            this.tblQC = advanced.tblQC;
            advanced.Dispose();
        }

        private void buttonSave_Click_1(object sender, EventArgs e)
        {
            WBTable table3;
            TextBox[] aText = new TextBox[] { this.textCode, this.textName, this.textUnit };
            if (!Program.CheckEmpty(aText))
            {
                if (((this.textGrossW.Text == "0") || (this.textGrossW.Text == "")) ? ((this.textNettW.Text != "0") && (this.textNettW.Text != "")) : true)
                {
                    if ((this.textNettW.Text != "0") && (this.textNettW.Text != ""))
                    {
                        if ((this.textGrossW.Text != "0") && (this.textGrossW.Text != ""))
                        {
                            if (Convert.ToDouble(this.textNettW.Text) > Convert.ToDouble(this.textGrossW.Text))
                            {
                                MessageBox.Show(Resource.Mes_Nett_Greater_Than_Gross);
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Gross_Mandatory);
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Nett_Mandatory);
                        return;
                    }
                }
                if (((this.pMode == "ADD") || (this.pMode == "EDIT")) && (((WBSetting.zwb == "Y") || ((WBSetting.zwb != "Y") && WBSetting.integrationIDSYS)) && ((!this.textTolerance.Enabled || (this.pMode == "ADD")) && (!this.radioFFB.Checked && (MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_Use_Token_IDSYS : Resource.Mes_Use_Token, Resource.Mes_Notice, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)))))
                {
                    this.hasil = this.tblComm.tokenOrApp(this.textCode.Text.Trim(), "", "NOT_ADOPTSAP", "TOKEN_ADOPTSAP", "NOT_ADOPTSAP", "E", "", null);
                    if (this.hasil[0] == "cancel")
                    {
                        return;
                    }
                }
                if (this.radioNonBulk.Checked && (this.textUnit.Text.ToUpper() != "KG"))
                {
                    if ((this.textNettW.Text != "0") && (this.textNettW.Text != ""))
                    {
                        if ((this.textGrossW.Text == "0") || (this.textGrossW.Text == ""))
                        {
                            MessageBox.Show(Resource.Mes_Gross_Mandatory);
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Nett_Mandatory);
                        return;
                    }
                }
                WBTable table = new WBTable();
                table.OpenTable("wb_commodity", "Select Uniq From wb_commodity Where " + WBData.CompanyLocation(" and (Comm_Code ='" + this.textCode.Text.Trim() + "' )"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.tblComm.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    if ((this.pMode != "EDIT") || (this.textCode.Text.Trim() == this.OldCode.Trim()))
                    {
                        goto TR_005B;
                    }
                    else
                    {
                        table3 = new WBTable();
                        table3.OpenTable("wb_transaction", "Select ref From wb_transaction where " + WBData.Company(" and (comm_code='" + this.tblComm.DT.Rows[this.nCurrRow]["Comm_Code"].ToString() + "' )"), WBData.conn);
                        WBTable table4 = new WBTable();
                        table4.OpenTable("wb_transDO", "Select ref From wb_transDO where " + WBData.Company(" and (comm_code='" + this.tblComm.DT.Rows[this.nCurrRow]["Comm_Code"].ToString() + "' )"), WBData.conn);
                        WBTable table5 = new WBTable();
                        table5.OpenTable("wb_contract", "Select Comm_Code From wb_contract where " + WBData.Company(" and (comm_code='" + this.tblComm.DT.Rows[this.nCurrRow]["Comm_Code"].ToString() + "' )"), WBData.conn);
                        if (((table3.DT.Rows.Count <= 0) && (table4.DT.Rows.Count <= 0)) && (table5.DT.Rows.Count <= 0))
                        {
                            goto TR_005D;
                        }
                        else
                        {
                            string[] textArray1 = new string[0x19];
                            textArray1[0] = Resource.Mes_Confirm_Code_Change;
                            textArray1[1] = " ";
                            textArray1[2] = this.OldCode;
                            textArray1[3] = " -> ";
                            textArray1[4] = this.textCode.Text;
                            textArray1[5] = "\n\n";
                            textArray1[6] = Resource.Msg_Replace_Warning;
                            textArray1[7] = "\n- ";
                            textArray1[8] = Resource.Mes_Transaction;
                            textArray1[9] = " : ";
                            textArray1[10] = table3.DT.Rows.Count.ToString();
                            textArray1[11] = " ";
                            textArray1[12] = Resource.Mes_Records;
                            textArray1[13] = " &  ";
                            textArray1[14] = table4.DT.Rows.Count.ToString();
                            textArray1[15] = " ";
                            textArray1[0x10] = Resource.Mes_Records;
                            textArray1[0x11] = " \n- ";
                            textArray1[0x12] = Resource.Mes_DO_Contract;
                            textArray1[0x13] = " : ";
                            textArray1[20] = table5.DT.Rows.Count.ToString();
                            textArray1[0x15] = " ";
                            textArray1[0x16] = Resource.Mes_Records;
                            textArray1[0x17] = " \n";
                            textArray1[0x18] = Resource.Mes_Confirm_Continue;
                            if (MessageBox.Show(string.Concat(textArray1), Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                int num2 = 0;
                                while (true)
                                {
                                    if (num2 < table3.DT.Rows.Count)
                                    {
                                        table3.DR = table3.DT.Rows[num2];
                                        WBTable table6 = new WBTable();
                                        table6.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.Company(" and Ref='" + table3.DR["Ref"].ToString() + "'"), WBData.conn);
                                        table6.DR = table6.DT.Rows[0];
                                        if (!table6.Locked(table6.DR["uniq"].ToString(), '0'))
                                        {
                                            num2++;
                                            continue;
                                        }
                                        string[] textArray2 = new string[] { Resource.Mes_Fail_Transaction_Locked, " ", table3.DR["Ref"].ToString(), "\n", Resource.Mes_Fail_Transaction_Locked_2, ",\n", Resource.Mes_Fail_Transaction_Locked_3 };
                                        MessageBox.Show(string.Concat(textArray2), Resource.Mes_Fail);
                                        table6.Dispose();
                                    }
                                    else
                                    {
                                        this.ReplaceAll = true;
                                        goto TR_005D;
                                    }
                                    break;
                                }
                            }
                            else
                            {
                                this.ReplaceAll = false;
                                this.textCode.Focus();
                            }
                        }
                    }
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_044);
                    this.textCode.Focus();
                }
                return;
            }
            else
            {
                return;
            }
            goto TR_005D;
        TR_005B:
            this.saved = true;
            WBTable table2 = new WBTable {
                DT = this.tblCommDetail.DT.Copy()
            };
            if (this.pMode == "EDIT")
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.CommE_001 },
                    textRefNo = { Text = this.textCode.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            string str = "";
            if (this.tblComm.DT.Rows.Count > 0)
            {
                str = this.tblComm.DT.Rows[this.nCurrRow]["uniq"].ToString();
            }
            this.tblComm.ReOpen();
            if (this.pMode == "ADD")
            {
                this.tblComm.DR = this.tblComm.DT.NewRow();
                this.tblComm.DR["Coy"] = WBData.sCoyCode;
                this.tblComm.DR["Location_Code"] = WBData.sLocCode;
                this.tblComm.DR["Comm_Code"] = this.textCode.Text;
                this.tblComm.DR["Comm_Name"] = this.textName.Text;
                this.tblComm.DR["Form_Iso"] = this.textFormISO.Text;
                this.tblComm.DR["Unit"] = this.textUnit.Text;
                this.tblComm.DR["Material"] = this.textSAPCode.Text;
                if (this.radioSolid.Checked)
                {
                    this.tblComm.DR["Material_Type"] = "SOLD";
                }
                else if (this.radioLiquid.Checked)
                {
                    this.tblComm.DR["Material_Type"] = "LIQD";
                }
                try
                {
                    this.tblComm.DR["Material_Batch"] = this.textBATCH.Text;
                    this.tblComm.DR["Check_Tare"] = this.checkTare.Checked ? "Y" : "N";
                }
                catch
                {
                }
                if (this.radioStandard.Checked)
                {
                    this.tblComm.DR["Type"] = "S";
                }
                else if (this.radioFFB.Checked)
                {
                    this.tblComm.DR["Type"] = "F";
                }
                else if (this.radioCopra.Checked)
                {
                    this.tblComm.DR["Type"] = "C";
                }
                else if (this.radioSugar.Checked)
                {
                    this.tblComm.DR["Type"] = "G";
                }
                this.tblComm.DR["Trade"] = !this.radioTrade.Checked ? "N" : "T";
                this.tblComm.DR["BulkPack"] = !this.radioBulk.Checked ? "P" : "B";
                this.tblComm.DR["Check_Grading"] = !this.radioGradingYes.Checked ? "N" : "Y";
                this.tblComm.DR["Using_Gunny"] = !this.radioGunnyYes.Checked ? "N" : "Y";
                this.tblComm.DR["PostSAP"] = !this.radioPostYes.Checked ? "N" : "Y";
                if (this.radioConYes.Checked)
                {
                    this.tblComm.DR["QCapprove"] = "Y";
                }
                else
                {
                    this.tblComm.DR["QCApprove"] = "N";
                }
                if (this.textConvValue.Text.Trim() == "")
                {
                    this.textConvValue.Text = "0";
                }
                this.tblComm.DR["Convertion"] = this.textConvValue.Text;
                this.tblComm.DR["ConvertionUnit"] = this.textConvUnit.Text;
                if (this.textConvTolerance.Text.Trim() == "")
                {
                    this.textConvTolerance.Text = "0";
                }
                this.tblComm.DR["ConvertionTolerance"] = this.textConvTolerance.Text;
                this.tblComm.DR["ConvertionCheck"] = this.checkConvert.Checked ? "Y" : "N";
                this.tblComm.DR["Create_By"] = WBUser.UserID;
                this.tblComm.DR["Create_Date"] = DateTime.Now;
                this.tblComm.DR["gross_min_Gunny"] = (this.textGrossMin.Text.Trim() == "") ? "0" : this.textGrossMin.Text.Trim();
                this.tblComm.DR["gross_max_gunny"] = (this.textGrossMax.Text.Trim() == "") ? "0" : this.textGrossMax.Text.Trim();
                this.tblComm.DR["netto_gunny"] = (this.textNetto.Text.Trim() == "") ? "0" : this.textNetto.Text.Trim();
                this.tblComm.DR["gross_weight"] = (this.textGrossW.Text.Trim() == "") ? "0" : this.textGrossW.Text.Trim();
                this.tblComm.DR["netto_weight"] = (this.textNettW.Text.Trim() == "") ? "0" : this.textNettW.Text.Trim();
                this.tblComm.DR["tolerance"] = (this.textTolerance.Text.Trim() == "") ? "0" : this.textTolerance.Text.Trim();
                this.tblComm.DT.Rows.Add(this.tblComm.DR);
                this.tblComm.Save();
                WBTable table7 = new WBTable();
                table7.OpenTable("wb_commodity", "SELECT uniq FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.textCode.Text.Trim() + "'"), WBData.conn);
                this.logKey = table7.DT.Rows[0]["uniq"].ToString();
                table2.Dispose();
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_commodity", this.logKey, logField, logValue);
            }
            else
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { str };
                this.nCurrRow = this.tblComm.GetRecNo(aField, aFind);
                this.tblComm.DR = this.tblComm.DT.Rows[this.nCurrRow];
                this.logKey = this.tblComm.DR["uniq"].ToString();
                this.tblComm.DR.BeginEdit();
                this.tblComm.DR["Coy"] = WBData.sCoyCode;
                this.tblComm.DR["Location_Code"] = WBData.sLocCode;
                this.tblComm.DR["Comm_Code"] = this.textCode.Text;
                this.tblComm.DR["Comm_Name"] = this.textName.Text;
                this.tblComm.DR["Form_Iso"] = this.textFormISO.Text;
                this.tblComm.DR["Unit"] = this.textUnit.Text;
                this.tblComm.DR["Material"] = this.textSAPCode.Text;
                if (this.radioLiquid.Checked)
                {
                    this.tblComm.DR["Material_Type"] = "LIQD";
                }
                else if (this.radioSolid.Checked)
                {
                    this.tblComm.DR["Material_Type"] = "SOLD";
                }
                this.tblComm.DR["Material_Batch"] = this.textBATCH.Text;
                this.tblComm.DR["Check_Tare"] = this.checkTare.Checked ? "Y" : "N";
                try
                {
                    this.tblComm.DR["Material_Batch"] = this.textBATCH.Text;
                    this.tblComm.DR["Check_Tare"] = this.checkTare.Checked ? "Y" : "N";
                }
                catch
                {
                }
                this.tblComm.DR["gross_min_Gunny"] = (this.textGrossMin.Text.Trim() == "") ? "0" : this.textGrossMin.Text.Trim();
                this.tblComm.DR["gross_max_gunny"] = (this.textGrossMax.Text.Trim() == "") ? "0" : this.textGrossMax.Text.Trim();
                this.tblComm.DR["netto_gunny"] = (this.textNetto.Text.Trim() == "") ? "0" : this.textNetto.Text.Trim();
                this.tblComm.DR["gross_weight"] = (this.textGrossW.Text.Trim() == "") ? "0" : this.textGrossW.Text.Trim();
                this.tblComm.DR["netto_weight"] = (this.textNettW.Text.Trim() == "") ? "0" : this.textNettW.Text.Trim();
                this.tblComm.DR["tolerance"] = (this.textTolerance.Text.Trim() == "") ? "0" : this.textTolerance.Text.Trim();
                if (this.radioStandard.Checked)
                {
                    this.tblComm.DR["Type"] = "S";
                }
                else if (this.radioFFB.Checked)
                {
                    this.tblComm.DR["Type"] = "F";
                }
                else if (this.radioCopra.Checked)
                {
                    this.tblComm.DR["Type"] = "C";
                }
                else if (this.radioSugar.Checked)
                {
                    this.tblComm.DR["Type"] = "G";
                }
                this.tblComm.DR["Trade"] = !this.radioTrade.Checked ? "N" : "T";
                this.tblComm.DR["BulkPack"] = !this.radioBulk.Checked ? "P" : "B";
                this.tblComm.DR["Check_Grading"] = !this.radioGradingYes.Checked ? "N" : "Y";
                this.tblComm.DR["Using_Gunny"] = !this.radioGunnyYes.Checked ? "N" : "Y";
                if (this.radioPostYes.Checked)
                {
                    this.tblComm.DR["PostSAP"] = "Y";
                }
                else
                {
                    this.tblComm.DR["POSTSAP"] = "N";
                }
                if (this.radioConYes.Checked)
                {
                    this.tblComm.DR["QCapprove"] = "Y";
                }
                else
                {
                    this.tblComm.DR["QCApprove"] = "N";
                }
                if (this.textConvValue.Text.Trim() == "")
                {
                    this.textConvValue.Text = "0";
                }
                this.tblComm.DR["Convertion"] = Convert.ToDouble(this.textConvValue.Text);
                this.tblComm.DR["ConvertionUnit"] = this.textConvUnit.Text;
                if (this.textConvTolerance.Text.Trim() == "")
                {
                    this.textConvTolerance.Text = "0";
                }
                this.tblComm.DR["ConvertionTolerance"] = Convert.ToDouble(this.textConvTolerance.Text);
                this.tblComm.DR["ConvertionCheck"] = this.checkConvert.Checked ? "Y" : "N";
                this.tblComm.DR["Change_By"] = WBUser.UserID;
                this.tblComm.DR["Change_Date"] = DateTime.Now;
                this.tblComm.DR.EndEdit();
                this.tblComm.Save();
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_commodity", this.logKey, logField, logValue);
                string str2 = "";
                if (this.pMode == "ADD")
                {
                    string[] textArray9 = new string[] { "(Triggered add new commodity in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                    str2 = string.Concat(textArray9);
                }
                else if (this.pMode == "EDIT")
                {
                    string[] textArray10 = new string[] { "(Triggered edit commodity in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                    str2 = string.Concat(textArray10);
                }
                Program.copyToLoc("wb_commodity", this.textCode.Text, 0, this.changeReason + " " + str2);
                if ((this.pMode == "EDIT") && (this.textCode.Text != this.OldCode))
                {
                    Program.copyToLoc("wb_commodity", this.OldCode, 0, this.changeReason + " " + str2);
                }
                if (this.ReplaceAll)
                {
                    string[] textArray11 = new string[] { "Comm_Code" };
                    string[] aNewValue = new string[] { this.textCode.Text };
                    Program.ReplaceInCompany("wb_transaction", textArray11, aNewValue, " Comm_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit commodity master data)");
                    string[] textArray13 = new string[] { "Comm_Code" };
                    string[] textArray14 = new string[] { this.textCode.Text };
                    Program.ReplaceInCompany("wb_transDO", textArray13, textArray14, " Comm_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit commodity master data)");
                    string[] textArray15 = new string[] { "Comm_Code" };
                    string[] textArray16 = new string[] { this.textCode.Text };
                    Program.ReplaceInCompany("wb_contract", textArray15, textArray16, " Comm_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit commodity master data)");
                    string[] textArray17 = new string[] { "Comm_Code" };
                    string[] textArray18 = new string[] { this.textCode.Text };
                    Program.ReplaceInCompany("wb_commodity_detail", textArray17, textArray18, " Comm_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit commodity master data)");
                    string[] textArray19 = new string[] { "Comm_Code" };
                    string[] textArray20 = new string[] { this.textCode.Text };
                    Program.ReplaceInCompany("wb_commodity_grading", textArray19, textArray20, " Comm_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit commodity master data)");
                }
            }
            this.tblCommDetail.Close();
            this.tblCommDetail.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail WHERE " + WBData.CompanyLocation(" AND comm_code='" + this.textCode.Text + "'"), WBData.conn);
            DataGridView pDGV = new DataGridView {
                ColumnCount = table2.DT.Columns.Count
            };
            int num3 = 0;
            while (true)
            {
                if (num3 >= table2.DT.Columns.Count)
                {
                    pDGV.Rows.Clear();
                    pDGV.AllowUserToAddRows = false;
                    pDGV = table2.ToDGV(pDGV);
                    this.tblCommDetail.AddFromDGV_new(pDGV, "Comm_Code", this.textCode.Text, this.pMode, this.changeReason);
                    DataGridView view2 = new DataGridView {
                        ColumnCount = this.tblCommGrading.DT.Columns.Count
                    };
                    int num4 = 0;
                    while (true)
                    {
                        if (num4 >= this.tblCommGrading.DT.Columns.Count)
                        {
                            view2.Rows.Clear();
                            view2.AllowUserToAddRows = false;
                            view2 = this.tblCommGrading.ToDGV(view2);
                            this.tblCommGrading.AddFromDGV_new(view2, "Comm_Code", this.textCode.Text, this.pMode, this.changeReason);
                            this.thisclose();
                            break;
                        }
                        view2.Columns[num4].Name = this.tblCommGrading.DT.Columns[num4].ColumnName;
                        num4++;
                    }
                    break;
                }
                pDGV.Columns[num3].Name = table2.DT.Columns[num3].ColumnName;
                num3++;
            }
            return;
        TR_005D:
            table3.Dispose();
            goto TR_005B;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormCommodityEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.thisclose();
            }
        }

        private void FormCommodityEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.pMode == "ADD")
            {
                this.radioStandard.Checked = true;
                this.radioTrade.Checked = true;
                this.radioGradingNo.Checked = true;
                this.radioGunnyNo.Checked = true;
                this.checkConvert.Checked = false;
                this.radioPostNo.Checked = true;
                this.checkTare.Checked = false;
                this.radioBulk.Checked = true;
            }
            if (this.pMode == "VIEW")
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.buttonCancel.Text = Resource.Btn_Close;
                this.buttonCancel.Enabled = true;
                this.tabControl1.Enabled = true;
                this.tabPage1.Enabled = true;
                foreach (Control control2 in this.tabPage1.Controls)
                {
                    control2.Enabled = false;
                }
                this.tabPage2.Enabled = true;
                foreach (Control control3 in this.tabPage2.Controls)
                {
                    control3.Enabled = false;
                }
                this.tabPage3.Enabled = true;
                foreach (Control control4 in this.tabPage3.Controls)
                {
                    control4.Enabled = false;
                }
                this.buttonGrading.Enabled = true;
                this.buttonQuality.Enabled = true;
            }
            this.tblCommDetail.Close();
            this.tblCommDetail.OpenTable("wb_commodity_detail", "Select * From wb_commodity_detail where " + WBData.CompanyLocation(" and ( Comm_Code='" + this.textCode.Text.Trim() + "' )"), WBData.conn);
            this.tblCommGrading.Close();
            this.tblCommGrading.OpenTable("wb_commodity_grading", "Select * From wb_commodity_grading where " + WBData.CompanyLocation(" and ( Comm_Code='" + this.textCode.Text.Trim() + "' )"), WBData.conn);
            this.tblQC.Close();
            this.tblQC.OpenTable("wb_yield", "Select Yield_Code, Yield_Name From wb_yield", WBData.conn);
            if (this.pMode != "ADD")
            {
                int num = 0;
                while (true)
                {
                    if (num >= this.tblQC.DT.Rows.Count)
                    {
                        break;
                    }
                    DataRow row = this.tblQC.DT.Rows[num];
                    string[] aField = new string[] { "QCode" };
                    string[] aFind = new string[] { row[0].ToString().Trim() };
                    if (this.tblCommDetail.GetRecNo(aField, aFind) >= 0)
                    {
                        this.tblQC.DT.Rows[num].Delete();
                    }
                    num++;
                }
            }
            if (this.pMode == "EDIT")
            {
                this.textCode.ReadOnly = true;
            }
            if (WBSetting.integrationIDSYS)
            {
                this.tabPage1.Text = "IDSYS";
                this.groupBox3.Enabled = false;
                this.groupGrading.Enabled = false;
                this.groupGunny.Enabled = false;
                this.groupBox4.Enabled = false;
                this.label5.Text = "IDSYS Code";
                this.label8.Text = "IDSYS Type";
                this.radioLiquid.Checked = false;
                this.radioLiquid.Enabled = false;
                this.radioSolid.Checked = false;
                this.radioSolid.Enabled = false;
                this.radioCopra.Enabled = false;
                this.radioFFB.Enabled = false;
                this.radioSugar.Enabled = false;
                this.textBATCH.Enabled = false;
                this.textCode.Enabled = false;
                this.textName.Enabled = false;
                this.checkTare.Enabled = false;
                this.textUnit.Enabled = false;
                this.textFormISO.Enabled = false;
                this.tabPage2.Enabled = false;
                this.tabPage3.Enabled = false;
                this.groupTrade.Enabled = false;
                this.groupBoxBulk.Enabled = false;
                this.buttonGrading.Enabled = false;
                this.buttonQuality.Enabled = false;
            }
        }

        public void InitializeComponent()
        {
            this.components = new Container();
            this.label1 = new Label();
            this.label2 = new Label();
            this.textCode = new TextBox();
            this.textName = new TextBox();
            this.groupType = new GroupBox();
            this.radioSugar = new RadioButton();
            this.radioCopra = new RadioButton();
            this.radioFFB = new RadioButton();
            this.radioStandard = new RadioButton();
            this.groupBox2 = new GroupBox();
            this.groupTrade = new GroupBox();
            this.radioNonTrade = new RadioButton();
            this.radioTrade = new RadioButton();
            this.groupGunny = new GroupBox();
            this.radioGunnyNo = new RadioButton();
            this.radioGunnyYes = new RadioButton();
            this.groupGrading = new GroupBox();
            this.radioGradingNo = new RadioButton();
            this.radioGradingYes = new RadioButton();
            this.groupBox8 = new GroupBox();
            this.buttonSave = new Button();
            this.buttonCancel = new Button();
            this.buttonQuality = new Button();
            this.groupBox1 = new GroupBox();
            this.label6 = new Label();
            this.textConvUnit = new TextBox();
            this.textConvValue = new TextBox();
            this.label7 = new Label();
            this.labelConvValue = new Label();
            this.textConvTolerance = new TextBox();
            this.label9 = new Label();
            this.checkConvert = new CheckBox();
            this.labelConvTolerance = new Label();
            this.groupBox3 = new GroupBox();
            this.radioPostNo = new RadioButton();
            this.radioPostYes = new RadioButton();
            this.buttonGrading = new Button();
            this.tabControl1 = new TabControl();
            this.tabPage1 = new TabPage();
            this.radioSolid = new RadioButton();
            this.radioLiquid = new RadioButton();
            this.textBATCH = new TextBox();
            this.label16 = new Label();
            this.label4 = new Label();
            this.textFormISO = new TextBox();
            this.label5 = new Label();
            this.textSAPCode = new TextBox();
            this.label8 = new Label();
            this.btnAdopt = new Button();
            this.tabPage2 = new TabPage();
            this.label10 = new Label();
            this.textNetto = new TextBox();
            this.label11 = new Label();
            this.label12 = new Label();
            this.textGrossMax = new TextBox();
            this.label13 = new Label();
            this.label14 = new Label();
            this.textGrossMin = new TextBox();
            this.label15 = new Label();
            this.tabPage3 = new TabPage();
            this.labelpersen = new Label();
            this.textTolerance = new TextBox();
            this.label17 = new Label();
            this.textNettW = new TextBox();
            this.lblNettW = new Label();
            this.lblTol = new Label();
            this.label21 = new Label();
            this.textGrossW = new TextBox();
            this.lblGrossW = new Label();
            this.checkTare = new CheckBox();
            this.groupBoxBulk = new GroupBox();
            this.radioNonBulk = new RadioButton();
            this.radioBulk = new RadioButton();
            this.label3 = new Label();
            this.textUnit = new TextBox();
            this.toolTipInformation = new ToolTip(this.components);
            this.groupBox4 = new GroupBox();
            this.radioConNo = new RadioButton();
            this.radioConYes = new RadioButton();
            this.groupType.SuspendLayout();
            this.groupTrade.SuspendLayout();
            this.groupGunny.SuspendLayout();
            this.groupGrading.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBoxBulk.SuspendLayout();
            this.groupBox4.SuspendLayout();
            base.SuspendLayout();
            this.label1.Location = new Point(0x18, 15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x56, 13);
            this.label1.TabIndex = 0x13;
            this.label1.Text = "Commodity Code";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.label2.Location = new Point(0x15, 0x2c);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x59, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "Commodity Name";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.textCode.CharacterCasing = CharacterCasing.Upper;
            this.textCode.Location = new Point(0x74, 12);
            this.textCode.Name = "textCode";
            this.textCode.Size = new Size(100, 20);
            this.textCode.TabIndex = 0;
            this.textName.Location = new Point(0x74, 0x29);
            this.textName.Name = "textName";
            this.textName.Size = new Size(0x1ec, 20);
            this.textName.TabIndex = 1;
            this.groupType.Controls.Add(this.radioSugar);
            this.groupType.Controls.Add(this.radioCopra);
            this.groupType.Controls.Add(this.radioFFB);
            this.groupType.Controls.Add(this.radioStandard);
            this.groupType.Location = new Point(12, 0x6d);
            this.groupType.Name = "groupType";
            this.groupType.Size = new Size(0xcc, 60);
            this.groupType.TabIndex = 3;
            this.groupType.TabStop = false;
            this.groupType.Text = "[ Type of Commodity ]";
            this.radioSugar.AutoSize = true;
            this.radioSugar.Location = new Point(0x69, 0x26);
            this.radioSugar.Name = "radioSugar";
            this.radioSugar.Size = new Size(0x35, 0x11);
            this.radioSugar.TabIndex = 3;
            this.radioSugar.Text = "Sugar";
            this.radioSugar.UseVisualStyleBackColor = true;
            this.radioSugar.CheckedChanged += new EventHandler(this.radioSugar_CheckedChanged);
            this.radioCopra.AutoSize = true;
            this.radioCopra.Location = new Point(9, 0x26);
            this.radioCopra.Name = "radioCopra";
            this.radioCopra.Size = new Size(0x35, 0x11);
            this.radioCopra.TabIndex = 2;
            this.radioCopra.Text = "Copra";
            this.radioCopra.UseVisualStyleBackColor = true;
            this.radioCopra.CheckedChanged += new EventHandler(this.radioCopra_CheckedChanged);
            this.radioFFB.AutoSize = true;
            this.radioFFB.Location = new Point(0x69, 0x13);
            this.radioFFB.Name = "radioFFB";
            this.radioFFB.Size = new Size(0x2c, 0x11);
            this.radioFFB.TabIndex = 1;
            this.radioFFB.Text = "FFB";
            this.radioFFB.UseVisualStyleBackColor = true;
            this.radioFFB.CheckedChanged += new EventHandler(this.radioFFB_CheckedChanged);
            this.radioStandard.AutoSize = true;
            this.radioStandard.Checked = true;
            this.radioStandard.Location = new Point(9, 0x13);
            this.radioStandard.Name = "radioStandard";
            this.radioStandard.Size = new Size(0x44, 0x11);
            this.radioStandard.TabIndex = 0;
            this.radioStandard.TabStop = true;
            this.radioStandard.Text = "Standard";
            this.radioStandard.UseVisualStyleBackColor = true;
            this.radioStandard.CheckedChanged += new EventHandler(this.radioStandard_CheckedChanged);
            this.groupBox2.Location = new Point(-2, 0x5d);
            this.groupBox2.Margin = new Padding(0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0x326, 10);
            this.groupBox2.TabIndex = 0x16;
            this.groupBox2.TabStop = false;
            this.groupTrade.Controls.Add(this.radioNonTrade);
            this.groupTrade.Controls.Add(this.radioTrade);
            this.groupTrade.Location = new Point(0xdf, 0x6d);
            this.groupTrade.Name = "groupTrade";
            this.groupTrade.Size = new Size(0x92, 60);
            this.groupTrade.TabIndex = 4;
            this.groupTrade.TabStop = false;
            this.groupTrade.Text = "[ Trade/Non Trande ]";
            this.radioNonTrade.AutoSize = true;
            this.radioNonTrade.Location = new Point(0x43, 0x1b);
            this.radioNonTrade.Name = "radioNonTrade";
            this.radioNonTrade.Size = new Size(0x4c, 0x11);
            this.radioNonTrade.TabIndex = 1;
            this.radioNonTrade.Text = "Non Trade";
            this.radioNonTrade.UseVisualStyleBackColor = true;
            this.radioTrade.AutoSize = true;
            this.radioTrade.Checked = true;
            this.radioTrade.Location = new Point(8, 0x1b);
            this.radioTrade.Name = "radioTrade";
            this.radioTrade.Size = new Size(0x35, 0x11);
            this.radioTrade.TabIndex = 0;
            this.radioTrade.TabStop = true;
            this.radioTrade.Text = "Trade";
            this.radioTrade.UseVisualStyleBackColor = true;
            this.groupGunny.Controls.Add(this.radioGunnyNo);
            this.groupGunny.Controls.Add(this.radioGunnyYes);
            this.groupGunny.Location = new Point(0x27e, 0x6d);
            this.groupGunny.Name = "groupGunny";
            this.groupGunny.Size = new Size(140, 60);
            this.groupGunny.TabIndex = 6;
            this.groupGunny.TabStop = false;
            this.groupGunny.Text = "[ Using Gunny/Bale ]";
            this.radioGunnyNo.AutoSize = true;
            this.radioGunnyNo.Checked = true;
            this.radioGunnyNo.Location = new Point(0x41, 0x1b);
            this.radioGunnyNo.Name = "radioGunnyNo";
            this.radioGunnyNo.Size = new Size(0x27, 0x11);
            this.radioGunnyNo.TabIndex = 1;
            this.radioGunnyNo.TabStop = true;
            this.radioGunnyNo.Text = "No";
            this.radioGunnyNo.UseVisualStyleBackColor = true;
            this.radioGunnyYes.AutoSize = true;
            this.radioGunnyYes.Location = new Point(0x10, 0x1b);
            this.radioGunnyYes.Name = "radioGunnyYes";
            this.radioGunnyYes.Size = new Size(0x2b, 0x11);
            this.radioGunnyYes.TabIndex = 0;
            this.radioGunnyYes.Text = "Yes";
            this.radioGunnyYes.UseVisualStyleBackColor = true;
            this.groupGrading.Controls.Add(this.radioGradingNo);
            this.groupGrading.Controls.Add(this.radioGradingYes);
            this.groupGrading.Location = new Point(0x1f7, 0x6d);
            this.groupGrading.Name = "groupGrading";
            this.groupGrading.Size = new Size(0x80, 60);
            this.groupGrading.TabIndex = 5;
            this.groupGrading.TabStop = false;
            this.groupGrading.Text = "[ Check Grading ]";
            this.radioGradingNo.AutoSize = true;
            this.radioGradingNo.Checked = true;
            this.radioGradingNo.Location = new Point(0x3b, 0x1b);
            this.radioGradingNo.Name = "radioGradingNo";
            this.radioGradingNo.Size = new Size(0x27, 0x11);
            this.radioGradingNo.TabIndex = 1;
            this.radioGradingNo.TabStop = true;
            this.radioGradingNo.Text = "No";
            this.radioGradingNo.UseVisualStyleBackColor = true;
            this.radioGradingYes.AutoSize = true;
            this.radioGradingYes.Location = new Point(13, 0x1b);
            this.radioGradingYes.Name = "radioGradingYes";
            this.radioGradingYes.Size = new Size(0x2b, 0x11);
            this.radioGradingYes.TabIndex = 0;
            this.radioGradingYes.Text = "Yes";
            this.radioGradingYes.UseVisualStyleBackColor = true;
            this.groupBox8.Location = new Point(-2, 0x153);
            this.groupBox8.Margin = new Padding(0);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new Size(0x326, 10);
            this.groupBox8.TabIndex = 0x1b;
            this.groupBox8.TabStop = false;
            this.buttonSave.Location = new Point(0x215, 0x166);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x62, 0x24);
            this.buttonSave.TabIndex = 0x11;
            this.buttonSave.Text = "&Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click_1);
            this.buttonCancel.Location = new Point(0x28b, 0x166);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x62, 0x24);
            this.buttonCancel.TabIndex = 0x12;
            this.buttonCancel.Text = "&Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.button2_Click);
            this.buttonQuality.Location = new Point(0x27d, 0x42);
            this.buttonQuality.Name = "buttonQuality";
            this.buttonQuality.Size = new Size(110, 0x1b);
            this.buttonQuality.TabIndex = 0x10;
            this.buttonQuality.Text = "&Quality Control ";
            this.toolTipInformation.SetToolTip(this.buttonQuality, "Entry Default Quality\r\nOnly Maintained Qualities Will Show in Transaction");
            this.buttonQuality.UseVisualStyleBackColor = true;
            this.buttonQuality.Click += new EventHandler(this.button3_Click);
            this.groupBox1.Location = new Point(-2, 0x1b0);
            this.groupBox1.Margin = new Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x326, 10);
            this.groupBox1.TabIndex = 0x21;
            this.groupBox1.TabStop = false;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x19, 0x1c7);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x53, 13);
            this.label6.TabIndex = 0x1c;
            this.label6.Text = "Convertion Unit ";
            this.label6.Visible = false;
            this.textConvUnit.Location = new Point(0x72, 0x1c4);
            this.textConvUnit.Name = "textConvUnit";
            this.textConvUnit.Size = new Size(110, 20);
            this.textConvUnit.TabIndex = 12;
            this.textConvUnit.Visible = false;
            this.textConvUnit.TextChanged += new EventHandler(this.textConvUnit_TextChanged);
            this.textConvValue.Location = new Point(0x72, 0x1de);
            this.textConvValue.Name = "textConvValue";
            this.textConvValue.Size = new Size(0x53, 20);
            this.textConvValue.TabIndex = 13;
            this.textConvValue.Text = "0";
            this.textConvValue.TextAlign = HorizontalAlignment.Right;
            this.textConvValue.Visible = false;
            this.label7.AutoSize = true;
            this.label7.Location = new Point(20, 0x1e1);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x58, 13);
            this.label7.TabIndex = 0x1d;
            this.label7.Text = "Convertion Value";
            this.label7.Visible = false;
            this.labelConvValue.AutoSize = true;
            this.labelConvValue.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.labelConvValue.Location = new Point(0xce, 0x1e1);
            this.labelConvValue.Name = "labelConvValue";
            this.labelConvValue.Size = new Size(0xbb, 13);
            this.labelConvValue.TabIndex = 0x1f;
            this.labelConvValue.Text = "( in Kg ),  1 \"Convertion Unit\" = xxx Kg";
            this.labelConvValue.Visible = false;
            this.textConvTolerance.Location = new Point(0x72, 0x1f8);
            this.textConvTolerance.Name = "textConvTolerance";
            this.textConvTolerance.Size = new Size(0x53, 20);
            this.textConvTolerance.TabIndex = 14;
            this.textConvTolerance.Text = "0";
            this.textConvTolerance.TextAlign = HorizontalAlignment.Right;
            this.textConvTolerance.Visible = false;
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x33, 0x1fb);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x37, 13);
            this.label9.TabIndex = 30;
            this.label9.Text = "Tolerance";
            this.label9.Visible = false;
            this.checkConvert.AutoSize = true;
            this.checkConvert.Location = new Point(0x1c8, 0x1c3);
            this.checkConvert.Name = "checkConvert";
            this.checkConvert.Size = new Size(150, 0x11);
            this.checkConvert.TabIndex = 0x22;
            this.checkConvert.Text = "Control Weight Convertion";
            this.checkConvert.UseVisualStyleBackColor = true;
            this.checkConvert.Visible = false;
            this.labelConvTolerance.AutoSize = true;
            this.labelConvTolerance.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.labelConvTolerance.Location = new Point(0xce, 0x1fb);
            this.labelConvTolerance.Name = "labelConvTolerance";
            this.labelConvTolerance.Size = new Size(0x110, 13);
            this.labelConvTolerance.TabIndex = 0x20;
            this.labelConvTolerance.Text = "( in Kg ),  1,000 \"Convertion Unit\", the tolerance is xx Kg";
            this.labelConvTolerance.Visible = false;
            this.groupBox3.Controls.Add(this.radioPostNo);
            this.groupBox3.Controls.Add(this.radioPostYes);
            this.groupBox3.Location = new Point(0x177, 0x6d);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new Size(0x7a, 60);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "[ Post To SAP ]";
            this.radioPostNo.AutoSize = true;
            this.radioPostNo.Location = new Point(0x41, 0x1b);
            this.radioPostNo.Name = "radioPostNo";
            this.radioPostNo.Size = new Size(0x27, 0x11);
            this.radioPostNo.TabIndex = 1;
            this.radioPostNo.Text = "No";
            this.radioPostNo.UseVisualStyleBackColor = true;
            this.radioPostYes.AutoSize = true;
            this.radioPostYes.Checked = true;
            this.radioPostYes.Location = new Point(0x10, 0x1b);
            this.radioPostYes.Name = "radioPostYes";
            this.radioPostYes.Size = new Size(0x2b, 0x11);
            this.radioPostYes.TabIndex = 0;
            this.radioPostYes.TabStop = true;
            this.radioPostYes.Text = "Yes";
            this.radioPostYes.UseVisualStyleBackColor = true;
            this.buttonGrading.Location = new Point(0x209, 0x42);
            this.buttonGrading.Name = "buttonGrading";
            this.buttonGrading.Size = new Size(110, 0x1b);
            this.buttonGrading.TabIndex = 15;
            this.buttonGrading.Text = "&Grading Control ";
            this.toolTipInformation.SetToolTip(this.buttonGrading, "Entry Default Grading for this Commodity\r\nMaintained Grading will show in Transaction.\r\nIf  a Grading code not maintained here, can be added  in Transaction also.");
            this.buttonGrading.UseVisualStyleBackColor = true;
            this.buttonGrading.Click += new EventHandler(this.button1_Click);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new Point(12, 0xde);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new Size(0x2df, 0x73);
            this.tabControl1.TabIndex = 0x24;
            this.toolTipInformation.SetToolTip(this.tabControl1, "Currently used for Sugar Commodity Product");
            this.tabPage1.BackColor = SystemColors.Control;
            this.tabPage1.Controls.Add(this.radioSolid);
            this.tabPage1.Controls.Add(this.radioLiquid);
            this.tabPage1.Controls.Add(this.textBATCH);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.textFormISO);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.textSAPCode);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.btnAdopt);
            this.tabPage1.Location = new Point(4, 0x16);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new Padding(3);
            this.tabPage1.Size = new Size(0x2d7, 0x59);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "SAP";
            this.radioSolid.AutoSize = true;
            this.radioSolid.Location = new Point(0xb6, 0x42);
            this.radioSolid.Name = "radioSolid";
            this.radioSolid.Size = new Size(0x30, 0x11);
            this.radioSolid.TabIndex = 30;
            this.radioSolid.Text = "Solid";
            this.radioSolid.UseVisualStyleBackColor = true;
            this.radioLiquid.AutoSize = true;
            this.radioLiquid.Checked = true;
            this.radioLiquid.Location = new Point(0x7b, 0x42);
            this.radioLiquid.Name = "radioLiquid";
            this.radioLiquid.Size = new Size(0x35, 0x11);
            this.radioLiquid.TabIndex = 0x1d;
            this.radioLiquid.TabStop = true;
            this.radioLiquid.Text = "Liquid";
            this.radioLiquid.UseVisualStyleBackColor = true;
            this.textBATCH.CharacterCasing = CharacterCasing.Upper;
            this.textBATCH.Location = new Point(0x124, 0x26);
            this.textBATCH.Name = "textBATCH";
            this.textBATCH.Size = new Size(100, 20);
            this.textBATCH.TabIndex = 0x1c;
            this.label16.Location = new Point(0xf3, 0x29);
            this.label16.Name = "label16";
            this.label16.Size = new Size(0x2b, 13);
            this.label16.TabIndex = 0x1b;
            this.label16.Text = "BATCH";
            this.label16.TextAlign = ContentAlignment.MiddleRight;
            this.label4.Location = new Point(12, 15);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x69, 13);
            this.label4.TabIndex = 0x18;
            this.label4.Text = "Form ISO Number";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            this.textFormISO.Location = new Point(0x7b, 12);
            this.textFormISO.Name = "textFormISO";
            this.textFormISO.Size = new Size(0x1ec, 20);
            this.textFormISO.TabIndex = 8;
            this.label5.Location = new Point(12, 0x29);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x69, 13);
            this.label5.TabIndex = 0x19;
            this.label5.Text = "SAP - Material Code";
            this.label5.TextAlign = ContentAlignment.MiddleRight;
            this.textSAPCode.Location = new Point(0x7b, 0x26);
            this.textSAPCode.Name = "textSAPCode";
            this.textSAPCode.Size = new Size(110, 20);
            this.textSAPCode.TabIndex = 9;
            this.label8.Location = new Point(12, 0x44);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x69, 13);
            this.label8.TabIndex = 0x1a;
            this.label8.Text = "SAP - Material Type";
            this.label8.TextAlign = ContentAlignment.MiddleRight;
            this.btnAdopt.Location = new Point(0x193, 0x26);
            this.btnAdopt.Name = "btnAdopt";
            this.btnAdopt.Size = new Size(0x4b, 0x2e);
            this.btnAdopt.TabIndex = 11;
            this.btnAdopt.Text = "&Adopt from SAP";
            this.toolTipInformation.SetToolTip(this.btnAdopt, "Get Commodity Name From SAP Master Table");
            this.btnAdopt.UseVisualStyleBackColor = true;
            this.btnAdopt.Click += new EventHandler(this.btnAdopt_Click);
            this.tabPage2.BackColor = SystemColors.Control;
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.textNetto);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.textGrossMax);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.textGrossMin);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Location = new Point(4, 0x16);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new Padding(3);
            this.tabPage2.Size = new Size(0x2d7, 0x59);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Gunny";
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0xe5, 0x29);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x16, 13);
            this.label10.TabIndex = 0x25;
            this.label10.Text = "KG";
            this.textNetto.CharacterCasing = CharacterCasing.Upper;
            this.textNetto.Location = new Point(0x7b, 0x26);
            this.textNetto.Name = "textNetto";
            this.textNetto.Size = new Size(100, 20);
            this.textNetto.TabIndex = 0x23;
            this.textNetto.Text = "0";
            this.textNetto.TextAlign = HorizontalAlignment.Right;
            this.label11.Location = new Point(12, 0x29);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x69, 13);
            this.label11.TabIndex = 0x24;
            this.label11.Text = "Netto Weight";
            this.label11.TextAlign = ContentAlignment.MiddleRight;
            this.label12.AutoSize = true;
            this.label12.Location = new Point(0x1e1, 15);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x16, 13);
            this.label12.TabIndex = 0x22;
            this.label12.Text = "KG";
            this.textGrossMax.CharacterCasing = CharacterCasing.Upper;
            this.textGrossMax.Location = new Point(0x177, 12);
            this.textGrossMax.Name = "textGrossMax";
            this.textGrossMax.Size = new Size(100, 20);
            this.textGrossMax.TabIndex = 0x20;
            this.textGrossMax.Text = "0";
            this.textGrossMax.TextAlign = HorizontalAlignment.Right;
            this.label13.Location = new Point(0x108, 15);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x69, 13);
            this.label13.TabIndex = 0x21;
            this.label13.Text = "Gross Maximum";
            this.label13.TextAlign = ContentAlignment.MiddleRight;
            this.label14.AutoSize = true;
            this.label14.Location = new Point(0xe5, 15);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x16, 13);
            this.label14.TabIndex = 0x1f;
            this.label14.Text = "KG";
            this.textGrossMin.CharacterCasing = CharacterCasing.Upper;
            this.textGrossMin.Location = new Point(0x7b, 12);
            this.textGrossMin.Name = "textGrossMin";
            this.textGrossMin.Size = new Size(100, 20);
            this.textGrossMin.TabIndex = 0x1d;
            this.textGrossMin.Text = "0";
            this.textGrossMin.TextAlign = HorizontalAlignment.Right;
            this.label15.Location = new Point(12, 15);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x69, 13);
            this.label15.TabIndex = 30;
            this.label15.Text = "Gross Minimum";
            this.label15.TextAlign = ContentAlignment.MiddleRight;
            this.tabPage3.BackColor = SystemColors.Control;
            this.tabPage3.Controls.Add(this.labelpersen);
            this.tabPage3.Controls.Add(this.textTolerance);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.textNettW);
            this.tabPage3.Controls.Add(this.lblNettW);
            this.tabPage3.Controls.Add(this.lblTol);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.textGrossW);
            this.tabPage3.Controls.Add(this.lblGrossW);
            this.tabPage3.Location = new Point(4, 0x16);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new Padding(3);
            this.tabPage3.Size = new Size(0x2d7, 0x59);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "UOM Convertion";
            this.labelpersen.AutoSize = true;
            this.labelpersen.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelpersen.Location = new Point(0x1a9, 13);
            this.labelpersen.Name = "labelpersen";
            this.labelpersen.Size = new Size(0x12, 15);
            this.labelpersen.TabIndex = 0x30;
            this.labelpersen.Text = "%";
            this.textTolerance.Location = new Point(0x177, 12);
            this.textTolerance.Margin = new Padding(3, 4, 3, 4);
            this.textTolerance.MaxLength = 5;
            this.textTolerance.Name = "textTolerance";
            this.textTolerance.Size = new Size(0x2c, 20);
            this.textTolerance.TabIndex = 0x2f;
            this.textTolerance.Text = "0";
            this.textTolerance.TextAlign = HorizontalAlignment.Right;
            this.textTolerance.Leave += new EventHandler(this.textTolerance_Leave);
            this.label17.AutoSize = true;
            this.label17.Location = new Point(0xe5, 0x29);
            this.label17.Name = "label17";
            this.label17.Size = new Size(0x16, 13);
            this.label17.TabIndex = 0x2e;
            this.label17.Text = "KG";
            this.textNettW.CharacterCasing = CharacterCasing.Upper;
            this.textNettW.Location = new Point(0x7b, 0x26);
            this.textNettW.Name = "textNettW";
            this.textNettW.Size = new Size(100, 20);
            this.textNettW.TabIndex = 0x2c;
            this.textNettW.Text = "0";
            this.textNettW.TextAlign = HorizontalAlignment.Right;
            this.textNettW.Leave += new EventHandler(this.textNettW_Leave);
            this.lblNettW.Location = new Point(12, 0x29);
            this.lblNettW.Name = "lblNettW";
            this.lblNettW.Size = new Size(0x69, 13);
            this.lblNettW.TabIndex = 0x2d;
            this.lblNettW.Text = "Netto Weight";
            this.lblNettW.TextAlign = ContentAlignment.MiddleRight;
            this.lblTol.Location = new Point(0x108, 15);
            this.lblTol.Name = "lblTol";
            this.lblTol.Size = new Size(0x69, 13);
            this.lblTol.TabIndex = 0x2a;
            this.lblTol.Text = "Tolerance/UOM";
            this.lblTol.TextAlign = ContentAlignment.MiddleRight;
            this.label21.AutoSize = true;
            this.label21.Location = new Point(0xe5, 15);
            this.label21.Name = "label21";
            this.label21.Size = new Size(0x16, 13);
            this.label21.TabIndex = 40;
            this.label21.Text = "KG";
            this.textGrossW.CharacterCasing = CharacterCasing.Upper;
            this.textGrossW.Location = new Point(0x7b, 12);
            this.textGrossW.Name = "textGrossW";
            this.textGrossW.Size = new Size(100, 20);
            this.textGrossW.TabIndex = 0x26;
            this.textGrossW.Text = "0";
            this.textGrossW.TextAlign = HorizontalAlignment.Right;
            this.textGrossW.Leave += new EventHandler(this.textGrossW_Leave);
            this.lblGrossW.Location = new Point(12, 15);
            this.lblGrossW.Name = "lblGrossW";
            this.lblGrossW.Size = new Size(0x69, 13);
            this.lblGrossW.TabIndex = 0x27;
            this.lblGrossW.Text = "Gross Weight";
            this.lblGrossW.TextAlign = ContentAlignment.MiddleRight;
            this.checkTare.AutoSize = true;
            this.checkTare.Location = new Point(0xe7, 0x49);
            this.checkTare.Name = "checkTare";
            this.checkTare.Size = new Size(0x71, 0x11);
            this.checkTare.TabIndex = 0x25;
            this.checkTare.Text = "Check Truck Tare";
            this.checkTare.UseVisualStyleBackColor = true;
            this.groupBoxBulk.Controls.Add(this.radioNonBulk);
            this.groupBoxBulk.Controls.Add(this.radioBulk);
            this.groupBoxBulk.Location = new Point(12, 0xb0);
            this.groupBoxBulk.Name = "groupBoxBulk";
            this.groupBoxBulk.Size = new Size(0xcc, 40);
            this.groupBoxBulk.TabIndex = 4;
            this.groupBoxBulk.TabStop = false;
            this.groupBoxBulk.Text = "[ Bulk/Pack ]";
            this.radioNonBulk.AutoSize = true;
            this.radioNonBulk.Location = new Point(0x69, 0x13);
            this.radioNonBulk.Name = "radioNonBulk";
            this.radioNonBulk.Size = new Size(50, 0x11);
            this.radioNonBulk.TabIndex = 1;
            this.radioNonBulk.Text = "Pack";
            this.radioNonBulk.UseVisualStyleBackColor = true;
            this.radioBulk.AutoSize = true;
            this.radioBulk.Checked = true;
            this.radioBulk.Location = new Point(9, 0x13);
            this.radioBulk.Name = "radioBulk";
            this.radioBulk.Size = new Size(0x2e, 0x11);
            this.radioBulk.TabIndex = 0;
            this.radioBulk.TabStop = true;
            this.radioBulk.Text = "Bulk";
            this.radioBulk.UseVisualStyleBackColor = true;
            this.label3.Location = new Point(0x4e, 0x49);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x20, 13);
            this.label3.TabIndex = 0x15;
            this.label3.Text = "UOM";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.textUnit.Location = new Point(0x74, 70);
            this.textUnit.Name = "textUnit";
            this.textUnit.Size = new Size(100, 20);
            this.textUnit.TabIndex = 2;
            this.textUnit.Text = "KG";
            this.toolTipInformation.SetToolTip(this.textUnit, "Default WB UOM is in KG\r\n");
            this.groupBox4.Controls.Add(this.radioConNo);
            this.groupBox4.Controls.Add(this.radioConYes);
            this.groupBox4.Location = new Point(0xdf, 0xb2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new Size(0x9d, 0x26);
            this.groupBox4.TabIndex = 0x27;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "[ Consignment / QC Report ]";
            this.radioConNo.AutoSize = true;
            this.radioConNo.Checked = true;
            this.radioConNo.Location = new Point(0x42, 0x11);
            this.radioConNo.Name = "radioConNo";
            this.radioConNo.Size = new Size(0x27, 0x11);
            this.radioConNo.TabIndex = 1;
            this.radioConNo.TabStop = true;
            this.radioConNo.Text = "No";
            this.radioConNo.UseVisualStyleBackColor = true;
            this.radioConYes.AutoSize = true;
            this.radioConYes.Location = new Point(6, 0x11);
            this.radioConYes.Name = "radioConYes";
            this.radioConYes.Size = new Size(0x2b, 0x11);
            this.radioConYes.TabIndex = 0;
            this.radioConYes.Text = "Yes";
            this.radioConYes.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(790, 0x1a1);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox4);
            base.Controls.Add(this.groupBoxBulk);
            base.Controls.Add(this.checkTare);
            base.Controls.Add(this.tabControl1);
            base.Controls.Add(this.buttonGrading);
            base.Controls.Add(this.groupBox3);
            base.Controls.Add(this.labelConvTolerance);
            base.Controls.Add(this.checkConvert);
            base.Controls.Add(this.textConvTolerance);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.labelConvValue);
            base.Controls.Add(this.textConvValue);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.textConvUnit);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.buttonQuality);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.groupBox8);
            base.Controls.Add(this.groupGrading);
            base.Controls.Add(this.groupGunny);
            base.Controls.Add(this.groupTrade);
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.groupType);
            base.Controls.Add(this.textUnit);
            base.Controls.Add(this.textName);
            base.Controls.Add(this.textCode);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.KeyPreview = true;
            base.Name = "FormCommodityEntry";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Add/Edit/Delete Commodity Item";
            base.Load += new EventHandler(this.FormCommodityEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormCommodityEntry_KeyPress);
            this.groupType.ResumeLayout(false);
            this.groupType.PerformLayout();
            this.groupTrade.ResumeLayout(false);
            this.groupTrade.PerformLayout();
            this.groupGunny.ResumeLayout(false);
            this.groupGunny.PerformLayout();
            this.groupGrading.ResumeLayout(false);
            this.groupGrading.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBoxBulk.ResumeLayout(false);
            this.groupBoxBulk.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void radioCopra_CheckedChanged(object sender, EventArgs e)
        {
            this.SetStandard();
        }

        private void radioFFB_CheckedChanged(object sender, EventArgs e)
        {
            this.SetStandard();
        }

        private void radioStandard_CheckedChanged(object sender, EventArgs e)
        {
            this.SetStandard();
        }

        private void radioSugar_CheckedChanged(object sender, EventArgs e)
        {
            this.SetStandard();
        }

        private void SetStandard()
        {
            this.radioGradingYes.Enabled = this.radioFFB.Checked;
            this.radioGradingNo.Enabled = this.radioFFB.Checked;
            this.textBATCH.Enabled = !this.radioSugar.Checked;
        }

        private void textConvUnit_TextChanged(object sender, EventArgs e)
        {
            if (this.textConvUnit.Text == "")
            {
                this.labelConvValue.Text = "";
                this.labelConvTolerance.Text = "";
            }
            else
            {
                string[] textArray1 = new string[] { " ( ", Resource.Lbl_In, " Kg ),  1 ", this.textConvUnit.Text, " = xxx Kg" };
                this.labelConvValue.Text = string.Concat(textArray1);
                string[] textArray2 = new string[] { " ( ", Resource.Lbl_In, " Kg ),  1,000 ", this.textConvUnit.Text, ", ", Resource.Lbl_Tolerance_Is };
                this.labelConvTolerance.Text = string.Concat(textArray2);
            }
        }

        private void textGrossW_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textGrossW);
        }

        private void textNettW_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textNettW);
        }

        private void textTolerance_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textTolerance);
        }

        public void thisclose()
        {
            base.Close();
        }

        private void translate()
        {
            this.label1.Text = Resource.CommE_001;
            this.groupType.Text = Resource.CommE_002;
            this.label2.Text = Resource.CommE_003;
            this.label3.Text = Resource.CommE_004;
            this.label4.Text = Resource.CommE_005;
            this.label6.Text = Resource.CommE_006;
            this.label7.Text = Resource.CommE_007;
            this.labelConvValue.Text = Resource.CommE_008;
            this.checkConvert.Text = Resource.CommE_009;
            this.label5.Text = this.sapIDSYS + Resource.CommE_010;
            this.label8.Text = this.sapIDSYS + Resource.CommE_011;
            this.radioTrade.Text = Resource.CommE_012;
            this.groupGrading.Text = Resource.CommE_013;
            this.tabPage2.Text = Resource.CommE_014;
            this.groupBox3.Text = Resource.CommE_015 + this.sapIDSYS;
            this.label13.Text = Resource.CommE_016;
            this.label15.Text = Resource.CommE_017;
            this.label11.Text = Resource.CommE_018;
            this.groupBoxBulk.Text = Resource.CommE_019;
            this.groupBox4.Text = Resource.CommE_020;
            this.label16.Text = Resource.CommE_021;
            this.checkTare.Text = Resource.CommE_022;
            this.btnAdopt.Text = Resource.ContractE_039 + this.sapIDSYS;
            this.buttonSave.Text = Resource.Save;
            this.buttonCancel.Text = Resource.Menu_Cancel;
            this.radioSugar.Text = Resource.Rdb_Sugar;
            this.radioCopra.Text = Resource.Rdb_Copra;
            this.radioFFB.Text = Resource.Setting_067;
            this.radioStandard.Text = Resource.Setting_068;
            this.groupTrade.Text = "[ " + Resource.Gbx_Trade_Non_Trade + " ]";
            this.groupGunny.Text = "[ " + Resource.Gbx_Gunny_Bale + " ]";
            this.radioGunnyNo.Text = Resource.Setting_094;
            this.radioGunnyYes.Text = Resource.Setting_095;
            this.radioGradingNo.Text = Resource.Setting_094;
            this.radioGradingYes.Text = Resource.Setting_095;
            this.buttonQuality.Text = Resource.Btn_Quality_Control;
            this.labelConvTolerance.Text = Resource.Lbl_Conv_Tolerance;
            this.radioPostNo.Text = Resource.Setting_094;
            this.radioPostYes.Text = Resource.Setting_095;
            this.buttonGrading.Text = Resource.Btn_Grading_Control;
            this.tabPage1.Text = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            this.radioSolid.Text = Resource.Rdb_Solid;
            this.radioLiquid.Text = Resource.Rdb_Liquid;
            this.tabPage3.Text = Resource.Tab_UOM_Conversion;
            this.lblNettW.Text = Resource.Col_Netto_Weight;
            this.lblTol.Text = Resource.Lbl_Tolerance_UOM;
            this.lblGrossW.Text = Resource.Mes_Gross_Weight;
            this.radioNonBulk.Text = Resource.Rdb_Pack;
            this.radioBulk.Text = Resource.Rdb_Bulk;
            this.radioConNo.Text = Resource.Setting_094;
            this.radioConYes.Text = Resource.Setting_095;
            this.toolTipInformation.SetToolTip(this.buttonGrading, Resource.Ttp_Btn_Grading);
            this.toolTipInformation.SetToolTip(this.tabControl1, Resource.Ttp_Tab_Sugar);
            this.toolTipInformation.SetToolTip(this.textUnit, Resource.Ttp_Txt_Unit);
            this.Text = Resource.Title_Commodity_Entry;
        }
    }
}

