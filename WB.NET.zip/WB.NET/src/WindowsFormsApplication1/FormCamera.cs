﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCamera : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pFind = "";
        public string pFilter = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public WBTable t_camera = new WBTable();
        public DataRow ReturnRow;
        private DataTable updTable = new DataTable();
        private DataTable retTable = new DataTable();
        private string[] zwbResult = new string[3];
        private string[] zwbRow = new string[0x16];
        public string sField;
        private IContainer components = null;
        private ImageList imageList1;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem closeToolStripMenuItem;
        public Panel panel1;
        private ProgressBar progressBar1;
        public TextBox TextFind;
        public Button buttonFind;
        private DataGridView dataGridView1;
        private ToolStripMenuItem viewRecordToolStripMenuItem;

        public FormCamera()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormCameraEntry entry = new FormCameraEntry {
                    pMode = "ADD",
                    zTable = this.ztable,
                    Text = Resource.Title_Add_Camera,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                    string[] aField = new string[] { "camera_Code" };
                    string[] aFind = new string[] { entry.txt_camera_code.Text };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                entry.Dispose();
                this.ztable.UnLock();
                if (this.dataGridView1.RowCount > 0)
                {
                    this.editRecordToolStripMenuItem.Enabled = true;
                    this.viewRecordToolStripMenuItem.Enabled = true;
                    this.deleteToolStripMenuItem.Enabled = true;
                }
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
            {
                this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                string str = this.ztable.DT.Rows[this.nCurrRow]["Camera_Code"].ToString();
                WBTable table = new WBTable();
                string[] textArray1 = new string[] { "SELECT uniq FROM wb_setting WHERE cam1_ip_name = '", str, "' OR cam2_ip_name = '", str, "'" };
                table.OpenTable("wb_setting", string.Concat(textArray1), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    if (MessageBox.Show(str + ".\n\n " + Resource.Mes_006, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = Resource.Col_Camera_Code },
                            textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Camera_Code"].ToString() },
                            Text = Resource.Form_Delete_Reason,
                            label2 = { Text = Resource.Lbl_Delete_Reason }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                            this.ztable.ReOpen();
                            this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                            this.ztable.DT.Rows[this.nCurrRow].Delete();
                            this.ztable.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                            Program.updateLogHeader("wb_camera", this.logKey, logField, logValue);
                            this.ztable.ReOpen();
                            this.ztable.AfterEdit("DELETE");
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                else
                {
                    string[] textArray2 = new string[] { Resource.Mes_Error_Delete_Used_In_Setting, "\n ( ", table.DT.Rows.Count.ToString(), " ", Resource.Mes_Records, " )" };
                    MessageBox.Show(string.Concat(textArray2), "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.ztable.UnLock();
                if (this.dataGridView1.RowCount == 0)
                {
                    this.editRecordToolStripMenuItem.Enabled = false;
                    this.viewRecordToolStripMenuItem.Enabled = false;
                    this.deleteToolStripMenuItem.Enabled = false;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                FormCameraEntry entry = new FormCameraEntry {
                    pMode = "EDIT",
                    zTable = this.ztable,
                    Text = Resource.Title_Edit_Camera,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                }
                entry.Dispose();
                this.ztable.UnLock();
            }
        }

        private void FormCamera_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormCamera_Load(object sender, EventArgs e)
        {
            this.progressBar1.Visible = false;
            this.sField = "uniq,camera_code,ip_address,username,password,web_url,create_by,create_date,edit_by,edit_date";
            this.ztable.OpenTable("wb_camera", "SELECT " + this.sField + " FROM wb_camera WHERE (deleted is null or deleted = '')", WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["camera_code"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["camera_code"].Visible = true;
            this.dataGridView1.Columns["ip_address"].Visible = true;
            this.dataGridView1.Columns["username"].Visible = false;
            this.dataGridView1.Columns["password"].Visible = false;
            this.dataGridView1.Columns["web_url"].Visible = false;
            this.dataGridView1.Columns["create_by"].Visible = true;
            this.dataGridView1.Columns["create_date"].Visible = true;
            this.dataGridView1.Columns["edit_by"].Visible = true;
            this.dataGridView1.Columns["edit_date"].Visible = true;
            this.dataGridView1.Columns["camera_code"].HeaderText = Resource.Col_Camera_Code;
            this.dataGridView1.Columns["ip_address"].HeaderText = Resource.Col_IP_Address;
            this.dataGridView1.Columns["username"].HeaderText = Resource.User_003;
            this.dataGridView1.Columns["password"].HeaderText = Resource.User_006;
            this.dataGridView1.Columns["web_url"].HeaderText = Resource.Col_Web_Url;
            this.dataGridView1.Columns["create_by"].HeaderText = Resource.Gatepass_063;
            this.dataGridView1.Columns["create_date"].HeaderText = Resource.Gatepass_064;
            this.dataGridView1.Columns["edit_by"].HeaderText = Resource.Col_Edit_By;
            this.dataGridView1.Columns["edit_date"].HeaderText = Resource.Col_Edit_Date;
            base.KeyPreview = true;
            if (!WBUser.CheckTrustee("CTR_CAMERA", "A"))
            {
                this.addNewRecordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("CTR_CAMERA", "E"))
            {
                this.editRecordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("CTR_CAMERA", "V"))
            {
                this.viewRecordToolStripMenuItem.Enabled = false;
            }
            if (!WBUser.CheckTrustee("CTR_CAMERA", "D"))
            {
                this.deleteToolStripMenuItem.Enabled = false;
            }
            if ((this.pMode != "") && (this.pFind.Trim() != ""))
            {
                this.TextFind.Text = this.pFind;
                this.buttonFind.PerformClick();
            }
            if (this.dataGridView1.RowCount == 0)
            {
                this.editRecordToolStripMenuItem.Enabled = false;
                this.viewRecordToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.imageList1 = new ImageList(this.components);
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.menuStrip1 = new MenuStrip();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.dataGridView1 = new DataGridView();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            base.SuspendLayout();
            this.imageList1.ColorDepth = ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new Size(0x10, 0x10);
            this.imageList1.TransparentColor = Color.Transparent;
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.viewRecordToolStripMenuItem, this.deleteToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(toolStripItems);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(itemArray2);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x38c, 0x18);
            this.menuStrip1.TabIndex = 0x18;
            this.menuStrip1.Text = "menuStrip1";
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 370);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x38c, 0x21);
            this.panel1.TabIndex = 0x17;
            this.progressBar1.Location = new Point(0x25b, 6);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xa7, 0x11);
            this.progressBar1.TabIndex = 0x13;
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x38c, 0x15a);
            this.dataGridView1.TabIndex = 0;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x38c, 0x193);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormCamera";
            base.ShowInTaskbar = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Master List Camera";
            base.Load += new EventHandler(this.FormCamera_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormCamera_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.deleteToolStripMenuItem.Text = Resource.Trans_057;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.buttonFind.Text = Resource.Menu_Find;
            this.Text = Resource.Title_Camera;
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "VIEW"))
            {
                FormCameraEntry entry = new FormCameraEntry {
                    pMode = "VIEW",
                    zTable = this.ztable,
                    Text = Resource.Title_View_Camera,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                entry.Dispose();
                this.ztable.UnLock();
            }
        }
    }
}

