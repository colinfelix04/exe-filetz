﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormUploadSync : Form
    {
        public string mode;
        public string logKey;
        public int n_estate;
        public int n_truck;
        public int n_transporter;
        public int n_driver;
        public int n_commodity;
        public int n_contract;
        public int n_relation;
        private string sapIDSYS;
        private int rCount;
        private WBTable tbl_templateTrans;
        private WBTable tbl_templateTransD;
        private DataTable tblTrans;
        private DataTable tblTransD;
        private DataTable retTable;
        public string tipeTrans;
        public string comm;
        public string Do_No;
        public string sapDest;
        public string transpt;
        public DateTime dateFrom;
        public DateTime dateTo;
        private string estateDiff;
        private string adopt;
        private string sapFunc;
        private string sapTable;
        private string sapReturn;
        private string sapType;
        private string zwbRef;
        private string zwbRefDo;
        private int jlhkolom;
        private int countRef;
        private WBTable aTable;
        private WBTable bTable;
        private WBTable postTrans;
        private string type;
        private string sqlText;
        private WBTable tbl_transaction;
        public bool showAll;
        public bool locked;
        public bool cTrans;
        private IContainer components;
        private TextBox List_Status;
        private Button btn_next;
        private DataGridView dgv1;
        private DataGridView dgv2;

        public FormUploadSync()
        {
            this.mode = "";
            this.logKey = "";
            this.n_estate = 0;
            this.n_truck = 0;
            this.n_transporter = 0;
            this.n_driver = 0;
            this.n_commodity = 0;
            this.n_contract = 0;
            this.n_relation = 0;
            this.sapIDSYS = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            this.tbl_templateTrans = new WBTable();
            this.tbl_templateTransD = new WBTable();
            this.tblTrans = new DataTable();
            this.tblTransD = new DataTable();
            this.retTable = new DataTable();
            this.tipeTrans = "";
            this.comm = "";
            this.Do_No = "";
            this.sapDest = "";
            this.transpt = "";
            this.estateDiff = "N";
            this.adopt = "N";
            this.countRef = 0;
            this.aTable = new WBTable();
            this.bTable = new WBTable();
            this.postTrans = new WBTable();
            this.tbl_transaction = new WBTable();
            this.locked = false;
            this.cTrans = false;
            this.components = null;
            this.InitializeComponent();
        }

        public FormUploadSync(string pass_mode)
        {
            this.mode = "";
            this.logKey = "";
            this.n_estate = 0;
            this.n_truck = 0;
            this.n_transporter = 0;
            this.n_driver = 0;
            this.n_commodity = 0;
            this.n_contract = 0;
            this.n_relation = 0;
            this.sapIDSYS = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP;
            this.tbl_templateTrans = new WBTable();
            this.tbl_templateTransD = new WBTable();
            this.tblTrans = new DataTable();
            this.tblTransD = new DataTable();
            this.retTable = new DataTable();
            this.tipeTrans = "";
            this.comm = "";
            this.Do_No = "";
            this.sapDest = "";
            this.transpt = "";
            this.estateDiff = "N";
            this.adopt = "N";
            this.countRef = 0;
            this.aTable = new WBTable();
            this.bTable = new WBTable();
            this.postTrans = new WBTable();
            this.tbl_transaction = new WBTable();
            this.locked = false;
            this.cTrans = false;
            this.components = null;
            this.InitializeComponent();
            this.mode = pass_mode;
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dgvDetailToTable(DataGridView aDgv, DataTable mainTable, DataTable subTable, string key)
        {
            try
            {
                subTable.Rows.Clear();
                foreach (DataRow row2 in mainTable.Rows)
                {
                    string str = row2[key].ToString();
                    foreach (DataGridViewRow row3 in (IEnumerable) aDgv.Rows)
                    {
                        if (row3.Cells[key].Value.ToString() == str)
                        {
                            DataRow row = subTable.NewRow();
                            int num = 0;
                            while (true)
                            {
                                if (num >= subTable.Columns.Count)
                                {
                                    subTable.Rows.Add(row);
                                    break;
                                }
                                row[subTable.Columns[num].ColumnName] = row3.Cells[subTable.Columns[num].ColumnName].Value;
                                num++;
                            }
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void dgvToTable(DataGridView aDgv, DataTable aTable)
        {
            try
            {
                aTable.Rows.Clear();
                foreach (DataGridViewRow row2 in (IEnumerable) aDgv.Rows)
                {
                    DataRow row = aTable.NewRow();
                    int num = 0;
                    while (true)
                    {
                        if (num >= aTable.Columns.Count)
                        {
                            aTable.Rows.Add(row);
                            break;
                        }
                        row[aTable.Columns[num].ColumnName] = row2.Cells[aTable.Columns[num].ColumnName].Value;
                        num++;
                    }
                }
            }
            catch
            {
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void fillDG(DataGridView zDgv, DataTable zTable, WBTable ztemplate)
        {
            this.rCount = this.tbl_transaction.DT.Rows.Count;
            this.zwbRef = "";
            this.zwbRefDo = "";
            zDgv.Rows.Clear();
            for (int i = 0; i < this.rCount; i++)
            {
                zDgv.Rows.Add();
                this.tbl_transaction.DR = this.tbl_transaction.DT.Rows[i];
                int crRow = zDgv.Rows.Count - 1;
                if (this.fillDGRow(this.tbl_transaction.DR, zDgv, crRow, ztemplate))
                {
                }
            }
        }

        private bool fillDGRow(DataRow aRow, DataGridView fDgv, int crRow, WBTable zTemplate)
        {
            bool flag = false;
            string str = "";
            string str3 = "N";
            int num3 = 0;
            WBTable table = new WBTable();
            int count = zTemplate.DT.Rows.Count;
            this.jlhkolom = count;
            string[] strArray = new string[count];
            string str13 = "";
            string str11 = aRow["ref"].ToString();
            if (str11.Length > 0)
            {
                string str12;
                if (str11.Substring(str11.Length - 1, 1) == Constant.TITIP_TIMBUN_POSTFIX)
                {
                    str12 = aRow["DO_NO"].ToString();
                    str12 = str12.Substring(0, str12.Length - 1);
                    str13 = Program.getFieldValue("wb_Contract", "coy_Tolling", "DO_NO", str12);
                }
                if (str11.Substring(str11.Length - 2, 1) == Constant.TITIP_TIMBUN_POSTFIX)
                {
                    str12 = aRow["DO_NO"].ToString();
                    str12 = str12.Substring(0, str12.Length - 1);
                    str13 = Program.getFieldValue("wb_Contract", "coy_Tolling", "DO_NO", str12);
                }
            }
            str3 = aRow["Posted"].ToString();
            int index = 0;
            while (true)
            {
                string str5;
                string str8;
                string str9;
                while (true)
                {
                    if (index >= count)
                    {
                        fDgv.Rows[crRow].Cells["posted"].Value = str3;
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_transaction", "Select * From wb_transaction where " + WBData.CompanyLocation(" and Ref='" + aRow["ref"].ToString() + "'"), WBData.conn);
                        if (table2.DT.Rows.Count <= 0)
                        {
                            this.locked = false;
                        }
                        else
                        {
                            table2.DR = table2.DT.Rows[0];
                            this.locked = table2.Locked(table2.DR["uniq"].ToString(), '0');
                        }
                        if ((this.type == "1") && (this.zwbRef.Trim() != aRow["ref"].ToString().Trim()))
                        {
                            this.zwbRef = aRow["ref"].ToString();
                            if (this.estateDiff == "Y")
                            {
                                DataGridViewCellStyle style = new DataGridViewCellStyle {
                                    BackColor = Color.Red,
                                    SelectionBackColor = Color.HotPink
                                };
                                this.dgv1.Rows[this.dgv1.Rows.Count - 1].DefaultCellStyle = style;
                            }
                        }
                        return !this.locked;
                    }
                    zTemplate.DR = zTemplate.DT.Rows[index];
                    string tablename = zTemplate.DR["table_name"].ToString();
                    str8 = zTemplate.DR["title_excel"].ToString();
                    string str6 = zTemplate.DR["Key_Field"].ToString();
                    string str7 = zTemplate.DR["Key_Field2"].ToString();
                    str5 = zTemplate.DR["Field_WB"].ToString();
                    str9 = zTemplate.DR["data_type"].ToString();
                    int num2 = Convert.ToInt16(zTemplate.DR["fixed"].ToString());
                    if (str8.ToUpper() == "ZWB_LOC".ToUpper())
                    {
                        num3 = index;
                    }
                    if (num2 != 0)
                    {
                        strArray[index] = zTemplate.DR["value"].ToString();
                    }
                    else if (((tablename.ToUpper() != "wb_transaction".ToUpper()) && ((tablename != "") && ((tablename.ToUpper() != "wb_transactiond".ToUpper()) && (tablename.ToUpper() != "wb_transQC".ToUpper())))) && (tablename.ToUpper() != "wb_transbatch".ToUpper()))
                    {
                        try
                        {
                            string[] textArray1 = new string[] { " And ", str6, "= '", aRow[str7].ToString(), "' " };
                            table.OpenTable(tablename, ("select * from " + tablename + " where ") + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                            table.DR = table.DT.Rows[0];
                            strArray[index] = table.DR[str5].ToString();
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                        if (tablename.ToUpper() == "wb_contract".ToUpper())
                        {
                            this.adopt = aRow["zadp"].ToString();
                        }
                        if ((str8.ToUpper() == "WJLHGONI".ToUpper()) && ((strArray[index] == "0") && (Program.StrToDouble(aRow["TotalBunch"].ToString(), 0) > 0.0)))
                        {
                            strArray[index] = aRow["totalbunch"].ToString();
                        }
                    }
                    else if (tablename.ToUpper() != "wb_transaction".ToUpper())
                    {
                        try
                        {
                            strArray[index] = aRow[str5].ToString();
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                    else
                    {
                        try
                        {
                            strArray[index] = !((str5.ToUpper() == "Received".ToUpper()) | (str5.ToUpper() == "terima".ToUpper())) ? aRow[str5].ToString() : Convert.ToString(Math.Abs((double) (Convert.ToDouble(strArray[index - 2]) - Convert.ToDouble(strArray[index - 1]))));
                            if (str5.ToUpper() == "Deleted".ToUpper())
                            {
                                strArray[index] = aRow[str5].ToString();
                                if (strArray[index] == "Y")
                                {
                                    strArray[index] = "1";
                                }
                                if (aRow["mark_accident"].ToString() == "X")
                                {
                                    strArray[index] = "A";
                                }
                            }
                            if (aRow["tolling"].ToString() == "Y")
                            {
                                flag = true;
                                str = aRow["Coy_Tolling"].ToString();
                            }
                            if (str5.ToUpper() == "IO".ToUpper())
                            {
                                strArray[index] = (strArray[index] != "I") ? "S" : "P";
                            }
                            if ((str8.ToUpper() == "Kirim".ToUpper()) && (strArray[index] == "0"))
                            {
                                strArray[index] = aRow["received"].ToString();
                            }
                            if (str8.ToUpper() == "STORAGE_CODE".ToUpper())
                            {
                                this.aTable.OpenTable("wb_transaction", "select ref, Source_code from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + str11 + "'"), WBData.conn);
                                if (this.aTable.DT.Rows.Count > 0)
                                {
                                    this.aTable.DR = this.aTable.DT.Rows[0];
                                    if (this.aTable.DR["source_code"].ToString().Trim() != "")
                                    {
                                        this.bTable.OpenTable("wb_source", "select * from wb_source where " + WBData.CompanyLocation(" and source_code = '" + this.aTable.DR["source_code"].ToString() + "'"), WBData.conn);
                                        if (this.bTable.DT.Rows.Count <= 0)
                                        {
                                            strArray[index] = this.aTable.DR["source_code"].ToString();
                                        }
                                        else
                                        {
                                            this.bTable.DR = this.bTable.DT.Rows[0];
                                            strArray[index] = this.bTable.DR["storage_loc"].ToString();
                                        }
                                    }
                                }
                            }
                            if ((str5.ToUpper() == "GROSS_ESTATE".ToUpper()) && (aRow["NOPW"].ToString() == "Y"))
                            {
                                strArray[index] = aRow["NETTO"].ToString();
                            }
                            if ((str5.ToUpper() == "NET_ESTATE".ToUpper()) && (aRow["NOPW"].ToString() == "Y"))
                            {
                                strArray[index] = aRow["NETTO"].ToString();
                            }
                            if ((str5.ToUpper() == "estate_qty".ToUpper()) && (aRow["NOPW"].ToString() == "Y"))
                            {
                                strArray[index] = aRow["NETTO"].ToString();
                            }
                            if ((str8.ToUpper() == "REF".ToUpper()) && (this.mode.ToUpper().Trim() == "TRANSPORT".ToUpper().Trim()))
                            {
                                int num5 = WBData.sCoyCode.Length + WBData.sLocCode.Length;
                                int num6 = 7;
                                if (WBSetting.Field("Ref6").ToString() == "Y")
                                {
                                    num6 = 6;
                                }
                                strArray[index] = strArray[index].Substring(0, num5 + num6);
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                            strArray[index] = "";
                        }
                        this.estateDiff = aRow["estateDiff"].ToString();
                    }
                    break;
                }
                if (((str8 == "ZWB_LOC") || (str8 == "WLOKASI")) && (str13 != ""))
                {
                    strArray[index] = str13;
                }
                if (str8.ToUpper() == "WUNIQ".ToUpper())
                {
                    if (this.zwbRefDo.Trim() == aRow["ref"].ToString().Trim())
                    {
                        this.countRef++;
                    }
                    else
                    {
                        this.countRef = 0;
                        this.zwbRefDo = aRow["ref"].ToString().Trim();
                    }
                    strArray[index] = this.countRef.ToString().PadLeft(2, '0');
                }
                if ((str5.ToUpper() == "DO_NO") && (Program.getFieldValue("wb_Contract", "zAuto", "DO_NO", strArray[index]) == "Y"))
                {
                    strArray[index] = strArray[index].Substring(0, strArray[index].Length - 1);
                }
                if ((((str8.ToUpper() == "WSTO") || ((str8.ToUpper() == "LANGSIR") || ((str8.ToUpper() == "WGIDO") || (str8.ToUpper() == "WSTO2")))) || (str8.ToUpper() == "WGIDO2")) && (Program.getFieldValue("wb_contract", "STO1DO", "Do_No", aRow["Do_NO"].ToString()) == "Y"))
                {
                    if (str8.ToUpper() == "WSTO")
                    {
                        strArray[index] = aRow["STO1X"].ToString();
                    }
                    else if (str8.ToUpper() == "WGIDO")
                    {
                        strArray[index] = aRow["DO1X"].ToString();
                    }
                    else if (str8.ToUpper() == "LANGSIR")
                    {
                        strArray[index] = "1";
                    }
                    else if (str8.ToUpper() == "WSTO2")
                    {
                        strArray[index] = aRow["STO1X"].ToString();
                    }
                    else if (str8.ToUpper() == "WGIDO2")
                    {
                        strArray[index] = aRow["DO1X"].ToString();
                    }
                }
                if (strArray[index] != "")
                {
                    if (str9.ToUpper() == "DATE".ToUpper())
                    {
                        DateTime time = Convert.ToDateTime(strArray[index]);
                        strArray[index] = time.ToString("dd.MM.yyyy");
                    }
                    else if (str9.ToUpper() != "TIME".ToUpper())
                    {
                        if (str9.ToUpper() == "Formula".ToUpper())
                        {
                        }
                    }
                    else
                    {
                        try
                        {
                            strArray[index] = Convert.ToDateTime(strArray[index]).ToString("HH:mm");
                            if (strArray[index] == "00:00")
                            {
                                strArray[index] = "00:01";
                            }
                        }
                        catch
                        {
                            strArray[index] = "";
                        }
                    }
                }
                if (str9.ToUpper() != "Number".ToUpper())
                {
                    if (str9.ToUpper() == "Boolean".ToUpper())
                    {
                        strArray[index] = (strArray[index] != "Y") ? "" : "X";
                    }
                }
                else
                {
                    if (ReferenceEquals(strArray[index], null))
                    {
                        strArray[index] = "0";
                    }
                    if (strArray[index].Trim() == "")
                    {
                        strArray[index] = "0";
                    }
                }
                if (str8 != "")
                {
                    fDgv.Rows[crRow].Cells[str8].Value = strArray[index];
                }
                index++;
            }
        }

        public void fillTable()
        {
            string str3;
            int num6;
            string str = Program.DTOC(this.dateFrom) + " 00:00:00";
            string str2 = Program.DTOC(this.dateTo) + " 00:00:00";
            string[] textArray1 = new string[] { "and report_date >= '", str, "' and report_Date <= '", str2, "' " };
            this.sqlText = "select * from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray1));
            this.sqlText = this.sqlText + " and report_date IS NOT NULL ";
            if (this.tipeTrans.Length > 0)
            {
                this.sqlText = this.sqlText + " and IO = '" + this.tipeTrans + "' ";
            }
            if (!this.showAll)
            {
                this.sqlText = this.sqlText + " and (posted_opw ='N') ";
            }
            if (this.comm.Length > 0)
            {
                this.sqlText = this.sqlText + " and (Comm_code = '" + this.comm + "') ";
            }
            if (this.transpt.Length > 0)
            {
                this.sqlText = this.sqlText + " and (Transporter_code = '" + this.comm + "') ";
            }
            if (this.Do_No.Length > 0)
            {
                this.sqlText = this.sqlText + " and (Do_No = '" + this.Do_No + "') ";
            }
            this.sqlText = this.sqlText + " order by Ref";
            this.tbl_transaction.OpenTable("vw_trans", this.sqlText, WBData.conn);
            this.List_Status.AppendText("Record found: " + this.tbl_transaction.DT.Rows.Count.ToString() + Environment.NewLine);
            if (this.tbl_transaction.DT.Rows.Count > 0)
            {
                this.dgv1.Refresh();
                this.dgv2.Refresh();
                this.List_Status.AppendText("Start Mapping Data..." + Environment.NewLine);
                this.type = "1";
                this.fillDG(this.dgv1, this.tblTrans, this.tbl_templateTrans);
                this.type = "2";
                this.fillDG(this.dgv2, this.tblTransD, this.tbl_templateTransD);
                this.List_Status.AppendText("Mapping Data completed..." + Environment.NewLine);
                this.List_Status.AppendText("Sending data to " + this.sapIDSYS + "..." + Environment.NewLine);
                if (this.dgv1.Rows.Count <= 0)
                {
                    MessageBox.Show("No Data Found...", "Information");
                    return;
                }
                else
                {
                    Cursor.Current = Cursors.WaitCursor;
                    this.dgvToTable(this.dgv1, this.tblTrans);
                    this.dgvDetailToTable(this.dgv2, this.tblTrans, this.tblTransD, "WREF");
                    str3 = "";
                    if (!WBSetting.activeMulesoftIntegration)
                    {
                        if (WBSAP.connect())
                        {
                            WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_TRX_OTHER_PARTY ");
                            WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("T_RECORD_D");
                            WBSAP.sendTable(this.tblTransD);
                            WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("T_RECORD");
                            WBSAP.sendTable(this.tblTrans);
                            WBSAP.sendZWB();
                            WBSAP.setImportReturn();
                            string[] strArray = new string[3];
                            WBSAP.getAllResult(this.tblTrans, this.retTable, "WREF");
                        }
                        else
                        {
                            return;
                        }
                    }
                    else
                    {
                        WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
                        List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
                        List<Dictionary<string, string>> list2 = new List<Dictionary<string, string>>();
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 < this.tblTrans.Rows.Count)
                            {
                                Dictionary<string, string> item = new Dictionary<string, string>();
                                int index = 0;
                                while (true)
                                {
                                    if (index >= this.tblTrans.Columns.Count)
                                    {
                                        sentTable.Add(item);
                                        num2++;
                                        break;
                                    }
                                    item.Add(this.tblTrans.Columns[index].ColumnName, this.tblTrans.Rows[num2].ItemArray[index].ToString());
                                    index++;
                                }
                                continue;
                            }
                            int num4 = 0;
                            while (true)
                            {
                                if (num4 < this.tblTransD.Rows.Count)
                                {
                                    Dictionary<string, string> item = new Dictionary<string, string>();
                                    int index = 0;
                                    while (true)
                                    {
                                        if (index >= this.tblTransD.Columns.Count)
                                        {
                                            list2.Add(item);
                                            num4++;
                                            break;
                                        }
                                        item.Add(this.tblTransD.Columns[index].ColumnName, this.tblTransD.Rows[num4].ItemArray[index].ToString());
                                        index++;
                                    }
                                    continue;
                                }
                                integrator.prepareTable();
                                integrator.addTable(sentTable, "T_RECORD");
                                integrator.addTable(list2, "T_RECORD_D");
                                string url = integrator.getURL("ZRFC_DNET_WB_TRX_OTHER_PARTY");
                                if (url != "")
                                {
                                    bool err = false;
                                    string[] resultHeaderName = new string[] { "ERRORS", "T_RECORD", "MESSAGE_ID" };
                                    Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                                    if (!err)
                                    {
                                        if (dictionary["ERRORS"].Count > 0)
                                        {
                                            MessageBox.Show("Error from " + this.sapIDSYS + " : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        }
                                        else
                                        {
                                            str3 = dictionary["MESSAGE_ID"][0]["VALUE"].ToString();
                                            foreach (Dictionary<string, string> dictionary4 in dictionary["T_RECORD"])
                                            {
                                                object[] values = new object[] { dictionary4["WREF"].ToString(), dictionary4["STAT"].ToString(), dictionary4["RFC_TEXT"].ToString() };
                                                this.retTable.Rows.Add(values);
                                            }
                                        }
                                        goto TR_000C;
                                    }
                                }
                                break;
                            }
                            break;
                        }
                        return;
                    }
                    goto TR_000B;
                }
            }
            else
            {
                return;
            }
            goto TR_000C;
        TR_000B:
            num6 = 0;
            while (true)
            {
                if (num6 >= this.retTable.Rows.Count)
                {
                    this.List_Status.AppendText("Sync Completed." + Environment.NewLine);
                    break;
                }
                DataRow row = this.retTable.Rows[num6];
                string str5 = row[0].ToString().Trim();
                string[] textArray3 = new string[] { row[0].ToString(), " ", row[1].ToString(), " ", row[2].ToString(), Environment.NewLine };
                this.List_Status.AppendText(string.Concat(textArray3));
                if (row[1].ToString() == "Y")
                {
                    this.postTrans.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str5 + "'", WBData.conn);
                    this.postTrans.DR = this.postTrans.DT.Rows[0];
                    this.logKey = this.postTrans.DR["uniq"].ToString();
                    this.postTrans.DR.BeginEdit();
                    this.postTrans.DR["posted_opw"] = "Y";
                    this.postTrans.DR["sync_return"] = "";
                    this.postTrans.DR["lastMulesoftReturnID"] = str3;
                    this.postTrans.DR["checksum"] = this.postTrans.Checksum(this.postTrans.DR);
                    this.postTrans.DR.EndEdit();
                    this.postTrans.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload other party weight to " + this.sapIDSYS };
                    Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                }
                else
                {
                    this.postTrans.OpenTable("wb_transaction", "select * from wb_transaction where ref ='" + str5 + "'", WBData.conn);
                    this.postTrans.DR = this.postTrans.DT.Rows[0];
                    this.logKey = this.postTrans.DR["uniq"].ToString();
                    this.postTrans.DR.BeginEdit();
                    this.postTrans.DR["posted_opw"] = "N";
                    this.postTrans.DR["sync_return"] = row[2].ToString();
                    this.postTrans.DR["lastMulesoftReturnID"] = str3;
                    this.postTrans.DR["checksum"] = this.postTrans.Checksum(this.postTrans.DR);
                    this.postTrans.DR.EndEdit();
                    this.postTrans.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Upload other party weight to SAP" };
                    Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                }
                num6++;
            }
            return;
        TR_000C:
            Cursor.Current = Cursors.Default;
            goto TR_000B;
        }

        private void formatDG(DataGridView zDgv, DataTable zTable, WBTable zTemplate)
        {
            this.rCount = zTemplate.DT.Rows.Count;
            this.jlhkolom = this.rCount;
            zTable.Columns.Clear();
            zDgv.Columns.Clear();
            int num = 0;
            while (true)
            {
                DataGridViewTextBoxColumn column;
                if (num >= this.rCount)
                {
                    column = new DataGridViewTextBoxColumn {
                        Name = "Posted",
                        HeaderText = "Posted",
                        ReadOnly = true
                    };
                    zDgv.Columns.Add(column);
                    return;
                }
                zTemplate.DR = zTemplate.DT.Rows[num];
                column = new DataGridViewTextBoxColumn();
                DataColumn column3 = new DataColumn();
                bool flag = zTemplate.DR["Title_Excel"].ToString().Trim() != "";
                column.Name = !flag ? ("Column_" + num.ToString()) : zTemplate.DR["Title_Excel"].ToString().Trim();
                column.HeaderText = zTemplate.DR["Title_Excel"].ToString();
                column.ReadOnly = true;
                column3.ColumnName = column.Name;
                zDgv.Columns.Add(column);
                zTable.Columns.Add(column3);
                num++;
            }
        }

        private void FormUploadSync_Load(object sender, EventArgs e)
        {
        }

        private void FormUploadSync_Shown(object sender, EventArgs e)
        {
            if ((this.mode != "ZWB") && (this.mode != "SYNC MASTER DATA"))
            {
                if (this.mode == "OTHER PARTY WEIGHT")
                {
                    string sqltext = "";
                    sqltext = "Select * from wb_templateSAP where " + WBData.CompanyLocation(" AND modul = '" + this.mode + "'  and type ='1' ") + " order by column_Numbering";
                    this.tbl_templateTrans.OpenTable("wb_templateSAP", sqltext, WBData.conn);
                    this.formatDG(this.dgv1, this.tblTrans, this.tbl_templateTrans);
                    sqltext = "Select * from wb_templateSAP where " + WBData.CompanyLocation(" AND modul = '" + this.mode + "'  and type ='2' ") + " order by column_Numbering";
                    this.tbl_templateTransD.OpenTable("wb_templateSAP", sqltext, WBData.conn);
                    this.formatDG(this.dgv2, this.tblTransD, this.tbl_templateTransD);
                    this.retTable.Columns.Clear();
                    DataColumn column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    this.retTable.Columns.Add(column);
                    column.Dispose();
                    this.fillTable();
                }
            }
            else
            {
                this.List_Status.Text = "";
                if (this.n_estate > 0)
                {
                    string[] strArray = new string[this.n_estate];
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    this.List_Status.AppendText("SYNC ESTATE" + Environment.NewLine);
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    strArray = WBSetting.activeMulesoftIntegration ? Sync.sync_estate_with_mulesoft("") : Sync.sync_estate("");
                    int index = 0;
                    while (true)
                    {
                        if (index >= this.n_estate)
                        {
                            break;
                        }
                        this.List_Status.AppendText(strArray[index] + Environment.NewLine);
                        index++;
                    }
                }
                if (this.n_transporter > 0)
                {
                    string[] strArray2 = new string[this.n_transporter];
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    this.List_Status.AppendText("SYNC TRANSPORTER" + Environment.NewLine);
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    strArray2 = WBSetting.activeMulesoftIntegration ? Sync.sync_transporter_with_mulesoft("") : Sync.sync_transporter("");
                    int index = 0;
                    while (true)
                    {
                        if (index >= this.n_transporter)
                        {
                            break;
                        }
                        this.List_Status.AppendText(strArray2[index] + Environment.NewLine);
                        index++;
                    }
                }
                if (this.n_truck > 0)
                {
                    string[] strArray3 = new string[this.n_truck];
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    this.List_Status.AppendText("SYNC TRUCK" + Environment.NewLine);
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    strArray3 = WBSetting.activeMulesoftIntegration ? Sync.sync_truck_with_mulesoft("") : Sync.sync_truck("");
                    int index = 0;
                    while (true)
                    {
                        if (index >= this.n_truck)
                        {
                            break;
                        }
                        this.List_Status.AppendText(strArray3[index] + Environment.NewLine);
                        index++;
                    }
                }
                if (this.n_driver > 0)
                {
                    string[] strArray4 = new string[this.n_driver];
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    this.List_Status.AppendText("SYNC DRIVER" + Environment.NewLine);
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    strArray4 = WBSetting.activeMulesoftIntegration ? Sync.sync_driver_with_mulesoft("") : Sync.sync_driver("");
                    int index = 0;
                    while (true)
                    {
                        if (index >= this.n_driver)
                        {
                            break;
                        }
                        this.List_Status.AppendText(strArray4[index] + Environment.NewLine);
                        index++;
                    }
                }
                if (this.n_commodity > 0)
                {
                    string[] strArray5 = new string[this.n_commodity];
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    this.List_Status.AppendText("SYNC COMMODITY" + Environment.NewLine);
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    strArray5 = WBSetting.activeMulesoftIntegration ? Sync.sync_commodity_with_mulesoft("") : Sync.sync_commodity("");
                    int index = 0;
                    while (true)
                    {
                        if (index >= this.n_commodity)
                        {
                            break;
                        }
                        this.List_Status.AppendText(strArray5[index] + Environment.NewLine);
                        index++;
                    }
                }
                if (this.n_relation > 0)
                {
                    string[] strArray6 = new string[this.n_relation];
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    this.List_Status.AppendText("SYNC RELATION" + Environment.NewLine);
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    strArray6 = WBSetting.activeMulesoftIntegration ? Sync.sync_relation_with_mulesoft("") : Sync.sync_relation("");
                    int index = 0;
                    while (true)
                    {
                        if (index >= this.n_relation)
                        {
                            break;
                        }
                        this.List_Status.AppendText(strArray6[index] + Environment.NewLine);
                        index++;
                    }
                }
                if (this.n_contract > 0)
                {
                    string[] strArray7 = new string[this.n_contract];
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    this.List_Status.AppendText("SYNC CONTRACT" + Environment.NewLine);
                    this.List_Status.AppendText("---------------------------------" + Environment.NewLine);
                    strArray7 = WBSetting.activeMulesoftIntegration ? Sync.sync_contract_with_mulesoft("") : Sync.sync_contract("");
                    int index = 0;
                    while (true)
                    {
                        if (index >= this.n_contract)
                        {
                            break;
                        }
                        this.List_Status.AppendText(strArray7[index] + Environment.NewLine);
                        index++;
                    }
                }
                this.btn_next.Visible = true;
                if ((WBSetting.zwb == "Y") && (WBSetting.cpuSAP == "Y"))
                {
                    base.Close();
                }
            }
        }

        private void InitializeComponent()
        {
            this.List_Status = new TextBox();
            this.btn_next = new Button();
            this.dgv1 = new DataGridView();
            this.dgv2 = new DataGridView();
            ((ISupportInitialize) this.dgv1).BeginInit();
            ((ISupportInitialize) this.dgv2).BeginInit();
            base.SuspendLayout();
            this.List_Status.Location = new Point(12, 12);
            this.List_Status.Multiline = true;
            this.List_Status.Name = "List_Status";
            this.List_Status.ReadOnly = true;
            this.List_Status.ScrollBars = ScrollBars.Vertical;
            this.List_Status.Size = new Size(0x1fa, 0xf9);
            this.List_Status.TabIndex = 0;
            this.btn_next.Location = new Point(0x1bb, 0x10b);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new Size(0x4b, 0x17);
            this.btn_next.TabIndex = 1;
            this.btn_next.Text = "Next >>";
            this.btn_next.UseVisualStyleBackColor = true;
            this.btn_next.Visible = false;
            this.btn_next.Click += new EventHandler(this.btn_next_Click);
            this.dgv1.AllowUserToAddRows = false;
            this.dgv1.AllowUserToDeleteRows = false;
            this.dgv1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Location = new Point(0x6c, 0x2d);
            this.dgv1.Name = "dgv1";
            this.dgv1.ReadOnly = true;
            this.dgv1.Size = new Size(0x16c, 0x5c);
            this.dgv1.TabIndex = 2;
            this.dgv1.Visible = false;
            this.dgv2.AllowUserToAddRows = false;
            this.dgv2.AllowUserToDeleteRows = false;
            this.dgv2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv2.Location = new Point(0x6c, 0x8f);
            this.dgv2.Name = "dgv2";
            this.dgv2.ReadOnly = true;
            this.dgv2.Size = new Size(0x16c, 0x65);
            this.dgv2.TabIndex = 3;
            this.dgv2.Visible = false;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(530, 0x12d);
            base.Controls.Add(this.dgv2);
            base.Controls.Add(this.dgv1);
            base.Controls.Add(this.btn_next);
            base.Controls.Add(this.List_Status);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormUploadSync";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Sync Master Data";
            base.Load += new EventHandler(this.FormUploadSync_Load);
            base.Shown += new EventHandler(this.FormUploadSync_Shown);
            ((ISupportInitialize) this.dgv1).EndInit();
            ((ISupportInitialize) this.dgv2).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

