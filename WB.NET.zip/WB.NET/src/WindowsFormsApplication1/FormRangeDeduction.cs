﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormRangeDeduction : Form
    {
        public WBTable ztable = new WBTable();
        public string CommCode;
        public string QCode;
        private bool perlusave = false;
        public bool view = false;
        private IContainer components = null;
        private DataGridView dataGridView1;
        private DataSet1 dataSet1;
        private BindingSource dataTable1BindingSource;
        private BindingSource wbcommodityrangeDeductionBindingSource;
        private Button buttonSave;
        private Button buttonDelete;
        private Button buttonClose;
        private Label label1;

        public FormRangeDeduction()
        {
            this.InitializeComponent();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.ztable.Dispose();
            base.Close();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.RowCount - 1) <= 0)
            {
                MessageBox.Show(Resource.RangeDeduction_004);
            }
            else if (this.dataGridView1.SelectedRows[0].Index >= (this.dataGridView1.RowCount - 1))
            {
                MessageBox.Show(Resource.RangeDeduction_004);
            }
            else if (this.perlusave)
            {
                MessageBox.Show(Resource.RangeDeduction_002);
            }
            else
            {
                int num;
                num = num = this.dataGridView1.CurrentRow.Index;
                if (MessageBox.Show(Resource.Mes_006, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
                {
                    this.ztable.DT.Rows[num].Delete();
                    this.ztable.Save();
                    MessageBox.Show(Resource.RangeDeduction_003);
                }
            }
        }

        private void buttonRemoveRange_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.RowCount > 0)
            {
                int index = this.dataGridView1.CurrentRow.Index;
                this.ztable.DT.Rows.RemoveAt(index);
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            int num = this.dataGridView1.Rows.Count - 1;
            if (num > 0)
            {
                int num2 = 0;
                while (true)
                {
                    if (num2 >= num)
                    {
                        WBTable ztable = new WBTable();
                        ztable = this.ztable;
                        int num3 = ztable.DT.Rows.Count - 1;
                        while (true)
                        {
                            if (num3 < 0)
                            {
                                ztable.Dispose();
                                this.ztable.Save();
                                this.dataGridView1.DataSource = this.ztable.DT;
                                this.dataGridView1.Refresh();
                                MessageBox.Show(Resource.RangeDeduction_001);
                                this.perlusave = false;
                                break;
                            }
                            if (ztable.DT.Rows[num3]["coy"].ToString() == "")
                            {
                                this.ztable.DR = ztable.DT.Rows[num3];
                                this.ztable.DT.Rows.Remove(this.ztable.DR);
                            }
                            num3--;
                        }
                        break;
                    }
                    DataGridViewRow row = this.dataGridView1.Rows[num2];
                    if (!((row.Cells == null) || string.IsNullOrEmpty(row.Cells[5].Value.ToString())))
                    {
                        DataRow row2 = null;
                        if (string.IsNullOrEmpty(row.Cells[4].Value.ToString()))
                        {
                            row2 = this.ztable.DT.NewRow();
                        }
                        else
                        {
                            DataRow[] rowArray = this.ztable.DT.Select("uniq=" + row.Cells[4].Value);
                            if ((rowArray != null) && (rowArray.Length != 0))
                            {
                                row2 = rowArray[0];
                                this.ztable.DR = row2;
                                this.ztable.DR.BeginEdit();
                            }
                        }
                        row2["Coy"] = WBData.sCoyCode;
                        row2["Location_Code"] = WBData.sLocCode;
                        row2["Comm_Code"] = this.CommCode;
                        row2["QCode"] = this.QCode;
                        row2["low_value"] = row.Cells[5].Value;
                        row2["PDeduc"] = row.Cells[6].Value;
                        if (string.IsNullOrEmpty(row.Cells[4].Value.ToString()))
                        {
                            this.ztable.DT.Rows.Add(row2);
                        }
                        else
                        {
                            this.ztable.DR = row2;
                            this.ztable.DR.EndEdit();
                        }
                    }
                    num2++;
                }
            }
        }

        private void dataGridView1_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if ((e.ColumnIndex == 5) || (e.ColumnIndex == 6))
            {
                try
                {
                    string str = "";
                    if ((this.dataGridView1.CurrentCell.EditedFormattedValue != null) && (this.dataGridView1.CurrentCell.EditedFormattedValue.ToString() != ""))
                    {
                        if (this.dataGridView1.CurrentCell.EditedFormattedValue.ToString().Length <= 6)
                        {
                            str = this.dataGridView1.CurrentCell.EditedFormattedValue.ToString();
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_607 + " 6!", Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            return;
                        }
                    }
                    else
                    {
                        str = "0";
                    }
                    float num = (float) Convert.ToDouble(str);
                    if (num > 100.0)
                    {
                        MessageBox.Show(Resource.Mes_608 + " '###.##'.   ", Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        e.Cancel = true;
                    }
                    else if (num < 0.0)
                    {
                        MessageBox.Show(Resource.Mes_609, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        e.Cancel = true;
                    }
                }
                catch
                {
                    MessageBox.Show(Resource.RegisGatepassMess_039, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    e.Cancel = true;
                }
            }
        }

        private void dataGridView1_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (this.dataGridView1.IsCurrentRowDirty)
            {
                this.perlusave = true;
                bool flag2 = false;
                if ((this.dataGridView1.Rows[e.RowIndex].Cells["low_value"].Value.ToString() == "") || (this.dataGridView1.Rows[e.RowIndex].Cells["PDeduc"].Value.ToString() == ""))
                {
                    MessageBox.Show(this, Resource.RangeDeduction_005, Resource.Title_007, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    e.Cancel = true;
                }
                foreach (DataGridViewRow row in (IEnumerable) this.dataGridView1.Rows)
                {
                    bool flag4 = !row.IsNewRow;
                    if (flag4 && ((e.RowIndex != row.Index) && (this.dataGridView1.Rows[e.RowIndex].Cells["low_value"].Value.ToString() == row.Cells["low_value"].Value.ToString())))
                    {
                        flag2 = true;
                        break;
                    }
                }
                if (flag2)
                {
                    MessageBox.Show(this, Resource.RangeDeduction_006, Resource.Title_007, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.dataGridView1.Rows[e.RowIndex].Cells["low_value"].Value = this.dataGridView1.Rows[e.RowIndex].Cells["low_value"].FormattedValue;
                    e.Cancel = true;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormRangeDeduction_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            string[] textArray1 = new string[] { " AND Comm_Code = '", this.CommCode, "' AND QCode = '", this.QCode, "'" };
            this.ztable.OpenTable("wb_commmodity_rangeDeduc", "SELECT Coy, Location_Code, Comm_Code, QCode, uniq, low_value, pdeduc FROM wb_commodity_rangeDeduc where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["Comm_Code"].Visible = false;
            this.dataGridView1.Columns["QCode"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["low_value"].Visible = true;
            this.dataGridView1.Columns["low_value"].HeaderText = "Low Value";
            this.dataGridView1.Columns["low_value"].DefaultCellStyle.Format = "N2";
            this.dataGridView1.Columns["PDeduc"].Visible = true;
            this.dataGridView1.Columns["PDeduc"].HeaderText = "Disc %";
            this.dataGridView1.Columns["PDeduc"].DefaultCellStyle.Format = "N2";
            this.label1.Text = this.QCode;
            this.ProcessTabKey(true);
            if (this.view)
            {
                this.buttonSave.Enabled = false;
                this.buttonDelete.Enabled = false;
                this.dataGridView1.ReadOnly = true;
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.dataGridView1 = new DataGridView();
            this.dataSet1 = new DataSet1();
            this.dataTable1BindingSource = new BindingSource(this.components);
            this.wbcommodityrangeDeductionBindingSource = new BindingSource(this.components);
            this.buttonSave = new Button();
            this.buttonDelete = new Button();
            this.buttonClose = new Button();
            this.label1 = new Label();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.dataSet1.BeginInit();
            ((ISupportInitialize) this.dataTable1BindingSource).BeginInit();
            ((ISupportInitialize) this.wbcommodityrangeDeductionBindingSource).BeginInit();
            base.SuspendLayout();
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new Point(0, 0x24);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new Size(0x160, 0x116);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellValidating += new DataGridViewCellValidatingEventHandler(this.dataGridView1_CellValidating);
            this.dataGridView1.RowValidating += new DataGridViewCellCancelEventHandler(this.dataGridView1_RowValidating);
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = SchemaSerializationMode.IncludeSchema;
            this.dataTable1BindingSource.DataMember = "DataTable1";
            this.dataTable1BindingSource.DataSource = this.dataSet1;
            this.buttonSave.Location = new Point(12, 320);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x41, 0x23);
            this.buttonSave.TabIndex = 2;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.buttonDelete.Location = new Point(0x53, 320);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new Size(0x41, 0x23);
            this.buttonDelete.TabIndex = 3;
            this.buttonDelete.Text = "Delete";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new EventHandler(this.buttonDelete_Click);
            this.buttonClose.Location = new Point(0x119, 0x141);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new Size(0x41, 0x22);
            this.buttonClose.TabIndex = 4;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new EventHandler(this.buttonClose_Click);
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Microsoft Sans Serif", 14f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(0x6c, 6);
            this.label1.Name = "label1";
            this.label1.Size = new Size(60, 0x18);
            this.label1.TabIndex = 5;
            this.label1.Text = "label1";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x166, 0x16f);
            base.ControlBox = false;
            base.Controls.Add(this.label1);
            base.Controls.Add(this.buttonClose);
            base.Controls.Add(this.buttonDelete);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.dataGridView1);
            base.Name = "FormRangeDeduction";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Range Deduction";
            base.Load += new EventHandler(this.FormRangeDeduction_Load);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.dataSet1.EndInit();
            ((ISupportInitialize) this.dataTable1BindingSource).EndInit();
            ((ISupportInitialize) this.wbcommodityrangeDeductionBindingSource).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }
    }
}

