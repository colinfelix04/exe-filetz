﻿namespace WindowsFormsApplication1
{
    using ciloci.Flee;
    using System;

    public class ExpressionVariabel
    {
        public double NET;
        public ExpressionOptions options;

        public ExpressionOptions opsi()
        {
            this.options = new ExpressionOptions();
            this.options.Imports.AddType(typeof(Math));
            return this.options;
        }
    }
}

