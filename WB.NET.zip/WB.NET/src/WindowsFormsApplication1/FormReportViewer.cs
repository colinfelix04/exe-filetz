﻿namespace WindowsFormsApplication1
{
    using CrystalDecisions.Windows.Forms;
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormReportViewer : Form
    {
        private IContainer components = null;
        private CrystalReportViewer crystalReportViewer1;

        public FormReportViewer()
        {
            this.InitializeComponent();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.crystalReportViewer1 = new CrystalReportViewer();
            base.SuspendLayout();
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = Cursors.Default;
            this.crystalReportViewer1.Dock = DockStyle.Fill;
            this.crystalReportViewer1.Location = new Point(0, 0);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.Size = new Size(0x342, 0x1bc);
            this.crystalReportViewer1.TabIndex = 0;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x342, 0x1bc);
            base.Controls.Add(this.crystalReportViewer1);
            base.Name = "FormReportViewer";
            this.Text = "FormReportViewer";
            base.ResumeLayout(false);
        }
    }
}

