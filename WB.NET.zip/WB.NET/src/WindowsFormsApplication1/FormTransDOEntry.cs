﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using SAP.Middleware.Connector;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Diagnostics;
    using System.Drawing;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormTransDOEntry : Form
    {
        public string oldComm;
        public string remark;
        private string CommType = "";
        private string IO;
        private string using_gunny;
        private string[] hasil = new string[3];
        public bool changeComm = false;
        public bool lSTO1DO = false;
        public bool deletebc = false;
        public string ISCC = "N";
        public string chkqty = "N";
        public string doEntryMode;
        public string pMode;
        public string pComm;
        public string pTransType;
        public string ptextNet;
        public string ptextEstate;
        public string oldDO_No;
        public string WX;
        public string RefNo;
        public string DoConvUnit;
        public string DoConv;
        public string DoConvTol;
        public string xEstQty;
        public string date1;
        public int dgvDOCurrRow;
        public bool saved = false;
        public bool ChangeDOCont;
        public bool IsReturn;
        public bool hasBeenWeighedOut = false;
        public bool scaneSPB;
        public bool expiredSPB;
        private bool need_choose_do = false;
        public DataGridView dgvTrans;
        public DataGridView dgvCont;
        public DataGridView dgvDoCont;
        public DataGridView dgvDO;
        public DataGridView dgvBatch;
        public WBTable tblTransDO;
        public WBTable tblDOContainer;
        public WBTable tblStorage;
        public WBTable zCust = new WBTable();
        public WBTable tblDO = new WBTable();
        public WBTable tblTType = new WBTable();
        public WBTable tblComm = new WBTable();
        public WBTable tblVesselMap = new WBTable();
        public string refDate = "";
        public string delivery_note = "";
        public double totalNet = 0.0;
        public double totalNetEstate = 0.0;
        public double totalVariance = 0.0;
        public double sisaNet = 0.0;
        public double sisaEstateNet = 0.0;
        public double qty;
        public double variance;
        public double DONet = 0.0;
        public double DOEstateNet = 0.0;
        public double OSNetwoTol = 0.0;
        public double OSNetTol;
        private double ongoing_opw_qty_used;
        public string party = "0";
        public string tolerance = "0";
        public string qualityInfo = "";
        public string tolling = "";
        public string transType = "";
        public string bulkPack = "";
        public string deductedBy = "0";
        public string isTrade2 = "";
        public float netto_weight = 0f;
        public string dIncoterm = "";
        public bool active_zdotrx;
        public bool active_require_do;
        private int DoTotalMulesoft;
        private int DrTotalMulesoft;
        private int DoTotalSAP;
        private WBCondition wCond;
        private WBTable t_do = new WBTable();
        private WBTable t_do_sap = new WBTable();
        public int num_of_do = 0;
        public int num_of_dr = 0;
        public int num_of_dotrx = 0;
        public string[,] map = new string[0x3e7, 0x18];
        public string uniq_contract = "";
        public string truck_number = "";
        public string transporter = "";
        public string driver_name = "";
        public string license_number = "";
        public string sto_no_item = "";
        public string setManual;
        private string CommUOM = "";
        public string isDOBesar = "";
        public bool nopw;
        public string net_estate;
        public string so_no = "";
        public string sto_no = "";
        public string so_item = "";
        public string indic = "";
        public bool auto_generate_dummy_contract = false;
        public string do_ = "";
        public string do_item = "";
        public string qty_base = "";
        public string base_uom = "";
        public string qty_do = "";
        public string do_uom = "";
        public string qty_kg = "";
        public bool loadingWithFlowMeter = false;
        public bool loadingNoFlowMeter = false;
        public bool CalcDensityToSparepart = false;
        public bool calcLoadingQtyAutomatically = false;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        public DataGridView retTable_DSAP_DO = new DataGridView();
        public DataGridView retTable_DSAP_DR = new DataGridView();
        public DataGridView retTable_DSAP_DOTRX = new DataGridView();
        private IContainer components = null;
        private Label label1;
        private Button buttonDO;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        public Button buttonSave;
        private Button button2;
        public TextBox textDO;
        public TextBox textCont;
        public TextBox textRCode;
        public TextBox textFactNet;
        public TextBox textRName;
        public Label labelAgen;
        public TextBox textComm;
        private Label label7;
        private Label label8;
        public TextBox textEstate;
        private Label label9;
        public TextBox textConvNett;
        private Label label10;
        public Label labelConvUnit;
        public TextBox textPI_No;
        private Label labelPI_No;
        private Label label11;
        public TextBox textTransporter;
        private Button btnFillContainer;
        public Label labelKB;
        public TextBox textOthNet;
        private Label label12;
        private Label label13;
        private Label labelStorageName;
        private Button buttonStorage;
        private Label labelStorage;
        public TextBox textStorage;
        private Label label16;
        public TextBox text1DOSTO;
        private Label label14;
        public TextBox text1STO;
        private Label label15;
        private RectangleShape rectangleShape1;
        public Label label1STO1DO;
        private Label labelZWB;
        private Panel panelSTO1DO;
        private ShapeContainer shapeContainer2;
        private ToolTip toolTip1;
        public Label labelQuantity;
        public Label labelQtyLeft;
        public TextBox txtDeliveryNote;
        private Label labelDN;
        private Label labelGunnyNetKg;
        public TextBox textGunnyNet;
        private Label labelGunnyNet;
        private Button but_sh_do_sap;
        public TextBox text_do_sap;
        private Label label2;
        private GroupBox gb_do_sap;
        private Label label19;
        private Label label18;
        private Label label17;
        private Label label20;
        private Label label21;
        public TextBox text_do_sap_item;
        private Button buttonPISI;
        public Label labelLoadingUOM;
        public TextBox textBoxLoadingQty;
        private Label labelLoadingQty;
        private Label label22;
        private Label label23;
        private Label lblINitem;
        public TextBox txtInNumItem;
        public TextBox txtInternalNum;
        private Label lblInternalNum;
        public TextBox text_do_sap_unit;
        public TextBox text_do_sap_qty;
        public TextBox text_do_sap_qty_kg;
        public TextBox textBoxBaseUOM;
        public TextBox textBoxQtyBaseUOM;
        private Label lbl_do_besar;
        private Label label_loading_qty_opw_uom;
        public TextBox text_opw_loading_qty;
        private Label label_loading_qty_opw;
        private Label lbl_comm_name;
        private Label lblReturnPackUom;
        public TextBox txtReturnPack;
        private Label lblReturnPack;
        public Label lblReturnKgUom;
        public TextBox txtReturnKg;
        private Label lblreturnKg;
        public TextBox textSOItem_detail;
        private Label labelSOItem_detail;
        public TextBox txtBox_QQ;
        private Label lbl_QQ;
        public TextBox txtDensity;
        private Label lblDensity;

        public FormTransDOEntry()
        {
            this.InitializeComponent();
        }

        private void adoptDataIDSYS()
        {
            if (this.try_connect_IDSYS())
            {
                try
                {
                    if ((this.txtInternalNum.Text == "") && (this.textDO.Text == ""))
                    {
                        MessageBox.Show("Please Fill in WB DO or DO " + this.sapIDSYS + " No.", "WARNING...");
                        this.need_choose_do = true;
                    }
                    else if (!((!this.text_do_sap.ReadOnly && this.text_do_sap.Visible) && this.gb_do_sap.Visible))
                    {
                        if (WBSetting.adopt_zdotrx)
                        {
                            if (this.txtInternalNum.Text != "")
                            {
                                if (this.get_data_from_zdotrx())
                                {
                                    this.filldopartial(false, true);
                                }
                            }
                            else if (this.active_zdotrx)
                            {
                                MessageBox.Show("Please Fill Loading Note No.", "WARNING...");
                                this.need_choose_do = true;
                            }
                            else if (this.active_require_do && this.get_data_from_sap())
                            {
                                this.filldopartial(true, false);
                            }
                        }
                        else if (this.get_data_from_IDSYS())
                        {
                            FormDoSAP osap = new FormDoSAP {
                                map = this.map,
                                RefNo = this.RefNo,
                                num_of_do = this.DoTotalSAP,
                                mode = "CHOOSE",
                                flagRegistration = false,
                                oldDOSAP = this.text_do_sap.Text,
                                oldInternalNo = this.txtInternalNum.Text
                            };
                            osap.ShowDialog();
                            if (osap.do_sap == "")
                            {
                                if (osap.internal_number != "")
                                {
                                    this.text_do_sap.Text = "";
                                    this.text_do_sap_item.Text = "";
                                    this.txtInternalNum.Text = osap.internal_number;
                                    this.txtInNumItem.Text = osap.internal_number_item;
                                    this.text_do_sap_qty.Text = osap.qty;
                                    this.text_do_sap_unit.Text = osap.unit;
                                    this.text_do_sap_qty_kg.Text = osap.qty_kg;
                                    this.textBoxQtyBaseUOM.Text = osap.qty_base_uom;
                                    this.textBoxBaseUOM.Text = osap.base_uom;
                                    this.textSOItem_detail.Text = osap.so_item_detail;
                                }
                            }
                            else
                            {
                                this.txtInternalNum.Text = "";
                                this.txtInNumItem.Text = "";
                                this.text_do_sap.Text = osap.do_sap;
                                this.text_do_sap_item.Text = osap.do_sap_item;
                                this.text_do_sap_qty.Text = osap.qty;
                                this.text_do_sap_unit.Text = osap.unit;
                                if ((this.bulkPack != "P") || (this.labelLoadingUOM.Text == "KG"))
                                {
                                    this.text_do_sap_qty_kg.Text = osap.qty_kg;
                                }
                                else
                                {
                                    float num = 0f;
                                    num = float.Parse(osap.qty_base_uom);
                                    if ((this.so_item != "*") && (this.so_item != ""))
                                    {
                                        this.text_do_sap_qty_kg.Text = (num * this.netto_weight).ToString();
                                    }
                                    else
                                    {
                                        WBTable table = new WBTable();
                                        WBTable table2 = new WBTable();
                                        string[] textArray1 = new string[] { " AND do_no = '", this.textDO.Text.Trim(), "' and so_item = '", Program.StrToDouble(osap.so_item_detail, 0).ToString(), "'" };
                                        table.OpenTable("wb_contract_sapinformation", "SELECT comm_code FROM wb_contract_sapinformation WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                                        table2.OpenTable("wb_commodity", "SELECT netto_weight FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + table.DT.Rows[0]["comm_code"].ToString() + "'"), WBData.conn);
                                        this.text_do_sap_qty_kg.Text = (num * float.Parse((table2.DT.Rows[0]["netto_weight"].ToString() == "") ? "0" : table2.DT.Rows[0]["netto_weight"].ToString())).ToString();
                                        table.Dispose();
                                        table2.Dispose();
                                    }
                                }
                                this.textBoxQtyBaseUOM.Text = osap.qty_base_uom;
                                this.textBoxBaseUOM.Text = osap.base_uom;
                                this.indic = osap.indic;
                                this.lbl_do_besar.Visible = osap.indic == "X";
                                this.textSOItem_detail.Text = osap.so_item_detail;
                            }
                        }
                    }
                }
                catch (Exception exception)
                {
                    MessageBox.Show("Error from IDSYS ! \n" + exception.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        private void but_sh_do_sap_Click(object sender, EventArgs e)
        {
            WBSetting.OpenSetting();
            if (!WBSetting.activeMulesoftIntegration)
            {
                if (!WBSetting.integrationIDSYS)
                {
                    if (WBSetting.IntegrationSAP != "Y")
                    {
                        if (WBSetting.adopt_zdotrx)
                        {
                            if (this.txtInternalNum.Text == "")
                            {
                                if (this.active_zdotrx)
                                {
                                    MessageBox.Show("Please Fill Loading Note No.", "WARNING...");
                                    this.need_choose_do = true;
                                    return;
                                }
                            }
                            else if (this.get_data_wb_zdo(this.txtInternalNum.Text))
                            {
                                this.filldopartial(false, true);
                            }
                        }
                    }
                    else if (this.try_connect())
                    {
                        if ((this.txtInternalNum.Text != "") || (this.textDO.Text != ""))
                        {
                            if (!((!this.text_do_sap.ReadOnly && this.text_do_sap.Visible) && this.gb_do_sap.Visible))
                            {
                                if (!WBSetting.adopt_zdotrx)
                                {
                                    if (this.get_data_from_sap())
                                    {
                                        this.filldopartial(true, false);
                                    }
                                }
                                else if (this.txtInternalNum.Text == "")
                                {
                                    if (!this.active_zdotrx)
                                    {
                                        if (this.active_require_do && this.get_data_from_sap())
                                        {
                                            this.filldopartial(true, false);
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Please Fill Loading Note No.", "WARNING...");
                                        this.need_choose_do = true;
                                        return;
                                    }
                                }
                                else if (this.get_data_from_zdotrx())
                                {
                                    this.filldopartial(false, true);
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please Fill in WB DO or DO " + this.sapIDSYS + " No.", "WARNING...");
                            this.need_choose_do = true;
                            return;
                        }
                    }
                }
                else
                {
                    this.adoptDataIDSYS();
                }
            }
            else if (!this.get_data_from_mulesoft())
            {
                return;
            }
            else
            {
                FormDoSAP osap = new FormDoSAP {
                    map = this.map,
                    RefNo = this.RefNo,
                    num_of_do = this.DoTotalMulesoft,
                    num_of_dr = this.DrTotalMulesoft,
                    mode = "CHOOSE",
                    flagRegistration = false,
                    oldDOSAP = this.text_do_sap.Text,
                    oldInternalNo = this.txtInternalNum.Text
                };
                osap.ShowDialog();
                if (osap.do_sap == "")
                {
                    if (osap.internal_number != "")
                    {
                        this.text_do_sap.Text = "";
                        this.text_do_sap_item.Text = "";
                        this.txtInternalNum.Text = osap.internal_number;
                        this.txtInNumItem.Text = osap.internal_number_item;
                        this.text_do_sap_qty.Text = osap.qty;
                        this.text_do_sap_unit.Text = osap.unit;
                        this.text_do_sap_qty_kg.Text = osap.qty_kg;
                        this.textBoxQtyBaseUOM.Text = osap.qty_base_uom;
                        this.textBoxBaseUOM.Text = osap.base_uom;
                        this.txtBox_QQ.Text = osap.customer_qq;
                        this.textSOItem_detail.Text = osap.so_item_detail;
                    }
                }
                else
                {
                    this.txtInternalNum.Text = "";
                    this.txtInNumItem.Text = "";
                    this.text_do_sap.Text = osap.do_sap;
                    this.text_do_sap_item.Text = osap.do_sap_item;
                    this.text_do_sap_qty.Text = osap.qty;
                    this.text_do_sap_unit.Text = osap.unit;
                    if ((this.bulkPack != "P") || (this.labelLoadingUOM.Text == "KG"))
                    {
                        this.text_do_sap_qty_kg.Text = osap.qty_kg;
                    }
                    else
                    {
                        float num = 0f;
                        num = float.Parse(osap.qty_base_uom);
                        if ((this.so_item != "*") && (this.so_item != ""))
                        {
                            this.text_do_sap_qty_kg.Text = (num * this.netto_weight).ToString();
                        }
                        else
                        {
                            WBTable table = new WBTable();
                            WBTable table2 = new WBTable();
                            string[] textArray1 = new string[] { " AND do_no = '", this.textDO.Text.Trim(), "' and so_item = '", Program.StrToDouble(osap.so_item_detail, 0).ToString(), "'" };
                            table.OpenTable("wb_contract_sapinformation", "SELECT comm_code FROM wb_contract_sapinformation WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                            table2.OpenTable("wb_commodity", "SELECT netto_weight FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + table.DT.Rows[0]["comm_code"].ToString() + "'"), WBData.conn);
                            this.text_do_sap_qty_kg.Text = (num * float.Parse((table2.DT.Rows[0]["netto_weight"].ToString() == "") ? "0" : table2.DT.Rows[0]["netto_weight"].ToString())).ToString();
                            table.Dispose();
                            table2.Dispose();
                        }
                    }
                    this.textBoxQtyBaseUOM.Text = osap.qty_base_uom;
                    this.textBoxBaseUOM.Text = osap.base_uom;
                    this.indic = osap.indic;
                    this.lbl_do_besar.Visible = osap.indic == "X";
                    this.textSOItem_detail.Text = osap.so_item_detail;
                }
            }
            if (WBSetting.integrationIDSYS && this.text_do_sap.ReadOnly)
            {
                this.textSOItem_detail.ReadOnly = true;
                this.text_do_sap.ReadOnly = true;
                this.txtInternalNum.ReadOnly = true;
                this.text_do_sap_item.ReadOnly = true;
                this.txtInNumItem.ReadOnly = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormTransDOContainer container = new FormTransDOContainer {
                zTable = this.tblDOContainer,
                qty = Convert.ToDouble(this.textFactNet.Text),
                dgvContainer = this.dgvCont,
                dgvDOCont = this.dgvDoCont,
                Do_No = this.textDO.Text,
                RefNo = this.RefNo,
                DoConv = this.DoConv,
                DoConvUnit = this.DoConvUnit
            };
            container.ShowDialog();
            if (!container.pSave)
            {
                this.ChangeDOCont = false;
            }
            else
            {
                this.dgvDoCont = container.dgvDoContAll;
                this.ChangeDOCont = true;
            }
            container.Dispose();
        }

        private void buttonDO_Click(object sender, EventArgs e)
        {
            this.chooseDoPISI();
            this.textDO.Focus();
        }

        private void buttonPISI_Click(object sender, EventArgs e)
        {
            this.chooseDoPISI();
            this.textDO.Focus();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            this.saveDO();
            if (this.saved)
            {
                base.Close();
            }
        }

        private void buttonStorage_Click(object sender, EventArgs e)
        {
            FormStorage storage = new FormStorage {
                pMode = "CHOOSE"
            };
            storage.ShowDialog();
            if (storage.ReturnRow != null)
            {
                this.textStorage.Text = storage.ReturnRow["Storage_Code"].ToString();
                this.labelStorageName.Text = storage.ReturnRow["Storage_Name"].ToString();
                this.textStorage.Focus();
            }
            storage.Dispose();
        }

        public void cekSisa(string DoNo, double zQty)
        {
            double num;
            WBTable table = new WBTable();
            table.OpenTable("vw_trans", "Select sum(NETTO) as Net from vw_trans where DO_NO = '" + DoNo + "' and (deleted is null or deleted = 'N') and report_date is not null", WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                num = 0.0;
            }
            else
            {
                table.DR = table.DT.Rows[0];
                num = (table.DR["Net"].ToString().Length <= 0) ? 0.0 : Convert.ToDouble(table.DR["Net"].ToString());
            }
            this.labelQtyLeft.Text = Convert.ToString(Math.Floor((double) (zQty - num)));
            this.labelQuantity.Text = "";
            table.Dispose();
        }

        private void check_do(DataRow pDoRow)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_vessel_map", "SELECT * FROM wb_vessel_map WHERE uniq_item ='" + pDoRow["uniq"].ToString() + "'", WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                table.Dispose();
                if (Program.getFieldValue("wb_transaction_type", "is_vessel", "transaction_code", pDoRow["transaction_code"].ToString()) == "Y")
                {
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_vessel_map", "SELECT * FROM wb_vessel_map WHERE uniq_vessel ='" + pDoRow["uniq"].ToString() + "'", WBData.conn);
                    if (table2.DT.Rows.Count != 0)
                    {
                        table2.Dispose();
                    }
                    else
                    {
                        MessageBox.Show("Can not use DO Vessel.\nDO Vessel has no DO PO Vessel.\nPlease Map Vessel DO first.\nThank you.", "WARNING...", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.textDO.Focus();
                        return;
                    }
                }
                this.wCond = new WBCondition();
                this.hideDOSAPForm(false);
                this.retTable_DSAP_DO = new DataGridView();
                this.retTable_DSAP_DOTRX = new DataGridView();
                this.retTable_DSAP_DR = new DataGridView();
                string[] aField = new string[] { "comm_code" };
                string[] aFind = new string[] { pDoRow["comm_code"].ToString() };
                this.tblComm.DR = this.tblComm.GetData(aField, aFind);
                DataRow[] dgRows = new DataRow[] { pDoRow, this.tblComm.DR };
                this.wCond.fillParameter("ACTIVE_ADOPT_ZDOTRX", dgRows);
                if (this.wCond.getResult())
                {
                    this.active_require_do = false;
                    this.active_zdotrx = true;
                    this.lblInternalNum.Text = "Loading Note";
                    this.gb_do_sap.Visible = true;
                    this.txtBox_QQ.Visible = true;
                    this.lbl_QQ.Visible = true;
                }
                else if (((Program.getFieldValue("wb_transaction_type", "trx_require_internal_no", "transaction_code", pDoRow["transaction_code"].ToString()) == "Y") && (this.CommType == "S")) && (this.isTrade2 == "T"))
                {
                    this.gb_do_sap.Visible = true;
                    this.active_require_do = true;
                    this.txtBox_QQ.Visible = true;
                    this.lbl_QQ.Visible = true;
                    this.active_zdotrx = false;
                    this.lblInternalNum.Text = "Internal No";
                }
                else
                {
                    this.active_require_do = false;
                    this.active_zdotrx = false;
                    this.gb_do_sap.Visible = false;
                    this.text_do_sap.Text = "";
                    this.txtInternalNum.Text = "";
                    this.txtInNumItem.Text = "";
                    this.text_do_sap_item.Text = "";
                    this.text_do_sap_qty.Text = "";
                    this.text_do_sap_unit.Text = "";
                    this.txtBox_QQ.Text = "";
                    this.text_do_sap_qty_kg.Text = "";
                    this.textBoxQtyBaseUOM.Text = "";
                    this.textBoxBaseUOM.Text = "";
                    this.textSOItem_detail.Text = "";
                }
                if (this.gb_do_sap.Visible && (WBSetting.IntegrationSAP == "Y"))
                {
                    if (!WBSetting.adopt_zdotrx)
                    {
                        this.txtInternalNum.ReadOnly = true;
                        this.txtBox_QQ.Visible = false;
                        this.lbl_QQ.Visible = false;
                    }
                    else
                    {
                        this.txtInternalNum.ReadOnly = false;
                        this.txtBox_QQ.Visible = true;
                        this.lbl_QQ.Visible = true;
                    }
                    this.text_do_sap.ReadOnly = true;
                    this.text_do_sap_item.ReadOnly = true;
                    this.txtInNumItem.ReadOnly = true;
                    this.but_sh_do_sap.Visible = true;
                    this.textSOItem_detail.ReadOnly = true;
                }
                else
                {
                    this.text_do_sap.ReadOnly = false;
                    this.text_do_sap_item.ReadOnly = false;
                    this.txtInternalNum.ReadOnly = false;
                    this.txtInNumItem.ReadOnly = false;
                    if (!WBSetting.adopt_zdotrx)
                    {
                        this.but_sh_do_sap.Enabled = WBSetting.integrationIDSYS;
                        this.but_sh_do_sap.Visible = true;
                    }
                    else if (WBSetting.integrationIDSYS)
                    {
                        this.but_sh_do_sap.Enabled = true;
                        this.but_sh_do_sap.Visible = true;
                    }
                    else
                    {
                        this.but_sh_do_sap.Enabled = true;
                        this.but_sh_do_sap.Visible = WBSetting.integrationIDSYS && false;
                    }
                    this.textSOItem_detail.ReadOnly = false;
                }
            }
            else
            {
                MessageBox.Show("DO PO Vessel can not be used in weighing", "WARNING...");
                this.textDO.Focus();
            }
        }

        private void checkDecimalOnKeyPress(TextBox textBox, KeyPressEventArgs e)
        {
            if (WBSetting.allowDecimalLoadingQty)
            {
                if (!Program.CheckNumericForLoadingQty(textBox.Text))
                {
                    textBox.Text = "0";
                }
            }
            else
            {
                bool flag4 = true;
                if (((e.KeyChar < '0') || (e.KeyChar > '9')) ? (e.KeyChar == '\b') : true)
                {
                    flag4 = false;
                }
                e.Handled = flag4;
            }
        }

        private bool CheckPeriodDO(DataRow prDO, string pDate) => 
            (prDO["checkPeriod"].ToString() == "Y") && (Convert.ToDateTime(pDate) > Convert.ToDateTime(prDO["Do_Date2"].ToString()));

        private bool CheckSPB()
        {
            using (IEnumerator enumerator = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                    string strA = this.txtDeliveryNote.Text.Trim();
                    WBTable table = new WBTable();
                    table.OpenTable("wb_delivery_note", "Select * From wb_delivery_note where Do_No='" + current.Cells["DO_No"].Value.ToString().Trim() + "'", WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num >= table.DT.Rows.Count)
                            {
                                break;
                            }
                            table.DR = table.DT.Rows[num];
                            bool flag2 = strA.Length != table.DR["delivery_note_from"].ToString().Length;
                            if (flag2 || ((string.Compare(strA, table.DR["Delivery_Note_From"].ToString()) < 0) || (string.Compare(strA, table.DR["Delivery_Note_to"].ToString()) > 0)))
                            {
                                num++;
                                continue;
                            }
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        private void chooseDoPISI()
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFrom = "formTransDO",
                pFind = this.textDO.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.tblDO.ReOpen();
                this.tblTType.ReOpen();
                string[] aField = new string[] { "Do_No" };
                string[] aFind = new string[] { contract.ReturnRow["Do_NO"].ToString() };
                DataRow data = this.tblDO.GetData(aField, aFind);
                string[] textArray3 = new string[] { "Transaction_code" };
                string[] textArray4 = new string[] { data["transaction_code"].ToString() };
                DataRow row2 = this.tblTType.GetData(textArray3, textArray4);
                this.IO = row2["IO"].ToString();
                this.tblVesselMap.OpenTable("wb_vessel_map", "SELECT uniq_item, qty_map, completed from wb_vessel_map where uniq_vessel = '" + data["uniq"].ToString() + "'", WBData.conn);
                if (this.tblVesselMap.DT.Rows.Count > 0)
                {
                    DataRow row3 = this.tblVesselMap.DT.Rows[0];
                    if ((row2["is_vessel"].ToString() == "Y") && (row3["completed"].ToString() == "Y"))
                    {
                        MessageBox.Show("DO Vessel is already completed", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        return;
                    }
                }
                if (!this.CheckPeriodDO(contract.ReturnRow, this.refDate))
                {
                    this.textDO.Text = contract.ReturnRow["Do_NO"].ToString();
                    this.uniq_contract = contract.ReturnRow["uniq"].ToString();
                    this.SetorVar(contract.ReturnRow);
                    if (this.dgvDO.Rows.Count > 0)
                    {
                        if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                        {
                            this.txtDeliveryNote.Enabled = false;
                        }
                        else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                        {
                            this.txtDeliveryNote.Enabled = false;
                        }
                        else if (((this.CommType == "F") && !this.CheckSPB()) && this.txtDeliveryNote.Visible)
                        {
                            this.txtDeliveryNote.Enabled = false;
                        }
                    }
                    this.label1.Text = (this.IO != "I") ? "Sales Order No." : "Delivery Order No.";
                }
                else
                {
                    string[] textArray5 = new string[] { "The period of DO  '", contract.ReturnRow["DO_NO"].ToString(), "' has been expired after ", contract.ReturnRow["Do_Date2"].ToString().Substring(0, 10), "...!" };
                    MessageBox.Show(string.Concat(textArray5), "WARNING...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            contract.Dispose();
        }

        private void comboDOContainer_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = '\0';
        }

        public bool connectIDSYS()
        {
            bool flag2;
            string requestUriString = new WBIDSYSIntegrator().getURL("IDSYS_ADOPT_DOPARTIAL");
            requestUriString = requestUriString.Substring(0, requestUriString.Length - 0x17);
            try
            {
                HttpWebResponse response = (HttpWebResponse) ((HttpWebRequest) WebRequest.Create(requestUriString)).GetResponse();
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Debug.Write($"{requestUriString} Available");
                    flag2 = true;
                }
                else
                {
                    MessageBox.Show($"{requestUriString} Returned, but with status: {response.StatusDescription}");
                    flag2 = false;
                }
            }
            catch (Exception exception1)
            {
                MessageBox.Show($"{requestUriString} unavailable: {exception1.Message}");
                flag2 = false;
            }
            return flag2;
        }

        private void countQtyLeft(string pDoNo)
        {
            string[] aField = new string[] { "DO_NO" };
            string[] aFind = new string[] { this.textDO.Text };
            DataRow data = this.tblDO.GetData(aField, aFind);
            if (this.using_gunny == "Y")
            {
                this.OSNetwoTol = Convert.ToDouble($"{Program.checkOSbyGunny(pDoNo, "", this.RefNo, "N"):N0}");
                this.OSNetTol = ((data["tolerance"].ToString().Trim() == "") && (data["tolerance"].ToString().Trim() == "0")) ? this.OSNetwoTol : Convert.ToDouble($"{Program.checkOSbyGunny(pDoNo, "", this.RefNo, "Y"):N0}");
            }
            else
            {
                this.OSNetwoTol = Program.checkOS(pDoNo, "", this.RefNo, "N");
                this.OSNetTol = ((data["tolerance"].ToString().Trim() == "") && (data["tolerance"].ToString().Trim() == "0")) ? this.OSNetwoTol : Program.checkOS(pDoNo, "", this.RefNo, "Y");
                if (data["deductedBy"].ToString() == "1")
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_transaction_type", "SELECT * FROM wb_transaction_type WHERE " + WBData.CompanyLocation(""), WBData.conn);
                    string[] textArray3 = new string[] { "Transaction_Code" };
                    string[] textArray4 = new string[] { data["transaction_code"].ToString() };
                    DataRow row2 = table.GetData(textArray3, textArray4);
                    if ((row2 != null) && (row2["IO"].ToString().Trim().ToUpper() == "I"))
                    {
                        this.ongoing_opw_qty_used = Convert.ToDouble($"{Program.checkQtyUsedOngoingOPW(pDoNo, "", this.RefNo, "", ""):N0}");
                        this.OSNetwoTol -= Convert.ToDouble(this.ongoing_opw_qty_used);
                        this.OSNetTol -= Convert.ToDouble(this.ongoing_opw_qty_used);
                    }
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public void f_load()
        {
            this.labelAgen.Text = "";
            this.labelKB.Text = "";
            this.label1STO1DO.Visible = false;
            this.labelZWB.Visible = false;
            this.textOthNet.Text = "0";
            this.textFactNet.Text = "0";
            this.textGunnyNet.Visible = false;
            this.labelGunnyNet.Visible = false;
            this.labelGunnyNetKg.Visible = false;
            if (this.doEntryMode == "ADD")
            {
                if (this.dgvDO.Rows.Count == 0)
                {
                    this.textOthNet.Enabled = false;
                    this.textFactNet.Enabled = false;
                    this.txtDeliveryNote.Visible = false;
                    this.labelDN.Visible = false;
                }
                else
                {
                    this.textOthNet.Enabled = true;
                    this.textFactNet.Enabled = true;
                    this.txtDeliveryNote.Visible = true;
                    if (WBSetting.default_delivery_note_for_split)
                    {
                        this.txtDeliveryNote.Text = this.delivery_note;
                    }
                    this.labelDN.Visible = true;
                    this.textOthNet.Enabled = this.totalNetEstate != 0.0;
                }
                if (WBSetting.adopt_zdotrx)
                {
                    this.gb_do_sap.Visible = true;
                    this.txtInternalNum.Enabled = true;
                    this.txtInternalNum.ReadOnly = false;
                    this.lblInternalNum.Text = "Loading Note";
                }
            }
            else if (((this.doEntryMode == "EDIT") || ((this.doEntryMode == "EDIT_OPW") || (this.doEntryMode == "ADD_RETUR"))) || (this.doEntryMode == "VIEW"))
            {
                this.textDO.Focus();
                this.txtDeliveryNote.Visible = false;
                this.labelDN.Visible = false;
                if (this.dgvDOCurrRow == 0)
                {
                    this.textOthNet.Enabled = false;
                    this.textFactNet.Enabled = false;
                }
                else
                {
                    this.textOthNet.Enabled = true;
                    this.textFactNet.Enabled = true;
                    this.textOthNet.Enabled = this.totalNetEstate != 0.0;
                }
                if ((this.doEntryMode != "VIEW") & !this.IsReturn)
                {
                    if ((this.dgvDO.CurrentRow.Cells["do_sap"].Value.ToString().Trim() == "") && (this.dgvDO.CurrentRow.Cells["internal_number"].Value.ToString().Trim() == ""))
                    {
                        this.gb_do_sap.Visible = false;
                    }
                    else if (WBSetting.integrationIDSYS)
                    {
                        this.gb_do_sap.Visible = this.transType == "JUL";
                    }
                    else
                    {
                        this.gb_do_sap.Visible = true;
                        this.lblInternalNum.Text = !WBSetting.adopt_zdotrx ? "Internal No" : "Loading Note";
                    }
                }
            }
            if (WBSetting.Container == "N")
            {
                this.btnFillContainer.Visible = false;
            }
            if (WBSetting.Field("Check_Storage") != "N")
            {
                this.tblStorage = new WBTable();
                this.tblStorage.OpenTable("wb_storage", "Select * from wb_storage", WBData.conn);
                Program.AutoComp(this.tblStorage, "Storage_code", this.textStorage);
            }
            else
            {
                this.textStorage.Visible = false;
                this.buttonStorage.Visible = false;
                this.labelStorageName.Visible = false;
                this.labelStorage.Visible = false;
            }
            this.tblTType.OpenTable("wb_transaction_type", "select * from wb_transaction_type where" + WBData.CompanyLocation(""), WBData.conn);
            if (this.doEntryMode == "ADD")
            {
                this.tblDO.OpenTable("wb_contract", "select * from wb_contract where" + WBData.CompanyLocation(" and (closed is null or closed <> 'X' or closed = 'N') and zAuto = 'N'"), WBData.conn);
            }
            else
            {
                this.tblDO.OpenTable("wb_contract", "select * from wb_contract where" + WBData.CompanyLocation(" and (((closed is null or closed <> 'X' or closed = 'N') and zAuto = 'N') or do_no = '" + this.textDO.Text.Trim() + "')"), WBData.conn);
            }
            Program.AutoComp(this.tblDO, "Do_No", this.textDO);
            Program.AutoComp(this.tblDO, "PI_No", this.textPI_No);
            if (WBSetting.zwb != "Y")
            {
                this.labelZWB.Visible = false;
            }
            this.panelSTO1DO.Visible = WBSetting.locType == "0";
            this.sisaNet = this.totalNet;
            this.sisaEstateNet = this.totalNetEstate;
            if ((this.doEntryMode == "ADD") && (this.dgvDO.Rows.Count > 0))
            {
                this.sisaNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["netto"].Value.ToString());
                this.sisaEstateNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString());
            }
            if (!(((this.doEntryMode == "EDIT") || ((this.doEntryMode == "EDIT_OPW") || (this.doEntryMode == "VIEW"))) ? (this.dgvDOCurrRow > 0) : false))
            {
                if ((this.doEntryMode == "EDIT") && (this.dgvDOCurrRow == 0))
                {
                    this.sisaNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["netto"].Value.ToString());
                    this.sisaEstateNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString());
                }
            }
            else
            {
                this.sisaNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["netto"].Value.ToString());
                this.sisaEstateNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString());
                this.DONet = Convert.ToDouble(this.dgvDO.Rows[this.dgvDOCurrRow].Cells["netto"].Value.ToString());
                this.DOEstateNet = Convert.ToDouble(this.dgvDO.Rows[this.dgvDOCurrRow].Cells["Estate_qty"].Value.ToString());
                this.sisaNet += this.DONet;
                this.sisaEstateNet += this.DOEstateNet;
            }
            string[] textArray1 = new string[] { this.doEntryMode, " DO for Ref ", this.RefNo, " Available Net (", $"{this.sisaEstateNet:N0}", @"\", $"{this.sisaNet:N0}", ")" };
            this.Text = string.Concat(textArray1);
            if (((this.doEntryMode == "EDIT") || ((this.doEntryMode == "EDIT_OPW") || (this.doEntryMode == "ADD_RETUR"))) || (this.doEntryMode == "VIEW"))
            {
                string[] aField = new string[] { "DO_NO" };
                string[] aFind = new string[] { this.textDO.Text };
                DataRow data = this.tblDO.GetData(aField, aFind);
                string[] textArray4 = new string[] { "Transaction_code" };
                string[] textArray5 = new string[] { data["transaction_code"].ToString() };
                DataRow row2 = this.tblTType.GetData(textArray4, textArray5);
                this.IO = row2["IO"].ToString();
                this.tblComm.OpenTable("wb_comm", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.dgvDO.CurrentRow.Cells["Comm_Code"].Value.ToString() + "'"), WBData.conn);
                string[] textArray6 = new string[] { "comm_code" };
                string[] textArray7 = new string[] { this.dgvDO.CurrentRow.Cells["Comm_Code"].Value.ToString() };
                DataRow row3 = this.tblComm.GetData(textArray6, textArray7);
                this.textDO.Text = this.dgvDO.CurrentRow.Cells["DO_No"].Value.ToString();
                this.oldDO_No = this.textDO.Text;
                if (ReferenceEquals(data, null))
                {
                }
                this.label1.Text = (row2["IO"].ToString() != "I") ? "Sales Order No." : "Delivery Order No.";
                this.SetorVar(data);
                this.textComm.Text = this.dgvDO.CurrentRow.Cells["Comm_Code"].Value.ToString();
                if (row3 == null)
                {
                    this.using_gunny = "N";
                    this.CommType = "S";
                }
                else
                {
                    this.using_gunny = row3["using_gunny"].ToString();
                    this.CommType = row3["Type"].ToString();
                    this.bulkPack = row3["BulkPack"].ToString();
                    this.isTrade2 = row3["Trade"].ToString();
                    this.labelLoadingUOM.Text = row3["Unit"].ToString();
                    this.label_loading_qty_opw_uom.Text = row3["Unit"].ToString();
                    this.lblReturnPackUom.Text = row3["Unit"].ToString();
                    this.netto_weight = float.Parse((row3["netto_weight"].ToString() == "") ? "0" : row3["netto_weight"].ToString());
                    this.lbl_comm_name.Text = row3["comm_name"].ToString();
                }
                this.textCont.Text = this.dgvDO.CurrentRow.Cells["Contract"].Value.ToString();
                this.textRCode.Text = this.dgvDO.CurrentRow.Cells["Relation_Code"].Value.ToString().Trim();
                this.textRName.Text = this.dgvDO.CurrentRow.Cells["Relation_Name"].Value.ToString().Trim();
                this.textFactNet.Text = this.dgvDO.CurrentRow.Cells["Netto"].Value.ToString();
                if (this.dgvDO.CurrentRow.Cells["loading_qty"].Value != null)
                {
                    this.textBoxLoadingQty.Text = this.dgvDO.CurrentRow.Cells["loading_qty"].Value.ToString();
                }
                this.txtDensity.Text = ((this.dgvDO.CurrentRow.Cells["density"].Value == null) || (this.dgvDO.CurrentRow.Cells["density"].Value.ToString().Trim() == "")) ? "0" : this.dgvDO.CurrentRow.Cells["density"].Value.ToString();
                if (this.CommType == "G")
                {
                    this.textGunnyNet.Visible = true;
                    this.labelGunnyNet.Visible = true;
                    this.labelGunnyNetKg.Visible = true;
                    double num = 0.0;
                    int num2 = this.dgvBatch.RowCount - 1;
                    while (true)
                    {
                        if (num2 < 0)
                        {
                            this.textGunnyNet.Text = num.ToString();
                            break;
                        }
                        DataGridViewRow row4 = this.dgvBatch.Rows[num2];
                        if (row4.Cells["SO_No"].Value.ToString().Trim() == this.textDO.Text)
                        {
                            num += Program.StrToDouble(this.dgvBatch.Rows[num2].Cells["Netto"].Value.ToString(), 0);
                        }
                        num2--;
                    }
                }
                this.textOthNet.Text = this.dgvDO.CurrentRow.Cells["Estate_Qty"].Value.ToString();
                this.textConvNett.Text = this.dgvDO.CurrentRow.Cells["ConvNett"].Value.ToString();
                this.labelConvUnit.Text = this.dgvDO.CurrentRow.Cells["ConvUnit"].Value.ToString();
                this.labelAgen.Text = (this.dgvDO.CurrentRow.Cells["Agen"].Value.ToString() == "Y") ? "*Agen" : "";
                this.text1STO.Text = this.dgvDO.CurrentRow.Cells["STO1X"].Value.ToString();
                this.text1DOSTO.Text = this.dgvDO.CurrentRow.Cells["DO1X"].Value.ToString();
                this.textEstate.Text = this.dgvDO.CurrentRow.Cells["Estate"].Value.ToString();
                this.textStorage.Text = this.dgvDO.CurrentRow.Cells["storage_code"].Value.ToString();
                this.textTransporter.Text = this.dgvDO.CurrentRow.Cells["Transporter_Code"].Value.ToString();
            }
            this.lbl_do_besar.Visible = this.indic == "X";
            if (!(this.gb_do_sap.Visible && (WBSetting.IntegrationSAP == "Y")))
            {
                this.text_do_sap.ReadOnly = false;
                this.text_do_sap_item.ReadOnly = false;
                this.txtBox_QQ.Visible = false;
                this.txtInternalNum.ReadOnly = false;
                this.txtInNumItem.ReadOnly = false;
                this.but_sh_do_sap.Visible = WBSetting.integrationIDSYS;
                this.textSOItem_detail.ReadOnly = false;
            }
            else
            {
                if (WBSetting.adopt_zdotrx)
                {
                    this.txtInternalNum.ReadOnly = false;
                    this.txtBox_QQ.Visible = true;
                }
                else
                {
                    this.txtInternalNum.ReadOnly = true;
                    this.txtBox_QQ.Visible = false;
                }
                this.text_do_sap.ReadOnly = true;
                this.text_do_sap_item.ReadOnly = true;
                this.txtInNumItem.ReadOnly = true;
                this.but_sh_do_sap.Visible = true;
                this.textSOItem_detail.ReadOnly = true;
            }
            if (this.doEntryMode == "EDIT_OPW")
            {
                foreach (Control control in this.GetOffsprings())
                {
                    if (control.GetType() == typeof(Label))
                    {
                        control.Enabled = true;
                        continue;
                    }
                    if ((control.GetType() != typeof(Label)) || (control.GetType() != typeof(TabControl)))
                    {
                        control.Enabled = false;
                    }
                }
                this.text_opw_loading_qty.Enabled = (this.bulkPack != "B") || (this.labelLoadingUOM.Text.ToUpper() != "KG");
                this.label_loading_qty_opw.Enabled = true;
                this.label_loading_qty_opw_uom.Enabled = true;
                this.buttonSave.Enabled = true;
                this.button2.Enabled = true;
                this.label_loading_qty_opw_uom.Text = this.labelLoadingUOM.Text;
            }
            else if (this.doEntryMode != "ADD_RETUR")
            {
                if ((this.doEntryMode != "VIEW") && !((this.doEntryMode == "EDIT") & this.IsReturn))
                {
                    this.txtReturnKg.Enabled = false;
                    this.txtReturnPack.Enabled = false;
                }
                else
                {
                    foreach (Control control3 in this.GetOffsprings())
                    {
                        if (control3.GetType() == typeof(Label))
                        {
                            control3.Enabled = true;
                            continue;
                        }
                        if ((control3.GetType() != typeof(Label)) && (control3.GetType() != typeof(TabControl)))
                        {
                            control3.Enabled = false;
                        }
                    }
                    this.button2.Enabled = true;
                    this.txtReturnKg.Enabled = false;
                    this.txtReturnPack.Enabled = false;
                    this.text_opw_loading_qty.Enabled = false;
                    if ((this.doEntryMode == "EDIT") & this.IsReturn)
                    {
                        this.textBoxLoadingQty.Enabled = true;
                        this.buttonSave.Enabled = true;
                    }
                }
            }
            else
            {
                foreach (Control control2 in this.GetOffsprings())
                {
                    if (control2.GetType() == typeof(Label))
                    {
                        control2.Enabled = true;
                        continue;
                    }
                    if ((control2.GetType() != typeof(Label)) || (control2.GetType() != typeof(TabControl)))
                    {
                        control2.Enabled = false;
                    }
                }
                this.buttonSave.Enabled = true;
                this.button2.Enabled = true;
                this.label_loading_qty_opw_uom.Text = this.labelLoadingUOM.Text;
                if (this.label_loading_qty_opw_uom.Text.ToUpper() != "KG")
                {
                    this.lblReturnPack.Enabled = true;
                    this.lblReturnPackUom.Enabled = true;
                    this.txtReturnPack.Enabled = true;
                    this.txtReturnKg.Enabled = false;
                }
                else if (this.label_loading_qty_opw_uom.Text.ToUpper() == "KG")
                {
                    this.lblreturnKg.Enabled = true;
                    this.lblReturnKgUom.Enabled = true;
                    this.txtReturnKg.Enabled = true;
                    this.txtReturnPack.Enabled = false;
                }
            }
            if (((this.doEntryMode == "EDIT") || ((this.doEntryMode == "EDIT_OPW") || (this.doEntryMode == "ADD_RETUR"))) || (this.doEntryMode == "VIEW"))
            {
                this.textBoxLoadingQty.ReadOnly = (this.labelLoadingUOM.Text.ToUpper() != "KG") || (this.labelLoadingUOM.Text == "KG");
                if (((this.bulkPack != "B") || (this.labelLoadingUOM.Text.ToUpper() == "KG")) ? this.IsReturn : true)
                {
                    this.textBoxLoadingQty.ReadOnly = false;
                }
            }
            if (this.setManual == "MANUAL")
            {
                this.textBoxLoadingQty.ReadOnly = this.labelLoadingUOM.Text.ToUpper() == "KG";
            }
            if ((this.pMode == "LOADQTY") && !this.hasBeenWeighedOut)
            {
                string[] aField = new string[] { "Do_No" };
                string[] aFind = new string[] { this.textDO.Text.Trim() };
                DataRow data = this.tblDO.GetData(aField, aFind);
                if ((data != null) & !this.IsReturn)
                {
                    string[] textArray10 = new string[] { "comm_code" };
                    string[] textArray11 = new string[] { data["comm_code"].ToString() };
                    this.tblComm.DR = this.tblComm.GetData(textArray10, textArray11);
                    this.wCond = new WBCondition();
                    DataRow[] dgRows = new DataRow[] { data, this.tblComm.DR };
                    this.wCond.fillParameter("ACTIVE_ADOPT_ZDOTRX", dgRows);
                    if (this.wCond.getResult())
                    {
                        foreach (Control control4 in base.Controls)
                        {
                            if (control4 is TextBox)
                            {
                                control4.Enabled = control4 is Label;
                            }
                        }
                        this.textStorage.Enabled = true;
                        this.buttonDO.Enabled = false;
                        this.btnFillContainer.Enabled = false;
                        this.buttonPISI.Enabled = false;
                        this.but_sh_do_sap.Enabled = WBSetting.integrationIDSYS;
                        this.txtInternalNum.Enabled = false;
                        this.text1STO.Enabled = false;
                        this.text1DOSTO.Enabled = false;
                    }
                }
            }
            if (WBSetting.integrationIDSYS)
            {
                this.labelZWB.Text = "Please Synchron this DO to IDSYS";
            }
        }

        private void filldopartial(bool require_do, bool zdo_trx)
        {
            FormDoSAP osap = new FormDoSAP {
                map = this.map,
                RefNo = this.RefNo,
                num_of_do = this.num_of_do,
                num_of_dr = this.num_of_dr,
                num_of_dotrx = this.num_of_dotrx,
                mode = "CHOOSE",
                flagRegistration = false,
                oldDOSAP = this.text_do_sap.Text,
                oldInternalNo = this.txtInternalNum.Text,
                doEntryMode = this.doEntryMode,
                previousSelected_DOTable = this.dgvDO,
                retTable_DO = this.retTable_DSAP_DO,
                retTable_DOTRX = this.retTable_DSAP_DOTRX,
                retTable_DR = this.retTable_DSAP_DR
            };
            osap.ShowDialog();
            string text1 = this.license_number = "";
            string text2 = this.driver_name = text1;
            this.truck_number = this.transporter = text2;
            if (osap.do_sap == "")
            {
                if (osap.internal_number != "")
                {
                    if (zdo_trx)
                    {
                        DataRow data;
                        int num5 = Convert.ToInt32(osap.so_item_detail.ToString().Trim());
                        int num6 = 0;
                        this.tblDO.ReOpen();
                        if (osap.wbdo.Trim() != "")
                        {
                            if (osap.so_item_detail.Trim() != "00000")
                            {
                                num6 = Convert.ToInt16(osap.so_item_detail.Trim());
                            }
                            string[] aField = new string[] { "SO", "SO_Item" };
                            string[] aFind = new string[] { osap.wbdo.Trim(), num6.ToString() };
                            data = this.tblDO.GetData(aField, aFind);
                            if (ReferenceEquals(data, null))
                            {
                                string[] textArray4 = new string[] { "SO", "SO_Item" };
                                string[] textArray5 = new string[] { osap.wbdo.Trim(), "*" };
                                data = this.tblDO.GetData(textArray4, textArray5);
                            }
                        }
                        else if (osap.no_sto.Trim() == "")
                        {
                            if (osap.spb_number_item.Trim() != "00000")
                            {
                                num6 = Convert.ToInt16(osap.spb_number_item.Trim());
                            }
                            string[] aField = new string[] { "SPB_No", "SPB_Item" };
                            string[] aFind = new string[] { osap.spb_number.Trim(), num6.ToString() };
                            data = this.tblDO.GetData(aField, aFind);
                        }
                        else
                        {
                            if (osap.no_sto_item.Trim() != "00000")
                            {
                                num6 = Convert.ToInt16(osap.no_sto_item.Trim());
                            }
                            string[] aField = new string[] { "STO", "STO_Item" };
                            string[] aFind = new string[] { osap.no_sto.Trim(), num6.ToString() };
                            data = this.tblDO.GetData(aField, aFind);
                            if (ReferenceEquals(data, null))
                            {
                                string[] textArray8 = new string[] { "STO", "STO_Item" };
                                string[] textArray9 = new string[] { osap.no_sto.Trim(), "*" };
                                data = this.tblDO.GetData(textArray8, textArray9);
                            }
                        }
                        if (data == null)
                        {
                            this.textDO.Text = "";
                            if (osap.wbdo.Trim() != "")
                            {
                                MessageBox.Show("Please Create WB DO for SO " + osap.wbdo.Trim());
                            }
                            else if (osap.no_sto.Trim() != "")
                            {
                                MessageBox.Show("Please Create WB DO for STO " + osap.no_sto.Trim());
                            }
                            else
                            {
                                MessageBox.Show("Please Create WB DO for SPB " + osap.spb_number.Trim());
                            }
                            return;
                        }
                        else if ((data["deleted"].ToString().Trim() == "Y") && (data["closed"].ToString().Trim() == "Y"))
                        {
                            this.textDO.Text = "";
                            MessageBox.Show("Contract with SO " + osap.wbdo.Trim() + " is closed or deleted");
                            return;
                        }
                        else
                        {
                            this.textDO.Text = data["Do_No"].ToString().Trim();
                            this.SetorVar(data);
                            this.check_do(data);
                            this.truck_number = osap.truck_number;
                            this.transporter = osap.transporter;
                            this.driver_name = osap.driver_name;
                            this.license_number = osap.license_number;
                            this.textDO.ReadOnly = true;
                            this.buttonDO.Enabled = false;
                            this.textPI_No.ReadOnly = true;
                            this.buttonPISI.Enabled = false;
                            this.sto_no = osap.no_sto;
                            this.sto_no_item = osap.no_sto_item;
                            if (osap.no_sto == "")
                            {
                                this.sto_no = data["STO"].ToString().Trim();
                                this.sto_no_item = data["STO_item"].ToString().Trim();
                            }
                        }
                    }
                    this.text_do_sap.Text = "";
                    this.text_do_sap_item.Text = "";
                    this.txtInternalNum.Text = osap.internal_number;
                    this.txtInNumItem.Text = osap.internal_number_item;
                    this.text_do_sap_qty.Text = osap.qty;
                    this.text_do_sap_unit.Text = osap.unit;
                    this.text_do_sap_qty_kg.Text = osap.qty_kg;
                    this.textBoxQtyBaseUOM.Text = osap.qty_base_uom;
                    this.textBoxBaseUOM.Text = osap.base_uom;
                    this.textSOItem_detail.Text = osap.so_item_detail;
                    this.txtBox_QQ.Text = osap.customer_qq;
                    this.retTable_DSAP_DR = osap.retTable_DR;
                    this.retTable_DSAP_DOTRX = osap.retTable_DOTRX;
                    if ((this.retTable_DSAP_DR.Rows.Count == 1) || (this.retTable_DSAP_DOTRX.Rows.Count == 1))
                    {
                        this.hideDOSAPForm(false);
                    }
                    else
                    {
                        this.hideDOSAPForm(true);
                    }
                }
            }
            else
            {
                this.txtInternalNum.Text = "";
                this.txtInNumItem.Text = "";
                this.text_do_sap.Text = osap.do_sap;
                this.text_do_sap_item.Text = osap.do_sap_item;
                this.text_do_sap_qty.Text = osap.qty;
                this.text_do_sap_unit.Text = osap.unit;
                if ((this.bulkPack != "P") || (this.CommUOM == "KG"))
                {
                    this.text_do_sap_qty_kg.Text = osap.qty_kg;
                }
                else
                {
                    float num = 0f;
                    num = float.Parse(osap.qty_base_uom);
                    if ((this.so_item != "*") && (this.so_item != ""))
                    {
                        this.text_do_sap_qty_kg.Text = (num * this.netto_weight).ToString();
                    }
                    else
                    {
                        WBTable table = new WBTable();
                        WBTable table2 = new WBTable();
                        string[] textArray1 = new string[] { " AND do_no = '", this.textDO.Text.Trim(), "' and so_item = '", Program.StrToDouble(osap.so_item_detail, 0).ToString(), "'" };
                        table.OpenTable("wb_contract_sapinformation", "SELECT comm_code FROM wb_contract_sapinformation WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                        table2.OpenTable("wb_commodity", "SELECT netto_weight FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + table.DT.Rows[0]["comm_code"].ToString() + "'"), WBData.conn);
                        this.text_do_sap_qty_kg.Text = (num * float.Parse((table2.DT.Rows[0]["netto_weight"].ToString() == "") ? "0" : table2.DT.Rows[0]["netto_weight"].ToString())).ToString();
                        table.Dispose();
                        table2.Dispose();
                    }
                }
                this.textBoxQtyBaseUOM.Text = osap.qty_base_uom;
                this.textBoxBaseUOM.Text = osap.base_uom;
                this.isDOBesar = this.indic = osap.indic;
                this.need_choose_do = false;
                this.textSOItem_detail.Text = osap.so_item_detail;
                this.retTable_DSAP_DO = osap.retTable_DO;
                if (this.retTable_DSAP_DO.Rows.Count == 1)
                {
                    this.hideDOSAPForm(false);
                }
                else
                {
                    this.hideDOSAPForm(true);
                }
                this.lbl_do_besar.Visible = osap.indic == "X";
            }
        }

        private void FormTransDOEntry_Load(object sender, EventArgs e)
        {
            this.f_load();
            this.but_sh_do_sap.Text = this.but_sh_do_sap.Text + this.sapIDSYS;
            this.label2.Text = this.label2.Text + this.sapIDSYS;
            this.gb_do_sap.Text = this.gb_do_sap.Text + this.sapIDSYS;
            this.labelZWB.Text = this.labelZWB.Text + this.sapIDSYS;
        }

        private void FormTransDOEntry_Shown(object sender, EventArgs e)
        {
            if (this.auto_generate_dummy_contract)
            {
                this.textDO.Focus();
                this.textDO.Text = WBSetting.dummy_contract;
                this.buttonSave.Focus();
                this.buttonSave.PerformClick();
            }
        }

        private bool get_data_from_IDSYS()
        {
            bool flag4;
            string str = this.textDO.Text.Trim();
            WBIDSYSIntegrator integrator = new WBIDSYSIntegrator();
            string url = integrator.getURL("IDSYS_ADOPT_DOPARTIAL");
            if (url == "")
            {
                flag4 = false;
            }
            else
            {
                new WBTable().OpenTable("wb_contract", "Select * from wb_contract where " + WBData.CompanyLocation(" and do_no = '" + str + "'"), WBData.conn);
                string[] textArray1 = new string[11];
                textArray1[0] = "{coy:'";
                textArray1[1] = WBSetting.CoySAP;
                textArray1[2] = "',so:'";
                textArray1[3] = this.so_no;
                textArray1[4] = "',so_item:'";
                textArray1[5] = this.so_item;
                textArray1[6] = "',sto:'";
                textArray1[7] = this.sto_no;
                textArray1[8] = "',sto_item:'";
                textArray1[9] = this.sto_no_item;
                textArray1[10] = "'}";
                bool err = false;
                Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                dictionary = integrator.getDataFromIDSYS(url, string.Concat(textArray1), out err);
                if (err)
                {
                    flag4 = false;
                }
                else if (dictionary.Count <= 0)
                {
                    MessageBox.Show("Error from IDSYS !", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    flag4 = false;
                }
                else
                {
                    List<Dictionary<string, string>> source = dictionary["data"];
                    this.DoTotalSAP = source.Count<Dictionary<string, string>>();
                    if (this.DoTotalSAP <= 0)
                    {
                        MessageBox.Show("Error from IDSYS !", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        flag4 = false;
                    }
                    else
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num >= source.Count<Dictionary<string, string>>())
                            {
                                flag4 = true;
                                break;
                            }
                            int num2 = 0;
                            foreach (KeyValuePair<string, string> pair in source[num])
                            {
                                if (((num2 != 2) && ((num2 != 3) && ((num2 != 4) && (num2 != 5)))) && (num2 != 6))
                                {
                                    this.map[num, num2] = pair.Value.ToString().Trim();
                                }
                                else
                                {
                                    string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                                    this.map[num, num2] = pair.Value.ToString().Trim().Replace(".", newValue);
                                }
                                num2++;
                            }
                            num++;
                        }
                    }
                }
            }
            return flag4;
        }

        private bool get_data_from_mulesoft()
        {
            bool flag4;
            string str = this.textDO.Text.Trim();
            WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
            string str2 = integrator.getURL("ZRFC_DNET_CHECK_SO_DO");
            if (str2 == "")
            {
                flag4 = false;
            }
            else
            {
                bool err = false;
                Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                string[] resultHeaderName = new string[] { "ERRORS", "DO_DETAILS", "DO_DR_DETAILS", "MESSAGE_ID" };
                dictionary = integrator.getDataFromMulesoft(str2 + "?so_no=" + str, resultHeaderName, out err);
                if (err)
                {
                    flag4 = false;
                }
                else if (dictionary["ERRORS"].Count > 0)
                {
                    MessageBox.Show("Error from " + this.sapIDSYS + " : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    flag4 = false;
                }
                else
                {
                    List<Dictionary<string, string>> source = dictionary["DO_DETAILS"];
                    List<Dictionary<string, string>> list2 = dictionary["DO_DR_DETAILS"];
                    this.DoTotalMulesoft = source.Count<Dictionary<string, string>>();
                    this.DrTotalMulesoft = list2.Count<Dictionary<string, string>>();
                    if (this.DoTotalMulesoft > 0)
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num >= source.Count<Dictionary<string, string>>())
                            {
                                break;
                            }
                            int num2 = 0;
                            foreach (KeyValuePair<string, string> pair in source[num])
                            {
                                if (((num2 != 2) && ((num2 != 3) && ((num2 != 4) && (num2 != 5)))) && (num2 != 6))
                                {
                                    this.map[num, num2] = !string.IsNullOrEmpty(pair.Value) ? pair.Value.ToString().Trim() : "";
                                }
                                else
                                {
                                    string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                                    this.map[num, num2] = pair.Value.ToString().Trim().Replace(".", newValue);
                                }
                                num2++;
                            }
                            num++;
                        }
                    }
                    else if (this.DrTotalMulesoft > 0)
                    {
                        int num3 = 0;
                        while (true)
                        {
                            if (num3 >= list2.Count<Dictionary<string, string>>())
                            {
                                break;
                            }
                            int num4 = 0;
                            foreach (KeyValuePair<string, string> pair2 in list2[num3])
                            {
                                if (((num4 != 2) && ((num4 != 3) && ((num4 != 4) && (num4 != 5)))) && (num4 != 6))
                                {
                                    this.map[num3, num4] = !string.IsNullOrEmpty(pair2.Value) ? pair2.Value.ToString().Trim() : "";
                                }
                                else
                                {
                                    string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                                    this.map[num3, num4] = pair2.Value.ToString().Trim().Replace(".", newValue);
                                }
                                num4++;
                            }
                            num3++;
                        }
                    }
                    flag4 = true;
                }
            }
            return flag4;
        }

        private bool get_data_from_sap()
        {
            bool flag3;
            bool flag = false;
            try
            {
                WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_CHECK_SO_DO");
                WBSAP.rfcFunction.SetValue("ZWB_LOC", WBSetting.CoySAP);
                WBSAP.rfcFunction.SetValue("SO_NO", this.so_no.Trim());
                WBSAP.rfcFunction.SetValue("SO_ITEM", this.so_item.Trim());
                WBSAP.rfcFunction.SetValue("STO_NO", this.sto_no.Trim());
                WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                IRfcTable table = WBSAP.rfcFunction.GetTable("DO_DR_DETAILS");
                IRfcTable table2 = WBSAP.rfcFunction.GetTable("DO_DETAILS");
                if (WBSAP.rfcFunction.GetValue("MSG_ERROR").ToString() == "")
                {
                    this.num_of_do = table2.RowCount;
                    this.num_of_dr = table.RowCount;
                    if (this.num_of_do > 0)
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num >= table2.RowCount)
                            {
                                break;
                            }
                            int index = 0;
                            while (true)
                            {
                                if (index >= 13)
                                {
                                    num++;
                                    break;
                                }
                                if (((index != 2) && ((index != 3) && ((index != 4) && (index != 5)))) && (index != 6))
                                {
                                    this.map[num, index] = table2[num].GetString(index).Trim();
                                }
                                else
                                {
                                    string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                                    this.map[num, index] = table2[num].GetString(index).Trim().Replace(".", newValue);
                                }
                                index++;
                            }
                        }
                    }
                    else if (this.num_of_dr > 0)
                    {
                        int num3 = 0;
                        while (true)
                        {
                            if (num3 >= table.RowCount)
                            {
                                break;
                            }
                            int index = 0;
                            while (true)
                            {
                                if (index >= 10)
                                {
                                    num3++;
                                    break;
                                }
                                if (((index != 2) && (index != 4)) && (index != 5))
                                {
                                    this.map[num3, index] = table[num3].GetString(index).Trim();
                                }
                                else
                                {
                                    string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                                    this.map[num3, index] = table[num3].GetString(index).Trim().Replace(".", newValue);
                                }
                                index++;
                            }
                        }
                    }
                    flag = true;
                }
                else
                {
                    MessageBox.Show("Error from " + this.sapIDSYS + " : " + WBSAP.rfcFunction.GetValue("MSG_ERROR").ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return false;
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error from " + this.sapIDSYS + ": " + exception.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                string[] textArray1 = new string[] { "DO ", this.sapIDSYS, " & Item is not found in ", this.sapIDSYS, ".\nPlease check again" };
                MessageBox.Show(string.Concat(textArray1), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return false;
            }
            if (flag)
            {
                flag3 = true;
            }
            else
            {
                string[] textArray2 = new string[] { "DO ", this.sapIDSYS, " & Item is not longer valid in ", this.sapIDSYS, ".\nPlease choose another SO." };
                MessageBox.Show(string.Concat(textArray2), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                flag3 = false;
            }
            return flag3;
        }

        private bool get_data_from_zdotrx()
        {
            bool flag = false;
            try
            {
                WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_SAP_TO_WBNET_ZDOTRX");
                WBSAP.rfcFunction.SetValue("_ZDCONR", this.txtInternalNum.Text.Trim());
                WBSAP.rfcFunction.SetValue("ZWB_LOC", WBSetting.CoySAP);
                WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                IRfcTable table = WBSAP.rfcFunction.GetTable("ITAB_ZDOTRX");
                this.num_of_dotrx = table.RowCount;
                this.num_of_do = this.num_of_dr = 0;
                if (WBSAP.rfcFunction.GetValue("MSG_ERR_HEADER").ToString() == "")
                {
                    if (this.num_of_dotrx > 0)
                    {
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= table.RowCount)
                            {
                                flag = true;
                                break;
                            }
                            int index = 0;
                            while (true)
                            {
                                if (index >= 0x17)
                                {
                                    num2++;
                                    break;
                                }
                                if (((index != 13) && (index != 15)) && (index != 0x10))
                                {
                                    this.map[num2, index] = table[num2].GetString(index).Trim();
                                }
                                else
                                {
                                    string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                                    this.map[num2, index] = table[num2].GetString(index).Trim().Replace(".", newValue);
                                }
                                index++;
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Error from " + this.sapIDSYS + " : " + WBSAP.rfcFunction.GetValue("MSG_ERR_HEADER").ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return false;
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error from " + this.sapIDSYS + ": " + exception.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                MessageBox.Show("DO Partial is not found in " + this.sapIDSYS + ".\nPlease check again", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return false;
            }
            return flag;
        }

        private bool get_data_wb_zdo(string zdo)
        {
            bool flag5;
            WBTable table = new WBTable();
            table.OpenTable("wb_zdo", "Select internal_number, so, sto1, sto2, sto2_item, transporter, license_no, driver_name, truck_number, internal_number_item, do_item, sto1_item, comm_code, do_qty, do_uom, do_qty_kg, qty_base_uom, mark_accident, reason, SPB_No, SPB_Item from wb_zdo where " + WBData.CompanyLocation(" and internal_number = '" + zdo + "'"), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                MessageBox.Show("Error : ZDOTRX No " + zdo + "Not Exist", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                flag5 = false;
            }
            else
            {
                this.num_of_dotrx = table.DT.Rows.Count;
                this.num_of_do = this.num_of_dr = 0;
                int num2 = 0;
                while (true)
                {
                    if (num2 >= table.DT.Rows.Count)
                    {
                        flag5 = true;
                        break;
                    }
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= 0x16)
                        {
                            num2++;
                            break;
                        }
                        if (((num3 != 13) && (num3 != 15)) && (num3 != 0x10))
                        {
                            this.map[num2, num3] = table.DT.Rows[num2][num3].ToString().Trim();
                        }
                        else
                        {
                            string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                            this.map[num2, num3] = table.DT.Rows[num2][num3].ToString().Trim().Replace(".", newValue);
                        }
                        num3++;
                    }
                }
            }
            return flag5;
        }

        public void hideDOSAPForm(bool is_hiding)
        {
            if (is_hiding)
            {
                foreach (Label label in this.gb_do_sap.Controls.OfType<Label>())
                {
                    label.Hide();
                }
                foreach (TextBox box in this.gb_do_sap.Controls.OfType<TextBox>())
                {
                    box.Hide();
                }
            }
            else
            {
                foreach (Label label2 in this.gb_do_sap.Controls.OfType<Label>())
                {
                    label2.Show();
                }
                foreach (TextBox box2 in this.gb_do_sap.Controls.OfType<TextBox>())
                {
                    box2.Show();
                }
            }
            this.lbl_do_besar.Hide();
            if (!WBSetting.adopt_zdotrx)
            {
                this.txtInternalNum.ReadOnly = true;
                this.txtBox_QQ.Visible = false;
                this.lbl_QQ.Visible = false;
            }
            else
            {
                this.txtInternalNum.ReadOnly = false;
                this.txtBox_QQ.Visible = true;
                this.lbl_QQ.Visible = true;
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.label1 = new Label();
            this.textDO = new TextBox();
            this.buttonDO = new Button();
            this.textCont = new TextBox();
            this.label3 = new Label();
            this.textRCode = new TextBox();
            this.label4 = new Label();
            this.label5 = new Label();
            this.textFactNet = new TextBox();
            this.label6 = new Label();
            this.buttonSave = new Button();
            this.button2 = new Button();
            this.textRName = new TextBox();
            this.labelAgen = new Label();
            this.textComm = new TextBox();
            this.label7 = new Label();
            this.label8 = new Label();
            this.textEstate = new TextBox();
            this.label9 = new Label();
            this.textConvNett = new TextBox();
            this.label10 = new Label();
            this.labelConvUnit = new Label();
            this.textPI_No = new TextBox();
            this.labelPI_No = new Label();
            this.textTransporter = new TextBox();
            this.label11 = new Label();
            this.btnFillContainer = new Button();
            this.labelKB = new Label();
            this.textOthNet = new TextBox();
            this.label12 = new Label();
            this.label13 = new Label();
            this.labelStorageName = new Label();
            this.buttonStorage = new Button();
            this.textStorage = new TextBox();
            this.labelStorage = new Label();
            this.label16 = new Label();
            this.text1DOSTO = new TextBox();
            this.label14 = new Label();
            this.text1STO = new TextBox();
            this.label15 = new Label();
            this.rectangleShape1 = new RectangleShape();
            this.label1STO1DO = new Label();
            this.labelZWB = new Label();
            this.panelSTO1DO = new Panel();
            this.shapeContainer2 = new ShapeContainer();
            this.toolTip1 = new ToolTip(this.components);
            this.labelQuantity = new Label();
            this.labelQtyLeft = new Label();
            this.txtDeliveryNote = new TextBox();
            this.labelDN = new Label();
            this.labelGunnyNetKg = new Label();
            this.textGunnyNet = new TextBox();
            this.labelGunnyNet = new Label();
            this.but_sh_do_sap = new Button();
            this.text_do_sap = new TextBox();
            this.label2 = new Label();
            this.gb_do_sap = new GroupBox();
            this.txtBox_QQ = new TextBox();
            this.lbl_QQ = new Label();
            this.textSOItem_detail = new TextBox();
            this.labelSOItem_detail = new Label();
            this.lbl_do_besar = new Label();
            this.lblINitem = new Label();
            this.txtInNumItem = new TextBox();
            this.txtInternalNum = new TextBox();
            this.lblInternalNum = new Label();
            this.label22 = new Label();
            this.label23 = new Label();
            this.textBoxBaseUOM = new TextBox();
            this.textBoxQtyBaseUOM = new TextBox();
            this.label21 = new Label();
            this.text_do_sap_item = new TextBox();
            this.label20 = new Label();
            this.label19 = new Label();
            this.label18 = new Label();
            this.label17 = new Label();
            this.text_do_sap_unit = new TextBox();
            this.text_do_sap_qty = new TextBox();
            this.text_do_sap_qty_kg = new TextBox();
            this.buttonPISI = new Button();
            this.labelLoadingUOM = new Label();
            this.textBoxLoadingQty = new TextBox();
            this.labelLoadingQty = new Label();
            this.label_loading_qty_opw_uom = new Label();
            this.text_opw_loading_qty = new TextBox();
            this.label_loading_qty_opw = new Label();
            this.lbl_comm_name = new Label();
            this.lblReturnPackUom = new Label();
            this.txtReturnPack = new TextBox();
            this.lblReturnPack = new Label();
            this.lblReturnKgUom = new Label();
            this.txtReturnKg = new TextBox();
            this.lblreturnKg = new Label();
            this.txtDensity = new TextBox();
            this.lblDensity = new Label();
            this.panelSTO1DO.SuspendLayout();
            this.gb_do_sap.SuspendLayout();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x2f, 0x21);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x5e, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Delivery Order No.";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.textDO.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textDO.Location = new Point(0x92, 0x1c);
            this.textDO.MaxLength = 100;
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0x14e, 0x16);
            this.textDO.TabIndex = 0;
            this.textDO.TextChanged += new EventHandler(this.textDO_Changed);
            this.textDO.KeyPress += new KeyPressEventHandler(this.textCompany_KeyPress);
            this.textDO.Leave += new EventHandler(this.textDO_L);
            this.buttonDO.Location = new Point(0x1e3, 0x1b);
            this.buttonDO.Margin = new Padding(0);
            this.buttonDO.Name = "buttonDO";
            this.buttonDO.Size = new Size(0x17, 0x17);
            this.buttonDO.TabIndex = 1;
            this.buttonDO.Text = "...";
            this.buttonDO.UseVisualStyleBackColor = true;
            this.buttonDO.Click += new EventHandler(this.buttonDO_Click);
            this.textCont.Location = new Point(0x93, 0x60);
            this.textCont.Name = "textCont";
            this.textCont.ReadOnly = true;
            this.textCont.Size = new Size(180, 20);
            this.textCont.TabIndex = 7;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x4c, 0x63);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x43, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Contract No.";
            this.textRCode.Location = new Point(0x93, 0x7a);
            this.textRCode.Name = "textRCode";
            this.textRCode.ReadOnly = true;
            this.textRCode.Size = new Size(0x63, 20);
            this.textRCode.TabIndex = 8;
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x22, 0x7d);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x6b, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Relation Code/Name";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x4c, 0x13c);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x41, 13);
            this.label5.TabIndex = 0x10;
            this.label5.Text = "Factory Nett";
            this.textFactNet.Location = new Point(0x93, 0x139);
            this.textFactNet.Name = "textFactNet";
            this.textFactNet.Size = new Size(0x53, 20);
            this.textFactNet.TabIndex = 2;
            this.textFactNet.Text = "0";
            this.textFactNet.TextAlign = HorizontalAlignment.Right;
            this.textFactNet.KeyPress += new KeyPressEventHandler(this.textFactNet_KeyPress);
            this.textFactNet.Leave += new EventHandler(this.textFactNet_Leave);
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xe7, 0x13c);
            this.label6.Name = "label6";
            this.label6.Size = new Size(20, 13);
            this.label6.TabIndex = 0x12;
            this.label6.Text = "Kg";
            this.buttonSave.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonSave.Location = new Point(0x1be, 0x1f9);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x6c, 0x2f);
            this.buttonSave.TabIndex = 4;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.button2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x242, 0x1f9);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x6c, 0x2f);
            this.button2.TabIndex = 5;
            this.button2.Text = "&Cancel";
            this.toolTip1.SetToolTip(this.button2, "Cancel this Screen\r\nShortcut : Esc atau Alt+C");
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.textRName.Location = new Point(0xfe, 0x7a);
            this.textRName.Name = "textRName";
            this.textRName.ReadOnly = true;
            this.textRName.Size = new Size(0x155, 20);
            this.textRName.TabIndex = 11;
            this.labelAgen.AutoSize = true;
            this.labelAgen.Location = new Point(0x28b, 0x182);
            this.labelAgen.Name = "labelAgen";
            this.labelAgen.Size = new Size(0x24, 13);
            this.labelAgen.TabIndex = 0x16;
            this.labelAgen.Text = "*Agen";
            this.textComm.Location = new Point(0x93, 70);
            this.textComm.Name = "textComm";
            this.textComm.ReadOnly = true;
            this.textComm.Size = new Size(180, 20);
            this.textComm.TabIndex = 6;
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0x55, 0x49);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x3a, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Commodity";
            this.label8.AutoSize = true;
            this.label8.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label8.Location = new Point(0x156, 0x60);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x77, 0x10);
            this.label8.TabIndex = 0x19;
            this.label8.Text = "DO Quantity Left";
            this.textEstate.AutoCompleteSource = AutoCompleteSource.RecentlyUsedList;
            this.textEstate.Location = new Point(0x93, 0xae);
            this.textEstate.Name = "textEstate";
            this.textEstate.ReadOnly = true;
            this.textEstate.Size = new Size(180, 20);
            this.textEstate.TabIndex = 10;
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x68, 0xb1);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x25, 13);
            this.label9.TabIndex = 0x11;
            this.label9.Text = "Estate";
            this.textConvNett.Location = new Point(0x91, 0x216);
            this.textConvNett.Name = "textConvNett";
            this.textConvNett.Size = new Size(0x53, 20);
            this.textConvNett.TabIndex = 3;
            this.textConvNett.Text = "0";
            this.textConvNett.TextAlign = HorizontalAlignment.Right;
            this.textConvNett.Visible = false;
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0x1b, 0x219);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x73, 13);
            this.label10.TabIndex = 30;
            this.label10.Text = "Qty Convertion (Comm)";
            this.label10.Visible = false;
            this.labelConvUnit.AutoSize = true;
            this.labelConvUnit.Location = new Point(0xe5, 0x219);
            this.labelConvUnit.Name = "labelConvUnit";
            this.labelConvUnit.Size = new Size(80, 13);
            this.labelConvUnit.TabIndex = 0x1f;
            this.labelConvUnit.Text = "Convertion Unit";
            this.labelConvUnit.Visible = false;
            this.textPI_No.BackColor = SystemColors.ButtonHighlight;
            this.textPI_No.Location = new Point(0x93, 0xe5);
            this.textPI_No.Name = "textPI_No";
            this.textPI_No.Size = new Size(0x88, 20);
            this.textPI_No.TabIndex = 13;
            this.textPI_No.KeyPress += new KeyPressEventHandler(this.textPINo_KeyPress);
            this.textPI_No.Leave += new EventHandler(this.textPINo_Leave);
            this.labelPI_No.AutoSize = true;
            this.labelPI_No.Location = new Point(0x59, 0xe8);
            this.labelPI_No.Name = "labelPI_No";
            this.labelPI_No.Size = new Size(0x34, 13);
            this.labelPI_No.TabIndex = 0x22;
            this.labelPI_No.Text = "PI/SI No.";
            this.textTransporter.CharacterCasing = CharacterCasing.Upper;
            this.textTransporter.Location = new Point(0x93, 0x94);
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.ReadOnly = true;
            this.textTransporter.Size = new Size(180, 20);
            this.textTransporter.TabIndex = 9;
            this.label11.AutoSize = true;
            this.label11.Location = new Point(0x52, 0x97);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x3d, 13);
            this.label11.TabIndex = 0x10;
            this.label11.Text = "Transporter";
            this.btnFillContainer.Location = new Point(0x236, 0x1c);
            this.btnFillContainer.Name = "btnFillContainer";
            this.btnFillContainer.Size = new Size(0x79, 0x21);
            this.btnFillContainer.TabIndex = 0x17;
            this.btnFillContainer.Text = "Fill &DO Container";
            this.toolTip1.SetToolTip(this.btnFillContainer, "Fill this DO to Container\r\nShortcut : Alt+D");
            this.btnFillContainer.UseVisualStyleBackColor = true;
            this.btnFillContainer.Click += new EventHandler(this.button3_Click);
            this.labelKB.AutoSize = true;
            this.labelKB.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelKB.Location = new Point(0x20c, 0);
            this.labelKB.Name = "labelKB";
            this.labelKB.Size = new Size(150, 20);
            this.labelKB.TabIndex = 0x18;
            this.labelKB.Text = "*Kawasan Berikat";
            this.textOthNet.AutoCompleteSource = AutoCompleteSource.RecentlyUsedList;
            this.textOthNet.Location = new Point(0x93, 0x11f);
            this.textOthNet.Name = "textOthNet";
            this.textOthNet.Size = new Size(0x53, 20);
            this.textOthNet.TabIndex = 1;
            this.textOthNet.Text = "0";
            this.textOthNet.TextAlign = HorizontalAlignment.Right;
            this.textOthNet.KeyPress += new KeyPressEventHandler(this.textFactNet_KeyPress);
            this.textOthNet.Leave += new EventHandler(this.textOthNet_Leave);
            this.label12.AutoSize = true;
            this.label12.Location = new Point(0x55, 290);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x38, 13);
            this.label12.TabIndex = 40;
            this.label12.Text = "Other Nett";
            this.label13.AutoSize = true;
            this.label13.Location = new Point(0xe7, 290);
            this.label13.Name = "label13";
            this.label13.Size = new Size(20, 13);
            this.label13.TabIndex = 0x29;
            this.label13.Text = "Kg";
            this.labelStorageName.AutoSize = true;
            this.labelStorageName.Location = new Point(260, 0x107);
            this.labelStorageName.Name = "labelStorageName";
            this.labelStorageName.Size = new Size(0x1c, 13);
            this.labelStorageName.TabIndex = 0x1a;
            this.labelStorageName.Text = "       ";
            this.buttonStorage.Location = new Point(0xea, 0x101);
            this.buttonStorage.Margin = new Padding(0);
            this.buttonStorage.Name = "buttonStorage";
            this.buttonStorage.Size = new Size(0x17, 0x17);
            this.buttonStorage.TabIndex = 3;
            this.buttonStorage.Text = "...";
            this.buttonStorage.UseVisualStyleBackColor = true;
            this.buttonStorage.Click += new EventHandler(this.buttonStorage_Click);
            this.textStorage.CharacterCasing = CharacterCasing.Upper;
            this.textStorage.Location = new Point(0x93, 260);
            this.textStorage.MaxLength = 5;
            this.textStorage.Name = "textStorage";
            this.textStorage.Size = new Size(0x53, 20);
            this.textStorage.TabIndex = 2;
            this.textStorage.Leave += new EventHandler(this.textStorage_Leave);
            this.labelStorage.AutoSize = true;
            this.labelStorage.Location = new Point(0x61, 0x106);
            this.labelStorage.Name = "labelStorage";
            this.labelStorage.Size = new Size(0x2c, 13);
            this.labelStorage.TabIndex = 0x12;
            this.labelStorage.Text = "Storage";
            this.label16.AutoSize = true;
            this.label16.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label16.Location = new Point(0xa3, 5);
            this.label16.Name = "label16";
            this.label16.Size = new Size(0x65, 13);
            this.label16.TabIndex = 2;
            this.label16.Text = "* for 1xSTO = 1xDO";
            this.text1DOSTO.CharacterCasing = CharacterCasing.Upper;
            this.text1DOSTO.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.text1DOSTO.Location = new Point(0x59, 0x36);
            this.text1DOSTO.MaxLength = 20;
            this.text1DOSTO.Name = "text1DOSTO";
            this.text1DOSTO.Size = new Size(0xa5, 0x1d);
            this.text1DOSTO.TabIndex = 1;
            this.label14.AutoSize = true;
            this.label14.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label14.Location = new Point(0x2f, 30);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x24, 0x10);
            this.label14.TabIndex = 3;
            this.label14.Text = "STO";
            this.text1STO.CharacterCasing = CharacterCasing.Upper;
            this.text1STO.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.text1STO.Location = new Point(0x59, 0x17);
            this.text1STO.MaxLength = 20;
            this.text1STO.Name = "text1STO";
            this.text1STO.Size = new Size(0xa5, 0x1d);
            this.text1STO.TabIndex = 0;
            this.label15.AutoSize = true;
            this.label15.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label15.Location = new Point(0x1f, 60);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x3b, 0x10);
            this.label15.TabIndex = 4;
            this.label15.Text = "DO STO";
            this.rectangleShape1.BorderColor = SystemColors.ControlDark;
            this.rectangleShape1.Location = new Point(0x1d, 7);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new Size(0xeb, 90);
            this.label1STO1DO.AutoSize = true;
            this.label1STO1DO.Location = new Point(0x256, 0x18f);
            this.label1STO1DO.Name = "label1STO1DO";
            this.label1STO1DO.Size = new Size(0x59, 13);
            this.label1STO1DO.TabIndex = 0x15;
            this.label1STO1DO.Text = "*1x STO = 1x DO";
            this.labelZWB.AutoSize = true;
            this.labelZWB.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelZWB.ForeColor = Color.Red;
            this.labelZWB.Location = new Point(0x19e, 0x22c);
            this.labelZWB.Name = "labelZWB";
            this.labelZWB.Size = new Size(0xea, 20);
            this.labelZWB.TabIndex = 0x13;
            this.labelZWB.Text = "Please Synchron this DO to ";
            this.labelZWB.Visible = false;
            this.panelSTO1DO.Controls.Add(this.text1DOSTO);
            this.panelSTO1DO.Controls.Add(this.label15);
            this.panelSTO1DO.Controls.Add(this.text1STO);
            this.panelSTO1DO.Controls.Add(this.label14);
            this.panelSTO1DO.Controls.Add(this.label16);
            this.panelSTO1DO.Controls.Add(this.shapeContainer2);
            this.panelSTO1DO.Location = new Point(0x18e, 0x19c);
            this.panelSTO1DO.Name = "panelSTO1DO";
            this.panelSTO1DO.Size = new Size(0x121, 0x58);
            this.panelSTO1DO.TabIndex = 0x4e;
            this.shapeContainer2.Location = new Point(0, 0);
            this.shapeContainer2.Margin = new Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            Shape[] shapes = new Shape[] { this.rectangleShape1 };
            this.shapeContainer2.Shapes.AddRange(shapes);
            this.shapeContainer2.Size = new Size(0x121, 0x58);
            this.shapeContainer2.TabIndex = 5;
            this.shapeContainer2.TabStop = false;
            this.labelQuantity.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelQuantity.Location = new Point(0x23f, 0x60);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new Size(0x79, 0x10);
            this.labelQuantity.TabIndex = 0x4f;
            this.labelQuantity.Text = "/ 0";
            this.labelQuantity.Click += new EventHandler(this.labelQuantity_Click);
            this.labelQtyLeft.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelQtyLeft.Location = new Point(0x1d7, 0x60);
            this.labelQtyLeft.Name = "labelQtyLeft";
            this.labelQtyLeft.Size = new Size(0x6b, 0x10);
            this.labelQtyLeft.TabIndex = 20;
            this.labelQtyLeft.Text = "0";
            this.labelQtyLeft.TextAlign = ContentAlignment.TopRight;
            this.txtDeliveryNote.Location = new Point(0x92, 0xca);
            this.txtDeliveryNote.Name = "txtDeliveryNote";
            this.txtDeliveryNote.Size = new Size(0xb5, 20);
            this.txtDeliveryNote.TabIndex = 1;
            this.txtDeliveryNote.Leave += new EventHandler(this.txtDeliveryNote_Leave);
            this.labelDN.AutoSize = true;
            this.labelDN.Location = new Point(70, 0xcd);
            this.labelDN.Name = "labelDN";
            this.labelDN.Size = new Size(0x47, 13);
            this.labelDN.TabIndex = 0x51;
            this.labelDN.Text = "Delivery Note";
            this.labelGunnyNetKg.AutoSize = true;
            this.labelGunnyNetKg.Location = new Point(230, 0x156);
            this.labelGunnyNetKg.Name = "labelGunnyNetKg";
            this.labelGunnyNetKg.Size = new Size(20, 13);
            this.labelGunnyNetKg.TabIndex = 0x54;
            this.labelGunnyNetKg.Text = "Kg";
            this.textGunnyNet.Location = new Point(0x93, 0x153);
            this.textGunnyNet.Name = "textGunnyNet";
            this.textGunnyNet.ReadOnly = true;
            this.textGunnyNet.Size = new Size(0x53, 20);
            this.textGunnyNet.TabIndex = 0x52;
            this.textGunnyNet.Text = "0";
            this.textGunnyNet.TextAlign = HorizontalAlignment.Right;
            this.labelGunnyNet.AutoSize = true;
            this.labelGunnyNet.Location = new Point(80, 0x156);
            this.labelGunnyNet.Name = "labelGunnyNet";
            this.labelGunnyNet.Size = new Size(0x3d, 13);
            this.labelGunnyNet.TabIndex = 0x53;
            this.labelGunnyNet.Text = "Gunny Nett";
            this.but_sh_do_sap.Location = new Point(20, 0x13);
            this.but_sh_do_sap.Margin = new Padding(0);
            this.but_sh_do_sap.Name = "but_sh_do_sap";
            this.but_sh_do_sap.Size = new Size(0x52, 0x17);
            this.but_sh_do_sap.TabIndex = 0x56;
            this.but_sh_do_sap.Text = "Choose DO ";
            this.but_sh_do_sap.UseVisualStyleBackColor = true;
            this.but_sh_do_sap.Click += new EventHandler(this.but_sh_do_sap_Click);
            this.text_do_sap.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.text_do_sap.Location = new Point(0x60, 0x4a);
            this.text_do_sap.MaxLength = 100;
            this.text_do_sap.Name = "text_do_sap";
            this.text_do_sap.ReadOnly = true;
            this.text_do_sap.Size = new Size(0x76, 0x16);
            this.text_do_sap.TabIndex = 0x55;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x11, 0x4f);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x1a, 13);
            this.label2.TabIndex = 0x57;
            this.label2.Text = "DO ";
            this.gb_do_sap.Controls.Add(this.txtBox_QQ);
            this.gb_do_sap.Controls.Add(this.lbl_QQ);
            this.gb_do_sap.Controls.Add(this.textSOItem_detail);
            this.gb_do_sap.Controls.Add(this.labelSOItem_detail);
            this.gb_do_sap.Controls.Add(this.lbl_do_besar);
            this.gb_do_sap.Controls.Add(this.lblINitem);
            this.gb_do_sap.Controls.Add(this.txtInNumItem);
            this.gb_do_sap.Controls.Add(this.txtInternalNum);
            this.gb_do_sap.Controls.Add(this.lblInternalNum);
            this.gb_do_sap.Controls.Add(this.label22);
            this.gb_do_sap.Controls.Add(this.label23);
            this.gb_do_sap.Controls.Add(this.textBoxBaseUOM);
            this.gb_do_sap.Controls.Add(this.textBoxQtyBaseUOM);
            this.gb_do_sap.Controls.Add(this.label21);
            this.gb_do_sap.Controls.Add(this.text_do_sap_item);
            this.gb_do_sap.Controls.Add(this.label20);
            this.gb_do_sap.Controls.Add(this.label19);
            this.gb_do_sap.Controls.Add(this.label18);
            this.gb_do_sap.Controls.Add(this.label17);
            this.gb_do_sap.Controls.Add(this.text_do_sap_unit);
            this.gb_do_sap.Controls.Add(this.text_do_sap_qty);
            this.gb_do_sap.Controls.Add(this.text_do_sap_qty_kg);
            this.gb_do_sap.Controls.Add(this.but_sh_do_sap);
            this.gb_do_sap.Controls.Add(this.text_do_sap);
            this.gb_do_sap.Controls.Add(this.label2);
            this.gb_do_sap.Location = new Point(0x159, 0x94);
            this.gb_do_sap.Name = "gb_do_sap";
            this.gb_do_sap.Size = new Size(0x156, 0xe9);
            this.gb_do_sap.TabIndex = 0x58;
            this.gb_do_sap.TabStop = false;
            this.gb_do_sap.Text = "DO ";
            this.gb_do_sap.Visible = false;
            this.txtBox_QQ.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtBox_QQ.Location = new Point(0x61, 0xce);
            this.txtBox_QQ.MaxLength = 100;
            this.txtBox_QQ.Name = "txtBox_QQ";
            this.txtBox_QQ.ReadOnly = true;
            this.txtBox_QQ.Size = new Size(0xef, 0x16);
            this.txtBox_QQ.TabIndex = 0x73;
            this.lbl_QQ.Location = new Point(0x12, 0xd3);
            this.lbl_QQ.Name = "lbl_QQ";
            this.lbl_QQ.Size = new Size(0x4a, 13);
            this.lbl_QQ.TabIndex = 0x74;
            this.lbl_QQ.Text = "Customer QQ";
            this.textSOItem_detail.Location = new Point(0x60, 50);
            this.textSOItem_detail.MaxLength = 6;
            this.textSOItem_detail.Name = "textSOItem_detail";
            this.textSOItem_detail.ReadOnly = true;
            this.textSOItem_detail.Size = new Size(80, 20);
            this.textSOItem_detail.TabIndex = 0x6b;
            this.textSOItem_detail.TextAlign = HorizontalAlignment.Right;
            this.labelSOItem_detail.AutoSize = true;
            this.labelSOItem_detail.Location = new Point(0x11, 0x35);
            this.labelSOItem_detail.Name = "labelSOItem_detail";
            this.labelSOItem_detail.Size = new Size(0x2d, 13);
            this.labelSOItem_detail.TabIndex = 0x6a;
            this.labelSOItem_detail.Text = "SO Item";
            this.lbl_do_besar.AutoSize = true;
            this.lbl_do_besar.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.lbl_do_besar.ForeColor = Color.DarkGreen;
            this.lbl_do_besar.Location = new Point(0xf1, 0x37);
            this.lbl_do_besar.Name = "lbl_do_besar";
            this.lbl_do_besar.Size = new Size(70, 13);
            this.lbl_do_besar.TabIndex = 0x69;
            this.lbl_do_besar.Text = "DO BESAR";
            this.lblINitem.AutoSize = true;
            this.lblINitem.Location = new Point(0xd6, 0x67);
            this.lblINitem.Name = "lblINitem";
            this.lblINitem.Size = new Size(0x1b, 13);
            this.lblINitem.TabIndex = 0x68;
            this.lblINitem.Text = "Item";
            this.txtInNumItem.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtInNumItem.Location = new Point(0xf1, 0x63);
            this.txtInNumItem.MaxLength = 100;
            this.txtInNumItem.Name = "txtInNumItem";
            this.txtInNumItem.ReadOnly = true;
            this.txtInNumItem.Size = new Size(0x3b, 0x16);
            this.txtInNumItem.TabIndex = 0x67;
            this.txtInternalNum.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtInternalNum.Location = new Point(0x60, 100);
            this.txtInternalNum.MaxLength = 100;
            this.txtInternalNum.Name = "txtInternalNum";
            this.txtInternalNum.ReadOnly = true;
            this.txtInternalNum.Size = new Size(0x76, 0x16);
            this.txtInternalNum.TabIndex = 0x65;
            this.txtInternalNum.KeyPress += new KeyPressEventHandler(this.txtInternalNum_KeyPress);
            this.lblInternalNum.AutoSize = true;
            this.lblInternalNum.Location = new Point(0x11, 0x69);
            this.lblInternalNum.Name = "lblInternalNum";
            this.lblInternalNum.Size = new Size(0x3b, 13);
            this.lblInternalNum.TabIndex = 0x66;
            this.lblInternalNum.Text = "Internal No";
            this.label22.AutoSize = true;
            this.label22.Location = new Point(0xb8, 0xb7);
            this.label22.Name = "label22";
            this.label22.Size = new Size(30, 13);
            this.label22.TabIndex = 100;
            this.label22.Text = "UoM";
            this.label23.AutoSize = true;
            this.label23.Location = new Point(0x11, 0xb7);
            this.label23.Name = "label23";
            this.label23.Size = new Size(0x49, 13);
            this.label23.TabIndex = 0x63;
            this.label23.Text = "Base Quantity";
            this.textBoxBaseUOM.Location = new Point(0xd9, 180);
            this.textBoxBaseUOM.Name = "textBoxBaseUOM";
            this.textBoxBaseUOM.ReadOnly = true;
            this.textBoxBaseUOM.Size = new Size(0x30, 20);
            this.textBoxBaseUOM.TabIndex = 0x62;
            this.textBoxQtyBaseUOM.Location = new Point(0x60, 180);
            this.textBoxQtyBaseUOM.Name = "textBoxQtyBaseUOM";
            this.textBoxQtyBaseUOM.ReadOnly = true;
            this.textBoxQtyBaseUOM.Size = new Size(80, 20);
            this.textBoxQtyBaseUOM.TabIndex = 0x61;
            this.textBoxQtyBaseUOM.TextAlign = HorizontalAlignment.Right;
            this.textBoxQtyBaseUOM.TextChanged += new EventHandler(this.textBoxQtyBaseUOM_TextChanged);
            this.label21.AutoSize = true;
            this.label21.Location = new Point(0xd6, 0x4d);
            this.label21.Name = "label21";
            this.label21.Size = new Size(0x1b, 13);
            this.label21.TabIndex = 0x60;
            this.label21.Text = "Item";
            this.text_do_sap_item.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.text_do_sap_item.Location = new Point(0xf1, 0x49);
            this.text_do_sap_item.MaxLength = 100;
            this.text_do_sap_item.Name = "text_do_sap_item";
            this.text_do_sap_item.ReadOnly = true;
            this.text_do_sap_item.Size = new Size(0x3b, 0x16);
            this.text_do_sap_item.TabIndex = 0x5f;
            this.label20.AutoSize = true;
            this.label20.Location = new Point(0x10f, 0x83);
            this.label20.Name = "label20";
            this.label20.Size = new Size(0x16, 13);
            this.label20.TabIndex = 0x5e;
            this.label20.Text = "KG";
            this.label19.AutoSize = true;
            this.label19.Location = new Point(0xb8, 0x9d);
            this.label19.Name = "label19";
            this.label19.Size = new Size(30, 13);
            this.label19.TabIndex = 0x5d;
            this.label19.Text = "UoM";
            this.label18.AutoSize = true;
            this.label18.Location = new Point(0x11, 0x9d);
            this.label18.Name = "label18";
            this.label18.Size = new Size(0x2e, 13);
            this.label18.TabIndex = 0x5c;
            this.label18.Text = "Quantity";
            this.label17.AutoSize = true;
            this.label17.Location = new Point(0x11, 0x83);
            this.label17.Name = "label17";
            this.label17.Size = new Size(0x4b, 13);
            this.label17.TabIndex = 0x5b;
            this.label17.Text = "Quantity in KG";
            this.text_do_sap_unit.Location = new Point(0xd9, 0x9a);
            this.text_do_sap_unit.Name = "text_do_sap_unit";
            this.text_do_sap_unit.ReadOnly = true;
            this.text_do_sap_unit.Size = new Size(0x30, 20);
            this.text_do_sap_unit.TabIndex = 0x59;
            this.text_do_sap_qty.Location = new Point(0x60, 0x9a);
            this.text_do_sap_qty.Name = "text_do_sap_qty";
            this.text_do_sap_qty.ReadOnly = true;
            this.text_do_sap_qty.Size = new Size(80, 20);
            this.text_do_sap_qty.TabIndex = 0x58;
            this.text_do_sap_qty.TextAlign = HorizontalAlignment.Right;
            this.text_do_sap_qty_kg.Location = new Point(0x60, 0x80);
            this.text_do_sap_qty_kg.Name = "text_do_sap_qty_kg";
            this.text_do_sap_qty_kg.ReadOnly = true;
            this.text_do_sap_qty_kg.Size = new Size(0xa9, 20);
            this.text_do_sap_qty_kg.TabIndex = 0;
            this.text_do_sap_qty_kg.TextAlign = HorizontalAlignment.Right;
            this.buttonPISI.Location = new Point(0x11f, 0xe5);
            this.buttonPISI.Margin = new Padding(0);
            this.buttonPISI.Name = "buttonPISI";
            this.buttonPISI.Size = new Size(0x17, 0x17);
            this.buttonPISI.TabIndex = 0x59;
            this.buttonPISI.Text = "...";
            this.buttonPISI.UseVisualStyleBackColor = true;
            this.buttonPISI.Click += new EventHandler(this.buttonPISI_Click);
            this.labelLoadingUOM.AutoSize = true;
            this.labelLoadingUOM.Location = new Point(230, 0x170);
            this.labelLoadingUOM.Name = "labelLoadingUOM";
            this.labelLoadingUOM.Size = new Size(20, 13);
            this.labelLoadingUOM.TabIndex = 0x5c;
            this.labelLoadingUOM.Text = "Kg";
            this.textBoxLoadingQty.Location = new Point(0x93, 0x16d);
            this.textBoxLoadingQty.Name = "textBoxLoadingQty";
            this.textBoxLoadingQty.ReadOnly = true;
            this.textBoxLoadingQty.Size = new Size(0x53, 20);
            this.textBoxLoadingQty.TabIndex = 90;
            this.textBoxLoadingQty.Text = "0";
            this.textBoxLoadingQty.TextAlign = HorizontalAlignment.Right;
            this.textBoxLoadingQty.KeyPress += new KeyPressEventHandler(this.textBoxLoadingQty_KeyPress);
            this.textBoxLoadingQty.Leave += new EventHandler(this.textBoxLoadingQty_Leave);
            this.labelLoadingQty.AutoSize = true;
            this.labelLoadingQty.Location = new Point(80, 0x170);
            this.labelLoadingQty.Name = "labelLoadingQty";
            this.labelLoadingQty.Size = new Size(0x40, 13);
            this.labelLoadingQty.TabIndex = 0x5b;
            this.labelLoadingQty.Text = "Loading Qty";
            this.label_loading_qty_opw_uom.AutoSize = true;
            this.label_loading_qty_opw_uom.Location = new Point(0xe7, 0x18a);
            this.label_loading_qty_opw_uom.Name = "label_loading_qty_opw_uom";
            this.label_loading_qty_opw_uom.Size = new Size(20, 13);
            this.label_loading_qty_opw_uom.TabIndex = 0x5f;
            this.label_loading_qty_opw_uom.Text = "Kg";
            this.text_opw_loading_qty.Location = new Point(0x93, 0x187);
            this.text_opw_loading_qty.Name = "text_opw_loading_qty";
            this.text_opw_loading_qty.Size = new Size(0x53, 20);
            this.text_opw_loading_qty.TabIndex = 0x5d;
            this.text_opw_loading_qty.Text = "0";
            this.text_opw_loading_qty.TextAlign = HorizontalAlignment.Right;
            this.text_opw_loading_qty.KeyPress += new KeyPressEventHandler(this.text_opw_loading_qty_KeyPress);
            this.text_opw_loading_qty.Leave += new EventHandler(this.textBoxLoadingQty_Leave);
            this.label_loading_qty_opw.AutoSize = true;
            this.label_loading_qty_opw.Location = new Point(0x18, 0x18a);
            this.label_loading_qty_opw.Name = "label_loading_qty_opw";
            this.label_loading_qty_opw.Size = new Size(120, 13);
            this.label_loading_qty_opw.TabIndex = 0x5e;
            this.label_loading_qty_opw.Text = "Other Party Loading Qty";
            this.lbl_comm_name.AutoSize = true;
            this.lbl_comm_name.Location = new Point(0x14d, 0x49);
            this.lbl_comm_name.Name = "lbl_comm_name";
            this.lbl_comm_name.Size = new Size(0x1f, 13);
            this.lbl_comm_name.TabIndex = 0x60;
            this.lbl_comm_name.Text = "        ";
            this.lblReturnPackUom.AutoSize = true;
            this.lblReturnPackUom.Location = new Point(0xe7, 0x1c9);
            this.lblReturnPackUom.Name = "lblReturnPackUom";
            this.lblReturnPackUom.Size = new Size(0x1d, 13);
            this.lblReturnPackUom.TabIndex = 0x66;
            this.lblReturnPackUom.Text = "KAR";
            this.txtReturnPack.Location = new Point(0x93, 0x1c6);
            this.txtReturnPack.Name = "txtReturnPack";
            this.txtReturnPack.Size = new Size(0x53, 20);
            this.txtReturnPack.TabIndex = 100;
            this.txtReturnPack.Text = "0";
            this.txtReturnPack.TextAlign = HorizontalAlignment.Right;
            this.txtReturnPack.KeyPress += new KeyPressEventHandler(this.txtReturnPack_KeyPress);
            this.txtReturnPack.Leave += new EventHandler(this.textBoxLoadingQty_Leave);
            this.lblReturnPack.AutoSize = true;
            this.lblReturnPack.Location = new Point(50, 0x1c9);
            this.lblReturnPack.Name = "lblReturnPack";
            this.lblReturnPack.Size = new Size(0x5f, 13);
            this.lblReturnPack.TabIndex = 0x65;
            this.lblReturnPack.Text = "Return Qty (PACK)";
            this.lblReturnKgUom.AutoSize = true;
            this.lblReturnKgUom.Location = new Point(230, 0x1af);
            this.lblReturnKgUom.Name = "lblReturnKgUom";
            this.lblReturnKgUom.Size = new Size(0x16, 13);
            this.lblReturnKgUom.TabIndex = 0x63;
            this.lblReturnKgUom.Text = "KG";
            this.txtReturnKg.BackColor = SystemColors.Window;
            this.txtReturnKg.Location = new Point(0x93, 0x1ac);
            this.txtReturnKg.Name = "txtReturnKg";
            this.txtReturnKg.Size = new Size(0x53, 20);
            this.txtReturnKg.TabIndex = 0x61;
            this.txtReturnKg.Text = "0";
            this.txtReturnKg.TextAlign = HorizontalAlignment.Right;
            this.txtReturnKg.KeyPress += new KeyPressEventHandler(this.txtReturnKg_KeyPress);
            this.txtReturnKg.Leave += new EventHandler(this.textBoxLoadingQty_Leave);
            this.lblreturnKg.AutoSize = true;
            this.lblreturnKg.Location = new Point(0x3f, 0x1af);
            this.lblreturnKg.Name = "lblreturnKg";
            this.lblreturnKg.Size = new Size(0x52, 13);
            this.lblreturnKg.TabIndex = 0x62;
            this.lblreturnKg.Text = "Return Qty (KG)";
            this.txtDensity.Location = new Point(0x93, 0x1e9);
            this.txtDensity.Name = "txtDensity";
            this.txtDensity.ReadOnly = true;
            this.txtDensity.Size = new Size(0x53, 20);
            this.txtDensity.TabIndex = 0x69;
            this.txtDensity.Text = "0";
            this.txtDensity.TextAlign = HorizontalAlignment.Right;
            this.txtDensity.Leave += new EventHandler(this.txtDensity_Leave);
            this.lblDensity.AutoSize = true;
            this.lblDensity.Location = new Point(0x61, 0x1ec);
            this.lblDensity.Name = "lblDensity";
            this.lblDensity.Size = new Size(0x2a, 13);
            this.lblDensity.TabIndex = 0x6a;
            this.lblDensity.Text = "Density";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x2be, 0x247);
            base.ControlBox = false;
            base.Controls.Add(this.txtDensity);
            base.Controls.Add(this.lblDensity);
            base.Controls.Add(this.lblReturnPackUom);
            base.Controls.Add(this.txtReturnPack);
            base.Controls.Add(this.lblReturnPack);
            base.Controls.Add(this.lblReturnKgUom);
            base.Controls.Add(this.txtReturnKg);
            base.Controls.Add(this.lblreturnKg);
            base.Controls.Add(this.lbl_comm_name);
            base.Controls.Add(this.label_loading_qty_opw_uom);
            base.Controls.Add(this.text_opw_loading_qty);
            base.Controls.Add(this.label_loading_qty_opw);
            base.Controls.Add(this.labelLoadingUOM);
            base.Controls.Add(this.textBoxLoadingQty);
            base.Controls.Add(this.labelLoadingQty);
            base.Controls.Add(this.buttonPISI);
            base.Controls.Add(this.gb_do_sap);
            base.Controls.Add(this.labelGunnyNetKg);
            base.Controls.Add(this.textGunnyNet);
            base.Controls.Add(this.labelGunnyNet);
            base.Controls.Add(this.labelDN);
            base.Controls.Add(this.txtDeliveryNote);
            base.Controls.Add(this.labelQtyLeft);
            base.Controls.Add(this.labelQuantity);
            base.Controls.Add(this.panelSTO1DO);
            base.Controls.Add(this.label1STO1DO);
            base.Controls.Add(this.buttonStorage);
            base.Controls.Add(this.textStorage);
            base.Controls.Add(this.labelStorage);
            base.Controls.Add(this.labelStorageName);
            base.Controls.Add(this.label13);
            base.Controls.Add(this.textOthNet);
            base.Controls.Add(this.label12);
            base.Controls.Add(this.labelKB);
            base.Controls.Add(this.btnFillContainer);
            base.Controls.Add(this.textTransporter);
            base.Controls.Add(this.label11);
            base.Controls.Add(this.textPI_No);
            base.Controls.Add(this.labelPI_No);
            base.Controls.Add(this.labelConvUnit);
            base.Controls.Add(this.textConvNett);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.textEstate);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.textComm);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.labelAgen);
            base.Controls.Add(this.textRName);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.textFactNet);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.textRCode);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textCont);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.buttonDO);
            base.Controls.Add(this.textDO);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.labelZWB);
            base.KeyPreview = true;
            base.Name = "FormTransDOEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Entry DO";
            base.Load += new EventHandler(this.FormTransDOEntry_Load);
            base.Shown += new EventHandler(this.FormTransDOEntry_Shown);
            this.panelSTO1DO.ResumeLayout(false);
            this.panelSTO1DO.PerformLayout();
            this.gb_do_sap.ResumeLayout(false);
            this.gb_do_sap.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void labelQuantity_Click(object sender, EventArgs e)
        {
        }

        public void manualEntry(string mode)
        {
            this.setManual = mode;
        }

        public string manualEntry2() => 
            new FormTransaction().pMode;

        public void saveDO()
        {
            if (this.textDO.Text.Trim() != "")
            {
                if (!this.need_choose_do)
                {
                    string[] aField = new string[] { "Do_No", "PI_No" };
                    string[] aFind = new string[] { this.textDO.Text.Trim(), this.textPI_No.Text.Trim() };
                    if (!ReferenceEquals(this.tblDO.GetData(aField, aFind), null))
                    {
                        if ((this.setManual == "MANUAL") || (((this.pMode == "SPLIT") || (this.pMode == "EDIT")) ? ((this.doEntryMode == "EDIT") || (this.doEntryMode == "ADD")) : false))
                        {
                            if ((this.txtDensity.Text != "0") || ((!this.loadingNoFlowMeter && !this.loadingWithFlowMeter) && !this.CalcDensityToSparepart))
                            {
                                if (((!this.loadingNoFlowMeter || this.calcLoadingQtyAutomatically) ? this.loadingWithFlowMeter : true) && (this.textBoxLoadingQty.Text == "0"))
                                {
                                    MessageBox.Show("Please Entry Loading Qty", "WARNING...");
                                    this.textBoxLoadingQty.Focus();
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please Entry Density", "WARNING...");
                                this.txtDensity.Focus();
                                return;
                            }
                        }
                        if (WBSetting.Field("GM") == "Y")
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(" AND ( Token_Code ='NOT_ADOPTSAP' and completed = 'N' and key_1 = '" + this.textDO.Text + "' )"), WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                MessageBox.Show("This DO hasn't been approved to not adopt from " + this.sapIDSYS, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                return;
                            }
                        }
                        if ((this.pMode != "LOADQTY") || ((this.bulkPack != "B") || (this.labelLoadingUOM.Text.ToUpper() != "KG")))
                        {
                            string[] textArray3 = new string[] { "Do_No" };
                            string[] textArray4 = new string[] { this.textDO.Text.Trim() };
                            DataRow data = this.tblDO.GetData(textArray3, textArray4);
                            if ((data != null) & !this.IsReturn)
                            {
                                string[] textArray5 = new string[] { "comm_code" };
                                string[] textArray6 = new string[] { data["comm_code"].ToString() };
                                this.tblComm.DR = this.tblComm.GetData(textArray5, textArray6);
                                this.uniq_contract = data["uniq"].ToString();
                                this.so_no = data["so"].ToString();
                                this.sto_no = data["sto"].ToString();
                                string str = Program.getFieldValue("wb_transaction_type", "trx_require_internal_no", "transaction_code", data["transaction_code"].ToString());
                                this.wCond = new WBCondition();
                                DataRow[] dgRows = new DataRow[] { data, this.tblComm.DR };
                                this.wCond.fillParameter("ACTIVE_ADOPT_ZDOTRX", dgRows);
                                if (this.wCond.getResult())
                                {
                                    this.gb_do_sap.Visible = true;
                                    this.txtInternalNum.Enabled = true;
                                    this.txtBox_QQ.Visible = true;
                                }
                                else if (((str == "Y") && (this.CommType == "S")) && (this.isTrade2 == "T"))
                                {
                                    this.gb_do_sap.Visible = true;
                                    this.txtBox_QQ.Visible = true;
                                }
                                else
                                {
                                    this.gb_do_sap.Visible = false;
                                    this.txtBox_QQ.Visible = false;
                                }
                            }
                            if (this.gb_do_sap.Visible)
                            {
                                if (!this.active_zdotrx)
                                {
                                    if (((this.text_do_sap.Text.Trim() == "") || (this.text_do_sap_item.Text.Trim() == "")) && ((this.txtInternalNum.Text.Trim() == "") || (this.txtInNumItem.Text.Trim() == "")))
                                    {
                                        MessageBox.Show("Please Fill DO " + this.sapIDSYS + " / Internal Number", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        this.but_sh_do_sap.Focus();
                                        return;
                                    }
                                }
                                else if (this.txtInternalNum.Text.Trim() == "")
                                {
                                    MessageBox.Show("Please Fill Loading Note ", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    this.but_sh_do_sap.Focus();
                                    return;
                                }
                                if ((this.textSOItem_detail.Text.Trim() != "") || WBSetting.integrationIDSYS)
                                {
                                    if ((this.text_do_sap.Text.Trim() == "") || ((this.text_do_sap_item.Text.Trim().Length >= 2) || WBSetting.integrationIDSYS))
                                    {
                                        if (((this.txtInternalNum.Text.Trim() == "") || WBSetting.integrationIDSYS) || (this.txtInNumItem.Text.Trim().Length >= 2))
                                        {
                                            if (((this.textSOItem_detail.Text.Trim() == "") || WBSetting.integrationIDSYS) || (this.textSOItem_detail.Text.Trim().Length >= 2))
                                            {
                                                WBTable table2 = new WBTable();
                                                table2.OpenTable("wb_contract", "SELECT so_item FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + this.textDO.Text.Trim() + "'"), WBData.conn);
                                                if (table2.DT.Rows[0]["so_item"].ToString() == "*")
                                                {
                                                    WBTable table3 = new WBTable();
                                                    object[] objArray1 = new object[] { " AND do_no = '", this.textDO.Text.Trim(), "' AND so_item = '", Program.StrToDouble(this.textSOItem_detail.Text.Trim(), 0), "'" };
                                                    table3.OpenTable("wb_contract_sapinformation", "SELECT uniq FROM wb_contract_sapinformation WHERE " + WBData.CompanyLocation(string.Concat(objArray1)), WBData.conn);
                                                    if (table3.DT.Rows.Count > 0)
                                                    {
                                                        table3.Dispose();
                                                    }
                                                    else
                                                    {
                                                        object[] objArray2 = new object[] { "SO item ", Program.StrToDouble(this.textSOItem_detail.Text.Trim(), 0), " is not available for WB DO ", this.textDO.Text.Trim(), ". Please check your WB DO!" };
                                                        MessageBox.Show(string.Concat(objArray2), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                        this.but_sh_do_sap.Focus();
                                                        return;
                                                    }
                                                }
                                                table2.Dispose();
                                                if (WBSetting.IntegrationSAP == "Y")
                                                {
                                                    if (this.text_do_sap.ReadOnly)
                                                    {
                                                        if (this.text_do_sap_qty.Text == "")
                                                        {
                                                            MessageBox.Show("Quantity DO " + this.sapIDSYS + " is zero. Please contact " + this.sapIDSYS, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                            return;
                                                        }
                                                    }
                                                    else if (this.txtInternalNum.Text.Trim() != "")
                                                    {
                                                        this.hasil = this.t_do_sap.tokenOrApp(this.txtInternalNum.Text, this.txtInNumItem.Text, "DO_SAP_FAIL_VALID", "TOKEN_DO_SAP_FAIL_VALID", "DOSAP_MANUAL", "E", "", null);
                                                        if (this.hasil[0] == "cancel")
                                                        {
                                                            return;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        this.hasil = this.t_do_sap.tokenOrApp(this.text_do_sap.Text, this.text_do_sap_item.Text, "DO_SAP_FAIL_VALID", "TOKEN_DO_SAP_FAIL_VALID", "DOSAP_MANUAL", "E", "", null);
                                                        if (this.hasil[0] == "cancel")
                                                        {
                                                            return;
                                                        }
                                                    }
                                                }
                                                if (this.txtInternalNum.Text.Trim() == "")
                                                {
                                                    WBTable table4 = new WBTable();
                                                    string[] textArray7 = new string[11];
                                                    textArray7[0] = "SELECT * FROM wb_transdo as DO inner join wb_transaction as TS on TS.do_no = DO.do_no WHERE DO.internal_number = '";
                                                    textArray7[1] = this.txtInternalNum.Text;
                                                    textArray7[2] = "' and DO.internal_number_item = '";
                                                    textArray7[3] = this.txtInNumItem.Text;
                                                    textArray7[4] = "'  and TS.ref <> '";
                                                    textArray7[5] = this.RefNo;
                                                    textArray7[6] = "' and (TS.deleted = 'N' or TS.deleted is null) and (TS.Mark_accident = 'N' or TS.Mark_accident is null) and TS.coy = '";
                                                    textArray7[7] = WBData.sCoyCode;
                                                    textArray7[8] = "' and TS.location_code = '";
                                                    textArray7[9] = WBData.sLocCode;
                                                    textArray7[10] = "'";
                                                    table4.OpenTable("wb_transdo", string.Concat(textArray7), WBData.conn);
                                                    if (table4.DT.Rows.Count > 0)
                                                    {
                                                        string[] textArray8 = new string[] { "Internal Number [ ", this.txtInternalNum.Text, " ] has been used in Ref [ ", table4.DT.Rows[0]["ref"].ToString(), " ] \nPlease use another Internal Number.\nThank you." };
                                                        MessageBox.Show(string.Concat(textArray8), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                        return;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("Invalid SO Item", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                return;
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Invalid Internal No Item", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Invalid DO " + this.sapIDSYS + " Item", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        return;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Please fill SO Item", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    this.but_sh_do_sap.Focus();
                                    return;
                                }
                            }
                            if ((WBSetting.locType != "1") || !(((this.txtDeliveryNote.Text.Trim() == "") && this.txtDeliveryNote.Visible) && this.txtDeliveryNote.Enabled))
                            {
                                this.changeComm = false;
                                this.deletebc = false;
                                if ((this.dgvDOCurrRow == 0) && ((this.doEntryMode == "EDIT") || (this.doEntryMode == "EDIT_OPW")))
                                {
                                    if (!(WBSetting.dummy_contract_on_registration && (this.oldComm.Trim() == WBSetting.dummy_comm_code)))
                                    {
                                        if ((this.oldComm.Trim().ToUpper() != this.textComm.Text.Trim().ToUpper()) && (this.oldComm.Trim() != ""))
                                        {
                                            string str2 = "(This action will reset the quality)";
                                            this.tblComm.OpenTable("wb_comm", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.oldComm.Trim() + "'"), WBData.conn);
                                            if (this.tblComm.DT.Rows[0]["Trade"].ToString() == "N")
                                            {
                                                str2 = "(This action will delete inputted sparepart loading Quantity)";
                                                this.deletebc = true;
                                            }
                                            string[] textArray9 = new string[] { "\n\n Are you sure to change commodity from ", this.oldComm, " to ", this.textComm.Text, " ? ", str2 };
                                            if (MessageBox.Show(string.Concat(textArray9) ?? "", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                                            {
                                                this.saved = false;
                                                return;
                                            }
                                            else
                                            {
                                                this.changeComm = true;
                                                if ((this.bulkPack == "B") && (this.labelLoadingUOM.Text.ToUpper() == "KG"))
                                                {
                                                    this.textBoxLoadingQty.Text = "0";
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        this.changeComm = true;
                                    }
                                }
                                if ((WBSetting.locType == "0") && this.lSTO1DO)
                                {
                                    TextBox[] aText = new TextBox[] { this.text1STO, this.text1DOSTO };
                                    if (Program.CheckEmpty(aText))
                                    {
                                        return;
                                    }
                                }
                                if (this.dgvDO.Rows.Count > 0)
                                {
                                    if (((((this.doEntryMode != "ADD") && ((this.doEntryMode != "EDIT") || (this.dgvDO.CurrentRow.Index <= 0))) || (this.pMode == "DL")) || ((this.pMode != "2ND") && (this.pMode != "4TH"))) || ((this.textFactNet.Text.Trim() != "") && (this.textFactNet.Text.Trim() != "0")))
                                    {
                                        this.tblComm.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.textComm.Text + "'"), WBData.conn);
                                        DataRow row3 = this.tblComm.DT.Rows[0];
                                        if ((this.doEntryMode == "ADD") || ((this.doEntryMode == "EDIT") && (this.dgvDO.CurrentRow.Index > 0)))
                                        {
                                            if ((((this.textFactNet.Text.Trim() != "") && (this.textFactNet.Text.Trim() != "0")) || (this.totalNetEstate != 0.0)) || (row3["bulkpack"].ToString() == "P"))
                                            {
                                                if (((this.textOthNet.Text.Trim() == "") || (this.textOthNet.Text.Trim() == "0")) ? (this.totalNetEstate > 0.0) : false)
                                                {
                                                    MessageBox.Show("Please fill other party net weight before save DO!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                    this.textOthNet.Focus();
                                                    return;
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("Please fill factory net weight before save DO!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                this.textFactNet.Focus();
                                                return;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Please Fill Net Weight...", "WARNING...");
                                        this.textFactNet.Focus();
                                        return;
                                    }
                                }
                                if (((this.doEntryMode != "ADD_RETUR") && (this.doEntryMode != "EDIT_OPW")) || ((((this.deductedBy != "1") || ((this.text_opw_loading_qty.Text != "0") || (this.bulkPack != "P"))) || (this.labelLoadingUOM.Text.ToUpper() == "KG")) || (MessageBox.Show("Other Party Loading Qty is Zero. Are You Sure? \n ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.No)))
                                {
                                    if (((this.chkqty == "Y") && ((this.bulkPack != "P") && ((this.textBoxLoadingQty.Text != "0") || (this.textBoxLoadingQty.Text != "")))) && (this.txtInNumItem.Text.Trim() == ""))
                                    {
                                        if (this.OSNetTol != 0.0)
                                        {
                                            if (this.deductedBy != "0")
                                            {
                                                if ((this.deductedBy == "1") && (Program.StrToDouble(this.textOthNet.Text, 0) > this.OSNetTol))
                                                {
                                                    MessageBox.Show("Other Quantity Over Quantity Tolerance..", "WARNING...");
                                                    return;
                                                }
                                            }
                                            else if (((this.CommType != "S") && (this.CommType != "F")) && (this.CommType != "C"))
                                            {
                                                if ((this.CommType == "G") && (Program.StrToDouble(this.textGunnyNet.Text, 0) > this.OSNetTol))
                                                {
                                                    MessageBox.Show("Gunny Net Over Quantity Tolerance..", "WARNING...");
                                                    return;
                                                }
                                            }
                                            else if (Program.StrToDouble(this.textFactNet.Text, 0) > this.OSNetTol)
                                            {
                                                MessageBox.Show("Factory Net Over Quantity Tolerance..", "WARNING...");
                                                return;
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Cannot Use DO, Outstanding DO is 0", "WARNING...");
                                            return;
                                        }
                                    }
                                    if ((this.textBoxQtyBaseUOM.Text == "") || ((!this.gb_do_sap.Visible || (Convert.ToDouble(this.textBoxQtyBaseUOM.Text) <= 0.0)) || (Convert.ToDouble(this.textBoxLoadingQty.Text) <= Convert.ToInt32(this.textBoxQtyBaseUOM.Text))))
                                    {
                                        this.saved = true;
                                    }
                                    else
                                    {
                                        MessageBox.Show("Loading Qty is greater than Do Base Qty", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        this.textBoxLoadingQty.Focus();
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please Fill Delivery Note", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.txtDeliveryNote.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Cannot choose this DO. This is not PACK / Bulk Non KG Commodity", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                    }
                    else
                    {
                        MessageBox.Show("PI No doesn't belong to this DO No", "WARNING...");
                        this.textDO.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please Click Choose DO", "WARNING...");
                }
            }
            else
            {
                MessageBox.Show("Please Entry WB DO No", "WARNING...");
            }
        }

        public void saveDOforFirstTime_TCS()
        {
            this.saved = true;
        }

        private void SetorVar(DataRow pDoRow)
        {
            this.labelKB.Text = (pDoRow["berikat"].ToString() == "Y") ? "*KB" : "";
            this.label1STO1DO.Visible = pDoRow["STO1DO"].ToString() == "Y";
            this.chkqty = pDoRow["Check_qty"].ToString();
            this.tolerance = pDoRow["tolerance"].ToString();
            this.deductedBy = pDoRow["deductedBy"].ToString();
            this.textComm.Text = pDoRow["Comm_Code"].ToString();
            this.tblComm.OpenTable("wb_comm", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.textComm.Text + "'"), WBData.conn);
            string[] aField = new string[] { "comm_code" };
            string[] aFind = new string[] { this.textComm.Text };
            DataRow data = this.tblComm.GetData(aField, aFind);
            if (data == null)
            {
                this.using_gunny = "N";
                this.CommType = "S";
            }
            else
            {
                this.using_gunny = data["using_gunny"].ToString();
                this.CommType = data["Type"].ToString();
                this.labelLoadingUOM.Text = data["Unit"].ToString();
                this.label_loading_qty_opw_uom.Text = data["Unit"].ToString();
                this.lblReturnPackUom.Text = data["Unit"].ToString();
                this.bulkPack = data["BulkPack"].ToString();
                this.isTrade2 = data["Trade"].ToString();
                this.netto_weight = float.Parse((data["netto_weight"].ToString() == "") ? "0" : data["netto_weight"].ToString());
                this.lbl_comm_name.Text = data["comm_name"].ToString();
            }
            this.countQtyLeft(pDoRow["DO_NO"].ToString());
            this.labelQtyLeft.Text = $"{Math.Floor(Convert.ToDouble(this.OSNetwoTol.ToString())):N0}";
            this.OSNetwoTol = Convert.ToDouble($"{Convert.ToDouble(this.OSNetwoTol.ToString()):N0}");
            this.labelQuantity.Text = "/ " + $"{Convert.ToDouble(pDoRow["quantity"].ToString()):N0}";
            this.labelConvUnit.Text = pDoRow["ConvertionUnit"].ToString();
            this.textCont.Text = pDoRow["Contract"].ToString();
            this.textTransporter.Text = pDoRow["Transporter_Code"].ToString();
            this.textRCode.Text = pDoRow["Relation_Code"].ToString().Trim();
            this.textEstate.Text = pDoRow["Estate1_Code"].ToString();
            this.labelAgen.Text = (pDoRow["Agen"].ToString().Trim() == "Y") ? "*Agen" : "";
            this.labelKB.Text = (pDoRow["Berikat"].ToString().Trim() == "Y") ? "*KB" : "";
            this.label1STO1DO.Visible = pDoRow["STO1DO"].ToString().Trim() == "Y";
            this.lSTO1DO = pDoRow["STO1DO"].ToString().Trim() == "Y";
            this.ISCC = pDoRow["ISCC"].ToString().Trim();
            this.textPI_No.Text = pDoRow["PI_No"].ToString();
            this.zCust.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" AND Relation_Code='" + pDoRow["Relation_Code"].ToString().Trim() + "'"), WBData.conn);
            if (this.zCust.DT.Rows.Count > 0)
            {
                this.textRCode.Text = pDoRow["Relation_Code"].ToString().Trim();
                this.textRName.Text = this.zCust.DT.Rows[0]["Relation_Name"].ToString().Trim();
            }
            this.pComm = pDoRow["Comm_Code"].ToString();
            if (!this.IsReturn)
            {
                this.pTransType = pDoRow["Transaction_Code"].ToString();
            }
            this.remark = pDoRow["remark"].ToString();
            this.DoConvUnit = pDoRow["ConvertionUnit"].ToString();
            this.labelConvUnit.Text = this.DoConvUnit;
            this.DoConv = pDoRow["Convertion"].ToString();
            this.DoConvTol = pDoRow["ConvertionTolerance"].ToString();
            this.qualityInfo = pDoRow["qualityInfo"].ToString();
            this.tolling = pDoRow["Tolling"].ToString();
            if (WBSetting.zwb == "Y")
            {
                this.labelZWB.Visible = pDoRow["ZWB"].ToString() != "Y";
            }
            if (pDoRow["check_qty"].ToString() == "Y")
            {
                this.party = pDoRow["quantity"].ToString();
                double num = 0.3 * Program.StrToDouble(this.party, 2);
                if (this.OSNetwoTol >= num)
                {
                    this.labelQtyLeft.ForeColor = Color.Black;
                }
                else
                {
                    MessageBox.Show("Quantity Left is Below 30 % of Total Party \nPress OK to Continue...", "WARNING...", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.labelQtyLeft.ForeColor = Color.Red;
                }
            }
            if ((this.setManual == "MANUAL") || (this.doEntryMode == "EDIT"))
            {
                this.textBoxLoadingQty.ReadOnly = this.labelLoadingUOM.Text.ToUpper() == "KG";
            }
            if ((this.setManual == "MANUAL") || (((this.pMode == "SPLIT") || (this.pMode == "EDIT")) ? ((this.doEntryMode == "EDIT") || (this.doEntryMode == "ADD")) : false))
            {
                WBCondition condition = new WBCondition();
                WBCondition condition2 = new WBCondition();
                WBCondition condition3 = new WBCondition();
                string[] textArray3 = new string[] { "Transaction_code" };
                string[] textArray4 = new string[] { pDoRow["Transaction_Code"].ToString() };
                DataRow row2 = this.tblTType.GetData(textArray3, textArray4);
                string[] textArray5 = new string[] { "Comm_Code" };
                string[] textArray6 = new string[] { this.textComm.Text.Trim() };
                DataRow row3 = this.tblComm.GetData(textArray5, textArray6);
                DataRow[] dgRows = new DataRow[] { row3, row2 };
                condition2.fillParameter("LOADING_NO_FLOWMETER", dgRows);
                DataRow[] rowArray2 = new DataRow[] { row3, row2 };
                condition.fillParameter("LOADING_WITH_FLOWMETER", rowArray2);
                DataRow[] rowArray3 = new DataRow[] { row3, row2 };
                condition3.fillParameter("CALC_DENSITY_TO_SPAREPARTQTY", rowArray3);
                if (!((condition2.getResult() || condition.getResult()) || condition3.getResult()))
                {
                    this.txtDensity.Text = "0";
                    this.txtDensity.ReadOnly = true;
                    this.loadingNoFlowMeter = false;
                    this.loadingWithFlowMeter = false;
                    this.CalcDensityToSparepart = false;
                }
                else
                {
                    this.textBoxLoadingQty.ReadOnly = true;
                    this.txtDensity.ReadOnly = false;
                    if (condition2.getResult())
                    {
                        this.loadingNoFlowMeter = true;
                        if (pDoRow["calcLoadingQtyAutomatically"].ToString() == "Y")
                        {
                            this.calcLoadingQtyAutomatically = true;
                        }
                        else
                        {
                            this.textBoxLoadingQty.ReadOnly = false;
                        }
                    }
                    if (condition.getResult())
                    {
                        this.textBoxLoadingQty.ReadOnly = false;
                        this.loadingWithFlowMeter = true;
                    }
                    if (condition3.getResult())
                    {
                        this.CalcDensityToSparepart = true;
                    }
                }
            }
        }

        private void text_opw_loading_qty_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox) sender;
            this.checkDecimalOnKeyPress(textBox, e);
        }

        private void text_opw_loading_qty_Leave(object sender, EventArgs e)
        {
            try
            {
                Convert.ToDouble(this.text_opw_loading_qty.Text);
            }
            catch
            {
                MessageBox.Show("Invalid entry on Other Party Loading Qty");
                this.text_opw_loading_qty.Text = "0";
            }
        }

        private void textBoxLoadingQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox) sender;
            this.checkDecimalOnKeyPress(textBox, e);
        }

        private void textBoxLoadingQty_Leave(object sender, EventArgs e)
        {
            TextBox box = (TextBox) sender;
            if (!Program.CheckNumericForLoadingQty(box.Text))
            {
                box.Text = "0";
            }
        }

        private void textBoxQtyBaseUOM_TextChanged(object sender, EventArgs e)
        {
            string[] source = new string[] { ".", "," };
            if (source.Any<string>(s => this.textBoxQtyBaseUOM.Text.Contains(s)))
            {
                MessageBox.Show(Resource.Error_Conversion_DOSAP + this.sapIDSYS, "WARNING...", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.buttonSave.Enabled = false;
            }
        }

        private void textCompany_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDO_Changed(object sender, EventArgs e)
        {
            if (this.textDO.Text != "")
            {
                this.text_do_sap.Text = "";
                this.txtInternalNum.Text = "";
                this.txtInNumItem.Text = "";
                this.text_do_sap_item.Text = "";
                this.text_do_sap_qty.Text = "";
                this.text_do_sap_unit.Text = "";
                this.text_do_sap_qty_kg.Text = "";
                this.textBoxQtyBaseUOM.Text = "";
                this.textBoxBaseUOM.Text = "";
                this.textSOItem_detail.Text = "";
                this.txtBox_QQ.Text = "";
                this.hideDOSAPForm(false);
                this.retTable_DSAP_DO = new DataGridView();
                this.retTable_DSAP_DOTRX = new DataGridView();
                this.retTable_DSAP_DR = new DataGridView();
            }
            if (this.setManual == "MANUAL")
            {
                this.textBoxLoadingQty.ReadOnly = this.labelLoadingUOM.Text.ToUpper() == "KG";
            }
        }

        private void textDO_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDO_L(object sender, EventArgs e)
        {
            if (this.textDO.Text != "")
            {
                this.textDO.Text = this.textDO.Text.Trim();
                this.tblDO.ReOpen();
                string[] aField = new string[] { "Do_No" };
                string[] aFind = new string[] { this.textDO.Text.Trim() };
                DataRow data = this.tblDO.GetData(aField, aFind);
                if (!ReferenceEquals(data, null))
                {
                    if (data["closed"].ToString() != "X")
                    {
                        this.tblTType.ReOpen();
                        string[] textArray3 = new string[] { "Transaction_code" };
                        string[] textArray4 = new string[] { data["transaction_code"].ToString() };
                        DataRow row2 = this.tblTType.GetData(textArray3, textArray4);
                        this.IO = row2["IO"].ToString();
                        WBTable table = new WBTable();
                        table.OpenTable("wb_commodity", "select * from wb_commodity where" + WBData.CompanyLocation(""), WBData.conn);
                        string[] textArray5 = new string[] { "comm_code" };
                        string[] textArray6 = new string[] { data["comm_code"].ToString() };
                        DataRow row3 = table.GetData(textArray5, textArray6);
                        this.tblVesselMap.OpenTable("wb_vessel_map", "SELECT uniq_item, qty_map, completed from wb_vessel_map where uniq_vessel = '" + data["uniq"].ToString() + "'", WBData.conn);
                        if (this.tblVesselMap.DT.Rows.Count > 0)
                        {
                            DataRow row4 = this.tblVesselMap.DT.Rows[0];
                            if ((row2["is_vessel"].ToString() == "Y") && (row4["completed"].ToString() == "Y"))
                            {
                                MessageBox.Show("DO Vessel is already completed", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.textDO.Focus();
                                return;
                            }
                        }
                        if ((((data["DeductedBy"].ToString() != "1") || this.nopw) || (this.IO != "I")) || ((this.net_estate != "0") && (this.net_estate != "")))
                        {
                            this.uniq_contract = data["uniq"].ToString();
                            this.so_no = data["so"].ToString();
                            this.sto_no = data["sto"].ToString();
                            this.so_item = (data["so_item"].ToString() != "*") ? data["so_item"].ToString() : "";
                            this.label1.Text = (row2["IO"].ToString() != "I") ? "Sales Order No." : "Delivery Order No.";
                            if (data["zAuto"].ToString() != "Y")
                            {
                                if ((WBSetting.Field("GM") != "Y") || (data["completedGRCust"].ToString() != "N"))
                                {
                                    if (!this.CheckPeriodDO(data, this.refDate))
                                    {
                                        this.txtOPWLoadQty(row2["IO"].ToString(), row3["unit"].ToString(), row3["trade"].ToString());
                                        this.SetorVar(data);
                                        this.check_do(data);
                                    }
                                    else
                                    {
                                        string[] textArray7 = new string[] { "The period of DO  '", data["DO_NO"].ToString(), "' has been expired after ", data["Do_Date2"].ToString().Substring(0, 10), "...!" };
                                        MessageBox.Show(string.Concat(textArray7), "WARNING...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        this.textDO.Focus();
                                        return;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Cannot Choose DO, PIN Not Yet Accepted..", "WARNING...");
                                    this.textDO.Focus();
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Cannot Use Automated DO for Titip Timbun..", "Warning..");
                                this.textDO.Focus();
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please fill in weight of other party", "WARNING...");
                            this.textDO.Focus();
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannot Choose Closed DO...", "WARNING...");
                        this.textDO.Focus();
                        return;
                    }
                }
                else
                {
                    this.buttonDO.PerformClick();
                }
                if (this.dgvDO.Rows.Count > 0)
                {
                    if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                    {
                        this.txtDeliveryNote.Enabled = false;
                    }
                    else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                    {
                        this.txtDeliveryNote.Enabled = false;
                    }
                    else if (((this.CommType == "F") && !this.CheckSPB()) && this.txtDeliveryNote.Visible)
                    {
                        this.txtDeliveryNote.Enabled = false;
                    }
                }
                this.textBoxLoadingQty.ReadOnly = true;
                if (((this.bulkPack != "B") || (this.labelLoadingUOM.Text.ToUpper() == "KG")) ? ((this.bulkPack == "P") && (this.labelLoadingUOM.Text.ToUpper() == "KG")) : true)
                {
                    this.textBoxLoadingQty.ReadOnly = false;
                }
                FormTransaction transaction = new FormTransaction();
                if (this.setManual == "MANUAL")
                {
                    this.textBoxLoadingQty.ReadOnly = this.labelLoadingUOM.Text.ToUpper() == "KG";
                }
            }
        }

        private void textEstate_Leave(object sender, EventArgs e)
        {
        }

        private void textFactNet_KeyPress(object sender, KeyPressEventArgs e)
        {
            bool flag = true;
            if (((e.KeyChar < '0') || (e.KeyChar > '9')) ? (e.KeyChar == '\b') : true)
            {
                flag = false;
            }
            e.Handled = flag;
        }

        private void textFactNet_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textFactNet);
            this.textFactNet.Text = Convert.ToString(Convert.ToInt32(this.textFactNet.Text));
        }

        private void textOthNet_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textOthNet);
            if (((this.textOthNet.Text != "0") && (this.textOthNet.Text != "")) && (MessageBox.Show("Proporsional Factory Net ?\n", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes))
            {
                this.textFactNet.Text = Convert.ToString(Math.Round((double) (Convert.ToDouble(this.textOthNet.Text) + ((Convert.ToDouble(this.totalVariance) / Convert.ToDouble(this.totalNetEstate)) * Convert.ToDouble(this.textOthNet.Text)))));
            }
        }

        private void textPINo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textPINo_Leave(object sender, EventArgs e)
        {
            if (this.textPI_No.Text != "")
            {
                this.textPI_No.Text = this.textPI_No.Text.Trim();
                this.tblDO.ReOpen();
                string[] aField = new string[] { "PI_No" };
                string[] aFind = new string[] { this.textPI_No.Text.Trim() };
                DataRow data = this.tblDO.GetData(aField, aFind);
                if (!ReferenceEquals(data, null))
                {
                    if (data["closed"].ToString() != "X")
                    {
                        this.uniq_contract = data["uniq"].ToString();
                        this.so_no = data["so"].ToString();
                        this.so_item = (data["so_item"].ToString() != "*") ? data["so_item"].ToString() : "";
                        this.sto_no = data["sto"].ToString();
                        this.tblTType.ReOpen();
                        string[] textArray3 = new string[] { "Transaction_code" };
                        string[] textArray4 = new string[] { data["transaction_code"].ToString() };
                        DataRow row2 = this.tblTType.GetData(textArray3, textArray4);
                        this.IO = row2["IO"].ToString();
                        this.label1.Text = (row2["IO"].ToString() != "I") ? "Sales Order No." : "Delivery Order No.";
                        if (data["zAuto"].ToString() != "Y")
                        {
                            if ((WBSetting.Field("GM") != "Y") || (data["completedGRCust"].ToString() != "N"))
                            {
                                if (!this.CheckPeriodDO(data, this.refDate))
                                {
                                    this.textDO.Text = data["do_no"].ToString();
                                    this.SetorVar(data);
                                    this.check_do(data);
                                }
                                else
                                {
                                    string[] textArray5 = new string[] { "The period of DO  '", data["DO_NO"].ToString(), "' has been expired after ", data["Do_Date2"].ToString().Substring(0, 10), "...!" };
                                    MessageBox.Show(string.Concat(textArray5), "WARNING...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Cannot Choose DO, PIN Not Yet Accepted..", "WARNING...");
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Cannot Use Automated DO for Titip Timbun..", "Warning..");
                            this.textDO.Focus();
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannot Choose Closed DO...", "WARNING...");
                        return;
                    }
                }
                else
                {
                    this.buttonPISI.PerformClick();
                }
                if (this.dgvDO.Rows.Count > 0)
                {
                    if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                    {
                        this.txtDeliveryNote.Enabled = false;
                    }
                    else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                    {
                        this.txtDeliveryNote.Enabled = false;
                    }
                    else if (((this.CommType == "F") && !this.CheckSPB()) && this.txtDeliveryNote.Visible)
                    {
                        this.txtDeliveryNote.Enabled = false;
                    }
                }
            }
        }

        private void textStorage_Leave(object sender, EventArgs e)
        {
            if (this.textStorage.Text != "")
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_storage", "SELECT * FROM wb_storage Where " + WBData.CompanyLocation(" and storage_code ='" + this.textStorage.Text.Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    this.buttonStorage.PerformClick();
                    this.textStorage.Focus();
                }
                table.Dispose();
            }
        }

        private bool try_connect()
        {
            if (WBSAP.connect())
            {
                if (WBSetting.adopt_zdotrx)
                {
                    this.txtInternalNum.ReadOnly = false;
                    this.txtBox_QQ.Visible = true;
                    this.lbl_QQ.Visible = true;
                }
                else
                {
                    this.txtInternalNum.ReadOnly = true;
                    this.txtBox_QQ.Visible = false;
                    this.lbl_QQ.Visible = false;
                }
                this.text_do_sap.ReadOnly = true;
                this.text_do_sap_item.ReadOnly = true;
                this.txtInNumItem.ReadOnly = true;
                this.textSOItem_detail.ReadOnly = true;
            }
            else
            {
                DialogResult result2 = MessageBox.Show("WB.NET cannot connect to " + this.sapIDSYS + ".\nPlease check your connection.\nDo you want to retry?\n\nPress YES to Retry.\nPress NO to continue with Token/Password Approval.", "WARNING", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk);
                if (result2 == DialogResult.Cancel)
                {
                    return false;
                }
                else if (result2 == DialogResult.Yes)
                {
                    this.try_connect();
                }
                else
                {
                    bool flag2;
                    if (result2 != DialogResult.No)
                    {
                        flag2 = false;
                    }
                    else
                    {
                        this.text_do_sap.ReadOnly = false;
                        this.text_do_sap_item.ReadOnly = false;
                        this.txtInNumItem.ReadOnly = false;
                        this.txtInternalNum.ReadOnly = false;
                        this.text_do_sap_qty_kg.Text = "";
                        this.text_do_sap_qty.Text = "";
                        this.textBoxQtyBaseUOM.Text = "";
                        this.text_do_sap_unit.Text = "";
                        this.textBoxBaseUOM.Text = "";
                        this.txtBox_QQ.Text = "";
                        this.textSOItem_detail.ReadOnly = false;
                        flag2 = true;
                    }
                    return flag2;
                }
            }
            return true;
        }

        private bool try_connect_IDSYS()
        {
            if (this.connectIDSYS())
            {
                this.txtInternalNum.ReadOnly = !WBSetting.adopt_zdotrx;
                this.text_do_sap_item.ReadOnly = true;
                this.txtInNumItem.ReadOnly = true;
                this.text_do_sap.ReadOnly = true;
                this.textSOItem_detail.ReadOnly = true;
            }
            else
            {
                DialogResult result2 = MessageBox.Show("WB.NET cannot connect to SAP.\nPlease check your connection.\nDo you want to retry?\n\nPress YES to Retry.\nPress NO to continue with Token/Password Approval.", "WARNING", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk);
                if (result2 == DialogResult.Cancel)
                {
                    return false;
                }
                else if (result2 == DialogResult.Yes)
                {
                    this.try_connect_IDSYS();
                }
                else
                {
                    bool flag2;
                    if (result2 != DialogResult.No)
                    {
                        flag2 = false;
                    }
                    else
                    {
                        this.text_do_sap.ReadOnly = false;
                        this.text_do_sap_item.ReadOnly = false;
                        this.txtInNumItem.ReadOnly = false;
                        this.txtInternalNum.ReadOnly = false;
                        this.text_do_sap_qty_kg.Text = "";
                        this.text_do_sap_qty.Text = "";
                        this.textBoxQtyBaseUOM.Text = "";
                        this.text_do_sap_unit.Text = "";
                        this.textBoxBaseUOM.Text = "";
                        this.textSOItem_detail.ReadOnly = false;
                        flag2 = true;
                    }
                    return flag2;
                }
            }
            return true;
        }

        private void txtDeliveryNote_Leave(object sender, EventArgs e)
        {
            string[] aField = new string[] { "Comm_Code" };
            string[] aFind = new string[] { this.textComm.Text.Trim() };
            DataRow data = this.tblComm.GetData(aField, aFind);
            if ((WBSetting.Field("DeliveryNote") == "Y") && (this.txtDeliveryNote.Text.Trim() != "-"))
            {
            }
        }

        private void txtDensity_Leave(object sender, EventArgs e)
        {
            if (this.loadingWithFlowMeter || this.loadingNoFlowMeter)
            {
                if (Convert.ToDouble(this.txtDensity.Text) >= 1.0)
                {
                    MessageBox.Show(Resource.FormLoadingInfo_003, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.txtDensity.Text = "0";
                    this.txtDensity.Focus();
                    this.txtDensity.Select();
                }
            }
            else if (this.CalcDensityToSparepart && ((Convert.ToDouble(this.txtDensity.Text) > 2.0) || !(Convert.ToDouble(this.txtDensity.Text) != 0.0)))
            {
                MessageBox.Show(Resource.FormLoadingInfo_005, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.txtDensity.Text = "0";
                this.txtDensity.Focus();
                this.txtDensity.Select();
            }
        }

        private void txtInternalNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "0123456789".IndexOfAny(anyOf) <= -1;
            }
        }

        private void txtOPWLoadQty(string IO, string unit, string trade)
        {
            if (((IO == "I") && (unit != "KG")) && (trade == "T"))
            {
                this.text_opw_loading_qty.Enabled = true;
            }
            else
            {
                this.text_opw_loading_qty.Text = "0";
                this.text_opw_loading_qty.Enabled = false;
            }
        }

        private void txtReturnKg_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox) sender;
            this.checkDecimalOnKeyPress(textBox, e);
        }

        private void txtReturnKg_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.txtReturnKg);
        }

        private void txtReturnPack_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox) sender;
            this.checkDecimalOnKeyPress(textBox, e);
        }

        private void txtReturnPack_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.txtReturnPack);
        }
    }
}

