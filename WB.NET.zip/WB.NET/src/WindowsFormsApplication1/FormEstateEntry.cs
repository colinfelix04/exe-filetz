﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormEstateEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public string OldCode;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private Button button2;
        private Button button1;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private Label label8;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label5;
        private GroupBox groupBox1;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        public TextBox textBox1;
        private CheckBox cBoxGHG;
        private CheckBox cBox_RSPO;
        private TextBox textISCC_F_Remark;
        private TextBox txt_RSPO;
        private Label label6;
        private Label label7;

        public FormEstateEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table4;
            WBTable table6;
            TextBox[] aText = new TextBox[] { this.textBox1, this.textBox2 };
            if (!Program.CheckEmpty(aText))
            {
                if (this.cBoxGHG.Checked && (this.textISCC_F_Remark.Text.Trim() == ""))
                {
                    MessageBox.Show("GHG Value For FFB is Empty !");
                }
                else if (this.cBox_RSPO.Checked && (this.txt_RSPO.Text.Trim() == ""))
                {
                    MessageBox.Show("RSPO Value is Empty !");
                }
                WBTable table = new WBTable();
                table.OpenTable("wb_estate", "Select Uniq From wb_estate Where " + WBData.CompanyLocation(" and ( Estate_Code='" + this.textBox1.Text.Trim() + "')"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    Cursor.Current = Cursors.WaitCursor;
                    if ((this.pMode != "EDIT") || (this.textBox1.Text.Trim() == this.OldCode.Trim()))
                    {
                        goto TR_001E;
                    }
                    else
                    {
                        WBTable table2 = new WBTable();
                        WBTable table3 = new WBTable();
                        table4 = new WBTable();
                        WBTable table5 = new WBTable();
                        table6 = new WBTable();
                        table2.OpenTable("wb_division", "Select estate_code From wb_division where " + WBData.CompanyLocation(" and ( Estate_Code='" + this.OldCode.Trim() + "')"), WBData.conn);
                        table3.OpenTable("wb_block", "Select estate_code From wb_block where " + WBData.CompanyLocation(" and ( Estate_Code='" + this.OldCode.Trim() + "')"), WBData.conn);
                        table4.OpenTable("wb_transaction", "Select ref From wb_transaction where " + WBData.CompanyLocation(" and ( Estate_Code='" + this.OldCode.Trim() + "')"), WBData.conn);
                        table5.OpenTable("wb_transDivision", "Select ref From wb_transDivision where " + WBData.CompanyLocation(" and ( Estate_Code='" + this.OldCode.Trim() + "')"), WBData.conn);
                        string[] textArray1 = new string[] { " and ((Estate1_Code='", this.OldCode.Trim(), "') or (Estate2_Code='", this.OldCode.Trim(), "'))" };
                        table6.OpenTable("wb_contract", "Select uniq From wb_contract where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                        Cursor.Current = Cursors.Default;
                        if (((table4.DT.Rows.Count <= 0) && ((table6.DT.Rows.Count <= 0) && (table2.DT.Rows.Count <= 0))) && (table3.DT.Rows.Count <= 0))
                        {
                            goto TR_001F;
                        }
                        else
                        {
                            string[] textArray2 = new string[0x27];
                            textArray2[0] = Resource.Mes_152;
                            textArray2[1] = " ";
                            textArray2[2] = this.OldCode;
                            textArray2[3] = " -> ";
                            textArray2[4] = this.textBox1.Text;
                            textArray2[5] = "\n\n";
                            textArray2[6] = Resource.Msg_Replace_Warning;
                            textArray2[7] = "\n\n- ";
                            textArray2[8] = Resource.Mes_Transaction;
                            textArray2[9] = "  : ";
                            textArray2[10] = table4.DT.Rows.Count.ToString();
                            textArray2[11] = " ";
                            textArray2[12] = Resource.Mes_047B;
                            textArray2[13] = "\n- ";
                            textArray2[14] = Resource.Mes_Trans_Detail;
                            textArray2[15] = " : ";
                            textArray2[0x10] = table5.DT.Rows.Count.ToString();
                            textArray2[0x11] = " ";
                            textArray2[0x12] = Resource.Mes_047B;
                            textArray2[0x13] = "\n- ";
                            textArray2[20] = Resource.Mes_DO_Contract;
                            textArray2[0x15] = "  : ";
                            textArray2[0x16] = table6.DT.Rows.Count.ToString();
                            textArray2[0x17] = " ";
                            textArray2[0x18] = Resource.Mes_047B;
                            textArray2[0x19] = "\n- ";
                            textArray2[0x1a] = Resource.Mes_Block_List;
                            textArray2[0x1b] = "   : ";
                            textArray2[0x1c] = table3.DT.Rows.Count.ToString();
                            textArray2[0x1d] = " ";
                            textArray2[30] = Resource.Mes_047B;
                            textArray2[0x1f] = "\n- ";
                            textArray2[0x20] = Resource.Mes_Div_List;
                            textArray2[0x21] = "    : ";
                            textArray2[0x22] = table2.DT.Rows.Count.ToString();
                            textArray2[0x23] = " ";
                            textArray2[0x24] = Resource.Mes_047B;
                            textArray2[0x25] = "\n\n";
                            textArray2[0x26] = Resource.Msg_Continue;
                            if (MessageBox.Show(string.Concat(textArray2), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.ReplaceAll = true;
                                goto TR_001F;
                            }
                            else
                            {
                                this.ReplaceAll = false;
                                this.textBox1.Focus();
                            }
                        }
                    }
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_044);
                    this.textBox1.Focus();
                }
            }
            return;
        TR_001E:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.Estate_001 },
                    textRefNo = { Text = this.textBox1.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
            this.zTable.ReOpen();
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Estate_Code"] = this.textBox1.Text.ToString().Trim();
            this.zTable.DR["Estate_Name"] = this.textBox2.Text.ToString().Trim();
            this.zTable.DR["Address"] = this.textBox3.Text;
            this.zTable.DR["City"] = this.textBox4.Text;
            this.zTable.DR["SAP_Code"] = this.textBox5.Text;
            this.zTable.DR["Type_Estate"] = this.radioButton1.Checked ? "0" : "1";
            this.zTable.DR["Show_GHG"] = this.cBoxGHG.Checked ? "Y" : "N";
            this.zTable.DR["Show_RSPO"] = this.cBox_RSPO.Checked ? "Y" : "N";
            this.zTable.DR["GHG_Value"] = this.textISCC_F_Remark.Text;
            this.zTable.DR["RSPO_Value"] = this.txt_RSPO.Text;
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table7 = new WBTable();
                    table7.OpenTable("wb_estate", "SELECT uniq FROM wb_estate WHERE " + WBData.CompanyLocation(" AND estate_code = '" + this.textBox1.Text + "' "), WBData.conn);
                    this.logKey = table7.DT.Rows[0]["uniq"].ToString();
                    table7.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_estate", this.logKey, logField, logValue);
            }
            string str = "";
            if (this.pMode == "ADD")
            {
                string[] textArray5 = new string[] { "(Triggered add new estate in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                str = string.Concat(textArray5);
            }
            else if (this.pMode == "EDIT")
            {
                string[] textArray6 = new string[] { "(Triggered edit estate in ", WBData.sCoyCode, " - ", WBData.sLocCode, ")" };
                str = string.Concat(textArray6);
            }
            Program.copyToLoc("wb_estate", this.textBox1.Text, 0, this.changeReason + " " + str);
            if ((this.pMode == "EDIT") && (this.textBox1.Text != this.OldCode))
            {
                Program.copyToLoc("wb_estate", this.OldCode, 0, this.changeReason + " " + str);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string[] aField = new string[] { "Estate_Code" };
                string[] aNewValue = new string[] { this.textBox1.Text };
                Program.ReplaceAll("wb_transaction", aField, aNewValue, " Estate_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit estate master data)");
                string[] textArray9 = new string[] { "Estate_Code", "Estate_Name" };
                string[] textArray10 = new string[] { this.textBox1.Text, this.textBox2.Text };
                Program.ReplaceAll("wb_transDivision", textArray9, textArray10, " Estate_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit estate master data)");
                string[] textArray11 = new string[] { "Estate_Code" };
                string[] textArray12 = new string[] { this.textBox1.Text };
                Program.ReplaceAll("wb_division", textArray11, textArray12, " Estate_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit estate master data)");
                string[] textArray13 = new string[] { "Estate_Code" };
                string[] textArray14 = new string[] { this.textBox1.Text };
                Program.ReplaceAll("wb_block", textArray13, textArray14, " Estate_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit estate master data)");
                string[] textArray15 = new string[] { "Estate1_Code" };
                string[] textArray16 = new string[] { this.textBox1.Text };
                Program.ReplaceAll("wb_contract", textArray15, textArray16, " Estate1_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit estate master data)");
                string[] textArray17 = new string[] { "Estate2_Code" };
                string[] textArray18 = new string[] { this.textBox1.Text };
                Program.ReplaceAll("wb_contract", textArray17, textArray18, " Estate2_Code='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit estate master data)");
                string[] textArray19 = new string[] { "Estate" };
                string[] textArray20 = new string[] { this.textBox1.Text };
                Program.ReplaceAll("wb_transDO", textArray19, textArray20, " Estate='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit estate master data)");
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            base.Close();
            return;
        TR_001F:
            table4.Dispose();
            table6.Dispose();
            goto TR_001E;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormEstateEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormEstateEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.pMode != "ADD")
            {
                this.textBox1.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Estate_Code"].Value.ToString();
                this.OldCode = this.textBox1.Text;
                this.textBox2.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Estate_Name"].Value.ToString();
                this.textBox3.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Address"].Value.ToString();
                this.textBox4.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["City"].Value.ToString();
                this.textBox5.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["SAP_Code"].Value.ToString();
                this.radioButton1.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Type_Estate"].Value.ToString() == "0";
                this.radioButton2.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Type_Estate"].Value.ToString() == "1";
                this.cBoxGHG.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["show_GHG"].Value.ToString() == "Y";
                this.cBox_RSPO.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["show_RSPO"].Value.ToString() == "Y";
                this.textISCC_F_Remark.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["GHG_Value"].Value.ToString();
                this.txt_RSPO.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["RSPO_Value"].Value.ToString();
            }
            if (this.pMode == "VIEW")
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.button2.Text = Resource.Btn_Close;
                this.button2.Enabled = true;
            }
            this.textBox5.Enabled = !WBSetting.integrationIDSYS;
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.textBox5 = new TextBox();
            this.textBox4 = new TextBox();
            this.textBox3 = new TextBox();
            this.textBox2 = new TextBox();
            this.textBox1 = new TextBox();
            this.label8 = new Label();
            this.label4 = new Label();
            this.label3 = new Label();
            this.label2 = new Label();
            this.label1 = new Label();
            this.label5 = new Label();
            this.groupBox1 = new GroupBox();
            this.radioButton2 = new RadioButton();
            this.radioButton1 = new RadioButton();
            this.cBoxGHG = new CheckBox();
            this.cBox_RSPO = new CheckBox();
            this.textISCC_F_Remark = new TextBox();
            this.txt_RSPO = new TextBox();
            this.label6 = new Label();
            this.label7 = new Label();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.button2.Location = new Point(410, 0x11f);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x21);
            this.button2.TabIndex = 8;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(310, 0x11f);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x21);
            this.button1.TabIndex = 7;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBox5.Location = new Point(0x87, 0x7f);
            this.textBox5.MaxLength = 0x1c;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new Size(0xa5, 20);
            this.textBox5.TabIndex = 5;
            this.textBox4.Location = new Point(0x87, 0x65);
            this.textBox4.MaxLength = 50;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Size(0xa5, 20);
            this.textBox4.TabIndex = 4;
            this.textBox3.Location = new Point(0x87, 0x39);
            this.textBox3.MaxLength = 150;
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Size(0x180, 0x26);
            this.textBox3.TabIndex = 3;
            this.textBox2.Location = new Point(0x87, 0x1f);
            this.textBox2.MaxLength = 50;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x180, 20);
            this.textBox2.TabIndex = 2;
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(0x87, 5);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0xa5, 20);
            this.textBox1.TabIndex = 1;
            this.label8.Location = new Point(12, 0x80);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x72, 0x11);
            this.label8.TabIndex = 0x1b;
            this.label8.Text = "SAP Code";
            this.label8.TextAlign = ContentAlignment.MiddleRight;
            this.label4.Location = new Point(12, 0x66);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x72, 0x11);
            this.label4.TabIndex = 0x17;
            this.label4.Text = "City";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            this.label3.Location = new Point(6, 0x3a);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x7b, 0x10);
            this.label3.TabIndex = 0x16;
            this.label3.Text = "Address";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.label2.Location = new Point(9, 0x22);
            this.label2.Name = "label2";
            this.label2.Size = new Size(120, 13);
            this.label2.TabIndex = 0x15;
            this.label2.Text = "Estate Name";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.label1.Location = new Point(12, 8);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x75, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "Estate Code";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.label5.Location = new Point(12, 0xfb);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x72, 0x11);
            this.label5.TabIndex = 40;
            this.label5.Text = "Type of Estate";
            this.label5.TextAlign = ContentAlignment.MiddleRight;
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Location = new Point(0x87, 0xee);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x94, 0x26);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new Point(0x4f, 13);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new Size(0x33, 0x11);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "Other";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new Point(8, 13);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new Size(0x2f, 0x11);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Own";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.cBoxGHG.AutoSize = true;
            this.cBoxGHG.Checked = true;
            this.cBoxGHG.CheckState = CheckState.Checked;
            this.cBoxGHG.Location = new Point(0x146, 7);
            this.cBoxGHG.Name = "cBoxGHG";
            this.cBoxGHG.Size = new Size(80, 0x11);
            this.cBoxGHG.TabIndex = 0x43;
            this.cBoxGHG.Text = "Show GHG";
            this.cBoxGHG.UseVisualStyleBackColor = true;
            this.cBox_RSPO.AutoSize = true;
            this.cBox_RSPO.Checked = true;
            this.cBox_RSPO.CheckState = CheckState.Checked;
            this.cBox_RSPO.Location = new Point(430, 7);
            this.cBox_RSPO.Name = "cBox_RSPO";
            this.cBox_RSPO.Size = new Size(0x56, 0x11);
            this.cBox_RSPO.TabIndex = 0x44;
            this.cBox_RSPO.Text = "Show RSPO";
            this.cBox_RSPO.UseVisualStyleBackColor = true;
            this.textISCC_F_Remark.BackColor = SystemColors.Window;
            this.textISCC_F_Remark.Location = new Point(0x87, 0xb8);
            this.textISCC_F_Remark.MaxLength = 200;
            this.textISCC_F_Remark.Multiline = true;
            this.textISCC_F_Remark.Name = "textISCC_F_Remark";
            this.textISCC_F_Remark.Size = new Size(0x15d, 0x31);
            this.textISCC_F_Remark.TabIndex = 0x45;
            this.txt_RSPO.Location = new Point(0x87, 0x9c);
            this.txt_RSPO.MaxLength = 50;
            this.txt_RSPO.Name = "txt_RSPO";
            this.txt_RSPO.Size = new Size(0xa5, 20);
            this.txt_RSPO.TabIndex = 70;
            this.label6.Location = new Point(0x3e, 0x9d);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x40, 0x11);
            this.label6.TabIndex = 0x47;
            this.label6.Text = "RSPO";
            this.label6.TextAlign = ContentAlignment.MiddleRight;
            this.label7.Location = new Point(15, 0xbb);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x6f, 0x11);
            this.label7.TabIndex = 0x48;
            this.label7.Text = "GHG Value for FFB";
            this.label7.TextAlign = ContentAlignment.MiddleRight;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x215, 0x153);
            base.ControlBox = false;
            base.Controls.Add(this.label7);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.txt_RSPO);
            base.Controls.Add(this.textISCC_F_Remark);
            base.Controls.Add(this.cBox_RSPO);
            base.Controls.Add(this.cBoxGHG);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textBox5);
            base.Controls.Add(this.textBox4);
            base.Controls.Add(this.textBox3);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.KeyPreview = true;
            base.Name = "FormEstateEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Entry Estate";
            base.Load += new EventHandler(this.FormEstateEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormEstateEntry_KeyPress);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label1.Text = Resource.Estate_001;
            this.label2.Text = Resource.Estate_002;
            this.label3.Text = Resource.Estate_003;
            this.label4.Text = Resource.Estate_004;
            this.label5.Text = Resource.Estate_005;
            this.label8.Text = this.sapIDSYS + Resource.Estate_006;
            this.label5.Text = Resource.Estate_007;
            this.radioButton1.Text = Resource.Estate_008;
            this.radioButton2.Text = Resource.Estate_009;
            this.button1.Text = Resource.Save;
            this.button2.Text = Resource.Menu_Cancel;
            this.Text = Resource.Title_Entry_Estate;
        }
    }
}

