﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormEmail : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pFind = "";
        public string pFilter = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public WBTable truck = new WBTable();
        public WBTable trans = new WBTable();
        public DataRow ReturnRow;
        private DataTable updTable = new DataTable();
        private DataTable retTable = new DataTable();
        private string[] zwbResult = new string[3];
        private string[] zwbRow = new string[0x16];
        public string sField;
        private IContainer components = null;
        private ImageList imageList1;
        public Panel panel1;
        private ProgressBar progressBar1;
        public TextBox TextFind;
        public Button buttonFind;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem closeToolStripMenuItem;
        private DataGridView dataGridView1;
        private ToolStripMenuItem viewRecordToolStripMenuItem;

        public FormEmail()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormEmailEntry entry = new FormEmailEntry {
                    pMode = "ADD",
                    zTable = this.ztable,
                    Text = Resource.Title_Add_Email,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                    string[] aField = new string[] { "Email_Code" };
                    string[] aFind = new string[] { entry.cbEmail_Code.Text };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                entry.Dispose();
                this.ztable.UnLock();
                if (this.dataGridView1.RowCount > 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = true;
                    this.editRecordToolStripMenuItem.Enabled = true;
                    this.deleteToolStripMenuItem.Enabled = true;
                }
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
            {
                this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                if (MessageBox.Show(this.ztable.DT.Rows[this.nCurrRow]["Email_Code"].ToString() + ".\n\n " + Resource.Mes_006, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    FormTransCancel cancel = new FormTransCancel {
                        label1 = { Text = Resource.Col_Email_Code },
                        textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Email_Code"].ToString() },
                        Text = Resource.Form_Delete_Reason,
                        label2 = { Text = Resource.Lbl_Delete_Reason }
                    };
                    cancel.textReason.Focus();
                    cancel.ShowDialog();
                    if (cancel.Saved)
                    {
                        this.changeReason = cancel.textReason.Text;
                        cancel.Dispose();
                        this.ztable.ReOpen();
                        this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                        this.ztable.DT.Rows[this.nCurrRow].Delete();
                        this.ztable.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_email_master", this.logKey, logField, logValue);
                        this.ztable.ReOpen();
                        this.ztable.AfterEdit("DELETE");
                    }
                    else
                    {
                        return;
                    }
                }
                this.ztable.UnLock();
                if (this.dataGridView1.RowCount == 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = false;
                    this.editRecordToolStripMenuItem.Enabled = false;
                    this.deleteToolStripMenuItem.Enabled = false;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                FormEmailEntry entry = new FormEmailEntry {
                    pMode = "EDIT",
                    zTable = this.ztable,
                    Text = Resource.Title_Edit_Email,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                }
                entry.Dispose();
                this.ztable.UnLock();
            }
        }

        private void FormEmail_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormEmail_Load(object sender, EventArgs e)
        {
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 6)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    this.retTable.Columns.Add(column);
                    column.Dispose();
                    this.progressBar1.Visible = false;
                    this.sField = " Coy,Location_Code,Department,Email_Code,Subject,Email_To,Email_CC,uniq,token,completed";
                    this.ztable.OpenTable("wb_email_master", "SELECT " + this.sField + " FROM wb_email_master", WBData.conn);
                    this.dataGridView1.DataSource = this.ztable.DT;
                    this.dataGridView1.Sort(this.dataGridView1.Columns["Coy"], ListSortDirection.Ascending);
                    this.dataGridView1.Columns["Coy"].Visible = true;
                    this.dataGridView1.Columns["Location_Code"].Visible = true;
                    this.dataGridView1.Columns["Email_Code"].Visible = true;
                    this.dataGridView1.Columns["Subject"].Visible = true;
                    this.dataGridView1.Columns["Email_To"].Visible = true;
                    this.dataGridView1.Columns["Email_CC"].Visible = true;
                    this.dataGridView1.Columns["uniq"].Visible = false;
                    this.dataGridView1.Columns["token"].Visible = false;
                    this.dataGridView1.Columns["completed"].Visible = false;
                    this.dataGridView1.Columns["Coy"].HeaderText = Resource.Col_Coy;
                    this.dataGridView1.Columns["Location_Code"].HeaderText = Resource.Col_Loc_Code;
                    this.dataGridView1.Columns["Department"].HeaderText = Resource.Col_Department;
                    this.dataGridView1.Columns["Email_Code"].HeaderText = Resource.Col_Email_Code;
                    this.dataGridView1.Columns["Subject"].HeaderText = Resource.Setting_055;
                    this.dataGridView1.Columns["Email_To"].HeaderText = Resource.Setting_053;
                    this.dataGridView1.Columns["Email_CC"].HeaderText = Resource.Setting_054;
                    base.KeyPreview = true;
                    if (!WBUser.CheckTrustee("MD_EMAIL", "A"))
                    {
                        this.addNewRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_EMAIL", "E"))
                    {
                        this.editRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_EMAIL", "D"))
                    {
                        this.deleteToolStripMenuItem.Enabled = false;
                    }
                    if ((this.pMode != "") && (this.pFind.Trim() != ""))
                    {
                        this.TextFind.Text = this.pFind;
                        this.buttonFind.PerformClick();
                    }
                    if (this.dataGridView1.RowCount == 0)
                    {
                        this.viewRecordToolStripMenuItem.Enabled = false;
                        this.editRecordToolStripMenuItem.Enabled = false;
                        this.deleteToolStripMenuItem.Enabled = false;
                    }
                    return;
                }
                column = new DataColumn();
                this.updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.imageList1 = new ImageList(this.components);
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.menuStrip1 = new MenuStrip();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            base.SuspendLayout();
            this.imageList1.ColorDepth = ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new Size(0x10, 0x10);
            this.imageList1.TransparentColor = Color.Transparent;
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x18c);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x3b3, 0x21);
            this.panel1.TabIndex = 20;
            this.progressBar1.Location = new Point(0x25b, 6);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xa7, 0x11);
            this.progressBar1.TabIndex = 0x13;
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.viewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(toolStripItems);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(itemArray2);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x3b3, 0x18);
            this.menuStrip1.TabIndex = 0x15;
            this.menuStrip1.Text = "menuStrip1";
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x3b3, 0x174);
            this.dataGridView1.TabIndex = 0x13;
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x3b3, 0x1ad);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.menuStrip1);
            base.Name = "FormEmail";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of Email Recipients";
            base.Load += new EventHandler(this.FormEmail_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormEmail_KeyPress);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dataGridView1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.buttonFind.Text = Resource.Menu_Find;
            this.deleteToolStripMenuItem.Text = Resource.Trans_057;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.Text = Resource.Title_Email;
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormEmailEntry entry = new FormEmailEntry {
                    pMode = "VIEW",
                    zTable = this.ztable,
                    Text = Resource.Title_View_Email,
                    nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                this.ztable.UnLock();
                entry.Dispose();
            }
        }
    }
}

