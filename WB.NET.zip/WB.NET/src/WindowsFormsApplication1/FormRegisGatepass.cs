﻿namespace WindowsFormsApplication1
{
    using CrystalDecisions.CrystalReports.Engine;
    using Microsoft.Win32;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.IO;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Africa;
    using WindowsFormsApplication1.Properties;
    using WindowsFormsApplication1.Utility;

    public class FormRegisGatepass : Form
    {
        private string cCoy = "";
        private string cLoc = "";
        private string cFrom = "";
        private string cTo = "";
        private WBTable t_gatepass = new WBTable();
        private WBTable tblCoy = new WBTable();
        private WBTable tblLoc = new WBTable();
        private string[] hasil = new string[3];
        public ReportDocument ticketRpt = new ReportDocument();
        public ReportDocument ticket_multi1 = new ReportDocument();
        public ReportDocument ticket_multi2 = new ReportDocument();
        public ReportDocument ticketLangsir = new ReportDocument();
        public ReportDocument ticketLangsir2 = new ReportDocument();
        public FormRpt fRpt;
        public bool needRefresh = false;
        private int idxFind = 0;
        private int nSubmit = 0;
        private int nUnsubmit = 0;
        private int nCancel = 0;
        private string tcsCard = "";
        private string select_fields = "g.uniq, Gatepass_Number, RegCard_no, WX, In_Date, In_Time, ref, submit_gatepass, submit_by, submit_date, submit_time, \r\n                                g.Truck_Number, tanker_no, g.License_No, d.name, Transporter_Code, delivery_note, seal, \r\n                                GatePass_Remark, g.Create_By, g.Create_Date, g.Change_By, g.Change_Date, g.deleted, g.delete_by, g.delete_date, \r\n                                tkn.token_no, g.token, g.completed  ";
        private IContainer components = null;
        public Panel panel1;
        public TextBox TextFind;
        public Button buttonFind;
        private GroupBox groupBox1;
        private Button btn_register;
        private Button btn_edit;
        private Button btn_cancel;
        private DateTimePicker dt2;
        private DateTimePicker dt1;
        private Label labelTo;
        private Label labelFilterTgl;
        private Button buttonFilter;
        private CheckBox cb_submit;
        private CheckBox cb_cancel;
        private Button btn_edit_TDT;
        private Label label1;
        private DataGridView dgv_gp;
        private Button btn_view;
        private Button buttonSubmit;
        private Panel panelCoyLoc;
        private Label labelLocName;
        private Label labelCompanyName;
        private Button buttonLoc;
        private Button buttonCoy;
        private TextBox textLoc;
        private TextBox textCoy;
        private Label labelLoc;
        private Label labelCoy;
        private CachedTicketGrading cachedTicketGrading1;
        private Panel panel2;
        private Panel panelFilter;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label6;
        private StatusStrip statusStrip1;
        private Label labelCancel;
        private Label labelUnsub;
        private Label labelSub;
        private Label labelTotal;
        private Button buttonCopy;
        private Button btn_refresh;

        public FormRegisGatepass()
        {
            this.InitializeComponent();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            if (WBUser.CheckTrustee("MN_REGISTER_GATEPASS", "D"))
            {
                if (this.dgv_gp.Rows.Count != 0)
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_transaction", " SELECT top 1 (ref) FROM wb_transaction  WHERE gatepass_number = '" + this.dgv_gp.CurrentRow.Cells["gatepass_number"].Value.ToString() + "'  AND ((Deleted = 'N' OR Deleted = '' OR Deleted IS NULL) OR (Deleted = 'Y' AND cancel_type = 'R'))", WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        table.Dispose();
                        if (!this.t_gatepass.Locked(this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString(), '0'))
                        {
                            if ((this.dgv_gp.CurrentRow.Cells["deleted"].Value == null) || (this.dgv_gp.CurrentRow.Cells["deleted"].Value.ToString().ToUpper() != "Y"))
                            {
                                if (MessageBox.Show("Are you sure to cancel registration for gatepass " + this.dgv_gp.CurrentRow.Cells["gatepass_number"].Value.ToString() + "?", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                {
                                    string reason = "";
                                    if (WBSetting.Field("GM") != "Y")
                                    {
                                        FormMessageEntry entry2 = new FormMessageEntry {
                                            lblHeader = { Text = "Cancel Registration" },
                                            lblDetail = { Text = "Reason for Cancel Registration" }
                                        };
                                        entry2.ShowDialog();
                                        reason = entry2.reason;
                                    }
                                    else if (this.t_gatepass.BeforeEdit(this.dgv_gp, "CANCEL"))
                                    {
                                        FormMessageEntry entry = new FormMessageEntry {
                                            lblHeader = { Text = "Cancel Registration" },
                                            lblDetail = { Text = "Reason for Cancel Registration" }
                                        };
                                        entry.ShowDialog();
                                        reason = entry.reason;
                                    }
                                    else
                                    {
                                        this.refresh(this.dgv_gp.CurrentRow.Cells["gatepass_number"].Value.ToString());
                                        this.t_gatepass.RLock(this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString(), false);
                                        return;
                                    }
                                    if (reason != "")
                                    {
                                        string sqltext = "SELECT * FROM wb_gatepass WHERE uniq = " + this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString();
                                        this.t_gatepass.OpenTable("wb_gatepass", sqltext, WBData.conn);
                                        if (this.t_gatepass.DT.Rows.Count > 0)
                                        {
                                            this.t_gatepass.DR = this.t_gatepass.DT.Rows[0];
                                            string regNo = this.t_gatepass.DR["RegCard_No"].ToString();
                                            this.t_gatepass.DR.BeginEdit();
                                            this.t_gatepass.DR["reason"] = reason;
                                            this.t_gatepass.DR["deleted"] = "Y";
                                            this.t_gatepass.DR["delete_by"] = WBUser.UserID;
                                            this.t_gatepass.DR["delete_date"] = DateTime.Now;
                                            this.t_gatepass.DR.EndEdit();
                                            this.t_gatepass.Save();
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "CANCEL", WBUser.UserID, reason };
                                            Program.updateLogHeader("wb_gatepass", this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString(), logField, logValue);
                                            WBCard.updateCardToFree(regNo);
                                        }
                                    }
                                    this.refresh("");
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.RegisGatepassMess_005, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                        }
                        else
                        {
                            string text = Resource.RegisGatepassMess_075 + " " + this.dgv_gp.CurrentRow.Cells["gatepass_number"].Value.ToString();
                            if (this.t_gatepass.lockingUser == "SYSTEM")
                            {
                                text = text + " " + Resource.RegisGatepassMess_076;
                            }
                            else
                            {
                                string[] textArray1 = new string[] { text, " ", Resource.RegisGatepassMess_058, " (", this.t_gatepass.lockingUser, "). " };
                                text = string.Concat(textArray1);
                            }
                            MessageBox.Show(text, "FAILED", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.RegisGatepassMess_004 + " " + table.DT.Rows[0]["ref"].ToString(), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            else
            {
                WBUser.ShowErr();
            }
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            bool flag = false;
            if (this.dgv_gp.Rows.Count > 0)
            {
                if (!this.t_gatepass.Locked(this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString(), '0'))
                {
                    if ((this.dgv_gp.CurrentRow.Cells["deleted"].Value == null) || (this.dgv_gp.CurrentRow.Cells["deleted"].Value.ToString().ToUpper() != "Y"))
                    {
                        if (this.tblLoc.CekTokenCompleted(this.dgv_gp.CurrentRow.Cells["Gatepass_number"].Value.ToString(), "", "UNLOCK_TDT", false) != "")
                        {
                            if (MessageBox.Show("In-progress token edit TDT. \n\n Are you sure to clear token edit TDT ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                            {
                                return;
                            }
                            else if (this.tblLoc.DelTokenCompleted(this.dgv_gp.CurrentRow.Cells["Gatepass_number"].Value.ToString().Trim(), "", "UNLOCK_TDT", false))
                            {
                            }
                        }
                        if (!this.t_gatepass.BeforeEdit(this.dgv_gp, "EDIT"))
                        {
                            this.refresh(this.dgv_gp.CurrentRow.Cells["gatepass_number"].Value.ToString());
                            this.t_gatepass.RLock(this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString(), false);
                        }
                        else if ((WBSetting.region == "2") && !WBSetting.activeTCS)
                        {
                            FormRegisGatepassEntry entry = new FormRegisGatepassEntry("EDIT", this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString());
                            entry.ShowDialog();
                            this.refresh("");
                            entry.Dispose();
                        }
                        else
                        {
                            FormRegisGatepassEntryId id = new FormRegisGatepassEntryId {
                                cCoy = this.textCoy.Text,
                                cLoc = this.textLoc.Text,
                                pMode = "EDIT",
                                inprogress_token = false,
                                pUniq = this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString(),
                                gatepassNo = this.dgv_gp.CurrentRow.Cells["Gatepass_Number"].Value.ToString(),
                                completed = flag
                            };
                            id.ShowDialog();
                            this.refresh(id.gatepassNo);
                            this.t_gatepass.RLock(id.pUniq, false);
                            id.Dispose();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Can't edit deleted gatepass!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
                else
                {
                    string text = Resource.RegisGatepassMess_056 + " " + this.dgv_gp.CurrentRow.Cells["gatepass_number"].Value.ToString();
                    if (this.t_gatepass.lockingUser == "SYSTEM")
                    {
                        text = text + " " + Resource.RegisGatepassMess_057;
                    }
                    else
                    {
                        string[] textArray1 = new string[] { text, " ", Resource.RegisGatepassMess_058, " (", this.t_gatepass.lockingUser, "). ", Resource.RegisGatepassMess_059 };
                        text = string.Concat(textArray1);
                    }
                    MessageBox.Show(text, "FAILED", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        private void btn_edit_TDT_Click(object sender, EventArgs e)
        {
            bool flag;
            WBTable table;
            WBTable table2;
            WBTable table3;
            if (WBUser.CheckTrustee("GP_EDIT_TDT", "E"))
            {
                flag = false;
                if (this.dgv_gp.Rows.Count > 0)
                {
                    if ((this.dgv_gp.CurrentRow.Cells["deleted"].Value == null) || (this.dgv_gp.CurrentRow.Cells["deleted"].Value.ToString().ToUpper() != "Y"))
                    {
                        table = new WBTable();
                        string sqltext = "SELECT * FROM wb_gatepass WHERE uniq = " + this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString();
                        table.OpenTable("WB_GATEPASS", sqltext, WBData.conn);
                        if (table.DT.Rows.Count <= 0)
                        {
                            goto TR_000D;
                        }
                        else
                        {
                            table2 = new WBTable();
                            table3 = new WBTable();
                            string[] textArray1 = new string[] { "Select * from wb_transDO where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And gatepass_number = '", table.DT.Rows[0]["gatepass_number"].ToString(), "' order by uniq asc" };
                            table2.OpenTable("wb_transDO", string.Concat(textArray1), WBData.conn);
                            if (table2.DT.Rows.Count <= 0)
                            {
                                goto TR_000E;
                            }
                            else
                            {
                                string[] textArray2 = new string[] { "Select * from wb_commodity where Coy = '", this.cCoy, "' AND Location_code = '", this.cLoc, "' And comm_code = '", table2.DT.Rows[0]["Comm_code"].ToString(), "'" };
                                table3.OpenTable("wb_commodity", string.Concat(textArray2), WBData.conn);
                                if (!WBSetting.adopt_zdotrx)
                                {
                                    goto TR_000E;
                                }
                                else
                                {
                                    WBCondition condition = new WBCondition();
                                    DataRow[] dgRows = new DataRow[] { table2.DT.Rows[0], table3.DT.Rows[0] };
                                    condition.fillParameter("ACTIVE_ADOPT_ZDOTRX", dgRows);
                                    if (!condition.getResult())
                                    {
                                        MessageBox.Show("This Gatepass is not Lock TDT. \n\n Please use edit Gatepass instead.");
                                    }
                                    else
                                    {
                                        condition.Dispose();
                                        goto TR_000E;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Can't edit deleted gatepass!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            else
            {
                WBUser.ShowErr();
            }
            return;
        TR_000D:
            if (this.dgv_gp.CurrentRow.Cells["completed"].Value.ToString().Trim() == "N")
            {
                if (MessageBox.Show("In-progress token edit gatepass. \n\n Are you sure to clear token edit gatepass ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                {
                    return;
                }
                else if (table.DT.Rows.Count > 0)
                {
                    table.DR = table.DT.Rows[0];
                    string keyField = table.DT.Rows[0]["uniq"].ToString();
                    table.DR.BeginEdit();
                    table.DR["Completed"] = "";
                    table.DR["Token"] = "";
                    table.DR.EndEdit();
                    table.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "REFRESH TOKEN EDIT" };
                    Program.updateLogHeader("wb_gatepass", keyField, logField, logValue);
                }
            }
            this.hasil = this.tblLoc.tokenOrApp(this.dgv_gp.CurrentRow.Cells["Gatepass_number"].Value.ToString().Trim(), "", "UNLOCK_TDT", "TOKEN_UNLOCK_TDT", "UNLOCK_TDT", "E", "", null);
            if (this.hasil[0] == "completed")
            {
                if ((WBSetting.region == "2") && !WBSetting.activeTCS)
                {
                    FormRegisGatepassEntry entry = new FormRegisGatepassEntry("EDIT_TDT", this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString());
                    entry.ShowDialog();
                    this.refresh("");
                    entry.Dispose();
                }
                else if (WBSetting.region == "0")
                {
                    FormRegisGatepassEntryId id = new FormRegisGatepassEntryId {
                        cCoy = this.textCoy.Text,
                        cLoc = this.textLoc.Text,
                        pMode = "EDIT_TDT",
                        inprogress_token = true,
                        pUniq = this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString(),
                        gatepassNo = this.dgv_gp.CurrentRow.Cells["Gatepass_Number"].Value.ToString(),
                        completed = flag
                    };
                    id.ShowDialog();
                    this.refresh(id.gatepassNo);
                    this.t_gatepass.RLock(id.pUniq, false);
                    id.Dispose();
                }
            }
            table.Dispose();
            return;
        TR_000E:
            table2.Dispose();
            table3.Dispose();
            goto TR_000D;
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            this.refresh("");
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MN_REGISTER_GATEPASS", "A"))
            {
                WBUser.ShowErr();
            }
            else if (string.IsNullOrEmpty(this.textCoy.Text) || string.IsNullOrEmpty(this.textLoc.Text))
            {
                MessageBox.Show(Resource.RegisGatepassMess_001, Resource.Title_002);
            }
            else if ((WBSetting.region == "2") && !WBSetting.activeTCS)
            {
                FormRegisGatepassEntry entry = new FormRegisGatepassEntry("NEW", "");
                entry.ShowDialog();
                this.refresh("");
                entry.Dispose();
            }
            else
            {
                FormRegisGatepassEntryId id = new FormRegisGatepassEntryId {
                    cCoy = this.textCoy.Text,
                    cLoc = this.textLoc.Text,
                    pMode = "ADD",
                    pUniq = ""
                };
                id.ShowDialog();
                if (id.saved)
                {
                    this.refresh(id.gatepassNo);
                }
                id.Dispose();
            }
        }

        private void btn_view_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MN_REGISTER_GATEPASS", "V"))
            {
                WBUser.ShowErr();
            }
            else if (this.dgv_gp.Rows.Count > 0)
            {
                if ((WBSetting.region == "2") && !WBSetting.activeTCS)
                {
                    FormRegisGatepassEntry entry = new FormRegisGatepassEntry("VIEW", this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString());
                    entry.ShowDialog();
                    entry.Dispose();
                }
                else
                {
                    FormRegisGatepassEntryId id = new FormRegisGatepassEntryId {
                        cCoy = this.textCoy.Text,
                        cLoc = this.textLoc.Text,
                        pMode = "VIEW",
                        pUniq = this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString(),
                        gatepassNo = this.dgv_gp.CurrentRow.Cells["Gatepass_Number"].Value.ToString()
                    };
                    id.ShowDialog();
                    id.Dispose();
                }
            }
        }

        private void buttonCopy_Click(object sender, EventArgs e)
        {
            if (!WBUser.CheckTrustee("MN_REGISTER_GATEPASS", "A"))
            {
                WBUser.ShowErr();
            }
            else if ((this.dgv_gp.Rows.Count > 0) && ((WBSetting.region != "2") || WBSetting.activeTCS))
            {
                FormRegisGatepassEntryId id = new FormRegisGatepassEntryId {
                    cCoy = this.textCoy.Text,
                    cLoc = this.textLoc.Text,
                    pMode = "ADD",
                    isCopied = true,
                    pUniq = this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString(),
                    gatepassNo = this.dgv_gp.CurrentRow.Cells["Gatepass_Number"].Value.ToString()
                };
                id.ShowDialog();
                if (id.saved)
                {
                    this.refresh(id.gatepassNo);
                }
                id.Dispose();
            }
        }

        private void buttonCoy_Click(object sender, EventArgs e)
        {
            FormCompany company = new FormCompany {
                pMode = "CHOOSE"
            };
            company.ShowDialog();
            if (company.ReturnRow != null)
            {
                this.textCoy.Text = company.ReturnRow["Coy_Code"].ToString().Trim();
                this.labelCompanyName.Text = company.ReturnRow["Coy_Name"].ToString().Trim();
                if (this.cCoy != this.textCoy.Text)
                {
                    this.textLoc.Text = "";
                    this.labelLocName.Text = "";
                    this.cLoc = "";
                    this.cCoy = this.textLoc.Text;
                }
            }
            company.Dispose();
        }

        private void buttonFilter_Click(object sender, EventArgs e)
        {
            this.refresh("");
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.t_gatepass.NextFindSqlv2(this.dgv_gp, this.TextFind.Text, this.idxFind);
        }

        private void buttonLoc_Click(object sender, EventArgs e)
        {
            if (this.textCoy.Text.Trim() == "")
            {
                MessageBox.Show(Resource.Mes_185, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textCoy.Focus();
            }
            else
            {
                FormLocation location = new FormLocation {
                    pMode = "CHOOSE",
                    pCoy = this.textCoy.Text.Trim()
                };
                location.ShowDialog();
                if (location.ReturnRow != null)
                {
                    FormMessage message = new FormMessage {
                        label1 = { Text = "Preparing . . . . . . ." }
                    };
                    this.textLoc.Text = location.ReturnRow["Location_Code"].ToString().Trim();
                    this.labelLocName.Text = location.ReturnRow["Location_Name"].ToString().Trim();
                    this.cLoc = this.textLoc.Text;
                    this.refresh("");
                    try
                    {
                        WBSetting.OpenSetting();
                        message.Show();
                    }
                    catch (Exception)
                    {
                    }
                    message.Dispose();
                }
                location.Dispose();
            }
        }

        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            if (!WBSetting.activeTCS)
            {
                if (this.dgv_gp.RowCount > 0)
                {
                    if (this.dgv_gp.CurrentRow.Cells["Deleted"].Value.ToString() != "Y")
                    {
                        if (this.dgv_gp.CurrentRow.Cells["Submit_Gatepass"].Value.ToString() != "Y")
                        {
                            string sqltext = "SELECT * FROM wb_gatepass WHERE uniq = " + this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString();
                            this.t_gatepass.OpenTable("WB_COMPANY", sqltext, WBData.conn);
                            if (this.t_gatepass.DT.Rows.Count > 0)
                            {
                                WBTable tT = new WBTable();
                                string[] textArray1 = new string[] { " SELECT * FROM wb_transaction WHERE Coy = '", this.textCoy.Text, "' AND location_code = '", this.textLoc.Text, "'  AND gatepass_number = '", this.dgv_gp.CurrentRow.Cells["gatepass_number"].Value.ToString(), "'  AND (Deleted = 'N' OR Deleted = '' OR Deleted IS NULL)" };
                                tT.OpenTable("wb_trans", string.Concat(textArray1), WBData.conn);
                                if (tT.DT.Rows.Count <= 0)
                                {
                                    this.t_gatepass.Dispose();
                                    MessageBox.Show("Can not submit gatepass which has not been used in weighing!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                else
                                {
                                    DataRow row = tT.DT.Rows[0];
                                    if (row["WX"].ToString() != "1X")
                                    {
                                        bool flag10 = false;
                                        string str2 = "";
                                        foreach (DataRow row2 in tT.DT.Rows)
                                        {
                                            if (((row2["report_date"].ToString().Trim() != "") || (row2["WX"].ToString() != "2X")) ? (((row2["_2nd"].ToString() == "") || (row2["_2nd"].ToString() == "0")) ? (row2["WX"].ToString() == "4X") : false) : true)
                                            {
                                                str2 = row2["ref"].ToString();
                                                flag10 = true;
                                                break;
                                            }
                                        }
                                        if (!flag10)
                                        {
                                            string[] textArray2 = new string[] { "Are you sure to submit gatepass ", this.dgv_gp.CurrentRow.Cells["Gatepass_Number"].Value.ToString(), " with card no. ", this.dgv_gp.CurrentRow.Cells["Card_No"].Value.ToString(), "? " };
                                            if (MessageBox.Show(string.Concat(textArray2), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                            {
                                                this.t_gatepass.DR = this.t_gatepass.DT.Rows[0];
                                                this.t_gatepass.DR.BeginEdit();
                                                this.t_gatepass.DR["Truck_Number"] = row["Truck_Number"].ToString();
                                                this.t_gatepass.DR["tanker_no"] = row["tanker"].ToString();
                                                this.t_gatepass.DR["Transporter_Code"] = row["Transporter_Code"].ToString();
                                                this.t_gatepass.DR["License_No"] = row["License_No"].ToString();
                                                this.t_gatepass.DR["delivery_note"] = row["delivery_note"].ToString();
                                                this.t_gatepass.DR["seal"] = row["seal"].ToString();
                                                if ((row["WX"].ToString() == "2X") || (row["WX"].ToString() == "NX"))
                                                {
                                                    this.t_gatepass.DR["Out_Date"] = row["Date2"].ToString();
                                                    this.t_gatepass.DR["Out_Time"] = row["time2"].ToString();
                                                }
                                                else if (row["WX"].ToString() == "4X")
                                                {
                                                    this.t_gatepass.DR["Out_Date"] = row["Date4"].ToString();
                                                    this.t_gatepass.DR["Out_Time"] = row["time4"].ToString();
                                                }
                                                this.t_gatepass.DR["Submit_Gatepass"] = "Y";
                                                this.t_gatepass.DR["Submit_Date"] = DateTime.Now.ToShortDateString();
                                                this.t_gatepass.DR["Submit_time"] = DateTime.Now.ToShortTimeString();
                                                this.t_gatepass.DR.EndEdit();
                                                this.t_gatepass.Save();
                                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                string[] logValue = new string[] { "SUBMIT", WBUser.UserID, "Submit gatepass" };
                                                Program.updateLogHeader("wb_gatepass", this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString(), logField, logValue);
                                                this.t_gatepass.Dispose();
                                                tT.Dispose();
                                                MessageBox.Show("Gatepass is submitted successfully!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Transaction with reference no " + str2 + " hasn't been weighed out!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                            tT.Dispose();
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        bool flag8 = this.submit_1X(this.t_gatepass, tT);
                                        this.t_gatepass.Dispose();
                                        tT.Dispose();
                                        if (!flag8)
                                        {
                                            return;
                                        }
                                    }
                                    this.refresh("");
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Can't submit gatepass which has been submitted before!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Can't submit deleted gatepass!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            else
            {
                FormRegisGatepassEntryId id = new FormRegisGatepassEntryId {
                    pMode = "SUBMIT",
                    cCoy = this.textCoy.Text,
                    cLoc = this.textLoc.Text,
                    gatepassNo = WBSetting.gatepassWithoutCard ? this.dgv_gp.CurrentRow.Cells["gatepass_number"].Value.ToString() : "",
                    ticketRpt = this.ticketRpt,
                    ticket_multi1 = this.ticket_multi1,
                    ticket_multi2 = this.ticket_multi2,
                    ticketLangsir = this.ticketLangsir,
                    ticketLangsir2 = this.ticketLangsir2,
                    fRpt = this.fRpt
                };
                id.ShowDialog();
                id.Dispose();
                this.refresh("");
            }
        }

        private void cb_cancel_CheckedChanged(object sender, EventArgs e)
        {
            this.refresh("");
        }

        private void cb_submit_CheckedChanged(object sender, EventArgs e)
        {
            this.refresh("");
        }

        private void dgv_gp_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.btn_view.PerformClick();
        }

        private void dgv_gp_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if ((this.dgv_gp.Rows[e.RowIndex].Cells["deleted"].Value != null) && (this.dgv_gp.Rows[e.RowIndex].Cells["deleted"].Value.ToString() == "Y"))
            {
                e.CellStyle.BackColor = Color.LightPink;
                e.CellStyle.SelectionBackColor = Color.LightCoral;
            }
            if ((this.dgv_gp.Rows[e.RowIndex].Cells["submit_gatepass"].Value != null) && (this.dgv_gp.Rows[e.RowIndex].Cells["submit_gatepass"].Value.ToString() == "Y"))
            {
                e.CellStyle.BackColor = Color.PaleGreen;
                e.CellStyle.SelectionBackColor = Color.LimeGreen;
            }
            if ((this.dgv_gp.Rows[e.RowIndex].Cells["token_no"].Value != null) && (this.dgv_gp.Rows[e.RowIndex].Cells["token_no"].Value.ToString() != ""))
            {
                e.CellStyle.BackColor = Color.PaleGoldenrod;
                e.CellStyle.SelectionBackColor = Color.Goldenrod;
            }
            DataGridViewCell cell = this.dgv_gp.Rows[e.RowIndex].Cells[e.ColumnIndex];
            if (this.dgv_gp.Rows[e.RowIndex].Cells["WX"].Value.ToString() == "0")
            {
                cell.ToolTipText = "2X Normal Weighing";
            }
            else if (this.dgv_gp.Rows[e.RowIndex].Cells["WX"].Value.ToString() == "1")
            {
                cell.ToolTipText = "NX Multiple Weighing";
            }
            else if (this.dgv_gp.Rows[e.RowIndex].Cells["WX"].Value.ToString() == "2")
            {
                cell.ToolTipText = "4X / Container Weighing In (1st,2nd)";
            }
            else if (this.dgv_gp.Rows[e.RowIndex].Cells["WX"].Value.ToString() == "3")
            {
                cell.ToolTipText = "4X / Container Weighing Out (3rd,4th)";
            }
            else if (this.dgv_gp.Rows[e.RowIndex].Cells["WX"].Value.ToString() == "4")
            {
                cell.ToolTipText = "Non Weighing";
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void dt1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.refresh("");
            }
        }

        private void dt2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.refresh("");
            }
        }

        private void FormRegisGatepass_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!File.Exists(WBConfigurationHandler.configurationFile))
            {
                RegistryKey key2 = Registry.LocalMachine.OpenSubKey("SOFTWARE", true);
                RegistryKey key3 = key2.OpenSubKey("WCS DATABASE");
                RegistryKey key4 = key2.CreateSubKey("WCS DATABASE").CreateSubKey("WB System");
                if ((WBData.sCoyCode == ((string) key4.GetValue("Coy_Code"))) && (WBData.sLocCode == ((string) key4.GetValue("Loc_Code"))))
                {
                    this.needRefresh = false;
                }
                else
                {
                    this.needRefresh = true;
                    key4.SetValue("Coy_Code", this.textCoy.Text, RegistryValueKind.String);
                    key4.SetValue("Loc_Code", this.textLoc.Text, RegistryValueKind.String);
                }
            }
            else
            {
                Dictionary<string, string> dictionary = WBConfigurationHandler.readFromTxt(WBConfigurationHandler.configurationFile);
                if (!((!dictionary.ContainsKey("COY") || (dictionary["COY"] == WBData.sCoyCode)) ? (dictionary.ContainsKey("LOC") && (dictionary["LOC"] != WBData.sLocCode)) : true))
                {
                    this.needRefresh = false;
                }
                else
                {
                    this.needRefresh = true;
                    WBConfigurationHandler.createTxtFile(WBConfigurationHandler.configurationFile);
                    Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                        { 
                            "COY",
                            this.textCoy.Text
                        },
                        { 
                            "LOC",
                            this.textLoc.Text
                        }
                    };
                    WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                    dictToTxt.Clear();
                }
                dictionary.Clear();
            }
        }

        private void FormRegisGatepass_Load(object sender, EventArgs e)
        {
            this.textCoy.Text = WBData.sCoyCode;
            this.labelCompanyName.Text = WBData.sCoyName;
            this.cCoy = this.textCoy.Text;
            this.textLoc.Text = WBData.sLocCode;
            this.labelLocName.Text = WBSetting.Field("Location_Name").ToString();
            this.cLoc = this.textLoc.Text;
            this.tblCoy.OpenTable("wb_company", "Select * From wb_company", WBData.conn);
            this.tblLoc.OpenTable("wb_location", "Select * From wb_location", WBData.conn);
            this.dt1.Value = DateTime.Now.AddDays(-1.0);
            this.dt2.Value = DateTime.Now;
            this.cFrom = Program.DTOC(this.dt1.Value) + " 00:00:00";
            this.cTo = Program.DTOC(this.dt2.Value) + " 23:59:59";
            string[] textArray1 = new string[] { "SELECT ", this.select_fields, " FROM wb_gatepass g \r\n\t\t\t\t            LEFT JOIN wb_driver d ON d.license_no = g.license_no and d.Coy = g.coy and d.Location_Code = g.Location_Code\r\n                            LEFT JOIN (select top 1 * from wb_token order by uniq desc) tkn ON g.gatepass_number = tkn.key_1 and tkn.Coy = g.coy and tkn.Location_Code = g.Location_Code \r\n\t\t\t\t            WHERE (g.Coy = '", this.textCoy.Text, "' AND g.Location_Code = '", this.textLoc.Text, "') " };
            string sqltext = string.Concat(textArray1);
            if (!this.cb_cancel.Checked)
            {
                sqltext = sqltext + " AND (g.Deleted IS NULL OR g.Deleted = '' OR g.Deleted = 'N')";
            }
            if (!this.cb_submit.Checked)
            {
                sqltext = sqltext + " AND (g.Submit_Gatepass IS NULL OR g.Submit_Gatepass = '' OR g.Submit_Gatepass = 'N')";
            }
            if (!(this.cb_submit.Checked || this.cb_cancel.Checked))
            {
                this.panelFilter.Enabled = false;
            }
            else
            {
                this.panelFilter.Enabled = true;
                string[] textArray2 = new string[] { sqltext, " AND (g.in_date >= '", this.cFrom, "' AND g.in_date <= '", this.cTo, "')" };
                sqltext = string.Concat(textArray2);
            }
            this.t_gatepass.OpenTable("wb_gatepass", sqltext, WBData.conn);
            this.dgv_gp.DataSource = this.t_gatepass.DT;
            this.dgv_gp.Sort(this.dgv_gp.Columns["gatepass_number"], ListSortDirection.Ascending);
            int num = 0;
            while (true)
            {
                if (num >= this.dgv_gp.ColumnCount)
                {
                    this.dgv_gp.Columns["uniq"].Visible = false;
                    this.dgv_gp.Columns["submit_gatepass"].Visible = false;
                    this.dgv_gp.Columns["deleted"].Visible = false;
                    this.dgv_gp.Columns["wx"].Visible = false;
                    this.dgv_gp.Columns["In_Date"].DefaultCellStyle.Format = "dd MMM yyyy";
                    this.dgv_gp.Columns["Submit_Date"].DefaultCellStyle.Format = "dd MMM yyyy";
                    this.dgv_gp.Columns["Create_Date"].DefaultCellStyle.Format = "dd MMM yyyy HH:mm";
                    this.dgv_gp.Columns["Change_Date"].DefaultCellStyle.Format = "dd MMM yyyy HH:mm";
                    if (this.dgv_gp.Rows.Count > 0)
                    {
                        this.dgv_gp.CurrentCell = this.dgv_gp.Rows[0].Cells["Gatepass_Number"];
                    }
                    this.nSubmit = 0;
                    this.nUnsubmit = 0;
                    this.nCancel = 0;
                    foreach (DataGridViewRow row in (IEnumerable) this.dgv_gp.Rows)
                    {
                        if ((row.Cells["deleted"].Value != null) && (row.Cells["deleted"].Value.ToString() == "Y"))
                        {
                            this.nCancel++;
                            continue;
                        }
                        if ((row.Cells["submit_gatepass"].Value != null) && (row.Cells["submit_gatepass"].Value.ToString() == "Y"))
                        {
                            this.nSubmit++;
                            continue;
                        }
                        this.nUnsubmit++;
                    }
                    this.labelTotal.Text = this.dgv_gp.RowCount.ToString() + " data";
                    this.labelSub.Text = this.nUnsubmit.ToString() + " data";
                    this.labelUnsub.Text = this.nSubmit.ToString() + " data";
                    this.labelCancel.Text = this.nCancel.ToString() + " data";
                    this.TextFind.CharacterCasing = CharacterCasing.Upper;
                    this.translate();
                    return;
                }
                this.dgv_gp.Columns[num].Name = this.t_gatepass.DT.Columns[num].ColumnName;
                this.dgv_gp.Columns[num].ReadOnly = true;
                num++;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }

        private void InitializeComponent()
        {
            ComponentResourceManager manager = new ComponentResourceManager(typeof(FormRegisGatepass));
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.panel1 = new Panel();
            this.panelFilter = new Panel();
            this.dt2 = new DateTimePicker();
            this.labelFilterTgl = new Label();
            this.dt1 = new DateTimePicker();
            this.buttonFilter = new Button();
            this.labelTo = new Label();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.cb_cancel = new CheckBox();
            this.cb_submit = new CheckBox();
            this.groupBox1 = new GroupBox();
            this.buttonCopy = new Button();
            this.labelCancel = new Label();
            this.labelUnsub = new Label();
            this.labelSub = new Label();
            this.labelTotal = new Label();
            this.label6 = new Label();
            this.label4 = new Label();
            this.label3 = new Label();
            this.label2 = new Label();
            this.buttonSubmit = new Button();
            this.btn_view = new Button();
            this.btn_edit_TDT = new Button();
            this.btn_cancel = new Button();
            this.btn_edit = new Button();
            this.btn_register = new Button();
            this.label1 = new Label();
            this.dgv_gp = new DataGridView();
            this.panelCoyLoc = new Panel();
            this.labelLocName = new Label();
            this.labelCompanyName = new Label();
            this.buttonLoc = new Button();
            this.buttonCoy = new Button();
            this.textLoc = new TextBox();
            this.textCoy = new TextBox();
            this.labelLoc = new Label();
            this.labelCoy = new Label();
            this.cachedTicketGrading1 = new CachedTicketGrading();
            this.panel2 = new Panel();
            this.statusStrip1 = new StatusStrip();
            this.btn_refresh = new Button();
            this.panel1.SuspendLayout();
            this.panelFilter.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((ISupportInitialize) this.dgv_gp).BeginInit();
            this.panelCoyLoc.SuspendLayout();
            this.panel2.SuspendLayout();
            base.SuspendLayout();
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.panelFilter);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Controls.Add(this.cb_cancel);
            this.panel1.Controls.Add(this.cb_submit);
            this.panel1.Location = new Point(0, 0x204);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x49d, 0x21);
            this.panel1.TabIndex = 0x1a;
            this.panelFilter.Controls.Add(this.dt2);
            this.panelFilter.Controls.Add(this.labelFilterTgl);
            this.panelFilter.Controls.Add(this.dt1);
            this.panelFilter.Controls.Add(this.buttonFilter);
            this.panelFilter.Controls.Add(this.labelTo);
            this.panelFilter.Location = new Point(280, 2);
            this.panelFilter.Name = "panelFilter";
            this.panelFilter.Size = new Size(0x17d, 30);
            this.panelFilter.TabIndex = 0x1f;
            this.dt2.Format = DateTimePickerFormat.Short;
            this.dt2.Location = new Point(0xdd, 6);
            this.dt2.Name = "dt2";
            this.dt2.Size = new Size(0x62, 20);
            this.dt2.TabIndex = 15;
            this.dt2.KeyPress += new KeyPressEventHandler(this.dt2_KeyPress);
            this.labelFilterTgl.AutoSize = true;
            this.labelFilterTgl.Location = new Point(7, 8);
            this.labelFilterTgl.Name = "labelFilterTgl";
            this.labelFilterTgl.Size = new Size(0x4c, 13);
            this.labelFilterTgl.TabIndex = 12;
            this.labelFilterTgl.Text = "Filter data from";
            this.dt1.Format = DateTimePickerFormat.Short;
            this.dt1.Location = new Point(0x61, 6);
            this.dt1.Name = "dt1";
            this.dt1.Size = new Size(0x5f, 20);
            this.dt1.TabIndex = 14;
            this.dt1.KeyPress += new KeyPressEventHandler(this.dt1_KeyPress);
            this.buttonFilter.Location = new Point(0x145, 1);
            this.buttonFilter.Name = "buttonFilter";
            this.buttonFilter.Size = new Size(0x2d, 0x1b);
            this.buttonFilter.TabIndex = 11;
            this.buttonFilter.Text = "Filter";
            this.buttonFilter.UseVisualStyleBackColor = true;
            this.buttonFilter.Click += new EventHandler(this.buttonFilter_Click);
            this.labelTo.AutoSize = true;
            this.labelTo.Location = new Point(0xc6, 8);
            this.labelTo.Name = "labelTo";
            this.labelTo.Size = new Size(0x10, 13);
            this.labelTo.TabIndex = 13;
            this.labelTo.Text = "to";
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x3d, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.cb_cancel.AutoSize = true;
            this.cb_cancel.Location = new Point(0x393, 9);
            this.cb_cancel.Name = "cb_cancel";
            this.cb_cancel.Size = new Size(0x9f, 0x11);
            this.cb_cancel.TabIndex = 0x12;
            this.cb_cancel.Text = "Include Cancelled Gatepass";
            this.cb_cancel.UseVisualStyleBackColor = true;
            this.cb_cancel.CheckedChanged += new EventHandler(this.cb_cancel_CheckedChanged);
            this.cb_submit.AutoSize = true;
            this.cb_submit.Location = new Point(0x2af, 9);
            this.cb_submit.Name = "cb_submit";
            this.cb_submit.Size = new Size(0x9f, 0x11);
            this.cb_submit.TabIndex = 0x10;
            this.cb_submit.Text = "Include Submitted Gatepass";
            this.cb_submit.UseVisualStyleBackColor = true;
            this.cb_submit.CheckedChanged += new EventHandler(this.cb_submit_CheckedChanged);
            this.groupBox1.Controls.Add(this.btn_refresh);
            this.groupBox1.Controls.Add(this.buttonCopy);
            this.groupBox1.Controls.Add(this.labelCancel);
            this.groupBox1.Controls.Add(this.labelUnsub);
            this.groupBox1.Controls.Add(this.labelSub);
            this.groupBox1.Controls.Add(this.labelTotal);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.buttonSubmit);
            this.groupBox1.Controls.Add(this.btn_view);
            this.groupBox1.Controls.Add(this.btn_edit_TDT);
            this.groupBox1.Controls.Add(this.btn_cancel);
            this.groupBox1.Controls.Add(this.btn_edit);
            this.groupBox1.Controls.Add(this.btn_register);
            this.groupBox1.Dock = DockStyle.Bottom;
            this.groupBox1.Location = new Point(0, 0x225);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x49d, 0x4b);
            this.groupBox1.TabIndex = 0x1b;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Menu";
            this.groupBox1.Enter += new EventHandler(this.groupBox1_Enter);
            this.buttonCopy.Image = (Image) manager.GetObject("buttonCopy.Image");
            this.buttonCopy.ImageAlign = ContentAlignment.MiddleLeft;
            this.buttonCopy.Location = new Point(0x2ae, 0x17);
            this.buttonCopy.Name = "buttonCopy";
            this.buttonCopy.Size = new Size(0x52, 0x21);
            this.buttonCopy.TabIndex = 0x27;
            this.buttonCopy.Text = "Copy";
            this.buttonCopy.TextAlign = ContentAlignment.MiddleRight;
            this.buttonCopy.UseVisualStyleBackColor = true;
            this.buttonCopy.Click += new EventHandler(this.buttonCopy_Click);
            this.labelCancel.Location = new Point(0x453, 0x38);
            this.labelCancel.Name = "labelCancel";
            this.labelCancel.Size = new Size(0x44, 14);
            this.labelCancel.TabIndex = 0x26;
            this.labelCancel.Text = "0 data";
            this.labelCancel.TextAlign = ContentAlignment.MiddleRight;
            this.labelUnsub.Location = new Point(0x453, 0x29);
            this.labelUnsub.Name = "labelUnsub";
            this.labelUnsub.Size = new Size(0x44, 14);
            this.labelUnsub.TabIndex = 0x25;
            this.labelUnsub.Text = "0 data";
            this.labelUnsub.TextAlign = ContentAlignment.MiddleRight;
            this.labelSub.Location = new Point(0x453, 0x1a);
            this.labelSub.Name = "labelSub";
            this.labelSub.Size = new Size(0x44, 14);
            this.labelSub.TabIndex = 0x24;
            this.labelSub.Text = "0 data";
            this.labelSub.TextAlign = ContentAlignment.MiddleRight;
            this.labelTotal.Location = new Point(0x453, 10);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new Size(0x44, 14);
            this.labelTotal.TabIndex = 0x23;
            this.labelTotal.Text = "0 data";
            this.labelTotal.TextAlign = ContentAlignment.MiddleRight;
            this.label6.AutoSize = true;
            this.label6.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label6.Location = new Point(0x390, 0x39);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x8a, 13);
            this.label6.TabIndex = 0x1b;
            this.label6.Text = "Total of cancelled gatepass";
            this.label4.AutoSize = true;
            this.label4.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label4.Location = new Point(0x390, 0x2a);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x89, 13);
            this.label4.TabIndex = 0x18;
            this.label4.Text = "Total of submitted gatepass";
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(0x390, 0x1b);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x95, 13);
            this.label3.TabIndex = 0x17;
            this.label3.Text = "Total of unsubmitted gatepass";
            this.label2.AutoSize = true;
            this.label2.Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label2.Location = new Point(0x390, 11);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x66, 13);
            this.label2.TabIndex = 0x16;
            this.label2.Text = "Total of all gatepass";
            this.buttonSubmit.Image = Resources.submit_22px;
            this.buttonSubmit.ImageAlign = ContentAlignment.MiddleLeft;
            this.buttonSubmit.Location = new Point(0x159, 0x17);
            this.buttonSubmit.Name = "buttonSubmit";
            this.buttonSubmit.Size = new Size(0x7c, 0x21);
            this.buttonSubmit.TabIndex = 0x15;
            this.buttonSubmit.Text = "Submit Gatepass";
            this.buttonSubmit.TextAlign = ContentAlignment.MiddleRight;
            this.buttonSubmit.UseVisualStyleBackColor = true;
            this.buttonSubmit.Click += new EventHandler(this.buttonSubmit_Click);
            this.btn_view.Image = Resources.search_16px;
            this.btn_view.ImageAlign = ContentAlignment.MiddleLeft;
            this.btn_view.Location = new Point(0x90, 0x17);
            this.btn_view.Name = "btn_view";
            this.btn_view.Size = new Size(0x4b, 0x21);
            this.btn_view.TabIndex = 20;
            this.btn_view.Text = "View";
            this.btn_view.TextAlign = ContentAlignment.MiddleRight;
            this.btn_view.UseVisualStyleBackColor = true;
            this.btn_view.Click += new EventHandler(this.btn_view_Click);
            this.btn_edit_TDT.Image = Resources.people__3_;
            this.btn_edit_TDT.ImageAlign = ContentAlignment.MiddleLeft;
            this.btn_edit_TDT.Location = new Point(0x1d8, 0x17);
            this.btn_edit_TDT.Name = "btn_edit_TDT";
            this.btn_edit_TDT.Size = new Size(0x6f, 0x21);
            this.btn_edit_TDT.TabIndex = 0x13;
            this.btn_edit_TDT.Text = "Edit TDT";
            this.btn_edit_TDT.TextAlign = ContentAlignment.MiddleRight;
            this.btn_edit_TDT.UseVisualStyleBackColor = true;
            this.btn_edit_TDT.Click += new EventHandler(this.btn_edit_TDT_Click);
            this.btn_cancel.Image = (Image) manager.GetObject("btn_cancel.Image");
            this.btn_cancel.ImageAlign = ContentAlignment.MiddleLeft;
            this.btn_cancel.Location = new Point(0x304, 0x17);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new Size(0x57, 0x21);
            this.btn_cancel.TabIndex = 2;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.TextAlign = ContentAlignment.MiddleRight;
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new EventHandler(this.btn_cancel_Click);
            this.btn_edit.Image = (Image) manager.GetObject("btn_edit.Image");
            this.btn_edit.ImageAlign = ContentAlignment.MiddleLeft;
            this.btn_edit.Location = new Point(0xdf, 0x17);
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new Size(0x77, 0x21);
            this.btn_edit.TabIndex = 1;
            this.btn_edit.Text = "Edit Registration";
            this.btn_edit.TextAlign = ContentAlignment.MiddleRight;
            this.btn_edit.UseVisualStyleBackColor = true;
            this.btn_edit.Click += new EventHandler(this.btn_edit_Click);
            this.btn_register.Image = (Image) manager.GetObject("btn_register.Image");
            this.btn_register.ImageAlign = ContentAlignment.MiddleLeft;
            this.btn_register.Location = new Point(12, 0x17);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new Size(0x7f, 0x21);
            this.btn_register.TabIndex = 0;
            this.btn_register.Text = "Register Truck";
            this.btn_register.TextAlign = ContentAlignment.MiddleRight;
            this.btn_register.UseVisualStyleBackColor = true;
            this.btn_register.Click += new EventHandler(this.btn_register_Click);
            this.label1.BackColor = Color.FromArgb(0xff, 0x80, 0);
            this.label1.Dock = DockStyle.Top;
            this.label1.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.ForeColor = Color.White;
            this.label1.Location = new Point(0, 0);
            this.label1.Margin = new Padding(0);
            this.label1.Name = "label1";
            this.label1.RightToLeft = RightToLeft.Yes;
            this.label1.Size = new Size(0x49d, 0x19);
            this.label1.TabIndex = 0x1d;
            this.label1.Text = "GATEPASS REGISTRATION";
            this.label1.TextAlign = ContentAlignment.TopCenter;
            this.dgv_gp.AllowUserToAddRows = false;
            this.dgv_gp.AllowUserToDeleteRows = false;
            this.dgv_gp.AllowUserToOrderColumns = true;
            this.dgv_gp.AllowUserToResizeRows = false;
            this.dgv_gp.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgv_gp.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgv_gp.ColumnHeadersDefaultCellStyle = style;
            this.dgv_gp.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgv_gp.DefaultCellStyle = style2;
            this.dgv_gp.Dock = DockStyle.Fill;
            this.dgv_gp.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgv_gp.Location = new Point(0, 0);
            this.dgv_gp.MultiSelect = false;
            this.dgv_gp.Name = "dgv_gp";
            this.dgv_gp.ReadOnly = true;
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgv_gp.RowHeadersDefaultCellStyle = style3;
            this.dgv_gp.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgv_gp.Size = new Size(0x49d, 420);
            this.dgv_gp.TabIndex = 30;
            this.dgv_gp.CellDoubleClick += new DataGridViewCellEventHandler(this.dgv_gp_CellDoubleClick);
            this.dgv_gp.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dgv_gp_CellFormatting);
            this.panelCoyLoc.Controls.Add(this.labelLocName);
            this.panelCoyLoc.Controls.Add(this.labelCompanyName);
            this.panelCoyLoc.Controls.Add(this.buttonLoc);
            this.panelCoyLoc.Controls.Add(this.buttonCoy);
            this.panelCoyLoc.Controls.Add(this.textLoc);
            this.panelCoyLoc.Controls.Add(this.textCoy);
            this.panelCoyLoc.Controls.Add(this.labelLoc);
            this.panelCoyLoc.Controls.Add(this.labelCoy);
            this.panelCoyLoc.Dock = DockStyle.Top;
            this.panelCoyLoc.Location = new Point(0, 0x19);
            this.panelCoyLoc.Name = "panelCoyLoc";
            this.panelCoyLoc.Size = new Size(0x49d, 0x47);
            this.panelCoyLoc.TabIndex = 0x1f;
            this.panelCoyLoc.Paint += new PaintEventHandler(this.panelCoyLoc_Paint);
            this.labelLocName.AutoSize = true;
            this.labelLocName.Location = new Point(0xc0, 0x2b);
            this.labelLocName.Name = "labelLocName";
            this.labelLocName.Size = new Size(0x4f, 13);
            this.labelLocName.TabIndex = 0x16;
            this.labelLocName.Text = "Location Name";
            this.labelCompanyName.AutoSize = true;
            this.labelCompanyName.Location = new Point(0xc0, 14);
            this.labelCompanyName.Name = "labelCompanyName";
            this.labelCompanyName.Size = new Size(0x52, 13);
            this.labelCompanyName.TabIndex = 0x15;
            this.labelCompanyName.Text = "Company Name";
            this.buttonLoc.Location = new Point(0xa6, 0x26);
            this.buttonLoc.Margin = new Padding(0);
            this.buttonLoc.Name = "buttonLoc";
            this.buttonLoc.Size = new Size(0x17, 0x17);
            this.buttonLoc.TabIndex = 20;
            this.buttonLoc.Text = "...";
            this.buttonLoc.UseVisualStyleBackColor = true;
            this.buttonLoc.Click += new EventHandler(this.buttonLoc_Click);
            this.buttonCoy.Location = new Point(0xa6, 9);
            this.buttonCoy.Margin = new Padding(0);
            this.buttonCoy.Name = "buttonCoy";
            this.buttonCoy.Size = new Size(0x17, 0x17);
            this.buttonCoy.TabIndex = 0x13;
            this.buttonCoy.Text = "...";
            this.buttonCoy.UseVisualStyleBackColor = true;
            this.buttonCoy.Click += new EventHandler(this.buttonCoy_Click);
            this.textLoc.Location = new Point(0x67, 40);
            this.textLoc.Name = "textLoc";
            this.textLoc.ReadOnly = true;
            this.textLoc.Size = new Size(60, 20);
            this.textLoc.TabIndex = 0x12;
            this.textCoy.CharacterCasing = CharacterCasing.Upper;
            this.textCoy.Location = new Point(0x67, 11);
            this.textCoy.Name = "textCoy";
            this.textCoy.ReadOnly = true;
            this.textCoy.Size = new Size(60, 20);
            this.textCoy.TabIndex = 0x11;
            this.labelLoc.Location = new Point(0x11, 0x2b);
            this.labelLoc.Name = "labelLoc";
            this.labelLoc.Size = new Size(0x52, 0x12);
            this.labelLoc.TabIndex = 0x10;
            this.labelLoc.Text = "Location";
            this.labelLoc.TextAlign = ContentAlignment.TopRight;
            this.labelCoy.Location = new Point(20, 14);
            this.labelCoy.Name = "labelCoy";
            this.labelCoy.Size = new Size(0x4f, 0x12);
            this.labelCoy.TabIndex = 15;
            this.labelCoy.Text = "Company";
            this.labelCoy.TextAlign = ContentAlignment.TopRight;
            this.panel2.Controls.Add(this.dgv_gp);
            this.panel2.Location = new Point(0, 0x5f);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0x49d, 420);
            this.panel2.TabIndex = 0x21;
            this.statusStrip1.Location = new Point(0, 0x270);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(0x49d, 0x16);
            this.statusStrip1.TabIndex = 0x20;
            this.statusStrip1.Text = "statusStrip1";
            this.btn_refresh.Image = Resources.refresh_24px;
            this.btn_refresh.ImageAlign = ContentAlignment.MiddleLeft;
            this.btn_refresh.Location = new Point(0x24d, 0x17);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new Size(0x5e, 0x21);
            this.btn_refresh.TabIndex = 40;
            this.btn_refresh.Text = "Refresh";
            this.btn_refresh.TextAlign = ContentAlignment.MiddleRight;
            this.btn_refresh.UseVisualStyleBackColor = true;
            this.btn_refresh.Click += new EventHandler(this.btn_refresh_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x49d, 0x286);
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.statusStrip1);
            base.Controls.Add(this.panelCoyLoc);
            base.Controls.Add(this.label1);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormRegisGatepass";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Gatepass Registration";
            base.FormClosed += new FormClosedEventHandler(this.FormRegisGatepass_FormClosed);
            base.Load += new EventHandler(this.FormRegisGatepass_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelFilter.ResumeLayout(false);
            this.panelFilter.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((ISupportInitialize) this.dgv_gp).EndInit();
            this.panelCoyLoc.ResumeLayout(false);
            this.panelCoyLoc.PerformLayout();
            this.panel2.ResumeLayout(false);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void panelCoyLoc_Paint(object sender, PaintEventArgs e)
        {
        }

        private void refresh(string gatepass)
        {
            Cursor.Current = Cursors.WaitCursor;
            WBData.sCoyCode = this.textCoy.Text;
            WBData.sLocCode = this.textLoc.Text;
            WBData.sCoyName = this.labelCompanyName.Text;
            WBData.sLocName = this.labelLocName.Text;
            this.cFrom = Program.DTOC(this.dt1.Value) + " 00:00:00";
            this.cTo = Program.DTOC(this.dt2.Value) + " 23:59:59";
            string[] textArray1 = new string[] { "SELECT ", this.select_fields, " FROM wb_gatepass g \r\n\t\t\t\t            LEFT JOIN wb_driver d ON d.license_no = g.license_no and d.Coy = g.coy and d.Location_Code = g.Location_Code\r\n                            LEFT JOIN (select top 1 * from wb_token order by uniq desc) tkn ON g.gatepass_number = tkn.key_1 and tkn.Coy = g.coy and tkn.Location_Code = g.Location_Code\r\n\t\t\t\t            WHERE (g.Coy = '", this.textCoy.Text, "' AND g.Location_Code = '", this.textLoc.Text, "') " };
            string sqltext = string.Concat(textArray1);
            if (!this.cb_cancel.Checked)
            {
                sqltext = sqltext + " AND (g.Deleted IS NULL OR g.Deleted = '' OR g.Deleted = 'N')";
            }
            if (!this.cb_submit.Checked)
            {
                sqltext = sqltext + " AND (g.Submit_Gatepass IS NULL OR g.Submit_Gatepass = '' OR g.Submit_Gatepass = 'N')";
            }
            if (!(this.cb_submit.Checked || this.cb_cancel.Checked))
            {
                this.panelFilter.Enabled = false;
            }
            else
            {
                this.panelFilter.Enabled = true;
                string[] textArray2 = new string[] { sqltext, " and (g.in_date >= '", this.cFrom, "' and g.in_date <= '", this.cTo, "')" };
                sqltext = string.Concat(textArray2);
            }
            this.t_gatepass.OpenTable("wb_gatepass", sqltext, WBData.conn);
            this.dgv_gp.DataSource = this.t_gatepass.DT;
            this.dgv_gp.Sort(this.dgv_gp.Columns["gatepass_number"], ListSortDirection.Ascending);
            this.dgv_gp.Update();
            this.dgv_gp.Refresh();
            this.nSubmit = 0;
            this.nUnsubmit = 0;
            this.nCancel = 0;
            foreach (DataGridViewRow row in (IEnumerable) this.dgv_gp.Rows)
            {
                if ((row.Cells["deleted"].Value != null) && (row.Cells["deleted"].Value.ToString() == "Y"))
                {
                    this.nCancel++;
                    continue;
                }
                if ((row.Cells["submit_gatepass"].Value != null) && (row.Cells["submit_gatepass"].Value.ToString() == "Y"))
                {
                    this.nSubmit++;
                    continue;
                }
                this.nUnsubmit++;
            }
            this.labelTotal.Text = this.dgv_gp.RowCount.ToString() + " record(s)";
            this.labelSub.Text = this.nUnsubmit.ToString() + " record(s)";
            this.labelUnsub.Text = this.nSubmit.ToString() + " record(s)";
            this.labelCancel.Text = this.nCancel.ToString() + " record(s)";
            if (gatepass != "")
            {
                string[] aField = new string[] { "gatepass_number" };
                string[] aFind = new string[] { gatepass };
                this.t_gatepass.SetCursor(this.dgv_gp, this.t_gatepass.GetCurrentRow(this.dgv_gp, aField, aFind));
            }
            Cursor.Current = Cursors.Default;
        }

        public void showFormforSubmit()
        {
            if (string.IsNullOrEmpty(this.textCoy.Text) || string.IsNullOrEmpty(this.textLoc.Text))
            {
                MessageBox.Show("Please Choose Company Code and Location Code", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (WBSetting.region == "2")
            {
                FormRegisGatepassEntry entry = new FormRegisGatepassEntry("SUBMIT", "");
                entry.ShowDialog();
                entry.Dispose();
                this.refresh("");
            }
            else if (WBSetting.region == "0")
            {
                FormRegisGatepassEntryId id = new FormRegisGatepassEntryId {
                    cCoy = this.textCoy.Text,
                    cLoc = this.textLoc.Text,
                    pMode = "SUBMIT",
                    pUniq = this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString(),
                    gatepassNo = this.dgv_gp.CurrentRow.Cells["Gatepass_Number"].Value.ToString(),
                    ticketRpt = this.ticketRpt,
                    ticket_multi1 = this.ticket_multi1,
                    ticket_multi2 = this.ticket_multi2,
                    ticketLangsir = this.ticketLangsir,
                    ticketLangsir2 = this.ticketLangsir2,
                    fRpt = this.fRpt
                };
                id.ShowDialog();
                id.Dispose();
                this.refresh("");
            }
        }

        public bool submit_1X(WBTable tG, WBTable tT)
        {
            bool flag = true;
            DataRow row = tG.DT.Rows[0];
            DataRow row2 = tT.DT.Rows[0];
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { " SELECT * FROM wb_transaction WHERE Coy = '", this.textCoy.Text, "' AND location_code = '", this.textLoc.Text, "'  AND linked = '", row2["ref"].ToString(), "'  AND (Deleted = 'N' OR Deleted = '' OR Deleted IS NULL) " };
            table.OpenTable("wb_trans", string.Concat(textArray1), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                MessageBox.Show("Can not submit unlinked transaction!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                flag = false;
            }
            else
            {
                DataRow row3 = table.DT.Rows[0];
                if (((row3["_4th"].ToString() == "") || (row3["_4th"].ToString() == "0")) ? (row3["Report_Date"].ToString() == "") : false)
                {
                    MessageBox.Show("Transaction with reference no " + row3["ref"].ToString() + " hasn't been weighed out!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    flag = false;
                }
                else
                {
                    string[] textArray2 = new string[] { "Are you sure to submit gatepass ", this.dgv_gp.CurrentRow.Cells["Gatepass_Number"].Value.ToString(), " with card no. ", this.dgv_gp.CurrentRow.Cells["Card_No"].Value.ToString(), "? " };
                    if (MessageBox.Show(string.Concat(textArray2), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        if (WBSetting.activeTCS)
                        {
                            table.Dispose();
                            this.showFormforSubmit();
                        }
                        else
                        {
                            tG.DR = tG.DT.Rows[0];
                            tG.DR.BeginEdit();
                            tG.DR["Truck_Number"] = row2["Truck_Number2"].ToString();
                            tG.DR["tanker_no"] = row2["tanker"].ToString();
                            tG.DR["Transporter_Code"] = row2["Transporter_Code"].ToString();
                            tG.DR["License_No"] = row2["License_No"].ToString();
                            tG.DR["delivery_note"] = row2["delivery_note"].ToString();
                            tG.DR["seal"] = row2["seal"].ToString();
                            tG.DR["Out_Date"] = row3["Date4"].ToString();
                            tG.DR["Out_Time"] = row3["time4"].ToString();
                            tG.DR["Submit_Gatepass"] = "Y";
                            tG.DR["Submit_Date"] = DateTime.Now.ToShortDateString();
                            tG.DR["Submit_time"] = DateTime.Now.ToShortTimeString();
                            tG.DR.EndEdit();
                            tG.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "SUBMIT", WBUser.UserID, "Submit Gatepass" };
                            Program.updateLogHeader("wb_gatepass", this.dgv_gp.CurrentRow.Cells["uniq"].Value.ToString(), logField, logValue);
                            MessageBox.Show("Gatepass is submitted successfully!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                    }
                }
            }
            table.Dispose();
            return flag;
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((this.dgv_gp.SortedColumn.Name.ToString().ToUpper() == "REGCARD_NO") && ((this.TextFind.Text.Length >= 10) && (e.KeyChar == '\r')))
            {
                this.TextFind.Text = WBCard.getCardNo(this.TextFind.Text);
            }
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.Text = Resource.Gatepass_055;
            this.label1.Text = Resource.Gatepass_055;
            this.labelCoy.Text = Resource.Menu_026;
            this.labelLoc.Text = Resource.Menu_027;
            this.buttonFind.Text = Resource.Gatepass_019;
            this.labelFilterTgl.Text = Resource.Gatepass_021;
            this.labelTo.Text = Resource.Gatepass_022;
            this.buttonFilter.Text = Resource.Gatepass_020;
            this.cb_cancel.Text = Resource.Gatepass_028;
            this.cb_submit.Text = Resource.Gatepass_027;
            this.btn_register.Text = Resource.Gatepass_051;
            this.btn_edit.Text = Resource.Gatepass_054;
            this.btn_cancel.Text = Resource.Gatepass_053;
            this.btn_view.Text = Resource.Gatepass_052;
            this.btn_refresh.Text = Resource.Trans_058;
            this.btn_edit_TDT.Text = Resource.Gatepass_077;
            this.buttonSubmit.Text = Resource.Gatepass_005;
            this.buttonCopy.Text = Resource.Gatepass_076;
            this.dgv_gp.Columns["Gatepass_Number"].HeaderText = Resource.Gatepass_001;
            this.dgv_gp.Columns["RegCard_No"].HeaderText = Resource.Gatepass_056;
            this.dgv_gp.Columns["ref"].HeaderText = Resource.Gatepass_057;
            this.dgv_gp.Columns["Truck_Number"].HeaderText = Resource.Gatepass_003;
            this.dgv_gp.Columns["tanker_no"].HeaderText = Resource.Gatepass_058;
            this.dgv_gp.Columns["License_No"].HeaderText = Resource.Gatepass_059;
            this.dgv_gp.Columns["Transporter_Code"].HeaderText = Resource.Gatepass_002;
            this.dgv_gp.Columns["name"].HeaderText = Resource.Gatepass_060;
            this.dgv_gp.Columns["delivery_note"].HeaderText = Resource.Gatepass_061;
            this.dgv_gp.Columns["seal"].HeaderText = Resource.Gatepass_062;
            this.dgv_gp.Columns["GatePass_Remark"].HeaderText = Resource.Gatepass_012;
            this.dgv_gp.Columns["In_Date"].HeaderText = Resource.Gatepass_006;
            this.dgv_gp.Columns["In_Time"].HeaderText = Resource.Gatepass_007;
            this.dgv_gp.Columns["Submit_by"].HeaderText = Resource.Gatepass_075;
            this.dgv_gp.Columns["submit_date"].HeaderText = Resource.Gatepass_008;
            this.dgv_gp.Columns["submit_time"].HeaderText = Resource.Gatepass_009;
            this.dgv_gp.Columns["Create_By"].HeaderText = Resource.Gatepass_063;
            this.dgv_gp.Columns["Create_Date"].HeaderText = Resource.Gatepass_064;
            this.dgv_gp.Columns["Change_By"].HeaderText = Resource.Gatepass_065;
            this.dgv_gp.Columns["Change_Date"].HeaderText = Resource.Gatepass_066;
            this.dgv_gp.Columns["delete_By"].HeaderText = Resource.Gatepass_067;
            this.dgv_gp.Columns["delete_Date"].HeaderText = Resource.Gatepass_068;
            this.dgv_gp.Columns["WX"].Visible = false;
            this.label2.Text = Resource.Gatepass_071;
            this.label3.Text = Resource.Gatepass_072;
            this.label4.Text = Resource.Gatepass_073;
            this.label6.Text = Resource.Gatepass_074;
        }
    }
}

