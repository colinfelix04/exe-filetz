﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Data;

    internal class RepUserList
    {
        public void generateRep()
        {
            string sqltext = ((("SELECT * FROM wb_user u, wb_group g with (nolock)" + " WHERE u.coy = g.coy " + " AND u.location_code = g.location_code ") + " AND u.coy = '" + WBData.sCoyCode + "' ") + " AND u.location_code = '" + WBData.sLocCode + "' ") + " AND u.user_group = g.code " + " ORDER BY u.user_id, u.user_group ";
            WBTable table = new WBTable();
            table.OpenTable("wb_user", sqltext, WBData.conn);
            HTML html = new HTML();
            html.File = html.File + @"\" + WBUser.UserID + "_UserList.htm";
            html.Title = "User List Report";
            html.Open();
            html.Write(html.Style());
            html.Write("<br><font size=5><b>USER LIST REPORT</b></font><br>");
            string[] textArray1 = new string[] { "<br><font size=4>", WBSetting.tblSetting.DR["Coy_Name"].ToString(), " (", WBData.sCoyCode, ")</font>" };
            html.Write(string.Concat(textArray1));
            string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
            html.Write(string.Concat(textArray2));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            html.Write("<br/><br/>");
            html.Write("<font size=2>Report Date : <b>" + DateTime.Now.ToShortDateString() + "</b></font>");
            html.Write("<br/><br/><br/>");
            html.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
            html.Write("<tr class=bd>");
            html.Write("<th>No.</th>");
            html.Write("<th>User ID</th>");
            html.Write("<th>Name</th>");
            html.Write("<th>User Group</th>");
            html.Write("<th>User Group Name</th>");
            html.Write("<th>Created Date Time</th>");
            html.Write("<th>Active</th>");
            html.Write("<th>Inactivate By</th>");
            html.Write("<th>Inactive Reason</th>");
            html.Write("<th>Inactive Date Time</th>");
            html.Write("<th>Last Login Date Time</th>");
            html.Write("<th>Last Login (in Days)</th>");
            html.Write("</tr>");
            int num = 1;
            foreach (DataRow row in table.DT.Rows)
            {
                html.Write("<tr class=bd>");
                html.Write("<td align='right'>" + num + "</td>");
                html.Write("<td>" + row["User_Id"].ToString() + "</td>");
                html.Write("<td>" + row["User_Name"].ToString() + "</td>");
                html.Write("<td align='center'>" + row["User_Group"].ToString() + "</td>");
                html.Write("<td>" + row["Name"].ToString() + "</td>");
                html.Write("<td>" + row["Create_Date"].ToString() + "</td>");
                if (row["deleted"].ToString() == "*")
                {
                    html.Write("<td align='center'>No</td>");
                    html.Write("<td>" + row["delete_by"].ToString() + "</td>");
                    html.Write("<td>" + row["changereason"].ToString() + "</td>");
                    html.Write("<td>" + row["delete_date"].ToString() + "</td>");
                }
                else
                {
                    html.Write("<td align='center'>Yes</td>");
                    html.Write("<td></td>");
                    html.Write("<td></td>");
                    html.Write("<td></td>");
                }
                if ((row["lastlogin"].ToString() == null) || (row["lastlogin"].ToString() == ""))
                {
                    html.Write("<td>Never Login to WB.Net</td>");
                    html.Write("<td align='right'>0</td>");
                }
                else
                {
                    html.Write("<td>" + row["lastlogin"].ToString() + "</td>");
                    html.Write("<td align = 'right'>" + (DateTime.Now - Convert.ToDateTime(row["lastlogin"].ToString())).Days + "</td>");
                }
                html.Write("</tr>");
                num++;
            }
            html.Write("</table>");
            html.Write("<br>");
            html.Write("<br>");
            html.writeSign();
            html.Close();
            if (html != null)
            {
                ViewReport report = new ViewReport {
                    webBrowser1 = { Url = new Uri("file:///" + html.File) }
                };
                report.ShowDialog();
                html.Dispose();
                report.Dispose();
            }
            table.Dispose();
        }
    }
}

