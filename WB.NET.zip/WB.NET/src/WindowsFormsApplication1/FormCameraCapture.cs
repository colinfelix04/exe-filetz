﻿namespace WindowsFormsApplication1
{
    using Camera.Utility;
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCameraCapture : Form
    {
        public string camera_code;
        public string camera_type;
        public string ip_address;
        public string username;
        public string password;
        public string web_url;
        public string webcam_name;
        public string path;
        public bool can_stream = false;
        public bool captured = false;
        private WBCamera camera = new WBCamera();
        private IContainer components = null;
        public PictureBox pic_box;
        private Button btnCapturePhoto;

        public FormCameraCapture()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void btnCapturePhoto_Click(object sender, EventArgs e)
        {
            this.f_CaptureImg();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void f_CaptureImg()
        {
            this.captured = true;
            base.Close();
        }

        private void FormCameraCapture_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                this.f_CaptureImg();
            }
        }

        private void FormCameraPreview_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.camera.CloseCurrentVideoSource();
        }

        private void FormCameraPreview_Load(object sender, EventArgs e)
        {
            if (this.camera_type == "IP_CAMERA")
            {
                Cursor.Current = Cursors.WaitCursor;
                this.can_stream = this.camera.getHttpRequest(this.web_url, this.username, this.password, this.pic_box, this.camera_code);
            }
            else if (this.camera_type == "WEB_CAMERA")
            {
                this.can_stream = this.camera.streamWebCamera(this.webcam_name, this.pic_box);
            }
            else
            {
                this.can_stream = true;
                base.Close();
            }
            if (!this.can_stream && (this.camera_type != "IP_CAMERA"))
            {
                MessageBox.Show(Resource.Camera_002, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else if (!this.can_stream)
            {
                base.Close();
            }
        }

        private void InitializeComponent()
        {
            this.pic_box = new PictureBox();
            this.btnCapturePhoto = new Button();
            ((ISupportInitialize) this.pic_box).BeginInit();
            base.SuspendLayout();
            this.pic_box.Location = new Point(0x10, 15);
            this.pic_box.Margin = new Padding(4);
            this.pic_box.Name = "pic_box";
            this.pic_box.Size = new Size(800, 0x22a);
            this.pic_box.SizeMode = PictureBoxSizeMode.StretchImage;
            this.pic_box.TabIndex = 9;
            this.pic_box.TabStop = false;
            this.btnCapturePhoto.Location = new Point(0x10, 0x241);
            this.btnCapturePhoto.Margin = new Padding(4);
            this.btnCapturePhoto.Name = "btnCapturePhoto";
            this.btnCapturePhoto.Size = new Size(800, 0x3a);
            this.btnCapturePhoto.TabIndex = 0x4e;
            this.btnCapturePhoto.Text = "&Click here or Press Space to Capture Photo";
            this.btnCapturePhoto.UseVisualStyleBackColor = true;
            this.btnCapturePhoto.Click += new EventHandler(this.btnCapturePhoto_Click);
            base.AutoScaleDimensions = new SizeF(8f, 16f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x347, 0x284);
            base.Controls.Add(this.btnCapturePhoto);
            base.Controls.Add(this.pic_box);
            base.FormBorderStyle = FormBorderStyle.FixedSingle;
            base.Margin = new Padding(4);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormCameraCapture";
            base.ShowInTaskbar = false;
            base.SizeGripStyle = SizeGripStyle.Hide;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Camera Capture";
            base.FormClosing += new FormClosingEventHandler(this.FormCameraPreview_FormClosing);
            base.Load += new EventHandler(this.FormCameraPreview_Load);
            base.KeyUp += new KeyEventHandler(this.FormCameraCapture_KeyUp);
            ((ISupportInitialize) this.pic_box).EndInit();
            base.ResumeLayout(false);
        }

        private void translate()
        {
            this.Text = Resource.Title_Camera_Capture;
        }
    }
}

