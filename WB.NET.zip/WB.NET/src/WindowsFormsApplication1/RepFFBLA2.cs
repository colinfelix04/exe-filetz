﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;

    public class RepFFBLA2 : Form
    {
        private WBTable tbl_Comm;
        private WBTable tbl_Supp;
        private WBTable tbl_Trans;
        private string sqlTrans;
        private int maxRow = 50;
        private int No = 0;
        private int jlhkol = 0;
        private int jlhRecord = 0;
        private double received;
        private double treceived;
        private double deduc;
        private double tdeduc;
        private double net;
        private double tnet;
        private double rSdhi;
        private double nSdhi;
        private double sreceived;
        private double sdeduc;
        private double snet;
        private double srsdhi;
        private double snsdhi;
        private double colly;
        private double tcolly;
        private double scolly;
        private double bunch;
        private double sbunch;
        private double tbunch;
        public bool ffb;
        private string relation_code;
        private IContainer components = null;
        public Button buttonComm;
        public Label labelCommName;
        public TextBox textCommodity;
        public Label labelcommodity;
        public Button button2;
        public Button button1;
        public DateTimePicker monthCalendar2;
        public Label labelRecNo;
        public Label labelProcess;
        public DateTimePicker monthCalendar1;
        public Label label5;
        private TextBox textBox1;
        public Label label3;
        public CheckBox checkColly;
        public CheckBox checkBunch;
        private GroupBox groupFType;
        private CheckBox checkR;
        private CheckBox checkK;
        private CheckBox checkS;
        private CheckBox checkB;
        private CheckBox checkM;
        public GroupBox grType;
        private RadioButton rboAll;
        public RadioButton rboGI;
        public RadioButton rboGR;
        public GroupBox groupBox2;
        public Label label8;
        public Label label9;

        public RepFFBLA2()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days <= 31.0)
            {
                if (this.textCommodity.Text.Trim() != "")
                {
                    if (this.textCommodity.Text.Trim() != "")
                    {
                        if (!this.ffb)
                        {
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE type!='F' AND comm_code='" + this.textCommodity.Text.Trim() + "'", WBData.conn);
                            if (table2.DT.Rows.Count < 1)
                            {
                                MessageBox.Show("Please Choose Commodity which Type is not F (FFB)!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.textCommodity.Focus();
                                return;
                            }
                        }
                        else
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE type='F' AND comm_code='" + this.textCommodity.Text.Trim() + "'", WBData.conn);
                            if (table.DT.Rows.Count < 1)
                            {
                                MessageBox.Show("Please Choose Commodity which Type is F (FFB)!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.textCommodity.Focus();
                                return;
                            }
                        }
                    }
                    if (Convert.ToDateTime(this.monthCalendar2.Value.ToShortDateString()) < Convert.ToDateTime(this.monthCalendar1.Value.ToShortDateString()))
                    {
                        MessageBox.Show("Invalid Date Selected, Date To is Smaller than Date From.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        int index = 0;
                        string[] source = new string[5];
                        foreach (Control control in this.groupFType.Controls)
                        {
                            CheckBox box = control as CheckBox;
                            if ((box != null) && box.Checked)
                            {
                                source[index] = box.Text;
                                index++;
                            }
                        }
                        this.sqlTrans = "select * from vw_trans where " + WBData.CompanyLocation(" and comm_code ='" + this.textCommodity.Text + "'");
                        this.sqlTrans = this.sqlTrans + " and ((report_Date>='" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00'";
                        this.sqlTrans = this.sqlTrans + " and report_Date<='" + this.monthCalendar2.Value.ToString("yyyy-MM-dd") + " 00:00:00'))";
                        if (this.rboGI.Checked)
                        {
                            this.sqlTrans = this.sqlTrans + " and IO = 'O' ";
                        }
                        else if (this.rboGR.Checked)
                        {
                            this.sqlTrans = this.sqlTrans + " and IO = 'I' ";
                        }
                        if (this.ffb)
                        {
                            this.sqlTrans = this.sqlTrans + " and Type = 'F' ";
                        }
                        this.sqlTrans = this.sqlTrans + " and (deleted is null or deleted = 'N') and ( report_Date is not null or report_date <> '') ";
                        if (this.ffb)
                        {
                            if (index <= 0)
                            {
                                this.sqlTrans = this.sqlTrans + " and (Fruits_type = '' or Fruits_type is null) ";
                            }
                            else
                            {
                                int num3 = 0;
                                while (true)
                                {
                                    if (num3 >= source.Count<string>())
                                    {
                                        this.sqlTrans = this.sqlTrans + " ) ";
                                        break;
                                    }
                                    if (source[num3] != "")
                                    {
                                        this.sqlTrans = (num3 != 0) ? (this.sqlTrans + " or Fruits_type = '" + source[num3] + "' ") : (this.sqlTrans + " and ( Fruits_type = '" + source[num3] + "' ");
                                    }
                                    num3++;
                                }
                            }
                        }
                        this.sqlTrans = this.sqlTrans + " order by relation_code,ref";
                        this.tbl_Trans = new WBTable();
                        this.tbl_Trans.OpenTable("vw_trans", this.sqlTrans, WBData.conn);
                        if (this.tbl_Trans.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show("No Records Found", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                        else
                        {
                            this.jlhRecord = this.tbl_Trans.DT.Rows.Count;
                            this.labelRecNo.Visible = true;
                            this.labelProcess.Visible = true;
                            this.labelProcess.Refresh();
                            this.labelRecNo.Refresh();
                            this.printReport();
                            this.labelRecNo.Visible = false;
                            this.labelProcess.Visible = false;
                            this.tbl_Trans.Dispose();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please Fill in Commodity.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            else
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
                this.textCommodity.Focus();
            }
            commodity.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void initHeader(HTML rep)
        {
            this.jlhkol = 0;
            rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
            rep.Write("<tr class='bd'>");
            rep.Write("<td nowrap align=center><b>No.</b></td>");
            rep.Write("<td nowrap align=center><b>Relation</b></td>");
            if (this.checkColly.Checked)
            {
                rep.Write("<td nowrap align=center><b>Colly</b></td>");
            }
            rep.Write("<td nowrap align=center><b>Received</b></td>");
            rep.Write("<td nowrap align=center><b>U/Today</b></td>");
            rep.Write("<td nowrap align=center><b>Deduction</b></td>");
            rep.Write("<td nowrap align=center><b>Netto</b></td>");
            rep.Write("<td nowrap align=center><b>U/Today</b></td>");
            rep.Write("</tr>");
        }

        private void InitializeComponent()
        {
            this.buttonComm = new Button();
            this.labelCommName = new Label();
            this.textCommodity = new TextBox();
            this.labelcommodity = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.monthCalendar2 = new DateTimePicker();
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.monthCalendar1 = new DateTimePicker();
            this.label5 = new Label();
            this.textBox1 = new TextBox();
            this.label3 = new Label();
            this.checkColly = new CheckBox();
            this.checkBunch = new CheckBox();
            this.groupFType = new GroupBox();
            this.checkR = new CheckBox();
            this.checkK = new CheckBox();
            this.checkS = new CheckBox();
            this.checkB = new CheckBox();
            this.checkM = new CheckBox();
            this.grType = new GroupBox();
            this.rboAll = new RadioButton();
            this.rboGI = new RadioButton();
            this.rboGR = new RadioButton();
            this.groupBox2 = new GroupBox();
            this.label8 = new Label();
            this.label9 = new Label();
            this.groupFType.SuspendLayout();
            this.grType.SuspendLayout();
            this.groupBox2.SuspendLayout();
            base.SuspendLayout();
            this.buttonComm.Location = new Point(0x11f, 0xac);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 0x90;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.labelCommName.AutoSize = true;
            this.labelCommName.Location = new Point(0x139, 0xb1);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x3a, 13);
            this.labelCommName.TabIndex = 0x92;
            this.labelCommName.Text = "Commodity";
            this.textCommodity.CharacterCasing = CharacterCasing.Upper;
            this.textCommodity.Location = new Point(0x6f, 0xad);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0xad, 20);
            this.textCommodity.TabIndex = 0;
            this.textCommodity.Leave += new EventHandler(this.textCommodity_Leave);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x13, 0xb1);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3a, 13);
            this.labelcommodity.TabIndex = 0x91;
            this.labelcommodity.Text = "Commodity";
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1b9, 0xf4);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x58, 0x20);
            this.button2.TabIndex = 4;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x15b, 0xf4);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x58, 0x21);
            this.button1.TabIndex = 3;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0xd6, 0x11);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 2;
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x1e7, 0x16);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 0x8a;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x15c, 0x16);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 0x89;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(60, 0x11);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 1;
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(15, 15);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x12b, 20);
            this.label5.TabIndex = 0x86;
            this.label5.Text = "Receiving Per Supplier Report (LA2)";
            this.textBox1.Location = new Point(0x4b, 0x100);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0x21, 20);
            this.textBox1.TabIndex = 0x9c;
            this.textBox1.Text = "30";
            this.textBox1.TextAlign = HorizontalAlignment.Right;
            this.textBox1.Leave += new EventHandler(this.textBox1_Leave);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x13, 260);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x37, 13);
            this.label3.TabIndex = 0x9b;
            this.label3.Text = "Max Row ";
            this.checkColly.AutoSize = true;
            this.checkColly.Location = new Point(0x16, 0xdf);
            this.checkColly.Name = "checkColly";
            this.checkColly.Size = new Size(0x4f, 0x11);
            this.checkColly.TabIndex = 0x9d;
            this.checkColly.Text = "Colly Copra";
            this.checkColly.UseVisualStyleBackColor = true;
            this.checkBunch.AutoSize = true;
            this.checkBunch.Location = new Point(0x16, 0xce);
            this.checkBunch.Name = "checkBunch";
            this.checkBunch.Size = new Size(0x39, 0x11);
            this.checkBunch.TabIndex = 0x9e;
            this.checkBunch.Text = "Bunch";
            this.checkBunch.UseVisualStyleBackColor = true;
            this.groupFType.Controls.Add(this.checkR);
            this.groupFType.Controls.Add(this.checkK);
            this.groupFType.Controls.Add(this.checkS);
            this.groupFType.Controls.Add(this.checkB);
            this.groupFType.Controls.Add(this.checkM);
            this.groupFType.Location = new Point(0x138, 0x37);
            this.groupFType.Name = "groupFType";
            this.groupFType.Size = new Size(220, 0x2d);
            this.groupFType.TabIndex = 0x9f;
            this.groupFType.TabStop = false;
            this.groupFType.Text = "Fruit Type";
            this.checkR.AutoSize = true;
            this.checkR.Checked = true;
            this.checkR.CheckState = CheckState.Checked;
            this.checkR.Location = new Point(0xb0, 20);
            this.checkR.Name = "checkR";
            this.checkR.Size = new Size(0x22, 0x11);
            this.checkR.TabIndex = 4;
            this.checkR.Text = "R";
            this.checkR.UseVisualStyleBackColor = true;
            this.checkK.AutoSize = true;
            this.checkK.Checked = true;
            this.checkK.CheckState = CheckState.Checked;
            this.checkK.Location = new Point(0x89, 20);
            this.checkK.Name = "checkK";
            this.checkK.Size = new Size(0x21, 0x11);
            this.checkK.TabIndex = 3;
            this.checkK.Text = "K";
            this.checkK.UseVisualStyleBackColor = true;
            this.checkS.AutoSize = true;
            this.checkS.Checked = true;
            this.checkS.CheckState = CheckState.Checked;
            this.checkS.Location = new Point(0x62, 20);
            this.checkS.Name = "checkS";
            this.checkS.Size = new Size(0x21, 0x11);
            this.checkS.TabIndex = 2;
            this.checkS.Text = "S";
            this.checkS.UseVisualStyleBackColor = true;
            this.checkB.AutoSize = true;
            this.checkB.Checked = true;
            this.checkB.CheckState = CheckState.Checked;
            this.checkB.Location = new Point(0x3b, 20);
            this.checkB.Name = "checkB";
            this.checkB.Size = new Size(0x21, 0x11);
            this.checkB.TabIndex = 1;
            this.checkB.Text = "B";
            this.checkB.UseVisualStyleBackColor = true;
            this.checkM.AutoSize = true;
            this.checkM.Checked = true;
            this.checkM.CheckState = CheckState.Checked;
            this.checkM.Location = new Point(0x12, 20);
            this.checkM.Name = "checkM";
            this.checkM.Size = new Size(0x23, 0x11);
            this.checkM.TabIndex = 0;
            this.checkM.Text = "M";
            this.checkM.UseVisualStyleBackColor = true;
            this.grType.Controls.Add(this.rboAll);
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x13, 0x37);
            this.grType.Name = "grType";
            this.grType.Size = new Size(0x11a, 0x2d);
            this.grType.TabIndex = 0xa6;
            this.grType.TabStop = false;
            this.grType.Text = "Report Type";
            this.rboAll.AutoSize = true;
            this.rboAll.Checked = true;
            this.rboAll.Location = new Point(0x12, 0x12);
            this.rboAll.Name = "rboAll";
            this.rboAll.Size = new Size(0x24, 0x11);
            this.rboAll.TabIndex = 0x7c;
            this.rboAll.TabStop = true;
            this.rboAll.Text = "All";
            this.rboAll.UseVisualStyleBackColor = true;
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(0xba, 0x12);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 0x11;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.rboGR.AutoSize = true;
            this.rboGR.Location = new Point(0x49, 0x12);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0x10;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.monthCalendar1);
            this.groupBox2.Controls.Add(this.monthCalendar2);
            this.groupBox2.Location = new Point(0x13, 0x6a);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0x15b, 0x30);
            this.groupBox2.TabIndex = 0xa7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Date";
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0x15, 0x15);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x21, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "From:";
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0xb8, 0x15);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x17, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "To:";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x232, 0x12f);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.grType);
            base.Controls.Add(this.groupFType);
            base.Controls.Add(this.checkBunch);
            base.Controls.Add(this.checkColly);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.label5);
            base.Name = "RepFFBLA2";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Report Per Supplier (LA2)";
            base.Load += new EventHandler(this.RepFFBLA2_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepFFBLA2_KeyPress);
            this.groupFType.ResumeLayout(false);
            this.groupFType.PerformLayout();
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void printReport()
        {
            HTML rep = new HTML();
            rep.File = rep.File + @"\" + WBUser.UserID + "_LA2.htm";
            rep.Title = "Receiving per Supplier Report (LA2)";
            rep.Open();
            rep.Write(rep.Style());
            rep.Write("<br><font size=5><b>RECEIVING PER SUPPLIER REPORT (LA2)</b></font><br>");
            string[] textArray1 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
            rep.Write(string.Concat(textArray1));
            string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
            rep.Write(string.Concat(textArray2));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            rep.Write("<br><br>");
            string str = Program.getFieldValue("wb_commodity", "Comm_Name", "comm_code", this.textCommodity.Text);
            rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
            rep.Write("<tr class=bd>");
            rep.Write("<td>Commodity</td>");
            string[] textArray3 = new string[] { "<td>: <b>", this.textCommodity.Text.Trim(), " - ", str, "</b></td>" };
            rep.Write(string.Concat(textArray3));
            rep.Write("</tr>");
            rep.Write("<tr class=bd>");
            rep.Write("<td>Selected Date</td>");
            string[] textArray4 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
            rep.Write(string.Concat(textArray4));
            rep.Write("</tr>");
            rep.Write("<tr class=bd>");
            rep.Write("<td>Report Date</td>");
            rep.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
            rep.Write("</tr>");
            rep.Write("</table>");
            rep.Write("<br/><br/><br/>");
            this.initHeader(rep);
            int num = 0;
            int num2 = 0;
            this.received = 0.0;
            this.treceived = 0.0;
            this.deduc = 0.0;
            this.tdeduc = 0.0;
            this.net = 0.0;
            this.tnet = 0.0;
            this.rSdhi = 0.0;
            this.nSdhi = 0.0;
            this.sreceived = 0.0;
            this.sdeduc = 0.0;
            this.snet = 0.0;
            this.srsdhi = 0.0;
            this.snsdhi = 0.0;
            this.No = 0;
            this.tbunch = 0.0;
            this.colly = 0.0;
            this.tcolly = 0.0;
            this.scolly = 0.0;
            this.bunch = 0.0;
            this.tbunch = 0.0;
            this.sbunch = 0.0;
            this.relation_code = this.tbl_Trans.DT.Rows[0]["relation_code"].ToString();
            this.maxRow = Convert.ToInt16(this.textBox1.Text);
            foreach (DataRow row in this.tbl_Trans.DT.Rows)
            {
                this.labelRecNo.Text = this.No.ToString() + " / " + this.jlhRecord.ToString();
                this.labelRecNo.Refresh();
                if (this.relation_code != row["Relation_code"].ToString())
                {
                    num++;
                    if ((num == 1) && (num2 > 0))
                    {
                        rep.Write("</table>");
                        rep.Write("<br>");
                        rep.Write("<br>");
                        this.initHeader(rep);
                    }
                    rep.Write("<tr class='bd'>");
                    rep.Write("<td nowrap align=right>" + $"{num:N0}" + "</td>");
                    rep.Write("<td nowrap>" + rep.strq(this.relation_code) + "</td>");
                    if (this.checkBunch.Checked)
                    {
                        rep.Write("<td nowrap align=right>" + $"{this.sbunch:N0}" + "</td>");
                    }
                    if (this.checkColly.Checked)
                    {
                        rep.Write("<td nowrap align=right>" + $"{this.scolly:N0}" + "</td>");
                    }
                    rep.Write("<td nowrap align=right>" + $"{this.sreceived:N0}" + "</td>");
                    rep.Write("<td nowrap align=right>" + $"{this.srsdhi:N0}" + "</td>");
                    rep.Write("<td nowrap align=right>" + $"{this.sdeduc:N0}" + "</td>");
                    rep.Write("<td nowrap align=right>" + $"{this.snet:N0}" + "</td>");
                    rep.Write("<td nowrap align=right>" + $"{this.snsdhi:N0}" + "</td>");
                    rep.Write("</tr>");
                    this.relation_code = row["Relation_code"].ToString();
                    this.sreceived = 0.0;
                    this.snet = 0.0;
                    this.sdeduc = 0.0;
                    this.srsdhi = 0.0;
                    this.snsdhi = 0.0;
                    this.colly = 0.0;
                    this.scolly = 0.0;
                    this.bunch = 0.0;
                    this.sbunch = 0.0;
                    if (num == this.maxRow)
                    {
                        num = 0;
                        num2++;
                    }
                }
                this.received = Program.StrToDouble(row["Received"].ToString(), 0);
                this.treceived += this.received;
                this.sreceived += this.received;
                this.rSdhi += this.received;
                this.srsdhi += this.received;
                if (this.checkColly.Checked)
                {
                    this.colly = Program.StrToDouble(row["JlhColly"].ToString(), 0);
                    this.tcolly += this.colly;
                    this.scolly += this.colly;
                }
                if (this.checkBunch.Checked)
                {
                    this.bunch = Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                    this.tbunch += this.bunch;
                    this.sbunch += this.bunch;
                }
                this.deduc = Program.StrToDouble(row["Deduction"].ToString(), 0);
                this.tdeduc += this.deduc;
                this.sdeduc += this.deduc;
                this.net = Program.StrToDouble(row["Netto"].ToString(), 0);
                this.tnet += this.net;
                this.snet += this.net;
                this.nSdhi += this.net;
                this.snsdhi += this.net;
                this.No++;
                if (num == (this.maxRow + 1))
                {
                    rep.Write("</table>");
                }
            }
            this.labelRecNo.Text = this.No.ToString() + " / " + this.jlhRecord.ToString();
            this.labelRecNo.Refresh();
            num++;
            if ((num == 1) && (num2 > 0))
            {
                rep.Write("</table>");
                rep.Write("<br>");
                rep.Write("<br>");
                this.initHeader(rep);
            }
            rep.Write("<tr class='bd'>");
            rep.Write("<td nowrap align=right>" + $"{num:N0}" + "</td>");
            rep.Write("<td nowrap>" + this.relation_code + "</td>");
            if (this.checkColly.Checked)
            {
                rep.Write("<td nowrap align=right>" + $"{this.scolly:N0}" + "</td>");
            }
            rep.Write("<td nowrap align=right>" + $"{this.sreceived:N0}" + "</td>");
            rep.Write("<td nowrap align=right>" + $"{this.srsdhi:N0}" + "</td>");
            rep.Write("<td nowrap align=right>" + $"{this.sdeduc:N0}" + "</td>");
            rep.Write("<td nowrap align=right>" + $"{this.snet:N0}" + "</td>");
            rep.Write("<td nowrap align=right>" + $"{this.snsdhi:N0}" + "</td>");
            rep.Write("</tr>");
            rep.Write("<tr class='bd'>");
            object[] objArray1 = new object[] { "<td colspan=", 2, " nowrap>", rep.strq(" "), "</td>" };
            rep.Write(string.Concat(objArray1));
            if (this.checkColly.Checked)
            {
                rep.Write("<td nowrap align=right><b>" + $"{this.tcolly:N0}" + "</b></td>");
            }
            rep.Write("<td nowrap align=right><b>" + $"{this.treceived:N0}" + "</b></td>");
            rep.Write("<td nowrap align=right><b>" + $"{this.rSdhi:N0}" + "</b></td>");
            rep.Write("<td nowrap align=right><b>" + $"{this.tdeduc:N0}" + "</b></td>");
            rep.Write("<td nowrap align=right><b>" + $"{this.tnet:N0}" + "</b></td>");
            rep.Write("<td nowrap align=right><b>" + $"{this.nSdhi:N0}" + "</b></td>");
            rep.Write("</tr>");
            rep.Write("</table>");
            rep.Write("<br>");
            rep.Write("<br>");
            rep.Write("<br>");
            rep.writeSign();
            rep.Close();
            ViewReport report = new ViewReport {
                webBrowser1 = { Url = new Uri("file:///" + rep.File) }
            };
            report.ShowDialog();
            rep.Dispose();
            report.Dispose();
        }

        private void RepFFBLA2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepFFBLA2_Load(object sender, EventArgs e)
        {
            this.groupFType.Visible = this.ffb;
            this.tbl_Comm = new WBTable();
            this.tbl_Comm.OpenTable("wb_commodity", "Select comm_code, comm_name from wb_commodity", WBData.conn);
            Program.AutoComp(this.tbl_Comm, "Comm_code", this.textCommodity);
            this.tbl_Supp = new WBTable();
            this.labelCommName.Text = "";
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBox1);
        }

        private void textCommodity_Leave(object sender, EventArgs e)
        {
            this.labelCommName.Text = "";
            if (this.textCommodity.Text.Trim() != "")
            {
                this.tbl_Comm.ReOpen();
                string[] aField = new string[] { "Comm_code" };
                string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                int recNo = this.tbl_Comm.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelCommName.Text = this.tbl_Comm.DT.Rows[recNo]["Comm_name"].ToString().Trim();
                }
                else
                {
                    this.buttonComm.PerformClick();
                    this.textCommodity.Focus();
                }
            }
        }
    }
}

