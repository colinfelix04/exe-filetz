﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class ViewReport : Form
    {
        private IContainer components = null;
        private Panel panel1;
        private Button button1;
        private Button button2;
        public WebBrowser webBrowser1;
        private ToolTip toolTip1;

        public ViewReport()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.webBrowser1.ShowPrintPreviewDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.webBrowser1.ShowSaveAsDialog();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.panel1 = new Panel();
            this.button2 = new Button();
            this.button1 = new Button();
            this.webBrowser1 = new WebBrowser();
            this.toolTip1 = new ToolTip(this.components);
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x115);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(700, 0x2f);
            this.panel1.TabIndex = 1;
            this.button2.Location = new Point(0x6d, 5);
            this.button2.Name = "button2";
            this.button2.Size = new Size(100, 30);
            this.button2.TabIndex = 1;
            this.button2.Text = "&Save As";
            this.toolTip1.SetToolTip(this.button2, "Save to File\r\nUse .XLS to save to Excel\r\nShortcut : Alt+S\r\n");
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new Size(100, 30);
            this.button1.TabIndex = 0;
            this.button1.Text = "&Print Preview";
            this.toolTip1.SetToolTip(this.button1, "Show Print Preview to Printer\r\nShortcut : Alt+P");
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.webBrowser1.Dock = DockStyle.Fill;
            this.webBrowser1.Location = new Point(0, 0);
            this.webBrowser1.MinimumSize = new Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new Size(700, 0x115);
            this.webBrowser1.TabIndex = 2;
            this.webBrowser1.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(this.webBrowser1_DocumentCompleted);
            this.toolTip1.AutoPopDelay = 0x1388;
            this.toolTip1.InitialDelay = 200;
            this.toolTip1.ReshowDelay = 100;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(700, 0x144);
            base.Controls.Add(this.webBrowser1);
            base.Controls.Add(this.panel1);
            base.Name = "ViewReport";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Report Preview";
            base.WindowState = FormWindowState.Maximized;
            base.Load += new EventHandler(this.ViewReport_Load);
            base.KeyPress += new KeyPressEventHandler(this.ViewReport_KeyPress);
            this.panel1.ResumeLayout(false);
            base.ResumeLayout(false);
        }

        private void ViewReport_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\x001b') && (MessageBox.Show(Resource.Mes_602, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes))
            {
                base.Close();
            }
        }

        private void ViewReport_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.button1.Text = Resource.Menu_Print_Preview;
            this.button2.Text = Resource.Menu_Save_As;
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
        }
    }
}

