﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Threading;
    using System.Windows.Forms;

    public class FormMill : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private DataTable updTable = new DataTable();
        private DataTable retTable = new DataTable();
        private string[] zwbResult = new string[3];
        private string[] zwbRow = new string[0x10];
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private DataGridView dataGridView1;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem printToolStripMenuItem;
        public ToolStripMenuItem closeToolStripMenuItem;
        public TextBox TextFind;
        public Button buttonFind;
        public Panel panel1;
        private ToolStripMenuItem chooseStripMenuItem1;
        private ToolStripMenuItem zWBToolStripMenuItem;
        private ToolStripMenuItem synchronizeToolStripMenuItem;
        private ToolStripMenuItem synchronizeAllToolStripMenuItem;
        private ProgressBar progressBar1;

        public FormMill()
        {
            this.InitializeComponent();
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            WBSetting.OpenSetting();
            this.zWBToolStripMenuItem.Visible = WBSetting.zwb == "Y";
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormMillEntry entry = new FormMillEntry {
                    pMode = "ADD",
                    zTable = this.ztable,
                    Text = "Add New Record of Mill List",
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                    string[] aField = new string[] { "Mill_Code" };
                    string[] aFind = new string[] { entry.textBox1.Text };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                entry.Dispose();
                this.ztable.UnLock();
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void chooseStripMenuItem1_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseStripMenuItem1.PerformClick();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.chooseStripMenuItem1.PerformClick();
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
            {
                this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                WBTable table = new WBTable();
                table.OpenTable("wb_transaction", "Select ref From wb_transaction where " + WBData.CompanyLocation(" and ( Mill_Code='" + this.ztable.DT.Rows[this.nCurrRow]["Mill_Code"].ToString() + "')"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    if (MessageBox.Show(this.ztable.DT.Rows[this.nCurrRow]["Mill_Code"].ToString() + " - " + this.ztable.DT.Rows[this.nCurrRow]["Mill_Name"].ToString() + ".\n\n Are you sure to deleted this record ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = "Mill Code" },
                            textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Mill_Code"].ToString() },
                            Text = "DELETE REASON",
                            label2 = { Text = "Delete Reason : " }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                            this.ztable.ReOpen();
                            this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                            this.ztable.DT.Rows[this.nCurrRow].Delete();
                            this.ztable.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                            Program.updateLogHeader("wb_mill", this.logKey, logField, logValue);
                            this.ztable.ReOpen();
                            this.ztable.AfterEdit("DELETE");
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                else
                {
                    string[] textArray1 = new string[] { "This record cannot be deleted, still used in the transaction or masterdata.\n\n- Transaction   : ", table.DT.Rows.Count.ToString(), " ", Resource.Mes_047B, "\n" };
                    MessageBox.Show(string.Concat(textArray1), "E R R O R", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                table.Dispose();
                this.ztable.UnLock();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                FormMillEntry entry = new FormMillEntry {
                    pMode = "EDIT",
                    zTable = this.ztable,
                    Text = "Edit Record of Mill List",
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                    string[] aField = new string[] { "Mill_Code" };
                    string[] aFind = new string[] { entry.textBox1.Text };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                entry.Dispose();
                this.ztable.UnLock();
            }
        }

        private void FormMill_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormMill_Load(object sender, EventArgs e)
        {
            this.translate();
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 0x10)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    this.retTable.Columns.Add(column);
                    column.Dispose();
                    string str = " Coy,Location_Code,Mill_Code,Mill_Name,Address,City,SAP_Code,Create_By,Create_Date,Change_By,Change_Date,Delete_By,Delete_Date,Deleted,zwb,token,uniq, completed";
                    if (this.pFilter != "")
                    {
                        this.ztable.OpenTable("wb_Mill", "SELECT " + str + " FROM wb_Mill where " + WBData.CompanyLocation(this.pFilter), WBData.conn);
                    }
                    else
                    {
                        this.ztable.OpenTable("wb_Mill", "SELECT " + str + " FROM wb_Mill", WBData.conn);
                    }
                    this.dataGridView1.DataSource = this.ztable.DT;
                    this.dataGridView1.Sort(this.dataGridView1.Columns["Mill_Code"], ListSortDirection.Ascending);
                    this.dataGridView1.Columns["Coy"].Visible = false;
                    this.dataGridView1.Columns["Location_Code"].Visible = false;
                    this.dataGridView1.Columns["Delete_By"].Visible = false;
                    this.dataGridView1.Columns["Delete_Date"].Visible = false;
                    this.dataGridView1.Columns["uniq"].Visible = false;
                    this.dataGridView1.Columns["token"].Visible = true;
                    this.dataGridView1.Columns["completed"].Visible = true;
                    this.dataGridView1.Columns["deleted"].Visible = false;
                    this.dataGridView1.Columns["Mill_Code"].HeaderText = "Mill Code";
                    this.dataGridView1.Columns["Mill_Name"].HeaderText = "Mill_Name";
                    this.dataGridView1.Columns["Address"].HeaderText = "Address or Location of Mill";
                    this.dataGridView1.Columns["City"].HeaderText = "City";
                    this.dataGridView1.Columns["SAP_Code"].HeaderText = "Code of SAP";
                    base.KeyPreview = true;
                    if (!WBUser.CheckTrustee("MD_Mill", "A"))
                    {
                        this.addNewRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_Mill", "E"))
                    {
                        this.editRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_Mill", "D"))
                    {
                        this.deleteToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_Mill", "P"))
                    {
                        this.printToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_SYNCH", "A"))
                    {
                        this.zWBToolStripMenuItem.Enabled = false;
                    }
                    if ((this.pMode != "") && (this.pFind.Trim() != ""))
                    {
                        this.TextFind.Text = this.pFind;
                        this.buttonFind.PerformClick();
                    }
                    this.chooseStripMenuItem1.Visible = this.pMode != "";
                    this.zWBToolStripMenuItem.Text = WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB";
                    return;
                }
                column = new DataColumn();
                this.updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        private void InitializeComponent()
        {
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.printToolStripMenuItem = new ToolStripMenuItem();
            this.zWBToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeAllToolStripMenuItem = new ToolStripMenuItem();
            this.chooseStripMenuItem1 = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x305, 0x176);
            this.dataGridView1.TabIndex = 0x10;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseStripMenuItem1, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x305, 0x18);
            this.menuStrip1.TabIndex = 0x12;
            this.menuStrip1.Text = "menuStrip1";
            this.activitiesToolStripMenuItem.Checked = true;
            this.activitiesToolStripMenuItem.CheckState = CheckState.Checked;
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem, this.printToolStripMenuItem, this.zWBToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.printToolStripMenuItem.Text = "Print";
            ToolStripItem[] itemArray3 = new ToolStripItem[] { this.synchronizeToolStripMenuItem, this.synchronizeAllToolStripMenuItem };
            this.zWBToolStripMenuItem.DropDownItems.AddRange(itemArray3);
            this.zWBToolStripMenuItem.Name = "zWBToolStripMenuItem";
            this.zWBToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.zWBToolStripMenuItem.Text = "ZWB";
            this.synchronizeToolStripMenuItem.Name = "synchronizeToolStripMenuItem";
            this.synchronizeToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeToolStripMenuItem.Text = "Synchronize";
            this.synchronizeToolStripMenuItem.Click += new EventHandler(this.synchronizeToolStripMenuItem_Click);
            this.synchronizeAllToolStripMenuItem.Name = "synchronizeAllToolStripMenuItem";
            this.synchronizeAllToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeAllToolStripMenuItem.Text = "Synchronize All";
            this.synchronizeAllToolStripMenuItem.Click += new EventHandler(this.synchronizeAllToolStripMenuItem_Click);
            this.chooseStripMenuItem1.Name = "chooseStripMenuItem1";
            this.chooseStripMenuItem1.Size = new Size(0x3b, 20);
            this.chooseStripMenuItem1.Text = "Choose";
            this.chooseStripMenuItem1.Click += new EventHandler(this.chooseStripMenuItem1_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x18e);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x305, 0x21);
            this.panel1.TabIndex = 0x11;
            this.progressBar1.Location = new Point(0x25b, 9);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xa7, 0x11);
            this.progressBar1.TabIndex = 11;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x305, 0x1af);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.Name = "FormMill";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of Mill";
            base.Load += new EventHandler(this.FormMill_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormMill_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void synchronizeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int count = this.dataGridView1.Rows.Count;
            this.updTable.Rows.Clear();
            this.retTable.Rows.Clear();
            if (MessageBox.Show("Synchronize ALL to " + this.sapIDSYS + " ?", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.progressBar1.Visible = true;
                this.progressBar1.Maximum = count;
                if (WBSAP.connect())
                {
                    WBSAP.setImportReturn();
                    WBSAP.setReturnTable();
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_Mill");
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= count)
                        {
                            WBSAP.sendTable(this.updTable);
                            WBSAP.sendZWB();
                            WBSAP.getAllResult(this.updTable, this.retTable, "KKEBUN");
                            WBSAP.showReturn();
                            this.progressBar1.Visible = false;
                            break;
                        }
                        this.progressBar1.Value = num2;
                        Thread.Sleep(10);
                        string str = this.dataGridView1.Rows[num2].Cells["uniq"].Value.ToString().Trim();
                        this.zwbRow[0] = this.dataGridView1.Rows[num2].Cells["Mill_code"].Value.ToString().Trim();
                        this.zwbRow[1] = WBSetting.CoySAP;
                        this.zwbRow[2] = this.dataGridView1.Rows[num2].Cells["Mill_name"].Value.ToString().Trim();
                        this.zwbRow[3] = this.dataGridView1.Rows[num2].Cells["Address"].Value.ToString().Trim();
                        this.zwbRow[4] = "";
                        this.zwbRow[5] = "";
                        this.zwbRow[6] = this.dataGridView1.Rows[num2].Cells["City"].Value.ToString().Trim();
                        this.zwbRow[7] = "";
                        this.zwbRow[8] = "";
                        this.zwbRow[9] = "";
                        this.zwbRow[10] = "";
                        this.zwbRow[11] = "";
                        this.zwbRow[12] = "";
                        this.zwbRow[13] = "";
                        this.zwbRow[14] = "";
                        this.zwbRow[15] = "";
                        this.updTable.Rows.Add(this.zwbRow);
                        num2++;
                    }
                }
            }
        }

        private void synchronizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str2 = this.dataGridView1.CurrentRow.Cells["Mill_Code"].Value.ToString().Trim();
            string str = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString().Trim();
            string[] textArray1 = new string[] { "Synchronize ", str2, " to ", this.sapIDSYS, " ?" };
            if (MessageBox.Show(string.Concat(textArray1), "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.zwbRow[0] = str2;
                this.zwbRow[1] = WBSetting.CoySAP;
                this.zwbRow[2] = this.dataGridView1.CurrentRow.Cells["Mill_name"].Value.ToString().Trim();
                this.zwbRow[3] = this.dataGridView1.CurrentRow.Cells["Address"].Value.ToString().Trim();
                this.zwbRow[4] = "";
                this.zwbRow[5] = "";
                this.zwbRow[6] = this.dataGridView1.CurrentRow.Cells["City"].Value.ToString().Trim();
                this.zwbRow[7] = "";
                this.zwbRow[8] = "";
                this.zwbRow[9] = "";
                this.zwbRow[10] = "";
                this.zwbRow[11] = "";
                this.zwbRow[12] = "";
                this.zwbRow[13] = "";
                this.zwbRow[14] = "";
                this.zwbRow[15] = "";
                if (WBSAP.connect())
                {
                    try
                    {
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_Mill");
                        WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                        WBSAP.appendTable(this.zwbRow);
                        WBSAP.sendZWB();
                        this.zwbResult = WBSAP.getResult();
                        string[] aField = new string[] { "uniq" };
                        string[] aFind = new string[] { str };
                        this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
                        this.ztable.DR = this.ztable.DT.Rows[this.nCurrRow];
                        this.logKey = this.ztable.DR["uniq"].ToString();
                        this.ztable.DR.BeginEdit();
                        this.ztable.DR["zwb"] = (this.zwbResult[1].ToUpper().Trim() == "Y") ? "Y" : "N";
                        this.ztable.DR.EndEdit();
                        this.ztable.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + this.sapIDSYS };
                        Program.updateLogHeader("wb_mill", this.logKey, logField, logValue);
                        if (this.zwbResult[1].ToUpper().Trim() != "Y")
                        {
                            MessageBox.Show("Failed Sync to " + this.sapIDSYS + ", " + this.zwbResult[2], "N O T I C E");
                        }
                        else
                        {
                            MessageBox.Show("Success Sync to " + this.sapIDSYS + " ", "N O T I C E");
                        }
                    }
                    catch (RfcInvalidParameterException exception)
                    {
                        MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    catch (RfcCommunicationException exception2)
                    {
                        if (WBUser.UserLevel == "1")
                        {
                            MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                    catch (RfcBaseException exception3)
                    {
                        if (WBUser.UserLevel == "1")
                        {
                            MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                    catch (Exception exception4)
                    {
                        MessageBox.Show("Error " + exception4.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseStripMenuItem1.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
        }
    }
}

