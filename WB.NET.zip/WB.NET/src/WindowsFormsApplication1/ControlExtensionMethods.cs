﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Runtime.CompilerServices;
    using System.Threading;
    using System.Windows.Forms;

    public static class ControlExtensionMethods
    {
        public static IEnumerable<Control> GetOffsprings(this Control @this)
        {
            IEnumerator<Control> <>s__3;
            Control current;
            IEnumerator enumerator = @this.Controls.GetEnumerator();
            goto TR_0005;
        Label_PostSwitchInIterator:;
            if (<>s__3.MoveNext())
            {
                Control current = <>s__3.Current;
                yield return current;
                current = null;
                goto Label_PostSwitchInIterator;
            }
            else
            {
                <>s__3 = null;
                current = null;
            }
        TR_0005:
            if (!enumerator.MoveNext())
            {
                enumerator = null;
                yield break;
            }
            else
            {
                current = (Control) enumerator.Current;
                yield return current;
                yield break;
            }
        }

    }
}

