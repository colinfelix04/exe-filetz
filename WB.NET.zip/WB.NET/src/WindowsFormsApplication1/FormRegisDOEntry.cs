﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using SAP.Middleware.Connector;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Diagnostics;
    using System.Drawing;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormRegisDOEntry : Form
    {
        public string gatepassNumber = "";
        public string oldComm;
        public string remark;
        public string CommType = "";
        private string IO = "";
        private string CommUOM = "";
        private string using_gunny;
        private string[] hasil = new string[3];
        public bool changeComm = false;
        public bool lSTO1DO = false;
        public bool expiredSPB = false;
        public bool scaneSPB;
        public string ISCC = "N";
        public string chkqty = "N";
        public string doEntryMode;
        public string pMode;
        public string pComm;
        public string pTransType;
        public string ptextNet;
        public string ptextEstate;
        public string oldDO_No;
        public string WX;
        public string RefNo;
        public string DoConvUnit;
        public string DoConv;
        public string DoConvTol;
        public string xEstQty;
        public string date1;
        public int dgvDOCurrRow;
        public bool saved = false;
        public bool ChangeDOCont;
        public bool IsReturn;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private int DoTotalMulesoft;
        private int DrTotalMulesoft;
        private int DoTotalSAP;
        public DataGridView dgvTrans;
        public DataGridView dgvCont;
        public DataGridView dgvDoCont;
        public DataGridView dgvDO;
        public DataGridView dgvBatch;
        public WBTable tblTransDO;
        public WBTable tblDOContainer;
        public WBTable tblStorage;
        public WBTable zCust = new WBTable();
        public WBTable tblDO = new WBTable();
        public WBTable tblTType = new WBTable();
        public WBTable tblComm = new WBTable();
        public WBTable tblVesselMap = new WBTable();
        public string refDate = "";
        public string delivery_note = "";
        public double totalNet = 0.0;
        public double totalNetEstate = 0.0;
        public double totalVariance = 0.0;
        public double sisaNet = 0.0;
        public double sisaEstateNet = 0.0;
        public double qty;
        public double variance;
        public double DONet = 0.0;
        public double DOEstateNet = 0.0;
        public double OSNetwoTol = 0.0;
        public double OSNetTol;
        public string party = "0";
        public string tolerance = "0";
        public string qualityInfo = "";
        public string tolling = "";
        public string transType = "";
        public string bulkPack = "";
        public string deductedBy = "0";
        public string isTrade2 = "";
        public float netto_weight = 0f;
        public string dIncoterm = "";
        private WBTable t_do = new WBTable();
        private WBTable t_do_sap = new WBTable();
        public int num_of_do = 0;
        public int num_of_dr = 0;
        public int num_of_dotrx = 0;
        public string[,] map = new string[0x3e7, 0x18];
        public string uniq_contract = "";
        public string truck_number = "";
        public string transporter = "";
        public string driver_name = "";
        public string license_number = "";
        public string sto_no_item = "";
        public string so_item = "";
        public string isDOBesar = "";
        public string indic = "";
        public bool auto_generate_dummy_contract = false;
        public bool nopw;
        private bool need_choose_do = false;
        public bool active_zdotrx;
        public bool active_require_do;
        public static string currInternalNumber = "";
        public bool readoptInternalNumber = false;
        public bool changeLoadingNote = false;
        public bool active_lock_tdt = false;
        public DataGridView retTable_DSAP_DO = new DataGridView();
        public DataGridView retTable_DSAP_DR = new DataGridView();
        public DataGridView retTable_DSAP_DOTRX = new DataGridView();
        private WBCondition wCond;
        public string so_no = "";
        public string sto_no = "";
        private string mUnit;
        private int count = 0;
        private IContainer components = null;
        private Label labelDO;
        private Button buttonDO;
        private Label labelContractNo;
        private Label labelRelation;
        public Button buttonSave;
        private Button button2;
        public TextBox textDO;
        public TextBox textCont;
        public TextBox textRCode;
        public TextBox textComm;
        private Label labelComm;
        private Label labelDOQtyLeft;
        public TextBox textEstate;
        private Label labelEstate;
        public TextBox textPI_No;
        private Label labelPI_No;
        private Label labelTransporter;
        public TextBox textTransporter;
        public Label labelKB;
        public TextBox textOthNet;
        private Label labelOtherNat;
        private Label label13;
        private Label labelStorageName;
        private Button buttonStorage;
        private Label labelStorage;
        public TextBox textStorage;
        private Label labelZWB;
        private ToolTip toolTip1;
        public Label labelQuantity;
        public Label labelQtyLeft;
        private Button but_sh_do_sap;
        public TextBox text_do_sap;
        private Label label2;
        private GroupBox gb_do_sap;
        private Label label19;
        private Label label18;
        private Label label17;
        private Label label20;
        private Label label21;
        public TextBox text_do_sap_item;
        private Button buttonPISI;
        private Label label22;
        private Label label23;
        private Label lblINitem;
        public TextBox txtInNumItem;
        public TextBox txtInternalNum;
        private Label lblInternalNum;
        public TextBox text_do_sap_unit;
        public TextBox text_do_sap_qty;
        public TextBox text_do_sap_qty_kg;
        public TextBox textBoxBaseUOM;
        public TextBox textBoxQtyBaseUOM;
        private Label lbl_do_besar;
        private Label lbl_comm_name;
        public TextBox textTransCode;
        private Label labelTransCode;
        public TextBox textRName;
        private StatusStrip statusStrip1;
        private Label label6;
        public TextBox textFactNet;
        private Label labelFactoryNet;
        private Panel panelSTO1DO;
        public TextBox text1DOSTO;
        private Label label15;
        public TextBox text1STO;
        private Label label14;
        private Label label16;
        private ShapeContainer shapeContainer2;
        public Label label1STO1DO;
        public Label labelLoadingUOM;
        public TextBox textBoxLoadingQty;
        private Label labelLoadingQty;
        private Button btnFillContainer;
        public TextBox labelTransName;
        public TextBox textSOItem_detail;
        private Label labelSOItem_detail;
        public TextBox txtBox_QQ;
        private Label lbl_QQ;
        private Label labelDN;
        public TextBox txtDeliveryNote;
        private Label label_loading_qty_opw_uom;
        public TextBox text_opw_loading_qty;
        private Label label_loading_qty_opw;

        public FormRegisDOEntry()
        {
            this.InitializeComponent();
        }

        private void adoptDataIDSYS()
        {
            if (this.try_connect_IDSYS())
            {
                try
                {
                    if ((this.txtInternalNum.Text == "") && (this.textDO.Text == ""))
                    {
                        MessageBox.Show("Please Fill in WB DO or DO " + this.sapIDSYS + " No.", "WARNING...");
                        this.need_choose_do = true;
                    }
                    else if (!((!this.text_do_sap.ReadOnly && this.text_do_sap.Visible) && this.gb_do_sap.Visible))
                    {
                        if (WBSetting.adopt_zdotrx)
                        {
                            if (this.txtInternalNum.Text != "")
                            {
                                if (this.get_data_from_zdotrx())
                                {
                                    this.filldopartial(false, true);
                                }
                            }
                            else if (this.active_zdotrx)
                            {
                                MessageBox.Show("Please Fill Loading Note No.", "WARNING...");
                                this.need_choose_do = true;
                            }
                            else if (this.active_require_do && this.get_data_from_sap())
                            {
                                this.filldopartial(true, false);
                            }
                        }
                        else if (this.get_data_from_IDSYS())
                        {
                            FormDoSAP osap = new FormDoSAP {
                                map = this.map,
                                RefNo = this.RefNo,
                                num_of_do = this.DoTotalSAP,
                                mode = "CHOOSE",
                                flagRegistration = true,
                                oldDOSAP = this.text_do_sap.Text,
                                oldInternalNo = this.txtInternalNum.Text,
                                gatepassNo = this.gatepassNumber
                            };
                            osap.ShowDialog();
                            if (osap.do_sap == "")
                            {
                                if (osap.internal_number != "")
                                {
                                    this.text_do_sap.Text = "";
                                    this.text_do_sap_item.Text = "";
                                    this.txtInternalNum.Text = osap.internal_number;
                                    this.txtInNumItem.Text = osap.internal_number_item;
                                    this.text_do_sap_qty.Text = osap.qty;
                                    this.text_do_sap_unit.Text = osap.unit;
                                    this.text_do_sap_qty_kg.Text = osap.qty_kg;
                                    this.textBoxQtyBaseUOM.Text = osap.qty_base_uom;
                                    this.textBoxBaseUOM.Text = osap.base_uom;
                                    this.textSOItem_detail.Text = osap.so_item_detail;
                                }
                            }
                            else
                            {
                                this.txtInternalNum.Text = osap.do_sap;
                                this.txtInNumItem.Text = osap.do_sap_item;
                                this.text_do_sap_qty.Text = osap.qty;
                                this.text_do_sap_unit.Text = osap.unit;
                                if ((this.bulkPack != "P") || (this.labelLoadingUOM.Text == "KG"))
                                {
                                    this.text_do_sap_qty_kg.Text = osap.qty_kg;
                                }
                                else
                                {
                                    float num = 0f;
                                    num = float.Parse(osap.qty_base_uom);
                                    if (this.so_item != "*")
                                    {
                                        this.text_do_sap_qty_kg.Text = (num * this.netto_weight).ToString();
                                    }
                                    else
                                    {
                                        WBTable table = new WBTable();
                                        WBTable table2 = new WBTable();
                                        string[] textArray1 = new string[] { " AND do_no = '", this.textDO.Text.Trim(), "' and so_item = '", Program.StrToDouble(osap.so_item_detail, 0).ToString(), "'" };
                                        table.OpenTable("wb_contract_sapinformation", "SELECT comm_code FROM wb_contract_sapinformation WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                                        table2.OpenTable("wb_commodity", "SELECT netto_weight FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + table.DT.Rows[0]["comm_code"].ToString() + "'"), WBData.conn);
                                        this.text_do_sap_qty_kg.Text = (num * float.Parse((table2.DT.Rows[0]["netto_weight"].ToString() == "") ? "0" : table2.DT.Rows[0]["netto_weight"].ToString())).ToString();
                                        table.Dispose();
                                        table2.Dispose();
                                    }
                                }
                                this.textBoxQtyBaseUOM.Text = osap.qty_base_uom;
                                this.textBoxBaseUOM.Text = osap.base_uom;
                                this.indic = osap.indic;
                                this.lbl_do_besar.Visible = osap.indic == "X";
                                this.textSOItem_detail.Text = osap.so_item_detail;
                            }
                        }
                    }
                }
                catch (Exception exception)
                {
                    MessageBox.Show("Error from IDSYS ! \n" + exception.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
        }

        private void btnFillContainer_Click(object sender, EventArgs e)
        {
            FormTransDOContainer container = new FormTransDOContainer {
                zTable = this.tblDOContainer,
                qty = Convert.ToDouble(this.textFactNet.Text),
                dgvContainer = this.dgvCont,
                dgvDOCont = this.dgvDoCont,
                Do_No = this.textDO.Text,
                RefNo = this.RefNo,
                DoConv = this.DoConv,
                DoConvUnit = this.DoConvUnit,
                gatepass_number = this.gatepassNumber
            };
            container.ShowDialog();
            if (!container.pSave)
            {
                this.ChangeDOCont = false;
            }
            else
            {
                this.dgvDoCont = container.dgvDoContAll;
                this.ChangeDOCont = true;
            }
            container.Dispose();
        }

        private void but_sh_do_sap_Click(object sender, EventArgs e)
        {
            WBSetting.OpenSetting();
            if (WBSetting.IntegrationSAP != "Y")
            {
                if (!WBSetting.integrationIDSYS)
                {
                    if (WBSetting.adopt_zdotrx)
                    {
                        if (this.txtInternalNum.Text == "")
                        {
                            if (this.active_zdotrx)
                            {
                                MessageBox.Show("Please Fill Loading Note No.", "WARNING...");
                                this.need_choose_do = true;
                                return;
                            }
                        }
                        else if (this.get_data_wb_zdo(this.txtInternalNum.Text))
                        {
                            this.filldopartial(false, true);
                        }
                    }
                }
                else
                {
                    this.adoptDataIDSYS();
                }
            }
            else if (!WBSetting.activeMulesoftIntegration)
            {
                if (this.try_connect())
                {
                    if ((this.txtInternalNum.Text != "") || (this.textDO.Text != ""))
                    {
                        if (!((!this.text_do_sap.ReadOnly && this.text_do_sap.Visible) && this.gb_do_sap.Visible))
                        {
                            if (!WBSetting.adopt_zdotrx)
                            {
                                if (this.get_data_from_sap())
                                {
                                    this.filldopartial(true, false);
                                }
                            }
                            else if (this.txtInternalNum.Text == "")
                            {
                                if (!this.active_zdotrx)
                                {
                                    if (this.active_require_do && this.get_data_from_sap())
                                    {
                                        this.filldopartial(true, false);
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Please Fill Loading Note No.", "WARNING...");
                                    this.need_choose_do = true;
                                    return;
                                }
                            }
                            else if (this.get_data_from_zdotrx())
                            {
                                this.filldopartial(false, true);
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Fill in WB DO or DO " + this.sapIDSYS + " No.", "WARNING...");
                        this.need_choose_do = true;
                        return;
                    }
                }
            }
            else if (!this.get_data_from_mulesoft())
            {
                return;
            }
            else
            {
                FormDoSAP osap = new FormDoSAP {
                    map = this.map,
                    RefNo = this.RefNo,
                    num_of_do = this.DoTotalMulesoft,
                    num_of_dr = this.DrTotalMulesoft,
                    mode = "CHOOSE",
                    flagRegistration = true,
                    oldDOSAP = this.text_do_sap.Text,
                    oldInternalNo = this.txtInternalNum.Text,
                    gatepassNo = this.gatepassNumber
                };
                osap.ShowDialog();
                if (osap.do_sap == "")
                {
                    if (osap.internal_number != "")
                    {
                        this.text_do_sap.Text = "";
                        this.text_do_sap_item.Text = "";
                        this.txtInternalNum.Text = osap.internal_number;
                        this.txtInNumItem.Text = osap.internal_number_item;
                        this.text_do_sap_qty.Text = osap.qty;
                        this.text_do_sap_unit.Text = osap.unit;
                        this.text_do_sap_qty_kg.Text = osap.qty_kg;
                        this.textBoxQtyBaseUOM.Text = osap.qty_base_uom;
                        this.textBoxBaseUOM.Text = osap.base_uom;
                        this.txtBox_QQ.Text = osap.customer_qq;
                        this.textSOItem_detail.Text = osap.so_item_detail;
                    }
                }
                else
                {
                    this.txtInternalNum.Text = "";
                    this.txtInNumItem.Text = "";
                    this.text_do_sap.Text = osap.do_sap;
                    this.text_do_sap_item.Text = osap.do_sap_item;
                    this.text_do_sap_qty.Text = osap.qty;
                    this.text_do_sap_unit.Text = osap.unit;
                    if ((this.bulkPack != "P") || (this.labelLoadingUOM.Text == "KG"))
                    {
                        this.text_do_sap_qty_kg.Text = osap.qty_kg;
                    }
                    else
                    {
                        float num = 0f;
                        num = float.Parse(osap.qty_base_uom);
                        if ((this.so_item != "*") && (this.so_item != ""))
                        {
                            this.text_do_sap_qty_kg.Text = (num * this.netto_weight).ToString();
                        }
                        else
                        {
                            WBTable table = new WBTable();
                            WBTable table2 = new WBTable();
                            string[] textArray1 = new string[] { " AND do_no = '", this.textDO.Text.Trim(), "' and so_item = '", Program.StrToDouble(osap.so_item_detail, 0).ToString(), "'" };
                            table.OpenTable("wb_contract_sapinformation", "SELECT comm_code FROM wb_contract_sapinformation WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                            table2.OpenTable("wb_commodity", "SELECT netto_weight FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + table.DT.Rows[0]["comm_code"].ToString() + "'"), WBData.conn);
                            this.text_do_sap_qty_kg.Text = (num * float.Parse((table2.DT.Rows[0]["netto_weight"].ToString() == "") ? "0" : table2.DT.Rows[0]["netto_weight"].ToString())).ToString();
                            table.Dispose();
                            table2.Dispose();
                        }
                    }
                    this.textBoxQtyBaseUOM.Text = osap.qty_base_uom;
                    this.textBoxBaseUOM.Text = osap.base_uom;
                    this.indic = osap.indic;
                    this.lbl_do_besar.Visible = osap.indic == "X";
                    this.textSOItem_detail.Text = osap.so_item_detail;
                }
            }
            if (WBSetting.integrationIDSYS && this.text_do_sap.ReadOnly)
            {
                this.textSOItem_detail.ReadOnly = true;
                this.text_do_sap.ReadOnly = true;
                this.txtInternalNum.ReadOnly = true;
                this.text_do_sap_item.ReadOnly = true;
                this.txtInNumItem.ReadOnly = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonDO_Click(object sender, EventArgs e)
        {
            this.chooseDoPISI();
            this.textDO.Focus();
        }

        private void buttonPISI_Click(object sender, EventArgs e)
        {
            this.chooseDoPISI();
            this.textDO.Focus();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (this.textDO.Text.Trim() != "")
            {
                if (!this.need_choose_do)
                {
                    string[] aField = new string[] { "Do_No", "PI_No" };
                    string[] aFind = new string[] { this.textDO.Text.Trim(), this.textPI_No.Text.Trim() };
                    if (!ReferenceEquals(this.tblDO.GetData(aField, aFind), null))
                    {
                        if (WBSetting.Field("GM") == "Y")
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(" AND ( Token_Code ='NOT_ADOPTSAP' and completed = 'N' and key_1 = '" + this.textDO.Text + "' )"), WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                MessageBox.Show("This DO hasn't been approved to not adopt from " + this.sapIDSYS, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                return;
                            }
                        }
                        string[] textArray3 = new string[] { "Do_No" };
                        string[] textArray4 = new string[] { this.textDO.Text.Trim() };
                        DataRow data = this.tblDO.GetData(textArray3, textArray4);
                        if ((data != null) & !this.IsReturn)
                        {
                            this.uniq_contract = data["uniq"].ToString();
                            this.so_no = data["so"].ToString();
                            this.sto_no = data["sto"].ToString();
                            string str = Program.getFieldValue("wb_transaction_type", "trx_require_internal_no", "transaction_code", data["transaction_code"].ToString());
                            this.tblComm.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.textComm.Text + "'"), WBData.conn);
                            this.wCond = new WBCondition();
                            DataRow[] dgRows = new DataRow[] { data, this.tblComm.DT.Rows[0] };
                            this.wCond.fillParameter("ACTIVE_ADOPT_ZDOTRX", dgRows);
                            if (this.wCond.getResult())
                            {
                                this.gb_do_sap.Visible = true;
                                this.txtInternalNum.Enabled = true;
                                this.txtBox_QQ.Visible = true;
                            }
                            else if (((str == "Y") && (this.CommType == "S")) && (this.isTrade2 == "T"))
                            {
                                this.gb_do_sap.Visible = true;
                                this.txtBox_QQ.Visible = true;
                            }
                            else
                            {
                                this.gb_do_sap.Visible = false;
                                this.txtBox_QQ.Visible = false;
                            }
                            this.wCond.Dispose();
                            this.wCond = new WBCondition();
                            this.tblComm.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.textComm.Text + "'"), WBData.conn);
                            DataRow[] rowArray2 = new DataRow[] { data, this.tblComm.DT.Rows[0] };
                            this.wCond.fillParameter("LOCK_DATA_TDT", rowArray2);
                            if (this.wCond.getResult())
                            {
                                this.active_lock_tdt = true;
                            }
                            this.tblComm.Dispose();
                            this.wCond.Dispose();
                        }
                        if (this.gb_do_sap.Visible)
                        {
                            if (!this.active_zdotrx)
                            {
                                if (((this.text_do_sap.Text.Trim() == "") || (this.text_do_sap_item.Text.Trim() == "")) && ((this.txtInternalNum.Text.Trim() == "") || (this.txtInNumItem.Text.Trim() == "")))
                                {
                                    MessageBox.Show("Please Fill DO " + this.sapIDSYS + " / Internal Number", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    this.but_sh_do_sap.Focus();
                                    return;
                                }
                            }
                            else if (this.txtInternalNum.Text.Trim() == "")
                            {
                                MessageBox.Show("Please Fill Loading Note ", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.but_sh_do_sap.Focus();
                                return;
                            }
                            if ((this.textSOItem_detail.Text.Trim() != "") || WBSetting.integrationIDSYS)
                            {
                                if ((this.text_do_sap.Text.Trim() == "") || ((this.text_do_sap_item.Text.Trim().Length >= 2) || WBSetting.integrationIDSYS))
                                {
                                    if (((this.txtInternalNum.Text.Trim() == "") || WBSetting.integrationIDSYS) || (this.txtInNumItem.Text.Trim().Length >= 2))
                                    {
                                        if (((this.textSOItem_detail.Text.Trim() == "") || WBSetting.integrationIDSYS) || (this.textSOItem_detail.Text.Trim().Length >= 2))
                                        {
                                            WBTable table2 = new WBTable();
                                            table2.OpenTable("wb_contract", "SELECT so_item FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + this.textDO.Text.Trim() + "'"), WBData.conn);
                                            if (table2.DT.Rows[0]["so_item"].ToString() == "*")
                                            {
                                                WBTable table3 = new WBTable();
                                                object[] objArray1 = new object[] { " AND do_no = '", this.textDO.Text.Trim(), "' AND so_item = '", Program.StrToDouble(this.textSOItem_detail.Text.Trim(), 0), "'" };
                                                table3.OpenTable("wb_contract_sapinformation", "SELECT uniq FROM wb_contract_sapinformation WHERE " + WBData.CompanyLocation(string.Concat(objArray1)), WBData.conn);
                                                if (table3.DT.Rows.Count > 0)
                                                {
                                                    table3.Dispose();
                                                }
                                                else
                                                {
                                                    object[] objArray2 = new object[] { "SO item ", Program.StrToDouble(this.textSOItem_detail.Text.Trim(), 0), " is not available for WB DO ", this.textDO.Text.Trim(), ". Please check your WB DO!" };
                                                    MessageBox.Show(string.Concat(objArray2), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                    this.but_sh_do_sap.Focus();
                                                    return;
                                                }
                                            }
                                            table2.Dispose();
                                            if ((WBSetting.IntegrationSAP == "Y") || WBSetting.integrationIDSYS)
                                            {
                                                if (this.text_do_sap.ReadOnly)
                                                {
                                                    if (this.text_do_sap_qty.Text == "")
                                                    {
                                                        MessageBox.Show("Quantity DO " + this.sapIDSYS + " is zero. Please contact " + this.sapIDSYS, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                        return;
                                                    }
                                                }
                                                else if (this.txtInternalNum.Text.Trim() != "")
                                                {
                                                    this.hasil = this.t_do_sap.tokenOrApp(this.txtInternalNum.Text, this.txtInNumItem.Text, "DO_SAP_FAIL_VALID", "TOKEN_DO_SAP_FAIL_VALID", "DOSAP_MANUAL", "E", "", null);
                                                    if (this.hasil[0] == "cancel")
                                                    {
                                                        return;
                                                    }
                                                }
                                                else
                                                {
                                                    this.hasil = this.t_do_sap.tokenOrApp(this.text_do_sap.Text, this.text_do_sap_item.Text, "DO_SAP_FAIL_VALID", "TOKEN_DO_SAP_FAIL_VALID", "DOSAP_MANUAL", "E", "", null);
                                                    if (this.hasil[0] == "cancel")
                                                    {
                                                        return;
                                                    }
                                                }
                                            }
                                            if (this.txtInternalNum.Text.Trim() == "")
                                            {
                                                WBTable table4 = new WBTable();
                                                string[] textArray5 = new string[11];
                                                textArray5[0] = "SELECT * FROM wb_transdo as DO inner join wb_transaction as TS on TS.do_no = DO.do_no WHERE DO.internal_number = '";
                                                textArray5[1] = this.txtInternalNum.Text;
                                                textArray5[2] = "' and DO.internal_number_item = '";
                                                textArray5[3] = this.txtInNumItem.Text;
                                                textArray5[4] = "'  and TS.ref <> '";
                                                textArray5[5] = this.RefNo;
                                                textArray5[6] = "' and (TS.deleted = 'N' or TS.deleted is null) and (TS.Mark_accident = 'N' or TS.Mark_accident is null) and TS.coy = '";
                                                textArray5[7] = WBData.sCoyCode;
                                                textArray5[8] = "' and TS.location_code = '";
                                                textArray5[9] = WBData.sLocCode;
                                                textArray5[10] = "'";
                                                table4.OpenTable("wb_transdo", string.Concat(textArray5), WBData.conn);
                                                if (table4.DT.Rows.Count > 0)
                                                {
                                                    string[] textArray6 = new string[] { "Internal Number [ ", this.txtInternalNum.Text, " ] has been used in Ref [ ", table4.DT.Rows[0]["ref"].ToString(), " ] \nPlease use another Internal Number.\nThank you." };
                                                    MessageBox.Show(string.Concat(textArray6), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                    return;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Invalid SO Item", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Invalid Internal No Item", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        return;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Invalid DO " + this.sapIDSYS + " Item", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please fill SO Item", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.but_sh_do_sap.Focus();
                                return;
                            }
                        }
                        this.changeComm = false;
                        if ((this.dgvDOCurrRow == 0) && ((this.doEntryMode == "EDIT") || (this.doEntryMode == "EDIT_OPW")))
                        {
                            if (!(WBSetting.dummy_contract_on_registration && (this.oldComm.Trim() == WBSetting.dummy_comm_code)))
                            {
                                if (this.oldComm.Trim().ToUpper() != this.textComm.Text.Trim().ToUpper())
                                {
                                    string[] textArray7 = new string[] { "Are you sure to change commodity from ", this.oldComm, " to ", this.textComm.Text, " ? (This action will reset the quality) " };
                                    if (MessageBox.Show(string.Concat(textArray7), "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                                    {
                                        this.saved = false;
                                        return;
                                    }
                                    else
                                    {
                                        this.changeComm = true;
                                        if ((this.bulkPack == "B") && (this.labelLoadingUOM.Text.ToUpper() == "KG"))
                                        {
                                            this.textBoxLoadingQty.Text = "0";
                                        }
                                    }
                                }
                            }
                            else
                            {
                                this.changeComm = true;
                            }
                        }
                        this.tblComm.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.textComm.Text + "'"), WBData.conn);
                        DataRow row3 = this.tblComm.DT.Rows[0];
                        if ((this.dgvDO.Rows.Count > 0) && ((this.doEntryMode == "ADD") || ((this.doEntryMode == "EDIT") && (this.dgvDO.CurrentRow.Index > 0))))
                        {
                            if ((((this.textFactNet.Text.Trim() != "") && (this.textFactNet.Text.Trim() != "0")) || (this.totalNetEstate != 0.0)) || (row3["bulkpack"].ToString() == "P"))
                            {
                                if (((this.textOthNet.Text.Trim() == "") || (this.textOthNet.Text.Trim() == "0")) ? (this.totalNetEstate > 0.0) : false)
                                {
                                    MessageBox.Show("Please fill other party net weight before save DO!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    this.textOthNet.Focus();
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please fill factory net weight before save DO!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                this.textFactNet.Focus();
                                return;
                            }
                        }
                        if (((this.chkqty == "Y") && ((this.bulkPack != "P") && ((this.textBoxLoadingQty.Text != "0") || (this.textBoxLoadingQty.Text != "")))) && (this.txtInNumItem.Text.Trim() == ""))
                        {
                            if (this.OSNetTol != 0.0)
                            {
                                if (this.deductedBy != "0")
                                {
                                    if ((this.deductedBy == "1") && (Program.StrToDouble(this.textOthNet.Text, 0) > this.OSNetTol))
                                    {
                                        MessageBox.Show("Other Quantity Over Quantity Tolerance..", "WARNING...");
                                        return;
                                    }
                                }
                                else if ((((this.CommType == "S") || (this.CommType == "F")) || (this.CommType == "C")) && (Program.StrToDouble(this.textFactNet.Text, 0) > this.OSNetTol))
                                {
                                    MessageBox.Show("Factory Net Over Quantity Tolerance..", "WARNING...");
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Cannot Use DO, Outstanding DO is 0", "WARNING...");
                                return;
                            }
                        }
                        if ((WBSetting.locType == "1") && (((this.txtDeliveryNote.Text.Trim() == "") && this.txtDeliveryNote.Visible) && this.txtDeliveryNote.Enabled))
                        {
                            MessageBox.Show("Please Fill Delivery Note", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            this.txtDeliveryNote.Focus();
                        }
                        else
                        {
                            this.saved = true;
                            base.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("PI No doesn't belong to this DO No", "WARNING...");
                        this.textDO.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please Click Choose DO", "WARNING...");
                }
            }
            else
            {
                MessageBox.Show("Please Entry WB DO No", "WARNING...");
            }
        }

        private void buttonStorage_Click(object sender, EventArgs e)
        {
            FormStorage storage = new FormStorage {
                pMode = "CHOOSE"
            };
            storage.ShowDialog();
            if (storage.ReturnRow != null)
            {
                this.textStorage.Text = storage.ReturnRow["Storage_Code"].ToString();
                this.labelStorageName.Text = storage.ReturnRow["Storage_Name"].ToString();
                this.textStorage.Focus();
            }
            storage.Dispose();
        }

        private void checkDecimalOnKeyPress(TextBox textBox, KeyPressEventArgs e)
        {
            if (WBSetting.allowDecimalLoadingQty)
            {
                if (!Program.CheckNumericForLoadingQty(textBox.Text))
                {
                    textBox.Text = "0";
                }
            }
            else
            {
                bool flag4 = true;
                if (((e.KeyChar < '0') || (e.KeyChar > '9')) ? (e.KeyChar == '\b') : true)
                {
                    flag4 = false;
                }
                e.Handled = flag4;
            }
        }

        public bool checkLoadingNote()
        {
            if (((currInternalNumber != "") && (currInternalNumber != this.txtInternalNum.Text)) && this.active_lock_tdt)
            {
                this.changeLoadingNote = true;
            }
            return this.changeLoadingNote;
        }

        private bool CheckPeriodDO(DataRow prDO, string pDate) => 
            (prDO["checkPeriod"].ToString() == "Y") && (Convert.ToDateTime(pDate) > Convert.ToDateTime(prDO["Do_Date2"].ToString()));

        public bool checkReadopt()
        {
            if (((currInternalNumber != "") && (currInternalNumber == this.txtInternalNum.Text)) && this.active_lock_tdt)
            {
                this.readoptInternalNumber = true;
            }
            return this.readoptInternalNumber;
        }

        private bool CheckSPB()
        {
            using (IEnumerator enumerator = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
            {
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        break;
                    }
                    DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                    string strA = this.txtDeliveryNote.Text.Trim();
                    WBTable table = new WBTable();
                    table.OpenTable("wb_delivery_note", "Select * From wb_delivery_note where Do_No='" + current.Cells["DO_No"].Value.ToString().Trim() + "'", WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num >= table.DT.Rows.Count)
                            {
                                break;
                            }
                            table.DR = table.DT.Rows[num];
                            bool flag2 = strA.Length != table.DR["delivery_note_from"].ToString().Length;
                            if (flag2 || ((string.Compare(strA, table.DR["Delivery_Note_From"].ToString()) < 0) || (string.Compare(strA, table.DR["Delivery_Note_to"].ToString()) > 0)))
                            {
                                num++;
                                continue;
                            }
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        private void chooseDoPISI()
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFrom = "formTransDO",
                pFind = this.textDO.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.tblDO.ReOpen();
                this.tblTType.ReOpen();
                string[] aField = new string[] { "Do_No" };
                string[] aFind = new string[] { contract.ReturnRow["Do_NO"].ToString() };
                DataRow data = this.tblDO.GetData(aField, aFind);
                string[] textArray3 = new string[] { "Transaction_code" };
                string[] textArray4 = new string[] { data["transaction_code"].ToString() };
                DataRow row2 = this.tblTType.GetData(textArray3, textArray4);
                this.IO = row2["IO"].ToString();
                this.tblVesselMap.OpenTable("wb_vessel_map", "SELECT uniq_item, qty_map, completed from wb_vessel_map where uniq_vessel = '" + data["uniq"].ToString() + "'", WBData.conn);
                if (this.tblVesselMap.DT.Rows.Count > 0)
                {
                    DataRow row3 = this.tblVesselMap.DT.Rows[0];
                    if ((row2["is_vessel"].ToString() == "Y") && (row3["completed"].ToString() == "Y"))
                    {
                        MessageBox.Show("DO Vessel is already completed", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        return;
                    }
                }
                if (!this.CheckPeriodDO(contract.ReturnRow, this.refDate))
                {
                    if (this.dgvDO.Rows.Count > 0)
                    {
                        if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                        {
                            this.txtDeliveryNote.Enabled = false;
                        }
                        else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                        {
                            this.txtDeliveryNote.Enabled = false;
                        }
                        else if (((this.CommType == "F") && !this.CheckSPB()) && this.txtDeliveryNote.Visible)
                        {
                            this.txtDeliveryNote.Enabled = false;
                        }
                    }
                    this.textDO.Text = contract.ReturnRow["Do_NO"].ToString();
                    this.uniq_contract = contract.ReturnRow["uniq"].ToString();
                    this.FillDataDO(contract.ReturnRow);
                }
                else
                {
                    string[] textArray5 = new string[] { "The period of DO  '", contract.ReturnRow["DO_NO"].ToString(), "' has been expired after ", contract.ReturnRow["Do_Date2"].ToString().Substring(0, 10), "...!" };
                    MessageBox.Show(string.Concat(textArray5), "WARNING...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            contract.Dispose();
        }

        private void comboDOContainer_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = '\0';
        }

        public bool connectIDSYS()
        {
            bool flag2;
            string requestUriString = new WBIDSYSIntegrator().getURL("IDSYS_ADOPT_DOPARTIAL");
            requestUriString = requestUriString.Substring(0, requestUriString.Length - 0x17);
            try
            {
                HttpWebResponse response = (HttpWebResponse) ((HttpWebRequest) WebRequest.Create(requestUriString)).GetResponse();
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Debug.Write($"{requestUriString} Available");
                    flag2 = true;
                }
                else
                {
                    MessageBox.Show($"{requestUriString} Returned, but with status: {response.StatusDescription}");
                    flag2 = false;
                }
            }
            catch (Exception exception1)
            {
                MessageBox.Show($"{requestUriString} unavailable: {exception1.Message}");
                flag2 = false;
            }
            return flag2;
        }

        private void countQtyLeft(string pDoNo)
        {
            string[] aField = new string[] { "DO_NO" };
            string[] aFind = new string[] { this.textDO.Text };
            DataRow data = this.tblDO.GetData(aField, aFind);
            if (this.using_gunny == "Y")
            {
                this.OSNetwoTol = Convert.ToDouble($"{Program.checkOSbyGunny(pDoNo, "", this.RefNo, "N"):N0}");
                this.OSNetTol = ((data["tolerance"].ToString().Trim() == "") && (data["tolerance"].ToString().Trim() == "0")) ? this.OSNetwoTol : Convert.ToDouble($"{Program.checkOSbyGunny(pDoNo, "", this.RefNo, "Y"):N0}");
            }
            else
            {
                this.OSNetwoTol = Program.checkOS(pDoNo, "", this.RefNo, "N");
                this.OSNetTol = ((data["tolerance"].ToString().Trim() == "") && (data["tolerance"].ToString().Trim() == "0")) ? this.OSNetwoTol : Program.checkOS(pDoNo, "", this.RefNo, "Y");
                if ((data["deductedBy"].ToString() == "1") && (this.IO == "I"))
                {
                    double num = Convert.ToDouble($"{Program.checkQtyUsedOngoingOPW(pDoNo, "", this.RefNo, this.gatepassNumber, ""):N0}");
                    this.OSNetTol -= Convert.ToDouble(num);
                    this.OSNetwoTol -= Convert.ToDouble(num);
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FillDataDO(DataRow pDoRow)
        {
            this.labelKB.Text = (pDoRow["berikat"].ToString() == "Y") ? "*KB" : "";
            this.label1STO1DO.Visible = pDoRow["STO1DO"].ToString() == "Y";
            this.chkqty = pDoRow["Check_qty"].ToString();
            this.tolerance = pDoRow["tolerance"].ToString();
            this.deductedBy = pDoRow["deductedBy"].ToString();
            string text1 = this.license_number = "";
            string text2 = this.driver_name = text1;
            this.truck_number = this.transporter = text2;
            this.tblTType.ReOpen();
            string[] aField = new string[] { "Transaction_code" };
            string[] aFind = new string[] { pDoRow["transaction_code"].ToString() };
            DataRow data = this.tblTType.GetData(aField, aFind);
            this.IO = data["IO"].ToString();
            if (!this.IsReturn)
            {
                this.pTransType = pDoRow["Transaction_Code"].ToString();
            }
            this.so_item = (pDoRow["so_item"].ToString() != "*") ? pDoRow["so_item"].ToString() : "";
            this.textComm.Text = pDoRow["Comm_Code"].ToString();
            this.pComm = pDoRow["Comm_Code"].ToString();
            this.tblComm.OpenTable("wb_comm", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.textComm.Text + "'"), WBData.conn);
            string[] textArray3 = new string[] { "comm_code" };
            string[] textArray4 = new string[] { this.textComm.Text };
            DataRow row2 = this.tblComm.GetData(textArray3, textArray4);
            if (row2 == null)
            {
                this.using_gunny = "N";
                this.CommType = "S";
                this.CommUOM = "KG";
            }
            else
            {
                this.using_gunny = row2["using_gunny"].ToString();
                this.CommType = row2["Type"].ToString();
                this.CommUOM = row2["Unit"].ToString();
                this.bulkPack = row2["BulkPack"].ToString();
                this.isTrade2 = row2["Trade"].ToString();
                this.netto_weight = float.Parse((row2["netto_weight"].ToString() == "") ? "0" : row2["netto_weight"].ToString());
                this.lbl_comm_name.Text = row2["comm_name"].ToString();
                this.txtOPWLoadQty(this.IO, row2["Unit"].ToString(), row2["Trade"].ToString());
                this.mUnit = row2["Unit"].ToString().Trim();
                if ((this.mUnit == null) || (this.mUnit == ""))
                {
                    this.labelLoadingUOM.Text = "Kg";
                    this.label_loading_qty_opw_uom.Text = "Kg";
                }
                else
                {
                    this.labelLoadingUOM.Text = row2["Unit"].ToString().ToUpper();
                    this.label_loading_qty_opw_uom.Text = row2["Unit"].ToString().ToUpper();
                }
            }
            this.countQtyLeft(pDoRow["DO_NO"].ToString());
            this.labelQtyLeft.Text = $"{Math.Floor(Convert.ToDouble(this.OSNetwoTol.ToString())):N0}";
            this.OSNetwoTol = Convert.ToDouble($"{Convert.ToDouble(this.OSNetwoTol.ToString()):N0}");
            this.labelQuantity.Text = "/ " + $"{Convert.ToDouble(pDoRow["quantity"].ToString()):N0}";
            this.textRCode.Text = pDoRow["Relation_Code"].ToString().Trim();
            this.zCust.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" AND Relation_Code='" + pDoRow["Relation_Code"].ToString().Trim() + "'"), WBData.conn);
            if (this.zCust.DT.Rows.Count > 0)
            {
                this.textRCode.Text = pDoRow["Relation_Code"].ToString().Trim();
                this.textRName.Text = this.zCust.DT.Rows[0]["Relation_Name"].ToString().Trim();
            }
            this.textTransporter.Text = pDoRow["Transporter_Code"].ToString();
            this.textTransCode.Text = pDoRow["Transaction_Code"].ToString();
            this.labelTransName.Text = data["Transaction_Name"].ToString();
            this.textCont.Text = pDoRow["Contract"].ToString();
            this.textEstate.Text = pDoRow["Estate1_Code"].ToString();
            this.labelKB.Text = (pDoRow["Berikat"].ToString().Trim() == "Y") ? "*KB" : "";
            this.lSTO1DO = pDoRow["STO1DO"].ToString().Trim() == "Y";
            this.ISCC = pDoRow["ISCC"].ToString().Trim();
            this.textPI_No.Text = pDoRow["PI_No"].ToString();
            this.remark = pDoRow["remark"].ToString();
            this.qualityInfo = pDoRow["qualityInfo"].ToString();
            this.tolling = pDoRow["Tolling"].ToString();
            this.label1STO1DO.Visible = pDoRow["STO1DO"].ToString().Trim() == "Y";
            this.lSTO1DO = pDoRow["STO1DO"].ToString().Trim() == "Y";
            if (WBSetting.zwb == "Y")
            {
                this.labelZWB.Visible = pDoRow["ZWB"].ToString() != "Y";
            }
            if (pDoRow["check_qty"].ToString() == "Y")
            {
                this.party = pDoRow["quantity"].ToString();
                double num = 0.3 * Program.StrToDouble(this.party, 2);
                if (this.OSNetwoTol >= num)
                {
                    this.labelQtyLeft.ForeColor = Color.Black;
                }
                else
                {
                    MessageBox.Show("Quantity Left is Below 30 % of Total Party \nPress OK to Continue...", "WARNING...", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.labelQtyLeft.ForeColor = Color.Red;
                }
            }
        }

        private void filldopartial(bool require_do, bool zdo_trx)
        {
            FormDoSAP osap = new FormDoSAP {
                map = this.map,
                RefNo = this.RefNo,
                num_of_do = this.num_of_do,
                num_of_dr = this.num_of_dr,
                num_of_dotrx = this.num_of_dotrx,
                mode = "CHOOSE",
                flagRegistration = true,
                oldDOSAP = this.text_do_sap.Text,
                oldInternalNo = this.txtInternalNum.Text,
                gatepassNo = this.gatepassNumber,
                doEntryMode = this.doEntryMode,
                previousSelected_DOTable = this.dgvDO,
                retTable_DO = this.retTable_DSAP_DO,
                retTable_DOTRX = this.retTable_DSAP_DOTRX,
                retTable_DR = this.retTable_DSAP_DR
            };
            osap.ShowDialog();
            string text1 = this.license_number = "";
            string text2 = this.driver_name = text1;
            this.truck_number = this.transporter = text2;
            if (osap.do_sap == "")
            {
                if (osap.internal_number != "")
                {
                    if (zdo_trx)
                    {
                        DataRow data;
                        int num5 = Convert.ToInt32(osap.so_item_detail.ToString().Trim());
                        int num6 = 0;
                        this.tblDO.ReOpen();
                        if (osap.wbdo.Trim() != "")
                        {
                            if (osap.so_item_detail.Trim() != "00000")
                            {
                                num6 = Convert.ToInt16(osap.so_item_detail.Trim());
                            }
                            string[] aField = new string[] { "SO", "SO_Item" };
                            string[] aFind = new string[] { osap.wbdo.Trim(), num6.ToString() };
                            data = this.tblDO.GetData(aField, aFind);
                            if (ReferenceEquals(data, null))
                            {
                                string[] textArray4 = new string[] { "SO", "SO_Item" };
                                string[] textArray5 = new string[] { osap.wbdo.Trim(), "*" };
                                data = this.tblDO.GetData(textArray4, textArray5);
                            }
                        }
                        else if (osap.no_sto.Trim() == "")
                        {
                            if (osap.spb_number_item.Trim() != "00000")
                            {
                                num6 = Convert.ToInt16(osap.spb_number_item.Trim());
                            }
                            string[] aField = new string[] { "SPB_No", "SPB_Item" };
                            string[] aFind = new string[] { osap.spb_number.Trim(), num6.ToString() };
                            data = this.tblDO.GetData(aField, aFind);
                        }
                        else
                        {
                            if (osap.no_sto_item.Trim() != "00000")
                            {
                                num6 = Convert.ToInt16(osap.no_sto_item.Trim());
                            }
                            string[] aField = new string[] { "STO", "STO_Item" };
                            string[] aFind = new string[] { osap.no_sto.Trim(), num6.ToString() };
                            data = this.tblDO.GetData(aField, aFind);
                            if (ReferenceEquals(data, null))
                            {
                                string[] textArray8 = new string[] { "STO", "STO_Item" };
                                string[] textArray9 = new string[] { osap.no_sto.Trim(), "*" };
                                data = this.tblDO.GetData(textArray8, textArray9);
                            }
                        }
                        if (data == null)
                        {
                            this.textDO.Text = "";
                            if (osap.wbdo.Trim() != "")
                            {
                                MessageBox.Show("Please Create WB DO for SO " + osap.wbdo.Trim());
                            }
                            else if (osap.no_sto.Trim() != "")
                            {
                                MessageBox.Show("Please Create WB DO for STO " + osap.no_sto.Trim());
                            }
                            else
                            {
                                MessageBox.Show("Please Create WB DO for SPB " + osap.spb_number.Trim());
                            }
                            return;
                        }
                        else if ((data["deleted"].ToString().Trim() == "Y") && (data["closed"].ToString().Trim() == "Y"))
                        {
                            this.textDO.Text = "";
                            MessageBox.Show("Contract with SO " + osap.wbdo.Trim() + " is closed or deleted");
                            return;
                        }
                        else
                        {
                            this.textDO.Text = data["Do_No"].ToString().Trim();
                            this.FillDataDO(data);
                            this.SetDOSAP(data);
                            if (WBSetting.integrationIDSYS)
                            {
                                this.transporter = (osap.transporter == "") ? this.textTransporter.Text : osap.transporter;
                                this.truck_number = osap.truck_number;
                                this.driver_name = osap.driver_name;
                                this.license_number = osap.license_number;
                            }
                            else
                            {
                                this.transporter = osap.transporter;
                                this.truck_number = osap.truck_number;
                                this.driver_name = osap.driver_name;
                                this.license_number = osap.license_number;
                            }
                            this.textDO.ReadOnly = true;
                            this.buttonDO.Enabled = false;
                            this.textPI_No.ReadOnly = true;
                            this.buttonPISI.Enabled = false;
                            this.sto_no = osap.no_sto;
                            this.sto_no_item = osap.no_sto_item;
                            if (osap.no_sto == "")
                            {
                                this.sto_no = data["STO"].ToString().Trim();
                                this.sto_no_item = data["STO_item"].ToString().Trim();
                            }
                        }
                    }
                    this.text_do_sap.Text = "";
                    this.text_do_sap_item.Text = "";
                    this.txtInternalNum.Text = osap.internal_number;
                    this.txtInNumItem.Text = osap.internal_number_item;
                    this.text_do_sap_qty.Text = osap.qty;
                    this.text_do_sap_unit.Text = osap.unit;
                    this.text_do_sap_qty_kg.Text = osap.qty_kg;
                    this.textBoxQtyBaseUOM.Text = osap.qty_base_uom;
                    this.textBoxBaseUOM.Text = osap.base_uom;
                    this.textSOItem_detail.Text = osap.so_item_detail;
                    this.txtBox_QQ.Text = osap.customer_qq;
                    this.retTable_DSAP_DR = osap.retTable_DR;
                    this.retTable_DSAP_DOTRX = osap.retTable_DOTRX;
                    if ((this.retTable_DSAP_DR.Rows.Count == 1) || (this.retTable_DSAP_DOTRX.Rows.Count == 1))
                    {
                        this.hideDOSAPForm(false);
                    }
                    else
                    {
                        this.hideDOSAPForm(true);
                    }
                }
            }
            else
            {
                this.txtInternalNum.Text = "";
                this.txtInNumItem.Text = "";
                this.text_do_sap.Text = osap.do_sap;
                this.text_do_sap_item.Text = osap.do_sap_item;
                this.text_do_sap_qty.Text = osap.qty;
                this.text_do_sap_unit.Text = osap.unit;
                if ((this.bulkPack != "P") || (this.CommUOM == "KG"))
                {
                    this.text_do_sap_qty_kg.Text = osap.qty_kg;
                }
                else
                {
                    float num = 0f;
                    num = float.Parse(osap.qty_base_uom);
                    if ((this.so_item != "*") && (this.so_item != ""))
                    {
                        this.text_do_sap_qty_kg.Text = (num * this.netto_weight).ToString();
                    }
                    else
                    {
                        WBTable table = new WBTable();
                        WBTable table2 = new WBTable();
                        string[] textArray1 = new string[] { " AND do_no = '", this.textDO.Text.Trim(), "' and so_item = '", Program.StrToDouble(osap.so_item_detail, 0).ToString(), "'" };
                        table.OpenTable("wb_contract_sapinformation", "SELECT comm_code FROM wb_contract_sapinformation WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                        table2.OpenTable("wb_commodity", "SELECT netto_weight FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + table.DT.Rows[0]["comm_code"].ToString() + "'"), WBData.conn);
                        this.text_do_sap_qty_kg.Text = (num * float.Parse((table2.DT.Rows[0]["netto_weight"].ToString() == "") ? "0" : table2.DT.Rows[0]["netto_weight"].ToString())).ToString();
                        table.Dispose();
                        table2.Dispose();
                    }
                }
                this.textBoxQtyBaseUOM.Text = osap.qty_base_uom;
                this.textBoxBaseUOM.Text = osap.base_uom;
                this.isDOBesar = this.indic = osap.indic;
                this.need_choose_do = false;
                this.textSOItem_detail.Text = osap.so_item_detail;
                this.retTable_DSAP_DO = osap.retTable_DO;
                if (this.retTable_DSAP_DO.Rows.Count == 1)
                {
                    this.hideDOSAPForm(false);
                }
                else
                {
                    this.hideDOSAPForm(true);
                }
                this.lbl_do_besar.Visible = osap.indic == "X";
            }
        }

        private void FormTransDOEntry_Load(object sender, EventArgs e)
        {
            currInternalNumber = this.txtInternalNum.Text;
            this.tblTType.OpenTable("wb_transaction_type", "select * from wb_transaction_type where" + WBData.CompanyLocation(""), WBData.conn);
            if (this.doEntryMode == "ADD")
            {
                this.tblDO.OpenTable("wb_contract", "select * from wb_contract where" + WBData.CompanyLocation(" and (closed is null or closed <> 'X' or closed = 'N') and zAuto = 'N'"), WBData.conn);
            }
            else
            {
                this.tblDO.OpenTable("wb_contract", "select * from wb_contract where" + WBData.CompanyLocation(" and ((closed is null or closed <> 'X' or closed = 'N') and zAuto = 'N' or do_no = '" + this.textDO.Text.Trim() + "')"), WBData.conn);
            }
            Program.AutoComp(this.tblDO, "Do_No", this.textDO);
            Program.AutoComp(this.tblDO, "PI_No", this.textPI_No);
            this.labelKB.Text = "";
            this.labelZWB.Visible = false;
            this.textOthNet.Text = (this.textOthNet.Text == "") ? "0" : this.textOthNet.Text;
            this.textBoxLoadingQty.ReadOnly = true;
            this.text_opw_loading_qty.ReadOnly = true;
            this.btnFillContainer.Visible = (WBSetting.Container != "N") || (this.dgvCont.Rows.Count != 0);
            if (this.doEntryMode == "ADD")
            {
                this.textOthNet.Enabled = this.totalNetEstate != 0.0;
                if (WBSetting.adopt_zdotrx)
                {
                    this.gb_do_sap.Visible = true;
                    this.txtInternalNum.Enabled = true;
                    this.txtInternalNum.ReadOnly = false;
                    this.lblInternalNum.Text = "Loading Note";
                }
                if (this.dgvDO.Rows.Count == 0)
                {
                    this.txtDeliveryNote.Visible = false;
                    this.labelDN.Visible = false;
                }
                else
                {
                    this.txtDeliveryNote.Visible = true;
                    if (WBSetting.default_delivery_note_for_split)
                    {
                        this.txtDeliveryNote.Text = this.delivery_note;
                    }
                    this.labelDN.Visible = true;
                }
            }
            else if (((this.doEntryMode == "EDIT") || ((this.doEntryMode == "EDIT_OPW") || (this.doEntryMode == "ADD_RETUR"))) || (this.doEntryMode == "VIEW"))
            {
                this.textDO.Focus();
                this.txtDeliveryNote.Visible = false;
                this.labelDN.Visible = false;
                this.textComm.Text = this.dgvDO.CurrentRow.Cells["Comm_Code"].Value.ToString();
                string[] aField = new string[] { "Transaction_code" };
                string[] aFind = new string[] { this.dgvDO.CurrentRow.Cells["Transaction_Code"].Value.ToString() };
                DataRow data = this.tblTType.GetData(aField, aFind);
                this.tblComm.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.textComm.Text + "'"), WBData.conn);
                this.textOthNet.Enabled = (data["IO"].ToString() != "I") ? ((this.dgvDOCurrRow != 0) ? (this.tblComm.DT.Rows[0]["bulkpack"].ToString() != "B") : false) : ((this.dgvDOCurrRow != 0) ? (this.totalNetEstate != 0.0) : false);
                if (((this.doEntryMode != "VIEW") & !this.IsReturn) || ((this.doEntryMode == "VIEW") & WBSetting.adopt_zdotrx))
                {
                    if ((this.dgvDO.CurrentRow.Cells["do_sap"].Value.ToString().Trim() == "") && (this.dgvDO.CurrentRow.Cells["internal_number"].Value.ToString().Trim() == ""))
                    {
                        this.gb_do_sap.Visible = false;
                    }
                    else if (WBSetting.integrationIDSYS)
                    {
                        this.gb_do_sap.Visible = this.textTransCode.Text.ToUpper() == "JUL";
                    }
                    else
                    {
                        this.gb_do_sap.Visible = true;
                        this.lblInternalNum.Text = !WBSetting.adopt_zdotrx ? "Internal No" : "Loading Note";
                    }
                }
                this.txtOPWLoadQty(data["IO"].ToString(), this.tblComm.DT.Rows[0]["Unit"].ToString(), this.tblComm.DT.Rows[0]["Trade"].ToString());
            }
            if (WBSetting.Container == "N")
            {
                this.btnFillContainer.Visible = this.dgvCont.Rows.Count != 0;
            }
            if (WBSetting.Field("Check_Storage") != "N")
            {
                this.tblStorage = new WBTable();
                this.tblStorage.OpenTable("wb_storage", "Select * from wb_storage", WBData.conn);
                Program.AutoComp(this.tblStorage, "Storage_code", this.textStorage);
            }
            else
            {
                this.textStorage.Visible = false;
                this.buttonStorage.Visible = false;
                this.labelStorageName.Visible = false;
                this.labelStorage.Visible = false;
            }
            if (WBSetting.zwb != "Y")
            {
                this.labelZWB.Visible = false;
            }
            this.sisaNet = this.totalNet;
            this.sisaEstateNet = this.totalNetEstate;
            if ((this.doEntryMode == "ADD") && (this.dgvDO.Rows.Count > 0))
            {
                this.sisaNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["netto"].Value.ToString());
                this.sisaEstateNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString());
            }
            if (!(((this.doEntryMode == "EDIT") || ((this.doEntryMode == "EDIT_OPW") || (this.doEntryMode == "VIEW"))) ? (this.dgvDOCurrRow > 0) : false))
            {
                if ((this.doEntryMode == "EDIT") && (this.dgvDOCurrRow == 0))
                {
                    this.sisaNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["netto"].Value.ToString());
                    this.sisaEstateNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString());
                }
            }
            else
            {
                this.sisaNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["netto"].Value.ToString());
                this.sisaEstateNet = Convert.ToDouble(this.dgvDO.Rows[0].Cells["Estate_qty"].Value.ToString());
                this.DONet = Convert.ToDouble(this.dgvDO.Rows[this.dgvDOCurrRow].Cells["netto"].Value.ToString());
                this.DOEstateNet = Convert.ToDouble(this.dgvDO.Rows[this.dgvDOCurrRow].Cells["Estate_qty"].Value.ToString());
                this.sisaNet += this.DONet;
                this.sisaEstateNet += this.DOEstateNet;
            }
            string str = (this.doEntryMode == "ADD") ? Resource.Trans_055 : ((this.doEntryMode == "EDIT") ? Resource.Trans_056 : ((this.doEntryMode == "VIEW") ? Resource.Trans_106 : ""));
            string[] textArray3 = new string[] { str, " ", Resource.RegisDOEntry_001, " (", $"{this.sisaEstateNet:N0}", @"\", $"{this.sisaNet:N0}", ")" };
            this.Text = string.Concat(textArray3);
            if (((this.doEntryMode == "EDIT") || ((this.doEntryMode == "EDIT_OPW") || (this.doEntryMode == "ADD_RETUR"))) || (this.doEntryMode == "VIEW"))
            {
                this.textDO.Text = this.dgvDO.CurrentRow.Cells["DO_No"].Value.ToString();
                this.oldDO_No = this.textDO.Text;
                string[] aField = new string[] { "DO_NO" };
                string[] aFind = new string[] { this.textDO.Text };
                DataRow data = this.tblDO.GetData(aField, aFind);
                if (ReferenceEquals(data, null))
                {
                }
                this.FillDataDO(data);
                this.tblComm.OpenTable("wb_comm", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.textComm.Text + "'"), WBData.conn);
                string[] textArray6 = new string[] { "comm_code" };
                string[] textArray7 = new string[] { this.textComm.Text };
                DataRow row3 = this.tblComm.GetData(textArray6, textArray7);
                if (row3 == null)
                {
                    this.using_gunny = "N";
                    this.CommType = "S";
                }
                else
                {
                    this.using_gunny = row3["using_gunny"].ToString();
                    this.CommType = row3["Type"].ToString();
                    this.bulkPack = row3["BulkPack"].ToString();
                    this.isTrade2 = row3["Trade"].ToString();
                    this.netto_weight = float.Parse((row3["netto_weight"].ToString() == "") ? "0" : row3["netto_weight"].ToString());
                    this.lbl_comm_name.Text = row3["comm_name"].ToString();
                }
                this.textCont.Text = this.dgvDO.CurrentRow.Cells["Contract"].Value.ToString();
                this.textRCode.Text = this.dgvDO.CurrentRow.Cells["Relation_Code"].Value.ToString().Trim();
                this.textRName.Text = this.dgvDO.CurrentRow.Cells["Relation_Name"].Value.ToString().Trim();
                this.textFactNet.Text = this.dgvDO.CurrentRow.Cells["Netto"].Value.ToString();
                this.textOthNet.Text = this.dgvDO.CurrentRow.Cells["Estate_Qty"].Value.ToString();
                this.textEstate.Text = this.dgvDO.CurrentRow.Cells["Estate"].Value.ToString();
                this.textStorage.Text = this.dgvDO.CurrentRow.Cells["storage_code"].Value.ToString();
                this.textTransporter.Text = this.dgvDO.CurrentRow.Cells["Transporter_Code"].Value.ToString();
                this.textTransCode.Text = this.dgvDO.CurrentRow.Cells["Transaction_Code"].Value.ToString();
                this.textBoxLoadingQty.Text = this.dgvDO.CurrentRow.Cells["loading_qty"].Value.ToString();
                this.text_opw_loading_qty.Text = this.dgvDO.CurrentRow.Cells["loading_qty_opw"].Value.ToString();
                string[] textArray8 = new string[] { "Transaction_code" };
                string[] textArray9 = new string[] { data["transaction_code"].ToString() };
                DataRow row4 = this.tblTType.GetData(textArray8, textArray9);
                this.IO = row4["IO"].ToString();
                this.labelTransName.Text = row4["Transaction_Name"].ToString();
            }
            this.lbl_do_besar.Visible = this.isDOBesar == "X";
            if (!(this.gb_do_sap.Visible && (WBSetting.IntegrationSAP == "Y")))
            {
                this.text_do_sap.ReadOnly = false;
                this.text_do_sap_item.ReadOnly = false;
                this.txtInternalNum.ReadOnly = false;
                this.txtInNumItem.ReadOnly = false;
                this.but_sh_do_sap.Visible = false;
                this.textSOItem_detail.ReadOnly = false;
                this.txtBox_QQ.Visible = false;
            }
            else
            {
                if (WBSetting.adopt_zdotrx)
                {
                    this.txtInternalNum.ReadOnly = false;
                    this.txtBox_QQ.Visible = true;
                }
                else
                {
                    this.txtInternalNum.ReadOnly = true;
                    this.txtBox_QQ.Visible = false;
                }
                this.text_do_sap_item.ReadOnly = true;
                this.text_do_sap.ReadOnly = true;
                this.txtInNumItem.ReadOnly = true;
                this.but_sh_do_sap.Visible = true;
                this.textSOItem_detail.ReadOnly = true;
            }
            if ((this.doEntryMode == "VIEW") || ((this.doEntryMode == "EDIT") & this.IsReturn))
            {
                foreach (Control control in this.GetOffsprings())
                {
                    if (control.GetType() == typeof(Label))
                    {
                        control.Enabled = true;
                        continue;
                    }
                    if ((control.GetType() != typeof(Label)) && (control.GetType() != typeof(TabControl)))
                    {
                        control.Enabled = false;
                    }
                }
                this.button2.Enabled = true;
            }
            this.translate();
            if (WBSetting.integrationIDSYS)
            {
                this.labelZWB.Text = "Please Synchron this DO to IDSYS";
                this.textSOItem_detail.Enabled = false;
                this.text_do_sap.Enabled = false;
                this.text_do_sap_item.Enabled = false;
                this.txtInternalNum.Enabled = false;
                this.txtInNumItem.Enabled = false;
                this.label2.Visible = false;
                this.text_do_sap.Visible = false;
                this.label21.Visible = false;
                this.text_do_sap_item.Visible = false;
                this.lblInternalNum.Text = "DO IDSYS";
            }
        }

        private void FormTransDOEntry_Shown(object sender, EventArgs e)
        {
            if (this.auto_generate_dummy_contract)
            {
                this.textDO.Focus();
                this.textDO.Text = WBSetting.dummy_contract;
                this.buttonSave.Focus();
                this.buttonSave.PerformClick();
            }
        }

        private bool get_data_from_IDSYS()
        {
            bool flag4;
            string str = this.textDO.Text.Trim();
            WBIDSYSIntegrator integrator = new WBIDSYSIntegrator();
            string url = integrator.getURL("IDSYS_ADOPT_DOPARTIAL");
            if (url == "")
            {
                flag4 = false;
            }
            else
            {
                new WBTable().OpenTable("wb_contract", "Select * from wb_contract where " + WBData.CompanyLocation(" and do_no = '" + str + "'"), WBData.conn);
                string[] textArray1 = new string[11];
                textArray1[0] = "{coy:'";
                textArray1[1] = WBSetting.CoySAP;
                textArray1[2] = "',so:'";
                textArray1[3] = this.so_no;
                textArray1[4] = "',so_item:'";
                textArray1[5] = this.so_item;
                textArray1[6] = "',sto:'";
                textArray1[7] = this.sto_no;
                textArray1[8] = "',sto_item:'";
                textArray1[9] = this.sto_no_item;
                textArray1[10] = "'}";
                bool err = false;
                Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                dictionary = integrator.getDataFromIDSYS(url, string.Concat(textArray1), out err);
                if (err)
                {
                    flag4 = false;
                }
                else if (dictionary.Count <= 0)
                {
                    MessageBox.Show(Resource.No_DataIDSYS, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    flag4 = false;
                }
                else
                {
                    List<Dictionary<string, string>> source = dictionary["data"];
                    this.DoTotalSAP = source.Count<Dictionary<string, string>>();
                    if (this.DoTotalSAP <= 0)
                    {
                        MessageBox.Show(Resource.No_DataIDSYS, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        flag4 = false;
                    }
                    else
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num >= source.Count<Dictionary<string, string>>())
                            {
                                this.transporter = this.textTransporter.Text;
                                flag4 = true;
                                break;
                            }
                            int num2 = 0;
                            foreach (KeyValuePair<string, string> pair in source[num])
                            {
                                if (((num2 != 2) && ((num2 != 3) && ((num2 != 4) && (num2 != 5)))) && (num2 != 6))
                                {
                                    this.map[num, num2] = pair.Value.ToString().Trim();
                                }
                                else
                                {
                                    string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                                    this.map[num, num2] = pair.Value.ToString().Trim().Replace(".", newValue);
                                }
                                num2++;
                            }
                            num++;
                        }
                    }
                }
            }
            return flag4;
        }

        private bool get_data_from_mulesoft()
        {
            bool flag4;
            string str = this.textDO.Text.Trim();
            WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
            string str2 = integrator.getURL("ZRFC_DNET_CHECK_SO_DO");
            if (str2 == "")
            {
                flag4 = false;
            }
            else
            {
                bool err = false;
                Dictionary<string, List<Dictionary<string, string>>> dictionary = new Dictionary<string, List<Dictionary<string, string>>>();
                string[] resultHeaderName = new string[] { "ERRORS", "DO_DETAILS", "DO_DR_DETAILS", "MESSAGE_ID" };
                dictionary = integrator.getDataFromMulesoft(str2 + "?so_no=" + str, resultHeaderName, out err);
                if (err)
                {
                    flag4 = false;
                }
                else if (dictionary["ERRORS"].Count > 0)
                {
                    MessageBox.Show("Error from SAP : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    flag4 = false;
                }
                else
                {
                    List<Dictionary<string, string>> source = dictionary["DO_DETAILS"];
                    List<Dictionary<string, string>> list2 = dictionary["DO_DR_DETAILS"];
                    this.DoTotalMulesoft = source.Count<Dictionary<string, string>>();
                    this.DrTotalMulesoft = list2.Count<Dictionary<string, string>>();
                    if (this.DoTotalMulesoft > 0)
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num >= source.Count<Dictionary<string, string>>())
                            {
                                break;
                            }
                            int num2 = 0;
                            foreach (KeyValuePair<string, string> pair in source[num])
                            {
                                if (((num2 != 2) && ((num2 != 3) && ((num2 != 4) && (num2 != 5)))) && (num2 != 6))
                                {
                                    this.map[num, num2] = !string.IsNullOrEmpty(pair.Value) ? pair.Value.ToString().Trim() : "";
                                }
                                else
                                {
                                    string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                                    this.map[num, num2] = pair.Value.ToString().Trim().Replace(".", newValue);
                                }
                                num2++;
                            }
                            num++;
                        }
                    }
                    else if (this.DrTotalMulesoft > 0)
                    {
                        int num3 = 0;
                        while (true)
                        {
                            if (num3 >= list2.Count<Dictionary<string, string>>())
                            {
                                break;
                            }
                            int num4 = 0;
                            foreach (KeyValuePair<string, string> pair2 in list2[num3])
                            {
                                if (((num4 != 2) && ((num4 != 3) && ((num4 != 4) && (num4 != 5)))) && (num4 != 6))
                                {
                                    this.map[num3, num4] = !string.IsNullOrEmpty(pair2.Value) ? pair2.Value.ToString().Trim() : "";
                                }
                                else
                                {
                                    string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                                    this.map[num3, num4] = pair2.Value.ToString().Trim().Replace(".", newValue);
                                }
                                num4++;
                            }
                            num3++;
                        }
                    }
                    flag4 = true;
                }
            }
            return flag4;
        }

        private bool get_data_from_sap()
        {
            bool flag3;
            bool flag = false;
            try
            {
                WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_CHECK_SO_DO");
                WBSAP.rfcFunction.SetValue("ZWB_LOC", WBSetting.CoySAP);
                WBSAP.rfcFunction.SetValue("SO_NO", this.so_no.Trim());
                WBSAP.rfcFunction.SetValue("SO_ITEM", this.so_item.Trim());
                WBSAP.rfcFunction.SetValue("STO_NO", this.sto_no.Trim());
                WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                IRfcTable table = WBSAP.rfcFunction.GetTable("DO_DR_DETAILS");
                IRfcTable table2 = WBSAP.rfcFunction.GetTable("DO_DETAILS");
                if (WBSAP.rfcFunction.GetValue("MSG_ERROR").ToString() == "")
                {
                    this.num_of_dotrx = 0;
                    this.num_of_do = table2.RowCount;
                    this.num_of_dr = table.RowCount;
                    if (this.num_of_do > 0)
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num >= table2.RowCount)
                            {
                                break;
                            }
                            int index = 0;
                            while (true)
                            {
                                if (index >= 13)
                                {
                                    num++;
                                    break;
                                }
                                if (((index != 2) && ((index != 3) && ((index != 4) && (index != 5)))) && (index != 6))
                                {
                                    this.map[num, index] = table2[num].GetString(index).Trim();
                                }
                                else
                                {
                                    string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                                    this.map[num, index] = table2[num].GetString(index).Trim().Replace(".", newValue);
                                }
                                index++;
                            }
                        }
                    }
                    else if (this.num_of_dr > 0)
                    {
                        int num3 = 0;
                        while (true)
                        {
                            if (num3 >= table.RowCount)
                            {
                                break;
                            }
                            int index = 0;
                            while (true)
                            {
                                if (index >= 10)
                                {
                                    num3++;
                                    break;
                                }
                                if (((index != 2) && (index != 4)) && (index != 5))
                                {
                                    this.map[num3, index] = table[num3].GetString(index).Trim();
                                }
                                else
                                {
                                    string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                                    this.map[num3, index] = table[num3].GetString(index).Trim().Replace(".", newValue);
                                }
                                index++;
                            }
                        }
                    }
                    flag = true;
                }
                else
                {
                    MessageBox.Show("Error from SAP : " + WBSAP.rfcFunction.GetValue("MSG_ERROR").ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return false;
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error from SAP: " + exception.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                MessageBox.Show("DO SAP & Item is not found in SAP.\nPlease check again", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return false;
            }
            if (flag)
            {
                flag3 = true;
            }
            else
            {
                MessageBox.Show("DO SAP & Item is not longer valid in SAP.\nPlease choose another SO.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                flag3 = false;
            }
            return flag3;
        }

        private bool get_data_from_zdotrx()
        {
            bool flag = false;
            try
            {
                WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_SAP_TO_WBNET_ZDOTRX");
                WBSAP.rfcFunction.SetValue("_ZDCONR", this.txtInternalNum.Text.Trim());
                WBSAP.rfcFunction.SetValue("ZWB_LOC", WBSetting.CoySAP);
                WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                IRfcTable table = WBSAP.rfcFunction.GetTable("ITAB_ZDOTRX");
                this.num_of_dotrx = table.RowCount;
                this.num_of_do = this.num_of_dr = 0;
                if (WBSAP.rfcFunction.GetValue("MSG_ERR_HEADER").ToString() == "")
                {
                    if (this.num_of_dotrx > 0)
                    {
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= table.RowCount)
                            {
                                flag = true;
                                break;
                            }
                            int index = 0;
                            while (true)
                            {
                                if (index >= 0x17)
                                {
                                    num2++;
                                    break;
                                }
                                if (((index != 13) && (index != 15)) && (index != 0x10))
                                {
                                    this.map[num2, index] = table[num2].GetString(index).Trim();
                                }
                                else
                                {
                                    string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                                    this.map[num2, index] = table[num2].GetString(index).Trim().Replace(".", newValue);
                                }
                                index++;
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Error from SAP : " + WBSAP.rfcFunction.GetValue("MSG_ERR_HEADER").ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return false;
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error from SAP: " + exception.Message.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                MessageBox.Show("Loading Note is not found in SAP.\nPlease check again", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return false;
            }
            return flag;
        }

        private bool get_data_wb_zdo(string zdo)
        {
            bool flag5;
            WBTable table = new WBTable();
            table.OpenTable("wb_zdo", "Select internal_number, so, sto1, sto2, sto2_item, transporter, license_no, driver_name, truck_number, internal_number_item, do_item, sto1_item, comm_code, do_qty, do_uom, do_qty_kg, qty_base_uom, mark_accident, reason SPB_No, SPB_Item from wb_zdo where " + WBData.CompanyLocation(" and internal_number = '" + zdo + "'"), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                MessageBox.Show("Error : ZDOTRX No " + zdo + "Not Exist", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                flag5 = false;
            }
            else
            {
                this.num_of_dotrx = table.DT.Rows.Count;
                this.num_of_do = this.num_of_dr = 0;
                int num2 = 0;
                while (true)
                {
                    if (num2 >= table.DT.Rows.Count)
                    {
                        flag5 = true;
                        break;
                    }
                    int num3 = 0;
                    while (true)
                    {
                        if (num3 >= 0x16)
                        {
                            num2++;
                            break;
                        }
                        if (((num3 != 13) && (num3 != 15)) && (num3 != 0x10))
                        {
                            this.map[num2, num3] = table.DT.Rows[num2][num3].ToString().Trim();
                        }
                        else
                        {
                            string newValue = Convert.ToString(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                            this.map[num2, num3] = table.DT.Rows[num2][num3].ToString().Trim().Replace(".", newValue);
                        }
                        num3++;
                    }
                }
            }
            return flag5;
        }

        public void hideDOSAPForm(bool is_hiding)
        {
            if (is_hiding)
            {
                foreach (Label label in this.gb_do_sap.Controls.OfType<Label>())
                {
                    label.Hide();
                }
                foreach (TextBox box in this.gb_do_sap.Controls.OfType<TextBox>())
                {
                    box.Hide();
                }
            }
            else
            {
                foreach (Label label2 in this.gb_do_sap.Controls.OfType<Label>())
                {
                    label2.Show();
                }
                foreach (TextBox box2 in this.gb_do_sap.Controls.OfType<TextBox>())
                {
                    box2.Show();
                }
            }
            this.lbl_do_besar.Hide();
            if (!WBSetting.adopt_zdotrx)
            {
                this.txtInternalNum.ReadOnly = true;
                this.txtBox_QQ.Visible = false;
                this.lbl_QQ.Visible = false;
            }
            else
            {
                this.txtInternalNum.ReadOnly = false;
                this.txtBox_QQ.Visible = true;
                this.lbl_QQ.Visible = true;
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.labelDO = new Label();
            this.textDO = new TextBox();
            this.buttonDO = new Button();
            this.textCont = new TextBox();
            this.labelContractNo = new Label();
            this.textRCode = new TextBox();
            this.labelRelation = new Label();
            this.buttonSave = new Button();
            this.button2 = new Button();
            this.textComm = new TextBox();
            this.labelComm = new Label();
            this.labelDOQtyLeft = new Label();
            this.textEstate = new TextBox();
            this.labelEstate = new Label();
            this.textPI_No = new TextBox();
            this.labelPI_No = new Label();
            this.textTransporter = new TextBox();
            this.labelTransporter = new Label();
            this.labelKB = new Label();
            this.textOthNet = new TextBox();
            this.labelOtherNat = new Label();
            this.label13 = new Label();
            this.labelStorageName = new Label();
            this.buttonStorage = new Button();
            this.textStorage = new TextBox();
            this.labelStorage = new Label();
            this.labelZWB = new Label();
            this.toolTip1 = new ToolTip(this.components);
            this.btnFillContainer = new Button();
            this.labelQuantity = new Label();
            this.labelQtyLeft = new Label();
            this.but_sh_do_sap = new Button();
            this.text_do_sap = new TextBox();
            this.label2 = new Label();
            this.gb_do_sap = new GroupBox();
            this.txtBox_QQ = new TextBox();
            this.lbl_QQ = new Label();
            this.textSOItem_detail = new TextBox();
            this.labelSOItem_detail = new Label();
            this.lbl_do_besar = new Label();
            this.lblINitem = new Label();
            this.txtInNumItem = new TextBox();
            this.txtInternalNum = new TextBox();
            this.lblInternalNum = new Label();
            this.label22 = new Label();
            this.label23 = new Label();
            this.textBoxBaseUOM = new TextBox();
            this.textBoxQtyBaseUOM = new TextBox();
            this.label21 = new Label();
            this.text_do_sap_item = new TextBox();
            this.label20 = new Label();
            this.label19 = new Label();
            this.label18 = new Label();
            this.label17 = new Label();
            this.text_do_sap_unit = new TextBox();
            this.text_do_sap_qty = new TextBox();
            this.text_do_sap_qty_kg = new TextBox();
            this.buttonPISI = new Button();
            this.lbl_comm_name = new Label();
            this.textTransCode = new TextBox();
            this.labelTransCode = new Label();
            this.textRName = new TextBox();
            this.statusStrip1 = new StatusStrip();
            this.label6 = new Label();
            this.textFactNet = new TextBox();
            this.labelFactoryNet = new Label();
            this.panelSTO1DO = new Panel();
            this.text1DOSTO = new TextBox();
            this.label15 = new Label();
            this.text1STO = new TextBox();
            this.label14 = new Label();
            this.label16 = new Label();
            this.shapeContainer2 = new ShapeContainer();
            this.label1STO1DO = new Label();
            this.labelLoadingUOM = new Label();
            this.textBoxLoadingQty = new TextBox();
            this.labelLoadingQty = new Label();
            this.labelTransName = new TextBox();
            this.labelDN = new Label();
            this.txtDeliveryNote = new TextBox();
            this.label_loading_qty_opw_uom = new Label();
            this.text_opw_loading_qty = new TextBox();
            this.label_loading_qty_opw = new Label();
            this.gb_do_sap.SuspendLayout();
            this.panelSTO1DO.SuspendLayout();
            base.SuspendLayout();
            this.labelDO.Location = new Point(12, 0x2a);
            this.labelDO.Name = "labelDO";
            this.labelDO.Size = new Size(0x7f, 13);
            this.labelDO.TabIndex = 12;
            this.labelDO.Text = "WB DO No.";
            this.labelDO.TextAlign = ContentAlignment.MiddleRight;
            this.textDO.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textDO.Location = new Point(0x93, 0x25);
            this.textDO.MaxLength = 100;
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0x14e, 0x16);
            this.textDO.TabIndex = 0;
            this.textDO.TextChanged += new EventHandler(this.textDO_Changed);
            this.textDO.KeyPress += new KeyPressEventHandler(this.textCompany_KeyPress);
            this.textDO.Leave += new EventHandler(this.textDO_L);
            this.buttonDO.Location = new Point(0x1e6, 0x24);
            this.buttonDO.Margin = new Padding(0);
            this.buttonDO.Name = "buttonDO";
            this.buttonDO.Size = new Size(0x17, 0x17);
            this.buttonDO.TabIndex = 1;
            this.buttonDO.Text = "...";
            this.buttonDO.UseVisualStyleBackColor = true;
            this.buttonDO.Click += new EventHandler(this.buttonDO_Click);
            this.textCont.Location = new Point(0x93, 0x8f);
            this.textCont.Name = "textCont";
            this.textCont.ReadOnly = true;
            this.textCont.Size = new Size(180, 20);
            this.textCont.TabIndex = 7;
            this.labelContractNo.Location = new Point(12, 0x92);
            this.labelContractNo.Name = "labelContractNo";
            this.labelContractNo.Size = new Size(0x7f, 13);
            this.labelContractNo.TabIndex = 14;
            this.labelContractNo.Text = "Contract No.";
            this.labelContractNo.TextAlign = ContentAlignment.MiddleRight;
            this.textRCode.Location = new Point(0x93, 0xa9);
            this.textRCode.Name = "textRCode";
            this.textRCode.ReadOnly = true;
            this.textRCode.Size = new Size(0x68, 20);
            this.textRCode.TabIndex = 8;
            this.labelRelation.Location = new Point(12, 0xac);
            this.labelRelation.Name = "labelRelation";
            this.labelRelation.Size = new Size(0x7f, 13);
            this.labelRelation.TabIndex = 15;
            this.labelRelation.Text = "Relation";
            this.labelRelation.TextAlign = ContentAlignment.MiddleRight;
            this.buttonSave.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonSave.Location = new Point(0x35e, 0x18c);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x6c, 0x2f);
            this.buttonSave.TabIndex = 4;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.button2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x3d0, 0x18c);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x6c, 0x2f);
            this.button2.TabIndex = 5;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.textComm.Location = new Point(0x93, 0x75);
            this.textComm.Name = "textComm";
            this.textComm.ReadOnly = true;
            this.textComm.Size = new Size(180, 20);
            this.textComm.TabIndex = 6;
            this.labelComm.Location = new Point(12, 120);
            this.labelComm.Name = "labelComm";
            this.labelComm.Size = new Size(0x7f, 13);
            this.labelComm.TabIndex = 13;
            this.labelComm.Text = "Commodity";
            this.labelComm.TextAlign = ContentAlignment.MiddleRight;
            this.labelDOQtyLeft.AutoSize = true;
            this.labelDOQtyLeft.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelDOQtyLeft.Location = new Point(0x166, 0x90);
            this.labelDOQtyLeft.Name = "labelDOQtyLeft";
            this.labelDOQtyLeft.Size = new Size(0x77, 0x10);
            this.labelDOQtyLeft.TabIndex = 0x19;
            this.labelDOQtyLeft.Text = "DO Quantity Left";
            this.textEstate.AutoCompleteSource = AutoCompleteSource.RecentlyUsedList;
            this.textEstate.Location = new Point(0x93, 0xdd);
            this.textEstate.Name = "textEstate";
            this.textEstate.ReadOnly = true;
            this.textEstate.Size = new Size(180, 20);
            this.textEstate.TabIndex = 10;
            this.labelEstate.Location = new Point(12, 0xe0);
            this.labelEstate.Name = "labelEstate";
            this.labelEstate.Size = new Size(0x7f, 13);
            this.labelEstate.TabIndex = 0x11;
            this.labelEstate.Text = "Estate";
            this.labelEstate.TextAlign = ContentAlignment.MiddleRight;
            this.textPI_No.BackColor = SystemColors.ButtonHighlight;
            this.textPI_No.Location = new Point(0x93, 0x41);
            this.textPI_No.Name = "textPI_No";
            this.textPI_No.Size = new Size(0x88, 20);
            this.textPI_No.TabIndex = 13;
            this.textPI_No.KeyPress += new KeyPressEventHandler(this.textPINo_KeyPress);
            this.textPI_No.Leave += new EventHandler(this.textPINo_Leave);
            this.labelPI_No.Location = new Point(12, 0x44);
            this.labelPI_No.Name = "labelPI_No";
            this.labelPI_No.Size = new Size(0x7f, 13);
            this.labelPI_No.TabIndex = 0x22;
            this.labelPI_No.Text = "PI/SI No.";
            this.labelPI_No.TextAlign = ContentAlignment.MiddleRight;
            this.textTransporter.CharacterCasing = CharacterCasing.Upper;
            this.textTransporter.Location = new Point(0x93, 0xc3);
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.ReadOnly = true;
            this.textTransporter.Size = new Size(180, 20);
            this.textTransporter.TabIndex = 9;
            this.labelTransporter.Location = new Point(12, 0xc6);
            this.labelTransporter.Name = "labelTransporter";
            this.labelTransporter.Size = new Size(0x7f, 13);
            this.labelTransporter.TabIndex = 0x10;
            this.labelTransporter.Text = "Transporter";
            this.labelTransporter.TextAlign = ContentAlignment.MiddleRight;
            this.labelKB.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelKB.Location = new Point(900, 5);
            this.labelKB.Name = "labelKB";
            this.labelKB.Size = new Size(0xb8, 20);
            this.labelKB.TabIndex = 0x18;
            this.labelKB.Text = "*Kawasan Berikat";
            this.labelKB.TextAlign = ContentAlignment.MiddleRight;
            this.textOthNet.AutoCompleteSource = AutoCompleteSource.RecentlyUsedList;
            this.textOthNet.Location = new Point(0x93, 0x135);
            this.textOthNet.Name = "textOthNet";
            this.textOthNet.Size = new Size(0x53, 20);
            this.textOthNet.TabIndex = 1;
            this.textOthNet.Text = "0";
            this.textOthNet.TextAlign = HorizontalAlignment.Right;
            this.textOthNet.KeyPress += new KeyPressEventHandler(this.textFactNet_KeyPress);
            this.textOthNet.Leave += new EventHandler(this.textOthNet_Leave);
            this.labelOtherNat.Location = new Point(12, 0x138);
            this.labelOtherNat.Name = "labelOtherNat";
            this.labelOtherNat.Size = new Size(0x7f, 13);
            this.labelOtherNat.TabIndex = 40;
            this.labelOtherNat.Text = "Other Nett";
            this.labelOtherNat.TextAlign = ContentAlignment.MiddleRight;
            this.label13.AutoSize = true;
            this.label13.Location = new Point(0xec, 0x138);
            this.label13.Name = "label13";
            this.label13.Size = new Size(20, 13);
            this.label13.TabIndex = 0x29;
            this.label13.Text = "Kg";
            this.labelStorageName.AutoSize = true;
            this.labelStorageName.Location = new Point(260, 0xfc);
            this.labelStorageName.Name = "labelStorageName";
            this.labelStorageName.Size = new Size(0x1c, 13);
            this.labelStorageName.TabIndex = 0x1a;
            this.labelStorageName.Text = "       ";
            this.buttonStorage.Location = new Point(0x120, 0xf7);
            this.buttonStorage.Margin = new Padding(0);
            this.buttonStorage.Name = "buttonStorage";
            this.buttonStorage.Size = new Size(0x17, 0x17);
            this.buttonStorage.TabIndex = 3;
            this.buttonStorage.Text = "...";
            this.buttonStorage.UseVisualStyleBackColor = true;
            this.buttonStorage.Click += new EventHandler(this.buttonStorage_Click);
            this.textStorage.CharacterCasing = CharacterCasing.Upper;
            this.textStorage.Location = new Point(0x93, 0xf9);
            this.textStorage.MaxLength = 5;
            this.textStorage.Name = "textStorage";
            this.textStorage.Size = new Size(0x89, 20);
            this.textStorage.TabIndex = 2;
            this.textStorage.Leave += new EventHandler(this.textStorage_Leave);
            this.labelStorage.Location = new Point(12, 0xfd);
            this.labelStorage.Name = "labelStorage";
            this.labelStorage.Size = new Size(0x7f, 13);
            this.labelStorage.TabIndex = 0x12;
            this.labelStorage.Text = "Storage";
            this.labelStorage.TextAlign = ContentAlignment.MiddleRight;
            this.labelZWB.AutoSize = true;
            this.labelZWB.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelZWB.ForeColor = Color.Red;
            this.labelZWB.Location = new Point(0x8e, 5);
            this.labelZWB.Name = "labelZWB";
            this.labelZWB.Size = new Size(0xe4, 20);
            this.labelZWB.TabIndex = 0x13;
            this.labelZWB.Text = "Please sync this WB DO to ";
            this.labelZWB.Visible = false;
            this.btnFillContainer.Location = new Point(0x21f, 0x1f);
            this.btnFillContainer.Name = "btnFillContainer";
            this.btnFillContainer.Size = new Size(150, 0x21);
            this.btnFillContainer.TabIndex = 0x6d;
            this.btnFillContainer.Text = "Fill &DO Container";
            this.toolTip1.SetToolTip(this.btnFillContainer, "Fill this DO to Container\r\nShortcut : Alt+D");
            this.btnFillContainer.UseVisualStyleBackColor = true;
            this.btnFillContainer.Click += new EventHandler(this.btnFillContainer_Click);
            this.labelQuantity.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelQuantity.Location = new Point(0x23f, 0x8f);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new Size(0x79, 0x10);
            this.labelQuantity.TabIndex = 0x4f;
            this.labelQuantity.Text = "/ 0";
            this.labelQtyLeft.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelQtyLeft.Location = new Point(0x1dd, 0x8f);
            this.labelQtyLeft.Name = "labelQtyLeft";
            this.labelQtyLeft.Size = new Size(0x65, 0x10);
            this.labelQtyLeft.TabIndex = 20;
            this.labelQtyLeft.Text = "0";
            this.labelQtyLeft.TextAlign = ContentAlignment.TopRight;
            this.but_sh_do_sap.Location = new Point(14, 0x15);
            this.but_sh_do_sap.Margin = new Padding(0);
            this.but_sh_do_sap.Name = "but_sh_do_sap";
            this.but_sh_do_sap.Size = new Size(0x52, 0x17);
            this.but_sh_do_sap.TabIndex = 0x56;
            this.but_sh_do_sap.Text = "Choose DO ";
            this.but_sh_do_sap.UseVisualStyleBackColor = true;
            this.but_sh_do_sap.Click += new EventHandler(this.but_sh_do_sap_Click);
            this.text_do_sap.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.text_do_sap.Location = new Point(0x66, 0x52);
            this.text_do_sap.MaxLength = 100;
            this.text_do_sap.Name = "text_do_sap";
            this.text_do_sap.ReadOnly = true;
            this.text_do_sap.Size = new Size(0x76, 0x16);
            this.text_do_sap.TabIndex = 0x55;
            this.label2.Location = new Point(12, 0x57);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x54, 13);
            this.label2.TabIndex = 0x57;
            this.label2.Text = "DO ";
            this.gb_do_sap.Controls.Add(this.txtBox_QQ);
            this.gb_do_sap.Controls.Add(this.lbl_QQ);
            this.gb_do_sap.Controls.Add(this.textSOItem_detail);
            this.gb_do_sap.Controls.Add(this.labelSOItem_detail);
            this.gb_do_sap.Controls.Add(this.lbl_do_besar);
            this.gb_do_sap.Controls.Add(this.lblINitem);
            this.gb_do_sap.Controls.Add(this.txtInNumItem);
            this.gb_do_sap.Controls.Add(this.txtInternalNum);
            this.gb_do_sap.Controls.Add(this.lblInternalNum);
            this.gb_do_sap.Controls.Add(this.label22);
            this.gb_do_sap.Controls.Add(this.label23);
            this.gb_do_sap.Controls.Add(this.textBoxBaseUOM);
            this.gb_do_sap.Controls.Add(this.textBoxQtyBaseUOM);
            this.gb_do_sap.Controls.Add(this.label21);
            this.gb_do_sap.Controls.Add(this.text_do_sap_item);
            this.gb_do_sap.Controls.Add(this.label20);
            this.gb_do_sap.Controls.Add(this.label19);
            this.gb_do_sap.Controls.Add(this.label18);
            this.gb_do_sap.Controls.Add(this.label17);
            this.gb_do_sap.Controls.Add(this.text_do_sap_unit);
            this.gb_do_sap.Controls.Add(this.text_do_sap_qty);
            this.gb_do_sap.Controls.Add(this.text_do_sap_qty_kg);
            this.gb_do_sap.Controls.Add(this.but_sh_do_sap);
            this.gb_do_sap.Controls.Add(this.text_do_sap);
            this.gb_do_sap.Controls.Add(this.label2);
            this.gb_do_sap.Location = new Point(0x2ce, 0x18);
            this.gb_do_sap.Name = "gb_do_sap";
            this.gb_do_sap.Size = new Size(0x16d, 0xfc);
            this.gb_do_sap.TabIndex = 0x58;
            this.gb_do_sap.TabStop = false;
            this.gb_do_sap.Text = "DO ";
            this.gb_do_sap.Visible = false;
            this.txtBox_QQ.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtBox_QQ.Location = new Point(0x66, 0xd6);
            this.txtBox_QQ.MaxLength = 100;
            this.txtBox_QQ.Name = "txtBox_QQ";
            this.txtBox_QQ.ReadOnly = true;
            this.txtBox_QQ.Size = new Size(0xfe, 0x16);
            this.txtBox_QQ.TabIndex = 0x71;
            this.lbl_QQ.Location = new Point(12, 0xdb);
            this.lbl_QQ.Name = "lbl_QQ";
            this.lbl_QQ.Size = new Size(0x54, 13);
            this.lbl_QQ.TabIndex = 0x72;
            this.lbl_QQ.Text = "Customer QQ";
            this.textSOItem_detail.Location = new Point(0x66, 0x38);
            this.textSOItem_detail.MaxLength = 6;
            this.textSOItem_detail.Name = "textSOItem_detail";
            this.textSOItem_detail.ReadOnly = true;
            this.textSOItem_detail.Size = new Size(80, 20);
            this.textSOItem_detail.TabIndex = 0x70;
            this.textSOItem_detail.TextAlign = HorizontalAlignment.Right;
            this.labelSOItem_detail.Location = new Point(12, 0x3b);
            this.labelSOItem_detail.Name = "labelSOItem_detail";
            this.labelSOItem_detail.Size = new Size(0x54, 13);
            this.labelSOItem_detail.TabIndex = 0x6f;
            this.labelSOItem_detail.Text = "SO Item";
            this.lbl_do_besar.AutoSize = true;
            this.lbl_do_besar.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.lbl_do_besar.ForeColor = Color.DarkGreen;
            this.lbl_do_besar.Location = new Point(0x110, 0x3e);
            this.lbl_do_besar.Name = "lbl_do_besar";
            this.lbl_do_besar.Size = new Size(70, 13);
            this.lbl_do_besar.TabIndex = 0x69;
            this.lbl_do_besar.Text = "DO BESAR";
            this.lblINitem.AutoSize = true;
            this.lblINitem.Location = new Point(0xde, 0x6f);
            this.lblINitem.Name = "lblINitem";
            this.lblINitem.Size = new Size(0x1b, 13);
            this.lblINitem.TabIndex = 0x68;
            this.lblINitem.Text = "Item";
            this.txtInNumItem.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtInNumItem.Location = new Point(0xf9, 0x6b);
            this.txtInNumItem.MaxLength = 100;
            this.txtInNumItem.Name = "txtInNumItem";
            this.txtInNumItem.ReadOnly = true;
            this.txtInNumItem.Size = new Size(0x3b, 0x16);
            this.txtInNumItem.TabIndex = 0x67;
            this.txtInternalNum.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.txtInternalNum.Location = new Point(0x66, 0x6c);
            this.txtInternalNum.MaxLength = 100;
            this.txtInternalNum.Name = "txtInternalNum";
            this.txtInternalNum.ReadOnly = true;
            this.txtInternalNum.Size = new Size(0x76, 0x16);
            this.txtInternalNum.TabIndex = 0x65;
            this.lblInternalNum.Location = new Point(11, 0x70);
            this.lblInternalNum.Name = "lblInternalNum";
            this.lblInternalNum.Size = new Size(0x54, 13);
            this.lblInternalNum.TabIndex = 0x66;
            this.lblInternalNum.Text = "Internal No";
            this.label22.AutoSize = true;
            this.label22.Location = new Point(190, 0xbf);
            this.label22.Name = "label22";
            this.label22.Size = new Size(30, 13);
            this.label22.TabIndex = 100;
            this.label22.Text = "UoM";
            this.label23.Location = new Point(12, 0xbf);
            this.label23.Name = "label23";
            this.label23.Size = new Size(0x54, 13);
            this.label23.TabIndex = 0x63;
            this.label23.Text = "Base Quantity";
            this.textBoxBaseUOM.Location = new Point(0xdf, 0xbc);
            this.textBoxBaseUOM.Name = "textBoxBaseUOM";
            this.textBoxBaseUOM.ReadOnly = true;
            this.textBoxBaseUOM.Size = new Size(0x30, 20);
            this.textBoxBaseUOM.TabIndex = 0x62;
            this.textBoxQtyBaseUOM.Location = new Point(0x66, 0xbc);
            this.textBoxQtyBaseUOM.Name = "textBoxQtyBaseUOM";
            this.textBoxQtyBaseUOM.ReadOnly = true;
            this.textBoxQtyBaseUOM.Size = new Size(80, 20);
            this.textBoxQtyBaseUOM.TabIndex = 0x61;
            this.textBoxQtyBaseUOM.TextAlign = HorizontalAlignment.Right;
            this.textBoxQtyBaseUOM.TextChanged += new EventHandler(this.textBoxQtyBaseUOM_TextChanged);
            this.label21.AutoSize = true;
            this.label21.Location = new Point(0xde, 0x55);
            this.label21.Name = "label21";
            this.label21.Size = new Size(0x1b, 13);
            this.label21.TabIndex = 0x60;
            this.label21.Text = "Item";
            this.text_do_sap_item.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.text_do_sap_item.Location = new Point(0xf9, 0x51);
            this.text_do_sap_item.MaxLength = 100;
            this.text_do_sap_item.Name = "text_do_sap_item";
            this.text_do_sap_item.ReadOnly = true;
            this.text_do_sap_item.Size = new Size(0x3b, 0x16);
            this.text_do_sap_item.TabIndex = 0x5f;
            this.label20.AutoSize = true;
            this.label20.Location = new Point(0x115, 0x8b);
            this.label20.Name = "label20";
            this.label20.Size = new Size(0x16, 13);
            this.label20.TabIndex = 0x5e;
            this.label20.Text = "KG";
            this.label19.AutoSize = true;
            this.label19.Location = new Point(190, 0xa5);
            this.label19.Name = "label19";
            this.label19.Size = new Size(30, 13);
            this.label19.TabIndex = 0x5d;
            this.label19.Text = "UoM";
            this.label18.Location = new Point(12, 0xa5);
            this.label18.Name = "label18";
            this.label18.Size = new Size(0x54, 13);
            this.label18.TabIndex = 0x5c;
            this.label18.Text = "Quantity";
            this.label17.Location = new Point(11, 0x8b);
            this.label17.Name = "label17";
            this.label17.Size = new Size(0x54, 13);
            this.label17.TabIndex = 0x5b;
            this.label17.Text = "Quantity in KG";
            this.text_do_sap_unit.Location = new Point(0xdf, 0xa2);
            this.text_do_sap_unit.Name = "text_do_sap_unit";
            this.text_do_sap_unit.ReadOnly = true;
            this.text_do_sap_unit.Size = new Size(0x30, 20);
            this.text_do_sap_unit.TabIndex = 0x59;
            this.text_do_sap_qty.Location = new Point(0x66, 0xa2);
            this.text_do_sap_qty.Name = "text_do_sap_qty";
            this.text_do_sap_qty.ReadOnly = true;
            this.text_do_sap_qty.Size = new Size(80, 20);
            this.text_do_sap_qty.TabIndex = 0x58;
            this.text_do_sap_qty.TextAlign = HorizontalAlignment.Right;
            this.text_do_sap_qty_kg.Location = new Point(0x66, 0x88);
            this.text_do_sap_qty_kg.Name = "text_do_sap_qty_kg";
            this.text_do_sap_qty_kg.ReadOnly = true;
            this.text_do_sap_qty_kg.Size = new Size(0xa9, 20);
            this.text_do_sap_qty_kg.TabIndex = 0;
            this.text_do_sap_qty_kg.Text = "0";
            this.text_do_sap_qty_kg.TextAlign = HorizontalAlignment.Right;
            this.buttonPISI.Location = new Point(0x120, 0x3f);
            this.buttonPISI.Margin = new Padding(0);
            this.buttonPISI.Name = "buttonPISI";
            this.buttonPISI.Size = new Size(0x17, 0x17);
            this.buttonPISI.TabIndex = 0x59;
            this.buttonPISI.Text = "...";
            this.buttonPISI.UseVisualStyleBackColor = true;
            this.buttonPISI.Click += new EventHandler(this.buttonPISI_Click);
            this.lbl_comm_name.AutoSize = true;
            this.lbl_comm_name.Location = new Point(0x14d, 120);
            this.lbl_comm_name.Name = "lbl_comm_name";
            this.lbl_comm_name.Size = new Size(0x1f, 13);
            this.lbl_comm_name.TabIndex = 0x60;
            this.lbl_comm_name.Text = "        ";
            this.textTransCode.Location = new Point(0x93, 0x5b);
            this.textTransCode.Name = "textTransCode";
            this.textTransCode.ReadOnly = true;
            this.textTransCode.Size = new Size(0x68, 20);
            this.textTransCode.TabIndex = 0x61;
            this.labelTransCode.Location = new Point(12, 0x5e);
            this.labelTransCode.Name = "labelTransCode";
            this.labelTransCode.Size = new Size(0x7f, 13);
            this.labelTransCode.TabIndex = 0x62;
            this.labelTransCode.Text = "Transaction Code";
            this.labelTransCode.TextAlign = ContentAlignment.MiddleRight;
            this.textRName.Location = new Point(0x101, 0xa9);
            this.textRName.Name = "textRName";
            this.textRName.ReadOnly = true;
            this.textRName.Size = new Size(0x1b1, 20);
            this.textRName.TabIndex = 11;
            this.statusStrip1.Location = new Point(0, 0x1ca);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(0x454, 0x16);
            this.statusStrip1.TabIndex = 100;
            this.statusStrip1.Text = "statusStrip1";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0xec, 0x152);
            this.label6.Name = "label6";
            this.label6.Size = new Size(20, 13);
            this.label6.TabIndex = 0x67;
            this.label6.Text = "Kg";
            this.textFactNet.Location = new Point(0x93, 0x14f);
            this.textFactNet.Name = "textFactNet";
            this.textFactNet.Size = new Size(0x53, 20);
            this.textFactNet.TabIndex = 0x65;
            this.textFactNet.Text = "0";
            this.textFactNet.TextAlign = HorizontalAlignment.Right;
            this.textFactNet.KeyPress += new KeyPressEventHandler(this.textFactNet_KeyPress);
            this.labelFactoryNet.Location = new Point(12, 0x152);
            this.labelFactoryNet.Name = "labelFactoryNet";
            this.labelFactoryNet.Size = new Size(0x7f, 13);
            this.labelFactoryNet.TabIndex = 0x66;
            this.labelFactoryNet.Text = "Factory Nett";
            this.labelFactoryNet.TextAlign = ContentAlignment.MiddleRight;
            this.panelSTO1DO.Controls.Add(this.text1DOSTO);
            this.panelSTO1DO.Controls.Add(this.label15);
            this.panelSTO1DO.Controls.Add(this.text1STO);
            this.panelSTO1DO.Controls.Add(this.label14);
            this.panelSTO1DO.Controls.Add(this.label16);
            this.panelSTO1DO.Controls.Add(this.shapeContainer2);
            this.panelSTO1DO.Location = new Point(0x31a, 0x124);
            this.panelSTO1DO.Name = "panelSTO1DO";
            this.panelSTO1DO.Size = new Size(0x121, 0x5f);
            this.panelSTO1DO.TabIndex = 0x69;
            this.text1DOSTO.CharacterCasing = CharacterCasing.Upper;
            this.text1DOSTO.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.text1DOSTO.Location = new Point(0x73, 0x3a);
            this.text1DOSTO.MaxLength = 20;
            this.text1DOSTO.Name = "text1DOSTO";
            this.text1DOSTO.Size = new Size(0xa5, 0x1a);
            this.text1DOSTO.TabIndex = 1;
            this.label15.AutoSize = true;
            this.label15.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label15.Location = new Point(50, 0x40);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x3b, 0x10);
            this.label15.TabIndex = 4;
            this.label15.Text = "DO STO";
            this.text1STO.CharacterCasing = CharacterCasing.Upper;
            this.text1STO.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.text1STO.Location = new Point(0x73, 0x1b);
            this.text1STO.MaxLength = 20;
            this.text1STO.Name = "text1STO";
            this.text1STO.Size = new Size(0xa5, 0x1a);
            this.text1STO.TabIndex = 0;
            this.label14.AutoSize = true;
            this.label14.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label14.Location = new Point(0x49, 0x21);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x24, 0x10);
            this.label14.TabIndex = 3;
            this.label14.Text = "STO";
            this.label16.AutoSize = true;
            this.label16.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label16.Location = new Point(0xb3, 8);
            this.label16.Name = "label16";
            this.label16.Size = new Size(0x65, 13);
            this.label16.TabIndex = 2;
            this.label16.Text = "* for 1xSTO = 1xDO";
            this.shapeContainer2.Location = new Point(0, 0);
            this.shapeContainer2.Margin = new Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            this.shapeContainer2.Size = new Size(0x121, 0x5f);
            this.shapeContainer2.TabIndex = 5;
            this.shapeContainer2.TabStop = false;
            this.label1STO1DO.AutoSize = true;
            this.label1STO1DO.Location = new Point(0x3e2, 0x117);
            this.label1STO1DO.Name = "label1STO1DO";
            this.label1STO1DO.Size = new Size(0x59, 13);
            this.label1STO1DO.TabIndex = 0x68;
            this.label1STO1DO.Text = "*1x STO = 1x DO";
            this.labelLoadingUOM.AutoSize = true;
            this.labelLoadingUOM.Location = new Point(0xec, 0x17a);
            this.labelLoadingUOM.Name = "labelLoadingUOM";
            this.labelLoadingUOM.Size = new Size(20, 13);
            this.labelLoadingUOM.TabIndex = 0x6c;
            this.labelLoadingUOM.Text = "Kg";
            this.textBoxLoadingQty.Location = new Point(0x93, 0x177);
            this.textBoxLoadingQty.Name = "textBoxLoadingQty";
            this.textBoxLoadingQty.Size = new Size(0x53, 20);
            this.textBoxLoadingQty.TabIndex = 0x6a;
            this.textBoxLoadingQty.Text = "0";
            this.textBoxLoadingQty.TextAlign = HorizontalAlignment.Right;
            this.textBoxLoadingQty.KeyPress += new KeyPressEventHandler(this.textBoxLoadingQty_KeyPress);
            this.textBoxLoadingQty.Leave += new EventHandler(this.textBoxLoadingQty_Leave);
            this.labelLoadingQty.Location = new Point(12, 0x17a);
            this.labelLoadingQty.Name = "labelLoadingQty";
            this.labelLoadingQty.Size = new Size(0x7f, 13);
            this.labelLoadingQty.TabIndex = 0x6b;
            this.labelLoadingQty.Text = "Loading Qty";
            this.labelLoadingQty.TextAlign = ContentAlignment.MiddleRight;
            this.labelTransName.Location = new Point(0x101, 0x5b);
            this.labelTransName.Name = "labelTransName";
            this.labelTransName.ReadOnly = true;
            this.labelTransName.Size = new Size(220, 20);
            this.labelTransName.TabIndex = 110;
            this.labelDN.AutoSize = true;
            this.labelDN.Location = new Point(0x47, 0x115);
            this.labelDN.Name = "labelDN";
            this.labelDN.Size = new Size(0x47, 13);
            this.labelDN.TabIndex = 0x70;
            this.labelDN.Text = "Delivery Note";
            this.txtDeliveryNote.Location = new Point(0x93, 0x112);
            this.txtDeliveryNote.Name = "txtDeliveryNote";
            this.txtDeliveryNote.Size = new Size(0xb5, 20);
            this.txtDeliveryNote.TabIndex = 0x6f;
            this.label_loading_qty_opw_uom.AutoSize = true;
            this.label_loading_qty_opw_uom.Location = new Point(0xec, 0x194);
            this.label_loading_qty_opw_uom.Name = "label_loading_qty_opw_uom";
            this.label_loading_qty_opw_uom.Size = new Size(20, 13);
            this.label_loading_qty_opw_uom.TabIndex = 0x73;
            this.label_loading_qty_opw_uom.Text = "Kg";
            this.text_opw_loading_qty.Location = new Point(0x92, 0x191);
            this.text_opw_loading_qty.Name = "text_opw_loading_qty";
            this.text_opw_loading_qty.Size = new Size(0x53, 20);
            this.text_opw_loading_qty.TabIndex = 0x71;
            this.text_opw_loading_qty.Text = "0";
            this.text_opw_loading_qty.TextAlign = HorizontalAlignment.Right;
            this.text_opw_loading_qty.KeyPress += new KeyPressEventHandler(this.text_opw_loading_qty_KeyPress);
            this.text_opw_loading_qty.Leave += new EventHandler(this.textBoxLoadingQty_Leave);
            this.label_loading_qty_opw.AutoSize = true;
            this.label_loading_qty_opw.Location = new Point(0x13, 0x194);
            this.label_loading_qty_opw.Name = "label_loading_qty_opw";
            this.label_loading_qty_opw.Size = new Size(120, 13);
            this.label_loading_qty_opw.TabIndex = 0x72;
            this.label_loading_qty_opw.Text = "Other Party Loading Qty";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x454, 480);
            base.ControlBox = false;
            base.Controls.Add(this.label_loading_qty_opw_uom);
            base.Controls.Add(this.text_opw_loading_qty);
            base.Controls.Add(this.label_loading_qty_opw);
            base.Controls.Add(this.labelDN);
            base.Controls.Add(this.txtDeliveryNote);
            base.Controls.Add(this.labelTransName);
            base.Controls.Add(this.btnFillContainer);
            base.Controls.Add(this.labelLoadingUOM);
            base.Controls.Add(this.textBoxLoadingQty);
            base.Controls.Add(this.labelLoadingQty);
            base.Controls.Add(this.panelSTO1DO);
            base.Controls.Add(this.label1STO1DO);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.textFactNet);
            base.Controls.Add(this.labelFactoryNet);
            base.Controls.Add(this.statusStrip1);
            base.Controls.Add(this.textTransCode);
            base.Controls.Add(this.labelTransCode);
            base.Controls.Add(this.lbl_comm_name);
            base.Controls.Add(this.buttonPISI);
            base.Controls.Add(this.gb_do_sap);
            base.Controls.Add(this.labelQtyLeft);
            base.Controls.Add(this.labelQuantity);
            base.Controls.Add(this.buttonStorage);
            base.Controls.Add(this.textStorage);
            base.Controls.Add(this.labelStorage);
            base.Controls.Add(this.labelStorageName);
            base.Controls.Add(this.label13);
            base.Controls.Add(this.textOthNet);
            base.Controls.Add(this.labelOtherNat);
            base.Controls.Add(this.labelKB);
            base.Controls.Add(this.textTransporter);
            base.Controls.Add(this.labelTransporter);
            base.Controls.Add(this.textPI_No);
            base.Controls.Add(this.labelPI_No);
            base.Controls.Add(this.textEstate);
            base.Controls.Add(this.labelEstate);
            base.Controls.Add(this.labelDOQtyLeft);
            base.Controls.Add(this.textComm);
            base.Controls.Add(this.labelComm);
            base.Controls.Add(this.textRName);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.textRCode);
            base.Controls.Add(this.labelRelation);
            base.Controls.Add(this.textCont);
            base.Controls.Add(this.labelContractNo);
            base.Controls.Add(this.buttonDO);
            base.Controls.Add(this.textDO);
            base.Controls.Add(this.labelDO);
            base.Controls.Add(this.labelZWB);
            base.KeyPreview = true;
            base.Name = "FormRegisDOEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Entry DO";
            base.Load += new EventHandler(this.FormTransDOEntry_Load);
            base.Shown += new EventHandler(this.FormTransDOEntry_Shown);
            this.gb_do_sap.ResumeLayout(false);
            this.gb_do_sap.PerformLayout();
            this.panelSTO1DO.ResumeLayout(false);
            this.panelSTO1DO.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void SetDOSAP(DataRow pDoRow)
        {
            this.wCond = new WBCondition();
            this.hideDOSAPForm(false);
            this.retTable_DSAP_DO = new DataGridView();
            this.retTable_DSAP_DOTRX = new DataGridView();
            this.retTable_DSAP_DR = new DataGridView();
            this.tblComm.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + pDoRow["comm_code"] + "'"), WBData.conn);
            DataRow[] dgRows = new DataRow[] { pDoRow, this.tblComm.DT.Rows[0] };
            this.wCond.fillParameter("ACTIVE_ADOPT_ZDOTRX", dgRows);
            if (this.wCond.getResult())
            {
                this.active_require_do = false;
                this.active_zdotrx = true;
                this.lblInternalNum.Text = "Loading Note";
                this.gb_do_sap.Visible = true;
                this.txtBox_QQ.Visible = true;
                this.lbl_QQ.Visible = true;
            }
            else if (((Program.getFieldValue("wb_transaction_type", "trx_require_internal_no", "transaction_code", pDoRow["transaction_code"].ToString()) == "Y") && (this.CommType == "S")) && (this.isTrade2 == "T"))
            {
                this.gb_do_sap.Visible = true;
                this.active_require_do = true;
                this.txtBox_QQ.Visible = true;
                this.lbl_QQ.Visible = true;
                this.active_zdotrx = false;
                this.lblInternalNum.Text = "Internal No";
            }
            else
            {
                this.active_require_do = false;
                this.active_zdotrx = false;
                this.gb_do_sap.Visible = false;
                this.text_do_sap.Text = "";
                this.txtInternalNum.Text = "";
                this.txtInNumItem.Text = "";
                this.text_do_sap_item.Text = "";
                this.txtBox_QQ.Text = "";
                this.text_do_sap_qty.Text = "";
                this.text_do_sap_unit.Text = "";
                this.text_do_sap_qty_kg.Text = "";
                this.textBoxQtyBaseUOM.Text = "";
                this.textBoxBaseUOM.Text = "";
                this.textSOItem_detail.Text = "";
            }
            if (!(this.gb_do_sap.Visible && (WBSetting.IntegrationSAP == "Y")))
            {
                if (!WBSetting.adopt_zdotrx)
                {
                    this.but_sh_do_sap.Enabled = WBSetting.integrationIDSYS;
                    this.but_sh_do_sap.Visible = true;
                }
                else
                {
                    this.but_sh_do_sap.Enabled = true;
                    this.but_sh_do_sap.Visible = true;
                }
                this.text_do_sap.ReadOnly = false;
                this.text_do_sap_item.ReadOnly = false;
                this.txtInternalNum.ReadOnly = false;
                this.txtInNumItem.ReadOnly = false;
                this.textSOItem_detail.ReadOnly = false;
            }
            else
            {
                if (!WBSetting.adopt_zdotrx)
                {
                    this.txtInternalNum.ReadOnly = true;
                    this.txtBox_QQ.Visible = false;
                    this.lbl_QQ.Visible = false;
                }
                else
                {
                    this.txtInternalNum.ReadOnly = false;
                    this.txtBox_QQ.Visible = true;
                    this.lbl_QQ.Visible = true;
                }
                this.text_do_sap.ReadOnly = true;
                this.text_do_sap_item.ReadOnly = true;
                this.txtInNumItem.ReadOnly = true;
                this.but_sh_do_sap.Visible = true;
                this.textSOItem_detail.ReadOnly = true;
            }
        }

        private void text_opw_loading_qty_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox) sender;
            this.checkDecimalOnKeyPress(textBox, e);
        }

        private void textBoxLoadingQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox) sender;
            this.checkDecimalOnKeyPress(textBox, e);
        }

        private void textBoxLoadingQty_Leave(object sender, EventArgs e)
        {
            TextBox box = (TextBox) sender;
            if (!Program.CheckNumericForLoadingQty(box.Text))
            {
                box.Text = "0";
            }
        }

        private void textBoxQtyBaseUOM_TextChanged(object sender, EventArgs e)
        {
            string[] source = new string[] { ".", "," };
            if (source.Any<string>(s => this.textBoxQtyBaseUOM.Text.Contains(s)))
            {
                MessageBox.Show(Resource.Error_Conversion_DOSAP + this.sapIDSYS, "WARNING...", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.buttonSave.Enabled = false;
            }
        }

        private void textCompany_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDO_Changed(object sender, EventArgs e)
        {
            if (this.textDO.Text != "")
            {
                this.text_do_sap.Text = "";
                this.txtInternalNum.Text = "";
                this.txtInNumItem.Text = "";
                this.text_do_sap_item.Text = "";
                this.text_do_sap_qty.Text = "";
                this.text_do_sap_unit.Text = "";
                this.text_do_sap_qty_kg.Text = "";
                this.textBoxQtyBaseUOM.Text = "";
                this.textBoxBaseUOM.Text = "";
                this.textSOItem_detail.Text = "";
                this.txtBox_QQ.Text = "";
                this.hideDOSAPForm(false);
                this.retTable_DSAP_DO = new DataGridView();
                this.retTable_DSAP_DOTRX = new DataGridView();
                this.retTable_DSAP_DR = new DataGridView();
            }
        }

        private void textDO_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDO_L(object sender, EventArgs e)
        {
            DataRow data;
            if (this.textDO.Text != "")
            {
                this.textDO.Text = this.textDO.Text.Trim();
                this.tblDO.ReOpen();
                string[] aField = new string[] { "Do_No" };
                string[] aFind = new string[] { this.textDO.Text.Trim() };
                data = this.tblDO.GetData(aField, aFind);
                if (!ReferenceEquals(data, null))
                {
                    if (data["closed"].ToString() != "X")
                    {
                        string[] textArray3 = new string[] { "Transaction_code" };
                        string[] textArray4 = new string[] { data["transaction_code"].ToString() };
                        DataRow data = this.tblTType.GetData(textArray3, textArray4);
                        this.IO = data["IO"].ToString();
                        this.tblComm.OpenTable("wb_comm", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + data["Comm_Code"].ToString() + "'"), WBData.conn);
                        string[] textArray5 = new string[] { "comm_code" };
                        string[] textArray6 = new string[] { data["Comm_Code"].ToString() };
                        DataRow row3 = this.tblComm.GetData(textArray5, textArray6);
                        this.tblVesselMap.OpenTable("wb_vessel_map", "SELECT uniq_item, qty_map, completed from wb_vessel_map where uniq_vessel = '" + data["uniq"].ToString() + "'", WBData.conn);
                        if (this.tblVesselMap.DT.Rows.Count > 0)
                        {
                            DataRow row4 = this.tblVesselMap.DT.Rows[0];
                            if ((data["is_vessel"].ToString() == "Y") && (row4["completed"].ToString() == "Y"))
                            {
                                MessageBox.Show("DO Vessel is already completed", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                this.textDO.Focus();
                                return;
                            }
                        }
                        if ((((data["DeductedBy"].ToString() != "1") || this.nopw) || (this.IO != "I")) || ((this.totalNetEstate.ToString() != "0") && (this.totalNetEstate.ToString() != "")))
                        {
                            if (data["zAuto"].ToString() != "Y")
                            {
                                if ((WBSetting.Field("GM") != "Y") || (data["completedGRCust"].ToString() != "N"))
                                {
                                    if (!this.CheckPeriodDO(data, this.refDate))
                                    {
                                        WBTable table = new WBTable();
                                        table.OpenTable("wb_vessel_map", "SELECT * FROM wb_vessel_map WHERE uniq_item ='" + data["uniq"].ToString() + "'", WBData.conn);
                                        if (table.DT.Rows.Count <= 0)
                                        {
                                            table.Dispose();
                                            if (Program.getFieldValue("wb_transaction_type", "is_vessel", "transaction_code", data["transaction_code"].ToString()) != "Y")
                                            {
                                                goto TR_0011;
                                            }
                                            else
                                            {
                                                WBTable table2 = new WBTable();
                                                table2.OpenTable("wb_vessel_map", "SELECT * FROM wb_vessel_map WHERE uniq_vessel ='" + data["uniq"].ToString() + "'", WBData.conn);
                                                if (table2.DT.Rows.Count != 0)
                                                {
                                                    table2.Dispose();
                                                    goto TR_0011;
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Can not use DO Vessel.\nDO Vessel has no DO PO Vessel.\nPlease Map Vessel DO first.\nThank you.", "WARNING...", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                    this.textDO.Focus();
                                                }
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("DO PO Vessel can not be used in weighing", "WARNING...");
                                            this.textDO.Focus();
                                        }
                                    }
                                    else
                                    {
                                        string[] textArray7 = new string[] { "The period of DO  '", data["DO_NO"].ToString(), "' has been expired after ", data["Do_Date2"].ToString().Substring(0, 10), "...!" };
                                        MessageBox.Show(string.Concat(textArray7), "WARNING...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        this.textDO.Focus();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Cannot Choose DO, PIN Not Yet Accepted..", "WARNING...");
                                    this.textDO.Focus();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Cannot Use Automated DO for Titip Timbun..", "Warning..");
                                this.textDO.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please fill in weight of other party", "WARNING...");
                            this.textDO.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannot Choose Closed DO...", "WARNING...");
                        this.textDO.Focus();
                    }
                }
                else
                {
                    this.buttonDO.PerformClick();
                    goto TR_0007;
                }
            }
            return;
        TR_0007:
            if (this.dgvDO.Rows.Count > 0)
            {
                if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    this.txtDeliveryNote.Enabled = false;
                }
                else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                {
                    this.txtDeliveryNote.Enabled = false;
                }
                else if (((this.CommType == "F") && !this.CheckSPB()) && this.txtDeliveryNote.Visible)
                {
                    this.txtDeliveryNote.Enabled = false;
                }
            }
            return;
        TR_0011:
            this.uniq_contract = data["uniq"].ToString();
            this.so_no = data["so"].ToString();
            this.sto_no = data["sto"].ToString();
            this.FillDataDO(data);
            this.SetDOSAP(data);
            goto TR_0007;
        }

        private void textFactNet_KeyPress(object sender, KeyPressEventArgs e)
        {
            bool flag = true;
            if (((e.KeyChar < '0') || (e.KeyChar > '9')) ? (e.KeyChar == '\b') : true)
            {
                flag = false;
            }
            e.Handled = flag;
        }

        private void textFactNet_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textFactNet);
            this.textFactNet.Text = Convert.ToString(Convert.ToInt32(this.textFactNet.Text));
        }

        private void textOthNet_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textOthNet);
            if (((this.textOthNet.Text != "0") && (this.textOthNet.Text != "")) && (this.dgvDO.RowCount > 0))
            {
                if (MessageBox.Show("Do you want to proportionate factory net ?\n", "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.textFactNet.Text = "0";
                    this.textFactNet.Enabled = false;
                }
                else
                {
                    this.textFactNet.Text = Convert.ToString(Math.Round((double) (Convert.ToDouble(this.textOthNet.Text) + ((Convert.ToDouble(this.totalVariance) / Convert.ToDouble(this.totalNetEstate)) * Convert.ToDouble(this.textOthNet.Text)))));
                    this.textFactNet.Enabled = false;
                }
            }
        }

        private void textPINo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textPINo_Leave(object sender, EventArgs e)
        {
            if (this.textPI_No.Text != "")
            {
                this.textPI_No.Text = this.textPI_No.Text.Trim();
                this.tblDO.ReOpen();
                string[] aField = new string[] { "PI_No" };
                string[] aFind = new string[] { this.textPI_No.Text.Trim() };
                DataRow data = this.tblDO.GetData(aField, aFind);
                if (!ReferenceEquals(data, null))
                {
                    if (data["closed"].ToString() != "X")
                    {
                        this.uniq_contract = data["uniq"].ToString();
                        this.so_no = data["so"].ToString();
                        this.sto_no = data["sto"].ToString();
                        this.tblTType.ReOpen();
                        string[] textArray3 = new string[] { "Transaction_code" };
                        string[] textArray4 = new string[] { data["transaction_code"].ToString() };
                        DataRow row2 = this.tblTType.GetData(textArray3, textArray4);
                        this.IO = row2["IO"].ToString();
                        this.labelDO.Text = (row2["IO"].ToString() != "I") ? "Sales Order No." : "Delivery Order No.";
                        if (data["zAuto"].ToString() != "Y")
                        {
                            if ((WBSetting.Field("GM") != "Y") || (data["completedGRCust"].ToString() != "N"))
                            {
                                if (!this.CheckPeriodDO(data, this.refDate))
                                {
                                    this.textDO.Text = data["do_no"].ToString();
                                    this.FillDataDO(data);
                                    this.SetDOSAP(data);
                                }
                                else
                                {
                                    string[] textArray5 = new string[] { "The period of DO  '", data["DO_NO"].ToString(), "' has been expired after ", data["Do_Date2"].ToString().Substring(0, 10), "...!" };
                                    MessageBox.Show(string.Concat(textArray5), "WARNING...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Cannot Choose DO, PIN Not Yet Accepted..", "WARNING...");
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Cannot Use Automated DO for Titip Timbun..", "Warning..");
                            this.textDO.Focus();
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannot Choose Closed DO...", "WARNING...");
                        return;
                    }
                }
                else
                {
                    this.buttonPISI.PerformClick();
                }
                if (this.dgvDO.Rows.Count > 0)
                {
                    if ((this.CommType == "F") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "1") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                    {
                        this.txtDeliveryNote.Enabled = false;
                    }
                    else if ((this.CommType == "S") & ((WBSetting.Field("AutoSPB").ToString().Trim() == "2") || (WBSetting.Field("AutoSPB").ToString().Trim() == "3")))
                    {
                        this.txtDeliveryNote.Enabled = false;
                    }
                    else if (((this.CommType == "F") && !this.CheckSPB()) && this.txtDeliveryNote.Visible)
                    {
                        this.txtDeliveryNote.Enabled = false;
                    }
                }
            }
        }

        private void textStorage_Leave(object sender, EventArgs e)
        {
            if (this.textStorage.Text != "")
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_storage", "SELECT * FROM wb_storage Where " + WBData.CompanyLocation(" and storage_code ='" + this.textStorage.Text.Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    this.buttonStorage.PerformClick();
                    this.textStorage.Focus();
                }
                table.Dispose();
            }
        }

        public void translate()
        {
            this.labelZWB.Text = Resource.RegisDOEntry_002 + this.sapIDSYS;
            this.labelDO.Text = Resource.RegisDOEntry_003;
            this.labelPI_No.Text = Resource.Contract_PI_SI_No;
            this.labelTransCode.Text = Resource.Trans_114;
            this.labelComm.Text = Resource.DoE_005;
            this.labelContractNo.Text = Resource.DoE_004;
            this.labelRelation.Text = Resource.DoE_006;
            this.labelTransporter.Text = Resource.DoE_008;
            this.labelEstate.Text = Resource.DoE_007;
            this.labelStorage.Text = Resource.Main_041;
            this.labelOtherNat.Text = Resource.DoE_010;
            this.labelFactoryNet.Text = Resource.DoE_011;
            this.but_sh_do_sap.Text = Resource.RegisDOEntry_004;
            this.btnFillContainer.Text = Resource.RegisDOEntry_005;
            this.labelDOQtyLeft.Text = Resource.DoE_003;
            this.buttonSave.Text = Resource.Btn_Save;
            this.button2.Text = Resource.Btn_Cancel;
            this.gb_do_sap.Text = this.gb_do_sap.Text + this.sapIDSYS;
            this.label2.Text = this.label2.Text + this.sapIDSYS;
            this.but_sh_do_sap.Text = this.but_sh_do_sap.Text + this.sapIDSYS;
            this.labelZWB.Text = this.labelZWB.Text + (WBSetting.integrationIDSYS ? Resource.IDSYS : "ZWB");
            this.labelDN.Text = Resource.Gatepass_061;
        }

        private bool try_connect()
        {
            if (WBSAP.connect())
            {
                if (WBSetting.adopt_zdotrx)
                {
                    this.txtInternalNum.ReadOnly = false;
                    this.txtBox_QQ.Visible = true;
                    this.lbl_QQ.Visible = true;
                }
                else
                {
                    this.txtInternalNum.ReadOnly = true;
                    this.txtBox_QQ.Visible = false;
                    this.lbl_QQ.Visible = false;
                }
                this.text_do_sap_item.ReadOnly = true;
                this.txtInNumItem.ReadOnly = true;
                this.text_do_sap.ReadOnly = true;
                this.textSOItem_detail.ReadOnly = true;
            }
            else
            {
                DialogResult result2 = MessageBox.Show("WB.NET cannot connect to SAP.\nPlease check your connection.\nDo you want to retry?\n\nPress YES to Retry.\nPress NO to continue with Token/Password Approval.", "WARNING", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk);
                if (result2 == DialogResult.Cancel)
                {
                    return false;
                }
                else if (result2 == DialogResult.Yes)
                {
                    this.try_connect();
                }
                else
                {
                    bool flag2;
                    if (result2 != DialogResult.No)
                    {
                        flag2 = false;
                    }
                    else
                    {
                        this.text_do_sap.ReadOnly = false;
                        this.text_do_sap_item.ReadOnly = false;
                        this.txtInNumItem.ReadOnly = false;
                        this.txtInternalNum.ReadOnly = false;
                        this.text_do_sap_qty_kg.Text = "";
                        this.text_do_sap_qty.Text = "";
                        this.textBoxQtyBaseUOM.Text = "";
                        this.text_do_sap_unit.Text = "";
                        this.textBoxBaseUOM.Text = "";
                        this.txtBox_QQ.Text = "";
                        this.textSOItem_detail.ReadOnly = false;
                        flag2 = true;
                    }
                    return flag2;
                }
            }
            return true;
        }

        private bool try_connect_IDSYS()
        {
            if (this.connectIDSYS())
            {
                this.txtInternalNum.ReadOnly = !WBSetting.adopt_zdotrx;
                this.text_do_sap_item.ReadOnly = true;
                this.txtInNumItem.ReadOnly = true;
                this.text_do_sap.ReadOnly = true;
                this.textSOItem_detail.ReadOnly = true;
            }
            else
            {
                DialogResult result2 = MessageBox.Show("WB.NET cannot connect to SAP.\nPlease check your connection.\nDo you want to retry?\n\nPress YES to Retry.\nPress NO to continue with Token/Password Approval.", "WARNING", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk);
                if (result2 == DialogResult.Cancel)
                {
                    return false;
                }
                else if (result2 == DialogResult.Yes)
                {
                    this.try_connect_IDSYS();
                }
                else
                {
                    bool flag2;
                    if (result2 != DialogResult.No)
                    {
                        flag2 = false;
                    }
                    else
                    {
                        this.text_do_sap.ReadOnly = false;
                        this.text_do_sap_item.ReadOnly = false;
                        this.txtInNumItem.ReadOnly = false;
                        this.txtInNumItem.Enabled = true;
                        this.txtInternalNum.ReadOnly = false;
                        this.txtInternalNum.Enabled = true;
                        this.text_do_sap_qty_kg.Text = "";
                        this.text_do_sap_qty.Text = "";
                        this.textBoxQtyBaseUOM.Text = "";
                        this.text_do_sap_unit.Text = "";
                        this.textBoxBaseUOM.Text = "";
                        this.textSOItem_detail.ReadOnly = false;
                        this.textSOItem_detail.Enabled = true;
                        flag2 = true;
                    }
                    return flag2;
                }
            }
            return true;
        }

        private void txtDeliveryNote_Leave(object sender, EventArgs e)
        {
            string[] aField = new string[] { "Comm_Code" };
            string[] aFind = new string[] { this.textComm.Text.Trim() };
            DataRow data = this.tblComm.GetData(aField, aFind);
            if ((WBSetting.Field("DeliveryNote") == "Y") && (this.txtDeliveryNote.Text.Trim() != "-"))
            {
            }
        }

        private void txtInternalNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "0123456789".IndexOfAny(anyOf) <= -1;
            }
        }

        private void txtOPWLoadQty(string IO, string unit, string trade)
        {
            if (((IO == "I") && (unit != "KG")) && (trade == "T"))
            {
                this.text_opw_loading_qty.ReadOnly = false;
            }
            else
            {
                this.text_opw_loading_qty.Text = "0";
                this.text_opw_loading_qty.ReadOnly = true;
            }
        }
    }
}

