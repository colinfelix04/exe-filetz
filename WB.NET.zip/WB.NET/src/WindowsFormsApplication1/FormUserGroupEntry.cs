﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormUserGroupEntry : Form
    {
        public WBTable tGroup;
        public WBTable tAuth;
        public WBTable tMenu;
        public string pMode;
        public string pUniq;
        public string pGroup;
        public string changeReason = "";
        public string logKey = "";
        public string oldGroup = "";
        public int nCurrRow;
        public bool Saved;
        private IContainer components = null;
        private Label label1;
        private Label label2;
        private TextBox textBox1;
        private TextBox textBox2;
        private DataGridView dataGridView1;
        private Button button2;
        private Button button1;
        private Label label3;
        private Label label4;
        private Button button3;
        private Button button4;
        private Label label5;

        public FormUserGroupEntry()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Saved = true;
            Cursor.Current = Cursors.WaitCursor;
            this.tGroup.ReOpen();
            this.tAuth.ReOpen();
            if (this.nCurrRow >= 0)
            {
                this.pGroup = this.textBox1.Text;
                if (this.pMode != "ADD")
                {
                    if (this.pMode != "EDIT")
                    {
                        if (this.pMode == "DELETE")
                        {
                            FormTransCancel cancel2 = new FormTransCancel {
                                label1 = { Text = "Group ID" },
                                textRefNo = { Text = this.textBox1.Text },
                                Text = "DELETE REASON",
                                label2 = { Text = "Delete Reason : " }
                            };
                            cancel2.textReason.Focus();
                            cancel2.ShowDialog();
                            if (cancel2.Saved)
                            {
                                this.changeReason = cancel2.textReason.Text;
                                cancel2.Dispose();
                                Cursor.Current = Cursors.WaitCursor;
                                WBTable table5 = new WBTable();
                                table5.OpenTable("wb_authorization", "SELECT * FROM wb_authorization WHERE " + WBData.CompanyLocation(" AND autho_group = '" + this.textBox1.Text + "'"), WBData.conn);
                                string[] strArray = new string[table5.DT.Rows.Count];
                                int index = 0;
                                while (true)
                                {
                                    if (index >= table5.DT.Rows.Count)
                                    {
                                        table5.Save();
                                        table5.Dispose();
                                        int num6 = 0;
                                        while (true)
                                        {
                                            if (num6 >= strArray.Length)
                                            {
                                                this.tGroup.DR = this.tGroup.DT.Rows[this.nCurrRow];
                                                this.logKey = this.tGroup.DR["uniq"].ToString();
                                                this.tGroup.DR.Delete();
                                                this.tGroup.Save();
                                                string[] textArray18 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                string[] textArray19 = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                                                Program.updateLogHeader("wb_group", this.logKey, textArray18, textArray19);
                                                Cursor.Current = Cursors.Default;
                                                break;
                                            }
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                                            Program.updateLogHeader("wb_authorization", strArray[num6], logField, logValue);
                                            num6++;
                                        }
                                        break;
                                    }
                                    table5.DR = table5.DT.Rows[index];
                                    strArray[index] = table5.DR["uniq"].ToString();
                                    table5.DR.Delete();
                                    index++;
                                }
                            }
                            else
                            {
                                return;
                            }
                        }
                    }
                    else
                    {
                        this.tGroup.DR = this.tGroup.DT.Rows[this.nCurrRow];
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = "Group ID" },
                            textRefNo = { Text = this.textBox1.Text },
                            Text = "CHANGE REASON",
                            label2 = { Text = "Change Reason : " }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                            this.tGroup.DR.BeginEdit();
                            this.logKey = this.tGroup.DR["uniq"].ToString();
                            this.tGroup.DR["coy"] = WBData.sCoyCode;
                            this.tGroup.DR["Location_Code"] = WBData.sLocCode;
                            this.tGroup.DR["Code"] = this.textBox1.Text;
                            this.tGroup.DR["Name"] = this.textBox2.Text;
                            this.tGroup.DR.EndEdit();
                            this.tGroup.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "EDIT", WBUser.UserID, this.changeReason };
                            Program.updateLogHeader("wb_group", this.logKey, logField, logValue);
                            if (this.textBox1.Text != this.oldGroup)
                            {
                                WBTable table2 = new WBTable();
                                table2.OpenTable("wb_user", "Select * from wb_user where " + WBData.CompanyLocation(" and User_Group = '" + this.oldGroup + "'"), WBData.conn);
                                foreach (DataRow row2 in table2.DT.Rows)
                                {
                                    this.logKey = row2["uniq"].ToString();
                                    row2.BeginEdit();
                                    row2["User_Group"] = this.textBox1.Text;
                                    row2.EndEdit();
                                    table2.Save();
                                    string[] textArray7 = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] textArray8 = new string[] { "EDIT", WBUser.UserID, this.changeReason + " (Edit group master data)" };
                                    Program.updateLogHeader("wb_user", this.logKey, textArray7, textArray8);
                                }
                            }
                            foreach (DataGridViewRow row3 in (IEnumerable) this.dataGridView1.Rows)
                            {
                                int recNo = -1;
                                string[] aField = new string[] { "coy", "Location_Code", "Autho_Group", "Autho_Menu" };
                                string[] aFind = new string[] { WBData.sCoyCode, WBData.sLocCode, this.tGroup.DR["code"].ToString(), row3.Cells[0].Value.ToString() };
                                recNo = this.tAuth.GetRecNo(aField, aFind);
                                WBTable table3 = new WBTable();
                                string[] textArray11 = new string[] { " AND autho_group = '", this.tGroup.DR["code"].ToString(), "' AND autho_menu = '", row3.Cells[0].Value.ToString(), "' ORDER BY uniq ASC" };
                                table3.OpenTable("wb_authorizaton", "SELECT * FROM wb_authorization WHERE " + WBData.CompanyLocation(string.Concat(textArray11)), WBData.conn);
                                if (table3.DT.Rows.Count > 0)
                                {
                                    table3.DR = table3.DT.Rows[0];
                                    this.logKey = table3.DR["uniq"].ToString();
                                    table3.DR.BeginEdit();
                                    table3.DR["coy"] = WBData.sCoyCode;
                                    table3.DR["Location_Code"] = WBData.sLocCode;
                                    table3.DR["Autho_Group"] = this.textBox1.Text;
                                    table3.DR["Autho_Menu"] = row3.Cells[0].Value.ToString();
                                    string str5 = "";
                                    string str6 = "VAEDP";
                                    int num3 = 0;
                                    while (true)
                                    {
                                        if (num3 >= str6.Length)
                                        {
                                            table3.DR["Autho_Trustee"] = str5;
                                            table3.DR["checksum"] = table3.Checksum(table3.DR);
                                            table3.DR.EndEdit();
                                            table3.Save();
                                            string[] textArray12 = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] textArray13 = new string[] { "EDIT", WBUser.UserID, this.changeReason };
                                            Program.updateLogHeader("wb_authorization", this.logKey, textArray12, textArray13);
                                            break;
                                        }
                                        char ch2 = str6[num3];
                                        if (row3.Cells[ch2.ToString()].Value.ToString().Trim() != "")
                                        {
                                            str5 = str5 + ch2.ToString();
                                        }
                                        num3++;
                                    }
                                }
                                else
                                {
                                    table3.DR = table3.DT.NewRow();
                                    table3.DR["coy"] = WBData.sCoyCode;
                                    table3.DR["Location_Code"] = WBData.sLocCode;
                                    table3.DR["Autho_Group"] = this.textBox1.Text;
                                    table3.DR["Autho_Menu"] = row3.Cells[0].Value.ToString();
                                    string str7 = "";
                                    string str9 = "VAEDP";
                                    int num4 = 0;
                                    while (true)
                                    {
                                        if (num4 >= str9.Length)
                                        {
                                            table3.DR["Autho_Trustee"] = str7;
                                            table3.DR["checksum"] = table3.Checksum(table3.DR);
                                            table3.DT.Rows.Add(table3.DR);
                                            table3.Save();
                                            string sqltext = ((("SELECT uniq FROM wb_authorization WHERE " + WBData.CompanyLocation("")) + " AND autho_group = '" + this.textBox1.Text + "'") + " AND autho_menu = '" + row3.Cells[0].Value.ToString() + "'") + " AND autho_trustee = '" + str7 + "'";
                                            WBTable table4 = new WBTable();
                                            table4.OpenTable("wb_authorization", sqltext, WBData.conn);
                                            this.logKey = table4.DT.Rows[0]["uniq"].ToString();
                                            table4.Dispose();
                                            string[] textArray14 = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] textArray15 = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                                            Program.updateLogHeader("wb_authorization", this.logKey, textArray14, textArray15);
                                            break;
                                        }
                                        char ch3 = str9[num4];
                                        if (row3.Cells[ch3.ToString()].Value.ToString().Trim() != "")
                                        {
                                            str7 = str7 + ch3.ToString();
                                        }
                                        num4++;
                                    }
                                }
                                table3.Dispose();
                            }
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                else
                {
                    this.tGroup.DR = this.tGroup.DT.NewRow();
                    this.tGroup.DR["Coy"] = WBData.sCoyCode;
                    this.tGroup.DR["Location_Code"] = WBData.sLocCode;
                    this.tGroup.DR["Code"] = this.textBox1.Text;
                    this.tGroup.DR["Name"] = this.textBox2.Text;
                    this.tGroup.DT.Rows.Add(this.tGroup.DR);
                    this.tGroup.Save();
                    string sqltext = (("SELECT uniq FROM wb_group WHERE " + WBData.CompanyLocation("")) + " AND code = '" + this.textBox1.Text + "'") + " AND name = '" + this.textBox2.Text + "'";
                    WBTable table = new WBTable();
                    table.OpenTable("wb_group", sqltext, WBData.conn);
                    this.logKey = table.DT.Rows[0]["uniq"].ToString();
                    table.Dispose();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                    Program.updateLogHeader("wb_group", this.logKey, logField, logValue);
                    foreach (DataGridViewRow row in (IEnumerable) this.dataGridView1.Rows)
                    {
                        this.tAuth.DR = this.tAuth.DT.NewRow();
                        this.tAuth.DR["coy"] = WBData.sCoyCode;
                        this.tAuth.DR["Location_Code"] = WBData.sLocCode;
                        this.tAuth.DR["Autho_Group"] = this.textBox1.Text;
                        this.tAuth.DR["Autho_Menu"] = row.Cells[0].Value.ToString();
                        string str3 = "";
                        string str4 = "VAEDP";
                        int num = 0;
                        while (true)
                        {
                            if (num >= str4.Length)
                            {
                                this.tAuth.DR["Autho_Trustee"] = str3;
                                this.tAuth.DR["checksum"] = this.tAuth.Checksum(this.tAuth.DR);
                                this.tAuth.DT.Rows.Add(this.tAuth.DR);
                                this.tAuth.Save();
                                sqltext = ((("SELECT uniq FROM wb_authorization WHERE " + WBData.CompanyLocation("")) + " AND autho_group = '" + this.textBox1.Text + "'") + " AND autho_menu = '" + row.Cells[0].Value.ToString() + "'") + " AND autho_trustee = '" + str3 + "'";
                                table.OpenTable("wb_authorization", sqltext, WBData.conn);
                                this.logKey = table.DT.Rows[0]["uniq"].ToString();
                                table.Dispose();
                                string[] textArray3 = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] textArray4 = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                                Program.updateLogHeader("wb_authorization", this.logKey, textArray3, textArray4);
                                break;
                            }
                            char ch = str4[num];
                            if (row.Cells[ch.ToString()].Value.ToString().Trim() != "")
                            {
                                str3 = str3 + ch.ToString();
                            }
                            num++;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_466, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                Cursor.Current = Cursors.Default;
                this.Saved = true;
                base.Close();
                return;
            }
            string str = "";
            if (this.pMode == "ADD")
            {
                str = "Add";
            }
            else if (this.pMode == "EDIT")
            {
                str = "Edit";
            }
            else if (this.pMode == "DELETE")
            {
                str = "Delete";
            }
            if (((this.pMode == "ADD") || (this.pMode == "EDIT")) || (this.pMode == "DELETE"))
            {
                bool flag1;
                WBTable table6 = new WBTable();
                table6.OpenTable("wb_location", "SELECT COUNT(uniq) AS n FROM wb_location WHERE 1=1", WBData.conn);
                int num7 = Convert.ToInt16(table6.DT.Rows[0]["n"].ToString());
                table6.Dispose();
                if (num7 <= 1)
                {
                    flag1 = false;
                }
                else
                {
                    string[] textArray20 = new string[] { "Do you want to ", str.ToLower(), " group ", this.textBox1.Text, " and its authorization in other locations?" };
                    flag1 = MessageBox.Show(string.Concat(textArray20), "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
                }
                if (flag1)
                {
                    FormCopyUserAutho autho = new FormCopyUserAutho {
                        pMode = this.pMode,
                        group = this.textBox1.Text,
                        groupName = this.textBox2.Text,
                        changeReason = this.changeReason,
                        oldGroup = this.oldGroup,
                        table = "auth",
                        Text = str + " Group & Authorization in Other Locations",
                        label1 = { Text = str + " group " + this.textBox1.Text + " and its authorization in locations:" }
                    };
                    autho.ShowDialog();
                    if (autho.saved)
                    {
                    }
                    autho.Dispose();
                }
            }
            Cursor.Current = Cursors.Default;
            base.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Saved = false;
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Resource.Mes_465, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int num = 0;
                while (true)
                {
                    if (num >= this.dataGridView1.Rows.Count)
                    {
                        break;
                    }
                    this.dataGridView1.Rows[num].Cells["V"].Value = "*";
                    this.dataGridView1.Rows[num].Cells["A"].Value = "*";
                    this.dataGridView1.Rows[num].Cells["E"].Value = "*";
                    this.dataGridView1.Rows[num].Cells["D"].Value = "*";
                    this.dataGridView1.Rows[num].Cells["P"].Value = "*";
                    num++;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("All of the mark will be clear, are you sure ?", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int num = 0;
                while (true)
                {
                    if (num >= this.dataGridView1.Rows.Count)
                    {
                        break;
                    }
                    this.dataGridView1.Rows[num].Cells["V"].Value = "  ";
                    this.dataGridView1.Rows[num].Cells["A"].Value = "  ";
                    this.dataGridView1.Rows[num].Cells["E"].Value = "  ";
                    this.dataGridView1.Rows[num].Cells["D"].Value = "  ";
                    this.dataGridView1.Rows[num].Cells["P"].Value = "  ";
                    num++;
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex >= 0)
            {
                if (e.RowIndex < 0)
                {
                    if ("VAEDP".Contains(this.dataGridView1.Columns[e.ColumnIndex].Name.ToString()))
                    {
                    }
                }
                else if ("VAEDP".Contains(this.dataGridView1.Columns[e.ColumnIndex].Name.ToString()))
                {
                    this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = (this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString() != "*") ? "*" : " ";
                    if ((this.dataGridView1.Columns[e.ColumnIndex].Name.ToString() == "V") & (this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().Trim() == ""))
                    {
                        this.dataGridView1.Rows[e.RowIndex].Cells["A"].Value = " ";
                        this.dataGridView1.Rows[e.RowIndex].Cells["E"].Value = " ";
                        this.dataGridView1.Rows[e.RowIndex].Cells["D"].Value = " ";
                        this.dataGridView1.Rows[e.RowIndex].Cells["P"].Value = " ";
                    }
                    if ((this.dataGridView1.Columns[e.ColumnIndex].Name.ToString() != "V") & (this.dataGridView1.Rows[e.RowIndex].Cells["V"].Value.ToString().Trim() == ""))
                    {
                        this.dataGridView1.Rows[e.RowIndex].Cells["V"].Value = "*";
                    }
                }
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                FormUserGroupAuthor author = new FormUserGroupAuthor {
                    dr = this.dataGridView1.Rows[e.RowIndex],
                    desc = this.dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString() + " - " + this.dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString()
                };
                author.ShowDialog();
                if (author.saved)
                {
                    this.dataGridView1.Rows[e.RowIndex].Cells["V"].Value = !author.V ? " " : "*";
                    this.dataGridView1.Rows[e.RowIndex].Cells["A"].Value = !author.A ? " " : "*";
                    this.dataGridView1.Rows[e.RowIndex].Cells["E"].Value = !author.E ? " " : "*";
                    this.dataGridView1.Rows[e.RowIndex].Cells["D"].Value = !author.D ? " " : "*";
                    this.dataGridView1.Rows[e.RowIndex].Cells["P"].Value = !author.P ? " " : "*";
                }
                author.Dispose();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormUserGroupEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.button2.PerformClick();
            }
        }

        private void FormUserGroupEntry_Load(object sender, EventArgs e)
        {
            this.translate();
            this.dataGridView1.ColumnCount = 7;
            this.dataGridView1.Columns[0].Name = "Activity Code";
            this.dataGridView1.Columns[0].Width = 160;
            this.dataGridView1.Columns[1].Name = "Description of Activity";
            this.dataGridView1.Columns[1].Width = 400;
            this.dataGridView1.Columns[0].HeaderText = Resource.UserGroup_005;
            this.dataGridView1.Columns[1].HeaderText = Resource.UserGroup_006;
            this.dataGridView1.Columns[2].Name = "V";
            this.dataGridView1.Columns[2].HeaderCell.ToolTipText = "View";
            this.dataGridView1.Columns[2].Width = 20;
            this.dataGridView1.Columns[3].Name = "A";
            this.dataGridView1.Columns[3].HeaderCell.ToolTipText = "Add";
            this.dataGridView1.Columns[3].Width = 20;
            this.dataGridView1.Columns[4].Name = "E";
            this.dataGridView1.Columns[4].HeaderCell.ToolTipText = "Edit";
            this.dataGridView1.Columns[4].Width = 20;
            this.dataGridView1.Columns[5].Name = "D";
            this.dataGridView1.Columns[5].HeaderCell.ToolTipText = "Delete";
            this.dataGridView1.Columns[5].Width = 20;
            this.dataGridView1.Columns[6].Name = "P";
            this.dataGridView1.Columns[6].HeaderCell.ToolTipText = "Print";
            this.dataGridView1.Columns[6].Width = 20;
            this.tGroup.DR = this.tGroup.DT.Rows[this.nCurrRow];
            this.label5.Visible = false;
            if (this.pMode == "ADD")
            {
                foreach (DataRow row in this.tMenu.DT.Rows)
                {
                    string[] values = new string[] { row["code"].ToString(), row["name"].ToString(), " ", " ", " ", " ", " " };
                    this.dataGridView1.Rows.Add(values);
                }
            }
            else
            {
                this.textBox1.Text = this.tGroup.DR["code"].ToString();
                this.textBox2.Text = this.tGroup.DR["name"].ToString();
                this.oldGroup = this.tGroup.DR["code"].ToString();
                foreach (DataRow row2 in this.tMenu.DT.Rows)
                {
                    string str = " ";
                    string str2 = " ";
                    string str3 = " ";
                    string str4 = " ";
                    string str5 = " ";
                    WBTable table = new WBTable();
                    string[] textArray2 = new string[] { " AND autho_group = '", this.tGroup.DR["code"].ToString(), "' AND autho_menu = '", row2["code"].ToString(), "' ORDER BY uniq ASC" };
                    table.OpenTable("wb_authorization", "SELECT * FROM wb_authorization WHERE " + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
                    DataRow objA = null;
                    if (table.DT.Rows.Count > 0)
                    {
                        objA = table.DT.Rows[0];
                    }
                    if (ReferenceEquals(objA, null))
                    {
                        objA = this.tAuth.DT.NewRow();
                    }
                    if (objA["Autho_Trustee"].ToString().Contains("V"))
                    {
                        str = "*";
                    }
                    if (objA["Autho_Trustee"].ToString().Contains("A"))
                    {
                        str2 = "*";
                    }
                    if (objA["Autho_Trustee"].ToString().Contains("E"))
                    {
                        str3 = "*";
                    }
                    if (objA["Autho_Trustee"].ToString().Contains("D"))
                    {
                        str4 = "*";
                    }
                    if (objA["Autho_Trustee"].ToString().Contains("P"))
                    {
                        str5 = "*";
                    }
                    string[] values = new string[] { row2["code"].ToString(), row2["name"].ToString(), str, str2, str3, str4, str5 };
                    this.dataGridView1.Rows.Add(values);
                }
                if (this.pMode == "EDIT")
                {
                    this.dataGridView1.Focus();
                }
                else
                {
                    this.label4.Visible = false;
                    this.label5.Visible = true;
                    this.button3.Visible = false;
                    this.button4.Visible = false;
                    this.button1.Text = "&Yes";
                    this.dataGridView1.Enabled = false;
                    this.textBox1.ReadOnly = true;
                    this.textBox2.ReadOnly = true;
                    this.button2.Focus();
                }
            }
            this.dataGridView1.Refresh();
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.label2 = new Label();
            this.textBox1 = new TextBox();
            this.textBox2 = new TextBox();
            this.dataGridView1 = new DataGridView();
            this.button2 = new Button();
            this.button1 = new Button();
            this.label3 = new Label();
            this.label4 = new Label();
            this.button3 = new Button();
            this.button4 = new Button();
            this.label5 = new Label();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x20, 0x13);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x40, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Group Code";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x1d, 0x2d);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x43, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Group Name";
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(0x66, 0x10);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0xb0, 20);
            this.textBox1.TabIndex = 2;
            this.textBox2.Location = new Point(0x66, 0x2a);
            this.textBox2.MaxLength = 50;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x142, 20);
            this.textBox2.TabIndex = 3;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new Point(0x1a, 0x5f);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x2d2, 280);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.CellContentClick += new DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.button2.Location = new Point(0x288, 0x18a);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x1a);
            this.button2.TabIndex = 0x12;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x228, 0x18a);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x1a);
            this.button1.TabIndex = 0x11;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x1d, 0x4f);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x68, 13);
            this.label3.TabIndex = 0x13;
            this.label3.Text = "List of authorization :";
            this.label4.AutoSize = true;
            this.label4.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.label4.Location = new Point(0x20, 0x17a);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0xd7, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "~  Double click to change authorization item";
            this.button3.Location = new Point(0x274, 0x48);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x38, 0x17);
            this.button3.TabIndex = 0x15;
            this.button3.Text = "&Mark All";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.button4.Location = new Point(690, 0x48);
            this.button4.Name = "button4";
            this.button4.Size = new Size(0x38, 0x17);
            this.button4.TabIndex = 0x16;
            this.button4.Text = "Clear &All";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new EventHandler(this.button4_Click);
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label5.ForeColor = Color.Red;
            this.label5.Location = new Point(0xad, 0x18a);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x165, 0x18);
            this.label5.TabIndex = 0x17;
            this.label5.Text = "This group will be deleted, are you sure ?";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x307, 0x1b3);
            base.ControlBox = false;
            base.Controls.Add(this.label5);
            base.Controls.Add(this.button4);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.KeyPreview = true;
            base.Name = "FormUserGroupEntry";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "formuser";
            base.Load += new EventHandler(this.FormUserGroupEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormUserGroupEntry_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.Text = Resource.UserGroup_001;
            this.label1.Text = Resource.UserGroup_002;
            this.label2.Text = Resource.UserGroup_003;
            this.label3.Text = Resource.UserGroup_004;
            this.button3.Text = Resource.UserGroup_007;
            this.button4.Text = Resource.UserGroup_008;
            this.label4.Text = Resource.UserGroup_014;
            this.button1.Text = Resource.Save;
            this.button2.Text = Resource.Menu_Cancel;
        }
    }
}

