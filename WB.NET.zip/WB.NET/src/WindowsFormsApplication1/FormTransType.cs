﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormTransType : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable zTable = new WBTable();
        public DataRow ReturnRow;
        private DataTable updTable = new DataTable();
        private DataTable retTable = new DataTable();
        private string[] zwbResult = new string[3];
        private string[] zwbRow = new string[13];
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private ToolStripMenuItem closeToolStripMenuItem;
        private DataGridView dataGridView1;
        private TextBox TextFind;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private Panel panel1;
        private Button buttonFind;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addCommodityItemToolStripMenuItem;
        private ToolStripMenuItem editCommodityToolStripMenuItem;
        private ToolStripMenuItem chooseToolStripMenuItem;
        private ToolStripMenuItem zWBToolStripMenuItem;
        private ToolStripMenuItem synchronizeToolStripMenuItem;
        private ToolStripMenuItem synchronizeAllToolStripMenuItem;
        private ProgressBar progressBar1;
        private ToolStripMenuItem copyToAllLocationsToolStripMenuItem;
        private ToolStripMenuItem copyThisTransTypeToolStripMenuItem;
        private ToolStripMenuItem copyAllTypesToolStripMenuItem;
        private ToolStripMenuItem viewReordToolStripMenuItem;

        public FormTransType()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            WBSetting.OpenSetting();
            this.zWBToolStripMenuItem.Visible = WBSetting.zwb == "Y";
        }

        private void addCommodityItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.entry("ADD", Resource.Menu_Add_Transaction_Type);
            if (this.dataGridView1.RowCount > 0)
            {
                this.viewReordToolStripMenuItem.Enabled = true;
                this.editCommodityToolStripMenuItem.Enabled = true;
                this.deleteToolStripMenuItem.Enabled = true;
                this.zWBToolStripMenuItem.Enabled = true;
                this.copyToAllLocationsToolStripMenuItem.Enabled = true;
                this.chooseToolStripMenuItem.Enabled = true;
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.zTable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.zTable.GetRecNo(aField, aFind);
            this.ReturnRow = this.zTable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void copyAllTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string key = this.dataGridView1.CurrentRow.Cells["transaction_code"].Value.ToString().Trim();
            string str = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString().Trim();
            if (MessageBox.Show(this.dataGridView1.Rows.Count + " " + Resource.Mes_Confirm_Copy_Types, Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Program.copyToLoc("wb_transaction_type", key, 0, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                MessageBox.Show(Resource.Mes_Type_Copied);
            }
        }

        private void copyThisTransTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string key = this.dataGridView1.CurrentRow.Cells["transaction_code"].Value.ToString().Trim();
            string str = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString().Trim();
            if (MessageBox.Show(key + " : " + Resource.Mes_Confirm_Copy, Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Program.copyToLoc("wb_transaction_type", key, 0, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                MessageBox.Show(Resource.Mes_Copied_All_Location);
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseToolStripMenuItem.PerformClick();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.chooseToolStripMenuItem.PerformClick();
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.zTable.BeforeEdit(this.dataGridView1, "DELETE"))
            {
                this.nCurrRow = this.zTable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                WBTable table = new WBTable();
                table.OpenTable("wb_transaction", "Select uniq From wb_transaction where " + WBData.Company(" and ( Transaction_Code='" + this.zTable.DT.Rows[this.nCurrRow]["Transaction_Code"].ToString() + "')"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    string[] textArray2 = new string[] { this.zTable.DT.Rows[this.nCurrRow]["Transaction_Code"].ToString(), " - ", this.zTable.DT.Rows[this.nCurrRow]["Transaction_Name"].ToString(), ".\n\n ", Resource.Mes_006 };
                    if (MessageBox.Show(string.Concat(textArray2), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = Resource.TransType_001 },
                            textRefNo = { Text = this.zTable.DT.Rows[this.nCurrRow]["Transaction_Code"].ToString() },
                            Text = Resource.Form_Delete_Reason,
                            label2 = { Text = Resource.Lbl_Delete_Reason }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                            this.zTable.ReOpen();
                            this.logKey = this.zTable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                            this.zTable.DT.Rows[this.nCurrRow].Delete();
                            this.zTable.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                            Program.updateLogHeader("wb_transaction_type", this.logKey, logField, logValue);
                            this.zTable.ReOpen();
                            this.zTable.AfterEdit("DELETE");
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                else
                {
                    string[] textArray1 = new string[] { Resource.Mes_047A, "\n ( ", table.DT.Rows.Count.ToString(), " ", Resource.Mes_047B, ")" };
                    MessageBox.Show(string.Concat(textArray1), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                this.zTable.UnLock();
                table.Dispose();
                if (this.dataGridView1.RowCount == 0)
                {
                    this.viewReordToolStripMenuItem.Enabled = false;
                    this.editCommodityToolStripMenuItem.Enabled = false;
                    this.deleteToolStripMenuItem.Enabled = false;
                    this.zWBToolStripMenuItem.Enabled = false;
                    this.copyToAllLocationsToolStripMenuItem.Enabled = false;
                    this.chooseToolStripMenuItem.Enabled = false;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editCommodityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.entry("EDIT", Resource.Menu_Edit_Transaction_Type);
        }

        private void entry(string pMode, string formText)
        {
            if (this.zTable.BeforeEdit(this.dataGridView1, pMode))
            {
                FormTransTypeEntry entry = new FormTransTypeEntry {
                    pMode = pMode,
                    zTable = this.zTable,
                    Text = formText,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.zTable.ReOpen();
                    this.dataGridView1 = this.zTable.AfterEdit(entry.pMode);
                }
                this.zTable.UnLock();
                entry.Dispose();
            }
        }

        private void FormTransType_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTransType_Load(object sender, EventArgs e)
        {
            this.chooseToolStripMenuItem.Visible = this.pMode != "";
            this.zTable.OpenTable("wb_transaction_type", "Select * From wb_transaction_type", WBData.conn);
            this.dataGridView1.DataSource = this.zTable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Transaction_Code"], ListSortDirection.Ascending);
            this.dataGridView1.Focus();
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["Create_By"].Visible = false;
            this.dataGridView1.Columns["Create_Date"].Visible = false;
            this.dataGridView1.Columns["Change_By"].Visible = false;
            this.dataGridView1.Columns["Change_Date"].Visible = false;
            this.dataGridView1.Columns["Delete_By"].Visible = false;
            this.dataGridView1.Columns["Delete_Date"].Visible = false;
            this.dataGridView1.Columns["deleted"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["token"].Visible = false;
            this.dataGridView1.Columns["SAP_code"].Visible = false;
            this.dataGridView1.Columns["Transaction_Code"].HeaderText = Resource.Gatepass_023;
            this.dataGridView1.Columns["Transaction_Name"].HeaderText = Resource.Source_002;
            this.dataGridView1.Columns["IO"].HeaderText = "I/O/X";
            this.dataGridView1.Columns["IO"].ToolTipText = Resource.Ttp_IOX;
            this.dataGridView1.Columns["AdoptSAP"].HeaderText = Resource.Col_Adopt_SAP + this.sapIDSYS;
            this.dataGridView1.Columns["AdoptSAP"].ToolTipText = Resource.Ttp_Must_Adopt + this.sapIDSYS;
            this.dataGridView1.Columns["is_vessel"].HeaderText = Resource.Col_Vessel_Transaction;
            this.dataGridView1.Columns["is_return"].HeaderText = Resource.Col_Return_Type;
            base.KeyPreview = true;
            this.addCommodityItemToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TRANS_TYPE", "A");
            if (WBSetting.Field("GM") == "Y")
            {
                this.editCommodityToolStripMenuItem.Enabled = true;
                this.deleteToolStripMenuItem.Enabled = true;
            }
            else
            {
                this.editCommodityToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TRANS_TYPE", "E");
                this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_TRANS_TYPE", "D");
            }
            this.copyToAllLocationsToolStripMenuItem.Enabled = (WBSetting.copyToLoc == "Y") && (WBUser.CheckTrustee("MD_TRANS_TYPE", "A") || WBUser.CheckTrustee("MD_TRANS_TYPE", "E"));
            if (this.dataGridView1.RowCount == 0)
            {
                this.viewReordToolStripMenuItem.Enabled = false;
                this.editCommodityToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
                this.zWBToolStripMenuItem.Enabled = false;
                this.copyToAllLocationsToolStripMenuItem.Enabled = false;
                this.chooseToolStripMenuItem.Enabled = false;
            }
            this.zWBToolStripMenuItem.Enabled = !WBSetting.integrationIDSYS;
        }

        private void InitializeComponent()
        {
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.TextFind = new TextBox();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.buttonFind = new Button();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addCommodityItemToolStripMenuItem = new ToolStripMenuItem();
            this.viewReordToolStripMenuItem = new ToolStripMenuItem();
            this.editCommodityToolStripMenuItem = new ToolStripMenuItem();
            this.zWBToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeAllToolStripMenuItem = new ToolStripMenuItem();
            this.copyToAllLocationsToolStripMenuItem = new ToolStripMenuItem();
            this.copyThisTransTypeToolStripMenuItem = new ToolStripMenuItem();
            this.copyAllTypesToolStripMenuItem = new ToolStripMenuItem();
            this.chooseToolStripMenuItem = new ToolStripMenuItem();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(420, 0x15f);
            this.dataGridView1.TabIndex = 6;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.TextFind.Location = new Point(5, 3);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 0;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(190, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x177);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(420, 0x21);
            this.panel1.TabIndex = 7;
            this.progressBar1.Location = new Point(0x11d, 9);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0x84, 0x11);
            this.progressBar1.TabIndex = 12;
            this.buttonFind.Location = new Point(0xc3, 3);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 1;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(420, 0x18);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addCommodityItemToolStripMenuItem, this.viewReordToolStripMenuItem, this.editCommodityToolStripMenuItem, this.deleteToolStripMenuItem, this.zWBToolStripMenuItem, this.copyToAllLocationsToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.addCommodityItemToolStripMenuItem.Name = "addCommodityItemToolStripMenuItem";
            this.addCommodityItemToolStripMenuItem.Size = new Size(190, 0x16);
            this.addCommodityItemToolStripMenuItem.Text = "Add New Record";
            this.addCommodityItemToolStripMenuItem.Click += new EventHandler(this.addCommodityItemToolStripMenuItem_Click);
            this.viewReordToolStripMenuItem.Name = "viewReordToolStripMenuItem";
            this.viewReordToolStripMenuItem.Size = new Size(190, 0x16);
            this.viewReordToolStripMenuItem.Text = "View Record";
            this.viewReordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            this.editCommodityToolStripMenuItem.Name = "editCommodityToolStripMenuItem";
            this.editCommodityToolStripMenuItem.Size = new Size(190, 0x16);
            this.editCommodityToolStripMenuItem.Text = "Edit  Record";
            this.editCommodityToolStripMenuItem.Click += new EventHandler(this.editCommodityToolStripMenuItem_Click);
            ToolStripItem[] itemArray3 = new ToolStripItem[] { this.synchronizeToolStripMenuItem, this.synchronizeAllToolStripMenuItem };
            this.zWBToolStripMenuItem.DropDownItems.AddRange(itemArray3);
            this.zWBToolStripMenuItem.Name = "zWBToolStripMenuItem";
            this.zWBToolStripMenuItem.Size = new Size(190, 0x16);
            this.zWBToolStripMenuItem.Text = "ZWB";
            this.zWBToolStripMenuItem.Visible = false;
            this.synchronizeToolStripMenuItem.Name = "synchronizeToolStripMenuItem";
            this.synchronizeToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeToolStripMenuItem.Text = "Synchronize";
            this.synchronizeToolStripMenuItem.Click += new EventHandler(this.synchronizeToolStripMenuItem_Click);
            this.synchronizeAllToolStripMenuItem.Name = "synchronizeAllToolStripMenuItem";
            this.synchronizeAllToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeAllToolStripMenuItem.Text = "Synchronize All";
            this.synchronizeAllToolStripMenuItem.Click += new EventHandler(this.synchronizeAllToolStripMenuItem_Click);
            ToolStripItem[] itemArray4 = new ToolStripItem[] { this.copyThisTransTypeToolStripMenuItem, this.copyAllTypesToolStripMenuItem };
            this.copyToAllLocationsToolStripMenuItem.DropDownItems.AddRange(itemArray4);
            this.copyToAllLocationsToolStripMenuItem.Name = "copyToAllLocationsToolStripMenuItem";
            this.copyToAllLocationsToolStripMenuItem.Size = new Size(190, 0x16);
            this.copyToAllLocationsToolStripMenuItem.Text = "Copy To All Locations";
            this.copyThisTransTypeToolStripMenuItem.Name = "copyThisTransTypeToolStripMenuItem";
            this.copyThisTransTypeToolStripMenuItem.Size = new Size(0x9c, 0x16);
            this.copyThisTransTypeToolStripMenuItem.Text = "Copy This Type";
            this.copyThisTransTypeToolStripMenuItem.Click += new EventHandler(this.copyThisTransTypeToolStripMenuItem_Click);
            this.copyAllTypesToolStripMenuItem.Name = "copyAllTypesToolStripMenuItem";
            this.copyAllTypesToolStripMenuItem.Size = new Size(0x9c, 0x16);
            this.copyAllTypesToolStripMenuItem.Text = "Copy All Types";
            this.copyAllTypesToolStripMenuItem.Click += new EventHandler(this.copyAllTypesToolStripMenuItem_Click);
            this.chooseToolStripMenuItem.Name = "chooseToolStripMenuItem";
            this.chooseToolStripMenuItem.Size = new Size(0x3b, 20);
            this.chooseToolStripMenuItem.Text = "Choose";
            this.chooseToolStripMenuItem.Click += new EventHandler(this.chooseToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(420, 0x198);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.menuStrip1);
            base.Name = "FormTransType";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormTransType";
            base.Load += new EventHandler(this.FormTransType_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransType_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void synchronizeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int count = this.dataGridView1.Rows.Count;
            if (MessageBox.Show(WBSetting.integrationIDSYS ? Resource.Mes_035_IDSYS : Resource.Mes_035, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.progressBar1.Visible = true;
                this.progressBar1.Maximum = count;
                if (WBSetting.activeMulesoftIntegration)
                {
                    this.syncTransTypeWithMulesoft("");
                }
                else if (WBSAP.connect())
                {
                    WBSAP.setReturnTable();
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_TRANS_TYPE");
                    WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= count)
                        {
                            WBSAP.showResult(WBSAP.retTable);
                            break;
                        }
                        string str = this.dataGridView1.Rows[num2].Cells["uniq"].Value.ToString().Trim();
                        this.zwbRow[0] = this.dataGridView1.Rows[num2].Cells["Transaction_code"].Value.ToString().Trim();
                        this.zwbRow[1] = this.dataGridView1.Rows[num2].Cells["Transaction_Name"].Value.ToString().Trim();
                        this.zwbRow[2] = (this.dataGridView1.Rows[num2].Cells["IO"].Value.ToString().Trim() == "I") ? "1" : "2";
                        this.zwbRow[3] = "";
                        this.zwbRow[4] = "";
                        this.zwbRow[5] = "";
                        this.zwbRow[6] = "";
                        this.zwbRow[7] = "";
                        this.zwbRow[8] = "";
                        this.zwbRow[9] = "";
                        this.zwbRow[10] = "";
                        this.zwbRow[11] = "";
                        this.zwbRow[12] = "";
                        WBSAP.appendTable(this.zwbRow);
                        WBSAP.sendZWB();
                        this.zwbResult[0] = this.zwbRow[0];
                        this.zwbResult[1] = WBSAP.rfcTable.GetString("STAT");
                        this.zwbResult[2] = WBSAP.rfcTable.GetString("RFC_TEXT");
                        WBSAP.retTable.Rows.Add(this.zwbResult);
                        string[] aField = new string[] { "uniq" };
                        string[] aFind = new string[] { str };
                        this.nCurrRow = this.zTable.GetRecNo(aField, aFind);
                        this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                        this.logKey = this.zTable.DR["uniq"].ToString();
                        this.zTable.DR.BeginEdit();
                        this.zTable.DR["zwb"] = (this.zwbResult[1].ToUpper().Trim() == "Y") ? "Y" : "N";
                        this.zTable.DR.EndEdit();
                        this.zTable.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + this.sapIDSYS };
                        Program.updateLogHeader("wb_transaction_type", this.logKey, logField, logValue);
                        this.progressBar1.Value = num2;
                        num2++;
                    }
                }
            }
        }

        private void synchronizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str2 = this.dataGridView1.CurrentRow.Cells["Transaction_Code"].Value.ToString().Trim();
            string uniq = this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString().Trim();
            string str3 = WBSetting.integrationIDSYS ? Resource.Mes_034_IDSYS : Resource.Mes_034;
            if (MessageBox.Show(str2 + " " + str3, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                if (WBSetting.activeMulesoftIntegration)
                {
                    this.syncTransTypeWithMulesoft(uniq);
                }
                else
                {
                    this.zwbRow[0] = str2;
                    this.zwbRow[1] = this.dataGridView1.CurrentRow.Cells["Transaction_Name"].Value.ToString().Trim();
                    this.zwbRow[2] = (this.dataGridView1.CurrentRow.Cells["IO"].Value.ToString().Trim() == "I") ? "1" : "2";
                    this.zwbRow[3] = "X";
                    this.zwbRow[4] = "X";
                    this.zwbRow[5] = "";
                    this.zwbRow[6] = "";
                    this.zwbRow[7] = "";
                    this.zwbRow[8] = "";
                    this.zwbRow[9] = "";
                    this.zwbRow[10] = "";
                    this.zwbRow[11] = "";
                    this.zwbRow[12] = "";
                    if (WBSAP.connect())
                    {
                        try
                        {
                            WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_WB_TRANS_TYPE");
                            WBSAP.rfcTable = WBSAP.rfcFunction.GetTable("I_RECORD");
                            WBSAP.appendTable(this.zwbRow);
                            WBSAP.sendZWB();
                            this.zwbResult = WBSAP.getResult();
                            string[] aField = new string[] { "uniq" };
                            string[] aFind = new string[] { uniq };
                            this.nCurrRow = this.zTable.GetRecNo(aField, aFind);
                            this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                            this.logKey = this.zTable.DR["uniq"].ToString();
                            this.zTable.DR.BeginEdit();
                            this.zTable.DR["zwb"] = (this.zwbResult[1].ToUpper().Trim() == "Y") ? "Y" : "N";
                            this.zTable.DR.EndEdit();
                            this.zTable.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Sync to " + this.sapIDSYS };
                            Program.updateLogHeader("wb_transaction_type", this.logKey, logField, logValue);
                            if (this.zwbResult[1].ToUpper().Trim() != "Y")
                            {
                                MessageBox.Show(Resource.Mes_078 + this.sapIDSYS + " " + this.zwbResult[2], Resource.Title_006);
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_080 + this.sapIDSYS, Resource.Title_006);
                            }
                        }
                        catch (RfcInvalidParameterException exception)
                        {
                            MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", Resource.Mes_Error_Caps + " <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        catch (RfcCommunicationException exception2)
                        {
                            if (WBUser.UserLevel == "1")
                            {
                                MessageBox.Show(exception2.ToString(), Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, Resource.Mes_Error_Caps + " <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                        }
                        catch (RfcBaseException exception3)
                        {
                            if (WBUser.UserLevel == "1")
                            {
                                MessageBox.Show(exception3.ToString(), Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, Resource.Mes_Error_Caps + " <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                        }
                        catch (Exception exception4)
                        {
                            MessageBox.Show(Resource.Title_003 + " " + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                    }
                }
            }
        }

        private void syncTransTypeWithMulesoft(string uniq)
        {
            Cursor.Current = Cursors.WaitCursor;
            WBTable table = new WBTable();
            WBMulesoftIntegrator integrator = new WBMulesoftIntegrator();
            List<Dictionary<string, string>> sentTable = new List<Dictionary<string, string>>();
            if (uniq == "")
            {
                table.OpenTable("wb_transaction_type", "SELECT * FROM wb_transaction_type WHERE " + WBData.CompanyLocation("") + " ORDER BY transaction_code", WBData.conn);
            }
            else
            {
                string[] textArray1 = new string[] { "SELECT * FROM wb_transaction_type WHERE ", WBData.CompanyLocation(""), " AND uniq = '", uniq, "' ORDER BY transaction_code" };
                table.OpenTable("wb_transaction_type", string.Concat(textArray1), WBData.conn);
            }
            int num = 0;
            while (true)
            {
                if (num >= table.DT.Rows.Count)
                {
                    table.Dispose();
                    integrator.prepareTable();
                    integrator.addTable(sentTable, "I_RECORD");
                    string url = integrator.getURL("ZRFC_DNET_WB_TRANS_TYPE");
                    if (url != "")
                    {
                        bool err = false;
                        string[] resultHeaderName = new string[] { "ERRORS", "I_RECORD", "MESSAGE_ID" };
                        Dictionary<string, List<Dictionary<string, string>>> dictionary = integrator.sendDataToMulesoft(url, resultHeaderName, out err);
                        if (!err)
                        {
                            if (dictionary["ERRORS"].Count > 0)
                            {
                                MessageBox.Show("Error from " + this.sapIDSYS + " : \n\n" + dictionary["ERRORS"][0]["MESSAGE"].ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                            else
                            {
                                DataTable table2 = new DataTable();
                                DataColumn column = new DataColumn {
                                    ColumnName = "Ref1"
                                };
                                table2.Columns.Add(column);
                                column = new DataColumn {
                                    ColumnName = "Stts2"
                                };
                                table2.Columns.Add(column);
                                column = new DataColumn {
                                    ColumnName = "Rmrk3"
                                };
                                table2.Columns.Add(column);
                                column.Dispose();
                                foreach (Dictionary<string, string> dictionary3 in dictionary["I_RECORD"])
                                {
                                    object[] values = new object[] { dictionary3["SSTATUS"].ToString(), dictionary3["STAT"].ToString(), dictionary3["RFC_TEXT"].ToString() };
                                    table2.Rows.Add(values);
                                }
                                FormUploadSAPReturn return2 = new FormUploadSAPReturn {
                                    aTable = table2
                                };
                                return2.ShowDialog();
                                return2.Dispose();
                            }
                            Cursor.Current = Cursors.Default;
                        }
                    }
                    return;
                }
                table.DR = table.DT.Rows[num];
                Dictionary<string, string> item = new Dictionary<string, string> {
                    { 
                        "SSTATUS",
                        table.DR["Transaction_Code"].ToString().Trim()
                    },
                    { 
                        "SNAMA",
                        table.DR["Transaction_Name"].ToString().Trim()
                    },
                    { 
                        "SIO",
                        (table.DR["IO"].ToString().Trim() == "I") ? "1" : "2"
                    },
                    { 
                        "SPOST",
                        "X"
                    },
                    { 
                        "SREPORT",
                        "X"
                    },
                    { 
                        "ERNAM",
                        ""
                    },
                    { 
                        "ERDAT",
                        ""
                    },
                    { 
                        "ERZET",
                        ""
                    },
                    { 
                        "AENAM",
                        ""
                    },
                    { 
                        "AEDAT",
                        ""
                    },
                    { 
                        "AEZET",
                        ""
                    },
                    { 
                        "STAT",
                        ""
                    },
                    { 
                        "RFC_TEXT",
                        ""
                    }
                };
                sentTable.Add(item);
                num++;
            }
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseToolStripMenuItem.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.addCommodityItemToolStripMenuItem.Text = Resource.Menu_Add;
            this.editCommodityToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.buttonFind.Text = Resource.Menu_Find;
            this.viewReordToolStripMenuItem.Text = Resource.Menu_015;
            this.zWBToolStripMenuItem.Text = WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.Menu_ZWB;
            this.synchronizeToolStripMenuItem.Text = Resource.Menu_Synchronize;
            this.synchronizeAllToolStripMenuItem.Text = Resource.Menu_Synchronize_All;
            this.copyToAllLocationsToolStripMenuItem.Text = Resource.Menu_Copy_To_All_Locations;
            this.copyThisTransTypeToolStripMenuItem.Text = Resource.Menu_Copy_Type;
            this.copyAllTypesToolStripMenuItem.Text = Resource.Menu_Copy_All_Types;
            this.Text = Resource.Menu_041;
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.zTable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormTransTypeEntry entry = new FormTransTypeEntry {
                    pMode = "VIEW",
                    zTable = this.zTable,
                    Text = Resource.Mes_View_Transaction_Type,
                    nCurrRow = this.zTable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                this.zTable.UnLock();
                entry.Dispose();
            }
        }
    }
}

