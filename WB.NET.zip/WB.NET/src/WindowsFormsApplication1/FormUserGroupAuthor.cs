﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormUserGroupAuthor : Form
    {
        public DataGridViewRow dr;
        public bool saved = false;
        public bool V;
        public bool A;
        public bool E;
        public bool D;
        public bool P;
        public string desc;
        private IContainer components = null;
        private Label label1;
        private Label label2;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private CheckBox checkBox4;
        private CheckBox checkBox5;
        private Button button1;
        private Button button2;
        private GroupBox groupBox1;
        private Button button3;

        public FormUserGroupAuthor()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.saved = true;
            this.V = this.checkBox1.Checked;
            this.A = this.checkBox2.Checked;
            this.E = this.checkBox3.Checked;
            this.D = this.checkBox4.Checked;
            this.P = this.checkBox5.Checked;
            base.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.saved = false;
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.checkBox1.Checked = true;
            this.checkBox2.Checked = true;
            this.checkBox3.Checked = true;
            this.checkBox4.Checked = true;
            this.checkBox5.Checked = true;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox1.Checked)
            {
                this.checkBox2.Enabled = true;
                this.checkBox3.Enabled = true;
                this.checkBox4.Enabled = true;
                this.checkBox5.Enabled = true;
            }
            else
            {
                this.checkBox2.Checked = false;
                this.checkBox3.Checked = false;
                this.checkBox4.Checked = false;
                this.checkBox5.Checked = false;
                this.checkBox2.Enabled = false;
                this.checkBox3.Enabled = false;
                this.checkBox4.Enabled = false;
                this.checkBox5.Enabled = false;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormUserGroupAuthor_Load(object sender, EventArgs e)
        {
            this.translate();
            this.label2.Text = this.desc;
            this.checkBox1.Checked = this.dr.Cells["V"].Value.ToString() == "*";
            this.checkBox2.Checked = this.dr.Cells["A"].Value.ToString() == "*";
            this.checkBox3.Checked = this.dr.Cells["E"].Value.ToString() == "*";
            this.checkBox4.Checked = this.dr.Cells["D"].Value.ToString() == "*";
            this.checkBox5.Checked = this.dr.Cells["P"].Value.ToString() == "*";
            if (this.checkBox1.Checked)
            {
                this.checkBox2.Enabled = true;
                this.checkBox3.Enabled = true;
                this.checkBox4.Enabled = true;
                this.checkBox5.Enabled = true;
            }
            else
            {
                this.checkBox2.Checked = false;
                this.checkBox3.Checked = false;
                this.checkBox4.Checked = false;
                this.checkBox5.Checked = false;
                this.checkBox2.Enabled = false;
                this.checkBox3.Enabled = false;
                this.checkBox4.Enabled = false;
                this.checkBox5.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.label2 = new Label();
            this.checkBox1 = new CheckBox();
            this.checkBox2 = new CheckBox();
            this.checkBox3 = new CheckBox();
            this.checkBox4 = new CheckBox();
            this.checkBox5 = new CheckBox();
            this.button1 = new Button();
            this.button2 = new Button();
            this.groupBox1 = new GroupBox();
            this.button3 = new Button();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(0x1a, 0x16);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x4f, 0x10);
            this.label1.TabIndex = 0;
            this.label1.Text = "For Activity :";
            this.label2.AutoSize = true;
            this.label2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label2.Location = new Point(0x1a, 0x2d);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x2d, 0x10);
            this.label2.TabIndex = 1;
            this.label2.Text = "label2";
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new Point(0x45, 0x17);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new Size(0x36, 0x11);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "VIEW";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new EventHandler(this.checkBox1_CheckedChanged);
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new Point(0x88, 0x17);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new Size(0x31, 0x11);
            this.checkBox2.TabIndex = 3;
            this.checkBox2.Text = "ADD";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new Point(0xce, 0x17);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new Size(0x33, 0x11);
            this.checkBox3.TabIndex = 4;
            this.checkBox3.Text = "EDIT";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new Point(0x113, 0x17);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new Size(0x44, 0x11);
            this.checkBox4.TabIndex = 5;
            this.checkBox4.Text = "DELETE";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new Point(0x167, 0x17);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new Size(0x3b, 0x11);
            this.checkBox5.TabIndex = 6;
            this.checkBox5.Text = "PRINT";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.button1.Location = new Point(0xb1, 0x86);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 7;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0x114, 0x86);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 8;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.checkBox5);
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Location = new Point(0x1d, 0x40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x1bb, 0x36);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.button3.Location = new Point(8, 0x13);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x2b, 0x17);
            this.button3.TabIndex = 1;
            this.button3.Text = "All";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1fb, 0xac);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Name = "FormUserGroupAuthor";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormUserGroupAuthor";
            base.Load += new EventHandler(this.FormUserGroupAuthor_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.checkBox1.Text = Resource.UserGroup_009;
            this.checkBox2.Text = Resource.UserGroup_010;
            this.checkBox3.Text = Resource.UserGroup_011;
            this.checkBox4.Text = Resource.UserGroup_012;
            this.checkBox5.Text = Resource.UserGroup_013;
        }
    }
}

