﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class RepVessel : Form
    {
        private WBTable s_help_kapal = new WBTable();
        private WBTable s_help_anak = new WBTable();
        private WBTable t_summary1 = new WBTable();
        private WBTable t_summary2 = new WBTable();
        private WBTable t_details = new WBTable();
        private WBTable t_item = new WBTable();
        private WBTable t_map = new WBTable();
        private int gtot_est_net = 0;
        private int gtot_deduction = 0;
        private int gtot_fac_net = 0;
        private int n_do_kapal = 0;
        private string do_kapal;
        private string[] list_kapal = new string[0x3e7];
        private string[] uniq_kapal = new string[0x3e7];
        private IContainer components = null;
        public Button btn_sh_vessel;
        public Label labelDoNo;
        public CheckBox checkDate;
        public TextBox text_do_kapal;
        public GroupBox groupDate;
        public DateTimePicker monthCalendar1;
        public Label label1;
        public Label label2;
        public DateTimePicker monthCalendar2;
        public Button btn_sh_anak;
        public Label label3;
        public TextBox text_do_anak;
        public GroupBox groupBox1;
        private RadioButton rb_detail;
        private RadioButton rb_summary;
        private Button btn_process;
        private Button btn_cancel;

        public RepVessel()
        {
            this.InitializeComponent();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btn_process_Click(object sender, EventArgs e)
        {
            HTML html;
            int num2;
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days <= 31.0)
            {
                if (!this.can_generate())
                {
                    return;
                }
                else
                {
                    html = new HTML();
                    HTML html2 = html;
                    string[] textArray1 = new string[] { html2.File, @"\", WBUser.UserID, "_Fail", DateTime.Today.ToString("dd_MM_yyyy"), ".htm" };
                    html2.File = string.Concat(textArray1);
                    html.Title = "VESSEl REPORT";
                    html.Open();
                    html.Write(html.Style());
                    html.Write("<br><font size=5><b>VESSEL REPORT</b></font><br>");
                    string[] textArray2 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                    html.Write(string.Concat(textArray2));
                    string[] textArray3 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font>" };
                    html.Write(string.Concat(textArray3));
                    if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                    {
                        html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                    }
                    if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                    {
                        html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                    }
                    if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                    {
                        html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                    }
                    html.Write("<br><br>");
                    html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                    if (this.checkDate.Checked)
                    {
                        html.Write("<tr class=bd>");
                        html.Write("<td>Selected Date</td>");
                        html.Write("<td>: <b>" + this.monthCalendar1.Value.ToShortDateString() + "</b></td>");
                        html.Write("</tr>");
                    }
                    html.Write("<tr class=bd>");
                    html.Write("<td>Report Date & Time</td>");
                    html.Write("<td>: <b>" + DateTime.Now.ToString() + "</b></td>");
                    html.Write("</tr>");
                    html.Write("</table>");
                    html.Write("<br/><br/><br/>");
                    html.Write("<br><b>Vessel TRANSACTION</b>");
                    num2 = 0;
                }
            }
            else
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            while (true)
            {
                if (num2 >= this.n_do_kapal)
                {
                    html.Write("<br><br><br>");
                    html.writeSign();
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + html.File) }
                    };
                    html.Close();
                    report.ShowDialog();
                    html.Dispose();
                    report.Dispose();
                    break;
                }
                string str2 = this.uniq_kapal[num2];
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { str2 };
                DataRow data = this.s_help_kapal.GetData(aField, aFind);
                string str = data["do_no"].ToString();
                this.do_kapal = this.list_kapal[num2];
                string[] textArray6 = new string[] { "do_no" };
                string[] textArray7 = new string[] { this.do_kapal };
                DataRow row2 = this.s_help_kapal.GetData(textArray6, textArray7);
                this.get_data(row2["uniq"].ToString());
                this.print_header(html);
                string str3 = "";
                string str4 = "";
                if (this.rb_detail.Checked)
                {
                    str3 = "<b>";
                    str4 = "</b>";
                }
                int num3 = 0;
                this.gtot_est_net = 0;
                this.gtot_deduction = 0;
                this.gtot_fac_net = 0;
                foreach (DataRow row3 in this.t_summary1.DT.Rows)
                {
                    if (row3["split"].ToString() == "Y")
                    {
                        num3++;
                        html.Write("<tr class='bd'>");
                        html.Write("<td align=right>" + num3.ToString() + "</td>");
                        html.Write("<td align=left>" + row3["date1"].ToString().Substring(0, 10) + "</td>");
                        html.Write("<td align=left>" + row3["date2"].ToString().Substring(0, 10) + "</td>");
                        html.Write("<td align=left>" + row3["truck_number"].ToString() + "</td>");
                        html.Write("<td align=left>" + row3["time1"].ToString() + "</td>");
                        html.Write("<td align=left>" + row3["time2"].ToString() + "</td>");
                        TimeSpan span2 = (TimeSpan) (Convert.ToDateTime(row3["date2"].ToString().Substring(0, 10) + " " + row3["Time2"].ToString()) - Convert.ToDateTime(row3["date1"].ToString().Substring(0, 10) + " " + row3["Time1"].ToString()));
                        html.Write("<td nowrap>" + span2.ToString().Substring(0, 5) + "</td>");
                        string[] textArray8 = new string[] { "<td align=left>", str3, row3["ref"].ToString(), str4, "</td>" };
                        html.Write(string.Concat(textArray8));
                        string[] textArray9 = new string[] { "<td align=left>", str3, str, str4, "</td>" };
                        html.Write(string.Concat(textArray9));
                        string[] textArray10 = new string[] { "<td align=right>", str3, row3["s_gross_estate"].ToString(), str4, "</td>" };
                        html.Write(string.Concat(textArray10));
                        string[] textArray11 = new string[] { "<td align=right>", str3, row3["s_tare_estate"].ToString(), str4, "</td>" };
                        html.Write(string.Concat(textArray11));
                        string[] textArray12 = new string[] { "<td align=right>", str3, row3["s_net_estate"].ToString(), str4, "</td>" };
                        html.Write(string.Concat(textArray12));
                        string[] textArray13 = new string[] { "<td align=right>", str3, row3["s_gross"].ToString(), str4, "</td>" };
                        html.Write(string.Concat(textArray13));
                        string[] textArray14 = new string[] { "<td align=right>", str3, row3["s_tare"].ToString(), str4, "</td>" };
                        html.Write(string.Concat(textArray14));
                        string[] textArray15 = new string[] { "<td align=right>", str3, row3["s_deduction"].ToString(), str4, "</td>" };
                        html.Write(string.Concat(textArray15));
                        string[] textArray16 = new string[] { "<td align=right>", str3, row3["s_net"].ToString(), str4, "</td>" };
                        html.Write(string.Concat(textArray16));
                        if (row3["Remark_Ticket"].ToString() == "")
                        {
                            html.Write("<td align=left>&nbsp</td>");
                        }
                        else
                        {
                            html.Write("<td align=left>" + row3["Remark_Ticket"].ToString() + "</td>");
                        }
                        html.Write("</tr>");
                        this.gtot_est_net += int.Parse(row3["s_net_estate"].ToString());
                        this.gtot_deduction += int.Parse(row3["s_deduction"].ToString());
                        this.gtot_fac_net += int.Parse(row3["s_net"].ToString());
                        if (this.rb_detail.Checked)
                        {
                            string sqltext = (((("SELECT trans.*" + " FROM wb_transaction trans") + " WHERE ref LIKE '" + row3["ref"].ToString() + "%'") + " AND (trans.mark_accident IS NULL OR trans.mark_accident = '')") + " AND (trans.mark_return IS NULL OR trans.mark_return = '')" + " AND (trans.Deleted IS NULL OR trans.Deleted = '')") + " AND (trans.Report_Date IS NOT NULL OR trans.Report_Date <> '')" + " ORDER BY trans.ref";
                            this.t_details.OpenTable("vw_os", sqltext, WBData.conn);
                            foreach (DataRow row4 in this.t_details.DT.Rows)
                            {
                                html.Write("<tr class='bd'>");
                                html.Write("<td align=right>&nbsp</td>");
                                html.Write("<td align=left>&nbsp</td>");
                                html.Write("<td align=left>&nbsp</td>");
                                html.Write("<td align=left>&nbsp</td>");
                                html.Write("<td align=left>&nbsp</td>");
                                html.Write("<td align=left>&nbsp</td>");
                                html.Write("<td align=left>&nbsp</td>");
                                html.Write("<td align=left>" + row4["ref"].ToString() + "</td>");
                                html.Write("<td align=left>" + row4["do_no"].ToString() + "</td>");
                                html.Write("<td align=right>" + row4["gross_estate"].ToString() + "</td>");
                                html.Write("<td align=right>" + row4["tare_estate"].ToString() + "</td>");
                                html.Write("<td align=right>" + row4["net_estate"].ToString() + "</td>");
                                html.Write("<td align=right>" + row4["gross"].ToString() + "</td>");
                                html.Write("<td align=right>" + row4["tare"].ToString() + "</td>");
                                html.Write("<td align=right>" + row4["deduction"].ToString() + "</td>");
                                html.Write("<td align=right>" + row4["net"].ToString() + "</td>");
                                if (row4["Remark_Ticket"].ToString() == "")
                                {
                                    html.Write("<td align=left>&nbsp</td>");
                                }
                                else
                                {
                                    html.Write("<td align=left>" + row4["Remark_Ticket"].ToString() + "</td>");
                                }
                                html.Write("</tr>");
                            }
                        }
                    }
                }
                foreach (DataRow row5 in this.t_summary2.DT.Rows)
                {
                    num3++;
                    html.Write("<tr class='bd'>");
                    html.Write("<td align=right>" + num3.ToString() + "</td>");
                    html.Write("<td align=left>" + row5["date1"].ToString().Substring(0, 10) + "</td>");
                    html.Write("<td align=left>" + row5["date2"].ToString().Substring(0, 10) + "</td>");
                    html.Write("<td align=left>" + row5["truck_number"].ToString() + "</td>");
                    html.Write("<td align=left>" + row5["time1"].ToString() + "</td>");
                    html.Write("<td align=left>" + row5["time2"].ToString() + "</td>");
                    DateTime time6 = Convert.ToDateTime(row5["date1"].ToString().Substring(0, 10) + " " + row5["Time1"].ToString());
                    DateTime time7 = Convert.ToDateTime(row5["date2"].ToString().Substring(0, 10) + " " + row5["Time2"].ToString());
                    TimeSpan span3 = (TimeSpan) (time7 - time6);
                    html.Write("<td nowrap>" + span3.ToString().Substring(0, 5) + "</td>");
                    string[] textArray17 = new string[] { "<td align=left>", str3, row5["ref"].ToString(), str4, "</td>" };
                    html.Write(string.Concat(textArray17));
                    string[] textArray18 = new string[] { "<td align=left>", str3, str, str4, "</td>" };
                    html.Write(string.Concat(textArray18));
                    string[] textArray19 = new string[] { "<td align=right>", str3, row5["gross_estate"].ToString(), str4, "</td>" };
                    html.Write(string.Concat(textArray19));
                    string[] textArray20 = new string[] { "<td align=right>", str3, row5["tare_estate"].ToString(), str4, "</td>" };
                    html.Write(string.Concat(textArray20));
                    string[] textArray21 = new string[] { "<td align=right>", str3, row5["net_estate"].ToString(), str4, "</td>" };
                    html.Write(string.Concat(textArray21));
                    string[] textArray22 = new string[] { "<td align=right>", str3, row5["gross"].ToString(), str4, "</td>" };
                    html.Write(string.Concat(textArray22));
                    string[] textArray23 = new string[] { "<td align=right>", str3, row5["tare"].ToString(), str4, "</td>" };
                    html.Write(string.Concat(textArray23));
                    string[] textArray24 = new string[] { "<td align=right>", str3, row5["deduction"].ToString(), str4, "</td>" };
                    html.Write(string.Concat(textArray24));
                    string[] textArray25 = new string[] { "<td align=right>", str3, row5["net"].ToString(), str4, "</td>" };
                    html.Write(string.Concat(textArray25));
                    if (row5["Remark_Ticket"].ToString() == "")
                    {
                        html.Write("<td align=left>&nbsp</td>");
                    }
                    else
                    {
                        html.Write("<td align=left>" + row5["Remark_Ticket"].ToString() + "</td>");
                    }
                    html.Write("</tr>");
                    this.gtot_est_net += int.Parse(row5["net_estate"].ToString());
                    this.gtot_deduction += int.Parse(row5["deduction"].ToString());
                    this.gtot_fac_net += int.Parse(row5["net"].ToString());
                }
                this.grand_total(html);
                html.Write("</table>");
                this.print_map(html, num2);
                num2++;
            }
        }

        private void btn_sh_anak_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                vessel = true,
                pFind = this.text_do_anak.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.text_do_anak.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        private void btn_sh_vessel_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                vessel = true,
                pFind = this.text_do_kapal.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.text_do_kapal.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        private bool can_generate()
        {
            this.text_do_kapal.Text = this.text_do_kapal.Text.Trim();
            this.text_do_anak.Text = this.text_do_anak.Text.Trim();
            DataRow objA = null;
            DataRow data = null;
            if ((this.text_do_kapal.Text != "") || (this.text_do_anak.Text != ""))
            {
                if ((this.text_do_kapal.Text == "") || (this.text_do_anak.Text != ""))
                {
                    if (this.text_do_anak.Text != "")
                    {
                        string[] aField = new string[] { "do_no" };
                        string[] aFind = new string[] { this.text_do_anak.Text };
                        objA = this.s_help_anak.GetData(aField, aFind);
                        if (!ReferenceEquals(objA, null))
                        {
                            if (this.text_do_kapal.Text == "")
                            {
                                string sqltext = ("SELECT do_no, uniq_vessel" + " FROM wb_vessel_map m LEFT JOIN wb_contract c ON m.uniq_vessel = c.uniq") + " WHERE uniq_item = '" + objA["uniq"].ToString() + "' ORDER BY Do_No";
                                this.t_map.OpenTable("wb_contract", sqltext, WBData.conn);
                                if (!ReferenceEquals(this.t_map, null))
                                {
                                    this.n_do_kapal = this.t_map.DT.Rows.Count;
                                    int index = 0;
                                    foreach (DataRow row3 in this.t_map.DT.Rows)
                                    {
                                        this.list_kapal[index] = row3["DO_No"].ToString().ToUpper();
                                        this.uniq_kapal[index] = row3["uniq_vessel"].ToString();
                                        index++;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Invalid Combination of DO Vessel & DO PO", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    return false;
                                }
                            }
                            else
                            {
                                string[] textArray5 = new string[] { "do_no" };
                                string[] textArray6 = new string[] { this.text_do_kapal.Text };
                                data = this.s_help_kapal.GetData(textArray5, textArray6);
                                if (!ReferenceEquals(data, null))
                                {
                                    string sqltext = (("SELECT Do_No, qty_map as Quantity, DeductedBy as Used, DeductedBy as Outstanding," + " Comm_Code , Relation_Code, Estate1_Code, Transporter_Code, Transaction_Code, uniq_vessel" + " FROM wb_vessel_map m LEFT JOIN wb_contract c ON m.uniq_item = c.uniq") + " WHERE uniq_vessel = '" + data["uniq"].ToString() + "'") + " AND uniq_item = '" + objA["uniq"].ToString() + "' ORDER BY Do_No";
                                    this.t_map.OpenTable("wb_contract", sqltext, WBData.conn);
                                    if (!ReferenceEquals(this.t_map, null))
                                    {
                                        this.n_do_kapal = 1;
                                        this.list_kapal[0] = this.text_do_kapal.Text;
                                        this.uniq_kapal[0] = this.t_map.DT.Rows[0]["uniq_vessel"].ToString();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Invalid Combination of DO Vessel & DO PO", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        return false;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Invalid DO Vessel", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    return false;
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Invalid DO PO", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            return false;
                        }
                    }
                }
                else
                {
                    string[] aField = new string[] { "do_no" };
                    string[] aFind = new string[] { this.text_do_kapal.Text };
                    data = this.s_help_kapal.GetData(aField, aFind);
                    if (!ReferenceEquals(data, null))
                    {
                        this.n_do_kapal = 1;
                        this.list_kapal[0] = this.text_do_kapal.Text;
                        this.uniq_kapal[0] = data["uniq"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("Invalid DO Vessel", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        return false;
                    }
                }
            }
            else
            {
                MessageBox.Show("Please enter either DO Vessel or DO PO to continue.", "WARNING...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }
            return true;
        }

        private void checkDate_CheckedChanged(object sender, EventArgs e)
        {
            this.groupDate.Enabled = this.checkDate.Checked;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void get_data(string uniq)
        {
            string sqltext = ("SELECT Do_No, qty_map as Quantity, DeductedBy as Used, DeductedBy as Outstanding," + " Comm_Code , Relation_Code, Estate1_Code, Transporter_Code, Transaction_Code" + " FROM wb_vessel_map m LEFT JOIN wb_contract c ON m.uniq_item = c.uniq") + " WHERE uniq_vessel = '" + uniq + "' ORDER BY Do_No";
            this.t_item.OpenTable("wb_contract", sqltext, WBData.conn);
            sqltext = (((("SELECT trans.*, b.do_no as s_do_no," + " b.gross_estate as s_gross_estate, b.tare_estate as s_tare_estate, b.net_estate as s_net_estate," + " b.gross as s_gross, b.tare as s_tare, b.deduction as s_deduction, b.net as s_net") + " FROM wb_transsplit b" + " LEFT JOIN wb_transaction trans ON trans.ref LIKE b.ref") + " WHERE b.Do_No LIKE '" + this.do_kapal + "'") + " AND (trans.mark_accident IS NULL OR trans.mark_accident = '')" + " AND (trans.mark_return IS NULL OR trans.mark_return = '')") + " AND (trans.Deleted IS NULL OR trans.Deleted = '')" + " AND (trans.Report_Date IS NOT NULL OR trans.Report_Date <> '')";
            if (this.checkDate.Checked)
            {
                sqltext = (sqltext + " and (report_Date>='" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00'") + " and report_Date<='" + this.monthCalendar2.Value.ToString("yyyy-MM-dd") + " 00:00:00')";
            }
            sqltext = sqltext + " ORDER BY trans.ref";
            this.t_summary1.OpenTable("vw_os", sqltext, WBData.conn);
            sqltext = ((("SELECT * " + " FROM wb_transaction trans") + " WHERE trans.Do_No LIKE '" + this.do_kapal + "'") + " AND (trans.mark_accident IS NULL OR trans.mark_accident = '')" + " AND (trans.mark_return IS NULL OR trans.mark_return = '')") + " AND (trans.Deleted IS NULL OR trans.Deleted = '')" + " AND (trans.Report_Date IS NOT NULL OR trans.Report_Date <> '')";
            if (this.checkDate.Checked)
            {
                sqltext = (sqltext + " and (report_Date>='" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00'") + " and report_Date<='" + this.monthCalendar2.Value.ToString("yyyy-MM-dd") + " 00:00:00')";
            }
            this.t_summary2.OpenTable("vw_os", sqltext, WBData.conn);
        }

        private void grand_total(HTML rep)
        {
            rep.Write("<tr class='bd'>");
            rep.Write("<td align=right colspan=9><b>GRAND TOTAL</b></td>");
            rep.Write("<td align=right>&nbsp</td>");
            rep.Write("<td align=right>&nbsp</td>");
            rep.Write("<td align=right><b>" + this.gtot_est_net.ToString() + "</b></td>");
            rep.Write("<td align=right>&nbsp</td>");
            rep.Write("<td align=right>&nbsp</td>");
            rep.Write("<td align=right><b>" + this.gtot_deduction.ToString() + "</b></td>");
            rep.Write("<td align=right><b>" + this.gtot_fac_net.ToString() + "</b></td>");
            rep.Write("<td align=left>&nbsp</td>");
        }

        private void InitializeComponent()
        {
            this.btn_sh_vessel = new Button();
            this.labelDoNo = new Label();
            this.checkDate = new CheckBox();
            this.text_do_kapal = new TextBox();
            this.groupDate = new GroupBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label1 = new Label();
            this.label2 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.btn_sh_anak = new Button();
            this.label3 = new Label();
            this.text_do_anak = new TextBox();
            this.groupBox1 = new GroupBox();
            this.rb_detail = new RadioButton();
            this.rb_summary = new RadioButton();
            this.btn_process = new Button();
            this.btn_cancel = new Button();
            this.groupDate.SuspendLayout();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.btn_sh_vessel.Location = new Point(0x10c, 10);
            this.btn_sh_vessel.Margin = new Padding(0);
            this.btn_sh_vessel.Name = "btn_sh_vessel";
            this.btn_sh_vessel.Size = new Size(0x17, 0x17);
            this.btn_sh_vessel.TabIndex = 1;
            this.btn_sh_vessel.Text = "...";
            this.btn_sh_vessel.UseVisualStyleBackColor = true;
            this.btn_sh_vessel.Click += new EventHandler(this.btn_sh_vessel_Click);
            this.labelDoNo.AutoSize = true;
            this.labelDoNo.Location = new Point(13, 0x10);
            this.labelDoNo.Name = "labelDoNo";
            this.labelDoNo.Size = new Size(0x37, 13);
            this.labelDoNo.TabIndex = 0x27;
            this.labelDoNo.Text = "Do Vessel";
            this.checkDate.AutoSize = true;
            this.checkDate.Checked = true;
            this.checkDate.CheckState = CheckState.Checked;
            this.checkDate.Location = new Point(0x10, 0x40);
            this.checkDate.Name = "checkDate";
            this.checkDate.Size = new Size(60, 0x11);
            this.checkDate.TabIndex = 0x26;
            this.checkDate.Text = "byDate";
            this.checkDate.UseVisualStyleBackColor = true;
            this.checkDate.CheckedChanged += new EventHandler(this.checkDate_CheckedChanged);
            this.text_do_kapal.CharacterCasing = CharacterCasing.Upper;
            this.text_do_kapal.Location = new Point(0x4a, 12);
            this.text_do_kapal.Name = "text_do_kapal";
            this.text_do_kapal.Size = new Size(0xbd, 20);
            this.text_do_kapal.TabIndex = 0;
            this.groupDate.Controls.Add(this.monthCalendar1);
            this.groupDate.Controls.Add(this.label1);
            this.groupDate.Controls.Add(this.label2);
            this.groupDate.Controls.Add(this.monthCalendar2);
            this.groupDate.Location = new Point(12, 0x4e);
            this.groupDate.Name = "groupDate";
            this.groupDate.Size = new Size(0x19e, 0x2d);
            this.groupDate.TabIndex = 0x23;
            this.groupDate.TabStop = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x54, 15);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(12, 0x13);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3e, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "From Date :";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0xd7, 0x13);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x34, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x111, 15);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.btn_sh_anak.Location = new Point(0x10c, 0x24);
            this.btn_sh_anak.Margin = new Padding(0);
            this.btn_sh_anak.Name = "btn_sh_anak";
            this.btn_sh_anak.Size = new Size(0x17, 0x17);
            this.btn_sh_anak.TabIndex = 0x29;
            this.btn_sh_anak.Text = "...";
            this.btn_sh_anak.UseVisualStyleBackColor = true;
            this.btn_sh_anak.Click += new EventHandler(this.btn_sh_anak_Click);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(13, 0x2a);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x27, 13);
            this.label3.TabIndex = 0x2a;
            this.label3.Text = "Do PO";
            this.text_do_anak.CharacterCasing = CharacterCasing.Upper;
            this.text_do_anak.Location = new Point(0x4a, 0x26);
            this.text_do_anak.Name = "text_do_anak";
            this.text_do_anak.Size = new Size(0xbd, 20);
            this.text_do_anak.TabIndex = 40;
            this.groupBox1.Controls.Add(this.rb_detail);
            this.groupBox1.Controls.Add(this.rb_summary);
            this.groupBox1.Location = new Point(12, 0x81);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0xbd, 0x43);
            this.groupBox1.TabIndex = 0x2b;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Report Type";
            this.rb_detail.AutoSize = true;
            this.rb_detail.Location = new Point(6, 0x2a);
            this.rb_detail.Name = "rb_detail";
            this.rb_detail.Size = new Size(0x34, 0x11);
            this.rb_detail.TabIndex = 1;
            this.rb_detail.Text = "Detail";
            this.rb_detail.UseVisualStyleBackColor = true;
            this.rb_summary.AutoSize = true;
            this.rb_summary.Checked = true;
            this.rb_summary.Location = new Point(6, 0x13);
            this.rb_summary.Name = "rb_summary";
            this.rb_summary.Size = new Size(0x44, 0x11);
            this.rb_summary.TabIndex = 0;
            this.rb_summary.TabStop = true;
            this.rb_summary.Text = "Summary";
            this.rb_summary.UseVisualStyleBackColor = true;
            this.btn_process.Location = new Point(270, 0xcd);
            this.btn_process.Name = "btn_process";
            this.btn_process.Size = new Size(0x4b, 0x17);
            this.btn_process.TabIndex = 0x2c;
            this.btn_process.Text = "Process";
            this.btn_process.UseVisualStyleBackColor = true;
            this.btn_process.Click += new EventHandler(this.btn_process_Click);
            this.btn_cancel.Location = new Point(0x15f, 0xcd);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new Size(0x4b, 0x17);
            this.btn_cancel.TabIndex = 0x2d;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new EventHandler(this.btn_cancel_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1b5, 0xef);
            base.Controls.Add(this.btn_cancel);
            base.Controls.Add(this.btn_process);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.btn_sh_anak);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.text_do_anak);
            base.Controls.Add(this.btn_sh_vessel);
            base.Controls.Add(this.labelDoNo);
            base.Controls.Add(this.checkDate);
            base.Controls.Add(this.text_do_kapal);
            base.Controls.Add(this.groupDate);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "RepVessel";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Report Vessel";
            base.Load += new EventHandler(this.RepVessel_Load);
            this.groupDate.ResumeLayout(false);
            this.groupDate.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void print_header(HTML rep)
        {
            rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
            rep.Write("<tr class='bd'>");
            rep.Write("<td align=center><b>No.</b></td>");
            rep.Write("<td align=center><b>Date In</b></td>");
            rep.Write("<td align=center><b>Date Out</b></td>");
            rep.Write("<td align=center><b>Truck No</b></td>");
            rep.Write("<td align=center><b>In</b></td>");
            rep.Write("<td align=center><b>Out</b></td>");
            rep.Write("<td align=center><b>Diff Time</b></td>");
            rep.Write("<td align=center><b>Ref No</b></td>");
            rep.Write("<td align=center><b>Do No</b></td>");
            rep.Write("<td align=center><b>Estate Gross</b></td>");
            rep.Write("<td align=center><b>Estate Tare</b></td>");
            rep.Write("<td align=center><b>Estate Net</b></td>");
            rep.Write("<td align=center><b>Factory Gross</b></td>");
            rep.Write("<td align=center><b>Factory Tare</b></td>");
            rep.Write("<td align=center><b>Deduction</b></td>");
            rep.Write("<td align=center><b>Factory Net</b></td>");
            rep.Write("<td align=center><b>Remark for Ticket</b></td>");
            rep.Write("</tr>");
        }

        private void print_map(HTML rep, int idx)
        {
            string str = this.list_kapal[idx];
            string str2 = this.uniq_kapal[idx];
            string sqltext = (("SELECT do_no, qty_map, quantity" + " FROM wb_vessel_map m LEFT JOIN wb_contract c ON m.uniq_item = c.uniq") + " WHERE uniq_vessel = '" + str2 + "'") + " ORDER BY Do_No";
            this.t_map.OpenTable("wb_contract", sqltext, WBData.conn);
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { str2 };
            DataRow data = this.s_help_kapal.GetData(aField, aFind);
            rep.Write("<br><br><br>");
            rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
            rep.Write("<tr class='bd'>");
            rep.Write("<td align=center><b>DO Vessel</b></td>");
            rep.Write("<td align=center><b>Qty DO Vessel</b></td>");
            rep.Write("<td align=center><b>DO PO</b></td>");
            rep.Write("<td align=center><b>Qty DO PO</b></td>");
            rep.Write("<td align=center><b>Qty DO PO Partial</b></td>");
            rep.Write("</tr>");
            int num = 0;
            foreach (DataRow row2 in this.t_map.DT.Rows)
            {
                rep.Write("<tr class='bd'>");
                if (num == 0)
                {
                    rep.Write("<td align=left><b>" + data["do_no"].ToString() + "</b></td>");
                    rep.Write("<td align=right><b>" + data["quantity"].ToString() + "</b></td>");
                }
                else
                {
                    rep.Write("<td>&nbsp</td>");
                    rep.Write("<td>&nbsp</td>");
                }
                rep.Write("<td align=left>" + row2["do_no"].ToString() + "</td>");
                rep.Write("<td align=right>" + row2["quantity"].ToString() + "</td>");
                rep.Write("<td align=right>" + row2["qty_map"].ToString() + "</td>");
                rep.Write("</tr>");
                num++;
            }
            rep.Write("</table>");
        }

        private void RepVessel_Load(object sender, EventArgs e)
        {
            string sqltext = "SELECT * FROM wb_contract WHERE " + WBData.CompanyLocation(" AND uniq IN (SELECT uniq_vessel FROM wb_vessel_map GROUP BY uniq_vessel) ORDER BY do_no");
            this.s_help_kapal.OpenTable("wb_contract", sqltext, WBData.conn);
            if (this.s_help_kapal.DT.Rows.Count > 0)
            {
                Program.AutoComp(this.s_help_kapal, "do_no", this.text_do_kapal);
            }
            sqltext = "SELECT * FROM wb_contract WHERE " + WBData.CompanyLocation(" ORDER BY do_no");
            this.s_help_anak.OpenTable("wb_contract", sqltext, WBData.conn);
            if (this.s_help_anak.DT.Rows.Count > 0)
            {
                Program.AutoComp(this.s_help_anak, "do_no", this.text_do_anak);
            }
        }
    }
}

