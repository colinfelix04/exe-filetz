﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Runtime.CompilerServices;
    using System.Windows.Forms;

    public class FormSAP_Test : Form
    {
        private IContainer components = null;
        private ListBox listBox1;
        private PropertyGrid propertyGrid1;
        private BackgroundWorker backgroundWorker1;

        public FormSAP_Test()
        {
            this.InitializeComponent();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormSAP_Test_Load(object sender, EventArgs e)
        {
            try
            {
                WBSetting.OpenSetting();
                RfcConfigParameters parameters = new RfcConfigParameters();
                parameters.Add("NAME", "TEST_SAP");
                parameters.Add("USER", WBSetting.Field("SAPLoginID"));
                parameters.Add("PASSWD", Program.shoot(WBSetting.Field("SAPPassword"), false));
                parameters.Add("SYSNR", "00");
                parameters.Add("CLIENT", WBSetting.Field("SAPClient"));
                parameters.Add("IDLE_TIMEOUT", "10");
                parameters.Add("MSHOST", WBSetting.Field("SAPServer"));
                parameters.Add("GROUP", WBSetting.Field("SAPLogonGroup"));
                parameters.Add("SYSID", WBSetting.Field("SAPLogonSystemID"));
                parameters.Add("MSSERV", WBSetting.Field("SAPMSSPort"));
                RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
                RfcRepository repository = destination.Repository;
                IRfcFunction function = repository.CreateFunction("BAPI_COMPANYCODE_GETLIST");
                IRfcFunction function2 = repository.CreateFunction("BAPI_COMPANYCODE_GETDETAIL");
                function.Invoke(destination);
                IRfcTable table = function.GetTable("CompanyCode_List");
                IRfcStructure structure = function.GetStructure("RETURN");
                int num = 0;
                while (true)
                {
                    if (num >= table.RowCount)
                    {
                        if (this.listBox1.Items.Count > 0)
                        {
                            this.listBox1.SelectedIndex = 0;
                            this.propertyGrid1.SelectedObject = this.listBox1.SelectedItem;
                        }
                        break;
                    }
                    table.CurrentIndex = num;
                    string str = table.GetString("COMP_CODE");
                    string str2 = table.GetString("COMP_NAME");
                    Coy item = new Coy();
                    IRfcStructure structure2 = function2.GetStructure("RETURN");
                    IRfcStructure structure3 = function2.GetStructure("COMPANYCODE_DETAIL");
                    function2.SetValue("COMPANYCODEID", str);
                    function2.Invoke(destination);
                    item.Company = structure3.GetString("Company");
                    item.CompanyCode = str;
                    item.CompanyName = str2;
                    item.City = structure3.GetString("CITY");
                    item.Country = structure3.GetString("Country");
                    item.Address = structure3.GetString("ADDR_NO");
                    item.Currency = structure3.GetString("Currency");
                    item.Language = structure3.GetString("LANGU");
                    this.listBox1.Items.Add(item);
                    num++;
                }
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "ERROR <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "ERROR <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "ERROR <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show(Resource.Title_003 + " " + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void InitializeComponent()
        {
            this.listBox1 = new ListBox();
            this.propertyGrid1 = new PropertyGrid();
            this.backgroundWorker1 = new BackgroundWorker();
            base.SuspendLayout();
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new Point(12, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new Size(0xbb, 420);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new EventHandler(this.listBox1_SelectedIndexChanged);
            this.propertyGrid1.Location = new Point(0xcd, 12);
            this.propertyGrid1.Name = "propertyGrid1";
            this.propertyGrid1.Size = new Size(0x1bf, 0x1ab);
            this.propertyGrid1.TabIndex = 1;
            this.backgroundWorker1.DoWork += new DoWorkEventHandler(this.backgroundWorker1_DoWork);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x298, 0x1c3);
            base.Controls.Add(this.propertyGrid1);
            base.Controls.Add(this.listBox1);
            base.Name = "FormSAP_Test";
            this.Text = "FormSAP_Test";
            base.Load += new EventHandler(this.FormSAP_Test_Load);
            base.ResumeLayout(false);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.propertyGrid1.SelectedObject = this.listBox1.SelectedItem;
            this.propertyGrid1.Refresh();
        }

        public class Coy
        {
            public override string ToString() => 
                this.CompanyName;

            public string Company { get; set; }

            public string CompanyCode { get; set; }

            public string CompanyName { get; set; }

            public string Address { get; set; }

            public string City { get; set; }

            public string Country { get; set; }

            public string Currency { get; set; }

            public string Language { get; set; }
        }
    }
}

