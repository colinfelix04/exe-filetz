﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormReportDaily : Form
    {
        public bool isOk = false;
        public string tipe;
        public string kb;
        private WBTable tblComm = new WBTable();
        private WBTable tblTransporter = new WBTable();
        private WBTable tblRelation = new WBTable();
        private WBTable tblRepSetting = new WBTable();
        private int urut = 0;
        private double tillToday = 0.0;
        private double totalTrans;
        private double quantity = 0.0;
        public DateTime dFrom;
        public DateTime dTo;
        private HTML rep = new HTML();
        private IContainer components = null;
        private RadioButton rboGI;
        private CheckBox checkRemarkReport;
        private CheckBox checkRemarkTicket;
        private CheckBox checkSO;
        private CheckBox checkSTO;
        private CheckBox checkGR;
        private CheckBox checkPO;
        public Button buttonComm;
        public Label labelCommName;
        public TextBox textCommodity;
        public Label labelcommodity;
        private RadioButton rboGR;
        public DateTimePicker monthCalendar1;
        private GroupBox groupDate;
        private Label label1;
        private Label label2;
        public DateTimePicker monthCalendar2;
        private GroupBox grType;
        private RadioButton rboNonKB;
        private RadioButton rboKB;
        private CheckBox checkConv;
        private GroupBox grKB;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem processToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ShapeContainer shapeContainer1;
        private LineShape lineShape2;
        private LineShape lineShape1;
        private Label label3;
        private Label label4;
        public Button buttonTransporter;
        public TextBox textTransporter;
        public Label label6;
        public Label labelTransporter;
        public Label labelRelation;
        public Button buttonRelation;
        public TextBox textRelation;
        public Label label8;
        private MaskedTextBox Time2;
        private MaskedTextBox Time1;
        private CheckBox checkTranspoter;
        private CheckBox checkStorage;
        private Button buttonStorage;
        public TextBox textStorage;
        private Label labelStorageName;

        public FormReportDaily()
        {
            this.InitializeComponent();
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
            }
            commodity.Dispose();
        }

        private void buttonRelation_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textRelation.Text = vendor.ReturnRow["relation_code"].ToString();
                this.labelRelation.Text = vendor.ReturnRow["relation_name"].ToString();
            }
            vendor.Dispose();
        }

        private void buttonStorage_Click(object sender, EventArgs e)
        {
            FormStorage storage = new FormStorage {
                pMode = "CHOOSE"
            };
            storage.ShowDialog();
            if (storage.ReturnRow != null)
            {
                this.textStorage.Text = storage.ReturnRow["Storage_Code"].ToString();
                this.labelStorageName.Text = storage.ReturnRow["Storage_Name"].ToString();
                this.textStorage.Focus();
            }
            storage.Dispose();
        }

        private void buttonTransporter_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransporter.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.labelTransporter.Text = transporter.ReturnRow["Transporter_Name"].ToString();
            }
            transporter.Dispose();
        }

        public double cekSisa(string DoNo, double zQty)
        {
            double num;
            WBTable table = new WBTable();
            this.dFrom = this.monthCalendar1.Value;
            this.dTo = this.monthCalendar2.Value;
            string str = Program.DTOC(this.dFrom) + " 00:00:00";
            string str2 = Program.DTOC(this.dTo) + " 00:00:00";
            string[] textArray1 = new string[] { " and  DO_NO = '", DoNo, "' and (deleted is null or deleted = 'N')  and (report_date < '", str, "')" };
            table.OpenTable("vw_trans", "Select sum(NETTO) as Net from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
            if (table.DT.Rows.Count <= 0)
            {
                num = 0.0;
            }
            else
            {
                table.DR = table.DT.Rows[0];
                num = (table.DR["Net"].ToString().Length <= 0) ? 0.0 : Convert.ToDouble(table.DR["Net"].ToString());
            }
            table.Dispose();
            return num;
        }

        private void checkStorage_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkStorage.Checked)
            {
                this.textStorage.Visible = true;
                this.buttonStorage.Visible = true;
                this.labelStorageName.Visible = true;
            }
            else
            {
                this.textStorage.Visible = false;
                this.buttonStorage.Visible = false;
                this.labelStorageName.Visible = false;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void FormReportDaily_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormReportDaily_Load(object sender, EventArgs e)
        {
        }

        private void initHeader()
        {
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("No");
            this.rep.WriteLine("</td>");
            if (this.checkPO.Checked)
            {
                this.rep.WriteLine("<td valign='middle' align='center' >");
                this.rep.WriteLine("PO");
                this.rep.WriteLine("</td>");
            }
            if (this.checkGR.Checked)
            {
                this.rep.WriteLine("<td valign='middle' align='center' >");
                this.rep.WriteLine("GR");
                this.rep.WriteLine("</td>");
            }
            if (this.checkSTO.Checked)
            {
                this.rep.WriteLine("<td valign='middle' align='center' >");
                this.rep.WriteLine("STO");
                this.rep.WriteLine("</td>");
            }
            if (this.checkSO.Checked)
            {
                this.rep.WriteLine("<td valign='middle' align='center' >");
                this.rep.WriteLine("SO");
                this.rep.WriteLine("</td>");
            }
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Date in");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Date out");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Doc. No.");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Plat No");
            this.rep.WriteLine("</td>");
            if (this.checkTranspoter.Checked)
            {
                this.rep.WriteLine("<td valign='middle' align='center' >");
                this.rep.WriteLine("Transporter");
                this.rep.WriteLine("</td>");
            }
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("IN");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("OUT");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Diff");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Est. Gross");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Est. tarra");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Est. Netto");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Fac. Bruto");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Fac. Tarra");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Fac. Netto");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Variance");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("% var.");
            this.rep.WriteLine("</td>");
            if (this.checkConv.Checked)
            {
                this.rep.WriteLine("<td valign='middle' align='center' >");
                this.rep.WriteLine("Qty. Unit");
                this.rep.WriteLine("</td>");
                this.rep.WriteLine("<td valign='middle' align='center' >");
                this.rep.WriteLine("UOM");
                this.rep.WriteLine("</td>");
            }
            if (this.checkStorage.Checked)
            {
                this.rep.WriteLine("<td valign='middle' align='center' >");
                this.rep.WriteLine("Storage");
                this.rep.WriteLine("</td>");
            }
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Total Trans.");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Till Today");
            this.rep.WriteLine("</td>");
            this.rep.WriteLine("<td valign='middle' align='center' >");
            this.rep.WriteLine("Remaining");
            this.rep.WriteLine("</td>");
            if (this.checkRemarkReport.Checked)
            {
                this.rep.WriteLine("<td valign='middle' align='center' >");
                this.rep.WriteLine("Remark Rpt.");
                this.rep.WriteLine("</td>");
            }
            if (this.checkRemarkTicket.Checked)
            {
                this.rep.WriteLine("<td valign='middle' align='center' >");
                this.rep.WriteLine("Remark Ticket");
                this.rep.WriteLine("</td>");
            }
        }

        private void InitializeComponent()
        {
            this.rboGI = new RadioButton();
            this.checkRemarkReport = new CheckBox();
            this.checkRemarkTicket = new CheckBox();
            this.checkSO = new CheckBox();
            this.checkSTO = new CheckBox();
            this.checkGR = new CheckBox();
            this.checkPO = new CheckBox();
            this.buttonComm = new Button();
            this.labelCommName = new Label();
            this.textCommodity = new TextBox();
            this.labelcommodity = new Label();
            this.rboGR = new RadioButton();
            this.monthCalendar1 = new DateTimePicker();
            this.groupDate = new GroupBox();
            this.Time2 = new MaskedTextBox();
            this.Time1 = new MaskedTextBox();
            this.label1 = new Label();
            this.label2 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.grType = new GroupBox();
            this.rboNonKB = new RadioButton();
            this.rboKB = new RadioButton();
            this.checkConv = new CheckBox();
            this.grKB = new GroupBox();
            this.menuStrip1 = new MenuStrip();
            this.processToolStripMenuItem = new ToolStripMenuItem();
            this.exitToolStripMenuItem = new ToolStripMenuItem();
            this.shapeContainer1 = new ShapeContainer();
            this.lineShape2 = new LineShape();
            this.lineShape1 = new LineShape();
            this.label3 = new Label();
            this.label4 = new Label();
            this.buttonTransporter = new Button();
            this.textTransporter = new TextBox();
            this.label6 = new Label();
            this.labelTransporter = new Label();
            this.labelRelation = new Label();
            this.buttonRelation = new Button();
            this.textRelation = new TextBox();
            this.label8 = new Label();
            this.checkTranspoter = new CheckBox();
            this.checkStorage = new CheckBox();
            this.buttonStorage = new Button();
            this.textStorage = new TextBox();
            this.labelStorageName = new Label();
            this.groupDate.SuspendLayout();
            this.grType.SuspendLayout();
            this.grKB.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(0xb0, 0x13);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 1;
            this.rboGI.TabStop = true;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.checkRemarkReport.AutoSize = true;
            this.checkRemarkReport.Location = new Point(0x12, 0x1e5);
            this.checkRemarkReport.Name = "checkRemarkReport";
            this.checkRemarkReport.Size = new Size(0x62, 0x11);
            this.checkRemarkReport.TabIndex = 14;
            this.checkRemarkReport.Text = "Remark Report";
            this.checkRemarkReport.UseVisualStyleBackColor = true;
            this.checkRemarkTicket.AutoSize = true;
            this.checkRemarkTicket.Location = new Point(0x12, 0x1ce);
            this.checkRemarkTicket.Name = "checkRemarkTicket";
            this.checkRemarkTicket.Size = new Size(0x60, 0x11);
            this.checkRemarkTicket.TabIndex = 13;
            this.checkRemarkTicket.Text = "Remark Ticket";
            this.checkRemarkTicket.UseVisualStyleBackColor = true;
            this.checkSO.AutoSize = true;
            this.checkSO.Location = new Point(0xc7, 0x1a0);
            this.checkSO.Name = "checkSO";
            this.checkSO.Size = new Size(0x29, 0x11);
            this.checkSO.TabIndex = 12;
            this.checkSO.Text = "SO";
            this.checkSO.UseVisualStyleBackColor = true;
            this.checkSTO.AutoSize = true;
            this.checkSTO.Location = new Point(0x91, 0x1a0);
            this.checkSTO.Name = "checkSTO";
            this.checkSTO.Size = new Size(0x30, 0x11);
            this.checkSTO.TabIndex = 10;
            this.checkSTO.Text = "STO";
            this.checkSTO.UseVisualStyleBackColor = true;
            this.checkGR.AutoSize = true;
            this.checkGR.Location = new Point(0x54, 0x1a0);
            this.checkGR.Name = "checkGR";
            this.checkGR.Size = new Size(0x2a, 0x11);
            this.checkGR.TabIndex = 9;
            this.checkGR.Text = "GR";
            this.checkGR.UseVisualStyleBackColor = true;
            this.checkPO.AutoSize = true;
            this.checkPO.Location = new Point(0x12, 0x1a0);
            this.checkPO.Name = "checkPO";
            this.checkPO.Size = new Size(0x29, 0x11);
            this.checkPO.TabIndex = 8;
            this.checkPO.Text = "PO";
            this.checkPO.UseVisualStyleBackColor = true;
            this.buttonComm.Location = new Point(0x123, 0x109);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 0x33;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.labelCommName.AutoSize = true;
            this.labelCommName.Location = new Point(0x13d, 270);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x3a, 13);
            this.labelCommName.TabIndex = 50;
            this.labelCommName.Text = "Commodity";
            this.textCommodity.Location = new Point(0x5b, 0x10c);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0xc0, 20);
            this.textCommodity.TabIndex = 3;
            this.textCommodity.Leave += new EventHandler(this.textCommodity_Leave);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x18, 0x10f);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3a, 13);
            this.labelcommodity.TabIndex = 0x30;
            this.labelcommodity.Text = "Commodity";
            this.rboGR.AutoSize = true;
            this.rboGR.Location = new Point(0x10, 0x13);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0;
            this.rboGR.TabStop = true;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x4e, 0x13);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0xc0, 20);
            this.monthCalendar1.TabIndex = 0;
            this.groupDate.Controls.Add(this.Time2);
            this.groupDate.Controls.Add(this.Time1);
            this.groupDate.Controls.Add(this.monthCalendar1);
            this.groupDate.Controls.Add(this.label1);
            this.groupDate.Controls.Add(this.label2);
            this.groupDate.Controls.Add(this.monthCalendar2);
            this.groupDate.Location = new Point(0x12, 0xa2);
            this.groupDate.Name = "groupDate";
            this.groupDate.Size = new Size(0x248, 100);
            this.groupDate.TabIndex = 2;
            this.groupDate.TabStop = false;
            this.Time2.Location = new Point(0x16a, 0x2d);
            this.Time2.Mask = "00:00";
            this.Time2.Name = "Time2";
            this.Time2.Size = new Size(0x29, 20);
            this.Time2.TabIndex = 6;
            this.Time2.ValidatingType = typeof(DateTime);
            this.Time2.Visible = false;
            this.Time1.Location = new Point(0x4e, 0x2d);
            this.Time1.Mask = "00:00";
            this.Time1.Name = "Time1";
            this.Time1.Size = new Size(0x29, 20);
            this.Time1.TabIndex = 5;
            this.Time1.ValidatingType = typeof(DateTime);
            this.Time1.Visible = false;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(6, 0x1a);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3e, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "From Date :";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x130, 0x1a);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x34, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x16a, 0x13);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(180, 20);
            this.monthCalendar2.TabIndex = 1;
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x12, 60);
            this.grType.Name = "grType";
            this.grType.Size = new Size(310, 0x2d);
            this.grType.TabIndex = 0;
            this.grType.TabStop = false;
            this.rboNonKB.AutoSize = true;
            this.rboNonKB.Location = new Point(0xb0, 0x13);
            this.rboNonKB.Name = "rboNonKB";
            this.rboNonKB.Size = new Size(60, 0x11);
            this.rboNonKB.TabIndex = 1;
            this.rboNonKB.TabStop = true;
            this.rboNonKB.Text = "non KB";
            this.rboNonKB.UseVisualStyleBackColor = true;
            this.rboKB.AutoSize = true;
            this.rboKB.Location = new Point(0x10, 0x13);
            this.rboKB.Name = "rboKB";
            this.rboKB.Size = new Size(0x27, 0x11);
            this.rboKB.TabIndex = 0;
            this.rboKB.TabStop = true;
            this.rboKB.Text = "KB";
            this.rboKB.UseVisualStyleBackColor = true;
            this.checkConv.AutoSize = true;
            this.checkConv.Location = new Point(0x12, 0x1fc);
            this.checkConv.Name = "checkConv";
            this.checkConv.Size = new Size(0x83, 0x11);
            this.checkConv.TabIndex = 15;
            this.checkConv.Text = "Commodity Convertion";
            this.checkConv.UseVisualStyleBackColor = true;
            this.grKB.Controls.Add(this.rboNonKB);
            this.grKB.Controls.Add(this.rboKB);
            this.grKB.Location = new Point(0x12, 0x6f);
            this.grKB.Name = "grKB";
            this.grKB.Size = new Size(310, 0x2d);
            this.grKB.TabIndex = 1;
            this.grKB.TabStop = false;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.processToolStripMenuItem, this.exitToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x26a, 0x18);
            this.menuStrip1.TabIndex = 0x40;
            this.menuStrip1.Text = "menuStrip1";
            this.processToolStripMenuItem.Name = "processToolStripMenuItem";
            this.processToolStripMenuItem.ShortcutKeys = Keys.F5;
            this.processToolStripMenuItem.Size = new Size(0x55, 20);
            this.processToolStripMenuItem.Text = "Process  (F5)";
            this.processToolStripMenuItem.Click += new EventHandler(this.processToolStripMenuItem_Click);
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.ShortcutKeys = Keys.F12;
            this.exitToolStripMenuItem.Size = new Size(0x45, 20);
            this.exitToolStripMenuItem.Text = "Exit  (F12)";
            this.exitToolStripMenuItem.Click += new EventHandler(this.exitToolStripMenuItem_Click);
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.lineShape2, this.lineShape1 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(0x26a, 0x236);
            this.shapeContainer1.TabIndex = 0x10;
            this.shapeContainer1.TabStop = false;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 9;
            this.lineShape2.X2 = 0x259;
            this.lineShape2.Y1 = 0x169;
            this.lineShape2.Y2 = 0x169;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 0;
            this.lineShape1.X2 = 0x4b;
            this.lineShape1.Y1 = 0;
            this.lineShape1.Y2 = 0x17;
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Courier New", 9.75f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(15, 0x182);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x68, 0x10);
            this.label3.TabIndex = 0x42;
            this.label3.Text = "Report Field";
            this.label4.AutoSize = true;
            this.label4.Font = new Font("Courier New", 9.75f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label4.Location = new Point(0x18, 0x29);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x88, 0x10);
            this.label4.TabIndex = 0x43;
            this.label4.Text = "Report Parameter";
            this.buttonTransporter.Location = new Point(0x123, 0x123);
            this.buttonTransporter.Margin = new Padding(0);
            this.buttonTransporter.Name = "buttonTransporter";
            this.buttonTransporter.Size = new Size(0x17, 0x17);
            this.buttonTransporter.TabIndex = 0x47;
            this.buttonTransporter.Text = "...";
            this.buttonTransporter.UseVisualStyleBackColor = true;
            this.buttonTransporter.Click += new EventHandler(this.buttonTransporter_Click);
            this.textTransporter.Location = new Point(0x5b, 0x126);
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.Size = new Size(0xc0, 20);
            this.textTransporter.TabIndex = 4;
            this.textTransporter.Leave += new EventHandler(this.textTransporter_Leave);
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x17, 0x128);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x3d, 13);
            this.label6.TabIndex = 0x45;
            this.label6.Text = "Transporter";
            this.labelTransporter.AutoSize = true;
            this.labelTransporter.Location = new Point(0x13d, 0x128);
            this.labelTransporter.Name = "labelTransporter";
            this.labelTransporter.Size = new Size(0x3d, 13);
            this.labelTransporter.TabIndex = 0x48;
            this.labelTransporter.Text = "Transporter";
            this.labelRelation.AutoSize = true;
            this.labelRelation.Location = new Point(0x13d, 0x143);
            this.labelRelation.Name = "labelRelation";
            this.labelRelation.Size = new Size(0x2e, 13);
            this.labelRelation.TabIndex = 0x4c;
            this.labelRelation.Text = "Relation";
            this.buttonRelation.Location = new Point(0x123, 0x13e);
            this.buttonRelation.Margin = new Padding(0);
            this.buttonRelation.Name = "buttonRelation";
            this.buttonRelation.Size = new Size(0x17, 0x17);
            this.buttonRelation.TabIndex = 0x4b;
            this.buttonRelation.Text = "...";
            this.buttonRelation.UseVisualStyleBackColor = true;
            this.buttonRelation.Click += new EventHandler(this.buttonRelation_Click);
            this.textRelation.Location = new Point(0x5b, 0x141);
            this.textRelation.Name = "textRelation";
            this.textRelation.Size = new Size(0xc0, 20);
            this.textRelation.TabIndex = 5;
            this.textRelation.Leave += new EventHandler(this.textBox1_Leave);
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0x23, 0x144);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x2e, 13);
            this.label8.TabIndex = 0x49;
            this.label8.Text = "Relation";
            this.checkTranspoter.AutoSize = true;
            this.checkTranspoter.Location = new Point(0x12, 0x1b7);
            this.checkTranspoter.Name = "checkTranspoter";
            this.checkTranspoter.Size = new Size(80, 0x11);
            this.checkTranspoter.TabIndex = 0x4d;
            this.checkTranspoter.Text = "Transporter";
            this.checkTranspoter.UseVisualStyleBackColor = true;
            this.checkStorage.AutoSize = true;
            this.checkStorage.Location = new Point(0x12, 0x213);
            this.checkStorage.Name = "checkStorage";
            this.checkStorage.Size = new Size(0x3f, 0x11);
            this.checkStorage.TabIndex = 0x4e;
            this.checkStorage.Text = "Storage";
            this.checkStorage.UseVisualStyleBackColor = true;
            this.checkStorage.CheckedChanged += new EventHandler(this.checkStorage_CheckedChanged);
            this.buttonStorage.Location = new Point(0xb2, 0x20d);
            this.buttonStorage.Margin = new Padding(0);
            this.buttonStorage.Name = "buttonStorage";
            this.buttonStorage.Size = new Size(0x17, 0x17);
            this.buttonStorage.TabIndex = 0x51;
            this.buttonStorage.Text = "...";
            this.buttonStorage.UseVisualStyleBackColor = true;
            this.buttonStorage.Click += new EventHandler(this.buttonStorage_Click);
            this.textStorage.CharacterCasing = CharacterCasing.Upper;
            this.textStorage.Location = new Point(0x5b, 0x210);
            this.textStorage.Name = "textStorage";
            this.textStorage.Size = new Size(0x53, 20);
            this.textStorage.TabIndex = 80;
            this.textStorage.Leave += new EventHandler(this.textStorage_Leave);
            this.labelStorageName.AutoSize = true;
            this.labelStorageName.Location = new Point(0xcc, 0x213);
            this.labelStorageName.Name = "labelStorageName";
            this.labelStorageName.Size = new Size(0x48, 13);
            this.labelStorageName.TabIndex = 0x4f;
            this.labelStorageName.Text = "StorageName";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x26a, 0x236);
            base.ControlBox = false;
            base.Controls.Add(this.buttonStorage);
            base.Controls.Add(this.textStorage);
            base.Controls.Add(this.labelStorageName);
            base.Controls.Add(this.checkStorage);
            base.Controls.Add(this.checkTranspoter);
            base.Controls.Add(this.labelRelation);
            base.Controls.Add(this.buttonRelation);
            base.Controls.Add(this.textRelation);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.labelTransporter);
            base.Controls.Add(this.buttonTransporter);
            base.Controls.Add(this.textTransporter);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.checkRemarkReport);
            base.Controls.Add(this.checkRemarkTicket);
            base.Controls.Add(this.checkSO);
            base.Controls.Add(this.checkSTO);
            base.Controls.Add(this.checkGR);
            base.Controls.Add(this.checkPO);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.groupDate);
            base.Controls.Add(this.grType);
            base.Controls.Add(this.checkConv);
            base.Controls.Add(this.grKB);
            base.Controls.Add(this.shapeContainer1);
            base.KeyPreview = true;
            base.Name = "FormReportDaily";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Daily Report";
            base.Load += new EventHandler(this.FormReportDaily_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormReportDaily_KeyPress);
            this.groupDate.ResumeLayout(false);
            this.groupDate.PerformLayout();
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            this.grKB.ResumeLayout(false);
            this.grKB.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void initSetting()
        {
        }

        private void processToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WBSetting.OpenSetting();
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            int count = 0;
            int num2 = 0;
            WBTable table3 = new WBTable();
            WBTable table4 = new WBTable();
            WBTable table5 = new WBTable();
            int num4 = 0;
            int num5 = 0;
            this.dFrom = this.monthCalendar1.Value;
            this.dTo = this.monthCalendar2.Value;
            string str7 = Program.DTOC(this.dFrom) + " 00:00:00";
            string str8 = Program.DTOC(this.dTo) + " 00:00:00";
            this.rep.File = WBData.rptPath + "zzz.htm";
            this.rep.Open();
            this.rep.Title = "Daily Report (HTML Version)";
            this.rep.WriteLine(this.rep.Style());
            this.rep.WriteLine("<body>");
            this.rep.WriteLine("<font size='+1'><b>Daily REPORT</b></font>");
            this.rep.WriteLine("<br>");
            this.rep.WriteLine("<font size='+1'><b>" + WBData.sCoyName + "</b></font>");
            this.rep.WriteLine("<br> <b>" + WBSetting.Field("coy_addr1").ToString() + "</b>");
            string[] textArray1 = new string[] { "<br>From Date <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b>" };
            this.rep.WriteLine(string.Concat(textArray1));
            this.rep.WriteLine("<br> <br> ");
            string[] textArray2 = new string[] { " and (deleted is null or deleted = 'N') and (report_date >= '", str7, "') and (report_date <= '", str8, "') and (deleted = 'N' or deleted is null) " };
            string sqltext = "select distinct Do_NO from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray2));
            if (this.textCommodity.Text.Trim() != "")
            {
                sqltext = sqltext + " and Comm_code = '" + this.textCommodity.Text + "'";
            }
            if (this.textTransporter.Text.Trim() != "")
            {
                sqltext = sqltext + " and transporter_code = '" + this.textTransporter.Text.Trim() + "'";
            }
            if (this.textRelation.Text.Trim() != "")
            {
                sqltext = sqltext + " and relation_code = '" + this.textRelation.Text.Trim() + "'";
            }
            sqltext = !this.rboKB.Checked ? (sqltext + " and berikat  = 'N'") : (sqltext + " and berikat  = 'Y'");
            sqltext = !this.rboGR.Checked ? (sqltext + " and IO  = 'O'") : (sqltext + " and IO  = 'I'");
            if (this.checkStorage.Checked && (this.textStorage.Text.Trim() != ""))
            {
                sqltext = sqltext + " and storage_code = '" + this.textStorage.Text + "'";
            }
            sqltext = sqltext + " order by do_no";
            table.OpenTable("vw_trans", sqltext, WBData.conn);
            count = table.DT.Rows.Count;
            num2 = 0;
            while (true)
            {
                if (num2 >= count)
                {
                    string[] textArray5 = new string[] { "<br> ", this.rep.space(50), this.rep.spaceRight("Create by", 50), this.rep.spaceRight("Checked by", 50), this.rep.spaceRight("Approved by", 50) };
                    string text1 = string.Concat(textArray5);
                    string pText = text1;
                    if (text1 == null)
                    {
                        string local1 = text1;
                        pText = "";
                    }
                    this.rep.WriteLine(pText);
                    this.rep.WriteLine("<br>");
                    this.rep.WriteLine("<br>");
                    this.rep.WriteLine("<br>");
                    this.rep.WriteLine("<br>");
                    string[] textArray6 = new string[] { "<br> ", this.rep.space(0x37), this.rep.spaceRight(WBUser.UserName, 50), this.rep.spaceRight(WBSetting.Field("check_by"), 50), this.rep.spaceRight(WBSetting.Field("Appr_by"), 50) };
                    string text2 = string.Concat(textArray6);
                    string text4 = text2;
                    if (text2 == null)
                    {
                        string local2 = text2;
                        text4 = "";
                    }
                    this.rep.WriteLine(text4);
                    this.rep.WriteLine("</body>");
                    this.rep.Close();
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + this.rep.File) }
                    };
                    report.ShowDialog();
                    this.rep.Dispose();
                    report.Dispose();
                    base.Close();
                    return;
                }
                table.DR = table.DT.Rows[num2];
                table4.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and do_no = '" + table.DR["Do_No"].ToString() + "'"), WBData.conn);
                table4.DR = table4.DT.Rows[0];
                string zValue = table4.DR["comm_code"].ToString();
                this.quantity = Convert.ToDouble(table4.DR["quantity"].ToString());
                this.tillToday = this.cekSisa(table.DR["Do_No"].ToString(), this.quantity);
                string text = Program.getFieldValue("wb_commodity", "comm_name", "comm_code", zValue);
                string[] textArray3 = new string[11];
                textArray3[0] = "<br> <p>  DO : ";
                textArray3[1] = this.rep.spaceRight(table.DR["Do_No"].ToString(), 40);
                textArray3[2] = " Comm : ";
                textArray3[3] = this.rep.spaceRight(text, 40);
                textArray3[4] = " Qty = ";
                textArray3[5] = this.rep.spaceRight(table4.DR["quantity"].ToString(), 12);
                textArray3[6] = " Contract : ";
                textArray3[7] = this.rep.spaceRight(table4.DR["contract"].ToString(), 20);
                textArray3[8] = " Relation : ";
                textArray3[9] = table4.DR["Relation_code"].ToString();
                textArray3[10] = " </p>";
                this.rep.WriteLine(string.Concat(textArray3));
                this.rep.WriteLine("<table border=1 rules=all cellpadding=3 cellspacing=-1 >");
                this.rep.WriteLine("<tr class='bd'>");
                this.initHeader();
                this.rep.WriteLine("</tr>");
                string[] textArray4 = new string[] { " and (deleted is null or deleted ='N') and do_no = '", table.DR["Do_No"].ToString().Trim(), "' and (report_date >= '", str7, "') and (report_date <= '", str8, "') " };
                string str = "select * from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray4));
                table2.OpenTable("vw_trans", str, WBData.conn);
                int num3 = table2.DT.Rows.Count;
                this.totalTrans = 0.0;
                int num6 = 0;
                while (true)
                {
                    if (num6 >= num3)
                    {
                        this.rep.WriteLine("</tr>");
                        this.rep.WriteLine("</table>");
                        this.rep.WriteLine("<br>");
                        num2++;
                        break;
                    }
                    this.rep.WriteLine("<tr class='bd'>");
                    table2.DR = table2.DT.Rows[num6];
                    this.urut++;
                    this.totalTrans += Convert.ToDouble(table2.DR["Netto"].ToString());
                    this.rep.WriteLine("<td valign='middle' align='center' >");
                    this.rep.WriteLine(this.urut.ToString());
                    this.rep.WriteLine("</td>");
                    if (this.checkPO.Checked)
                    {
                        this.rep.WriteLine("<td valign='middle' align='center' >");
                        this.rep.WriteLine(table4.DR["PO"].ToString());
                        this.rep.WriteLine("</td>");
                    }
                    if (this.checkGR.Checked)
                    {
                        this.rep.WriteLine("<td valign='middle' align='center' >");
                        this.rep.WriteLine(table4.DR["GR"].ToString());
                        this.rep.WriteLine("</td>");
                    }
                    if (this.checkSTO.Checked)
                    {
                        this.rep.WriteLine("<td valign='middle' align='center' >");
                        this.rep.WriteLine(table4.DR["STO"].ToString());
                        this.rep.WriteLine("</td>");
                    }
                    if (this.checkSO.Checked)
                    {
                        this.rep.WriteLine("<td valign='middle' align='center' >");
                        this.rep.WriteLine(table4.DR["SO"].ToString());
                        this.rep.WriteLine("</td>");
                    }
                    this.rep.WriteLine("<td valign='middle' align='center' >");
                    DateTime time = Convert.ToDateTime(table2.DR["date1"].ToString());
                    this.rep.WriteLine(time.ToString("dd/MM/yyyy"));
                    this.rep.WriteLine("</td>");
                    string str5 = time.ToString("dd/MM/yyyy");
                    this.rep.WriteLine("<td valign='middle' align='center' >");
                    time = Convert.ToDateTime(table2.DR["Date2"].ToString());
                    this.rep.WriteLine(time.ToString("dd/MM/yyyy"));
                    this.rep.WriteLine("</td>");
                    string str6 = time.ToString("dd/MM/yyyy");
                    this.rep.WriteLine("<td valign='middle' align='center' >");
                    this.rep.WriteLine(table2.DR["Ref"].ToString());
                    this.rep.WriteLine("</td>");
                    this.rep.WriteLine("<td valign='middle' align='left' >");
                    this.rep.WriteLine(table2.DR["Truck_number"].ToString());
                    this.rep.WriteLine("</td>");
                    if (this.checkTranspoter.Checked)
                    {
                        this.rep.WriteLine("<td valign='middle' align='left' >");
                        this.rep.WriteLine(Program.getFieldValue("wb_transporter", "transporter_name", "transporter_code", table2.DR["Transporter_code"].ToString()));
                        this.rep.WriteLine("</td>");
                    }
                    this.rep.WriteLine("<td valign='middle' align='center' >");
                    this.rep.WriteLine(table2.DR["time1"].ToString());
                    this.rep.WriteLine("</td>");
                    this.rep.WriteLine("<td valign='middle' align='center' >");
                    this.rep.WriteLine(table2.DR["time2"].ToString());
                    this.rep.WriteLine("</td>");
                    TimeSpan span = (TimeSpan) (Convert.ToDateTime(str6 + " " + table2.DR["time2"].ToString()) - Convert.ToDateTime(str5 + " " + table2.DR["time1"].ToString()));
                    num5 = span.Minutes / 60;
                    num4 = span.Minutes - (num5 * 60);
                    this.rep.WriteLine("<td valign='middle' align='center' >");
                    this.rep.WriteLine(num5.ToString().PadLeft(2, '0') + ":" + num4.ToString().PadLeft(2, '0'));
                    this.rep.WriteLine("</td>");
                    this.rep.WriteLine("<td valign='middle' align='right' >");
                    this.rep.WriteLine($"{Convert.ToDouble(table2.DR["Gross_estate"].ToString()):N0}");
                    this.rep.WriteLine("</td>");
                    this.rep.WriteLine("<td valign='middle' align='right' >");
                    this.rep.WriteLine($"{Convert.ToDouble(table2.DR["Tare_estate"].ToString()):N0}");
                    this.rep.WriteLine("</td>");
                    this.rep.WriteLine("<td valign='middle' align='right' >");
                    this.rep.WriteLine($"{Convert.ToDouble(table2.DR["Estate_qty"].ToString()):N0}");
                    this.rep.WriteLine("</td>");
                    this.rep.WriteLine("<td valign='middle' align='right' >");
                    this.rep.WriteLine($"{Convert.ToDouble(table2.DR["Bruto"].ToString()):N0}");
                    this.rep.WriteLine("</td>");
                    this.rep.WriteLine("<td valign='middle' align='right' >");
                    this.rep.WriteLine($"{Convert.ToDouble(table2.DR["Tarra"].ToString()):N0}");
                    this.rep.WriteLine("</td>");
                    this.rep.WriteLine("<td valign='middle' align='right' >");
                    this.rep.WriteLine($"{Convert.ToDouble(table2.DR["Netto"].ToString()):N0}");
                    this.rep.WriteLine("</td>");
                    this.rep.WriteLine("<td valign='middle' align='right' >");
                    if (Convert.ToDouble(table2.DR["Estate_qty"].ToString()) > 0.0)
                    {
                        this.rep.WriteLine($"{Convert.ToDouble(table2.DR["Estate_qty"].ToString()) - Convert.ToDouble(table2.DR["Netto"].ToString()):N0}");
                    }
                    else
                    {
                        this.rep.WriteLine("0");
                    }
                    this.rep.WriteLine("</td>");
                    double num7 = 0.0;
                    this.rep.WriteLine("<td valign='middle' align='right' >");
                    if (Convert.ToDouble(table2.DR["Estate_qty"].ToString()) <= 0.0)
                    {
                        this.rep.WriteLine("0");
                    }
                    else
                    {
                        num7 = (Convert.ToDouble(table2.DR["Estate_qty"].ToString()) - Convert.ToDouble(table2.DR["Netto"].ToString())) / Convert.ToDouble(table2.DR["Estate_qty"].ToString());
                        this.rep.WriteLine($"{num7 * 100.0:N3}");
                    }
                    this.rep.WriteLine("</td>");
                    if (this.checkConv.Checked)
                    {
                        this.rep.WriteLine("<td valign='middle' align='right' >");
                        this.rep.WriteLine($"{Convert.ToDouble(table2.DR["Convnett"].ToString()):N0}");
                        this.rep.WriteLine("</td>");
                        this.rep.WriteLine("<td valign='middle' align='center' >");
                        this.rep.WriteLine(table2.DR["Convunit"].ToString());
                        this.rep.WriteLine("</td>");
                    }
                    if (this.checkStorage.Checked)
                    {
                        this.rep.WriteLine("<td valign='middle' align='center' >");
                        this.rep.WriteLine(table2.DR["storage_code"].ToString());
                        this.rep.WriteLine("</td>");
                    }
                    this.rep.WriteLine("<td valign='middle' align='right' >");
                    this.rep.WriteLine($"{this.totalTrans:N0}");
                    this.rep.WriteLine("</td>");
                    this.rep.WriteLine("<td valign='middle' align='right' >");
                    this.tillToday += this.totalTrans;
                    this.rep.WriteLine($"{this.tillToday:N0}");
                    this.rep.WriteLine("</td>");
                    this.rep.WriteLine("<td valign='middle' align='right' >");
                    this.rep.WriteLine($"{this.quantity - this.tillToday:N0}");
                    this.rep.WriteLine("</td>");
                    if (this.checkRemarkReport.Checked)
                    {
                        this.rep.WriteLine("<td valign='middle' align='center' >");
                        this.rep.WriteLine(table2.DR["remark_report"].ToString());
                        this.rep.WriteLine("</td>");
                    }
                    if (this.checkRemarkTicket.Checked)
                    {
                        this.rep.WriteLine("<td valign='middle' align='center' >");
                        this.rep.WriteLine(table2.DR["Remark_ticket"].ToString());
                        this.rep.WriteLine("</td>");
                    }
                    this.rep.WriteLine("</tr>");
                    num6++;
                }
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (this.textRelation.Text.Trim() == "")
            {
                this.labelRelation.Text = "";
            }
            else
            {
                string[] aField = new string[] { "Relation_Code" };
                string[] aFind = new string[] { this.textRelation.Text.Trim() };
                this.tblRelation.DR = this.tblRelation.GetData(aField, aFind);
                if (!ReferenceEquals(this.tblRelation.DR, null))
                {
                    this.labelRelation.Text = this.tblRelation.DR["Relation_Name"].ToString();
                }
                else
                {
                    this.buttonRelation.PerformClick();
                    this.textRelation.Focus();
                }
            }
        }

        private void textCommodity_Leave(object sender, EventArgs e)
        {
            if (this.textCommodity.Text.Trim() == "")
            {
                this.labelCommName.Text = "";
            }
            else
            {
                string[] aField = new string[] { "Comm_Code" };
                string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                this.tblComm.DR = this.tblComm.GetData(aField, aFind);
                if (!ReferenceEquals(this.tblComm.DR, null))
                {
                    this.labelCommName.Text = this.tblComm.DR["Comm_Name"].ToString();
                }
                else
                {
                    this.buttonComm.PerformClick();
                    this.textCommodity.Focus();
                }
            }
        }

        private void textStorage_Leave(object sender, EventArgs e)
        {
            if (this.textStorage.Text == "")
            {
                this.labelStorageName.Text = "";
            }
            else
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_storage", "SELECT * FROM wb_storage Where " + WBData.CompanyLocation(" and storage_code ='" + this.textStorage.Text.Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    this.buttonStorage.PerformClick();
                    this.textStorage.Focus();
                }
                table.Dispose();
            }
        }

        private void textTransporter_Leave(object sender, EventArgs e)
        {
            if (this.textTransporter.Text.Trim() == "")
            {
                this.labelTransporter.Text = "";
            }
            else
            {
                string[] aField = new string[] { "Transporter_Code" };
                string[] aFind = new string[] { this.textTransporter.Text.Trim() };
                this.tblTransporter.DR = this.tblTransporter.GetData(aField, aFind);
                if (!ReferenceEquals(this.tblTransporter.DR, null))
                {
                    this.labelTransporter.Text = this.tblTransporter.DR["Transporter_Name"].ToString();
                }
                else
                {
                    this.buttonTransporter.PerformClick();
                    this.textTransporter.Focus();
                }
            }
        }
    }
}

