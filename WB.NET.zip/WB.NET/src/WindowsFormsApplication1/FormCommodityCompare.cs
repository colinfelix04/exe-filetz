﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCommodityCompare : Form
    {
        public IRfcTable rfcTable;
        public IRfcTable rfcTableD;
        public ProgressBar p1 = new ProgressBar();
        public int inserted;
        public int updated;
        private string msgConv = "";
        private string logKey = "";
        public Dictionary<string, List<Dictionary<string, string>>> adoptTable = new Dictionary<string, List<Dictionary<string, string>>>();
        public Dictionary<string, string> adoptRow = new Dictionary<string, string>();
        private IContainer components = null;
        public DataGridView dataGridView1;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolTotRecord;

        public FormCommodityCompare()
        {
            this.InitializeComponent();
            this.translate();
        }

        public void Compare()
        {
            WBTable comm = new WBTable();
            WBTable commD = new WBTable();
            WBTable table3 = new WBTable();
            WBTable yield = new WBTable();
            DataRow rr = null;
            if (WBSetting.activeMulesoftIntegration)
            {
                this.toolTotRecord.Text = this.adoptTable["I_COMM"].Count + " " + Resource.Mes_047B;
                if (this.adoptTable.Count > 0)
                {
                    this.dataGridView1.ColumnCount = 15;
                    this.dataGridView1.Columns[0].Name = "Comm_code";
                    this.dataGridView1.Columns[1].Name = "Comm_name";
                    this.dataGridView1.Columns[2].Name = "LOCATION_CODE";
                    this.dataGridView1.Columns[3].Name = "Type";
                    this.dataGridView1.Columns[4].Name = "Material";
                    this.dataGridView1.Columns[5].Name = "Material_Type";
                    this.dataGridView1.Columns[6].Name = "form_iso";
                    this.dataGridView1.Columns[7].Name = "Trade";
                    this.dataGridView1.Columns[8].Name = "BulkPack";
                    this.dataGridView1.Columns[9].Name = "PostSAP";
                    this.dataGridView1.Columns[10].Name = "Gross_Weight";
                    this.dataGridView1.Columns[11].Name = "Netto_Weight";
                    this.dataGridView1.Columns[12].Name = "Tolerance";
                    this.dataGridView1.Columns[13].Name = "UOM";
                    this.dataGridView1.Columns[14].Name = "Result";
                    this.dataGridView1.Columns["comm_code"].HeaderText = Resource.CommE_001;
                    this.dataGridView1.Columns["LOCATION_CODE"].HeaderText = Resource.Col_WB_Location;
                    this.dataGridView1.Columns["Material"].HeaderText = Resource.Col_Material;
                    this.p1.Maximum = this.adoptTable["I_COMM"].Count;
                    this.inserted = 0;
                    this.updated = 0;
                    string str = "";
                    bool flag3 = false;
                    int num5 = 0;
                    while (true)
                    {
                        int recNo;
                        if (num5 >= this.adoptTable["I_COMM"].Count)
                        {
                            string str2 = "";
                            List<string> list = new List<string>();
                            yield.OpenTable("Wb_yield", " Select * from wb_yield", WBData.conn);
                            string[] strArray = new string[0x63];
                            WBTable table5 = new WBTable();
                            if (this.adoptTable["I_COMM"].Count == 1)
                            {
                                table5.OpenTable("wb_commodity_detail", "SELECT * FROM wb_commodity_detail WHERE " + WBData.CompanyLocation(" AND Comm_Code = '" + this.adoptTable["I_COMM"][0]["CCOMM"] + "'"), WBData.conn);
                            }
                            else if (this.adoptTable["I_COMM"].Count > 1)
                            {
                                table5.OpenTable("wb_commodity_detail", "SELECT * FROM wb_commodity_detail WHERE " + WBData.CompanyLocation(""), WBData.conn);
                            }
                            str2 = "";
                            int num3 = 0;
                            int index = 0;
                            string[] strArray2 = new string[table5.DT.Rows.Count];
                            foreach (DataRow row2 in table5.DT.Rows)
                            {
                                bool flag16 = false;
                                bool flag17 = false;
                                int num6 = 0;
                                while (true)
                                {
                                    if (num6 < this.adoptTable["I_COMM"].Count)
                                    {
                                        if (row2["Comm_Code"].ToString() != this.adoptTable["I_COMM"][num6]["CCOMM"])
                                        {
                                            num6++;
                                            continue;
                                        }
                                        flag17 = true;
                                    }
                                    int num7 = 0;
                                    while (true)
                                    {
                                        if (num7 < this.adoptTable["I_COMMD"].Count)
                                        {
                                            if ((row2["Comm_Code"].ToString() != this.adoptTable["I_COMMD"][num7]["CCOMM"]) || (row2["QCode"].ToString() != this.adoptTable["I_COMMD"][num7]["CYIELD"]))
                                            {
                                                num7++;
                                                continue;
                                            }
                                            flag16 = true;
                                        }
                                        if (!flag16 & flag17)
                                        {
                                            strArray2[index] = table5.DT.Rows[num3]["uniq"].ToString();
                                            table5.DT.Rows[num3].Delete();
                                            index++;
                                        }
                                        num3++;
                                        break;
                                    }
                                    break;
                                }
                            }
                            table5.Save();
                            int num8 = 0;
                            while (true)
                            {
                                if (num8 >= strArray2.Length)
                                {
                                    str2 = "";
                                    int J = 0;
                                    while (true)
                                    {
                                        if (J >= this.adoptTable["I_COMMD"].Count)
                                        {
                                            list.Clear();
                                            this.msgConv = "";
                                            if ((this.adoptTable["I_COMM"].Count == 1) && (this.dataGridView1.Rows[0].Cells["UOM"].Value.ToString().Trim().ToUpper() != "KG"))
                                            {
                                                this.msgConv = this.dataGridView1.Rows[0].Cells["comm_code"].Value.ToString() + " : ";
                                                string[] textArray28 = new string[] { this.msgConv, "\n ", Resource.Mes_Conversion_Weight_2, " ", $"{this.dataGridView1.Rows[0].Cells["Gross_Weight"].Value:N0}" };
                                                this.msgConv = string.Concat(textArray28);
                                                this.msgConv = this.msgConv + ("\n " + Resource.Mes_Conversion_Weight_3 + " " + $"{this.dataGridView1.Rows[0].Cells["Netto_Weight"].Value:N0}");
                                                this.msgConv = this.msgConv + ("\n " + Resource.Mes_Conversion_Weight_4 + " " + $"{this.dataGridView1.Rows[0].Cells["Tolerance"].Value:N0}");
                                                MessageBox.Show("\n" + Resource.Mes_Conversion_Weight + " \n" + this.msgConv, "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            }
                                            break;
                                        }
                                        if ((str2 == "") || (str2 != this.adoptTable["I_COMMD"][J]["CCOMM"]))
                                        {
                                            str2 = this.adoptTable["I_COMMD"][J]["CCOMM"];
                                            string[] textArray11 = new string[] { " Select * from Wb_Commodity_detail where comm_code = '", this.adoptTable["I_COMMD"][J]["CCOMM"], "' and coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "' " };
                                            commD.OpenTable("Wb_Commodity_detail", string.Concat(textArray11), WBData.conn);
                                        }
                                        string[] aField = new string[] { "QCode" };
                                        string[] aFind = new string[] { this.adoptTable["I_COMMD"][J]["CYIELD"] };
                                        DataRow data = commD.GetData(aField, aFind);
                                        if (!ReferenceEquals(data, null))
                                        {
                                            commD.DR = data;
                                            comm.DR.BeginEdit();
                                            commD.DR["Deduct"] = this.rfcTableD[J].GetString("CDEDUCT_NET").ToString() == "X";
                                            commD.DR.EndEdit();
                                            commD.Save();
                                            WBTable table8 = new WBTable();
                                            string[] textArray17 = new string[] { " AND comm_code = '", this.adoptTable["I_COMMD"][J]["CCOMM"], "' AND QCode = '", this.adoptTable["I_COMMD"][J]["CYIELD"], "'" };
                                            table8.OpenTable("wb_commodity_detail", "SELECT uniq FROM wb_commodity_detail WHERE " + WBData.CompanyLocation(string.Concat(textArray17)), WBData.conn);
                                            this.logKey = table8.DT.Rows[0]["uniq"].ToString();
                                            table8.Dispose();
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Get commodity detail from ZWB" };
                                            Program.updateLogHeader("wb_commodity_detail", this.logKey, logField, logValue);
                                        }
                                        else
                                        {
                                            commD.DR = commD.DT.NewRow();
                                            commD.DR["Coy"] = WBData.sCoyCode;
                                            commD.DR["Location_Code"] = WBData.sLocCode;
                                            commD.DR["Comm_Code"] = this.adoptTable["I_COMMD"][J]["CCOMM"];
                                            commD.DR["QCode"] = this.adoptTable["I_COMMD"][J]["CYIELD"];
                                            commD.DR["QName"] = this.adoptTable["I_COMMD"][J]["CNAMA"];
                                            commD.DR["Deduct"] = this.rfcTableD[J].GetString("CDEDUCT_NET").ToString() == "X";
                                            commD.DT.Rows.Add(commD.DR);
                                            commD.Save();
                                            WBTable table7 = new WBTable();
                                            string[] textArray14 = new string[] { " AND comm_code = '", this.adoptTable["I_COMMD"][J]["CCOMM"], "' AND QCode = '", this.adoptTable["I_COMMD"][J]["CYIELD"], "'" };
                                            table7.OpenTable("wb_commodity_detail", "SELECT uniq FROM wb_commodity_detail WHERE " + WBData.CompanyLocation(string.Concat(textArray14)), WBData.conn);
                                            this.logKey = table7.DT.Rows[0]["uniq"].ToString();
                                            table7.Dispose();
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "ADD", WBUser.UserID, "Get commodity detail from ZWB" };
                                            Program.updateLogHeader("wb_commodity_detail", this.logKey, logField, logValue);
                                        }
                                        string str3 = list.Find(x => x == this.adoptTable["I_COMMD"][J]["CYIELD"]);
                                        if ((str3 == null) || (str3 == ""))
                                        {
                                            list.Add(this.adoptTable["I_COMMD"][J]["CYIELD"]);
                                            string[] textArray20 = new string[] { "yield_code" };
                                            string[] textArray21 = new string[] { this.adoptTable["I_COMMD"][J]["CYIELD"] };
                                            rr = yield.GetData(textArray20, textArray21);
                                            if (rr == null)
                                            {
                                                yield.DR = yield.DT.NewRow();
                                                yield.DR["Coy"] = WBData.sCoyCode;
                                                yield.DR["Location_code"] = WBData.sLocCode;
                                                yield.DR["yield_code"] = this.adoptTable["I_COMMD"][J]["CYIELD"];
                                                yield.DR["Yield_Name"] = this.adoptTable["I_COMMD"][J]["CNAMA"];
                                                yield.DR["type"] = this.adoptTable["I_COMMD"][J]["CNUM"];
                                                yield.DR["Create_By"] = "SYSTEM";
                                                yield.DR["Create_Date"] = DateTime.Now;
                                                yield.DT.Rows.Add(yield.DR);
                                                yield.Save();
                                                WBTable table9 = new WBTable();
                                                table9.OpenTable("wb_yield", "SELECT uniq FROM wb_yield WHERE " + WBData.CompanyLocation(" AND yield_code = '" + this.adoptTable["I_COMMD"][J]["CYIELD"] + "'"), WBData.conn);
                                                this.logKey = table9.DT.Rows[0]["uniq"].ToString();
                                                table9.Dispose();
                                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                string[] logValue = new string[] { "ADD", WBUser.UserID, "Get yield from ZWB" };
                                                Program.updateLogHeader("wb_yield", this.logKey, logField, logValue);
                                            }
                                            else if ((rr["Yield_Name"].ToString() != this.adoptTable["I_COMMD"][J]["CNAMA"]) || (rr["Type"].ToString() != this.adoptTable["I_COMMD"][J]["CNUM"]))
                                            {
                                                string[] textArray22 = new string[] { "yield_code" };
                                                string[] textArray23 = new string[] { this.adoptTable["I_COMMD"][J]["CYIELD"] };
                                                recNo = yield.GetRecNo(textArray22, textArray23);
                                                yield.DR = yield.DT.Rows[recNo];
                                                this.logKey = yield.DR["uniq"].ToString();
                                                yield.DR.BeginEdit();
                                                yield.DR["Yield_Name"] = this.adoptTable["I_COMMD"][J]["CNAMA"];
                                                yield.DR["type"] = this.adoptTable["I_COMMD"][J]["CNUM"];
                                                yield.DR["Change_By"] = "SYSTEM";
                                                yield.DR["Change_Date"] = DateTime.Now;
                                                yield.DR.EndEdit();
                                                yield.Save();
                                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Get yield from ZWB" };
                                                Program.updateLogHeader("wb_yield", this.logKey, logField, logValue);
                                            }
                                        }
                                        J++;
                                    }
                                    break;
                                }
                                if ((strArray2[num8] != "") || ReferenceEquals(strArray2[num8], null))
                                {
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { "DELETE", WBUser.UserID, "Get commodity detail from ZWB" };
                                    Program.updateLogHeader("wb_commodity_detail", strArray2[num8], logField, logValue);
                                }
                                num8++;
                            }
                            break;
                        }
                        this.logKey = "";
                        try
                        {
                            this.p1.Value = num5;
                            this.p1.Refresh();
                            comm.OpenTable("Wb_Commodity", " Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.adoptTable["I_COMM"][num5]["CCOMM"] + "' "), WBData.conn);
                            string[] aField = new string[] { "comm_code" };
                            string[] aFind = new string[] { this.adoptTable["I_COMM"][num5]["CCOMM"] };
                            rr = comm.GetData(aField, aFind);
                            this.dataGridView1.Rows.Add();
                            this.dataGridView1.Rows[num5].Cells["Location_Code"].Value = WBData.sLocCode;
                            this.dataGridView1.Rows[num5].Cells["comm_code"].Value = this.adoptTable["I_COMM"][num5]["CCOMM"];
                            this.dataGridView1.Rows[num5].Cells["comm_name"].Value = this.adoptTable["I_COMM"][num5]["CNAMA"];
                            this.dataGridView1.Rows[num5].Cells["material"].Value = this.adoptTable["I_COMM"][num5]["MATNR"];
                            this.dataGridView1.Rows[num5].Cells["Type"].Value = (this.adoptTable["I_COMM"][num5]["CTYPE"] == "1") ? "S" : ((this.adoptTable["I_COMM"][num5]["CTYPE"] == "2") ? "F" : ((this.adoptTable["I_COMM"][num5]["CTYPE"] == "3") ? "C" : ((this.adoptTable["I_COMM"][num5]["CTYPE"] == "4") ? "G" : "")));
                            this.dataGridView1.Rows[num5].Cells["Material_Type"].Value = this.adoptTable["I_COMM"][num5]["MTART"];
                            this.dataGridView1.Rows[num5].Cells["form_iso"].Value = this.adoptTable["I_COMM"][num5]["CISO"];
                            this.dataGridView1.Rows[num5].Cells["Trade"].Value = (this.adoptTable["I_COMM"][num5]["CTRADE"] == "1") ? "T" : "N";
                            this.dataGridView1.Rows[num5].Cells["BulkPack"].Value = (this.adoptTable["I_COMM"][num5]["CFORM"] == "P") ? "P" : "B";
                            this.dataGridView1.Rows[num5].Cells["PostSAP"].Value = (this.adoptTable["I_COMM"][num5]["CPOST"] == "X") ? "Y" : "N";
                            this.dataGridView1.Rows[num5].Cells["Gross_Weight"].Value = this.adoptTable["I_COMM"][num5]["GROSSWEIGHT"];
                            this.dataGridView1.Rows[num5].Cells["Netto_Weight"].Value = this.adoptTable["I_COMM"][num5]["NETWEIGHT"];
                            this.dataGridView1.Rows[num5].Cells["UOM"].Value = this.adoptTable["I_COMM"][num5]["BASE_UOM"];
                            this.dataGridView1.Rows[num5].Cells["Tolerance"].Value = this.adoptTable["I_COMM"][num5]["CTOL1"];
                            flag3 = true;
                            this.msgConv = this.adoptTable["I_COMM"][num5]["MATNR"];
                            if (((this.msgConv != "") && (this.msgConv.Length > 1)) && ((this.msgConv.Substring(0, 2) == "7.") && (((this.adoptTable["I_COMM"][num5]["GROSSWEIGHT"] == "0.000") || (this.adoptTable["I_COMM"][num5]["NETWEIGHT"] == "0.000")) || (this.adoptTable["I_COMM"][num5]["CTOL1"] == "0.00"))))
                            {
                                flag3 = false;
                                str = "CANCELLED : Commodity Convertion = 0";
                            }
                            if ((this.dataGridView1.Rows[num5].Cells["Trade"].Value.ToString() == "T") && (this.dataGridView1.Rows[num5].Cells["comm_code"].Value.ToString().Trim() != this.dataGridView1.Rows[num5].Cells["material"].Value.ToString().Trim()))
                            {
                                flag3 = false;
                            }
                            if (!flag3)
                            {
                                this.dataGridView1.Rows[num5].Cells["Result"].Value = str;
                            }
                            else
                            {
                                if (rr == null)
                                {
                                    this.dataGridView1.Rows[num5].Cells["Result"].Value = "INSERTED";
                                    this.inserted++;
                                    comm.DR = comm.DT.NewRow();
                                }
                                else
                                {
                                    string[] textArray3 = new string[] { "comm_code" };
                                    string[] textArray4 = new string[] { this.adoptTable["data"][num5]["code"] };
                                    recNo = comm.GetRecNo(textArray3, textArray4);
                                    this.dataGridView1.Rows[num5].Cells["Result"].Value = "UPDATED";
                                    this.updated++;
                                    comm.DR = comm.DT.Rows[recNo];
                                    this.logKey = comm.DR["uniq"].ToString();
                                    comm.DR.BeginEdit();
                                }
                                comm.DR["coy"] = WBData.sCoyCode;
                                comm.DR["Location_code"] = WBData.sLocCode;
                                comm.DR["comm_code"] = this.adoptTable["I_COMM"][num5]["CCOMM"];
                                comm.DR["comm_name"] = this.adoptTable["I_COMM"][num5]["CNAMA"];
                                comm.DR["material"] = this.adoptTable["I_COMM"][num5]["MATNR"];
                                comm.DR["Type"] = (this.adoptTable["I_COMM"][num5]["CTYPE"] == "1") ? "S" : ((this.adoptTable["I_COMM"][num5]["CTYPE"] == "2") ? "F" : ((this.adoptTable["I_COMM"][num5]["CTYPE"] == "3") ? "C" : ((this.adoptTable["I_COMM"][num5]["CTYPE"] == "4") ? "G" : "")));
                                comm.DR["Material_Type"] = this.adoptTable["I_COMM"][num5]["MTART"];
                                comm.DR["form_iso"] = this.adoptTable["I_COMM"][num5]["CISO"];
                                comm.DR["Trade"] = (this.adoptTable["I_COMM"][num5]["CTRADE"] == "1") ? "T" : "N";
                                comm.DR["BulkPack"] = (this.adoptTable["I_COMM"][num5]["CFORM"] == "P") ? "P" : "B";
                                comm.DR["PostSAP"] = (this.adoptTable["I_COMM"][num5]["CPOST"] == "X") ? "Y" : "N";
                                comm.DR["Tolerance"] = this.adoptTable["I_COMM"][num5]["CTOL1"];
                                comm.DR["Gross_Weight"] = this.adoptTable["I_COMM"][num5]["GROSSWEIGHT"];
                                comm.DR["Netto_Weight"] = this.adoptTable["I_COMM"][num5]["NETWEIGHT"];
                                comm.DR["Unit"] = this.adoptTable["I_COMM"][num5]["BASE_UOM"];
                                comm.DR["ZWB"] = "Y";
                                comm.DR["Deleted"] = (this.adoptTable["I_COMM"][num5]["LOEKZ"] == "X") ? "Y" : "N";
                                comm.DR["Get_From_SAP"] = "Y";
                                if (this.adoptTable["I_COMM"][num5]["LOEKZ"] == "X")
                                {
                                    comm.DR["Delete_By"] = "ZWB";
                                    comm.DR["Delete_Date"] = Program.DTOCSAP(DateTime.Now);
                                    this.dataGridView1.Rows[num5].Cells["Result"].Value = "DELETED";
                                }
                                if (rr != null)
                                {
                                    comm.DR["Change_By"] = "ZWB";
                                    comm.DR["Change_Date"] = Program.DTOCSAP(DateTime.Now);
                                    comm.DR.EndEdit();
                                }
                                else
                                {
                                    comm.DR["Create_By"] = "ZWB";
                                    comm.DR["Create_Date"] = Program.DTOCSAP(DateTime.Now);
                                    comm.DT.Rows.Add(comm.DR);
                                }
                                comm.Save();
                                if (this.logKey != "")
                                {
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Get commodity from ZWB" };
                                    Program.updateLogHeader("wb_commodity", this.logKey, logField, logValue);
                                }
                                else
                                {
                                    WBTable table6 = new WBTable();
                                    table6.OpenTable("wb_commodity", "SELECT uniq FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.adoptTable["I_COMM"][num5]["CCOMM"] + "'"), WBData.conn);
                                    this.logKey = table6.DT.Rows[0]["uniq"].ToString();
                                    table6.Dispose();
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { "ADD", WBUser.UserID, "Get commodity from ZWB" };
                                    Program.updateLogHeader("wb_commodity", this.logKey, logField, logValue);
                                }
                            }
                        }
                        catch (SyntaxErrorException exception)
                        {
                            this.dataGridView1.Rows[num5].Cells["comm_code"].Value = this.adoptTable["I_COMM"][num5]["CCOMM"];
                            this.dataGridView1.Rows[num5].Cells["Result"].Value = exception.Message;
                        }
                        num5++;
                    }
                }
                if (WBSetting.copyToLoc == "Y")
                {
                    if (this.adoptTable["I_COMM"].Count == 1)
                    {
                        Program.copyToLoc("wb_commodity", this.adoptTable["I_COMM"][0]["CCOMM"], 0, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                        MessageBox.Show(Resource.Mes_Record_Copied);
                    }
                    else if (this.adoptTable["I_COMM"].Count > 1)
                    {
                        Program.copyToLoc("wb_commodity", "", 1, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                        string[] textArray29 = new string[] { Resource.Mes_Copy_From, " ", WBData.sCoyCode, " - ", WBData.sLocCode };
                        MessageBox.Show(Resource.Mes_Records_Copied, string.Concat(textArray29));
                    }
                }
            }
            else if (WBSetting.integrationIDSYS)
            {
                this.dataIDSYS(comm, commD, table3, yield, rr);
            }
            else
            {
                this.toolTotRecord.Text = this.rfcTable.RowCount.ToString() + " " + Resource.Mes_047B;
                if (this.rfcTable.RowCount > 0)
                {
                    this.dataGridView1.ColumnCount = 15;
                    this.dataGridView1.Columns[0].Name = "Comm_code";
                    this.dataGridView1.Columns[1].Name = "Comm_name";
                    this.dataGridView1.Columns[2].Name = "LOCATION_CODE";
                    this.dataGridView1.Columns[3].Name = "Type";
                    this.dataGridView1.Columns[4].Name = "Material";
                    this.dataGridView1.Columns[5].Name = "Material_Type";
                    this.dataGridView1.Columns[6].Name = "form_iso";
                    this.dataGridView1.Columns[7].Name = "Trade";
                    this.dataGridView1.Columns[8].Name = "BulkPack";
                    this.dataGridView1.Columns[9].Name = "PostSAP";
                    this.dataGridView1.Columns[10].Name = "Gross_Weight";
                    this.dataGridView1.Columns[11].Name = "Netto_Weight";
                    this.dataGridView1.Columns[12].Name = "Tolerance";
                    this.dataGridView1.Columns[13].Name = "UOM";
                    this.dataGridView1.Columns[14].Name = "Result";
                    this.dataGridView1.Columns["comm_code"].HeaderText = Resource.CommE_001;
                    this.dataGridView1.Columns["LOCATION_CODE"].HeaderText = Resource.Col_WB_Location;
                    this.dataGridView1.Columns["Material"].HeaderText = Resource.Col_Material;
                    this.p1.Maximum = this.rfcTable.RowCount;
                    this.inserted = 0;
                    this.updated = 0;
                    string str4 = "";
                    bool flag40 = false;
                    int num14 = 0;
                    while (true)
                    {
                        int recNo;
                        if (num14 >= this.rfcTable.RowCount)
                        {
                            string str5 = "";
                            List<string> list2 = new List<string>();
                            yield.OpenTable("Wb_yield", " Select * from wb_yield", WBData.conn);
                            string[] strArray3 = new string[0x63];
                            WBTable table10 = new WBTable();
                            if (this.rfcTable.RowCount == 1)
                            {
                                table10.OpenTable("wb_commodity_detail", "SELECT * FROM wb_commodity_detail WHERE " + WBData.CompanyLocation(" AND Comm_Code = '" + this.rfcTable[0].GetString("CCOMM").ToString() + "'"), WBData.conn);
                            }
                            else if (this.rfcTable.RowCount > 1)
                            {
                                table10.OpenTable("wb_commodity_detail", "SELECT * FROM wb_commodity_detail WHERE " + WBData.CompanyLocation(""), WBData.conn);
                            }
                            str5 = "";
                            int num12 = 0;
                            int index = 0;
                            string[] strArray4 = new string[table10.DT.Rows.Count];
                            foreach (DataRow row4 in table10.DT.Rows)
                            {
                                bool flag53 = false;
                                bool flag54 = false;
                                int num15 = 0;
                                while (true)
                                {
                                    if (num15 < this.rfcTable.RowCount)
                                    {
                                        if (row4["Comm_Code"].ToString() != this.rfcTable[num15].GetString("CCOMM").ToString())
                                        {
                                            num15++;
                                            continue;
                                        }
                                        flag54 = true;
                                    }
                                    int num16 = 0;
                                    while (true)
                                    {
                                        if (num16 < this.rfcTableD.RowCount)
                                        {
                                            if ((row4["Comm_Code"].ToString() != this.rfcTableD[num16].GetString("CCOMM").ToString()) || (row4["QCode"].ToString() != this.rfcTableD[num16].GetString("CYIELD").ToString()))
                                            {
                                                num16++;
                                                continue;
                                            }
                                            flag53 = true;
                                        }
                                        if (!flag53 & flag54)
                                        {
                                            strArray4[index] = table10.DT.Rows[num12]["uniq"].ToString();
                                            table10.DT.Rows[num12].Delete();
                                            index++;
                                        }
                                        num12++;
                                        break;
                                    }
                                    break;
                                }
                            }
                            table10.Save();
                            int num17 = 0;
                            while (true)
                            {
                                if (num17 >= strArray4.Length)
                                {
                                    str5 = "";
                                    int num1 = 0;
                                    while (true)
                                    {
                                        if (num1 >= this.rfcTableD.RowCount)
                                        {
                                            list2.Clear();
                                            this.msgConv = "";
                                            if ((this.rfcTable.RowCount == 1) && (this.dataGridView1.Rows[0].Cells["UOM"].Value.ToString().Trim().ToUpper() != "KG"))
                                            {
                                                this.msgConv = this.dataGridView1.Rows[0].Cells["comm_code"].Value.ToString() + " : ";
                                                string[] textArray57 = new string[] { this.msgConv, "\n ", Resource.Mes_Conversion_Weight_2, " ", $"{this.dataGridView1.Rows[0].Cells["Gross_Weight"].Value:N0}" };
                                                this.msgConv = string.Concat(textArray57);
                                                this.msgConv = this.msgConv + ("\n " + Resource.Mes_Conversion_Weight_3 + " " + $"{this.dataGridView1.Rows[0].Cells["Netto_Weight"].Value:N0}");
                                                this.msgConv = this.msgConv + ("\n " + Resource.Mes_Conversion_Weight_4 + " " + $"{this.dataGridView1.Rows[0].Cells["Tolerance"].Value:N0}");
                                                MessageBox.Show("\n" + Resource.Mes_Conversion_Weight + " \n" + this.msgConv, "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            }
                                            break;
                                        }
                                        if ((str5 == "") || (str5 != this.rfcTableD[num1].GetString("CCOMM").ToString()))
                                        {
                                            str5 = this.rfcTableD[num1].GetString("CCOMM").ToString();
                                            string[] textArray40 = new string[] { " Select * from Wb_Commodity_detail where comm_code = '", this.rfcTableD[num1].GetString("CCOMM").ToString(), "' and coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "' " };
                                            commD.OpenTable("Wb_Commodity_detail", string.Concat(textArray40), WBData.conn);
                                        }
                                        string[] aField = new string[] { "QCode" };
                                        string[] aFind = new string[] { this.rfcTableD[num1].GetString("CYIELD").ToString() };
                                        DataRow data = commD.GetData(aField, aFind);
                                        if (!ReferenceEquals(data, null))
                                        {
                                            commD.DR = data;
                                            comm.DR.BeginEdit();
                                            commD.DR["Deduct"] = this.rfcTableD[num1].GetString("CDEDUCT_NET").ToString() == "X";
                                            commD.DR.EndEdit();
                                            commD.Save();
                                            WBTable table13 = new WBTable();
                                            string[] textArray46 = new string[] { " AND comm_code = '", this.rfcTableD[num1].GetString("CCOMM").ToString(), "' AND QCode = '", this.rfcTableD[num1].GetString("CYIELD").ToString(), "'" };
                                            table13.OpenTable("wb_commodity_detail", "SELECT uniq FROM wb_commodity_detail WHERE " + WBData.CompanyLocation(string.Concat(textArray46)), WBData.conn);
                                            this.logKey = table13.DT.Rows[0]["uniq"].ToString();
                                            table13.Dispose();
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "EDIT", WBUser.UserID, "Get commodity detail from ZWB" };
                                            Program.updateLogHeader("wb_commodity_detail", this.logKey, logField, logValue);
                                        }
                                        else
                                        {
                                            commD.DR = commD.DT.NewRow();
                                            commD.DR["Coy"] = WBData.sCoyCode;
                                            commD.DR["Location_Code"] = WBData.sLocCode;
                                            commD.DR["Comm_Code"] = this.rfcTableD[num1].GetString("CCOMM").ToString();
                                            commD.DR["QCode"] = this.rfcTableD[num1].GetString("CYIELD").ToString();
                                            commD.DR["QName"] = this.rfcTableD[num1].GetString("CNAMA").ToString();
                                            commD.DR["Deduct"] = this.rfcTableD[num1].GetString("CDEDUCT_NET").ToString() == "X";
                                            commD.DT.Rows.Add(commD.DR);
                                            commD.Save();
                                            WBTable table12 = new WBTable();
                                            string[] textArray43 = new string[] { " AND comm_code = '", this.rfcTableD[num1].GetString("CCOMM").ToString(), "' AND QCode = '", this.rfcTableD[num1].GetString("CYIELD").ToString(), "'" };
                                            table12.OpenTable("wb_commodity_detail", "SELECT uniq FROM wb_commodity_detail WHERE " + WBData.CompanyLocation(string.Concat(textArray43)), WBData.conn);
                                            this.logKey = table12.DT.Rows[0]["uniq"].ToString();
                                            table12.Dispose();
                                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                            string[] logValue = new string[] { "ADD", WBUser.UserID, "Get commodity detail from ZWB" };
                                            Program.updateLogHeader("wb_commodity_detail", this.logKey, logField, logValue);
                                        }
                                        string str6 = list2.Find(x => x == this.rfcTableD[num1].GetString("CYIELD").ToString());
                                        if ((str6 == null) || (str6 == ""))
                                        {
                                            list2.Add(this.rfcTableD[num1].GetString("CYIELD").ToString());
                                            string[] textArray49 = new string[] { "yield_code" };
                                            string[] textArray50 = new string[] { this.rfcTableD[num1].GetString("CYIELD").ToString() };
                                            rr = yield.GetData(textArray49, textArray50);
                                            if (rr == null)
                                            {
                                                yield.DR = yield.DT.NewRow();
                                                yield.DR["Coy"] = WBData.sCoyCode;
                                                yield.DR["Location_code"] = WBData.sLocCode;
                                                yield.DR["yield_code"] = this.rfcTableD[num1].GetString("CYIELD").ToString();
                                                yield.DR["Yield_Name"] = this.rfcTableD[num1].GetString("CNAMA").ToString();
                                                yield.DR["type"] = this.rfcTableD[num1].GetString("CNUM").ToString();
                                                yield.DR["Create_By"] = "SYSTEM";
                                                yield.DR["Create_Date"] = DateTime.Now;
                                                yield.DT.Rows.Add(yield.DR);
                                                yield.Save();
                                                WBTable table14 = new WBTable();
                                                table14.OpenTable("wb_yield", "SELECT uniq FROM wb_yield WHERE " + WBData.CompanyLocation(" AND yield_code = '" + this.rfcTableD[num1].GetString("CYIELD").ToString() + "'"), WBData.conn);
                                                this.logKey = table14.DT.Rows[0]["uniq"].ToString();
                                                table14.Dispose();
                                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                string[] logValue = new string[] { "ADD", WBUser.UserID, "Get yield from ZWB" };
                                                Program.updateLogHeader("wb_yield", this.logKey, logField, logValue);
                                            }
                                            else if ((rr["Yield_Name"].ToString() != this.rfcTableD[num1].GetString("CNAMA").ToString()) || (rr["Type"].ToString() != this.rfcTableD[num1].GetString("CNUM").ToString()))
                                            {
                                                string[] textArray51 = new string[] { "yield_code" };
                                                string[] textArray52 = new string[] { this.rfcTableD[num1].GetString("CYIELD").ToString() };
                                                recNo = yield.GetRecNo(textArray51, textArray52);
                                                yield.DR = yield.DT.Rows[recNo];
                                                this.logKey = yield.DR["uniq"].ToString();
                                                yield.DR.BeginEdit();
                                                yield.DR["Yield_Name"] = this.rfcTableD[num1].GetString("CNAMA").ToString();
                                                yield.DR["type"] = this.rfcTableD[num1].GetString("CNUM").ToString();
                                                yield.DR["Change_By"] = "SYSTEM";
                                                yield.DR["Change_Date"] = DateTime.Now;
                                                yield.DR.EndEdit();
                                                yield.Save();
                                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Get yield from ZWB" };
                                                Program.updateLogHeader("wb_yield", this.logKey, logField, logValue);
                                            }
                                        }
                                        num1++;
                                    }
                                    break;
                                }
                                if ((strArray4[num17] != "") || ReferenceEquals(strArray4[num17], null))
                                {
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { "DELETE", WBUser.UserID, "Get commodity detail from ZWB" };
                                    Program.updateLogHeader("wb_commodity_detail", strArray4[num17], logField, logValue);
                                }
                                num17++;
                            }
                            break;
                        }
                        this.logKey = "";
                        try
                        {
                            this.p1.Value = num14;
                            this.p1.Refresh();
                            comm.OpenTable("Wb_Commodity", " Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.rfcTable[num14].GetString("CCOMM").ToString() + "' "), WBData.conn);
                            string[] aField = new string[] { "comm_code" };
                            string[] aFind = new string[] { this.rfcTable[num14].GetString("CCOMM").ToString() };
                            rr = comm.GetData(aField, aFind);
                            this.dataGridView1.Rows.Add();
                            this.dataGridView1.Rows[num14].Cells["Location_Code"].Value = WBData.sLocCode;
                            this.dataGridView1.Rows[num14].Cells["comm_code"].Value = this.rfcTable[num14].GetString("CCOMM").ToString();
                            this.dataGridView1.Rows[num14].Cells["comm_name"].Value = this.rfcTable[num14].GetString("CNAMA").ToString();
                            this.dataGridView1.Rows[num14].Cells["material"].Value = this.rfcTable[num14].GetString("MATNR").ToString();
                            this.dataGridView1.Rows[num14].Cells["Type"].Value = (this.rfcTable[num14].GetString("CTYPE").ToString().Trim() == "1") ? "S" : ((this.rfcTable[num14].GetString("CTYPE").ToString().Trim() == "2") ? "F" : ((this.rfcTable[num14].GetString("CTYPE").ToString().Trim() == "3") ? "C" : ((this.rfcTable[num14].GetString("CTYPE").ToString().Trim() == "4") ? "G" : "")));
                            this.dataGridView1.Rows[num14].Cells["Material_Type"].Value = this.rfcTable[num14].GetString("mtart").ToString();
                            this.dataGridView1.Rows[num14].Cells["form_iso"].Value = this.rfcTable[num14].GetString("ciso").ToString();
                            this.dataGridView1.Rows[num14].Cells["Trade"].Value = (this.rfcTable[num14].GetString("ctrade").ToString().Trim() == "1") ? "T" : "N";
                            this.dataGridView1.Rows[num14].Cells["BulkPack"].Value = (this.rfcTable[num14].GetString("cform").ToString().Trim() == "P") ? "P" : "B";
                            this.dataGridView1.Rows[num14].Cells["PostSAP"].Value = (this.rfcTable[num14].GetString("cPost").ToString().Trim() == "X") ? "Y" : "N";
                            this.dataGridView1.Rows[num14].Cells["Gross_Weight"].Value = this.rfcTable[num14].GetString("GROSSWEIGHT").ToString();
                            this.dataGridView1.Rows[num14].Cells["Netto_Weight"].Value = this.rfcTable[num14].GetString("NETWEIGHT").ToString();
                            this.dataGridView1.Rows[num14].Cells["UOM"].Value = this.rfcTable[num14].GetString("BASE_UOM").ToString();
                            this.dataGridView1.Rows[num14].Cells["Tolerance"].Value = this.rfcTable[num14].GetString("CTOL1").ToString();
                            flag40 = true;
                            this.msgConv = this.rfcTable[num14].GetString("MATNR").ToString();
                            if (((this.msgConv != "") && (this.msgConv.Length > 1)) && ((this.msgConv.Substring(0, 2) == "7.") && (((this.rfcTable[num14].GetString("GROSSWEIGHT").ToString().Trim() == "0.000") || (this.rfcTable[num14].GetString("NETWEIGHT").ToString().Trim() == "0.000")) || (this.rfcTable[num14].GetString("CTOL1").ToString().Trim() == "0.00"))))
                            {
                                flag40 = false;
                                str4 = "CANCELLED : Commodity Convertion = 0";
                            }
                            if ((this.dataGridView1.Rows[num14].Cells["Trade"].Value.ToString() == "T") && (this.dataGridView1.Rows[num14].Cells["comm_code"].Value.ToString().Trim() != this.dataGridView1.Rows[num14].Cells["material"].Value.ToString().Trim()))
                            {
                                flag40 = false;
                            }
                            if (!flag40)
                            {
                                this.dataGridView1.Rows[num14].Cells["Result"].Value = str4;
                            }
                            else
                            {
                                if (rr == null)
                                {
                                    this.dataGridView1.Rows[num14].Cells["Result"].Value = "INSERTED";
                                    this.inserted++;
                                    comm.DR = comm.DT.NewRow();
                                }
                                else
                                {
                                    string[] textArray32 = new string[] { "comm_code" };
                                    string[] textArray33 = new string[] { this.rfcTable[num14].GetString("CCOMM").ToString() };
                                    recNo = comm.GetRecNo(textArray32, textArray33);
                                    this.dataGridView1.Rows[num14].Cells["Result"].Value = "UPDATED";
                                    this.updated++;
                                    comm.DR = comm.DT.Rows[recNo];
                                    this.logKey = comm.DR["uniq"].ToString();
                                    comm.DR.BeginEdit();
                                }
                                comm.DR["coy"] = WBData.sCoyCode;
                                comm.DR["Location_code"] = WBData.sLocCode;
                                comm.DR["comm_code"] = this.rfcTable[num14].GetString("CCOMM").ToString();
                                comm.DR["comm_name"] = this.rfcTable[num14].GetString("cnama").ToString();
                                comm.DR["material"] = this.rfcTable[num14].GetString("MATNR").ToString();
                                comm.DR["Type"] = (this.rfcTable[num14].GetString("CTYPE").ToString().Trim() == "1") ? "S" : ((this.rfcTable[num14].GetString("CTYPE").ToString().Trim() == "2") ? "F" : ((this.rfcTable[num14].GetString("CTYPE").ToString().Trim() == "3") ? "C" : ((this.rfcTable[num14].GetString("CTYPE").ToString().Trim() == "4") ? "G" : "")));
                                comm.DR["Material_Type"] = this.rfcTable[num14].GetString("mtart").ToString();
                                comm.DR["form_iso"] = this.rfcTable[num14].GetString("ciso").ToString();
                                comm.DR["Trade"] = (this.rfcTable[num14].GetString("ctrade").ToString().Trim() == "1") ? "T" : "N";
                                comm.DR["BulkPack"] = (this.rfcTable[num14].GetString("cform").ToString().Trim() == "P") ? "P" : "B";
                                comm.DR["PostSAP"] = (this.rfcTable[num14].GetString("cPost").ToString().Trim() == "X") ? "Y" : "N";
                                comm.DR["Tolerance"] = this.rfcTable[num14].GetString("CTOL1").ToString().Trim();
                                comm.DR["Gross_Weight"] = this.rfcTable[num14].GetString("GROSSWEIGHT").ToString().Trim();
                                comm.DR["Netto_Weight"] = this.rfcTable[num14].GetString("NETWEIGHT").ToString().Trim();
                                comm.DR["Unit"] = this.rfcTable[num14].GetString("BASE_UOM").ToString().Trim();
                                comm.DR["ZWB"] = "Y";
                                comm.DR["Deleted"] = (this.rfcTable[num14].GetString("LOEKZ").ToString().Trim() == "X") ? "Y" : "N";
                                comm.DR["Get_From_SAP"] = "Y";
                                if (this.rfcTable[num14].GetString("LOEKZ").ToString().Trim() == "X")
                                {
                                    comm.DR["Delete_By"] = "ZWB";
                                    comm.DR["Delete_Date"] = Program.DTOCSAP(DateTime.Now);
                                    this.dataGridView1.Rows[num14].Cells["Result"].Value = "DELETED";
                                }
                                if (rr != null)
                                {
                                    comm.DR["Change_By"] = "ZWB";
                                    comm.DR["Change_Date"] = Program.DTOCSAP(DateTime.Now);
                                    comm.DR.EndEdit();
                                }
                                else
                                {
                                    comm.DR["Create_By"] = "ZWB";
                                    comm.DR["Create_Date"] = Program.DTOCSAP(DateTime.Now);
                                    comm.DT.Rows.Add(comm.DR);
                                }
                                comm.Save();
                                if (this.logKey != "")
                                {
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Get commodity from ZWB" };
                                    Program.updateLogHeader("wb_commodity", this.logKey, logField, logValue);
                                }
                                else
                                {
                                    WBTable table11 = new WBTable();
                                    table11.OpenTable("wb_commodity", "SELECT uniq FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.rfcTable[num14].GetString("CCOMM").ToString() + "'"), WBData.conn);
                                    this.logKey = table11.DT.Rows[0]["uniq"].ToString();
                                    table11.Dispose();
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { "ADD", WBUser.UserID, "Get commodity from ZWB" };
                                    Program.updateLogHeader("wb_commodity", this.logKey, logField, logValue);
                                }
                            }
                        }
                        catch (SyntaxErrorException exception2)
                        {
                            this.dataGridView1.Rows[num14].Cells["comm_code"].Value = this.rfcTable[num14].GetString("CCOMM").ToString();
                            this.dataGridView1.Rows[num14].Cells["Result"].Value = exception2.Message;
                        }
                        num14++;
                    }
                }
                if (WBSetting.copyToLoc == "Y")
                {
                    if (this.rfcTable.RowCount == 1)
                    {
                        Program.copyToLoc("wb_commodity", this.rfcTable[0].GetString("CCOMM").ToString(), 0, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                        MessageBox.Show(Resource.Mes_Record_Copied);
                    }
                    else if (this.rfcTable.RowCount > 1)
                    {
                        Program.copyToLoc("wb_commodity", "", 1, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                        string[] textArray58 = new string[] { Resource.Mes_Copy_From, " ", WBData.sCoyCode, " - ", WBData.sLocCode };
                        MessageBox.Show(Resource.Mes_Records_Copied, string.Concat(textArray58));
                    }
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dataIDSYS(WBTable comm, WBTable commD, WBTable t_comm_d, WBTable yield, DataRow rr)
        {
            this.toolTotRecord.Text = this.adoptTable["data"].Count + " " + Resource.Mes_047B;
            if (this.adoptTable.Count > 0)
            {
                this.dataGridView1.ColumnCount = 10;
                this.dataGridView1.Columns[0].Name = "LOCATION_CODE";
                this.dataGridView1.Columns[1].Name = "Comm_code";
                this.dataGridView1.Columns[2].Name = "Comm_name";
                this.dataGridView1.Columns[3].Name = "UOM";
                this.dataGridView1.Columns[4].Name = "Bulk/Pack";
                this.dataGridView1.Columns[5].Name = "Trade/Non_Trade";
                this.dataGridView1.Columns[6].Name = "Gross_Weight";
                this.dataGridView1.Columns[7].Name = "Netto_Weight";
                this.dataGridView1.Columns[8].Name = "Tolerance";
                this.dataGridView1.Columns[9].Name = "Result";
                this.dataGridView1.Columns["comm_code"].HeaderText = Resource.CommE_001;
                this.dataGridView1.Columns["LOCATION_CODE"].HeaderText = Resource.Col_WB_Location;
                this.p1.Maximum = this.adoptTable["data"].Count;
                this.inserted = 0;
                this.updated = 0;
                string str = "";
                bool flag2 = false;
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.adoptTable["data"].Count)
                    {
                        this.msgConv = "";
                        if ((this.adoptTable["data"].Count == 1) && (this.dataGridView1.Rows[0].Cells["UOM"].Value.ToString().Trim().ToUpper() != "KG"))
                        {
                            this.msgConv = this.dataGridView1.Rows[0].Cells["comm_code"].Value.ToString() + " : ";
                            string[] textArray9 = new string[] { this.msgConv, "\n ", Resource.Mes_Conversion_Weight_2, " ", $"{this.dataGridView1.Rows[0].Cells["Gross_Weight"].Value:N0}" };
                            this.msgConv = string.Concat(textArray9);
                            this.msgConv = this.msgConv + ("\n " + Resource.Mes_Conversion_Weight_3 + " " + $"{this.dataGridView1.Rows[0].Cells["Netto_Weight"].Value:N0}");
                            this.msgConv = this.msgConv + ("\n " + Resource.Mes_Conversion_Weight_4 + " " + $"{this.dataGridView1.Rows[0].Cells["Tolerance"].Value:N0}");
                            MessageBox.Show("\n" + Resource.Mes_Conversion_Weight + " \n" + this.msgConv, "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }
                        break;
                    }
                    this.logKey = "";
                    try
                    {
                        this.p1.Value = num2;
                        this.p1.Refresh();
                        comm.OpenTable("Wb_Commodity", " Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.adoptTable["data"][num2]["code"] + "' "), WBData.conn);
                        string[] aField = new string[] { "comm_code" };
                        string[] aFind = new string[] { this.adoptTable["data"][num2]["code"] };
                        rr = comm.GetData(aField, aFind);
                        this.dataGridView1.Rows.Add();
                        this.dataGridView1.Rows[num2].Cells["Location_Code"].Value = WBData.sLocCode;
                        this.dataGridView1.Rows[num2].Cells["comm_code"].Value = this.adoptTable["data"][num2]["code"];
                        this.dataGridView1.Rows[num2].Cells["comm_name"].Value = this.adoptTable["data"][num2]["name"];
                        this.dataGridView1.Rows[num2].Cells["UOM"].Value = this.adoptTable["data"][num2]["uom"];
                        this.dataGridView1.Rows[num2].Cells["Bulk/Pack"].Value = this.adoptTable["data"][num2]["m_type"];
                        this.dataGridView1.Rows[num2].Cells["Trade/Non_Trade"].Value = this.adoptTable["data"][num2]["t_type"];
                        this.dataGridView1.Rows[num2].Cells["Gross_Weight"].Value = this.adoptTable["data"][num2]["gw"];
                        this.dataGridView1.Rows[num2].Cells["Netto_Weight"].Value = this.adoptTable["data"][num2]["nw"];
                        this.dataGridView1.Rows[num2].Cells["Tolerance"].Value = this.adoptTable["data"][num2]["tol"];
                        flag2 = true;
                        if (this.dataGridView1.Rows[num2].Cells["Trade/Non_Trade"].Value.ToString() == "N")
                        {
                            flag2 = false;
                        }
                        if (!flag2)
                        {
                            this.dataGridView1.Rows[num2].Cells["Result"].Value = str;
                        }
                        else
                        {
                            if (rr == null)
                            {
                                this.dataGridView1.Rows[num2].Cells["Result"].Value = "INSERTED";
                                this.inserted++;
                                comm.DR = comm.DT.NewRow();
                            }
                            else
                            {
                                string[] textArray3 = new string[] { "comm_code" };
                                string[] textArray4 = new string[] { this.adoptTable["data"][num2]["code"] };
                                int recNo = comm.GetRecNo(textArray3, textArray4);
                                this.dataGridView1.Rows[num2].Cells["Result"].Value = "UPDATED";
                                this.updated++;
                                comm.DR = comm.DT.Rows[recNo];
                                this.logKey = comm.DR["uniq"].ToString();
                                comm.DR.BeginEdit();
                            }
                            comm.DR["coy"] = WBData.sCoyCode;
                            comm.DR["Location_code"] = WBData.sLocCode;
                            comm.DR["comm_code"] = this.adoptTable["data"][num2]["code"];
                            comm.DR["comm_name"] = this.adoptTable["data"][num2]["name"];
                            comm.DR["Unit"] = this.adoptTable["data"][num2]["uom"];
                            comm.DR["Trade"] = (this.adoptTable["data"][num2]["t_type"] == "T") ? "T" : "N";
                            comm.DR["BulkPack"] = (this.adoptTable["data"][num2]["m_type"] == "PACK") ? "P" : "B";
                            comm.DR["Material"] = this.adoptTable["data"][num2]["code"];
                            comm.DR["Tolerance"] = this.adoptTable["data"][num2]["tol"];
                            comm.DR["Gross_Weight"] = this.adoptTable["data"][num2]["gw"];
                            comm.DR["Netto_Weight"] = this.adoptTable["data"][num2]["nw"];
                            if (rr != null)
                            {
                                comm.DR["Change_By"] = "IDSYS";
                                comm.DR["Change_Date"] = Program.DTOCSAP(DateTime.Now);
                                comm.DR.EndEdit();
                            }
                            else
                            {
                                comm.DR["Create_By"] = "IDSYS";
                                comm.DR["Create_Date"] = Program.DTOCSAP(DateTime.Now);
                                comm.DT.Rows.Add(comm.DR);
                            }
                            comm.Save();
                            if (this.logKey != "")
                            {
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "EDIT", WBUser.UserID, "Get commodity from IDSYS" };
                                Program.updateLogHeader("wb_commodity", this.logKey, logField, logValue);
                            }
                            else
                            {
                                WBTable table = new WBTable();
                                table.OpenTable("wb_commodity", "SELECT uniq FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.adoptTable["data"][num2]["code"] + "'"), WBData.conn);
                                this.logKey = table.DT.Rows[0]["uniq"].ToString();
                                table.Dispose();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "ADD", WBUser.UserID, "Get commodity from IDSYS" };
                                Program.updateLogHeader("wb_commodity", this.logKey, logField, logValue);
                            }
                        }
                    }
                    catch (SyntaxErrorException exception)
                    {
                        this.dataGridView1.Rows[num2].Cells["comm_code"].Value = this.adoptTable["data"][num2]["code"];
                        this.dataGridView1.Rows[num2].Cells["Result"].Value = exception.Message;
                    }
                    num2++;
                }
            }
            if (WBSetting.copyToLoc == "Y")
            {
                if (this.adoptTable["data"].Count == 1)
                {
                    Program.copyToLoc("wb_commodity", this.adoptTable["data"][0]["code"], 0, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                    MessageBox.Show(Resource.Mes_Record_Copied);
                }
                else if (this.adoptTable["data"].Count > 1)
                {
                    Program.copyToLoc("wb_commodity", "", 1, "Copy from location " + WBData.sCoyCode + " - " + WBData.sLocCode);
                    string[] textArray10 = new string[] { Resource.Mes_Copy_From, " ", WBData.sCoyCode, " - ", WBData.sLocCode };
                    MessageBox.Show(Resource.Mes_Records_Copied, string.Concat(textArray10));
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormCommodityCompare_FormClosed(object sender, FormClosedEventArgs e)
        {
            if ((this.dataGridView1.Rows.Count <= 0) && (this.dataGridView1.Rows[0].Cells["UOM"].Value.ToString().Trim().ToUpper() != "KG"))
            {
                string caption = "";
                caption = this.dataGridView1.Rows[0].Cells["Comm_Code"].Value.ToString() + " : " + this.dataGridView1.Rows[0].Cells["Comm_name"].Value.ToString();
                string[] textArray1 = new string[] { caption, "\n", Resource.Mes_Commodity_Unit, " : ", this.dataGridView1.Rows[0].Cells["UOM"].Value.ToString() };
                caption = string.Concat(textArray1);
                string[] textArray2 = new string[] { caption, "\n", Resource.Mes_Commodity_Type, " : ", this.dataGridView1.Rows[0].Cells["Type"].Value.ToString() };
                caption = string.Concat(textArray2);
                if (this.dataGridView1.Rows[0].Cells["BulkPack"].Value.ToString() == "P")
                {
                    caption = caption + "PACK";
                }
                else if (this.dataGridView1.Rows[0].Cells["BulkPack"].Value.ToString() == "B")
                {
                    caption = caption + "BULK";
                }
                caption = caption + "\n" + Resource.Mes_Commodity_Convertion;
                string[] textArray3 = new string[] { caption, "\n", Resource.Mes_Gross_Weight, " : ", this.dataGridView1.Rows[0].Cells["Gross_Weight"].Value.ToString() };
                caption = string.Concat(textArray3);
                string[] textArray4 = new string[] { caption, "\n", Resource.Gatepass_031, " : ", this.dataGridView1.Rows[0].Cells["Netto_Weight"].Value.ToString() };
                caption = string.Concat(textArray4);
                string[] textArray5 = new string[] { caption, "\n", Resource.Contract_055, " : ", this.dataGridView1.Rows[0].Cells["Tolerance"].Value.ToString() };
                caption = string.Concat(textArray5);
                MessageBox.Show(Resource.Mes_Commodity_Convertion, caption);
            }
        }

        private void FormCommodityCompare_Load(object sender, EventArgs e)
        {
            this.Compare();
        }

        private void InitializeComponent()
        {
            this.dataGridView1 = new DataGridView();
            this.statusStrip1 = new StatusStrip();
            this.toolTotRecord = new ToolStripStatusLabel();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.statusStrip1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(930, 0x1b3);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.toolTotRecord };
            this.statusStrip1.Items.AddRange(toolStripItems);
            this.statusStrip1.Location = new Point(0, 0x1b3);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(930, 0x16);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            this.toolTotRecord.Name = "toolTotRecord";
            this.toolTotRecord.Size = new Size(0x3a, 0x11);
            this.toolTotRecord.Text = "0 Records";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(930, 0x1c9);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.statusStrip1);
            base.Name = "FormCommodityCompare";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Commodity Compare & Patch";
            base.FormClosed += new FormClosedEventHandler(this.FormCommodityCompare_FormClosed);
            base.Load += new EventHandler(this.FormCommodityCompare_Load);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.toolTotRecord.Text = "0 " + Resource.Mes_047B;
            this.Text = Resource.Title_Commodity_Compare;
        }
    }
}

