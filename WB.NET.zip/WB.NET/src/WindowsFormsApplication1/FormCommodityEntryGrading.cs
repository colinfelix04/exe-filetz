﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormCommodityEntryGrading : Form
    {
        public string comm_code;
        public WBTable tblCommGrading;
        public bool view;
        public string mode = "";
        public string changeReason = "";
        private IContainer components = null;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private SplitContainer splitContainer1;
        public DataGridView dgvDeduc;
        private Button button3;
        private Button button2;
        private Button button1;
        private TextBox textUnitName;
        private Label label34;
        private Button button4;
        private Button button5;

        public FormCommodityEntryGrading()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.thisClose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.EntryDeduction("ADD");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int index = this.dgvDeduc.CurrentRow.Index;
            this.tblCommGrading.DR = this.tblCommGrading.DT.Rows[index];
            this.tblCommGrading.DT.Rows.RemoveAt(index);
            this.dgvDeduc.Rows.Remove(this.dgvDeduc.CurrentRow);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (this.mode.ToLower() != "add")
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Visible = false },
                    textRefNo = { Visible = false }
                };
                if (this.mode.ToLower() == "edit")
                {
                    cancel.Text = Resource.Title_Change_Reason;
                    cancel.label2.Text = Resource.Lbl_Change_Reason + " : ";
                }
                else
                {
                    cancel.Text = Resource.Form_Delete_Reason;
                    cancel.label2.Text = Resource.Lbl_Delete_Reason;
                }
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            this.tblCommGrading.AddFromDGV_new(this.dgvDeduc, "ref", "SYS-GEN", this.mode.ToUpper(), this.changeReason);
            base.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.EntryDeduction("Edit");
        }

        private void dgvDeduc_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.EntryDeduction("Edit");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void EntryDeduction(string pmode)
        {
            FormTransDeducEntry entry = new FormTransDeducEntry {
                pMode = pmode,
                textNET2 = "999",
                textDeducPercent = { Enabled = false },
                textDeducKG = { Enabled = false },
                textDeducQtyUnit = { Enabled = false }
            };
            this.mode = pmode;
            entry.textBunchDeduc = "99";
            if (pmode == "ADD")
            {
                entry.Text = Resource.Title_Add_Deduction;
                entry.oldDeducCode = "";
            }
            else
            {
                entry.Text = Resource.Title_Edit_Deduction;
                entry.comboDeducBy.Text = this.dgvDeduc.CurrentRow.Cells["Deduc_by"].Value.ToString();
                entry.textDeducCode.Text = this.dgvDeduc.CurrentRow.Cells["Code"].Value.ToString();
                entry.oldDeducCode = this.dgvDeduc.CurrentRow.Cells["Code"].Value.ToString();
                entry.textDeducName.Text = this.dgvDeduc.CurrentRow.Cells["Name"].Value.ToString();
                entry.textFormula.Text = this.dgvDeduc.CurrentRow.Cells["Formula"].Value.ToString();
                entry.textDeducVar.Text = this.dgvDeduc.CurrentRow.Cells["Variable"].Value.ToString();
                entry.checkDeduct.Checked = this.dgvDeduc.CurrentRow.Cells["Deduct"].Value.ToString() == "Y";
                entry.textTarget.Text = this.dgvDeduc.CurrentRow.Cells["Target"].Value.ToString();
                entry.checkDeducReturn.Checked = this.dgvDeduc.CurrentRow.Cells["Retur"].Value.ToString() == "Y";
            }
            entry.labelKgUnit.Text = this.textUnitName.Text;
            entry.dataGridView1 = this.dgvDeduc;
            entry.ShowDialog();
            if (!entry.saved)
            {
                goto TR_0000;
            }
            else
            {
                int index;
                Cursor.Current = Cursors.WaitCursor;
                try
                {
                    index = this.dgvDeduc.CurrentRow.Index;
                }
                catch
                {
                    index = 0;
                }
                if (pmode == "ADD")
                {
                    index = this.dgvDeduc.Rows.Count;
                    this.dgvDeduc.Rows.Add();
                }
                this.dgvDeduc.Rows[index].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvDeduc.Rows[index].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvDeduc.Rows[index].Cells["Deduc_by"].Value = entry.comboDeducBy.Text;
                this.dgvDeduc.Rows[index].Cells["Code"].Value = entry.textDeducCode.Text;
                this.dgvDeduc.Rows[index].Cells["Name"].Value = entry.textDeducName.Text;
                this.dgvDeduc.Rows[index].Cells["Formula"].Value = entry.textFormula.Text;
                this.dgvDeduc.Rows[index].Cells["comm_code"].Value = this.comm_code;
                this.dgvDeduc.Rows[index].Cells["Variable"].Value = entry.textDeducVar.Text;
                this.dgvDeduc.Rows[index].Cells["Retur"].Value = entry.checkDeducReturn.Checked ? "Y" : " ";
                this.dgvDeduc.Rows[index].Cells["Pdeduc"].Value = "0";
                this.dgvDeduc.Rows[index].Cells["kgdeduc"].Value = "0";
                this.dgvDeduc.Rows[index].Cells["qtybunch"].Value = "0";
                this.dgvDeduc.Rows[index].Cells["deduct"].Value = entry.checkDeduct.Checked ? "Y" : "N";
                this.dgvDeduc.Rows[index].Cells["target"].Value = entry.textTarget.Text;
                this.dgvDeduc.Refresh();
                if (pmode == "ADD")
                {
                    this.tblCommGrading.DR = this.tblCommGrading.DT.NewRow();
                    this.tblCommGrading.DR.BeginEdit();
                    this.tblCommGrading.DR["Coy"] = WBData.sCoyCode;
                    this.tblCommGrading.DR["Location_Code"] = WBData.sLocCode;
                    this.tblCommGrading.DR["Deduc_by"] = entry.comboDeducBy.Text;
                    this.tblCommGrading.DR["Code"] = entry.textDeducCode.Text;
                    this.tblCommGrading.DR["Name"] = entry.textDeducName.Text;
                    this.tblCommGrading.DR["Formula"] = entry.textFormula.Text;
                    this.tblCommGrading.DR["Comm_code"] = this.comm_code;
                    this.tblCommGrading.DR["Variable"] = entry.textDeducVar.Text;
                    this.tblCommGrading.DR["Retur"] = entry.checkDeducReturn.Checked ? "Y" : " ";
                    this.tblCommGrading.DR["Pdeduc"] = "0";
                    this.tblCommGrading.DR["kgdeduc"] = "0";
                    this.tblCommGrading.DR["qtybunch"] = "0";
                    this.tblCommGrading.DR["deduct"] = entry.checkDeduct.Checked ? "Y" : "N";
                    this.tblCommGrading.DR["target"] = entry.textTarget.Text;
                    this.tblCommGrading.DR.EndEdit();
                    this.tblCommGrading.DT.Rows.Add(this.tblCommGrading.DR);
                }
                else if (pmode == "Edit")
                {
                    int num2 = 0;
                    foreach (DataGridViewRow row in (IEnumerable) this.dgvDeduc.Rows)
                    {
                        this.tblCommGrading.DR = this.tblCommGrading.DT.Rows[num2];
                        this.tblCommGrading.DR.BeginEdit();
                        int num3 = 0;
                        while (true)
                        {
                            if (num3 >= this.tblCommGrading.DT.Columns.Count)
                            {
                                num2++;
                                this.tblCommGrading.DR.EndEdit();
                                break;
                            }
                            string str = this.tblCommGrading.DT.Columns[num3].ColumnName.ToString();
                            if ((((str.ToLower() != "uniq") && (row.Cells[str].Value != null)) && (row.Cells[str].Value.ToString().Trim() != "")) && (row.Cells[str].Value.ToString() != this.tblCommGrading.DR[str].ToString()))
                            {
                                this.tblCommGrading.DR[str] = row.Cells[str].Value.ToString();
                            }
                            num3++;
                        }
                    }
                }
            }
            Cursor.Current = Cursors.Default;
        TR_0000:
            entry.Dispose();
        }

        private void FormCommodityEntryGrading_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormCommodityEntryGrading_Load(object sender, EventArgs e)
        {
            this.dgvDeduc.ColumnCount = this.tblCommGrading.DT.Columns.Count;
            int num = 0;
            while (true)
            {
                if (num >= this.tblCommGrading.DT.Columns.Count)
                {
                    this.dgvDeduc.Columns["Coy"].Visible = false;
                    this.dgvDeduc.Columns["Location_Code"].Visible = false;
                    this.dgvDeduc.Columns["Ref"].Visible = false;
                    this.dgvDeduc.Columns["Type"].Visible = false;
                    this.dgvDeduc.Columns["Formula"].Visible = true;
                    this.dgvDeduc.Columns["Variable"].Visible = false;
                    this.dgvDeduc.Columns["Uniq"].Visible = false;
                    this.dgvDeduc.Columns["Do_No"].Visible = false;
                    this.dgvDeduc.Columns["comm_code"].Visible = false;
                    this.dgvDeduc.Columns["Deduc_by"].HeaderText = "D";
                    this.dgvDeduc.Columns["Deduc_by"].Width = 20;
                    string[] textArray1 = new string[] { Resource.Ttp_Deduc_By, "\n", Resource.Ttp_Deduc_By_2, "\n", Resource.Ttp_Deduc_By_3 };
                    this.dgvDeduc.Columns["Deduc_by"].ToolTipText = string.Concat(textArray1);
                    this.dgvDeduc.Columns["KgDeduc"].Visible = false;
                    this.dgvDeduc.Columns["PDeduc"].Visible = false;
                    this.dgvDeduc.Columns["QtyBunch"].Visible = false;
                    this.dgvDeduc = this.tblCommGrading.ToDGV(this.dgvDeduc);
                    if (this.view)
                    {
                        foreach (Control control in base.Controls)
                        {
                            control.Enabled = false;
                        }
                        this.dgvDeduc.Enabled = true;
                        this.button1.Text = Resource.Btn_Close;
                        this.button1.Enabled = true;
                    }
                    return;
                }
                this.dgvDeduc.Columns[num].Name = this.tblCommGrading.DT.Columns[num].ColumnName;
                num++;
            }
        }

        private void InitializeComponent()
        {
            this.tabControl1 = new TabControl();
            this.tabPage1 = new TabPage();
            this.splitContainer1 = new SplitContainer();
            this.dgvDeduc = new DataGridView();
            this.button5 = new Button();
            this.button3 = new Button();
            this.button2 = new Button();
            this.button1 = new Button();
            this.textUnitName = new TextBox();
            this.label34 = new Label();
            this.button4 = new Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.splitContainer1.BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((ISupportInitialize) this.dgvDeduc).BeginInit();
            base.SuspendLayout();
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new Point(1, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new Size(0x245, 0x126);
            this.tabControl1.TabIndex = 4;
            this.tabPage1.Controls.Add(this.splitContainer1);
            this.tabPage1.Location = new Point(4, 0x16);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new Padding(3);
            this.tabPage1.Size = new Size(0x23d, 0x10c);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Grading Control";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.splitContainer1.Dock = DockStyle.Fill;
            this.splitContainer1.Location = new Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Panel1.Controls.Add(this.dgvDeduc);
            this.splitContainer1.Panel2.Controls.Add(this.button5);
            this.splitContainer1.Panel2.Controls.Add(this.button3);
            this.splitContainer1.Panel2.Controls.Add(this.button2);
            this.splitContainer1.Size = new Size(0x237, 0x106);
            this.splitContainer1.SplitterDistance = 0x1d8;
            this.splitContainer1.TabIndex = 0;
            this.dgvDeduc.AllowUserToAddRows = false;
            this.dgvDeduc.AllowUserToDeleteRows = false;
            this.dgvDeduc.AllowUserToResizeRows = false;
            this.dgvDeduc.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDeduc.Dock = DockStyle.Fill;
            this.dgvDeduc.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvDeduc.Location = new Point(0, 0);
            this.dgvDeduc.MultiSelect = false;
            this.dgvDeduc.Name = "dgvDeduc";
            this.dgvDeduc.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDeduc.Size = new Size(0x1d8, 0x106);
            this.dgvDeduc.TabIndex = 1;
            this.dgvDeduc.CellDoubleClick += new DataGridViewCellEventHandler(this.dgvDeduc_CellDoubleClick);
            this.button5.Location = new Point(12, 0x52);
            this.button5.Name = "button5";
            this.button5.Size = new Size(0x43, 0x37);
            this.button5.TabIndex = 3;
            this.button5.Text = "Edit";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new EventHandler(this.button5_Click);
            this.button3.Location = new Point(12, 0x9a);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x43, 0x37);
            this.button3.TabIndex = 2;
            this.button3.Text = "Remove";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.button2.Location = new Point(12, 14);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x43, 0x35);
            this.button2.TabIndex = 1;
            this.button2.Text = "Add Item";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0xce, 0x133);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x2f);
            this.button1.TabIndex = 5;
            this.button1.Text = "BACK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textUnitName.Location = new Point(0x1da, 0x14e);
            this.textUnitName.MaxLength = 15;
            this.textUnitName.Name = "textUnitName";
            this.textUnitName.Size = new Size(0x65, 20);
            this.textUnitName.TabIndex = 11;
            this.textUnitName.Text = "Bunch";
            this.label34.AutoSize = true;
            this.label34.Location = new Point(0x1d7, 0x13e);
            this.label34.Name = "label34";
            this.label34.Size = new Size(0x39, 13);
            this.label34.TabIndex = 12;
            this.label34.Text = "Unit Name";
            this.button4.Location = new Point(0x70, 0x133);
            this.button4.Name = "button4";
            this.button4.Size = new Size(0x4b, 0x2f);
            this.button4.TabIndex = 13;
            this.button4.Text = "SAVE";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            this.button4.Click += new EventHandler(this.button4_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x24c, 370);
            base.ControlBox = false;
            base.Controls.Add(this.button4);
            base.Controls.Add(this.textUnitName);
            base.Controls.Add(this.label34);
            base.Controls.Add(this.tabControl1);
            base.Controls.Add(this.button1);
            base.KeyPreview = true;
            base.Name = "FormCommodityEntryGrading";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Advanced Option For Grading";
            base.Load += new EventHandler(this.FormCommodityEntryGrading_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormCommodityEntryGrading_KeyPress);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((ISupportInitialize) this.dgvDeduc).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        public void thisClose()
        {
            base.Close();
        }

        private void translate()
        {
            this.tabPage1.Text = Resource.Tab_Grading_Control;
            this.button5.Text = Resource.Btn_Edit;
            this.button3.Text = Resource.Btn_Remove;
            this.button2.Text = Resource.Btn_Add_Item;
            this.button1.Text = Resource.Btn_Back;
            this.textUnitName.Text = Resource.Txt_Unit_Name_Bunch;
            this.label34.Text = Resource.Trans_068;
            this.button4.Text = Resource.Btn_Save;
            this.Text = Resource.Title_Commodity_Entry_Grading;
        }
    }
}

