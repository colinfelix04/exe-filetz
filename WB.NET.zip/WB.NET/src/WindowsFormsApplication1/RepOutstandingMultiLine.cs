﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class RepOutstandingMultiLine : Form
    {
        private WBTable getContract = new WBTable();
        private WBTable tbl_comm = new WBTable();
        private IContainer components = null;
        public Label label5;
        public Label labelRecNo;
        public Label labelProcess;
        public GroupBox grType;
        public Label labelcommodity;
        public TextBox textDO;
        public Button buttonDO;
        private GroupBox gbDispOpt;
        private CheckBox cBoxLossInPack;
        private CheckBox cBoxLossInKg;
        private CheckBox cBoxReturnInPack;
        private CheckBox cBoxReturnInKg;
        public Label label1;
        public DateTimePicker monthCalendar1;
        public Button button2;
        public Button button3;
        public DateTimePicker monthCalendar2;
        public Label label2;
        private CheckBox checkBrutoTarra;
        private CheckBox check3rdParty;
        private CheckBox checkLoadingQty;
        public Button buttonComm;
        public TextBox textComm;
        public Label label3;
        public Label labelComm;
        private CheckBox checkDeduc;
        private CheckBox checkProcess;

        public RepOutstandingMultiLine()
        {
            this.InitializeComponent();
        }

        private void button1st_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFind = this.textDO.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDO.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                this.getContract = this.getQuery();
                if (this.getContract.DT.Rows.Count <= 0)
                {
                    MessageBox.Show("No Records Found", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    this.labelProcess.Visible = true;
                    this.labelRecNo.Visible = true;
                    this.labelProcess.Refresh();
                    this.labelRecNo.Refresh();
                    this.getTemplate(WBData.sCoyCode, WBData.sLocCode, this.getContract);
                }
            }
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE",
                pFind = this.textComm.Text.Trim()
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow == null)
            {
                this.labelComm.Visible = false;
            }
            else
            {
                this.textComm.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelComm.Visible = true;
                this.labelComm.Text = commodity.ReturnRow["Comm_Name"].ToString();
            }
            commodity.Dispose();
        }

        private unsafe double[] cekSDHI(string DoNo, string so_item)
        {
            double[] numArray2;
            string str = "0";
            double num = 0.0;
            double num2 = 0.0;
            double num3 = 0.0;
            string str2 = "";
            string str3 = "";
            string str4 = "KG";
            string str5 = "";
            double num4 = 0.0;
            double[] numArray = new double[4];
            WBTable table = new WBTable();
            table.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + DoNo + "'"), WBData.conn);
            table.DR = table.DT.Rows[0];
            if (table.DT.Rows[0]["check_qty"].ToString() != "Y")
            {
                table.Dispose();
                numArray2 = numArray;
            }
            else
            {
                double num5;
                WBTable table2 = new WBTable();
                string[] textArray1 = new string[] { " AND do_no = '", DoNo, "' AND so_item = '", Program.StrToDouble(so_item, 0).ToString(), "'" };
                table2.OpenTable("wb_contract_sapinformation", "SELECT * FROM wb_contract_sapinformation WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                table2.DR = table2.DT.Rows[0];
                str2 = table2.DR["comm_code"].ToString();
                str = table.DR["deductedby"].ToString();
                num2 = (Program.StrToDouble(table.DR["Entry_Est"].ToString(), 0) <= 0.0) ? Program.StrToDouble(table2.DR["Quantity"].ToString(), 0) : Program.StrToDouble(table.DR["Entry_Est"].ToString(), 0);
                num3 = (Program.StrToDouble(table.DR["Entry_Fact"].ToString(), 0) <= 0.0) ? Program.StrToDouble(table2.DR["Quantity"].ToString(), 0) : Program.StrToDouble(table.DR["Entry_Fact"].ToString(), 0);
                num = (table.DR["tolerance"].ToString() == "") ? 0.0 : Convert.ToDouble(table.DR["tolerance"].ToString());
                WBTable table3 = new WBTable();
                table3.OpenTable("wb_Comm", "select * from wb_commodity where " + WBData.CompanyLocation(" and Comm_code = '" + str2 + "'"), WBData.conn);
                table3.DR = table3.DT.Rows[0];
                str3 = table3.DR["BulkPack"].ToString();
                str4 = table3.DR["Unit"].ToString();
                str5 = table3.DR["Type"].ToString();
                num4 = (table3.DT.Rows[0]["netto_weight"].ToString() == "") ? ((double) 0f) : ((double) float.Parse(table3.DT.Rows[0]["netto_weight"].ToString()));
                WBTable table4 = new WBTable();
                string[] textArray2 = new string[5];
                textArray2[0] = "Select sum(NetFactory) as NetFactory,  sum(case when netOther = '0' then netFactory else netOther end) as NetOther,  sum(loading_qty) as loading_qty,  sum(TotalGunny) as TotalGunny  from vw_outstanding  where ";
                string[] textArray3 = new string[] { " and DO_NO = '", DoNo, "' AND (so_item_detail = '", so_item.PadLeft(6, '0'), "' or so_item_detail = '", Convert.ToInt32(so_item).ToString(), "')" };
                textArray2[1] = WBData.CompanyLocation(string.Concat(textArray3));
                textArray2[2] = " AND (mark_return = '' OR mark_return is null)  and report_date < '";
                textArray2[3] = Program.DTOC(Convert.ToDateTime(this.monthCalendar1.Text));
                textArray2[4] = "'";
                table4.OpenTable("vw_outstanding", string.Concat(textArray2), WBData.conn);
                if (table4.DT.Rows.Count <= 0)
                {
                    num5 = 0.0;
                }
                else
                {
                    table4.DR = table4.DT.Rows[0];
                    if (table4.DR["NetFactory"].ToString().Length > 0)
                    {
                        numArray[1] = Convert.ToDouble(table4.DR["NetFactory"].ToString());
                    }
                    if (table4.DR["NetOther"].ToString().Length > 0)
                    {
                        numArray[0] = Convert.ToDouble(table4.DR["NetOther"].ToString());
                    }
                    if (str == "1")
                    {
                        if ((str4 == "KG") || (str4 == ""))
                        {
                            if (table4.DR["NetOther"].ToString().Length > 0)
                            {
                                num5 = Convert.ToDouble(table4.DR["NetOther"].ToString());
                            }
                            else
                            {
                                num5 = 0.0;
                                numArray[0] = 0.0;
                            }
                        }
                        else if (str3 == "P")
                        {
                            num5 = Program.StrToDouble((Program.StrToDouble(table4.DT.Rows[0]["loading_qty"].ToString(), 3) * num4).ToString(), 3);
                            numArray[2] = Program.StrToDouble((Program.StrToDouble(table4.DT.Rows[0]["loading_qty"].ToString(), 3) * num4).ToString(), 3);
                        }
                        else
                        {
                            num5 = Program.StrToDouble(table4.DT.Rows[0]["loading_qty"].ToString(), 0);
                            numArray[2] = Program.StrToDouble(table4.DT.Rows[0]["loading_qty"].ToString(), 0);
                        }
                    }
                    else if ((str4 == "KG") || (str4 == ""))
                    {
                        if (table4.DR["NetFactory"].ToString().Length > 0)
                        {
                            num5 = Convert.ToDouble(table4.DR["NetFactory"].ToString());
                        }
                        else
                        {
                            num5 = 0.0;
                            numArray[1] = 0.0;
                        }
                    }
                    else if (str3 == "P")
                    {
                        num5 = Program.StrToDouble((Program.StrToDouble(table4.DT.Rows[0]["loading_qty"].ToString(), 3) * num4).ToString(), 3);
                        numArray[2] = Program.StrToDouble((Program.StrToDouble(table4.DT.Rows[0]["loading_qty"].ToString(), 3) * num4).ToString(), 3);
                    }
                    else
                    {
                        num5 = Program.StrToDouble(table4.DT.Rows[0]["loading_qty"].ToString(), 0);
                        numArray[2] = Program.StrToDouble(table4.DT.Rows[0]["loading_qty"].ToString(), 0);
                    }
                }
                numArray[3] = num5;
                string[] textArray4 = new string[5];
                textArray4[0] = "Select sum(NetFactory) as NetFactory,  sum(case when netOther = '0' then netFactory else netOther end) as NetOther,  sum(loading_qty) as loading_qty,  sum(TotalGunny) as TotalGunny  from vw_outstanding  where ";
                string[] textArray5 = new string[] { " and DO_NO = '", DoNo, "' AND (so_item_detail = '", so_item.PadLeft(6, '0'), "' or so_item_detail = '", Convert.ToInt32(so_item).ToString(), "')" };
                textArray4[1] = WBData.CompanyLocation(string.Concat(textArray5));
                textArray4[2] = " AND (mark_return = 'X')  and report_date < '";
                textArray4[3] = Program.DTOC(Convert.ToDateTime(this.monthCalendar1.Text));
                textArray4[4] = "'";
                table4.OpenTable("vw_outstanding", string.Concat(textArray4), WBData.conn);
                if (table4.DT.Rows.Count > 0)
                {
                    num5 -= Program.StrToDouble(table4.DT.Rows[0]["netOther"].ToString(), 0);
                    double* numPtr1 = numArray;
                    numPtr1[0] -= Program.StrToDouble(table4.DT.Rows[0]["netOther"].ToString(), 0);
                    double* numPtr2 = &(numArray[1]);
                    numPtr2[0] -= Program.StrToDouble(table4.DT.Rows[0]["netOther"].ToString(), 0);
                    double* numPtr3 = &(numArray[2]);
                    numPtr3[0] -= Program.StrToDouble(table4.DT.Rows[0]["netOther"].ToString(), 0);
                }
                numArray[3] = num5;
                table.Dispose();
                table3.Dispose();
                table4.Dispose();
                numArray2 = numArray;
            }
            return numArray2;
        }

        private void checkBrutoTarra_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBrutoTarra.Checked)
            {
                this.checkDeduc.Enabled = true;
            }
            else
            {
                this.checkDeduc.Checked = false;
                this.checkDeduc.Enabled = false;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void getHeader(HTML rep)
        {
            rep.Write("<tr class='bd'>");
            rep.Write("<th nowrap rowspan=3>No.</th>");
            rep.Write("<th nowrap rowspan=3>Commodity Code</th>");
            rep.Write("<th nowrap rowspan=3>Commodity Name</th>");
            rep.Write("<th nowrap rowspan=3>Relation Code</th>");
            rep.Write("<th nowrap rowspan=3>DO SAP</th>");
            rep.Write("<th nowrap rowspan=3>DO SAP Item</th>");
            rep.Write("<th nowrap rowspan=3>Date</th>");
            rep.Write("<th nowrap rowspan=3>Reference No.</th>");
            rep.Write("<th nowrap rowspan=3>Truck No</th>");
            rep.Write("<th nowrap rowspan=3>Driver Name</th>");
            rep.Write("<th nowrap rowspan=3>Transporter Code</th>");
            rep.Write("<th nowrap rowspan=3>Party</th>");
            if (this.checkBrutoTarra.Checked)
            {
                if (this.checkDeduc.Checked)
                {
                    rep.Write("<th nowrap colspan=8>Factory</th>");
                }
                else
                {
                    rep.Write("<th nowrap colspan=6>Factory</th>");
                }
            }
            if (this.check3rdParty.Checked)
            {
                rep.Write("<th nowrap colspan=6>3rd Party</th>");
            }
            if (this.checkLoadingQty.Checked)
            {
                rep.Write("<th nowrap colspan=10>Loading Qty</th>");
            }
            rep.Write("<th rowspan=3>Admitted Outstanding</th>");
            if (this.cBoxReturnInKg.Checked && this.cBoxReturnInPack.Checked)
            {
                rep.Write("<th nowrap colspan=2>Return</th>");
            }
            else if (this.cBoxReturnInKg.Checked || this.cBoxReturnInPack.Checked)
            {
                rep.Write("<th nowrap>Return</th>");
            }
            if (this.cBoxLossInKg.Checked && this.cBoxLossInPack.Checked)
            {
                rep.Write("<th nowrap colspan=2>Loss(-)/Gain(+)</th>");
            }
            else if (this.cBoxLossInKg.Checked || this.cBoxLossInPack.Checked)
            {
                rep.Write("<th nowrap>Loss(-)/Gain(+)</th>");
            }
            rep.Write("</tr>");
            rep.Write("<tr class='bd'>");
            if (this.checkBrutoTarra.Checked)
            {
                if (this.checkDeduc.Checked)
                {
                    rep.Write("<th nowrap colspan=5>Weight</th>");
                }
                else
                {
                    rep.Write("<th nowrap colspan=3>Weight</th>");
                }
                rep.Write("<th nowrap rowspan=2>Sub</th>");
                rep.Write("<th nowrap rowspan=2>U/ Today</th>");
                rep.Write("<th nowrap rowspan=2>Outstanding</th>");
            }
            if (this.check3rdParty.Checked)
            {
                rep.Write("<th nowrap colspan=3>Weight</th>");
                rep.Write("<th nowrap rowspan=2>Sub</th>");
                rep.Write("<th nowrap rowspan=2>U/ Today</th>");
                rep.Write("<th nowrap rowspan=2>Outstanding</th>");
            }
            if (this.checkLoadingQty.Checked)
            {
                rep.Write("<th rowspan=2>Loading Qty Factory</th>");
                rep.Write("<th rowspan=2>Loading Qty OPW</th>");
                rep.Write("<th nowrap rowspan=2>UOM</th>");
                rep.Write("<th nowrap rowspan=2>Loading Net (KG)</th>");
                rep.Write("<th nowrap rowspan=2>Gross Weight</th>");
                rep.Write("<th nowrap rowspan=2>Diff (+/-)</th>");
                rep.Write("<th nowrap rowspan=2>Diff (%)</th>");
                rep.Write("<th nowrap rowspan=2>Sub</th>");
                rep.Write("<th nowrap rowspan=2>U/ Today</th>");
                rep.Write("<th nowrap rowspan=2>Outstanding</th>");
            }
            if (this.cBoxReturnInKg.Checked)
            {
                rep.Write("<th nowrap rowspan=2>KG</th>");
            }
            if (this.cBoxReturnInPack.Checked)
            {
                rep.Write("<th nowrap rowspan=2>Pack</th>");
            }
            if (this.cBoxLossInKg.Checked)
            {
                rep.Write("<th nowrap rowspan=2>KG</th>");
            }
            if (this.cBoxLossInPack.Checked)
            {
                rep.Write("<th nowrap rowspan=2>Pack</th>");
            }
            rep.Write("</tr>");
            rep.Write("<tr class='bd'>");
            if (this.checkBrutoTarra.Checked)
            {
                rep.Write("<th nowrap>Gross</th>");
                rep.Write("<th nowrap>Tare</th>");
                if (this.checkDeduc.Checked)
                {
                    rep.Write("<th nowrap>Received</th>");
                    rep.Write("<th nowrap>Deduction</th>");
                }
                rep.Write("<th nowrap>Net</th>");
            }
            if (this.check3rdParty.Checked)
            {
                rep.Write("<th nowrap>Gross</th>");
                rep.Write("<th nowrap>Tare</th>");
                rep.Write("<th nowrap>Net</th>");
            }
            rep.Write("</tr>");
        }

        private WBTable getQuery()
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            string str = "t.do_no, c.so, d.so_item_detail, c.comm_code as cc, o.relation_code, t.report_date, t.ref, t.truck_number, t.name, t.transporter_code, c.quantity, t.gross, t.tare, t.net, t.gross_estate, t.tare_estate, t.net_estate, o.deductedBy, o.Entry_Fact, o.Entry_Est, d.estate_qty, d.loading_qty_opw, d.bruto, d.tarra, d.netto, d.loading_qty, d.return_qty_pack, d.return_qty_kg, t.deduction, t.received, t.mark_return, d.do_sap, m.comm_code, m.comm_name, t.WX, t._2nd, t._4th, d.do_sap_item";
            string sqltext = ((((("SELECT " + str + " FROM wb_transaction t, wb_transDO d, wb_contract_sapinformation c, wb_contract o, wb_commodity m") + " WHERE t.coy = d.coy AND t.location_code = d.location_code ") + " AND d.coy = c.coy AND d.location_code = c.location_code " + " AND c.coy = o.coy AND c.location_code = o.location_code ") + " AND o.coy = m.coy AND o.location_code = m.location_code " + " AND d.ref = t.ref") + " AND t.do_no = d.do_no AND d.do_no = o.do_no AND o.do_no = c.do_no " + " AND cast(d.so_item_detail as INT) = c.so_item") + " AND o.so_item = '*'" + " AND m.comm_code = c.comm_code";
            string str3 = (((((" UNION ALL SELECT " + str + " FROM wb_transaction t, wb_transDO d, wb_contract_sapinformation c, wb_contract o, wb_commodity m") + " WHERE t.coy = d.coy AND t.location_code = d.location_code ") + " AND d.coy = c.coy AND d.location_code = c.location_code " + " AND c.coy = o.coy AND c.location_code = o.location_code ") + " AND o.coy = m.coy AND o.location_code = m.location_code " + " AND d.ref like t.ref + '%'") + " AND t.do_no = d.do_no AND d.do_no = o.do_no AND o.do_no = c.do_no " + " AND cast(d.so_item_detail as INT) = c.so_item") + " AND o.so_item = '*'" + " AND m.comm_code = c.comm_code";
            if (this.textDO.Text.Trim() != "")
            {
                sqltext = sqltext + " AND t.do_no = '" + this.textDO.Text.Trim() + "'";
                str3 = str3 + " AND t.do_no = '" + this.textDO.Text.Trim() + "'";
            }
            if (this.textComm.Text.Trim() != "")
            {
                sqltext = sqltext + " AND c.comm_code = '" + this.textComm.Text + "'";
                str3 = str3 + " AND c.comm_code = '" + this.textComm.Text + "'";
            }
            sqltext = sqltext + " AND (t.Deleted IS NULL or t.Deleted = '' or t.Deleted = 'N')" + " AND t.report_date IS NOT null ";
            string[] textArray1 = new string[] { sqltext, " AND (t.report_date >= '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), " 00:00:00' and t.report_date <= '", this.monthCalendar2.Value.ToString("yyyy-MM-dd"), " 00:00:00' )" };
            sqltext = string.Concat(textArray1);
            str3 = str3 + " AND (t.Deleted IS NULL or t.Deleted = '' or t.Deleted = 'N')" + " AND t.report_date IS null ";
            if (!this.checkProcess.Checked)
            {
                sqltext = sqltext + " ORDER by t.do_no, c.so, convert(int, d.so_item_detail), t.ref ";
                table.OpenTable("wb_csi", sqltext, WBData.conn);
            }
            else
            {
                string[] textArray2 = new string[] { "SELECT * FROM (", sqltext, " ", str3, ") x ORDER by x.do_no, x.so, convert(int, x.so_item_detail), x.ref " };
                table.OpenTable("wb_csi", string.Concat(textArray2), WBData.conn);
            }
            return table;
        }

        public void getTemplate(string coy, string loc, WBTable data)
        {
            HTML rep = new HTML();
            rep.File = rep.File + @"\" + WBUser.UserID + "_Oustanding_SO_MultiLine.htm";
            rep.Title = "Report of SO Multiline Outstanding";
            rep.Open();
            rep.Write(rep.Style());
            rep.Write("<br><font size=5><b>REPORT OF SO MULTILINE OUTSTANDING</b></font><br>");
            string[] textArray1 = new string[] { "<br><font size=4><b>", WBSetting.tblSetting.DR["Coy_Name"].ToString(), " (", coy, ")</b></font>" };
            rep.Write(string.Concat(textArray1));
            string[] textArray2 = new string[] { "<br><font size=4><b>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", loc, ")</b></font><br>" };
            rep.Write(string.Concat(textArray2));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            rep.Write("<br><br>");
            rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
            if (this.textDO.Text.Trim() != "")
            {
                rep.Write("<tr class=bd>");
                rep.Write("<td>DO No</td>");
                rep.Write("<td>: <b>" + this.textDO.Text + "</b></td>");
                rep.Write("</tr>");
            }
            if (this.textComm.Text.Trim() != "")
            {
                rep.Write("<tr class=bd>");
                rep.Write("<td>Commodity</td>");
                rep.Write("<td>: <b>" + this.textComm.Text + "</b></td>");
                rep.Write("</tr>");
            }
            rep.Write("<tr class=bd>");
            rep.Write("<td>Selected Date</td>");
            string[] textArray3 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
            rep.Write(string.Concat(textArray3));
            rep.Write("</tr>");
            rep.Write("<tr class=bd>");
            rep.Write("<td>Report Date & Time</td>");
            rep.Write("<td>: <b>" + DateTime.Now.ToString() + "</b></td>");
            rep.Write("</tr>");
            rep.Write("</table>");
            rep.Write("<br/><br/><br/>");
            int num = 0 + 12;
            if (this.checkBrutoTarra.Checked)
            {
                num += 6;
            }
            if (this.checkDeduc.Checked)
            {
                num += 2;
            }
            if (this.check3rdParty.Checked)
            {
                num += 6;
            }
            if (this.checkLoadingQty.Checked)
            {
                num += 11;
            }
            if (this.cBoxReturnInKg.Checked)
            {
                num++;
            }
            if (this.cBoxReturnInPack.Checked)
            {
                num++;
            }
            if (this.cBoxLossInKg.Checked)
            {
                num++;
            }
            if (this.cBoxLossInPack.Checked)
            {
                num++;
            }
            int num2 = 1;
            string str = "";
            string pArg = "";
            string str3 = "";
            string str4 = "";
            string str5 = "";
            string str6 = "";
            double num3 = 0.0;
            double num4 = 0.0;
            double num5 = 0.0;
            double num6 = 0.0;
            double num7 = 0.0;
            double num8 = 0.0;
            double num9 = 0.0;
            double num10 = 0.0;
            double num11 = 0.0;
            double num12 = 0.0;
            double num13 = 0.0;
            double num14 = 0.0;
            double num15 = 0.0;
            double num16 = 0.0;
            double num17 = 0.0;
            double num18 = 0.0;
            double num19 = 0.0;
            double num20 = 0.0;
            double num21 = 0.0;
            double num22 = 0.0;
            double num23 = 0.0;
            double num24 = 0.0;
            double num25 = 0.0;
            double num26 = 0.0;
            double num27 = 0.0;
            double num28 = 0.0;
            double num29 = 0.0;
            double num30 = 0.0;
            double num31 = 0.0;
            double num32 = 0.0;
            double num33 = 0.0;
            double num34 = 0.0;
            double num35 = 0.0;
            double num36 = 0.0;
            double num37 = 0.0;
            double num38 = 0.0;
            double num39 = 0.0;
            double num40 = 0.0;
            double num41 = 0.0;
            double num42 = 0.0;
            double num43 = 0.0;
            double num44 = 0.0;
            double num45 = 0.0;
            double num46 = 0.0;
            double num47 = 0.0;
            double num48 = 0.0;
            double num49 = 0.0;
            double num50 = 0.0;
            double num51 = 0.0;
            double num52 = 0.0;
            double num53 = 0.0;
            double num54 = 0.0;
            double num55 = 0.0;
            double num56 = 0.0;
            double num57 = 0.0;
            double num58 = 0.0;
            double num59 = 0.0;
            double num60 = 0.0;
            double num61 = 0.0;
            double num62 = 0.0;
            double num63 = 0.0;
            double num64 = 0.0;
            double num65 = 0.0;
            double num66 = 0.0;
            double num67 = 0.0;
            double num68 = 0.0;
            double num69 = 0.0;
            double num70 = 0.0;
            double num71 = 0.0;
            rep.Write("<table class=onlyLine cellpadding=3 cellspacing=-1>");
            this.getHeader(rep);
            int num72 = 0;
            while (true)
            {
                if (num72 >= data.DT.Rows.Count)
                {
                    rep.Write("<tr class='bd'>");
                    rep.Write("<td colspan=12><b>TOTAL</b></td>");
                    if (this.checkBrutoTarra.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num18.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + num19.ToString() + "</b></td>");
                        if (this.checkDeduc.Checked)
                        {
                            rep.Write("<td nowrap align=right><b>" + num25.ToString() + " </b></td>");
                            rep.Write("<td nowrap align=right><b>" + num26.ToString() + " </b></td>");
                        }
                        rep.Write("<td nowrap align=right><b>" + num20.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right colspan=3><b>&nbsp;</b></td>");
                    }
                    if (this.check3rdParty.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num9.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + num10.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + num11.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right colspan=3><b>&nbsp;</b></td>");
                    }
                    if (this.checkLoadingQty.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num33.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + num35.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>&nbsp;</td>");
                        rep.Write("<td nowrap align=right><b>" + num34.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + Math.Round(num71, 2) + "</td>");
                        rep.Write("<td nowrap align=right><b>" + Math.Round(num69, 2) + "</b></td>");
                        rep.Write("<td nowrap align=right><b>&nbsp;</td>");
                        rep.Write("<td nowrap align=right colspan=3><b>&nbsp;</b></td>");
                    }
                    rep.Write("<td nowrap align=right><b>&nbsp;</b></td>");
                    if (this.cBoxReturnInKg.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num43.ToString() + "</b></td>");
                    }
                    if (this.cBoxReturnInPack.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num42.ToString() + "</b></td>");
                    }
                    if (this.cBoxLossInKg.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num45.ToString() + "</b></td>");
                    }
                    if (this.cBoxLossInPack.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num44.ToString() + "</b></td>");
                    }
                    rep.Write("</tr>");
                    rep.Write("</table>");
                    rep.Write("<br/>");
                    rep.writeSign();
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + rep.File) }
                    };
                    report.ShowDialog();
                    rep.Close();
                    rep.Dispose();
                    report.Dispose();
                    this.labelProcess.Visible = false;
                    this.labelRecNo.Visible = false;
                    return;
                }
                DataRow row = data.DT.Rows[num72];
                this.labelRecNo.Text = num2.ToString() + " / " + data.DT.Rows.Count.ToString();
                this.labelRecNo.Refresh();
                if ((str != row["do_no"].ToString()) || (pArg != Convert.ToInt32(row["so_item_detail"].ToString()).ToString()))
                {
                    num3 = 0.0;
                    num4 = 0.0;
                    num5 = 0.0;
                    num8 = 0.0;
                    num6 = 0.0;
                    num7 = 0.0;
                    num12 = 0.0;
                    num13 = 0.0;
                    num14 = 0.0;
                    num15 = 0.0;
                    num16 = 0.0;
                    num17 = 0.0;
                    num21 = 0.0;
                    num22 = 0.0;
                    num23 = 0.0;
                    num24 = 0.0;
                    num28 = 0.0;
                    num27 = 0.0;
                    num29 = 0.0;
                    num30 = 0.0;
                    num31 = 0.0;
                    num32 = 0.0;
                    num66 = 0.0;
                    num67 = 0.0;
                    num70 = 0.0;
                    num36 = 0.0;
                    num37 = 0.0;
                    num38 = 0.0;
                    num39 = 0.0;
                    num40 = 0.0;
                    num41 = 0.0;
                    num58 = 0.0;
                    num59 = 0.0;
                    num46 = 0.0;
                    num47 = 0.0;
                    num48 = 0.0;
                    num49 = 0.0;
                    num50 = 0.0;
                    num51 = 0.0;
                    num52 = 0.0;
                    num53 = 0.0;
                    num54 = 0.0;
                    num55 = 0.0;
                    num56 = 0.0;
                    num57 = 0.0;
                    num60 = 0.0;
                    num61 = 0.0;
                    num62 = 0.0;
                    str = row["do_no"].ToString();
                    pArg = Convert.ToInt32(row["so_item_detail"].ToString()).ToString();
                    rep.Write("<tr class='bd'>");
                    string[] textArray4 = new string[] { "<td colspan=", num.ToString(), "><b>SO : ", row["so"].ToString(), "/", Program.StrToDouble(pArg, 0).ToString(), "<b></td>" };
                    rep.Write(string.Concat(textArray4));
                    rep.Write("</tr>");
                }
                WBTable table = new WBTable();
                table.OpenTable("wb_commodity", "SELECT Gross_Weight ,Netto_Weight, bulkpack, unit FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + row["comm_code"].ToString() + "'"), WBData.conn);
                num65 = (table.DT.Rows[0]["gross_weight"].ToString() == "") ? ((double) 0f) : ((double) float.Parse(table.DT.Rows[0]["gross_weight"].ToString()));
                num63 = (table.DT.Rows[0]["netto_weight"].ToString() == "") ? ((double) 0f) : ((double) float.Parse(table.DT.Rows[0]["netto_weight"].ToString()));
                str5 = table.DT.Rows[0]["bulkpack"].ToString();
                str6 = table.DT.Rows[0]["unit"].ToString();
                table.Dispose();
                num61 = num62 = num60 = Program.StrToDouble(row["Quantity"].ToString().Trim(), 0);
                str4 = row["deductedBy"].ToString();
                if (row["Entry_Fact"].ToString().Trim() != "0")
                {
                    num62 = Program.StrToDouble(row["Entry_Fact"].ToString().Trim(), 0);
                }
                if (row["Entry_Est"].ToString().Trim() != "0")
                {
                    num61 = Program.StrToDouble(row["Entry_Est"].ToString().Trim(), 0);
                }
                if (str4 == "0")
                {
                    if (row["Entry_Fact"].ToString().Trim() != "0")
                    {
                        num60 = Program.StrToDouble(row["Entry_Fact"].ToString().Trim(), 0);
                    }
                }
                else if ((str4 == "1") && (row["Entry_Est"].ToString().Trim() != "0"))
                {
                    num60 = Program.StrToDouble(row["Entry_Est"].ToString().Trim(), 0);
                }
                str4 = row["deductedBy"].ToString();
                double[] numArray = this.cekSDHI(row["do_no"].ToString(), row["so_item_detail"].ToString());
                num64 = numArray[3];
                num3 = Program.StrToDouble(row["Gross_Estate"].ToString(), 0);
                num4 = Program.StrToDouble(row["Tare_Estate"].ToString(), 0);
                num5 = Program.StrToDouble(row["Estate_qty"].ToString(), 0);
                num8 += num5;
                num6 += num3;
                num7 += num4;
                num9 += num3;
                num10 += num4;
                num11 += num5;
                num12 = Program.StrToDouble(row["Bruto"].ToString(), 0);
                num13 = Program.StrToDouble(row["Tarra"].ToString(), 0);
                num14 = Program.StrToDouble(row["Netto"].ToString(), 0);
                num15 += num12;
                num16 += num13;
                num17 += num14;
                num18 += num12;
                num19 += num13;
                num20 += num14;
                num21 = Program.StrToDouble(row["Received"].ToString(), 0);
                num22 = Program.StrToDouble(row["Deduction"].ToString(), 0);
                num23 += num21;
                num24 += num22;
                num25 += num21;
                num26 += num22;
                num28 = Program.StrToDouble(row["loading_qty"].ToString(), 3);
                num27 = Program.StrToDouble(row["loading_qty_opw"].ToString(), 3);
                num29 = Math.Round((double) (Program.StrToDouble(row["loading_qty"].ToString(), 3) * num63));
                num36 = 0.0;
                num37 = 0.0;
                num30 += num28;
                num31 += num29;
                num32 += num27;
                num33 += num28;
                num34 += num29;
                num35 += num27;
                num38 += Program.StrToDouble(row["return_qty_pack"].ToString(), 3);
                num39 += Program.StrToDouble(row["return_qty_kg"].ToString(), 0);
                num42 += Program.StrToDouble(row["return_qty_pack"].ToString(), 3);
                num43 += Program.StrToDouble(row["return_qty_kg"].ToString(), 0);
                str3 = row["mark_return"].ToString();
                if (str3 != "X")
                {
                    num46 -= num5;
                    num47 -= num5;
                    if (str4 == "1")
                    {
                        if ((str5 != "P") && ((str6 == "KG") || (str6 == "")))
                        {
                            num49 = (num5 <= 0.0) ? (num49 - num14) : (num49 - num5);
                        }
                        else
                        {
                            num48 -= num5;
                            num49 -= num5;
                        }
                    }
                    else if ((str5 != "P") && ((str6 == "KG") || (str6 == "")))
                    {
                        num49 -= num5;
                    }
                    else
                    {
                        num48 -= num5;
                        num49 -= num5;
                    }
                }
                else if (row["mark_return"].ToString() != "X")
                {
                    num46 += num14;
                    num47 = ((Program.StrToDouble(row["Estate_qty"].ToString(), 0) <= 0.0) && (Program.StrToDouble(row["return_qty_kg"].ToString(), 0) <= 0.0)) ? (num47 + num14) : (num47 + num5);
                    if (str4 != "1")
                    {
                        if ((str5 != "P") && ((str6 == "KG") || (str6 == "")))
                        {
                            num49 += num14;
                        }
                        else if (str5 != "P")
                        {
                            num48 += num28;
                        }
                        else
                        {
                            num49 += num29;
                            num48 += num29;
                        }
                    }
                    else if ((str5 != "P") && ((str6 == "KG") || (str6 == "")))
                    {
                        int result = 0;
                        if (row["return_qty_kg"] != null)
                        {
                            int.TryParse(row["return_qty_kg"].ToString(), out result);
                        }
                        num36 = (num14 - (num5 + result)) * -1.0;
                        num41 += num36;
                        num45 += num36;
                        num49 = (num5 <= 0.0) ? (((num49 + num14) - (num36 * -1.0)) - result) : (((num49 + num5) - (num36 * -1.0)) - result);
                    }
                    else
                    {
                        num37 = (num28 - (num27 + Program.StrToDouble(row["return_qty_pack"].ToString(), 3))) * -1.0;
                        num40 += num37;
                        num44 += num37;
                        if ((Program.StrToDouble(row["return_qty_pack"].ToString(), 3) > 0.0) || (Program.StrToDouble(row["loading_qty_opw"].ToString(), 3) > 0.0))
                        {
                            num49 += Math.Round((double) (Convert.ToDouble(row["loading_qty_opw"]) * num63));
                            num48 += Math.Round((double) (Convert.ToDouble(row["loading_qty_opw"]) * num63));
                        }
                        else
                        {
                            num49 += num29;
                            num48 += num29;
                        }
                    }
                }
                try
                {
                    num66 = num65 * num28;
                }
                catch
                {
                    num66 = 0.0;
                }
                num70 += num66;
                num71 += num66;
                num66 = num14 - num66;
                if (num66 < 0.0)
                {
                    num66 *= -1.0;
                }
                num68 = (num66 / num14) * 100.0;
                num67 += num66;
                num69 += num66;
                num50 = num64 + num49;
                num51 = numArray[0] + num47;
                num52 = numArray[1] + num46;
                num53 = numArray[2] + num48;
                if (row["mark_return"].ToString() != "X")
                {
                    num54 = num60 - (num64 + num49);
                    num55 = num60 - (numArray[1] + num46);
                    num56 = num60 - (numArray[0] + num47);
                    num57 = num60 - (numArray[2] + num48);
                }
                if ((str5 == "P") || ((str6 != "KG") && (str6 != "")))
                {
                    num58 = num57;
                }
                else if (str4 == "0")
                {
                    num58 = num55;
                }
                else if (str4 == "1")
                {
                    num58 = num56;
                }
                rep.Write("<tr class='bd'>");
                rep.Write("<td nowrap>" + num2 + "</td>");
                rep.Write("<td nowrap>" + row["comm_code"].ToString() + " </td>");
                rep.Write("<td nowrap>" + row["comm_name"].ToString() + " </td>");
                rep.Write("<td nowrap>" + row["relation_code"].ToString() + " </td>");
                rep.Write("<td nowrap>" + row["do_sap"].ToString() + " </td>");
                rep.Write("<td nowrap>" + row["do_sap_item"].ToString() + " </td>");
                rep.Write("<td nowrap>" + row["report_date"].ToString() + " </td>");
                rep.Write("<td nowrap>" + row["ref"].ToString() + " </td>");
                rep.Write("<td nowrap>" + row["truck_number"].ToString() + " </td>");
                rep.Write("<td nowrap>" + row["name"].ToString() + " </td>");
                rep.Write("<td nowrap>" + row["transporter_code"].ToString() + " </td>");
                rep.Write("<td nowrap>" + row["quantity"].ToString() + " </td>");
                if (this.checkBrutoTarra.Checked)
                {
                    rep.Write("<td nowrap align=right>" + num12.ToString() + " </td>");
                    rep.Write("<td nowrap align=right>" + num13.ToString() + " </td>");
                    if (this.checkDeduc.Checked)
                    {
                        rep.Write("<td nowrap align=right>" + num21.ToString() + " </td>");
                        rep.Write("<td nowrap align=right>" + num22.ToString() + " </td>");
                    }
                    rep.Write("<td nowrap align=right>" + num14.ToString() + " </td>");
                    rep.Write("<td nowrap align=right>" + num46.ToString() + "</td>");
                    rep.Write("<td nowrap align=right>" + num52.ToString() + "</td>");
                    if (str3 == "X")
                    {
                        rep.Write("<td nowrap align=right> - </td>");
                    }
                    else
                    {
                        rep.Write("<td nowrap align=right>" + num55.ToString() + "</td>");
                    }
                }
                if (this.check3rdParty.Checked)
                {
                    rep.Write("<td nowrap align=right>" + num3.ToString() + " </td>");
                    rep.Write("<td nowrap align=right>" + num4.ToString() + " </td>");
                    rep.Write("<td nowrap align=right>" + num5.ToString() + " </td>");
                    rep.Write("<td nowrap align=right>" + num47.ToString() + "</td>");
                    rep.Write("<td nowrap align=right>" + num51.ToString() + "</td>");
                    if (str3 == "X")
                    {
                        rep.Write("<td nowrap align=right> - </td>");
                    }
                    else
                    {
                        rep.Write("<td nowrap align=right>" + num56.ToString() + "</td>");
                    }
                }
                if (this.checkLoadingQty.Checked)
                {
                    rep.Write("<td nowrap align=right>" + num28.ToString() + " </td>");
                    rep.Write("<td nowrap align=right>" + num27.ToString() + " </td>");
                    rep.Write("<td nowrap align=right>" + str6.ToString() + " </td>");
                    rep.Write("<td nowrap align=right>" + num29.ToString() + " </td>");
                    rep.Write("<td nowrap align=right>" + Math.Round((double) (num65 * num28), 3) + " </td>");
                    rep.Write("<td nowrap align=right>" + Math.Round(num66, 2) + " </td>");
                    rep.Write("<td nowrap align=right>" + Math.Round(num68, 2) + " </td>");
                    rep.Write("<td nowrap align=right>" + num48.ToString() + " </td>");
                    rep.Write("<td nowrap align=right>" + num53.ToString() + " </td>");
                    if (str3 == "X")
                    {
                        rep.Write("<td nowrap align=right> - </td>");
                    }
                    else
                    {
                        rep.Write("<td nowrap align=right>" + num57.ToString() + " </td>");
                    }
                }
                if (str3 == "X")
                {
                    rep.Write("<td nowrap align=right> - </td>");
                }
                else
                {
                    rep.Write("<td nowrap align=right>" + num58.ToString() + "</td>");
                }
                if (this.cBoxReturnInKg.Checked)
                {
                    rep.Write("<td nowrap align=right>" + Program.StrToDouble(row["Return_qty_Kg"].ToString(), 0).ToString() + "</td>");
                }
                if (this.cBoxReturnInPack.Checked)
                {
                    rep.Write("<td nowrap align=right>" + Program.StrToDouble(row["Return_qty_pack"].ToString(), 3).ToString() + "</td>");
                }
                if (this.cBoxLossInKg.Checked)
                {
                    rep.Write("<td nowrap align=right>" + num36.ToString() + "</td>");
                }
                if (this.cBoxLossInPack.Checked)
                {
                    rep.Write("<td nowrap align=right>" + num37.ToString() + "</td>");
                }
                rep.Write("</tr>");
                num2++;
                DataRow row2 = null;
                string str7 = null;
                string str8 = null;
                if (num72 < (data.DT.Rows.Count - 1))
                {
                    row2 = data.DT.Rows[num72 + 1];
                    str7 = row2["do_no"].ToString();
                    str8 = Convert.ToInt32(row2["so_item_detail"].ToString()).ToString();
                }
                if ((str != str7) || (pArg != str8))
                {
                    rep.Write("<tr class='bd'>");
                    object[] objArray1 = new object[] { "<td colspan=12><b>SUB TOTAL OF SO ", row["so"].ToString(), "/", Program.StrToDouble(row["so_item_detail"].ToString(), 0), "</b></td>" };
                    rep.Write(string.Concat(objArray1));
                    if (this.checkBrutoTarra.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num15.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + num16.ToString() + "</b></td>");
                        if (this.checkDeduc.Checked)
                        {
                            rep.Write("<td nowrap align=right><b>" + num23.ToString() + " </b></td>");
                            rep.Write("<td nowrap align=right><b>" + num24.ToString() + " </b></td>");
                        }
                        rep.Write("<td nowrap align=right><b>" + num17.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + num46.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + (numArray[1] + num46).ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + (num62 - (numArray[1] + num46)).ToString() + "</b></td>");
                    }
                    if (this.check3rdParty.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num6.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + num7.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + num8.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + num47.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + (numArray[0] + num47).ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + (num61 - (numArray[0] + num47)).ToString() + "</b></td>");
                    }
                    if (this.checkLoadingQty.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num30.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + num32.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>&nbsp;</td>");
                        rep.Write("<td nowrap align=right><b>" + num31.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + Math.Round(num70, 2) + " </b></td>");
                        rep.Write("<td nowrap align=right><b>" + Math.Round(num67, 2) + " </b></td>");
                        rep.Write("<td nowrap align=right><b>&nbsp;</b></td>");
                        rep.Write("<td nowrap align=right><b>" + num48.ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + (num64 + num48).ToString() + "</b></td>");
                        rep.Write("<td nowrap align=right><b>" + (num60 - (num64 + num48)).ToString() + "</b></td>");
                    }
                    if ((str5 == "P") || ((str6 != "KG") && (str6 != "")))
                    {
                        num59 = num60 - (num64 + num48);
                    }
                    else if (str4 == "0")
                    {
                        num59 = num62 - (numArray[1] + num46);
                    }
                    else if (str4 == "1")
                    {
                        num59 = num61 - (numArray[0] + num47);
                    }
                    rep.Write("<td nowrap align=right><b>" + num59.ToString() + "</b></td>");
                    if (this.cBoxReturnInKg.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num39.ToString() + "</b></td>");
                    }
                    if (this.cBoxReturnInPack.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num38.ToString() + "</b></td>");
                    }
                    if (this.cBoxLossInKg.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num41.ToString() + "</b></td>");
                    }
                    if (this.cBoxLossInPack.Checked)
                    {
                        rep.Write("<td nowrap align=right><b>" + num40.ToString() + "</b></td>");
                    }
                    rep.Write("</tr>");
                    rep.Write("<tr><td colspan=" + num.ToString() + ">&nbsp;</td></tr>");
                }
                num72++;
            }
        }

        private void InitializeComponent()
        {
            this.label5 = new Label();
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.grType = new GroupBox();
            this.labelComm = new Label();
            this.buttonComm = new Button();
            this.textComm = new TextBox();
            this.label3 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.label2 = new Label();
            this.monthCalendar1 = new DateTimePicker();
            this.buttonDO = new Button();
            this.label1 = new Label();
            this.textDO = new TextBox();
            this.labelcommodity = new Label();
            this.gbDispOpt = new GroupBox();
            this.checkDeduc = new CheckBox();
            this.checkLoadingQty = new CheckBox();
            this.check3rdParty = new CheckBox();
            this.checkBrutoTarra = new CheckBox();
            this.cBoxReturnInPack = new CheckBox();
            this.cBoxLossInPack = new CheckBox();
            this.cBoxLossInKg = new CheckBox();
            this.cBoxReturnInKg = new CheckBox();
            this.button2 = new Button();
            this.button3 = new Button();
            this.checkProcess = new CheckBox();
            this.grType.SuspendLayout();
            this.gbDispOpt.SuspendLayout();
            base.SuspendLayout();
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(12, 0x12);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0xbd, 13);
            this.label5.TabIndex = 0x77;
            this.label5.Text = "Multiline SO Outstanding Report";
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x1e4, 0x12);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 0x7a;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x15d, 0x12);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 0x79;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.grType.Controls.Add(this.checkProcess);
            this.grType.Controls.Add(this.labelComm);
            this.grType.Controls.Add(this.buttonComm);
            this.grType.Controls.Add(this.textComm);
            this.grType.Controls.Add(this.label3);
            this.grType.Controls.Add(this.monthCalendar2);
            this.grType.Controls.Add(this.label2);
            this.grType.Controls.Add(this.monthCalendar1);
            this.grType.Controls.Add(this.buttonDO);
            this.grType.Controls.Add(this.label1);
            this.grType.Controls.Add(this.textDO);
            this.grType.Controls.Add(this.labelcommodity);
            this.grType.Location = new Point(15, 0x2f);
            this.grType.Name = "grType";
            this.grType.Size = new Size(0x214, 0x8d);
            this.grType.TabIndex = 0x8f;
            this.grType.TabStop = false;
            this.labelComm.AutoSize = true;
            this.labelComm.Location = new Point(0x145, 0x59);
            this.labelComm.Name = "labelComm";
            this.labelComm.Size = new Size(0x43, 13);
            this.labelComm.TabIndex = 0xba;
            this.labelComm.Text = "Comm Name";
            this.labelComm.Visible = false;
            this.buttonComm.Location = new Point(0x12b, 0x54);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 0xb7;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.textComm.CharacterCasing = CharacterCasing.Upper;
            this.textComm.Location = new Point(0x63, 0x56);
            this.textComm.Name = "textComm";
            this.textComm.Size = new Size(0xc5, 20);
            this.textComm.TabIndex = 0xb8;
            this.textComm.Leave += new EventHandler(this.textComm_Leave);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x12, 0x59);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x40, 13);
            this.label3.TabIndex = 0xb9;
            this.label3.Text = "Commodity :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x139, 0x12);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 0xb6;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(280, 0x16);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x1a, 13);
            this.label2.TabIndex = 0xb5;
            this.label2.Text = "To :";
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x8e, 0x12);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 180;
            this.buttonDO.Location = new Point(0x12b, 0x3a);
            this.buttonDO.Margin = new Padding(0);
            this.buttonDO.Name = "buttonDO";
            this.buttonDO.Size = new Size(0x17, 0x17);
            this.buttonDO.TabIndex = 0x90;
            this.buttonDO.Text = "...";
            this.buttonDO.UseVisualStyleBackColor = true;
            this.buttonDO.Click += new EventHandler(this.button1st_Click);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(100, 0x16);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x24, 13);
            this.label1.TabIndex = 0xb3;
            this.label1.Text = "From :";
            this.textDO.CharacterCasing = CharacterCasing.Upper;
            this.textDO.Location = new Point(0x63, 60);
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0xc5, 20);
            this.textDO.TabIndex = 0x90;
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x12, 0x3f);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x2e, 13);
            this.labelcommodity.TabIndex = 0x90;
            this.labelcommodity.Text = "DO No :";
            this.gbDispOpt.Controls.Add(this.checkDeduc);
            this.gbDispOpt.Controls.Add(this.checkLoadingQty);
            this.gbDispOpt.Controls.Add(this.check3rdParty);
            this.gbDispOpt.Controls.Add(this.checkBrutoTarra);
            this.gbDispOpt.Controls.Add(this.cBoxReturnInPack);
            this.gbDispOpt.Controls.Add(this.cBoxLossInPack);
            this.gbDispOpt.Controls.Add(this.cBoxLossInKg);
            this.gbDispOpt.Controls.Add(this.cBoxReturnInKg);
            this.gbDispOpt.Location = new Point(15, 0xc2);
            this.gbDispOpt.Name = "gbDispOpt";
            this.gbDispOpt.Size = new Size(0x214, 0x53);
            this.gbDispOpt.TabIndex = 0xb2;
            this.gbDispOpt.TabStop = false;
            this.gbDispOpt.Text = "Displayed Column";
            this.checkDeduc.AutoSize = true;
            this.checkDeduc.Checked = true;
            this.checkDeduc.CheckState = CheckState.Checked;
            this.checkDeduc.Location = new Point(0x197, 0x1b);
            this.checkDeduc.Name = "checkDeduc";
            this.checkDeduc.Size = new Size(0x4b, 0x11);
            this.checkDeduc.TabIndex = 0xb8;
            this.checkDeduc.Text = "Deduction";
            this.checkDeduc.UseVisualStyleBackColor = true;
            this.checkLoadingQty.AutoSize = true;
            this.checkLoadingQty.Checked = true;
            this.checkLoadingQty.CheckState = CheckState.Checked;
            this.checkLoadingQty.Location = new Point(0x11b, 0x1b);
            this.checkLoadingQty.Name = "checkLoadingQty";
            this.checkLoadingQty.Size = new Size(0x6a, 0x11);
            this.checkLoadingQty.TabIndex = 0xb7;
            this.checkLoadingQty.Text = "Loading Quantity";
            this.checkLoadingQty.UseVisualStyleBackColor = true;
            this.check3rdParty.AutoSize = true;
            this.check3rdParty.Checked = true;
            this.check3rdParty.CheckState = CheckState.Checked;
            this.check3rdParty.Location = new Point(0x80, 0x1b);
            this.check3rdParty.Name = "check3rdParty";
            this.check3rdParty.Size = new Size(0x88, 0x11);
            this.check3rdParty.TabIndex = 0xb6;
            this.check3rdParty.Text = "Other Party/Estate Qty)";
            this.check3rdParty.UseVisualStyleBackColor = true;
            this.checkBrutoTarra.AutoSize = true;
            this.checkBrutoTarra.Checked = true;
            this.checkBrutoTarra.CheckState = CheckState.Checked;
            this.checkBrutoTarra.Location = new Point(13, 0x1b);
            this.checkBrutoTarra.Name = "checkBrutoTarra";
            this.checkBrutoTarra.Size = new Size(0x56, 0x11);
            this.checkBrutoTarra.TabIndex = 0xb5;
            this.checkBrutoTarra.Text = "Gross / Tare";
            this.checkBrutoTarra.UseVisualStyleBackColor = true;
            this.checkBrutoTarra.CheckedChanged += new EventHandler(this.checkBrutoTarra_CheckedChanged);
            this.cBoxReturnInPack.AutoSize = true;
            this.cBoxReturnInPack.Location = new Point(0x80, 50);
            this.cBoxReturnInPack.Name = "cBoxReturnInPack";
            this.cBoxReturnInPack.Size = new Size(0x61, 0x11);
            this.cBoxReturnInPack.TabIndex = 0xb0;
            this.cBoxReturnInPack.Text = "Return in Pack";
            this.cBoxReturnInPack.UseVisualStyleBackColor = true;
            this.cBoxLossInPack.AutoSize = true;
            this.cBoxLossInPack.Location = new Point(0x197, 50);
            this.cBoxLossInPack.Name = "cBoxLossInPack";
            this.cBoxLossInPack.Size = new Size(0x57, 0x11);
            this.cBoxLossInPack.TabIndex = 0xb0;
            this.cBoxLossInPack.Text = "Loss in Pack";
            this.cBoxLossInPack.UseVisualStyleBackColor = true;
            this.cBoxLossInKg.AutoSize = true;
            this.cBoxLossInKg.Location = new Point(0x11b, 50);
            this.cBoxLossInKg.Name = "cBoxLossInKg";
            this.cBoxLossInKg.Size = new Size(0x4d, 0x11);
            this.cBoxLossInKg.TabIndex = 0xb0;
            this.cBoxLossInKg.Text = "Loss in KG";
            this.cBoxLossInKg.UseVisualStyleBackColor = true;
            this.cBoxReturnInKg.AutoSize = true;
            this.cBoxReturnInKg.Location = new Point(13, 50);
            this.cBoxReturnInKg.Name = "cBoxReturnInKg";
            this.cBoxReturnInKg.Size = new Size(0x57, 0x11);
            this.cBoxReturnInKg.TabIndex = 0xb0;
            this.cBoxReturnInKg.Text = "Return in KG";
            this.cBoxReturnInKg.UseVisualStyleBackColor = true;
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1cb, 0x123);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x58, 0x20);
            this.button2.TabIndex = 180;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button3.Location = new Point(0x16d, 0x123);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x58, 0x21);
            this.button3.TabIndex = 0xb3;
            this.button3.Text = "Process";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.checkProcess.AutoSize = true;
            this.checkProcess.Location = new Point(13, 0x76);
            this.checkProcess.Name = "checkProcess";
            this.checkProcess.Size = new Size(0x93, 0x11);
            this.checkProcess.TabIndex = 0xbb;
            this.checkProcess.Text = "Include Processing Truck";
            this.checkProcess.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x232, 0x155);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.gbDispOpt);
            base.Controls.Add(this.grType);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.label5);
            base.Name = "RepOutstandingMultiLine";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Multiline SO Outstanding Report";
            base.Load += new EventHandler(this.RepOutstandingMultiLine_Load);
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            this.gbDispOpt.ResumeLayout(false);
            this.gbDispOpt.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void RepOutstandingMultiLine_Load(object sender, EventArgs e)
        {
            WBTable tbl = new WBTable();
            tbl.OpenTable("wb_contract", "Select * from wb_contract WHERE " + WBData.CompanyLocation(""), WBData.conn);
            Program.AutoComp(tbl, "Do_No", this.textDO);
            tbl.Dispose();
            this.tbl_comm.OpenTable("wb_commodity", "Select * from wb_commodity WHERE " + WBData.CompanyLocation(""), WBData.conn);
            Program.AutoComp(this.tbl_comm, "Comm_Code", this.textComm);
        }

        private void textComm_Leave(object sender, EventArgs e)
        {
            this.labelComm.Visible = true;
            this.labelComm.Text = "";
            if (this.textComm.Text.Trim() != "")
            {
                this.tbl_comm.ReOpen();
                string[] aField = new string[] { "Comm_code" };
                string[] aFind = new string[] { this.textComm.Text.Trim() };
                int recNo = this.tbl_comm.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelComm.Text = this.tbl_comm.DT.Rows[recNo]["Comm_name"].ToString().Trim();
                }
                else
                {
                    this.buttonComm.PerformClick();
                    this.textComm.Focus();
                }
            }
        }
    }
}

