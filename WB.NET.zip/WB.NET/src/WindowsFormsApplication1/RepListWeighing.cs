﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Runtime.CompilerServices;
    using System.Windows.Forms;

    public class RepListWeighing : Form
    {
        public bool isOk = false;
        public string tipe;
        public string kb;
        private WBTable tbl_Do;
        private WBTable tbl_Transport;
        private WBTable tbl_Driver;
        private WBTable tbl_Comm;
        private WBTable tbl_iscc;
        private WBTable tbl_Storage;
        private WBTable tblTruck;
        private DataRow DRComm;
        private DateTime time1;
        private DateTime time2;
        private TimeSpan ts;
        private string tmpDate;
        private string Retur_masuk;
        private string Retur_keluar;
        private IContainer components = null;
        public Button buttonDoNo;
        public Label labelDoNo;
        public CheckBox checkDate;
        public DateTimePicker monthCalendar1;
        public DateTimePicker monthCalendar2;
        public TextBox textDoNo;
        public Button buttonComm;
        public Label labelCommName;
        public TextBox textCommodity;
        public Label labelcommodity;
        public Label label1;
        public Label label2;
        public GroupBox groupDate;
        public Button button2;
        public Button button1;
        public GroupBox grKB;
        public RadioButton rboNonKB;
        public RadioButton rboKB;
        public Button buttonTransporter;
        public Label label4;
        public TextBox textTransport;
        public GroupBox grType;
        public RadioButton rboGI;
        public RadioButton rboGR;
        public Label labelProses2;
        public Label labelProses1;
        private Panel panel1;
        private CheckBox checkDO_No;
        private CheckBox checkDelivery;
        private CheckBox checkSTO;
        private CheckBox checkPO;
        private CheckBox check1xSTO;
        private CheckBox check1xDO;
        private CheckBox checkRelation;
        private CheckBox checkEstate;
        private CheckBox checkDriverName;
        private CheckBox checkLicenseNo;
        private CheckBox checkDeliNote;
        private CheckBox checkTransporter;
        private CheckBox checkBrutoTarra;
        private CheckBox check3rdParty;
        private CheckBox checkDiff;
        private CheckBox checkSeal;
        private CheckBox checkRmkReport;
        private CheckBox checkRmkTicket;
        public Label label3;
        private Button buttonStorage;
        public TextBox textStorage;
        private Label labelStorageName;
        private CheckBox checkStorage;
        private CheckBox checkConv;
        private CheckBox checkProcess;
        private CheckBox checkWBRef;
        private CheckBox checkAutomated;
        public Label label7;
        public TextBox textTruck;
        public Button buttonTruck;
        private CheckBox cbGunny;
        private CheckBox cbDeduction;
        private CheckBox checkContract;
        public TextBox textTank;
        private CheckBox checkBoxTank;
        private CheckBox checkColly;
        public Button buttonDriver;
        public Label label5;
        public TextBox textDriver;
        private CheckBox cbDL;
        private ComboBox comboComm;
        private CheckBox checkRelationName;
        public TextBox txtqstandard;
        public Button btnQstandard;
        public CheckBox chkQstandard;
        public CheckBox chkNonQ;
        private ComboBox ComboIscc;
        public Label labelQStandard;
        private CheckBox checkChgBy;
        private CheckBox checkCrtBy;
        private CheckBox checkQSt;
        private CheckBox cbAddInfo;
        private CheckBox cBoxPISI;
        private CheckBox checkBoxMaterialStuffing;
        private CheckBox checkLoadingQty;
        private StatusStrip statusStrip1;
        private CheckBox cBoxCommName;
        private CheckBox cBoxTransName;
        private CheckBox cBoxYellowPlate;
        private CheckBox cBoxDiffHour;
        private CheckBox cb_internal_no;
        private CheckBox cb_do_sap;
        private CheckBox cBoxAll;
        private CheckBox cBoxWBCode;
        private MaskedTextBox TimeTo;
        private MaskedTextBox TimeFrom;
        public TextBox txt_ref;
        public Label label6;
        private CheckBox checkSourceDesc;
        private CheckBox checkSourceCode;
        private CheckBox cb_tank;
        private CheckBox checkBoxGatepassNumber;
        private CheckBox checkGrade;
        private CheckBox cb_interval34;
        private CheckBox cb_interval12;
        private CheckBox checkRegistrationInOut;
        private GroupBox gb_grouping;
        private RadioButton rb_mill;
        private RadioButton rb_comm;
        public TextBox txt_mill;
        public Label label8;
        public Button sh_mill;
        public Label label9;
        public TextBox txt_contract;
        public Button button3;
        private CheckBox cBoxLossInPack;
        private CheckBox cBoxLossInKg;
        private CheckBox cBoxReturInKg;
        private CheckBox cBoxReturInPack;
        private RadioButton rb_none;
        private RadioButton rb_iscc;
        private RadioButton rboAll;
        private RadioButton rboKBAll;
        private CheckBox checkNot1stYet;
        private CheckBox checkSO;
        private CheckBox checkTrailerNo;

        public RepListWeighing()
        {
            this.InitializeComponent();
        }

        private void btnQstandard_Click(object sender, EventArgs e)
        {
            FormQStandard standard = new FormQStandard {
                pMode = "CHOOSE"
            };
            standard.ShowDialog();
            if (standard.countt != 0)
            {
                this.txtqstandard.Text = standard.arry[0].ToString();
                this.txtqstandard.Focus();
                this.ComboIscc.Items.Clear();
                foreach (string str in standard.arry)
                {
                    if (str != null)
                    {
                        this.ComboIscc.Items.Add(str);
                    }
                }
            }
            if (standard.ReturnRow != null)
            {
                this.txtqstandard.Text = standard.ReturnRow["iscc_code"].ToString();
                this.labelQStandard.Text = standard.ReturnRow["iscc_text"].ToString();
                this.textCommodity.Focus();
            }
            standard.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if ((this.rb_iscc.Checked && this.chkQstandard.Checked) && (this.txtqstandard.Text.Trim() == ""))
            {
                MessageBox.Show("Please choose quality standard!", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.txtqstandard.Focus();
            }
            else
            {
                int num89;
                this.isOk = true;
                int num2 = 6;
                int num3 = 6;
                int num4 = 0;
                new WBTable().OpenTable("wb_driver", "Select * From wb_driver WITH (NOLOCK)", WBData.conn);
                WBTable table2 = new WBTable();
                WBTable table3 = new WBTable();
                string[] textArray1 = new string[] { "SELECT trx.uniq, trx.Coy, trx.Location_Code, trx.WX, trx.Ref, trx.Ref_Date, trx.Report_Date, \r\n                             trx.Report2_Date, trx._1st, trx._2nd, trx._3rd, trx._4th, trx.Delivery_Date, trx.Delivery_Time, \r\n                             trx.Register_Date, trx.Register_Time, trx.Estate_Code, trx.Storage, trx.Truck_Number, trx.Truck_Number2, \r\n                             trx.License_No, trx.Name, trx.Transporter_Code, trx.Delivery_Note, trx.Unloading, trx.In_Time, trx.Out_Time, \r\n                             trx.Remark_Ticket, trx.Remark_Report, trx.Gross_Estate, trx.Tare_Estate, trx.TotalBunch, trx.TotalBunchGrading, \r\n                             trx.Average, trx.Fruits_Type, trx.Rend_CPO, trx.UnitName, trx.WeightPerUnitName, trx.Deleted, trx.Printed, \r\n                             trx.Ticket, trx.Retur, trx.Tanker, trx.MaxCap, trx.Seal, trx.ISCC_Checked, trx.ISCC_GC_Checked, \r\n                             trx.ISCC_No, trx.ISCC_Weight, trx.ChangeReason, trx.Time1, trx.Time2, trx.Time3, trx.Time4, \r\n                             trx.Date4, trx.Date3, trx.Date2, trx.Date1, trx.Transaction_Code, ctr.Nego, tTy.IO, \r\n                             trx.Deduction, ctr.STO, ctr.GR, ctr.SO, ctr.PO, ctr.Group_Type, ctr.Berikat, ctr.Agen, trx.Net_Estate, \r\n                             tDO.Comm_Code, trx.posted, comm.PostSAP, tDO.Estate_qty, tDO.tolling, tDO.tolling_location, trx.TankQC, \r\n                             trx.ISCC_No2, trx.Reason, trx.WBCode1, trx.WBCode2, trx.WBCode3, trx.WBCode4, trx.NOPW, \r\n                             ctr.Quantity, ctr.Franco, comm.Type, trx.TBS_Reject, trx.Received, trx.EstateDiff, ctr.DeductedBy, \r\n                             ctr.Entry_Est, ctr.Entry_Fact, ctr.Estate1_Code AS Estate, ctr.zadp, trx.Create_By, trx.Change_By, trx.Create_Date, \r\n                             trx.Edit_By, trx.Edit_Date, tCo.TPCopra, tCo.JlhColly, ctr.Contract, ctr.Upload_Type, trx.NonContract, \r\n                             trx.Gatepass_Number, trx.Source_Code, ctr.Batch_GI, ctr.Batch_GR, trx.TotalGunny, trx.zAuto, ctr.qstandard, \r\n                             iscc.ISCC_Text, trx.Addi_info, trx.PI_No, trx.materialStuffing, trx.posted_opw, trx.mark_return, comm.Comm_Name, \r\n                             comm.Gross_Weight, rlt.Relation_Name, tpr.Transporter_Name, comm.BulkPack, trx.mark_accident, trx.reposted, \r\n                             source.Description AS SourceDesc, source.Storage_Loc AS SourceDest, trx.Delivery_Date2, trx.Delivery_Time2, trx.FFB_Grade, trx.PL3_No, \r\n                             trx.time_bgate1_open, trx.time_bgate1_close, trx.time_bgate2_open, trx.time_bgate2_close, trx.time_bgate3_open, \r\n                             trx.time_bgate3_close, trx.time_bgate4_open, trx.time_bgate4_close, trx.registrationClose_date, trx.registrationClose_time, \r\n                             trx.registrationClose_by, tDO.Bruto, tDO.Tarra, tDO.Netto, tDO.DO_No, tDO.Relation_Code, tDO.STO1X, tDO.DO1X, \r\n                             tDO.ConvNett, tDO.ConvUnit, tDO.storage_code, tDO.LOADING_QTY, tDO.do_sap, tDO.do_sap_item, tDO.internal_number, \r\n                             tDO.internal_number_item, tDO.Netto AS net, tDO.Bruto AS gross, tDO.Tarra AS tare, tDO.LOADING_QTY_OPW, tDO.Return_Qty_KG, \r\n                             tDO.Return_Qty_Pack, tDO.so_item_detail, tDO.LOADING_DO_QTY, RIGHT('0' + CAST(DATEDIFF(SECOND, trx.time_bgate1_open, trx.time_bgate1_close) \r\n                             / 3600 AS VARCHAR), 2) + ':' + RIGHT('0' + CAST(DATEDIFF(SECOND, trx.time_bgate1_open, trx.time_bgate1_close) / 60 % 60 AS VARCHAR), 2) + ':' + RIGHT('0' + CAST(DATEDIFF(SECOND, \r\n                             trx.time_bgate1_open, trx.time_bgate1_close) % 60 AS VARCHAR), 2) AS interval_1, RIGHT('0' + CAST(DATEDIFF(SECOND, trx.time_bgate2_open, \r\n                             trx.time_bgate2_close) / 3600 AS VARCHAR), 2) + ':' + RIGHT('0' + CAST(DATEDIFF(SECOND, trx.time_bgate2_open, trx.time_bgate2_close) / 60 % 60 AS VARCHAR), 2) \r\n                             + ':' + RIGHT('0' + CAST(DATEDIFF(SECOND, trx.time_bgate2_open, trx.time_bgate2_close) % 60 AS VARCHAR), 2) AS interval_2, RIGHT('0' + CAST(DATEDIFF(SECOND, \r\n                             trx.time_bgate3_open, trx.time_bgate3_close) / 3600 AS VARCHAR), 2) + ':' + RIGHT('0' + CAST(DATEDIFF(SECOND, trx.time_bgate3_open, \r\n                             trx.time_bgate3_close) / 60 % 60 AS VARCHAR), 2) + ':' + RIGHT('0' + CAST(DATEDIFF(SECOND, trx.time_bgate3_open, trx.time_bgate3_close) % 60 AS VARCHAR), 2) \r\n                             AS interval_3, RIGHT('0' + CAST(DATEDIFF(SECOND, trx.time_bgate4_open, trx.time_bgate4_close) / 3600 AS VARCHAR), 2) + ':' + RIGHT('0' + CAST(DATEDIFF(SECOND, \r\n                             trx.time_bgate4_open, trx.time_bgate4_close) / 60 % 60 AS VARCHAR), 2) + ':' + RIGHT('0' + CAST(DATEDIFF(SECOND, trx.time_bgate4_open, \r\n                             trx.time_bgate4_close) % 60 AS VARCHAR), 2) AS interval_4, comm.Unit, ctr.mill, ctr.qOrigin, trx.return_ref, ctr.Plasma, \r\n                             trx.Split, trx.cancel_reason, trx.cancel_type, trx.manual, ctr.Lock_KB, trx.Truck_Trailer_Number as Trailer_Number\r\n                        FROM wb_transaction trx\r\n                            RIGHT JOIN wb_transDO tDO ON trx.Ref = tDO.Ref AND trx.Coy = tDO.Coy AND trx.Location_Code = tDO.Location_Code\r\n                            INNER JOIN wb_contract ctr ON tDO.DO_No = ctr.Do_No AND tDO.Coy = ctr.Coy AND tDO.Location_Code = ctr.Location_Code\r\n                            INNER JOIN wb_transaction_type tTy ON tDO.Coy = tTy.Coy AND tDO.Location_Code = tTy.Location_Code AND tDO.Transaction_Code = tTy.Transaction_Code\r\n                            INNER JOIN wb_commodity comm ON tDO.Comm_Code = comm.Comm_Code AND tDO.Coy = comm.Coy AND tDO.Location_Code = comm.Location_Code\r\n                            LEFT JOIN wb_transCopra tCo ON tDO.Ref = tCo.Ref AND tDO.Coy = tCo.Coy AND tDO.Location_Code = tCo.Location_Code\r\n                            LEFT JOIN wb_iscc iscc ON ctr.qstandard = iscc.ISCC_Code\r\n                            LEFT JOIN wb_relation rlt ON tDO.Relation_Code = rlt.Relation_Code AND tDO.Coy = rlt.Coy AND tDO.Location_Code = rlt.Location_Code\r\n                            LEFT JOIN wb_transporter tpr ON trx.Transporter_Code = tpr.Transporter_Code AND trx.Coy = tpr.Coy AND trx.Location_Code = tpr.Location_Code\r\n                            LEFT JOIN wb_source source ON trx.Coy = source.Coy AND trx.Location_Code = source.Location_Code AND trx.Source_Code = source.Source_Code\r\n                        where tDO.coy = '", WBData.sCoyCode, "' and tDO.location_code = '", WBData.sLocCode, "' " };
                string sqltext = string.Concat(textArray1);
                string str2 = "";
                string str3 = "";
                string[] textArray2 = new string[] { "SELECT gp.coy as Coy, gp.location_code as Location_Code, ctrt.transaction_code as transaction_code, trxtp.IO as IO, gp.Gatepass_Number as Gatepass_Number, \r\n\t                        gp.WX as WX, ctrt.Berikat as Berikat, Delivery_Date, trdo.do_no as DO_No, trdo.Transporter_Code as Transporter_code,\r\n\t                        trdo.do_sap as do_sap, gp.create_date as Create_Date, gp.deleted as Deleted, trdo.storage_code as storage_code,\r\n\t                        ctrt.Contract as Contract,  gp.Truck_Number as Truck_Number, gp.License_No as License_No, trdo.relation_code as Relation_code,\r\n\t                        ctrt.qstandard as qstandard, ctrt.mill as mill, ctrt.qOrigin as qOrigin, gp.Remark_Ticket as Remark_Ticket, gp.Remark_Report as Remark_Report,\r\n                            trdo.estate as Estate,trdo.comm_code as Comm_Code, comm.Comm_Name as Comm_Name, trdo.Internal_Number as Internal_Number, ctrt.PO as PO, ctrt.STO as STO,\r\n                            ctrt.PI_No as PI_No, trdo.STO1X as STO1X, trdo.DO1X as DO1X, gp.Delivery_Note as Delivery_Note, trpt.Transporter_Name as Transporter_Name, drv.Name,\r\n                            gp.Addi_info as Addi_info, trdo.Estate_qty as Estate_qty, gp.Gross_Estate as Gross_Estate, gp.Tare_Estate as Tare_Estate, gp.Net_Estate as Net_Estate,\r\n                            gp.Delivery_Time as Delivery_Time, gp.Trailer_Number as Trailer_Number\r\n                        FROM wb_gatepass gp WITH (NOLOCK)\r\n                        RIGHT OUTER JOIN wb_transdo trdo WITH (NOLOCK)\r\n\t                        ON trdo.gatepass_number = gp.gatepass_number\r\n                        INNER JOIN wb_contract ctrt WITH (NOLOCK)\r\n\t                        ON ctrt.coy = trdo.coy AND ctrt.location_code = trdo.Location_Code AND ctrt.Do_no = trdo.do_no\r\n                        INNER JOIN wb_commodity comm WITH (NOLOCK)\r\n\t                        ON trdo.coy = comm.coy AND trdo.location_code = comm.Location_Code AND trdo.comm_code = comm.comm_code\r\n                        INNER JOIN wb_transaction_type trxtp WITH (NOLOCK)\r\n\t                        ON trxtp.coy = ctrt.coy AND trxtp.location_code = ctrt.Location_Code AND trxtp.Transaction_Code = ctrt.Transaction_Code\r\n                        LEFT OUTER JOIN wb_iscc iscc WITH (NOLOCK)\r\n\t                        ON iscc.iscc_code = ctrt.qstandard\r\n                        INNER JOIN wb_relation rel WITH (NOLOCK)\r\n\t                        ON rel.Coy = trdo.coy AND rel.Location_Code = trdo.Location_Code AND rel.Relation_Code = trdo.Relation_Code\r\n                        INNER JOIN wb_transporter trpt WITH (NOLOCK)\r\n\t                        ON trpt.Coy = gp.coy AND trpt.Location_Code = gp.Location_Code AND trpt.Transporter_Code = gp.Transporter_Code \r\n                        INNER JOIN wb_driver drv WITH (NOLOCK)\r\n\t                        ON drv.Coy = gp.coy AND drv.Location_Code = gp.Location_Code AND drv.License_No = gp.License_No \r\n                        where (gp.ref is null or gp.ref = '') and gp.coy = '", WBData.sCoyCode, "' and gp.location_code = '", WBData.sLocCode, "' " };
                string str4 = string.Concat(textArray2);
                if (this.txt_ref.Text.Trim() != "")
                {
                    str2 = str2 + " and Ref ='" + this.txt_ref.Text.Trim() + "'";
                    str3 ??= "";
                }
                if (this.checkDate.Checked)
                {
                    str2 = (str2 + " and ((report_Date>='" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00'") + " and report_Date<='" + this.monthCalendar2.Value.ToString("yyyy-MM-dd") + " 00:00:00')";
                    string str11 = this.monthCalendar2.Value.AddDays(1.0).ToString("yyyy-MM-dd");
                    str3 = (str3 + " and ((gp.create_date>='" + this.monthCalendar1.Value.ToString("yyyy-MM-dd") + " 00:00:00'") + " and gp.create_date<='" + str11 + " 00:00:00')";
                }
                if (this.checkProcess.Checked)
                {
                    str2 = str2 + " or ((WX = '4X' and _4th = 0 and report_date is null) or (WX = '2X' and _2nd = 0 and report_date is null))) ";
                    str3 = str3 + ") ";
                }
                else if (this.checkDate.Checked)
                {
                    str2 = str2 + ") ";
                    str3 = str3 + ") ";
                }
                if (this.rboGR.Checked)
                {
                    str2 = str2 + " and IO = 'I'";
                    str3 = str3 + " and IO = 'I'";
                }
                else if (this.rboGI.Checked)
                {
                    str2 = str2 + " and IO = 'O'";
                    str3 = str3 + " and IO = 'O'";
                }
                if (this.textCommodity.Text.Trim() != "")
                {
                    str2 = str2 + " and (tDO.Comm_Code='" + this.textCommodity.Text.Trim() + "'";
                    str3 = str3 + " and (trdo.Comm_Code='" + this.textCommodity.Text.Trim() + "'";
                    int num88 = 1;
                    while (true)
                    {
                        if (num88 >= this.comboComm.Items.Count)
                        {
                            str2 = str2 + ") ";
                            str3 = str3 + ") ";
                            break;
                        }
                        str2 = str2 + " or tDO.comm_code = '" + this.comboComm.Items[num88].ToString() + "' ";
                        str3 = str3 + " or trdo.comm_code = '" + this.comboComm.Items[num88].ToString() + "' ";
                        num89 = num88;
                        num88 = num89 + 1;
                    }
                }
                if (this.rboKB.Checked)
                {
                    str2 = str2 + " and berikat='Y' ";
                    str3 = str3 + " and berikat='Y' ";
                }
                else if (this.rboNonKB.Checked)
                {
                    str2 = str2 + " and berikat='N' ";
                    str3 = str3 + " and berikat='N' ";
                }
                if (this.textTransport.Text.Trim() != "")
                {
                    str2 = str2 + " and trx.Transporter_Code='" + this.textTransport.Text.Trim() + "'";
                    str3 = str3 + " and gp.Transporter_Code='" + this.textTransport.Text.Trim() + "'";
                }
                if (this.textDoNo.Text.Trim() != "")
                {
                    str2 = str2 + " and tDO.Do_No='" + this.textDoNo.Text.Trim() + "'";
                    str3 = str3 + " and trdo.Do_No='" + this.textDoNo.Text.Trim() + "'";
                }
                if (this.txt_contract.Text.Trim() != "")
                {
                    str2 = str2 + " and ctr.contract='" + this.txt_contract.Text.Trim() + "'";
                    str3 = str3 + " and trdo.contract='" + this.txt_contract.Text.Trim() + "'";
                }
                if (this.textTank.Text.Trim() != "")
                {
                    str2 = str2 + " and trx.TankQC ='" + this.textTank.Text.Trim() + "'";
                    str3 ??= "";
                }
                if (this.textTruck.Text.Trim() != "")
                {
                    str2 = str2 + " and trx.Truck_NUmber ='" + this.textTruck.Text.Trim() + "'";
                    str3 = str3 + " and gp.Truck_NUmber ='" + this.textTruck.Text.Trim() + "'";
                }
                if (this.textDriver.Text.Trim() != "")
                {
                    str2 = str2 + " and trx.license_no ='" + this.textDriver.Text.Trim() + "'";
                    str3 = str3 + " and gp.license_no ='" + this.textDriver.Text.Trim() + "'";
                }
                if (this.chkQstandard.Checked && this.chkNonQ.Checked)
                {
                    str2 = str2 + " and (qstandard = '" + this.txtqstandard.Text + "' ";
                    str3 = str3 + " and (qstandard = '" + this.txtqstandard.Text + "' ";
                    int num90 = 1;
                    while (true)
                    {
                        if (num90 >= this.ComboIscc.Items.Count)
                        {
                            str2 = str2 + " or qstandard = '' or qstandard is null) ";
                            str3 = str3 + " or qstandard = '' or qstandard is null) ";
                            break;
                        }
                        str2 = str2 + " or qstandard = '" + this.ComboIscc.Items[num90].ToString() + "' ";
                        str3 = str3 + " or qstandard = '" + this.ComboIscc.Items[num90].ToString() + "' ";
                        num89 = num90;
                        num90 = num89 + 1;
                    }
                }
                else if (this.chkQstandard.Checked || this.chkNonQ.Checked)
                {
                    if (!this.chkQstandard.Checked)
                    {
                        if (this.chkNonQ.Checked)
                        {
                            str2 = str2 + " and (qstandard = '' or qstandard is null) ";
                            str3 = str3 + " and (qstandard = '' or qstandard is null) ";
                        }
                    }
                    else
                    {
                        str2 = str2 + " and (qstandard = '" + this.txtqstandard.Text + "' ";
                        str3 = str3 + " and (qstandard = '" + this.txtqstandard.Text + "' ";
                        int num91 = 1;
                        while (true)
                        {
                            if (num91 >= this.ComboIscc.Items.Count)
                            {
                                str2 = str2 + ") ";
                                str3 = str3 + ") ";
                                break;
                            }
                            str2 = str2 + " or qstandard = '" + this.ComboIscc.Items[num91].ToString() + "' ";
                            str3 = str3 + " or qstandard = '" + this.ComboIscc.Items[num91].ToString() + "' ";
                            num89 = num91;
                            num91 = num89 + 1;
                        }
                    }
                }
                if (this.checkStorage.Checked && (this.textStorage.Text.Trim() != ""))
                {
                    str2 = str2 + " and storage_code = '" + this.textStorage.Text.Trim() + "'";
                    str3 = str3 + " and storage_code = '" + this.textStorage.Text.Trim() + "'";
                }
                if (this.txt_mill.Text.Trim() != "")
                {
                    str2 = str2 + " and (mill = '" + this.txt_mill.Text.Trim() + "') ";
                    str3 = str3 + " and (mill = '" + this.txt_mill.Text.Trim() + "') ";
                }
                if (!this.checkAutomated.Checked)
                {
                    str2 = str2 + " and (trx.zauto = 'N' or trx.zauto is null)";
                    str3 = str3 + " and (zauto = 'N' or zauto is null)";
                }
                if (this.rb_comm.Checked)
                {
                    str2 = str2 + " and (trx.deleted is null or trx.deleted = 'N') Order By Comm_Code,Ref Asc";
                    str3 = str3 + " and (gp.deleted is null or gp.deleted = 'N') Order By Comm_Code,Gatepass_Number Asc";
                }
                else if (this.rb_mill.Checked)
                {
                    str2 = str2 + " and (trx.deleted is null or trx.deleted = 'N') Order By mill, relation_code, comm_code, Ref Asc";
                    str3 = str3 + " and (gp.deleted is null or gp.deleted = 'N') Order By mill, relation_code, comm_code, Gatepass_Number Asc";
                }
                else if (this.rb_iscc.Checked)
                {
                    str2 = str2 + " AND (trx.deleted is null or trx.deleted = 'N') ORDER BY qOrigin, relation_code, Ref Asc";
                    str3 = str3 + " AND (gp.deleted is null or gp.deleted = 'N') ORDER BY qOrigin, relation_code, Gatepass_Number Asc";
                }
                else
                {
                    str2 = str2 + " and (trx.deleted is null or trx.deleted = 'N') Order By Ref Asc";
                    str3 = str3 + " and (gp.deleted is null or gp.deleted = 'N') Order By Gatepass_Number Asc";
                }
                sqltext = sqltext + str2;
                str4 = str4 + str3;
                table2.OpenTable("view", sqltext, WBData.conn);
                if (this.checkNot1stYet.Checked)
                {
                    table3.OpenTable("view2", str4, WBData.conn);
                    if (table3.DT.Rows.Count == 0)
                    {
                        MessageBox.Show("No Truck not 1st Weighed Yet.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        table2.DT.Merge(table3.DT);
                        table2.DT = new DataView(table2.DT) { Sort = "Gatepass_Number" }.ToTable();
                    }
                }
                if (table2.DT.Rows.Count > 0)
                {
                    HTML html = new HTML();
                    HTML html2 = html;
                    html2.File = html2.File + @"\" + WBUser.UserID + "_ListofWeighing.htm";
                    html.Title = "List of Weighing";
                    html.Open();
                    html.Write(html.Style());
                    if (this.rboGR.Checked)
                    {
                        html.Write("<br><font size=5><b>WEIGHING LIST OF GOODS RECEIVE</b></font><br>");
                    }
                    else if (this.rboGI.Checked)
                    {
                        html.Write("<br><font size=5><b>WEIGHING LIST OF GOODS ISSUE</b></font><br>");
                    }
                    else
                    {
                        html.Write("<br><font size=5><b>WEIGHING LIST OF GOODS RECEIVE & GOODS ISSUE</b></font><br>");
                    }
                    string[] textArray3 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                    html.Write(string.Concat(textArray3));
                    string[] textArray4 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                    html.Write(string.Concat(textArray4));
                    if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                    {
                        html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                    }
                    if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                    {
                        html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                    }
                    if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                    {
                        html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                    }
                    html.Write("<br><br>");
                    html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                    if (this.textCommodity.Text.Trim() != "")
                    {
                        html.Write("<tr class=bd>");
                        html.Write("<td>Commodity</td>");
                        string[] textArray5 = new string[] { "<td>: <b>", this.textCommodity.Text, " - ", this.labelCommName.Text, "</b></td>" };
                        html.Write(string.Concat(textArray5));
                        html.Write("</tr>");
                    }
                    if (this.textDoNo.Text.Trim() != "")
                    {
                        if (this.rboGR.Checked)
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>DO No</td>");
                            html.Write("<td>: <b>" + this.textDoNo.Text + "</b></td>");
                            html.Write("</tr>");
                        }
                        else if (this.rboGI.Checked)
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>SO No</td>");
                            html.Write("<td>: <b>" + this.textDoNo.Text + "</b></td>");
                            html.Write("</tr>");
                        }
                        else
                        {
                            html.Write("<tr class=bd>");
                            html.Write("<td>DO/SO No</td>");
                            html.Write("<td>: <b>" + this.textDoNo.Text + "</b></td>");
                            html.Write("</tr>");
                        }
                    }
                    if (this.textTransport.Text.Trim() != "")
                    {
                        html.Write("<tr class=bd>");
                        html.Write("<td>Transporter</td>");
                        html.Write("<td>: <b>" + this.textTransport.Text + "</b></td>");
                        html.Write("</tr>");
                    }
                    if (this.textTruck.Text.Trim() != "")
                    {
                        html.Write("<tr class=bd>");
                        html.Write("<td>Truck No</td>");
                        html.Write("<td>: <b>" + this.textTruck.Text + "</b></td>");
                        html.Write("</tr>");
                    }
                    if (this.textTank.Text.Trim() != "")
                    {
                        html.Write("<tr class=bd>");
                        html.Write("<td>Tanker No</td>");
                        html.Write("<td>: <b>" + this.textTank.Text + "</b></td>");
                        html.Write("</tr>");
                    }
                    if (this.rb_iscc.Checked)
                    {
                        html.Write("<tr class=bd>");
                        html.Write("<td>Quality Standard</td>");
                        string[] textArray6 = new string[] { "<td>: <b>", this.txtqstandard.Text, " (", this.labelQStandard.Text, ")</b></td>" };
                        html.Write(string.Concat(textArray6));
                    }
                    if (this.checkDate.Checked)
                    {
                        html.Write("<tr class=bd>");
                        html.Write("<td>Selected Date</td>");
                        string[] textArray7 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                        html.Write(string.Concat(textArray7));
                        html.Write("</tr>");
                    }
                    html.Write("<tr class=bd>");
                    html.Write("<td>Report Date</td>");
                    html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                    html.Write("</tr>");
                    html.Write("</table>");
                    html.Write("<br/><br/>");
                    html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                    html.Write("<tr class='bd'>");
                    html.Write("<td nowrap rowspan=2>No.</td>");
                    html.Write("<td nowrap rowspan=2>TX</td>");
                    if (this.checkNot1stYet.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Gatepass_001 + "</td>");
                        num2++;
                    }
                    html.Write("<td nowrap rowspan=2>" + Resource.Trans_005 + "</td>");
                    if (this.checkBoxGatepassNumber.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Gatepass_001 + "</td>");
                        num2++;
                    }
                    if (this.rboGI.Checked)
                    {
                        html.Write("<td rowspan='2' align=center>" + Resource.Main_036 + " </td>");
                    }
                    else if (this.rboGR.Checked)
                    {
                        html.Write("<td rowspan='2' align=center>" + Resource.Main_036a + " </td>");
                    }
                    else
                    {
                        html.Write("<td rowspan='2' align=center>" + Resource.Main_035 + " </td>");
                    }
                    num2++;
                    if (this.checkDelivery.Checked)
                    {
                        if (this.rboGI.Checked)
                        {
                            html.Write("<td rowspan=2 align=center>" + Resource.Main_108 + "</td>");
                            html.Write("<td rowspan=2 align=center>" + Resource.Main_108c + "</td>");
                        }
                        else if (this.rboGR.Checked)
                        {
                            html.Write("<td rowspan=2 align=center>" + Resource.Main_108a + "</td>");
                            html.Write("<td rowspan=2 align=center>" + Resource.Main_108b + "</td>");
                        }
                        else
                        {
                            html.Write("<td rowspan=2 align=center>" + Resource.Main_036 + "</td>");
                            html.Write("<td rowspan=2 align=center>" + Resource.Main_037 + "</td>");
                        }
                        num2 += 2;
                    }
                    if (this.cBoxDiffHour.Checked)
                    {
                        html.Write("<td align=center colspan = 5>Weighing In & Out</td>");
                    }
                    else
                    {
                        html.Write("<td align=center colspan = 4>Weighing In & Out</td>");
                    }
                    if (this.cBoxDiffHour.Checked)
                    {
                        num2++;
                    }
                    if (this.checkRegistrationInOut.Checked)
                    {
                        html.Write("<td align=center colspan = 4>Registration In & Out</td>");
                        num2 += 4;
                    }
                    if (this.cb_interval12.Checked)
                    {
                        html.Write("<td align=center colspan = 3>Barrier Gate 1st Weight</td>");
                        html.Write("<td align=center colspan = 3>Barrier Gate 2nd Weight</td>");
                        num2 += 6;
                    }
                    if (this.cb_interval34.Checked)
                    {
                        html.Write("<td align=center colspan = 3>Barrier Gate 3rd Weight</td>");
                        html.Write("<td align=center colspan = 3>Barrier Gate 4th Weight</td>");
                        num2 += 6;
                    }
                    if (this.checkDO_No.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Contract_002 + "</td>");
                        num2++;
                    }
                    if (this.cb_do_sap.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>DO SAP No.</td>");
                        num2++;
                    }
                    if (this.cb_internal_no.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>Internal No.</td>");
                        num2++;
                    }
                    if (this.checkQSt.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>Q.Standard</td>");
                        num2++;
                    }
                    if (this.checkContract.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Contract_010 + "</td>");
                        num2++;
                    }
                    if (this.cBoxPISI.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>PI/SI No.</td>");
                        num2++;
                    }
                    if (this.checkSTO.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>STO</td>");
                        num2++;
                    }
                    if (this.checkPO.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>PO</td>");
                        num2++;
                    }
                    if (this.checkSO.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>SO</td>");
                        num2++;
                    }
                    if (this.check1xSTO.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>1xSTO</td>");
                        num2++;
                    }
                    if (this.check1xDO.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>1xDO</td>");
                        num2++;
                    }
                    html.Write("<td nowrap rowspan=2>" + Resource.Trans_027 + "</td>");
                    num2++;
                    if (this.cBoxCommName.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.CommE_003 + "</td>");
                        num2++;
                    }
                    if (this.checkStorage.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Load_003 + "</td>");
                        num2++;
                    }
                    if (this.checkDeliNote.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.DoE_009 + "</td>");
                        num2++;
                    }
                    if (this.checkRelation.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Composite_002 + "</td>");
                        num2++;
                    }
                    if (this.checkRelationName.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Rep01_027 + "</td>");
                        num2++;
                    }
                    if (this.checkEstate.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Block_001 + "</td>");
                        num2++;
                    }
                    if (this.checkLicenseNo.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.DriverE_001 + "</td>");
                        num2++;
                    }
                    if (this.checkDriverName.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.DriverE_002 + "</td>");
                        num2++;
                    }
                    html.Write("<td nowrap rowspan=2>" + Resource.DriverE_003 + "</td>");
                    num2++;
                    if (this.cBoxYellowPlate.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>Yellow Plate</td>");
                        num2++;
                    }
                    if (this.checkTrailerNo.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.TruckE_003 + "</td>");
                        num2++;
                    }
                    if (this.checkTransporter.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Menu_025 + "</td>");
                        num2++;
                    }
                    if (this.cBoxTransName.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Transporter_002 + "</td>");
                        num2++;
                    }
                    if (this.checkBoxTank.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Main_082 + "</td>");
                        num2++;
                    }
                    if (this.cbAddInfo.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>ADDITIONAL INFO</td>");
                        num2++;
                    }
                    if (this.cb_tank.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>TANK</td>");
                        num2++;
                    }
                    if (this.checkSourceCode.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Trans_059 + "</td>");
                        num2++;
                    }
                    if (this.checkSourceDesc.Checked)
                    {
                        string[] textArray8 = new string[] { "<td nowrap rowspan=2>", Resource.Trans_059, " ", Resource.Source_002, "</td>" };
                        html.Write(string.Concat(textArray8));
                        num2++;
                    }
                    num3 = num2;
                    if (this.checkColly.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Report02_008 + "</td>");
                        num3++;
                    }
                    if (this.cbGunny.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>GUNNY (" + Resource.ContractE_038 + ")</td>");
                        num3++;
                    }
                    if (this.checkConv.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>Qty.Unit</td>");
                        html.Write("<td nowrap rowspan=2>UOM</td>");
                        num3 += 2;
                    }
                    if (this.check3rdParty.Checked)
                    {
                        string[] textArray9 = new string[] { "<td nowrap rowspan=2>", Resource.Main_019, " (", Resource.ContractE_037, ")</td>" };
                        html.Write(string.Concat(textArray9));
                        string[] textArray10 = new string[] { "<td nowrap rowspan=2>", Resource.Main_020, "  (", Resource.ContractE_037, ")</td>" };
                        html.Write(string.Concat(textArray10));
                        html.Write("<td nowrap rowspan=2>NETT  (" + Resource.ContractE_037 + ")</td>");
                        num3 += 3;
                    }
                    if (this.checkBrutoTarra.Checked)
                    {
                        string[] textArray11 = new string[] { "<td nowrap rowspan=2>", Resource.Main_019, " (", Resource.ContractE_038, ")</td>" };
                        html.Write(string.Concat(textArray11));
                        string[] textArray12 = new string[] { "<td nowrap rowspan=2>", Resource.Main_020, "  (", Resource.ContractE_038, ")</td>" };
                        html.Write(string.Concat(textArray12));
                        num3 += 2;
                    }
                    if (this.cbDeduction.Checked)
                    {
                        string[] textArray13 = new string[] { "<td nowrap rowspan=2>", Resource.Main_021, " (", Resource.ContractE_038, ")</td>" };
                        html.Write(string.Concat(textArray13));
                        string[] textArray14 = new string[] { "<td nowrap rowspan=2>", Resource.Main_022, " (", Resource.ContractE_038, ")</td>" };
                        html.Write(string.Concat(textArray14));
                        num3 += 2;
                    }
                    html.Write("<td nowrap rowspan=2>NETT  (" + Resource.ContractE_038 + ")</td>");
                    num3++;
                    if (this.checkDiff.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>DIFF</td>");
                        html.Write("<td nowrap rowspan=2>DIFF %</td>");
                        num3 += 2;
                    }
                    if (this.checkLoadingQty.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>Loading Qty</td>");
                        html.Write("<td nowrap rowspan=2>Loading Qty OPW</td>");
                        html.Write("<td nowrap rowspan=2>UOM</td>");
                        html.Write("<td nowrap rowspan=2>Loading Net(KG)</td>");
                        num3 += 3;
                    }
                    if (this.checkBoxMaterialStuffing.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>Material Stuffing</td>");
                        num3++;
                    }
                    if (this.cBoxReturInKg.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>Return (Kg)</td>");
                        num3++;
                    }
                    if (this.cBoxReturInPack.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>Return (Pack)</td>");
                        num3++;
                    }
                    if (this.cBoxLossInKg.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>Loss(-)/Gain(+) (Kg)</td>");
                        num3++;
                    }
                    if (this.cBoxLossInPack.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>Loss(-)/Gain(+) (Pack)</td>");
                        num3++;
                    }
                    if (this.checkSeal.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Rep01_038 + "</td>");
                        num3++;
                    }
                    if (this.checkWBRef.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>WB Ref.</td>");
                        num3++;
                    }
                    if (this.cbDL.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Rep01_041 + "</td>");
                        html.Write("<td nowrap rowspan=2>" + Resource.TruckE_024 + "</td>");
                        html.Write("<td nowrap rowspan=2>" + Resource.CommE_021 + "</td>");
                        html.Write("<td nowrap rowspan=2>STO No</td>");
                        html.Write("<td nowrap rowspan=2>Batch STO</td>");
                        html.Write("<td nowrap rowspan=2>Gunny</td>");
                        html.Write("<td nowrap rowspan=2>" + Resource.Contract_008 + "</td>");
                    }
                    if (this.checkRmkTicket.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Rep01_036 + "</td>");
                        num4++;
                    }
                    if (this.checkRmkReport.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>" + Resource.Rep01_037 + "</td>");
                        num4++;
                    }
                    if (this.checkCrtBy.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>Create By</td>");
                        num4++;
                    }
                    if (this.checkChgBy.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>Change By</td>");
                        num4++;
                    }
                    if (this.cBoxWBCode.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>WB Code 1st</td>");
                        html.Write("<td nowrap rowspan=2>WB Code 2nd</td>");
                        num4 = (num4 + 1) + 1;
                        if (WBSetting.Container == "Y")
                        {
                            html.Write("<td nowrap rowspan=2>WB Code 3rd</td>");
                            html.Write("<td nowrap rowspan=2>WB Code 4th</td>");
                            num4 = (num4 + 1) + 1;
                        }
                    }
                    if (this.checkGrade.Checked)
                    {
                        html.Write("<td nowrap rowspan=2>FFB Grade</td>");
                        num4++;
                    }
                    html.Write("</tr>");
                    html.Write("<tr class='bd'>");
                    html.Write("<td nowrap rowspan=1>" + Resource.Main_057 + "</td>");
                    html.Write("<td nowrap rowspan=1>" + Resource.Main_014 + "</td>");
                    html.Write("<td nowrap rowspan=1>" + Resource.Main_059 + "</td>");
                    html.Write("<td nowrap rowspan=1>" + Resource.Main_015 + "</td>");
                    if (this.cBoxDiffHour.Checked)
                    {
                        html.Write("<td rowspan=1 align=center>Dif.Hour</td>");
                    }
                    if (this.checkRegistrationInOut.Checked)
                    {
                        html.Write("<td nowrap align=center>Date Time In</td>");
                        html.Write("<td nowrap align=center>Registered By</td>");
                        html.Write("<td nowrap align=center>Date Time Out</td>");
                        html.Write("<td nowrap align=center>Checked Out By</td>");
                    }
                    if (this.cb_interval12.Checked)
                    {
                        html.Write("<td nowrap align=center>Time In</td>");
                        html.Write("<td nowrap align=center>Time Out</td>");
                        html.Write("<td nowrap align=center>Interval</td>");
                        html.Write("<td nowrap align=center>Time In</td>");
                        html.Write("<td nowrap align=center>Time Out</td>");
                        html.Write("<td nowrap align=center>Interval</td>");
                    }
                    if (this.cb_interval34.Checked)
                    {
                        html.Write("<td nowrap align=center>Time In</td>");
                        html.Write("<td nowrap align=center>Time Out</td>");
                        html.Write("<td nowrap align=center>Interval</td>");
                        html.Write("<td nowrap align=center>Time In</td>");
                        html.Write("<td nowrap align=center>Time Out</td>");
                        html.Write("<td nowrap align=center>Interval</td>");
                    }
                    html.Write("</tr>");
                    if (this.rb_mill.Checked)
                    {
                        html.Write("<tr>");
                        string str12 = "";
                        str12 = (table2.DT.Rows[0]["mill"].ToString() != "") ? html.strq(table2.DT.Rows[0]["mill"].ToString() + " (" + table2.DT.Rows[0]["comm_name"].ToString() + ")") : html.strq(table2.DT.Rows[0]["relation_name"].ToString() + " (" + table2.DT.Rows[0]["comm_name"].ToString() + ")");
                        string[] textArray15 = new string[5];
                        textArray15[0] = "<td colspan=";
                        num89 = ((num2 + num3) + num4) + 7;
                        textArray15[1] = num89.ToString();
                        textArray15[2] = "><b>";
                        textArray15[3] = str12;
                        textArray15[4] = "</b></td>";
                        html.Write(string.Concat(textArray15));
                        html.Write("</tr>");
                    }
                    else if (this.rb_iscc.Checked)
                    {
                        html.Write("<tr>");
                        string str13 = html.strq("Area: " + table2.DT.Rows[0]["qOrigin"].ToString());
                        string[] textArray16 = new string[] { "<td colspan=", (((num2 + num3) + num4) + 7).ToString(), "><b>", str13, "</b></td>" };
                        html.Write(string.Concat(textArray16));
                        html.Write("</tr>");
                        html.Write("<tr>");
                        string[] textArray17 = new string[] { "Vendor: ", table2.DT.Rows[0]["relation_code"].ToString(), " (", table2.DT.Rows[0]["relation_name"].ToString(), ")" };
                        str13 = html.strq(string.Concat(textArray17));
                        string[] textArray18 = new string[] { "<td colspan=", (((num2 + num3) + num4) + 7).ToString(), "><b>", str13, "</b></td>" };
                        html.Write(string.Concat(textArray18));
                        html.Write("</tr>");
                    }
                    double num5 = 0.0;
                    double num6 = 0.0;
                    double num7 = 0.0;
                    double num8 = 0.0;
                    double num9 = 0.0;
                    double num10 = 0.0;
                    double num11 = 0.0;
                    double num12 = 0.0;
                    double num13 = 0.0;
                    double num14 = 0.0;
                    double num15 = 0.0;
                    double num16 = 0.0;
                    double num17 = 0.0;
                    double num18 = 0.0;
                    double num19 = 0.0;
                    double num20 = 0.0;
                    double num21 = 0.0;
                    double num22 = 0.0;
                    double num23 = 0.0;
                    double num24 = 0.0;
                    double num25 = 0.0;
                    double num26 = 0.0;
                    double num27 = 0.0;
                    double num28 = 0.0;
                    float num29 = 0f;
                    string pStr = "";
                    double num30 = 0.0;
                    double num31 = 0.0;
                    double num32 = 0.0;
                    double num33 = 0.0;
                    double num34 = 0.0;
                    double num35 = 0.0;
                    double num36 = 0.0;
                    double num37 = 0.0;
                    double num38 = 0.0;
                    double num39 = 0.0;
                    double num40 = 0.0;
                    double num41 = 0.0;
                    double num42 = 0.0;
                    double num43 = 0.0;
                    double num44 = 0.0;
                    double num47 = 0.0;
                    double num50 = 0.0;
                    double num51 = 0.0;
                    double num52 = 0.0;
                    double num53 = 0.0;
                    double num54 = 0.0;
                    double num55 = 0.0;
                    double num56 = 0.0;
                    double num57 = 0.0;
                    double num58 = 0.0;
                    double num59 = 0.0;
                    double num60 = 0.0;
                    double num62 = 0.0;
                    double num63 = 0.0;
                    double num64 = 0.0;
                    double num65 = 0.0;
                    double num66 = 0.0;
                    double num67 = 0.0;
                    double num68 = 0.0;
                    int num69 = 0;
                    int num70 = 1;
                    string str6 = "";
                    string str7 = "";
                    string zValue = "";
                    string str9 = "";
                    string str10 = "";
                    this.labelProses1.Text = "";
                    this.labelProses2.Text = "";
                    this.labelProses1.Visible = true;
                    this.labelProses2.Visible = true;
                    double num71 = 0.0;
                    double num72 = 0.0;
                    double num73 = 0.0;
                    double num74 = 0.0;
                    double num75 = 0.0;
                    double num76 = 0.0;
                    double num77 = 0.0;
                    double num78 = 0.0;
                    double num79 = 0.0;
                    double num80 = 0.0;
                    double num81 = 0.0;
                    double num82 = 0.0;
                    double num83 = 0.0;
                    double num84 = 0.0;
                    double num85 = 0.0;
                    double num86 = 0.0;
                    int count = table2.DT.Rows.Count;
                    using (IEnumerator enumerator = table2.DT.Rows.GetEnumerator())
                    {
                        DataRow current;
                        goto TR_02FA;
                    TR_02F0:
                        num44 = 0.0;
                        this.labelProses1.Text = num69.ToString() + "/" + count;
                        this.labelProses1.Refresh();
                        this.labelProses2.Text = current["Comm_Code"].ToString() + " - " + (string.IsNullOrEmpty(current["Ref"].ToString()) ? current["Gatepass_Number"].ToString() : current["Ref"].ToString());
                        this.labelProses2.Refresh();
                        if (this.rb_comm.Checked)
                        {
                            double num92;
                            if ((str6 != "") && (str6 != current["Comm_Code"].ToString()))
                            {
                                html.Write("<tr class='bd'>");
                                html.Write("<td>" + html.strq("") + "</td>");
                                string[] textArray19 = new string[] { "<td colspan=", num2.ToString(), "><b>Sub Total of ", str6, "</td>" };
                                html.Write(string.Concat(textArray19));
                                num52 = Program.StrToDouble($"{num52:N0}", 0);
                                if (this.checkColly.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num62:N0}" + "</td>");
                                }
                                if (this.cbGunny.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num60:N0}" + "</td>");
                                }
                                if (this.checkConv.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + html.strq(current["ConvUnit"].ToString()) + "</td>");
                                    html.Write("<td nowrap align=right><b>&nbsp</td>");
                                }
                                if (this.check3rdParty.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num13:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num14:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num15:N0}" + "</td>");
                                }
                                if (this.checkBrutoTarra.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num16:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num17:N0}" + "</td>");
                                }
                                if (this.cbDeduction.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{(num16 - num17):N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num56:N0}" + "</td>");
                                }
                                html.Write("<td nowrap align=right><b>" + $"{num18:N0}" + "</td>");
                                if (this.checkDiff.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num19:N0}" + "</td>");
                                    if (!(num19 == 0.0))
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{((num19 / num15) * 100.0):N2}" + "</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td nowrap align=right><b>0.00</td>");
                                    }
                                }
                                if (this.checkLoadingQty.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num33:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num34:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + html.strq(pStr) + "</td>");
                                    html.Write("<td nowrap align=right><b>" + html.strq($"{num35:N0}") + "</td>");
                                }
                                if (this.checkBoxMaterialStuffing.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.cBoxReturInKg.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num75 + "</td>");
                                }
                                if (this.cBoxReturInPack.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num76 + "</td>");
                                }
                                if (this.cBoxLossInKg.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num77 + "</td>");
                                }
                                if (this.cBoxLossInPack.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num78 + "</td>");
                                }
                                if (this.checkSeal.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.checkWBRef.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.cbDL.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    if (num63 > 0.0)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num63:N0}" + "</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (num64 > 0.0)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num64:N0}" + "</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                }
                                if (this.checkRmkTicket.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.checkRmkReport.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                html.Write("</tr>");
                                html.Write("<td colspan=" + (((num2 + num3) + num4) + 7).ToString() + ">&nbsp</td>");
                                html.Write("</tr>");
                                num13 = 0.0;
                                num14 = 0.0;
                                num15 = 0.0;
                                num16 = 0.0;
                                num62 = 0.0;
                                num17 = 0.0;
                                num18 = 0.0;
                                num19 = 0.0;
                                num75 = 0.0;
                                num76 = 0.0;
                                num77 = 0.0;
                                num78 = 0.0;
                                num33 = 0.0;
                                num34 = 0.0;
                                num35 = 0.0;
                                num55 = 0.0;
                                num60 = 0.0;
                                num56 = 0.0;
                                num63 = 0.0;
                                num64 = 0.0;
                                num71 = 0.0;
                                num72 = 0.0;
                                num73 = 0.0;
                                num74 = 0.0;
                                num20 = 0.0;
                                str6 = current["Comm_Code"].ToString();
                                string[] textArray20 = new string[] { "comm_code" };
                                string[] textArray21 = new string[] { str6 };
                                this.DRComm = this.tbl_Comm.GetData(textArray20, textArray21);
                                if (this.DRComm != null)
                                {
                                    num92 = Program.StrToDouble(this.DRComm["netto_Weight"].ToString(), 0);
                                    num29 = float.Parse(num92.ToString());
                                    pStr = this.DRComm["unit"].ToString().Trim().ToUpper();
                                }
                                num70 = 1;
                            }
                            if (str6 == "")
                            {
                                str6 = current["Comm_Code"].ToString();
                                string[] textArray22 = new string[] { "comm_code" };
                                string[] textArray23 = new string[] { str6 };
                                this.DRComm = this.tbl_Comm.GetData(textArray22, textArray23);
                                if (this.DRComm != null)
                                {
                                    num92 = Program.StrToDouble(this.DRComm["netto_Weight"].ToString(), 0);
                                    num29 = float.Parse(num92.ToString());
                                    pStr = this.DRComm["unit"].ToString().Trim().ToUpper();
                                }
                            }
                        }
                        else if (this.rb_mill.Checked)
                        {
                            if ((((str7 != "") && (str7 != current["mill"].ToString())) || ((zValue != "") && (zValue != current["relation_code"].ToString()))) || ((str9 != "") && (str9 != current["comm_code"].ToString())))
                            {
                                html.Write("<tr class='bd'>");
                                html.Write("<td>" + html.strq("") + "</td>");
                                string str14 = str7;
                                if (str7 == "")
                                {
                                    str14 = Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", zValue);
                                }
                                string[] textArray24 = new string[] { "<td colspan=", num2.ToString(), "><b>Sub Total of ", str14, "</td>" };
                                html.Write(string.Concat(textArray24));
                                num52 = Program.StrToDouble($"{num52:N0}", 0);
                                if (this.checkColly.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num62:N0}" + "</td>");
                                }
                                if (this.cbGunny.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num60:N0}" + "</td>");
                                }
                                if (this.checkConv.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + html.strq(current["ConvUnit"].ToString()) + "</td>");
                                    html.Write("<td nowrap align=right><b>&nbsp</td>");
                                }
                                if (this.check3rdParty.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num13:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num14:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num15:N0}" + "</td>");
                                }
                                if (this.checkBrutoTarra.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num16:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num17:N0}" + "</td>");
                                }
                                if (this.cbDeduction.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{(num16 - num17):N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num56:N0}" + "</td>");
                                }
                                html.Write("<td nowrap align=right><b>" + $"{num18:N0}" + "</td>");
                                if (this.checkDiff.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num19:N0}" + "</td>");
                                    if (!(num19 == 0.0))
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{((num19 / num15) * 100.0):N2}" + "</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td nowrap align=right><b>0.00</td>");
                                    }
                                }
                                if (this.checkLoadingQty.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num33:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num34:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + html.strq(pStr) + "</td>");
                                    html.Write("<td nowrap align=right><b>" + html.strq($"{num35:N0}") + "</td>");
                                }
                                if (this.checkBoxMaterialStuffing.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.cBoxReturInKg.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num75 + "</td>");
                                }
                                if (this.cBoxReturInPack.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num76 + "</td>");
                                }
                                if (this.cBoxLossInKg.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num77 + "</td>");
                                }
                                if (this.cBoxLossInPack.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num78 + "</td>");
                                }
                                if (this.checkSeal.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.checkWBRef.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.cbDL.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    if (num63 > 0.0)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num63:N0}" + "</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (num64 > 0.0)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num64:N0}" + "</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                }
                                if (this.checkRmkTicket.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.checkRmkReport.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                html.Write("</tr>");
                                html.Write("<td colspan=" + (((num2 + num3) + num4) + 7).ToString() + ">&nbsp</td>");
                                html.Write("</tr>");
                                if (this.rb_mill.Checked)
                                {
                                    html.Write("<tr>");
                                    string str15 = "";
                                    str15 = (current["mill"].ToString() != "") ? html.strq(current["mill"].ToString() + " (" + current["comm_name"].ToString() + ")") : html.strq(current["relation_name"].ToString() + " (" + current["comm_name"].ToString() + ")");
                                    string[] textArray25 = new string[] { "<td colspan=", (((num2 + num3) + num4) + 7).ToString(), "><b>", str15, "</b></td>" };
                                    html.Write(string.Concat(textArray25));
                                    html.Write("</tr>");
                                }
                                num13 = 0.0;
                                num14 = 0.0;
                                num15 = 0.0;
                                num75 = 0.0;
                                num76 = 0.0;
                                num77 = 0.0;
                                num78 = 0.0;
                                num16 = 0.0;
                                num62 = 0.0;
                                num17 = 0.0;
                                num18 = 0.0;
                                num19 = 0.0;
                                num33 = 0.0;
                                num34 = 0.0;
                                num35 = 0.0;
                                num55 = 0.0;
                                num60 = 0.0;
                                num56 = 0.0;
                                num63 = 0.0;
                                num64 = 0.0;
                                num71 = 0.0;
                                num72 = 0.0;
                                num73 = 0.0;
                                num74 = 0.0;
                                num20 = 0.0;
                                str7 = current["Mill"].ToString();
                                zValue = current["relation_code"].ToString();
                                str9 = current["comm_code"].ToString();
                                num70 = 1;
                            }
                            if (str7 == "")
                            {
                                str7 = current["Mill"].ToString();
                            }
                            if (zValue == "")
                            {
                                zValue = current["relation_code"].ToString();
                            }
                            if (str9 == "")
                            {
                                str9 = current["comm_code"].ToString();
                            }
                        }
                        else if (this.rb_iscc.Checked)
                        {
                            if ((zValue != "") && (zValue != current["relation_code"].ToString()))
                            {
                                html.Write("<tr class='bd'>");
                                html.Write("<td>" + html.strq("") + "</td>");
                                string str16 = zValue + " (" + Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", zValue) + ")";
                                string[] textArray26 = new string[] { "<td colspan=", num2.ToString(), "><b>Sub Total of Vendor: ", str16, "</td>" };
                                html.Write(string.Concat(textArray26));
                                num52 = Program.StrToDouble($"{num52:N0}", 0);
                                if (this.checkColly.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num62:N0}" + "</td>");
                                }
                                if (this.cbGunny.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num60:N0}" + "</td>");
                                }
                                if (this.checkConv.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + html.strq(current["ConvUnit"].ToString()) + "</td>");
                                    html.Write("<td nowrap align=right><b>&nbsp</td>");
                                }
                                if (this.check3rdParty.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num13:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num14:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num15:N0}" + "</td>");
                                }
                                if (this.checkBrutoTarra.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num16:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num17:N0}" + "</td>");
                                }
                                if (this.cbDeduction.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{(num16 - num17):N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num56:N0}" + "</td>");
                                }
                                html.Write("<td nowrap align=right><b>" + $"{num18:N0}" + "</td>");
                                if (this.checkDiff.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num19:N0}" + "</td>");
                                    if (!(num19 == 0.0))
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{((num19 / num15) * 100.0):N2}" + "</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td nowrap align=right><b>0.00</td>");
                                    }
                                }
                                if (this.checkLoadingQty.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num33:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num34:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + html.strq(pStr) + "</td>");
                                    html.Write("<td nowrap align=right><b>" + html.strq($"{num35:N0}") + "</td>");
                                }
                                if (this.checkBoxMaterialStuffing.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.cBoxReturInKg.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num75 + "</td>");
                                }
                                if (this.cBoxReturInPack.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num76 + "</td>");
                                }
                                if (this.cBoxLossInKg.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num77 + "</td>");
                                }
                                if (this.cBoxLossInPack.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num78 + "</td>");
                                }
                                if (this.checkSeal.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.checkWBRef.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.cbDL.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    if (num63 > 0.0)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num63:N0}" + "</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (num64 > 0.0)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num64:N0}" + "</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                }
                                if (this.checkRmkTicket.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.checkRmkReport.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.checkCrtBy.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.checkChgBy.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.cBoxWBCode.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    if (WBSetting.Container == "Y")
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                }
                                if (this.checkGrade.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                html.Write("</tr>");
                                if ((str10 != "") && (str10 != current["qOrigin"].ToString()))
                                {
                                    html.Write("<tr class='bd'>");
                                    string[] textArray27 = new string[] { "<td colspan=", (num2 + 1).ToString(), "><b>Total of Area: ", str10, "</td>" };
                                    html.Write(string.Concat(textArray27));
                                    if (this.checkColly.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num54:N0}" + "</td>");
                                    }
                                    if (this.cbGunny.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num51:N0}" + "</td>");
                                    }
                                    if (this.checkConv.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num28:N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>&nbsp</td>");
                                    }
                                    if (this.check3rdParty.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num21:N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>" + $"{num22:N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>" + $"{num23:N0}" + "</td>");
                                    }
                                    if (this.checkBrutoTarra.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num24:N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>" + $"{num25:N0}" + "</td>");
                                    }
                                    if (this.cbDeduction.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{(num24 - num25):N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>" + $"{num58:N0}" + "</td>");
                                    }
                                    html.Write("<td nowrap align=right><b>" + $"{num26:N0}" + "</td>");
                                    if (this.checkDiff.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num27:N0}" + "</td>");
                                        if (!(num19 == 0.0))
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{((num27 / num23) * 100.0):N2}" + "</td>");
                                        }
                                        else
                                        {
                                            html.Write("<td nowrap align=right><b>0.00</td>");
                                        }
                                    }
                                    if (this.checkLoadingQty.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num39:N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>" + $"{num40:N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>" + html.strq(pStr) + "</td>");
                                        html.Write("<td nowrap align=right><b>" + html.strq($"{num41:N0}") + "</td>");
                                    }
                                    if (this.checkBoxMaterialStuffing.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.cBoxReturInKg.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + num83 + "</td>");
                                    }
                                    if (this.cBoxReturInPack.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + num84 + "</td>");
                                    }
                                    if (this.cBoxLossInKg.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + num85 + "</td>");
                                    }
                                    if (this.cBoxLossInPack.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + num86 + "</td>");
                                    }
                                    if (this.checkSeal.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.checkWBRef.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.cbDL.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        if (num63 > 0.0)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num67:N0}" + "</td>");
                                        }
                                        else
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (num64 > 0.0)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num68:N0}" + "</td>");
                                        }
                                        else
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                    }
                                    if (this.checkRmkTicket.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.checkRmkReport.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.checkCrtBy.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.checkChgBy.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.cBoxWBCode.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        if (WBSetting.Container == "Y")
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                    }
                                    if (this.checkGrade.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    num21 = 0.0;
                                    num22 = 0.0;
                                    num23 = 0.0;
                                    num83 = 0.0;
                                    num84 = 0.0;
                                    num85 = 0.0;
                                    num86 = 0.0;
                                    num24 = 0.0;
                                    num54 = 0.0;
                                    num25 = 0.0;
                                    num26 = 0.0;
                                    num27 = 0.0;
                                    num39 = 0.0;
                                    num40 = 0.0;
                                    num41 = 0.0;
                                    num51 = 0.0;
                                    num58 = 0.0;
                                    num67 = 0.0;
                                    num68 = 0.0;
                                    num28 = 0.0;
                                    html.Write("</tr>");
                                }
                                html.Write("<tr>");
                                html.Write("<td colspan=" + (((num2 + num3) + num4) + 7).ToString() + ">&nbsp</td>");
                                html.Write("</tr>");
                                if (this.rb_iscc.Checked)
                                {
                                    if ((str10 != "") && (str10 != current["qOrigin"].ToString()))
                                    {
                                        html.Write("<tr>");
                                        string str18 = "";
                                        str18 = html.strq("Area: " + current["qOrigin"].ToString());
                                        string[] textArray28 = new string[] { "<td colspan=", (((num2 + num3) + num4) + 7).ToString(), "><b>", str18, "</b></td>" };
                                        html.Write(string.Concat(textArray28));
                                        html.Write("</tr>");
                                    }
                                    html.Write("<tr>");
                                    string str17 = "";
                                    string[] textArray29 = new string[] { "Vendor: ", current["relation_code"].ToString(), " (", current["relation_name"].ToString(), ")" };
                                    str17 = html.strq(string.Concat(textArray29));
                                    string[] textArray30 = new string[] { "<td colspan=", (((num2 + num3) + num4) + 7).ToString(), "><b>", str17, "</b></td>" };
                                    html.Write(string.Concat(textArray30));
                                    html.Write("</tr>");
                                }
                                num13 = 0.0;
                                num14 = 0.0;
                                num15 = 0.0;
                                num75 = 0.0;
                                num76 = 0.0;
                                num77 = 0.0;
                                num78 = 0.0;
                                num16 = 0.0;
                                num62 = 0.0;
                                num17 = 0.0;
                                num18 = 0.0;
                                num19 = 0.0;
                                num33 = 0.0;
                                num34 = 0.0;
                                num35 = 0.0;
                                num55 = 0.0;
                                num60 = 0.0;
                                num56 = 0.0;
                                num63 = 0.0;
                                num64 = 0.0;
                                num71 = 0.0;
                                num72 = 0.0;
                                num73 = 0.0;
                                num74 = 0.0;
                                num20 = 0.0;
                                zValue = current["relation_code"].ToString();
                                str10 = current["qOrigin"].ToString();
                                num70 = 1;
                            }
                            if (str10 == "")
                            {
                                str10 = current["qOrigin"].ToString();
                            }
                            if (zValue == "")
                            {
                                zValue = current["relation_code"].ToString();
                            }
                        }
                        num42 = Program.StrToDouble(current["Gross_Estate"].ToString(), 0);
                        num43 = Program.StrToDouble(current["Net_Estate"].ToString(), 0);
                        num52 = Program.StrToDouble(current["JlhColly"].ToString(), 0);
                        string[] aField = new string[] { "comm_code" };
                        string[] aFind = new string[] { current["Comm_Code"].ToString() };
                        this.DRComm = this.tbl_Comm.GetData(aField, aFind);
                        if (this.DRComm != null)
                        {
                            num29 = float.Parse(Program.StrToDouble(this.DRComm["netto_Weight"].ToString(), 0).ToString());
                            pStr = this.DRComm["unit"].ToString().Trim().ToUpper();
                        }
                        if (current["report_Date"].ToString().Trim() != "")
                        {
                            num16 += Program.StrToDouble(current["Bruto"].ToString(), 0);
                            num17 += Program.StrToDouble(current["Tarra"].ToString(), 0);
                            num18 += Program.StrToDouble(current["Netto"].ToString(), 0);
                            num8 += Program.StrToDouble(current["Bruto"].ToString(), 0);
                            num9 += Program.StrToDouble(current["Tarra"].ToString(), 0);
                            num10 += Program.StrToDouble(current["Netto"].ToString(), 0);
                            num24 += Program.StrToDouble(current["Bruto"].ToString(), 0);
                            num25 += Program.StrToDouble(current["Tarra"].ToString(), 0);
                            num26 += Program.StrToDouble(current["Netto"].ToString(), 0);
                            num60 += Program.StrToDouble(current["TotalBunch"].ToString(), 0);
                            num50 += Program.StrToDouble(current["TotalBunch"].ToString(), 0);
                            num51 += Program.StrToDouble(current["TotalBunch"].ToString(), 0);
                            num62 += num52;
                            num53 += num52;
                            num54 += num52;
                            num56 += Program.StrToDouble(current["Deduction"].ToString(), 0);
                            num57 += Program.StrToDouble(current["Deduction"].ToString(), 0);
                            num58 += Program.StrToDouble(current["Deduction"].ToString(), 0);
                            num13 += num42;
                            num14 += Program.StrToDouble(current["Tare_Estate"].ToString(), 0);
                            num15 += num43;
                            num5 += num42;
                            num6 += Program.StrToDouble(current["Tare_Estate"].ToString(), 0);
                            num7 += num43;
                            num21 += num42;
                            num22 += Program.StrToDouble(current["Tare_Estate"].ToString(), 0);
                            num23 += num43;
                            num30 = Program.StrToDouble(current["Loading_Qty"].ToString(), 3);
                            num31 = Program.StrToDouble(current["Loading_Qty_opw"].ToString(), 3);
                            num32 = num30 * num29;
                            num33 += num30;
                            num34 += num31;
                            num35 += num32;
                            num36 += num30;
                            num37 += num31;
                            num38 += num32;
                            num39 += num30;
                            num40 += num31;
                            num41 += num32;
                            num71 = Program.StrToDouble(current["Return_qty_Kg"].ToString(), 0);
                            num72 = Program.StrToDouble(current["Return_qty_Pack"].ToString(), 3);
                            num74 = ((((Program.StrToDouble(current["Return_qty_Pack"].ToString(), 3) <= 0.0) && (Program.StrToDouble(current["loading_qty_opw"].ToString(), 3) <= 0.0)) || (current["transaction_code"].ToString() == this.Retur_masuk)) || (current["transaction_code"].ToString() == this.Retur_keluar)) ? 0.0 : (((Program.StrToDouble(current["loading_qty"].ToString(), 3) - Program.StrToDouble(current["loading_qty_opw"].ToString(), 3)) - Program.StrToDouble(current["Return_qty_Pack"].ToString(), 3)) * -1.0);
                            num73 = (((Program.StrToDouble(current["estate_qty"].ToString(), 0) <= 0.0) || ((current["transaction_code"].ToString() == this.Retur_masuk) || ((current["transaction_code"].ToString() == this.Retur_keluar) || (current["deductedby"].ToString() != "1")))) || (current["Unit"].ToString().ToUpper() != "KG")) ? 0.0 : (((Program.StrToDouble(current["netto"].ToString(), 0) - Program.StrToDouble(current["estate_qty"].ToString(), 0)) - Program.StrToDouble(current["return_qty_kg"].ToString(), 0)) * -1.0);
                            num75 += num71;
                            num76 += num72;
                            num77 += num73;
                            num78 += num74;
                            num79 += num71;
                            num80 += num72;
                            num81 += num73;
                            num82 += num74;
                            num83 += num71;
                            num84 += num72;
                            num85 += num73;
                            num86 += num74;
                            if (this.checkConv.Checked)
                            {
                                num20 += Program.StrToDouble(current["ConvNett"].ToString(), 0);
                                num12 += Program.StrToDouble(current["ConvNett"].ToString(), 0);
                                num28 += Program.StrToDouble(current["ConvNett"].ToString(), 0);
                            }
                            if (num43 > 0.0)
                            {
                                num44 = Program.StrToDouble(current["Netto"].ToString(), 0) - num43;
                            }
                            num11 += num44;
                            num19 += num44;
                            num27 += num44;
                        }
                        html.Write("<tr class='bd'>");
                        html.Write("<td nowrap>" + html.strq(num70.ToString()) + "</td>");
                        html.Write("<td nowrap>" + html.strq(current["Transaction_Code"].ToString()) + "</td>");
                        if (this.checkNot1stYet.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Gatepass_Number"].ToString()) + "</td>");
                        }
                        html.Write("<td nowrap>" + html.strq(current["Ref"].ToString()) + "</td>");
                        if (this.checkBoxGatepassNumber.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Gatepass_Number"].ToString()) + "</td>");
                        }
                        if (current["Report_date"].ToString().Trim() != "")
                        {
                            html.Write("<td nowrap>" + html.strq(current["Report_date"].ToString().Substring(0, 10)) + "</td>");
                        }
                        else
                        {
                            html.Write("<td nowrap>" + html.strq(current["Ref_date"].ToString().Substring(0, 10)) + "</td>");
                        }
                        if (this.checkDelivery.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Delivery_Date"].ToString().Substring(0, 10)) + "</td>");
                            html.Write("<td nowrap>" + html.strq(current["Delivery_Time"].ToString()) + "</td>");
                        }
                        if (current["Date1"].ToString() != "")
                        {
                            html.Write("<td nowrap>" + html.strq(current["Date1"].ToString().Substring(0, 10)) + "</td>");
                        }
                        else
                        {
                            html.Write("<td nowrap>" + html.strq("") + "</td>");
                        }
                        if (current["Time1"].ToString() != "")
                        {
                            html.Write("<td nowrap>" + html.strq(current["Time1"].ToString()) + "</td>");
                        }
                        else
                        {
                            html.Write("<td nowrap>" + html.strq("") + "</td>");
                        }
                        if (current["Date2"].ToString() != "")
                        {
                            html.Write("<td nowrap>" + html.strq(current["Date2"].ToString().Substring(0, 10)) + "</td>");
                        }
                        else
                        {
                            html.Write("<td nowrap>" + html.strq("") + "</td>");
                        }
                        if (current["Time2"].ToString() != "")
                        {
                            html.Write("<td nowrap>" + html.strq(current["Time2"].ToString()) + "</td>");
                        }
                        else
                        {
                            html.Write("<td nowrap>" + html.strq("") + "</td>");
                        }
                        if (this.cBoxDiffHour.Checked)
                        {
                            if (current["report_date"].ToString() == "")
                            {
                                html.Write("<td nowrap>00:00</td>");
                            }
                            else if (current["Date1"].ToString() == "")
                            {
                                html.Write("<td nowrap>00:00</td>");
                            }
                            else
                            {
                                this.tmpDate = current["Date1"].ToString().Substring(0, 10) + " " + current["Time1"].ToString();
                                this.time1 = Convert.ToDateTime(this.tmpDate);
                                this.tmpDate = current["date2"].ToString().Substring(0, 10) + " " + current["Time2"].ToString();
                                this.time2 = Convert.ToDateTime(this.tmpDate);
                                this.ts = (TimeSpan) (this.time2 - this.time1);
                                html.Write("<td nowrap>" + this.ts.ToString().Substring(0, 5) + "</td>");
                            }
                        }
                        if (this.checkRegistrationInOut.Checked)
                        {
                            WBTable table4 = new WBTable();
                            table4.OpenTable("wb_gatepass", "Select Create_By,Create_Date,Submit_Date,Submit_Time,Submit_By from wb_gatepass WITH (NOLOCK) where " + WBData.CompanyLocation(" and ref = '" + current["ref"].ToString() + "'"), WBData.conn);
                            if (table4.DT.Rows.Count > 0)
                            {
                                string str19 = (table4.DT.Rows[0]["Create_Date"].ToString() == "") ? "&nbsp;" : table4.DT.Rows[0]["Create_Date"].ToString().Substring(0, 10);
                                string str20 = (table4.DT.Rows[0]["Create_Date"].ToString() == "") ? "&nbsp;" : table4.DT.Rows[0]["Create_Date"].ToString().Substring(11, 5);
                                string[] textArray33 = new string[] { "<td nowrap align='center'>", str20, " ", str19, "</td>" };
                                html.Write(string.Concat(textArray33));
                                html.Write("<td nowrap align='center'>" + html.strq((table4.DT.Rows[0]["Create_By"].ToString() == "") ? "&nbsp;" : table4.DT.Rows[0]["Create_By"].ToString()) + "</td>");
                                string str22 = (table4.DT.Rows[0]["Submit_Date"].ToString() == "") ? "&nbsp;" : table4.DT.Rows[0]["Submit_Date"].ToString().Substring(0, 10);
                                string str23 = (table4.DT.Rows[0]["Submit_Time"].ToString() == "") ? "&nbsp;" : table4.DT.Rows[0]["Submit_Time"].ToString();
                                string[] textArray34 = new string[] { "<td nowrap align='center'>", str23, " ", str22, "</td>" };
                                html.Write(string.Concat(textArray34));
                                html.Write("<td nowrap align='center'>" + html.strq((table4.DT.Rows[0]["Submit_By"].ToString() == "") ? "&nbsp;" : table4.DT.Rows[0]["Submit_By"].ToString()) + "</td>");
                            }
                            else
                            {
                                WBTable table5 = new WBTable();
                                table5.OpenTable("wb_gatepass", "Select Create_By,Create_Date,Submit_Date,Submit_Time,Submit_By from wb_gatepass WITH (NOLOCK) where " + WBData.CompanyLocation(" and gatepass_number = '" + current["ref"].ToString() + "'"), WBData.conn);
                                if (table5.DT.Rows.Count <= 0)
                                {
                                    html.Write("<td nowrap align='center'> " + html.strq("") + " </td>");
                                    html.Write("<td nowrap align='center'> " + html.strq("") + " </td>");
                                    html.Write("<td nowrap align='center'> " + html.strq("") + " </td>");
                                    html.Write("<td nowrap align='center'> " + html.strq("") + " </td>");
                                }
                                else
                                {
                                    string str25 = (table5.DT.Rows[0]["Create_Date"].ToString() == "") ? "&nbsp;" : table5.DT.Rows[0]["Create_Date"].ToString().Substring(0, 10);
                                    string str26 = (table5.DT.Rows[0]["Create_Date"].ToString() == "") ? "&nbsp;" : table5.DT.Rows[0]["Create_Date"].ToString().Substring(11, 5);
                                    string[] textArray35 = new string[] { "<td nowrap align='center'>", str26, " ", str25, "</td>" };
                                    html.Write(string.Concat(textArray35));
                                    html.Write("<td nowrap align='center'>" + html.strq((table5.DT.Rows[0]["Create_By"].ToString() == "") ? "&nbsp;" : table5.DT.Rows[0]["Create_By"].ToString()) + "</td>");
                                    string str28 = (table5.DT.Rows[0]["Submit_Date"].ToString() == "") ? "&nbsp;" : table5.DT.Rows[0]["Submit_Date"].ToString().Substring(0, 10);
                                    string str29 = (table5.DT.Rows[0]["Submit_Time"].ToString() == "") ? "&nbsp;" : table5.DT.Rows[0]["Submit_Time"].ToString();
                                    string[] textArray36 = new string[] { "<td nowrap align='center'>", str29, " ", str28, "</td>" };
                                    html.Write(string.Concat(textArray36));
                                    html.Write("<td nowrap align='center'>" + html.strq((table5.DT.Rows[0]["Submit_By"].ToString() == "") ? "&nbsp;" : table5.DT.Rows[0]["Submit_By"].ToString()) + "</td>");
                                }
                            }
                        }
                        if (this.cb_interval12.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["time_bgate1_open"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(current["time_bgate1_close"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(current["interval_1"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(current["time_bgate2_open"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(current["time_bgate2_close"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(current["interval_2"].ToString()) + "</td>");
                        }
                        if (this.cb_interval34.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["time_bgate3_open"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(current["time_bgate3_close"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(current["interval_3"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(current["time_bgate4_open"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(current["time_bgate4_close"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(current["interval_4"].ToString()) + "</td>");
                        }
                        if (this.checkDO_No.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Do_No"].ToString()) + "</td>");
                        }
                        if (this.cb_do_sap.Checked)
                        {
                            if (current["do_sap"].ToString().Trim() == "")
                            {
                                html.Write("<td nowrap>&nbsp</td>");
                            }
                            else
                            {
                                string[] textArray37 = new string[] { "<td nowrap>", html.strq(current["do_sap"].ToString()), "/", html.strq(current["do_sap_item"].ToString()), "</td>" };
                                html.Write(string.Concat(textArray37));
                            }
                        }
                        if (this.cb_internal_no.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["internal_number"].ToString()) + "</td>");
                        }
                        if (this.checkQSt.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Iscc_Text"].ToString()) + "</td>");
                        }
                        if (this.checkContract.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Contract"].ToString()) + "</td>");
                        }
                        if (this.cBoxPISI.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["PI_No"].ToString()) + "</td>");
                        }
                        if (this.checkSTO.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["STO"].ToString()) + "</td>");
                        }
                        if (this.checkPO.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["PO"].ToString()) + "</td>");
                        }
                        if (this.checkSO.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["SO"].ToString()) + "</td>");
                        }
                        if (this.check1xSTO.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["STO1X"].ToString()) + "</td>");
                        }
                        if (this.check1xDO.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["DO1X"].ToString()) + "</td>");
                        }
                        html.Write("<td nowrap>" + html.strq(current["Comm_code"].ToString()) + "</td>");
                        if (this.cBoxCommName.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Comm_Name"].ToString()) + "</td>");
                        }
                        if (this.checkStorage.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["storage_code"].ToString()) + "</td>");
                        }
                        if (this.checkDeliNote.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Delivery_Note"].ToString()) + "</td>");
                        }
                        if (this.checkRelation.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Relation_code"].ToString()) + "</td>");
                        }
                        if (this.checkRelationName.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", current["Relation_code"].ToString())) + "</td>");
                        }
                        if (this.checkEstate.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Estate"].ToString()) + "</td>");
                        }
                        if (this.checkLicenseNo.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["License_No"].ToString().Trim()) + "</td>");
                        }
                        if (this.checkDriverName.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Name"].ToString()) + "</td>");
                        }
                        html.Write("<td nowrap>" + html.strq(current["Truck_Number"].ToString()) + "</td>");
                        if (this.cBoxYellowPlate.Checked)
                        {
                            WBTable table6 = new WBTable();
                            table6.OpenTable("wb_truck", "Select * from wb_truck WITH (NOLOCK) where " + WBData.CompanyLocation(" and truck_number = '" + current["Truck_Number"].ToString() + "'"), WBData.conn);
                            if (table6.DT.Rows.Count > 0)
                            {
                                html.Write("<td nowrap>" + html.strq((table6.DT.Rows[0]["tipe"].ToString() == "K") ? "Y" : "N") + "</td>");
                            }
                        }
                        if (this.checkTrailerNo.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Trailer_Number"].ToString()) + "</td>");
                        }
                        if (this.checkTransporter.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Transporter_Code"].ToString()) + "</td>");
                        }
                        if (this.cBoxTransName.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Transporter_Name"].ToString()) + "</td>");
                        }
                        if (this.checkBoxTank.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["TankQC"].ToString()) + "</td>");
                        }
                        if (this.cbAddInfo.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Addi_Info"].ToString()) + "</td>");
                        }
                        if (this.cb_tank.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["TankQC"].ToString()) + "</td>");
                        }
                        if (this.checkSourceCode.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Source_code"].ToString()) + "</td>");
                        }
                        if (this.checkSourceDesc.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["SourceDesc"].ToString()) + "</td>");
                        }
                        if (this.checkColly.Checked)
                        {
                            html.Write("<td nowrap align=right>" + $"{num52:N0}" + "</td>");
                        }
                        if (this.cbGunny.Checked)
                        {
                            num59 = Program.StrToDouble(current["TotalBunch"].ToString(), 0);
                            html.Write("<td nowrap align=right>" + html.strq($"{num59:N0}") + "</td>");
                        }
                        if (this.checkConv.Checked)
                        {
                            html.Write("<td nowrap align=right>" + html.strq($"{Program.StrToDouble(current["ConvNett"].ToString(), 0):N0}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq(current["ConvUnit"].ToString()) + "</td>");
                        }
                        if (this.check3rdParty.Checked)
                        {
                            html.Write("<td nowrap align=right>" + html.strq($"{num42:N0}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{current["Tare_Estate"]:N0}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{num43:N0}") + "</td>");
                        }
                        if (this.checkBrutoTarra.Checked)
                        {
                            html.Write("<td nowrap align=right>" + html.strq($"{current["Bruto"]:N0}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{current["Tarra"]:N0}") + "</td>");
                        }
                        if (this.cbDeduction.Checked)
                        {
                            num47 = Program.StrToDouble(current["Bruto"].ToString(), 0) - Program.StrToDouble(current["Tarra"].ToString(), 0);
                            num55 = Program.StrToDouble(current["Deduction"].ToString(), 0);
                            html.Write("<td nowrap align=right>" + html.strq($"{num47:N0}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{num55:N0}") + "</td>");
                        }
                        html.Write("<td nowrap align=right>" + html.strq($"{current["Netto"]:N0}") + "</td>");
                        if (this.checkDiff.Checked)
                        {
                            html.Write("<td nowrap align=right>" + html.strq($"{num44:N0}") + "</td>");
                            if (!(num43 == 0.0))
                            {
                                html.Write("<td nowrap align=right>" + html.strq($"{(num44 / num43) * 100.0:N2}") + "</td>");
                            }
                            else
                            {
                                html.Write("<td nowrap align=right>0.00</td>");
                            }
                        }
                        if (this.checkLoadingQty.Checked)
                        {
                            html.Write("<td nowrap align=right>" + html.strq($"{num30:N0}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{num31:N0}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq(pStr) + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{num32:N0}") + "</td>");
                        }
                        if (this.checkBoxMaterialStuffing.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["materialStuffing"].ToString()) + "</td>");
                        }
                        if (this.cBoxReturInKg.Checked)
                        {
                            html.Write("<td nowrap align=right>" + num71 + "</td>");
                        }
                        if (this.cBoxReturInPack.Checked)
                        {
                            html.Write("<td nowrap align=right>" + num72 + "</td>");
                        }
                        if (this.cBoxLossInKg.Checked)
                        {
                            html.Write("<td nowrap align=right>" + num73 + "</td>");
                        }
                        if (this.cBoxLossInPack.Checked)
                        {
                            html.Write("<td nowrap align=right>" + num74 + "</td>");
                        }
                        if (this.checkSeal.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Seal"].ToString()) + "</td>");
                        }
                        if (this.checkWBRef.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Ticket"].ToString()) + "</td>");
                        }
                        if (!this.cbDL.Checked)
                        {
                            if (this.checkRmkTicket.Checked)
                            {
                                html.Write("<td nowrap>" + html.strq(current["Remark_Ticket"].ToString()) + "</td>");
                            }
                            if (this.checkRmkReport.Checked)
                            {
                                html.Write("<td nowrap>" + html.strq(current["Remark_Report"].ToString()) + "</td>");
                            }
                        }
                        else
                        {
                            WBTable table7 = new WBTable();
                            string[] textArray38 = new string[] { " and (ref = '", current["ref"].ToString().Trim(), "' or ref like '", current["ref"].ToString().Trim(), "-%') and SO_no = '", current["Do_No"].ToString().Trim(), "'" };
                            table7.OpenTable("wb_transbatch", "select * from wb_transBatch WITH (NOLOCK) where " + WBData.CompanyLocation(string.Concat(textArray38)), WBData.conn);
                            if (table7.DT.Rows.Count <= 0)
                            {
                                html.Write("<td>" + html.strq("") + "</td>");
                                html.Write("<td>" + html.strq("") + "</td>");
                                html.Write("<td>" + html.strq("") + "</td>");
                                html.Write("<td>" + html.strq("") + "</td>");
                                html.Write("<td>" + html.strq("") + "</td>");
                                html.Write("<td>" + html.strq("") + "</td>");
                                html.Write("<td>" + html.strq("") + "</td>");
                                if (this.checkRmkTicket.Checked)
                                {
                                    html.Write("<td nowrap>" + html.strq(current["Remark_Ticket"].ToString()) + "</td>");
                                }
                                if (this.checkRmkReport.Checked)
                                {
                                    html.Write("<td nowrap>" + html.strq(current["Remark_Report"].ToString()) + "</td>");
                                }
                            }
                            else
                            {
                                int num93 = 0;
                                while (true)
                                {
                                    int num94;
                                    if (num93 >= table7.DT.Rows.Count)
                                    {
                                        break;
                                    }
                                    DataRow row2 = table7.DT.Rows[num93];
                                    if ((num93 > 0) & (num93 < table7.DT.Rows.Count))
                                    {
                                        html.Write("</tr>");
                                        html.Write("<tr class='bd'>");
                                        num94 = 1;
                                        while (true)
                                        {
                                            if (num94 > (num3 + 1))
                                            {
                                                break;
                                            }
                                            html.Write("<td>&nbsp</td>");
                                            num89 = num94;
                                            num94 = num89 + 1;
                                        }
                                    }
                                    if (num93 == 0)
                                    {
                                        html.Write("<td>" + html.strq(row2["Do_No"].ToString()) + "</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    html.Write("<td>" + html.strq(row2["Item_No"].ToString()) + "</td>");
                                    html.Write("<td>" + html.strq(row2["Batch"].ToString()) + "</td>");
                                    html.Write("<td>" + html.strq(row2["STO_No"].ToString()) + "</td>");
                                    html.Write("<td>" + html.strq(row2["STO_Batch"].ToString()) + "</td>");
                                    html.Write("<td nowrap align=right>" + html.strq(row2["Num_of_Gunny"].ToString()) + "</td>");
                                    html.Write("<td nowrap align=right>" + html.strq(row2["Netto"].ToString()) + "</td>");
                                    num63 += Convert.ToDouble(row2["Num_of_Gunny"].ToString());
                                    num64 += Convert.ToDouble(row2["Netto"].ToString());
                                    num65 += Convert.ToDouble(row2["Num_of_Gunny"].ToString());
                                    num66 += Convert.ToDouble(row2["Netto"].ToString());
                                    num67 += Convert.ToDouble(row2["Num_of_Gunny"].ToString());
                                    num68 += Convert.ToDouble(row2["Netto"].ToString());
                                    if (!((num93 > 0) & (num93 < table7.DT.Rows.Count)))
                                    {
                                        if (this.checkRmkTicket.Checked)
                                        {
                                            html.Write("<td nowrap>" + html.strq(current["Remark_Ticket"].ToString()) + "</td>");
                                        }
                                        if (this.checkRmkReport.Checked)
                                        {
                                            html.Write("<td nowrap>" + html.strq(current["Remark_Report"].ToString()) + "</td>");
                                        }
                                    }
                                    else
                                    {
                                        num94 = 1;
                                        while (true)
                                        {
                                            if (num94 > num4)
                                            {
                                                break;
                                            }
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            num89 = num94;
                                            num94 = num89 + 1;
                                        }
                                    }
                                    num93++;
                                }
                            }
                        }
                        if (this.checkCrtBy.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Create_By"].ToString()) + "</td>");
                        }
                        if (this.checkChgBy.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["Change_By"].ToString()) + "</td>");
                        }
                        if (this.cBoxWBCode.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["WBCode1"].ToString()) + "</td>");
                            html.Write("<td nowrap>" + html.strq(current["WBCode2"].ToString()) + "</td>");
                            if (WBSetting.Container == "Y")
                            {
                                html.Write("<td nowrap>" + html.strq(current["WBCode3"].ToString()) + "</td>");
                                html.Write("<td nowrap>" + html.strq(current["WBCode4"].ToString()) + "</td>");
                            }
                        }
                        if (this.checkGrade.Checked)
                        {
                            html.Write("<td nowrap>" + html.strq(current["FFB_Grade"].ToString()) + "</td>");
                        }
                        html.Write("</tr>");
                        num70++;
                        num69++;
                    TR_02FA:
                        while (true)
                        {
                            if (enumerator.MoveNext())
                            {
                                current = (DataRow) enumerator.Current;
                                if ((this.TimeFrom.Text != "") && (this.TimeTo.Text != ""))
                                {
                                    try
                                    {
                                        if (current["Time2"].ToString().Trim() != "")
                                        {
                                            this.time1 = Convert.ToDateTime(this.monthCalendar1.Text.Substring(0, 10) + " " + this.TimeFrom.Text + ":00");
                                            this.time2 = Convert.ToDateTime(this.monthCalendar2.Text.Substring(0, 10) + " " + this.TimeTo.Text + ":00");
                                            this.tmpDate = current["Date2"].ToString().Substring(0, 10) + " " + current["Time2"].ToString();
                                        }
                                        else
                                        {
                                            this.time1 = Convert.ToDateTime(this.monthCalendar1.Text.Substring(0, 10) + " " + this.TimeFrom.Text + ":00");
                                            this.time2 = Convert.ToDateTime(this.monthCalendar2.Text.Substring(0, 10) + " " + this.TimeTo.Text + ":00");
                                            this.tmpDate = current["Date1"].ToString().Substring(0, 10) + " " + current["Time1"].ToString();
                                        }
                                        if ((Convert.ToDateTime(this.tmpDate) <= this.time1) || (Convert.ToDateTime(this.tmpDate) >= this.time2))
                                        {
                                            continue;
                                        }
                                    }
                                    catch
                                    {
                                    }
                                }
                            }
                            else
                            {
                                this.labelProses1.Text = num69.ToString() + "/" + count;
                                this.labelProses1.Refresh();
                                if (this.rb_comm.Checked)
                                {
                                    if (str6 != "")
                                    {
                                        html.Write("<tr class='bd'>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        string[] textArray39 = new string[] { "<td colspan=", num2.ToString(), "><b>Sub Total of ", str6, "</td>" };
                                        html.Write(string.Concat(textArray39));
                                        num62 = Program.StrToDouble($"{num62:N0}", 0);
                                        if (this.checkColly.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num62:N0}" + "</td>");
                                        }
                                        if (this.cbGunny.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num60:N0}" + "</td>");
                                        }
                                        if (this.checkConv.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num20:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>&nbsp</td>");
                                        }
                                        if (this.check3rdParty.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num13:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num14:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num15:N0}" + "</td>");
                                        }
                                        if (this.checkBrutoTarra.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num16:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num17:N0}" + "</td>");
                                        }
                                        if (this.cbDeduction.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{(num16 - num17):N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num56:N0}" + "</td>");
                                        }
                                        html.Write("<td nowrap align=right><b>" + $"{num18:N0}" + "</td>");
                                        if (this.checkDiff.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num19:N0}" + "</td>");
                                            if (!(num19 == 0.0))
                                            {
                                                html.Write("<td nowrap align=right><b>" + $"{((num19 / num15) * 100.0):N2}" + "</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td nowrap align=right><b>0.00</td>");
                                            }
                                        }
                                        if (this.checkLoadingQty.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num33:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num34:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + html.strq(pStr) + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num35:N0}" + "</td>");
                                        }
                                        if (this.checkBoxMaterialStuffing.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.cBoxReturInKg.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + num75 + "</td>");
                                        }
                                        if (this.cBoxReturInPack.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + num76 + "</td>");
                                        }
                                        if (this.cBoxLossInKg.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + num77 + "</td>");
                                        }
                                        if (this.cBoxLossInPack.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + num78 + "</td>");
                                        }
                                        if (this.checkSeal.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.checkWBRef.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.cbDL.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            if (num63 > 0.0)
                                            {
                                                html.Write("<td nowrap align=right><b>" + $"{num63:N0}" + "</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td>" + html.strq("") + "</td>");
                                            }
                                            if (num64 > 0.0)
                                            {
                                                html.Write("<td nowrap align=right><b>" + $"{num64:N0}" + "</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td>" + html.strq("") + "</td>");
                                            }
                                        }
                                        if (this.checkRmkTicket.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.checkRmkReport.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.checkCrtBy.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.checkChgBy.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.cBoxWBCode.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            if (WBSetting.Container == "Y")
                                            {
                                                html.Write("<td>" + html.strq("") + "</td>");
                                                html.Write("<td>" + html.strq("") + "</td>");
                                            }
                                        }
                                        if (this.checkGrade.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        html.Write("</tr>");
                                    }
                                }
                                else if (this.rb_mill.Checked)
                                {
                                    if (((str7 != "") || (zValue != "")) || (str9 != ""))
                                    {
                                        html.Write("<tr class='bd'>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        string str33 = str7;
                                        if (str7 == "")
                                        {
                                            str33 = Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", zValue);
                                        }
                                        string[] textArray40 = new string[] { "<td colspan=", num2.ToString(), "><b>Sub Total of ", str33, "</td>" };
                                        html.Write(string.Concat(textArray40));
                                        num62 = Program.StrToDouble($"{num62:N0}", 0);
                                        if (this.checkColly.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num62:N0}" + "</td>");
                                        }
                                        if (this.cbGunny.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num60:N0}" + "</td>");
                                        }
                                        if (this.checkConv.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num20:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>&nbsp</td>");
                                        }
                                        if (this.check3rdParty.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num13:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num14:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num15:N0}" + "</td>");
                                        }
                                        if (this.checkBrutoTarra.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num16:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num17:N0}" + "</td>");
                                        }
                                        if (this.cbDeduction.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{(num16 - num17):N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num56:N0}" + "</td>");
                                        }
                                        html.Write("<td nowrap align=right><b>" + $"{num18:N0}" + "</td>");
                                        if (this.checkDiff.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num19:N0}" + "</td>");
                                            if (!(num19 == 0.0))
                                            {
                                                html.Write("<td nowrap align=right><b>" + $"{((num19 / num15) * 100.0):N2}" + "</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td nowrap align=right><b>0.00</td>");
                                            }
                                        }
                                        if (this.checkLoadingQty.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num33:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num34:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + html.strq(pStr) + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num35:N0}" + "</td>");
                                        }
                                        if (this.checkBoxMaterialStuffing.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.cBoxReturInKg.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + num75 + "</td>");
                                        }
                                        if (this.cBoxReturInPack.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + num76 + "</td>");
                                        }
                                        if (this.cBoxLossInKg.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + num77 + "</td>");
                                        }
                                        if (this.cBoxLossInPack.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + num78 + "</td>");
                                        }
                                        if (this.checkSeal.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.checkWBRef.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.cbDL.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            if (num63 > 0.0)
                                            {
                                                html.Write("<td nowrap align=right><b>" + $"{num63:N0}" + "</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td>" + html.strq("") + "</td>");
                                            }
                                            if (num64 > 0.0)
                                            {
                                                html.Write("<td nowrap align=right><b>" + $"{num64:N0}" + "</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td>" + html.strq("") + "</td>");
                                            }
                                        }
                                        if (this.checkRmkTicket.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.checkRmkReport.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.checkCrtBy.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.checkChgBy.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.cBoxWBCode.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            if (WBSetting.Container == "Y")
                                            {
                                                html.Write("<td>" + html.strq("") + "</td>");
                                                html.Write("<td>" + html.strq("") + "</td>");
                                            }
                                        }
                                        if (this.checkGrade.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        html.Write("</tr>");
                                    }
                                }
                                else if (this.rb_iscc.Checked && ((str10 != "") || (zValue != "")))
                                {
                                    html.Write("<tr class='bd'>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    string str34 = zValue + " (" + Program.getFieldValue("wb_relation", "Relation_Name", "Relation_Code", zValue) + ")";
                                    string[] textArray41 = new string[] { "<td colspan=", num2.ToString(), "><b>Sub Total of Vendor : ", str34, "</td>" };
                                    html.Write(string.Concat(textArray41));
                                    num62 = Program.StrToDouble($"{num62:N0}", 0);
                                    if (this.checkColly.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num62:N0}" + "</td>");
                                    }
                                    if (this.cbGunny.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num60:N0}" + "</td>");
                                    }
                                    if (this.checkConv.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num20:N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>&nbsp</td>");
                                    }
                                    if (this.check3rdParty.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num13:N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>" + $"{num14:N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>" + $"{num15:N0}" + "</td>");
                                    }
                                    if (this.checkBrutoTarra.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num16:N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>" + $"{num17:N0}" + "</td>");
                                    }
                                    if (this.cbDeduction.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{(num16 - num17):N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>" + $"{num56:N0}" + "</td>");
                                    }
                                    html.Write("<td nowrap align=right><b>" + $"{num18:N0}" + "</td>");
                                    if (this.checkDiff.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num19:N0}" + "</td>");
                                        if (!(num19 == 0.0))
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{((num19 / num15) * 100.0):N2}" + "</td>");
                                        }
                                        else
                                        {
                                            html.Write("<td nowrap align=right><b>0.00</td>");
                                        }
                                    }
                                    if (this.checkLoadingQty.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num33:N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>" + $"{num34:N0}" + "</td>");
                                        html.Write("<td nowrap align=right><b>" + html.strq(pStr) + "</td>");
                                        html.Write("<td nowrap align=right><b>" + $"{num35:N0}" + "</td>");
                                    }
                                    if (this.checkBoxMaterialStuffing.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.cBoxReturInKg.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + num75 + "</td>");
                                    }
                                    if (this.cBoxReturInPack.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + num76 + "</td>");
                                    }
                                    if (this.cBoxLossInKg.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + num77 + "</td>");
                                    }
                                    if (this.cBoxLossInPack.Checked)
                                    {
                                        html.Write("<td nowrap align=right><b>" + num78 + "</td>");
                                    }
                                    if (this.checkSeal.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.checkWBRef.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.cbDL.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        if (num63 > 0.0)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num63:N0}" + "</td>");
                                        }
                                        else
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (num64 > 0.0)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num64:N0}" + "</td>");
                                        }
                                        else
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                    }
                                    if (this.checkRmkTicket.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.checkRmkReport.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.checkCrtBy.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.checkChgBy.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (this.cBoxWBCode.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        if (WBSetting.Container == "Y")
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                    }
                                    if (this.checkGrade.Checked)
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    html.Write("</tr>");
                                    if (str10 != "")
                                    {
                                        html.Write("<tr class='bd'>");
                                        string[] textArray42 = new string[] { "<td colspan=", (num2 + 1).ToString(), "><b>Total of Area: ", str10, "</td>" };
                                        html.Write(string.Concat(textArray42));
                                        if (this.checkColly.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num54:N0}" + "</td>");
                                        }
                                        if (this.cbGunny.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num51:N0}" + "</td>");
                                        }
                                        if (this.checkConv.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num28:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>&nbsp</td>");
                                        }
                                        if (this.check3rdParty.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num21:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num22:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num23:N0}" + "</td>");
                                        }
                                        if (this.checkBrutoTarra.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num24:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num25:N0}" + "</td>");
                                        }
                                        if (this.cbDeduction.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{(num24 - num25):N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num58:N0}" + "</td>");
                                        }
                                        html.Write("<td nowrap align=right><b>" + $"{num26:N0}" + "</td>");
                                        if (this.checkDiff.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num27:N0}" + "</td>");
                                            if (!(num19 == 0.0))
                                            {
                                                html.Write("<td nowrap align=right><b>" + $"{((num27 / num23) * 100.0):N2}" + "</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td nowrap align=right><b>0.00</td>");
                                            }
                                        }
                                        if (this.checkLoadingQty.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + $"{num39:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + $"{num40:N0}" + "</td>");
                                            html.Write("<td nowrap align=right><b>" + html.strq(pStr) + "</td>");
                                            html.Write("<td nowrap align=right><b>" + html.strq($"{num41:N0}") + "</td>");
                                        }
                                        if (this.checkBoxMaterialStuffing.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.cBoxReturInKg.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + num83 + "</td>");
                                        }
                                        if (this.cBoxReturInPack.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + num84 + "</td>");
                                        }
                                        if (this.cBoxLossInKg.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + num85 + "</td>");
                                        }
                                        if (this.cBoxLossInPack.Checked)
                                        {
                                            html.Write("<td nowrap align=right><b>" + num86 + "</td>");
                                        }
                                        if (this.checkSeal.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.checkWBRef.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.cbDL.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            if (num63 > 0.0)
                                            {
                                                html.Write("<td nowrap align=right><b>" + $"{num67:N0}" + "</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td>" + html.strq("") + "</td>");
                                            }
                                            if (num64 > 0.0)
                                            {
                                                html.Write("<td nowrap align=right><b>" + $"{num68:N0}" + "</td>");
                                            }
                                            else
                                            {
                                                html.Write("<td>" + html.strq("") + "</td>");
                                            }
                                        }
                                        if (this.checkRmkTicket.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.checkRmkReport.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.checkCrtBy.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.checkChgBy.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        if (this.cBoxWBCode.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            html.Write("<td>" + html.strq("") + "</td>");
                                            if (WBSetting.Container == "Y")
                                            {
                                                html.Write("<td>" + html.strq("") + "</td>");
                                                html.Write("<td>" + html.strq("") + "</td>");
                                            }
                                        }
                                        if (this.checkGrade.Checked)
                                        {
                                            html.Write("<td>" + html.strq("") + "</td>");
                                        }
                                        num21 = 0.0;
                                        num22 = 0.0;
                                        num23 = 0.0;
                                        num83 = 0.0;
                                        num84 = 0.0;
                                        num85 = 0.0;
                                        num86 = 0.0;
                                        num24 = 0.0;
                                        num54 = 0.0;
                                        num25 = 0.0;
                                        num26 = 0.0;
                                        num27 = 0.0;
                                        num39 = 0.0;
                                        num40 = 0.0;
                                        num41 = 0.0;
                                        num51 = 0.0;
                                        num58 = 0.0;
                                        num67 = 0.0;
                                        num68 = 0.0;
                                        num28 = 0.0;
                                        html.Write("</tr>");
                                    }
                                    html.Write("<tr>");
                                    html.Write("<td colspan=" + (((num2 + num3) + num4) + 7).ToString() + ">&nbsp</td>");
                                    html.Write("</tr>");
                                }
                                html.Write("<tr class='bd'>");
                                num2++;
                                html.Write("<td colspan=" + num2.ToString() + "><b>T O T A L</td>");
                                num53 = Program.StrToDouble($"{num53:N0}", 0);
                                if (this.checkColly.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num53:N0}" + "</td>");
                                }
                                if (this.cbGunny.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num50:N0}" + "</td>");
                                }
                                if (this.checkConv.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num12:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>&nbsp</td>");
                                }
                                if (this.check3rdParty.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num5:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num6:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num7:N0}" + "</td>");
                                }
                                if (this.checkBrutoTarra.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num8:N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num9:N0}" + "</td>");
                                }
                                if (this.cbDeduction.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{(num8 - num9):N0}" + "</td>");
                                    html.Write("<td nowrap align=right><b>" + $"{num57:N0}" + "</td>");
                                }
                                html.Write("<td nowrap align=right><b>" + $"{num10:N0}" + "</td>");
                                if (this.checkDiff.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num11:N0}" + "</td></b>");
                                    if (!(num11 == 0.0))
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{((num11 / num7) * 100.0):N2}" + "</td></b>");
                                    }
                                    else
                                    {
                                        html.Write("<td nowrap align=right><b>0.00</td></b>");
                                    }
                                }
                                if (this.checkLoadingQty.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + $"{num36:N0}" + "</td></b>");
                                    html.Write("<td nowrap align=right><b>" + $"{num37:N0}" + "</td></b>");
                                    html.Write("<td nowrap align=right><b>" + html.strq(pStr) + "</td></b>");
                                    html.Write("<td nowrap align=right><b>" + $"{num38:N0}" + "</td></b>");
                                }
                                if (this.checkBoxMaterialStuffing.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.cBoxReturInKg.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num79 + "</td></b>");
                                }
                                if (this.cBoxReturInPack.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num80 + "</td></b>");
                                }
                                if (this.cBoxLossInKg.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num81 + "</td></b>");
                                }
                                if (this.cBoxLossInPack.Checked)
                                {
                                    html.Write("<td nowrap align=right><b>" + num82 + "</td></b>");
                                }
                                if (this.checkSeal.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.checkWBRef.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.cbDL.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    if (num65 > 0.0)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num65:N0}" + "</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                    if (num66 > 0.0)
                                    {
                                        html.Write("<td nowrap align=right><b>" + $"{num66:N0}" + "</td>");
                                    }
                                    else
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                }
                                if (this.checkRmkTicket.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.checkRmkReport.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.checkCrtBy.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.checkChgBy.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                if (this.cBoxWBCode.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    html.Write("<td>" + html.strq("") + "</td>");
                                    if (WBSetting.Container == "Y")
                                    {
                                        html.Write("<td>" + html.strq("") + "</td>");
                                        html.Write("<td>" + html.strq("") + "</td>");
                                    }
                                }
                                if (this.checkGrade.Checked)
                                {
                                    html.Write("<td>" + html.strq("") + "</td>");
                                }
                                html.Write("</tr>");
                                html.Write("</table>");
                                html.Write("<br>");
                                html.Write("<br>");
                                html.writeSign();
                                html.Close();
                                ViewReport report = new ViewReport {
                                    webBrowser1 = { Url = new Uri("file:///" + html.File) }
                                };
                                report.ShowDialog();
                                html.Dispose();
                                report.Dispose();
                                this.labelProses1.Text = "";
                                this.labelProses2.Text = "";
                                this.labelProses1.Visible = false;
                                this.labelProses2.Visible = false;
                                return;
                            }
                            break;
                        }
                        goto TR_02F0;
                    }
                }
                MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.isOk = false;
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFind = this.txt_contract.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.txt_contract.Text = contract.ReturnRow["contract"].ToString();
            }
            contract.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransport.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.textTransport.Focus();
            }
            transporter.Dispose();
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
                this.textCommodity.Focus();
            }
            commodity.Dispose();
        }

        private void buttonDoNo_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFind = this.textDoNo.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDoNo.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        private void buttonDriver_Click(object sender, EventArgs e)
        {
            FormDriver driver = new FormDriver {
                pMode = "CHOOSE"
            };
            driver.ShowDialog();
            if (driver.ReturnRow != null)
            {
                this.textDriver.Text = driver.ReturnRow["License_No"].ToString();
                this.textDriver.Focus();
            }
            driver.Dispose();
        }

        private void buttonStorage_Click(object sender, EventArgs e)
        {
            FormStorage storage = new FormStorage {
                pMode = "CHOOSE"
            };
            storage.ShowDialog();
            if (storage.ReturnRow != null)
            {
                this.textStorage.Text = storage.ReturnRow["Storage_Code"].ToString();
                this.labelStorageName.Text = storage.ReturnRow["Storage_Name"].ToString();
                this.textStorage.Focus();
            }
            storage.Dispose();
        }

        private void buttonTruck_Click(object sender, EventArgs e)
        {
            FormTruck truck = new FormTruck {
                pMode = "CHOOSE",
                pFind = this.textTruck.Text
            };
            truck.ShowDialog();
            if (truck.ReturnRow != null)
            {
                this.textTruck.Text = truck.ReturnRow["Truck_Number"].ToString();
            }
            truck.Dispose();
        }

        private void cBoxAll_CheckedChanged(object sender, EventArgs e)
        {
            if (this.cBoxAll.Checked)
            {
                foreach (Control control in this.panel1.GetOffsprings())
                {
                    if (((control.GetType() == typeof(CheckBox)) && control.Visible) && (((control.Name != "checkDate") && ((control.Name != "chkQstandard") && ((control.Name != "chkNonQ") && ((control.Name != "checkStorage") && (control.Name != "checkBoxTank"))))) && (control.Name != "checkProcess")))
                    {
                        ((CheckBox) control).Checked = true;
                    }
                }
            }
            else
            {
                foreach (Control control2 in this.panel1.GetOffsprings())
                {
                    if (((control2.GetType() == typeof(CheckBox)) && control2.Visible) && (((control2.Name != "checkDate") && ((control2.Name != "chkQstandard") && ((control2.Name != "chkNonQ") && ((control2.Name != "checkStorage") && (control2.Name != "checkBoxTank"))))) && (control2.Name != "checkProcess")))
                    {
                        ((CheckBox) control2).Checked = false;
                    }
                }
            }
        }

        private void checkBoxTank_CheckedChanged(object sender, EventArgs e)
        {
            this.textTank.Visible = this.checkBoxTank.Checked;
        }

        private void checkBrutoTarra_CheckedChanged(object sender, EventArgs e)
        {
            this.cbDeduction.Enabled = true;
            this.cbGunny.Enabled = true;
            if (!this.checkBrutoTarra.Checked)
            {
                this.cbDeduction.Checked = false;
                this.cbGunny.Checked = false;
                this.cbDeduction.Enabled = false;
                this.cbGunny.Enabled = false;
            }
        }

        private void checkDate_CheckedChanged(object sender, EventArgs e)
        {
            this.groupDate.Enabled = this.checkDate.Checked;
        }

        private void checkNot1stYet_CheckedChanged(object sender, EventArgs e)
        {
            this.IncludedCheckbox();
        }

        private void checkProcess_CheckedChanged(object sender, EventArgs e)
        {
            this.IncludedCheckbox();
        }

        private void checkStorage_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkStorage.Checked)
            {
                this.textStorage.Visible = true;
                this.buttonStorage.Visible = true;
                this.labelStorageName.Visible = true;
            }
            else
            {
                this.textStorage.Visible = false;
                this.buttonStorage.Visible = false;
                this.labelStorageName.Visible = false;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void IncludedCheckbox()
        {
            if (!(this.checkProcess.Checked || this.checkNot1stYet.Checked))
            {
                this.checkDate.Enabled = true;
            }
            else
            {
                this.checkDate.Checked = true;
                this.checkDate.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.buttonDoNo = new Button();
            this.labelDoNo = new Label();
            this.checkDate = new CheckBox();
            this.monthCalendar1 = new DateTimePicker();
            this.label1 = new Label();
            this.label2 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.textDoNo = new TextBox();
            this.groupDate = new GroupBox();
            this.TimeTo = new MaskedTextBox();
            this.TimeFrom = new MaskedTextBox();
            this.button2 = new Button();
            this.buttonComm = new Button();
            this.labelCommName = new Label();
            this.textCommodity = new TextBox();
            this.labelcommodity = new Label();
            this.button1 = new Button();
            this.grKB = new GroupBox();
            this.rboKBAll = new RadioButton();
            this.rboNonKB = new RadioButton();
            this.rboKB = new RadioButton();
            this.buttonTransporter = new Button();
            this.label4 = new Label();
            this.textTransport = new TextBox();
            this.grType = new GroupBox();
            this.rboAll = new RadioButton();
            this.rboGI = new RadioButton();
            this.rboGR = new RadioButton();
            this.labelProses2 = new Label();
            this.labelProses1 = new Label();
            this.panel1 = new Panel();
            this.checkTrailerNo = new CheckBox();
            this.checkSO = new CheckBox();
            this.checkRegistrationInOut = new CheckBox();
            this.cBoxReturInPack = new CheckBox();
            this.cBoxReturInKg = new CheckBox();
            this.cBoxLossInPack = new CheckBox();
            this.cBoxLossInKg = new CheckBox();
            this.checkSourceDesc = new CheckBox();
            this.checkSourceCode = new CheckBox();
            this.cb_interval34 = new CheckBox();
            this.cb_interval12 = new CheckBox();
            this.checkGrade = new CheckBox();
            this.cb_tank = new CheckBox();
            this.checkBoxGatepassNumber = new CheckBox();
            this.cBoxWBCode = new CheckBox();
            this.cb_internal_no = new CheckBox();
            this.cb_do_sap = new CheckBox();
            this.cBoxYellowPlate = new CheckBox();
            this.cBoxDiffHour = new CheckBox();
            this.cBoxTransName = new CheckBox();
            this.cBoxCommName = new CheckBox();
            this.checkLoadingQty = new CheckBox();
            this.checkBoxMaterialStuffing = new CheckBox();
            this.cBoxPISI = new CheckBox();
            this.cbAddInfo = new CheckBox();
            this.checkChgBy = new CheckBox();
            this.checkCrtBy = new CheckBox();
            this.checkQSt = new CheckBox();
            this.checkRelationName = new CheckBox();
            this.cbDL = new CheckBox();
            this.checkColly = new CheckBox();
            this.checkContract = new CheckBox();
            this.cbGunny = new CheckBox();
            this.cbDeduction = new CheckBox();
            this.checkAutomated = new CheckBox();
            this.checkWBRef = new CheckBox();
            this.checkConv = new CheckBox();
            this.checkSeal = new CheckBox();
            this.checkRmkReport = new CheckBox();
            this.checkRmkTicket = new CheckBox();
            this.checkDiff = new CheckBox();
            this.checkBrutoTarra = new CheckBox();
            this.check3rdParty = new CheckBox();
            this.checkTransporter = new CheckBox();
            this.checkDeliNote = new CheckBox();
            this.checkDriverName = new CheckBox();
            this.checkLicenseNo = new CheckBox();
            this.checkEstate = new CheckBox();
            this.checkRelation = new CheckBox();
            this.check1xDO = new CheckBox();
            this.check1xSTO = new CheckBox();
            this.checkPO = new CheckBox();
            this.checkSTO = new CheckBox();
            this.checkDO_No = new CheckBox();
            this.checkDelivery = new CheckBox();
            this.label3 = new Label();
            this.buttonStorage = new Button();
            this.textStorage = new TextBox();
            this.labelStorageName = new Label();
            this.checkStorage = new CheckBox();
            this.checkProcess = new CheckBox();
            this.label7 = new Label();
            this.textTruck = new TextBox();
            this.buttonTruck = new Button();
            this.textTank = new TextBox();
            this.checkBoxTank = new CheckBox();
            this.buttonDriver = new Button();
            this.label5 = new Label();
            this.textDriver = new TextBox();
            this.comboComm = new ComboBox();
            this.txtqstandard = new TextBox();
            this.btnQstandard = new Button();
            this.chkQstandard = new CheckBox();
            this.chkNonQ = new CheckBox();
            this.ComboIscc = new ComboBox();
            this.labelQStandard = new Label();
            this.statusStrip1 = new StatusStrip();
            this.cBoxAll = new CheckBox();
            this.txt_ref = new TextBox();
            this.label6 = new Label();
            this.gb_grouping = new GroupBox();
            this.rb_iscc = new RadioButton();
            this.rb_none = new RadioButton();
            this.rb_mill = new RadioButton();
            this.rb_comm = new RadioButton();
            this.txt_mill = new TextBox();
            this.label8 = new Label();
            this.sh_mill = new Button();
            this.label9 = new Label();
            this.txt_contract = new TextBox();
            this.button3 = new Button();
            this.checkNot1stYet = new CheckBox();
            this.groupDate.SuspendLayout();
            this.grKB.SuspendLayout();
            this.grType.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gb_grouping.SuspendLayout();
            base.SuspendLayout();
            this.buttonDoNo.Location = new Point(0x11b, 0xd4);
            this.buttonDoNo.Margin = new Padding(0);
            this.buttonDoNo.Name = "buttonDoNo";
            this.buttonDoNo.Size = new Size(0x17, 0x17);
            this.buttonDoNo.TabIndex = 8;
            this.buttonDoNo.Text = "...";
            this.buttonDoNo.UseVisualStyleBackColor = true;
            this.buttonDoNo.Click += new EventHandler(this.buttonDoNo_Click);
            this.labelDoNo.AutoSize = true;
            this.labelDoNo.Location = new Point(0x34, 0xd9);
            this.labelDoNo.Name = "labelDoNo";
            this.labelDoNo.Size = new Size(0x26, 13);
            this.labelDoNo.TabIndex = 0x22;
            this.labelDoNo.Text = "Do No";
            this.checkDate.AutoSize = true;
            this.checkDate.Checked = true;
            this.checkDate.CheckState = CheckState.Checked;
            this.checkDate.Location = new Point(0x2b, 0x5f);
            this.checkDate.Name = "checkDate";
            this.checkDate.Size = new Size(60, 0x11);
            this.checkDate.TabIndex = 0x21;
            this.checkDate.Text = "byDate";
            this.checkDate.UseVisualStyleBackColor = true;
            this.checkDate.CheckedChanged += new EventHandler(this.checkDate_CheckedChanged);
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x54, 15);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(12, 0x13);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3e, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "From Date :";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0xf2, 0x13);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x34, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "To Date :";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(300, 15);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 1;
            this.textDoNo.CharacterCasing = CharacterCasing.Upper;
            this.textDoNo.Location = new Point(100, 0xd6);
            this.textDoNo.Name = "textDoNo";
            this.textDoNo.Size = new Size(180, 20);
            this.textDoNo.TabIndex = 3;
            this.textDoNo.KeyPress += new KeyPressEventHandler(this.textDoNo_KeyPress);
            this.textDoNo.Leave += new EventHandler(this.textDoNo_Leave);
            this.groupDate.Controls.Add(this.TimeTo);
            this.groupDate.Controls.Add(this.TimeFrom);
            this.groupDate.Controls.Add(this.monthCalendar1);
            this.groupDate.Controls.Add(this.label1);
            this.groupDate.Controls.Add(this.label2);
            this.groupDate.Controls.Add(this.monthCalendar2);
            this.groupDate.Location = new Point(0x1b, 0x6b);
            this.groupDate.Name = "groupDate";
            this.groupDate.Size = new Size(0x1d9, 0x2b);
            this.groupDate.TabIndex = 1;
            this.groupDate.TabStop = false;
            this.TimeTo.Location = new Point(0x19b, 15);
            this.TimeTo.Mask = "00:00";
            this.TimeTo.Name = "TimeTo";
            this.TimeTo.Size = new Size(0x29, 20);
            this.TimeTo.TabIndex = 0x45;
            this.TimeTo.ValidatingType = typeof(DateTime);
            this.TimeFrom.Location = new Point(0xc3, 15);
            this.TimeFrom.Mask = "00:00";
            this.TimeFrom.Name = "TimeFrom";
            this.TimeFrom.Size = new Size(0x24, 20);
            this.TimeFrom.TabIndex = 0x44;
            this.TimeFrom.ValidatingType = typeof(DateTime);
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x254, 0x60);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x22);
            this.button2.TabIndex = 6;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.buttonComm.Location = new Point(0x11b, 0xba);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 7;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.labelCommName.AutoSize = true;
            this.labelCommName.Location = new Point(0x135, 0xbf);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x3a, 13);
            this.labelCommName.TabIndex = 0x1b;
            this.labelCommName.Text = "Commodity";
            this.textCommodity.CharacterCasing = CharacterCasing.Upper;
            this.textCommodity.Location = new Point(100, 0xbb);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(180, 20);
            this.textCommodity.TabIndex = 2;
            this.textCommodity.KeyPress += new KeyPressEventHandler(this.textCommodity_KeyPress);
            this.textCommodity.Leave += new EventHandler(this.textCommodity_Leave);
            this.textCommodity.MouseDoubleClick += new MouseEventHandler(this.textCommodity_MouseDoubleClick);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x24, 0xbd);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3a, 13);
            this.labelcommodity.TabIndex = 0x19;
            this.labelcommodity.Text = "Commodity";
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x254, 0x35);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x22);
            this.button1.TabIndex = 5;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.grKB.Controls.Add(this.rboKBAll);
            this.grKB.Controls.Add(this.rboNonKB);
            this.grKB.Controls.Add(this.rboKB);
            this.grKB.Location = new Point(0x148, 0x29);
            this.grKB.Name = "grKB";
            this.grKB.Size = new Size(0xc7, 0x2d);
            this.grKB.TabIndex = 1;
            this.grKB.TabStop = false;
            this.grKB.Text = "KB / Non KB";
            this.rboKBAll.AutoSize = true;
            this.rboKBAll.Location = new Point(0x11, 0x12);
            this.rboKBAll.Name = "rboKBAll";
            this.rboKBAll.Size = new Size(0x24, 0x11);
            this.rboKBAll.TabIndex = 0x7d;
            this.rboKBAll.Text = "All";
            this.rboKBAll.UseVisualStyleBackColor = true;
            this.rboNonKB.AutoSize = true;
            this.rboNonKB.Location = new Point(0x7e, 0x12);
            this.rboNonKB.Name = "rboNonKB";
            this.rboNonKB.Size = new Size(60, 0x11);
            this.rboNonKB.TabIndex = 0x11;
            this.rboNonKB.TabStop = true;
            this.rboNonKB.Text = "non KB";
            this.rboNonKB.UseVisualStyleBackColor = true;
            this.rboKB.AutoSize = true;
            this.rboKB.Location = new Point(70, 0x12);
            this.rboKB.Name = "rboKB";
            this.rboKB.Size = new Size(0x27, 0x11);
            this.rboKB.TabIndex = 0x10;
            this.rboKB.TabStop = true;
            this.rboKB.Text = "KB";
            this.rboKB.UseVisualStyleBackColor = true;
            this.buttonTransporter.Location = new Point(0x11b, 0xef);
            this.buttonTransporter.Margin = new Padding(0);
            this.buttonTransporter.Name = "buttonTransporter";
            this.buttonTransporter.Size = new Size(0x17, 0x17);
            this.buttonTransporter.TabIndex = 9;
            this.buttonTransporter.Text = "...";
            this.buttonTransporter.UseVisualStyleBackColor = true;
            this.buttonTransporter.Click += new EventHandler(this.button4_Click);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x1f, 0xf4);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x3d, 13);
            this.label4.TabIndex = 0x2c;
            this.label4.Text = "Transporter";
            this.textTransport.CharacterCasing = CharacterCasing.Upper;
            this.textTransport.Location = new Point(100, 0xf1);
            this.textTransport.Name = "textTransport";
            this.textTransport.Size = new Size(180, 20);
            this.textTransport.TabIndex = 4;
            this.textTransport.KeyPress += new KeyPressEventHandler(this.textTransport_KeyPress);
            this.textTransport.Leave += new EventHandler(this.textTransport_Leave);
            this.grType.Controls.Add(this.rboAll);
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x1b, 0x29);
            this.grType.Name = "grType";
            this.grType.Size = new Size(0x11a, 0x2d);
            this.grType.TabIndex = 0;
            this.grType.TabStop = false;
            this.grType.Text = "Report Type";
            this.rboAll.AutoSize = true;
            this.rboAll.Location = new Point(0x12, 0x12);
            this.rboAll.Name = "rboAll";
            this.rboAll.Size = new Size(0x24, 0x11);
            this.rboAll.TabIndex = 0x7c;
            this.rboAll.Text = "All";
            this.rboAll.UseVisualStyleBackColor = true;
            this.rboAll.CheckedChanged += new EventHandler(this.rboAll_CheckedChanged);
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(0xba, 0x12);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 0x11;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.rboGI.CheckedChanged += new EventHandler(this.rboGI_CheckedChanged);
            this.rboGI.TextChanged += new EventHandler(this.rboGI_TextChanged);
            this.rboGR.AutoSize = true;
            this.rboGR.Checked = true;
            this.rboGR.Location = new Point(0x49, 0x12);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0x10;
            this.rboGR.TabStop = true;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            this.rboGR.CheckedChanged += new EventHandler(this.rboGR_CheckedChanged);
            this.rboGR.TextChanged += new EventHandler(this.rboGR_TextChanged);
            this.labelProses2.AutoSize = true;
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(500, 0x16);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0xd6, 13);
            this.labelProses2.TabIndex = 0x2e;
            this.labelProses2.Text = "Progresssss . . . . . . . . . . . . . . . . . ";
            this.labelProses1.AutoSize = true;
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(0x28b, 9);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0x37, 13);
            this.labelProses1.TabIndex = 0x2f;
            this.labelProses1.Text = "1/88888";
            this.panel1.BorderStyle = BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.checkTrailerNo);
            this.panel1.Controls.Add(this.checkSO);
            this.panel1.Controls.Add(this.checkRegistrationInOut);
            this.panel1.Controls.Add(this.cBoxReturInPack);
            this.panel1.Controls.Add(this.cBoxReturInKg);
            this.panel1.Controls.Add(this.cBoxLossInPack);
            this.panel1.Controls.Add(this.cBoxLossInKg);
            this.panel1.Controls.Add(this.checkSourceDesc);
            this.panel1.Controls.Add(this.checkSourceCode);
            this.panel1.Controls.Add(this.cb_interval34);
            this.panel1.Controls.Add(this.cb_interval12);
            this.panel1.Controls.Add(this.checkGrade);
            this.panel1.Controls.Add(this.cb_tank);
            this.panel1.Controls.Add(this.checkBoxGatepassNumber);
            this.panel1.Controls.Add(this.cBoxWBCode);
            this.panel1.Controls.Add(this.cb_internal_no);
            this.panel1.Controls.Add(this.cb_do_sap);
            this.panel1.Controls.Add(this.cBoxYellowPlate);
            this.panel1.Controls.Add(this.cBoxDiffHour);
            this.panel1.Controls.Add(this.cBoxTransName);
            this.panel1.Controls.Add(this.cBoxCommName);
            this.panel1.Controls.Add(this.checkLoadingQty);
            this.panel1.Controls.Add(this.checkBoxMaterialStuffing);
            this.panel1.Controls.Add(this.cBoxPISI);
            this.panel1.Controls.Add(this.cbAddInfo);
            this.panel1.Controls.Add(this.checkChgBy);
            this.panel1.Controls.Add(this.checkCrtBy);
            this.panel1.Controls.Add(this.checkQSt);
            this.panel1.Controls.Add(this.checkRelationName);
            this.panel1.Controls.Add(this.cbDL);
            this.panel1.Controls.Add(this.checkColly);
            this.panel1.Controls.Add(this.checkContract);
            this.panel1.Controls.Add(this.cbGunny);
            this.panel1.Controls.Add(this.cbDeduction);
            this.panel1.Controls.Add(this.checkAutomated);
            this.panel1.Controls.Add(this.checkWBRef);
            this.panel1.Controls.Add(this.checkConv);
            this.panel1.Controls.Add(this.checkSeal);
            this.panel1.Controls.Add(this.checkRmkReport);
            this.panel1.Controls.Add(this.checkRmkTicket);
            this.panel1.Controls.Add(this.checkDiff);
            this.panel1.Controls.Add(this.checkBrutoTarra);
            this.panel1.Controls.Add(this.check3rdParty);
            this.panel1.Controls.Add(this.checkTransporter);
            this.panel1.Controls.Add(this.checkDeliNote);
            this.panel1.Controls.Add(this.checkDriverName);
            this.panel1.Controls.Add(this.checkLicenseNo);
            this.panel1.Controls.Add(this.checkEstate);
            this.panel1.Controls.Add(this.checkRelation);
            this.panel1.Controls.Add(this.check1xDO);
            this.panel1.Controls.Add(this.check1xSTO);
            this.panel1.Controls.Add(this.checkPO);
            this.panel1.Controls.Add(this.checkSTO);
            this.panel1.Controls.Add(this.checkDO_No);
            this.panel1.Controls.Add(this.checkDelivery);
            this.panel1.Location = new Point(0x1b, 0x19c);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x2a7, 0x116);
            this.panel1.TabIndex = 0x30;
            this.checkTrailerNo.AutoSize = true;
            this.checkTrailerNo.Location = new Point(0x225, 0xff);
            this.checkTrailerNo.Name = "checkTrailerNo";
            this.checkTrailerNo.Size = new Size(0x48, 0x11);
            this.checkTrailerNo.TabIndex = 0xba;
            this.checkTrailerNo.Text = "Trailer No";
            this.checkTrailerNo.UseVisualStyleBackColor = true;
            this.checkSO.AutoSize = true;
            this.checkSO.Location = new Point(0x11, 0x67);
            this.checkSO.Name = "checkSO";
            this.checkSO.Size = new Size(0x3d, 0x11);
            this.checkSO.TabIndex = 0xb9;
            this.checkSO.Text = "SO No.";
            this.checkSO.UseVisualStyleBackColor = true;
            this.checkRegistrationInOut.AutoSize = true;
            this.checkRegistrationInOut.Location = new Point(0xbf, 0xed);
            this.checkRegistrationInOut.Name = "checkRegistrationInOut";
            this.checkRegistrationInOut.Size = new Size(0x7b, 0x11);
            this.checkRegistrationInOut.TabIndex = 0x2f;
            this.checkRegistrationInOut.Text = "Registration In && Out";
            this.checkRegistrationInOut.TextAlign = ContentAlignment.MiddleCenter;
            this.checkRegistrationInOut.UseVisualStyleBackColor = true;
            this.cBoxReturInPack.AutoSize = true;
            this.cBoxReturInPack.Location = new Point(0x11, 0xff);
            this.cBoxReturInPack.Name = "cBoxReturInPack";
            this.cBoxReturInPack.Size = new Size(0x61, 0x11);
            this.cBoxReturInPack.TabIndex = 0xb8;
            this.cBoxReturInPack.Text = "Return in Pack";
            this.cBoxReturInPack.UseVisualStyleBackColor = true;
            this.cBoxReturInKg.AutoSize = true;
            this.cBoxReturInKg.Location = new Point(0x11, 0xec);
            this.cBoxReturInKg.Name = "cBoxReturInKg";
            this.cBoxReturInKg.Size = new Size(0x57, 0x11);
            this.cBoxReturInKg.TabIndex = 0xb7;
            this.cBoxReturInKg.Text = "Return in KG";
            this.cBoxReturInKg.UseVisualStyleBackColor = true;
            this.cBoxLossInPack.AutoSize = true;
            this.cBoxLossInPack.Location = new Point(0x150, 0xc6);
            this.cBoxLossInPack.Name = "cBoxLossInPack";
            this.cBoxLossInPack.Size = new Size(0x57, 0x11);
            this.cBoxLossInPack.TabIndex = 0xb5;
            this.cBoxLossInPack.Text = "Loss in Pack";
            this.cBoxLossInPack.UseVisualStyleBackColor = true;
            this.cBoxLossInKg.AutoSize = true;
            this.cBoxLossInKg.Location = new Point(0x150, 0xb3);
            this.cBoxLossInKg.Name = "cBoxLossInKg";
            this.cBoxLossInKg.Size = new Size(0x4d, 0x11);
            this.cBoxLossInKg.TabIndex = 0xb6;
            this.cBoxLossInKg.Text = "Loss in KG";
            this.cBoxLossInKg.UseVisualStyleBackColor = true;
            this.checkSourceDesc.AutoSize = true;
            this.checkSourceDesc.Location = new Point(0x225, 0xec);
            this.checkSourceDesc.Name = "checkSourceDesc";
            this.checkSourceDesc.Size = new Size(0x76, 0x11);
            this.checkSourceDesc.TabIndex = 0x2a;
            this.checkSourceDesc.Text = "Source/Dest Desc.";
            this.checkSourceDesc.UseVisualStyleBackColor = true;
            this.checkSourceCode.AutoSize = true;
            this.checkSourceCode.Location = new Point(0x225, 0xd9);
            this.checkSourceCode.Name = "checkSourceCode";
            this.checkSourceCode.Size = new Size(0x73, 0x11);
            this.checkSourceCode.TabIndex = 0x29;
            this.checkSourceCode.Text = "Source/Dest Code";
            this.checkSourceCode.UseVisualStyleBackColor = true;
            this.cb_interval34.AutoSize = true;
            this.cb_interval34.Location = new Point(0x150, 0xec);
            this.cb_interval34.Name = "cb_interval34";
            this.cb_interval34.Size = new Size(0xd3, 0x11);
            this.cb_interval34.TabIndex = 0x2e;
            this.cb_interval34.Text = "Interval barrier gate for 3rd && 4th weight";
            this.cb_interval34.UseVisualStyleBackColor = true;
            this.cb_interval12.AutoSize = true;
            this.cb_interval12.Location = new Point(0x150, 0xd9);
            this.cb_interval12.Name = "cb_interval12";
            this.cb_interval12.Size = new Size(0xd5, 0x11);
            this.cb_interval12.TabIndex = 0x2d;
            this.cb_interval12.Text = "Interval barrier gate for 1st && 2nd weight";
            this.cb_interval12.UseVisualStyleBackColor = true;
            this.checkGrade.AutoSize = true;
            this.checkGrade.Location = new Point(0xbf, 0xff);
            this.checkGrade.Name = "checkGrade";
            this.checkGrade.Size = new Size(0x4d, 0x11);
            this.checkGrade.TabIndex = 0x2c;
            this.checkGrade.Text = "FFB Grade";
            this.checkGrade.UseVisualStyleBackColor = true;
            this.cb_tank.AutoSize = true;
            this.cb_tank.Location = new Point(0xbf, 0xd9);
            this.cb_tank.Name = "cb_tank";
            this.cb_tank.Size = new Size(0x33, 0x11);
            this.cb_tank.TabIndex = 0x2b;
            this.cb_tank.Text = "Tank";
            this.cb_tank.UseVisualStyleBackColor = true;
            this.checkBoxGatepassNumber.AutoSize = true;
            this.checkBoxGatepassNumber.Location = new Point(0x225, 0xc6);
            this.checkBoxGatepassNumber.Name = "checkBoxGatepassNumber";
            this.checkBoxGatepassNumber.Size = new Size(0x6f, 0x11);
            this.checkBoxGatepassNumber.TabIndex = 0x2b;
            this.checkBoxGatepassNumber.Text = "Gatepass Number";
            this.checkBoxGatepassNumber.UseVisualStyleBackColor = true;
            this.cBoxWBCode.AutoSize = true;
            this.cBoxWBCode.Location = new Point(0x225, 0x54);
            this.cBoxWBCode.Name = "cBoxWBCode";
            this.cBoxWBCode.Size = new Size(0x48, 0x11);
            this.cBoxWBCode.TabIndex = 40;
            this.cBoxWBCode.Text = "WB Code";
            this.cBoxWBCode.UseVisualStyleBackColor = true;
            this.cb_internal_no.AutoSize = true;
            this.cb_internal_no.Location = new Point(0x225, 0x8d);
            this.cb_internal_no.Name = "cb_internal_no";
            this.cb_internal_no.Size = new Size(0x4e, 0x11);
            this.cb_internal_no.TabIndex = 0x27;
            this.cb_internal_no.Text = "Internal No";
            this.cb_internal_no.UseVisualStyleBackColor = true;
            this.cb_do_sap.AutoSize = true;
            this.cb_do_sap.Location = new Point(0x225, 0x7a);
            this.cb_do_sap.Name = "cb_do_sap";
            this.cb_do_sap.Size = new Size(0x42, 0x11);
            this.cb_do_sap.TabIndex = 0x26;
            this.cb_do_sap.Text = "DO SAP";
            this.cb_do_sap.UseVisualStyleBackColor = true;
            this.cBoxYellowPlate.AutoSize = true;
            this.cBoxYellowPlate.Location = new Point(0x11, 0xd9);
            this.cBoxYellowPlate.Name = "cBoxYellowPlate";
            this.cBoxYellowPlate.Size = new Size(0x7a, 0x11);
            this.cBoxYellowPlate.TabIndex = 0x25;
            this.cBoxYellowPlate.Text = "Vehicle Yellow Plate";
            this.cBoxYellowPlate.UseVisualStyleBackColor = true;
            this.cBoxDiffHour.AutoSize = true;
            this.cBoxDiffHour.Location = new Point(0x150, 0x54);
            this.cBoxDiffHour.Name = "cBoxDiffHour";
            this.cBoxDiffHour.Size = new Size(90, 0x11);
            this.cBoxDiffHour.TabIndex = 0x24;
            this.cBoxDiffHour.Text = "Different hour";
            this.cBoxDiffHour.UseVisualStyleBackColor = true;
            this.cBoxTransName.AutoSize = true;
            this.cBoxTransName.Location = new Point(0xbf, 0x8d);
            this.cBoxTransName.Name = "cBoxTransName";
            this.cBoxTransName.Size = new Size(0x6f, 0x11);
            this.cBoxTransName.TabIndex = 0x23;
            this.cBoxTransName.Text = "Transporter Name";
            this.cBoxTransName.UseVisualStyleBackColor = true;
            this.cBoxCommName.AutoSize = true;
            this.cBoxCommName.Location = new Point(0x150, 8);
            this.cBoxCommName.Name = "cBoxCommName";
            this.cBoxCommName.Size = new Size(0x6c, 0x11);
            this.cBoxCommName.TabIndex = 0x22;
            this.cBoxCommName.Text = "Commodity Name";
            this.cBoxCommName.UseVisualStyleBackColor = true;
            this.checkLoadingQty.AutoSize = true;
            this.checkLoadingQty.Location = new Point(0x225, 8);
            this.checkLoadingQty.Name = "checkLoadingQty";
            this.checkLoadingQty.Size = new Size(0x6a, 0x11);
            this.checkLoadingQty.TabIndex = 0x21;
            this.checkLoadingQty.Text = "Loading Quantity";
            this.checkLoadingQty.UseVisualStyleBackColor = true;
            this.checkBoxMaterialStuffing.AutoSize = true;
            this.checkBoxMaterialStuffing.Location = new Point(0x225, 0x1b);
            this.checkBoxMaterialStuffing.Name = "checkBoxMaterialStuffing";
            this.checkBoxMaterialStuffing.Size = new Size(0x66, 0x11);
            this.checkBoxMaterialStuffing.TabIndex = 0x20;
            this.checkBoxMaterialStuffing.Text = "Material Stuffing";
            this.checkBoxMaterialStuffing.UseVisualStyleBackColor = true;
            this.cBoxPISI.AutoSize = true;
            this.cBoxPISI.Location = new Point(0x225, 0x41);
            this.cBoxPISI.Name = "cBoxPISI";
            this.cBoxPISI.Size = new Size(0x4a, 0x11);
            this.cBoxPISI.TabIndex = 0x1f;
            this.cBoxPISI.Text = "PI / SI No";
            this.cBoxPISI.UseVisualStyleBackColor = true;
            this.cbAddInfo.AutoSize = true;
            this.cbAddInfo.Location = new Point(0x225, 0x2e);
            this.cbAddInfo.Name = "cbAddInfo";
            this.cbAddInfo.Size = new Size(0x5d, 0x11);
            this.cbAddInfo.TabIndex = 30;
            this.cbAddInfo.Text = "Additional Info";
            this.cbAddInfo.UseVisualStyleBackColor = true;
            this.checkChgBy.AutoSize = true;
            this.checkChgBy.Location = new Point(0x150, 160);
            this.checkChgBy.Name = "checkChgBy";
            this.checkChgBy.Size = new Size(0x4e, 0x11);
            this.checkChgBy.TabIndex = 0x1d;
            this.checkChgBy.Text = "Change By";
            this.checkChgBy.UseVisualStyleBackColor = true;
            this.checkCrtBy.AutoSize = true;
            this.checkCrtBy.Location = new Point(0xbf, 0xc6);
            this.checkCrtBy.Name = "checkCrtBy";
            this.checkCrtBy.Size = new Size(0x48, 0x11);
            this.checkCrtBy.TabIndex = 0x1c;
            this.checkCrtBy.Text = "Create By";
            this.checkCrtBy.UseVisualStyleBackColor = true;
            this.checkQSt.AutoSize = true;
            this.checkQSt.Location = new Point(0x11, 0xc6);
            this.checkQSt.Name = "checkQSt";
            this.checkQSt.Size = new Size(80, 0x11);
            this.checkQSt.TabIndex = 0x1b;
            this.checkQSt.Text = "Q.Standard";
            this.checkQSt.UseVisualStyleBackColor = true;
            this.checkRelationName.AutoSize = true;
            this.checkRelationName.Location = new Point(0xbf, 0x1b);
            this.checkRelationName.Name = "checkRelationName";
            this.checkRelationName.Size = new Size(0x60, 0x11);
            this.checkRelationName.TabIndex = 0x1a;
            this.checkRelationName.Text = "Relation Name";
            this.checkRelationName.UseVisualStyleBackColor = true;
            this.cbDL.AutoSize = true;
            this.cbDL.Location = new Point(0x225, 0x67);
            this.cbDL.Name = "cbDL";
            this.cbDL.Size = new Size(0x5e, 0x11);
            this.cbDL.TabIndex = 0x19;
            this.cbDL.Text = "Delivery Letter";
            this.cbDL.UseVisualStyleBackColor = true;
            this.checkColly.AutoSize = true;
            this.checkColly.Location = new Point(0xbf, 0xb3);
            this.checkColly.Name = "checkColly";
            this.checkColly.Size = new Size(0x4f, 0x11);
            this.checkColly.TabIndex = 0x18;
            this.checkColly.Text = "Colly Copra";
            this.checkColly.UseVisualStyleBackColor = true;
            this.checkContract.AutoSize = true;
            this.checkContract.Checked = true;
            this.checkContract.CheckState = CheckState.Checked;
            this.checkContract.Location = new Point(0x11, 0x2e);
            this.checkContract.Name = "checkContract";
            this.checkContract.Size = new Size(0x56, 0x11);
            this.checkContract.TabIndex = 0x17;
            this.checkContract.Text = "Contract No.";
            this.checkContract.UseVisualStyleBackColor = true;
            this.cbGunny.AutoSize = true;
            this.cbGunny.Location = new Point(0xbf, 160);
            this.cbGunny.Name = "cbGunny";
            this.cbGunny.Size = new Size(0x39, 0x11);
            this.cbGunny.TabIndex = 0x16;
            this.cbGunny.Text = "Gunny";
            this.cbGunny.UseVisualStyleBackColor = true;
            this.cbDeduction.AutoSize = true;
            this.cbDeduction.Location = new Point(0x150, 0x8d);
            this.cbDeduction.Name = "cbDeduction";
            this.cbDeduction.Size = new Size(0x4b, 0x11);
            this.cbDeduction.TabIndex = 0x15;
            this.cbDeduction.Text = "Deduction";
            this.cbDeduction.UseVisualStyleBackColor = true;
            this.checkAutomated.AutoSize = true;
            this.checkAutomated.Location = new Point(0x150, 0x7a);
            this.checkAutomated.Name = "checkAutomated";
            this.checkAutomated.Size = new Size(0x88, 0x11);
            this.checkAutomated.TabIndex = 20;
            this.checkAutomated.Text = "Automated Transaction";
            this.checkAutomated.UseVisualStyleBackColor = true;
            this.checkWBRef.AutoSize = true;
            this.checkWBRef.Location = new Point(0x11, 0xb3);
            this.checkWBRef.Name = "checkWBRef";
            this.checkWBRef.Size = new Size(0x61, 0x11);
            this.checkWBRef.TabIndex = 0x13;
            this.checkWBRef.Text = "WB Ref Estate";
            this.checkWBRef.UseVisualStyleBackColor = true;
            this.checkConv.AutoSize = true;
            this.checkConv.Location = new Point(0x11, 160);
            this.checkConv.Name = "checkConv";
            this.checkConv.Size = new Size(0x83, 0x11);
            this.checkConv.TabIndex = 0x12;
            this.checkConv.Text = "Commodity Convertion";
            this.checkConv.UseVisualStyleBackColor = true;
            this.checkSeal.AutoSize = true;
            this.checkSeal.Location = new Point(0x150, 0x67);
            this.checkSeal.Name = "checkSeal";
            this.checkSeal.Size = new Size(0x35, 0x11);
            this.checkSeal.TabIndex = 0x11;
            this.checkSeal.Text = "SEAL";
            this.checkSeal.UseVisualStyleBackColor = true;
            this.checkRmkReport.AutoSize = true;
            this.checkRmkReport.Checked = true;
            this.checkRmkReport.CheckState = CheckState.Checked;
            this.checkRmkReport.Location = new Point(0x225, 0xb3);
            this.checkRmkReport.Name = "checkRmkReport";
            this.checkRmkReport.Size = new Size(0x71, 0x11);
            this.checkRmkReport.TabIndex = 0x10;
            this.checkRmkReport.Text = "Remark for Report";
            this.checkRmkReport.UseVisualStyleBackColor = true;
            this.checkRmkTicket.AutoSize = true;
            this.checkRmkTicket.Checked = true;
            this.checkRmkTicket.CheckState = CheckState.Checked;
            this.checkRmkTicket.Location = new Point(0x225, 160);
            this.checkRmkTicket.Name = "checkRmkTicket";
            this.checkRmkTicket.Size = new Size(0x6f, 0x11);
            this.checkRmkTicket.TabIndex = 15;
            this.checkRmkTicket.Text = "Remark for Ticket";
            this.checkRmkTicket.UseVisualStyleBackColor = true;
            this.checkDiff.AutoSize = true;
            this.checkDiff.Checked = true;
            this.checkDiff.CheckState = CheckState.Checked;
            this.checkDiff.Location = new Point(0x150, 0x41);
            this.checkDiff.Name = "checkDiff";
            this.checkDiff.Size = new Size(0x42, 0x11);
            this.checkDiff.TabIndex = 14;
            this.checkDiff.Text = "Different";
            this.checkDiff.UseVisualStyleBackColor = true;
            this.checkBrutoTarra.AutoSize = true;
            this.checkBrutoTarra.Checked = true;
            this.checkBrutoTarra.CheckState = CheckState.Checked;
            this.checkBrutoTarra.Location = new Point(0x150, 0x2e);
            this.checkBrutoTarra.Name = "checkBrutoTarra";
            this.checkBrutoTarra.Size = new Size(0x56, 0x11);
            this.checkBrutoTarra.TabIndex = 13;
            this.checkBrutoTarra.Text = "Gross / Tare";
            this.checkBrutoTarra.UseVisualStyleBackColor = true;
            this.checkBrutoTarra.CheckedChanged += new EventHandler(this.checkBrutoTarra_CheckedChanged);
            this.check3rdParty.AutoSize = true;
            this.check3rdParty.Checked = true;
            this.check3rdParty.CheckState = CheckState.Checked;
            this.check3rdParty.Location = new Point(0x150, 0x1b);
            this.check3rdParty.Name = "check3rdParty";
            this.check3rdParty.Size = new Size(0xb3, 0x11);
            this.check3rdParty.TabIndex = 12;
            this.check3rdParty.Text = "Other Party Quantity (Estate Qty)";
            this.check3rdParty.UseVisualStyleBackColor = true;
            this.checkTransporter.AutoSize = true;
            this.checkTransporter.Location = new Point(0xbf, 0x7a);
            this.checkTransporter.Name = "checkTransporter";
            this.checkTransporter.Size = new Size(80, 0x11);
            this.checkTransporter.TabIndex = 11;
            this.checkTransporter.Text = "Transporter";
            this.checkTransporter.UseVisualStyleBackColor = true;
            this.checkDeliNote.AutoSize = true;
            this.checkDeliNote.Location = new Point(0xbf, 0x67);
            this.checkDeliNote.Name = "checkDeliNote";
            this.checkDeliNote.Size = new Size(90, 0x11);
            this.checkDeliNote.TabIndex = 10;
            this.checkDeliNote.Text = "Delivery Note";
            this.checkDeliNote.UseVisualStyleBackColor = true;
            this.checkDriverName.AutoSize = true;
            this.checkDriverName.Checked = true;
            this.checkDriverName.CheckState = CheckState.Checked;
            this.checkDriverName.Location = new Point(0xbf, 0x54);
            this.checkDriverName.Name = "checkDriverName";
            this.checkDriverName.Size = new Size(0x55, 0x11);
            this.checkDriverName.TabIndex = 9;
            this.checkDriverName.Text = "Driver Name";
            this.checkDriverName.UseVisualStyleBackColor = true;
            this.checkLicenseNo.AutoSize = true;
            this.checkLicenseNo.Checked = true;
            this.checkLicenseNo.CheckState = CheckState.Checked;
            this.checkLicenseNo.Location = new Point(0xbf, 0x41);
            this.checkLicenseNo.Name = "checkLicenseNo";
            this.checkLicenseNo.Size = new Size(0x53, 0x11);
            this.checkLicenseNo.TabIndex = 8;
            this.checkLicenseNo.Text = "License No.";
            this.checkLicenseNo.UseVisualStyleBackColor = true;
            this.checkEstate.AutoSize = true;
            this.checkEstate.Location = new Point(0xbf, 0x2e);
            this.checkEstate.Name = "checkEstate";
            this.checkEstate.Size = new Size(0x38, 0x11);
            this.checkEstate.TabIndex = 7;
            this.checkEstate.Text = "Estate";
            this.checkEstate.UseVisualStyleBackColor = true;
            this.checkRelation.AutoSize = true;
            this.checkRelation.Checked = true;
            this.checkRelation.CheckState = CheckState.Checked;
            this.checkRelation.Location = new Point(0xbf, 8);
            this.checkRelation.Name = "checkRelation";
            this.checkRelation.Size = new Size(0x41, 0x11);
            this.checkRelation.TabIndex = 6;
            this.checkRelation.Text = "Relation";
            this.checkRelation.UseVisualStyleBackColor = true;
            this.check1xDO.AutoSize = true;
            this.check1xDO.Location = new Point(0x11, 0x8d);
            this.check1xDO.Name = "check1xDO";
            this.check1xDO.Size = new Size(0x4e, 0x11);
            this.check1xDO.TabIndex = 5;
            this.check1xDO.Text = "1xDO STO";
            this.check1xDO.UseVisualStyleBackColor = true;
            this.check1xSTO.AutoSize = true;
            this.check1xSTO.Location = new Point(0x11, 0x7a);
            this.check1xSTO.Name = "check1xSTO";
            this.check1xSTO.Size = new Size(0x3b, 0x11);
            this.check1xSTO.TabIndex = 4;
            this.check1xSTO.Text = "1xSTO";
            this.check1xSTO.UseVisualStyleBackColor = true;
            this.checkPO.AutoSize = true;
            this.checkPO.Location = new Point(0x11, 0x54);
            this.checkPO.Name = "checkPO";
            this.checkPO.Size = new Size(0x3d, 0x11);
            this.checkPO.TabIndex = 3;
            this.checkPO.Text = "PO No.";
            this.checkPO.UseVisualStyleBackColor = true;
            this.checkSTO.AutoSize = true;
            this.checkSTO.Location = new Point(0x11, 0x41);
            this.checkSTO.Name = "checkSTO";
            this.checkSTO.Size = new Size(0x44, 0x11);
            this.checkSTO.TabIndex = 2;
            this.checkSTO.Text = "STO No.";
            this.checkSTO.UseVisualStyleBackColor = true;
            this.checkDO_No.AutoSize = true;
            this.checkDO_No.Checked = true;
            this.checkDO_No.CheckState = CheckState.Checked;
            this.checkDO_No.Location = new Point(0x11, 0x1b);
            this.checkDO_No.Name = "checkDO_No";
            this.checkDO_No.Size = new Size(0x52, 0x11);
            this.checkDO_No.TabIndex = 1;
            this.checkDO_No.Text = "DO/SO No.";
            this.checkDO_No.UseVisualStyleBackColor = true;
            this.checkDelivery.AutoSize = true;
            this.checkDelivery.Checked = true;
            this.checkDelivery.CheckState = CheckState.Checked;
            this.checkDelivery.Location = new Point(0x11, 8);
            this.checkDelivery.Name = "checkDelivery";
            this.checkDelivery.Size = new Size(0x7c, 0x11);
            this.checkDelivery.TabIndex = 0;
            this.checkDelivery.Text = "Delivery Date / Time";
            this.checkDelivery.UseVisualStyleBackColor = true;
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(0x17, 9);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x123, 20);
            this.label3.TabIndex = 0x31;
            this.label3.Text = "List of Weighing / Daily Transaction";
            this.label3.TextAlign = ContentAlignment.TopCenter;
            this.buttonStorage.Location = new Point(0xc4, 0x16b);
            this.buttonStorage.Margin = new Padding(0);
            this.buttonStorage.Name = "buttonStorage";
            this.buttonStorage.Size = new Size(0x17, 0x17);
            this.buttonStorage.TabIndex = 0x55;
            this.buttonStorage.Text = "...";
            this.buttonStorage.UseVisualStyleBackColor = true;
            this.buttonStorage.Click += new EventHandler(this.buttonStorage_Click);
            this.textStorage.CharacterCasing = CharacterCasing.Upper;
            this.textStorage.Location = new Point(100, 0x16d);
            this.textStorage.Name = "textStorage";
            this.textStorage.Size = new Size(0x5d, 20);
            this.textStorage.TabIndex = 0x54;
            this.textStorage.KeyPress += new KeyPressEventHandler(this.textStorage_KeyPress);
            this.textStorage.Leave += new EventHandler(this.textStorage_Leave);
            this.labelStorageName.AutoSize = true;
            this.labelStorageName.Location = new Point(220, 0x171);
            this.labelStorageName.Name = "labelStorageName";
            this.labelStorageName.Size = new Size(0x48, 13);
            this.labelStorageName.TabIndex = 0x53;
            this.labelStorageName.Text = "StorageName";
            this.checkStorage.AutoSize = true;
            this.checkStorage.Location = new Point(0x1b, 0x16f);
            this.checkStorage.Name = "checkStorage";
            this.checkStorage.Size = new Size(0x3f, 0x11);
            this.checkStorage.TabIndex = 0x52;
            this.checkStorage.Text = "Storage";
            this.checkStorage.UseVisualStyleBackColor = true;
            this.checkStorage.CheckedChanged += new EventHandler(this.checkStorage_CheckedChanged);
            this.checkProcess.AutoSize = true;
            this.checkProcess.Location = new Point(0xb9, 0x187);
            this.checkProcess.Name = "checkProcess";
            this.checkProcess.Size = new Size(0x93, 0x11);
            this.checkProcess.TabIndex = 0x52;
            this.checkProcess.Text = "Include Processing Truck";
            this.checkProcess.UseVisualStyleBackColor = true;
            this.checkProcess.CheckedChanged += new EventHandler(this.checkProcess_CheckedChanged);
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0x10, 0x157);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x4b, 13);
            this.label7.TabIndex = 0x56;
            this.label7.Text = "Truck Number";
            this.textTruck.CharacterCasing = CharacterCasing.Upper;
            this.textTruck.Location = new Point(0x66, 0x153);
            this.textTruck.Name = "textTruck";
            this.textTruck.Size = new Size(90, 20);
            this.textTruck.TabIndex = 0x57;
            this.textTruck.KeyPress += new KeyPressEventHandler(this.textTruck_KeyPress);
            this.textTruck.Leave += new EventHandler(this.textTruck_Leave);
            this.buttonTruck.Location = new Point(0xc4, 0x152);
            this.buttonTruck.Margin = new Padding(0);
            this.buttonTruck.Name = "buttonTruck";
            this.buttonTruck.Size = new Size(0x17, 0x17);
            this.buttonTruck.TabIndex = 0x58;
            this.buttonTruck.Text = "...";
            this.buttonTruck.UseVisualStyleBackColor = true;
            this.buttonTruck.Click += new EventHandler(this.buttonTruck_Click);
            this.textTank.CharacterCasing = CharacterCasing.Upper;
            this.textTank.Location = new Point(0x149, 0x153);
            this.textTank.Name = "textTank";
            this.textTank.Size = new Size(0x3f, 20);
            this.textTank.TabIndex = 90;
            this.textTank.Visible = false;
            this.checkBoxTank.AutoSize = true;
            this.checkBoxTank.Location = new Point(0x10a, 0x155);
            this.checkBoxTank.Name = "checkBoxTank";
            this.checkBoxTank.Size = new Size(60, 0x11);
            this.checkBoxTank.TabIndex = 0x59;
            this.checkBoxTank.Text = "Tanker";
            this.checkBoxTank.UseVisualStyleBackColor = true;
            this.checkBoxTank.CheckedChanged += new EventHandler(this.checkBoxTank_CheckedChanged);
            this.buttonDriver.Location = new Point(0x11b, 0x10a);
            this.buttonDriver.Margin = new Padding(0);
            this.buttonDriver.Name = "buttonDriver";
            this.buttonDriver.Size = new Size(0x17, 0x17);
            this.buttonDriver.TabIndex = 0x5c;
            this.buttonDriver.Text = "...";
            this.buttonDriver.UseVisualStyleBackColor = true;
            this.buttonDriver.Click += new EventHandler(this.buttonDriver_Click);
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x21, 0x110);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x40, 13);
            this.label5.TabIndex = 0x5d;
            this.label5.Text = "License No.";
            this.textDriver.CharacterCasing = CharacterCasing.Upper;
            this.textDriver.Location = new Point(100, 0x10c);
            this.textDriver.Name = "textDriver";
            this.textDriver.Size = new Size(180, 20);
            this.textDriver.TabIndex = 0x5b;
            this.textDriver.KeyPress += new KeyPressEventHandler(this.textDriver_KeyPress);
            this.textDriver.Leave += new EventHandler(this.textDriver_Leave);
            this.comboComm.FormattingEnabled = true;
            this.comboComm.Location = new Point(480, 0xd5);
            this.comboComm.Name = "comboComm";
            this.comboComm.Size = new Size(0x79, 0x15);
            this.comboComm.TabIndex = 0x5e;
            this.comboComm.Visible = false;
            this.txtqstandard.CharacterCasing = CharacterCasing.Upper;
            this.txtqstandard.Enabled = false;
            this.txtqstandard.Location = new Point(100, 0x126);
            this.txtqstandard.Name = "txtqstandard";
            this.txtqstandard.Size = new Size(180, 20);
            this.txtqstandard.TabIndex = 0x60;
            this.txtqstandard.TextChanged += new EventHandler(this.txtqstandard_TextChanged);
            this.txtqstandard.KeyPress += new KeyPressEventHandler(this.txtqstandard_KeyPress);
            this.txtqstandard.Leave += new EventHandler(this.txtqstandard_Leave);
            this.txtqstandard.MouseDoubleClick += new MouseEventHandler(this.txtqstandard_MouseDoubleClick);
            this.btnQstandard.Enabled = false;
            this.btnQstandard.Location = new Point(0x11b, 0x124);
            this.btnQstandard.Margin = new Padding(0);
            this.btnQstandard.Name = "btnQstandard";
            this.btnQstandard.Size = new Size(0x17, 0x17);
            this.btnQstandard.TabIndex = 0x61;
            this.btnQstandard.Text = "...";
            this.btnQstandard.UseVisualStyleBackColor = true;
            this.btnQstandard.Click += new EventHandler(this.btnQstandard_Click);
            this.chkQstandard.AutoSize = true;
            this.chkQstandard.Location = new Point(12, 0x127);
            this.chkQstandard.Name = "chkQstandard";
            this.chkQstandard.Size = new Size(80, 0x11);
            this.chkQstandard.TabIndex = 0x62;
            this.chkQstandard.Text = "Q.Standard";
            this.chkQstandard.UseVisualStyleBackColor = true;
            this.chkQstandard.CheckedChanged += new EventHandler(this.qstandard_checkedchanged);
            this.chkNonQ.AutoSize = true;
            this.chkNonQ.Location = new Point(12, 0x13f);
            this.chkNonQ.Name = "chkNonQ";
            this.chkNonQ.Size = new Size(0x67, 0x11);
            this.chkNonQ.TabIndex = 0x63;
            this.chkNonQ.Text = "Non Q.Standard";
            this.chkNonQ.UseVisualStyleBackColor = true;
            this.ComboIscc.FormattingEnabled = true;
            this.ComboIscc.Location = new Point(480, 0xba);
            this.ComboIscc.Name = "ComboIscc";
            this.ComboIscc.Size = new Size(0x79, 0x15);
            this.ComboIscc.TabIndex = 100;
            this.ComboIscc.Visible = false;
            this.labelQStandard.AutoSize = true;
            this.labelQStandard.Location = new Point(0x135, 0x129);
            this.labelQStandard.Name = "labelQStandard";
            this.labelQStandard.Size = new Size(0x3d, 13);
            this.labelQStandard.TabIndex = 0x65;
            this.labelQStandard.Text = "Q.Standard";
            this.statusStrip1.Location = new Point(0, 0x2b7);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(0x2d6, 0x16);
            this.statusStrip1.TabIndex = 0x66;
            this.statusStrip1.Text = "statusStrip1";
            this.cBoxAll.AutoSize = true;
            this.cBoxAll.Location = new Point(0x1b, 0x187);
            this.cBoxAll.Name = "cBoxAll";
            this.cBoxAll.Size = new Size(150, 0x11);
            this.cBoxAll.TabIndex = 0x72;
            this.cBoxAll.Text = "Checked / Unchecked All";
            this.cBoxAll.UseVisualStyleBackColor = true;
            this.cBoxAll.CheckedChanged += new EventHandler(this.cBoxAll_CheckedChanged);
            this.txt_ref.CharacterCasing = CharacterCasing.Upper;
            this.txt_ref.Location = new Point(100, 0xa1);
            this.txt_ref.Name = "txt_ref";
            this.txt_ref.Size = new Size(180, 20);
            this.txt_ref.TabIndex = 0x73;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x35, 0xa4);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x29, 13);
            this.label6.TabIndex = 0x74;
            this.label6.Text = "No Ref";
            this.gb_grouping.Controls.Add(this.rb_iscc);
            this.gb_grouping.Controls.Add(this.rb_none);
            this.gb_grouping.Controls.Add(this.rb_mill);
            this.gb_grouping.Controls.Add(this.rb_comm);
            this.gb_grouping.Location = new Point(480, 0xec);
            this.gb_grouping.Name = "gb_grouping";
            this.gb_grouping.Size = new Size(0xce, 0x62);
            this.gb_grouping.TabIndex = 0x75;
            this.gb_grouping.TabStop = false;
            this.gb_grouping.Text = "Group By";
            this.rb_iscc.AutoSize = true;
            this.rb_iscc.Location = new Point(6, 0x49);
            this.rb_iscc.Name = "rb_iscc";
            this.rb_iscc.Size = new Size(0xbf, 0x11);
            this.rb_iscc.TabIndex = 3;
            this.rb_iscc.Text = "Origin && Vendor of Quality Standard";
            this.rb_iscc.UseVisualStyleBackColor = true;
            this.rb_iscc.CheckedChanged += new EventHandler(this.rb_iscc_CheckedChanged);
            this.rb_none.AutoSize = true;
            this.rb_none.Checked = true;
            this.rb_none.Location = new Point(6, 0x13);
            this.rb_none.Name = "rb_none";
            this.rb_none.Size = new Size(0x33, 0x11);
            this.rb_none.TabIndex = 2;
            this.rb_none.TabStop = true;
            this.rb_none.Text = "None";
            this.rb_none.UseVisualStyleBackColor = true;
            this.rb_mill.AutoSize = true;
            this.rb_mill.Location = new Point(6, 0x37);
            this.rb_mill.Name = "rb_mill";
            this.rb_mill.Size = new Size(40, 0x11);
            this.rb_mill.TabIndex = 1;
            this.rb_mill.Text = "Mill";
            this.rb_mill.UseVisualStyleBackColor = true;
            this.rb_comm.AutoSize = true;
            this.rb_comm.Location = new Point(6, 0x25);
            this.rb_comm.Name = "rb_comm";
            this.rb_comm.Size = new Size(0x4c, 0x11);
            this.rb_comm.TabIndex = 0;
            this.rb_comm.Text = "Commodity";
            this.rb_comm.UseVisualStyleBackColor = true;
            this.txt_mill.CharacterCasing = CharacterCasing.Upper;
            this.txt_mill.Location = new Point(480, 340);
            this.txt_mill.Name = "txt_mill";
            this.txt_mill.Size = new Size(180, 20);
            this.txt_mill.TabIndex = 0x76;
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0x1c4, 0x158);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x16, 13);
            this.label8.TabIndex = 0x77;
            this.label8.Text = "Mill";
            this.sh_mill.Location = new Point(0x297, 0x153);
            this.sh_mill.Margin = new Padding(0);
            this.sh_mill.Name = "sh_mill";
            this.sh_mill.Size = new Size(0x17, 0x17);
            this.sh_mill.TabIndex = 120;
            this.sh_mill.Text = "...";
            this.sh_mill.UseVisualStyleBackColor = true;
            this.sh_mill.Click += new EventHandler(this.sh_mill_Click);
            this.label9.AutoSize = true;
            this.label9.Location = new Point(410, 370);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x40, 13);
            this.label9.TabIndex = 0x7a;
            this.label9.Text = "Contract No";
            this.txt_contract.CharacterCasing = CharacterCasing.Upper;
            this.txt_contract.Location = new Point(480, 0x16f);
            this.txt_contract.Name = "txt_contract";
            this.txt_contract.Size = new Size(180, 20);
            this.txt_contract.TabIndex = 0x79;
            this.button3.Location = new Point(0x297, 0x16d);
            this.button3.Margin = new Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x17, 0x17);
            this.button3.TabIndex = 0x7b;
            this.button3.Text = "...";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.checkNot1stYet.AutoSize = true;
            this.checkNot1stYet.Location = new Point(0x151, 0x187);
            this.checkNot1stYet.Name = "checkNot1stYet";
            this.checkNot1stYet.Size = new Size(0x98, 0x11);
            this.checkNot1stYet.TabIndex = 0x7c;
            this.checkNot1stYet.Text = "Include Has not 1st Weigh";
            this.checkNot1stYet.UseVisualStyleBackColor = true;
            this.checkNot1stYet.CheckedChanged += new EventHandler(this.checkNot1stYet_CheckedChanged);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x2d6, 0x2cd);
            base.ControlBox = false;
            base.Controls.Add(this.checkNot1stYet);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.txt_contract);
            base.Controls.Add(this.sh_mill);
            base.Controls.Add(this.txt_mill);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.gb_grouping);
            base.Controls.Add(this.txt_ref);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.cBoxAll);
            base.Controls.Add(this.statusStrip1);
            base.Controls.Add(this.labelQStandard);
            base.Controls.Add(this.ComboIscc);
            base.Controls.Add(this.chkNonQ);
            base.Controls.Add(this.chkQstandard);
            base.Controls.Add(this.btnQstandard);
            base.Controls.Add(this.txtqstandard);
            base.Controls.Add(this.comboComm);
            base.Controls.Add(this.buttonDriver);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.textDriver);
            base.Controls.Add(this.textTank);
            base.Controls.Add(this.checkBoxTank);
            base.Controls.Add(this.buttonTruck);
            base.Controls.Add(this.textTruck);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.checkProcess);
            base.Controls.Add(this.buttonStorage);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textStorage);
            base.Controls.Add(this.labelStorageName);
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.checkStorage);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.grType);
            base.Controls.Add(this.buttonTransporter);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textTransport);
            base.Controls.Add(this.grKB);
            base.Controls.Add(this.buttonDoNo);
            base.Controls.Add(this.labelDoNo);
            base.Controls.Add(this.checkDate);
            base.Controls.Add(this.textDoNo);
            base.Controls.Add(this.groupDate);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.button1);
            base.Name = "RepListWeighing";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Report List Weighing";
            base.Load += new EventHandler(this.RepListWeighing_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepListWeighing_KeyPress);
            this.groupDate.ResumeLayout(false);
            this.groupDate.PerformLayout();
            this.grKB.ResumeLayout(false);
            this.grKB.PerformLayout();
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_grouping.ResumeLayout(false);
            this.gb_grouping.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void initTable()
        {
            this.tbl_Comm = new WBTable();
            this.tbl_Comm.OpenTable("wb_commodity", "Select * from wb_commodity WITH (NOLOCK)", WBData.conn);
            Program.AutoComp(this.tbl_Comm, "Comm_code", this.textCommodity);
            this.tbl_Transport = new WBTable();
            this.tbl_Transport.OpenTable("wb_Transport", "Select * from wb_Transporter WITH (NOLOCK)", WBData.conn);
            Program.AutoComp(this.tbl_Transport, "Transporter_code", this.textTransport);
            this.tbl_Driver = new WBTable();
            this.tbl_Driver.OpenTable("wb_Driver", "Select * from wb_Driver WITH (NOLOCK)", WBData.conn);
            Program.AutoComp(this.tbl_Driver, "License_No", this.textDriver);
            this.tbl_Do = new WBTable();
            this.tbl_Do.OpenTable("wb_contract", "Select * from wb_contract WITH (NOLOCK)", WBData.conn);
            Program.AutoComp(this.tbl_Do, "Do_No", this.textDoNo);
            this.tbl_Storage = new WBTable();
            this.tbl_Storage.OpenTable("wb_storage", "Select * from wb_storage WITH (NOLOCK)", WBData.conn);
            Program.AutoComp(this.tbl_Storage, "Storage_code", this.textStorage);
            this.tblTruck = new WBTable();
            this.tblTruck.OpenTable("wb_truck", "Select * from wb_truck WITH (NOLOCK)", WBData.conn);
            Program.AutoComp(this.tblTruck, "Truck_NUmber", this.textTruck);
            this.tbl_iscc = new WBTable();
            this.tbl_iscc.OpenTable("wb_iscc", "Select * from wb_iscc WITH (NOLOCK) where 1 = 1 ", WBData.conn);
            Program.AutoComp(this.tbl_iscc, "iscc_code", this.txtqstandard);
            WBTable table = new WBTable();
            table.OpenTable("wb_transaction_type", "Select top 1 * from wb_transaction_type WITH (NOLOCK) where " + WBData.CompanyLocation("and is_return = 'Y' and IO = 'I'"), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                this.Retur_masuk = table.DT.Rows[0]["transaction_code"].ToString();
            }
            table.OpenTable("wb_transaction_type", "Select top 1 * from wb_transaction_type WITH (NOLOCK) where " + WBData.CompanyLocation("and is_return = 'Y' and IO = 'O'"), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                this.Retur_keluar = table.DT.Rows[0]["transaction_code"].ToString();
            }
        }

        private void qstandard_checkedchanged(object sender, EventArgs e)
        {
            if (this.chkQstandard.Checked)
            {
                this.txtqstandard.Enabled = true;
                this.btnQstandard.Enabled = true;
            }
            else
            {
                this.txtqstandard.Text = "";
                this.ComboIscc.Items.Clear();
                this.txtqstandard.Enabled = false;
                this.btnQstandard.Enabled = false;
            }
        }

        private void rb_iscc_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rb_iscc.Checked)
            {
                this.chkQstandard.Checked = true;
                this.chkQstandard.Enabled = false;
            }
            else
            {
                this.chkQstandard.Checked = false;
                this.chkQstandard.Enabled = true;
            }
        }

        private void rboAll_CheckedChanged(object sender, EventArgs e)
        {
            this.checkSO.Checked = false;
            this.checkSO.Enabled = true;
            this.checkPO.Checked = false;
            this.checkPO.Enabled = true;
        }

        private void rboGI_CheckedChanged(object sender, EventArgs e)
        {
            this.checkPO.Checked = false;
            this.checkPO.Enabled = false;
            this.checkSO.Checked = false;
            this.checkSO.Enabled = true;
        }

        private void rboGI_TextChanged(object sender, EventArgs e)
        {
            this.labelDoNo.Text = !this.rboGR.Checked ? "SO No." : "DO No.";
        }

        private void rboGR_CheckedChanged(object sender, EventArgs e)
        {
            this.checkSO.Checked = false;
            this.checkSO.Enabled = false;
            this.checkPO.Checked = false;
            this.checkPO.Enabled = true;
        }

        private void rboGR_TextChanged(object sender, EventArgs e)
        {
            this.labelDoNo.Text = !this.rboGR.Checked ? "SO No." : "DO No.";
        }

        private void RepListWeighing_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepListWeighing_Load(object sender, EventArgs e)
        {
            this.translate();
            this.initTable();
            this.textStorage.Visible = false;
            this.buttonStorage.Visible = false;
            this.labelStorageName.Visible = false;
            this.labelStorageName.Text = "";
            this.labelQStandard.Text = "";
            base.KeyPreview = true;
            this.tipe = "I";
            this.rboGR.Checked = true;
            this.rboNonKB.Checked = true;
            if (WBSetting.Field("KB").ToString() == "N")
            {
                this.kb = "N";
                this.rboNonKB.Checked = true;
            }
            else
            {
                this.kb = "Y";
                this.rboKB.Checked = true;
            }
            this.labelProses1.Text = "";
            this.labelProses2.Text = "";
            this.labelCommName.Text = "";
            if (WBSetting.region == "1")
            {
                this.checkSourceCode.Visible = true;
                this.checkSourceDesc.Visible = true;
                this.rb_mill.Visible = false;
                this.label8.Visible = false;
                this.txt_mill.Visible = false;
                this.sh_mill.Visible = false;
                this.rb_iscc.Visible = false;
                this.checkGrade.Visible = false;
                this.checkTrailerNo.Checked = true;
            }
            else if (WBSetting.region == "2")
            {
                this.checkSourceCode.Visible = false;
                this.checkSourceDesc.Visible = false;
                this.rb_mill.Visible = true;
                this.label8.Visible = true;
                this.txt_mill.Visible = true;
                this.sh_mill.Visible = true;
                this.rb_iscc.Visible = true;
                this.checkGrade.Visible = true;
            }
            else
            {
                this.checkSourceCode.Visible = false;
                this.checkSourceDesc.Visible = false;
                this.rb_mill.Visible = false;
                this.label8.Visible = false;
                this.txt_mill.Visible = false;
                this.sh_mill.Visible = false;
                this.rb_iscc.Visible = false;
                this.checkGrade.Visible = false;
            }
            if (WBSetting.activeTCS)
            {
                this.checkBoxGatepassNumber.Visible = false;
                this.checkBoxGatepassNumber.Checked = false;
                this.checkNot1stYet.Visible = true;
            }
            else
            {
                if (WBSetting.transflow == "1")
                {
                    this.checkBoxGatepassNumber.Visible = false;
                    this.checkBoxGatepassNumber.Checked = false;
                }
                else if (WBSetting.transflow == "2")
                {
                    this.checkBoxGatepassNumber.Visible = true;
                    this.checkBoxGatepassNumber.Checked = true;
                }
                else if (WBSetting.transflow == "3")
                {
                    this.checkBoxGatepassNumber.Visible = true;
                    this.checkBoxGatepassNumber.Checked = true;
                }
                if (WBSetting.bGate == "Y")
                {
                    this.cb_interval12.Visible = true;
                    this.cb_interval34.Visible = true;
                }
                else
                {
                    this.cb_interval12.Visible = false;
                    this.cb_interval34.Visible = false;
                }
                this.checkNot1stYet.Visible = false;
            }
            if (this.rboAll.Checked)
            {
                this.checkSO.Enabled = true;
                this.checkPO.Enabled = true;
            }
            else
            {
                if (this.rboGR.Checked)
                {
                    this.checkPO.Enabled = true;
                    this.checkSO.Enabled = false;
                }
                if (this.rboGI.Checked)
                {
                    this.checkPO.Enabled = false;
                    this.checkSO.Enabled = true;
                }
            }
        }

        private void sh_mill_Click(object sender, EventArgs e)
        {
            FormMillMsia msia = new FormMillMsia {
                DATA_FROM = "DB",
                num_of_mill = 1
            };
            msia.ShowDialog();
            if (msia.mill != "")
            {
                this.txt_mill.Text = msia.mill;
            }
        }

        private void textCommodity_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textCommodity_Leave(object sender, EventArgs e)
        {
            this.labelCommName.Text = "";
            if (this.textCommodity.Text.Trim() != "")
            {
                this.tbl_Comm.ReOpen();
                string[] aField = new string[] { "Comm_code" };
                string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                int recNo = this.tbl_Comm.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelCommName.Text = this.tbl_Comm.DT.Rows[recNo]["Comm_name"].ToString().Trim();
                }
                else
                {
                    this.buttonComm.PerformClick();
                    this.textCommodity.Focus();
                }
            }
        }

        private void textCommodity_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FormPickList list = new FormPickList();
            this.tbl_Comm.ReOpen();
            list.tempTable = this.tbl_Comm;
            list.dgView.Rows.Clear();
            list.autoField = "Comm_Code";
            int num = 0;
            while (true)
            {
                if (num >= this.comboComm.Items.Count)
                {
                    list.ShowDialog();
                    this.comboComm.Items.Clear();
                    num = 0;
                    while (true)
                    {
                        if (num >= (list.dgView.Rows.Count - 1))
                        {
                            this.textCommodity.Text = (this.comboComm.Items.Count <= 0) ? "" : this.comboComm.Items[0].ToString();
                            return;
                        }
                        this.comboComm.Items.Add(list.dgView.Rows[num].Cells[0].Value.ToString());
                        num++;
                    }
                }
                object[] values = new object[] { this.comboComm.Items[num].ToString() };
                list.dgView.Rows.Add(values);
                num++;
            }
        }

        private void textDoNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDoNo_Leave(object sender, EventArgs e)
        {
            if (this.textDoNo.Text.Trim() != "")
            {
                this.tbl_Do.ReOpen();
                string[] aField = new string[] { "Do_NO" };
                string[] aFind = new string[] { this.textDoNo.Text.Trim() };
                if (this.tbl_Do.GetRecNo(aField, aFind) < -1)
                {
                    this.buttonDoNo.PerformClick();
                    this.textDoNo.Focus();
                }
            }
        }

        private void textDriver_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDriver_Leave(object sender, EventArgs e)
        {
            if (this.textDriver.Text.Trim() != "")
            {
                this.tbl_Driver.ReOpen();
                string[] aField = new string[] { "License_no" };
                string[] aFind = new string[] { this.textDriver.Text.Trim() };
                if (this.tbl_Driver.GetRecNo(aField, aFind) < -1)
                {
                    this.buttonDriver.PerformClick();
                    this.textDriver.Focus();
                }
            }
        }

        private void textStorage_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textStorage_Leave(object sender, EventArgs e)
        {
            if (this.textStorage.Text.Trim() != "")
            {
                this.tbl_Storage.ReOpen();
                string[] aField = new string[] { "Storage_code" };
                string[] aFind = new string[] { this.textStorage.Text.Trim() };
                if (this.tbl_Storage.GetRecNo(aField, aFind) < -1)
                {
                    this.buttonStorage.PerformClick();
                    this.textStorage.Focus();
                }
            }
        }

        private void textTransport_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransport_Leave(object sender, EventArgs e)
        {
            if (this.textTransport.Text.Trim() != "")
            {
                this.tbl_Transport.ReOpen();
                string[] aField = new string[] { "Transporter_code" };
                string[] aFind = new string[] { this.textDriver.Text.Trim() };
                if (this.tbl_Transport.GetRecNo(aField, aFind) < -1)
                {
                    this.buttonTransporter.PerformClick();
                    this.textTransport.Focus();
                }
            }
        }

        private void textTruck_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTruck_Leave(object sender, EventArgs e)
        {
            if (this.textTruck.Text.Trim() != "")
            {
                this.tblTruck.ReOpen();
                string[] aField = new string[] { "Truck_Number" };
                string[] aFind = new string[] { this.textTruck.Text.Trim() };
                int recNo = this.tblTruck.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.textTruck.Text = this.tblTruck.DT.Rows[recNo]["Truck_Number"].ToString().Trim();
                }
                else
                {
                    this.buttonTruck.PerformClick();
                    this.textTruck.Focus();
                }
            }
        }

        private void translate()
        {
            this.label3.Text = Resource.Rep01_001;
            this.grType.Text = Resource.Rep01_002;
            this.rboGR.Text = Resource.Rep01_003;
            this.rboGI.Text = Resource.Rep01_004;
            this.rboKB.Text = Resource.Rep01_005;
            this.rboNonKB.Text = Resource.Rep01_006;
            this.checkDate.Text = Resource.Rep01_007;
            this.label1.Text = Resource.Rep01_008;
            this.label2.Text = Resource.Rep01_009;
            this.labelcommodity.Text = Resource.Rep01_010;
            this.label4.Text = Resource.Rep01_011;
            this.label5.Text = Resource.Rep01_012;
            this.label7.Text = Resource.Rep01_013;
            this.checkBoxTank.Text = Resource.Rep01_014;
            this.checkStorage.Text = Resource.Rep01_015;
            this.checkProcess.Text = Resource.Rep01_016;
            this.checkDelivery.Text = Resource.Rep01_017;
            this.checkDO_No.Text = Resource.Rep01_018;
            this.checkContract.Text = Resource.Rep01_019;
            this.checkSTO.Text = Resource.Rep01_020;
            this.checkPO.Text = Resource.Rep01_021;
            this.check1xSTO.Text = Resource.Rep01_022;
            this.check1xDO.Text = Resource.Rep01_023;
            this.checkConv.Text = Resource.Rep01_024;
            this.checkWBRef.Text = Resource.Rep01_025;
            this.checkEstate.Text = Resource.Rep01_028;
            this.checkDriverName.Text = Resource.Rep01_029;
            this.checkDeliNote.Text = Resource.Rep01_030;
            this.cbGunny.Text = Resource.Rep01_031;
            this.checkColly.Text = Resource.Rep01_032;
            this.check3rdParty.Text = Resource.Rep01_033;
            this.checkBrutoTarra.Text = Resource.Rep01_034;
            this.checkDiff.Text = Resource.Rep01_035;
            this.checkRmkTicket.Text = Resource.Rep01_036;
            this.checkRmkReport.Text = Resource.Rep01_037;
            this.checkSeal.Text = Resource.Rep01_038;
            this.checkAutomated.Text = Resource.Rep01_039;
            this.cbDeduction.Text = Resource.Rep01_040;
            this.cbDL.Text = Resource.Rep01_041;
            this.button1.Text = Resource.Rep01_042;
            this.button2.Text = Resource.Rep01_043;
            this.checkLicenseNo.Text = Resource.Rep01_012;
            this.checkRelation.Text = Resource.Rep01_026;
            this.checkRelationName.Text = Resource.Rep01_027;
            this.cBoxCommName.Text = Resource.CommE_003;
            this.checkTransporter.Text = Resource.Rep01_011;
            this.cBoxTransName.Text = Resource.Transporter_002;
            this.checkSourceCode.Text = Resource.Source_014;
            this.checkSourceDesc.Text = Resource.Trans_059;
            this.checkBoxGatepassNumber.Text = Resource.Gatepass_001;
        }

        private void txtqstandard_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void txtqstandard_Leave(object sender, EventArgs e)
        {
            this.labelCommName.Text = "";
            if (this.txtqstandard.Text.Trim() != "")
            {
                this.tbl_iscc.ReOpen();
                string[] aField = new string[] { "iscc_code" };
                string[] aFind = new string[] { this.txtqstandard.Text.Trim() };
                int recNo = this.tbl_iscc.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelQStandard.Text = this.tbl_iscc.DT.Rows[recNo]["Iscc_Text"].ToString().Trim();
                }
                else
                {
                    this.btnQstandard.PerformClick();
                    this.txtqstandard.Focus();
                }
            }
        }

        private void txtqstandard_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.btnQstandard.PerformClick();
        }

        private void txtqstandard_TextChanged(object sender, EventArgs e)
        {
        }

        public class ComboboxItem
        {
            public override string ToString() => 
                this.Text;

            public string Text { get; set; }

            public object Value { get; set; }
        }
    }
}

