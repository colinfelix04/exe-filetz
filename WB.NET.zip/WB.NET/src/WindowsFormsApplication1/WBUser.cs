﻿namespace WindowsFormsApplication1
{
    using Microsoft.Win32;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.IO;
    using System.Net;
    using System.Net.Sockets;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class WBUser : Component
    {
        public static string UserID;
        public static string UserName;
        public static string UserGroup;
        public static string UserLevel;
        public static string UserPass;
        public static bool WBRun = false;
        public static IPHostEntry host;
        public static string localIP = "?";
        public static string ComName;

        public static bool CheckTrustee(string MenuCode, string Act)
        {
            bool flag4;
            WBTable table = new WBTable();
            table.OpenTable("wb_menu", "Select * From wb_menu where code = '" + MenuCode + "'", WBData.conn);
            if (table.DT.Rows.Count == 0)
            {
                table.OpenTable("WB_RLOCK", "INSERT INTO [wb_menu] (code) VALUES ('" + MenuCode + "')", WBData.conn);
            }
            table.Dispose();
            bool flag = false;
            if (UserLevel == "1")
            {
                flag4 = true;
            }
            else
            {
                WBTable table2 = new WBTable();
                string[] textArray1 = new string[] { "Select * From wb_authorization where ", WBData.CompanyLocation(""), " AND (Autho_Group='", UserGroup, "' and Autho_Menu='", MenuCode, "')" };
                table2.OpenTable("wb_authorization", string.Concat(textArray1), WBData.conn);
                if (table2.DT.Rows.Count <= 0)
                {
                    table2.Dispose();
                    flag4 = false;
                }
                else
                {
                    table2.DR = table2.DT.Rows[0];
                    if (table2.ValidChecksum(table2.DR))
                    {
                        flag = table2.DR["Autho_Trustee"].ToString().Contains(Act);
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_002, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    table2.Dispose();
                    flag4 = flag;
                }
            }
            return flag4;
        }

        private static bool isStillRunning(string processName)
        {
            int num = 0;
            Process[] processes = Process.GetProcesses();
            int index = 0;
            while (true)
            {
                while (true)
                {
                    if (index >= processes.Length)
                    {
                        return (num > 1);
                    }
                    Process process = processes[index];
                    if ((process.ProcessName != "System") && (process.ProcessName != "Idle"))
                    {
                        try
                        {
                            if (process.MainModule.FileVersionInfo.FileDescription.Contains(processName))
                            {
                                num++;
                            }
                        }
                        catch (Exception)
                        {
                        }
                    }
                    break;
                }
                index++;
            }
        }

        public static bool Login()
        {
            bool flag9;
            WBRun = false;
            if (isStillRunning("WB System"))
            {
                WBRun = true;
            }
            bool flag = false;
            FormLogin login = new FormLogin();
            if (((UserID != "") && ((UserPass != "") && (UserID != null))) && (UserPass != null))
            {
                login.PassValue(UserID, UserPass);
            }
            login.ShowDialog();
            if (!login.berhasil)
            {
                flag9 = flag;
            }
            else
            {
                if (!WBSetting.loginWithActiveDirectory)
                {
                    string keyField = "";
                    WBTable table2 = new WBTable();
                    table2.OpenTable("wb_setting", "Select * from wb_setting where " + WBData.CompanyLocation(" and wbCode = '" + WBData.sWBCode + "'"), WBData.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        table2.DR = table2.DT.Rows[0];
                        keyField = table2.DR["uniq"].ToString();
                        table2.DR.BeginEdit();
                        table2.DR["version"] = login.prodVersion;
                        table2.DR["CompName"] = Environment.MachineName;
                        table2.DR["LastLogin"] = DateTime.Now;
                        table2.DR.EndEdit();
                        table2.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "LOAD-LOGIN", "SYSTEM", "Load login form" };
                        Program.updateLogHeader("wb_setting", keyField, logField, logValue);
                    }
                    WBTable table3 = new WBTable();
                    flag = true;
                    ComName = Environment.MachineName;
                    host = Dns.GetHostEntry(Dns.GetHostName());
                    IPAddress[] addressList = host.AddressList;
                    int index = 0;
                    while (true)
                    {
                        if (index < addressList.Length)
                        {
                            IPAddress address = addressList[index];
                            AddressFamily addressFamily = address.AddressFamily;
                            if (addressFamily.ToString() == "InterNetwork")
                            {
                                localIP = address.ToString();
                            }
                            index++;
                            continue;
                        }
                        if (MainForm.changeProfile)
                        {
                            table3.OpenTable("wb_user", "SELECT * FROM wb_user WHERE " + WBData.CompanyLocation(" AND user_id = '" + UserID + "'"), WBData.conn);
                            if (table3.DT.Rows.Count > 0)
                            {
                                table3.DR = table3.DT.Rows[0];
                                keyField = table3.DR["uniq"].ToString();
                                table3.DR.BeginEdit();
                                table3.DR["lastLogout"] = DateTime.Now;
                                table3.DR["lastLogoutIP"] = DateTime.Now.ToString("HH:mm:ss") + localIP;
                                table3.DR["lastLogoutCompName"] = DateTime.Now.ToString("HH:mm:ss") + ComName;
                                table3.DR["checksum"] = table3.Checksum(table3.DR);
                                table3.DR.EndEdit();
                                table3.Save();
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "LOGSYS", UserID, "Logout from system" };
                                Program.updateLogHeader("wb_user", keyField, logField, logValue);
                            }
                            MainForm.changeProfile = false;
                        }
                        UserID = login.tbl.DR["User_Id"].ToString();
                        UserName = login.tbl.DR["User_Name"].ToString();
                        UserGroup = login.tbl.DR["User_Group"].ToString();
                        UserLevel = login.tbl.DR["User_Level"].ToString();
                        UserPass = Program.shoot(login.tbl.DR["User_Pass"].ToString(), false);
                        WBData.sCoyCode = login.tbl.DR["Coy"].ToString();
                        WBData.sLocCode = login.tbl.DR["Location_Code"].ToString();
                        table3.OpenTable("wb_user", "SELECT * FROM wb_user WHERE " + WBData.CompanyLocation(" AND user_id = '" + UserID + "'"), WBData.conn);
                        if (table3.DT.Rows.Count > 0)
                        {
                            table3.DR = table3.DT.Rows[0];
                            keyField = table3.DR["uniq"].ToString();
                            table3.DR.BeginEdit();
                            table3.DR["lastLogin"] = DateTime.Now;
                            table3.DR["lastLoginResult"] = DateTime.Now.ToString("HH:mm:ss") + "S";
                            table3.DR["lastLoginIP"] = DateTime.Now.ToString("HH:mm:ss") + localIP;
                            table3.DR["lastLoginCompName"] = DateTime.Now.ToString("HH:mm:ss") + ComName;
                            table3.DR["checksum"] = table3.Checksum(table3.DR);
                            table3.DR.EndEdit();
                            table3.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "LOGSYS", UserID, "Login to system" };
                            Program.updateLogHeader("wb_user", keyField, logField, logValue);
                        }
                        table3.Dispose();
                        WBConfigurationHandler.createDirectory();
                        if (File.Exists(WBConfigurationHandler.configurationFile))
                        {
                            Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                                { 
                                    "COY",
                                    login.tbl.DR["Coy"].ToString().Trim()
                                },
                                { 
                                    "LOC",
                                    login.tbl.DR["Location_Code"].ToString().Trim()
                                }
                            };
                            WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                            dictToTxt.Clear();
                        }
                        else
                        {
                            RegistryKey key6 = Registry.LocalMachine.OpenSubKey("SOFTWARE", true);
                            RegistryKey key7 = key6.OpenSubKey("WCS DATABASE");
                            RegistryKey key8 = key6.CreateSubKey("WCS DATABASE").CreateSubKey("WB System");
                            key8.SetValue("Coy_Code", login.tbl.DR["Coy"].ToString().Trim(), RegistryValueKind.String);
                            key8.SetValue("Loc_Code", login.tbl.DR["Location_Code"].ToString().Trim(), RegistryValueKind.String);
                            Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                                { 
                                    "COY",
                                    login.tbl.DR["Coy"].ToString().Trim()
                                },
                                { 
                                    "LOC",
                                    login.tbl.DR["Location_Code"].ToString().Trim()
                                }
                            };
                            WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                            dictToTxt.Clear();
                        }
                        if (!WBRun || CheckTrustee("MULTI_SESSION", "V"))
                        {
                            FormUserEntry entry = new FormUserEntry();
                            if (!entry.checkPass_IsDefault(UserPass))
                            {
                                if (!entry.checkPassComplexity(UserPass))
                                {
                                    MessageBox.Show("Current Password is too Simple, Please Reset Password to Continue...", "W A R N I N G");
                                    entry.pMode = "EDIT";
                                    entry.pMode2 = "RESET";
                                    WBTable table5 = new WBTable();
                                    table5.OpenTable("wb_user", "Select * from wb_user where " + WBData.CompanyLocation(" and user_id = '" + UserID + "'"), WBData.conn);
                                    entry.nCurrRow = table5.GetPosRec(table5.DT.Rows[0]["uniq"].ToString().Trim());
                                    entry.Text = "Reset Password";
                                    entry.zTable = table5;
                                    entry.ShowDialog();
                                    if (!entry.saved)
                                    {
                                        MessageBox.Show("Current Password is too Simple, Please Reset Password....\nApllication Will now Close... \nPlease ReOpen WB.Net to Reset Password", "RESET PASSWORD...");
                                        table5.Dispose();
                                        entry.Dispose();
                                        return false;
                                    }
                                    else
                                    {
                                        MessageBox.Show("Success Change Password, Thank You...", "RESET PASSWORD...");
                                        table5.Dispose();
                                        entry.Dispose();
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("Current Password is still the Default Generated Password, Please Change Password to Continue...", "W A R N I N G");
                                entry.pMode = "EDIT";
                                entry.pMode2 = "CHANGE_FROM_DEFAULT";
                                WBTable table4 = new WBTable();
                                table4.OpenTable("wb_user", "Select * from wb_user where " + WBData.CompanyLocation(" and user_id = '" + UserID + "' and coy is not null and location_code is not null"), WBData.conn);
                                entry.nCurrRow = table4.GetPosRec(table4.DT.Rows[0]["uniq"].ToString().Trim());
                                entry.Text = "Change Password";
                                entry.zTable = table4;
                                entry.ShowDialog();
                                if (!entry.saved)
                                {
                                    MessageBox.Show("Current Password is still the Default Generated Password, Please Change Password....\nApllication Will now Close... \nPlease ReOpen WB.Net to Change Password", "CHANGE PASSWORD...");
                                    table4.Dispose();
                                    entry.Dispose();
                                    return false;
                                }
                                else
                                {
                                    MessageBox.Show("Successfully Change Password for all locations., Thank You...", "CHANGE PASSWORD...");
                                    table4.Dispose();
                                    entry.Dispose();
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_537, "STOP <mutex>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            Application.Exit();
                            return false;
                        }
                        break;
                    }
                }
                else
                {
                    flag = true;
                    UserID = login.userID;
                    UserName = login.userName;
                    UserGroup = login.userGroup;
                    string userGroup = UserGroup;
                    UserLevel = (userGroup == "ADMIN") ? "1" : ((userGroup == "MGR") ? "2" : "3");
                    UserPass = login.password;
                    WBData.sCoyCode = login.ADCoy;
                    WBData.sLocCode = login.ADLocation_Code;
                    WBTable table = new WBTable();
                    table.OpenTable("wb_setting", "Select * from wb_setting where " + WBData.CompanyLocation(" and wbCode = '" + WBData.sWBCode + "'"), WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        table.DR = table.DT.Rows[0];
                        string keyField = table.DR["uniq"].ToString();
                        table.DR.BeginEdit();
                        table.DR["version"] = login.prodVersion;
                        table.DR["CompName"] = Environment.MachineName;
                        table.DR["LastLogin"] = DateTime.Now;
                        table.DR.EndEdit();
                        table.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "LOAD-LOGIN", "SYSTEM", "Load login form" };
                        Program.updateLogHeader("wb_setting", keyField, logField, logValue);
                    }
                    if (!WBRun || CheckTrustee("MULTI_SESSION", "V"))
                    {
                        WBConfigurationHandler.createDirectory();
                        if (File.Exists(WBConfigurationHandler.configurationFile))
                        {
                            Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                                { 
                                    "COY",
                                    login.ADCoy.Trim()
                                },
                                { 
                                    "LOC",
                                    login.ADLocation_Code.Trim()
                                }
                            };
                            WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                            dictToTxt.Clear();
                        }
                        else
                        {
                            RegistryKey key2 = Registry.LocalMachine.OpenSubKey("SOFTWARE", true);
                            RegistryKey key3 = key2.OpenSubKey("WCS DATABASE");
                            RegistryKey key4 = key2.CreateSubKey("WCS DATABASE").CreateSubKey("WB System");
                            key4.SetValue("Coy_Code", login.ADCoy.Trim(), RegistryValueKind.String);
                            key4.SetValue("Loc_Code", login.ADLocation_Code.Trim(), RegistryValueKind.String);
                            Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                                { 
                                    "COY",
                                    login.ADCoy.Trim()
                                },
                                { 
                                    "LOC",
                                    login.ADLocation_Code.ToString().Trim()
                                }
                            };
                            WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                            dictToTxt.Clear();
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_537, "STOP <mutex>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        Application.Exit();
                        return false;
                    }
                }
                login.Dispose();
                flag9 = flag;
            }
            return flag9;
        }

        public static void ShowErr()
        {
            MessageBox.Show(Resource.Mes_565, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        }
    }
}

