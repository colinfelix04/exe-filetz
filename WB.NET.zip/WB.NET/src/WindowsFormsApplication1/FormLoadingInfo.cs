﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text.RegularExpressions;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormLoadingInfo : Form
    {
        private WBTable tblTrans = new WBTable();
        private WBTable tblTransTemp = new WBTable();
        private WBTable tblTransDO = new WBTable();
        private WBTable tblTransporter = new WBTable();
        private WBTable tblDOSAP = new WBTable();
        private WBTable tblComm = new WBTable();
        private WBTable tblComm2 = new WBTable();
        private WBTable tblTransType = new WBTable();
        private int nCurrRowDO = 0;
        private double before;
        private string commcode = "";
        private string transtype = "";
        private string dono = "";
        private string PINo = "";
        private string indic = "";
        private string transporter = "";
        private string RCode = "";
        private string EstateCode = "";
        private string gatepass_no = "";
        public string oldComm = "";
        public string logKey = "";
        private string WX = "";
        private bool link = false;
        public DataGridView dgv = new DataGridView();
        private string tempRef = "";
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        public TextBox txtRefNo;
        private Label lblVehicle;
        private TextBox txtVehicle;
        private Label lblRef;
        private Label lblMS;
        private TextBox txtMS;
        private Label lblKG;
        private DataGridView dgvDO;
        private Button btnSave;
        private Button btnCancel;
        private StatusStrip statusStrip1;
        private ToolTip toolTipInformation;
        private Label label1;
        public Button buttonDeleteDO;
        private Button buttonEditDO;
        private Button buttonAddDO;
        private Label label35;
        public TextBox textRef_Date;
        private Label label3;
        private TextBox textDriverID;
        private Label labelDriverName;
        private TextBox textReport_Date;
        private Label label37;
        private Label labelArrow;
        public TextBox textRefTemp;
        private Button buttonLink;
        public Button buttonBrowse;
        private Panel panelLink;
        private Button buttonUnlink;
        public Button buttonDeleteAllDO;
        private TableLayoutPanel tableLayoutPanel1;
        private Label lblTotalItem;
        private Label label2;
        private Label label6;
        private Label lblTotalDOQtyInKG;
        private Label label8;

        public FormLoadingInfo()
        {
            this.InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (this.dgvDO.Rows.Count != 0)
            {
                string[] source = new string[this.dgvDO.Rows.Count];
                int index = 0;
                bool flag = false;
                Cursor.Current = Cursors.WaitCursor;
                foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
                {
                    if ((!string.IsNullOrEmpty(row.Cells["do_sap"].Value.ToString()) && ((row.Cells["do_sap"].Value != null) && (!string.IsNullOrEmpty(row.Cells["do_sap_item"].Value.ToString()) && (row.Cells["do_sap_item"].Value != null)))) && (row.Cells["do_besar"].Value.ToString() != "X"))
                    {
                        string str = row.Cells["do_sap"].Value.ToString() + row.Cells["do_sap_item"].Value.ToString();
                        if (source.Contains<string>(str))
                        {
                            flag = true;
                            break;
                        }
                        source[index] = str;
                        index++;
                    }
                }
                if (!flag)
                {
                    TextBox[] aText = new TextBox[] { this.txtMS };
                    if (!Program.CheckEmpty(aText))
                    {
                        int num2 = 0;
                        using (IEnumerator enumerator2 = ((IEnumerable) this.dgvDO.Rows).GetEnumerator())
                        {
                            while (true)
                            {
                                if (!enumerator2.MoveNext())
                                {
                                    break;
                                }
                                DataGridViewRow current = (DataGridViewRow) enumerator2.Current;
                                if ((current.Cells["do_base_qty"].Value == null) || (current.Cells["do_base_qty"].Value.ToString() == ""))
                                {
                                    current.Cells["do_base_qty"].Value = "0";
                                }
                                if ((current.Cells["Loading_Qty"].Value == null) || (current.Cells["Loading_Qty"].Value.ToString() == ""))
                                {
                                    current.Cells["Loading_Qty"].Value = "0";
                                }
                                if ((current.Cells["loading_qty_opw"].Value == null) || (current.Cells["loading_qty_opw"].Value.ToString() == ""))
                                {
                                    current.Cells["loading_qty_opw"].Value = "0";
                                }
                                if ((current.Cells["return_qty_kg"].Value == null) || (current.Cells["return_qty_kg"].Value.ToString() == ""))
                                {
                                    current.Cells["return_qty_kg"].Value = 0;
                                }
                                if ((current.Cells["return_qty_pack"].Value == null) || (current.Cells["return_qty_pack"].Value.ToString() == ""))
                                {
                                    current.Cells["return_qty_pack"].Value = 0;
                                }
                                if ((current.Cells["Density"].Value == null) || (current.Cells["Density"].Value.ToString() == ""))
                                {
                                    current.Cells["Density"].Value = "0";
                                }
                                if (Convert.ToDouble(current.Cells["do_base_qty"].Value) > 0.0)
                                {
                                    if (Convert.ToDouble(current.Cells["Loading_Qty"].Value) <= Convert.ToDouble(current.Cells["do_base_qty"].Value))
                                    {
                                        if ((current.Cells["DO_BESAR"].Value.ToString() != "") && (Convert.ToDouble(this.checkOS(current.Cells["do_sap"].Value.ToString(), current.Cells["do_sap_item"].Value.ToString(), current.Cells["Ref"].Value.ToString(), Convert.ToDouble(current.Cells["loading_qty"].Value))) > Convert.ToDouble(current.Cells["do_base_qty"].Value)))
                                        {
                                            double num6 = Convert.ToDouble(current.Cells["do_base_qty"].Value) - Convert.ToDouble(this.before);
                                            object[] objArray1 = new object[15];
                                            objArray1[0] = "Over Quantity DO ";
                                            objArray1[1] = this.sapIDSYS;
                                            objArray1[2] = ": ";
                                            objArray1[3] = current.Cells["do_sap"].Value;
                                            objArray1[4] = "/";
                                            objArray1[5] = current.Cells["do_sap_item"].Value;
                                            objArray1[6] = "\nDO ";
                                            objArray1[7] = this.sapIDSYS;
                                            objArray1[8] = " Qty = ";
                                            objArray1[9] = Convert.ToDouble(current.Cells["do_base_qty"].Value);
                                            objArray1[10] = "\nLoading Qty in other trans = ";
                                            objArray1[11] = this.before.ToString();
                                            objArray1[12] = "\nLoading Qty left = ";
                                            objArray1[13] = num6.ToString();
                                            objArray1[14] = "\n";
                                            MessageBox.Show(string.Concat(objArray1), "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Loading Qty is greater than Do Base Qty");
                                        return;
                                    }
                                }
                                WBTable table = new WBTable();
                                WBTable table2 = new WBTable();
                                WBTable table3 = new WBTable();
                                WBCondition condition = new WBCondition();
                                WBCondition condition2 = new WBCondition();
                                WBCondition condition3 = new WBCondition();
                                string[] textArray2 = new string[] { "SELECT * FROM wb_commodity WHERE ", WBData.CompanyLocation(""), " AND comm_code = '", current.Cells["comm_code"].Value.ToString(), "'" };
                                table.OpenTable("wb_commodity", string.Concat(textArray2), WBData.conn);
                                string[] textArray3 = new string[] { "SELECT * FROM wb_transaction_type WHERE ", WBData.CompanyLocation(""), " AND transaction_code = '", current.Cells["transaction_code"].Value.ToString(), "'" };
                                table2.OpenTable("wb_transaction_type", string.Concat(textArray3), WBData.conn);
                                string[] textArray4 = new string[] { "SELECT * FROM wb_contract WHERE ", WBData.CompanyLocation(""), " AND do_no = '", current.Cells["do_no"].Value.ToString(), "'" };
                                table3.OpenTable("wb_contract", string.Concat(textArray4), WBData.conn);
                                DataRow[] dgRows = new DataRow[] { table.DT.Rows[0], table2.DT.Rows[0] };
                                condition.fillParameter("LOADING_NO_FLOWMETER", dgRows);
                                DataRow[] rowArray2 = new DataRow[] { table.DT.Rows[0], table2.DT.Rows[0] };
                                condition2.fillParameter("LOADING_WITH_FLOWMETER", rowArray2);
                                DataRow[] rowArray3 = new DataRow[] { table.DT.Rows[0] };
                                condition3.fillParameter("CALC_DENSITY_TO_SPAREPARTQTY", rowArray3);
                                if (!condition3.getResult() || !(string.IsNullOrEmpty(current.Cells["Density"].Value.ToString()) || current.Cells["Density"].Value.ToString().Equals("0")))
                                {
                                    if (condition.getResult())
                                    {
                                        if (table3.DT.Rows[0]["calcLoadingQtyAutomatically"].ToString() != "Y")
                                        {
                                            if ((string.IsNullOrEmpty(current.Cells["Density"].Value.ToString()) || (current.Cells["Density"].Value.ToString().Equals("0") || string.IsNullOrEmpty(current.Cells["Loading_Qty"].Value.ToString()))) || current.Cells["Loading_Qty"].Value.ToString().Equals("0"))
                                            {
                                                MessageBox.Show(Resource.FormLoadingInfo_002, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                return;
                                            }
                                        }
                                        else if (string.IsNullOrEmpty(current.Cells["Density"].Value.ToString()) || current.Cells["Density"].Value.ToString().Equals("0"))
                                        {
                                            MessageBox.Show(Resource.FormLoadingInfo_001, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                            return;
                                        }
                                    }
                                    if (condition2.getResult() && ((string.IsNullOrEmpty(current.Cells["Density"].Value.ToString()) || (current.Cells["Density"].Value.ToString().Equals("0") || string.IsNullOrEmpty(current.Cells["Loading_Qty"].Value.ToString()))) || current.Cells["Loading_Qty"].Value.ToString().Equals("0")))
                                    {
                                        MessageBox.Show(Resource.FormLoadingInfo_002, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    }
                                    else if (((Convert.ToDouble(current.Cells["Density"].Value) >= 1.0) || (Convert.ToDouble(current.Cells["Density"].Value) <= 0.0)) ? condition2.getResult() : false)
                                    {
                                        MessageBox.Show(Resource.FormLoadingInfo_003, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    }
                                    else if (((Convert.ToDouble(current.Cells["Density"].Value) > 2.0) || (Convert.ToDouble(current.Cells["Density"].Value) <= 0.0)) ? condition3.getResult() : false)
                                    {
                                        MessageBox.Show(Resource.FormLoadingInfo_005, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    }
                                    else
                                    {
                                        if (!WBSetting.activeTCS || (!(((current.Cells["do_sap"].Value == null) || (current.Cells["do_sap"].Value.ToString() == "")) ? ((current.Cells["internal_number"].Value != null) && (current.Cells["internal_number"].Value.ToString() != "")) : true) || ((condition.getResult() && (table3.DT.Rows[0]["calcLoadingQtyAutomatically"].ToString() == "Y")) || !(((current.Cells["loading_qty"].Value == null) || ((current.Cells["loading_qty"].Value.ToString() == "") || (current.Cells["loading_qty"].Value.ToString() == "0"))) ? (this.tblComm.DT.Rows[0]["UNIT"].ToString() != "KG") : false))))
                                        {
                                            table.Dispose();
                                            table2.Dispose();
                                            table3.Dispose();
                                            condition.Dispose();
                                            condition2.Dispose();
                                            condition3.Dispose();
                                            num2++;
                                            continue;
                                        }
                                        MessageBox.Show("Please entry loading quantity for DO " + current.Cells["do_no"].Value.ToString() + "!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        this.dgvDO.CurrentCell = this.dgvDO.Rows[num2].Cells["do_no"];
                                        this.dgvDO.Rows[num2].Selected = true;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(Resource.FormLoadingInfo_001, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                return;
                            }
                        }
                        if ((this.tblTrans.DT.Rows[0]["report_date"] == null) || (this.tblTrans.DT.Rows[0]["report_date"].ToString() == ""))
                        {
                            string[] textArray5 = new string[] { "Select * from wb_transDO where coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "' And Ref like '", this.txtRefNo.Text, "%'" };
                            this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray5), WBData.conn);
                        }
                        else
                        {
                            string[] textArray6 = new string[] { "Select * from wb_transDO where coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "' And Ref like '", this.txtRefNo.Text, "%'" };
                            this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray6), WBData.conn);
                            if (this.tblTransDO.DT.Rows.Count > 1)
                            {
                                int num7 = 0;
                                foreach (DataRow row3 in this.tblTransDO.DT.Rows)
                                {
                                    WBTable table4 = new WBTable();
                                    table4.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref = '" + row3["ref"].ToString() + "'"), WBData.conn);
                                    if (table4.DT.Rows.Count > 0)
                                    {
                                        num7++;
                                    }
                                    table4.Dispose();
                                }
                                if (num7 > 1)
                                {
                                    string[] textArray7 = new string[] { "select * from wb_transDO where coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "' And Ref = '", this.txtRefNo.Text, "'" };
                                    this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray7), WBData.conn);
                                }
                                else
                                {
                                    string[] textArray8 = new string[] { "Select * from wb_transDO where coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "' And Ref like '", this.txtRefNo.Text, "%'" };
                                    this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray8), WBData.conn);
                                }
                            }
                        }
                        string str2 = "";
                        int num3 = 0x40;
                        int num4 = 0;
                        if (this.tblTransDO.DT.Rows.Count > 0)
                        {
                            string[] aField = new string[] { "ref" };
                            string[] aFind = new string[] { this.txtRefNo.Text + "AA" };
                            this.tblTrans.DR = this.tblTrans.GetData(aField, aFind);
                            foreach (DataRow row4 in this.tblTransDO.DT.Rows)
                            {
                                if (row4["Ref"].ToString() == this.txtRefNo.Text)
                                {
                                    row4.Delete();
                                    continue;
                                }
                                if ((this.tblTrans.DR == null) && row4["Ref"].ToString().Contains(this.txtRefNo.Text))
                                {
                                    row4.Delete();
                                }
                            }
                            this.tblTransDO.Save();
                            string[] textArray11 = new string[] { "ref" };
                            string[] textArray12 = new string[] { this.txtRefNo.Text };
                            this.tblTrans.DR = this.tblTrans.GetData(textArray11, textArray12);
                        }
                        foreach (DataGridViewRow row5 in (IEnumerable) this.dgvDO.Rows)
                        {
                            this.tblTransDO.DR = this.tblTransDO.DT.NewRow();
                            int num8 = 0;
                            while (true)
                            {
                                if (num8 >= this.tblTransDO.DT.Columns.Count)
                                {
                                    this.tblTransDO.DR["Coy"] = WBData.sCoyCode;
                                    this.tblTransDO.DR["Location_Code"] = WBData.sLocCode;
                                    this.tblTransDO.DR["estate_qty"] = row5.Cells["estate_qty"].Value.ToString();
                                    this.tblTransDO.DR["Netto"] = row5.Cells["Netto"].Value.ToString();
                                    this.tblTransDO.DR["Ref"] = (num4 != 0) ? (this.txtRefNo.Text + WBUtility.getSplitV2Ext(num3)) : this.txtRefNo.Text;
                                    this.tblTransDO.DR["Gatepass_Number"] = this.gatepass_no;
                                    this.tblTransDO.DT.Rows.Add(this.tblTransDO.DR);
                                    this.tblTransDO.Save();
                                    num4++;
                                    num3++;
                                    break;
                                }
                                str2 = this.tblTransDO.DT.Columns[num8].ColumnName.ToString();
                                if (((str2.ToUpper() != "UNIQ".ToUpper()) && (str2.ToUpper() != "COMM_NAME".ToUpper())) && ((row5.Cells[str2].Value != null) && (row5.Cells[str2].Value.ToString().Trim() != "")))
                                {
                                    this.tblTransDO.DR[str2] = row5.Cells[str2].Value;
                                }
                                if (str2 == "Density")
                                {
                                    this.tblTransDO.DR[str2] = float.Parse(row5.Cells[str2].Value.ToString()).ToString("N4");
                                }
                                num8++;
                            }
                        }
                        this.tblTrans.DR = this.tblTrans.DT.Rows[0];
                        this.logKey = this.tblTrans.DR["uniq"].ToString();
                        this.tblTrans.DR.BeginEdit();
                        this.tblTrans.DR["PI_NO"] = this.PINo;
                        this.tblTrans.DR["tolling"] = this.dgvDO.Rows[0].Cells["tolling"].Value.ToString();
                        this.tblTrans.DR["Transaction_code"] = this.transtype;
                        this.tblTrans.DR["Comm_code"] = this.commcode;
                        this.tblTrans.DR["Relation_code"] = this.RCode;
                        this.tblTrans.DR["Estate_code"] = this.EstateCode;
                        this.tblTrans.DR["Do_No"] = this.dono;
                        this.tblTrans.DR["Transporter_Code"] = this.transporter;
                        this.tblTrans.DR["Change_By"] = WBUser.UserID;
                        this.tblTrans.DR["Change_Date"] = DateTime.Now;
                        this.tblTrans.DR["Posted"] = "N";
                        this.tblTrans.DR["Reposted"] = "N";
                        this.tblTrans.DR["materialStuffing"] = this.txtMS.Text;
                        this.tblTrans.DR["checksum"] = this.tblTrans.Checksum(this.tblTrans.DR);
                        this.tblTrans.DR.EndEdit();
                        this.tblTrans.Save();
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { "EDIT", WBUser.UserID, "Entry Loading Info" };
                        Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                        base.Close();
                    }
                    else
                    {
                        MessageBox.Show("Please Entry Material Stuffing Quantity...", "WARNING");
                    }
                }
                else
                {
                    string[] textArray1 = new string[] { "There are two or more same DO ", this.sapIDSYS, " and DO ", this.sapIDSYS, " Item No." };
                    MessageBox.Show(string.Concat(textArray1), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_292, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void buttonActivation()
        {
            if (this.textRefTemp.Text != "")
            {
                this.buttonLink.Enabled = true;
                this.buttonUnlink.Enabled = true;
                this.buttonAddDO.Enabled = true;
                this.buttonEditDO.Enabled = true;
                this.buttonDeleteDO.Enabled = true;
                this.dgvDO.Enabled = true;
                this.txtMS.Enabled = true;
                this.dgvDO.Columns["loading_qty"].DefaultCellStyle.BackColor = Color.White;
            }
            else
            {
                this.buttonLink.Enabled = false;
                this.buttonUnlink.Enabled = false;
                this.buttonAddDO.Enabled = false;
                this.buttonEditDO.Enabled = false;
                this.buttonDeleteDO.Enabled = false;
                this.buttonDeleteAllDO.Enabled = false;
                this.dgvDO.Enabled = false;
                this.txtMS.Enabled = false;
                this.dgvDO.Columns["loading_qty"].DefaultCellStyle.BackColor = Color.LightGray;
            }
        }

        private void buttonAddDO_Click(object sender, EventArgs e)
        {
            this.entryDO("ADD");
            this.countAdditionalInformation();
        }

        private void buttonBrowse_Click(object sender, EventArgs e)
        {
            this.tempRef = this.textRefTemp.Text;
            FormTransactionContainerOut @out = new FormTransactionContainerOut {
                pMode = "CHOOSE"
            };
            @out.ShowDialog();
            if (@out.ReturnRow != null)
            {
                this.textRefTemp.Text = @out.ReturnRow["ref"].ToString();
                this.buttonLink.Focus();
            }
            @out.Dispose();
            if (this.textRefTemp.Text.Trim() != "")
            {
                this.buttonLink.Enabled = true;
            }
        }

        private void buttonDeleteAllDO_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Resource.Mes_629, "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                int index = this.dgvDO.Rows.Count - 1;
                while (true)
                {
                    if (index <= -1)
                    {
                        this.countAdditionalInformation();
                        break;
                    }
                    this.dgvDO.Rows.RemoveAt(index);
                    index--;
                }
            }
        }

        private void buttonDeleteDO_Click(object sender, EventArgs e)
        {
            if (this.dgvDO.Rows.Count > 0)
            {
                int index = this.dgvDO.CurrentRow.Index;
                if (MessageBox.Show(" Are you sure to deleted this record ? ", "C O N F I R M", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    this.dgvDO.Rows.Remove(this.dgvDO.Rows[index]);
                    this.countAdditionalInformation();
                }
            }
        }

        private void buttonEditDO_Click(object sender, EventArgs e)
        {
            this.entryDO("EDIT");
            this.countAdditionalInformation();
        }

        private void buttonLink_Click(object sender, EventArgs e)
        {
            this.tblTrans.DR = this.tblTrans.DT.Rows[0];
            if ((this.tblTrans.DR["_4th"].ToString() != "0") && (this.tblTrans.DR["_4th"].ToString() != ""))
            {
                MessageBox.Show("Can't link transaction since it's been weighed for 4 times!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else if (MessageBox.Show("Are you sure want to LINK reference " + this.txtRefNo.Text.Trim() + " to reference " + this.textRefTemp.Text.Trim(), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                if (this.tempRef != this.textRefTemp.Text)
                {
                    this.linkRef(false);
                    this.tempRef = this.textRefTemp.Text;
                    this.linkRef(true);
                }
                this.link = true;
                MessageBox.Show("Reference " + this.txtRefNo.Text + " has been linked successfuly to " + this.textRefTemp.Text, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.buttonActivation();
            }
        }

        private void buttonUnlink_Click(object sender, EventArgs e)
        {
            this.tblTrans.DR = this.tblTrans.DT.Rows[0];
            if ((this.tblTrans.DR["_4th"].ToString() != "0") && (this.tblTrans.DR["_4th"].ToString() != ""))
            {
                MessageBox.Show("Can't unlink transaction since it's been weighed for 4 times!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else if (MessageBox.Show("Are you sure want to UNLINK reference " + this.txtRefNo.Text.Trim() + " to reference " + this.textRefTemp.Text.Trim(), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.linkRef(false);
                this.link = false;
                MessageBox.Show("Reference " + this.txtRefNo.Text + " has been unlinked successfuly to " + this.textRefTemp.Text, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.textRefTemp.Text = "";
                this.buttonActivation();
            }
        }

        private double checkOS(string do_sap, string do_sap_item, string ref_no, double load_qty)
        {
            double num;
            this.before = 0.0;
            WBTable table = new WBTable();
            string sqltext = "Select " + " sum(do.loading_qty) as loading_qty";
            string[] textArray1 = new string[12];
            textArray1[0] = sqltext;
            textArray1[1] = " FROM wb_transaction as ts RIGHT OUTER JOIN  wb_transDO as do ON ts.Ref = do.Ref AND ts.Coy = do.Coy AND  ts.Location_Code = do.Location_Code  WHERE (ts.mark_accident IS NULL or ts.mark_accident = '') AND (ts.Deleted IS NULL or ts.Deleted = '')  and do.do_sap = '";
            textArray1[2] = do_sap;
            textArray1[3] = "' and do.do_sap_item = '";
            textArray1[4] = do_sap_item;
            textArray1[5] = "' and do.ref <> '";
            textArray1[6] = ref_no;
            textArray1[7] = "' and do.coy = '";
            textArray1[8] = WBData.sCoyCode;
            textArray1[9] = "' and do.location_code = '";
            textArray1[10] = WBData.sLocCode;
            textArray1[11] = "' ";
            sqltext = string.Concat(textArray1);
            table.OpenTable("vw_outstanding", sqltext, WBData.conn);
            if ((table.DT.Rows[0]["loading_qty"].ToString() == "") || (table.DT.Rows[0]["loading_qty"].ToString() == null))
            {
                num = Convert.ToDouble(load_qty);
            }
            else
            {
                this.before = Convert.ToDouble(table.DT.Rows[0]["loading_qty"].ToString());
                num = Convert.ToDouble(table.DT.Rows[0]["loading_qty"].ToString()) + Convert.ToDouble(load_qty);
            }
            return num;
        }

        private void countAdditionalInformation()
        {
            int count = 0;
            double num2 = 0.0;
            count = this.dgvDO.Rows.Count;
            foreach (DataGridViewRow row in (IEnumerable) this.dgvDO.Rows)
            {
                num2 += Program.StrToDouble(row.Cells["DO_QTY_KG"].Value.ToString(), 3);
            }
            this.lblTotalItem.Text = count.ToString();
            this.lblTotalDOQtyInKG.Text = num2.ToString("0.###");
        }

        private void dgvDO_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            try
            {
                if (this.dgvDO.Rows[e.RowIndex].Cells["Internal_Number"].Value.ToString() != "")
                {
                    this.dgvDO.Columns["DO_SAP"].Visible = false;
                    this.dgvDO.Columns["DO_SAP_Item"].Visible = false;
                    this.dgvDO.Columns["Internal_Number"].Visible = true;
                    this.dgvDO.Columns["Internal_Number_Item"].Visible = true;
                }
                else
                {
                    this.dgvDO.Columns["DO_SAP"].Visible = true;
                    this.dgvDO.Columns["DO_SAP_Item"].Visible = true;
                    this.dgvDO.Columns["Internal_Number"].Visible = false;
                    this.dgvDO.Columns["Internal_Number_Item"].Visible = false;
                }
            }
            catch
            {
            }
        }

        private void dgvDO_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex == 3)
            {
                int num;
                if (!int.TryParse(Convert.ToString(e.FormattedValue), out num))
                {
                    e.Cancel = true;
                    MessageBox.Show("Please entry numeric only", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            else if (e.ColumnIndex == 0x29)
            {
                if (!Program.CheckNumericForLoadingQty(Convert.ToString(e.FormattedValue)))
                {
                    e.Cancel = true;
                }
            }
            else
            {
                double num2;
                if ((e.ColumnIndex == 60) && !double.TryParse(Convert.ToString(e.FormattedValue), out num2))
                {
                    e.Cancel = true;
                    MessageBox.Show("Please entry numeric only", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
        }

        private void dgvDO_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (((DataGridView) sender).CurrentCell.ColumnIndex == 0x29)
            {
                e.Control.KeyPress -= new KeyPressEventHandler(this.TextboxLoadingQty_KeyPress);
                e.Control.KeyPress += new KeyPressEventHandler(this.TextboxLoadingQty_KeyPress);
            }
            else if (((DataGridView) sender).CurrentCell.ColumnIndex == 60)
            {
                e.Control.KeyPress -= new KeyPressEventHandler(this.TextboxDensity_KeyPress);
                e.Control.KeyPress += new KeyPressEventHandler(this.TextboxDensity_KeyPress);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void entryDO(string doEntryMode)
        {
            FormTransDOEntry fr = new FormTransDOEntry {
                Text = doEntryMode + " DO item",
                RefNo = this.txtRefNo.Text.Trim(),
                refDate = this.textRef_Date.Text,
                doEntryMode = doEntryMode,
                pMode = "LOADQTY",
                hasBeenWeighedOut = this.tblTrans.DT.Rows[0]["report_date"].ToString() != "",
                tblTransDO = this.tblTransDO,
                tblComm = this.tblComm,
                dgvDO = this.dgvDO
            };
            if (doEntryMode == "EDIT")
            {
                fr.dgvDOCurrRow = this.dgvDO.CurrentRow.Index;
                fr.oldComm = this.oldComm;
                fr.textDO.Text = this.dgvDO.CurrentRow.Cells["DO_No"].Value.ToString();
                fr.text_do_sap.Text = this.dgvDO.CurrentRow.Cells["do_sap"].Value.ToString();
                fr.text_do_sap_item.Text = this.dgvDO.CurrentRow.Cells["do_sap_item"].Value.ToString();
                fr.txtInternalNum.Text = this.dgvDO.CurrentRow.Cells["internal_number"].Value.ToString();
                fr.txtInNumItem.Text = this.dgvDO.CurrentRow.Cells["internal_number_item"].Value.ToString();
                fr.textBoxBaseUOM.Text = this.dgvDO.CurrentRow.Cells["DO_base_uom"].Value.ToString();
                fr.text_do_sap_qty.Text = this.dgvDO.CurrentRow.Cells["do_qty"].Value.ToString();
                fr.text_do_sap_unit.Text = this.dgvDO.CurrentRow.Cells["do_uom"].Value.ToString();
                fr.textBoxQtyBaseUOM.Text = this.dgvDO.CurrentRow.Cells["do_base_qty"].Value.ToString();
                fr.text_do_sap_qty_kg.Text = this.dgvDO.CurrentRow.Cells["do_qty_kg"].Value.ToString();
                fr.indic = this.dgvDO.CurrentRow.Cells["do_besar"].Value.ToString();
                fr.transType = this.dgvDO.CurrentRow.Cells["Transaction_Code"].Value.ToString();
                fr.textSOItem_detail.Text = this.dgvDO.CurrentRow.Cells["so_item_detail"].Value.ToString();
            }
            fr.ShowDialog();
            if (fr.saved)
            {
                if (fr.retTable_DSAP_DO.Rows.Count > 0)
                {
                    this.fillDGV_fromTransDOEntry(fr, doEntryMode, true, false, false);
                }
                else if (fr.retTable_DSAP_DOTRX.Rows.Count > 0)
                {
                    this.fillDGV_fromTransDOEntry(fr, doEntryMode, false, true, false);
                }
                else if (fr.retTable_DSAP_DR.Rows.Count > 0)
                {
                    this.fillDGV_fromTransDOEntry(fr, doEntryMode, false, false, true);
                }
                else
                {
                    if (doEntryMode == "ADD")
                    {
                        this.dgvDO.Rows.Add();
                        this.nCurrRowDO = this.dgvDO.Rows.Count - 1;
                    }
                    else if (doEntryMode == "EDIT")
                    {
                        this.nCurrRowDO = this.dgvDO.CurrentRow.Index;
                    }
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Coy"].Value = WBData.sCoyCode;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Location_Code"].Value = WBData.sLocCode;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Transaction_Code"].Value = fr.transType;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Ref"].Value = this.txtRefNo.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["do_sap"].Value = fr.text_do_sap.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["do_sap_item"].Value = fr.text_do_sap_item.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["DO_No"].Value = fr.textDO.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["internal_number"].Value = fr.txtInternalNum.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["internal_number_item"].Value = fr.txtInNumItem.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["DO_base_uom"].Value = fr.textBoxBaseUOM.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["do_qty"].Value = fr.text_do_sap_qty.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["do_uom"].Value = fr.text_do_sap_unit.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["do_base_qty"].Value = fr.textBoxQtyBaseUOM.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["do_qty_kg"].Value = fr.text_do_sap_qty_kg.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Comm_Code"].Value = fr.textComm.Text;
                    string[] textArray1 = new string[] { "Select * from wb_commodity where coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "' And comm_code = '", fr.textComm.Text, "'" };
                    this.tblComm2.OpenTable("wb_commodity", string.Concat(textArray1), WBData.conn);
                    if (this.tblComm2.DT.Rows.Count > 0)
                    {
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["Comm_Name"].Value = this.tblComm2.DT.Rows[0]["Comm_Name"].ToString();
                    }
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Contract"].Value = fr.textCont.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Relation_Code"].Value = fr.textRCode.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Relation_Name"].Value = fr.textRName.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Netto"].Value = Program.StrToDouble(fr.textFactNet.Text, 2);
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Estate_qty"].Value = Program.StrToDouble(fr.textOthNet.Text, 2);
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Agen"].Value = (fr.labelAgen.Text != "") ? "Y" : "N";
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Estate"].Value = fr.textEstate.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["ConvNett"].Value = Program.StrToDouble(fr.textConvNett.Text, 2);
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["ConvUnit"].Value = fr.labelConvUnit.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["PI_No"].Value = fr.textPI_No.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Transporter_Code"].Value = fr.textTransporter.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Transaction_Code"].Value = fr.pTransType;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Storage_code"].Value = fr.textStorage.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["STO1X"].Value = fr.text1STO.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["DO1X"].Value = fr.text1DOSTO.Text;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Tolling"].Value = fr.tolling;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Estate_qty"].Value = "0";
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Netto"].Value = "0";
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Bruto"].Value = "0";
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Tarra"].Value = "0";
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["do_besar"].Value = fr.indic;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["WeightPerUnitName"].Value = (this.dgvDO.Rows[this.nCurrRowDO].Cells["WeightPerUnitName"].Value == null) ? 0 : this.dgvDO.Rows[this.nCurrRowDO].Cells["WeightPerUnitName"].Value;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["DeducUnitQty"].Value = (this.dgvDO.Rows[this.nCurrRowDO].Cells["DeducUnitQty"].Value == null) ? 0 : this.dgvDO.Rows[this.nCurrRowDO].Cells["DeducUnitQty"].Value;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["TotalDeducUnit"].Value = (this.dgvDO.Rows[this.nCurrRowDO].Cells["TotalDeducUnit"].Value == null) ? 0 : this.dgvDO.Rows[this.nCurrRowDO].Cells["TotalDeducUnit"].Value;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Deduction"].Value = (this.dgvDO.Rows[this.nCurrRowDO].Cells["Deduction"].Value == null) ? 0 : this.dgvDO.Rows[this.nCurrRowDO].Cells["Deduction"].Value;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["UnitName"].Value = (this.dgvDO.Rows[this.nCurrRowDO].Cells["UnitName"].Value == null) ? "" : this.dgvDO.Rows[this.nCurrRowDO].Cells["UnitName"].Value;
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["so_item_detail"].Value = fr.textSOItem_detail.Text;
                    if (this.nCurrRowDO == 0)
                    {
                        this.commcode = fr.pComm;
                        this.transtype = fr.pTransType;
                        this.dono = fr.textDO.Text;
                        this.transporter = fr.textTransporter.Text;
                        this.RCode = fr.textRCode.Text;
                        this.EstateCode = fr.textEstate.Text;
                        this.PINo = fr.textPI_No.Text;
                    }
                }
            }
        }

        private void fillDGV_fromTransDOEntry(FormTransDOEntry fr, string doEntryMode, bool from_do, bool from_dotrx, bool from_dr)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            DataGridView view = new DataGridView();
            string str = "";
            string str2 = "";
            float num = 0f;
            if (doEntryMode == "ADD")
            {
                table.OpenTable("wb_contract", "select * from wb_contract where" + WBData.CompanyLocation(" and (closed is null or closed <> 'X' or closed = 'N') and zAuto = 'N'"), WBData.conn);
            }
            else
            {
                table.OpenTable("wb_contract", "select * from wb_contract where" + WBData.CompanyLocation(" and ((closed is null or closed <> 'X' or closed = 'N') and zAuto = 'N' or do_no = '" + fr.textDO.Text.Trim() + "')"), WBData.conn);
            }
            string[] aField = new string[] { "Do_No" };
            string[] aFind = new string[] { fr.textDO.Text.Trim() };
            DataRow data = table.GetData(aField, aFind);
            table2.OpenTable("wb_comm", "Select * from wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + data["Comm_Code"].ToString() + "'"), WBData.conn);
            string[] textArray3 = new string[] { "comm_code" };
            string[] textArray4 = new string[] { data["Comm_Code"].ToString() };
            DataRow row2 = table2.GetData(textArray3, textArray4);
            if (row2 != null)
            {
                str2 = row2["Unit"].ToString();
                str = row2["BulkPack"].ToString();
                num = float.Parse((row2["netto_weight"].ToString() == "") ? "0" : row2["netto_weight"].ToString());
            }
            if (from_do)
            {
                view = fr.retTable_DSAP_DO;
            }
            else if (from_dotrx)
            {
                view = fr.retTable_DSAP_DOTRX;
            }
            else if (from_dr)
            {
                view = fr.retTable_DSAP_DR;
            }
            foreach (DataGridViewRow row3 in (IEnumerable) view.Rows)
            {
                if (doEntryMode == "ADD")
                {
                    this.dgvDO.Rows.Add();
                    this.nCurrRowDO = this.dgvDO.Rows.Count - 1;
                }
                else if (doEntryMode == "EDIT")
                {
                    this.nCurrRowDO = this.dgvDO.CurrentRow.Index;
                }
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Coy"].Value = WBData.sCoyCode;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Location_Code"].Value = WBData.sLocCode;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Transaction_Code"].Value = fr.transType;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Ref"].Value = this.txtRefNo.Text;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["DO_No"].Value = fr.textDO.Text;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Comm_Code"].Value = fr.textComm.Text;
                string[] textArray5 = new string[] { "Select * from wb_commodity where coy = '", WBData.sCoyCode, "' and location_code = '", WBData.sLocCode, "' And comm_code = '", fr.textComm.Text, "'" };
                this.tblComm2.OpenTable("wb_commodity", string.Concat(textArray5), WBData.conn);
                if (this.tblComm2.DT.Rows.Count > 0)
                {
                    this.dgvDO.Rows[this.nCurrRowDO].Cells["Comm_Name"].Value = this.tblComm2.DT.Rows[0]["Comm_Name"].ToString();
                }
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Contract"].Value = fr.textCont.Text;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Relation_Code"].Value = fr.textRCode.Text;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Relation_Name"].Value = fr.textRName.Text;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Netto"].Value = Program.StrToDouble(fr.textFactNet.Text, 2);
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Estate_qty"].Value = Program.StrToDouble(fr.textOthNet.Text, 2);
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Agen"].Value = (fr.labelAgen.Text != "") ? "Y" : "N";
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Estate"].Value = fr.textEstate.Text;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["ConvNett"].Value = Program.StrToDouble(fr.textConvNett.Text, 2);
                this.dgvDO.Rows[this.nCurrRowDO].Cells["ConvUnit"].Value = fr.labelConvUnit.Text;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["PI_No"].Value = fr.textPI_No.Text;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Transporter_Code"].Value = fr.textTransporter.Text;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Transaction_Code"].Value = fr.pTransType;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Storage_code"].Value = fr.textStorage.Text;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["STO1X"].Value = fr.text1STO.Text;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["DO1X"].Value = fr.text1DOSTO.Text;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Tolling"].Value = fr.tolling;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Estate_qty"].Value = "0";
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Netto"].Value = "0";
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Bruto"].Value = "0";
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Tarra"].Value = "0";
                this.dgvDO.Rows[this.nCurrRowDO].Cells["WeightPerUnitName"].Value = (this.dgvDO.Rows[this.nCurrRowDO].Cells["WeightPerUnitName"].Value == null) ? 0 : this.dgvDO.Rows[this.nCurrRowDO].Cells["WeightPerUnitName"].Value;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["DeducUnitQty"].Value = (this.dgvDO.Rows[this.nCurrRowDO].Cells["DeducUnitQty"].Value == null) ? 0 : this.dgvDO.Rows[this.nCurrRowDO].Cells["DeducUnitQty"].Value;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["TotalDeducUnit"].Value = (this.dgvDO.Rows[this.nCurrRowDO].Cells["TotalDeducUnit"].Value == null) ? 0 : this.dgvDO.Rows[this.nCurrRowDO].Cells["TotalDeducUnit"].Value;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["Deduction"].Value = (this.dgvDO.Rows[this.nCurrRowDO].Cells["Deduction"].Value == null) ? 0 : this.dgvDO.Rows[this.nCurrRowDO].Cells["Deduction"].Value;
                this.dgvDO.Rows[this.nCurrRowDO].Cells["UnitName"].Value = (this.dgvDO.Rows[this.nCurrRowDO].Cells["UnitName"].Value == null) ? "" : this.dgvDO.Rows[this.nCurrRowDO].Cells["UnitName"].Value;
                if (WBSetting.integrationIDSYS)
                {
                    if (from_do)
                    {
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_sap"].Value = "";
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_sap_item"].Value = "";
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["internal_number"].Value = row3.Cells["do_"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["internal_number_item"].Value = row3.Cells["do_item"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["DO_base_uom"].Value = row3.Cells["base_uom"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_qty"].Value = row3.Cells["qty_do"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_uom"].Value = row3.Cells["do_uom"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_base_qty"].Value = row3.Cells["qty_base"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_qty_kg"].Value = row3.Cells["qty_kg"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_besar"].Value = "";
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["so_item_detail"].Value = "";
                    }
                }
                else
                {
                    if (from_do)
                    {
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_sap"].Value = row3.Cells["VBELN"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_sap_item"].Value = row3.Cells["POSNR"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["internal_number"].Value = "";
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["internal_number_item"].Value = "";
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["DO_base_uom"].Value = row3.Cells["BASE_UOM"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_qty"].Value = row3.Cells["LFIMG"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_uom"].Value = row3.Cells["VRKME"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_base_qty"].Value = row3.Cells["LFIMG_BASE"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_qty_kg"].Value = row3.Cells["LFIMG_KG"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_besar"].Value = row3.Cells["ZZDO_INDICATOR"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["so_item_detail"].Value = row3.Cells["POSNR_VA"].Value.ToString();
                    }
                    else if (from_dr)
                    {
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_sap"].Value = "";
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_sap_item"].Value = "";
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["internal_number"].Value = row3.Cells["ZDCONR"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["internal_number_item"].Value = row3.Cells["POSNR"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["DO_base_uom"].Value = row3.Cells["BASE_UOM"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_qty"].Value = row3.Cells["DLFIMG"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_uom"].Value = row3.Cells["VRKME"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_base_qty"].Value = row3.Cells["DLFIMG_BASE"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_qty_kg"].Value = row3.Cells["DLFIMG_NET"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_besar"].Value = "";
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["so_item_detail"].Value = row3.Cells["POSNR_VA"].Value.ToString();
                    }
                    else if (from_dotrx)
                    {
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_sap"].Value = "";
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_sap_item"].Value = "";
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["internal_number"].Value = row3.Cells["ZDCONR"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["internal_number_item"].Value = row3.Cells["DOPLINE"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["DO_base_uom"].Value = row3.Cells["BUOM"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_qty"].Value = row3.Cells["PLN_LFIMG"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_uom"].Value = row3.Cells["Q_VRKME"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_base_qty"].Value = row3.Cells["QTYBUOM"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_qty_kg"].Value = row3.Cells["QTYKG"].Value.ToString();
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["do_besar"].Value = "";
                        this.dgvDO.Rows[this.nCurrRowDO].Cells["so_item_detail"].Value = row3.Cells["POSNR"].Value.ToString();
                    }
                    if (this.nCurrRowDO == 0)
                    {
                        this.commcode = fr.pComm;
                        this.transtype = fr.pTransType;
                        this.dono = fr.textDO.Text;
                        this.transporter = fr.textTransporter.Text;
                        this.RCode = fr.textRCode.Text;
                        this.EstateCode = fr.textEstate.Text;
                        this.PINo = fr.textPI_No.Text;
                    }
                    if (!string.IsNullOrEmpty(this.dgvDO.Rows[this.nCurrRowDO].Cells["do_sap"].Value.ToString()) && ((str == "P") && (str2 != "KG")))
                    {
                        float num2 = 0f;
                        num2 = float.Parse(this.dgvDO.Rows[this.nCurrRowDO].Cells["do_base_qty"].Value.ToString());
                        if ((data["so_item"].ToString() != "*") && (data["so_item"].ToString() != ""))
                        {
                            this.dgvDO.Rows[this.nCurrRowDO].Cells["do_qty_kg"].Value = (num2 * num).ToString();
                        }
                        else
                        {
                            WBTable table3 = new WBTable();
                            WBTable table4 = new WBTable();
                            string[] textArray6 = new string[] { " AND do_no = '", fr.textDO.Text.Trim(), "' and so_item = '", Program.StrToDouble(this.dgvDO.Rows[this.nCurrRowDO].Cells["so_item_detail"].Value.ToString(), 0).ToString(), "'" };
                            table3.OpenTable("wb_contract_sapinformation", "SELECT comm_code FROM wb_contract_sapinformation WHERE " + WBData.CompanyLocation(string.Concat(textArray6)), WBData.conn);
                            table4.OpenTable("wb_commodity", "SELECT netto_weight FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + table3.DT.Rows[0]["comm_code"].ToString() + "'"), WBData.conn);
                            this.dgvDO.Rows[this.nCurrRowDO].Cells["do_qty_kg"].Value = (num2 * float.Parse((table4.DT.Rows[0]["netto_weight"].ToString() == "") ? "0" : table4.DT.Rows[0]["netto_weight"].ToString())).ToString();
                            table3.Dispose();
                            table4.Dispose();
                        }
                    }
                }
            }
        }

        private void FormLoadingInfo_Load(object sender, EventArgs e)
        {
            if (this.txtRefNo.Text != "")
            {
                this.tblTrans.OpenTable("wb_transaction", "select * from wb_transaction where " + WBData.CompanyLocation(" AND (deleted <> 'Y' OR deleted IS null) and ref = '" + this.txtRefNo.Text + "'"), WBData.conn);
                this.dgv.DataSource = this.tblTrans.DT;
                this.tblTransTemp.OpenTable("wb_transaction", "select * from wb_transaction where " + WBData.CompanyLocation(" AND (deleted <> 'Y' OR deleted IS null) and ref = '" + this.textRefTemp.Text + "'"), WBData.conn);
                if (this.tblTrans.DT.Rows.Count > 0)
                {
                    this.tblComm.OpenTable("wb_checkComm", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.tblTrans.DT.Rows[0]["comm_code"].ToString() + "'"), WBData.conn);
                    WBCondition condition4 = new WBCondition();
                    DataRow[] dgRows = new DataRow[] { this.tblTrans.DT.Rows[0], this.tblComm.DT.Rows[0] };
                    condition4.fillParameter("ACTIVE_ADOPT_ZDOTRX", dgRows);
                    if (condition4.getResult() && ((this.tblTrans.DT.Rows[0]["report_date"] == null) || (this.tblTrans.DT.Rows[0]["report_date"].ToString() == "")))
                    {
                        this.buttonAddDO.Enabled = false;
                        this.buttonEditDO.Enabled = WBSetting.Field("Check_Storage") == "Y";
                        this.buttonDeleteDO.Enabled = false;
                        this.buttonDeleteAllDO.Enabled = false;
                    }
                    this.txtVehicle.Text = this.tblTrans.DT.Rows[0]["truck_number"].ToString();
                    this.txtMS.Text = this.tblTrans.DT.Rows[0]["materialStuffing"].ToString();
                    this.textDriverID.Text = this.tblTrans.DT.Rows[0]["License_No"].ToString();
                    this.labelDriverName.Text = this.tblTrans.DT.Rows[0]["Name"].ToString();
                    this.textRefTemp.Text = this.tblTrans.DT.Rows[0]["linked"].ToString();
                    this.gatepass_no = this.tblTrans.DT.Rows[0]["gatepass_number"].ToString();
                    this.tempRef = this.textRefTemp.Text;
                    if (this.txtMS.Text == "")
                    {
                        this.txtMS.Text = "0";
                    }
                    if ((this.tblTrans.DT.Rows[0]["report_date"] == null) || (this.tblTrans.DT.Rows[0]["report_date"].ToString() == ""))
                    {
                        string[] textArray1 = new string[] { "Select comm.comm_name, do.* from wb_transDO as do inner join wb_commodity as comm on comm.comm_code = do.comm_code and comm.coy = do.coy and comm.location_code = do.location_code where do.coy = '", WBData.sCoyCode, "' and do.location_code = '", WBData.sLocCode, "' And do.Ref like '", this.txtRefNo.Text, "%'" };
                        this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray1), WBData.conn);
                    }
                    else
                    {
                        string[] textArray2 = new string[] { "Select comm.comm_name, do.* from wb_transDO as do inner join wb_commodity as comm on comm.comm_code = do.comm_code and comm.coy = do.coy and comm.location_code = do.location_code where do.coy = '", WBData.sCoyCode, "' and do.location_code = '", WBData.sLocCode, "' And do.Ref like '", this.txtRefNo.Text, "%'" };
                        this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray2), WBData.conn);
                        if (this.tblTransDO.DT.Rows.Count <= 1)
                        {
                            string[] textArray5 = new string[] { "Select comm.comm_name, do.* from wb_transDO as do inner join wb_commodity as comm on comm.comm_code = do.comm_code and comm.coy = do.coy and comm.location_code = do.location_code where do.coy = '", WBData.sCoyCode, "' and do.location_code = '", WBData.sLocCode, "' And do.Ref = '", this.txtRefNo.Text, "'" };
                            this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray5), WBData.conn);
                        }
                        else
                        {
                            int num2 = 0;
                            foreach (DataRow row in this.tblTransDO.DT.Rows)
                            {
                                WBTable table = new WBTable();
                                table.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref = '" + row["ref"].ToString() + "'"), WBData.conn);
                                if (table.DT.Rows.Count > 0)
                                {
                                    num2++;
                                }
                                table.Dispose();
                            }
                            if (num2 > 1)
                            {
                                string[] textArray3 = new string[] { "Select comm.comm_name, do.* from wb_transDO as do inner join wb_commodity as comm on comm.comm_code = do.comm_code and comm.coy = do.coy and comm.location_code = do.location_code where do.coy = '", WBData.sCoyCode, "' and do.location_code = '", WBData.sLocCode, "' And do.Ref = '", this.txtRefNo.Text, "'" };
                                this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray3), WBData.conn);
                            }
                            else
                            {
                                string[] textArray4 = new string[] { "Select comm.comm_name, do.* from wb_transDO as do inner join wb_commodity as comm on comm.comm_code = do.comm_code and comm.coy = do.coy and comm.location_code = do.location_code where do.coy = '", WBData.sCoyCode, "' and do.location_code = '", WBData.sLocCode, "' And do.Ref like '", this.txtRefNo.Text, "%'" };
                                this.tblTransDO.OpenTable("wb_transDO", string.Concat(textArray4), WBData.conn);
                            }
                        }
                    }
                }
            }
            this.dgvDO.ColumnCount = this.tblTransDO.DT.Columns.Count;
            int num = 0;
            while (true)
            {
                if (num >= this.tblTransDO.DT.Columns.Count)
                {
                    this.dgvDO.Columns["loading_qty"].HeaderText = "Loading Qty in Base UOM";
                    this.dgvDO.Columns["DO_base_UOM"].HeaderText = "BASE UOM";
                    this.dgvDO.Columns["DO_QTY"].HeaderText = "DO QTY";
                    this.dgvDO.Columns["DO_UOM"].HeaderText = "DO  UOM";
                    this.dgvDO.Columns["DO_BASE_Qty"].HeaderText = "DO BASE QTY";
                    this.dgvDO.Columns["DO_QTY_KG"].HeaderText = "DO QTY in KG";
                    this.dgvDO.Columns["DO_No"].HeaderText = "SO No";
                    this.dgvDO.Columns["Do_sap"].HeaderText = "DO " + this.sapIDSYS;
                    this.dgvDO.Columns["Do_sap_item"].HeaderText = "DO " + this.sapIDSYS + " Item";
                    this.dgvDO.Columns["Internal_number"].HeaderText = "Internal No.";
                    this.dgvDO.Columns["internal_number_item"].HeaderText = "Internal No. Item";
                    this.dgvDO.Columns["Comm_Code"].HeaderText = "Commodity code";
                    this.dgvDO.Columns["loading_qty"].HeaderText = "Loading Qty in Base UOM";
                    this.dgvDO.Columns["DO_BASE_Qty"].DisplayIndex = this.dgvDO.Columns["loading_qty"].Index + 1;
                    this.dgvDO.Columns["DO_base_UOM"].DisplayIndex = this.dgvDO.Columns["loading_qty"].Index + 2;
                    this.dgvDO.Columns["Comm_Name"].HeaderText = "Commodity Name";
                    this.dgvDO.Columns["so_item_detail"].HeaderText = "SO Item";
                    this.dgvDO.Columns["loading_qty_opw"].HeaderText = "Loading Qty OPW";
                    this.dgvDO.Columns["loading_qty_opw"].Visible = false;
                    this.dgvDO.Columns["Comm_Code"].Visible = true;
                    this.dgvDO.Columns["Comm_Name"].Visible = true;
                    this.dgvDO.Columns["Do_No"].Visible = true;
                    this.dgvDO.Columns["Do_sap"].Visible = true;
                    this.dgvDO.Columns["Do_sap_item"].Visible = true;
                    this.dgvDO.Columns["Internal_number"].Visible = true;
                    this.dgvDO.Columns["internal_number_item"].Visible = true;
                    this.dgvDO.Columns["loading_qty"].Visible = true;
                    this.dgvDO.Columns["DO_Base_UOM"].Visible = true;
                    this.dgvDO.Columns["DO_QTY"].Visible = true;
                    this.dgvDO.Columns["DO_UOM"].Visible = true;
                    this.dgvDO.Columns["DO_BASE_Qty"].Visible = true;
                    this.dgvDO.Columns["DO_QTY_KG"].Visible = true;
                    this.dgvDO.Columns["so_item_detail"].Visible = true;
                    this.dgvDO.Columns["loading_qty"].DefaultCellStyle.BackColor = Color.White;
                    this.tblComm.OpenTable("wb_checkComm", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + this.tblTrans.DT.Rows[0]["comm_code"].ToString() + "'"), WBData.conn);
                    if (this.tblComm.DT.Rows.Count > 0)
                    {
                        if ((this.tblComm.DT.Rows[0]["unit"].ToString().Trim().ToUpper() == "") || (this.tblComm.DT.Rows[0]["unit"].ToString().Trim().ToUpper() == "KG"))
                        {
                            this.dgvDO.Columns["loading_qty"].ReadOnly = true;
                            this.dgvDO.Columns["loading_qty"].DefaultCellStyle.BackColor = Color.LightGray;
                            this.buttonAddDO.Enabled = false;
                            this.buttonEditDO.Enabled = false;
                            this.buttonDeleteDO.Enabled = false;
                            this.buttonDeleteAllDO.Enabled = false;
                        }
                        else if (this.tblComm.DT.Rows[0]["bulkpack"].ToString().Trim().ToUpper() != "P")
                        {
                            this.txtMS.Enabled = true;
                            this.dgvDO.Columns["loading_qty"].ReadOnly = false;
                            this.dgvDO.Columns["loading_qty"].DefaultCellStyle.BackColor = Color.White;
                        }
                        else if (!((WBUser.UserLevel != "1") && WBUser.CheckTrustee("MN_LOADING_ENTRY_FOR_MS_ONLY", "A")))
                        {
                            this.txtMS.Enabled = true;
                            this.dgvDO.Columns["loading_qty"].ReadOnly = false;
                            this.dgvDO.Columns["loading_qty"].DefaultCellStyle.BackColor = Color.White;
                        }
                        else
                        {
                            this.txtMS.Enabled = false;
                            this.dgvDO.Columns["loading_qty"].ReadOnly = true;
                            this.dgvDO.Columns["loading_qty"].DefaultCellStyle.BackColor = Color.LightGray;
                            this.buttonAddDO.Enabled = false;
                            this.buttonEditDO.Enabled = false;
                            this.buttonDeleteDO.Enabled = false;
                            this.buttonDeleteAllDO.Enabled = false;
                        }
                    }
                    WBCondition condition = new WBCondition();
                    WBCondition condition2 = new WBCondition();
                    this.tblTransType.OpenTable("wb_checkTransType", "Select * from Wb_transaction_Type where " + WBData.CompanyLocation(" and transaction_code = '" + this.tblTrans.DT.Rows[0]["transaction_code"].ToString() + "'"), WBData.conn);
                    DataRow[] dgRows = new DataRow[] { this.tblComm.DT.Rows[0], this.tblTransType.DT.Rows[0] };
                    condition.fillParameter("LOADING_NO_FLOWMETER", dgRows);
                    DataRow[] rowArray3 = new DataRow[] { this.tblComm.DT.Rows[0] };
                    condition2.fillParameter("CALC_DENSITY_TO_SPAREPARTQTY", rowArray3);
                    WBCondition condition3 = new WBCondition();
                    DataRow[] rowArray4 = new DataRow[] { this.tblComm.DT.Rows[0], this.tblTransType.DT.Rows[0] };
                    condition3.fillParameter("LOADING_WITH_FLOWMETER", rowArray4);
                    if (!(condition.getResult() || condition2.getResult()))
                    {
                        if (condition3.getResult())
                        {
                            this.dgvDO.Columns["Density"].HeaderText = "Density";
                            this.dgvDO.Columns["Density"].Visible = true;
                            this.dgvDO.Columns["Density"].DefaultCellStyle.BackColor = Color.White;
                            this.dgvDO.Columns["Density"].ReadOnly = false;
                        }
                    }
                    else
                    {
                        this.dgvDO.Columns["Density"].HeaderText = "Density";
                        this.dgvDO.Columns["Density"].Visible = true;
                        this.dgvDO.Columns["Density"].DefaultCellStyle.BackColor = Color.White;
                        this.dgvDO.Columns["Density"].ReadOnly = false;
                        WBTable table2 = new WBTable();
                        string[] textArray6 = new string[] { "SELECT calcLoadingQtyAutomatically FROM wb_contract WHERE ", WBData.CompanyLocation(""), " AND Do_No = '", this.tblTrans.DT.Rows[0]["Do_No"].ToString(), "'" };
                        table2.OpenTable("wb_contract", string.Concat(textArray6), WBData.conn);
                        if ((table2.DT.Rows[0]["calcLoadingQtyAutomatically"].ToString() == "Y") || condition2.getResult())
                        {
                            this.dgvDO.Columns["Loading_qty"].ReadOnly = true;
                            this.dgvDO.Columns["Loading_qty"].DefaultCellStyle.BackColor = Color.LightGray;
                        }
                        else
                        {
                            this.dgvDO.Columns["Loading_qty"].ReadOnly = false;
                            this.dgvDO.Columns["Loading_qty"].DefaultCellStyle.BackColor = Color.White;
                        }
                        this.txtMS.Enabled = !condition2.getResult();
                        table2.Dispose();
                    }
                    this.dgvDO = this.tblTransDO.ToDGV(this.dgvDO);
                    this.countAdditionalInformation();
                    if (this.dgvDO.Rows.Count > 0)
                    {
                        this.commcode = this.dgvDO.Rows[0].Cells["comm_code"].Value.ToString();
                        this.transtype = this.dgvDO.Rows[0].Cells["Transaction_Code"].Value.ToString();
                        this.dono = this.dgvDO.Rows[0].Cells["DO_No"].Value.ToString();
                        this.transporter = this.dgvDO.Rows[0].Cells["Transporter_Code"].Value.ToString();
                        this.RCode = this.dgvDO.Rows[0].Cells["Relation_Code"].Value.ToString();
                        this.EstateCode = this.dgvDO.Rows[0].Cells["Estate"].Value.ToString();
                        this.PINo = this.dgvDO.Rows[0].Cells["PI_No"].Value.ToString();
                        this.indic = this.dgvDO.Rows[0].Cells["DO_BESAR"].Value.ToString();
                    }
                    foreach (DataGridViewColumn column in this.dgvDO.Columns)
                    {
                        column.SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                    this.dgvDO.Columns["do_no"].DisplayIndex = 0;
                    this.dgvDO.Columns["so_item_detail"].DisplayIndex = 1;
                    this.dgvDO.Columns["comm_code"].DisplayIndex = 2;
                    this.dgvDO.Columns["Comm_Name"].DisplayIndex = 3;
                    this.dgvDO.Columns["Do_sap"].DisplayIndex = 4;
                    this.dgvDO.Columns["Do_sap_item"].DisplayIndex = 5;
                    this.dgvDO.Columns["Internal_number"].DisplayIndex = 6;
                    this.dgvDO.Columns["internal_number_item"].DisplayIndex = 7;
                    this.dgvDO.Columns["Density"].DisplayIndex = 8;
                    this.dgvDO.Columns["loading_qty"].DisplayIndex = 9;
                    this.dgvDO.Columns["DO_BASE_Qty"].DisplayIndex = 10;
                    this.dgvDO.Columns["DO_Base_UOM"].DisplayIndex = 11;
                    this.dgvDO.Columns["DO_QTY"].DisplayIndex = 12;
                    this.WX = this.tblTrans.DT.Rows[0]["WX"].ToString();
                    if (this.tblTrans.DT.Rows[0]["linked"].ToString() != "")
                    {
                        this.link = true;
                    }
                    if (this.WX != "4X")
                    {
                        this.panelLink.Visible = false;
                    }
                    else
                    {
                        this.panelLink.Visible = true;
                        this.buttonActivation();
                    }
                    condition2.Dispose();
                    condition.Dispose();
                    condition3.Dispose();
                    return;
                }
                this.dgvDO.Columns[num].Name = this.tblTransDO.DT.Columns[num].ColumnName;
                this.dgvDO.Columns[num].Visible = false;
                this.dgvDO.Columns[num].ReadOnly = true;
                this.dgvDO.Columns[num].DefaultCellStyle.BackColor = Color.LightGray;
                num++;
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.txtRefNo = new TextBox();
            this.lblVehicle = new Label();
            this.txtVehicle = new TextBox();
            this.lblRef = new Label();
            this.lblMS = new Label();
            this.txtMS = new TextBox();
            this.lblKG = new Label();
            this.dgvDO = new DataGridView();
            this.btnSave = new Button();
            this.btnCancel = new Button();
            this.statusStrip1 = new StatusStrip();
            this.toolTipInformation = new ToolTip(this.components);
            this.label1 = new Label();
            this.buttonDeleteDO = new Button();
            this.buttonEditDO = new Button();
            this.buttonAddDO = new Button();
            this.textRef_Date = new TextBox();
            this.label35 = new Label();
            this.label3 = new Label();
            this.textDriverID = new TextBox();
            this.labelDriverName = new Label();
            this.textReport_Date = new TextBox();
            this.label37 = new Label();
            this.labelArrow = new Label();
            this.textRefTemp = new TextBox();
            this.buttonLink = new Button();
            this.buttonBrowse = new Button();
            this.panelLink = new Panel();
            this.buttonUnlink = new Button();
            this.buttonDeleteAllDO = new Button();
            this.tableLayoutPanel1 = new TableLayoutPanel();
            this.label6 = new Label();
            this.lblTotalDOQtyInKG = new Label();
            this.lblTotalItem = new Label();
            this.label2 = new Label();
            this.label8 = new Label();
            ((ISupportInitialize) this.dgvDO).BeginInit();
            this.panelLink.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            base.SuspendLayout();
            this.txtRefNo.BackColor = SystemColors.Control;
            this.txtRefNo.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.txtRefNo.Location = new Point(0x61, 12);
            this.txtRefNo.MaxLength = 0x10;
            this.txtRefNo.Name = "txtRefNo";
            this.txtRefNo.ReadOnly = true;
            this.txtRefNo.Size = new Size(0xc1, 0x1a);
            this.txtRefNo.TabIndex = 0x65;
            this.lblVehicle.AutoSize = true;
            this.lblVehicle.Location = new Point(9, 100);
            this.lblVehicle.Name = "lblVehicle";
            this.lblVehicle.Size = new Size(0x3e, 13);
            this.lblVehicle.TabIndex = 0x68;
            this.lblVehicle.Text = "Vehicle No.";
            this.txtVehicle.BackColor = SystemColors.Control;
            this.txtVehicle.CharacterCasing = CharacterCasing.Upper;
            this.txtVehicle.Enabled = false;
            this.txtVehicle.Location = new Point(0x61, 0x62);
            this.txtVehicle.MaxLength = 20;
            this.txtVehicle.Name = "txtVehicle";
            this.txtVehicle.Size = new Size(0x7b, 20);
            this.txtVehicle.TabIndex = 0x66;
            this.lblRef.AutoSize = true;
            this.lblRef.Location = new Point(9, 20);
            this.lblRef.Name = "lblRef";
            this.lblRef.Size = new Size(0x2c, 13);
            this.lblRef.TabIndex = 0x69;
            this.lblRef.Text = "Ref No.";
            this.lblMS.AutoSize = true;
            this.lblMS.Location = new Point(9, 0x99);
            this.lblMS.Name = "lblMS";
            this.lblMS.Size = new Size(0x53, 13);
            this.lblMS.TabIndex = 0x6a;
            this.lblMS.Text = "Material Stuffing";
            this.txtMS.BackColor = SystemColors.Window;
            this.txtMS.CharacterCasing = CharacterCasing.Upper;
            this.txtMS.Location = new Point(0x61, 150);
            this.txtMS.MaxLength = 20;
            this.txtMS.Name = "txtMS";
            this.txtMS.Size = new Size(0x3a, 20);
            this.txtMS.TabIndex = 0x6b;
            this.txtMS.Text = "0";
            this.txtMS.TextAlign = HorizontalAlignment.Right;
            this.txtMS.TextChanged += new EventHandler(this.txtMS_TextChanged);
            this.txtMS.Leave += new EventHandler(this.txtMS_Leave);
            this.lblKG.AutoSize = true;
            this.lblKG.Location = new Point(0xa1, 0x99);
            this.lblKG.Name = "lblKG";
            this.lblKG.Size = new Size(0x16, 13);
            this.lblKG.TabIndex = 0x6c;
            this.lblKG.Text = "KG";
            this.dgvDO.AllowUserToAddRows = false;
            this.dgvDO.AllowUserToDeleteRows = false;
            this.dgvDO.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDO.Dock = DockStyle.Bottom;
            this.dgvDO.Location = new Point(0, 0x109);
            this.dgvDO.Name = "dgvDO";
            this.dgvDO.Size = new Size(0x368, 0xa3);
            this.dgvDO.TabIndex = 0x6d;
            this.dgvDO.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dgvDO_CellFormatting);
            this.dgvDO.CellValidating += new DataGridViewCellValidatingEventHandler(this.dgvDO_CellValidating);
            this.btnSave.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.btnSave.Location = new Point(0x291, 0xa9);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new Size(0x5f, 0x38);
            this.btnSave.TabIndex = 110;
            this.btnSave.Text = "&SAVE";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new EventHandler(this.btnSave_Click);
            this.btnCancel.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.btnCancel.Location = new Point(0x2fd, 0xa9);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(0x5f, 0x38);
            this.btnCancel.TabIndex = 0x6f;
            this.btnCancel.Text = "&CANCEL";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);
            this.statusStrip1.Location = new Point(0, 470);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(0x368, 0x16);
            this.statusStrip1.TabIndex = 0x70;
            this.statusStrip1.Text = "statusStrip1";
            this.label1.BackColor = SystemColors.ActiveCaption;
            this.label1.Dock = DockStyle.Bottom;
            this.label1.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(0, 0xed);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x368, 0x1c);
            this.label1.TabIndex = 0x71;
            this.label1.Text = "Table SO";
            this.label1.TextAlign = ContentAlignment.MiddleCenter;
            this.buttonDeleteDO.Location = new Point(0xae, 0xbc);
            this.buttonDeleteDO.Name = "buttonDeleteDO";
            this.buttonDeleteDO.Size = new Size(0x4b, 0x27);
            this.buttonDeleteDO.TabIndex = 0x74;
            this.buttonDeleteDO.Text = "&Delete";
            this.buttonDeleteDO.UseVisualStyleBackColor = true;
            this.buttonDeleteDO.Click += new EventHandler(this.buttonDeleteDO_Click);
            this.buttonEditDO.Location = new Point(0x5d, 0xbc);
            this.buttonEditDO.Name = "buttonEditDO";
            this.buttonEditDO.Size = new Size(0x4b, 0x27);
            this.buttonEditDO.TabIndex = 0x73;
            this.buttonEditDO.Text = "&Edit";
            this.buttonEditDO.UseVisualStyleBackColor = true;
            this.buttonEditDO.Click += new EventHandler(this.buttonEditDO_Click);
            this.buttonAddDO.Location = new Point(12, 0xbc);
            this.buttonAddDO.Name = "buttonAddDO";
            this.buttonAddDO.Size = new Size(0x4b, 0x27);
            this.buttonAddDO.TabIndex = 0x72;
            this.buttonAddDO.Text = "&Add";
            this.buttonAddDO.UseVisualStyleBackColor = true;
            this.buttonAddDO.Click += new EventHandler(this.buttonAddDO_Click);
            this.textRef_Date.BackColor = SystemColors.Control;
            this.textRef_Date.Location = new Point(0x61, 0x2e);
            this.textRef_Date.Name = "textRef_Date";
            this.textRef_Date.ReadOnly = true;
            this.textRef_Date.Size = new Size(0x66, 20);
            this.textRef_Date.TabIndex = 0x75;
            this.textRef_Date.Text = "08/08/2013";
            this.label35.AutoSize = true;
            this.label35.Location = new Point(9, 0x31);
            this.label35.Name = "label35";
            this.label35.Size = new Size(50, 13);
            this.label35.TabIndex = 0x76;
            this.label35.Text = "Ref Date";
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(9, 0x7f);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x31, 13);
            this.label3.TabIndex = 0x79;
            this.label3.Text = "Driver ID";
            this.textDriverID.CharacterCasing = CharacterCasing.Upper;
            this.textDriverID.Location = new Point(0x61, 0x7c);
            this.textDriverID.MaxLength = 50;
            this.textDriverID.Name = "textDriverID";
            this.textDriverID.ReadOnly = true;
            this.textDriverID.Size = new Size(0x7b, 20);
            this.textDriverID.TabIndex = 0x77;
            this.labelDriverName.AutoSize = true;
            this.labelDriverName.Location = new Point(0xe2, 0x7f);
            this.labelDriverName.Name = "labelDriverName";
            this.labelDriverName.Size = new Size(0x3f, 13);
            this.labelDriverName.TabIndex = 0x7a;
            this.labelDriverName.Text = "DriverName";
            this.textReport_Date.BackColor = SystemColors.Control;
            this.textReport_Date.Location = new Point(0x61, 0x48);
            this.textReport_Date.MaxLength = 10;
            this.textReport_Date.Name = "textReport_Date";
            this.textReport_Date.ReadOnly = true;
            this.textReport_Date.Size = new Size(0x66, 20);
            this.textReport_Date.TabIndex = 0x7e;
            this.label37.AutoSize = true;
            this.label37.Location = new Point(9, 0x4b);
            this.label37.Name = "label37";
            this.label37.Size = new Size(0x41, 13);
            this.label37.TabIndex = 0x7f;
            this.label37.Text = "Report Date";
            this.labelArrow.AutoSize = true;
            this.labelArrow.Font = new Font("Microsoft Sans Serif", 14f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelArrow.Location = new Point(4, 8);
            this.labelArrow.Name = "labelArrow";
            this.labelArrow.Size = new Size(30, 0x18);
            this.labelArrow.TabIndex = 0x81;
            this.labelArrow.Text = "↔";
            this.textRefTemp.BackColor = SystemColors.Control;
            this.textRefTemp.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textRefTemp.Location = new Point(0x26, 8);
            this.textRefTemp.MaxLength = 0x10;
            this.textRefTemp.Name = "textRefTemp";
            this.textRefTemp.ReadOnly = true;
            this.textRefTemp.Size = new Size(0xc1, 0x1a);
            this.textRefTemp.TabIndex = 130;
            this.buttonLink.Location = new Point(0x10f, 8);
            this.buttonLink.Name = "buttonLink";
            this.buttonLink.Size = new Size(0x3f, 0x1a);
            this.buttonLink.TabIndex = 0x83;
            this.buttonLink.Text = "&Link";
            this.buttonLink.UseVisualStyleBackColor = true;
            this.buttonLink.Visible = false;
            this.buttonLink.Click += new EventHandler(this.buttonLink_Click);
            this.buttonBrowse.Location = new Point(0xed, 8);
            this.buttonBrowse.Name = "buttonBrowse";
            this.buttonBrowse.Size = new Size(0x1c, 0x1a);
            this.buttonBrowse.TabIndex = 0x84;
            this.buttonBrowse.Text = "...";
            this.buttonBrowse.UseVisualStyleBackColor = true;
            this.buttonBrowse.Visible = false;
            this.buttonBrowse.Click += new EventHandler(this.buttonBrowse_Click);
            this.panelLink.Controls.Add(this.buttonUnlink);
            this.panelLink.Controls.Add(this.textRefTemp);
            this.panelLink.Controls.Add(this.buttonBrowse);
            this.panelLink.Controls.Add(this.labelArrow);
            this.panelLink.Controls.Add(this.buttonLink);
            this.panelLink.Location = new Point(0x125, 4);
            this.panelLink.Name = "panelLink";
            this.panelLink.Size = new Size(0x199, 0x29);
            this.panelLink.TabIndex = 0x85;
            this.buttonUnlink.Location = new Point(340, 8);
            this.buttonUnlink.Name = "buttonUnlink";
            this.buttonUnlink.Size = new Size(0x3f, 0x1a);
            this.buttonUnlink.TabIndex = 0x85;
            this.buttonUnlink.Text = "&Unlink";
            this.buttonUnlink.UseVisualStyleBackColor = true;
            this.buttonUnlink.Visible = false;
            this.buttonUnlink.Click += new EventHandler(this.buttonUnlink_Click);
            this.buttonDeleteAllDO.Location = new Point(0xff, 0xbc);
            this.buttonDeleteAllDO.Name = "buttonDeleteAllDO";
            this.buttonDeleteAllDO.Size = new Size(0x4b, 0x27);
            this.buttonDeleteAllDO.TabIndex = 0x86;
            this.buttonDeleteAllDO.Text = "Delete All";
            this.buttonDeleteAllDO.UseVisualStyleBackColor = true;
            this.buttonDeleteAllDO.Click += new EventHandler(this.buttonDeleteAllDO_Click);
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 66.48351f));
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.51648f));
            this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 657f));
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblTotalDOQtyInKG, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblTotalItem, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label8, 2, 1);
            this.tableLayoutPanel1.Dock = DockStyle.Bottom;
            this.tableLayoutPanel1.Location = new Point(0, 0x1ac);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
            this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20f));
            this.tableLayoutPanel1.Size = new Size(0x368, 0x2a);
            this.tableLayoutPanel1.TabIndex = 0x87;
            this.label6.AutoSize = true;
            this.label6.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label6.Location = new Point(3, 0x15);
            this.label6.Name = "label6";
            this.label6.Padding = new Padding(9, 4, 0, 4);
            this.label6.Size = new Size(0x85, 0x15);
            this.label6.TabIndex = 3;
            this.label6.Text = "Total DO Qty in KG :";
            this.lblTotalDOQtyInKG.AutoSize = true;
            this.lblTotalDOQtyInKG.Dock = DockStyle.Fill;
            this.lblTotalDOQtyInKG.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.lblTotalDOQtyInKG.Location = new Point(0x91, 0x15);
            this.lblTotalDOQtyInKG.Name = "lblTotalDOQtyInKG";
            this.lblTotalDOQtyInKG.Padding = new Padding(9, 4, 0, 4);
            this.lblTotalDOQtyInKG.Size = new Size(0x42, 0x15);
            this.lblTotalDOQtyInKG.TabIndex = 2;
            this.lblTotalDOQtyInKG.Text = "0";
            this.lblTotalDOQtyInKG.TextAlign = ContentAlignment.TopRight;
            this.lblTotalItem.AutoSize = true;
            this.lblTotalItem.Dock = DockStyle.Fill;
            this.lblTotalItem.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.lblTotalItem.Location = new Point(0x91, 0);
            this.lblTotalItem.Name = "lblTotalItem";
            this.lblTotalItem.Padding = new Padding(9, 4, 0, 4);
            this.lblTotalItem.Size = new Size(0x42, 0x15);
            this.lblTotalItem.TabIndex = 1;
            this.lblTotalItem.Text = "0";
            this.lblTotalItem.TextAlign = ContentAlignment.TopRight;
            this.label2.AutoSize = true;
            this.label2.Dock = DockStyle.Fill;
            this.label2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label2.Location = new Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Padding = new Padding(9, 4, 0, 4);
            this.label2.Size = new Size(0x88, 0x15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Total Item :";
            this.label8.AutoSize = true;
            this.label8.Dock = DockStyle.Fill;
            this.label8.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label8.Location = new Point(0xd9, 0x15);
            this.label8.Name = "label8";
            this.label8.Padding = new Padding(2, 4, 0, 4);
            this.label8.Size = new Size(0x28c, 0x15);
            this.label8.TabIndex = 4;
            this.label8.Text = "KG";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x368, 0x1ec);
            base.ControlBox = false;
            base.Controls.Add(this.buttonDeleteAllDO);
            base.Controls.Add(this.panelLink);
            base.Controls.Add(this.textReport_Date);
            base.Controls.Add(this.label37);
            base.Controls.Add(this.labelDriverName);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textDriverID);
            base.Controls.Add(this.textRef_Date);
            base.Controls.Add(this.label35);
            base.Controls.Add(this.buttonDeleteDO);
            base.Controls.Add(this.buttonEditDO);
            base.Controls.Add(this.buttonAddDO);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.dgvDO);
            base.Controls.Add(this.btnCancel);
            base.Controls.Add(this.btnSave);
            base.Controls.Add(this.lblKG);
            base.Controls.Add(this.txtMS);
            base.Controls.Add(this.lblMS);
            base.Controls.Add(this.lblRef);
            base.Controls.Add(this.lblVehicle);
            base.Controls.Add(this.txtVehicle);
            base.Controls.Add(this.txtRefNo);
            base.Controls.Add(this.tableLayoutPanel1);
            base.Controls.Add(this.statusStrip1);
            base.FormBorderStyle = FormBorderStyle.FixedDialog;
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormLoadingInfo";
            base.ShowIcon = false;
            base.SizeGripStyle = SizeGripStyle.Hide;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = " Loading Info / Density";
            base.Load += new EventHandler(this.FormLoadingInfo_Load);
            ((ISupportInitialize) this.dgvDO).EndInit();
            this.panelLink.ResumeLayout(false);
            this.panelLink.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void linkRef(bool copy)
        {
            string keyField = "";
            this.tblTrans.ReOpen();
            this.tblTrans.DR = this.tblTrans.DT.Rows[0];
            keyField = this.tblTrans.DR["uniq"].ToString();
            this.tblTrans.DR.BeginEdit();
            this.tblTrans.DR["linked"] = copy ? this.textRefTemp.Text.Trim() : "";
            this.tblTrans.DR["checksum"] = this.tblTrans.Checksum(this.tblTrans.DR);
            this.tblTrans.DR.EndEdit();
            this.tblTrans.Save();
            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
            string[] logValue = new string[] { "EDIT", WBUser.UserID, copy ? ("Link to reference " + this.textRefTemp.Text) : ("Unlink to reference " + this.textRefTemp.Text) };
            Program.updateLogHeader("wb_transaction", keyField, logField, logValue);
            this.tblTransTemp.OpenTable("wb_transaction", "select * from wb_transaction where " + WBData.CompanyLocation(" AND (mark_return = '' OR mark_return IS null) AND (deleted = '' OR deleted IS null) and ref = '" + this.tempRef + "'"), WBData.conn);
            if (this.tblTransTemp.DT.Rows.Count > 0)
            {
                this.tblTransTemp.DR = this.tblTransTemp.DT.Rows[0];
                keyField = this.tblTransTemp.DR["uniq"].ToString();
                this.tblTransTemp.DR.BeginEdit();
                this.tblTransTemp.DR["linked"] = copy ? this.txtRefNo.Text : "";
                this.tblTransTemp.DR["checksum"] = this.tblTransTemp.Checksum(this.tblTransTemp.DR);
                this.tblTransTemp.DR.EndEdit();
                this.tblTransTemp.Save();
                string[] textArray3 = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] textArray4 = new string[] { "EDIT", WBUser.UserID, copy ? ("Link to reference " + this.txtRefNo.Text) : ("Unlink to reference " + this.txtRefNo.Text) };
                Program.updateLogHeader("wb_transaction", keyField, textArray3, textArray4);
            }
        }

        private void TextboxDensity_KeyPress(object sender, KeyPressEventArgs e)
        {
            bool flag = true;
            if ((((e.KeyChar >= '0') && (e.KeyChar <= '9')) || (e.KeyChar == '\b')) || (e.KeyChar == '.'))
            {
                flag = false;
            }
            e.Handled = flag;
        }

        private void TextboxLoadingQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            bool flag = true;
            if (((e.KeyChar < '0') || (e.KeyChar > '9')) ? (e.KeyChar == '\b') : true)
            {
                flag = false;
            }
            e.Handled = flag;
        }

        private void txtMS_Leave(object sender, EventArgs e)
        {
            if (Regex.IsMatch(this.txtMS.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                this.txtMS.Text.Remove(this.txtMS.Text.Length - 1);
                this.txtMS.Focus();
            }
        }

        private void txtMS_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(this.txtMS.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                this.txtMS.Text.Remove(this.txtMS.Text.Length - 1);
                this.txtMS.Focus();
            }
        }
    }
}

