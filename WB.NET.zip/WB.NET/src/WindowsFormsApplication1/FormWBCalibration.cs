﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormWBCalibration : Form
    {
        private int idxFind = 0;
        private int nCurrRow;
        public string pMode = "";
        public string pFilter = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private IContainer components = null;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem closeToolStripMenuItem;
        private ToolStripMenuItem viewRecordToolStripMenuItem;
        private DataGridView dgvSAPDest;
        public Panel panel1;
        private CheckBox checkDeleted;
        private ProgressBar progressBar1;

        public FormWBCalibration()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void activitiesToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            if ((this.dgvSAPDest.Rows.Count > 0) && (this.dgvSAPDest.CurrentRow.Cells["Deleted"].Value.ToString() == "Y"))
            {
                this.deleteToolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
            }
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dgvSAPDest, "ADD"))
            {
                FormWBCalibrationEntry entry = new FormWBCalibrationEntry {
                    pMode = "ADD",
                    Text = Resource.Title_Add_WB_Calibration,
                    zTable = this.ztable
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dgvSAPDest = this.ztable.AfterEdit("ADD");
                    string[] aField = new string[] { "WBCode" };
                    string[] aFind = new string[] { entry.comboWBCode.Text };
                    this.ztable.SetCursor(this.dgvSAPDest, this.ztable.GetCurrentRow(this.dgvSAPDest, aField, aFind));
                }
                this.ztable.UnLock();
                entry.Dispose();
                if (this.dgvSAPDest.RowCount > 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = true;
                    this.editRecordToolStripMenuItem.Enabled = true;
                    this.deleteToolStripMenuItem.Enabled = true;
                }
            }
        }

        private void checkDeleted_CheckedChanged(object sender, EventArgs e)
        {
            if (!this.checkDeleted.Checked)
            {
                this.ztable.OpenTable("wb_calibration", "SELECT * FROM wb_calibration WHERE (deleted is null or deleted = '' or deleted = 'N') ", WBData.conn);
            }
            else
            {
                this.ztable.OpenTable("wb_calibration", "SELECT * FROM wb_calibration WHERE 1=1 ", WBData.conn);
            }
            this.dgvSAPDest.DataSource = this.ztable.DT;
            this.dgvSAPDest.Update();
            this.dgvSAPDest.Refresh();
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dgvSAPDest.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dgvSAPDest.Rows.Count > 0)
            {
                string[] textArray1 = new string[14];
                textArray1[0] = Resource.Title_Confirm_Delete_WB_Calibration;
                textArray1[1] = " \n\n";
                textArray1[2] = Resource.Col_Certification_No;
                textArray1[3] = " : ";
                textArray1[4] = this.dgvSAPDest.CurrentRow.Cells["Certification_No"].Value.ToString();
                textArray1[5] = "\n";
                textArray1[6] = Resource.Col_Calibration_Date;
                textArray1[7] = " : ";
                textArray1[8] = Convert.ToDateTime(this.dgvSAPDest.CurrentRow.Cells["Calibration_Date"].Value.ToString()).ToString("dd/MM/yyyy");
                textArray1[9] = "\n";
                textArray1[10] = Resource.Setting_064;
                textArray1[11] = " : ";
                textArray1[12] = Convert.ToDateTime(this.dgvSAPDest.CurrentRow.Cells["Valid_Date"].Value.ToString()).ToString("dd/MM/yyyy");
                textArray1[13] = "\n";
                if (MessageBox.Show(string.Concat(textArray1), Resource.Mes_Confirmation, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    FormTransCancel cancel = new FormTransCancel {
                        label1 = { Text = Resource.Lbl_WB_Calibration },
                        textRefNo = { Text = this.dgvSAPDest.CurrentRow.Cells["WBCode"].Value.ToString() },
                        Text = Resource.Form_Delete_Reason,
                        label2 = { Text = Resource.Lbl_Delete_Reason }
                    };
                    cancel.textReason.Focus();
                    cancel.ShowDialog();
                    if (cancel.Saved)
                    {
                        this.changeReason = cancel.textReason.Text;
                        cancel.Dispose();
                        if (this.ztable.BeforeEdit(this.dgvSAPDest, "DELETE"))
                        {
                            string[] aField = new string[] { "uniq" };
                            string[] aFind = new string[] { this.dgvSAPDest.CurrentRow.Cells["uniq"].Value.ToString() };
                            int recNo = this.ztable.GetRecNo(aField, aFind);
                            this.ztable.DR = this.ztable.DT.Rows[recNo];
                            this.ztable.DR.BeginEdit();
                            this.ztable.DR["deleted"] = "Y";
                            this.ztable.DR["delete_by"] = WBUser.UserID;
                            this.ztable.DR["delete_date"] = DateTime.Now;
                            this.ztable.DR.EndEdit();
                            this.ztable.Save();
                        }
                        else
                        {
                            return;
                        }
                    }
                    else
                    {
                        return;
                    }
                }
            }
            if (this.dgvSAPDest.RowCount == 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
            }
        }

        private void dgvSAPDest_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dgvSAPDest.Rows[e.RowIndex].Cells["deleted"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Red;
                e.CellStyle.SelectionBackColor = Color.Pink;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dgvSAPDest.Rows.Count > 0) && this.ztable.BeforeEdit(this.dgvSAPDest, "EDIT"))
            {
                FormWBCalibrationEntry entry = new FormWBCalibrationEntry {
                    pMode = "EDIT",
                    nCurrRow = this.ztable.GetPosRec(this.dgvSAPDest.CurrentRow.Cells["uniq"].Value.ToString()),
                    Text = Resource.Title_Edit_WB_Calibration,
                    zTable = this.ztable
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dgvSAPDest = this.ztable.AfterEdit("EDIT");
                    string[] aField = new string[] { "WBCode" };
                    string[] aFind = new string[] { entry.comboWBCode.Text };
                    this.ztable.SetCursor(this.dgvSAPDest, this.ztable.GetCurrentRow(this.dgvSAPDest, aField, aFind));
                }
                this.ztable.UnLock();
                entry.Dispose();
            }
        }

        private void FormWBCalibration_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormWBCalibration_Load(object sender, EventArgs e)
        {
            this.viewRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_WB_CALIBRATION", "V");
            this.addNewRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_WB_CALIBRATION", "A");
            this.editRecordToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_WB_CALIBRATION", "E");
            this.deleteToolStripMenuItem.Enabled = WBUser.CheckTrustee("MD_WB_CALIBRATION", "D");
            string sqltext = "SELECT * FROM wb_calibration WHERE 1=1 ";
            if (!this.checkDeleted.Checked)
            {
                sqltext = sqltext + " AND deleted IS NULL or deleted = 'N' or deleted = ''";
            }
            this.ztable.OpenTable("wb_calibration", sqltext, WBData.conn);
            this.dgvSAPDest.DataSource = this.ztable.DT;
            this.dgvSAPDest.Columns["Uniq"].Visible = false;
            this.dgvSAPDest.Columns["Deleted"].Visible = false;
            this.dgvSAPDest.Columns["token"].Visible = false;
            this.dgvSAPDest.Columns["completed"].Visible = false;
            this.dgvSAPDest.Columns["WBCode"].HeaderText = Resource.Main_033;
            this.dgvSAPDest.Columns["Certification_No"].HeaderText = Resource.Col_Certification_No;
            this.dgvSAPDest.Columns["Calibration_Date"].HeaderText = Resource.Col_Calibration_Date;
            this.dgvSAPDest.Columns["Valid_Date"].HeaderText = Resource.Setting_064;
            this.dgvSAPDest.Columns["Lock_Weighing"].HeaderText = Resource.Col_Lock_Weighing;
            this.dgvSAPDest.Columns["Create_By"].HeaderText = Resource.Gatepass_063;
            this.dgvSAPDest.Columns["Create_Date"].HeaderText = Resource.Gatepass_064;
            this.dgvSAPDest.Columns["Change_By"].HeaderText = Resource.Gatepass_065;
            this.dgvSAPDest.Columns["Change_Date"].HeaderText = Resource.Gatepass_066;
            this.dgvSAPDest.Columns["Delete_By"].HeaderText = Resource.Col_Delete_By;
            this.dgvSAPDest.Columns["Delete_Date"].HeaderText = Resource.Col_Delete_Date;
            this.dgvSAPDest.Columns["WBCode"].DisplayIndex = 0;
            this.dgvSAPDest.Columns["Certification_No"].DisplayIndex = 1;
            this.dgvSAPDest.Columns["Calibration_Date"].DisplayIndex = 2;
            this.dgvSAPDest.Columns["Valid_Date"].DisplayIndex = 3;
            this.dgvSAPDest.Columns["Lock_Weighing"].DisplayIndex = 4;
            this.dgvSAPDest.Columns["Create_By"].DisplayIndex = 5;
            this.dgvSAPDest.Columns["Create_Date"].DisplayIndex = 6;
            this.dgvSAPDest.Columns["Change_By"].DisplayIndex = 7;
            this.dgvSAPDest.Columns["Change_Date"].DisplayIndex = 8;
            this.dgvSAPDest.Columns["Delete_By"].DisplayIndex = 9;
            this.dgvSAPDest.Columns["Delete_Date"].DisplayIndex = 10;
            if (this.dgvSAPDest.RowCount == 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.dgvSAPDest = new DataGridView();
            this.panel1 = new Panel();
            this.checkDeleted = new CheckBox();
            this.progressBar1 = new ProgressBar();
            this.menuStrip1.SuspendLayout();
            ((ISupportInitialize) this.dgvSAPDest).BeginInit();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(630, 0x18);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.viewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.activitiesToolStripMenuItem.DropDownOpening += new EventHandler(this.activitiesToolStripMenuItem_DropDownOpening);
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.dgvSAPDest.AllowUserToAddRows = false;
            this.dgvSAPDest.AllowUserToDeleteRows = false;
            this.dgvSAPDest.AllowUserToResizeRows = false;
            this.dgvSAPDest.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvSAPDest.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgvSAPDest.ColumnHeadersDefaultCellStyle = style;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgvSAPDest.DefaultCellStyle = style2;
            this.dgvSAPDest.Dock = DockStyle.Fill;
            this.dgvSAPDest.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvSAPDest.Location = new Point(0, 0x18);
            this.dgvSAPDest.MultiSelect = false;
            this.dgvSAPDest.Name = "dgvSAPDest";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgvSAPDest.RowHeadersDefaultCellStyle = style3;
            this.dgvSAPDest.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvSAPDest.Size = new Size(630, 0x120);
            this.dgvSAPDest.TabIndex = 12;
            this.dgvSAPDest.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dgvSAPDest_CellFormatting);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.checkDeleted);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x138);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(630, 0x20);
            this.panel1.TabIndex = 13;
            this.checkDeleted.AutoSize = true;
            this.checkDeleted.Location = new Point(0x1ac, 6);
            this.checkDeleted.Name = "checkDeleted";
            this.checkDeleted.Size = new Size(0x97, 0x11);
            this.checkDeleted.TabIndex = 0x15;
            this.checkDeleted.Text = "Show Deleted Certification";
            this.checkDeleted.UseVisualStyleBackColor = true;
            this.checkDeleted.CheckedChanged += new EventHandler(this.checkDeleted_CheckedChanged);
            this.progressBar1.Location = new Point(0x2bb, 10);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xe0, 0x11);
            this.progressBar1.TabIndex = 20;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(630, 0x158);
            base.ControlBox = false;
            base.Controls.Add(this.dgvSAPDest);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.MainMenuStrip = this.menuStrip1;
            base.Name = "FormWBCalibration";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "List of WB Calibration Certification";
            base.Load += new EventHandler(this.FormWBCalibration_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormWBCalibration_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((ISupportInitialize) this.dgvSAPDest).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Trans_057;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.checkDeleted.Text = Resource.Chk_Deleted_Certification;
            this.Text = Resource.Title_WB_Calibration;
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dgvSAPDest.Rows.Count > 0) && this.ztable.BeforeEdit(this.dgvSAPDest, "ADD"))
            {
                FormWBCalibrationEntry entry = new FormWBCalibrationEntry {
                    pMode = "VIEW",
                    Text = Resource.Title_View_WB_Calibration,
                    nCurrRow = this.ztable.GetPosRec(this.dgvSAPDest.CurrentRow.Cells["uniq"].Value.ToString()),
                    zTable = this.ztable
                };
                entry.ShowDialog();
                this.ztable.UnLock();
                entry.Dispose();
            }
        }
    }
}

