﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormDeepSetting : Form
    {
        public bool df_NOPW;
        public bool df_lockbongkar;
        public bool df_cekzero;
        public bool df_token;
        public string uniq_no;
        public string result;
        public string editTrace = "";
        public string logKey = "";
        private DataTable tmpTrans;
        private DataRow transBefore;
        public WBTable tLocation = new WBTable();
        public WBTable tblComp = new WBTable();
        private WBTable tbl_warning_trace = new WBTable();
        private IContainer components = null;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private CheckBox checkZero;
        private Button butCancel;
        private Button butSave;
        private ComboBox cmbBoxWBOwner;
        private Label label1;
        private CheckBox checkTare;
        private CheckBox cbAutoCloseDO;
        private CheckBox checkDeliveryNote;
        private CheckBox cbCopytoLoc;
        private CheckBox checkRounding;
        private Label label22;
        private Label label21;
        private TextBox textMinTrans;
        private Label label98;
        private ComboBox cmbColour;
        private Label lblColour;
        private Panel panel19;
        private RadioButton radioNKB;
        private RadioButton radioKB;
        private CheckBox checkEmailAllow;
        private Panel panel2;
        private Label label2;
        private MaskedTextBox textBeginAt;
        private RadioButton radioBeginsAt;
        private RadioButton radioTimeDefault;
        private Label label3;
        private Label label4;
        private Panel panel3;
        private CheckBox checkToken;
        private Label label5;
        private TextBox textArea;
        private CheckBox chkLockBongkar;
        private CheckBox chkNOPW;
        private Label label6;
        private CheckBox cBoxItgSAP;
        private StatusStrip statusStrip1;
        private Panel panel1;
        private Panel panel4;
        private Label label7;
        private Label label8;
        private Panel panel5;
        private Label label9;
        private CheckBox checkBoxControlGrossW;
        private ToolTip toolTipInformation;
        private CheckBox checkControlOutgoing;
        private CheckBox checkBoxLocationChecksumControl;
        private CheckBox checkZero1st;
        private CheckBox checkZero4th;
        private CheckBox checkZero2nd;
        private CheckBox checkZero3rd;
        private Panel panelCheckZero;
        private CheckBox cTanker;
        private Panel pCheckTanker;
        private RadioButton rbTankerKG;
        private RadioButton rbTankerPersen;
        private TextBox tTankerTolKG;
        private TextBox tTankerTolPersen;
        private CheckBox checkOutSpec;
        private Label label10;
        private Panel panel6;
        private NumericUpDown numeric_VesselLimitTolerance;
        private Label label11;
        private Panel panel7;
        private NumericUpDown numericDNDuration;
        private Label lblDNDuration;
        private Label lblDN;
        private Label lblDNMaintainInfo;

        public FormDeepSetting()
        {
            this.InitializeComponent();
        }

        private void butCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void butSave_Click(object sender, EventArgs e)
        {
            if (this.cmbColour.SelectedItem == null)
            {
                MessageBox.Show("Please choose Colour");
            }
            else if ((WBSetting.activeBC && this.radioKB.Checked) && this.chkLockBongkar.Checked)
            {
                MessageBox.Show("KB Location cannot activate Lock Bongkar");
            }
            else if (this.checkZero.Checked && ((!this.checkZero1st.Checked && (!this.checkZero2nd.Checked && !this.checkZero3rd.Checked)) && !this.checkZero4th.Checked))
            {
                MessageBox.Show("Check Zero is activated, Please Choose check zero at 1st, 2nd, 3rd or 4th");
            }
            else if ((this.cTanker.Checked && !this.rbTankerPersen.Checked) && !this.rbTankerKG.Checked)
            {
                MessageBox.Show("Check Tanker is activated, Please Choose Tolerance by % or KG");
            }
            else if (this.rbTankerPersen.Checked && (this.tTankerTolPersen.Text == ""))
            {
                MessageBox.Show("Please fill in % tolerance for check tanker");
            }
            else if (this.rbTankerKG.Checked && (this.tTankerTolKG.Text == ""))
            {
                MessageBox.Show("Please fill in KG tolerance for check tanker");
            }
            else
            {
                this.result = Interaction.InputBox("Change Reasons", "Change Reasons", "", 150, 150);
                if (this.result == "")
                {
                    MessageBox.Show("Please Fill In Reason", "W A R N I N G ! !");
                }
                else
                {
                    this.tLocation.ReOpen();
                    DataRow row = this.tLocation.DT.Rows[0];
                    this.logKey = row["uniq"].ToString();
                    row.BeginEdit();
                    row["GM"] = this.checkToken.Checked ? "Y" : "N";
                    row["Indicator"] = this.checkZero.Checked ? "Y" : "N";
                    row["GRCustRequired"] = this.chkLockBongkar.Checked ? "Y" : "N";
                    row["NOPW"] = this.chkNOPW.Checked ? "Y" : "N";
                    row["WBOwner"] = this.cmbBoxWBOwner.Text;
                    row["CopyToLoc"] = this.cbCopytoLoc.Checked ? "Y" : "N";
                    row["AutoCloseDO"] = this.cbAutoCloseDO.Checked ? "Y" : "N";
                    row["Colour"] = this.cmbColour.SelectedItem;
                    row["Check_Tare"] = this.checkTare.Checked ? "Y" : "N";
                    row["DeliveryNote"] = this.checkDeliveryNote.Checked ? "Y" : "N";
                    row["Check_Tare_MinTrans"] = this.textMinTrans.Text;
                    row["round"] = this.checkRounding.Checked ? "Y" : "N";
                    row["KB"] = this.radioKB.Checked ? "Y" : "N";
                    row["Check_Email"] = this.checkEmailAllow.Checked ? "Y" : "N";
                    row["Time_Default"] = this.radioTimeDefault.Checked ? "Y" : "N";
                    row["Time_Begin"] = this.textBeginAt.Text;
                    row["Area"] = this.textArea.Text;
                    if (WBSetting.integrationIDSYS)
                    {
                        row["IntegrationSAP"] = "N";
                    }
                    else
                    {
                        row["IntegrationSAP"] = this.cBoxItgSAP.Checked ? "Y" : "N";
                        WBTable table = new WBTable();
                        table.OpenTable("wb_condition", "select * from wb_condition where " + WBData.CompanyLocation(" and Condition_Code = 'IntegrationSAP'"), WBData.conn);
                        if (table.DT.Rows.Count > 0)
                        {
                            table.DR = table.DT.Rows[0];
                            table.DR.BeginEdit();
                            table.DR["allow_disable"] = "Y";
                            if (this.cBoxItgSAP.Checked)
                            {
                                table.DR["start_inactive_time"] = DateTime.Now.AddSeconds(-1.0).ToString("yyyy-MM-dd HH:mm:ss");
                                table.DR["end_inactive_time"] = DateTime.Now.AddSeconds(-1.0).ToString("yyyy-MM-dd HH:mm:ss");
                            }
                            else
                            {
                                table.DR["start_inactive_time"] = DateTime.Now.AddSeconds(-1.0).ToString("yyyy-MM-dd HH:mm:ss");
                                table.DR["end_inactive_time"] = new DateTime(0x270f, 12, 0x1f, 0x17, 0x3b, 0x3b).ToString("yyyy-MM-dd HH:mm:ss");
                            }
                            table.DR.EndEdit();
                            table.Save();
                        }
                        else
                        {
                            table.DR = table.DT.NewRow();
                            table.DR["Coy"] = WBData.sCoyCode;
                            table.DR["Location_Code"] = WBData.sLocCode;
                            table.DR["Condition_Code"] = "IntegrationSap";
                            table.DR["Description"] = "Active SAP Integration for WB.NET";
                            table.DR["allow_disable"] = "Y";
                            if (this.cBoxItgSAP.Checked)
                            {
                                table.DR["start_inactive_time"] = DateTime.Now.AddSeconds(-1.0);
                                table.DR["end_inactive_time"] = DateTime.Now.AddSeconds(-1.0);
                            }
                            else
                            {
                                table.DR["start_inactive_time"] = DateTime.Now.AddSeconds(-1.0);
                                table.DR["end_inactive_time"] = new DateTime(0x270f, 12, 0x1f, 0x17, 0x3b, 0x3b);
                            }
                            table.DT.Rows.Add(table.DR);
                            table.Save();
                        }
                        table.Dispose();
                    }
                    row["Reason"] = this.result.Trim();
                    row["GrossWeightControl"] = this.checkBoxControlGrossW.Checked ? "Y" : "N";
                    row["OutgoingTransControl"] = this.checkControlOutgoing.Checked ? "Y" : "N";
                    row["LocationChecksumControl"] = this.checkBoxLocationChecksumControl.Checked ? "Y" : "N";
                    row["checkOutSpec"] = this.checkOutSpec.Checked ? "Y" : "N";
                    row["VesselLimitTolerance"] = this.numeric_VesselLimitTolerance.Value;
                    string str = "";
                    if (this.checkZero1st.Checked)
                    {
                        str = str + "1";
                    }
                    if (this.checkZero2nd.Checked)
                    {
                        str = str + "2";
                    }
                    if (this.checkZero3rd.Checked)
                    {
                        str = str + "3";
                    }
                    if (this.checkZero4th.Checked)
                    {
                        str = str + "4";
                    }
                    row["CheckIndMode"] = str;
                    if (!this.cTanker.Checked)
                    {
                        row["Check_Tanker"] = "";
                        row["CheckTankerTol"] = 0;
                        row["CheckTankerKG"] = 0;
                    }
                    else if (this.rbTankerPersen.Checked)
                    {
                        row["Check_Tanker"] = "P";
                        row["CheckTankerTol"] = this.tTankerTolPersen.Text;
                        row["CheckTankerKG"] = 0;
                    }
                    else if (this.rbTankerKG.Checked)
                    {
                        row["Check_Tanker"] = "K";
                        row["CheckTankerKG"] = this.tTankerTolKG.Text;
                        row["CheckTankerTol"] = 0;
                    }
                    row["dn_expired_duration"] = this.numericDNDuration.Value;
                    row["checksum"] = this.tLocation.Checksum(row);
                    row.EndEdit();
                    this.tLocation.DR = row;
                    this.tLocation.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, this.result };
                    Program.updateLogHeader("wb_location", this.logKey, logField, logValue);
                    base.Close();
                }
            }
        }

        private void checkToken_CheckedChanged(object sender, EventArgs e)
        {
            this.textArea.Enabled = this.checkToken.Checked;
        }

        private void checkZero_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkZero.Checked)
            {
                this.panelCheckZero.Enabled = true;
            }
            else
            {
                this.panelCheckZero.Enabled = false;
                this.checkZero1st.Checked = false;
                this.checkZero2nd.Checked = false;
                this.checkZero3rd.Checked = false;
                this.checkZero4th.Checked = false;
            }
        }

        private void cmbColour_SelectedIndexChanged(object sender, EventArgs e)
        {
            string s = this.cmbColour.Items[this.cmbColour.SelectedIndex].ToString();
            uint num = <PrivateImplementationDetails>.ComputeStringHash(s);
            if (num > 0x727b390b)
            {
                if (num > 0xa37f187c)
                {
                    if (num == 0xa953c75c)
                    {
                        if (s == "Green")
                        {
                            this.cmbColour.BackColor = Color.Green;
                            return;
                        }
                    }
                    else if ((num == 0xb682ba1f) && (s == "Purple"))
                    {
                        this.cmbColour.BackColor = Color.Purple;
                        return;
                    }
                }
                else if (num == 0x8bb8038d)
                {
                    if (s == "Pink")
                    {
                        this.cmbColour.BackColor = Color.Pink;
                        return;
                    }
                }
                else if ((num == 0xa37f187c) && (s == "Red"))
                {
                    this.cmbColour.BackColor = Color.Red;
                    return;
                }
            }
            else if (num == 0x2b043744)
            {
                if (s == "Black")
                {
                    this.cmbColour.BackColor = Color.Black;
                    return;
                }
            }
            else if (num == 0x6c94b6b3)
            {
                if (s == "Gold")
                {
                    this.cmbColour.BackColor = Color.Gold;
                    return;
                }
            }
            else if ((num == 0x727b390b) && (s == "Orange"))
            {
                this.cmbColour.BackColor = Color.Orange;
                return;
            }
            this.cmbColour.BackColor = Color.RoyalBlue;
        }

        private void cTanker_CheckedChanged(object sender, EventArgs e)
        {
            if (this.cTanker.Checked)
            {
                this.pCheckTanker.Enabled = true;
            }
            else
            {
                this.pCheckTanker.Enabled = false;
                this.rbTankerPersen.Checked = false;
                this.rbTankerKG.Checked = false;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool editWarning(DataTable tmpTrans)
        {
            this.editTrace = "";
            bool flag = false;
            this.tLocation.OpenTable("wb_location", "Select * From wb_location where " + WBData.CompanyLocation(""), WBData.conn);
            this.tbl_warning_trace.OpenTable("wb_warning_trace", "select * from wb_warning_trace WHERE " + WBData.CompanyLocation(" AND ( type = 'CONTROL')"), WBData.conn);
            this.tLocation.DR = this.tLocation.DT.Rows[0];
            foreach (DataRow row in this.tbl_warning_trace.DT.Rows)
            {
                bool flag2 = row["selected"].ToString() == "Y";
                if (flag2 && (row["name"].ToString().ToUpper().Trim() != "DO"))
                {
                    this.transBefore = tmpTrans.Rows[0];
                    if (this.tLocation.DR[row["FieldName"].ToString()].ToString().ToUpper().Trim() != this.transBefore[row["FieldName"].ToString()].ToString().ToUpper().Trim())
                    {
                        flag = true;
                        string str = "Blank";
                        if (this.transBefore[row["FieldName"].ToString()].ToString().Trim().Length > 0)
                        {
                            str = this.transBefore[row["FieldName"].ToString()].ToString().Trim();
                        }
                        string[] textArray1 = new string[] { this.editTrace, "<tr class='bd'><td nowrap>", row["Name"].ToString().Trim().PadRight(20, ' '), "</td><td nowrap>", str.PadRight(20, ' '), "</td><td nowrap>", this.tLocation.DR[row["FieldName"].ToString()].ToString().Trim().PadRight(20, ' '), "</td></tr>" };
                        this.editTrace = string.Concat(textArray1);
                    }
                }
            }
            return flag;
        }

        private void FormDeepSetting_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormDeepSetting_Load(object sender, EventArgs e)
        {
            int result = 0;
            string sCoyCode = WBData.sCoyCode;
            string sLocCode = WBData.sLocCode;
            string sWBCode = WBData.sWBCode;
            this.tLocation.OpenTable("wb_location", "Select * From wb_location where " + WBData.CompanyLocation(""), WBData.conn);
            DataRow row = this.tLocation.DT.Rows[0];
            this.tbl_warning_trace.OpenTable("wb_warning_trace", "select * from wb_warning_trace WHERE " + WBData.CompanyLocation(" AND ( type = 'CONTROL')"), WBData.conn);
            this.tmpTrans = this.tLocation.DT.Clone();
            this.transBefore = this.tmpTrans.NewRow();
            this.transBefore.ItemArray = this.tLocation.DT.Rows[0].ItemArray;
            this.tmpTrans.Rows.Add(this.transBefore);
            this.label6.Text = "Wilmar Group - Copyright \x00a9, V." + row["Version"].ToString();
            this.uniq_no = row["uniq"].ToString();
            this.checkZero.Checked = this.df_cekzero = row["Indicator"].ToString() == "Y";
            if (this.checkZero.Checked)
            {
                this.panelCheckZero.Enabled = true;
            }
            else
            {
                this.panelCheckZero.Enabled = false;
                this.checkZero1st.Checked = false;
                this.checkZero2nd.Checked = false;
                this.checkZero3rd.Checked = false;
                this.checkZero4th.Checked = false;
            }
            this.checkToken.Checked = this.df_token = row["GM"].ToString() == "Y";
            this.chkLockBongkar.Checked = this.df_lockbongkar = row["GRCustRequired"].ToString() == "Y";
            this.cbCopytoLoc.Checked = row["CopyToLoc"].ToString() == "Y";
            this.cbAutoCloseDO.Checked = row["AutoCloseDO"].ToString() == "Y";
            this.cmbColour.SelectedItem = row["Colour"].ToString();
            this.checkTare.Checked = row["Check_Tare"].ToString() == "Y";
            if (WBSetting.integrationIDSYS)
            {
                this.cBoxItgSAP.Checked = true;
            }
            else
            {
                WBCondition condition = new WBCondition();
                this.cBoxItgSAP.Checked = condition.getSettingCondition("IntegrationSAP");
                condition.Dispose();
            }
            this.checkDeliveryNote.Checked = row["DeliveryNote"].ToString() == "Y";
            this.textMinTrans.Text = row["Check_Tare_MinTrans"].ToString();
            this.checkRounding.Checked = false;
            this.checkRounding.Checked = row["round"].ToString() == "Y";
            if (row["KB"].ToString() == "Y")
            {
                this.radioKB.Checked = true;
            }
            else
            {
                this.radioNKB.Checked = true;
            }
            this.checkEmailAllow.Checked = row["Check_Email"].ToString() == "Y";
            this.radioTimeDefault.Checked = row["Time_Default"].ToString() == "Y";
            this.radioBeginsAt.Checked = row["Time_Default"].ToString() == "N";
            this.textBeginAt.Text = row["Time_Begin"].ToString();
            this.textArea.Text = row["Area"].ToString();
            this.checkOutSpec.Checked = row["checkOutSpec"].ToString() == "Y";
            this.numeric_VesselLimitTolerance.Value = int.TryParse(row["VesselLimitTolerance"].ToString(), out result) ? result : 0;
            this.chkNOPW.Checked = this.df_NOPW = row["NOPW"].ToString() == "Y";
            this.checkBoxControlGrossW.Checked = row["GrossWeightControl"].ToString() == "Y";
            this.checkControlOutgoing.Checked = row["OutgoingTransControl"].ToString() == "Y";
            this.checkBoxLocationChecksumControl.Checked = row["LocationChecksumControl"].ToString() == "Y";
            string str4 = "";
            this.checkZero1st.Checked = false;
            this.checkZero2nd.Checked = false;
            this.checkZero3rd.Checked = false;
            this.checkZero4th.Checked = false;
            str4 = row["CheckIndMode"].ToString();
            if (str4.Length > 0)
            {
                foreach (char ch in str4)
                {
                    if (ch == '1')
                    {
                        this.checkZero1st.Checked = true;
                    }
                    if (ch == '2')
                    {
                        this.checkZero2nd.Checked = true;
                    }
                    if (ch == '3')
                    {
                        this.checkZero3rd.Checked = true;
                    }
                    if (ch == '4')
                    {
                        this.checkZero4th.Checked = true;
                    }
                }
            }
            this.tblComp.OpenTable("wb_company", "select distinct (coy_name) from wb_company where coy_name <> ''", WBData.conn);
            foreach (DataRow row2 in this.tblComp.DT.Rows)
            {
                this.cmbBoxWBOwner.Items.Add(row2["coy_name"].ToString());
            }
            this.cmbBoxWBOwner.Text = row["WBOwner"].ToString();
            if (this.cmbBoxWBOwner.Text == "")
            {
                this.cmbBoxWBOwner.Text = this.tblComp.DT.Rows[0]["coy_name"].ToString();
            }
            if (row["Check_Tanker"].ToString().Trim() == "")
            {
                this.cTanker.Checked = false;
                this.rbTankerKG.Checked = false;
                this.rbTankerPersen.Checked = false;
                this.tTankerTolPersen.Text = "0";
                this.tTankerTolPersen.Enabled = false;
                this.tTankerTolKG.Enabled = false;
                this.tTankerTolKG.Text = "0";
            }
            else
            {
                this.cTanker.Checked = true;
                if (row["Check_Tanker"].ToString() == "P")
                {
                    this.rbTankerPersen.Checked = true;
                    this.rbTankerKG.Checked = false;
                    this.tTankerTolKG.Enabled = false;
                    this.tTankerTolKG.Text = "0";
                    this.tTankerTolPersen.Text = row["CheckTankerTol"].ToString();
                }
                else if (row["Check_Tanker"].ToString() == "K")
                {
                    this.rbTankerPersen.Checked = false;
                    this.rbTankerKG.Checked = true;
                    this.tTankerTolPersen.Enabled = false;
                    this.tTankerTolPersen.Text = "0";
                    this.tTankerTolKG.Text = row["CheckTankerKG"].ToString();
                }
            }
            if (!WBUser.CheckTrustee("MD_CONTROL", "E"))
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.butSave.Enabled = false;
                this.butCancel.Enabled = true;
            }
            this.cBoxItgSAP.Text = this.cBoxItgSAP.Text + this.sapIDSYS;
            this.checkControlOutgoing.Text = "Control Outgoing by DO " + this.sapIDSYS + " and Internal Number";
            if (string.IsNullOrEmpty(row["dn_expired_duration"].ToString()))
            {
                this.lblDNMaintainInfo.Visible = true;
            }
            else if (!string.IsNullOrEmpty(row["dn_expired_duration"].ToString()))
            {
                this.lblDNMaintainInfo.Visible = false;
                this.numericDNDuration.Value = Convert.ToInt32(row["dn_expired_duration"].ToString());
            }
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.checkZero = new CheckBox();
            this.butCancel = new Button();
            this.butSave = new Button();
            this.cmbBoxWBOwner = new ComboBox();
            this.label1 = new Label();
            this.checkTare = new CheckBox();
            this.cbAutoCloseDO = new CheckBox();
            this.checkDeliveryNote = new CheckBox();
            this.cbCopytoLoc = new CheckBox();
            this.checkRounding = new CheckBox();
            this.label22 = new Label();
            this.label21 = new Label();
            this.textMinTrans = new TextBox();
            this.label98 = new Label();
            this.cmbColour = new ComboBox();
            this.lblColour = new Label();
            this.panel19 = new Panel();
            this.radioNKB = new RadioButton();
            this.radioKB = new RadioButton();
            this.checkEmailAllow = new CheckBox();
            this.panel2 = new Panel();
            this.label2 = new Label();
            this.textBeginAt = new MaskedTextBox();
            this.radioBeginsAt = new RadioButton();
            this.radioTimeDefault = new RadioButton();
            this.label3 = new Label();
            this.label4 = new Label();
            this.panel3 = new Panel();
            this.checkToken = new CheckBox();
            this.label5 = new Label();
            this.textArea = new TextBox();
            this.chkLockBongkar = new CheckBox();
            this.chkNOPW = new CheckBox();
            this.label6 = new Label();
            this.cBoxItgSAP = new CheckBox();
            this.statusStrip1 = new StatusStrip();
            this.panel1 = new Panel();
            this.checkBoxLocationChecksumControl = new CheckBox();
            this.panel4 = new Panel();
            this.checkOutSpec = new CheckBox();
            this.cTanker = new CheckBox();
            this.pCheckTanker = new Panel();
            this.tTankerTolKG = new TextBox();
            this.tTankerTolPersen = new TextBox();
            this.rbTankerKG = new RadioButton();
            this.rbTankerPersen = new RadioButton();
            this.panelCheckZero = new Panel();
            this.checkZero4th = new CheckBox();
            this.checkZero1st = new CheckBox();
            this.checkZero2nd = new CheckBox();
            this.checkZero3rd = new CheckBox();
            this.checkControlOutgoing = new CheckBox();
            this.checkBoxControlGrossW = new CheckBox();
            this.label7 = new Label();
            this.label8 = new Label();
            this.panel5 = new Panel();
            this.label9 = new Label();
            this.toolTipInformation = new ToolTip(this.components);
            this.label10 = new Label();
            this.panel6 = new Panel();
            this.numeric_VesselLimitTolerance = new NumericUpDown();
            this.label11 = new Label();
            this.panel7 = new Panel();
            this.numericDNDuration = new NumericUpDown();
            this.lblDNDuration = new Label();
            this.lblDN = new Label();
            this.lblDNMaintainInfo = new Label();
            this.panel19.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.pCheckTanker.SuspendLayout();
            this.panelCheckZero.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.numeric_VesselLimitTolerance.BeginInit();
            this.panel7.SuspendLayout();
            this.numericDNDuration.BeginInit();
            base.SuspendLayout();
            this.checkZero.AutoSize = true;
            this.checkZero.Location = new Point(0xde, 7);
            this.checkZero.Name = "checkZero";
            this.checkZero.Size = new Size(0xaf, 0x11);
            this.checkZero.TabIndex = 0x45;
            this.checkZero.Text = "Checked Zero on The Indicator";
            this.toolTipInformation.SetToolTip(this.checkZero, "Cannot Weight Truck if Indicator Not Zero");
            this.checkZero.UseVisualStyleBackColor = true;
            this.checkZero.CheckedChanged += new EventHandler(this.checkZero_CheckedChanged);
            this.butCancel.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.butCancel.Location = new Point(0x2ba, 0x1c1);
            this.butCancel.Name = "butCancel";
            this.butCancel.Size = new Size(0x62, 60);
            this.butCancel.TabIndex = 0x47;
            this.butCancel.Text = "&Cancel";
            this.butCancel.UseVisualStyleBackColor = true;
            this.butCancel.Click += new EventHandler(this.butCancel_Click);
            this.butSave.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.butSave.Location = new Point(0x250, 0x1c1);
            this.butSave.Name = "butSave";
            this.butSave.Size = new Size(0x62, 60);
            this.butSave.TabIndex = 70;
            this.butSave.Text = "&Save";
            this.butSave.UseVisualStyleBackColor = true;
            this.butSave.Click += new EventHandler(this.butSave_Click);
            this.cmbBoxWBOwner.FormattingEnabled = true;
            this.cmbBoxWBOwner.Location = new Point(0x48, 0x20);
            this.cmbBoxWBOwner.Name = "cmbBoxWBOwner";
            this.cmbBoxWBOwner.Size = new Size(0x1a6, 0x15);
            this.cmbBoxWBOwner.TabIndex = 0x4a;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(7, 0x23);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3b, 13);
            this.label1.TabIndex = 0x4b;
            this.label1.Text = "WB Owner";
            this.checkTare.AutoSize = true;
            this.checkTare.Location = new Point(3, 7);
            this.checkTare.Name = "checkTare";
            this.checkTare.Size = new Size(0x9f, 0x11);
            this.checkTare.TabIndex = 0x4c;
            this.checkTare.Text = "Checked Tare of The Truck";
            this.checkTare.UseVisualStyleBackColor = true;
            this.cbAutoCloseDO.AutoSize = true;
            this.cbAutoCloseDO.Location = new Point(3, 0x35);
            this.cbAutoCloseDO.Name = "cbAutoCloseDO";
            this.cbAutoCloseDO.Size = new Size(0x60, 0x11);
            this.cbAutoCloseDO.TabIndex = 0x4e;
            this.cbAutoCloseDO.Text = "Auto Close DO";
            this.cbAutoCloseDO.UseVisualStyleBackColor = true;
            this.checkDeliveryNote.AutoSize = true;
            this.checkDeliveryNote.Location = new Point(3, 0x4c);
            this.checkDeliveryNote.Name = "checkDeliveryNote";
            this.checkDeliveryNote.Size = new Size(0xc5, 0x11);
            this.checkDeliveryNote.TabIndex = 0x4d;
            this.checkDeliveryNote.Text = "Require Entry Delivery Note Number";
            this.checkDeliveryNote.UseVisualStyleBackColor = true;
            this.cbCopytoLoc.AutoSize = true;
            this.cbCopytoLoc.Location = new Point(2, 0x1d);
            this.cbCopytoLoc.Name = "cbCopytoLoc";
            this.cbCopytoLoc.Size = new Size(0x11c, 0x11);
            this.cbCopytoLoc.TabIndex = 0x4f;
            this.cbCopytoLoc.Text = "Enable Master Data Copy to All Location in 1 Company";
            this.cbCopytoLoc.UseVisualStyleBackColor = true;
            this.checkRounding.AutoSize = true;
            this.checkRounding.Location = new Point(3, 0x63);
            this.checkRounding.Name = "checkRounding";
            this.checkRounding.Size = new Size(0x92, 0x11);
            this.checkRounding.TabIndex = 0x52;
            this.checkRounding.Text = "Rounding The Deduction";
            this.checkRounding.UseVisualStyleBackColor = true;
            this.label22.AutoSize = true;
            this.label22.Location = new Point(0x5e, 30);
            this.label22.Name = "label22";
            this.label22.Size = new Size(0x44, 13);
            this.label22.TabIndex = 0x59;
            this.label22.Text = "Transactions";
            this.label21.AutoSize = true;
            this.label21.Location = new Point(0x1b, 30);
            this.label21.Name = "label21";
            this.label21.Size = new Size(0x18, 13);
            this.label21.TabIndex = 0x58;
            this.label21.Text = "Min";
            this.textMinTrans.Location = new Point(0x39, 0x1b);
            this.textMinTrans.Name = "textMinTrans";
            this.textMinTrans.Size = new Size(0x22, 20);
            this.textMinTrans.TabIndex = 0x57;
            this.textMinTrans.Text = "5";
            this.textMinTrans.TextAlign = HorizontalAlignment.Right;
            this.label98.AutoSize = true;
            this.label98.Location = new Point(0x256, 11);
            this.label98.Name = "label98";
            this.label98.Size = new Size(0x45, 13);
            this.label98.TabIndex = 90;
            this.label98.Text = "KB / Non KB";
            this.cmbColour.BackColor = Color.Blue;
            this.cmbColour.ForeColor = SystemColors.Window;
            this.cmbColour.FormattingEnabled = true;
            object[] items = new object[] { "Black", "Blue", "Gold", "Green", "Orange", "Pink", "Purple", "Red" };
            this.cmbColour.Items.AddRange(items);
            this.cmbColour.Location = new Point(0x35, 0x22);
            this.cmbColour.Name = "cmbColour";
            this.cmbColour.Size = new Size(0x8e, 0x15);
            this.cmbColour.TabIndex = 0;
            this.cmbColour.Text = "Blue";
            this.cmbColour.SelectedIndexChanged += new EventHandler(this.cmbColour_SelectedIndexChanged);
            this.lblColour.AutoSize = true;
            this.lblColour.Location = new Point(7, 0x25);
            this.lblColour.Name = "lblColour";
            this.lblColour.Size = new Size(0x25, 13);
            this.lblColour.TabIndex = 0x4d;
            this.lblColour.Text = "Colour";
            this.panel19.BorderStyle = BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.radioNKB);
            this.panel19.Controls.Add(this.radioKB);
            this.panel19.Controls.Add(this.cmbColour);
            this.panel19.Controls.Add(this.lblColour);
            this.panel19.Location = new Point(0x255, 0x1b);
            this.panel19.Name = "panel19";
            this.panel19.Size = new Size(0xca, 0x45);
            this.panel19.TabIndex = 0x5b;
            this.radioNKB.AutoSize = true;
            this.radioNKB.Checked = true;
            this.radioNKB.Location = new Point(14, 8);
            this.radioNKB.Name = "radioNKB";
            this.radioNKB.Size = new Size(0x3e, 0x11);
            this.radioNKB.TabIndex = 0x2c;
            this.radioNKB.TabStop = true;
            this.radioNKB.Text = "Non KB";
            this.radioNKB.UseVisualStyleBackColor = true;
            this.radioKB.AutoSize = true;
            this.radioKB.Location = new Point(0x67, 8);
            this.radioKB.Name = "radioKB";
            this.radioKB.Size = new Size(0x27, 0x11);
            this.radioKB.TabIndex = 0x2b;
            this.radioKB.Text = "KB";
            this.radioKB.UseVisualStyleBackColor = true;
            this.checkEmailAllow.AutoSize = true;
            this.checkEmailAllow.ForeColor = SystemColors.ControlText;
            this.checkEmailAllow.Location = new Point(2, 6);
            this.checkEmailAllow.Name = "checkEmailAllow";
            this.checkEmailAllow.Size = new Size(0x4f, 0x11);
            this.checkEmailAllow.TabIndex = 0x5c;
            this.checkEmailAllow.Text = "Allow Email";
            this.checkEmailAllow.UseVisualStyleBackColor = true;
            this.panel2.BorderStyle = BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.textBeginAt);
            this.panel2.Controls.Add(this.radioBeginsAt);
            this.panel2.Controls.Add(this.radioTimeDefault);
            this.panel2.Location = new Point(0x255, 0x75);
            this.panel2.Name = "panel2";
            this.panel2.Size = new Size(0xca, 0x51);
            this.panel2.TabIndex = 0x53;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x76, 0x2f);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x29, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "o'clock";
            this.textBeginAt.Enabled = false;
            this.textBeginAt.Location = new Point(0x51, 0x2c);
            this.textBeginAt.Mask = "00:00";
            this.textBeginAt.Name = "textBeginAt";
            this.textBeginAt.Size = new Size(0x24, 20);
            this.textBeginAt.TabIndex = 2;
            this.textBeginAt.Text = "0800";
            this.textBeginAt.ValidatingType = typeof(DateTime);
            this.radioBeginsAt.AutoSize = true;
            this.radioBeginsAt.Location = new Point(12, 0x2d);
            this.radioBeginsAt.Name = "radioBeginsAt";
            this.radioBeginsAt.Size = new Size(0x48, 0x11);
            this.radioBeginsAt.TabIndex = 1;
            this.radioBeginsAt.Text = "Begins at ";
            this.radioBeginsAt.UseVisualStyleBackColor = true;
            this.radioTimeDefault.AutoSize = true;
            this.radioTimeDefault.Checked = true;
            this.radioTimeDefault.Location = new Point(12, 15);
            this.radioTimeDefault.Name = "radioTimeDefault";
            this.radioTimeDefault.Size = new Size(0x91, 0x11);
            this.radioTimeDefault.TabIndex = 0;
            this.radioTimeDefault.TabStop = true;
            this.radioTimeDefault.Text = "Default ( Computer Time )";
            this.radioTimeDefault.UseVisualStyleBackColor = true;
            this.radioTimeDefault.CheckedChanged += new EventHandler(this.radioTimeDefault_CheckedChanged);
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x25b, 0x63);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x4f, 13);
            this.label3.TabIndex = 0x54;
            this.label3.Text = "Working Time :";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x25d, 0xcf);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x26, 13);
            this.label4.TabIndex = 0x55;
            this.label4.Text = "Token";
            this.panel3.BorderStyle = BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.checkToken);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.textArea);
            this.panel3.Location = new Point(0x255, 0xdf);
            this.panel3.Name = "panel3";
            this.panel3.Size = new Size(0xca, 0x42);
            this.panel3.TabIndex = 0x56;
            this.checkToken.AutoSize = true;
            this.checkToken.Location = new Point(0x10, 12);
            this.checkToken.Name = "checkToken";
            this.checkToken.Size = new Size(0x5d, 0x11);
            this.checkToken.TabIndex = 0x3d;
            this.checkToken.Text = "Enable Token";
            this.checkToken.UseVisualStyleBackColor = true;
            this.checkToken.CheckedChanged += new EventHandler(this.checkToken_CheckedChanged);
            this.label5.AutoSize = true;
            this.label5.Location = new Point(13, 0x25);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x1d, 13);
            this.label5.TabIndex = 0x3b;
            this.label5.Text = "Area";
            this.textArea.Location = new Point(0x30, 0x22);
            this.textArea.MaxLength = 5;
            this.textArea.Name = "textArea";
            this.textArea.Size = new Size(0x3d, 20);
            this.textArea.TabIndex = 60;
            this.chkLockBongkar.AutoSize = true;
            this.chkLockBongkar.Location = new Point(5, 4);
            this.chkLockBongkar.Name = "chkLockBongkar";
            this.chkLockBongkar.Size = new Size(0x12d, 0x11);
            this.chkLockBongkar.TabIndex = 0x4b;
            this.chkLockBongkar.Text = "GR No. Customized Required in Master Data DO/Contract";
            this.chkLockBongkar.UseVisualStyleBackColor = true;
            this.chkNOPW.AutoSize = true;
            this.chkNOPW.Location = new Point(4, 0x7a);
            this.chkNOPW.Name = "chkNOPW";
            this.chkNOPW.Size = new Size(0x9f, 0x11);
            this.chkNOPW.TabIndex = 0x4a;
            this.chkNOPW.Text = "No Other Party WB Quantity";
            this.chkNOPW.UseVisualStyleBackColor = true;
            this.label6.AutoSize = true;
            this.label6.Location = new Point(7, 8);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x23, 13);
            this.label6.TabIndex = 0x5d;
            this.label6.Text = "label6";
            this.cBoxItgSAP.AutoSize = true;
            this.cBoxItgSAP.Location = new Point(2, 0x33);
            this.cBoxItgSAP.Name = "cBoxItgSAP";
            this.cBoxItgSAP.Size = new Size(0x5b, 0x11);
            this.cBoxItgSAP.TabIndex = 0x5e;
            this.cBoxItgSAP.Text = "Integration to ";
            this.cBoxItgSAP.UseVisualStyleBackColor = true;
            this.statusStrip1.Location = new Point(0, 0x200);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(0x328, 0x16);
            this.statusStrip1.TabIndex = 0x5f;
            this.statusStrip1.Text = "statusStrip1";
            this.panel1.BorderStyle = BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.checkBoxLocationChecksumControl);
            this.panel1.Controls.Add(this.cbCopytoLoc);
            this.panel1.Controls.Add(this.cBoxItgSAP);
            this.panel1.Controls.Add(this.checkEmailAllow);
            this.panel1.Location = new Point(10, 0x55);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x1e8, 0x4c);
            this.panel1.TabIndex = 0x60;
            this.checkBoxLocationChecksumControl.AutoSize = true;
            this.checkBoxLocationChecksumControl.Location = new Point(0x12b, 6);
            this.checkBoxLocationChecksumControl.Name = "checkBoxLocationChecksumControl";
            this.checkBoxLocationChecksumControl.Size = new Size(0x9c, 0x11);
            this.checkBoxLocationChecksumControl.TabIndex = 0x5c;
            this.checkBoxLocationChecksumControl.Text = "Location Checksum Control";
            this.toolTipInformation.SetToolTip(this.checkBoxLocationChecksumControl, "If Checked Cannot open Program if Location Checksum Error\r\nIf Not Checked Can open Program even if Location Checksum Error\r\n");
            this.checkBoxLocationChecksumControl.UseVisualStyleBackColor = true;
            this.panel4.BorderStyle = BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.checkOutSpec);
            this.panel4.Controls.Add(this.cTanker);
            this.panel4.Controls.Add(this.pCheckTanker);
            this.panel4.Controls.Add(this.checkZero);
            this.panel4.Controls.Add(this.panelCheckZero);
            this.panel4.Controls.Add(this.checkControlOutgoing);
            this.panel4.Controls.Add(this.checkBoxControlGrossW);
            this.panel4.Controls.Add(this.checkTare);
            this.panel4.Controls.Add(this.checkDeliveryNote);
            this.panel4.Controls.Add(this.cbAutoCloseDO);
            this.panel4.Controls.Add(this.checkRounding);
            this.panel4.Controls.Add(this.chkNOPW);
            this.panel4.Controls.Add(this.textMinTrans);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Location = new Point(6, 0xbd);
            this.panel4.Name = "panel4";
            this.panel4.Size = new Size(0x1e8, 0xdf);
            this.panel4.TabIndex = 0x61;
            this.checkOutSpec.AutoSize = true;
            this.checkOutSpec.Location = new Point(4, 190);
            this.checkOutSpec.Name = "checkOutSpec";
            this.checkOutSpec.Size = new Size(0x146, 0x11);
            this.checkOutSpec.TabIndex = 0x69;
            this.checkOutSpec.Text = "Show Warning if Factory Quality is Out of Contract Specification";
            this.checkOutSpec.UseVisualStyleBackColor = true;
            this.cTanker.AutoSize = true;
            this.cTanker.Location = new Point(0xde, 0x52);
            this.cTanker.Name = "cTanker";
            this.cTanker.Size = new Size(150, 0x11);
            this.cTanker.TabIndex = 0x67;
            this.cTanker.Text = "Checked Tanker Capacity";
            this.cTanker.UseVisualStyleBackColor = true;
            this.cTanker.CheckedChanged += new EventHandler(this.cTanker_CheckedChanged);
            this.pCheckTanker.BorderStyle = BorderStyle.FixedSingle;
            this.pCheckTanker.Controls.Add(this.tTankerTolKG);
            this.pCheckTanker.Controls.Add(this.tTankerTolPersen);
            this.pCheckTanker.Controls.Add(this.rbTankerKG);
            this.pCheckTanker.Controls.Add(this.rbTankerPersen);
            this.pCheckTanker.Location = new Point(0xf5, 0x66);
            this.pCheckTanker.Name = "pCheckTanker";
            this.pCheckTanker.Size = new Size(0xbc, 0x3b);
            this.pCheckTanker.TabIndex = 0x68;
            this.toolTipInformation.SetToolTip(this.pCheckTanker, "Choose Weighning Mode to Check zero");
            this.tTankerTolKG.Location = new Point(0x7b, 0x1f);
            this.tTankerTolKG.MaxLength = 5;
            this.tTankerTolKG.Name = "tTankerTolKG";
            this.tTankerTolKG.Size = new Size(0x31, 20);
            this.tTankerTolKG.TabIndex = 0x6a;
            this.tTankerTolKG.Text = "0";
            this.tTankerTolKG.TextAlign = HorizontalAlignment.Right;
            this.tTankerTolKG.Leave += new EventHandler(this.tTankerTolKG_Leave);
            this.tTankerTolPersen.Location = new Point(0x7b, 5);
            this.tTankerTolPersen.MaxLength = 5;
            this.tTankerTolPersen.Name = "tTankerTolPersen";
            this.tTankerTolPersen.Size = new Size(0x31, 20);
            this.tTankerTolPersen.TabIndex = 0x69;
            this.tTankerTolPersen.Text = "0";
            this.tTankerTolPersen.TextAlign = HorizontalAlignment.Right;
            this.tTankerTolPersen.Leave += new EventHandler(this.tTankerTolPersen_Leave);
            this.rbTankerKG.AutoSize = true;
            this.rbTankerKG.Checked = true;
            this.rbTankerKG.Location = new Point(8, 0x1f);
            this.rbTankerKG.Name = "rbTankerKG";
            this.rbTankerKG.Size = new Size(0x66, 0x11);
            this.rbTankerKG.TabIndex = 0x6a;
            this.rbTankerKG.TabStop = true;
            this.rbTankerKG.Text = "Tolerance in KG";
            this.rbTankerKG.UseVisualStyleBackColor = true;
            this.rbTankerKG.CheckedChanged += new EventHandler(this.rbTankerKG_CheckedChanged);
            this.rbTankerPersen.AutoSize = true;
            this.rbTankerPersen.Location = new Point(8, 5);
            this.rbTankerPersen.Name = "rbTankerPersen";
            this.rbTankerPersen.Size = new Size(0x5f, 0x11);
            this.rbTankerPersen.TabIndex = 0x69;
            this.rbTankerPersen.Text = "Tolerance in %";
            this.rbTankerPersen.UseVisualStyleBackColor = true;
            this.rbTankerPersen.CheckedChanged += new EventHandler(this.rbTankerPersen_CheckedChanged);
            this.panelCheckZero.BorderStyle = BorderStyle.FixedSingle;
            this.panelCheckZero.Controls.Add(this.checkZero4th);
            this.panelCheckZero.Controls.Add(this.checkZero1st);
            this.panelCheckZero.Controls.Add(this.checkZero2nd);
            this.panelCheckZero.Controls.Add(this.checkZero3rd);
            this.panelCheckZero.Location = new Point(0xf5, 0x1b);
            this.panelCheckZero.Name = "panelCheckZero";
            this.panelCheckZero.Size = new Size(0x9d, 0x2d);
            this.panelCheckZero.TabIndex = 0x66;
            this.toolTipInformation.SetToolTip(this.panelCheckZero, "Choose Weighning Mode to Check zero");
            this.checkZero4th.AutoSize = true;
            this.checkZero4th.Location = new Point(0x65, 0x19);
            this.checkZero4th.Name = "checkZero4th";
            this.checkZero4th.Size = new Size(0x29, 0x11);
            this.checkZero4th.TabIndex = 0x49;
            this.checkZero4th.Text = "4th";
            this.checkZero4th.UseVisualStyleBackColor = true;
            this.checkZero1st.AutoSize = true;
            this.checkZero1st.Location = new Point(0x12, 2);
            this.checkZero1st.Name = "checkZero1st";
            this.checkZero1st.Size = new Size(40, 0x11);
            this.checkZero1st.TabIndex = 70;
            this.checkZero1st.Text = "1st";
            this.checkZero1st.UseVisualStyleBackColor = true;
            this.checkZero2nd.AutoSize = true;
            this.checkZero2nd.Location = new Point(0x65, 2);
            this.checkZero2nd.Name = "checkZero2nd";
            this.checkZero2nd.Size = new Size(0x2c, 0x11);
            this.checkZero2nd.TabIndex = 0x48;
            this.checkZero2nd.Text = "2nd";
            this.checkZero2nd.UseVisualStyleBackColor = true;
            this.checkZero3rd.AutoSize = true;
            this.checkZero3rd.Location = new Point(0x12, 0x19);
            this.checkZero3rd.Name = "checkZero3rd";
            this.checkZero3rd.Size = new Size(0x29, 0x11);
            this.checkZero3rd.TabIndex = 0x47;
            this.checkZero3rd.Text = "3rd";
            this.checkZero3rd.UseVisualStyleBackColor = true;
            this.checkControlOutgoing.AutoSize = true;
            this.checkControlOutgoing.Location = new Point(4, 0xa7);
            this.checkControlOutgoing.Name = "checkControlOutgoing";
            this.checkControlOutgoing.Size = new Size(0x105, 0x11);
            this.checkControlOutgoing.TabIndex = 0x5b;
            this.checkControlOutgoing.Text = "Control Outgoing by DO SAP and Internal Number";
            this.toolTipInformation.SetToolTip(this.checkControlOutgoing, "Block Transaction if Gross weight commodity is Beyond Tolerance");
            this.checkControlOutgoing.UseVisualStyleBackColor = true;
            this.checkBoxControlGrossW.AutoSize = true;
            this.checkBoxControlGrossW.Location = new Point(4, 0x90);
            this.checkBoxControlGrossW.Name = "checkBoxControlGrossW";
            this.checkBoxControlGrossW.Size = new Size(0xd0, 0x11);
            this.checkBoxControlGrossW.TabIndex = 90;
            this.checkBoxControlGrossW.Text = "Control Pack Commodity Gross Weight";
            this.toolTipInformation.SetToolTip(this.checkBoxControlGrossW, "Block Transaction if Gross weight commodity is Beyond Tolerance");
            this.checkBoxControlGrossW.UseVisualStyleBackColor = true;
            this.label7.AutoSize = true;
            this.label7.Location = new Point(11, 0x45);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x7e, 13);
            this.label7.TabIndex = 0x62;
            this.label7.Text = "Global Control && Features";
            this.label8.AutoSize = true;
            this.label8.Location = new Point(7, 0xad);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x98, 13);
            this.label8.TabIndex = 0x63;
            this.label8.Text = "Transaction Control && Features";
            this.panel5.BorderStyle = BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.chkLockBongkar);
            this.panel5.Location = new Point(6, 0x1ba);
            this.panel5.Name = "panel5";
            this.panel5.Size = new Size(0x1e8, 0x35);
            this.panel5.TabIndex = 100;
            this.label9.AutoSize = true;
            this.label9.Location = new Point(10, 0x1aa);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x9a, 13);
            this.label9.TabIndex = 0x65;
            this.label9.Text = "Master Data Control && Features";
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0x25d, 0x12e);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x26, 13);
            this.label10.TabIndex = 0x66;
            this.label10.Text = "Vessel";
            this.panel6.BorderStyle = BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.numeric_VesselLimitTolerance);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Location = new Point(0x255, 320);
            this.panel6.Name = "panel6";
            this.panel6.Size = new Size(0xca, 40);
            this.panel6.TabIndex = 0x67;
            this.numeric_VesselLimitTolerance.Location = new Point(0x99, 7);
            this.numeric_VesselLimitTolerance.Name = "numeric_VesselLimitTolerance";
            this.numeric_VesselLimitTolerance.Size = new Size(0x25, 20);
            this.numeric_VesselLimitTolerance.TabIndex = 60;
            this.label11.AutoSize = true;
            this.label11.Location = new Point(13, 10);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x7f, 13);
            this.label11.TabIndex = 0x3b;
            this.label11.Text = "Max % Tolerance for Split";
            this.panel7.BorderStyle = BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.lblDNMaintainInfo);
            this.panel7.Controls.Add(this.numericDNDuration);
            this.panel7.Controls.Add(this.lblDNDuration);
            this.panel7.Location = new Point(0x255, 0x185);
            this.panel7.Name = "panel7";
            this.panel7.Size = new Size(0xca, 0x36);
            this.panel7.TabIndex = 0x69;
            this.numericDNDuration.Location = new Point(0x99, 7);
            this.numericDNDuration.Name = "numericDNDuration";
            this.numericDNDuration.Size = new Size(0x25, 20);
            this.numericDNDuration.TabIndex = 60;
            this.lblDNDuration.AutoSize = true;
            this.lblDNDuration.Location = new Point(13, 10);
            this.lblDNDuration.Name = "lblDNDuration";
            this.lblDNDuration.Size = new Size(0x56, 13);
            this.lblDNDuration.TabIndex = 0x3b;
            this.lblDNDuration.Text = "Valid for x Month";
            this.lblDN.AutoSize = true;
            this.lblDN.Location = new Point(0x25d, 0x173);
            this.lblDN.Name = "lblDN";
            this.lblDN.Size = new Size(0x47, 13);
            this.lblDN.TabIndex = 0x68;
            this.lblDN.Text = "Delivery Note";
            this.lblDNMaintainInfo.AutoSize = true;
            this.lblDNMaintainInfo.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.lblDNMaintainInfo.ForeColor = Color.Crimson;
            this.lblDNMaintainInfo.Location = new Point(0x22, 30);
            this.lblDNMaintainInfo.Name = "lblDNMaintainInfo";
            this.lblDNMaintainInfo.Size = new Size(0x9c, 0x10);
            this.lblDNMaintainInfo.TabIndex = 0x6a;
            this.lblDNMaintainInfo.Text = "Please Maintain Data";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x328, 0x216);
            base.ControlBox = false;
            base.Controls.Add(this.panel7);
            base.Controls.Add(this.lblDN);
            base.Controls.Add(this.panel6);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.panel5);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.panel4);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.statusStrip1);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.label98);
            base.Controls.Add(this.panel19);
            base.Controls.Add(this.panel3);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.panel2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.cmbBoxWBOwner);
            base.Controls.Add(this.butCancel);
            base.Controls.Add(this.butSave);
            base.Name = "FormDeepSetting";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "WB Control";
            base.Load += new EventHandler(this.FormDeepSetting_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormDeepSetting_KeyPress);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.pCheckTanker.ResumeLayout(false);
            this.pCheckTanker.PerformLayout();
            this.panelCheckZero.ResumeLayout(false);
            this.panelCheckZero.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.numeric_VesselLimitTolerance.EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.numericDNDuration.EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void radioBeginsAt_CheckedChanged(object sender, EventArgs e)
        {
            this.textBeginAt.Enabled = this.radioBeginsAt.Checked;
        }

        private void radioTimeDefault_CheckedChanged(object sender, EventArgs e)
        {
            this.textBeginAt.Enabled = !this.radioTimeDefault.Checked;
        }

        private void rbTankerKG_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rbTankerKG.Checked)
            {
                this.tTankerTolKG.Enabled = true;
            }
            else
            {
                this.tTankerTolKG.Text = "";
                this.tTankerTolKG.Enabled = false;
            }
        }

        private void rbTankerPersen_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rbTankerPersen.Checked)
            {
                this.tTankerTolPersen.Enabled = true;
                this.tTankerTolKG.Enabled = false;
                this.tTankerTolKG.Text = "0";
            }
            else
            {
                this.tTankerTolKG.Enabled = true;
                this.tTankerTolPersen.Text = "0";
                this.tTankerTolPersen.Enabled = false;
            }
        }

        public void SettToLog(string pUniq, DataTable tmpTrans, string rst)
        {
            WBTable table = new WBTable();
            this.result = rst;
            if (pUniq.Trim() != "")
            {
                table.OpenTable("wb_location", "Select * From wb_location where Uniq=" + pUniq.Trim(), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_loc_log", "Select * From wb_loc_log where 1=2", WBData.conn);
                    table3.DR = table3.DT.NewRow();
                    foreach (DataColumn column in table3.DT.Columns)
                    {
                        try
                        {
                            if (((column.ColumnName.ToUpper() != "UNIQ") && (column.ColumnName.ToUpper() != "LOG_DATE".ToUpper())) && (column.ColumnName.ToUpper() != "LOG_TIME".ToUpper()))
                            {
                                table3.DR[column.ColumnName] = table.DT.Rows[0][column.ColumnName];
                            }
                        }
                        catch
                        {
                        }
                    }
                    table3.DR["change_By"] = WBUser.UserID;
                    table3.DR["change_Date"] = DateTime.Now;
                    table3.DR["log_Date"] = DateTime.Now.Date;
                    table3.DR["log_time"] = DateTime.Now.ToString("HH:mm");
                    table3.DT.Rows.Add(table3.DR);
                    table3.Save();
                    table3.Dispose();
                }
            }
            else
            {
                return;
            }
            table.Dispose();
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_email_master", "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND ( Email_Code ='WB_CONTROL')"), WBData.conn);
            if (table2.DT.Rows.Count <= 0)
            {
                MessageBox.Show("Please Maintain Email Master for WB Control", "WARNING");
            }
            else
            {
                DataRow row = table2.DT.Rows[0];
                WBMail mail = new WBMail();
                string str = "";
                string[] textArray1 = new string[] { row[0].ToString().Trim(), " ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
                mail.Subject = string.Concat(textArray1);
                mail.To = row[1].ToString().Trim();
                mail.CC = row[2].ToString().Trim();
                string[] textArray2 = new string[] { ("Dear All, <br><br>This email is to notify you that the following setting has been edited :<table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.sLocName, "</tr><tr class='bd'><td nowrap>Date & Time</td><td nowrap> : ", DateTime.Now.ToShortDateString(), " ", DateTime.Now.ToString("HH:mm:ss") };
                string[] textArray3 = new string[] { string.Concat(textArray2) + "</tr><tr class='bd'><td nowrap>Change Reason</td><td nowrap> : " + this.result, "</tr><tr class='bd'><td nowrap>WB User</td><td nowrap> : ", WBUser.UserGroup.Trim(), " ( ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " ) " };
                str = (string.Concat(textArray3) + "</tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : " + WBData.sWBCode) + "</tr></table>";
                str = !this.editWarning(tmpTrans) ? (str + "<br><br>~NO Changes on Data~               ") : (str + ("<br><br>~Changes on Data~               <table border=1 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Field</td><td nowrap>Before Edit</td><td nowrap>After Edit</td></tr>" + this.editTrace) + "</tr></table>");
                mail.Body = str + "<br><br><br>Thank you.";
                mail.SendMail();
            }
        }

        private void tTankerTolKG_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.tTankerTolKG);
        }

        private void tTankerTolPersen_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.tTankerTolPersen);
        }
    }
}

