﻿namespace WindowsFormsApplication1
{
    using CrystalDecisions.CrystalReports.Engine;
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormConsignmentAfrica : Form
    {
        public string pRef = "";
        public string pUniq = "";
        public int nCurrRow;
        public string sUniq = "";
        private string pCLMode = "";
        private string pQCMode = "";
        private string lkey = "";
        private string[] logKey;
        private DataRow commRow;
        private DataRow gdRow;
        private DataRow qcRow;
        public DataGridView dgTrans;
        private WBTable tbl_transCL = new WBTable();
        private WBTable tbl_transConLab = new WBTable();
        public WBTable tblTrans = new WBTable();
        public WBTable tblComm = new WBTable();
        private WBTable tbl_commD = new WBTable();
        private WBTable tbl_transQC = new WBTable();
        private WBTable tbl_yield = new WBTable();
        private IContainer components = null;
        private Panel panelBawah;
        private Panel panelTengah;
        private TabControl tabControlQuality;
        private TabPage tabPageConsigment;
        private TabPage tabPageLab;
        private TabPage tabPageComposite;
        private Label labelConDips1;
        private Label labelConComp5;
        private Label labelConComp4;
        private Label labelConComp3;
        private Label labelConComp2;
        private Label labelConComp1;
        private Label labelConCode;
        private Label labelConDips2;
        private Label labelConDiff;
        private Label label8;
        private Label labelSpannerJack;
        private Label labelDiesel;
        private Label labelWheel;
        private Label labelWater;
        private Label labelConCheckBy;
        private CheckBox checkConPaper;
        private Label labelConRemark;
        private Button buttonConSave;
        private TextBox textMSADips1;
        private TextBox textConCode5;
        private TextBox textConCode4;
        private TextBox textConCode3;
        private TextBox textConCode2;
        private TextBox textConCode1;
        private TextBox textConSpanner;
        private TextBox textConDiesel;
        private TextBox textConWheel;
        private TextBox textConWater;
        private TextBox textDips5;
        private TextBox textDips4;
        private TextBox textDips3;
        private TextBox textDips2;
        private TextBox textDips1;
        private TextBox textMSADips5;
        private TextBox textMSADips4;
        private TextBox textMSADips3;
        private TextBox textMSADips2;
        private TextBox textConCheckBy;
        private TextBox textConRemark;
        private TextBox textConAllSeal;
        private ShapeContainer shapeContainer1;
        private RectangleShape rectangleShape1;
        private RectangleShape rectangleShape7;
        private LineShape lineShape9;
        private LineShape lineShape8;
        private LineShape lineShape7;
        private LineShape lineShape6;
        private LineShape lineShape5;
        private LineShape lineShape4;
        private LineShape lineShape3;
        private LineShape lineShape2;
        private LineShape lineShape1;
        private LineShape lineShape10;
        private LineShape lineShape11;
        private LineShape lineShape14;
        private LineShape lineShape13;
        private LineShape lineShape12;
        private TextBox textConDiff1;
        private TextBox textConDiff2;
        private TextBox textConDiff3;
        private TextBox textConDiff4;
        private TextBox textConDiff5;
        private TextBox textConTotalDiff;
        private TextBox textTotalDips;
        private TextBox textTotalMSADips;
        private Button buttonPrint;
        private TabControl tabLab;
        private TabPage tabPageCPO;
        private TabPage tabPageOther;
        private CheckBox checkAllSeal;
        private TabPage tabPagePK;
        private Label labelBSam;
        private Label labelTSam;
        private Label labelSpek;
        private Label labelParam;
        private TextBox textTFFA;
        private TextBox textTIV;
        private TextBox textTColour;
        private TextBox textTDobi;
        private TextBox textTSP;
        private TextBox textTMI;
        private TextBox textBIV;
        private TextBox textBColour;
        private TextBox textBDobi;
        private TextBox textBSP;
        private TextBox textBMI;
        private TextBox textBFFA;
        private Button buttonSaveLab;
        private Label labelDocStatusLab;
        private Label labelSampeLab;
        private Label labelRemarkLab;
        private Label labelApprovedLab;
        private Label labelSmplLab;
        private ComboBox comboDocStatuslab;
        private TextBox textCheckedByLab;
        private TextBox textRemarkLab;
        private TextBox textApprovedByLab;
        private TextBox textSampleByLab;
        private TextBox textBSpatOth;
        private TextBox textBCSOth;
        private TextBox textBIVOth;
        private TextBox textBPVOth;
        private TextBox textBColourOth;
        private TextBox textBFFAOth;
        private TextBox textTSpatOth;
        private TextBox textTCSOth;
        private TextBox textTIVOth;
        private TextBox textTPVOth;
        private TextBox textTColourOth;
        private TextBox textTFFAOth;
        private Label labelBOth;
        private Label labelTOth;
        private Label labelParamOth;
        private TextBox textBIVPK;
        private TextBox textBColourPK;
        private TextBox textBDobiPK;
        private TextBox textBDSPK;
        private TextBox textBMIPK;
        private TextBox textBFFAPK;
        private TextBox textTIVPK;
        private TextBox textTColourPK;
        private TextBox textTDobiPK;
        private TextBox textTDSPK;
        private TextBox textTMIPK;
        private TextBox textTFFAPK;
        private Label labelBPK;
        private Label labelTPK;
        private Label labelSpecPK;
        private Label label4;
        private Label label5;
        private Label label3;
        private Label label2;
        private Label label7;
        private Label label6;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label31;
        private Label label32;
        private Label label33;
        private Label label34;
        private Label label35;
        private Label label1;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label23;
        private Label label24;
        private Label label25;
        private Label label28;
        private Label label26;
        private Label label27;
        private Panel panel1;
        private Button buttonSaveComposite;
        private DataGridView dgComposite;
        private Button buttonConClose;
        private Label labelVehicleNo;
        private Label labelMaterial;
        private Label labelShip;
        private Label labelLoadingDate;
        private TextBox textVehicle;
        private TextBox textCommName;
        private TextBox textShip;
        private DateTimePicker dtLoadDate;
        private Panel panelAtas;
        private Button buttonPrintPK;

        public FormConsignmentAfrica()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonConClose_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonConSave_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            if (this.pCLMode == "ADD")
            {
                this.tbl_transCL.DR = this.tbl_transCL.DT.NewRow();
            }
            else if (this.pCLMode == "EDIT")
            {
                this.tbl_transCL.ReOpen();
                string[] aField = new string[] { "ref" };
                string[] aFind = new string[] { this.pRef };
                this.tbl_transCL.DR = this.tbl_transCL.GetData(aField, aFind);
                this.lkey = this.tbl_transCL.DR["uniq"].ToString();
                this.tbl_transCL.DR.BeginEdit();
            }
            this.tbl_transCL.DR["Coy"] = WBData.sCoyCode;
            this.tbl_transCL.DR["Location_Code"] = WBData.sLocCode;
            this.tbl_transCL.DR["ref"] = this.pRef;
            this.tbl_transCL.DR["Load_date"] = this.dtLoadDate.Value;
            this.tbl_transCL.DR["ship"] = this.textShip.Text;
            this.tbl_transCL.DR["code1"] = this.textConCode1.Text;
            this.tbl_transCL.DR["Comp1_SV"] = this.textMSADips1.Text;
            this.tbl_transCL.DR["Comp1_FC"] = this.textDips1.Text;
            this.tbl_transCL.DR["Comp1_Dif"] = this.textConDiff1.Text;
            this.tbl_transCL.DR["code2"] = this.textConCode2.Text;
            this.tbl_transCL.DR["Comp2_SV"] = this.textMSADips2.Text;
            this.tbl_transCL.DR["Comp2_FC"] = this.textDips2.Text;
            this.tbl_transCL.DR["Comp2_Dif"] = this.textConDiff2.Text;
            this.tbl_transCL.DR["code3"] = this.textConCode3.Text;
            this.tbl_transCL.DR["Comp3_SV"] = this.textMSADips3.Text;
            this.tbl_transCL.DR["Comp3_FC"] = this.textDips3.Text;
            this.tbl_transCL.DR["Comp3_Dif"] = this.textConDiff3.Text;
            this.tbl_transCL.DR["code4"] = this.textConCode4.Text;
            this.tbl_transCL.DR["Comp4_SV"] = this.textMSADips4.Text;
            this.tbl_transCL.DR["Comp4_FC"] = this.textDips4.Text;
            this.tbl_transCL.DR["Comp4_Dif"] = this.textConDiff4.Text;
            this.tbl_transCL.DR["code5"] = this.textConCode5.Text;
            this.tbl_transCL.DR["Comp5_SV"] = this.textMSADips5.Text;
            this.tbl_transCL.DR["Comp5_FC"] = this.textDips5.Text;
            this.tbl_transCL.DR["Comp5_Dif"] = this.textConDiff5.Text;
            this.tbl_transCL.DR["Water"] = this.textConWater.Text;
            this.tbl_transCL.DR["Diesel"] = this.textConDiesel.Text;
            this.tbl_transCL.DR["Wheel"] = this.textConWheel.Text;
            this.tbl_transCL.DR["Spanner"] = this.textConSpanner.Text;
            this.tbl_transCL.DR["Check_by"] = this.textConCheckBy.Text;
            this.tbl_transCL.DR["Cons_paper_chk"] = this.checkConPaper.Checked ? "Y" : "N";
            this.tbl_transCL.DR["Seal_chk"] = this.checkAllSeal.Checked ? "Y" : "N";
            this.tbl_transCL.DR["Sealchk"] = this.textConAllSeal.Text;
            this.tbl_transCL.DR["Remark"] = this.textConRemark.Text;
            if (this.pCLMode == "ADD")
            {
                this.tbl_transCL.DT.Rows.Add(this.tbl_transCL.DR);
            }
            else if (this.pCLMode == "EDIT")
            {
                this.tbl_transCL.DR.EndEdit();
            }
            this.tbl_transCL.Save();
            if ((this.pCLMode == "ADD") || (this.pCLMode == "EDIT"))
            {
                if (this.pCLMode == "ADD")
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_transactionCL", "SELECT * FROM wb_transactionCL WHERE " + WBData.CompanyLocation(""), WBData.conn);
                    string[] aField = new string[] { "ref" };
                    string[] aFind = new string[] { this.pRef };
                    DataRow data = table.GetData(aField, aFind);
                    this.lkey = data["uniq"].ToString();
                    table.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pCLMode, WBUser.UserID, "Entry Consignment" };
                Program.updateLogHeader("wb_transactionCL", this.lkey, logField, logValue);
            }
            Cursor.Current = Cursors.Default;
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            this.buttonConSave.PerformClick();
            this.buttonSaveComposite.PerformClick();
            this.buttonSaveLab.PerformClick();
            this.printConLab(this.pRef);
        }

        private void buttonPrintPK_Click(object sender, EventArgs e)
        {
            this.buttonSaveLab.PerformClick();
            this.printConPK(this.pRef);
        }

        private void buttonSaveComposite_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            if (this.dgComposite.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in (IEnumerable) this.dgComposite.Rows)
                {
                    string[] aField = new string[] { "uniq" };
                    string[] aFind = new string[] { row.Cells["uniq"].Value.ToString() };
                    this.tbl_transQC.DR = this.tbl_transQC.GetData(aField, aFind);
                    this.lkey = this.tbl_transQC.DR["uniq"].ToString();
                    this.tbl_transQC.DR.BeginEdit();
                    foreach (DataGridViewColumn column in this.dgComposite.Columns)
                    {
                        bool flag2 = column.Name.Trim().ToUpper() != "UNIQ";
                        if (flag2 && ((row.Cells[column.Name.Trim()].Value != null) && (row.Cells[column.Name.Trim()].Value.ToString().Trim() != "")))
                        {
                            this.tbl_transQC.DR[column.Name.Trim()] = row.Cells[column.Name.Trim()].Value.ToString().Trim();
                        }
                    }
                    this.tbl_transQC.DR.EndEdit();
                    this.tbl_transQC.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Entry Consignment" };
                    Program.updateLogHeader("wb_transQC", this.lkey, logField, logValue);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void buttonSaveLab_Click(object sender, EventArgs e)
        {
            if ((this.comboDocStatuslab.Text == "APPROVE BY CFO/FM") && !WBUser.CheckTrustee("MNCFO", "A"))
            {
                MessageBox.Show(Resource.Mes_054, Resource.Title_002);
            }
            else
            {
                string[] aField = new string[] { "ref" };
                string[] aFind = new string[] { this.pRef };
                this.tbl_transConLab.DR = this.tbl_transConLab.GetData(aField, aFind);
                this.pQCMode = !ReferenceEquals(this.tbl_transConLab.DR, null) ? "EDIT" : "ADD";
                Cursor.Current = Cursors.WaitCursor;
                if (this.pQCMode == "ADD")
                {
                    this.tbl_transConLab.DR = this.tbl_transConLab.DT.NewRow();
                }
                else if (this.pQCMode == "EDIT")
                {
                    this.lkey = this.tbl_transConLab.DR["uniq"].ToString();
                    this.tbl_transConLab.DR.BeginEdit();
                }
                this.tbl_transConLab.DR["Coy"] = WBData.sCoyCode;
                this.tbl_transConLab.DR["Location_code"] = WBData.sLocCode;
                this.tbl_transConLab.DR["ref"] = this.pRef;
                this.tbl_transConLab.DR["Top_FFA"] = (this.textTFFA.Text.Trim() == "") ? this.textTFFAOth.Text : this.textTFFA.Text;
                this.tbl_transConLab.DR["Top_MI"] = this.textTMI.Text;
                this.tbl_transConLab.DR["Top_SLIP"] = this.textTSP.Text;
                this.tbl_transConLab.DR["Top_DOBI"] = this.textTDobi.Text;
                this.tbl_transConLab.DR["Top_Colour"] = this.textTColour.Text;
                this.tbl_transConLab.DR["Top_Iodine"] = (this.textTIV.Text.Trim() == "") ? this.textTIVOth.Text : this.textTIV.Text;
                this.tbl_transConLab.DR["Top_Colour54"] = this.textTColourOth.Text;
                this.tbl_transConLab.DR["Top_Peroxide"] = this.textTPVOth.Text;
                this.tbl_transConLab.DR["Top_Cold"] = this.textTCSOth.Text;
                this.tbl_transConLab.DR["Top_Spatter"] = this.textTSpatOth.Text;
                this.tbl_transConLab.DR["Bottom_FFA"] = (this.textBFFA.Text.Trim() == "") ? this.textBFFAOth.Text : this.textBFFA.Text;
                this.tbl_transConLab.DR["Bottom_MI"] = this.textBMI.Text;
                this.tbl_transConLab.DR["Bottom_SLIP"] = this.textBSP.Text;
                this.tbl_transConLab.DR["Bottom_DOBI"] = this.textBDobi.Text;
                this.tbl_transConLab.DR["Bottom_Colour"] = this.textBColour.Text;
                this.tbl_transConLab.DR["Bottom_Iodine"] = (this.textBIV.Text.Trim() == "") ? this.textBIVOth.Text : this.textBIV.Text;
                this.tbl_transConLab.DR["Bottom_Colour54"] = this.textBColourOth.Text;
                this.tbl_transConLab.DR["Bottom_Peroxide"] = this.textBPVOth.Text;
                this.tbl_transConLab.DR["Bottom_Cold"] = this.textBCSOth.Text;
                this.tbl_transConLab.DR["Bottom_Spatter"] = this.textBSpatOth.Text;
                this.tbl_transConLab.DR["Sample_take"] = this.textSampleByLab.Text;
                this.tbl_transConLab.DR["Sample_check"] = this.textCheckedByLab.Text;
                this.tbl_transConLab.DR["Approve_by"] = this.textApprovedByLab.Text;
                this.tbl_transConLab.DR["Status"] = this.comboDocStatuslab.SelectedIndex;
                this.tbl_transConLab.DR["Remark"] = this.labelRemarkLab.Text;
                this.tbl_transConLab.DR["Top_PKffa"] = this.textTFFAPK.Text;
                this.tbl_transConLab.DR["Bottom_PKffa"] = this.textBFFAPK.Text;
                this.tbl_transConLab.DR["Top_PKMI"] = this.textTMIPK.Text;
                this.tbl_transConLab.DR["Bottom_PKMI"] = this.textBMIPK.Text;
                this.tbl_transConLab.DR["Top_PKdirt"] = this.textTDSPK.Text;
                this.tbl_transConLab.DR["Bottom_PKdirt"] = this.textBDSPK.Text;
                this.tbl_transConLab.DR["Top_PKDOBI"] = this.textTDobiPK.Text;
                this.tbl_transConLab.DR["Bottom_PKDOBI"] = this.textBDobiPK.Text;
                this.tbl_transConLab.DR["Top_PKCol"] = this.textTColourPK.Text;
                this.tbl_transConLab.DR["Bottom_PKCol"] = this.textBColourPK.Text;
                this.tbl_transConLab.DR["Top_PKIon"] = this.textTIVPK.Text;
                this.tbl_transConLab.DR["Bottom_PKIon"] = this.textBIVPK.Text;
                if (this.pQCMode == "ADD")
                {
                    this.tbl_transConLab.DT.Rows.Add(this.tbl_transConLab.DR);
                }
                else if (this.pQCMode == "EDIT")
                {
                    this.tbl_transConLab.DR.EndEdit();
                }
                this.tbl_transConLab.Save();
                if ((this.pCLMode == "ADD") || (this.pCLMode == "EDIT"))
                {
                    if (this.pCLMode == "ADD")
                    {
                        WBTable table2 = new WBTable();
                        table2.OpenTable("wb_transQC_CL", "SELECT * FROM wb_transQC_CL WHERE " + WBData.CompanyLocation(""), WBData.conn);
                        string[] textArray3 = new string[] { "ref" };
                        string[] textArray4 = new string[] { this.pRef };
                        DataRow data = table2.GetData(textArray3, textArray4);
                        this.lkey = data["uniq"].ToString();
                        table2.Dispose();
                    }
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { this.pCLMode, WBUser.UserID, "Entry Consignment" };
                    Program.updateLogHeader("wb_transQC_CL", this.lkey, logField, logValue);
                }
                WBTable table = new WBTable();
                table.OpenTable("wb_trans", "select " + WBTable.cFieldTransAfrica + " from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + this.pRef + "'"), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    table.DR = table.DT.Rows[0];
                    this.lkey = table.DR["uniq"].ToString();
                    table.DR.BeginEdit();
                    table.DR["QCStatus"] = (this.comboDocStatuslab.SelectedIndex == 0) ? "PASS" : ((this.comboDocStatuslab.SelectedIndex == 1) ? "FAIL" : "APPROVE BY CFO/FM");
                    table.DR["checksum"] = table.Checksum(table.DR);
                    table.DR.EndEdit();
                    table.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Entry Consignment" };
                    Program.updateLogHeader("wb_transaction", this.lkey, logField, logValue);
                }
                table.Dispose();
                if (WBSetting.Field("Check_Email").Trim() == "Y")
                {
                    string[] textArray9 = new string[] { ("Dear All,<br><br>This email is to notify you that the following truck QUALITY is FAIL :<table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name"), "</tr><tr class='bd'><td nowrap>Date & Time</td><td nowrap> : ", DateTime.Now.ToShortDateString(), " ", DateTime.Now.ToString("HH:mm:ss") };
                    string[] textArray10 = new string[] { string.Concat(textArray9) + "</tr><tr class='bd'><td nowrap>Truck Number</td><td nowrap> : " + this.textVehicle.Text, "</tr><tr class='bd'><td nowrap>User ID</td><td nowrap> : ", WBUser.UserGroup.Trim(), " ( ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " ) " };
                    string str = (string.Concat(textArray10) + "</tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : " + WBData.sWBCode) + "</tr></table>" + "<br>Thank you.";
                    WBMail mail = new WBMail();
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_email_master", "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND ( Email_Code ='QUALITYFAIL')"), WBData.conn);
                    int num = 0;
                    while (true)
                    {
                        if (num >= table3.DT.Rows.Count)
                        {
                            mail.SendMail();
                            mail.Dispose();
                            table3.Dispose();
                            break;
                        }
                        DataRow row2 = table3.DT.Rows[num];
                        string[] textArray11 = new string[] { row2[0].ToString().Trim(), " ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
                        mail.Subject = string.Concat(textArray11);
                        mail.To = row2[1].ToString().Trim();
                        mail.CC = row2[2].ToString().Trim();
                        num++;
                    }
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void dgComposite_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            string[] aField = new string[] { "Yield_Code" };
            string[] aFind = new string[] { this.dgComposite.Rows[this.dgComposite.CurrentCell.RowIndex].Cells["Qcode"].Value.ToString() };
            if (this.tbl_yield.GetData(aField, aFind)["Type"].ToString() != "1")
            {
                if (this.dgComposite.CurrentCell.Value.ToString().Length > 10)
                {
                    MessageBox.Show(Resource.Mes_051, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            else
            {
                try
                {
                    if (((float) Convert.ToDouble(this.dgComposite.CurrentCell.Value.ToString())) <= 99.999)
                    {
                        this.dgComposite.CurrentCell.Value = Convert.ToString(Program.StrToDouble(this.dgComposite.CurrentCell.Value.ToString(), 3));
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_053, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.dgComposite.CurrentCell.Value = "0";
                    }
                }
                catch
                {
                    MessageBox.Show(Resource.Mes_018, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.dgComposite.CurrentCell.Value = "0";
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormConsignment_Load(object sender, EventArgs e)
        {
            this.translate();
            if (WBUser.CheckTrustee("MNLAB", "A") || WBUser.CheckTrustee("MNCFO", "A"))
            {
                this.buttonSaveLab.Enabled = true;
                this.comboDocStatuslab.Enabled = true;
            }
            else
            {
                this.buttonSaveLab.Enabled = false;
                this.comboDocStatuslab.Enabled = false;
            }
            this.tabControlQuality.TabPages.Remove(this.tabPageConsigment);
            this.tabControlQuality.TabPages.Remove(this.tabPageLab);
            this.tabControlQuality.TabPages.Remove(this.tabPageComposite);
            if (!((WBUser.CheckTrustee("MNLAB", "V") || WBUser.CheckTrustee("MNLAB", "A")) || WBUser.CheckTrustee("MNLAB", "E")))
            {
                this.buttonSaveLab.Enabled = false;
                this.buttonSaveComposite.Enabled = false;
                this.buttonPrint.Enabled = false;
            }
            else
            {
                this.tabControlQuality.TabPages.Add(this.tabPageConsigment);
                this.tabControlQuality.TabPages.Add(this.tabPageLab);
                this.tabControlQuality.TabPages.Add(this.tabPageComposite);
                this.buttonSaveLab.Enabled = true;
                this.buttonSaveComposite.Enabled = true;
                this.buttonPrint.Enabled = true;
            }
            this.tabControlQuality.TabPages.Remove(this.tabPageConsigment);
            if (!((WBUser.CheckTrustee("MNCIR", "V") || WBUser.CheckTrustee("MNCIR", "A")) || WBUser.CheckTrustee("MNCIR", "E")))
            {
                this.buttonPrint.Enabled = false;
                this.buttonConSave.Enabled = false;
            }
            else
            {
                this.tabControlQuality.TabPages.Add(this.tabPageConsigment);
                this.buttonPrint.Enabled = true;
                this.buttonConSave.Enabled = true;
            }
            this.Text = "Entry Consignment Lab For Ref " + this.dgTrans.CurrentRow.Cells["Ref"].Value.ToString();
            this.pRef = this.dgTrans.CurrentRow.Cells["Ref"].Value.ToString();
            this.textVehicle.Text = this.dgTrans.CurrentRow.Cells["Truck_Number"].Value.ToString();
            this.tblComm.OpenTable("wb_comm", "select * from wb_commodity where comm_code ='" + this.dgTrans.CurrentRow.Cells["Comm_code"].Value.ToString() + "'", WBData.conn);
            if (this.tblComm.DT.Rows.Count > 0)
            {
                this.commRow = this.tblComm.DT.Rows[0];
                this.textCommName.Text = this.commRow["Comm_Name"].ToString();
            }
            this.tbl_yield.OpenTable("wb_yield", "Select * from wb_yield", WBData.conn);
            this.tbl_commD.OpenTable("wb_commD", "Select * from wb_commodity_Detail where " + WBData.CompanyLocation(" and comm_code = '" + this.dgTrans.CurrentRow.Cells["Comm_code"].Value.ToString() + "'"), WBData.conn);
            this.tbl_transQC.OpenTable("wb_transQC", "select * from wb_transQC where " + WBData.CompanyLocation(" and Ref = '" + this.pRef + "'"), WBData.conn);
            this.dgComposite.DataSource = this.tbl_transQC.DT;
            int index = 0;
            if (this.tbl_transQC.DT.Rows.Count == 0)
            {
                this.logKey = new string[this.tbl_commD.DT.Rows.Count];
                bool flag6 = false;
                foreach (DataRow row in this.tbl_commD.DT.Rows)
                {
                    string[] aField = new string[] { "QCODE" };
                    string[] aFind = new string[] { row["qCode"].ToString() };
                    this.gdRow = this.tbl_transQC.GetData(aField, aFind);
                    if (ReferenceEquals(this.gdRow, null))
                    {
                        this.tbl_transQC.DR = this.tbl_transQC.DT.NewRow();
                        this.tbl_transQC.DR["Coy"] = WBData.sCoyCode;
                        this.tbl_transQC.DR["Ref"] = this.pRef;
                        this.tbl_transQC.DR["Location_code"] = WBData.sLocCode;
                        this.tbl_transQC.DR["Qcode"] = row["QCode"].ToString();
                        this.tbl_transQC.DR["QName"] = row["QName"].ToString();
                        string[] textArray3 = new string[] { "Yield_Code" };
                        string[] textArray4 = new string[] { row["QCode"].ToString() };
                        this.qcRow = this.tbl_yield.GetData(textArray3, textArray4);
                        if (this.qcRow != null)
                        {
                            if (this.qcRow["type"].ToString() == "1")
                            {
                                this.tbl_transQC.DR["Estate"] = "0";
                                this.tbl_transQC.DR["Factory"] = "0";
                            }
                            else
                            {
                                this.tbl_transQC.DR["Estate"] = "";
                                this.tbl_transQC.DR["Factory"] = "";
                            }
                        }
                        this.tbl_transQC.DR["comm_code"] = this.dgTrans.CurrentRow.Cells["Comm_code"].Value.ToString();
                        this.tbl_transQC.DT.Rows.Add(this.tbl_transQC.DR);
                        this.tbl_transQC.Save();
                        flag6 = true;
                        WBTable table = new WBTable();
                        table.OpenTable("wb_transQC", "SELECT * FROM wb_transQC WHERE " + WBData.CompanyLocation(""), WBData.conn);
                        string[] textArray5 = new string[] { "ref", "Qcode" };
                        string[] textArray6 = new string[] { this.pRef, row["QCode"].ToString() };
                        this.logKey[index] = table.GetData(textArray5, textArray6)["uniq"].ToString();
                        table.Dispose();
                        index++;
                    }
                }
                if (flag6)
                {
                    index = 0;
                    while (true)
                    {
                        if (index >= this.logKey.Length)
                        {
                            this.tbl_transQC.ReOpen();
                            this.dgComposite.DataSource = this.tbl_transQC.DT;
                            break;
                        }
                        if ((this.logKey[index] != "") || ReferenceEquals(this.logKey[index], null))
                        {
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "ADD", WBUser.UserID, "Entry Consignment" };
                            Program.updateLogHeader("wb_transQC", this.logKey[index], logField, logValue);
                        }
                        index++;
                    }
                }
            }
            foreach (DataGridViewColumn column in this.dgComposite.Columns)
            {
                column.Visible = false;
            }
            this.dgComposite.Columns["Qcode"].Visible = true;
            this.dgComposite.Columns["Qcode"].HeaderText = "Quality Code";
            this.dgComposite.Columns["QName"].Visible = true;
            this.dgComposite.Columns["QName"].HeaderText = "Quality Name";
            this.dgComposite.Columns["Estate"].Visible = true;
            this.dgComposite.Columns["Estate"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.dgComposite.Columns["Factory"].Visible = true;
            this.dgComposite.Columns["Factory"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            this.tbl_transCL.OpenTable("wb_transCL", " Select * from wb_transactionCL where " + WBData.CompanyLocation(" and ref = '" + this.pRef + "'"), WBData.conn);
            if (this.tbl_transCL.DT.Rows.Count <= 0)
            {
                this.pCLMode = "ADD";
            }
            else
            {
                this.pCLMode = "EDIT";
                this.tbl_transCL.DR = this.tbl_transCL.DT.Rows[0];
                this.dtLoadDate.Value = Convert.ToDateTime(this.tbl_transCL.DR["Load_date"].ToString());
                this.textShip.Text = this.tbl_transCL.DR["ship"].ToString();
                this.textConCode1.Text = this.tbl_transCL.DR["code1"].ToString();
                this.textMSADips1.Text = this.tbl_transCL.DR["Comp1_SV"].ToString();
                this.textDips1.Text = this.tbl_transCL.DR["Comp1_FC"].ToString();
                this.textConCode2.Text = this.tbl_transCL.DR["code2"].ToString();
                this.textMSADips2.Text = this.tbl_transCL.DR["Comp2_SV"].ToString();
                this.textDips2.Text = this.tbl_transCL.DR["Comp2_FC"].ToString();
                this.textConCode3.Text = this.tbl_transCL.DR["code3"].ToString();
                this.textMSADips3.Text = this.tbl_transCL.DR["Comp3_SV"].ToString();
                this.textDips3.Text = this.tbl_transCL.DR["Comp3_FC"].ToString();
                this.textConCode4.Text = this.tbl_transCL.DR["code4"].ToString();
                this.textMSADips4.Text = this.tbl_transCL.DR["Comp4_SV"].ToString();
                this.textDips4.Text = this.tbl_transCL.DR["Comp4_FC"].ToString();
                this.textConCode5.Text = this.tbl_transCL.DR["code5"].ToString();
                this.textMSADips5.Text = this.tbl_transCL.DR["Comp5_SV"].ToString();
                this.textDips5.Text = this.tbl_transCL.DR["Comp5_FC"].ToString();
                this.textConWater.Text = this.tbl_transCL.DR["Water"].ToString();
                this.textConDiesel.Text = this.tbl_transCL.DR["Diesel"].ToString();
                this.textConWheel.Text = this.tbl_transCL.DR["Wheel"].ToString();
                this.textConSpanner.Text = this.tbl_transCL.DR["Spanner"].ToString();
                this.textConCheckBy.Text = this.tbl_transCL.DR["Check_by"].ToString();
                this.checkConPaper.Checked = this.tbl_transCL.DR["Cons_paper_chk"].ToString() == "Y";
                this.checkAllSeal.Checked = this.tbl_transCL.DR["Seal_chk"].ToString() == "Y";
                this.textConAllSeal.Text = this.tbl_transCL.DR["Sealchk"].ToString();
                this.textConRemark.Text = this.tbl_transCL.DR["Remark"].ToString();
                this.HitCon();
            }
            this.comboDocStatuslab.Items.Clear();
            this.comboDocStatuslab.Items.Add("PASS");
            this.comboDocStatuslab.Items.Add("FAIL");
            this.comboDocStatuslab.Items.Add("APPROVE BY CFO/FM");
            this.comboDocStatuslab.Text = "";
            this.tbl_transConLab.OpenTable("wb_transQC", " Select * from wb_transQC_CL where " + WBData.CompanyLocation(" and ref = '" + this.pRef + "'"), WBData.conn);
            if (this.tbl_transConLab.DT.Rows.Count <= 0)
            {
                this.pQCMode = "ADD";
            }
            else
            {
                this.pQCMode = "EDIT";
                this.tbl_transConLab.DR = this.tbl_transConLab.DT.Rows[0];
                this.textTFFA.Text = this.tbl_transConLab.DR["Top_FFA"].ToString();
                this.textBFFA.Text = this.tbl_transConLab.DR["Bottom_FFA"].ToString();
                this.textTMI.Text = this.tbl_transConLab.DR["Top_MI"].ToString();
                this.textBMI.Text = this.tbl_transConLab.DR["Bottom_MI"].ToString();
                this.textTSP.Text = this.tbl_transConLab.DR["Top_SLIP"].ToString();
                this.textBSP.Text = this.tbl_transConLab.DR["Bottom_SLIP"].ToString();
                this.textTDobi.Text = this.tbl_transConLab.DR["Top_DOBI"].ToString();
                this.textBDobi.Text = this.tbl_transConLab.DR["Bottom_DOBI"].ToString();
                this.textTColour.Text = this.tbl_transConLab.DR["Top_Colour"].ToString();
                this.textBColour.Text = this.tbl_transConLab.DR["Bottom_Colour"].ToString();
                this.textTIV.Text = this.tbl_transConLab.DR["Top_Iodine"].ToString();
                this.textBIV.Text = this.tbl_transConLab.DR["Bottom_Iodine"].ToString();
                this.textTFFAOth.Text = this.tbl_transConLab.DR["Top_FFA"].ToString();
                this.textBFFAOth.Text = this.tbl_transConLab.DR["Bottom_FFA"].ToString();
                this.textTIVOth.Text = this.tbl_transConLab.DR["Top_Iodine"].ToString();
                this.textBIVOth.Text = this.tbl_transConLab.DR["Bottom_Iodine"].ToString();
                this.textTColourOth.Text = this.tbl_transConLab.DR["Top_Colour54"].ToString();
                this.textBColourOth.Text = this.tbl_transConLab.DR["Bottom_Colour54"].ToString();
                this.textTPVOth.Text = this.tbl_transConLab.DR["Top_Peroxide"].ToString();
                this.textBPVOth.Text = this.tbl_transConLab.DR["Bottom_Peroxide"].ToString();
                this.textTCSOth.Text = this.tbl_transConLab.DR["Top_Cold"].ToString();
                this.textBCSOth.Text = this.tbl_transConLab.DR["Bottom_Cold"].ToString();
                this.textTSpatOth.Text = this.tbl_transConLab.DR["Top_Spatter"].ToString();
                this.textBSpatOth.Text = this.tbl_transConLab.DR["Bottom_Spatter"].ToString();
                this.textSampleByLab.Text = this.tbl_transConLab.DR["Sample_take"].ToString();
                this.textCheckedByLab.Text = this.tbl_transConLab.DR["Sample_check"].ToString();
                this.textApprovedByLab.Text = this.tbl_transConLab.DR["Approve_by"].ToString();
                this.comboDocStatuslab.SelectedIndex = Convert.ToInt16(this.tbl_transConLab.DR["Status"].ToString());
                this.labelRemarkLab.Text = this.tbl_transConLab.DR["Remark"].ToString();
                this.textTFFAPK.Text = this.tbl_transConLab.DR["Top_PKffa"].ToString();
                this.textBFFAPK.Text = this.tbl_transConLab.DR["Bottom_PKffa"].ToString();
                this.textTMIPK.Text = this.tbl_transConLab.DR["Top_PKMI"].ToString();
                this.textBMIPK.Text = this.tbl_transConLab.DR["Bottom_PKMI"].ToString();
                this.textTDSPK.Text = this.tbl_transConLab.DR["Top_PKdirt"].ToString();
                this.textBDSPK.Text = this.tbl_transConLab.DR["Bottom_PKdirt"].ToString();
                this.textTDobiPK.Text = this.tbl_transConLab.DR["Top_PKDOBI"].ToString();
                this.textBDobiPK.Text = this.tbl_transConLab.DR["Bottom_PKDOBI"].ToString();
                this.textTColourPK.Text = this.tbl_transConLab.DR["Top_PKCol"].ToString();
                this.textBColourPK.Text = this.tbl_transConLab.DR["Bottom_PKCol"].ToString();
                this.textTIVPK.Text = this.tbl_transConLab.DR["Top_PKIon"].ToString();
                this.textBIVPK.Text = this.tbl_transConLab.DR["Bottom_PKIon"].ToString();
            }
        }

        private void HitCon()
        {
            if (this.textMSADips1.Text.Trim() == "")
            {
                this.textMSADips1.Text = "0";
            }
            if (this.textMSADips2.Text.Trim() == "")
            {
                this.textMSADips2.Text = "0";
            }
            if (this.textMSADips3.Text.Trim() == "")
            {
                this.textMSADips3.Text = "0";
            }
            if (this.textMSADips4.Text.Trim() == "")
            {
                this.textMSADips4.Text = "0";
            }
            if (this.textMSADips5.Text.Trim() == "")
            {
                this.textMSADips5.Text = "0";
            }
            if (this.textDips1.Text.Trim() == "")
            {
                this.textDips1.Text = "0";
            }
            if (this.textDips2.Text.Trim() == "")
            {
                this.textDips2.Text = "0";
            }
            if (this.textDips3.Text.Trim() == "")
            {
                this.textDips3.Text = "0";
            }
            if (this.textDips4.Text.Trim() == "")
            {
                this.textDips4.Text = "0";
            }
            if (this.textDips5.Text.Trim() == "")
            {
                this.textDips5.Text = "0";
            }
            this.textTotalMSADips.Text = ((((Program.StrToDouble(this.textMSADips1.Text, 2) + Program.StrToDouble(this.textMSADips2.Text, 2)) + Program.StrToDouble(this.textMSADips3.Text, 2)) + Program.StrToDouble(this.textMSADips4.Text, 2)) + Program.StrToDouble(this.textMSADips5.Text, 2)).ToString();
            this.textTotalDips.Text = ((((Program.StrToDouble(this.textDips1.Text, 2) + Program.StrToDouble(this.textDips2.Text, 2)) + Program.StrToDouble(this.textDips3.Text, 2)) + Program.StrToDouble(this.textDips4.Text, 2)) + Program.StrToDouble(this.textDips5.Text, 2)).ToString();
            this.textConDiff1.Text = (Program.StrToDouble(this.textDips1.Text, 2) - Program.StrToDouble(this.textMSADips1.Text, 2)).ToString();
            this.textConDiff2.Text = (Program.StrToDouble(this.textDips2.Text, 2) - Program.StrToDouble(this.textMSADips2.Text, 2)).ToString();
            this.textConDiff3.Text = (Program.StrToDouble(this.textDips3.Text, 2) - Program.StrToDouble(this.textMSADips3.Text, 2)).ToString();
            this.textConDiff4.Text = (Program.StrToDouble(this.textDips4.Text, 2) - Program.StrToDouble(this.textMSADips4.Text, 2)).ToString();
            this.textConDiff5.Text = (Program.StrToDouble(this.textDips5.Text, 2) - Program.StrToDouble(this.textMSADips5.Text, 2)).ToString();
            this.textConTotalDiff.Text = ((((Program.StrToDouble(this.textConDiff1.Text, 2) + Program.StrToDouble(this.textConDiff2.Text, 2)) + Program.StrToDouble(this.textConDiff3.Text, 2)) + Program.StrToDouble(this.textConDiff4.Text, 2)) + Program.StrToDouble(this.textConDiff5.Text, 2)).ToString();
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.panelBawah = new Panel();
            this.buttonConClose = new Button();
            this.buttonPrint = new Button();
            this.panelTengah = new Panel();
            this.tabControlQuality = new TabControl();
            this.tabPageConsigment = new TabPage();
            this.checkAllSeal = new CheckBox();
            this.textConDiff1 = new TextBox();
            this.textConDiff2 = new TextBox();
            this.textConDiff3 = new TextBox();
            this.textConDiff4 = new TextBox();
            this.textConDiff5 = new TextBox();
            this.textConTotalDiff = new TextBox();
            this.textTotalDips = new TextBox();
            this.textTotalMSADips = new TextBox();
            this.textConRemark = new TextBox();
            this.textConAllSeal = new TextBox();
            this.textConCheckBy = new TextBox();
            this.textConSpanner = new TextBox();
            this.textConDiesel = new TextBox();
            this.textConWheel = new TextBox();
            this.textConWater = new TextBox();
            this.textDips5 = new TextBox();
            this.textDips4 = new TextBox();
            this.textDips3 = new TextBox();
            this.textDips2 = new TextBox();
            this.textDips1 = new TextBox();
            this.textMSADips5 = new TextBox();
            this.textMSADips4 = new TextBox();
            this.textMSADips3 = new TextBox();
            this.textMSADips2 = new TextBox();
            this.textMSADips1 = new TextBox();
            this.textConCode5 = new TextBox();
            this.textConCode4 = new TextBox();
            this.textConCode3 = new TextBox();
            this.textConCode2 = new TextBox();
            this.textConCode1 = new TextBox();
            this.buttonConSave = new Button();
            this.labelConRemark = new Label();
            this.checkConPaper = new CheckBox();
            this.labelConCheckBy = new Label();
            this.labelWater = new Label();
            this.labelSpannerJack = new Label();
            this.labelDiesel = new Label();
            this.labelWheel = new Label();
            this.label8 = new Label();
            this.labelConDiff = new Label();
            this.labelConDips2 = new Label();
            this.labelConDips1 = new Label();
            this.labelConComp5 = new Label();
            this.labelConComp4 = new Label();
            this.labelConComp3 = new Label();
            this.labelConComp2 = new Label();
            this.labelConComp1 = new Label();
            this.labelConCode = new Label();
            this.shapeContainer1 = new ShapeContainer();
            this.lineShape14 = new LineShape();
            this.lineShape13 = new LineShape();
            this.lineShape12 = new LineShape();
            this.lineShape11 = new LineShape();
            this.lineShape10 = new LineShape();
            this.lineShape9 = new LineShape();
            this.lineShape8 = new LineShape();
            this.lineShape7 = new LineShape();
            this.lineShape6 = new LineShape();
            this.lineShape5 = new LineShape();
            this.lineShape4 = new LineShape();
            this.lineShape3 = new LineShape();
            this.lineShape2 = new LineShape();
            this.lineShape1 = new LineShape();
            this.rectangleShape7 = new RectangleShape();
            this.rectangleShape1 = new RectangleShape();
            this.tabPageLab = new TabPage();
            this.comboDocStatuslab = new ComboBox();
            this.textCheckedByLab = new TextBox();
            this.textRemarkLab = new TextBox();
            this.textApprovedByLab = new TextBox();
            this.textSampleByLab = new TextBox();
            this.labelDocStatusLab = new Label();
            this.labelSampeLab = new Label();
            this.labelRemarkLab = new Label();
            this.labelApprovedLab = new Label();
            this.labelSmplLab = new Label();
            this.buttonSaveLab = new Button();
            this.tabLab = new TabControl();
            this.tabPageCPO = new TabPage();
            this.label28 = new Label();
            this.label14 = new Label();
            this.label13 = new Label();
            this.label12 = new Label();
            this.label11 = new Label();
            this.label10 = new Label();
            this.label9 = new Label();
            this.label7 = new Label();
            this.label6 = new Label();
            this.label5 = new Label();
            this.label3 = new Label();
            this.label2 = new Label();
            this.textBIV = new TextBox();
            this.textBColour = new TextBox();
            this.textBDobi = new TextBox();
            this.textBSP = new TextBox();
            this.textBMI = new TextBox();
            this.textBFFA = new TextBox();
            this.textTIV = new TextBox();
            this.textTColour = new TextBox();
            this.textTDobi = new TextBox();
            this.textTSP = new TextBox();
            this.textTMI = new TextBox();
            this.textTFFA = new TextBox();
            this.labelBSam = new Label();
            this.labelTSam = new Label();
            this.labelSpek = new Label();
            this.labelParam = new Label();
            this.tabPageOther = new TabPage();
            this.label26 = new Label();
            this.label31 = new Label();
            this.label32 = new Label();
            this.label33 = new Label();
            this.label34 = new Label();
            this.label35 = new Label();
            this.textBSpatOth = new TextBox();
            this.textBCSOth = new TextBox();
            this.textBIVOth = new TextBox();
            this.textBPVOth = new TextBox();
            this.textBColourOth = new TextBox();
            this.textBFFAOth = new TextBox();
            this.textTSpatOth = new TextBox();
            this.textTCSOth = new TextBox();
            this.textTIVOth = new TextBox();
            this.textTPVOth = new TextBox();
            this.textTColourOth = new TextBox();
            this.textTFFAOth = new TextBox();
            this.labelBOth = new Label();
            this.labelTOth = new Label();
            this.labelParamOth = new Label();
            this.tabPagePK = new TabPage();
            this.buttonPrintPK = new Button();
            this.label27 = new Label();
            this.label25 = new Label();
            this.label1 = new Label();
            this.label15 = new Label();
            this.label16 = new Label();
            this.label17 = new Label();
            this.label18 = new Label();
            this.label19 = new Label();
            this.label20 = new Label();
            this.label21 = new Label();
            this.label23 = new Label();
            this.label24 = new Label();
            this.textBIVPK = new TextBox();
            this.textBColourPK = new TextBox();
            this.textBDobiPK = new TextBox();
            this.textBDSPK = new TextBox();
            this.textBMIPK = new TextBox();
            this.textBFFAPK = new TextBox();
            this.textTIVPK = new TextBox();
            this.textTColourPK = new TextBox();
            this.textTDobiPK = new TextBox();
            this.textTDSPK = new TextBox();
            this.textTMIPK = new TextBox();
            this.textTFFAPK = new TextBox();
            this.labelBPK = new Label();
            this.labelTPK = new Label();
            this.labelSpecPK = new Label();
            this.label4 = new Label();
            this.tabPageComposite = new TabPage();
            this.dgComposite = new DataGridView();
            this.panel1 = new Panel();
            this.buttonSaveComposite = new Button();
            this.labelVehicleNo = new Label();
            this.labelMaterial = new Label();
            this.labelShip = new Label();
            this.labelLoadingDate = new Label();
            this.textVehicle = new TextBox();
            this.textCommName = new TextBox();
            this.textShip = new TextBox();
            this.dtLoadDate = new DateTimePicker();
            this.panelAtas = new Panel();
            this.panelBawah.SuspendLayout();
            this.panelTengah.SuspendLayout();
            this.tabControlQuality.SuspendLayout();
            this.tabPageConsigment.SuspendLayout();
            this.tabPageLab.SuspendLayout();
            this.tabLab.SuspendLayout();
            this.tabPageCPO.SuspendLayout();
            this.tabPageOther.SuspendLayout();
            this.tabPagePK.SuspendLayout();
            this.tabPageComposite.SuspendLayout();
            ((ISupportInitialize) this.dgComposite).BeginInit();
            this.panel1.SuspendLayout();
            this.panelAtas.SuspendLayout();
            base.SuspendLayout();
            this.panelBawah.BorderStyle = BorderStyle.Fixed3D;
            this.panelBawah.Controls.Add(this.buttonConClose);
            this.panelBawah.Controls.Add(this.buttonPrint);
            this.panelBawah.Dock = DockStyle.Bottom;
            this.panelBawah.Location = new Point(0, 0x219);
            this.panelBawah.Name = "panelBawah";
            this.panelBawah.Size = new Size(0x2d2, 50);
            this.panelBawah.TabIndex = 2;
            this.panelBawah.Paint += new PaintEventHandler(this.panelBawah_Paint);
            this.buttonConClose.Location = new Point(600, 3);
            this.buttonConClose.Name = "buttonConClose";
            this.buttonConClose.Size = new Size(0x6f, 40);
            this.buttonConClose.TabIndex = 0x1d;
            this.buttonConClose.Text = "&Close";
            this.buttonConClose.UseVisualStyleBackColor = true;
            this.buttonConClose.Click += new EventHandler(this.buttonConClose_Click);
            this.buttonPrint.Location = new Point(0x1dc, 3);
            this.buttonPrint.Name = "buttonPrint";
            this.buttonPrint.Size = new Size(0x6f, 40);
            this.buttonPrint.TabIndex = 0x1c;
            this.buttonPrint.Text = "&Print";
            this.buttonPrint.UseVisualStyleBackColor = true;
            this.buttonPrint.Click += new EventHandler(this.buttonPrint_Click);
            this.panelTengah.BorderStyle = BorderStyle.Fixed3D;
            this.panelTengah.Controls.Add(this.tabControlQuality);
            this.panelTengah.Dock = DockStyle.Fill;
            this.panelTengah.Location = new Point(0, 0x4b);
            this.panelTengah.Name = "panelTengah";
            this.panelTengah.Size = new Size(0x2d2, 0x1ce);
            this.panelTengah.TabIndex = 1;
            this.tabControlQuality.Controls.Add(this.tabPageConsigment);
            this.tabControlQuality.Controls.Add(this.tabPageLab);
            this.tabControlQuality.Controls.Add(this.tabPageComposite);
            this.tabControlQuality.Dock = DockStyle.Fill;
            this.tabControlQuality.Location = new Point(0, 0);
            this.tabControlQuality.Name = "tabControlQuality";
            this.tabControlQuality.SelectedIndex = 0;
            this.tabControlQuality.Size = new Size(0x2ce, 0x1ca);
            this.tabControlQuality.TabIndex = 0;
            this.tabPageConsigment.BackColor = SystemColors.ButtonFace;
            this.tabPageConsigment.Controls.Add(this.checkAllSeal);
            this.tabPageConsigment.Controls.Add(this.textConDiff1);
            this.tabPageConsigment.Controls.Add(this.textConDiff2);
            this.tabPageConsigment.Controls.Add(this.textConDiff3);
            this.tabPageConsigment.Controls.Add(this.textConDiff4);
            this.tabPageConsigment.Controls.Add(this.textConDiff5);
            this.tabPageConsigment.Controls.Add(this.textConTotalDiff);
            this.tabPageConsigment.Controls.Add(this.textTotalDips);
            this.tabPageConsigment.Controls.Add(this.textTotalMSADips);
            this.tabPageConsigment.Controls.Add(this.textConRemark);
            this.tabPageConsigment.Controls.Add(this.textConAllSeal);
            this.tabPageConsigment.Controls.Add(this.textConCheckBy);
            this.tabPageConsigment.Controls.Add(this.textConSpanner);
            this.tabPageConsigment.Controls.Add(this.textConDiesel);
            this.tabPageConsigment.Controls.Add(this.textConWheel);
            this.tabPageConsigment.Controls.Add(this.textConWater);
            this.tabPageConsigment.Controls.Add(this.textDips5);
            this.tabPageConsigment.Controls.Add(this.textDips4);
            this.tabPageConsigment.Controls.Add(this.textDips3);
            this.tabPageConsigment.Controls.Add(this.textDips2);
            this.tabPageConsigment.Controls.Add(this.textDips1);
            this.tabPageConsigment.Controls.Add(this.textMSADips5);
            this.tabPageConsigment.Controls.Add(this.textMSADips4);
            this.tabPageConsigment.Controls.Add(this.textMSADips3);
            this.tabPageConsigment.Controls.Add(this.textMSADips2);
            this.tabPageConsigment.Controls.Add(this.textMSADips1);
            this.tabPageConsigment.Controls.Add(this.textConCode5);
            this.tabPageConsigment.Controls.Add(this.textConCode4);
            this.tabPageConsigment.Controls.Add(this.textConCode3);
            this.tabPageConsigment.Controls.Add(this.textConCode2);
            this.tabPageConsigment.Controls.Add(this.textConCode1);
            this.tabPageConsigment.Controls.Add(this.buttonConSave);
            this.tabPageConsigment.Controls.Add(this.labelConRemark);
            this.tabPageConsigment.Controls.Add(this.checkConPaper);
            this.tabPageConsigment.Controls.Add(this.labelConCheckBy);
            this.tabPageConsigment.Controls.Add(this.labelWater);
            this.tabPageConsigment.Controls.Add(this.labelSpannerJack);
            this.tabPageConsigment.Controls.Add(this.labelDiesel);
            this.tabPageConsigment.Controls.Add(this.labelWheel);
            this.tabPageConsigment.Controls.Add(this.label8);
            this.tabPageConsigment.Controls.Add(this.labelConDiff);
            this.tabPageConsigment.Controls.Add(this.labelConDips2);
            this.tabPageConsigment.Controls.Add(this.labelConDips1);
            this.tabPageConsigment.Controls.Add(this.labelConComp5);
            this.tabPageConsigment.Controls.Add(this.labelConComp4);
            this.tabPageConsigment.Controls.Add(this.labelConComp3);
            this.tabPageConsigment.Controls.Add(this.labelConComp2);
            this.tabPageConsigment.Controls.Add(this.labelConComp1);
            this.tabPageConsigment.Controls.Add(this.labelConCode);
            this.tabPageConsigment.Controls.Add(this.shapeContainer1);
            this.tabPageConsigment.Location = new Point(4, 0x16);
            this.tabPageConsigment.Name = "tabPageConsigment";
            this.tabPageConsigment.Padding = new Padding(3);
            this.tabPageConsigment.Size = new Size(710, 0x1b0);
            this.tabPageConsigment.TabIndex = 0;
            this.tabPageConsigment.Text = "Consignment";
            this.tabPageConsigment.Click += new EventHandler(this.tabPageConsigment_Click);
            this.checkAllSeal.AutoSize = true;
            this.checkAllSeal.Location = new Point(0x2f, 360);
            this.checkAllSeal.Name = "checkAllSeal";
            this.checkAllSeal.Size = new Size(0xbc, 0x11);
            this.checkAllSeal.TabIndex = 0x17;
            this.checkAllSeal.Text = "All Seal Checked (EAS, SGS, ITS)";
            this.checkAllSeal.UseVisualStyleBackColor = true;
            this.textConDiff1.BackColor = SystemColors.ButtonFace;
            this.textConDiff1.BorderStyle = BorderStyle.None;
            this.textConDiff1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textConDiff1.Location = new Point(0x1d9, 0x2a);
            this.textConDiff1.Name = "textConDiff1";
            this.textConDiff1.ReadOnly = true;
            this.textConDiff1.Size = new Size(120, 13);
            this.textConDiff1.TabIndex = 0x30;
            this.textConDiff1.Text = "0";
            this.textConDiff1.TextAlign = HorizontalAlignment.Right;
            this.textConDiff2.BackColor = SystemColors.ButtonFace;
            this.textConDiff2.BorderStyle = BorderStyle.None;
            this.textConDiff2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textConDiff2.Location = new Point(0x1d9, 0x47);
            this.textConDiff2.Name = "textConDiff2";
            this.textConDiff2.ReadOnly = true;
            this.textConDiff2.Size = new Size(120, 13);
            this.textConDiff2.TabIndex = 0x31;
            this.textConDiff2.Text = "0";
            this.textConDiff2.TextAlign = HorizontalAlignment.Right;
            this.textConDiff3.BackColor = SystemColors.ButtonFace;
            this.textConDiff3.BorderStyle = BorderStyle.None;
            this.textConDiff3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textConDiff3.Location = new Point(0x1d9, 0x66);
            this.textConDiff3.Name = "textConDiff3";
            this.textConDiff3.ReadOnly = true;
            this.textConDiff3.Size = new Size(120, 13);
            this.textConDiff3.TabIndex = 0;
            this.textConDiff3.Text = "0";
            this.textConDiff3.TextAlign = HorizontalAlignment.Right;
            this.textConDiff4.BackColor = SystemColors.ButtonFace;
            this.textConDiff4.BorderStyle = BorderStyle.None;
            this.textConDiff4.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textConDiff4.Location = new Point(0x1d9, 0x85);
            this.textConDiff4.Name = "textConDiff4";
            this.textConDiff4.ReadOnly = true;
            this.textConDiff4.Size = new Size(120, 13);
            this.textConDiff4.TabIndex = 1;
            this.textConDiff4.Text = "0";
            this.textConDiff4.TextAlign = HorizontalAlignment.Right;
            this.textConDiff5.BackColor = SystemColors.ButtonFace;
            this.textConDiff5.BorderStyle = BorderStyle.None;
            this.textConDiff5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textConDiff5.Location = new Point(0x1d9, 0xa8);
            this.textConDiff5.Name = "textConDiff5";
            this.textConDiff5.ReadOnly = true;
            this.textConDiff5.Size = new Size(120, 13);
            this.textConDiff5.TabIndex = 2;
            this.textConDiff5.Text = "0";
            this.textConDiff5.TextAlign = HorizontalAlignment.Right;
            this.textConTotalDiff.BackColor = SystemColors.ButtonFace;
            this.textConTotalDiff.BorderStyle = BorderStyle.None;
            this.textConTotalDiff.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textConTotalDiff.Location = new Point(0x1d9, 0xc9);
            this.textConTotalDiff.Name = "textConTotalDiff";
            this.textConTotalDiff.ReadOnly = true;
            this.textConTotalDiff.Size = new Size(120, 13);
            this.textConTotalDiff.TabIndex = 3;
            this.textConTotalDiff.Text = "0";
            this.textConTotalDiff.TextAlign = HorizontalAlignment.Right;
            this.textTotalDips.BackColor = SystemColors.ButtonFace;
            this.textTotalDips.BorderStyle = BorderStyle.None;
            this.textTotalDips.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textTotalDips.Location = new Point(0x146, 0xc9);
            this.textTotalDips.Name = "textTotalDips";
            this.textTotalDips.ReadOnly = true;
            this.textTotalDips.Size = new Size(0x80, 13);
            this.textTotalDips.TabIndex = 0x2b;
            this.textTotalDips.Text = "0";
            this.textTotalDips.TextAlign = HorizontalAlignment.Right;
            this.textTotalMSADips.BackColor = SystemColors.ButtonFace;
            this.textTotalMSADips.BorderStyle = BorderStyle.None;
            this.textTotalMSADips.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textTotalMSADips.Location = new Point(0xb6, 0xc9);
            this.textTotalMSADips.Name = "textTotalMSADips";
            this.textTotalMSADips.ReadOnly = true;
            this.textTotalMSADips.Size = new Size(0x80, 13);
            this.textTotalMSADips.TabIndex = 0x11;
            this.textTotalMSADips.Text = "0";
            this.textTotalMSADips.TextAlign = HorizontalAlignment.Right;
            this.textConRemark.Location = new Point(100, 0x182);
            this.textConRemark.Name = "textConRemark";
            this.textConRemark.Size = new Size(0x162, 20);
            this.textConRemark.TabIndex = 0x19;
            this.textConAllSeal.Location = new Point(0xf1, 0x166);
            this.textConAllSeal.Name = "textConAllSeal";
            this.textConAllSeal.Size = new Size(0xd5, 20);
            this.textConAllSeal.TabIndex = 0x18;
            this.textConCheckBy.Location = new Point(0x7b, 0x12e);
            this.textConCheckBy.Name = "textConCheckBy";
            this.textConCheckBy.Size = new Size(0x14b, 20);
            this.textConCheckBy.TabIndex = 0x15;
            this.textConSpanner.Location = new Point(0x1d9, 0x108);
            this.textConSpanner.Name = "textConSpanner";
            this.textConSpanner.Size = new Size(120, 20);
            this.textConSpanner.TabIndex = 20;
            this.textConSpanner.TextAlign = HorizontalAlignment.Right;
            this.textConDiesel.Location = new Point(0x143, 0x108);
            this.textConDiesel.Name = "textConDiesel";
            this.textConDiesel.Size = new Size(0x83, 20);
            this.textConDiesel.TabIndex = 0x13;
            this.textConDiesel.Text = "0";
            this.textConDiesel.TextAlign = HorizontalAlignment.Right;
            this.textConDiesel.KeyPress += new KeyPressEventHandler(this.textConDiesel_KeyPress);
            this.textConWheel.Location = new Point(0xb2, 0x108);
            this.textConWheel.Name = "textConWheel";
            this.textConWheel.Size = new Size(0x84, 20);
            this.textConWheel.TabIndex = 0x12;
            this.textConWheel.TextAlign = HorizontalAlignment.Right;
            this.textConWater.Location = new Point(0x2b, 0x108);
            this.textConWater.Name = "textConWater";
            this.textConWater.Size = new Size(0x7c, 20);
            this.textConWater.TabIndex = 0x24;
            this.textConWater.Text = "0";
            this.textConWater.TextAlign = HorizontalAlignment.Right;
            this.textConWater.KeyPress += new KeyPressEventHandler(this.textConWater_KeyPress);
            this.textDips5.Location = new Point(0x144, 0xa8);
            this.textDips5.Name = "textDips5";
            this.textDips5.Size = new Size(130, 20);
            this.textDips5.TabIndex = 14;
            this.textDips5.Text = "0";
            this.textDips5.TextAlign = HorizontalAlignment.Right;
            this.textDips5.TextChanged += new EventHandler(this.textDips5_TextChanged);
            this.textDips5.KeyPress += new KeyPressEventHandler(this.textDips5_KeyPress);
            this.textDips4.Location = new Point(0x144, 0x85);
            this.textDips4.Name = "textDips4";
            this.textDips4.Size = new Size(130, 20);
            this.textDips4.TabIndex = 15;
            this.textDips4.Text = "0";
            this.textDips4.TextAlign = HorizontalAlignment.Right;
            this.textDips4.TextChanged += new EventHandler(this.textDips4_TextChanged);
            this.textDips4.KeyPress += new KeyPressEventHandler(this.textDips4_KeyPress);
            this.textDips3.Location = new Point(0x144, 0x66);
            this.textDips3.Name = "textDips3";
            this.textDips3.Size = new Size(130, 20);
            this.textDips3.TabIndex = 12;
            this.textDips3.Text = "0";
            this.textDips3.TextAlign = HorizontalAlignment.Right;
            this.textDips3.TextChanged += new EventHandler(this.textDips3_TextChanged);
            this.textDips3.KeyPress += new KeyPressEventHandler(this.textDips3_KeyPress);
            this.textDips2.Location = new Point(0x144, 0x47);
            this.textDips2.Name = "textDips2";
            this.textDips2.Size = new Size(130, 20);
            this.textDips2.TabIndex = 11;
            this.textDips2.Text = "0";
            this.textDips2.TextAlign = HorizontalAlignment.Right;
            this.textDips2.TextChanged += new EventHandler(this.textDips2_TextChanged);
            this.textDips2.KeyPress += new KeyPressEventHandler(this.textDips2_KeyPress);
            this.textDips1.Location = new Point(0x144, 0x2a);
            this.textDips1.Name = "textDips1";
            this.textDips1.Size = new Size(130, 20);
            this.textDips1.TabIndex = 10;
            this.textDips1.Text = "0";
            this.textDips1.TextAlign = HorizontalAlignment.Right;
            this.textDips1.TextChanged += new EventHandler(this.textDips1_TextChanged);
            this.textDips1.KeyPress += new KeyPressEventHandler(this.textDips1_KeyPress);
            this.textMSADips5.Location = new Point(0xb6, 0xa8);
            this.textMSADips5.Name = "textMSADips5";
            this.textMSADips5.Size = new Size(0x80, 20);
            this.textMSADips5.TabIndex = 9;
            this.textMSADips5.Text = "0";
            this.textMSADips5.TextAlign = HorizontalAlignment.Right;
            this.textMSADips5.TextChanged += new EventHandler(this.textMSADips5_TextChanged);
            this.textMSADips5.KeyPress += new KeyPressEventHandler(this.textMSADips5_KeyPress);
            this.textMSADips4.Location = new Point(0xb6, 0x85);
            this.textMSADips4.Name = "textMSADips4";
            this.textMSADips4.Size = new Size(0x80, 20);
            this.textMSADips4.TabIndex = 8;
            this.textMSADips4.Text = "0";
            this.textMSADips4.TextAlign = HorizontalAlignment.Right;
            this.textMSADips4.TextChanged += new EventHandler(this.textMSADips4_TextChanged);
            this.textMSADips4.KeyPress += new KeyPressEventHandler(this.textMSADips4_KeyPress);
            this.textMSADips3.Location = new Point(0xb6, 0x66);
            this.textMSADips3.Name = "textMSADips3";
            this.textMSADips3.Size = new Size(0x80, 20);
            this.textMSADips3.TabIndex = 7;
            this.textMSADips3.Text = "0";
            this.textMSADips3.TextAlign = HorizontalAlignment.Right;
            this.textMSADips3.TextChanged += new EventHandler(this.textMSADips3_TextChanged);
            this.textMSADips3.KeyPress += new KeyPressEventHandler(this.textMSADips3_KeyPress);
            this.textMSADips2.Location = new Point(0xb6, 0x47);
            this.textMSADips2.Name = "textMSADips2";
            this.textMSADips2.Size = new Size(0x80, 20);
            this.textMSADips2.TabIndex = 6;
            this.textMSADips2.Text = "0";
            this.textMSADips2.TextAlign = HorizontalAlignment.Right;
            this.textMSADips2.TextChanged += new EventHandler(this.textMSADips2_TextChanged);
            this.textMSADips2.KeyPress += new KeyPressEventHandler(this.textMSADips2_KeyPress);
            this.textMSADips1.Location = new Point(0xb6, 0x2a);
            this.textMSADips1.Name = "textMSADips1";
            this.textMSADips1.Size = new Size(0x80, 20);
            this.textMSADips1.TabIndex = 5;
            this.textMSADips1.Text = "0";
            this.textMSADips1.TextAlign = HorizontalAlignment.Right;
            this.textMSADips1.TextChanged += new EventHandler(this.textMSADips1_TextChanged);
            this.textMSADips1.KeyPress += new KeyPressEventHandler(this.textMSADips1_KeyPress);
            this.textConCode5.Location = new Point(0x6f, 0xa8);
            this.textConCode5.Name = "textConCode5";
            this.textConCode5.Size = new Size(0x38, 20);
            this.textConCode5.TabIndex = 4;
            this.textConCode4.Location = new Point(0x6f, 0x85);
            this.textConCode4.Name = "textConCode4";
            this.textConCode4.Size = new Size(0x38, 20);
            this.textConCode4.TabIndex = 3;
            this.textConCode3.Location = new Point(0x6f, 0x66);
            this.textConCode3.Name = "textConCode3";
            this.textConCode3.Size = new Size(0x38, 20);
            this.textConCode3.TabIndex = 2;
            this.textConCode2.Location = new Point(0x6f, 0x47);
            this.textConCode2.Name = "textConCode2";
            this.textConCode2.Size = new Size(0x38, 20);
            this.textConCode2.TabIndex = 1;
            this.textConCode1.Location = new Point(0x6f, 0x2a);
            this.textConCode1.Name = "textConCode1";
            this.textConCode1.Size = new Size(0x38, 20);
            this.textConCode1.TabIndex = 0;
            this.buttonConSave.Location = new Point(0x1d8, 0x177);
            this.buttonConSave.Name = "buttonConSave";
            this.buttonConSave.Size = new Size(0x6f, 40);
            this.buttonConSave.TabIndex = 0x1a;
            this.buttonConSave.Text = "Save";
            this.buttonConSave.UseVisualStyleBackColor = true;
            this.buttonConSave.Click += new EventHandler(this.buttonConSave_Click);
            this.labelConRemark.AutoSize = true;
            this.labelConRemark.Location = new Point(50, 0x185);
            this.labelConRemark.Name = "labelConRemark";
            this.labelConRemark.Size = new Size(0x2c, 13);
            this.labelConRemark.TabIndex = 40;
            this.labelConRemark.Text = "Remark";
            this.checkConPaper.AutoSize = true;
            this.checkConPaper.Location = new Point(0x2f, 0x14d);
            this.checkConPaper.Name = "checkConPaper";
            this.checkConPaper.Size = new Size(0x98, 0x11);
            this.checkConPaper.TabIndex = 0x16;
            this.checkConPaper.Text = "Consignmnet Paper Check";
            this.checkConPaper.UseVisualStyleBackColor = true;
            this.labelConCheckBy.AutoSize = true;
            this.labelConCheckBy.Location = new Point(0x2c, 0x131);
            this.labelConCheckBy.Name = "labelConCheckBy";
            this.labelConCheckBy.Size = new Size(0x41, 13);
            this.labelConCheckBy.TabIndex = 0x25;
            this.labelConCheckBy.Text = "Checked By";
            this.labelWater.AutoSize = true;
            this.labelWater.Location = new Point(0x4d, 0xef);
            this.labelWater.Name = "labelWater";
            this.labelWater.Size = new Size(0x2f, 13);
            this.labelWater.TabIndex = 0x22;
            this.labelWater.Text = "WATER";
            this.labelSpannerJack.AutoSize = true;
            this.labelSpannerJack.Location = new Point(0x1df, 0xef);
            this.labelSpannerJack.Name = "labelSpannerJack";
            this.labelSpannerJack.Size = new Size(90, 13);
            this.labelSpannerJack.TabIndex = 4;
            this.labelSpannerJack.Text = "SPANNER/JACK";
            this.labelDiesel.AutoSize = true;
            this.labelDiesel.Location = new Point(0x16f, 0xef);
            this.labelDiesel.Name = "labelDiesel";
            this.labelDiesel.Size = new Size(0x2d, 13);
            this.labelDiesel.TabIndex = 0x2a;
            this.labelDiesel.Text = "DIESEL";
            this.labelWheel.AutoSize = true;
            this.labelWheel.Location = new Point(220, 0xef);
            this.labelWheel.Name = "labelWheel";
            this.labelWheel.Size = new Size(0x2e, 13);
            this.labelWheel.TabIndex = 0x29;
            this.labelWheel.Text = "WHEEL";
            this.label8.AutoSize = true;
            this.label8.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label8.Location = new Point(0x2c, 0xcc);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x2f, 13);
            this.label8.TabIndex = 0x21;
            this.label8.Text = "TOTAL";
            this.labelConDiff.AutoSize = true;
            this.labelConDiff.Location = new Point(0x1df, 20);
            this.labelConDiff.Name = "labelConDiff";
            this.labelConDiff.Size = new Size(0x68, 13);
            this.labelConDiff.TabIndex = 0x2f;
            this.labelConDiff.Text = "DIFFERENCE (LTR)";
            this.labelConDips2.AutoSize = true;
            this.labelConDips2.Location = new Point(0x16f, 20);
            this.labelConDips2.Name = "labelConDips2";
            this.labelConDips2.Size = new Size(0x3e, 13);
            this.labelConDips2.TabIndex = 0x2e;
            this.labelConDips2.Text = "DIPS [LTR]";
            this.labelConDips1.AutoSize = true;
            this.labelConDips1.Location = new Point(0xcf, 20);
            this.labelConDips1.Name = "labelConDips1";
            this.labelConDips1.Size = new Size(0x58, 13);
            this.labelConDips1.TabIndex = 0x2c;
            this.labelConDips1.Text = "MSA DIPS [LTR]";
            this.labelConComp5.AutoSize = true;
            this.labelConComp5.Location = new Point(0x2c, 0xab);
            this.labelConComp5.Name = "labelConComp5";
            this.labelConComp5.Size = new Size(0x35, 13);
            this.labelConComp5.TabIndex = 0x20;
            this.labelConComp5.Text = "COMP - 5";
            this.labelConComp4.AutoSize = true;
            this.labelConComp4.Location = new Point(0x2c, 0x88);
            this.labelConComp4.Name = "labelConComp4";
            this.labelConComp4.Size = new Size(0x35, 13);
            this.labelConComp4.TabIndex = 0x1f;
            this.labelConComp4.Text = "COMP - 4";
            this.labelConComp3.AutoSize = true;
            this.labelConComp3.Location = new Point(0x2c, 0x69);
            this.labelConComp3.Name = "labelConComp3";
            this.labelConComp3.Size = new Size(0x35, 13);
            this.labelConComp3.TabIndex = 30;
            this.labelConComp3.Text = "COMP - 3";
            this.labelConComp2.AutoSize = true;
            this.labelConComp2.Location = new Point(0x2c, 0x4a);
            this.labelConComp2.Name = "labelConComp2";
            this.labelConComp2.Size = new Size(0x35, 13);
            this.labelConComp2.TabIndex = 0x1d;
            this.labelConComp2.Text = "COMP - 2";
            this.labelConComp1.AutoSize = true;
            this.labelConComp1.Location = new Point(0x2c, 0x2d);
            this.labelConComp1.Name = "labelConComp1";
            this.labelConComp1.Size = new Size(0x35, 13);
            this.labelConComp1.TabIndex = 0x1c;
            this.labelConComp1.Text = "COMP - 1";
            this.labelConCode.AutoSize = true;
            this.labelConCode.Location = new Point(120, 20);
            this.labelConCode.Name = "labelConCode";
            this.labelConCode.Size = new Size(0x20, 13);
            this.labelConCode.TabIndex = 0x2d;
            this.labelConCode.Text = "Code";
            this.shapeContainer1.Location = new Point(3, 3);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[0x10];
            shapes[0] = this.lineShape14;
            shapes[1] = this.lineShape13;
            shapes[2] = this.lineShape12;
            shapes[3] = this.lineShape11;
            shapes[4] = this.lineShape10;
            shapes[5] = this.lineShape9;
            shapes[6] = this.lineShape8;
            shapes[7] = this.lineShape7;
            shapes[8] = this.lineShape6;
            shapes[9] = this.lineShape5;
            shapes[10] = this.lineShape4;
            shapes[11] = this.lineShape3;
            shapes[12] = this.lineShape2;
            shapes[13] = this.lineShape1;
            shapes[14] = this.rectangleShape7;
            shapes[15] = this.rectangleShape1;
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(0x2c0, 0x1aa);
            this.shapeContainer1.TabIndex = 0x1b;
            this.shapeContainer1.TabStop = false;
            this.lineShape14.Name = "lineShape14";
            this.lineShape14.X1 = 0x1cd;
            this.lineShape14.X2 = 0x1cd;
            this.lineShape14.Y1 = 0xe4;
            this.lineShape14.Y2 = 0x11f;
            this.lineShape13.Name = "lineShape13";
            this.lineShape13.X1 = 0x13a;
            this.lineShape13.X2 = 0x13a;
            this.lineShape13.Y1 = 0xe5;
            this.lineShape13.Y2 = 0x120;
            this.lineShape12.Name = "lineShape12";
            this.lineShape12.X1 = 0xa8;
            this.lineShape12.X2 = 0xa8;
            this.lineShape12.Y1 = 0xe5;
            this.lineShape12.Y2 = 0x120;
            this.lineShape11.Name = "lineShape11";
            this.lineShape11.X1 = 0x15;
            this.lineShape11.X2 = 600;
            this.lineShape11.Y1 = 0xfd;
            this.lineShape11.Y2 = 0xfd;
            this.lineShape10.Name = "lineShape10";
            this.lineShape10.X1 = 0x61;
            this.lineShape10.X2 = 0x61;
            this.lineShape10.Y1 = 8;
            this.lineShape10.Y2 = 0xdd;
            this.lineShape9.Name = "lineShape9";
            this.lineShape9.X1 = 0x13a;
            this.lineShape9.X2 = 0x139;
            this.lineShape9.Y1 = 8;
            this.lineShape9.Y2 = 0xde;
            this.lineShape8.Name = "lineShape8";
            this.lineShape8.X1 = 0xa9;
            this.lineShape8.X2 = 0xa8;
            this.lineShape8.Y1 = 8;
            this.lineShape8.Y2 = 0xde;
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 0x16;
            this.lineShape7.X2 = 0x259;
            this.lineShape7.Y1 = 0xc0;
            this.lineShape7.Y2 = 0xc0;
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 0x17;
            this.lineShape6.X2 = 0x259;
            this.lineShape6.Y1 = 0x9b;
            this.lineShape6.Y2 = 0x9b;
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 0x16;
            this.lineShape5.X2 = 0x259;
            this.lineShape5.Y1 = 0x7a;
            this.lineShape5.Y2 = 0x7a;
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 0x17;
            this.lineShape4.X2 = 0x259;
            this.lineShape4.Y1 = 0x5d;
            this.lineShape4.Y2 = 0x5d;
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 0x17;
            this.lineShape3.X2 = 0x259;
            this.lineShape3.Y1 = 0x3e;
            this.lineShape3.Y2 = 0x3e;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 0x1cd;
            this.lineShape2.X2 = 0x1cd;
            this.lineShape2.Y1 = 8;
            this.lineShape2.Y2 = 0xdd;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 0x15;
            this.lineShape1.X2 = 0x257;
            this.lineShape1.Y1 = 0x22;
            this.lineShape1.Y2 = 0x22;
            this.rectangleShape7.Location = new Point(0x15, 0xe4);
            this.rectangleShape7.Name = "rectangleShape7";
            this.rectangleShape7.Size = new Size(0x243, 0x3d);
            this.rectangleShape1.Location = new Point(0x16, 7);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new Size(0x242, 0xd7);
            this.tabPageLab.BackColor = SystemColors.ButtonFace;
            this.tabPageLab.Controls.Add(this.comboDocStatuslab);
            this.tabPageLab.Controls.Add(this.textCheckedByLab);
            this.tabPageLab.Controls.Add(this.textRemarkLab);
            this.tabPageLab.Controls.Add(this.textApprovedByLab);
            this.tabPageLab.Controls.Add(this.textSampleByLab);
            this.tabPageLab.Controls.Add(this.labelDocStatusLab);
            this.tabPageLab.Controls.Add(this.labelSampeLab);
            this.tabPageLab.Controls.Add(this.labelRemarkLab);
            this.tabPageLab.Controls.Add(this.labelApprovedLab);
            this.tabPageLab.Controls.Add(this.labelSmplLab);
            this.tabPageLab.Controls.Add(this.buttonSaveLab);
            this.tabPageLab.Controls.Add(this.tabLab);
            this.tabPageLab.Location = new Point(4, 0x16);
            this.tabPageLab.Name = "tabPageLab";
            this.tabPageLab.Padding = new Padding(3);
            this.tabPageLab.Size = new Size(710, 0x1b0);
            this.tabPageLab.TabIndex = 1;
            this.tabPageLab.Text = "Laboratory";
            this.comboDocStatuslab.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboDocStatuslab.FormattingEnabled = true;
            this.comboDocStatuslab.Location = new Point(0x1b4, 0x13a);
            this.comboDocStatuslab.Name = "comboDocStatuslab";
            this.comboDocStatuslab.Size = new Size(0xb3, 0x15);
            this.comboDocStatuslab.TabIndex = 0x35;
            this.textCheckedByLab.Location = new Point(0x1b4, 0x11e);
            this.textCheckedByLab.Name = "textCheckedByLab";
            this.textCheckedByLab.Size = new Size(180, 20);
            this.textCheckedByLab.TabIndex = 0x34;
            this.textRemarkLab.Location = new Point(0x7f, 340);
            this.textRemarkLab.Name = "textRemarkLab";
            this.textRemarkLab.Size = new Size(0x1e9, 20);
            this.textRemarkLab.TabIndex = 0x33;
            this.textApprovedByLab.Location = new Point(0x7f, 0x13a);
            this.textApprovedByLab.Name = "textApprovedByLab";
            this.textApprovedByLab.Size = new Size(180, 20);
            this.textApprovedByLab.TabIndex = 50;
            this.textSampleByLab.Location = new Point(0x7f, 0x11e);
            this.textSampleByLab.Name = "textSampleByLab";
            this.textSampleByLab.Size = new Size(180, 20);
            this.textSampleByLab.TabIndex = 0x2c;
            this.labelDocStatusLab.AutoSize = true;
            this.labelDocStatusLab.Location = new Point(0x148, 0x13a);
            this.labelDocStatusLab.Name = "labelDocStatusLab";
            this.labelDocStatusLab.Size = new Size(0x59, 13);
            this.labelDocStatusLab.TabIndex = 0x31;
            this.labelDocStatusLab.Text = "Document Status";
            this.labelSampeLab.AutoSize = true;
            this.labelSampeLab.Location = new Point(0x145, 0x121);
            this.labelSampeLab.Name = "labelSampeLab";
            this.labelSampeLab.Size = new Size(0x67, 13);
            this.labelSampeLab.TabIndex = 0x30;
            this.labelSampeLab.Text = "Sample Checked By";
            this.labelRemarkLab.AutoSize = true;
            this.labelRemarkLab.Location = new Point(30, 0x157);
            this.labelRemarkLab.Name = "labelRemarkLab";
            this.labelRemarkLab.Size = new Size(0x2c, 13);
            this.labelRemarkLab.TabIndex = 0x2f;
            this.labelRemarkLab.Text = "Remark";
            this.labelApprovedLab.AutoSize = true;
            this.labelApprovedLab.Location = new Point(0x20, 0x13a);
            this.labelApprovedLab.Name = "labelApprovedLab";
            this.labelApprovedLab.Size = new Size(0x44, 13);
            this.labelApprovedLab.TabIndex = 0x2e;
            this.labelApprovedLab.Text = "Approved By";
            this.labelSmplLab.AutoSize = true;
            this.labelSmplLab.Location = new Point(30, 0x121);
            this.labelSmplLab.Name = "labelSmplLab";
            this.labelSmplLab.Size = new Size(0x5b, 13);
            this.labelSmplLab.TabIndex = 0x2d;
            this.labelSmplLab.Text = "Sample Taken By";
            this.buttonSaveLab.Location = new Point(0x1d8, 0x17a);
            this.buttonSaveLab.Name = "buttonSaveLab";
            this.buttonSaveLab.Size = new Size(0x6f, 0x25);
            this.buttonSaveLab.TabIndex = 0x2c;
            this.buttonSaveLab.Text = "SAVE";
            this.buttonSaveLab.UseVisualStyleBackColor = true;
            this.buttonSaveLab.Click += new EventHandler(this.buttonSaveLab_Click);
            this.tabLab.Controls.Add(this.tabPageCPO);
            this.tabLab.Controls.Add(this.tabPageOther);
            this.tabLab.Controls.Add(this.tabPagePK);
            this.tabLab.Location = new Point(6, 0x12);
            this.tabLab.Name = "tabLab";
            this.tabLab.SelectedIndex = 0;
            this.tabLab.Size = new Size(0x288, 0xfe);
            this.tabLab.TabIndex = 0;
            this.tabPageCPO.BackColor = SystemColors.ButtonFace;
            this.tabPageCPO.Controls.Add(this.label28);
            this.tabPageCPO.Controls.Add(this.label14);
            this.tabPageCPO.Controls.Add(this.label13);
            this.tabPageCPO.Controls.Add(this.label12);
            this.tabPageCPO.Controls.Add(this.label11);
            this.tabPageCPO.Controls.Add(this.label10);
            this.tabPageCPO.Controls.Add(this.label9);
            this.tabPageCPO.Controls.Add(this.label7);
            this.tabPageCPO.Controls.Add(this.label6);
            this.tabPageCPO.Controls.Add(this.label5);
            this.tabPageCPO.Controls.Add(this.label3);
            this.tabPageCPO.Controls.Add(this.label2);
            this.tabPageCPO.Controls.Add(this.textBIV);
            this.tabPageCPO.Controls.Add(this.textBColour);
            this.tabPageCPO.Controls.Add(this.textBDobi);
            this.tabPageCPO.Controls.Add(this.textBSP);
            this.tabPageCPO.Controls.Add(this.textBMI);
            this.tabPageCPO.Controls.Add(this.textBFFA);
            this.tabPageCPO.Controls.Add(this.textTIV);
            this.tabPageCPO.Controls.Add(this.textTColour);
            this.tabPageCPO.Controls.Add(this.textTDobi);
            this.tabPageCPO.Controls.Add(this.textTSP);
            this.tabPageCPO.Controls.Add(this.textTMI);
            this.tabPageCPO.Controls.Add(this.textTFFA);
            this.tabPageCPO.Controls.Add(this.labelBSam);
            this.tabPageCPO.Controls.Add(this.labelTSam);
            this.tabPageCPO.Controls.Add(this.labelSpek);
            this.tabPageCPO.Controls.Add(this.labelParam);
            this.tabPageCPO.Location = new Point(4, 0x16);
            this.tabPageCPO.Name = "tabPageCPO";
            this.tabPageCPO.Padding = new Padding(3);
            this.tabPageCPO.Size = new Size(640, 0xe4);
            this.tabPageCPO.TabIndex = 0;
            this.tabPageCPO.Text = "CPO / CPL";
            this.label28.AutoSize = true;
            this.label28.Location = new Point(0x8a, 0x22);
            this.label28.Name = "label28";
            this.label28.Size = new Size(0x1a, 0x1a);
            this.label28.TabIndex = 0x80;
            this.label28.Text = "FFA\r\n(%)";
            this.label14.AutoSize = true;
            this.label14.Location = new Point(0x7e, 0x44);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x4b, 0x1a);
            this.label14.TabIndex = 0x54;
            this.label14.Text = "5.5% max\r\n (as oleic acid)\r\n";
            this.label13.AutoSize = true;
            this.label13.Location = new Point(0xd7, 0x51);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x34, 13);
            this.label13.TabIndex = 0x53;
            this.label13.Text = "0.2% max";
            this.label12.AutoSize = true;
            this.label12.Location = new Point(290, 0x44);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x42, 0x1a);
            this.label12.TabIndex = 0x52;
            this.label12.Text = "36-39 \r\n/ 12\x00b0C (max)\r\n";
            this.label11.AutoSize = true;
            this.label11.Location = new Point(0x181, 0x44);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x26, 13);
            this.label11.TabIndex = 0x51;
            this.label11.Text = "2 (min)";
            this.label10.AutoSize = true;
            this.label10.Location = new Point(470, 0x44);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x33, 13);
            this.label10.TabIndex = 80;
            this.label10.Text = "10 - 12 R";
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x224, 0x44);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x41, 0x1a);
            this.label9.TabIndex = 0x4f;
            this.label9.Text = "51-54 (CPO)\r\n55-58 (CPL)\r\n";
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0x223, 0x22);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x42, 0x1a);
            this.label7.TabIndex = 0x4e;
            this.label7.Text = "Iodine Value\r\n(g/100g)";
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x1d3, 0x22);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x36, 0x1a);
            this.label6.TabIndex = 0x4d;
            this.label6.Text = "Colour\r\n(1/4\" cell)";
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x181, 0x22);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x1d, 13);
            this.label5.TabIndex = 0x4c;
            this.label5.Text = "Dobi";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x121, 0x22);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x4d, 0x1a);
            this.label3.TabIndex = 0x4b;
            this.label3.Text = "Slip Point / \r\nCloud point(\x00b0C)\r\n";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0xcc, 0x22);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x37, 0x27);
            this.label2.TabIndex = 0x4a;
            this.label2.Text = "Moistures &\r\n Impurities\r\n(%)";
            this.textBIV.Location = new Point(0x21e, 0x9b);
            this.textBIV.Name = "textBIV";
            this.textBIV.Size = new Size(0x4a, 20);
            this.textBIV.TabIndex = 0x2b;
            this.textBIV.Text = "0";
            this.textBIV.TextAlign = HorizontalAlignment.Right;
            this.textBColour.Location = new Point(460, 0x9b);
            this.textBColour.Name = "textBColour";
            this.textBColour.Size = new Size(0x4a, 20);
            this.textBColour.TabIndex = 0x2a;
            this.textBColour.Text = "0";
            this.textBColour.TextAlign = HorizontalAlignment.Right;
            this.textBDobi.Location = new Point(0x174, 0x9b);
            this.textBDobi.Name = "textBDobi";
            this.textBDobi.Size = new Size(0x4a, 20);
            this.textBDobi.TabIndex = 0x29;
            this.textBDobi.Text = "0";
            this.textBDobi.TextAlign = HorizontalAlignment.Right;
            this.textBSP.Location = new Point(0x124, 0x9b);
            this.textBSP.Name = "textBSP";
            this.textBSP.Size = new Size(0x4a, 20);
            this.textBSP.TabIndex = 40;
            this.textBSP.Text = "0";
            this.textBSP.TextAlign = HorizontalAlignment.Right;
            this.textBMI.Location = new Point(0xcf, 0x9b);
            this.textBMI.Name = "textBMI";
            this.textBMI.Size = new Size(0x4a, 20);
            this.textBMI.TabIndex = 0x27;
            this.textBMI.Text = "0";
            this.textBMI.TextAlign = HorizontalAlignment.Right;
            this.textBFFA.Location = new Point(0x7f, 0x9b);
            this.textBFFA.Name = "textBFFA";
            this.textBFFA.Size = new Size(0x4a, 20);
            this.textBFFA.TabIndex = 0x26;
            this.textBFFA.Text = "0";
            this.textBFFA.TextAlign = HorizontalAlignment.Right;
            this.textTIV.Location = new Point(0x21e, 0x74);
            this.textTIV.Name = "textTIV";
            this.textTIV.Size = new Size(0x4a, 20);
            this.textTIV.TabIndex = 0x25;
            this.textTIV.Text = "0";
            this.textTIV.TextAlign = HorizontalAlignment.Right;
            this.textTColour.Location = new Point(460, 0x74);
            this.textTColour.Name = "textTColour";
            this.textTColour.Size = new Size(0x4a, 20);
            this.textTColour.TabIndex = 0x24;
            this.textTColour.Text = "0";
            this.textTColour.TextAlign = HorizontalAlignment.Right;
            this.textTDobi.Location = new Point(0x174, 0x74);
            this.textTDobi.Name = "textTDobi";
            this.textTDobi.Size = new Size(0x4a, 20);
            this.textTDobi.TabIndex = 0x23;
            this.textTDobi.Text = "0";
            this.textTDobi.TextAlign = HorizontalAlignment.Right;
            this.textTSP.Location = new Point(0x124, 0x74);
            this.textTSP.Name = "textTSP";
            this.textTSP.Size = new Size(0x4a, 20);
            this.textTSP.TabIndex = 0x22;
            this.textTSP.Text = "0";
            this.textTSP.TextAlign = HorizontalAlignment.Right;
            this.textTMI.Location = new Point(0xcf, 0x74);
            this.textTMI.Name = "textTMI";
            this.textTMI.Size = new Size(0x4a, 20);
            this.textTMI.TabIndex = 0x21;
            this.textTMI.Text = "0";
            this.textTMI.TextAlign = HorizontalAlignment.Right;
            this.textTFFA.Location = new Point(0x7f, 0x74);
            this.textTFFA.Name = "textTFFA";
            this.textTFFA.Size = new Size(0x4a, 20);
            this.textTFFA.TabIndex = 0x20;
            this.textTFFA.Text = "0";
            this.textTFFA.TextAlign = HorizontalAlignment.Right;
            this.labelBSam.AutoSize = true;
            this.labelBSam.Location = new Point(0x16, 0x9e);
            this.labelBSam.Name = "labelBSam";
            this.labelBSam.Size = new Size(0x4e, 13);
            this.labelBSam.TabIndex = 12;
            this.labelBSam.Text = "Bottom Sample";
            this.labelTSam.AutoSize = true;
            this.labelTSam.Location = new Point(0x18, 0x77);
            this.labelTSam.Name = "labelTSam";
            this.labelTSam.Size = new Size(0x40, 13);
            this.labelTSam.TabIndex = 11;
            this.labelTSam.Text = "Top Sample";
            this.labelSpek.AutoSize = true;
            this.labelSpek.Location = new Point(0x18, 0x44);
            this.labelSpek.Name = "labelSpek";
            this.labelSpek.Size = new Size(0x44, 13);
            this.labelSpek.TabIndex = 10;
            this.labelSpek.Text = "Specification";
            this.labelParam.AutoSize = true;
            this.labelParam.Location = new Point(0x16, 0x22);
            this.labelParam.Name = "labelParam";
            this.labelParam.Size = new Size(60, 13);
            this.labelParam.TabIndex = 0;
            this.labelParam.Text = "Parametres";
            this.tabPageOther.BackColor = SystemColors.ButtonFace;
            this.tabPageOther.Controls.Add(this.label26);
            this.tabPageOther.Controls.Add(this.label31);
            this.tabPageOther.Controls.Add(this.label32);
            this.tabPageOther.Controls.Add(this.label33);
            this.tabPageOther.Controls.Add(this.label34);
            this.tabPageOther.Controls.Add(this.label35);
            this.tabPageOther.Controls.Add(this.textBSpatOth);
            this.tabPageOther.Controls.Add(this.textBCSOth);
            this.tabPageOther.Controls.Add(this.textBIVOth);
            this.tabPageOther.Controls.Add(this.textBPVOth);
            this.tabPageOther.Controls.Add(this.textBColourOth);
            this.tabPageOther.Controls.Add(this.textBFFAOth);
            this.tabPageOther.Controls.Add(this.textTSpatOth);
            this.tabPageOther.Controls.Add(this.textTCSOth);
            this.tabPageOther.Controls.Add(this.textTIVOth);
            this.tabPageOther.Controls.Add(this.textTPVOth);
            this.tabPageOther.Controls.Add(this.textTColourOth);
            this.tabPageOther.Controls.Add(this.textTFFAOth);
            this.tabPageOther.Controls.Add(this.labelBOth);
            this.tabPageOther.Controls.Add(this.labelTOth);
            this.tabPageOther.Controls.Add(this.labelParamOth);
            this.tabPageOther.Location = new Point(4, 0x16);
            this.tabPageOther.Name = "tabPageOther";
            this.tabPageOther.Padding = new Padding(3);
            this.tabPageOther.Size = new Size(640, 0xe4);
            this.tabPageOther.TabIndex = 1;
            this.tabPageOther.Text = "OTHER";
            this.label26.AutoSize = true;
            this.label26.Location = new Point(0x91, 0x33);
            this.label26.Name = "label26";
            this.label26.Size = new Size(0x1a, 0x1a);
            this.label26.TabIndex = 0x7f;
            this.label26.Text = "FFA\r\n(%)";
            this.label31.AutoSize = true;
            this.label31.Location = new Point(550, 0x33);
            this.label31.Name = "label31";
            this.label31.Size = new Size(0x29, 13);
            this.label31.TabIndex = 0x7e;
            this.label31.Text = "Spatter";
            this.label32.AutoSize = true;
            this.label32.Location = new Point(470, 0x33);
            this.label32.Name = "label32";
            this.label32.Size = new Size(0x43, 0x1a);
            this.label32.TabIndex = 0x7d;
            this.label32.Text = "Cold Stability\r\ntest";
            this.label33.AutoSize = true;
            this.label33.Location = new Point(0x184, 0x33);
            this.label33.Name = "label33";
            this.label33.Size = new Size(0x42, 0x1a);
            this.label33.TabIndex = 0x7c;
            this.label33.Text = "Iodine Value\r\n(g/100g)";
            this.label34.AutoSize = true;
            this.label34.Location = new Point(0x124, 0x33);
            this.label34.Name = "label34";
            this.label34.Size = new Size(50, 0x27);
            this.label34.TabIndex = 0x7b;
            this.label34.Text = "Peroxide\r\nvalue\r\n(meq/kg)";
            this.label35.AutoSize = true;
            this.label35.Location = new Point(0xcf, 0x33);
            this.label35.Name = "label35";
            this.label35.Size = new Size(0x3f, 0x1a);
            this.label35.TabIndex = 0x7a;
            this.label35.Text = "Colour\r\n(5 1/4\" cell)";
            this.textBSpatOth.Location = new Point(0x221, 0x90);
            this.textBSpatOth.Name = "textBSpatOth";
            this.textBSpatOth.Size = new Size(0x4a, 20);
            this.textBSpatOth.TabIndex = 120;
            this.textBSpatOth.Text = "0";
            this.textBSpatOth.TextAlign = HorizontalAlignment.Right;
            this.textBCSOth.Location = new Point(0x1cf, 0x90);
            this.textBCSOth.Name = "textBCSOth";
            this.textBCSOth.Size = new Size(0x4a, 20);
            this.textBCSOth.TabIndex = 0x77;
            this.textBCSOth.Text = "0";
            this.textBCSOth.TextAlign = HorizontalAlignment.Right;
            this.textBIVOth.Location = new Point(0x177, 0x90);
            this.textBIVOth.Name = "textBIVOth";
            this.textBIVOth.Size = new Size(0x4a, 20);
            this.textBIVOth.TabIndex = 0x76;
            this.textBIVOth.Text = "0";
            this.textBIVOth.TextAlign = HorizontalAlignment.Right;
            this.textBPVOth.Location = new Point(0x127, 0x90);
            this.textBPVOth.Name = "textBPVOth";
            this.textBPVOth.Size = new Size(0x4a, 20);
            this.textBPVOth.TabIndex = 0x75;
            this.textBPVOth.Text = "0";
            this.textBPVOth.TextAlign = HorizontalAlignment.Right;
            this.textBColourOth.Location = new Point(210, 0x90);
            this.textBColourOth.Name = "textBColourOth";
            this.textBColourOth.Size = new Size(0x4a, 20);
            this.textBColourOth.TabIndex = 0x74;
            this.textBColourOth.Text = "0";
            this.textBColourOth.TextAlign = HorizontalAlignment.Right;
            this.textBFFAOth.Location = new Point(130, 0x90);
            this.textBFFAOth.Name = "textBFFAOth";
            this.textBFFAOth.Size = new Size(0x4a, 20);
            this.textBFFAOth.TabIndex = 0x73;
            this.textBFFAOth.Text = "0";
            this.textBFFAOth.TextAlign = HorizontalAlignment.Right;
            this.textTSpatOth.Location = new Point(0x221, 0x69);
            this.textTSpatOth.Name = "textTSpatOth";
            this.textTSpatOth.Size = new Size(0x4a, 20);
            this.textTSpatOth.TabIndex = 0x72;
            this.textTSpatOth.Text = "0";
            this.textTSpatOth.TextAlign = HorizontalAlignment.Right;
            this.textTCSOth.Location = new Point(0x1cf, 0x69);
            this.textTCSOth.Name = "textTCSOth";
            this.textTCSOth.Size = new Size(0x4a, 20);
            this.textTCSOth.TabIndex = 0x71;
            this.textTCSOth.Text = "0";
            this.textTCSOth.TextAlign = HorizontalAlignment.Right;
            this.textTIVOth.Location = new Point(0x177, 0x69);
            this.textTIVOth.Name = "textTIVOth";
            this.textTIVOth.Size = new Size(0x4a, 20);
            this.textTIVOth.TabIndex = 0x70;
            this.textTIVOth.Text = "0";
            this.textTIVOth.TextAlign = HorizontalAlignment.Right;
            this.textTPVOth.Location = new Point(0x127, 0x69);
            this.textTPVOth.Name = "textTPVOth";
            this.textTPVOth.Size = new Size(0x4a, 20);
            this.textTPVOth.TabIndex = 0x6f;
            this.textTPVOth.Text = "0";
            this.textTPVOth.TextAlign = HorizontalAlignment.Right;
            this.textTColourOth.Location = new Point(210, 0x69);
            this.textTColourOth.Name = "textTColourOth";
            this.textTColourOth.Size = new Size(0x4a, 20);
            this.textTColourOth.TabIndex = 110;
            this.textTColourOth.Text = "0";
            this.textTColourOth.TextAlign = HorizontalAlignment.Right;
            this.textTFFAOth.Location = new Point(130, 0x69);
            this.textTFFAOth.Name = "textTFFAOth";
            this.textTFFAOth.Size = new Size(0x4a, 20);
            this.textTFFAOth.TabIndex = 0x6d;
            this.textTFFAOth.Text = "0";
            this.textTFFAOth.TextAlign = HorizontalAlignment.Right;
            this.labelBOth.AutoSize = true;
            this.labelBOth.Location = new Point(0x19, 0x93);
            this.labelBOth.Name = "labelBOth";
            this.labelBOth.Size = new Size(0x4e, 13);
            this.labelBOth.TabIndex = 0x66;
            this.labelBOth.Text = "Bottom Sample";
            this.labelTOth.AutoSize = true;
            this.labelTOth.Location = new Point(0x1b, 0x6c);
            this.labelTOth.Name = "labelTOth";
            this.labelTOth.Size = new Size(0x40, 13);
            this.labelTOth.TabIndex = 0x65;
            this.labelTOth.Text = "Top Sample";
            this.labelParamOth.AutoSize = true;
            this.labelParamOth.Location = new Point(0x16, 0x40);
            this.labelParamOth.Name = "labelParamOth";
            this.labelParamOth.Size = new Size(60, 13);
            this.labelParamOth.TabIndex = 100;
            this.labelParamOth.Text = "Parametres";
            this.tabPagePK.BackColor = SystemColors.ButtonFace;
            this.tabPagePK.Controls.Add(this.buttonPrintPK);
            this.tabPagePK.Controls.Add(this.label27);
            this.tabPagePK.Controls.Add(this.label25);
            this.tabPagePK.Controls.Add(this.label1);
            this.tabPagePK.Controls.Add(this.label15);
            this.tabPagePK.Controls.Add(this.label16);
            this.tabPagePK.Controls.Add(this.label17);
            this.tabPagePK.Controls.Add(this.label18);
            this.tabPagePK.Controls.Add(this.label19);
            this.tabPagePK.Controls.Add(this.label20);
            this.tabPagePK.Controls.Add(this.label21);
            this.tabPagePK.Controls.Add(this.label23);
            this.tabPagePK.Controls.Add(this.label24);
            this.tabPagePK.Controls.Add(this.textBIVPK);
            this.tabPagePK.Controls.Add(this.textBColourPK);
            this.tabPagePK.Controls.Add(this.textBDobiPK);
            this.tabPagePK.Controls.Add(this.textBDSPK);
            this.tabPagePK.Controls.Add(this.textBMIPK);
            this.tabPagePK.Controls.Add(this.textBFFAPK);
            this.tabPagePK.Controls.Add(this.textTIVPK);
            this.tabPagePK.Controls.Add(this.textTColourPK);
            this.tabPagePK.Controls.Add(this.textTDobiPK);
            this.tabPagePK.Controls.Add(this.textTDSPK);
            this.tabPagePK.Controls.Add(this.textTMIPK);
            this.tabPagePK.Controls.Add(this.textTFFAPK);
            this.tabPagePK.Controls.Add(this.labelBPK);
            this.tabPagePK.Controls.Add(this.labelTPK);
            this.tabPagePK.Controls.Add(this.labelSpecPK);
            this.tabPagePK.Controls.Add(this.label4);
            this.tabPagePK.Location = new Point(4, 0x16);
            this.tabPagePK.Name = "tabPagePK";
            this.tabPagePK.Padding = new Padding(3);
            this.tabPagePK.Size = new Size(640, 0xe4);
            this.tabPagePK.TabIndex = 2;
            this.tabPagePK.Text = "PK";
            this.buttonPrintPK.Location = new Point(0x1f6, 0xc2);
            this.buttonPrintPK.Name = "buttonPrintPK";
            this.buttonPrintPK.Size = new Size(0x6f, 0x1f);
            this.buttonPrintPK.TabIndex = 0x81;
            this.buttonPrintPK.Text = "&Print PK Report";
            this.buttonPrintPK.UseVisualStyleBackColor = true;
            this.buttonPrintPK.Click += new EventHandler(this.buttonPrintPK_Click);
            this.label27.AutoSize = true;
            this.label27.Location = new Point(0x98, 0x2c);
            this.label27.Name = "label27";
            this.label27.Size = new Size(0x1a, 0x1a);
            this.label27.TabIndex = 0x80;
            this.label27.Text = "FFA\r\n(%)";
            this.label25.AutoSize = true;
            this.label25.Location = new Point(0x18b, 0x2c);
            this.label25.Name = "label25";
            this.label25.Size = new Size(0x1d, 13);
            this.label25.TabIndex = 0x4d;
            this.label25.Text = "Dobi";
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x88, 0x4e);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x4b, 0x1a);
            this.label1.TabIndex = 0x60;
            this.label1.Text = "5.5% max\r\n (as oleic acid)\r\n";
            this.label15.AutoSize = true;
            this.label15.Location = new Point(0xe1, 0x5b);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x34, 13);
            this.label15.TabIndex = 0x5f;
            this.label15.Text = "0.2% max";
            this.label16.AutoSize = true;
            this.label16.Location = new Point(300, 0x4e);
            this.label16.Name = "label16";
            this.label16.Size = new Size(30, 13);
            this.label16.TabIndex = 0x5e;
            this.label16.Text = "< 6%";
            this.label17.AutoSize = true;
            this.label17.Location = new Point(0x18b, 0x4e);
            this.label17.Name = "label17";
            this.label17.Size = new Size(0x26, 13);
            this.label17.TabIndex = 0x5d;
            this.label17.Text = "2 (min)";
            this.label18.AutoSize = true;
            this.label18.Location = new Point(480, 0x4e);
            this.label18.Name = "label18";
            this.label18.Size = new Size(0x33, 13);
            this.label18.TabIndex = 0x5c;
            this.label18.Text = "10 - 12 R";
            this.label19.AutoSize = true;
            this.label19.Location = new Point(0x22e, 0x4e);
            this.label19.Name = "label19";
            this.label19.Size = new Size(0x41, 0x1a);
            this.label19.TabIndex = 0x5b;
            this.label19.Text = "51-54 (CPO)\r\n55-58 (CPL)\r\n";
            this.label20.AutoSize = true;
            this.label20.Location = new Point(0x22d, 0x2c);
            this.label20.Name = "label20";
            this.label20.Size = new Size(0x42, 0x1a);
            this.label20.TabIndex = 90;
            this.label20.Text = "Iodine Value\r\n(g/100g)";
            this.label21.AutoSize = true;
            this.label21.Location = new Point(0x1dd, 0x2c);
            this.label21.Name = "label21";
            this.label21.Size = new Size(0x36, 0x1a);
            this.label21.TabIndex = 0x59;
            this.label21.Text = "Colour\r\n(1/4\" cell)";
            this.label23.AutoSize = true;
            this.label23.Location = new Point(0x12b, 0x2c);
            this.label23.Name = "label23";
            this.label23.Size = new Size(0x3a, 13);
            this.label23.TabIndex = 0x57;
            this.label23.Text = "Dirt && Shell";
            this.label24.AutoSize = true;
            this.label24.Location = new Point(0xd6, 0x2c);
            this.label24.Name = "label24";
            this.label24.Size = new Size(0x37, 0x27);
            this.label24.TabIndex = 0x56;
            this.label24.Text = "Moistures &\r\n Impurities\r\n(%)";
            this.textBIVPK.Location = new Point(0x21b, 0xa5);
            this.textBIVPK.Name = "textBIVPK";
            this.textBIVPK.Size = new Size(0x4a, 20);
            this.textBIVPK.TabIndex = 0x47;
            this.textBIVPK.Text = "0";
            this.textBIVPK.TextAlign = HorizontalAlignment.Right;
            this.textBColourPK.Location = new Point(0x1c9, 0xa5);
            this.textBColourPK.Name = "textBColourPK";
            this.textBColourPK.Size = new Size(0x4a, 20);
            this.textBColourPK.TabIndex = 70;
            this.textBColourPK.Text = "0";
            this.textBColourPK.TextAlign = HorizontalAlignment.Right;
            this.textBDobiPK.Location = new Point(0x171, 0xa5);
            this.textBDobiPK.Name = "textBDobiPK";
            this.textBDobiPK.Size = new Size(0x4a, 20);
            this.textBDobiPK.TabIndex = 0x45;
            this.textBDobiPK.Text = "0";
            this.textBDobiPK.TextAlign = HorizontalAlignment.Right;
            this.textBDSPK.Location = new Point(0x121, 0xa5);
            this.textBDSPK.Name = "textBDSPK";
            this.textBDSPK.Size = new Size(0x4a, 20);
            this.textBDSPK.TabIndex = 0x44;
            this.textBDSPK.Text = "0";
            this.textBDSPK.TextAlign = HorizontalAlignment.Right;
            this.textBMIPK.Location = new Point(0xcc, 0xa5);
            this.textBMIPK.Name = "textBMIPK";
            this.textBMIPK.Size = new Size(0x4a, 20);
            this.textBMIPK.TabIndex = 0x43;
            this.textBMIPK.Text = "0";
            this.textBMIPK.TextAlign = HorizontalAlignment.Right;
            this.textBFFAPK.Location = new Point(0x7c, 0xa5);
            this.textBFFAPK.Name = "textBFFAPK";
            this.textBFFAPK.Size = new Size(0x4a, 20);
            this.textBFFAPK.TabIndex = 0x42;
            this.textBFFAPK.Text = "0";
            this.textBFFAPK.TextAlign = HorizontalAlignment.Right;
            this.textTIVPK.Location = new Point(0x21b, 0x7e);
            this.textTIVPK.Name = "textTIVPK";
            this.textTIVPK.Size = new Size(0x4a, 20);
            this.textTIVPK.TabIndex = 0x41;
            this.textTIVPK.Text = "0";
            this.textTIVPK.TextAlign = HorizontalAlignment.Right;
            this.textTColourPK.Location = new Point(0x1c9, 0x7e);
            this.textTColourPK.Name = "textTColourPK";
            this.textTColourPK.Size = new Size(0x4a, 20);
            this.textTColourPK.TabIndex = 0x40;
            this.textTColourPK.Text = "0";
            this.textTColourPK.TextAlign = HorizontalAlignment.Right;
            this.textTDobiPK.Location = new Point(0x171, 0x7e);
            this.textTDobiPK.Name = "textTDobiPK";
            this.textTDobiPK.Size = new Size(0x4a, 20);
            this.textTDobiPK.TabIndex = 0x3f;
            this.textTDobiPK.Text = "0";
            this.textTDobiPK.TextAlign = HorizontalAlignment.Right;
            this.textTDSPK.Location = new Point(0x121, 0x7e);
            this.textTDSPK.Name = "textTDSPK";
            this.textTDSPK.Size = new Size(0x4a, 20);
            this.textTDSPK.TabIndex = 0x3e;
            this.textTDSPK.Text = "0";
            this.textTDSPK.TextAlign = HorizontalAlignment.Right;
            this.textTMIPK.Location = new Point(0xcc, 0x7e);
            this.textTMIPK.Name = "textTMIPK";
            this.textTMIPK.Size = new Size(0x4a, 20);
            this.textTMIPK.TabIndex = 0x3d;
            this.textTMIPK.Text = "0";
            this.textTMIPK.TextAlign = HorizontalAlignment.Right;
            this.textTFFAPK.Location = new Point(0x7c, 0x7e);
            this.textTFFAPK.Name = "textTFFAPK";
            this.textTFFAPK.Size = new Size(0x4a, 20);
            this.textTFFAPK.TabIndex = 60;
            this.textTFFAPK.Text = "0";
            this.textTFFAPK.TextAlign = HorizontalAlignment.Right;
            this.labelBPK.AutoSize = true;
            this.labelBPK.Location = new Point(0x13, 0xa8);
            this.labelBPK.Name = "labelBPK";
            this.labelBPK.Size = new Size(0x4e, 13);
            this.labelBPK.TabIndex = 0x2f;
            this.labelBPK.Text = "Bottom Sample";
            this.labelTPK.AutoSize = true;
            this.labelTPK.Location = new Point(0x15, 0x81);
            this.labelTPK.Name = "labelTPK";
            this.labelTPK.Size = new Size(0x40, 13);
            this.labelTPK.TabIndex = 0x2e;
            this.labelTPK.Text = "Top Sample";
            this.labelSpecPK.AutoSize = true;
            this.labelSpecPK.Location = new Point(0x15, 0x4e);
            this.labelSpecPK.Name = "labelSpecPK";
            this.labelSpecPK.Size = new Size(0x44, 13);
            this.labelSpecPK.TabIndex = 0x2d;
            this.labelSpecPK.Text = "Specification";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0x13, 0x2c);
            this.label4.Name = "label4";
            this.label4.Size = new Size(60, 13);
            this.label4.TabIndex = 0x2c;
            this.label4.Text = "Parametres";
            this.tabPageComposite.BackColor = SystemColors.ButtonFace;
            this.tabPageComposite.Controls.Add(this.dgComposite);
            this.tabPageComposite.Controls.Add(this.panel1);
            this.tabPageComposite.Location = new Point(4, 0x16);
            this.tabPageComposite.Name = "tabPageComposite";
            this.tabPageComposite.Size = new Size(710, 0x1b0);
            this.tabPageComposite.TabIndex = 2;
            this.tabPageComposite.Text = "Composite";
            this.dgComposite.AllowUserToAddRows = false;
            this.dgComposite.AllowUserToDeleteRows = false;
            this.dgComposite.AllowUserToResizeRows = false;
            this.dgComposite.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgComposite.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgComposite.ColumnHeadersDefaultCellStyle = style;
            this.dgComposite.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgComposite.DefaultCellStyle = style2;
            this.dgComposite.Dock = DockStyle.Fill;
            this.dgComposite.EditMode = DataGridViewEditMode.EditOnKeystroke;
            this.dgComposite.Location = new Point(0, 0);
            this.dgComposite.MultiSelect = false;
            this.dgComposite.Name = "dgComposite";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgComposite.RowHeadersDefaultCellStyle = style3;
            this.dgComposite.SelectionMode = DataGridViewSelectionMode.CellSelect;
            this.dgComposite.Size = new Size(710, 0x14c);
            this.dgComposite.TabIndex = 4;
            this.dgComposite.CellEndEdit += new DataGridViewCellEventHandler(this.dgComposite_CellEndEdit);
            this.panel1.Controls.Add(this.buttonSaveComposite);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x14c);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(710, 100);
            this.panel1.TabIndex = 1;
            this.buttonSaveComposite.Location = new Point(0x1d8, 0x33);
            this.buttonSaveComposite.Name = "buttonSaveComposite";
            this.buttonSaveComposite.Size = new Size(0x6f, 0x25);
            this.buttonSaveComposite.TabIndex = 0x2d;
            this.buttonSaveComposite.Text = "SAVE";
            this.buttonSaveComposite.UseVisualStyleBackColor = true;
            this.buttonSaveComposite.Click += new EventHandler(this.buttonSaveComposite_Click);
            this.labelVehicleNo.AutoSize = true;
            this.labelVehicleNo.Location = new Point(0x2c, 14);
            this.labelVehicleNo.Name = "labelVehicleNo";
            this.labelVehicleNo.Size = new Size(0x3e, 13);
            this.labelVehicleNo.TabIndex = 8;
            this.labelVehicleNo.Text = "Vehicle No.";
            this.labelMaterial.AutoSize = true;
            this.labelMaterial.Location = new Point(0x2c, 40);
            this.labelMaterial.Name = "labelMaterial";
            this.labelMaterial.Size = new Size(70, 13);
            this.labelMaterial.TabIndex = 9;
            this.labelMaterial.Text = "Comm. Name";
            this.labelShip.AutoSize = true;
            this.labelShip.Location = new Point(0x156, 40);
            this.labelShip.Name = "labelShip";
            this.labelShip.Size = new Size(0x1c, 13);
            this.labelShip.TabIndex = 10;
            this.labelShip.Text = "Ship";
            this.labelLoadingDate.AutoSize = true;
            this.labelLoadingDate.Location = new Point(0x153, 14);
            this.labelLoadingDate.Name = "labelLoadingDate";
            this.labelLoadingDate.Size = new Size(0x47, 13);
            this.labelLoadingDate.TabIndex = 11;
            this.labelLoadingDate.Text = "Loading Date";
            this.textVehicle.Location = new Point(0x7f, 11);
            this.textVehicle.Name = "textVehicle";
            this.textVehicle.ReadOnly = true;
            this.textVehicle.Size = new Size(0x9a, 20);
            this.textVehicle.TabIndex = 12;
            this.textCommName.Location = new Point(0x7f, 0x25);
            this.textCommName.Name = "textCommName";
            this.textCommName.ReadOnly = true;
            this.textCommName.Size = new Size(0x9a, 20);
            this.textCommName.TabIndex = 13;
            this.textShip.Location = new Point(0x19b, 0x25);
            this.textShip.Name = "textShip";
            this.textShip.Size = new Size(0xd0, 20);
            this.textShip.TabIndex = 14;
            this.dtLoadDate.Format = DateTimePickerFormat.Short;
            this.dtLoadDate.Location = new Point(0x19b, 11);
            this.dtLoadDate.Name = "dtLoadDate";
            this.dtLoadDate.Size = new Size(0x66, 20);
            this.dtLoadDate.TabIndex = 15;
            this.panelAtas.BorderStyle = BorderStyle.Fixed3D;
            this.panelAtas.Controls.Add(this.dtLoadDate);
            this.panelAtas.Controls.Add(this.textShip);
            this.panelAtas.Controls.Add(this.textCommName);
            this.panelAtas.Controls.Add(this.textVehicle);
            this.panelAtas.Controls.Add(this.labelLoadingDate);
            this.panelAtas.Controls.Add(this.labelShip);
            this.panelAtas.Controls.Add(this.labelMaterial);
            this.panelAtas.Controls.Add(this.labelVehicleNo);
            this.panelAtas.Dock = DockStyle.Top;
            this.panelAtas.Location = new Point(0, 0);
            this.panelAtas.Name = "panelAtas";
            this.panelAtas.Size = new Size(0x2d2, 0x4b);
            this.panelAtas.TabIndex = 0;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x2d2, 0x24b);
            base.ControlBox = false;
            base.Controls.Add(this.panelTengah);
            base.Controls.Add(this.panelBawah);
            base.Controls.Add(this.panelAtas);
            base.Name = "FormConsignmentAfrica";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "FormConsignment";
            base.Load += new EventHandler(this.FormConsignment_Load);
            this.panelBawah.ResumeLayout(false);
            this.panelTengah.ResumeLayout(false);
            this.tabControlQuality.ResumeLayout(false);
            this.tabPageConsigment.ResumeLayout(false);
            this.tabPageConsigment.PerformLayout();
            this.tabPageLab.ResumeLayout(false);
            this.tabPageLab.PerformLayout();
            this.tabLab.ResumeLayout(false);
            this.tabPageCPO.ResumeLayout(false);
            this.tabPageCPO.PerformLayout();
            this.tabPageOther.ResumeLayout(false);
            this.tabPageOther.PerformLayout();
            this.tabPagePK.ResumeLayout(false);
            this.tabPagePK.PerformLayout();
            this.tabPageComposite.ResumeLayout(false);
            ((ISupportInitialize) this.dgComposite).EndInit();
            this.panel1.ResumeLayout(false);
            this.panelAtas.ResumeLayout(false);
            this.panelAtas.PerformLayout();
            base.ResumeLayout(false);
        }

        private void panelBawah_Paint(object sender, PaintEventArgs e)
        {
        }

        private void printConLab(string refno)
        {
            FormRpt rpt = new FormRpt();
            ReportDocument cryRpt = new ReportDocument();
            ReportDocument document2 = new ReportDocument();
            try
            {
                if (WBData.sLanguage == "1")
                {
                    cryRpt.Load(Application.StartupPath.ToString() + @"\Report\ticketConLabFR.rpt");
                }
                else
                {
                    cryRpt.Load(Application.StartupPath.ToString() + @"\Report\ticketConLab.rpt");
                }
                cryRpt = Program.rptLogon(cryRpt);
                rpt.setReport(cryRpt);
            }
            catch
            {
                MessageBox.Show(Resource.Mes_316, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            string[] paramName = new string[2];
            string[] paramValue = new string[] { refno, WBData.sCoyName };
            paramName[0] = "ref";
            paramName[1] = "coyName";
            document2 = Program.setParam2(cryRpt, paramName, paramValue);
            rpt.setReport(document2);
            rpt.ShowDialog();
            if (rpt.doPrint)
            {
                document2.PrintToPrinter(1, true, 0, 0);
            }
            rpt.Dispose();
            cryRpt.Dispose();
        }

        private void printConPK(string refno)
        {
            FormRpt rpt = new FormRpt();
            ReportDocument cryRpt = new ReportDocument();
            ReportDocument document2 = new ReportDocument();
            try
            {
                if (WBData.sLanguage == "1")
                {
                    cryRpt.Load(Application.StartupPath.ToString() + @"\Report\ticketConPKFR.rpt");
                }
                else
                {
                    cryRpt.Load(Application.StartupPath.ToString() + @"\Report\ticketConPK.rpt");
                }
                cryRpt = Program.rptLogon(cryRpt);
                rpt.setReport(cryRpt);
            }
            catch
            {
                MessageBox.Show(Resource.Mes_316, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            string[] paramName = new string[2];
            string[] paramValue = new string[] { refno, WBData.sCoyName };
            paramName[0] = "ref";
            paramName[1] = "coyName";
            document2 = Program.setParam2(cryRpt, paramName, paramValue);
            rpt.setReport(document2);
            rpt.ShowDialog();
            if (rpt.doPrint)
            {
                document2.PrintToPrinter(1, true, 0, 0);
            }
            rpt.Dispose();
            cryRpt.Dispose();
        }

        private void tabPageConsigment_Click(object sender, EventArgs e)
        {
        }

        private void textConDiesel_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textConWater_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textDips1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textDips1_TextChanged(object sender, EventArgs e)
        {
            this.HitCon();
        }

        private void textDips2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textDips2_TextChanged(object sender, EventArgs e)
        {
            this.HitCon();
        }

        private void textDips3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textDips3_TextChanged(object sender, EventArgs e)
        {
            this.HitCon();
        }

        private void textDips4_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textDips4_TextChanged(object sender, EventArgs e)
        {
            this.HitCon();
        }

        private void textDips5_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textDips5_TextChanged(object sender, EventArgs e)
        {
            this.HitCon();
        }

        private void textMSADips1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textMSADips1_TextChanged(object sender, EventArgs e)
        {
            this.HitCon();
        }

        private void textMSADips2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textMSADips2_TextChanged(object sender, EventArgs e)
        {
            this.HitCon();
        }

        private void textMSADips3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textMSADips3_TextChanged(object sender, EventArgs e)
        {
            this.HitCon();
        }

        private void textMSADips4_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textMSADips4_TextChanged(object sender, EventArgs e)
        {
            this.HitCon();
        }

        private void textMSADips5_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textMSADips5_TextChanged(object sender, EventArgs e)
        {
            this.HitCon();
        }

        private void translate()
        {
            this.labelVehicleNo.Text = Resource.Lab_001;
            this.labelMaterial.Text = Resource.Lab_002;
            this.labelLoadingDate.Text = Resource.Lab_003;
            this.labelShip.Text = Resource.Lab_004;
            this.tabPageConsigment.Text = Resource.Lab_005;
            this.tabPageLab.Text = Resource.Lab_006;
            this.tabPageComposite.Text = Resource.Lab_007;
            this.labelConComp1.Text = Resource.Lab_008;
            this.labelConComp2.Text = Resource.Lab_009;
            this.labelConComp3.Text = Resource.Lab_010;
            this.labelConComp4.Text = Resource.Lab_011;
            this.labelConComp5.Text = Resource.Lab_012;
            this.labelConCode.Text = Resource.Lab_013;
            this.labelConDips1.Text = Resource.Lab_014;
            this.labelConDips2.Text = Resource.Lab_015;
            this.labelConDiff.Text = Resource.Lab_016;
            this.labelWater.Text = Resource.Lab_017;
            this.labelWheel.Text = Resource.Lab_018;
            this.labelDiesel.Text = Resource.Lab_019;
            this.labelSpannerJack.Text = Resource.Lab_020;
            this.labelConCheckBy.Text = Resource.Lab_021;
            this.checkConPaper.Text = Resource.Lab_022;
            this.checkAllSeal.Text = Resource.Lab_023;
            this.labelConRemark.Text = Resource.Lab_024;
            this.tabPageCPO.Text = Resource.Lab_025;
            this.labelParam.Text = Resource.Lab_026;
            this.labelSpecPK.Text = Resource.Lab_027;
            this.labelTSam.Text = Resource.Lab_028;
            this.labelBOth.Text = Resource.Lab_029;
            this.labelSmplLab.Text = Resource.Lab_030;
            this.labelSampeLab.Text = Resource.Lab_031;
            this.labelApprovedLab.Text = Resource.Lab_032;
            this.labelDocStatusLab.Text = Resource.Lab_033;
            this.buttonConSave.Text = Resource.DbConn_008;
            this.buttonSaveLab.Text = Resource.DbConn_008;
            this.buttonPrint.Text = Resource.Menu_016;
            this.buttonConClose.Text = Resource.ABW_011;
        }
    }
}

