﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;

    public class RepFFBVendorSummary : Form
    {
        private double unit;
        private double tunit;
        private double netSDHI;
        private double tnetSDHI;
        private double gross;
        private double tandan;
        private double ttandan;
        private double tarra;
        private double receive;
        private double receiveAVG;
        private double treceiveAVG;
        private double deduct;
        private double netto;
        private double tgross;
        private double treceive;
        private double ttarra;
        private double tnetto;
        private double tdeduct;
        private double avg;
        private double tavg;
        private double oercpo;
        private double toercpo;
        private double rvcpo;
        private double trvcpo;
        private double gunny;
        private double tgunny;
        private IContainer components = null;
        public Label labelRecNo;
        public Label labelProcess;
        public DateTimePicker monthCalendar1;
        public Label label5;
        public DateTimePicker monthCalendar2;
        public Button button2;
        public Button button1;
        private CheckBox cbGunny;
        public Label label3;
        private ComboBox comboCom;
        private GroupBox groupFType;
        private CheckBox checkR;
        private CheckBox checkK;
        private CheckBox checkS;
        private CheckBox checkB;
        private CheckBox checkM;
        public GroupBox grType;
        private RadioButton rboAll;
        public RadioButton rboGI;
        public RadioButton rboGR;
        public GroupBox groupBox2;
        public Label label8;
        public Label label9;

        public RepFFBVendorSummary()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.comboCom.Text.Trim() == "")
            {
                MessageBox.Show("Please choose commodity!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.comboCom.Focus();
            }
            else
            {
                int index = 0;
                string[] source = new string[5];
                foreach (Control control in this.groupFType.Controls)
                {
                    CheckBox box = control as CheckBox;
                    if ((box != null) && box.Checked)
                    {
                        source[index] = box.Text;
                        index++;
                    }
                }
                this.labelProcess.Visible = true;
                this.labelRecNo.Visible = true;
                this.labelProcess.Refresh();
                this.labelRecNo.Refresh();
                HTML rep = new HTML();
                rep.File = rep.File + @"\" + WBUser.UserID + "_VENDOR SUMMARY REPORT FFB.htm";
                rep.Title = "VENDOR SUMMARY REPORT";
                rep.Open();
                rep.Write(rep.Style());
                rep.Write("<br><font size=5><b>VENDOR SUMMARY REPORT</b></font><br>");
                string[] textArray1 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                rep.Write(string.Concat(textArray1));
                string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                rep.Write(string.Concat(textArray2));
                if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                {
                    rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                {
                    rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                }
                if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                {
                    rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                }
                rep.Write("<br><br>");
                string str = Program.getFieldValue("wb_commodity", "Comm_Name", "comm_code", this.comboCom.Text);
                rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                rep.Write("<tr class=bd>");
                rep.Write("<td>Commodity</td>");
                string[] textArray3 = new string[] { "<td>: <b>", this.comboCom.Text.Trim(), " - ", str, "</b></td>" };
                rep.Write(string.Concat(textArray3));
                rep.Write("</tr>");
                rep.Write("<tr class=bd>");
                rep.Write("<td>Selected Date</td>");
                string[] textArray4 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                rep.Write(string.Concat(textArray4));
                rep.Write("</tr>");
                rep.Write("<tr class=bd>");
                rep.Write("<td>Report Date</td>");
                rep.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                rep.Write("</tr>");
                rep.Write("</table>");
                rep.Write("<br/><br/><br/>");
                WBTable table = new WBTable();
                DateTime time3 = this.monthCalendar2.Value;
                DateTime time6 = this.monthCalendar2.Value;
                string sqltext = ((("Select * from VW_TRANS where " + WBData.CompanyLocation(" and ((report_Date>='" + time3.ToString("yyyy/MM/01") + " 00:00:00'")) + " and report_Date<='" + time6.ToString("yyyy/MM/dd") + " 00:00:00'))") + " and (deleted is null or deleted = 'N') " + " and (Report_Date is not null) ") + " and (comm_code = '" + this.comboCom.Text.Trim() + "')";
                if (this.rboGI.Checked)
                {
                    sqltext = sqltext + " and IO = 'O' ";
                }
                else if (this.rboGR.Checked)
                {
                    sqltext = sqltext + " and IO = 'I' ";
                }
                if (index <= 0)
                {
                    sqltext = sqltext + " and (Fruits_type = '' or Fruits_type is null) ";
                }
                else
                {
                    int num6 = 0;
                    while (true)
                    {
                        if (num6 >= source.Count<string>())
                        {
                            sqltext = sqltext + " ) ";
                            break;
                        }
                        if (source[num6] != "")
                        {
                            sqltext = (num6 != 0) ? (sqltext + " or Fruits_type = '" + source[num6] + "' ") : (sqltext + " and ( Fruits_type = '" + source[num6] + "' ");
                        }
                        num6++;
                    }
                }
                sqltext = sqltext + " order by Relation_code,ref ";
                table.OpenTable("vw_trans", sqltext, WBData.conn);
                string str3 = "";
                string pStr = "";
                int num3 = 0;
                double count = 0.0;
                count = table.DT.Rows.Count;
                this.gross = 0.0;
                this.netto = 0.0;
                this.tarra = 0.0;
                this.receive = 0.0;
                this.deduct = 0.0;
                this.gunny = 0.0;
                this.tgunny = 0.0;
                this.tgross = 0.0;
                this.tnetto = 0.0;
                this.ttarra = 0.0;
                this.treceive = 0.0;
                this.tdeduct = 0.0;
                this.tandan = 0.0;
                this.tunit = 0.0;
                this.ttandan = 0.0;
                this.rvcpo = 0.0;
                this.toercpo = 0.0;
                this.trvcpo = 0.0;
                this.oercpo = 0.0;
                this.avg = 0.0;
                this.tavg = 0.0;
                this.unit = 0.0;
                this.netSDHI = 0.0;
                this.tnetSDHI = 0.0;
                if (!(count != 0.0))
                {
                    MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    int num7;
                    table.DR = table.DT.Rows[0];
                    str3 = table.DR["Relation_Code"].ToString();
                    pStr = Program.getFieldValue("wb_relation", "Relation_Name", "relation_code", str3.Trim());
                    rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                    this.initHeader(rep);
                    int num5 = 0;
                    foreach (DataRow row in table.DT.Rows)
                    {
                        num7 = num5;
                        num5 = num7 + 1;
                        this.labelRecNo.Text = num7.ToString() + " / " + count.ToString();
                        this.labelRecNo.Refresh();
                        time3 = Convert.ToDateTime(row["report_date"].ToString());
                        DateTime time4 = Convert.ToDateTime(this.monthCalendar1.Value.ToShortDateString() + " 00:00:00");
                        DateTime time5 = Convert.ToDateTime(this.monthCalendar2.Value.ToShortDateString() + " 00:00:00");
                        if (row["relation_code"].ToString() != str3)
                        {
                            if (this.unit > 0.0)
                            {
                                num3++;
                                rep.Write("<tr class='bd'>");
                                rep.Write("<td align=right>" + rep.strq(num3.ToString()) + "</td>");
                                rep.Write("<td align=left>" + rep.strq(pStr) + "</td>");
                                rep.Write("<td align=right>" + this.unit + "</td>");
                                if (this.tandan > 0.0)
                                {
                                    rep.Write("<td align=right>" + rep.strq($"{this.receiveAVG / this.tandan:N2}") + "</td>");
                                }
                                else
                                {
                                    rep.Write("<td align=right>0</td>");
                                }
                                this.rvcpo = (this.oercpo * 100.0) / this.netto;
                                rep.Write("<td align=center>" + rep.strq($"{this.rvcpo:N2}") + "</td>");
                                rep.Write("<td align=right>" + rep.strq($"{this.gross:N0}") + "</td>");
                                rep.Write("<td align=right>" + rep.strq($"{this.tarra:N0}") + "</td>");
                                rep.Write("<td align=right>" + rep.strq($"{this.receive:N0}") + "</td>");
                                this.gunny = Program.StrToDouble($"{this.gunny:N0}", 0);
                                this.deduct -= this.cbGunny.Checked ? this.gunny : 0.0;
                                rep.Write("<td align=right>" + rep.strq($"{this.deduct:N0}") + "</td>");
                                if (this.cbGunny.Checked)
                                {
                                    rep.Write("<td align=right>" + rep.strq($"{this.gunny:N0}") + "</td>");
                                }
                                rep.Write("<td align=right>" + rep.strq($"{this.netto:N0}") + "</td>");
                                rep.Write("<td align=right>" + rep.strq($"{this.netSDHI:N0}") + "</td>");
                                rep.Write("</tr>");
                            }
                            pStr = Program.getFieldValue("wb_relation", "Relation_Name", "relation_code", row["relation_code"].ToString().Trim());
                            this.gross = 0.0;
                            this.netto = 0.0;
                            this.tarra = 0.0;
                            this.receive = 0.0;
                            this.deduct = 0.0;
                            this.unit = 0.0;
                            this.oercpo = 0.0;
                            this.tandan = 0.0;
                            this.receiveAVG = 0.0;
                            this.netSDHI = 0.0;
                            this.gunny = 0.0;
                        }
                        if ((time3 >= time4) && (time3 <= time5))
                        {
                            this.unit++;
                            this.tunit++;
                            this.tandan += Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                            if (Program.StrToDouble(row["TotalBunch"].ToString(), 0) > 0.0)
                            {
                                this.receiveAVG += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                                this.treceiveAVG += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                            }
                            this.oercpo += (Program.StrToDouble(row["Rend_CPO"].ToString(), 2) * Program.StrToDouble(row["Netto"].ToString(), 2)) / 100.0;
                            this.toercpo += (Program.StrToDouble(row["Rend_CPO"].ToString(), 2) * Program.StrToDouble(row["Netto"].ToString(), 2)) / 100.0;
                            this.ttandan += Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                            this.gross += Program.StrToDouble(row["bruto"].ToString(), 0);
                            this.tarra += Program.StrToDouble(row["tarra"].ToString(), 0);
                            this.netto += Program.StrToDouble(row["netto"].ToString(), 0);
                            this.receive += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                            this.deduct += Program.StrToDouble(row["Deduction"].ToString(), 0);
                            this.tdeduct += Program.StrToDouble(row["Deduction"].ToString(), 0);
                            this.tgross += Program.StrToDouble(row["bruto"].ToString(), 0);
                            this.ttarra += Program.StrToDouble(row["tarra"].ToString(), 0);
                            this.tnetto += Program.StrToDouble(row["netto"].ToString(), 0);
                            this.treceive += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                            this.gunny += Program.StrToDouble(row["WeightPerUnitName"].ToString(), 2) * Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                            this.tgunny += Program.StrToDouble(row["WeightPerUnitName"].ToString(), 2) * Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                        }
                        this.tnetSDHI += Program.StrToDouble(row["Netto"].ToString(), 0);
                        this.netSDHI += Program.StrToDouble(row["Netto"].ToString(), 0);
                    }
                    num7 = num5;
                    num5 = num7 + 1;
                    this.labelRecNo.Text = num7.ToString() + " / " + count.ToString();
                    this.labelRecNo.Refresh();
                    num3++;
                    rep.Write("<tr class='bd'>");
                    rep.Write("<td align=right>" + rep.strq(num3.ToString()) + "</td>");
                    rep.Write("<td align=left>" + rep.strq(pStr) + "</td>");
                    rep.Write("<td align=right>" + this.unit + "</td>");
                    if (this.tandan > 0.0)
                    {
                        rep.Write("<td align=right>" + rep.strq($"{this.receiveAVG / this.tandan:N2}") + "</td>");
                    }
                    else
                    {
                        rep.Write("<td align=right>0</td>");
                    }
                    this.rvcpo = (this.oercpo * 100.0) / this.netto;
                    rep.Write("<td align=center>" + rep.strq($"{this.rvcpo:N2}") + "</td>");
                    rep.Write("<td align=right>" + rep.strq($"{this.gross:N0}") + "</td>");
                    rep.Write("<td align=right>" + rep.strq($"{this.tarra:N0}") + "</td>");
                    rep.Write("<td align=right>" + rep.strq($"{this.receive:N0}") + "</td>");
                    this.gunny = Program.StrToDouble($"{this.gunny:N0}", 0);
                    this.deduct -= this.cbGunny.Checked ? this.gunny : 0.0;
                    rep.Write("<td align=right>" + rep.strq($"{this.deduct:N0}") + "</td>");
                    if (this.cbGunny.Checked)
                    {
                        rep.Write("<td align=right>" + rep.strq($"{this.gunny:N0}") + "</td>");
                    }
                    rep.Write("<td align=right>" + rep.strq($"{this.netto:N0}") + "</td>");
                    rep.Write("<td align=right>" + rep.strq($"{this.netSDHI:N0}") + "</td>");
                    rep.Write("</tr>");
                    rep.Write("<tr class='bd'>");
                    rep.Write("<td colspan=2 align=CENTER><b>TOTAL</b></td>");
                    rep.Write("<td align=right><b>" + this.tunit + "</b></td>");
                    if (this.ttandan > 0.0)
                    {
                        rep.Write("<td align=right><b>" + rep.strq($"{this.treceiveAVG / this.ttandan:N2}") + "</b></td>");
                    }
                    else
                    {
                        rep.Write("<td align=right>0</td>");
                    }
                    this.rvcpo = (this.toercpo * 100.0) / this.tnetto;
                    rep.Write("<td align=center><b>" + rep.strq($"{this.rvcpo:N2}") + "</b></td>");
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tgross:N0}") + "</b></td>");
                    rep.Write("<td align=right><b>" + rep.strq($"{this.ttarra:N0}") + "</b></td>");
                    rep.Write("<td align=right><b>" + rep.strq($"{this.treceive:N0}") + "</b></td>");
                    this.tgunny = Program.StrToDouble($"{this.tgunny:N0}", 0);
                    this.tdeduct -= this.cbGunny.Checked ? Math.Round(this.tgunny) : 0.0;
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tdeduct:N0}") + "</b></td>");
                    if (this.cbGunny.Checked)
                    {
                        rep.Write("<td align=right>" + rep.strq($"{this.tgunny:N0}") + "</td>");
                    }
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tnetto:N0}") + "</b></td>");
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tnetSDHI:N0}") + "</b></td>");
                    rep.Write("</tr>");
                    rep.Write("</table>");
                    rep.Write("<br><br><br>");
                    rep.writeSign();
                    rep.Close();
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + rep.File) }
                    };
                    report.ShowDialog();
                    rep.Dispose();
                    report.Dispose();
                    this.labelRecNo.Text = "0/0";
                    this.labelProcess.Visible = false;
                    this.labelRecNo.Visible = false;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void initHeader(HTML rep)
        {
            rep.Write("<tr class='bd'>");
            rep.Write("<td align=center><b>No</b></td>");
            rep.Write("<td align=center><b>Relation</b></td>");
            rep.Write("<td align=center><b>Unit</b></td>");
            rep.Write("<td align=center><b>BJR</b></td>");
            rep.Write("<td align=center><b>RV.CPO</b></td>");
            rep.Write("<td align=center><b>Gross</b></td>");
            rep.Write("<td align=center><b>Tarra</b></td>");
            rep.Write("<td align=center><b>Received</b></td>");
            rep.Write("<td align=center><b>Deduction</b></td>");
            if (this.cbGunny.Checked)
            {
                rep.Write("<td align=center><b>Gunny</b></td>");
            }
            rep.Write("<td align=center><b>Netto</b></td>");
            rep.Write("<td align=center><b>Net u/ Today</b></td>");
            rep.Write("</tr>");
        }

        private void InitializeComponent()
        {
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.monthCalendar1 = new DateTimePicker();
            this.label5 = new Label();
            this.monthCalendar2 = new DateTimePicker();
            this.button2 = new Button();
            this.button1 = new Button();
            this.cbGunny = new CheckBox();
            this.label3 = new Label();
            this.comboCom = new ComboBox();
            this.groupFType = new GroupBox();
            this.checkR = new CheckBox();
            this.checkK = new CheckBox();
            this.checkS = new CheckBox();
            this.checkB = new CheckBox();
            this.checkM = new CheckBox();
            this.grType = new GroupBox();
            this.rboAll = new RadioButton();
            this.rboGI = new RadioButton();
            this.rboGR = new RadioButton();
            this.groupBox2 = new GroupBox();
            this.label8 = new Label();
            this.label9 = new Label();
            this.groupFType.SuspendLayout();
            this.grType.SuspendLayout();
            this.groupBox2.SuspendLayout();
            base.SuspendLayout();
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x1d5, 20);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 0x65;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x137, 20);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 100;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(60, 0x12);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0x62;
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(15, 15);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0xd9, 20);
            this.label5.TabIndex = 0x61;
            this.label5.Text = "Vendor Summary For FFB";
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0xd6, 0x12);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 0x66;
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1be, 0xc6);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x58, 0x20);
            this.button2.TabIndex = 0x70;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x160, 0xc6);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x58, 0x21);
            this.button1.TabIndex = 0x6f;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.cbGunny.AutoSize = true;
            this.cbGunny.Location = new Point(0x13, 0xd5);
            this.cbGunny.Name = "cbGunny";
            this.cbGunny.Size = new Size(0x99, 0x11);
            this.cbGunny.TabIndex = 0x71;
            this.cbGunny.Text = "Show Deduction by Gunny";
            this.cbGunny.UseVisualStyleBackColor = true;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x13, 0xb0);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x3a, 13);
            this.label3.TabIndex = 0x72;
            this.label3.Text = "Commodity";
            this.comboCom.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboCom.FormattingEnabled = true;
            this.comboCom.Location = new Point(0x5c, 0xad);
            this.comboCom.Name = "comboCom";
            this.comboCom.Size = new Size(0x92, 0x15);
            this.comboCom.TabIndex = 0x73;
            this.groupFType.Controls.Add(this.checkR);
            this.groupFType.Controls.Add(this.checkK);
            this.groupFType.Controls.Add(this.checkS);
            this.groupFType.Controls.Add(this.checkB);
            this.groupFType.Controls.Add(this.checkM);
            this.groupFType.Location = new Point(0x139, 0x39);
            this.groupFType.Name = "groupFType";
            this.groupFType.Size = new Size(220, 0x2d);
            this.groupFType.TabIndex = 160;
            this.groupFType.TabStop = false;
            this.groupFType.Text = "Fruit Type";
            this.checkR.AutoSize = true;
            this.checkR.Checked = true;
            this.checkR.CheckState = CheckState.Checked;
            this.checkR.Location = new Point(0xb0, 20);
            this.checkR.Name = "checkR";
            this.checkR.Size = new Size(0x22, 0x11);
            this.checkR.TabIndex = 4;
            this.checkR.Text = "R";
            this.checkR.UseVisualStyleBackColor = true;
            this.checkK.AutoSize = true;
            this.checkK.Checked = true;
            this.checkK.CheckState = CheckState.Checked;
            this.checkK.Location = new Point(0x89, 20);
            this.checkK.Name = "checkK";
            this.checkK.Size = new Size(0x21, 0x11);
            this.checkK.TabIndex = 3;
            this.checkK.Text = "K";
            this.checkK.UseVisualStyleBackColor = true;
            this.checkS.AutoSize = true;
            this.checkS.Checked = true;
            this.checkS.CheckState = CheckState.Checked;
            this.checkS.Location = new Point(0x62, 20);
            this.checkS.Name = "checkS";
            this.checkS.Size = new Size(0x21, 0x11);
            this.checkS.TabIndex = 2;
            this.checkS.Text = "S";
            this.checkS.UseVisualStyleBackColor = true;
            this.checkB.AutoSize = true;
            this.checkB.Checked = true;
            this.checkB.CheckState = CheckState.Checked;
            this.checkB.Location = new Point(0x3b, 20);
            this.checkB.Name = "checkB";
            this.checkB.Size = new Size(0x21, 0x11);
            this.checkB.TabIndex = 1;
            this.checkB.Text = "B";
            this.checkB.UseVisualStyleBackColor = true;
            this.checkM.AutoSize = true;
            this.checkM.Checked = true;
            this.checkM.CheckState = CheckState.Checked;
            this.checkM.Location = new Point(0x12, 20);
            this.checkM.Name = "checkM";
            this.checkM.Size = new Size(0x23, 0x11);
            this.checkM.TabIndex = 0;
            this.checkM.Text = "M";
            this.checkM.UseVisualStyleBackColor = true;
            this.grType.Controls.Add(this.rboAll);
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x13, 0x39);
            this.grType.Name = "grType";
            this.grType.Size = new Size(0x11a, 0x2d);
            this.grType.TabIndex = 0xa7;
            this.grType.TabStop = false;
            this.grType.Text = "Report Type";
            this.rboAll.AutoSize = true;
            this.rboAll.Checked = true;
            this.rboAll.Location = new Point(0x12, 0x12);
            this.rboAll.Name = "rboAll";
            this.rboAll.Size = new Size(0x24, 0x11);
            this.rboAll.TabIndex = 0x7c;
            this.rboAll.TabStop = true;
            this.rboAll.Text = "All";
            this.rboAll.UseVisualStyleBackColor = true;
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(0xba, 0x12);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 0x11;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.rboGR.AutoSize = true;
            this.rboGR.Location = new Point(0x49, 0x12);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0x10;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.monthCalendar1);
            this.groupBox2.Controls.Add(this.monthCalendar2);
            this.groupBox2.Location = new Point(0x13, 0x6c);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(0x15b, 0x30);
            this.groupBox2.TabIndex = 0xa8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Date";
            this.label8.AutoSize = true;
            this.label8.Location = new Point(0x15, 0x15);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x21, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "From:";
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0xb8, 0x15);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x17, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "To:";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x233, 0x101);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.grType);
            base.Controls.Add(this.groupFType);
            base.Controls.Add(this.comboCom);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.cbGunny);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.label5);
            base.Name = "RepFFBVendorSummary";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Report Vendor Summary TBS";
            base.Load += new EventHandler(this.RepFFBVendorSummary_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepFFBVendorSummary_KeyPress);
            this.groupFType.ResumeLayout(false);
            this.groupFType.PerformLayout();
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void RepFFBVendorSummary_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepFFBVendorSummary_Load(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" AND type='F'"), WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                this.comboCom.Items.Add(row["Comm_Code"].ToString());
            }
            table.Dispose();
        }
    }
}

