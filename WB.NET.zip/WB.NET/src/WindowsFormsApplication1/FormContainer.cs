﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormContainer : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pFind = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        private DataTable updTable = new DataTable();
        private DataTable retTable = new DataTable();
        private string[] zwbResult = new string[3];
        private string[] zwbRow = new string[0x12];
        private IContainer components = null;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem synchronizeAllToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem synchronizeToolStripMenuItem;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem viewToolStripMenuItem;
        private ToolStripMenuItem zWBToolStripMenuItem;
        private DataGridView dataGridView1;
        public ToolStripMenuItem closeToolStripMenuItem;
        public TextBox TextFind;
        private ToolStripMenuItem chooseToolStripMenuItem;
        public Panel panel1;
        private ProgressBar progressBar1;
        public Button buttonFind;
        public MenuStrip menuStrip1;

        public FormContainer()
        {
            this.InitializeComponent();
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormContainerEntry entry = new FormContainerEntry();
            this.ztable.BeforeEdit(this.dataGridView1, "ADD");
            entry.pMode = "ADD";
            entry.zTable = this.ztable;
            entry.Text = "Add New Record of Container Number";
            entry.dataGridView1 = this.dataGridView1;
            entry.ShowDialog();
            if (entry.saved)
            {
                this.ztable.ReOpen();
                this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                string[] aField = new string[] { "Container_Number" };
                string[] aFind = new string[] { entry.textContainer.Text };
                this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
            }
            this.ztable.UnLock();
            entry.Dispose();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void chooseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.CurrentRow.Cells["black_list"].Value.ToString() != "Y")
            {
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
                this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
                this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
                base.Close();
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseToolStripMenuItem.PerformClick();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dataGridView1.Rows[e.RowIndex].Cells["black_list"].Value.ToString() == "Y")
            {
                e.CellStyle.BackColor = Color.Red;
                e.CellStyle.SelectionBackColor = Color.HotPink;
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ztable.BeforeEdit(this.dataGridView1, "DELETE");
            this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
            string[] textArray1 = new string[] { this.ztable.DT.Rows[this.nCurrRow]["Container_Number"].ToString(), " - ", this.ztable.DT.Rows[this.nCurrRow]["Description"].ToString(), ".\n\n", Resource.Mes_006 };
            if (MessageBox.Show(string.Concat(textArray1), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = "Container No" },
                    textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Container_Number"].ToString() },
                    Text = "DELETE REASON",
                    label2 = { Text = "Delete Reason : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                    this.ztable.ReOpen();
                    this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                    this.ztable.DT.Rows[this.nCurrRow].Delete();
                    this.ztable.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                    Program.updateLogHeader("wb_container", this.logKey, logField, logValue);
                    this.ztable.ReOpen();
                    this.ztable.AfterEdit("DELETE");
                }
                else
                {
                    return;
                }
            }
            this.ztable.UnLock();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormContainerEntry entry = new FormContainerEntry();
            this.ztable.BeforeEdit(this.dataGridView1, "EDIT");
            entry.pMode = "EDIT";
            entry.zTable = this.ztable;
            entry.Text = "Edit Record of Container ";
            entry.dataGridView1 = this.dataGridView1;
            entry.ShowDialog();
            if (entry.saved)
            {
                this.ztable.ReOpen();
                this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
            }
            this.ztable.UnLock();
            entry.Dispose();
        }

        private void FormContainer_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormContainer_Load(object sender, EventArgs e)
        {
            int num = 0;
            while (true)
            {
                DataColumn column;
                if (num >= 0x12)
                {
                    column = new DataColumn {
                        ColumnName = "Ref1"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Stts2"
                    };
                    this.retTable.Columns.Add(column);
                    column = new DataColumn {
                        ColumnName = "Rmrk3"
                    };
                    this.retTable.Columns.Add(column);
                    column.Dispose();
                    this.progressBar1.Visible = false;
                    this.ztable.OpenTable("wb_Container", "SELECT * FROM wb_Container", WBData.conn);
                    this.dataGridView1.DataSource = this.ztable.DT;
                    this.dataGridView1.Sort(this.dataGridView1.Columns["Container_Number"], ListSortDirection.Ascending);
                    foreach (DataGridViewColumn column2 in this.dataGridView1.Columns)
                    {
                        column2.Visible = false;
                    }
                    this.dataGridView1.Columns["Container_Number"].Visible = true;
                    this.dataGridView1.Columns["Container_Number"].Width = 120;
                    this.dataGridView1.Columns["Description"].Visible = true;
                    this.dataGridView1.Columns["Black_List"].Visible = true;
                    this.dataGridView1.Columns["Reason"].Visible = true;
                    this.dataGridView1.Columns["Create_by"].Visible = true;
                    this.dataGridView1.Columns["Create_Date"].Visible = true;
                    this.dataGridView1.Columns["Change_by"].Visible = true;
                    this.dataGridView1.Columns["Change_Date"].Visible = true;
                    this.dataGridView1.Columns["Container_Number"].HeaderText = "Container Number";
                    this.dataGridView1.Columns["Black_List"].HeaderText = "Blacklist";
                    this.dataGridView1.Columns["Reason"].HeaderText = "Reason of Blacklist";
                    base.KeyPreview = true;
                    if (!WBUser.CheckTrustee("MD_CONTAINER", "A"))
                    {
                        this.addNewRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_CONTAINER", "E"))
                    {
                        this.editRecordToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_CONTAINER", "D"))
                    {
                        this.deleteToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_CONTAINER", "V"))
                    {
                        this.viewToolStripMenuItem.Enabled = false;
                    }
                    if (!WBUser.CheckTrustee("MD_SYNCH", "A"))
                    {
                        this.zWBToolStripMenuItem.Enabled = false;
                    }
                    if ((this.pMode != "") && (this.pFind.Trim() != ""))
                    {
                        this.TextFind.Text = this.pFind;
                        this.buttonFind.PerformClick();
                    }
                    this.chooseToolStripMenuItem.Visible = this.pMode != "";
                    return;
                }
                column = new DataColumn();
                this.updTable.Columns.Add(column);
                column.Dispose();
                num++;
            }
        }

        private void InitializeComponent()
        {
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeAllToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator1 = new ToolStripSeparator();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.synchronizeToolStripMenuItem = new ToolStripMenuItem();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.viewToolStripMenuItem = new ToolStripMenuItem();
            this.zWBToolStripMenuItem = new ToolStripMenuItem();
            this.dataGridView1 = new DataGridView();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.chooseToolStripMenuItem = new ToolStripMenuItem();
            this.panel1 = new Panel();
            this.progressBar1 = new ProgressBar();
            this.buttonFind = new Button();
            this.menuStrip1 = new MenuStrip();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            base.SuspendLayout();
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.synchronizeAllToolStripMenuItem.Name = "synchronizeAllToolStripMenuItem";
            this.synchronizeAllToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeAllToolStripMenuItem.Text = "Synchronize All";
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new Size(160, 6);
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.synchronizeToolStripMenuItem.Name = "synchronizeToolStripMenuItem";
            this.synchronizeToolStripMenuItem.Size = new Size(0x9b, 0x16);
            this.synchronizeToolStripMenuItem.Text = "Synchronize";
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem, this.viewToolStripMenuItem, this.toolStripSeparator1, this.zWBToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(toolStripItems);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewToolStripMenuItem.Text = "View";
            this.viewToolStripMenuItem.Click += new EventHandler(this.viewToolStripMenuItem_Click);
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.synchronizeToolStripMenuItem, this.synchronizeAllToolStripMenuItem };
            this.zWBToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.zWBToolStripMenuItem.Name = "zWBToolStripMenuItem";
            this.zWBToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.zWBToolStripMenuItem.Text = "ZWB";
            this.zWBToolStripMenuItem.Visible = false;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x305, 0x176);
            this.dataGridView1.TabIndex = 0x10;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.CellFormatting += new DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.TextFind.Location = new Point(5, 5);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.chooseToolStripMenuItem.Name = "chooseToolStripMenuItem";
            this.chooseToolStripMenuItem.Size = new Size(0x3b, 20);
            this.chooseToolStripMenuItem.Text = "Choose";
            this.chooseToolStripMenuItem.ToolTipText = "Choose this record & close this browser";
            this.chooseToolStripMenuItem.Click += new EventHandler(this.chooseToolStripMenuItem_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 0x18e);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x305, 0x21);
            this.panel1.TabIndex = 0x11;
            this.progressBar1.Location = new Point(0x25c, 8);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new Size(0xa6, 0x10);
            this.progressBar1.TabIndex = 0x10;
            this.buttonFind.Location = new Point(0xc3, 4);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] itemArray3 = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseToolStripMenuItem, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(itemArray3);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x305, 0x18);
            this.menuStrip1.TabIndex = 0x12;
            this.menuStrip1.Text = "menuStrip1";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x305, 0x1af);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.panel1);
            base.Controls.Add(this.menuStrip1);
            base.KeyPreview = true;
            base.Name = "FormContainer";
            this.Text = "List of Container ";
            base.Load += new EventHandler(this.FormContainer_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormContainer_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormContainerEntry entry = new FormContainerEntry();
            this.ztable.BeforeEdit(this.dataGridView1, "EDIT");
            entry.pMode = "VIEW";
            entry.zTable = this.ztable;
            entry.Text = "View Record of Container ";
            entry.dataGridView1 = this.dataGridView1;
            entry.ShowDialog();
        }
    }
}

