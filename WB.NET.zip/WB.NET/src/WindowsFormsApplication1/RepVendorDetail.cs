﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Text;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class RepVendorDetail : Form
    {
        public WBTable tblComm = new WBTable();
        public WBTable tblDO = new WBTable();
        public WBTable tblRelation = new WBTable();
        private double totalgross;
        private double totalnetto;
        private double totaltarra;
        private double totalreceive;
        private double totaldeduct;
        private double totalunit;
        private double totaloercpo;
        private double totaltandan;
        private double totalreceiveAVG;
        private double totalnetSDHI;
        private double unit;
        private double tunit;
        private double netSDHI;
        private double tnetSDHI;
        private double gross;
        private double tandan;
        private double ttandan;
        private double tarra;
        private double receive;
        private double receiveAVG;
        private double treceiveAVG;
        private double ReturInKg;
        private double ReturInPack;
        private double tReturInKg;
        private double tReturInPack;
        private double LossInKg;
        private double LossInPack;
        private double tLossInKg;
        private double tLossInPack;
        private double LoadingQty;
        private double tLoadingQty;
        private double deduct;
        private double netto;
        private double tgross;
        private double treceive;
        private double ttarra;
        private double tnetto;
        private double tdeduct;
        private double avg;
        private double tavg;
        private double oercpo;
        private double toercpo;
        private double rvcpo;
        private double trvcpo;
        private double grossDate;
        private double nettoDate;
        private double tarraDate;
        private double receiveDate;
        private double deductDate;
        private double unitDate;
        private double oercpoDate;
        private double tandanDate;
        private double receiveAVGDate;
        private double netSDHIDate;
        private double ReturInKgDate;
        private double ReturInPackDate;
        private double LossInKgDate;
        private double LossInPackDate;
        private double LoadingQtyDate;
        private double tmpgunny;
        private double gunny;
        private double gunnyDate;
        private double tgunny;
        private string Retur_masuk;
        private string Retur_keluar;
        private IContainer components = null;
        public Button buttonComm;
        public Label labelCommName;
        public TextBox textCommodity;
        public Label labelcommodity;
        public Label labelRecNo;
        public Label labelProcess;
        public Label label5;
        private LineShape lineShape1;
        private ShapeContainer shapeContainer1;
        public DateTimePicker monthCalendar2;
        public Label label2;
        public DateTimePicker monthCalendar1;
        public Label label1;
        public Button button3;
        public TextBox textDO;
        public Label label3;
        public Button buttonRelation;
        public Label label4;
        public TextBox textRelation;
        private GroupBox groupBox1;
        private RadioButton radioDO;
        private RadioButton radioDate;
        public Button button2;
        public Button buttonProcess;
        private GroupBox groupBox2;
        private RadioButton rbSNUT;
        private RadioButton rbDNS;
        private ShapeContainer shapeContainer2;
        private GroupBox gbDispOpt;
        private CheckBox cBoxReturInKg;
        private CheckBox cBoxReturInPack;
        private CheckBox cBoxLossInKg;
        private CheckBox cBoxLossInPack;
        private CheckBox cBoxLoadingQty;

        public RepVendorDetail()
        {
            this.InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFind = this.textDO.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDO.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE"
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textCommodity.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelCommName.Text = commodity.ReturnRow["Comm_Name"].ToString();
                this.textCommodity.Focus();
            }
            commodity.Dispose();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                this.labelProcess.Visible = true;
                this.labelRecNo.Visible = true;
                this.labelProcess.Refresh();
                this.labelRecNo.Refresh();
                this.printreport();
                this.labelProcess.Visible = false;
                this.labelRecNo.Visible = false;
                this.labelProcess.Text = "";
                this.labelRecNo.Text = "";
            }
        }

        private void buttonRelation_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textRelation.Text = vendor.ReturnRow["relation_code"].ToString();
            }
            vendor.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void initHeader(HTML rep)
        {
            rep.Write("<tr class='bd'>");
            rep.Write("<td align=center><b>No</b></td>");
            rep.Write("<td align=center width=200><b>Relation</b></td>");
            rep.Write("<td align=center width=200><b>Relation Name</b></td>");
            if (this.radioDO.Checked)
            {
                rep.Write("<td align=center width=250><b>DO/SO NO</b></td>");
            }
            rep.Write("<td align=center width=80><b>Gross</b></td>");
            rep.Write("<td align=center width=80><b>Tarra</b></td>");
            rep.Write("<td align=center width=80><b>Received</b></td>");
            rep.Write("<td align=center width=80><b>Deduction</b></td>");
            rep.Write("<td align=center width=80><b>Netto</b></td>");
            if (this.radioDO.Checked && this.rbSNUT.Checked)
            {
                rep.Write("<td align=center width=80><b>Net u/ Today</b></td>");
            }
            if (this.cBoxReturInKg.Checked)
            {
                rep.Write("<td align=center width=80><b>Return (Kg)</b></td>");
            }
            if (this.cBoxReturInPack.Checked)
            {
                rep.Write("<td align=center width=80><b>Return (Pack)</b></td>");
            }
            if (this.cBoxLossInKg.Checked)
            {
                rep.Write("<td align=center width=100><b>Loss(-)/Gain(+) (Kg)</b></td>");
            }
            if (this.cBoxLossInPack.Checked)
            {
                rep.Write("<td align=center width=100><b>Loss(-)/Gain(+) (Pack)</b></td>");
            }
            if (this.cBoxLoadingQty.Checked)
            {
                rep.Write("<td align=center width=100><b>Loading Qty</b></td>");
            }
            rep.Write("</tr>");
        }

        private void InitializeComponent()
        {
            this.buttonComm = new Button();
            this.labelCommName = new Label();
            this.textCommodity = new TextBox();
            this.labelcommodity = new Label();
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.label5 = new Label();
            this.lineShape1 = new LineShape();
            this.shapeContainer1 = new ShapeContainer();
            this.monthCalendar2 = new DateTimePicker();
            this.label2 = new Label();
            this.monthCalendar1 = new DateTimePicker();
            this.label1 = new Label();
            this.button3 = new Button();
            this.textDO = new TextBox();
            this.label3 = new Label();
            this.buttonRelation = new Button();
            this.label4 = new Label();
            this.textRelation = new TextBox();
            this.groupBox1 = new GroupBox();
            this.radioDO = new RadioButton();
            this.radioDate = new RadioButton();
            this.button2 = new Button();
            this.buttonProcess = new Button();
            this.groupBox2 = new GroupBox();
            this.rbSNUT = new RadioButton();
            this.rbDNS = new RadioButton();
            this.shapeContainer2 = new ShapeContainer();
            this.gbDispOpt = new GroupBox();
            this.cBoxLossInPack = new CheckBox();
            this.cBoxLossInKg = new CheckBox();
            this.cBoxReturInPack = new CheckBox();
            this.cBoxReturInKg = new CheckBox();
            this.cBoxLoadingQty = new CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbDispOpt.SuspendLayout();
            base.SuspendLayout();
            this.buttonComm.Location = new Point(0x115, 0x3a);
            this.buttonComm.Margin = new Padding(0);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x17, 0x17);
            this.buttonComm.TabIndex = 0x15;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.labelCommName.AutoSize = true;
            this.labelCommName.Location = new Point(0x12f, 0x3f);
            this.labelCommName.Name = "labelCommName";
            this.labelCommName.Size = new Size(0x3a, 13);
            this.labelCommName.TabIndex = 0x16;
            this.labelCommName.Text = "Commodity";
            this.textCommodity.CharacterCasing = CharacterCasing.Upper;
            this.textCommodity.Location = new Point(0x65, 0x3b);
            this.textCommodity.Name = "textCommodity";
            this.textCommodity.Size = new Size(0xad, 20);
            this.textCommodity.TabIndex = 0x10;
            this.textCommodity.Leave += new EventHandler(this.textCommodity_Leave);
            this.labelcommodity.AutoSize = true;
            this.labelcommodity.Location = new Point(0x24, 0x3f);
            this.labelcommodity.Name = "labelcommodity";
            this.labelcommodity.Size = new Size(0x3a, 13);
            this.labelcommodity.TabIndex = 0x12;
            this.labelcommodity.Text = "Commodity";
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x187, 0x18);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(60, 13);
            this.labelRecNo.TabIndex = 20;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.TextAlign = ContentAlignment.TopRight;
            this.labelRecNo.Visible = false;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x105, 0x18);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x7c, 13);
            this.labelProcess.TabIndex = 0x13;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(0x18, 0x18);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x70, 13);
            this.label5.TabIndex = 0x11;
            this.label5.Text = "Vendor Summary 2";
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 8;
            this.lineShape1.X2 = 0x1c5;
            this.lineShape1.Y1 = 0x2e;
            this.lineShape1.Y2 = 0x2e;
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Size = new Size(0x1db, 0x1ed);
            this.shapeContainer1.TabIndex = 0x17;
            this.shapeContainer1.TabStop = false;
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0x65, 0x6f);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x83, 20);
            this.monthCalendar2.TabIndex = 0x19;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x4a, 0x73);
            this.label2.Name = "label2";
            this.label2.Size = new Size(20, 13);
            this.label2.TabIndex = 0x1b;
            this.label2.Text = "To";
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x65, 0x55);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x83, 20);
            this.monthCalendar1.TabIndex = 0x18;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x40, 0x59);
            this.label1.Name = "label1";
            this.label1.Size = new Size(30, 13);
            this.label1.TabIndex = 0x1a;
            this.label1.Text = "From";
            this.button3.Location = new Point(0x115, 0x88);
            this.button3.Margin = new Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x17, 0x17);
            this.button3.TabIndex = 30;
            this.button3.Text = "...";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.textDO.CharacterCasing = CharacterCasing.Upper;
            this.textDO.Location = new Point(0x65, 0x89);
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0xad, 20);
            this.textDO.TabIndex = 0x1c;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x22, 0x8d);
            this.label3.Name = "label3";
            this.label3.Size = new Size(60, 13);
            this.label3.TabIndex = 0x1d;
            this.label3.Text = "DO/SO No";
            this.buttonRelation.Location = new Point(0x115, 0xa1);
            this.buttonRelation.Margin = new Padding(0);
            this.buttonRelation.Name = "buttonRelation";
            this.buttonRelation.Size = new Size(0x17, 0x17);
            this.buttonRelation.TabIndex = 170;
            this.buttonRelation.Text = "...";
            this.buttonRelation.UseVisualStyleBackColor = true;
            this.buttonRelation.Click += new EventHandler(this.buttonRelation_Click);
            this.label4.AutoSize = true;
            this.label4.Location = new Point(20, 0xa6);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x4a, 13);
            this.label4.TabIndex = 0xa9;
            this.label4.Text = "Relation Code";
            this.textRelation.CharacterCasing = CharacterCasing.Upper;
            this.textRelation.Location = new Point(0x65, 0xa3);
            this.textRelation.Name = "textRelation";
            this.textRelation.Size = new Size(0xad, 20);
            this.textRelation.TabIndex = 0xa8;
            this.groupBox1.Controls.Add(this.radioDO);
            this.groupBox1.Controls.Add(this.radioDate);
            this.groupBox1.Location = new Point(100, 0xc1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(150, 0x43);
            this.groupBox1.TabIndex = 0xab;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Report Details";
            this.radioDO.AutoSize = true;
            this.radioDO.Location = new Point(6, 0x2a);
            this.radioDO.Name = "radioDO";
            this.radioDO.Size = new Size(110, 0x11);
            this.radioDO.TabIndex = 0x18;
            this.radioDO.Text = "Details by DO/SO";
            this.radioDO.UseVisualStyleBackColor = true;
            this.radioDO.CheckedChanged += new EventHandler(this.radioDO_CheckedChanged);
            this.radioDate.AutoSize = true;
            this.radioDate.Checked = true;
            this.radioDate.Location = new Point(6, 0x13);
            this.radioDate.Name = "radioDate";
            this.radioDate.Size = new Size(0x61, 0x11);
            this.radioDate.TabIndex = 0x17;
            this.radioDate.TabStop = true;
            this.radioDate.Text = "Details by Date";
            this.radioDate.UseVisualStyleBackColor = true;
            this.radioDate.CheckedChanged += new EventHandler(this.radioDate_CheckedChanged);
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x16b, 0x1bf);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x58, 0x20);
            this.button2.TabIndex = 0xad;
            this.button2.Text = "&Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.buttonProcess.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonProcess.Location = new Point(0x10d, 0x1bf);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(0x58, 0x21);
            this.buttonProcess.TabIndex = 0xac;
            this.buttonProcess.Text = "&Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.groupBox2.Controls.Add(this.rbSNUT);
            this.groupBox2.Controls.Add(this.rbDNS);
            this.groupBox2.Location = new Point(100, 0x115);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new Size(150, 0x43);
            this.groupBox2.TabIndex = 0xae;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Net Until Today";
            this.rbSNUT.AutoSize = true;
            this.rbSNUT.Enabled = false;
            this.rbSNUT.Location = new Point(6, 0x2a);
            this.rbSNUT.Name = "rbSNUT";
            this.rbSNUT.Size = new Size(0x81, 0x11);
            this.rbSNUT.TabIndex = 0x18;
            this.rbSNUT.Text = "Show Net Until Today";
            this.rbSNUT.UseVisualStyleBackColor = true;
            this.rbDNS.AutoSize = true;
            this.rbDNS.Checked = true;
            this.rbDNS.Location = new Point(6, 0x13);
            this.rbDNS.Name = "rbDNS";
            this.rbDNS.Size = new Size(0x59, 0x11);
            this.rbDNS.TabIndex = 0x17;
            this.rbDNS.TabStop = true;
            this.rbDNS.Text = "Do Not Show";
            this.rbDNS.UseVisualStyleBackColor = true;
            this.shapeContainer2.Location = new Point(0, 0);
            this.shapeContainer2.Margin = new Padding(0);
            this.shapeContainer2.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.lineShape1 };
            this.shapeContainer2.Shapes.AddRange(shapes);
            this.shapeContainer2.Size = new Size(0x1db, 0x1b9);
            this.shapeContainer2.TabIndex = 0x17;
            this.shapeContainer2.TabStop = false;
            this.gbDispOpt.Controls.Add(this.cBoxLoadingQty);
            this.gbDispOpt.Controls.Add(this.cBoxLossInPack);
            this.gbDispOpt.Controls.Add(this.cBoxLossInKg);
            this.gbDispOpt.Controls.Add(this.cBoxReturInPack);
            this.gbDispOpt.Controls.Add(this.cBoxReturInKg);
            this.gbDispOpt.Location = new Point(0x63, 0x160);
            this.gbDispOpt.Name = "gbDispOpt";
            this.gbDispOpt.Size = new Size(0xd6, 0x59);
            this.gbDispOpt.TabIndex = 0xaf;
            this.gbDispOpt.TabStop = false;
            this.gbDispOpt.Text = "Display Options";
            this.cBoxLossInPack.AutoSize = true;
            this.cBoxLossInPack.Location = new Point(0x77, 0x2c);
            this.cBoxLossInPack.Name = "cBoxLossInPack";
            this.cBoxLossInPack.Size = new Size(0x57, 0x11);
            this.cBoxLossInPack.TabIndex = 0xb0;
            this.cBoxLossInPack.Text = "Loss in Pack";
            this.cBoxLossInPack.UseVisualStyleBackColor = true;
            this.cBoxLossInKg.AutoSize = true;
            this.cBoxLossInKg.Location = new Point(0x77, 0x15);
            this.cBoxLossInKg.Name = "cBoxLossInKg";
            this.cBoxLossInKg.Size = new Size(0x4d, 0x11);
            this.cBoxLossInKg.TabIndex = 0xb0;
            this.cBoxLossInKg.Text = "Loss in KG";
            this.cBoxLossInKg.UseVisualStyleBackColor = true;
            this.cBoxReturInPack.AutoSize = true;
            this.cBoxReturInPack.Location = new Point(14, 0x2c);
            this.cBoxReturInPack.Name = "cBoxReturInPack";
            this.cBoxReturInPack.Size = new Size(0x61, 0x11);
            this.cBoxReturInPack.TabIndex = 0xb0;
            this.cBoxReturInPack.Text = "Return in Pack";
            this.cBoxReturInPack.UseVisualStyleBackColor = true;
            this.cBoxReturInKg.AutoSize = true;
            this.cBoxReturInKg.Location = new Point(14, 0x15);
            this.cBoxReturInKg.Name = "cBoxReturInKg";
            this.cBoxReturInKg.Size = new Size(0x57, 0x11);
            this.cBoxReturInKg.TabIndex = 0xb0;
            this.cBoxReturInKg.Text = "Return in KG";
            this.cBoxReturInKg.UseVisualStyleBackColor = true;
            this.cBoxLoadingQty.AutoSize = true;
            this.cBoxLoadingQty.Location = new Point(14, 0x42);
            this.cBoxLoadingQty.Name = "cBoxLoadingQty";
            this.cBoxLoadingQty.Size = new Size(0x53, 0x11);
            this.cBoxLoadingQty.TabIndex = 0xb1;
            this.cBoxLoadingQty.Text = "Loading Qty";
            this.cBoxLoadingQty.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1db, 0x1ed);
            base.Controls.Add(this.gbDispOpt);
            base.Controls.Add(this.groupBox2);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.buttonProcess);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.buttonRelation);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textRelation);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.textDO);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.monthCalendar2);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.monthCalendar1);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.labelCommName);
            base.Controls.Add(this.textCommodity);
            base.Controls.Add(this.labelcommodity);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.shapeContainer1);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "RepVendorDetail";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Vendor Summary 2";
            base.Load += new EventHandler(this.RepVendorDetail_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbDispOpt.ResumeLayout(false);
            this.gbDispOpt.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void printreport()
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_transaction_type", "Select top 1 * from wb_transaction_type where " + WBData.CompanyLocation("and is_return = 'Y' and IO = 'I'"), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                this.Retur_masuk = table.DT.Rows[0]["transaction_code"].ToString();
            }
            table.OpenTable("wb_transaction_type", "Select top 1 * from wb_transaction_type where " + WBData.CompanyLocation("and is_return = 'Y' and IO = 'O'"), WBData.conn);
            if (table.DT.Rows.Count > 0)
            {
                this.Retur_keluar = table.DT.Rows[0]["transaction_code"].ToString();
            }
            HTML rep = new HTML();
            rep.File = rep.File + @"\" + WBUser.UserID + "repdetail.htm";
            rep.Title = "VENDOR SUMMARY 2 REPORT";
            rep.Open();
            rep.Write(rep.Style());
            rep.Write("<br><font size=5><b>VENDOR SUMMARY 2 REPORT</b></font>");
            if (this.radioDate.Checked)
            {
                rep.Write("<br><font size=4>Details By Date</font><br>");
            }
            if (this.radioDO.Checked)
            {
                rep.Write("<br><font size=4>Details By DO/SO</font><br>");
            }
            string[] textArray1 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
            rep.Write(string.Concat(textArray1));
            string[] textArray2 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
            rep.Write(string.Concat(textArray2));
            if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
            }
            if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
            {
                rep.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
            }
            rep.Write("<br><br>");
            rep.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
            rep.Write("<tr class=bd>");
            rep.Write("<td>Selected Date</td>");
            string[] textArray3 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
            rep.Write(string.Concat(textArray3));
            rep.Write("</tr>");
            rep.Write("<tr class=bd>");
            rep.Write("<td>Report Date</td>");
            rep.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
            rep.Write("</tr>");
            rep.Write("</table>");
            rep.Write("<br/><br/>");
            WBTable table2 = new WBTable();
            string sqltext = "SELECT comm_code, comm_name, Relation_Code, relation_name, Report_Date, SUM(netto) as netto, SUM(Tarra) as Tarra, SUM(bruto) as bruto, SUM (CASE WHEN TotalBunch < 1 THEN Bruto Else 0 END) AS BrutoBunchNol, SUM (CASE WHEN TotalBunch < 1 THEN Tarra Else 0 END) AS TarraBunchNol, SUM (return_qty_kg) as ReturInKg, SUM (return_qty_pack) as ReturInPack,SUM (loading_qty_opw) as loading_qty_opw, sum (estate_qty) as estate_qty,SUM (case when deductedBy = '1' and (Unit <> 'KG' or bulkpack = 'P') then (loading_qty - loading_qty_opw - return_qty_pack) * -1 else 0 end) as lossinpack,SUM (case when deductedBy = '1' and Unit = 'KG' then (netto - estate_qty - return_qty_kg) * -1 else 0 end) as lossinkg, SUM(TotalBunch) as TotalBunch, SUM(Rend_CPO) as Rend_CPO, SUM(Rend_CPO * Netto / 100) AS oercpoDate, SUM(TotalBunch * WeightPerUnitName) as Gunny, SUM(Deduction) as deduction, COUNT(Report_Date) as unit , SUM(LOADING_QTY) as Loading_Qty ";
            if (this.radioDO.Checked)
            {
                sqltext = sqltext + ", DO_No ";
            }
            sqltext = sqltext + "FROM vw_trans WHERE ";
            sqltext = !(this.radioDO.Checked && this.rbSNUT.Checked) ? ((sqltext + WBData.CompanyLocation(" and ((report_Date>='" + this.monthCalendar1.Value.ToString("yyyy/MM/dd") + " 00:00:00'")) + " and report_Date<='" + this.monthCalendar2.Value.ToString("yyyy/MM/dd") + " 00:00:00'))") : (sqltext + WBData.CompanyLocation("and report_Date<='" + this.monthCalendar2.Value.ToString("yyyy/MM/dd") + " 00:00:00'"));
            sqltext = sqltext + " and (deleted is null or deleted = 'N') " + " and (Report_Date is not null) ";
            if (this.textRelation.Text != "")
            {
                sqltext = sqltext + " and (Relation_Code = '" + this.textRelation.Text + "') ";
            }
            if (this.textCommodity.Text != "")
            {
                sqltext = sqltext + " and (Comm_Code = '" + this.textCommodity.Text + "') ";
            }
            if (this.textDO.Text != "")
            {
                sqltext = sqltext + " and (DO_NO = '" + this.textDO.Text + "') ";
            }
            string[] textArray4 = new string[] { sqltext, " and (transaction_code <> '", this.Retur_masuk, "' and transaction_code <> '", this.Retur_keluar, "') " };
            sqltext = (string.Concat(textArray4) + " and (NOT(REF like '%" + Constant.TITIP_TIMBUN_POSTFIX + "'))") + " and (NOT(REF like '%T'))" + " GROUP BY comm_code, comm_name, relation_code, relation_name, Report_Date ";
            if (this.radioDO.Checked)
            {
                sqltext = sqltext + ", DO_No ";
            }
            sqltext = sqltext + "ORDER BY comm_code, relation_code, Report_Date";
            if (this.radioDO.Checked)
            {
                sqltext = sqltext + ", DO_No ";
            }
            table2.OpenTable("vw_trans", sqltext, WBData.conn);
            this.gross = 0.0;
            this.netto = 0.0;
            this.tarra = 0.0;
            this.receive = 0.0;
            this.deduct = 0.0;
            this.ReturInKg = 0.0;
            this.ReturInPack = 0.0;
            this.LossInKg = 0.0;
            this.LossInPack = 0.0;
            this.LoadingQty = 0.0;
            this.tgross = 0.0;
            this.tnetto = 0.0;
            this.ttarra = 0.0;
            this.treceive = 0.0;
            this.tdeduct = 0.0;
            this.tandan = 0.0;
            this.tunit = 0.0;
            this.ttandan = 0.0;
            this.tReturInKg = 0.0;
            this.tReturInPack = 0.0;
            this.tLossInKg = 0.0;
            this.tLossInPack = 0.0;
            this.tLoadingQty = 0.0;
            this.rvcpo = 0.0;
            this.toercpo = 0.0;
            this.trvcpo = 0.0;
            this.oercpo = 0.0;
            this.avg = 0.0;
            this.tavg = 0.0;
            this.unit = 0.0;
            this.netSDHI = 0.0;
            this.tnetSDHI = 0.0;
            this.grossDate = 0.0;
            this.nettoDate = 0.0;
            this.tarraDate = 0.0;
            this.receiveDate = 0.0;
            this.deductDate = 0.0;
            this.unitDate = 0.0;
            this.oercpoDate = 0.0;
            this.tandanDate = 0.0;
            this.receiveAVGDate = 0.0;
            this.netSDHIDate = 0.0;
            this.ReturInKgDate = 0.0;
            this.ReturInPackDate = 0.0;
            this.LossInKgDate = 0.0;
            this.LossInPackDate = 0.0;
            this.LoadingQtyDate = 0.0;
            this.gunny = 0.0;
            this.tgunny = 0.0;
            int num = 0;
            if (table2.DT.Rows.Count == 0.0)
            {
                MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                rep.Close();
                rep.Dispose();
            }
            else
            {
                table2.DR = table2.DT.Rows[0];
                string pStr = table2.DR["relation_code"].ToString();
                string str3 = table2.DR["relation_name"].ToString();
                string objA = "";
                string str5 = "";
                if (this.radioDO.Checked)
                {
                    objA = table2.DR["DO_No"].ToString();
                    str5 = table2.DR["DO_No"].ToString();
                }
                string str6 = table2.DR["relation_code"].ToString();
                string str7 = table2.DR["comm_code"].ToString();
                DateTime time = Convert.ToDateTime("01/01/1970 00:00:00");
                StringBuilder builder = new StringBuilder();
                string[] textArray5 = new string[] { "<br><b><font size =2 >Commodity : ", str7, " - ", table2.DR["comm_name"].ToString(), "</font></b>" };
                rep.Write(string.Concat(textArray5));
                rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                this.initHeader(rep);
                int num3 = 0;
                int count = table2.DT.Rows.Count;
                string str8 = "";
                string str9 = "";
                foreach (DataRow row in table2.DT.Rows)
                {
                    string str10 = row["relation_Code"].ToString();
                    this.grossDate += Program.StrToDouble(row["bruto"].ToString(), 0);
                    this.nettoDate += Program.StrToDouble(row["netto"].ToString(), 0);
                    this.tarraDate += Program.StrToDouble(row["tarra"].ToString(), 0);
                    this.receiveDate += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                    this.tmpgunny = Program.StrToDouble(row["Gunny"].ToString(), 2);
                    this.tmpgunny = Program.StrToDouble($"{this.tmpgunny:N0}", 0);
                    this.gunnyDate += this.tmpgunny;
                    this.deductDate += Program.StrToDouble(row["Deduction"].ToString(), 0);
                    this.oercpoDate += Program.StrToDouble(row["oercpodate"].ToString(), 2);
                    this.tandanDate += Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                    this.netSDHIDate += Program.StrToDouble(row["Netto"].ToString(), 0);
                    this.ReturInPackDate += Program.StrToDouble(row["ReturInPack"].ToString(), 0);
                    this.ReturInKgDate += Program.StrToDouble(row["ReturInKg"].ToString(), 0);
                    this.LossInPackDate += Program.StrToDouble(row["lossInPack"].ToString(), 0);
                    this.LossInKgDate += Program.StrToDouble(row["lossInKg"].ToString(), 0);
                    this.LoadingQtyDate += Program.StrToDouble(row["Loading_Qty"].ToString(), 0);
                    if (row["comm_code"].ToString() != str7)
                    {
                        num++;
                        rep.Write("<tr class='bd'>");
                        rep.Write("<td align=right><b>" + rep.strq(num.ToString()) + "</b></td>");
                        rep.Write("<td align=left><b>" + rep.strq(pStr) + "</b></td>");
                        rep.Write("<td align=left><b>" + rep.strq(str3) + "</b></td>");
                        if (this.radioDO.Checked)
                        {
                            str8 = "&nbsp;";
                        }
                        else if (this.radioDate.Checked)
                        {
                            str8 = !((objA == "") || ReferenceEquals(objA, null)) ? objA : "&nbsp;";
                        }
                        if (this.radioDO.Checked)
                        {
                            rep.Write("<td align=right><b>" + str8 + "</b></td>");
                        }
                        this.rvcpo = (this.oercpo * 100.0) / this.netto;
                        rep.Write("<td align=right><b>" + rep.strq($"{this.gross:N0}") + "</b></td>");
                        rep.Write("<td align=right><b>" + rep.strq($"{this.tarra:N0}") + "</b></td>");
                        rep.Write("<td align=right><b>" + rep.strq($"{this.receive:N0}") + "</b></td>");
                        this.deduct -= this.gunny;
                        rep.Write("<td align=right><b>" + rep.strq($"{this.gunny:N0}") + "</b></td>");
                        rep.Write("<td align=right><b>" + rep.strq($"{this.netto:N0}") + "</b></td>");
                        if (this.radioDO.Checked && this.rbSNUT.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.netSDHI:N0}") + "</b></td>");
                        }
                        if (this.cBoxReturInKg.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.ReturInKg:N0}") + "</b></td>");
                        }
                        if (this.cBoxReturInPack.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.ReturInPack:N0}") + "</b></td>");
                        }
                        if (this.cBoxLossInKg.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.LossInKg:N0}") + "</b></td>");
                        }
                        if (this.cBoxLossInPack.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.LossInPack:N0}") + "</b></td>");
                        }
                        if (this.cBoxLoadingQty.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.LoadingQty:N0}") + "</b></td>");
                        }
                        rep.Write("</tr>");
                        rep.Write(builder.ToString());
                        builder.Clear();
                        rep.Write("<tr class='bd'>");
                        if (this.radioDO.Checked)
                        {
                            rep.Write("<td colspan=4 align=CENTER><b>TOTAL</b></td>");
                        }
                        else
                        {
                            rep.Write("<td colspan=3 align=CENTER><b>TOTAL</b></td>");
                        }
                        this.rvcpo = (this.toercpo * 100.0) / this.tnetto;
                        rep.Write("<td align=right><b>" + rep.strq($"{this.tgross:N0}") + "</b></td>");
                        rep.Write("<td align=right><b>" + rep.strq($"{this.ttarra:N0}") + "</b></td>");
                        rep.Write("<td align=right><b>" + rep.strq($"{this.treceive:N0}") + "</b></td>");
                        this.tdeduct -= this.tgunny;
                        rep.Write("<td align=right><b>" + rep.strq($"{this.tgunny:N0}") + "</b></td>");
                        rep.Write("<td align=right><b>" + rep.strq($"{this.tnetto:N0}") + "</b></td>");
                        if (this.radioDO.Checked && this.rbSNUT.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tnetSDHI:N0}") + "</b></td>");
                        }
                        if (this.cBoxReturInKg.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tReturInKg:N0}") + "</b></td>");
                        }
                        if (this.cBoxReturInPack.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tReturInPack:N0}") + "</b></td>");
                        }
                        if (this.cBoxLossInKg.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tLossInKg:N0}") + "</b></td>");
                        }
                        if (this.cBoxLossInPack.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tLossInPack:N0}") + "</b></td>");
                        }
                        if (this.cBoxLoadingQty.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tLoadingQty:N0}") + "</b></td>");
                        }
                        rep.Write("</tr>");
                        rep.Write("</table>");
                        this.tunit = 0.0;
                        this.treceive = 0.0;
                        this.ttandan = 0.0;
                        this.toercpo = 0.0;
                        this.tnetto = 0.0;
                        this.tgross = 0.0;
                        this.ttarra = 0.0;
                        this.treceive = 0.0;
                        this.tdeduct = 0.0;
                        this.tgunny = 0.0;
                        this.tnetto = 0.0;
                        this.tnetSDHI = 0.0;
                        this.tReturInKg = 0.0;
                        this.tReturInPack = 0.0;
                        this.tLossInKg = 0.0;
                        this.tLossInPack = 0.0;
                        this.tLoadingQty = 0.0;
                        this.gross = 0.0;
                        this.netto = 0.0;
                        this.tarra = 0.0;
                        this.receive = 0.0;
                        this.deduct = 0.0;
                        this.gunny = 0.0;
                        this.unit = 0.0;
                        this.oercpo = 0.0;
                        this.tandan = 0.0;
                        this.receiveAVG = 0.0;
                        this.netSDHI = 0.0;
                        this.LossInKg = 0.0;
                        this.LossInPack = 0.0;
                        this.LoadingQty = 0.0;
                        this.ReturInKg = 0.0;
                        this.ReturInPack = 0.0;
                        num = 0;
                        rep.Write("<br>");
                        string[] textArray6 = new string[] { "<b><font size =3 >Commodity : ", row["comm_code"].ToString(), " - ", row["comm_name"].ToString(), "</font></b>" };
                        rep.Write(string.Concat(textArray6));
                        rep.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                        this.initHeader(rep);
                        str7 = row["comm_code"].ToString();
                        str6 = pStr;
                        pStr = row["relation_code"].ToString();
                        str3 = row["relation_name"].ToString();
                        str5 = objA;
                        if (this.radioDO.Checked)
                        {
                            objA = row["DO_No"].ToString();
                        }
                        time = Convert.ToDateTime("01/01/1970 00:00:00");
                    }
                    else if (this.radioDate.Checked && (row["relation_code"].ToString() != pStr))
                    {
                        num++;
                        this.labelRecNo.Refresh();
                        str9 = pStr;
                        rep.Write("<tr class='bd'>");
                        rep.Write("<td align=right><b>" + rep.strq(num.ToString()) + "</b></td>");
                        rep.Write("<td align=left><b>" + rep.strq(pStr) + "</b></td>");
                        rep.Write("<td align=left><b>" + rep.strq(str3) + "</b></td>");
                        if (this.radioDO.Checked)
                        {
                            str8 = "&nbsp;";
                        }
                        else if (this.radioDate.Checked)
                        {
                            str8 = !((objA == "") || ReferenceEquals(objA, null)) ? objA : "&nbsp;";
                        }
                        if (this.radioDO.Checked)
                        {
                            rep.Write("<td align=right><b>" + str8 + "</b></td>");
                        }
                        this.rvcpo = (this.oercpo * 100.0) / this.netto;
                        rep.Write("<td align=right><b>" + rep.strq($"{this.gross:N0}") + "</b></td>");
                        rep.Write("<td align=right><b>" + rep.strq($"{this.tarra:N0}") + "</b></td>");
                        rep.Write("<td align=right><b>" + rep.strq($"{this.receive:N0}") + "</b></td>");
                        this.deduct -= this.gunny;
                        rep.Write("<td align=right><b>" + rep.strq($"{this.gunny:N0}") + "</b></td>");
                        rep.Write("<td align=right><b>" + rep.strq($"{this.netto:N0}") + "</b></td>");
                        if (this.radioDO.Checked && this.rbSNUT.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.netSDHI:N0}") + "</b></td>");
                        }
                        if (this.cBoxReturInKg.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.ReturInKg:N0}") + "</b></td>");
                        }
                        if (this.cBoxReturInPack.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.ReturInPack:N0}") + "</b></td>");
                        }
                        if (this.cBoxLossInKg.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.LossInKg:N0}") + "</b></td>");
                        }
                        if (this.cBoxLossInPack.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.LossInPack:N0}") + "</b></td>");
                        }
                        if (this.cBoxLoadingQty.Checked)
                        {
                            rep.Write("<td align=right><b>" + rep.strq($"{this.LoadingQty:N0}") + "</b></td>");
                        }
                        rep.Write("</tr>");
                        rep.Write(builder.ToString());
                        builder.Clear();
                        pStr = row["relation_code"].ToString();
                        str3 = row["relation_name"].ToString();
                        if (this.radioDO.Checked)
                        {
                            objA = row["DO_No"].ToString();
                        }
                        str6 = pStr;
                        time = Convert.ToDateTime("01/01/1970 00:00:00");
                        if (this.radioDate.Checked)
                        {
                            this.gross = 0.0;
                            this.netto = 0.0;
                            this.tarra = 0.0;
                            this.receive = 0.0;
                            this.gunny = 0.0;
                            this.deduct = 0.0;
                            this.unit = 0.0;
                            this.oercpo = 0.0;
                            this.tandan = 0.0;
                            this.receiveAVG = 0.0;
                            this.netSDHI = 0.0;
                            this.ReturInKg = 0.0;
                            this.ReturInPack = 0.0;
                            this.LossInKg = 0.0;
                            this.LossInPack = 0.0;
                            this.LoadingQty = 0.0;
                        }
                    }
                    else if (this.radioDO.Checked && (row["relation_code"].ToString() != pStr))
                    {
                        this.labelRecNo.Refresh();
                        if (pStr == str10)
                        {
                            rep.Write(builder.ToString());
                            builder.Clear();
                        }
                        else
                        {
                            rep.Write("<tr class='bd'>");
                            num++;
                            rep.Write("<td align=right><b>" + rep.strq(num.ToString()) + "</b></td>");
                            rep.Write("<td align=left><b>" + rep.strq(pStr) + "</b></td>");
                            rep.Write("<td align=left><b>" + rep.strq(str3) + "</b></td>");
                            if (this.radioDO.Checked)
                            {
                                str8 = "&nbsp;";
                            }
                            else if (this.radioDate.Checked)
                            {
                                str8 = !((objA == "") || ReferenceEquals(objA, null)) ? objA : "&nbsp;";
                            }
                            if (this.radioDO.Checked)
                            {
                                rep.Write("<td align=right><b>" + str8 + "</b></td>");
                            }
                            this.rvcpo = (this.oercpo * 100.0) / this.netto;
                            rep.Write("<td align=right><b>" + rep.strq($"{this.gross:N0}") + "</b></td>");
                            rep.Write("<td align=right><b>" + rep.strq($"{this.tarra:N0}") + "</b></td>");
                            rep.Write("<td align=right><b>" + rep.strq($"{this.receive:N0}") + "</td>");
                            this.deduct -= this.gunny;
                            rep.Write("<td align=right><b>" + rep.strq($"{this.gunny:N0}") + "</b></td>");
                            rep.Write("<td align=right><b>" + rep.strq($"{this.netto:N0}") + "</b></td>");
                            if (this.radioDO.Checked && this.rbSNUT.Checked)
                            {
                                rep.Write("<td align=right><b>" + rep.strq($"{this.netSDHI:N0}") + "</b></td>");
                            }
                            if (this.cBoxReturInKg.Checked)
                            {
                                rep.Write("<td align=right><b>" + rep.strq($"{this.ReturInKg:N0}") + "</b></td>");
                            }
                            if (this.cBoxReturInPack.Checked)
                            {
                                rep.Write("<td align=right><b>" + rep.strq($"{this.ReturInPack:N0}") + "</b></td>");
                            }
                            if (this.cBoxLossInKg.Checked)
                            {
                                rep.Write("<td align=right><b>" + rep.strq($"{this.LossInKg:N0}") + "</b></td>");
                            }
                            if (this.cBoxLossInPack.Checked)
                            {
                                rep.Write("<td align=right><b>" + rep.strq($"{this.LossInPack:N0}") + "</b></td>");
                            }
                            if (this.cBoxLoadingQty.Checked)
                            {
                                rep.Write("<td align=right><b>" + rep.strq($"{this.LoadingQty:N0}") + "</b></td>");
                            }
                            rep.Write("</tr>");
                            rep.Write(builder.ToString());
                            builder.Clear();
                        }
                        pStr = row["relation_code"].ToString();
                        str3 = row["relation_name"].ToString();
                        if (this.radioDO.Checked)
                        {
                            objA = row["DO_No"].ToString();
                        }
                        str6 = pStr;
                        time = Convert.ToDateTime("01/01/1970 00:00:00");
                        this.gross = 0.0;
                        this.netto = 0.0;
                        this.tarra = 0.0;
                        this.receive = 0.0;
                        this.gunny = 0.0;
                        this.deduct = 0.0;
                        this.unit = 0.0;
                        this.oercpo = 0.0;
                        this.tandan = 0.0;
                        this.receiveAVG = 0.0;
                        this.netSDHI = 0.0;
                        this.ReturInKg = 0.0;
                        this.ReturInPack = 0.0;
                        this.LossInKg = 0.0;
                        this.LossInPack = 0.0;
                        this.LoadingQty = 0.0;
                    }
                    this.unit += Program.StrToDouble(row["unit"].ToString(), 0);
                    this.tunit += Program.StrToDouble(row["unit"].ToString(), 0);
                    this.unitDate += Program.StrToDouble(row["unit"].ToString(), 0);
                    if (Program.StrToDouble(row["TotalBunch"].ToString(), 0) > 0.0)
                    {
                        this.receiveAVGDate += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                    }
                    builder.Append("<tr class='bd'>");
                    builder.Append("<td align=right>&nbsp;</td>");
                    builder.Append("<td colspan=2 align=right>" + Convert.ToDateTime(row["report_date"].ToString()).ToShortDateString() + "</td>");
                    str8 = !((objA == "") || ReferenceEquals(objA, null)) ? row["DO_No"].ToString() : "&nbsp;";
                    if (this.radioDO.Checked)
                    {
                        builder.Append("<td align=right>" + str8 + "</td>");
                    }
                    this.rvcpo = (this.oercpoDate * 100.0) / this.nettoDate;
                    builder.Append("<td align=right>" + rep.strq($"{this.grossDate:N0}") + "</td>");
                    builder.Append("<td align=right>" + rep.strq($"{this.tarraDate:N0}") + "</td>");
                    builder.Append("<td align=right>" + rep.strq($"{this.receiveDate:N0}") + "</td>");
                    this.deductDate -= this.gunnyDate;
                    builder.Append("<td align=right>" + rep.strq($"{this.gunnyDate:N0}") + "</td>");
                    builder.Append("<td align=right>" + rep.strq($"{this.nettoDate:N0}") + "</td>");
                    if (this.radioDO.Checked && this.rbSNUT.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.netSDHIDate:N0}") + "</td>");
                    }
                    if (this.cBoxReturInKg.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.ReturInKgDate:N0}") + "</td>");
                    }
                    if (this.cBoxReturInPack.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.ReturInPackDate:N0}") + "</td>");
                    }
                    if (this.cBoxLossInKg.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.LossInKgDate:N0}") + "</td>");
                    }
                    if (this.cBoxLossInPack.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.LossInPackDate:N0}") + "</td>");
                    }
                    if (this.cBoxLoadingQty.Checked)
                    {
                        builder.Append("<td align=right>" + rep.strq($"{this.LoadingQtyDate:N0}") + "</td>");
                    }
                    builder.Append("</tr>");
                    time = Convert.ToDateTime(row["report_date"].ToString());
                    this.grossDate = 0.0;
                    this.nettoDate = 0.0;
                    this.tarraDate = 0.0;
                    this.receiveDate = 0.0;
                    this.deductDate = 0.0;
                    this.gunnyDate = 0.0;
                    this.unitDate = 0.0;
                    this.oercpoDate = 0.0;
                    this.tandanDate = 0.0;
                    this.receiveAVGDate = 0.0;
                    this.netSDHIDate = 0.0;
                    this.ReturInKgDate = 0.0;
                    this.ReturInPackDate = 0.0;
                    this.LossInKgDate = 0.0;
                    this.LossInPackDate = 0.0;
                    this.LoadingQtyDate = 0.0;
                    this.tandan += Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                    if (Program.StrToDouble(row["TotalBunch"].ToString(), 0) > 0.0)
                    {
                        this.receiveAVG += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                        this.treceiveAVG += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                    }
                    this.oercpo += Program.StrToDouble(row["oercpodate"].ToString(), 2);
                    this.toercpo += Program.StrToDouble(row["oercpodate"].ToString(), 2);
                    this.ttandan += Program.StrToDouble(row["TotalBunch"].ToString(), 0);
                    this.gross += Program.StrToDouble(row["bruto"].ToString(), 0);
                    this.tarra += Program.StrToDouble(row["tarra"].ToString(), 0);
                    this.netto += Program.StrToDouble(row["netto"].ToString(), 0);
                    this.ReturInKg += Program.StrToDouble(row["ReturInKg"].ToString(), 0);
                    this.ReturInPack += Program.StrToDouble(row["ReturInPack"].ToString(), 0);
                    this.LossInKg += Program.StrToDouble(row["LossInKg"].ToString(), 0);
                    this.LossInPack += Program.StrToDouble(row["LossInPack"].ToString(), 0);
                    this.LoadingQty += Program.StrToDouble(row["Loading_Qty"].ToString(), 0);
                    this.receive += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                    this.tmpgunny = Program.StrToDouble(row["Gunny"].ToString(), 2);
                    this.tmpgunny = Program.StrToDouble($"{this.tmpgunny:N0}", 0);
                    this.gunny += this.tmpgunny;
                    this.deduct += Program.StrToDouble(row["Deduction"].ToString(), 0);
                    this.tgunny += this.tmpgunny;
                    this.tdeduct += Program.StrToDouble(row["Deduction"].ToString(), 0);
                    this.tgross += Program.StrToDouble(row["bruto"].ToString(), 0);
                    this.ttarra += Program.StrToDouble(row["tarra"].ToString(), 0);
                    this.tnetto += Program.StrToDouble(row["netto"].ToString(), 0);
                    this.treceive += Program.StrToDouble(row["bruto"].ToString(), 0) - Program.StrToDouble(row["tarra"].ToString(), 0);
                    this.tnetSDHI += Program.StrToDouble(row["Netto"].ToString(), 0);
                    this.netSDHI += Program.StrToDouble(row["Netto"].ToString(), 0);
                    this.tReturInKg += Program.StrToDouble(row["ReturInKg"].ToString(), 0);
                    this.tReturInPack += Program.StrToDouble(row["ReturInPack"].ToString(), 0);
                    this.tLossInKg += Program.StrToDouble(row["LossInKg"].ToString(), 0);
                    this.tLossInPack += Program.StrToDouble(row["LossInPack"].ToString(), 0);
                    this.tLoadingQty += Program.StrToDouble(row["Loading_Qty"].ToString(), 0);
                    this.labelRecNo.Text = num3++ + "/" + count;
                    this.labelRecNo.Refresh();
                }
                this.labelRecNo.Text = num3++ + "/" + count;
                this.labelRecNo.Refresh();
                num++;
                rep.Write("<tr class='bd'>");
                rep.Write("<td align=right><b>" + rep.strq(num.ToString()) + "</b></td>");
                rep.Write("<td align=left><b>" + rep.strq(pStr) + "</b></td>");
                rep.Write("<td align=left><b>" + rep.strq(str3) + "</b></td>");
                if (this.radioDO.Checked)
                {
                    str8 = "&nbsp;";
                }
                else if (this.radioDate.Checked)
                {
                    str8 = !((objA == "") || ReferenceEquals(objA, null)) ? objA : "&nbsp;";
                }
                if (this.radioDO.Checked)
                {
                    rep.Write("<td align=right><b>" + str8 + "</b></td>");
                }
                this.rvcpo = (this.oercpo * 100.0) / this.netto;
                rep.Write("<td align=right><b>" + rep.strq($"{this.gross:N0}") + "</b></td>");
                rep.Write("<td align=right><b>" + rep.strq($"{this.tarra:N0}") + "</b></td>");
                rep.Write("<td align=right><b>" + rep.strq($"{this.receive:N0}") + "</b></td>");
                this.deduct -= this.gunny;
                rep.Write("<td align=right><b>" + rep.strq($"{this.gunny:N0}") + "</b></td>");
                rep.Write("<td align=right><b>" + rep.strq($"{this.netto:N0}") + "</b></td>");
                if (this.radioDO.Checked && this.rbSNUT.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.netSDHI:N0}") + "</b></td>");
                }
                if (this.cBoxReturInKg.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.ReturInKg:N0}") + "</b></td>");
                }
                if (this.cBoxReturInPack.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.ReturInPack:N0}") + "</b></td>");
                }
                if (this.cBoxLossInKg.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.LossInKg:N0}") + "</b></td>");
                }
                if (this.cBoxLossInPack.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.LossInPack:N0}") + "</b></td>");
                }
                if (this.cBoxLoadingQty.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.LoadingQty:N0}") + "</b></td>");
                }
                rep.Write("</tr>");
                rep.Write(builder.ToString());
                builder.Clear();
                rep.Write("<tr class='bd'>");
                if (this.radioDO.Checked)
                {
                    rep.Write("<td colspan=4 align=CENTER><b>TOTAL</b></td>");
                }
                else
                {
                    rep.Write("<td colspan=3 align=CENTER><b>TOTAL</b></td>");
                }
                this.rvcpo = (this.toercpo * 100.0) / this.tnetto;
                rep.Write("<td align=right><b>" + rep.strq($"{this.tgross:N0}") + "</b></td>");
                rep.Write("<td align=right><b>" + rep.strq($"{this.ttarra:N0}") + "</b></td>");
                rep.Write("<td align=right><b>" + rep.strq($"{this.treceive:N0}") + "</b></td>");
                this.tdeduct -= this.tgunny;
                rep.Write("<td align=right><b>" + rep.strq($"{this.tgunny:N0}") + "</b></td>");
                rep.Write("<td align=right><b>" + rep.strq($"{this.tnetto:N0}") + "</b></td>");
                if (this.radioDO.Checked && this.rbSNUT.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tnetSDHI:N0}") + "</b></td>");
                }
                if (this.cBoxReturInKg.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tReturInKg:N0}") + "</b></td>");
                }
                if (this.cBoxReturInPack.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tReturInPack:N0}") + "</b></td>");
                }
                if (this.cBoxLossInKg.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tLossInKg:N0}") + "</b></td>");
                }
                if (this.cBoxLossInPack.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tLossInPack:N0}") + "</b></td>");
                }
                if (this.cBoxLoadingQty.Checked)
                {
                    rep.Write("<td align=right><b>" + rep.strq($"{this.tLoadingQty:N0}") + "</b></td>");
                }
                rep.Write("</tr>");
                rep.Write("</table>");
                rep.Write("<br><br><br>");
                rep.writeSign();
                rep.Close();
                ViewReport report = new ViewReport {
                    webBrowser1 = { Url = new Uri("file:///" + rep.File) }
                };
                report.ShowDialog();
                rep.Dispose();
                report.Dispose();
            }
        }

        private void radioDate_CheckedChanged(object sender, EventArgs e)
        {
            if (!this.radioDate.Checked)
            {
                this.rbSNUT.Enabled = true;
            }
            else
            {
                this.rbDNS.Checked = true;
                this.rbSNUT.Checked = false;
                this.rbSNUT.Enabled = false;
            }
        }

        private void radioDO_CheckedChanged(object sender, EventArgs e)
        {
            if (!this.radioDate.Checked)
            {
                this.rbSNUT.Enabled = true;
            }
            else
            {
                this.rbDNS.Checked = true;
                this.rbSNUT.Checked = false;
                this.rbSNUT.Enabled = false;
            }
        }

        private void RepVendorDetail_Load(object sender, EventArgs e)
        {
            this.tblComm.OpenTable("wb_commodity", "Select * From wb_commodity", WBData.conn);
            Program.AutoComp(this.tblComm, "comm_code", this.textCommodity);
            this.tblDO.OpenTable("wb_contract", "Select * From wb_contract", WBData.conn);
            Program.AutoComp(this.tblDO, "do_no", this.textDO);
            this.tblRelation.OpenTable("wb_relation", "Select * From wb_relation", WBData.conn);
            Program.AutoComp(this.tblRelation, "relation_code", this.textRelation);
        }

        private void textCommodity_Leave(object sender, EventArgs e)
        {
            this.labelCommName.Text = "";
            if (this.textCommodity.Text.Trim() != "")
            {
                this.tblComm.ReOpen();
                string[] aField = new string[] { "Comm_code" };
                string[] aFind = new string[] { this.textCommodity.Text.Trim() };
                int recNo = this.tblComm.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelCommName.Text = this.tblComm.DT.Rows[recNo]["Comm_name"].ToString().Trim();
                }
                else
                {
                    this.labelCommName.Text = "";
                    this.buttonComm.PerformClick();
                    this.textCommodity.Focus();
                }
            }
        }
    }
}

