﻿namespace WindowsFormsApplication1
{
    using Encryption.Utility;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Net;
    using System.Windows.Forms;

    public class FormToken : Form
    {
        private WBToken aToken = new WBToken();
        public DateTime email_date;
        public DataGridView dataGrid;
        public DataTable dt;
        public DataModal DM;
        public TokenOrAppModal TOAPM;
        public WBTable WB;
        public string pmode = "";
        public string tblName = "";
        public string type = "";
        public string oldToken = "";
        public string oldCode = "";
        public string newCode = "";
        public bool saved = false;
        public bool close = false;
        public bool use3x = false;
        public bool editnX = false;
        public bool userNotMaintainedYet = false;
        public bool savedCauseSystemErr = false;
        public string completed = "N";
        public string manualQty = "0";
        public string email_code = "";
        public string AllTrx = "";
        public string CommTol = "";
        public string DoNo = "";
        public string TokenParam2;
        private bool dblToken = false;
        private string lastToken;
        private string differ;
        private string token1;
        private string token2;
        private string jlhEdit = "0";
        public Dictionary<string, object> disable_condition_params = null;
        public string trans_ref = null;
        private int sendingSMSCount = 0;
        private int toleranceForSendingSMS = 5;
        private IContainer components = null;
        private Button buttonProcess;
        private Button button1;
        private Label label1;
        private Label label2;
        public TextBox textBoxToken;
        private TextBox textBoxPIN;
        private TextBox textWarning;
        private Label labelEdit;
        private Label labelQty;
        private TextBox textQty;
        private Label label3;
        private TextBox textMessage;
        private TextBox txtAllTrx;
        private Label lblAllTrx;
        private TextBox txtCommTol;
        private Label lblCommTol;
        private Label lblPercen;
        private TextBox labelInstruct;

        public FormToken()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!this.savedCauseSystemErr)
            {
                this.saved = false;
                base.Close();
            }
            else
            {
                try
                {
                    this.saveWhenError();
                    base.Close();
                }
                catch
                {
                }
            }
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            bool flag = true;
            if (this.textBoxPIN.Text.Trim() != "")
            {
                goto TR_002D;
            }
            else if (this.textMessage.Text != "")
            {
                if (this.pmode != "COMM_CONT_TOL")
                {
                    goto TR_0030;
                }
                else if (this.txtCommTol.Text.Trim() != "")
                {
                    if ((this.txtAllTrx.Text.Trim() != "0") || (MessageBox.Show(Resource.Mes_Warning_Tolerance_All, Resource.Mes_Confirmation, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.No))
                    {
                        goto TR_0030;
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Fill_Tolerance, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.txtCommTol.Focus();
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_Fill_Message, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textMessage.Focus();
            }
            return;
        TR_002D:
            if (!flag)
            {
                if (this.userNotMaintainedYet)
                {
                    this.textBoxPIN.Enabled = false;
                    this.saved = false;
                }
                else if (!string.IsNullOrEmpty(this.textBoxPIN.Text))
                {
                    this.saved = false;
                }
                else
                {
                    try
                    {
                        this.saved = true;
                        this.saveWhenError();
                        this.textBoxPIN.Enabled = true;
                    }
                    catch (Exception exception)
                    {
                        this.savedCauseSystemErr = true;
                        MessageBox.Show(exception.ToString(), Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
            else
            {
                this.textBoxPIN.Enabled = true;
                if (this.pmode == "MANUAL")
                {
                    if (this.pmode == "MANUAL")
                    {
                        if (this.textQty.Text.ToString().Trim() == "")
                        {
                            MessageBox.Show(Resource.Mes_Warning_Fill_Quantity_Manual, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.textQty.Focus();
                        }
                        else if (Convert.ToInt16(this.textQty.Text) <= 0)
                        {
                            MessageBox.Show(Resource.Mes_Warning_Fill_Quantity_Manual, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.textQty.Focus();
                        }
                        else if (this.textBoxPIN.Text.Trim() == "")
                        {
                            this.saved = true;
                            this.completed = "N";
                            base.Close();
                        }
                        else if (MessageBox.Show(Resource.Mes_Confirm_Weigh_Form_Closed, Resource.Mes_Confirmation, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                        {
                            try
                            {
                                string str4 = "";
                                str4 = this.aToken.generateV2PIN(this.textBoxToken.Text.Trim(), this.pmode).Trim();
                                string pArg = "0";
                                pArg = this.aToken.countManual(str4, this.textBoxPIN.Text.Trim());
                                if (!((Program.StrToDouble(pArg, 3) % Program.StrToDouble(pArg, 0)) == 0.0))
                                {
                                    this.saved = false;
                                    MessageBox.Show(Resource.Mes_Warning_Invalid_PIN, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }
                                else
                                {
                                    this.saved = true;
                                    this.manualQty = pArg;
                                    this.completed = "Y";
                                    base.Close();
                                }
                            }
                            catch
                            {
                                this.saved = false;
                                MessageBox.Show(Resource.Mes_Warning_Invalid_PIN, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            }
                        }
                    }
                }
                else if (this.textBoxPIN.Text.Trim() == "")
                {
                    if (this.pmode == "COMM_CONT_TOL")
                    {
                        this.saved = true;
                        this.completed = "N";
                        base.Close();
                    }
                    else if (!(((this.tblName.ToUpper() != "WB_CONTRACT") || (this.pmode != "GRCUST")) ? ((this.tblName.ToUpper() == "WB_TRANSACTION") && (this.pmode != "ADD_RETUR")) : true))
                    {
                        this.saved = true;
                        this.completed = "N";
                        base.Close();
                    }
                    else if (MessageBox.Show(Resource.Mes_Confirm_Without_Token, Resource.Mes_Confirmation, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        this.saved = true;
                        this.completed = "N";
                        base.Close();
                    }
                }
                else
                {
                    string str;
                    string str2;
                    if (this.pmode != "COMM_CONT_TOL")
                    {
                        str = this.textBoxPIN.Text.Trim();
                        str2 = this.textBoxToken.Text.Trim();
                    }
                    else
                    {
                        string[] tDPIN = this.aToken.GetTDPIN(this.textBoxPIN.Text.Trim());
                        str = tDPIN[0];
                        this.CommTol = tDPIN[1];
                        this.AllTrx = tDPIN[2];
                        int length = Convert.ToInt32(this.textBoxToken.Text.Substring(this.textBoxToken.Text.Length - 1, 1));
                        string str3 = this.textBoxToken.Text.Substring(0, length) + this.textBoxToken.Text.Substring(length + 4);
                        str2 = str3.Substring(0, str3.Length - 1);
                    }
                    if (str != this.aToken.generateV2PIN(str2, this.pmode).Trim())
                    {
                        MessageBox.Show(Resource.Mes_Pin_Rejected, Resource.Mes_Fail_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    else
                    {
                        this.saved = true;
                        MessageBox.Show(Resource.Mes_Pin_Accepted, Resource.Mes_Success, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        this.completed = "Y";
                        WBTable table = new WBTable();
                        if (this.pmode == "MARK_ACCIDENT")
                        {
                            table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(" AND token_code = '" + this.pmode + "'"), WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                table.DT.Rows[0].Delete();
                                table.Save();
                            }
                            else if (table.DT.Rows.Count == 0)
                            {
                            }
                        }
                        table.Dispose();
                        base.Close();
                    }
                }
            }
            return;
        TR_0030:
            if (WBSetting.activeSMSToken && ((this.pmode != "MANUAL") && (this.pmode != "COMM_CONT_TOL")))
            {
                flag = this.sendHTTPRequest(this.textBoxToken.Text.Trim(), WBUser.UserID, this.textMessage.Text.Trim());
            }
            else
            {
                this.sendEmailToken(this.email_code);
                flag = true;
            }
            goto TR_002D;
        }

        private bool cekDoubleToken(string aToken)
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_ctrToken", "select Do_no, Token from wb_contract where " + WBData.CompanyLocation(" and tokenGRCust = '" + aToken + "'"), WBData.conn);
            return (table.DT.Rows.Count > 0);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        public void f_load()
        {
        }

        private string firstLetterToUpper(string reason)
        {
            string str = reason.ToLower();
            return ((str.Length <= 1) ? str : (char.ToUpper(str[0]).ToString() + str.Substring(1)));
        }

        private void FormToken_Load(object sender, EventArgs e)
        {
            if (this.tblName.ToUpper().Trim() == "WB_TRANSACTION")
            {
                if (this.pmode == "MANUAL")
                {
                    base.Width = 430;
                    base.Height = 0x174;
                    this.labelQty.Visible = true;
                    this.textQty.Visible = true;
                }
                else
                {
                    this.labelQty.Visible = false;
                    this.textQty.Visible = false;
                    base.Width = 430;
                    base.Height = 0x174;
                }
            }
            else
            {
                if (this.pmode != "COMM_CONT_TOL")
                {
                    base.Width = 430;
                    base.Height = 0x174;
                }
                else
                {
                    this.txtCommTol.Visible = true;
                    this.txtAllTrx.Visible = true;
                    this.lblAllTrx.Visible = true;
                    this.lblCommTol.Visible = true;
                    this.lblPercen.Visible = true;
                    base.Width = 0x1a1;
                    base.Height = 400;
                    this.txtCommTol.Focus();
                }
                this.labelQty.Visible = false;
                this.textQty.Visible = false;
            }
            if (this.close)
            {
                base.Close();
            }
        }

        private string get_code(string aToken)
        {
            string str3 = "";
            string str5 = "";
            str3 = aToken;
            int num = Convert.ToInt16(aToken.Substring(1, 1));
            int num2 = Convert.ToInt16(aToken.Substring(2, 1));
            int num3 = Convert.ToInt16(aToken.Substring(4, 1));
            int[] source = new int[] { num, num2, num3 };
            int num5 = source.Max();
            int num6 = source.Min();
            str5 = Math.Abs((int) ((((Convert.ToInt16(aToken.Substring(aToken.Length - 3, 3)) - 0xde) - (((num + num2) + num3) + (Convert.ToInt16(num + num2 + num3) - ((num * num2) * num3)))) - (0x2a * num6)) / num5)).ToString();
            if (str5 == "1")
            {
                str5 = "01";
            }
            else if (str5 == "2")
            {
                str5 = "02";
            }
            else if (str5 == "3")
            {
                str5 = "03";
            }
            else if (str5 == "4")
            {
                str5 = "04";
            }
            else if (str5 == "5")
            {
                str5 = "05";
            }
            else if (str5 == "6")
            {
                str5 = "06";
            }
            else if (str5 == "7")
            {
                str5 = "07";
            }
            else if (str5 == "8")
            {
                str5 = "08";
            }
            else if (str5 == "9")
            {
                str5 = "09";
            }
            return str5;
        }

        public void initData(string[] tokenParams, string mode, string ztbl, string key, string key_2)
        {
            this.dblToken = false;
            this.differ = key_2;
            this.tblName = ztbl;
            if (mode == "COMM_CONT_TOL")
            {
                this.DoNo = key;
            }
            else
            {
                this.jlhEdit = key;
            }
            this.TokenParam2 = tokenParams[0];
            while (true)
            {
                WBTable table = new WBTable();
                if (mode == "MARK_ACCIDENT")
                {
                    table.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(" AND token_code = '" + mode + "'"), WBData.conn);
                    if (table.DT.Rows.Count > 0)
                    {
                        this.textBoxToken.Text = table.DT.Rows[0]["token_no"].ToString();
                    }
                    else if (table.DT.Rows.Count == 0)
                    {
                        this.textBoxToken.Text = this.aToken.generateToken(tokenParams, mode, "", "").Trim();
                        table.DR = table.DT.NewRow();
                        table.DR["coy"] = WBData.sCoyCode;
                        table.DR["location_code"] = WBData.sLocCode;
                        table.DR["key_1"] = "";
                        table.DR["token_code"] = mode;
                        table.DR["token_no"] = this.textBoxToken.Text;
                        table.DR["completed"] = "N";
                        table.DT.Rows.Add(table.DR);
                        table.Save();
                    }
                }
                table.Dispose();
                if (this.textBoxToken.Text.Trim() == "")
                {
                    if (mode != "COMM_CONT_TOL")
                    {
                        this.textBoxToken.Text = this.aToken.generateToken(tokenParams, mode, "", "").Trim();
                    }
                    else
                    {
                        this.textBoxToken.Text = this.aToken.generateToken(tokenParams, mode, "0.4", "0").Trim();
                        this.textBoxToken.Text = this.aToken.TokenDeviation(this.DoNo, this.textBoxToken.Text);
                    }
                }
                this.buttonProcess.Enabled = true;
                this.textBoxPIN.Enabled = false;
                this.labelInstruct.Visible = true;
                this.token1 = this.textBoxToken.Text;
                if ((this.tblName.ToUpper() == "WB_CONTRACT") && (this.pmode == "GRCUST"))
                {
                    this.dblToken = this.cekDoubleToken(this.textBoxToken.Text.Trim());
                }
                if (this.oldToken != "")
                {
                    this.labelInstruct.Visible = false;
                    this.textBoxPIN.Enabled = true;
                    this.newCode = this.aToken.getMenuCode(mode);
                    this.oldCode = this.get_code(this.oldToken);
                    if ((this.newCode == this.oldCode) || (this.oldToken.Trim() == ""))
                    {
                        this.token2 = this.textBoxToken.Text;
                    }
                    else
                    {
                        string[] textArray1 = new string[] { Resource.Mes_Confirm_Older_Token, " (", this.oldToken, "). \n", Resource.Mes_Confirm_Older_Token_2 };
                        if (MessageBox.Show(string.Concat(textArray1), Resource.Mes_Confirmation, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                        {
                            this.close = true;
                        }
                        else
                        {
                            if (mode != "COMM_CONT_TOL")
                            {
                                string[] parameters = new string[] { "" };
                                this.textBoxToken.Text = this.aToken.generateToken(parameters, mode, "", "").Trim();
                            }
                            else
                            {
                                string[] parameters = new string[] { "" };
                                this.textBoxToken.Text = this.aToken.generateToken(parameters, mode, this.txtCommTol.Text.Trim(), this.txtAllTrx.Text.Trim()).Trim();
                                this.textBoxToken.Text = this.aToken.TokenDeviation(this.DoNo, this.textBoxToken.Text);
                            }
                            this.textBoxPIN.Enabled = false;
                            this.token2 = this.textBoxToken.Text;
                        }
                    }
                }
                if (!this.dblToken)
                {
                    this.pmode = mode;
                    if (this.pmode == "COMM_CONT_TOL")
                    {
                        this.Text = Resource.Title_Token_CMD + this.tblName.Substring(3, this.tblName.Length - 3).ToUpper();
                    }
                    else
                    {
                        string[] textArray4 = new string[] { Resource.Title_Token, " ", this.pmode.ToUpper(), " ", this.tblName.Substring(3, this.tblName.Length - 3).ToUpper() };
                        this.Text = string.Concat(textArray4);
                    }
                    if ((this.tblName.ToUpper() == "WB_TRANSACTION") && (((this.pmode == "EDIT") || ((this.pmode == "QTY") || ((this.pmode == "DEDUCTION") || (this.pmode == "EDIT_SPB")))) || (this.pmode == "EDIT_REPORTDATE")))
                    {
                        this.textWarning.Visible = true;
                        this.labelEdit.Visible = true;
                        this.labelEdit.Text = Resource.Lbl_Edit_No + " = " + this.jlhEdit + " x";
                    }
                    this.lastToken = this.textBoxToken.Text.Trim();
                    return;
                }
            }
        }

        private void InitializeComponent()
        {
            this.buttonProcess = new Button();
            this.button1 = new Button();
            this.textBoxToken = new TextBox();
            this.label1 = new Label();
            this.label2 = new Label();
            this.textBoxPIN = new TextBox();
            this.textWarning = new TextBox();
            this.labelEdit = new Label();
            this.labelQty = new Label();
            this.textQty = new TextBox();
            this.label3 = new Label();
            this.textMessage = new TextBox();
            this.txtAllTrx = new TextBox();
            this.lblAllTrx = new Label();
            this.txtCommTol = new TextBox();
            this.lblCommTol = new Label();
            this.lblPercen = new Label();
            this.labelInstruct = new TextBox();
            base.SuspendLayout();
            this.buttonProcess.Location = new Point(0x5c, 0xfc);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(0x5d, 0x2b);
            this.buttonProcess.TabIndex = 0;
            this.buttonProcess.Text = "&Request for PIN";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.button1.Location = new Point(0xf2, 0xfc);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x5d, 0x2b);
            this.button1.TabIndex = 1;
            this.button1.Text = "&Cancel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBoxToken.BackColor = SystemColors.Window;
            this.textBoxToken.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textBoxToken.HideSelection = false;
            this.textBoxToken.Location = new Point(90, 12);
            this.textBoxToken.Name = "textBoxToken";
            this.textBoxToken.ReadOnly = true;
            this.textBoxToken.Size = new Size(290, 0x1f);
            this.textBoxToken.TabIndex = 2;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x12, 0x18);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x42, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Token Code";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(30, 0x76);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x35, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "PIN Code";
            this.textBoxPIN.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textBoxPIN.Location = new Point(90, 0x6a);
            this.textBoxPIN.MaxLength = 15;
            this.textBoxPIN.Name = "textBoxPIN";
            this.textBoxPIN.Size = new Size(290, 0x1f);
            this.textBoxPIN.TabIndex = 5;
            this.textBoxPIN.TextChanged += new EventHandler(this.textBoxPIN_TextChanged);
            this.textWarning.BackColor = SystemColors.Control;
            this.textWarning.BorderStyle = BorderStyle.None;
            this.textWarning.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textWarning.ForeColor = Color.Red;
            this.textWarning.Location = new Point(3, 0x138);
            this.textWarning.Multiline = true;
            this.textWarning.Name = "textWarning";
            this.textWarning.Size = new Size(0x1a1, 0x12);
            this.textWarning.TabIndex = 6;
            this.textWarning.Text = "WARNING : MAXIMUM EDIT RECORD IS 5 X TIMES";
            this.textWarning.Visible = false;
            this.labelEdit.AutoSize = true;
            this.labelEdit.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelEdit.ForeColor = Color.Red;
            this.labelEdit.Location = new Point(3, 0x14d);
            this.labelEdit.Name = "labelEdit";
            this.labelEdit.Size = new Size(0xcc, 0x11);
            this.labelEdit.TabIndex = 7;
            this.labelEdit.Text = "Number of Edit = 0 x Times";
            this.labelEdit.Visible = false;
            this.labelQty.AutoSize = true;
            this.labelQty.Location = new Point(0x26, 0x53);
            this.labelQty.Name = "labelQty";
            this.labelQty.Size = new Size(0x2e, 13);
            this.labelQty.TabIndex = 9;
            this.labelQty.Text = "Quantity";
            this.textQty.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textQty.Location = new Point(90, 0x4e);
            this.textQty.MaxLength = 4;
            this.textQty.Name = "textQty";
            this.textQty.Size = new Size(70, 0x16);
            this.textQty.TabIndex = 10;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x21, 0x94);
            this.label3.Name = "label3";
            this.label3.Size = new Size(50, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Message";
            this.textMessage.Location = new Point(90, 0x91);
            this.textMessage.MaxLength = 250;
            this.textMessage.Multiline = true;
            this.textMessage.Name = "textMessage";
            this.textMessage.Size = new Size(290, 0x49);
            this.textMessage.TabIndex = 12;
            this.txtAllTrx.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.txtAllTrx.Location = new Point(90, 0x31);
            this.txtAllTrx.MaxLength = 3;
            this.txtAllTrx.Name = "txtAllTrx";
            this.txtAllTrx.Size = new Size(70, 0x16);
            this.txtAllTrx.TabIndex = 14;
            this.txtAllTrx.Text = "0";
            this.txtAllTrx.Visible = false;
            this.txtAllTrx.KeyPress += new KeyPressEventHandler(this.txtAllTrx_KeyPress);
            this.txtAllTrx.Leave += new EventHandler(this.txtAllTrx_Leave);
            this.lblAllTrx.AutoSize = true;
            this.lblAllTrx.Location = new Point(0x16, 0x36);
            this.lblAllTrx.Name = "lblAllTrx";
            this.lblAllTrx.Size = new Size(0x38, 13);
            this.lblAllTrx.TabIndex = 13;
            this.lblAllTrx.Text = "Unit of Trx";
            this.lblAllTrx.Visible = false;
            this.txtCommTol.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.txtCommTol.Location = new Point(290, 0x31);
            this.txtCommTol.MaxLength = 3;
            this.txtCommTol.Name = "txtCommTol";
            this.txtCommTol.Size = new Size(70, 0x16);
            this.txtCommTol.TabIndex = 0x10;
            this.txtCommTol.Text = "0.4";
            this.txtCommTol.TextAlign = HorizontalAlignment.Right;
            this.txtCommTol.Visible = false;
            this.txtCommTol.KeyPress += new KeyPressEventHandler(this.txtCommTol_KeyPress);
            this.txtCommTol.Leave += new EventHandler(this.txtCommTol_Leave);
            this.lblCommTol.AutoSize = true;
            this.lblCommTol.Location = new Point(0xcb, 0x36);
            this.lblCommTol.Name = "lblCommTol";
            this.lblCommTol.Size = new Size(0x54, 13);
            this.lblCommTol.TabIndex = 15;
            this.lblCommTol.Text = "Comm Tol/UOM";
            this.lblCommTol.Visible = false;
            this.lblPercen.AutoSize = true;
            this.lblPercen.Location = new Point(0x16d, 0x36);
            this.lblPercen.Name = "lblPercen";
            this.lblPercen.Size = new Size(15, 13);
            this.lblPercen.TabIndex = 0x11;
            this.lblPercen.Text = "%";
            this.lblPercen.Visible = false;
            this.labelInstruct.BackColor = SystemColors.Control;
            this.labelInstruct.BorderStyle = BorderStyle.None;
            this.labelInstruct.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelInstruct.ForeColor = Color.Red;
            this.labelInstruct.Location = new Point(90, 0xe0);
            this.labelInstruct.Multiline = true;
            this.labelInstruct.Name = "labelInstruct";
            this.labelInstruct.Size = new Size(290, 0x12);
            this.labelInstruct.TabIndex = 0x12;
            this.labelInstruct.Text = "PLEASE REQUEST PIN FIRST TO ENTRY PIN";
            this.labelInstruct.Visible = false;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x191, 0x169);
            base.ControlBox = false;
            base.Controls.Add(this.labelInstruct);
            base.Controls.Add(this.lblPercen);
            base.Controls.Add(this.txtCommTol);
            base.Controls.Add(this.lblCommTol);
            base.Controls.Add(this.txtAllTrx);
            base.Controls.Add(this.lblAllTrx);
            base.Controls.Add(this.textMessage);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textQty);
            base.Controls.Add(this.labelQty);
            base.Controls.Add(this.labelEdit);
            base.Controls.Add(this.textWarning);
            base.Controls.Add(this.textBoxPIN);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.textBoxToken);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.buttonProcess);
            base.KeyPreview = true;
            base.Name = "FormToken";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Token";
            base.Load += new EventHandler(this.FormToken_Load);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private string isTokenParamRef(string token_param)
        {
            string str = WBData.sCoyCode + WBData.sLocCode;
            string str2 = "";
            WBTable table = new WBTable();
            if ((token_param.Length >= str.Length) && (token_param.Substring(0, str.Length) == str))
            {
                table.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Ref = '" + token_param + "'"), WBData.conn);
            }
            if ((table.DT != null) && (table.DT.Rows.Count > 0))
            {
                str2 = table.DT.Rows[0]["Ref"].ToString();
            }
            return str2;
        }

        private void saveWhenError()
        {
            WBTable table = new WBTable();
            if (this.type.ToUpper() == "BEFORE_EDIT")
            {
                table.saveTokenCodeBeforeEdit(this.pmode, this.jlhEdit, this.email_code, this.email_date, this.DM, this);
            }
            if (this.type.ToUpper() == "TOKEN_OR_APP")
            {
                table.saveTokenCodeOrApp(this.WB, this.TOAPM, this.disable_condition_params, this);
            }
            if (this.type.ToUpper() == "TOKEN_OR_APP_WRITE_TO_ERROR_LIST")
            {
                table.saveTokenCodeOrApp_WritetoErrorList(this.WB, this.TOAPM, this.disable_condition_params, this);
            }
        }

        private void sendEmailToken(string email_code)
        {
            WBMail mail = new WBMail();
            string str = "";
            string str2 = "";
            if (this.tblName.Length > 3)
            {
                str2 = this.tblName.Substring(3, this.tblName.Length - 3).ToUpper();
            }
            DateTime time = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd"));
            string str3 = "";
            List<string> list = null;
            string str4 = "";
            string str5 = "";
            string str6 = "";
            if (this.disable_condition_params != null)
            {
                str3 = this.disable_condition_params["ToBeDisabledCondition"].ToString();
                list = (List<string>) this.disable_condition_params["appliedLocation"];
                str4 = this.disable_condition_params["requested_start_inactive_time"].ToString();
                str5 = this.disable_condition_params["requested_end_inactive_time"].ToString();
                str6 = this.disable_condition_params["disableSeparator"].ToString();
            }
            string[] textArray1 = new string[] { "Dear Sir/Madam, <br><br>PIN HAVE BEEN REQUESTED<br><br><a href='http://token.wilmar.co.id:8080/generate/?t=", this.textBoxToken.Text.Trim(), "&uid=", WBEncryption.Encrypt(WBUser.UserID), "'>Click here to directly go to Web Token </a><br><br><table border=0 rules=all cellpadding=3 cellspacing=-1>" };
            str = string.Concat(textArray1);
            if (list == null)
            {
                str = str + (("<tr class='bd'><td nowrap>Company</td><td nowrap> : </td><td nowrap>" + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : </td><td nowrap>" + WBSetting.Field("Location_name")) + "</tr>";
            }
            else
            {
                str = str + "<tr class='bd'><td nowrap>Requested Locations(s)</td><td nowrap> : </td><td nowrap>" + list[0] + "</tr>";
                int num = 1;
                while (true)
                {
                    if (num >= list.Count)
                    {
                        str = str + "</tr>";
                        break;
                    }
                    str = str + "<tr class='bd'><td nowrap></td><td nowrap></td><td nowrap>" + list[num];
                    num++;
                }
            }
            string[] textArray2 = new string[] { "<tr class='bd'><td nowrap>Request Time</td><td nowrap> : </td><td nowrap>" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), "</tr><tr class='bd'><td nowrap>Request By</td><td nowrap> : </td><td nowrap>", WBUser.UserID, " - ", WBUser.UserName, "</tr><tr class='bd'><td nowrap>Token No</td><td nowrap> : </td><td nowrap>", this.textBoxToken.Text.Trim() };
            str = str + string.Concat(textArray2) + "</tr>";
            if (string.IsNullOrEmpty(str3))
            {
                str = str + "<tr class='bd'><td nowrap>Menu</td><td nowrap> : </td><td nowrap>";
            }
            else
            {
                string[] textArray3 = new string[] { str, "<tr class='bd'><td nowrap>Menu</td><td nowrap> : </td><td nowrap>", this.pmode.ToUpper(), " (", str3, ")</tr>" };
                str = string.Concat(textArray3);
            }
            if (this.pmode.ToUpper() == "MANUAL")
            {
                str = str + "ENTRY MANUAL TRANSACTION</tr>";
            }
            else if (this.pmode.ToUpper() == "QTY")
            {
                str = str + "EDIT QTY TRANSACTION</tr>";
            }
            else if (this.pmode.ToUpper() == "DEDUCTION")
            {
                str = str + "EDIT TRANSACTION DEDUCTION</tr>";
            }
            else if (this.pmode.ToUpper() == "EDIT_SPB")
            {
                str = str + "EDIT TRANSACTION DELIVERY NOTE</tr>";
            }
            else if (this.pmode.ToUpper() == "EDIT_REPORTDATE")
            {
                str = str + "EDIT TRANSACTION REPORT DATE</tr>";
            }
            else if (this.pmode.ToUpper() == "COMM_CONT_TOL")
            {
                str = str + "COMMODITY CONTRACT TOLERANCE</tr>";
            }
            else if (this.pmode.ToUpper() == "DISABLE_CONDITION")
            {
                str = str + "</tr>";
            }
            else
            {
                string[] textArray4 = new string[] { str, this.pmode.ToUpper(), " ", str2, "</tr>" };
                str = string.Concat(textArray4);
            }
            if (this.pmode.ToUpper() == "OVERQTY")
            {
                str = (str + "<tr class='bd'><td nowrap>Ref</td><td nowrap> : </td><td nowrap>" + this.TokenParam2) + "</tr>";
            }
            else
            {
                string str7 = this.isTokenParamRef(this.TokenParam2);
                if (!string.IsNullOrEmpty(str7))
                {
                    str = (str + "<tr class='bd'><td nowrap>Ref No</td><td nowrap> : </td><td nowrap>" + str7) + "</tr>";
                }
                else if (!string.IsNullOrEmpty(this.trans_ref))
                {
                    str = (str + "<tr class='bd'><td nowrap>Ref No</td><td nowrap> : </td><td nowrap>" + this.trans_ref) + "</tr>";
                }
            }
            if ((this.tblName.ToUpper().Trim() == "WB_TRANSACTION") && (this.pmode.ToUpper() == "MANUAL"))
            {
                str = (str + "<tr class='bd'><td nowrap>Quantity Entry</td><td nowrap> : </td><td nowrap>" + this.textQty.Text.ToUpper()) + "</tr>";
            }
            else if (this.pmode.ToUpper() == "OVER_GROSSQTY")
            {
                str = (str + "<tr class='bd'><td nowrap>Different</td><td nowrap> : </td><td nowrap>" + this.differ) + "</tr>";
            }
            if (!string.IsNullOrEmpty(str4))
            {
                str = str + "<tr class='bd'><td nowrap>Start Time</td><td nowrap> : </td><td nowrap>" + str4 + ":00</tr>";
            }
            if (!string.IsNullOrEmpty(str5))
            {
                str = str + "<tr class='bd'><td nowrap>End Time</td><td nowrap> : </td><td nowrap>" + str5 + ":00</tr>";
            }
            if (this.textMessage.Text != "")
            {
                int index = 0;
                while (true)
                {
                    if (index >= this.textMessage.Lines.Length)
                    {
                        break;
                    }
                    if (index == 0)
                    {
                        str = str + "<tr class='bd'><td nowrap>Message</td><td nowrap> : </td><td nowrap>" + this.textMessage.Lines[index] + "</td></tr>";
                    }
                    else if (index != 1)
                    {
                        str = str + "<tr><td nowrap>&nbsp;&nbsp;" + this.textMessage.Lines[index] + "</td></tr>";
                    }
                    else
                    {
                        object[] objArray1 = new object[] { str, "<tr><td rowspan=", this.textMessage.Lines.Length - 1, " nowrap></td><td nowrap>&nbsp;&nbsp;", this.textMessage.Lines[index], "</td></tr>" };
                        str = string.Concat(objArray1);
                    }
                    index++;
                }
            }
            str = str + "</table><br><br>Thank You. ";
            WBTable table = new WBTable();
            table.OpenTable("wb_email_master", "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND ( Email_Code ='" + email_code + "')"), WBData.conn);
            int num3 = 0;
            while (true)
            {
                if (num3 >= table.DT.Rows.Count)
                {
                    mail.Body = str;
                    try
                    {
                        mail.SendMail();
                    }
                    catch
                    {
                        MessageBox.Show(Resource.Mes_Fail_Send_Email, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    return;
                }
                DataRow row = table.DT.Rows[num3];
                string[] textArray5 = new string[] { row[0].ToString().Trim(), " ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
                mail.Subject = string.Concat(textArray5);
                mail.To = row[1].ToString().Trim();
                mail.CC = row[2].ToString().Trim();
                num3++;
            }
        }

        private bool sendHTTPRequest(string token_, string user_, string reason_)
        {
            string str8;
            string message;
            bool flag5;
            bool flag = true;
            bool flag2 = false;
            bool flag3 = false;
            string str = WBSetting.token_path;
            if (str != "")
            {
                string[] textArray1 = new string[] { "tkn=", token_, "&user=", user_, "&rmk=", reason_, "&user_name=", (WBUser.UserName.Length > 20) ? WBUser.UserName.Substring(0, 20) : WBUser.UserName };
                string str2 = WBEncryption.Encrypt(string.Concat(textArray1));
                string str3 = this.isTokenParamRef(this.TokenParam2);
                if (!string.IsNullOrEmpty(str3))
                {
                    str2 = str2 + "&trans_ref=" + str3;
                }
                else if (!string.IsNullOrEmpty(this.trans_ref))
                {
                    str2 = str2 + "&trans_ref=" + this.trans_ref;
                }
                string str4 = "";
                string str5 = "";
                string str6 = "";
                string str7 = "";
                if (this.disable_condition_params != null)
                {
                    str4 = this.disable_condition_params["ToBeDisabledCondition"].ToString();
                    str5 = string.Join(this.disable_condition_params["disableSeparator"].ToString(), (List<string>) this.disable_condition_params["appliedLocation"]);
                    str6 = this.disable_condition_params["requested_start_inactive_time"].ToString();
                    str7 = this.disable_condition_params["requested_end_inactive_time"].ToString();
                }
                if (!string.IsNullOrEmpty(str4))
                {
                    str2 = str2 + "&df=" + str4;
                }
                if (!string.IsNullOrEmpty(str5))
                {
                    str2 = str2 + "&dai=" + str5;
                }
                if (!string.IsNullOrEmpty(str6))
                {
                    str2 = str2 + "&st=" + str6;
                }
                if (!string.IsNullOrEmpty(str7))
                {
                    str2 = str2 + "&et=" + str7;
                }
                str8 = str + "?p=" + str2;
                message = "";
            }
            else
            {
                MessageBox.Show("Failed sending token: \n Token Path Not Found, please contact MIS HO", "FAILED SENDING TOKEN", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return false;
            }
            while (true)
            {
                if (!(flag && (this.sendingSMSCount < this.toleranceForSendingSMS)))
                {
                    if (this.sendingSMSCount >= this.toleranceForSendingSMS)
                    {
                        this.sendingSMSCount = 0;
                        string[] textArray4 = new string[9];
                        textArray4[0] = Resource.Mes_Fail_Send_Token;
                        textArray4[1] = ": \n";
                        textArray4[2] = message;
                        textArray4[3] = "\n\n";
                        textArray4[4] = Resource.Mes_Fail_Send_Token_2;
                        textArray4[5] = " ";
                        textArray4[6] = token_;
                        textArray4[7] = " ";
                        textArray4[8] = Resource.Mes_Fail_Send_Token_3;
                        MessageBox.Show(string.Concat(textArray4), Resource.Mes_Fail_Send_Token_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    flag5 = flag3;
                    break;
                }
                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    using (WebClient client = new WebClient())
                    {
                        string[] separator = new string[] { "<!DOCTYPE" };
                        char[] chArray1 = new char[] { '|' };
                        string[] strArray2 = Convert.ToString(client.DownloadString(str8)).Split(separator, StringSplitOptions.None)[0].Trim().Split(chArray1);
                        if (strArray2[0].ToUpper().Trim() == "OK")
                        {
                            string[] textArray3 = new string[] { Resource.Mes_Success_Send_Token, ": ", token_, " !\n\n", strArray2[1].Trim() };
                            MessageBox.Show(string.Concat(textArray3), Resource.Mes_Success, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            flag2 = true;
                            flag3 = true;
                            flag = false;
                        }
                        else
                        {
                            message = this.firstLetterToUpper(strArray2[0].Trim().Replace("*", "").Replace(".", "").Trim());
                            if (strArray2[1].ToUpper().Trim().Contains("SYSERR"))
                            {
                                flag3 = false;
                            }
                            else if (strArray2[1].ToUpper().Trim().Contains("ERR-"))
                            {
                                if (strArray2[1].ToUpper().Trim() == "ERR-01")
                                {
                                    this.userNotMaintainedYet = true;
                                }
                                flag3 = false;
                            }
                            flag2 = false;
                            flag = true;
                            this.sendingSMSCount++;
                        }
                    }
                    Cursor.Current = Cursors.Default;
                }
                catch (Exception exception1)
                {
                    flag2 = false;
                    flag = true;
                    this.sendingSMSCount++;
                    flag3 = false;
                    message = exception1.Message;
                }
            }
            return flag5;
        }

        private void textBoxPIN_TextChanged(object sender, EventArgs e)
        {
            if (this.textBoxPIN.Text != "")
            {
                this.buttonProcess.Text = Resource.Btn_Process;
                this.textMessage.Text = "";
                this.textMessage.ReadOnly = true;
                this.textMessage.Enabled = false;
                this.lblCommTol.Visible = false;
                this.txtCommTol.Visible = false;
                this.lblAllTrx.Visible = false;
                this.txtAllTrx.Visible = false;
                this.lblPercen.Visible = false;
            }
            else
            {
                this.buttonProcess.Text = Resource.Btn_Request_PIN;
                this.textMessage.ReadOnly = false;
                this.textMessage.Enabled = true;
                if (this.pmode == "COMM_CONT_TOL")
                {
                    this.lblCommTol.Visible = true;
                    this.txtCommTol.Visible = true;
                    this.lblAllTrx.Visible = true;
                    this.txtAllTrx.Visible = true;
                    this.lblPercen.Visible = true;
                }
            }
        }

        private void translate()
        {
            this.buttonProcess.Text = Resource.Btn_Request_PIN;
            this.button1.Text = Resource.Btn_Cancel;
            this.label1.Text = Resource.Lbl_Token_Code;
            this.label2.Text = Resource.Lbl_PIN_Code;
            this.textWarning.Text = Resource.Txt_Warning_Max_Edit;
            this.labelEdit.Text = Resource.Lbl_Edit_No + " = " + this.jlhEdit + " x";
            this.labelQty.Text = Resource.Contract_008;
            this.label3.Text = Resource.Lbl_Message;
            this.lblAllTrx.Text = Resource.Lbl_All_Trx;
            this.lblCommTol.Text = Resource.Lbl_Comm_Tol;
            this.Text = Resource.Contract_069;
        }

        private void txtAllTrx_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "0123456789".IndexOfAny(anyOf) <= -1;
            }
        }

        private void txtAllTrx_Leave(object sender, EventArgs e)
        {
            if (this.txtAllTrx.Text.Trim() == "")
            {
                this.txtAllTrx.Text = "0";
            }
            if (Convert.ToInt16(this.txtAllTrx.Text) > 900)
            {
                MessageBox.Show(Resource.Mes_Max_Transaction + " 900!", Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.txtAllTrx.Focus();
            }
            else
            {
                string[] parameters = new string[] { "" };
                this.textBoxToken.Text = this.aToken.generateToken(parameters, "COMM_CONT_TOL", this.txtCommTol.Text.Trim(), this.txtAllTrx.Text.Trim()).Trim();
                this.textBoxToken.Text = this.aToken.TokenDeviation(this.DoNo, this.textBoxToken.Text);
                if (this.lastToken != this.textBoxToken.Text.Trim())
                {
                    this.lastToken = this.textBoxToken.Text.Trim();
                    MessageBox.Show(Resource.Mes_Warning_Token_Changed, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private void txtCommTol_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                char[] anyOf = new char[] { e.KeyChar };
                e.Handled = "0123456789.".IndexOfAny(anyOf) <= -1;
            }
        }

        private void txtCommTol_Leave(object sender, EventArgs e)
        {
            if (this.txtCommTol.Text.Trim() == "")
            {
                this.txtCommTol.Text = "0.4";
            }
            if ((Convert.ToDouble(this.txtCommTol.Text) < 0.4) || (Convert.ToDouble(this.txtCommTol.Text) > 8.4))
            {
                MessageBox.Show(Resource.Mes_Warning_Tolerance_Range + " 8.4% " + Resource.Mes_Warning_Tolerance_Range_2 + " 0.4% !", Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.txtCommTol.Focus();
            }
            else
            {
                string[] parameters = new string[] { "" };
                this.textBoxToken.Text = this.aToken.generateToken(parameters, "COMM_CONT_TOL", this.txtCommTol.Text.Trim(), this.txtAllTrx.Text.Trim()).Trim();
                this.textBoxToken.Text = this.aToken.TokenDeviation(this.DoNo, this.textBoxToken.Text);
                if (this.lastToken != this.textBoxToken.Text.Trim())
                {
                    this.lastToken = this.textBoxToken.Text.Trim();
                    MessageBox.Show(Resource.Mes_Warning_Token_Changed, Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }
    }
}

