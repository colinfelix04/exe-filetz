﻿namespace WindowsFormsApplication1
{
    using Encryption.Utility;
    using System;
    using System.ComponentModel;
    using System.IO;
    using System.Threading;
    using WindowsFormsApplication1.Utility;

    public class WBIndicator_File : Component
    {
        public const string UWB_FOLDER_NAME = "UWB";
        private static string regWbCheck0 = "MSCRT1";
        private static string regWbStatus = "MSCRT2";
        private static string regWbValue = "MSDAT1";
        private static string secretFile = (Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "UWB") + @"\INDICATOR\MSCRT");
        private static string configFile = (Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "UWB") + @"\INDICATOR\MCFG");
        private static string dataFile = (Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "UWB") + @"\INDICATOR\MSDAT");
        private static string cmdZeroFile = (Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "UWB") + @"\INDICATOR\MCMDZ");
        public string wbStatus = "N";
        public string wbCheck0 = "N";
        public string wbValue = "";
        public string msgStatus = "";
        private string[] mscrt = new string[1];
        private string[] msdat = new string[15];
        private string[] mscfg = new string[15];

        public bool check0()
        {
            bool flag = false;
            this.readText(secretFile, this.mscrt);
            if (this.wbStatus != "13")
            {
                flag = false;
            }
            else
            {
                this.wbCheck0 = this.mscrt[0].Substring(0x13, 1);
                flag = this.wbCheck0 != "X";
            }
            return flag;
        }

        public void checkStatus()
        {
            this.readText(configFile, this.mscfg);
            if (File.Exists(dataFile))
            {
                this.writeFileStatus();
            }
            else
            {
                this.writeErrStatus();
            }
            this.msgStatus = (this.wbStatus != "13") ? ((this.wbStatus != "33") ? "Unavailable" : "Setting Error") : "Connected";
        }

        public void Init()
        {
            Directory.CreateDirectory(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "UWB") + @"\INDICATOR");
            this.initDefaultData();
            this.readText(secretFile, this.mscrt);
            this.readText(configFile, this.mscfg);
            this.readText(dataFile, this.msdat);
        }

        private void initDefaultData()
        {
            if (!File.Exists(secretFile))
            {
                this.mscrt[0] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "X";
                this.writeTextAll(secretFile, this.mscrt);
            }
            if (!File.Exists(configFile))
            {
                this.mscfg[0] = "7";
                this.mscfg[1] = "2400,e,7,1,";
                this.mscfg[2] = "9";
                this.mscfg[3] = "6";
                this.mscfg[4] = "";
                this.mscfg[5] = "qwaszx123";
                this.mscfg[6] = "0";
                this.mscfg[7] = "0";
                this.writeTextAll(configFile, this.mscfg);
            }
            if (!File.Exists(dataFile))
            {
                this.msdat[0] = "0";
                this.writeTextAll(dataFile, this.msdat);
            }
        }

        private void readText(string filePath, string[] pfile)
        {
            try
            {
                string[] strArray = null;
                using (FileStream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        char[] separator = new char[] { '\n' };
                        strArray = reader.ReadToEnd().Split(separator);
                    }
                }
                int index = 0;
                while (true)
                {
                    if (index >= strArray.Length)
                    {
                        break;
                    }
                    strArray[index] = strArray[index].Replace("\r", "");
                    if ((strArray[index] != "") && (strArray[index] != null))
                    {
                        pfile[index] = WBEncryption.Decrypt(strArray[index]);
                    }
                    index++;
                }
            }
            catch (Exception)
            {
            }
        }

        public void readValue()
        {
            this.readText(dataFile, this.msdat);
            this.wbValue = (this.wbStatus != "13") ? "0" : this.msdat[0];
        }

        public void updateCheck0()
        {
            this.mscrt[0] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "X";
            this.writeTextLine(secretFile, this.mscrt, 0);
        }

        public void writeErrStatus()
        {
            this.wbStatus = "43";
        }

        public void writeFileStatus()
        {
            this.wbStatus = "13";
        }

        private void writeTextAll(string filePath, string[] pfile)
        {
            int num = 0;
            while (num < Constant.TOLERANCE_FOR_WRITING_TXT)
            {
                try
                {
                    int index = 0;
                    while (true)
                    {
                        if (index >= pfile.Length)
                        {
                            StreamWriter writer = new StreamWriter(filePath);
                            int num3 = 0;
                            while (true)
                            {
                                if (num3 >= pfile.Length)
                                {
                                    writer.Dispose();
                                    break;
                                }
                                string str = pfile[num3];
                                writer.WriteLine(str);
                                num3++;
                            }
                            break;
                        }
                        if ((pfile[index] != "") && (pfile[index] != null))
                        {
                            pfile[index] = WBEncryption.Encrypt(pfile[index]);
                        }
                        index++;
                    }
                    break;
                }
                catch
                {
                    num++;
                    Thread.Sleep(10);
                }
            }
        }

        private void writeTextLine(string filePath, string[] pfile, int no)
        {
            int num = 0;
            while (num < Constant.TOLERANCE_FOR_WRITING_TXT)
            {
                try
                {
                    string[] strArray = new string[pfile.Length];
                    string[] strArray2 = new string[pfile.Length];
                    using (FileStream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        using (StreamReader reader = new StreamReader(stream))
                        {
                            char[] separator = new char[] { '\n' };
                            strArray = reader.ReadToEnd().Split(separator);
                        }
                    }
                    int index = 0;
                    while (true)
                    {
                        if (index >= pfile.Length)
                        {
                            StreamWriter writer = new StreamWriter(filePath);
                            int num3 = 0;
                            while (true)
                            {
                                if (num3 >= strArray2.Length)
                                {
                                    writer.Dispose();
                                    break;
                                }
                                string str = strArray2[num3];
                                writer.WriteLine(str);
                                num3++;
                            }
                            break;
                        }
                        if (no != index)
                        {
                            strArray2[index] = strArray[index];
                        }
                        else if ((pfile[no] != "") && (pfile[no] != null))
                        {
                            strArray2[no] = WBEncryption.Encrypt(pfile[no]);
                        }
                        index++;
                    }
                    break;
                }
                catch
                {
                    num++;
                    Thread.Sleep(10);
                }
            }
        }
    }
}

