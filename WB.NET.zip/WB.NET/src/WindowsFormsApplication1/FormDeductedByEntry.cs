﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormDeductedByEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public WBTable trans = new WBTable();
        private IContainer components = null;
        private Button button2;
        private Button button1;
        private Label label1;
        public ComboBox cbTrx_Code;
        private Label label2;
        public ComboBox cbInc_Code;
        private GroupBox groupBoxDeducted;
        private RadioButton radioSeller;
        private RadioButton radioBuyer;

        public FormDeductedByEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (((this.cbInc_Code.Text != "") && (this.cbTrx_Code.Text != "")) && (this.radioBuyer.Checked || this.radioSeller.Checked))
            {
                WBTable table = new WBTable();
                string[] textArray1 = new string[] { " AND ( transaction_code ='", this.cbTrx_Code.Text.Trim(), "' and incoterm_code ='", this.cbInc_Code.Text.Trim(), "')" };
                table.OpenTable("wb_deductedby", "SELECT Uniq FROM wb_deductedby WHERE " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || (this.pMode != "ADD"))
                {
                    table.Dispose();
                    if (this.pMode == "EDIT")
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = Resource.Trans_114 },
                            textRefNo = { Text = this.cbTrx_Code.Text },
                            Text = Resource.Title_Change_Reason,
                            label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                        }
                        else
                        {
                            return;
                        }
                    }
                    Cursor.Current = Cursors.WaitCursor;
                    this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                    this.zTable.ReOpen();
                    if (this.pMode == "ADD")
                    {
                        this.zTable.DR = this.zTable.DT.NewRow();
                    }
                    else
                    {
                        this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                        this.logKey = this.zTable.DR["uniq"].ToString();
                        this.zTable.DR.BeginEdit();
                    }
                    this.zTable.DR["Coy"] = WBData.sCoyCode;
                    this.zTable.DR["Location_Code"] = WBData.sLocCode;
                    this.zTable.DR["transaction_code"] = this.cbTrx_Code.Text;
                    this.zTable.DR["incoterm_code"] = this.cbInc_Code.Text;
                    this.zTable.DR["DeductedBy"] = this.radioBuyer.Checked ? "0" : "1";
                    if (this.pMode == "ADD")
                    {
                        this.zTable.DR["Create_By"] = WBUser.UserID;
                        this.zTable.DR["Create_Date"] = DateTime.Now;
                        this.zTable.DT.Rows.Add(this.zTable.DR);
                    }
                    else
                    {
                        this.zTable.DR["Change_By"] = WBUser.UserID;
                        this.zTable.DR["Change_Date"] = DateTime.Now;
                        this.zTable.DR.EndEdit();
                    }
                    this.zTable.Save();
                    if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
                    {
                        if (this.pMode == "ADD")
                        {
                            string str = this.radioBuyer.Checked ? "0" : "1";
                            string sqltext = ((("SELECT uniq FROM wb_deductedby WHERE " + WBData.CompanyLocation("")) + " AND transaction_code = '" + this.cbTrx_Code.Text + "'") + " AND incoterm_code = '" + this.cbInc_Code.Text + "'") + " AND DeductedBy = '" + str + "'";
                            WBTable table2 = new WBTable();
                            table2.OpenTable("wb_deductedby", sqltext, WBData.conn);
                            this.logKey = table2.DT.Rows[0]["uniq"].ToString();
                            table2.Dispose();
                        }
                        string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                        string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                        Program.updateLogHeader("wb_deductedby", this.logKey, logField, logValue);
                    }
                    this.saved = true;
                    Cursor.Current = Cursors.Default;
                    base.Close();
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_Transaction_Incoterm_Exist);
                    this.cbTrx_Code.Focus();
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_Fill_All);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormDeductedByEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormDeductedByEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            WBTable table = new WBTable();
            table.OpenTable("wb_transaction_type", "SELECT * FROM wb_transaction_type", WBData.conn);
            this.cbTrx_Code.Items.Clear();
            int num = 0;
            while (true)
            {
                DataRow row;
                if (num >= table.DT.Rows.Count)
                {
                    table.OpenTable("wb_incoterm", "SELECT * FROM wb_incoterm", WBData.conn);
                    this.cbInc_Code.Items.Clear();
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 >= table.DT.Rows.Count)
                        {
                            if (this.pMode == "ADD")
                            {
                                this.cbInc_Code.Enabled = true;
                                this.cbTrx_Code.Enabled = true;
                            }
                            else
                            {
                                this.cbInc_Code.Enabled = false;
                                this.cbTrx_Code.Enabled = false;
                                this.cbTrx_Code.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["transaction_code"].Value.ToString();
                                this.cbInc_Code.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Incoterm_code"].Value.ToString();
                                this.radioBuyer.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["DeductedBy"].Value.ToString() == "0";
                                this.radioSeller.Checked = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["DeductedBy"].Value.ToString() == "1";
                            }
                            if (this.pMode == "VIEW")
                            {
                                foreach (Control control in base.Controls)
                                {
                                    control.Enabled = false;
                                }
                                this.button2.Text = Resource.Btn_Close;
                                this.button2.Enabled = true;
                            }
                            return;
                        }
                        row = table.DT.Rows[num2];
                        this.cbInc_Code.Items.Add(row[2].ToString().Trim());
                        num2++;
                    }
                }
                row = table.DT.Rows[num];
                this.cbTrx_Code.Items.Add(row[2].ToString().Trim());
                num++;
            }
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.label1 = new Label();
            this.cbTrx_Code = new ComboBox();
            this.label2 = new Label();
            this.cbInc_Code = new ComboBox();
            this.groupBoxDeducted = new GroupBox();
            this.radioSeller = new RadioButton();
            this.radioBuyer = new RadioButton();
            this.groupBoxDeducted.SuspendLayout();
            base.SuspendLayout();
            this.button2.Location = new Point(0x73, 0xa3);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 12;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(14, 0xa3);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 11;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(11, 15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x5b, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Transaction Code";
            this.cbTrx_Code.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbTrx_Code.FormattingEnabled = true;
            this.cbTrx_Code.Location = new Point(120, 12);
            this.cbTrx_Code.Name = "cbTrx_Code";
            this.cbTrx_Code.Size = new Size(0x4d, 0x15);
            this.cbTrx_Code.TabIndex = 13;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(11, 0x35);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x4c, 13);
            this.label2.TabIndex = 0x10;
            this.label2.Text = "Incoterm Code";
            this.cbInc_Code.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cbInc_Code.FormattingEnabled = true;
            this.cbInc_Code.Location = new Point(120, 50);
            this.cbInc_Code.Name = "cbInc_Code";
            this.cbInc_Code.Size = new Size(0x4d, 0x15);
            this.cbInc_Code.TabIndex = 15;
            this.groupBoxDeducted.Controls.Add(this.radioSeller);
            this.groupBoxDeducted.Controls.Add(this.radioBuyer);
            this.groupBoxDeducted.Location = new Point(12, 0x56);
            this.groupBoxDeducted.Margin = new Padding(3, 4, 3, 4);
            this.groupBoxDeducted.Name = "groupBoxDeducted";
            this.groupBoxDeducted.Padding = new Padding(3, 4, 3, 4);
            this.groupBoxDeducted.Size = new Size(0xbb, 0x34);
            this.groupBoxDeducted.TabIndex = 0x11;
            this.groupBoxDeducted.TabStop = false;
            this.radioSeller.AutoSize = true;
            this.radioSeller.Location = new Point(0x67, 0x16);
            this.radioSeller.Margin = new Padding(3, 4, 3, 4);
            this.radioSeller.Name = "radioSeller";
            this.radioSeller.Size = new Size(70, 0x11);
            this.radioSeller.TabIndex = 1;
            this.radioSeller.TabStop = true;
            this.radioSeller.Text = "Other Qty";
            this.radioSeller.UseVisualStyleBackColor = true;
            this.radioBuyer.AutoSize = true;
            this.radioBuyer.Checked = true;
            this.radioBuyer.Location = new Point(13, 0x16);
            this.radioBuyer.Margin = new Padding(3, 4, 3, 4);
            this.radioBuyer.Name = "radioBuyer";
            this.radioBuyer.Size = new Size(0x4f, 0x11);
            this.radioBuyer.TabIndex = 0;
            this.radioBuyer.TabStop = true;
            this.radioBuyer.Text = "Factory Qty";
            this.radioBuyer.UseVisualStyleBackColor = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0xea, 0xce);
            base.ControlBox = false;
            base.Controls.Add(this.groupBoxDeducted);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.cbInc_Code);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.cbTrx_Code);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Name = "FormDeductedByEntry";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Form DeductedBy Entry";
            base.Load += new EventHandler(this.FormDeductedByEntry_Load);
            this.groupBoxDeducted.ResumeLayout(false);
            this.groupBoxDeducted.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label1.Text = Resource.Trans_114;
            this.label2.Text = Resource.Col_Incoterm_Code;
            this.radioSeller.Text = Resource.ContractE_004;
            this.radioBuyer.Text = Resource.ContractE_003;
            this.button2.Text = Resource.Btn_Cancel;
            this.button1.Text = Resource.Btn_Save;
            this.Text = Resource.Title_Deducted_By_Entry;
        }
    }
}

