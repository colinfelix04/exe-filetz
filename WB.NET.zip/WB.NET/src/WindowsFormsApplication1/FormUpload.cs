﻿namespace WindowsFormsApplication1
{
    using JR.Utils.GUI.Forms;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Properties;

    public class FormUpload : Form
    {
        private string module;
        private string type;
        private string tipeTrans;
        private string sapDest;
        private string comm_code;
        private WBTable tblTransporter = new WBTable();
        private WBTable tblcontract = new WBTable();
        private string n_estate = "0";
        private string n_truck = "0";
        private string n_transporter = "0";
        private string n_driver = "0";
        private string n_commodity = "0";
        private string n_contract = "0";
        private string n_relation = "0";
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private Button buttonProses;
        private Label labelDest;
        private ComboBox comboTable;
        private Button button1;
        private CheckBox checkcTrans;
        private Panel panel_filter;
        private GroupBox groupDetails;
        private Button button3;
        private TextBox textTransporter;
        private Label label1;
        private Button button11;
        public TextBox textDO;
        private Label label5;
        private ComboBox comboComm;
        private Label label2;
        private CheckBox chkAll;
        public DateTimePicker monthCalendar2;
        public DateTimePicker monthCalendar1;
        private Label label3;
        private Label label4;
        private GroupBox groupType;
        private Button btnExit;
        private RadioButton rbSD4;
        private RadioButton rbSales;
        private RadioButton rbSD2;
        private RadioButton rbSD1;
        private RadioButton rbPurchase;
        private CheckBox checkDate;
        private Label label_info;
        private CheckBox checkExcel;
        private Button buttonFilterAdmin;
        private CheckBox cBoxSyncMD;
        private TextBox textBoxRefNo;
        private Label label6;
        private Button buttonDestinationInfo;

        public FormUpload()
        {
            this.InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.type = "1";
            if (this.rbPurchase.Checked)
            {
                this.module = "MM";
            }
            else if (this.rbSD1.Checked)
            {
                this.module = "SD";
                this.type = "2";
            }
            else if (this.rbSD2.Checked)
            {
                this.module = "SD";
                this.type = "3";
            }
            else if (this.rbSales.Checked)
            {
                this.module = "SD";
                this.type = "1";
            }
            else if (this.rbSD4.Checked)
            {
                this.module = "SD";
                this.type = "5";
            }
            FormUploadSAP dsap = new FormUploadSAP {
                module = this.module,
                type = this.type,
                dateFrom = this.monthCalendar1.Value,
                dateTo = this.monthCalendar2.Value
            };
            dsap.ShowDialog();
            dsap.Dispose();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (this.comboTable.Text.Trim() == "")
            {
                MessageBox.Show("Please choose upload destination!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (Convert.ToDateTime(this.monthCalendar1.Value.ToShortDateString()) > Convert.ToDateTime(this.monthCalendar2.Value.ToShortDateString()))
            {
                MessageBox.Show("Date is invalid! From Date must be smaller than To Date!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (Math.Abs((this.monthCalendar1.Value - this.monthCalendar2.Value).Days) > Math.Abs(3))
            {
                MessageBox.Show("Interval date must less than or equals to 3 days!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                if (this.comboTable.Text.Trim() != "ZWB")
                {
                    this.tipeTrans = !this.rbPurchase.Checked ? "O" : "I";
                }
                else
                {
                    this.tipeTrans = "";
                    if (this.panel_filter.Visible)
                    {
                        this.tipeTrans = !this.rbPurchase.Checked ? "O" : "I";
                    }
                }
                this.comm_code = (this.comboComm.Text.Trim().ToUpper() == "ALL COMMODITY") ? "" : this.comboComm.Text.Trim().ToUpper();
                this.sapDest = this.comboTable.Text.Trim().ToUpper();
                if (WBSetting.integrationIDSYS)
                {
                    FormUploadZWB dzwb = new FormUploadZWB {
                        tipeTrans = this.tipeTrans,
                        sapDest = this.sapDest,
                        comm = this.comm_code,
                        transpt = this.textTransporter.Text.Trim(),
                        refNo = this.textBoxRefNo.Text.Trim(),
                        showAll = this.chkAll.Checked,
                        cTrans = this.checkcTrans.Checked
                    };
                    if (this.textDO.Text != "")
                    {
                        dzwb.Do_No = this.textDO.Text;
                    }
                    dzwb.auto = 'N';
                    dzwb.dateFrom = this.monthCalendar1.Value;
                    dzwb.dateTo = this.monthCalendar2.Value;
                    dzwb.ShowDialog();
                    dzwb.Dispose();
                    this.refresh_count_IDSYS();
                }
                else
                {
                    if (this.sapDest == "ZWB")
                    {
                        if ((WBUser.UserLevel != "1") || this.cBoxSyncMD.Checked)
                        {
                            this.sync_master_data(this.sapDest);
                        }
                        FormUploadZWB dzwb2 = new FormUploadZWB {
                            tipeTrans = this.tipeTrans,
                            sapDest = this.sapDest,
                            comm = this.comm_code,
                            transpt = this.textTransporter.Text.Trim(),
                            refNo = this.textBoxRefNo.Text.Trim(),
                            showAll = this.chkAll.Checked,
                            cTrans = this.checkcTrans.Checked
                        };
                        if (this.textDO.Text != "")
                        {
                            dzwb2.Do_No = this.textDO.Text;
                        }
                        dzwb2.auto = 'N';
                        dzwb2.dateFrom = this.monthCalendar1.Value;
                        dzwb2.dateTo = this.monthCalendar2.Value;
                        dzwb2.ShowDialog();
                        dzwb2.Dispose();
                    }
                    else if (this.sapDest == "SYNC MASTER DATA")
                    {
                        this.sync_master_data(this.sapDest);
                    }
                    else if (this.sapDest == "OTHER PARTY WEIGHT")
                    {
                        this.opw(this.sapDest);
                    }
                    else if (this.sapDest == "GATEPASS")
                    {
                        FormUploadGatepass gatepass = new FormUploadGatepass {
                            sapDest = this.sapDest,
                            comm = this.comm_code,
                            showAll = this.chkAll.Checked,
                            cTrans = this.checkcTrans.Checked
                        };
                        if (this.textDO.Text != "")
                        {
                            gatepass.Do_No = this.textDO.Text;
                        }
                        gatepass.auto = 'N';
                        gatepass.dateFrom = this.monthCalendar1.Value;
                        gatepass.dateTo = this.monthCalendar2.Value;
                        gatepass.ShowDialog();
                        gatepass.Dispose();
                    }
                    else
                    {
                        FormUploadSAP dsap = new FormUploadSAP {
                            tipeTrans = this.tipeTrans,
                            sapDest = this.sapDest,
                            comm = this.comm_code,
                            uplDate = this.checkDate.Checked,
                            transpt = this.textTransporter.Text.Trim(),
                            showAll = this.chkAll.Checked,
                            cTrans = this.checkcTrans.Checked
                        };
                        if (this.textDO.Text != "")
                        {
                            dsap.Do_No = this.textDO.Text;
                        }
                        dsap.dateFrom = this.monthCalendar1.Value;
                        dsap.dateTo = this.monthCalendar2.Value;
                        if (!this.checkExcel.Checked)
                        {
                            dsap.ShowDialog();
                            dsap.Dispose();
                        }
                        else
                        {
                            dsap.extractExcel = true;
                            dsap.f_load();
                            dsap.Dispose();
                        }
                    }
                    this.refresh_count();
                }
            }
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFind = this.textDO.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.textDO.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE",
                pFind = this.textTransporter.Text.Trim()
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransporter.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.textTransporter.Focus();
            }
            transporter.Dispose();
        }

        private void buttonDestinationInfo_Click(object sender, EventArgs e)
        {
            string str = "";
            WBTable table = new WBTable();
            if (string.IsNullOrEmpty(this.comboTable.Text))
            {
                MessageBox.Show("Please select SAP Destination.", Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                table.OpenTable("wb_SAPDest", "select * from wb_SAPDest where " + WBData.CompanyLocation(" and SAPDest = '" + this.comboTable.Text.ToString() + "' "), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    string[] strArray = null;
                    string[] separator = new string[] { @"\n", @"\N" };
                    strArray = table.DT.Rows[0]["descriptionText"].ToString().Split(separator, StringSplitOptions.None);
                    str = string.Join(Environment.NewLine, strArray);
                }
                table.Dispose();
                if (!string.IsNullOrEmpty(str))
                {
                    FlexibleMessageBox.Show(str, "I N F O R M A T I O N", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button2);
                }
                else
                {
                    MessageBox.Show("No description text to be found for Destination " + this.comboTable.Text + ".", Resource.Mes_Warning_Caps, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private void buttonFilterAdmin_Click(object sender, EventArgs e)
        {
            this.panel_filter.Visible = true;
            this.cBoxSyncMD.Enabled = true;
            this.cBoxSyncMD.Visible = true;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (!this.checkExcel.Checked)
            {
                this.rbPurchase.Enabled = true;
                this.rbSales.Enabled = true;
                this.chkAll.Enabled = true;
                this.comboComm.Enabled = true;
                this.textDO.Enabled = true;
                this.textTransporter.Enabled = true;
                this.button11.Enabled = true;
                this.button3.Enabled = true;
                this.chkAll.Checked = false;
            }
            else
            {
                this.rbPurchase.Checked = true;
                this.rbPurchase.Enabled = false;
                this.rbSales.Checked = false;
                this.rbSales.Enabled = false;
                this.chkAll.Checked = false;
                this.chkAll.Enabled = false;
                this.comboComm.Enabled = false;
                this.textDO.Enabled = false;
                this.textTransporter.Enabled = false;
                this.button11.Enabled = false;
                this.button3.Enabled = false;
            }
        }

        private void checkcTrans_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkcTrans.Checked)
            {
                this.chkAll.Checked = false;
            }
        }

        private void checkDate_CheckedChanged(object sender, EventArgs e)
        {
            if (!this.checkDate.Checked)
            {
                this.monthCalendar1.Enabled = false;
                this.monthCalendar2.Enabled = false;
                this.chkAll.Checked = false;
                this.chkAll.Enabled = false;
            }
            else
            {
                this.monthCalendar1.Enabled = true;
                this.monthCalendar2.Enabled = true;
                this.chkAll.Checked = false;
                this.chkAll.Enabled = this.comboTable.Text.Trim().ToUpper() != "ZWB";
                if (this.checkExcel.Checked)
                {
                    this.chkAll.Checked = true;
                }
            }
        }

        private void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            if (this.chkAll.Checked)
            {
                this.checkcTrans.Checked = false;
            }
        }

        private void comboComm_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void comboTable_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.buttonFilterAdmin.Visible = false;
            if (!WBSetting.integrationIDSYS)
            {
                if ((this.comboTable.Text.Trim() == "SYNC MASTER DATA") || (this.comboTable.Text.Trim() == "ZWB"))
                {
                    this.cBoxSyncMD.Checked = true;
                    this.cBoxSyncMD.Visible = false;
                    this.cBoxSyncMD.Enabled = false;
                    this.chkAll.Enabled = false;
                    this.comboComm.Text = "";
                    this.textDO.Text = "";
                    this.textTransporter.Text = "";
                    if (WBUser.UserLevel == "1")
                    {
                        this.buttonFilterAdmin.Visible = true;
                    }
                }
                else if (this.comboTable.Text.Trim() == "ZMY_UPLOADFFB")
                {
                    this.rbPurchase.Enabled = true;
                    this.rbPurchase.Checked = true;
                    this.comboComm.Enabled = false;
                    this.rbSales.Enabled = false;
                    this.checkExcel.Visible = true;
                }
                else if ((this.comboTable.Text.Trim() == "ZMM_UPLOADSTM") || (this.comboTable.Text.Trim() == "ZMM_UPLOADSTM_RCV"))
                {
                    this.rbSales.Enabled = true;
                    this.rbSales.Checked = true;
                    this.rbPurchase.Enabled = false;
                    this.comboComm.Enabled = true;
                    this.checkExcel.Checked = false;
                    this.checkExcel.Visible = false;
                }
                else
                {
                    this.panel_filter.Visible = true;
                    this.cBoxSyncMD.Checked = true;
                    this.cBoxSyncMD.Visible = false;
                    this.cBoxSyncMD.Enabled = false;
                    this.checkDate.Enabled = true;
                    this.checkExcel.Checked = false;
                    this.checkExcel.Visible = false;
                }
                this.refresh_count();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void fillCombo()
        {
            WBTable table = new WBTable();
            table.OpenTable("wb_sapDest", "Select * from wb_SapDest where " + WBData.CompanyLocation("") + " ORDER BY sapdest", WBData.conn);
            this.comboTable.Visible = true;
            foreach (DataRow row in table.DT.Rows)
            {
                this.comboTable.Items.Add(row["SAPDest"].ToString());
            }
            this.comboComm.Items.Add("All Commodity");
            WBTable table2 = new WBTable();
            table2.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(""), WBData.conn);
            foreach (DataRow row2 in table2.DT.Rows)
            {
                this.comboComm.Items.Add(row2["comm_code"].ToString());
            }
            this.comboComm.Text = "All Commodity";
        }

        private void FormUpload_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormUpload_Load(object sender, EventArgs e)
        {
            this.rbPurchase.Checked = true;
            this.fillCombo();
            this.tblTransporter.OpenTable("Wb_Trspt", "select * from wb_transporter WHERE " + WBData.CompanyLocation(""), WBData.conn);
            Program.AutoComp(this.tblTransporter, "transporter_code", this.textTransporter);
            this.tblcontract.OpenTable("Wb_contract", "select * from wb_contract WHERE " + WBData.CompanyLocation(""), WBData.conn);
            Program.AutoComp(this.tblcontract, "do_no", this.textDO);
            WBSetting.OpenSetting();
            if (WBSetting.zwb == "Y")
            {
                this.comboTable.Text = "ZWB";
            }
            if (!this.checkDate.Checked)
            {
                this.monthCalendar1.Enabled = false;
                this.monthCalendar2.Enabled = false;
            }
            this.buttonFilterAdmin.Visible = false;
            this.checkDate.Checked = true;
            this.checkDate.Enabled = false;
            this.Text = this.Text + this.sapIDSYS;
        }

        private void InitializeComponent()
        {
            this.buttonProses = new Button();
            this.labelDest = new Label();
            this.comboTable = new ComboBox();
            this.button1 = new Button();
            this.checkcTrans = new CheckBox();
            this.panel_filter = new Panel();
            this.cBoxSyncMD = new CheckBox();
            this.checkDate = new CheckBox();
            this.groupDetails = new GroupBox();
            this.textBoxRefNo = new TextBox();
            this.label6 = new Label();
            this.button3 = new Button();
            this.textTransporter = new TextBox();
            this.label1 = new Label();
            this.button11 = new Button();
            this.textDO = new TextBox();
            this.label5 = new Label();
            this.comboComm = new ComboBox();
            this.label2 = new Label();
            this.chkAll = new CheckBox();
            this.monthCalendar2 = new DateTimePicker();
            this.monthCalendar1 = new DateTimePicker();
            this.label3 = new Label();
            this.label4 = new Label();
            this.groupType = new GroupBox();
            this.btnExit = new Button();
            this.rbSD4 = new RadioButton();
            this.rbSales = new RadioButton();
            this.rbSD2 = new RadioButton();
            this.rbSD1 = new RadioButton();
            this.rbPurchase = new RadioButton();
            this.label_info = new Label();
            this.checkExcel = new CheckBox();
            this.buttonFilterAdmin = new Button();
            this.buttonDestinationInfo = new Button();
            this.panel_filter.SuspendLayout();
            this.groupDetails.SuspendLayout();
            this.groupType.SuspendLayout();
            base.SuspendLayout();
            this.buttonProses.Location = new Point(0x79, 0x18e);
            this.buttonProses.Name = "buttonProses";
            this.buttonProses.Size = new Size(0x68, 0x26);
            this.buttonProses.TabIndex = 0x11;
            this.buttonProses.Text = "Process";
            this.buttonProses.UseVisualStyleBackColor = true;
            this.buttonProses.Click += new EventHandler(this.button1_Click_1);
            this.labelDest.AutoSize = true;
            this.labelDest.Location = new Point(0x10, 12);
            this.labelDest.Name = "labelDest";
            this.labelDest.Size = new Size(60, 13);
            this.labelDest.TabIndex = 0x13;
            this.labelDest.Text = "Destination";
            this.comboTable.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboTable.FormattingEnabled = true;
            this.comboTable.Location = new Point(0x54, 9);
            this.comboTable.Name = "comboTable";
            this.comboTable.Size = new Size(0xf9, 0x15);
            this.comboTable.TabIndex = 0;
            this.comboTable.SelectedIndexChanged += new EventHandler(this.comboTable_SelectedIndexChanged);
            this.comboTable.KeyPress += new KeyPressEventHandler(this.textTransporter_KeyPress);
            this.button1.Location = new Point(0xf8, 0x18e);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x68, 0x26);
            this.button1.TabIndex = 0x17;
            this.button1.Text = "Cancel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click_2);
            this.checkcTrans.AutoSize = true;
            this.checkcTrans.ForeColor = Color.Red;
            this.checkcTrans.Location = new Point(15, 0x24);
            this.checkcTrans.Name = "checkcTrans";
            this.checkcTrans.Size = new Size(0x12b, 0x11);
            this.checkcTrans.TabIndex = 30;
            this.checkcTrans.Text = "Show Only All Unposted Data Exclude Today Transaction";
            this.checkcTrans.UseVisualStyleBackColor = true;
            this.checkcTrans.Visible = false;
            this.checkcTrans.CheckedChanged += new EventHandler(this.checkcTrans_CheckedChanged);
            this.panel_filter.Controls.Add(this.cBoxSyncMD);
            this.panel_filter.Controls.Add(this.checkDate);
            this.panel_filter.Controls.Add(this.groupDetails);
            this.panel_filter.Controls.Add(this.chkAll);
            this.panel_filter.Controls.Add(this.monthCalendar2);
            this.panel_filter.Controls.Add(this.monthCalendar1);
            this.panel_filter.Controls.Add(this.label3);
            this.panel_filter.Controls.Add(this.label4);
            this.panel_filter.Controls.Add(this.groupType);
            this.panel_filter.Location = new Point(4, 0x4f);
            this.panel_filter.Name = "panel_filter";
            this.panel_filter.Size = new Size(0x16f, 0x13b);
            this.panel_filter.TabIndex = 0x29;
            this.cBoxSyncMD.AutoSize = true;
            this.cBoxSyncMD.Checked = true;
            this.cBoxSyncMD.CheckState = CheckState.Checked;
            this.cBoxSyncMD.Enabled = false;
            this.cBoxSyncMD.Location = new Point(0xe2, 5);
            this.cBoxSyncMD.Name = "cBoxSyncMD";
            this.cBoxSyncMD.Size = new Size(0x6f, 0x11);
            this.cBoxSyncMD.TabIndex = 0x2e;
            this.cBoxSyncMD.Text = "Sync Master Data";
            this.cBoxSyncMD.UseVisualStyleBackColor = true;
            this.cBoxSyncMD.Visible = false;
            this.checkDate.AutoSize = true;
            this.checkDate.Location = new Point(11, 5);
            this.checkDate.Name = "checkDate";
            this.checkDate.Size = new Size(0x58, 0x11);
            this.checkDate.TabIndex = 0x30;
            this.checkDate.Text = "Filter by Date";
            this.checkDate.UseVisualStyleBackColor = true;
            this.checkDate.CheckedChanged += new EventHandler(this.checkDate_CheckedChanged);
            this.groupDetails.Controls.Add(this.textBoxRefNo);
            this.groupDetails.Controls.Add(this.label6);
            this.groupDetails.Controls.Add(this.button3);
            this.groupDetails.Controls.Add(this.textTransporter);
            this.groupDetails.Controls.Add(this.label1);
            this.groupDetails.Controls.Add(this.button11);
            this.groupDetails.Controls.Add(this.textDO);
            this.groupDetails.Controls.Add(this.label5);
            this.groupDetails.Controls.Add(this.comboComm);
            this.groupDetails.Controls.Add(this.label2);
            this.groupDetails.Location = new Point(10, 0xa7);
            this.groupDetails.Name = "groupDetails";
            this.groupDetails.Size = new Size(0x14d, 0x91);
            this.groupDetails.TabIndex = 0x2f;
            this.groupDetails.TabStop = false;
            this.groupDetails.Text = "Additional Filters";
            this.textBoxRefNo.Location = new Point(0x4d, 0x65);
            this.textBoxRefNo.Margin = new Padding(3, 4, 3, 4);
            this.textBoxRefNo.MaxLength = 20;
            this.textBoxRefNo.Name = "textBoxRefNo";
            this.textBoxRefNo.Size = new Size(0xba, 20);
            this.textBoxRefNo.TabIndex = 0x31;
            this.textBoxRefNo.KeyPress += new KeyPressEventHandler(this.textBoxRefNo_KeyPress);
            this.label6.AutoSize = true;
            this.label6.Location = new Point(0x1b, 0x68);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x2c, 13);
            this.label6.TabIndex = 0x30;
            this.label6.Text = "Ref No.";
            this.button3.Location = new Point(0x10a, 0x47);
            this.button3.Margin = new Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x17, 0x16);
            this.button3.TabIndex = 0x2f;
            this.button3.Text = "...";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.textTransporter.Location = new Point(0x4d, 0x49);
            this.textTransporter.Margin = new Padding(3, 4, 3, 4);
            this.textTransporter.MaxLength = 20;
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.Size = new Size(0xba, 20);
            this.textTransporter.TabIndex = 0x2e;
            this.textTransporter.KeyPress += new KeyPressEventHandler(this.textTransporter_KeyPress_1);
            this.textTransporter.Leave += new EventHandler(this.textTransporter_Leave);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(10, 0x4c);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x3d, 13);
            this.label1.TabIndex = 0x2d;
            this.label1.Text = "Transporter";
            this.button11.Location = new Point(0x10a, 0x2b);
            this.button11.Margin = new Padding(0);
            this.button11.Name = "button11";
            this.button11.Size = new Size(0x17, 0x17);
            this.button11.TabIndex = 0x2c;
            this.button11.Text = "...";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new EventHandler(this.button11_Click);
            this.textDO.Location = new Point(0x4d, 0x2e);
            this.textDO.Name = "textDO";
            this.textDO.Size = new Size(0xba, 20);
            this.textDO.TabIndex = 0x2b;
            this.textDO.KeyPress += new KeyPressEventHandler(this.textDO_KeyPress);
            this.textDO.Leave += new EventHandler(this.textDO_Leave);
            this.label5.AutoSize = true;
            this.label5.Location = new Point(0x21, 0x31);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x26, 13);
            this.label5.TabIndex = 0x2a;
            this.label5.Text = "Do No";
            this.comboComm.FormattingEnabled = true;
            this.comboComm.Location = new Point(0x4d, 0x13);
            this.comboComm.Name = "comboComm";
            this.comboComm.Size = new Size(0xba, 0x15);
            this.comboComm.TabIndex = 0x29;
            this.comboComm.KeyPress += new KeyPressEventHandler(this.comboComm_KeyPress);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(13, 0x16);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x3a, 13);
            this.label2.TabIndex = 40;
            this.label2.Text = "Commodity";
            this.chkAll.AutoSize = true;
            this.chkAll.Enabled = false;
            this.chkAll.Location = new Point(10, 0x8d);
            this.chkAll.Name = "chkAll";
            this.chkAll.Size = new Size(0x107, 0x11);
            this.chkAll.TabIndex = 0x2e;
            this.chkAll.Text = "Show All for Resend Transaction in Selected Date";
            this.chkAll.UseVisualStyleBackColor = true;
            this.chkAll.CheckedChanged += new EventHandler(this.chkAll_CheckedChanged);
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0xed, 0x1c);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(100, 20);
            this.monthCalendar2.TabIndex = 0x2d;
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(0x49, 0x1c);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(100, 20);
            this.monthCalendar1.TabIndex = 0x2c;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0xb3, 0x22);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x34, 13);
            this.label3.TabIndex = 0x2b;
            this.label3.Text = "To Date :";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(7, 0x22);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x3e, 13);
            this.label4.TabIndex = 0x2a;
            this.label4.Text = "From Date :";
            this.groupType.Controls.Add(this.btnExit);
            this.groupType.Controls.Add(this.rbSD4);
            this.groupType.Controls.Add(this.rbSales);
            this.groupType.Controls.Add(this.rbSD2);
            this.groupType.Controls.Add(this.rbSD1);
            this.groupType.Controls.Add(this.rbPurchase);
            this.groupType.Location = new Point(8, 60);
            this.groupType.Name = "groupType";
            this.groupType.Size = new Size(0x14d, 0x43);
            this.groupType.TabIndex = 0x29;
            this.groupType.TabStop = false;
            this.groupType.Text = "Trans. Type";
            this.btnExit.Location = new Point(0x1a5, 0xb2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new Size(0x66, 0x20);
            this.btnExit.TabIndex = 0x12;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.rbSD4.AutoSize = true;
            this.rbSD4.Location = new Point(0x20, 0xb2);
            this.rbSD4.Name = "rbSD4";
            this.rbSD4.Size = new Size(90, 0x11);
            this.rbSD4.TabIndex = 0x11;
            this.rbSD4.TabStop = true;
            this.rbSD4.Text = "Loco Oil (Sell)";
            this.rbSD4.UseVisualStyleBackColor = true;
            this.rbSD4.Visible = false;
            this.rbSales.AutoSize = true;
            this.rbSales.Location = new Point(6, 0x2a);
            this.rbSales.Name = "rbSales";
            this.rbSales.Size = new Size(0x6b, 0x11);
            this.rbSales.TabIndex = 0x10;
            this.rbSales.TabStop = true;
            this.rbSales.Text = "Goods Issue ( O )";
            this.rbSales.UseVisualStyleBackColor = true;
            this.rbSD2.AutoSize = true;
            this.rbSD2.Location = new Point(0x101, 0xb2);
            this.rbSD2.Name = "rbSD2";
            this.rbSD2.Size = new Size(0x80, 0x11);
            this.rbSD2.TabIndex = 15;
            this.rbSD2.TabStop = true;
            this.rbSD2.Text = "Estate to Others POM";
            this.rbSD2.UseVisualStyleBackColor = true;
            this.rbSD2.Visible = false;
            this.rbSD1.AutoSize = true;
            this.rbSD1.Location = new Point(0x80, 0xb2);
            this.rbSD1.Name = "rbSD1";
            this.rbSD1.Size = new Size(0x77, 0x11);
            this.rbSD1.TabIndex = 14;
            this.rbSD1.TabStop = true;
            this.rbSD1.Text = "Estate to Own POM";
            this.rbSD1.UseVisualStyleBackColor = true;
            this.rbSD1.Visible = false;
            this.rbPurchase.AutoSize = true;
            this.rbPurchase.Location = new Point(6, 0x13);
            this.rbPurchase.Name = "rbPurchase";
            this.rbPurchase.Size = new Size(0x75, 0x11);
            this.rbPurchase.TabIndex = 13;
            this.rbPurchase.TabStop = true;
            this.rbPurchase.Text = "Goods Receive ( I )";
            this.rbPurchase.UseVisualStyleBackColor = true;
            this.label_info.AutoSize = true;
            this.label_info.Font = new Font("Courier New", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label_info.Location = new Point(0x51, 0x3d);
            this.label_info.Name = "label_info";
            this.label_info.Size = new Size(0x26, 0x12);
            this.label_info.TabIndex = 0x2b;
            this.label_info.Text = "   ";
            this.checkExcel.AutoSize = true;
            this.checkExcel.Location = new Point(15, 0x39);
            this.checkExcel.Name = "checkExcel";
            this.checkExcel.Size = new Size(0x8b, 0x11);
            this.checkExcel.TabIndex = 0x2c;
            this.checkExcel.Text = "Extract template for FFB";
            this.checkExcel.UseVisualStyleBackColor = true;
            this.checkExcel.Visible = false;
            this.checkExcel.CheckedChanged += new EventHandler(this.checkBox1_CheckedChanged);
            this.buttonFilterAdmin.Location = new Point(320, 0x24);
            this.buttonFilterAdmin.Name = "buttonFilterAdmin";
            this.buttonFilterAdmin.Size = new Size(0x33, 0x23);
            this.buttonFilterAdmin.TabIndex = 0x2d;
            this.buttonFilterAdmin.Text = "Filter Admin";
            this.buttonFilterAdmin.UseVisualStyleBackColor = true;
            this.buttonFilterAdmin.Visible = false;
            this.buttonFilterAdmin.Click += new EventHandler(this.buttonFilterAdmin_Click);
            this.buttonDestinationInfo.Image = Resources.blue_info_icon;
            this.buttonDestinationInfo.Location = new Point(0x153, 6);
            this.buttonDestinationInfo.Name = "buttonDestinationInfo";
            this.buttonDestinationInfo.Size = new Size(0x20, 0x1c);
            this.buttonDestinationInfo.TabIndex = 0x2e;
            this.buttonDestinationInfo.UseVisualStyleBackColor = false;
            this.buttonDestinationInfo.Click += new EventHandler(this.buttonDestinationInfo_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x17f, 0x1c0);
            base.ControlBox = false;
            base.Controls.Add(this.buttonDestinationInfo);
            base.Controls.Add(this.buttonFilterAdmin);
            base.Controls.Add(this.checkExcel);
            base.Controls.Add(this.panel_filter);
            base.Controls.Add(this.checkcTrans);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.comboTable);
            base.Controls.Add(this.labelDest);
            base.Controls.Add(this.buttonProses);
            base.Controls.Add(this.label_info);
            base.KeyPreview = true;
            base.Name = "FormUpload";
            base.SizeGripStyle = SizeGripStyle.Hide;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Upload to ";
            base.Load += new EventHandler(this.FormUpload_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormUpload_KeyPress);
            this.panel_filter.ResumeLayout(false);
            this.panel_filter.PerformLayout();
            this.groupDetails.ResumeLayout(false);
            this.groupDetails.PerformLayout();
            this.groupType.ResumeLayout(false);
            this.groupType.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        public void opw(string mode)
        {
            new FormUploadSync(mode) { 
                dateFrom = this.monthCalendar1.Value,
                dateTo = this.monthCalendar2.Value,
                tipeTrans = this.tipeTrans,
                sapDest = this.sapDest,
                comm = this.comm_code,
                transpt = this.textTransporter.Text.Trim(),
                Do_No = this.textDO.Text,
                mode = mode
            }.ShowDialog();
        }

        private void refresh_count()
        {
            if ((this.comboTable.Text.Trim() != "ZWB") && (this.comboTable.Text.Trim() != "SYNC MASTER DATA"))
            {
                this.label_info.Text = "";
            }
            else
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_estate", "SELECT COUNT(uniq) AS n FROM wb_estate WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_estate = table.DR["n"].ToString();
                }
                table.OpenTable("wb_truck", "SELECT COUNT(uniq) AS n FROM wb_truck WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_truck = table.DR["n"].ToString();
                }
                table.OpenTable("wb_transporter", "SELECT COUNT(uniq) AS n FROM wb_transporter WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_transporter = table.DR["n"].ToString();
                }
                table.OpenTable("wb_driver", "SELECT COUNT(uniq) AS n FROM wb_driver WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_driver = table.DR["n"].ToString();
                }
                table.OpenTable("wb_commodity", "SELECT COUNT(uniq) AS n FROM wb_commodity WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_commodity = table.DR["n"].ToString();
                }
                table.OpenTable("wb_contract", "SELECT COUNT(uniq) AS n FROM wb_contract WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_contract = table.DR["n"].ToString();
                }
                table.OpenTable("wb_relation", "SELECT COUNT(uniq) AS n FROM wb_relation WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_relation = table.DR["n"].ToString();
                }
                this.label_info.Text = "";
                table.Dispose();
            }
        }

        private void refresh_count_IDSYS()
        {
            if ((this.comboTable.Text.Trim() != "IDSYS") && (this.comboTable.Text.Trim() != "SYNC MASTER DATA"))
            {
                this.label_info.Text = "";
            }
            else
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_estate", "SELECT COUNT(uniq) AS n FROM wb_estate WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_estate = table.DR["n"].ToString();
                }
                table.OpenTable("wb_truck", "SELECT COUNT(uniq) AS n FROM wb_truck WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_truck = table.DR["n"].ToString();
                }
                table.OpenTable("wb_transporter", "SELECT COUNT(uniq) AS n FROM wb_transporter WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_transporter = table.DR["n"].ToString();
                }
                table.OpenTable("wb_driver", "SELECT COUNT(uniq) AS n FROM wb_driver WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_driver = table.DR["n"].ToString();
                }
                table.OpenTable("wb_commodity", "SELECT COUNT(uniq) AS n FROM wb_commodity WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_commodity = table.DR["n"].ToString();
                }
                table.OpenTable("wb_contract", "SELECT COUNT(uniq) AS n FROM wb_contract WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_contract = table.DR["n"].ToString();
                }
                table.OpenTable("wb_relation", "SELECT COUNT(uniq) AS n FROM wb_relation WHERE " + Sync.where_con, WBData.conn);
                if (table.DT.Rows.Count == 1)
                {
                    table.DR = table.DT.Rows[0];
                    this.n_relation = table.DR["n"].ToString();
                }
                string[] textArray1 = new string[0x17];
                textArray1[0] = "Sync Master Data: ";
                textArray1[1] = Environment.NewLine;
                textArray1[2] = "Estate         = ";
                textArray1[3] = this.n_estate;
                textArray1[4] = Environment.NewLine;
                textArray1[5] = "Truck          = ";
                textArray1[6] = this.n_truck;
                textArray1[7] = Environment.NewLine;
                textArray1[8] = "Transporter    = ";
                textArray1[9] = this.n_transporter;
                textArray1[10] = Environment.NewLine;
                textArray1[11] = "Driver         = ";
                textArray1[12] = this.n_driver;
                textArray1[13] = Environment.NewLine;
                textArray1[14] = "Commodity      = ";
                textArray1[15] = this.n_commodity;
                textArray1[0x10] = Environment.NewLine;
                textArray1[0x11] = "Contract       = ";
                textArray1[0x12] = this.n_contract;
                textArray1[0x13] = Environment.NewLine;
                textArray1[20] = "Relation       = ";
                textArray1[0x15] = this.n_relation;
                textArray1[0x16] = Environment.NewLine;
                this.label_info.Text = string.Concat(textArray1);
                table.Dispose();
            }
        }

        public void sync_master_data(string mode)
        {
            new FormUploadSync(mode) { 
                n_estate = Convert.ToInt32(this.n_estate),
                n_transporter = Convert.ToInt32(this.n_transporter),
                n_truck = Convert.ToInt32(this.n_truck),
                n_driver = Convert.ToInt32(this.n_driver),
                n_commodity = Convert.ToInt32(this.n_commodity),
                n_relation = Convert.ToInt32(this.n_relation),
                n_contract = Convert.ToInt32(this.n_contract)
            }.ShowDialog();
        }

        private void textBoxRefNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDO_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDO_Leave(object sender, EventArgs e)
        {
            if (this.textDO.Text != "")
            {
                FormContract contract = new FormContract();
                WBTable table = new WBTable();
                table.OpenTable("wb_contract", "SELECT * FROM wb_contract Where " + WBData.CompanyLocation(" and Do_No='" + this.textDO.Text.Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    this.button11.PerformClick();
                }
                contract.Dispose();
                table.Dispose();
            }
        }

        private void textTransporter_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransporter_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransporter_Leave(object sender, EventArgs e)
        {
            if (this.textTransporter.Text.Trim() != "")
            {
                string[] aField = new string[] { "transporter_code" };
                string[] aFind = new string[] { this.textTransporter.Text.Trim() };
                if (ReferenceEquals(this.tblTransporter.GetData(aField, aFind), null))
                {
                    MessageBox.Show("Transporter Code Does Not Exist...", "WARNING...");
                    this.textTransporter.Focus();
                }
            }
        }
    }
}

