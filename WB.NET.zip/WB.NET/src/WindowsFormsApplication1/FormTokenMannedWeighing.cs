﻿namespace WindowsFormsApplication1
{
    using Encryption.Utility;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Net;
    using System.Windows.Forms;

    public class FormTokenMannedWeighing : Form
    {
        private WBToken aToken = new WBToken();
        private WBTable tblToken = new WBTable();
        public string pmode = "";
        public string tblName = "";
        public string oldToken = "";
        public string oldCode = "";
        public string newCode = "";
        public bool saved = false;
        public bool close = false;
        public bool use3x = false;
        public bool errosendToken = false;
        public string completed = "N";
        public string manualQty = "0";
        public string email_code = "";
        public string AllTrx = "";
        public string CommTol = "";
        public string DoNo = "";
        public string TokenParam2;
        private const int DEFAULT_FOR_MAX_HOUR = 8;
        private int sendingSMSCount = 0;
        private int toleranceForSendingSMS = 5;
        private IContainer components = null;
        private Button buttonProcess;
        private Button button1;
        private Label label1;
        private Label label2;
        public TextBox textBoxToken;
        private TextBox textBoxPIN;
        private Label label3;
        private TextBox textMessage;
        private GroupBox groupBox1;
        private Label label7;
        private Label label6;
        private Label label5;
        private TextBox textHour;
        private Label label4;
        private Label labelComp;
        private Label labelWB;

        public FormTokenMannedWeighing()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.saved = false;
            base.Close();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            int num2;
            bool flag12;
            int num = 8;
            WBTable table = new WBTable();
            table.OpenTable("wb_condition", "SELECT description FROM wb_condition WHERE " + WBData.CompanyLocation("") + " AND condition_code = 'MAX_HOUR_FOR_MANNED_WEIGHING'", WBData.conn);
            if ((table.DT.Rows.Count > 0) && int.TryParse(table.DT.Rows[0]["description"].ToString(), out num2))
            {
                num = Convert.ToInt16(table.DT.Rows[0]["description"].ToString());
            }
            table.Dispose();
            if (Convert.ToInt16(this.textHour.Text.Trim()) > 0)
            {
                if (Convert.ToInt16(this.textHour.Text.Trim()) <= num)
                {
                    if ((this.textBoxPIN.Text.Trim() != "") || (this.buttonProcess.Text.ToUpper() == "PROCESS"))
                    {
                        if (!(((this.textBoxPIN.Text.Trim() != "") || (this.buttonProcess.Text.ToUpper() != "PROCESS")) ? (this.textBoxPIN.Text != "") : true))
                        {
                            return;
                        }
                        else if (this.textBoxPIN.Text != "")
                        {
                            this.tblToken.OpenTable("wb_token", "SELECT * FROM wb_token WHERE token_code = 'BYPASS_MANNED_WEIGHING'  AND key_1 = '" + WBData.sWBCode + "'  AND completed = 'Y'", WBData.conn);
                            flag12 = false;
                            if (this.tblToken.DT.Rows.Count <= 0)
                            {
                                flag12 = true;
                            }
                            else
                            {
                                foreach (DataRow row in this.tblToken.DT.Rows)
                                {
                                    double num3 = Convert.ToInt16(row["key_2"].ToString()) * 0xe10;
                                    TimeSpan span = (TimeSpan) (DateTime.Now - Convert.ToDateTime(row["Datetime1"].ToString()));
                                    double totalSeconds = span.TotalSeconds;
                                    if (totalSeconds < num3)
                                    {
                                        TimeSpan span2 = TimeSpan.FromSeconds(num3 - totalSeconds);
                                        string[] textArray3 = new string[] { span2.Hours.ToString(), " hour(s) ", span2.Minutes.ToString(), " minute(s) ", span2.Seconds.ToString(), " second(s)" };
                                        string str3 = string.Concat(textArray3);
                                        string[] textArray4 = new string[10];
                                        textArray4[0] = Resource.Token_010;
                                        textArray4[1] = " ";
                                        textArray4[2] = row["token_no"].ToString();
                                        textArray4[3] = " ";
                                        textArray4[4] = Resource.Token_011;
                                        textArray4[5] = " ";
                                        textArray4[6] = str3;
                                        textArray4[7] = "\n\n";
                                        textArray4[8] = Resource.Token_012;
                                        textArray4[9] = "?";
                                        flag12 = MessageBox.Show(string.Concat(textArray4), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes;
                                        break;
                                    }
                                    flag12 = true;
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Token_009, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.textMessage.Focus();
                            return;
                        }
                    }
                    else
                    {
                        if (this.textMessage.Text == "")
                        {
                            MessageBox.Show(Resource.Token_004, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.textMessage.Focus();
                        }
                        else
                        {
                            string[] textArray1 = new string[0x10];
                            textArray1[0] = Resource.Token_005;
                            textArray1[1] = " ";
                            textArray1[2] = this.textHour.Text.Trim();
                            textArray1[3] = " ";
                            textArray1[4] = Resource.Token_003;
                            textArray1[5] = " ";
                            textArray1[6] = Resource.Token_006;
                            textArray1[7] = " ";
                            textArray1[8] = this.labelWB.Text;
                            textArray1[9] = " ";
                            textArray1[10] = Resource.Token_007;
                            textArray1[11] = " ";
                            textArray1[12] = this.labelComp.Text;
                            textArray1[13] = "?\n\n";
                            textArray1[14] = Resource.Token_008;
                            textArray1[15] = "!";
                            if (MessageBox.Show(string.Concat(textArray1), "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.saved = true;
                                this.completed = "N";
                                this.tblToken.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(" AND token_no = '" + this.textBoxToken.Text.Trim() + "'"), WBData.conn);
                                if (this.tblToken.DT.Rows.Count == 0)
                                {
                                    this.tblToken.DR = this.tblToken.DT.NewRow();
                                    this.tblToken.DR["coy"] = WBData.sCoyCode;
                                    this.tblToken.DR["location_code"] = WBData.sLocCode;
                                    this.tblToken.DR["key_1"] = WBData.sWBCode;
                                    this.tblToken.DR["key_2"] = this.textHour.Text.Trim();
                                    this.tblToken.DR["token_code"] = this.pmode;
                                    this.tblToken.DR["token_no"] = this.textBoxToken.Text;
                                    this.tblToken.DR["completed"] = "N";
                                    this.tblToken.DT.Rows.Add(this.tblToken.DR);
                                    this.tblToken.Save();
                                }
                                if (!WBSetting.activeSMSToken)
                                {
                                    this.sendEmailToken(this.email_code);
                                }
                                else
                                {
                                    string[] textArray2 = new string[] { this.textMessage.Text.Trim(), " (Request ", this.textHour.Text.Trim(), " ", Resource.Report05_038, ")" };
                                    this.sendHTTPRequest(this.textBoxToken.Text.Trim(), WBUser.UserID, string.Concat(textArray2));
                                }
                                if (!this.errosendToken)
                                {
                                    base.Close();
                                }
                            }
                        }
                        return;
                    }
                }
                else
                {
                    object[] objArray1 = new object[] { Resource.Token_002, " ", num, " ", Resource.Token_003, "!" };
                    MessageBox.Show(string.Concat(objArray1), "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.textHour.Focus();
                    return;
                }
            }
            else
            {
                MessageBox.Show(Resource.Token_001, "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textHour.Focus();
                return;
            }
            if (flag12)
            {
                string aToken = this.textBoxToken.Text.Trim();
                if (this.textBoxPIN.Text.Trim() != this.aToken.generateV2PIN(aToken, this.pmode).Trim())
                {
                    MessageBox.Show(Resource.Token_014 + "!", "FAIL", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    this.saved = true;
                    this.completed = "Y";
                    this.tblToken.OpenTable("wb_token", "SELECT * FROM wb_token WHERE " + WBData.CompanyLocation(" AND token_no = '" + aToken + "'"), WBData.conn);
                    if (this.tblToken.DT.Rows.Count > 0)
                    {
                        this.tblToken.DR = this.tblToken.DT.Rows[0];
                        this.tblToken.DR.BeginEdit();
                        this.tblToken.DR["completed"] = "Y";
                        this.tblToken.DR["Datetime1"] = DateTime.Now;
                        this.tblToken.DR.EndEdit();
                        this.tblToken.Save();
                    }
                    else
                    {
                        this.tblToken.DR = this.tblToken.DT.NewRow();
                        this.tblToken.DR["coy"] = WBData.sCoyCode;
                        this.tblToken.DR["location_code"] = WBData.sLocCode;
                        this.tblToken.DR["key_1"] = WBData.sWBCode;
                        this.tblToken.DR["key_2"] = this.textHour.Text.Trim();
                        this.tblToken.DR["token_code"] = this.pmode;
                        this.tblToken.DR["token_no"] = this.textBoxToken.Text;
                        this.tblToken.DR["completed"] = "Y";
                        this.tblToken.DR["Datetime1"] = DateTime.Now;
                        this.tblToken.DT.Rows.Add(this.tblToken.DR);
                        this.tblToken.Save();
                    }
                    MessageBox.Show(Resource.Token_013 + "!", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    base.Close();
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private string firstLetterToUpper(string reason)
        {
            string str = reason.ToLower();
            return ((str.Length <= 1) ? str : (char.ToUpper(str[0]).ToString() + str.Substring(1)));
        }

        private void FormToken_Collective_Load(object sender, EventArgs e)
        {
            this.email_code = "TOKEN_BYPASS_MANNED_WEIGHING";
            this.pmode = "BYPASS_MANNED_WEIGHING";
            this.labelWB.Text = WBData.sWBCode;
            this.labelComp.Text = Environment.MachineName;
            this.tblToken.OpenTable("wb_token", "SELECT * FROM wb_token WHERE token_code = 'BYPASS_MANNED_WEIGHING'  AND key_1 = '" + WBData.sWBCode + "'  AND completed = 'N' ORDER BY UNIQ DESC", WBData.conn);
            if (this.tblToken.DT.Rows.Count > 0)
            {
                this.textBoxToken.Text = this.tblToken.DT.Rows[0]["token_no"].ToString();
                this.textHour.Text = this.tblToken.DT.Rows[0]["key_2"].ToString();
                this.textHour.Enabled = false;
            }
            else
            {
                string[] parameters = new string[] { "0" };
                this.textBoxToken.Text = this.aToken.generateToken(parameters, this.pmode, "", "").Trim();
                this.textHour.Enabled = true;
            }
            this.setForm();
            this.translate();
        }

        private void InitializeComponent()
        {
            this.buttonProcess = new Button();
            this.button1 = new Button();
            this.textBoxToken = new TextBox();
            this.label1 = new Label();
            this.label2 = new Label();
            this.textBoxPIN = new TextBox();
            this.label3 = new Label();
            this.textMessage = new TextBox();
            this.groupBox1 = new GroupBox();
            this.labelComp = new Label();
            this.labelWB = new Label();
            this.label7 = new Label();
            this.label6 = new Label();
            this.label5 = new Label();
            this.textHour = new TextBox();
            this.label4 = new Label();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.buttonProcess.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.buttonProcess.Location = new Point(0x6a, 300);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(0x6f, 0x2b);
            this.buttonProcess.TabIndex = 0;
            this.buttonProcess.Text = "&Request for PIN";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0xe7, 300);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x6f, 0x2b);
            this.button1.TabIndex = 1;
            this.button1.Text = "&Cancel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBoxToken.BackColor = SystemColors.Window;
            this.textBoxToken.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textBoxToken.HideSelection = false;
            this.textBoxToken.Location = new Point(0x71, 12);
            this.textBoxToken.Name = "textBoxToken";
            this.textBoxToken.ReadOnly = true;
            this.textBoxToken.Size = new Size(290, 0x1f);
            this.textBoxToken.TabIndex = 2;
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(0x22, 0x16);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x49, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Token Code";
            this.label2.AutoSize = true;
            this.label2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label2.Location = new Point(0x22, 0xad);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x1b, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "PIN";
            this.textBoxPIN.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.textBoxPIN.Location = new Point(0x71, 0xa3);
            this.textBoxPIN.MaxLength = 15;
            this.textBoxPIN.Name = "textBoxPIN";
            this.textBoxPIN.Size = new Size(290, 0x1f);
            this.textBoxPIN.TabIndex = 5;
            this.textBoxPIN.TextChanged += new EventHandler(this.textBoxPIN_TextChanged);
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(0x22, 0xe5);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x3a, 15);
            this.label3.TabIndex = 11;
            this.label3.Text = "Message";
            this.textMessage.Location = new Point(0x71, 200);
            this.textMessage.MaxLength = 250;
            this.textMessage.Multiline = true;
            this.textMessage.Name = "textMessage";
            this.textMessage.Size = new Size(290, 0x49);
            this.textMessage.TabIndex = 12;
            this.groupBox1.Controls.Add(this.labelComp);
            this.groupBox1.Controls.Add(this.labelWB);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textHour);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new Point(0x24, 0x3d);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x16f, 0x51);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.labelComp.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelComp.Location = new Point(230, 0x30);
            this.labelComp.Name = "labelComp";
            this.labelComp.Size = new Size(0x7d, 15);
            this.labelComp.TabIndex = 6;
            this.labelComp.Text = "COMPNAME";
            this.labelWB.AutoSize = true;
            this.labelWB.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelWB.Location = new Point(0x47, 0x30);
            this.labelWB.Name = "labelWB";
            this.labelWB.Size = new Size(0x37, 15);
            this.labelWB.TabIndex = 5;
            this.labelWB.Text = "WBXXX";
            this.label7.AutoSize = true;
            this.label7.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label7.Location = new Point(0x7f, 0x30);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x57, 15);
            this.label7.TabIndex = 4;
            this.label7.Text = "with computer:";
            this.label6.AutoSize = true;
            this.label6.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label6.Location = new Point(11, 0x30);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x2e, 15);
            this.label6.TabIndex = 3;
            this.label6.Text = "for WB:";
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(0x135, 0x15);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x2e, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "hour(s)";
            this.textHour.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textHour.Location = new Point(0x10b, 0x12);
            this.textHour.MaxLength = 2;
            this.textHour.Name = "textHour";
            this.textHour.Size = new Size(0x22, 0x18);
            this.textHour.TabIndex = 1;
            this.textHour.Text = "1";
            this.textHour.TextAlign = HorizontalAlignment.Center;
            this.label4.AutoSize = true;
            this.label4.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label4.Location = new Point(11, 0x15);
            this.label4.Name = "label4";
            this.label4.Size = new Size(220, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "Request to allow manned weighing for ";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1bc, 0x169);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.textMessage);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textBoxPIN);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.textBoxToken);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.buttonProcess);
            base.KeyPreview = true;
            base.Name = "FormTokenMannedWeighing";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Token to Allow Manned Weighing";
            base.Load += new EventHandler(this.FormToken_Collective_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void sendEmailToken(string email_code)
        {
            WBMail mail = new WBMail();
            string str = "";
            string str2 = "";
            if (this.tblName.Length > 3)
            {
                str2 = this.tblName.Substring(3, this.tblName.Length - 3).ToUpper();
            }
            DateTime time = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd"));
            string[] textArray1 = new string[] { ("Dear Sir/Madam, <br><br>PIN HAS BEEN REQUESTED<br><br><a href='http://token.wilmar.co.id:8080/generate/?t=" + this.textBoxToken.Text.Trim() + "'>Click here to directly go to Web Token </a><br><br><table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Unit</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Request Date Time</td><td nowrap> : " + Convert.ToDateTime(DateTime.Now.ToString("hh:mm:ss")), "</tr><tr class='bd'><td nowrap>Requested By</td><td nowrap> : ", WBUser.UserName, "</tr><tr class='bd'><td nowrap>Token No</td><td nowrap> : ", this.textBoxToken.Text.Trim() };
            string[] textArray2 = new string[] { string.Concat(textArray1), "</tr><tr class='bd'><td nowrap>Menu</td><td nowrap> : ALLOW MANNED WEIGHING </td></tr><tr class='bd'><td nowrap>Menu Description</td><td nowrap> : This token is used to do manned weighing for WB ", this.labelWB.Text, " (", this.labelComp.Text, ") for ", this.textHour.Text.Trim(), " hour(s) since PIN is entered and accepted by system.</td></tr>" };
            str = string.Concat(textArray2);
            if (this.textMessage.Text != "")
            {
                int index = 0;
                while (true)
                {
                    if (index >= this.textMessage.Lines.Length)
                    {
                        break;
                    }
                    if (index == 0)
                    {
                        str = str + "<tr class='bd'><td nowrap>Reason for Requesting Token</td><td nowrap> : " + this.textMessage.Lines[index] + "</td></tr>";
                    }
                    else if (index != 1)
                    {
                        str = str + "<tr><td nowrap>&nbsp;&nbsp;" + this.textMessage.Lines[index] + "</td></tr>";
                    }
                    else
                    {
                        object[] objArray1 = new object[] { str, "<tr><td rowspan=", this.textMessage.Lines.Length - 1, " nowrap></td><td nowrap>&nbsp;&nbsp;", this.textMessage.Lines[index], "</td></tr>" };
                        str = string.Concat(objArray1);
                    }
                    index++;
                }
            }
            str = str + "</table><br><br>Thank You. ";
            WBTable table = new WBTable();
            table.OpenTable("wb_email_master", "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND ( Email_Code ='" + email_code + "')"), WBData.conn);
            int num2 = 0;
            while (true)
            {
                if (num2 >= table.DT.Rows.Count)
                {
                    mail.Body = str;
                    try
                    {
                        mail.SendMail();
                    }
                    catch
                    {
                        this.errosendToken = true;
                        MessageBox.Show("Fail sending email!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    return;
                }
                DataRow row = table.DT.Rows[num2];
                string[] textArray3 = new string[] { row[0].ToString().Trim(), " ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
                mail.Subject = string.Concat(textArray3);
                mail.To = row[1].ToString().Trim();
                mail.CC = row[2].ToString().Trim();
                num2++;
            }
        }

        private bool sendHTTPRequest(string token_, string user_, string reason_)
        {
            string str3;
            string message;
            bool flag4;
            bool flag = true;
            bool flag2 = false;
            string str = WBSetting.token_path;
            if (str != "")
            {
                string[] textArray1 = new string[] { "tkn=", token_, "&user=", user_, "&rmk=", reason_ };
                string str2 = WBEncryption.Encrypt(string.Concat(textArray1));
                str3 = str + "?p=" + str2;
                message = "";
            }
            else
            {
                MessageBox.Show("Failed sending token: \n Token Path Not Found, please contact MIS HO", "FAILED SENDING TOKEN", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return false;
            }
            while (true)
            {
                if (!(flag && (this.sendingSMSCount < this.toleranceForSendingSMS)))
                {
                    if (this.sendingSMSCount >= this.toleranceForSendingSMS)
                    {
                        this.errosendToken = true;
                        string[] textArray3 = new string[] { "Failed sending token: \n", message, "\n\nPlease inform token ", token_, " to PIC manually to get PIN." };
                        MessageBox.Show(string.Concat(textArray3), "FAILED SENDING TOKEN", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    flag4 = flag2;
                    break;
                }
                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    using (WebClient client = new WebClient())
                    {
                        string[] separator = new string[] { "<!DOCTYPE" };
                        char[] chArray1 = new char[] { '|' };
                        string[] strArray2 = Convert.ToString(client.DownloadString(str3)).Split(separator, StringSplitOptions.None)[0].Trim().Split(chArray1);
                        if (strArray2[0].ToUpper().Trim() == "OK")
                        {
                            MessageBox.Show("Token " + token_ + " has been sent successfully!\n\n" + strArray2[1].Trim(), "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            flag2 = true;
                            flag = false;
                        }
                        else
                        {
                            message = this.firstLetterToUpper(strArray2[0].Trim().Replace("*", "").Replace(".", "").Trim());
                            flag2 = false;
                            flag = true;
                            this.sendingSMSCount++;
                        }
                    }
                    Cursor.Current = Cursors.Default;
                }
                catch (Exception exception)
                {
                    flag2 = false;
                    flag = true;
                    this.sendingSMSCount++;
                    message = exception.Message;
                }
            }
            return flag4;
        }

        private void setForm()
        {
            if (this.textBoxPIN.Text == "")
            {
                this.buttonProcess.Text = "Request for PIN";
                this.textMessage.ReadOnly = false;
                this.textMessage.Enabled = true;
            }
            else
            {
                this.buttonProcess.Text = "Process";
                this.textMessage.Text = "";
                this.textMessage.ReadOnly = true;
                this.textMessage.Enabled = false;
            }
        }

        private void textBoxPIN_TextChanged(object sender, EventArgs e)
        {
            this.setForm();
        }

        private void translate()
        {
            this.Text = Resource.Token_015;
            this.label1.Text = Resource.Token_016;
            this.label4.Text = Resource.Token_017;
            this.label5.Text = Resource.Token_003;
            this.label6.Text = Resource.Token_018;
            this.label7.Text = Resource.Token_007;
            this.label3.Text = Resource.Token_019;
        }
    }
}

