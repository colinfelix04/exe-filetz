﻿namespace WindowsFormsApplication1
{
    using Encryption.Utility;
    using Microsoft.Win32;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.IO;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormCfg : Form
    {
        public bool pReturn = false;
        public bool firstrun = false;
        public bool exit = false;
        public string sServer;
        public string sDatabase;
        public string sUser;
        public string sPass;
        public string sCoyCode;
        public string sLocCode;
        public string sWBCode;
        public string sPort;
        private IContainer components = null;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textServer;
        private TextBox textDatabase;
        private TextBox textUserID;
        private TextBox textPassword;
        private Button buttonConnect;
        private Button buttonSave;
        private Button buttonCancel;
        private Label label5;
        private TextBox textWBCode;
        private Label label8;
        private Button buttonQuit;
        private Label labelChangeServer;
        private Button buttonPCList;
        private Label labelCompName;
        private Button btnServerList;
        private Label label6;
        private Label labelPort;
        private TextBox textPort;

        public FormCfg()
        {
            this.InitializeComponent();
        }

        private void btnServerList_Click(object sender, EventArgs e)
        {
            FormServer server = new FormServer();
            server.ShowDialog();
            if (server.pReturn)
            {
                this.textServer.Text = WBData.sServer;
                this.textDatabase.Text = WBData.sDatabase;
                this.textUserID.Text = WBData.sUserID;
                this.textPassword.Text = WBData.sPassword;
                this.textPort.Text = (WBData.sPort == "") ? "8888" : WBData.sPort;
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.pReturn = false;
            base.Close();
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            WBData data = new WBData();
            WBData.sServer = this.textServer.Text;
            WBData.sDatabase = this.textDatabase.Text;
            WBData.sUserID = this.textUserID.Text;
            WBData.sPassword = this.textPassword.Text;
            WBData.sPort = this.textPort.Text;
            if (!data.TestConnect())
            {
                this.textServer.Focus();
                this.buttonSave.Enabled = false;
                this.buttonPCList.Enabled = false;
            }
            else
            {
                WBData.Close();
                MessageBox.Show(Resource.Mes_206, Resource.Title_007);
                this.buttonSave.Enabled = true;
                this.buttonPCList.Enabled = true;
            }
        }

        private void buttonPCList_Click(object sender, EventArgs e)
        {
            FormPCList list = new FormPCList();
            list.ShowDialog();
            list.Dispose();
        }

        private void buttonQuit_Click(object sender, EventArgs e)
        {
            this.exit = true;
            base.Close();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (this.textWBCode.Text.Trim() != "")
            {
                WBTable table2 = new WBTable();
                string[] textArray1 = new string[] { "Select * from wb_Setting where WBCode = '", this.textWBCode.Text.Trim(), "' and CompName <> '", this.labelCompName.Text.Trim(), "'" };
                table2.OpenTable("wb_setting", string.Concat(textArray1), WBData.conn);
                if (table2.DT.Rows.Count <= 0)
                {
                    table2.OpenTable("wb_setting", "Select * from wb_Setting where CompName = '" + this.labelCompName.Text.Trim() + "'", WBData.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        table2.DR = table2.DT.Rows[0];
                        if (this.textWBCode.Text.Trim().ToUpper() != table2.DR["WBCode"].ToString().ToUpper())
                        {
                            string[] textArray3 = new string[] { " This Computer Already have WBCode  \nCompany        : ", table2.DR["Coy"].ToString(), " \nLocation Code  : ", table2.DR["Location_Code"].ToString(), " \nWBCode         : ", table2.DR["WBCode"].ToString(), " \nThe WBCode Will be Changed To The Correct Code  \nClick Save Again..." };
                            MessageBox.Show(string.Concat(textArray3), "Wrong WBCode");
                            this.textWBCode.Text = table2.DR["WBCode"].ToString();
                            table2.Dispose();
                            return;
                        }
                    }
                    table2.Dispose();
                    WBData.sServer = this.textServer.Text;
                    WBData.sDatabase = this.textDatabase.Text;
                    WBData.sUserID = this.textUserID.Text;
                    WBData.sPassword = this.textPassword.Text;
                    WBData.sPort = this.textPort.Text;
                    WBData.sWBCode = this.textWBCode.Text;
                    this.sServer = this.textServer.Text;
                    this.sDatabase = this.textDatabase.Text;
                    this.sUser = this.textUserID.Text;
                    this.sPass = this.textPassword.Text;
                    this.sPort = this.textPort.Text;
                    this.sWBCode = this.textWBCode.Text;
                    WBConfigurationHandler.createDirectory();
                    WBConfigurationHandler.createTxtFile(WBConfigurationHandler.configurationFile);
                    Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                        { 
                            "SERVER",
                            this.textServer.Text.Trim()
                        },
                        { 
                            "DATABASE",
                            this.textDatabase.Text.Trim()
                        },
                        { 
                            "USERID",
                            this.textUserID.Text.Trim()
                        },
                        { 
                            "PASSWORD",
                            this.textPassword.Text.Trim()
                        },
                        { 
                            "WBCODE",
                            this.sWBCode.Trim()
                        },
                        { 
                            "PORT",
                            this.sPort.Trim()
                        },
                        { 
                            "REGION",
                            "0"
                        }
                    };
                    WBTable table = new WBTable();
                    table.OpenTable("WB_LOCATION", "SELECT TOP 1 LANGUAGE FROM WB_LOCATION", WBData.conn);
                    dictToTxt.Add("LANGUAGE", string.IsNullOrEmpty(table.DT.Rows[0]["LANGUAGE"].ToString()) ? "0" : table.DT.Rows[0]["LANGUAGE"].ToString());
                    table.Dispose();
                    WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                    dictToTxt.Clear();
                    this.pReturn = true;
                    base.Close();
                }
                else
                {
                    table2.DR = table2.DT.Rows[0];
                    string[] textArray2 = new string[] { " This WBCode Already Reserved for  \nCompany       : ", table2.DR["Coy"].ToString(), " \nLocation Code : ", table2.DR["Location_Code"].ToString(), " \nComputer Name : ", table2.DR["CompName"].ToString(), " \nPlease Use Another WBCode " };
                    MessageBox.Show(string.Concat(textArray2), "Wrong WBCode");
                    table2.Dispose();
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_023, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.textWBCode.Focus();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormCfg_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                this.pReturn = false;
                base.Close();
            }
        }

        private void FormCfg_Load(object sender, EventArgs e)
        {
            string str;
            this.translate();
            this.buttonSave.Enabled = false;
            this.buttonPCList.Enabled = false;
            this.labelCompName.Text = Environment.MachineName.ToString();
            Crypthography crypthography = new Crypthography();
            FileInfo info = new FileInfo(Application.StartupPath + @"\server.txt");
            if (!info.Exists)
            {
                this.btnServerList.Visible = true;
                if (!crypthography.checkFile())
                {
                    this.btnServerList.Visible = false;
                }
                else
                {
                    this.textServer.ReadOnly = true;
                    this.textDatabase.ReadOnly = true;
                    this.textUserID.ReadOnly = true;
                    this.textPassword.ReadOnly = true;
                    this.btnServerList.Visible = true;
                }
            }
            if (!info.Exists)
            {
                this.labelChangeServer.Visible = false;
            }
            else
            {
                this.btnServerList.Visible = false;
                this.labelChangeServer.Visible = true;
            }
            if (this.firstrun)
            {
                if (!info.Exists)
                {
                    if (!crypthography.checkFile())
                    {
                        MessageBox.Show("Server Connection Not Yet Listed Please Contact Administrator", "Configuration...");
                    }
                    else
                    {
                        FormServer server = new FormServer();
                        server.fLoad();
                        if (!server.getConnection())
                        {
                            MessageBox.Show("Failed to Retrive Connection List, Please Contact Administrator", "Error...");
                        }
                        else
                        {
                            this.textServer.Text = server.dataGridView1.Rows[0].Cells["Server"].Value.ToString();
                            this.textDatabase.Text = server.dataGridView1.Rows[0].Cells["Database"].Value.ToString();
                            this.textUserID.Text = server.dataGridView1.Rows[0].Cells["Username"].Value.ToString();
                            this.textPassword.Text = Program.shoot(server.dataGridView1.Rows[0].Cells["Shoot"].Value.ToString(), false);
                        }
                        server.Dispose();
                    }
                }
                goto TR_0006;
            }
            else
            {
                WBConfigurationHandler.createDirectory();
                if (!File.Exists(WBConfigurationHandler.configurationFile))
                {
                    RegistryKey key6 = Registry.LocalMachine.OpenSubKey("SOFTWARE", true);
                    RegistryKey key7 = key6.OpenSubKey("WCS DATABASE");
                    RegistryKey key8 = key6.CreateSubKey("WCS DATABASE").CreateSubKey("WB System");
                    this.textServer.Text = (string) key8.GetValue("Server");
                    this.textDatabase.Text = (string) key8.GetValue("Database");
                    this.textUserID.Text = Program.shoot((string) key8.GetValue("UserID"), false);
                    this.textPassword.Text = Program.shoot((string) key8.GetValue("Password"), false);
                    this.textPort.Text = "8888";
                    this.textWBCode.Text = (string) key8.GetValue("WBCode");
                    WBConfigurationHandler.createTxtFile(WBConfigurationHandler.configurationFile);
                    Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                        { 
                            "SERVER",
                            this.textServer.Text.Trim()
                        },
                        { 
                            "DATABASE",
                            this.textDatabase.Text.Trim()
                        },
                        { 
                            "USERID",
                            this.textUserID.Text.Trim()
                        },
                        { 
                            "PASSWORD",
                            this.textPassword.Text.Trim()
                        },
                        { 
                            "PORT",
                            this.textPort.Text.Trim()
                        },
                        { 
                            "WBCODE",
                            this.textWBCode.Text.Trim()
                        }
                    };
                    WBTable table2 = new WBTable();
                    table2.OpenTable("WB_LOCATION", "SELECT TOP 1 LANGUAGE FROM WB_LOCATION", WBData.conn);
                    dictToTxt.Add("LANGUAGE", string.IsNullOrEmpty(table2.DT.Rows[0]["LANGUAGE"].ToString()) ? "0" : table2.DT.Rows[0]["LANGUAGE"].ToString());
                    table2.Dispose();
                    WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                    dictToTxt.Clear();
                    goto TR_0006;
                }
                else
                {
                    str = "";
                    using (FileStream stream = new FileStream(WBConfigurationHandler.configurationFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        using (StreamReader reader = new StreamReader(stream))
                        {
                            str = WBEncryption.Decrypt(reader.ReadToEnd());
                        }
                    }
                }
            }
            if (str != "")
            {
                Dictionary<string, string> dictionary2 = WBConfigurationHandler.readFromTxt(WBConfigurationHandler.configurationFile);
                this.textServer.Text = dictionary2.ContainsKey("SERVER") ? dictionary2["SERVER"] : "";
                this.textDatabase.Text = dictionary2.ContainsKey("DATABASE") ? dictionary2["DATABASE"] : "";
                this.textUserID.Text = dictionary2.ContainsKey("USERID") ? dictionary2["USERID"] : "";
                this.textPassword.Text = dictionary2.ContainsKey("PASSWORD") ? dictionary2["PASSWORD"] : "";
                this.textPort.Text = dictionary2.ContainsKey("PORT") ? dictionary2["PORT"] : "";
                this.textWBCode.Text = dictionary2.ContainsKey("WBCODE") ? dictionary2["WBCODE"] : "";
                dictionary2.Clear();
            }
            else
            {
                RegistryKey key2 = Registry.LocalMachine.OpenSubKey("SOFTWARE", true);
                RegistryKey key3 = key2.OpenSubKey("WCS DATABASE");
                RegistryKey key4 = key2.CreateSubKey("WCS DATABASE").CreateSubKey("WB System");
                this.textServer.Text = (string) key4.GetValue("Server");
                this.textDatabase.Text = (string) key4.GetValue("Database");
                this.textUserID.Text = Program.shoot((string) key4.GetValue("UserID"), false);
                this.textPassword.Text = Program.shoot((string) key4.GetValue("Password"), false);
                this.textPort.Text = "8888";
                this.textWBCode.Text = (string) key4.GetValue("WBCode");
                Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                    { 
                        "SERVER",
                        this.textServer.Text.Trim()
                    },
                    { 
                        "DATABASE",
                        this.textDatabase.Text.Trim()
                    },
                    { 
                        "USERID",
                        this.textUserID.Text.Trim()
                    },
                    { 
                        "PASSWORD",
                        this.textPassword.Text.Trim()
                    },
                    { 
                        "PORT",
                        this.textPort.Text.Trim()
                    },
                    { 
                        "WBCODE",
                        this.textWBCode.Text.Trim()
                    }
                };
                WBTable table = new WBTable();
                table.OpenTable("WB_LOCATION", "SELECT TOP 1 LANGUAGE FROM WB_LOCATION", WBData.conn);
                dictToTxt.Add("LANGUAGE", string.IsNullOrEmpty(table.DT.Rows[0]["LANGUAGE"].ToString()) ? "0" : table.DT.Rows[0]["LANGUAGE"].ToString());
                table.Dispose();
                WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                dictToTxt.Clear();
            }
        TR_0006:
            crypthography.Dispose();
            this.label5.Height = 2;
            base.KeyPreview = true;
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.label4 = new Label();
            this.textServer = new TextBox();
            this.textDatabase = new TextBox();
            this.textUserID = new TextBox();
            this.textPassword = new TextBox();
            this.buttonConnect = new Button();
            this.buttonSave = new Button();
            this.buttonCancel = new Button();
            this.label5 = new Label();
            this.textWBCode = new TextBox();
            this.label8 = new Label();
            this.buttonQuit = new Button();
            this.labelChangeServer = new Label();
            this.buttonPCList = new Button();
            this.labelCompName = new Label();
            this.btnServerList = new Button();
            this.label6 = new Label();
            this.labelPort = new Label();
            this.textPort = new TextBox();
            base.SuspendLayout();
            this.label1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(0x10, 0x19);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x75, 0x11);
            this.label1.TabIndex = 10;
            this.label1.Text = "Server";
            this.label1.TextAlign = ContentAlignment.TopRight;
            this.label2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label2.Location = new Point(0x13, 0x34);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x72, 0x11);
            this.label2.TabIndex = 11;
            this.label2.Text = "Database Name";
            this.label2.TextAlign = ContentAlignment.TopRight;
            this.label3.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(0x16, 0x4f);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x6f, 0x11);
            this.label3.TabIndex = 12;
            this.label3.Text = "User ID";
            this.label3.TextAlign = ContentAlignment.TopRight;
            this.label4.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label4.Location = new Point(0x19, 0x6a);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x6c, 0x10);
            this.label4.TabIndex = 13;
            this.label4.Text = "Password";
            this.label4.TextAlign = ContentAlignment.TopRight;
            this.textServer.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textServer.Location = new Point(0x8d, 0x16);
            this.textServer.Name = "textServer";
            this.textServer.Size = new Size(0xc6, 0x17);
            this.textServer.TabIndex = 0;
            this.textDatabase.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textDatabase.Location = new Point(0x8d, 0x31);
            this.textDatabase.Name = "textDatabase";
            this.textDatabase.Size = new Size(0xc6, 0x17);
            this.textDatabase.TabIndex = 1;
            this.textUserID.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textUserID.Location = new Point(0x8d, 0x4c);
            this.textUserID.Name = "textUserID";
            this.textUserID.Size = new Size(0x85, 0x17);
            this.textUserID.TabIndex = 2;
            this.textUserID.UseSystemPasswordChar = true;
            this.textPassword.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textPassword.Location = new Point(0x8d, 0x67);
            this.textPassword.Name = "textPassword";
            this.textPassword.Size = new Size(0x85, 0x17);
            this.textPassword.TabIndex = 3;
            this.textPassword.UseSystemPasswordChar = true;
            this.buttonConnect.Location = new Point(0x15d, 0x4c);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new Size(0x72, 0x2f);
            this.buttonConnect.TabIndex = 5;
            this.buttonConnect.Text = "Connect";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new EventHandler(this.buttonConnect_Click);
            this.buttonSave.Location = new Point(0x70, 0xf1);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x4b, 0x20);
            this.buttonSave.TabIndex = 6;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.buttonCancel.Location = new Point(0xd1, 0xf1);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x4b, 0x20);
            this.buttonCancel.TabIndex = 7;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.label5.BorderStyle = BorderStyle.Fixed3D;
            this.label5.Location = new Point(15, 0xa5);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x1c0, 10);
            this.label5.TabIndex = 14;
            this.label5.Text = "label5";
            this.textWBCode.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textWBCode.Location = new Point(0x8d, 0xc6);
            this.textWBCode.MaxLength = 5;
            this.textWBCode.Name = "textWBCode";
            this.textWBCode.Size = new Size(0x51, 0x15);
            this.textWBCode.TabIndex = 4;
            this.textWBCode.KeyPress += new KeyPressEventHandler(this.textWBCode_KeyPress);
            this.label8.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label8.Location = new Point(12, 0xc9);
            this.label8.Name = "label8";
            this.label8.Size = new Size(120, 20);
            this.label8.TabIndex = 15;
            this.label8.Text = "Weigh Indicator Code";
            this.label8.TextAlign = ContentAlignment.TopRight;
            this.buttonQuit.Location = new Point(0x12f, 0xf1);
            this.buttonQuit.Name = "buttonQuit";
            this.buttonQuit.Size = new Size(0x4b, 0x20);
            this.buttonQuit.TabIndex = 8;
            this.buttonQuit.Text = "Quit";
            this.buttonQuit.UseVisualStyleBackColor = true;
            this.buttonQuit.Click += new EventHandler(this.buttonQuit_Click);
            this.labelChangeServer.AutoSize = true;
            this.labelChangeServer.Dock = DockStyle.Right;
            this.labelChangeServer.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Underline | FontStyle.Italic, GraphicsUnit.Point, 0);
            this.labelChangeServer.Location = new Point(0x196, 0);
            this.labelChangeServer.Name = "labelChangeServer";
            this.labelChangeServer.Size = new Size(0x4e, 13);
            this.labelChangeServer.TabIndex = 9;
            this.labelChangeServer.Text = "Change Server";
            this.labelChangeServer.Visible = false;
            this.labelChangeServer.Click += new EventHandler(this.labelChangeServer_Click);
            this.buttonPCList.Location = new Point(0xe4, 0xc6);
            this.buttonPCList.Name = "buttonPCList";
            this.buttonPCList.Size = new Size(0x58, 0x17);
            this.buttonPCList.TabIndex = 0x10;
            this.buttonPCList.Text = "Computer List";
            this.buttonPCList.UseVisualStyleBackColor = true;
            this.buttonPCList.Click += new EventHandler(this.buttonPCList_Click);
            this.labelCompName.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelCompName.Location = new Point(0x10, 0xb1);
            this.labelCompName.Name = "labelCompName";
            this.labelCompName.Size = new Size(0x1bf, 20);
            this.labelCompName.TabIndex = 0x11;
            this.labelCompName.Text = "Computer Name";
            this.labelCompName.TextAlign = ContentAlignment.TopRight;
            this.btnServerList.Location = new Point(0x15d, 0x16);
            this.btnServerList.Name = "btnServerList";
            this.btnServerList.Size = new Size(0x72, 0x1f);
            this.btnServerList.TabIndex = 0x13;
            this.btnServerList.Text = "Server List";
            this.btnServerList.UseVisualStyleBackColor = true;
            this.btnServerList.Click += new EventHandler(this.btnServerList_Click);
            this.label6.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label6.Location = new Point(-22, 0x11e);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0xf5, 20);
            this.label6.TabIndex = 0x12;
            this.label6.Text = "*Click Test Connect To Enable Save";
            this.label6.TextAlign = ContentAlignment.TopRight;
            this.labelPort.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelPort.Location = new Point(0x19, 0x85);
            this.labelPort.Name = "labelPort";
            this.labelPort.Size = new Size(0x6c, 0x10);
            this.labelPort.TabIndex = 0x15;
            this.labelPort.Text = "Port";
            this.labelPort.TextAlign = ContentAlignment.TopRight;
            this.textPort.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textPort.Location = new Point(0x8d, 130);
            this.textPort.Name = "textPort";
            this.textPort.Size = new Size(0x52, 0x17);
            this.textPort.TabIndex = 0x16;
            this.textPort.Text = "8888";
            this.textPort.UseSystemPasswordChar = true;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1e4, 0x138);
            base.ControlBox = false;
            base.Controls.Add(this.textPort);
            base.Controls.Add(this.labelPort);
            base.Controls.Add(this.btnServerList);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.labelCompName);
            base.Controls.Add(this.buttonPCList);
            base.Controls.Add(this.labelChangeServer);
            base.Controls.Add(this.buttonQuit);
            base.Controls.Add(this.textWBCode);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.buttonConnect);
            base.Controls.Add(this.textPassword);
            base.Controls.Add(this.textUserID);
            base.Controls.Add(this.textDatabase);
            base.Controls.Add(this.textServer);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.KeyPreview = true;
            base.Name = "FormCfg";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Database Configuration";
            base.Load += new EventHandler(this.FormCfg_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormCfg_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void labelChangeServer_Click(object sender, EventArgs e)
        {
            FormServer server = new FormServer();
            server.ShowDialog();
            if (server.pReturn)
            {
                this.textServer.Text = WBData.sServer;
                this.textDatabase.Text = WBData.sDatabase;
                this.textUserID.Text = WBData.sUserID;
                this.textPassword.Text = WBData.sPassword;
            }
        }

        private void textWBCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void translate()
        {
            this.Text = Resource.DbConn_001;
            this.label1.Text = Resource.DbConn_002;
            this.label2.Text = Resource.DbConn_003;
            this.label3.Text = Resource.DbConn_004;
            this.label4.Text = Resource.DbConn_005;
            this.label8.Text = Resource.DbConn_006;
            this.buttonConnect.Text = Resource.DbConn_007;
            this.buttonSave.Text = Resource.DbConn_008;
            this.buttonCancel.Text = Resource.DbConn_009;
            this.buttonQuit.Text = Resource.DbConn_010;
            this.labelChangeServer.Text = Resource.Login_008;
        }
    }
}

