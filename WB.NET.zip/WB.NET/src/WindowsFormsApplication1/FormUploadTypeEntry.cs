﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormUploadTypeEntry : Form
    {
        public string pMode;
        public string changeReason = "";
        public string logKey = "";
        public WBTable zTable;
        public int nCurrRow;
        public bool saved;
        private IContainer components = null;
        private TextBox textDigit;
        private Label label10;
        public TextBox textDigitValue;
        private Label label1;
        private Button button2;
        private Button button1;
        public TextBox textDesc;
        private Label label2;
        public TextBox textUploadCode;
        private Label label3;
        private Label label4;
        public TextBox textMovement;

        public FormUploadTypeEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TextBox[] aText = new TextBox[] { this.textDigit, this.textDigitValue, this.textUploadCode, this.textMovement };
            if (!Program.CheckEmpty(aText))
            {
                if (this.pMode == "EDIT")
                {
                    FormTransCancel cancel = new FormTransCancel {
                        label1 = { Text = Resource.UploadType_001 },
                        textRefNo = { Text = this.textUploadCode.Text },
                        Text = Resource.Title_Change_Reason,
                        label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                    };
                    cancel.textReason.Focus();
                    cancel.ShowDialog();
                    if (cancel.Saved)
                    {
                        this.changeReason = cancel.textReason.Text;
                        cancel.Dispose();
                    }
                    else
                    {
                        return;
                    }
                }
                Cursor.Current = Cursors.WaitCursor;
                if (this.pMode == "ADD")
                {
                    this.zTable.DR = this.zTable.DT.NewRow();
                }
                else
                {
                    this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                    this.logKey = this.zTable.DR["uniq"].ToString();
                    this.zTable.DR.BeginEdit();
                }
                this.zTable.DR["Coy"] = WBData.sCoyCode;
                this.zTable.DR["Location_Code"] = WBData.sLocCode;
                this.zTable.DR["Digit"] = this.textDigit.Text.Trim();
                this.zTable.DR["Digit_Value"] = this.textDigitValue.Text.Trim();
                this.zTable.DR["Upload_Type"] = this.textUploadCode.Text.Trim();
                this.zTable.DR["Description"] = this.textDesc.Text.Trim();
                this.zTable.DR["Movement_Type"] = this.textMovement.Text.Trim();
                if (this.pMode == "ADD")
                {
                    this.zTable.DR["Create_By"] = WBUser.UserID;
                    this.zTable.DR["Create_Date"] = DateTime.Now.ToString();
                    this.zTable.DT.Rows.Add(this.zTable.DR);
                }
                else
                {
                    this.zTable.DR["Change_By"] = WBUser.UserID;
                    this.zTable.DR["Change_Date"] = DateTime.Now.ToString();
                    this.zTable.DR.EndEdit();
                }
                this.zTable.Save();
                if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
                {
                    if (this.pMode == "ADD")
                    {
                        WBTable table = new WBTable();
                        table.OpenTable("wb_upload_type", "SELECT uniq FROM wb_upload_type WHERE " + WBData.CompanyLocation(" AND upload_type = '" + this.textUploadCode.Text + "'"), WBData.conn);
                        this.logKey = table.DT.Rows[0]["uniq"].ToString();
                        table.Dispose();
                    }
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                    Program.updateLogHeader("wb_upload_type", this.logKey, logField, logValue);
                }
                Cursor.Current = Cursors.Default;
                this.saved = true;
                base.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormUploadTypeEntry_Load(object sender, EventArgs e)
        {
            if (this.pMode == "ADD")
            {
                this.textDigit.Text = "";
                this.textDigitValue.Text = "";
                this.textDesc.Text = "";
                this.textUploadCode.Text = "";
                this.textMovement.Text = "";
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.textDigit.Text = this.zTable.DR["Digit"].ToString();
                this.textDigitValue.Text = this.zTable.DR["Digit_Value"].ToString();
                this.textUploadCode.Text = this.zTable.DR["Upload_Type"].ToString();
                this.textDesc.Text = this.zTable.DR["Description"].ToString().Trim();
                this.textMovement.Text = this.zTable.DR["Movement_Type"].ToString().Trim();
                if (this.pMode == "VIEW")
                {
                    foreach (Control control in base.Controls)
                    {
                        control.Enabled = false;
                    }
                    this.button2.Text = Resource.Btn_Close;
                    this.button2.Enabled = true;
                }
            }
        }

        private void InitializeComponent()
        {
            this.textDigit = new TextBox();
            this.label10 = new Label();
            this.textDigitValue = new TextBox();
            this.label1 = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.textDesc = new TextBox();
            this.label2 = new Label();
            this.textUploadCode = new TextBox();
            this.label3 = new Label();
            this.label4 = new Label();
            this.textMovement = new TextBox();
            base.SuspendLayout();
            this.textDigit.CharacterCasing = CharacterCasing.Upper;
            this.textDigit.Location = new Point(0x6c, 0x58);
            this.textDigit.Name = "textDigit";
            this.textDigit.Size = new Size(0x2f, 20);
            this.textDigit.TabIndex = 50;
            this.textDigit.Text = "0";
            this.label10.Location = new Point(13, 0x5b);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x52, 13);
            this.label10.TabIndex = 0x35;
            this.label10.Text = "Digit";
            this.textDigitValue.CharacterCasing = CharacterCasing.Upper;
            this.textDigitValue.Location = new Point(0x6c, 0x72);
            this.textDigitValue.Name = "textDigitValue";
            this.textDigitValue.Size = new Size(0x2f, 20);
            this.textDigitValue.TabIndex = 0x33;
            this.textDigitValue.Text = "0";
            this.label1.Location = new Point(13, 0x75);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x52, 13);
            this.label1.TabIndex = 0x34;
            this.label1.Text = "Digit Value";
            this.button2.Location = new Point(280, 0xb7);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 0x37;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0xba, 0xb7);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 0x36;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textDesc.CharacterCasing = CharacterCasing.Upper;
            this.textDesc.Location = new Point(0x6c, 0x26);
            this.textDesc.Multiline = true;
            this.textDesc.Name = "textDesc";
            this.textDesc.Size = new Size(0xf4, 0x2c);
            this.textDesc.TabIndex = 0x38;
            this.label2.Location = new Point(13, 0x29);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x52, 13);
            this.label2.TabIndex = 0x39;
            this.label2.Text = "Description";
            this.textUploadCode.CharacterCasing = CharacterCasing.Upper;
            this.textUploadCode.Location = new Point(0x6b, 12);
            this.textUploadCode.Name = "textUploadCode";
            this.textUploadCode.Size = new Size(90, 20);
            this.textUploadCode.TabIndex = 0x3a;
            this.label3.Location = new Point(12, 15);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x52, 13);
            this.label3.TabIndex = 0x3b;
            this.label3.Text = "Upload Code";
            this.label4.Location = new Point(13, 0x92);
            this.label4.Name = "label4";
            this.label4.Size = new Size(100, 0x11);
            this.label4.TabIndex = 60;
            this.label4.Text = "Add. Mov. Type";
            this.textMovement.CharacterCasing = CharacterCasing.Upper;
            this.textMovement.Location = new Point(0x6c, 0x8f);
            this.textMovement.Name = "textMovement";
            this.textMovement.Size = new Size(90, 20);
            this.textMovement.TabIndex = 0x3d;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x179, 0xe0);
            base.ControlBox = false;
            base.Controls.Add(this.textMovement);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textUploadCode);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textDesc);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textDigit);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.textDigitValue);
            base.Controls.Add(this.label1);
            base.KeyPreview = true;
            base.Name = "FormUploadTypeEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Entry Upload Type";
            base.Load += new EventHandler(this.FormUploadTypeEntry_Load);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label3.Text = Resource.UploadType_001;
            this.label2.Text = Resource.UploadType_002;
            this.label10.Text = Resource.UploadType_003;
            this.label1.Text = Resource.UploadType_004;
            this.button1.Text = Resource.Save;
            this.button2.Text = Resource.Menu_Cancel;
            this.label4.Text = Resource.Lbl_Add_Mov_Type;
            this.Text = Resource.Title_Upload_Type_Entry;
        }
    }
}

