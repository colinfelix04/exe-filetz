﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormMergeDoVessel : Form
    {
        public WBTable t_item = new WBTable();
        public WBTable s_help = new WBTable();
        public WBTable t_trans = new WBTable();
        public WBTable t_do = new WBTable();
        public WBTable t_do_save = new WBTable();
        public WBTable t_os = new WBTable();
        public WBTable t_tmp = new WBTable();
        public long total_qty = 0L;
        public long qty_do_vessel = 0L;
        public double used = 0.0;
        private int n_ref = 0;
        private int n_do = 0;
        private string last_ref = "";
        private IContainer components = null;
        private GroupBox gb_header;
        private Button btn_go;
        private TextBox text_DO;
        private GroupBox gb_detail;
        private GroupBox gb_info;
        private DataGridView dgv_item;
        private DataGridView dgv_split;
        private DateTimePicker date_transFrom;
        private Button btn_search;
        private GroupBox gb_filter;
        private RadioButton rb_date;
        private RadioButton rb_all;
        private Panel panel_info;
        private DateTimePicker date_DO;
        private Label label2;
        private TextBox text_qty;
        private Label label1;
        private Button btn_cancel;
        private Button btn_Merge;
        private Label label4;
        private TextBox text_remain;
        private Label label3;
        private TextBox text_used;
        private Label label_do_complete;
        private Button buttonDO;
        private DateTimePicker date_TransTo;

        public FormMergeDoVessel()
        {
            this.InitializeComponent();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btn_go_Click(object sender, EventArgs e)
        {
            if (this.text_DO.Text == "")
            {
                MessageBox.Show("Please fill in DO Vessel", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                this.text_DO.Text = this.text_DO.Text.Trim();
                string[] aField = new string[] { "do_no" };
                string[] aFind = new string[] { this.text_DO.Text.Trim() };
                DataRow data = this.s_help.GetData(aField, aFind);
                if (ReferenceEquals(data, null))
                {
                    MessageBox.Show("Invalid DO", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    if (Program.getFieldValue("wb_transaction_type", "is_vessel", "transaction_code", data["transaction_code"].ToString()) != "Y")
                    {
                        MessageBox.Show(Resource.Mes_Warning_Not_Vessel_DO, Resource.Mes_Warning, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    this.gb_detail.Visible = true;
                    this.gb_info.Visible = true;
                    this.panel_info.Visible = true;
                    this.gb_filter.Visible = true;
                    this.date_DO.Value = Convert.ToDateTime(data["Do_Date"].ToString());
                    this.text_qty.Text = data["quantity"].ToString();
                    this.qty_do_vessel = long.Parse(this.text_qty.Text);
                    this.total_qty = long.Parse(data["quantity"].ToString());
                    this.label_do_complete.Visible = Program.getFieldValue("wb_vessel_map", "completed", "uniq_vessel", data["uniq"].ToString()) == "Y";
                    string sqltext = ("SELECT Do_No, qty_map as Quantity, DeductedBy as Used, DeductedBy as Outstanding," + " Comm_Code , Relation_Code, Estate1_Code, Transporter_Code, Transaction_Code" + " FROM wb_vessel_map m LEFT JOIN wb_contract c ON m.uniq_item = c.uniq") + " WHERE uniq_vessel = '" + data["uniq"].ToString() + "' ORDER BY Do_No";
                    this.t_item.OpenTable("wb_contract", sqltext, WBData.conn);
                    this.dgv_item.DataSource = this.t_item.DT;
                    this.dgv_item.Columns["Comm_Code"].Visible = false;
                    this.dgv_item.Columns["Relation_Code"].Visible = false;
                    this.dgv_item.Columns["Estate1_Code"].Visible = false;
                    this.dgv_item.Columns["Transporter_Code"].Visible = false;
                    this.dgv_item.Columns["Transaction_Code"].Visible = false;
                    this.dgv_item.Columns["quantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgv_item.Columns["used"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgv_item.Columns["outstanding"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    foreach (DataGridViewRow row2 in (IEnumerable) this.dgv_item.Rows)
                    {
                        string str4 = ((DataGridViewTextBoxCell) row2.Cells["do_no"]).Value.ToString();
                        string str5 = ((DataGridViewTextBoxCell) row2.Cells["Outstanding"]).Value.ToString();
                        string str6 = ((("SELECT SUM(trans.Net) AS Nett FROM wb_transaction trans" + " LEFT JOIN wb_transSplit b ON trans.ref LIKE b.ref+'%'") + " WHERE b.Do_No LIKE '" + this.text_DO.Text + "'") + " AND trans.do_no = '" + str4 + "'") + " AND ((trans.mark_accident IS NULL) AND (trans.Deleted IS NULL) AND " + " (trans.Report_Date IS NOT NULL) OR (trans.mark_accident = '') AND (trans.Deleted = ''))";
                        this.t_os.OpenTable("vw_os", str6, WBData.conn);
                        if (this.t_os.DT.Rows.Count == 1)
                        {
                            this.t_os.DR = this.t_os.DT.Rows[0];
                            double num = Program.StrToDouble(((DataGridViewTextBoxCell) row2.Cells["quantity"]).Value.ToString(), 0);
                            double num2 = Program.StrToDouble(this.t_os.DR["Nett"].ToString(), 0);
                            ((DataGridViewTextBoxCell) row2.Cells["used"]).Value = num2;
                            double num3 = num - num2;
                            ((DataGridViewTextBoxCell) row2.Cells["outstanding"]).Value = num3;
                            this.used += num2;
                        }
                    }
                    this.text_used.Text = this.used.ToString();
                    this.text_remain.Text = (Program.StrToDouble(this.text_qty.Text, 0) - this.used).ToString();
                    this.dgv_split.ColumnCount = 5;
                    this.dgv_split.Columns[0].Name = "REF";
                    this.dgv_split.Columns[0].HeaderText = "Ref No";
                    this.dgv_split.Columns[1].Name = "GROSS";
                    this.dgv_split.Columns[1].HeaderText = "Gross";
                    this.dgv_split.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgv_split.Columns[2].Name = "TARE";
                    this.dgv_split.Columns[2].HeaderText = "Tare";
                    this.dgv_split.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgv_split.Columns[3].Name = "NET";
                    this.dgv_split.Columns[3].HeaderText = "Net";
                    this.dgv_split.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.dgv_split.Columns[4].Name = "DATE";
                    this.dgv_split.Columns[4].HeaderText = "Report Date";
                    this.dgv_split.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    this.btn_search.Focus();
                }
            }
        }

        private void btn_Merge_Click(object sender, EventArgs e)
        {
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            WBTable table3 = new WBTable();
            WBTable table4 = new WBTable();
            WBTable table5 = new WBTable();
            WBTable table6 = new WBTable();
            if (this.n_ref == 0)
            {
                MessageBox.Show("No Record to Merge", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (MessageBox.Show("Are you sure you want to Merge?", "Please confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Cursor.Current = Cursors.WaitCursor;
                foreach (DataRow row in this.t_trans.DT.Rows)
                {
                    string str = row["Ref"].ToString();
                    string str2 = "";
                    double num2 = 0.0;
                    double num3 = 0.0;
                    string str3 = "";
                    double num4 = 0.0;
                    double num5 = 0.0;
                    int count = 0;
                    table3.OpenTable("wb_transSplit", "select * from wb_transSplit where " + WBData.CompanyLocation(" and Ref = '" + row["Ref"].ToString() + "'"), WBData.conn);
                    table3.DR = table3.DT.Rows[0];
                    table6.OpenTable("wb_contract", "select * from wb_contract where " + WBData.CompanyLocation(" and Do_No = '" + this.text_DO.Text.Trim().ToUpper() + "'"), WBData.conn);
                    table6.DR = table6.DT.Rows[0];
                    table2.OpenTable("wb_transDO", "select * from wb_transDO where " + WBData.CompanyLocation(" and ref like '" + row["Ref"].ToString() + "%'") + " order by ref asc;", WBData.conn);
                    count = table2.DT.Rows.Count;
                    table5.OpenTable("wb_transBatch", "select * from wb_transBatch where " + WBData.CompanyLocation(" and ref like '" + row["Ref"].ToString() + "%'"), WBData.conn);
                    string[] strArray = new string[table5.DT.Rows.Count];
                    int index = 0;
                    while (true)
                    {
                        if (index >= table5.DT.Rows.Count)
                        {
                            table5.Save();
                            int num8 = 0;
                            while (true)
                            {
                                if (num8 >= strArray.Length)
                                {
                                    num2 = 0.0;
                                    num3 = 0.0;
                                    str3 = "";
                                    num4 = 0.0;
                                    int num9 = 0;
                                    while (true)
                                    {
                                        if (num9 >= count)
                                        {
                                            if ((num2 > 0.0) && (num3 > 0.0))
                                            {
                                                num4 = num2 / num3;
                                            }
                                            string keyField = "";
                                            string[,] strArray2 = new string[count, 2];
                                            int num10 = 0;
                                            while (true)
                                            {
                                                if (num10 >= count)
                                                {
                                                    table2.Save();
                                                    int num14 = 0;
                                                    while (true)
                                                    {
                                                        if (num14 >= count)
                                                        {
                                                            table.OpenTable("wb_transTemp", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref like '" + str + "%'"), WBData.conn);
                                                            count = table.DT.Rows.Count;
                                                            if (table.DT.Rows.Count > 0)
                                                            {
                                                                int num15 = 0;
                                                                while (true)
                                                                {
                                                                    if (num15 >= count)
                                                                    {
                                                                        break;
                                                                    }
                                                                    table.DR = table.DT.Rows[num15];
                                                                    if (((str == table.DR["REF"].ToString()) || ((str + "T") == table.DR["REF"].ToString())) && (table.DR["split"].ToString() == "Y"))
                                                                    {
                                                                        table.DR.BeginEdit();
                                                                        table.DR["Split"] = "N";
                                                                        table.DR["posted"] = "N";
                                                                        string str6 = "";
                                                                        try
                                                                        {
                                                                            str6 = table3.DR["DO_No"].ToString().Trim();
                                                                        }
                                                                        catch
                                                                        {
                                                                            str6 = "";
                                                                        }
                                                                        if (str6 != "")
                                                                        {
                                                                            table.DR["DO_No"] = str6;
                                                                        }
                                                                        table.DR["PI_No"] = table6.DR["PI_No"].ToString().Trim();
                                                                        table.DR["Transaction_Code"] = Program.getFieldValue("wb_contract", "transaction_code", "DO_NO", table.DR["DO_No"].ToString());
                                                                        table.DR["Comm_Code"] = table6.DR["Comm_Code"].ToString().Trim();
                                                                        table.DR["Relation_Code"] = table6.DR["Relation_Code"].ToString().Trim();
                                                                        table.DR["Estate"] = table6.DR["Estate1_Code"].ToString().Trim();
                                                                        table.DR["Transporter_Code"] = table6.DR["Transporter_Code"].ToString().Trim();
                                                                        table.DR["_1ST"] = table3.DR["_1ST"].ToString();
                                                                        table.DR["_2ND"] = table3.DR["_2ND"].ToString();
                                                                        table.DR["_3RD"] = table3.DR["_3RD"].ToString();
                                                                        table.DR["_4TH"] = table3.DR["_4TH"].ToString();
                                                                        table.DR["Gross"] = table3.DR["Gross"].ToString();
                                                                        table.DR["Tare"] = table3.DR["Tare"].ToString();
                                                                        table.DR["Received"] = table3.DR["Received"].ToString();
                                                                        table.DR["Net"] = table3.DR["Net"].ToString();
                                                                        table.DR["UnitName"] = str3;
                                                                        table.DR["TotalBunch"] = num3;
                                                                        table.DR["TotalBunchGrading"] = num3;
                                                                        table.DR["Deduction"] = num2 + (Program.StrToDouble(table.DR["Deduction"].ToString(), 0) - num5);
                                                                        num4 = ((num3 <= 0.0) || (num2 <= 0.0)) ? 0.0 : Program.StrToDouble((num2 / num3).ToString(), 2);
                                                                        table.DR["WeightPerUnitName"] = num4;
                                                                        table.DR["Gross_Estate"] = table3.DR["Gross_Estate"].ToString();
                                                                        table.DR["Tare_Estate"] = table3.DR["Tare_Estate"].ToString();
                                                                        table.DR["Net_Estate"] = table3.DR["Net_Estate"].ToString();
                                                                        table.DR["checksum"] = table.Checksum_Main(table.DR);
                                                                        table.DR.EndEdit();
                                                                        table.Save();
                                                                        string[] textArray11 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                        string[] textArray12 = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                                        Program.updateLogHeader("wb_transaction", table.DR["uniq"].ToString(), textArray11, textArray12);
                                                                    }
                                                                    num15++;
                                                                }
                                                            }
                                                            table3.Close();
                                                            table.Close();
                                                            if (num4 > 0.0)
                                                            {
                                                                table2.OpenTable("wb_transDOTemp", "Select * from wb_transDO where " + WBData.CompanyLocation(" and ref = '" + str + "'"), WBData.conn);
                                                                if (table2.DT.Rows.Count > 0)
                                                                {
                                                                    table2.DR = table2.DT.Rows[0];
                                                                    table2.DR.BeginEdit();
                                                                    table2.DR["WeightPerUnitName"] = Program.StrToDouble(num4.ToString(), 2);
                                                                    table2.DR["DeducUnitQty"] = num3;
                                                                    table2.DR["TotalDeducUnit"] = num2;
                                                                    table2.DR["deduction"] = num2;
                                                                    table2.DR.EndEdit();
                                                                    table2.Save();
                                                                    string[] textArray13 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                    string[] textArray14 = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                                    Program.updateLogHeader("wb_transDO", table2.DR["uniq"].ToString(), textArray13, textArray14);
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        if (strArray2[num14, 1] == "del")
                                                        {
                                                            string[] textArray7 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                            string[] textArray8 = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                            Program.updateLogHeader("wb_transDO", strArray2[num14, 0], textArray7, textArray8);
                                                        }
                                                        else if (strArray2[num14, 1] == "edit")
                                                        {
                                                            string[] textArray9 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                            string[] textArray10 = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                            Program.updateLogHeader("wb_transDO", strArray2[num14, 0], textArray9, textArray10);
                                                        }
                                                        num14++;
                                                    }
                                                    break;
                                                }
                                                table2.DR = table2.DT.Rows[num10];
                                                str2 = table2.DR["ref"].ToString().Trim();
                                                if ((str2 == str) || (str2 == (str + "T")))
                                                {
                                                    if ((str2 == str) || (str2 == (str + "T")))
                                                    {
                                                        table.OpenTable("wb_transTemp", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + str2 + "'"), WBData.conn);
                                                        if (table.DT.Rows.Count > 0)
                                                        {
                                                            table.DR = table.DT.Rows[0];
                                                            if (table.DR["split"].ToString() == "Y")
                                                            {
                                                                strArray2[num10, 0] = table2.DR["uniq"].ToString();
                                                                strArray2[num10, 1] = "edit";
                                                                table2.DR.BeginEdit();
                                                                string str5 = "";
                                                                try
                                                                {
                                                                    str5 = table3.DR["DO_No"].ToString().Trim();
                                                                }
                                                                catch
                                                                {
                                                                    str5 = "";
                                                                }
                                                                if (str5 != "")
                                                                {
                                                                    table2.DR["DO_No"] = str5;
                                                                }
                                                                table2.DR["Contract"] = table6.DR["Contract"].ToString().Trim();
                                                                table2.DR["PI_No"] = table6.DR["PI_No"].ToString().Trim();
                                                                table2.DR["Transaction_Code"] = table6.DR["Transaction_Code"].ToString().Trim();
                                                                table2.DR["Comm_Code"] = table6.DR["Comm_Code"].ToString().Trim();
                                                                table2.DR["Relation_Code"] = table6.DR["Relation_Code"].ToString().Trim();
                                                                table2.DR["Estate"] = table6.DR["Estate1_Code"].ToString().Trim();
                                                                table2.DR["Transporter_Code"] = table6.DR["Transporter_Code"].ToString().Trim();
                                                                table2.DR["Relation_Name"] = Program.getFieldValue("wb_relation", "relation_name", "relation_code", table6.DR["Relation_Code"].ToString().Trim());
                                                                table2.DR["Bruto"] = table3.DR["Gross"].ToString();
                                                                table2.DR["Tarra"] = table3.DR["Tare"].ToString();
                                                                table2.DR["Netto"] = table3.DR["Net"].ToString();
                                                                table2.DR["Estate_qty"] = table3.DR["Net_Estate"].ToString();
                                                                table2.DR["WeightPerUnitName"] = Program.StrToDouble(num4.ToString(), 2);
                                                                table2.DR["DeducUnitQty"] = num3;
                                                                table2.DR["TotalDeducUnit"] = Program.StrToDouble((Program.StrToDouble(num4.ToString(), 2) * num3).ToString(), 0);
                                                                table2.DR.EndEdit();
                                                            }
                                                        }
                                                        table.Close();
                                                    }
                                                }
                                                else
                                                {
                                                    table.OpenTable("wb_transTemp", "Select * from wb_transaction where " + WBData.CompanyLocation(" and ref = '" + str2 + "'"), WBData.conn);
                                                    if (table.DT.Rows.Count > 0)
                                                    {
                                                        table.DR = table.DT.Rows[0];
                                                        if (table.DR["split"].ToString() == "X")
                                                        {
                                                            strArray2[num10, 0] = table2.DR["uniq"].ToString();
                                                            strArray2[num10, 1] = "del";
                                                            table2.DR.Delete();
                                                            keyField = table.DR["uniq"].ToString();
                                                            table.DR.Delete();
                                                            table4.OpenTable("wb_transQCtemp", "Select * from wb_transQC where " + WBData.CompanyLocation(" and ref = '" + str2 + "'"), WBData.conn);
                                                            string[] strArray3 = new string[table4.DT.Rows.Count];
                                                            int num11 = 0;
                                                            while (true)
                                                            {
                                                                if (num11 >= table4.DT.Rows.Count)
                                                                {
                                                                    table4.Save();
                                                                    int num12 = 0;
                                                                    while (true)
                                                                    {
                                                                        if (num12 >= strArray3.Length)
                                                                        {
                                                                            table4.Close();
                                                                            table.Save();
                                                                            string[] textArray5 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                            string[] textArray6 = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                                            Program.updateLogHeader("wb_transaction", keyField, textArray5, textArray6);
                                                                            table.Close();
                                                                            break;
                                                                        }
                                                                        string[] textArray3 = new string[] { "PMode", "UserID", "ChangeReason" };
                                                                        string[] textArray4 = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                                                        Program.updateLogHeader("wb_transQC", strArray3[num12], textArray3, textArray4);
                                                                        num12++;
                                                                    }
                                                                    break;
                                                                }
                                                                strArray3[num11] = table4.DT.Rows[num11]["uniq"].ToString();
                                                                table4.DT.Rows[num11].Delete();
                                                                num11++;
                                                            }
                                                        }
                                                    }
                                                }
                                                num10++;
                                            }
                                            break;
                                        }
                                        table2.DR = table2.DT.Rows[num9];
                                        str2 = table2.DR["ref"].ToString().Trim();
                                        if (str2.Substring(str2.Length - 1, 1) != "T")
                                        {
                                            table2.DR["TotalDeducUnit"] = (table2.DR["TotalDeducUnit"] == null) ? 0 : table2.DR["TotalDeducUnit"];
                                            table2.DR["DeducUnitQty"] = (table2.DR["DeducUnitQty"] == null) ? 0 : table2.DR["DeducUnitQty"];
                                            num2 += Program.StrToDouble(table2.DR["TotalDeducUnit"].ToString(), 0);
                                            num3 += Program.StrToDouble(table2.DR["DeducUnitQty"].ToString(), 0);
                                            if (str2 == str)
                                            {
                                                num5 = Program.StrToDouble(table2.DR["TotalDeducUnit"].ToString(), 0);
                                                str3 = table2.DR["UnitName"].ToString();
                                            }
                                        }
                                        num9++;
                                    }
                                    break;
                                }
                                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                string[] logValue = new string[] { "MERGE", WBUser.UserID, "Merge transaction" };
                                Program.updateLogHeader("wb_transBatch", strArray[num8], logField, logValue);
                                num8++;
                            }
                            break;
                        }
                        table5.DR = table5.DT.Rows[index];
                        strArray[index] = table5.DR["uniq"].ToString();
                        table5.DR.BeginEdit();
                        table5.DR.Delete();
                        table5.DR.EndEdit();
                        index++;
                    }
                }
                table3.Dispose();
                table4.Dispose();
                table2.Dispose();
                table5.Dispose();
                table.Dispose();
                Cursor.Current = Cursors.WaitCursor;
                MessageBox.Show("Merge Completed", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                base.Close();
            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            this.dgv_split.Rows.Clear();
            string sqltext = "select a.*, b.report_date from wb_transSplit a\r\n                          inner join wb_transaction b\r\n                          on a.ref = b.ref\r\n                          where (b.Split = 'Y') and (b.deleted is null or b.Deleted <> 'Y') and (b.mark_accident is null or b.mark_accident <> 'X') and ";
            string[] textArray1 = new string[] { sqltext, " a.Coy = '", WBData.sCoyCode, "' and a.Location_Code = '", WBData.sLocCode, "' and a.Do_No = '", this.text_DO.Text.Trim().ToUpper(), "' " };
            sqltext = string.Concat(textArray1);
            if (this.rb_all.Checked)
            {
                sqltext = sqltext + "and b.report_date is not null";
            }
            else if (this.rb_date.Checked)
            {
                string[] textArray2 = new string[] { sqltext, " and b.report_date >= '", this.date_transFrom.Value.ToString("yyyy-MM-dd"), " 00:00:00' and b.report_date <= '", this.date_TransTo.Value.ToString("yyyy-MM-dd"), " 23:59:59'" };
                sqltext = string.Concat(textArray2);
            }
            sqltext = sqltext + " order by b.ref asc;";
            this.t_trans.OpenTable("wb_transaction", sqltext, WBData.conn);
            this.n_ref = this.t_trans.DT.Rows.Count;
            this.n_do = this.t_item.DT.Rows.Count;
            if (this.n_ref == 0)
            {
                MessageBox.Show("No Transaction found.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                int num = 0;
                while (true)
                {
                    if (num >= this.n_ref)
                    {
                        MessageBox.Show("Number of Ref found:" + this.n_ref.ToString() + ".\nPlease check Merge Simulation before proceeding.\nThank you.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        break;
                    }
                    this.dgv_split.Rows.Add();
                    this.dgv_split.Rows[num].Cells["REF"].Value = this.t_trans.DT.Rows[num]["Ref"].ToString();
                    this.dgv_split.Rows[num].Cells["GROSS"].Value = this.t_trans.DT.Rows[num]["Gross"].ToString();
                    this.dgv_split.Rows[num].Cells["TARE"].Value = this.t_trans.DT.Rows[num]["Tare"].ToString();
                    this.dgv_split.Rows[num].Cells["Net"].Value = this.t_trans.DT.Rows[num]["Net"].ToString();
                    this.dgv_split.Rows[num].Cells["DATE"].Value = string.IsNullOrEmpty(this.t_trans.DT.Rows[num]["report_date"].ToString()) ? "" : this.t_trans.DT.Rows[num]["report_date"].ToString().Substring(0, 10);
                    num++;
                }
            }
        }

        private void buttonDO_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                vessel = true,
                pFind = this.text_DO.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.text_DO.Text = contract.ReturnRow["Do_No"].ToString();
            }
            contract.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormMergeDoVessel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormMergeDoVessel_Load(object sender, EventArgs e)
        {
            this.gb_detail.Visible = false;
            this.gb_info.Visible = false;
            this.panel_info.Visible = false;
            this.gb_filter.Visible = false;
            string sqltext = "SELECT * FROM wb_contract WHERE " + WBData.CompanyLocation(" AND uniq IN (SELECT uniq_vessel FROM wb_vessel_map GROUP BY uniq_vessel) ORDER BY do_no");
            this.s_help.OpenTable("wb_contract", sqltext, WBData.conn);
            Program.AutoComp(this.s_help, "do_no", this.text_DO);
            this.date_transFrom.Value = DateTime.Now.Date.AddDays(-1.0);
            this.date_TransTo.Value = DateTime.Now.Date;
        }

        private void InitializeComponent()
        {
            this.gb_header = new GroupBox();
            this.buttonDO = new Button();
            this.label_do_complete = new Label();
            this.panel_info = new Panel();
            this.date_DO = new DateTimePicker();
            this.label2 = new Label();
            this.text_qty = new TextBox();
            this.label1 = new Label();
            this.btn_go = new Button();
            this.text_DO = new TextBox();
            this.gb_detail = new GroupBox();
            this.btn_cancel = new Button();
            this.btn_Merge = new Button();
            this.dgv_split = new DataGridView();
            this.gb_filter = new GroupBox();
            this.date_TransTo = new DateTimePicker();
            this.btn_search = new Button();
            this.rb_date = new RadioButton();
            this.rb_all = new RadioButton();
            this.date_transFrom = new DateTimePicker();
            this.gb_info = new GroupBox();
            this.label4 = new Label();
            this.text_remain = new TextBox();
            this.label3 = new Label();
            this.text_used = new TextBox();
            this.dgv_item = new DataGridView();
            this.gb_header.SuspendLayout();
            this.panel_info.SuspendLayout();
            this.gb_detail.SuspendLayout();
            ((ISupportInitialize) this.dgv_split).BeginInit();
            this.gb_filter.SuspendLayout();
            this.gb_info.SuspendLayout();
            ((ISupportInitialize) this.dgv_item).BeginInit();
            base.SuspendLayout();
            this.gb_header.Controls.Add(this.buttonDO);
            this.gb_header.Controls.Add(this.label_do_complete);
            this.gb_header.Controls.Add(this.panel_info);
            this.gb_header.Controls.Add(this.btn_go);
            this.gb_header.Controls.Add(this.text_DO);
            this.gb_header.Location = new Point(0, 0);
            this.gb_header.Name = "gb_header";
            this.gb_header.Size = new Size(0x116, 0x89);
            this.gb_header.TabIndex = 0;
            this.gb_header.TabStop = false;
            this.gb_header.Text = "DO Vessel";
            this.buttonDO.Location = new Point(0xf9, 0x11);
            this.buttonDO.Margin = new Padding(0);
            this.buttonDO.Name = "buttonDO";
            this.buttonDO.Size = new Size(0x17, 0x17);
            this.buttonDO.TabIndex = 12;
            this.buttonDO.Text = "...";
            this.buttonDO.UseVisualStyleBackColor = true;
            this.buttonDO.Click += new EventHandler(this.buttonDO_Click);
            this.label_do_complete.AutoSize = true;
            this.label_do_complete.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label_do_complete.ForeColor = Color.DarkGreen;
            this.label_do_complete.Location = new Point(70, 50);
            this.label_do_complete.Name = "label_do_complete";
            this.label_do_complete.Size = new Size(0x94, 13);
            this.label_do_complete.TabIndex = 11;
            this.label_do_complete.Text = "DO Status: COMPLETED";
            this.label_do_complete.Visible = false;
            this.panel_info.Controls.Add(this.date_DO);
            this.panel_info.Controls.Add(this.label2);
            this.panel_info.Controls.Add(this.text_qty);
            this.panel_info.Controls.Add(this.label1);
            this.panel_info.Location = new Point(6, 0x4a);
            this.panel_info.Name = "panel_info";
            this.panel_info.Size = new Size(0x10a, 0x35);
            this.panel_info.TabIndex = 9;
            this.date_DO.Enabled = false;
            this.date_DO.Format = DateTimePickerFormat.Short;
            this.date_DO.Location = new Point(0x4f, 3);
            this.date_DO.Name = "date_DO";
            this.date_DO.Size = new Size(0x57, 20);
            this.date_DO.TabIndex = 11;
            this.date_DO.Value = new DateTime(0x7df, 7, 20, 0, 0, 0, 0);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(11, 0x20);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x41, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "DO Quantity";
            this.text_qty.Location = new Point(0x4f, 0x1d);
            this.text_qty.Name = "text_qty";
            this.text_qty.ReadOnly = true;
            this.text_qty.Size = new Size(0x7c, 20);
            this.text_qty.TabIndex = 9;
            this.text_qty.TextAlign = HorizontalAlignment.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(11, 6);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x31, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "DO Date";
            this.btn_go.Location = new Point(6, 0x2d);
            this.btn_go.Name = "btn_go";
            this.btn_go.Size = new Size(0x3a, 0x17);
            this.btn_go.TabIndex = 2;
            this.btn_go.Text = "Go";
            this.btn_go.UseVisualStyleBackColor = true;
            this.btn_go.Click += new EventHandler(this.btn_go_Click);
            this.text_DO.Location = new Point(6, 0x13);
            this.text_DO.Name = "text_DO";
            this.text_DO.Size = new Size(0xee, 20);
            this.text_DO.TabIndex = 0;
            this.text_DO.KeyPress += new KeyPressEventHandler(this.text_DO_KeyPress);
            this.gb_detail.Controls.Add(this.btn_cancel);
            this.gb_detail.Controls.Add(this.btn_Merge);
            this.gb_detail.Controls.Add(this.dgv_split);
            this.gb_detail.Location = new Point(0, 0xf6);
            this.gb_detail.Name = "gb_detail";
            this.gb_detail.Size = new Size(0x306, 0x149);
            this.gb_detail.TabIndex = 1;
            this.gb_detail.TabStop = false;
            this.gb_detail.Text = "Merge Simulation";
            this.btn_cancel.Location = new Point(710, 0x129);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new Size(0x3a, 0x17);
            this.btn_cancel.TabIndex = 12;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new EventHandler(this.btn_cancel_Click);
            this.btn_Merge.Location = new Point(0x26e, 0x129);
            this.btn_Merge.Name = "btn_Merge";
            this.btn_Merge.Size = new Size(0x3a, 0x17);
            this.btn_Merge.TabIndex = 11;
            this.btn_Merge.Text = "Merge";
            this.btn_Merge.UseVisualStyleBackColor = true;
            this.btn_Merge.Click += new EventHandler(this.btn_Merge_Click);
            this.dgv_split.AllowUserToAddRows = false;
            this.dgv_split.AllowUserToDeleteRows = false;
            this.dgv_split.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_split.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_split.Location = new Point(6, 0x13);
            this.dgv_split.Name = "dgv_split";
            this.dgv_split.ReadOnly = true;
            this.dgv_split.Size = new Size(0x2fa, 0x110);
            this.dgv_split.TabIndex = 1;
            this.gb_filter.Controls.Add(this.date_TransTo);
            this.gb_filter.Controls.Add(this.btn_search);
            this.gb_filter.Controls.Add(this.rb_date);
            this.gb_filter.Controls.Add(this.rb_all);
            this.gb_filter.Controls.Add(this.date_transFrom);
            this.gb_filter.Location = new Point(0, 0x8f);
            this.gb_filter.Name = "gb_filter";
            this.gb_filter.Size = new Size(0x116, 0x61);
            this.gb_filter.TabIndex = 0;
            this.gb_filter.TabStop = false;
            this.gb_filter.Text = "Filter";
            this.date_TransTo.Format = DateTimePickerFormat.Short;
            this.date_TransTo.Location = new Point(0x76, 0x3d);
            this.date_TransTo.Name = "date_TransTo";
            this.date_TransTo.Size = new Size(0x57, 20);
            this.date_TransTo.TabIndex = 11;
            this.date_TransTo.Value = new DateTime(0x7df, 7, 20, 0, 0, 0, 0);
            this.btn_search.Location = new Point(0xd3, 0x3b);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new Size(0x3a, 0x17);
            this.btn_search.TabIndex = 10;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new EventHandler(this.btn_search_Click);
            this.rb_date.AutoSize = true;
            this.rb_date.Location = new Point(6, 0x27);
            this.rb_date.Name = "rb_date";
            this.rb_date.Size = new Size(120, 0x11);
            this.rb_date.TabIndex = 1;
            this.rb_date.TabStop = true;
            this.rb_date.Text = "By Date (From && To)";
            this.rb_date.UseVisualStyleBackColor = true;
            this.rb_all.AutoSize = true;
            this.rb_all.Checked = true;
            this.rb_all.Location = new Point(6, 0x10);
            this.rb_all.Name = "rb_all";
            this.rb_all.Size = new Size(0x24, 0x11);
            this.rb_all.TabIndex = 0;
            this.rb_all.TabStop = true;
            this.rb_all.Text = "All";
            this.rb_all.UseVisualStyleBackColor = true;
            this.date_transFrom.Format = DateTimePickerFormat.Short;
            this.date_transFrom.Location = new Point(0x19, 0x3d);
            this.date_transFrom.Name = "date_transFrom";
            this.date_transFrom.Size = new Size(0x57, 20);
            this.date_transFrom.TabIndex = 8;
            this.date_transFrom.Value = new DateTime(0x7df, 7, 20, 0, 0, 0, 0);
            this.gb_info.Controls.Add(this.label4);
            this.gb_info.Controls.Add(this.text_remain);
            this.gb_info.Controls.Add(this.label3);
            this.gb_info.Controls.Add(this.text_used);
            this.gb_info.Controls.Add(this.dgv_item);
            this.gb_info.Location = new Point(0x11e, 0);
            this.gb_info.Name = "gb_info";
            this.gb_info.Size = new Size(0x1e8, 240);
            this.gb_info.TabIndex = 2;
            this.gb_info.TabStop = false;
            this.gb_info.Text = "Vessel Information";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0xd7, 0xce);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x54, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Total Remaining";
            this.text_remain.Location = new Point(0x131, 0xcb);
            this.text_remain.Name = "text_remain";
            this.text_remain.ReadOnly = true;
            this.text_remain.Size = new Size(0x7c, 20);
            this.text_remain.TabIndex = 13;
            this.text_remain.TextAlign = HorizontalAlignment.Right;
            this.label3.AutoSize = true;
            this.label3.Location = new Point(8, 0xcf);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x3b, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Total Used";
            this.text_used.Location = new Point(0x4c, 0xcc);
            this.text_used.Name = "text_used";
            this.text_used.ReadOnly = true;
            this.text_used.Size = new Size(0x7c, 20);
            this.text_used.TabIndex = 11;
            this.text_used.TextAlign = HorizontalAlignment.Right;
            this.dgv_item.AllowUserToAddRows = false;
            this.dgv_item.AllowUserToDeleteRows = false;
            this.dgv_item.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_item.Location = new Point(6, 0x13);
            this.dgv_item.Name = "dgv_item";
            this.dgv_item.ReadOnly = true;
            this.dgv_item.Size = new Size(0x1dc, 0xb0);
            this.dgv_item.TabIndex = 0;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x307, 0x241);
            base.Controls.Add(this.gb_info);
            base.Controls.Add(this.gb_detail);
            base.Controls.Add(this.gb_header);
            base.Controls.Add(this.gb_filter);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormMergeDoVessel";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Merge DO Vessel";
            base.Load += new EventHandler(this.FormMergeDoVessel_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormMergeDoVessel_KeyPress);
            this.gb_header.ResumeLayout(false);
            this.gb_header.PerformLayout();
            this.panel_info.ResumeLayout(false);
            this.panel_info.PerformLayout();
            this.gb_detail.ResumeLayout(false);
            ((ISupportInitialize) this.dgv_split).EndInit();
            this.gb_filter.ResumeLayout(false);
            this.gb_filter.PerformLayout();
            this.gb_info.ResumeLayout(false);
            this.gb_info.PerformLayout();
            ((ISupportInitialize) this.dgv_item).EndInit();
            base.ResumeLayout(false);
        }

        private void text_DO_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.btn_go.PerformClick();
            }
            else
            {
                e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
            }
        }
    }
}

