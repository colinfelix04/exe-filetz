﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Net;
    using System.Net.Mail;
    using System.Reflection;
    using System.Windows.Forms;

    public class WBMail : Component
    {
        public string To = "";
        public string CC = "";
        public string Subject = "";
        public string Body = "";
        private Attachment attachment;
        public bool haveAttachment = false;

        public bool Load_SendMail_SPB(string em_body, string pMode)
        {
            WBSetting.OpenSetting();
            string str = "";
            if (pMode == "EDIT")
            {
                str = "EDIT_SPB";
            }
            else if ((pMode == "DELETE") || (pMode == "UNDELETE"))
            {
                str = "DELETE_SPB";
            }
            WBTable table = new WBTable();
            table.OpenTable("wb_email_master", "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND ( Email_Code ='" + str + "')"), WBData.conn);
            int num = 0;
            while (true)
            {
                if (num >= table.DT.Rows.Count)
                {
                    this.Body = em_body;
                    return this.SendMail_SPB();
                }
                DataRow row = table.DT.Rows[num];
                this.Subject = row[0].ToString().Trim();
                this.To = row[1].ToString().Trim();
                this.CC = row[2].ToString().Trim();
                num++;
            }
        }

        public void mailAttachment(string zPath)
        {
            try
            {
                this.attachment = new Attachment(zPath);
                this.haveAttachment = true;
            }
            catch
            {
                this.haveAttachment = false;
            }
        }

        public bool SendMail()
        {
            bool flag = false;
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                MailMessage message = new MailMessage {
                    Priority = MailPriority.High,
                    IsBodyHtml = true
                };
                if ((WBSetting.Field("Sender_Name") != null) && (WBSetting.Field("Sender_Name") != ""))
                {
                    message.From = new MailAddress(WBSetting.Field("Sender_Name"));
                    if (this.haveAttachment)
                    {
                        message.Attachments.Add(this.attachment);
                    }
                    if (this.To.Trim() != "")
                    {
                        message.To.Add(this.To);
                    }
                    if (this.CC.Trim() != "")
                    {
                        message.CC.Add(this.CC);
                    }
                    if ((this.To.Trim() != "") || (this.CC.Trim() != ""))
                    {
                        message.Subject = this.Subject;
                        string[] textArray1 = new string[] { this.Body, "<br><br><br>THIS EMAIL IS GENERATED AUTOMATICALLY BY WB SYSTEM VERSION ", Assembly.GetExecutingAssembly().GetName().Version.ToString(), "<br><br>Sent from ", WBUser.ComName, " with IP ", WBUser.localIP, "." };
                        this.Body = string.Concat(textArray1);
                        message.Body = this.Body;
                        new SmtpClient(WBSetting.Field("SMTP_Server")) { 
                            Port = !ReferenceEquals(WBSetting.Field("Port"), null) ? Convert.ToInt32(WBSetting.Field("Port")) : 0x19,
                            EnableSsl = (WBSetting.Field("SSL").ToString() != "Y") ? false : true,
                            Credentials = (WBSetting.Field("Domain").Trim().Length <= 0) ? new NetworkCredential(WBSetting.Field("Sender_Name"), Program.shoot(WBSetting.Field("Sender_Pass"), false)) : new NetworkCredential(WBSetting.Field("Sender_Name"), Program.shoot(WBSetting.Field("Sender_Pass"), false), WBSetting.Field("Domain"))
                        }.Send(message);
                        flag = true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("Warning email cannot be sent.\nPlease maintain Sender Email.\nThank you.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return false;
                }
            }
            catch (Exception exception1)
            {
                MessageBox.Show(exception1.ToString(), Resource.Mes_564, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                flag = false;
            }
            Cursor.Current = Cursors.Default;
            return flag;
        }

        public bool SendMail_Cancel(string em_body)
        {
            WBSetting.OpenSetting();
            WBTable table = new WBTable();
            table.OpenTable("wb_email_master", "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND ( Email_Code ='CANCEL_WARNING')"), WBData.conn);
            int num = 0;
            while (true)
            {
                if (num >= table.DT.Rows.Count)
                {
                    this.Body = em_body;
                    return this.SendMail();
                }
                DataRow row = table.DT.Rows[num];
                string[] textArray1 = new string[] { row[0].ToString().Trim(), " ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
                this.Subject = string.Concat(textArray1);
                this.To = row[1].ToString().Trim();
                this.CC = row[2].ToString().Trim();
                num++;
            }
        }

        public bool SendMail_Edit(string em_body)
        {
            WBSetting.OpenSetting();
            WBTable table = new WBTable();
            table.OpenTable("wb_email_master", "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND ( Email_Code ='EDIT_WARNING')"), WBData.conn);
            int num = 0;
            while (true)
            {
                if (num >= table.DT.Rows.Count)
                {
                    this.Body = em_body;
                    return this.SendMail();
                }
                DataRow row = table.DT.Rows[num];
                string[] textArray1 = new string[] { row[0].ToString().Trim(), " ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
                this.Subject = string.Concat(textArray1);
                this.To = row[1].ToString().Trim();
                this.CC = row[2].ToString().Trim();
                num++;
            }
        }

        public bool SendMail_SPB()
        {
            bool flag = false;
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                MailMessage message = new MailMessage {
                    Priority = MailPriority.High,
                    IsBodyHtml = true
                };
                if ((WBSetting.Field("Sender_Name") != null) && (WBSetting.Field("Sender_Name") != ""))
                {
                    message.From = new MailAddress(WBSetting.Field("Sender_Name"));
                    if (this.haveAttachment)
                    {
                        message.Attachments.Add(this.attachment);
                    }
                    if (this.To.Trim() != "")
                    {
                        message.To.Add(this.To);
                    }
                    if (this.CC.Trim() != "")
                    {
                        message.CC.Add(this.CC);
                    }
                    message.Subject = this.Subject;
                    string[] textArray1 = new string[] { this.Body, "<br><br><br>THIS EMAIL IS GENERATED AUTOMATICALLY BY WB SYSTEM VERSION ", Assembly.GetExecutingAssembly().GetName().Version.ToString(), "<br><br>Sent from ", WBUser.ComName, " with IP ", WBUser.localIP, "." };
                    this.Body = string.Concat(textArray1);
                    message.Body = this.Body;
                    new SmtpClient(WBSetting.Field("SMTP_Server")) { 
                        Port = !ReferenceEquals(WBSetting.Field("Port"), null) ? Convert.ToInt32(WBSetting.Field("Port")) : 0x19,
                        EnableSsl = (WBSetting.Field("SSL").ToString() != "Y") ? false : true,
                        Credentials = (WBSetting.Field("Domain").Trim().Length <= 0) ? new NetworkCredential(WBSetting.Field("Sender_Name"), Program.shoot(WBSetting.Field("Sender_Pass"), false)) : new NetworkCredential(WBSetting.Field("Sender_Name"), Program.shoot(WBSetting.Field("Sender_Pass"), false), WBSetting.Field("Domain"))
                    }.Send(message);
                    flag = true;
                }
                else
                {
                    MessageBox.Show("Warning email cannot be sent.\nPlease maintain Sender Email.\nThank you.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return false;
                }
            }
            catch (Exception exception1)
            {
                MessageBox.Show(exception1.ToString(), Resource.Mes_564, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                flag = false;
            }
            Cursor.Current = Cursors.Default;
            return flag;
        }

        public bool SendMail_Tanker(string em_body)
        {
            WBSetting.OpenSetting();
            this.To = WBSetting.Field("Recipient_Email");
            this.CC = WBSetting.Field("CC_Email");
            this.Subject = WBSetting.Field("Subject_Email");
            this.Body = em_body;
            return this.SendMail();
        }
    }
}

