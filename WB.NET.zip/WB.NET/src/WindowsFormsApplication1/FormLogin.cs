﻿namespace WindowsFormsApplication1
{
    using Microsoft.Win32;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Diagnostics;
    using System.DirectoryServices;
    using System.DirectoryServices.AccountManagement;
    using System.Drawing;
    using System.IO;
    using System.Net;
    using System.Net.Sockets;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Properties;
    using WindowsFormsApplication1.Utility;

    public class FormLogin : Form
    {
        public bool berhasil = false;
        public bool chksum_error = false;
        public WBTable tbl = new WBTable();
        public WBTable tblCoy = new WBTable();
        public WBTable tblLoc = new WBTable();
        public WBTable tblLog = new WBTable();
        public string logKey = "";
        public string prodVersion = "";
        public string ADCoy = "";
        public string ADLocation_Code = "";
        public string exPrincipal = "";
        private Form form = new Form();
        public string path = "";
        public string strAccountId = "";
        public string strPassword = "";
        public string strAuthenticatedBy = "";
        public string strError = "";
        public string ldapPath = "";
        public string userGroup = "";
        public string userID = "";
        public string userName = "";
        public string password = "";
        public string loginadex = "";
        public bool changeProfile = false;
        private IContainer components = null;
        private Label label1;
        private Label label2;
        private TextBox textBox1;
        private TextBox textBox2;
        private Button button1;
        private Button button2;
        private TextBox textLoc;
        private TextBox textCoy;
        private Label label3;
        private Label label4;
        private Button button13;
        private Button button3;
        private Label labelCompanyName;
        private Label labelLocName;
        private Panel panelChangeServer;
        private Label labelChangeServer;
        private Label labelServer;
        private LinkLabel lLinkAD;
        private GroupBox groupBoxLogin;
        private Label labelTitle;
        private GroupBox groupBoxCompany;
        private GroupBox groupBoxInfo;
        private LinkLabel lLinkSupport;
        private Label lblADInfo;

        public FormLogin()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string machineName;
            string str2;
            TextBox[] aText = new TextBox[] { this.textLoc, this.textCoy, this.textBox1, this.textBox2 };
            if (!Program.CheckEmpty(aText))
            {
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                table.OpenTable("wb_location", "Select count(*) as jlh From wb_location where 1=1", WBData.conn);
                table2.OpenTable("wb_ref", "Select count(*) as jlh From wb_ref where Ref_Code = 'NO_TICKET_REF'", WBData.conn);
                if (table2.DT.Rows.Count <= 0)
                {
                    MessageBox.Show("No Ref has not been maintained. Please contact Administrator.", Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }
                else if (table2.DT.Rows[0]["jlh"].ToString() == table.DT.Rows[0]["jlh"].ToString())
                {
                    if (!WBSetting.loginWithActiveDirectory)
                    {
                        string[] textArray1 = new string[] { "Select * from wb_user where (Coy='", this.textCoy.Text, "') and (Location_Code='", this.textLoc.Text, "') and user_id = '", this.textBox1.Text.Trim(), "'" };
                        this.tbl.OpenTable("wb_user", string.Concat(textArray1), WBData.conn);
                        if (this.tbl.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show(Resource.Mes_004, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.textBox1.Focus();
                            return;
                        }
                        else
                        {
                            machineName = Environment.MachineName;
                            str2 = "";
                            IPAddress[] addressList = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
                            int index = 0;
                            while (true)
                            {
                                if (index < addressList.Length)
                                {
                                    IPAddress address = addressList[index];
                                    AddressFamily addressFamily = address.AddressFamily;
                                    if (addressFamily.ToString() == "InterNetwork")
                                    {
                                        str2 = address.ToString();
                                    }
                                    index++;
                                    continue;
                                }
                                if (this.tbl.DT.Rows.Count > 1)
                                {
                                    using (IEnumerator enumerator = this.tbl.DT.Rows.GetEnumerator())
                                    {
                                        while (true)
                                        {
                                            if (!enumerator.MoveNext())
                                            {
                                                break;
                                            }
                                            DataRow current = (DataRow) enumerator.Current;
                                            if ((current["Deleted"].ToString().Trim() == "*") || (current["Deleted"].ToString().Trim() == "Y"))
                                            {
                                                object[] objArray1 = new object[] { Resource.Mes_004a, " ", Environment.NewLine, "Inactive Date: ", current["delete_date"], " ", Environment.NewLine };
                                                object[] objArray2 = new object[] { string.Concat(objArray1), Resource.User_011, ": Deactivated by ", current["delete_by"], " (", current["ChangeReason"].ToString(), ")" };
                                                MessageBox.Show(string.Concat(objArray2), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                this.textBox1.Focus();
                                                return;
                                            }
                                        }
                                    }
                                }
                                break;
                            }
                        }
                    }
                    else
                    {
                        Cursor.Current = Cursors.WaitCursor;
                        if (WBSetting.ADPath.ToString() != "")
                        {
                            char[] separator = new char[] { '|' };
                            string[] lDAP = WBSetting.ADPath.Split(separator);
                            if (lDAP.Length != 0)
                            {
                                WBSetting.ADPath = lDAP[0];
                                this.userID = this.textBox1.Text;
                                this.password = this.textBox2.Text;
                                this.chksum_error = true;
                                if (this.checkUserAtActiveDirectory(lDAP))
                                {
                                    if (!this.loginwithADwillocal())
                                    {
                                        if (lDAP.Length >= 2)
                                        {
                                            if (lDAP[1] != "")
                                            {
                                                WBSetting.ADPath = lDAP[1];
                                                this.showMB(Resource.LoginADChangeConnection + WBSetting.ADPath);
                                                if (!this.loginwithADwillocal() && (lDAP.Length >= 3))
                                                {
                                                    if (lDAP[2] != "")
                                                    {
                                                        WBSetting.ADPath = lDAP[2];
                                                        this.showMB(Resource.LoginADChangeConnection + WBSetting.ADPath);
                                                    }
                                                    else
                                                    {
                                                        MessageBox.Show(Resource.ADPATHERR02, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                        return;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show(Resource.ADPATHERR02, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                                return;
                                            }
                                        }
                                        if (!this.loginwithADwillocal())
                                        {
                                            MessageBox.Show(this.loginadex.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        }
                                    }
                                }
                                else if (this.exPrincipal != "")
                                {
                                    MessageBox.Show("Principal Error: " + this.exPrincipal, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                else
                                {
                                    MessageBox.Show(Resource.loginAD_001, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.ADPATH_ERR01, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.ADPATH_ERR01, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        }
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("No Ref not yet maintained for certain company. Please contact Administrator.", Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }
            }
            else
            {
                return;
            }
            this.tbl.DR = this.tbl.DT.Rows[0];
            if ((this.tbl.DR["Deleted"].ToString().Trim() == "*") || (this.tbl.DR["Deleted"].ToString().Trim() == "Y"))
            {
                object[] objArray3 = new object[] { Resource.Mes_004a, " ", Environment.NewLine, "Inactive Date: ", this.tbl.DR["delete_date"], " ", Environment.NewLine };
                object[] objArray4 = new object[] { string.Concat(objArray3), Resource.User_011, ": Deactivated by ", this.tbl.DR["delete_by"], " (", this.tbl.DR["ChangeReason"].ToString(), ")" };
                MessageBox.Show(string.Concat(objArray4), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textBox1.Focus();
            }
            else if (!this.tbl.ValidChecksum(this.tbl.DR))
            {
                MessageBox.Show(Resource.Mes_002, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textBox1.Focus();
            }
            else if (Program.shoot(this.tbl.DR["User_Pass"].ToString(), false) != this.textBox2.Text)
            {
                WBTable table3 = new WBTable();
                table3.OpenTable("wb_user", "SELECT * FROM wb_user WHERE " + WBData.CompanyLocation(" AND user_id = '" + this.textBox1.Text.Trim() + "'"), WBData.conn);
                if (table3.DT.Rows.Count > 0)
                {
                    table3.DR = table3.DT.Rows[0];
                    this.logKey = table3.DR["uniq"].ToString();
                    table3.DR.BeginEdit();
                    table3.DR["lastLogin"] = DateTime.Now;
                    table3.DR["lastLoginResult"] = DateTime.Now.ToString("HH:mm:ss") + "F";
                    table3.DR["lastLoginIP"] = DateTime.Now.ToString("HH:mm:ss") + str2;
                    table3.DR["lastLoginCompName"] = DateTime.Now.ToString("HH:mm:ss") + machineName;
                    table3.DR["lastLoginFailedReason"] = DateTime.Now.ToString("HH:mm:ss") + "Wrong password";
                    table3.DR["checksum"] = table3.Checksum(table3.DR);
                    table3.DR.EndEdit();
                    table3.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "LOGSYS", this.textBox1.Text.Trim(), "Login to system" };
                    Program.updateLogHeader("wb_user", this.logKey, logField, logValue);
                }
                table3.Dispose();
                MessageBox.Show(Resource.Mes_005, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textBox2.Text = "";
                this.textBox2.Focus();
            }
            else
            {
                this.tblLoc.OpenTable("wb_location", "Select * From wb_location", WBData.conn);
                string[] aField = new string[] { "Coy", "Location_Code" };
                string[] aFind = new string[] { this.textCoy.Text, this.textLoc.Text };
                DataRow data = this.tblLoc.GetData(aField, aFind);
                if (data["LocationChecksumControl"].ToString() != "Y")
                {
                    this.berhasil = true;
                    base.Close();
                }
                else if (this.tblLoc.ValidChecksum(data))
                {
                    this.berhasil = true;
                    base.Close();
                }
                else if (this.textBox1.Text.Trim().ToUpper() != "ADMIN")
                {
                    MessageBox.Show("Location Checksum Error. Please contact Admin ! ", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    MessageBox.Show("Location Checksum Error. Please contact Admin ! ", "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.chksum_error = true;
                    this.berhasil = true;
                    base.Close();
                }
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            FormCompany company = new FormCompany {
                pMode = "CHOOSE"
            };
            company.ShowDialog();
            if (company.ReturnRow != null)
            {
                this.textCoy.Text = company.ReturnRow["Coy_Code"].ToString().Trim();
                this.labelCompanyName.Text = company.ReturnRow["Coy_Name"].ToString().Trim();
            }
            company.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Resource.Mes_184, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.berhasil = false;
                base.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.textCoy.Text.Trim() == "")
            {
                MessageBox.Show(Resource.Mes_185, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.textCoy.Focus();
            }
            else
            {
                FormLocation location = new FormLocation {
                    pMode = "CHOOSE",
                    pCoy = this.textCoy.Text.Trim()
                };
                location.ShowDialog();
                if (location.ReturnRow != null)
                {
                    this.textLoc.Text = location.ReturnRow["Location_Code"].ToString().Trim();
                    this.labelLocName.Text = location.ReturnRow["Location_Name"].ToString().Trim();
                }
                location.Dispose();
            }
        }

        private bool checkUserAtActiveDirectory(string[] LDAP)
        {
            string str;
            int num;
            bool flag = false;
            this.exPrincipal = "";
            if (WBSetting.ADPrincipal != "")
            {
                str = Program.shoot(WBSetting.ADPrincipal, false);
                num = 0;
            }
            else
            {
                this.exPrincipal = "Principal not maintained yet. Please contact MIS HO.";
                return flag;
            }
            goto TR_0014;
        TR_0002:
            num++;
        TR_0014:
            while (true)
            {
                if (num >= LDAP.Length)
                {
                    break;
                }
                if (LDAP[num] != "")
                {
                    try
                    {
                        char[] separator = new char[] { '/' };
                        char[] chArray2 = new char[] { '|' };
                        char[] chArray3 = new char[] { '|' };
                        using (PrincipalContext context = new PrincipalContext(ContextType.Domain, LDAP[num].Split(separator)[2], str.Split(chArray2)[0], str.Split(chArray3)[1]))
                        {
                            using (UserPrincipal principal = UserPrincipal.FindByIdentity(context, this.userID))
                            {
                                flag = principal != null;
                            }
                        }
                    }
                    catch (Exception exception)
                    {
                        this.exPrincipal = exception.ToString();
                        goto TR_0002;
                    }
                    break;
                }
                goto TR_0002;
            }
            return flag;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
            this.tblCoy.OpenTable("wb_company", "Select * From wb_company", WBData.conn);
            this.tblLoc.OpenTable("wb_location", "Select * From wb_location", WBData.conn);
            this.berhasil = false;
            WBConfigurationHandler.createDirectory();
            if (File.Exists(WBConfigurationHandler.configurationFile))
            {
                Dictionary<string, string> dictionary = WBConfigurationHandler.readFromTxt(WBConfigurationHandler.configurationFile);
                this.textCoy.Text = dictionary.ContainsKey("COY") ? dictionary["COY"] : "";
                this.textLoc.Text = dictionary.ContainsKey("LOC") ? dictionary["LOC"] : "";
                dictionary.Clear();
            }
            else
            {
                RegistryKey key2 = Registry.LocalMachine.OpenSubKey("SOFTWARE", true);
                RegistryKey key3 = key2.OpenSubKey("WCS DATABASE");
                RegistryKey key4 = key2.CreateSubKey("WCS DATABASE").CreateSubKey("WB System");
                this.textCoy.Text = (string) key4.GetValue("Coy_Code");
                this.textLoc.Text = (string) key4.GetValue("Loc_Code");
                WBConfigurationHandler.createTxtFile(WBConfigurationHandler.configurationFile);
                Dictionary<string, string> dictToTxt = new Dictionary<string, string> {
                    { 
                        "COY",
                        this.textCoy.Text.Trim()
                    },
                    { 
                        "LOC",
                        this.textLoc.Text.Trim()
                    }
                };
                WBConfigurationHandler.writeToTxt(WBConfigurationHandler.configurationFile, dictToTxt);
                dictToTxt.Clear();
            }
            string[] aField = new string[] { "Coy_Code" };
            string[] aFind = new string[] { this.textCoy.Text };
            DataRow data = this.tblCoy.GetData(aField, aFind);
            this.labelCompanyName.Text = (data != null) ? data["Coy_Name"].ToString() : "";
            string[] textArray3 = new string[] { "Coy", "Location_Code" };
            string[] textArray4 = new string[] { this.textCoy.Text, this.textLoc.Text };
            data = this.tblLoc.GetData(textArray3, textArray4);
            this.labelLocName.Text = (data != null) ? data["Location_Name"].ToString() : "";
            this.labelServer.Text = WBData.sServer + @"\" + WBData.sDatabase.ToUpper();
            this.prodVersion = base.ProductVersion.ToString();
            this.labelChangeServer.Visible = !new Crypthography().checkFile() ? new FileInfo(Application.StartupPath + @"\server.txt").Exists : true;
            string[] textArray5 = new string[] { "Select * from wb_user where (Coy='", this.textCoy.Text, "') and (Location_Code='", this.textLoc.Text, "')" };
            this.tbl.OpenTable("wb_user", string.Concat(textArray5), WBData.conn);
            WBTable table = new WBTable();
            string[] textArray6 = new string[] { "Select * from wb_setting where (Coy='", this.textCoy.Text, "') and (Location_Code='", this.textLoc.Text, "') and wbCode = '", WBData.sWBCode, "'" };
            table.OpenTable("wb_setting", string.Concat(textArray6), WBData.conn);
            foreach (DataRow row2 in table.DT.Rows)
            {
                if (row2["AutoRun"].ToString() == "Y")
                {
                    FormDelay delay = new FormDelay();
                    delay.ShowDialog();
                    if (delay.post)
                    {
                        this.textBox1.Text = "SCH";
                        this.textBox2.Text = "SCH!23456";
                        this.button1_Click(null, EventArgs.Empty);
                    }
                    delay.Dispose();
                }
            }
            WBSetting.GetConditionAD();
            this.translate();
            if (WBSetting.loginWithActiveDirectory)
            {
                this.lLinkAD.Visible = true;
                this.lblADInfo.Visible = true;
            }
        }

        private void hideMB()
        {
            this.form.Close();
            this.form.Dispose();
        }

        private void InitializeComponent()
        {
            ComponentResourceManager manager = new ComponentResourceManager(typeof(FormLogin));
            this.label1 = new Label();
            this.label2 = new Label();
            this.textBox1 = new TextBox();
            this.textBox2 = new TextBox();
            this.button1 = new Button();
            this.button2 = new Button();
            this.textLoc = new TextBox();
            this.textCoy = new TextBox();
            this.label3 = new Label();
            this.label4 = new Label();
            this.button13 = new Button();
            this.button3 = new Button();
            this.labelCompanyName = new Label();
            this.labelLocName = new Label();
            this.panelChangeServer = new Panel();
            this.labelChangeServer = new Label();
            this.labelServer = new Label();
            this.lLinkAD = new LinkLabel();
            this.groupBoxLogin = new GroupBox();
            this.lblADInfo = new Label();
            this.labelTitle = new Label();
            this.groupBoxCompany = new GroupBox();
            this.groupBoxInfo = new GroupBox();
            this.lLinkSupport = new LinkLabel();
            this.panelChangeServer.SuspendLayout();
            this.groupBoxLogin.SuspendLayout();
            this.groupBoxCompany.SuspendLayout();
            this.groupBoxInfo.SuspendLayout();
            base.SuspendLayout();
            this.label1.Location = new Point(0x73, 0x2d);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x68, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "User ID";
            this.label1.TextAlign = ContentAlignment.TopRight;
            this.label2.Location = new Point(0x6f, 0x4a);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x6b, 0x11);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password";
            this.label2.TextAlign = ContentAlignment.TopRight;
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(0xdf, 0x2a);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0x8f, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.KeyPress += new KeyPressEventHandler(this.textBox1_KeyPress);
            this.textBox2.Location = new Point(0xdf, 0x47);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x8f, 20);
            this.textBox2.TabIndex = 3;
            this.textBox2.UseSystemPasswordChar = true;
            this.textBox2.KeyPress += new KeyPressEventHandler(this.textBox2_KeyPress);
            this.button1.Location = new Point(0xb2, 0x76);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 4;
            this.button1.Text = "Login";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0x121, 0x76);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 5;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.textLoc.Location = new Point(0x66, 0x2f);
            this.textLoc.Name = "textLoc";
            this.textLoc.ReadOnly = true;
            this.textLoc.Size = new Size(60, 20);
            this.textLoc.TabIndex = 9;
            this.textCoy.CharacterCasing = CharacterCasing.Upper;
            this.textCoy.Location = new Point(0x66, 0x12);
            this.textCoy.Name = "textCoy";
            this.textCoy.ReadOnly = true;
            this.textCoy.Size = new Size(60, 20);
            this.textCoy.TabIndex = 8;
            this.label3.Location = new Point(0x10, 50);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x52, 0x12);
            this.label3.TabIndex = 7;
            this.label3.Text = "Location";
            this.label3.TextAlign = ContentAlignment.TopRight;
            this.label4.Location = new Point(20, 0x15);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x4f, 0x12);
            this.label4.TabIndex = 6;
            this.label4.Text = "Company";
            this.label4.TextAlign = ContentAlignment.TopRight;
            this.button13.Location = new Point(0xa5, 0x10);
            this.button13.Margin = new Padding(0);
            this.button13.Name = "button13";
            this.button13.Size = new Size(0x17, 0x17);
            this.button13.TabIndex = 11;
            this.button13.Text = "...";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new EventHandler(this.button13_Click);
            this.button3.Location = new Point(0xa5, 0x2e);
            this.button3.Margin = new Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new Size(0x17, 0x17);
            this.button3.TabIndex = 12;
            this.button3.Text = "...";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            this.labelCompanyName.AutoSize = true;
            this.labelCompanyName.Location = new Point(0xbf, 0x15);
            this.labelCompanyName.Name = "labelCompanyName";
            this.labelCompanyName.Size = new Size(0x52, 13);
            this.labelCompanyName.TabIndex = 13;
            this.labelCompanyName.Text = "Company Name";
            this.labelLocName.AutoSize = true;
            this.labelLocName.Location = new Point(0xbf, 50);
            this.labelLocName.Name = "labelLocName";
            this.labelLocName.Size = new Size(0x4f, 13);
            this.labelLocName.TabIndex = 14;
            this.labelLocName.Text = "Location Name";
            this.panelChangeServer.BackColor = SystemColors.ControlLight;
            this.panelChangeServer.Controls.Add(this.labelChangeServer);
            this.panelChangeServer.Controls.Add(this.labelServer);
            this.panelChangeServer.Dock = DockStyle.Bottom;
            this.panelChangeServer.Location = new Point(0, 0x161);
            this.panelChangeServer.Name = "panelChangeServer";
            this.panelChangeServer.Size = new Size(530, 0x12);
            this.panelChangeServer.TabIndex = 15;
            this.labelChangeServer.AutoSize = true;
            this.labelChangeServer.Dock = DockStyle.Right;
            this.labelChangeServer.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Underline | FontStyle.Italic, GraphicsUnit.Point, 0);
            this.labelChangeServer.Location = new Point(0x1c4, 0);
            this.labelChangeServer.Name = "labelChangeServer";
            this.labelChangeServer.Size = new Size(0x4e, 13);
            this.labelChangeServer.TabIndex = 0x11;
            this.labelChangeServer.Text = "Change Server";
            this.labelChangeServer.Visible = false;
            this.labelChangeServer.Click += new EventHandler(this.labelChangeServer_Click);
            this.labelServer.AutoSize = true;
            this.labelServer.Dock = DockStyle.Left;
            this.labelServer.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
            this.labelServer.Location = new Point(0, 0);
            this.labelServer.Name = "labelServer";
            this.labelServer.Size = new Size(0x2f, 13);
            this.labelServer.TabIndex = 0x10;
            this.labelServer.Text = "Server : ";
            this.lLinkAD.Location = new Point(0x47, 0x62);
            this.lLinkAD.Name = "lLinkAD";
            this.lLinkAD.Size = new Size(0x12e, 13);
            this.lLinkAD.TabIndex = 0x10;
            this.lLinkAD.TabStop = true;
            this.lLinkAD.Text = "Click here to change password";
            this.lLinkAD.TextAlign = ContentAlignment.MiddleRight;
            this.lLinkAD.Visible = false;
            this.lLinkAD.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lLinkAD_LinkClicked);
            this.groupBoxLogin.Controls.Add(this.lblADInfo);
            this.groupBoxLogin.Controls.Add(this.label1);
            this.groupBoxLogin.Controls.Add(this.lLinkAD);
            this.groupBoxLogin.Controls.Add(this.label2);
            this.groupBoxLogin.Controls.Add(this.textBox1);
            this.groupBoxLogin.Controls.Add(this.textBox2);
            this.groupBoxLogin.Controls.Add(this.button1);
            this.groupBoxLogin.Controls.Add(this.button2);
            this.groupBoxLogin.Location = new Point(0, 0x7f);
            this.groupBoxLogin.Margin = new Padding(2);
            this.groupBoxLogin.Name = "groupBoxLogin";
            this.groupBoxLogin.Padding = new Padding(2);
            this.groupBoxLogin.Size = new Size(530, 0xa5);
            this.groupBoxLogin.TabIndex = 0x11;
            this.groupBoxLogin.TabStop = false;
            this.lblADInfo.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.lblADInfo.Location = new Point(0, 10);
            this.lblADInfo.Name = "lblADInfo";
            this.lblADInfo.Size = new Size(530, 0x1b);
            this.lblADInfo.TabIndex = 0x11;
            this.lblADInfo.Text = "Login with Active Directory";
            this.lblADInfo.TextAlign = ContentAlignment.MiddleCenter;
            this.lblADInfo.Visible = false;
            this.labelTitle.Dock = DockStyle.Top;
            this.labelTitle.Font = new Font("Microsoft Sans Serif", 25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelTitle.Location = new Point(0, 0);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new Size(530, 0x2e);
            this.labelTitle.TabIndex = 0x12;
            this.labelTitle.Text = "WB.Net";
            this.labelTitle.TextAlign = ContentAlignment.MiddleCenter;
            this.groupBoxCompany.Controls.Add(this.textLoc);
            this.groupBoxCompany.Controls.Add(this.label4);
            this.groupBoxCompany.Controls.Add(this.label3);
            this.groupBoxCompany.Controls.Add(this.textCoy);
            this.groupBoxCompany.Controls.Add(this.labelLocName);
            this.groupBoxCompany.Controls.Add(this.button13);
            this.groupBoxCompany.Controls.Add(this.labelCompanyName);
            this.groupBoxCompany.Controls.Add(this.button3);
            this.groupBoxCompany.Dock = DockStyle.Top;
            this.groupBoxCompany.Location = new Point(0, 0x2e);
            this.groupBoxCompany.Margin = new Padding(2);
            this.groupBoxCompany.Name = "groupBoxCompany";
            this.groupBoxCompany.Padding = new Padding(2);
            this.groupBoxCompany.Size = new Size(530, 0x51);
            this.groupBoxCompany.TabIndex = 0x13;
            this.groupBoxCompany.TabStop = false;
            this.groupBoxInfo.Controls.Add(this.lLinkSupport);
            this.groupBoxInfo.Dock = DockStyle.Bottom;
            this.groupBoxInfo.Location = new Point(0, 0x110);
            this.groupBoxInfo.Margin = new Padding(2);
            this.groupBoxInfo.Name = "groupBoxInfo";
            this.groupBoxInfo.Padding = new Padding(2);
            this.groupBoxInfo.Size = new Size(530, 0x51);
            this.groupBoxInfo.TabIndex = 20;
            this.groupBoxInfo.TabStop = false;
            this.lLinkSupport.AutoSize = true;
            this.lLinkSupport.Location = new Point(0, 0x41);
            this.lLinkSupport.Margin = new Padding(2, 0, 2, 0);
            this.lLinkSupport.Name = "lLinkSupport";
            this.lLinkSupport.Size = new Size(0xe7, 13);
            this.lLinkSupport.TabIndex = 0;
            this.lLinkSupport.TabStop = true;
            this.lLinkSupport.Text = "Click Here to Report Your Issue to Desksupport";
            this.lLinkSupport.LinkClicked += new LinkLabelLinkClickedEventHandler(this.lLinkSupport_LinkClicked);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(530, 0x173);
            base.ControlBox = false;
            base.Controls.Add(this.groupBoxLogin);
            base.Controls.Add(this.groupBoxCompany);
            base.Controls.Add(this.labelTitle);
            base.Controls.Add(this.groupBoxInfo);
            base.Controls.Add(this.panelChangeServer);
            base.Icon = (Icon) manager.GetObject("$this.Icon");
            base.Name = "FormLogin";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Login to WeighBridge System";
            base.Load += new EventHandler(this.FormLogin_Load);
            this.panelChangeServer.ResumeLayout(false);
            this.panelChangeServer.PerformLayout();
            this.groupBoxLogin.ResumeLayout(false);
            this.groupBoxLogin.PerformLayout();
            this.groupBoxCompany.ResumeLayout(false);
            this.groupBoxCompany.PerformLayout();
            this.groupBoxInfo.ResumeLayout(false);
            this.groupBoxInfo.PerformLayout();
            base.ResumeLayout(false);
        }

        private void labelChangeServer_Click(object sender, EventArgs e)
        {
            FormServer server = new FormServer();
            server.ShowDialog();
            if (server.pReturn)
            {
                this.labelServer.Text = WBData.sServer + @"\" + WBData.sDatabase.ToUpper();
                this.textCoy.Text = "";
                this.textLoc.Text = "";
                this.labelCompanyName.Text = "";
                this.labelLocName.Text = "";
            }
            server.Dispose();
        }

        private void lLinkAD_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormGuideChangePasswordAD dad = new FormGuideChangePasswordAD();
            dad.ShowDialog();
            dad.Dispose();
        }

        private void lLinkSupport_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string fileName = "http://10.1.1.130:8081/desksupport/add_bug.aspx?url=/desksupport/bugs.aspx&qs=";
            try
            {
                WBTable table = new WBTable();
                table.OpenTable("tbl_Condition", "select condition_code , description from wb_condition where condition_code = 'SUPPORT_PATH'", WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    fileName = table.DT.Rows[0]["Description"].ToString();
                }
                table.Dispose();
            }
            catch
            {
            }
            Process.Start(fileName);
        }

        private bool loginwithADwillocal()
        {
            try
            {
                using (DirectoryEntry entry = new DirectoryEntry(WBSetting.ADPath, this.userID, this.password))
                {
                    using (DirectorySearcher searcher = new DirectorySearcher(entry))
                    {
                        searcher.Filter = "(sAMAccountName=" + this.userID + ")";
                        try
                        {
                            SearchResult result = searcher.FindOne();
                            this.ldapPath = result.Path;
                            foreach (string str3 in result.Properties["displayname"])
                            {
                                this.userName = str3;
                            }
                            WBTable table = new WBTable();
                            string[] textArray1 = new string[] { "Select top 1 * from wb_location where Coy = '", this.textCoy.Text, "' and Location_Code = '", this.textLoc.Text, "'" };
                            table.OpenTable("wb_location", string.Concat(textArray1), WBData.conn);
                            if (table.DT.Rows.Count != 0)
                            {
                                string str = this.textCoy.Text + this.textLoc.Text;
                                string str2 = "";
                                bool flag = false;
                                this.tbl.OpenTable("wb_user", "Select * from wb_user where user_id = '" + this.textBox1.Text.Trim() + "'", WBData.conn);
                                if (this.tbl.DT.Rows.Count <= 0)
                                {
                                    this.berhasil = false;
                                    MessageBox.Show(Resource.LoginAD_014, Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    this.textBox1.Focus();
                                    return true;
                                }
                                else
                                {
                                    flag = false;
                                    int num = 0;
                                    while (true)
                                    {
                                        if (num < this.tbl.DT.Rows.Count)
                                        {
                                            str2 = this.tbl.DT.Rows[num]["coy"].ToString() + this.tbl.DT.Rows[num]["location_code"].ToString();
                                            if (str != str2)
                                            {
                                                num++;
                                                continue;
                                            }
                                            this.userGroup = this.tbl.DT.Rows[num]["user_group"].ToString();
                                            flag = true;
                                        }
                                        if (!flag)
                                        {
                                            this.berhasil = false;
                                            MessageBox.Show(Resource.Mes_614, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                            this.textBox1.Focus();
                                            return true;
                                        }
                                        else
                                        {
                                            this.ADCoy = this.textCoy.Text;
                                            this.ADLocation_Code = this.textLoc.Text;
                                            this.berhasil = true;
                                            base.Close();
                                        }
                                        break;
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_004b, Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                return true;
                            }
                        }
                        catch (DirectoryServicesCOMException exception)
                        {
                            string str7;
                            string extendedErrorMessage = exception.ExtendedErrorMessage;
                            string message = exception.Message;
                            string str6 = "";
                            char[] separator = new char[] { ',' };
                            string[] strArray2 = extendedErrorMessage.Split(separator);
                            int index = 0;
                            while (true)
                            {
                                if (index < strArray2.Length)
                                {
                                    string str8 = strArray2[index];
                                    if (!str8.Contains("data"))
                                    {
                                        index++;
                                        continue;
                                    }
                                    str6 = str8.Replace("data ", "").Trim();
                                }
                                str7 = "";
                                string s = str6;
                                uint num3 = <PrivateImplementationDetails>.ComputeStringHash(s);
                                if (num3 <= 0x8dbb4212)
                                {
                                    if (num3 <= 0x649d7999)
                                    {
                                        if (num3 != 0x9c73e39)
                                        {
                                            if ((num3 == 0x649d7999) && (s == "52e"))
                                            {
                                                str7 = Resource.loginAD_002 + Environment.NewLine + Resource.loginAD_003;
                                                break;
                                            }
                                        }
                                        else if (s == "701")
                                        {
                                            str7 = Resource.loginAD_010 + Environment.NewLine + Resource.loginAD_005;
                                            break;
                                        }
                                    }
                                    else if (num3 != 0x87bb38a0)
                                    {
                                        if ((num3 == 0x8dbb4212) && (s == "775"))
                                        {
                                            str7 = Resource.loginAD_012;
                                            break;
                                        }
                                    }
                                    else if (s == "773")
                                    {
                                        str7 = Resource.loginAD_011 + Environment.NewLine + Resource.loginAD_008;
                                        break;
                                    }
                                }
                                else if (num3 <= 0xbca042b8)
                                {
                                    if (num3 != 0xb49df789)
                                    {
                                        if ((num3 == 0xbca042b8) && (s == "531"))
                                        {
                                            str7 = Resource.loginAD_006 + Environment.NewLine + Resource.loginAD_005;
                                            break;
                                        }
                                    }
                                    else if (s == "525")
                                    {
                                        str7 = Resource.loginAD_001;
                                        break;
                                    }
                                }
                                else if (num3 == 0xbda0444b)
                                {
                                    if (s == "530")
                                    {
                                        str7 = Resource.loginAD_004 + Environment.NewLine + Resource.loginAD_005;
                                        break;
                                    }
                                }
                                else if (num3 != 0xbea045de)
                                {
                                    if ((num3 == 0xbfa04771) && (s == "532"))
                                    {
                                        str7 = Resource.loginAD_007 + Environment.NewLine + Resource.loginAD_008;
                                        break;
                                    }
                                }
                                else if (s == "533")
                                {
                                    str7 = Resource.loginAD_009 + Environment.NewLine + Resource.loginAD_005;
                                    break;
                                }
                                str7 = "unspecify error: " + str6;
                                break;
                            }
                            string[] textArray2 = new string[] { str7, Environment.NewLine, Environment.NewLine, Resource.loginAD_013, Environment.NewLine, extendedErrorMessage };
                            MessageBox.Show(string.Concat(textArray2), Resource.Title_002, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        finally
                        {
                            entry.Close();
                        }
                    }
                }
                this.hideMB();
                return true;
            }
            catch (Exception exception2)
            {
                this.hideMB();
                this.loginadex = exception2.Message;
                return false;
            }
        }

        public void PassValue(string strValue, string strValue2)
        {
            this.textBox1.Text = strValue;
            this.textBox2.Text = strValue2;
        }

        private void showMB(string text)
        {
            this.form = new Form();
            Label label = new Label();
            PictureBox box = new PictureBox();
            label.Location = new Point(80, 20);
            box.Location = new Point(20, 20);
            box.Image = Resources.wbconnicon;
            box.Width = 40;
            box.Height = 40;
            box.SizeMode = PictureBoxSizeMode.StretchImage;
            label.Width = 400;
            label.Height = 50;
            label.Text = text;
            this.form.ControlBox = false;
            this.form.StartPosition = FormStartPosition.CenterScreen;
            this.form.Size = new Size(500, 100);
            this.form.Controls.Add(label);
            this.form.Controls.Add(box);
            this.form.Show();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.button1.PerformClick();
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.button1.PerformClick();
            }
        }

        private void translate()
        {
            this.label4.Text = Resource.Login_001;
            this.label3.Text = Resource.Login_002;
            this.label1.Text = Resource.Login_003;
            this.label2.Text = Resource.Login_004;
            this.button1.Text = Resource.Login_005;
            this.button2.Text = Resource.Login_006;
            this.Text = Resource.Login_007;
            this.labelChangeServer.Text = Resource.Login_008;
            this.lLinkAD.Text = Resource.link_change_password_ad;
            this.lLinkSupport.Text = Resource.Support_01;
        }
    }
}

