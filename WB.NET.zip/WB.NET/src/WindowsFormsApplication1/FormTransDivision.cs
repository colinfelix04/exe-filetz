﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTransDivision : Form
    {
        public bool Saved = false;
        public bool entryFromRegistration = false;
        private int sisa;
        public int jTandan;
        public DataGridView dgvDiv = new DataGridView();
        public string refDate;
        public string pMode = "";
        private IContainer components = null;
        public TextBox textEstateName;
        public TextBox textEstate;
        public Label label4;
        public Button button11;
        public TextBox textDiv;
        public TextBox textDivName;
        public Label label5;
        public TextBox textBlockName;
        public TextBox textBlockCode;
        public Label label1;
        public Button button2;
        public Button button1;
        public Label label3;
        public Label label6;
        public Label label7;
        public Label label8;
        public Label labelRemain;
        public TextBox textBunch;
        public TextBox textWeight;
        public Label label9;
        public TextBox textYear;
        public Label label2;
        public TextBox maskedAVG;

        public FormTransDivision()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.textBlockCode.Text.Trim() == "") || (this.textDiv.Text.Trim() == ""))
            {
                MessageBox.Show("Please Fill in Block & Division", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.button11.Focus();
            }
            else if ((this.entryFromRegistration || ((Convert.ToInt16(this.labelRemain.Text) <= 0) || ((this.textBunch.Text != "") && (Convert.ToInt16(this.textBunch.Text) > 0)))) ? (this.entryFromRegistration && ((this.textBunch.Text == "") || (Convert.ToInt16(this.textBunch.Text) <= 0))) : true)
            {
                MessageBox.Show("Please Fill in Bunch", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.textBunch.Focus();
            }
            else if ((!this.entryFromRegistration && (Convert.ToInt16(this.labelRemain.Text) > 0)) && ((this.maskedAVG.Text == "") || !(Convert.ToDouble(this.maskedAVG.Text) != 0.0)))
            {
                MessageBox.Show("Please Fill in Average Weight", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.maskedAVG.Focus();
            }
            else if (!this.entryFromRegistration && (Convert.ToInt16(this.textBunch.Text) > Convert.ToInt16(this.labelRemain.Text.Replace(",", ""))))
            {
                MessageBox.Show("Invalid Entry, Bunch Remain Not Enough....", "Message...");
                this.textBunch.Focus();
            }
            else
            {
                this.Saved = true;
                base.Close();
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            FormBlock block = new FormBlock {
                pMode = "CHOOSE",
                pSQLtext = "Select * From wb_block where " + WBData.CompanyLocation(" ")
            };
            block.ShowDialog();
            if (block.ReturnRow != null)
            {
                string str = block.ReturnRow["Division_Code"].ToString();
                string str2 = block.ReturnRow["Block_Code"].ToString();
                int num = 0;
                while (true)
                {
                    if (num < this.dgvDiv.Rows.Count)
                    {
                        if ((str != this.dgvDiv.Rows[num].Cells["division_code"].Value.ToString()) || (str2 != this.dgvDiv.Rows[num].Cells["Block_code"].Value.ToString()))
                        {
                            num++;
                            continue;
                        }
                        MessageBox.Show("Entry Already Exist, Please Choose Another Record....", "Message....");
                        return;
                    }
                    else
                    {
                        this.textEstate.Text = block.ReturnRow["Estate_Code"].ToString();
                        WBTable table = new WBTable();
                        table.OpenTable("wb_estate", "Select * From wb_estate where " + WBData.CompanyLocation(" and Estate_Code='" + this.textEstate.Text.Trim() + "'"), WBData.conn);
                        if (table.DT.Rows.Count > 0)
                        {
                            this.textEstateName.Text = table.DT.Rows[0]["Estate_Name"].ToString();
                        }
                        this.textDiv.Text = block.ReturnRow["Division_Code"].ToString();
                        this.textDivName.Text = block.ReturnRow["Division_Name"].ToString();
                        this.textBlockCode.Text = block.ReturnRow["Block_Code"].ToString();
                        this.textBlockName.Text = block.ReturnRow["Block_Name"].ToString();
                        this.textYear.Text = block.ReturnRow["YearPlanting"].ToString();
                    }
                    break;
                }
            }
            block.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Saved = false;
            base.Close();
        }

        public string calcDivisionWeight(string avg, string bunch)
        {
            double num = Convert.ToDouble(avg) * Convert.ToDouble(bunch);
            double num2 = num % 10.0;
            num = (num2 < 5.0) ? (num - num2) : ((num - num2) + 10.0);
            return string.Format("{0:N0}", num, 0).Replace(",", "");
        }

        private int cekSisa(DataGridView dgv)
        {
            int jTandan = this.jTandan;
            for (int i = 0; i < dgv.Rows.Count; i++)
            {
                if (!dgv.Rows[i].Selected || (this.pMode != "EDIT"))
                {
                    jTandan -= Convert.ToInt16(dgv.Rows[i].Cells["Bunch"].Value.ToString());
                }
            }
            return jTandan;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransDivision_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTransDivision_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.sisa = this.cekSisa(this.dgvDiv);
            this.labelRemain.Text = string.Format("{0:N0}", Convert.ToDouble(this.sisa), 0).Replace(",", "");
            this.translate();
        }

        private string getBJR(string refDate, DataRow aRow)
        {
            string str = "00.00";
            switch (Convert.ToDateTime(refDate).Month)
            {
                case 0:
                    str = aRow["BJR0"].ToString();
                    break;

                case 1:
                    str = aRow["BJR1"].ToString();
                    break;

                case 2:
                    str = aRow["BJR2"].ToString();
                    break;

                case 3:
                    str = aRow["BJR3"].ToString();
                    break;

                case 4:
                    str = aRow["BJR4"].ToString();
                    break;

                case 5:
                    str = aRow["BJR5"].ToString();
                    break;

                case 6:
                    str = aRow["BJR6"].ToString();
                    break;

                case 7:
                    str = aRow["BJR7"].ToString();
                    break;

                case 8:
                    str = aRow["BJR8"].ToString();
                    break;

                case 9:
                    str = aRow["BJR9"].ToString();
                    break;

                case 10:
                    str = aRow["BJR10"].ToString();
                    break;

                case 11:
                    str = aRow["BJR11"].ToString();
                    break;

                case 12:
                    str = aRow["BJR12"].ToString();
                    break;

                default:
                    break;
            }
            return string.Format("{0:N2}", Convert.ToDouble(str), 0);
        }

        private void InitializeComponent()
        {
            this.textEstateName = new TextBox();
            this.textEstate = new TextBox();
            this.label4 = new Label();
            this.button11 = new Button();
            this.textDiv = new TextBox();
            this.textDivName = new TextBox();
            this.label5 = new Label();
            this.textBlockName = new TextBox();
            this.textBlockCode = new TextBox();
            this.label1 = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.label3 = new Label();
            this.textBunch = new TextBox();
            this.label6 = new Label();
            this.textWeight = new TextBox();
            this.label7 = new Label();
            this.label8 = new Label();
            this.labelRemain = new Label();
            this.label9 = new Label();
            this.textYear = new TextBox();
            this.maskedAVG = new TextBox();
            this.label2 = new Label();
            base.SuspendLayout();
            this.textEstateName.Location = new Point(0x100, 40);
            this.textEstateName.MaxLength = 50;
            this.textEstateName.Name = "textEstateName";
            this.textEstateName.ReadOnly = true;
            this.textEstateName.Size = new Size(0x126, 20);
            this.textEstateName.TabIndex = 7;
            this.textEstate.Location = new Point(0x75, 40);
            this.textEstate.MaxLength = 20;
            this.textEstate.Name = "textEstate";
            this.textEstate.ReadOnly = true;
            this.textEstate.Size = new Size(0x84, 20);
            this.textEstate.TabIndex = 4;
            this.label4.Location = new Point(12, 0x2b);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x5f, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Estate";
            this.label4.TextAlign = ContentAlignment.MiddleRight;
            this.button11.Location = new Point(0x75, 9);
            this.button11.Margin = new Padding(0);
            this.button11.Name = "button11";
            this.button11.Size = new Size(0x21, 0x1a);
            this.button11.TabIndex = 0;
            this.button11.Text = "...";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new EventHandler(this.button11_Click);
            this.textDiv.Location = new Point(0x75, 0x42);
            this.textDiv.MaxLength = 20;
            this.textDiv.Name = "textDiv";
            this.textDiv.ReadOnly = true;
            this.textDiv.Size = new Size(0x84, 20);
            this.textDiv.TabIndex = 5;
            this.textDivName.Location = new Point(0x100, 0x42);
            this.textDivName.MaxLength = 50;
            this.textDivName.Name = "textDivName";
            this.textDivName.ReadOnly = true;
            this.textDivName.Size = new Size(0x126, 20);
            this.textDivName.TabIndex = 8;
            this.label5.Location = new Point(12, 0x45);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x5f, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Division Code";
            this.label5.TextAlign = ContentAlignment.MiddleRight;
            this.textBlockName.Location = new Point(0x100, 0x5c);
            this.textBlockName.MaxLength = 50;
            this.textBlockName.Name = "textBlockName";
            this.textBlockName.ReadOnly = true;
            this.textBlockName.Size = new Size(0x125, 20);
            this.textBlockName.TabIndex = 9;
            this.textBlockCode.CharacterCasing = CharacterCasing.Upper;
            this.textBlockCode.Location = new Point(0x75, 0x5c);
            this.textBlockCode.MaxLength = 20;
            this.textBlockCode.Name = "textBlockCode";
            this.textBlockCode.ReadOnly = true;
            this.textBlockCode.Size = new Size(0x84, 20);
            this.textBlockCode.TabIndex = 6;
            this.label1.Location = new Point(12, 0x5f);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x5f, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Block Code";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.button2.Location = new Point(0x1d9, 0xb1);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 40);
            this.button2.TabIndex = 3;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x188, 0xb1);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 40);
            this.button1.TabIndex = 2;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.label3.Location = new Point(12, 0xac);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x5f, 13);
            this.label3.TabIndex = 0x10;
            this.label3.Text = "Bunch";
            this.label3.TextAlign = ContentAlignment.MiddleRight;
            this.textBunch.Location = new Point(0x75, 0xa9);
            this.textBunch.MaxLength = 5;
            this.textBunch.Name = "textBunch";
            this.textBunch.Size = new Size(0x4a, 20);
            this.textBunch.TabIndex = 1;
            this.textBunch.Text = "0";
            this.textBunch.TextAlign = HorizontalAlignment.Right;
            this.textBunch.Leave += new EventHandler(this.textBunch_Leave);
            this.label6.Location = new Point(12, 0xc6);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x5f, 13);
            this.label6.TabIndex = 0x11;
            this.label6.Text = "Weight";
            this.label6.TextAlign = ContentAlignment.MiddleRight;
            this.textWeight.Location = new Point(0x75, 0xc3);
            this.textWeight.Name = "textWeight";
            this.textWeight.Size = new Size(0x4a, 20);
            this.textWeight.TabIndex = 0x12;
            this.textWeight.Text = "0";
            this.textWeight.TextAlign = HorizontalAlignment.Right;
            this.textWeight.Leave += new EventHandler(this.textWeight_Leave);
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0xc5, 200);
            this.label7.Name = "label7";
            this.label7.Size = new Size(20, 13);
            this.label7.TabIndex = 0x13;
            this.label7.Text = "Kg";
            this.label8.AutoSize = true;
            this.label8.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label8.ForeColor = SystemColors.ControlText;
            this.label8.Location = new Point(0x17b, 9);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x76, 13);
            this.label8.TabIndex = 0x15;
            this.label8.Text = "Remaining Bunch : ";
            this.labelRemain.AutoSize = true;
            this.labelRemain.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRemain.Location = new Point(0x1f7, 9);
            this.labelRemain.Name = "labelRemain";
            this.labelRemain.Size = new Size(14, 13);
            this.labelRemain.TabIndex = 0x16;
            this.labelRemain.Text = "0";
            this.label9.Location = new Point(12, 120);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x5f, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Year Planting";
            this.label9.TextAlign = ContentAlignment.MiddleRight;
            this.textYear.Location = new Point(0x75, 0x75);
            this.textYear.MaxLength = 4;
            this.textYear.Name = "textYear";
            this.textYear.ReadOnly = true;
            this.textYear.Size = new Size(0x2f, 20);
            this.textYear.TabIndex = 14;
            this.textYear.Text = "0";
            this.textYear.TextAlign = HorizontalAlignment.Right;
            this.maskedAVG.Location = new Point(0x75, 0x8f);
            this.maskedAVG.MaxLength = 4;
            this.maskedAVG.Name = "maskedAVG";
            this.maskedAVG.ReadOnly = true;
            this.maskedAVG.Size = new Size(0x2f, 20);
            this.maskedAVG.TabIndex = 20;
            this.maskedAVG.Text = "0";
            this.maskedAVG.TextAlign = HorizontalAlignment.Right;
            this.label2.Location = new Point(12, 0x92);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x5f, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "BJR";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x23d, 0xee);
            base.ControlBox = false;
            base.Controls.Add(this.maskedAVG);
            base.Controls.Add(this.textYear);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.labelRemain);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.textWeight);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.textBunch);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textEstateName);
            base.Controls.Add(this.textEstate);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.button11);
            base.Controls.Add(this.textDiv);
            base.Controls.Add(this.textDivName);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.textBlockName);
            base.Controls.Add(this.textBlockCode);
            base.Controls.Add(this.label1);
            base.MaximizeBox = false;
            base.Name = "FormTransDivision";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Entry Division/Block Item";
            base.Load += new EventHandler(this.FormTransDivision_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransDivision_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textBunch_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBunch);
            if (!this.entryFromRegistration)
            {
                this.textWeight.Text = this.calcDivisionWeight(this.maskedAVG.Text, this.textBunch.Text);
            }
        }

        private void textWeight_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textWeight);
        }

        private void translate()
        {
            string str = (this.pMode == "ADD") ? Resource.Trans_055 : ((this.pMode == "EDIT") ? Resource.Trans_056 : ((this.pMode == "DELETE") ? Resource.Trans_057 : ""));
            this.Text = str + " " + Resource.DivBlock_008;
            this.label8.Text = Resource.DivBlock_009;
            this.label4.Text = Resource.DivBlock_001;
            this.label5.Text = Resource.DivBlock_002;
            this.label1.Text = Resource.DivBlock_003;
            this.label9.Text = Resource.DivBlock_004;
            this.label2.Text = Resource.DivBlock_005;
            this.label3.Text = Resource.DivBlock_006;
            this.label6.Text = Resource.DivBlock_007;
            this.button1.Text = Resource.Btn_Save;
            this.button2.Text = Resource.Btn_Cancel;
        }
    }
}

