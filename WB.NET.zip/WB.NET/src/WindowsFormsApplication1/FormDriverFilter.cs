﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormDriverFilter : Form
    {
        public bool saved = false;
        public string pFilter = "";
        private IContainer components = null;
        private Button button1;
        private Button btnFilter;
        private Label label1;
        public TextBox textTruck_Number;

        public FormDriverFilter()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string str = " = ";
            string text = "";
            if (this.textTruck_Number.Text == "")
            {
                text = "";
            }
            else if (this.checkFind(this.textTruck_Number.Text))
            {
                str = " like ";
                text = this.replaceFind(this.textTruck_Number.Text);
            }
            else
            {
                str = " = ";
                text = this.textTruck_Number.Text;
            }
            if (text != "")
            {
                string[] textArray1 = new string[] { " AND Truck_Number ", str, "'", text, "'" };
                this.pFilter = string.Concat(textArray1);
            }
            this.saved = true;
            base.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.saved = false;
            base.Close();
        }

        private bool checkFind(string pFind)
        {
            int num = 0;
            while (true)
            {
                bool flag2;
                if (num >= pFind.Length)
                {
                    flag2 = false;
                }
                else
                {
                    if (pFind[num] != '*')
                    {
                        num++;
                        continue;
                    }
                    flag2 = true;
                }
                return flag2;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormDriverFilter_Load(object sender, EventArgs e)
        {
            this.textTruck_Number.Focus();
        }

        private void InitializeComponent()
        {
            this.button1 = new Button();
            this.btnFilter = new Button();
            this.label1 = new Label();
            this.textTruck_Number = new TextBox();
            base.SuspendLayout();
            this.button1.Location = new Point(0x8e, 0x95);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x57, 0x1d);
            this.button1.TabIndex = 2;
            this.button1.Text = "Cancel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.btnFilter.Location = new Point(0x2f, 0x95);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new Size(0x57, 0x1d);
            this.btnFilter.TabIndex = 1;
            this.btnFilter.Text = "Filter";
            this.btnFilter.UseVisualStyleBackColor = true;
            this.btnFilter.Click += new EventHandler(this.btnFilter_Click);
            this.label1.Location = new Point(0x15, 0x3b);
            this.label1.Name = "label1";
            this.label1.Size = new Size(100, 13);
            this.label1.TabIndex = 0x48;
            this.label1.Text = "Truck Number";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            this.textTruck_Number.Location = new Point(0x7f, 0x38);
            this.textTruck_Number.MaxLength = 30;
            this.textTruck_Number.Name = "textTruck_Number";
            this.textTruck_Number.Size = new Size(0x84, 20);
            this.textTruck_Number.TabIndex = 0;
            this.textTruck_Number.KeyPress += new KeyPressEventHandler(this.textTruck_Number_KeyPress);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x11c, 200);
            base.ControlBox = false;
            base.Controls.Add(this.label1);
            base.Controls.Add(this.textTruck_Number);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.btnFilter);
            base.Name = "FormDriverFilter";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "FormDriverFilter";
            base.Load += new EventHandler(this.FormDriverFilter_Load);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private string replaceFind(string pFind)
        {
            string str = "";
            for (int i = 0; i < pFind.Length; i++)
            {
                bool flag = pFind[i] == '*';
                str = !flag ? (str + pFind[i].ToString()) : (str + "%");
            }
            return str;
        }

        private void textTruck_Number_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.btnFilter.PerformClick();
            }
        }

        private void translate()
        {
            this.button1.Text = Resource.Menu_Cancel;
            this.btnFilter.Text = Resource.Menu_Filter;
            this.label1.Text = Resource.Rep01_013;
            this.Text = Resource.Title_Driver_Filter;
        }
    }
}

