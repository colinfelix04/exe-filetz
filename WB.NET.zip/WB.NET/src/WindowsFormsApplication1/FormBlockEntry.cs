﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormBlockEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode1;
        public string OldCode2;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        public WBTable tbldiv = new WBTable();
        public WBTable tblEstate = new WBTable();
        public string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private Label label3;
        private Button button2;
        private Button button1;
        private TextBox textSAP;
        private TextBox textRemark;
        private TextBox textBlockName;
        private Label label8;
        private Label label2;
        private Label label1;
        private Label label5;
        private TextBox textDivName;
        private TextBox textDiv;
        private Button button11;
        private TextBox textEstate;
        private Label label4;
        private TextBox textEstateName;
        private TextBox textYP;
        private Label label6;
        private GroupBox groupBox1;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label7;
        private Label label20;
        private TextBox textBJR12;
        private TextBox textBJR11;
        private TextBox textBJR10;
        private TextBox textBJR9;
        private TextBox textBJR8;
        private TextBox textBJR7;
        private TextBox textBJR6;
        private TextBox textBJR5;
        private TextBox textBJR4;
        private TextBox textBJR3;
        private TextBox textBJR2;
        private TextBox textBJR1;
        private TextBox textBJR0;
        public TextBox textBlockCode;
        private ShapeContainer shapeContainer1;
        private LineShape lineShape7;
        private LineShape lineShape6;
        private LineShape lineShape5;
        private LineShape lineShape4;
        private LineShape lineShape3;
        private LineShape lineShape2;
        private LineShape lineShape1;

        public FormBlockEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str;
            WBTable table2;
            TextBox[] aText = new TextBox[] { this.textBlockCode, this.textBlockName, this.textDiv };
            if (!Program.CheckEmpty(aText))
            {
                WBTable table = new WBTable();
                string[] textArray1 = new string[] { " AND estate_code ='", this.textEstate.Text.Trim(), "'and (Division_Code='", this.textDiv.Text.Trim(), "') and ( Block_Code='", this.textBlockCode.Text.Trim(), "')" };
                str = "Select Block_Code,Uniq From wb_block where " + WBData.CompanyLocation(string.Concat(textArray1));
                table.OpenTable("wb_block", str, WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    Cursor.Current = Cursors.WaitCursor;
                    this.nCurrRow = this.zTable.GetPosRec(this.zTable.uniq);
                    if ((this.pMode != "EDIT") || ((this.textDiv.Text.Trim() + this.textBlockCode.Text.Trim()) == (this.OldCode1.Trim() + this.OldCode2.Trim())))
                    {
                        goto TR_0016;
                    }
                    else
                    {
                        table2 = new WBTable();
                        string[] textArray2 = new string[] { " and (Division_Code='", this.OldCode1.Trim(), "') and  (BLock_Code='", this.OldCode2.Trim(), "')" };
                        table2.OpenTable("wb_transDivision", "Select uniq From wb_transDivision where " + WBData.CompanyLocation(string.Concat(textArray2)), WBData.conn);
                        Cursor.Current = Cursors.Default;
                        if (table2.DT.Rows.Count <= 0)
                        {
                            goto TR_0017;
                        }
                        else
                        {
                            string[] textArray3 = new string[0x11];
                            textArray3[0] = Resource.Mes_Confirm_Replace_Block;
                            textArray3[1] = " ";
                            textArray3[2] = this.OldCode1.Trim();
                            textArray3[3] = "-";
                            textArray3[4] = this.OldCode2.Trim();
                            textArray3[5] = " -> ";
                            textArray3[6] = this.textDiv.Text.Trim();
                            textArray3[7] = "-";
                            textArray3[8] = this.textBlockCode.Text.Trim();
                            textArray3[9] = "\n\n";
                            textArray3[10] = Resource.Msg_Replace_Warning;
                            textArray3[11] = "\n  - ";
                            textArray3[12] = table2.DT.Rows.Count.ToString();
                            textArray3[13] = " ";
                            textArray3[14] = Resource.Mes_Records_In_Transaction;
                            textArray3[15] = "\n\n";
                            textArray3[0x10] = Resource.Mes_Confirm_Continue;
                            if (MessageBox.Show(string.Concat(textArray3), Resource.Mes_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.ReplaceAll = true;
                                goto TR_0017;
                            }
                            else
                            {
                                this.ReplaceAll = false;
                                this.textBlockCode.Focus();
                            }
                        }
                    }
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_020);
                    this.textBlockCode.Focus();
                }
            }
            return;
        TR_0016:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.Block_004 },
                    textRefNo = { Text = this.textBlockCode.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Estate_Code"] = this.textEstate.Text;
            this.zTable.DR["Block_Code"] = this.textBlockCode.Text;
            this.zTable.DR["Block_Name"] = this.textBlockName.Text;
            this.zTable.DR["Division_Code"] = this.textDiv.Text;
            this.zTable.DR["Division_Name"] = this.textDivName.Text;
            this.zTable.DR["Remark"] = this.textRemark.Text;
            this.zTable.DR["YearPlanting"] = (this.textYP.Text != "") ? ((object) this.textYP.Text) : ((object) 0);
            this.zTable.DR["SAP_Code"] = this.textSAP.Text;
            this.zTable.DR["BJR0"] = this.textBJR0.Text;
            this.zTable.DR["BJR1"] = this.textBJR1.Text;
            this.zTable.DR["BJR2"] = this.textBJR2.Text;
            this.zTable.DR["BJR3"] = this.textBJR3.Text;
            this.zTable.DR["BJR4"] = this.textBJR4.Text;
            this.zTable.DR["BJR5"] = this.textBJR5.Text;
            this.zTable.DR["BJR6"] = this.textBJR6.Text;
            this.zTable.DR["BJR7"] = this.textBJR7.Text;
            this.zTable.DR["BJR8"] = this.textBJR8.Text;
            this.zTable.DR["BJR9"] = this.textBJR9.Text;
            this.zTable.DR["BJR10"] = this.textBJR10.Text;
            this.zTable.DR["BJR11"] = this.textBJR11.Text;
            this.zTable.DR["BJR12"] = this.textBJR12.Text;
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    str = (("SELECT uniq FROM wb_block WHERE " + WBData.CompanyLocation("")) + " AND division_code = '" + this.textDiv.Text.Trim() + "'") + " AND block_code = '" + this.textBlockCode.Text.Trim() + "'";
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_block", str, WBData.conn);
                    this.logKey = table3.DT.Rows[0]["uniq"].ToString();
                    table3.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_block", this.logKey, logField, logValue);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string[] aField = new string[] { "Division_Code", "Block_Code" };
                string[] aNewValue = new string[] { this.textDiv.Text, this.textBlockCode.Text };
                string[] textArray8 = new string[] { " (Division_Code='", this.OldCode1.Trim(), "') and  (Block_Code   ='", this.OldCode2.Trim(), "') " };
                Program.ReplaceAll("wb_transDivision", aField, aNewValue, string.Concat(textArray8), this.changeReason + " (Edit block master data)");
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            base.Close();
            return;
        TR_0017:
            table2.Dispose();
            goto TR_0016;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            FormDivision division = new FormDivision {
                pMode = "CHOOSE"
            };
            division.ShowDialog();
            if (division.ReturnRow != null)
            {
                this.textEstate.Text = division.ReturnRow["Estate_Code"].ToString();
                WBTable table = new WBTable();
                table.OpenTable("wb_estate", "Select * From wb_estate", WBData.conn);
                string[] aField = new string[] { "Estate_Code" };
                string[] aFind = new string[] { this.textEstate.Text };
                DataRow data = table.GetData(aField, aFind);
                if (data != null)
                {
                    this.textEstateName.Text = data["Estate_Name"].ToString();
                }
                this.textDiv.Text = division.ReturnRow["Division_Code"].ToString();
                this.textDivName.Text = division.ReturnRow["Division_Name"].ToString();
                this.textEstate.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void CheckDiv()
        {
            if (this.textDiv.Text.Trim() == "")
            {
                this.textDiv.Focus();
            }
            else
            {
                this.tbldiv.ReOpen();
                string[] aField = new string[] { "Division_Code" };
                string[] aFind = new string[] { this.textDiv.Text.Trim() };
                int recNo = this.tbldiv.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.textDivName.ReadOnly = true;
                    this.textDivName.Text = this.tbldiv.DT.Rows[recNo]["Division_Name"].ToString();
                    this.textBlockCode.Focus();
                }
                else
                {
                    if (!this.textDivName.Enabled)
                    {
                        this.textDivName.Text = "";
                    }
                    this.textDivName.ReadOnly = false;
                    this.textDivName.Focus();
                }
            }
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void comboBox1_Leave(object sender, EventArgs e)
        {
            this.CheckDiv();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormBlockEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormBlockEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            this.tbldiv.OpenTable("wb_division", "SELECT Division_Code,Division_Name FROM wb_division", WBData.conn);
            this.tblEstate.OpenTable("wb_estate", "SELECT Estate_Code,Estate_Name FROM wb_estate", WBData.conn);
            this.textYP.Text = "";
            if (this.pMode != "ADD")
            {
                this.textDiv.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Division_Code"].Value.ToString();
                this.OldCode1 = this.textDiv.Text;
                string[] aField = new string[] { "Division_Code" };
                string[] aFind = new string[] { this.textDiv.Text.Trim() };
                int recNo = this.tbldiv.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.textDivName.Text = this.tbldiv.DT.Rows[recNo]["Division_Name"].ToString();
                }
                this.textEstate.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Estate_Code"].Value.ToString();
                string[] textArray3 = new string[] { "Estate_Code" };
                string[] textArray4 = new string[] { this.textEstate.Text };
                DataRow data = this.tblEstate.GetData(textArray3, textArray4);
                if (data != null)
                {
                    this.textEstateName.Text = data["Estate_Name"].ToString();
                }
                this.textBlockCode.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Block_Code"].Value.ToString();
                this.OldCode2 = this.textBlockCode.Text;
                this.textBlockName.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Block_Name"].Value.ToString();
                this.textRemark.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Remark"].Value.ToString();
                this.textYP.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["YearPlanting"].Value.ToString();
                this.textSAP.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["SAP_Code"].Value.ToString();
                this.textBJR0.Text = Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["BJR0"].Value.ToString(), 2).ToString();
                this.textBJR1.Text = Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["BJR1"].Value.ToString(), 2).ToString();
                this.textBJR2.Text = Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["BJR2"].Value.ToString(), 2).ToString();
                this.textBJR3.Text = Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["BJR3"].Value.ToString(), 2).ToString();
                this.textBJR4.Text = Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["BJR4"].Value.ToString(), 2).ToString();
                this.textBJR5.Text = Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["BJR5"].Value.ToString(), 2).ToString();
                this.textBJR6.Text = Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["BJR6"].Value.ToString(), 2).ToString();
                this.textBJR7.Text = Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["BJR7"].Value.ToString(), 2).ToString();
                this.textBJR8.Text = Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["BJR8"].Value.ToString(), 2).ToString();
                this.textBJR9.Text = Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["BJR9"].Value.ToString(), 2).ToString();
                this.textBJR10.Text = Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["BJR10"].Value.ToString(), 2).ToString();
                this.textBJR11.Text = Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["BJR11"].Value.ToString(), 2).ToString();
                this.textBJR12.Text = Program.StrToDouble(this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["BJR12"].Value.ToString(), 2).ToString();
            }
            this.textDivName.ReadOnly = true;
            if (this.pMode == "VIEW")
            {
                foreach (Control control in base.Controls)
                {
                    control.Enabled = false;
                }
                this.button2.Text = Resource.Btn_Close;
                this.button2.Enabled = true;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }

        private void InitializeComponent()
        {
            this.label3 = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.textSAP = new TextBox();
            this.textRemark = new TextBox();
            this.textBlockName = new TextBox();
            this.textBlockCode = new TextBox();
            this.label8 = new Label();
            this.label2 = new Label();
            this.label1 = new Label();
            this.label5 = new Label();
            this.textDivName = new TextBox();
            this.textDiv = new TextBox();
            this.button11 = new Button();
            this.textEstate = new TextBox();
            this.label4 = new Label();
            this.textEstateName = new TextBox();
            this.textYP = new TextBox();
            this.label6 = new Label();
            this.groupBox1 = new GroupBox();
            this.textBJR12 = new TextBox();
            this.textBJR11 = new TextBox();
            this.textBJR10 = new TextBox();
            this.textBJR9 = new TextBox();
            this.textBJR8 = new TextBox();
            this.textBJR7 = new TextBox();
            this.textBJR6 = new TextBox();
            this.textBJR5 = new TextBox();
            this.textBJR4 = new TextBox();
            this.textBJR3 = new TextBox();
            this.textBJR2 = new TextBox();
            this.textBJR1 = new TextBox();
            this.textBJR0 = new TextBox();
            this.label20 = new Label();
            this.label16 = new Label();
            this.label17 = new Label();
            this.label18 = new Label();
            this.label19 = new Label();
            this.label15 = new Label();
            this.label14 = new Label();
            this.label13 = new Label();
            this.label12 = new Label();
            this.label11 = new Label();
            this.label10 = new Label();
            this.label9 = new Label();
            this.label7 = new Label();
            this.shapeContainer1 = new ShapeContainer();
            this.lineShape7 = new LineShape();
            this.lineShape6 = new LineShape();
            this.lineShape5 = new LineShape();
            this.lineShape4 = new LineShape();
            this.lineShape3 = new LineShape();
            this.lineShape2 = new LineShape();
            this.lineShape1 = new LineShape();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.label3.Location = new Point(0x26, 150);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x55, 13);
            this.label3.TabIndex = 0x44;
            this.label3.Text = "Remark";
            this.label3.TextAlign = ContentAlignment.MiddleLeft;
            this.label3.Click += new EventHandler(this.label3_Click);
            this.button2.Location = new Point(0x210, 0xb3);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x5b, 0x24);
            this.button2.TabIndex = 7;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x187, 0xb3);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x60, 0x24);
            this.button1.TabIndex = 6;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textSAP.Location = new Point(0x81, 0xbc);
            this.textSAP.Name = "textSAP";
            this.textSAP.Size = new Size(0x66, 20);
            this.textSAP.TabIndex = 5;
            this.textRemark.Location = new Point(0x81, 0x93);
            this.textRemark.MaxLength = 100;
            this.textRemark.Multiline = true;
            this.textRemark.Name = "textRemark";
            this.textRemark.Size = new Size(0x1e6, 0x15);
            this.textRemark.TabIndex = 4;
            this.textBlockName.Location = new Point(0x81, 0x62);
            this.textBlockName.MaxLength = 50;
            this.textBlockName.Name = "textBlockName";
            this.textBlockName.Size = new Size(0xa5, 20);
            this.textBlockName.TabIndex = 2;
            this.textBlockCode.CharacterCasing = CharacterCasing.Upper;
            this.textBlockCode.Location = new Point(0x81, 0x4a);
            this.textBlockCode.MaxLength = 20;
            this.textBlockCode.Name = "textBlockCode";
            this.textBlockCode.Size = new Size(0x66, 20);
            this.textBlockCode.TabIndex = 1;
            this.label8.Location = new Point(0x26, 0xbf);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x55, 13);
            this.label8.TabIndex = 0x43;
            this.label8.Text = "SAP Code";
            this.label8.TextAlign = ContentAlignment.MiddleLeft;
            this.label2.Location = new Point(0x26, 0x65);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x55, 13);
            this.label2.TabIndex = 0x42;
            this.label2.Text = "Block Name";
            this.label2.TextAlign = ContentAlignment.MiddleLeft;
            this.label1.Location = new Point(0x26, 0x4d);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x55, 13);
            this.label1.TabIndex = 0x41;
            this.label1.Text = "Block Code";
            this.label1.TextAlign = ContentAlignment.MiddleLeft;
            this.label5.Location = new Point(0x26, 0x25);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x55, 13);
            this.label5.TabIndex = 0x45;
            this.label5.Text = "Division Code";
            this.label5.TextAlign = ContentAlignment.MiddleLeft;
            this.textDivName.Location = new Point(0x143, 0x22);
            this.textDivName.MaxLength = 50;
            this.textDivName.Name = "textDivName";
            this.textDivName.ReadOnly = true;
            this.textDivName.Size = new Size(0x142, 20);
            this.textDivName.TabIndex = 11;
            this.textDiv.Location = new Point(0x81, 0x22);
            this.textDiv.MaxLength = 20;
            this.textDiv.Name = "textDiv";
            this.textDiv.ReadOnly = true;
            this.textDiv.Size = new Size(0xa5, 20);
            this.textDiv.TabIndex = 10;
            this.button11.Location = new Point(0x129, 0x20);
            this.button11.Margin = new Padding(0);
            this.button11.Name = "button11";
            this.button11.Size = new Size(0x17, 0x17);
            this.button11.TabIndex = 0;
            this.button11.Text = "...";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new EventHandler(this.button11_Click);
            this.textEstate.Location = new Point(0x81, 8);
            this.textEstate.MaxLength = 20;
            this.textEstate.Name = "textEstate";
            this.textEstate.ReadOnly = true;
            this.textEstate.Size = new Size(0xa5, 20);
            this.textEstate.TabIndex = 8;
            this.label4.Location = new Point(0x26, 11);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x55, 13);
            this.label4.TabIndex = 0x49;
            this.label4.Text = "Estate";
            this.label4.TextAlign = ContentAlignment.MiddleLeft;
            this.textEstateName.Location = new Point(0x127, 8);
            this.textEstateName.MaxLength = 50;
            this.textEstateName.Name = "textEstateName";
            this.textEstateName.ReadOnly = true;
            this.textEstateName.Size = new Size(350, 20);
            this.textEstateName.TabIndex = 9;
            this.textYP.CharacterCasing = CharacterCasing.Upper;
            this.textYP.Location = new Point(0x81, 0x7a);
            this.textYP.MaxLength = 4;
            this.textYP.Name = "textYP";
            this.textYP.Size = new Size(0x24, 20);
            this.textYP.TabIndex = 3;
            this.textYP.Text = "1988";
            this.label6.Location = new Point(0x26, 0x7d);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x55, 13);
            this.label6.TabIndex = 0x4d;
            this.label6.Text = "Year of Planting";
            this.label6.TextAlign = ContentAlignment.MiddleLeft;
            this.groupBox1.Controls.Add(this.textBJR12);
            this.groupBox1.Controls.Add(this.textBJR11);
            this.groupBox1.Controls.Add(this.textBJR10);
            this.groupBox1.Controls.Add(this.textBJR9);
            this.groupBox1.Controls.Add(this.textBJR8);
            this.groupBox1.Controls.Add(this.textBJR7);
            this.groupBox1.Controls.Add(this.textBJR6);
            this.groupBox1.Controls.Add(this.textBJR5);
            this.groupBox1.Controls.Add(this.textBJR4);
            this.groupBox1.Controls.Add(this.textBJR3);
            this.groupBox1.Controls.Add(this.textBJR2);
            this.groupBox1.Controls.Add(this.textBJR1);
            this.groupBox1.Controls.Add(this.textBJR0);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Location = new Point(12, 0x116);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x286, 0xb3);
            this.groupBox1.TabIndex = 0x4e;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "BJR/ Month";
            this.groupBox1.Visible = false;
            this.groupBox1.Enter += new EventHandler(this.groupBox1_Enter);
            this.textBJR12.CharacterCasing = CharacterCasing.Upper;
            this.textBJR12.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR12.Location = new Point(0x227, 0x7c);
            this.textBJR12.MaxLength = 4;
            this.textBJR12.Name = "textBJR12";
            this.textBJR12.Size = new Size(0x34, 0x1a);
            this.textBJR12.TabIndex = 0x5d;
            this.textBJR12.Text = "0";
            this.textBJR12.Leave += new EventHandler(this.textBJR12_Leave);
            this.textBJR11.CharacterCasing = CharacterCasing.Upper;
            this.textBJR11.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR11.Location = new Point(0x227, 0x5c);
            this.textBJR11.MaxLength = 4;
            this.textBJR11.Name = "textBJR11";
            this.textBJR11.Size = new Size(0x34, 0x1a);
            this.textBJR11.TabIndex = 0x5c;
            this.textBJR11.Text = "0";
            this.textBJR11.Leave += new EventHandler(this.textBJR11_Leave);
            this.textBJR10.CharacterCasing = CharacterCasing.Upper;
            this.textBJR10.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR10.Location = new Point(0x228, 60);
            this.textBJR10.MaxLength = 4;
            this.textBJR10.Name = "textBJR10";
            this.textBJR10.Size = new Size(0x34, 0x1a);
            this.textBJR10.TabIndex = 0x5b;
            this.textBJR10.Text = "0";
            this.textBJR10.Leave += new EventHandler(this.textBJR10_Leave);
            this.textBJR9.CharacterCasing = CharacterCasing.Upper;
            this.textBJR9.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR9.Location = new Point(0x195, 0x7c);
            this.textBJR9.MaxLength = 4;
            this.textBJR9.Name = "textBJR9";
            this.textBJR9.Size = new Size(0x34, 0x1a);
            this.textBJR9.TabIndex = 90;
            this.textBJR9.Text = "0";
            this.textBJR9.Leave += new EventHandler(this.textBJR9_Leave);
            this.textBJR8.CharacterCasing = CharacterCasing.Upper;
            this.textBJR8.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR8.Location = new Point(0x195, 0x5c);
            this.textBJR8.MaxLength = 4;
            this.textBJR8.Name = "textBJR8";
            this.textBJR8.Size = new Size(0x34, 0x1a);
            this.textBJR8.TabIndex = 0x59;
            this.textBJR8.Text = "0";
            this.textBJR8.Leave += new EventHandler(this.textBJR8_Leave);
            this.textBJR7.CharacterCasing = CharacterCasing.Upper;
            this.textBJR7.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR7.Location = new Point(0x195, 60);
            this.textBJR7.MaxLength = 4;
            this.textBJR7.Name = "textBJR7";
            this.textBJR7.Size = new Size(0x34, 0x1a);
            this.textBJR7.TabIndex = 0x58;
            this.textBJR7.Text = "0";
            this.textBJR7.Leave += new EventHandler(this.textBJR7_Leave);
            this.textBJR6.CharacterCasing = CharacterCasing.Upper;
            this.textBJR6.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR6.Location = new Point(0xf6, 0x7c);
            this.textBJR6.MaxLength = 4;
            this.textBJR6.Name = "textBJR6";
            this.textBJR6.Size = new Size(0x34, 0x1a);
            this.textBJR6.TabIndex = 0x57;
            this.textBJR6.Text = "0";
            this.textBJR6.Leave += new EventHandler(this.textBJR6_Leave);
            this.textBJR5.CharacterCasing = CharacterCasing.Upper;
            this.textBJR5.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR5.Location = new Point(0xf6, 0x5c);
            this.textBJR5.MaxLength = 4;
            this.textBJR5.Name = "textBJR5";
            this.textBJR5.Size = new Size(0x34, 0x1a);
            this.textBJR5.TabIndex = 0x56;
            this.textBJR5.Text = "0";
            this.textBJR5.Leave += new EventHandler(this.textBJR5_Leave);
            this.textBJR4.CharacterCasing = CharacterCasing.Upper;
            this.textBJR4.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR4.Location = new Point(0xf6, 60);
            this.textBJR4.MaxLength = 4;
            this.textBJR4.Name = "textBJR4";
            this.textBJR4.Size = new Size(0x34, 0x1a);
            this.textBJR4.TabIndex = 0x55;
            this.textBJR4.Text = "0";
            this.textBJR4.Leave += new EventHandler(this.textBJR4_Leave);
            this.textBJR3.CharacterCasing = CharacterCasing.Upper;
            this.textBJR3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR3.Location = new Point(0x65, 0x7c);
            this.textBJR3.MaxLength = 4;
            this.textBJR3.Name = "textBJR3";
            this.textBJR3.Size = new Size(0x34, 0x1a);
            this.textBJR3.TabIndex = 0x54;
            this.textBJR3.Text = "0";
            this.textBJR3.Leave += new EventHandler(this.textBJR3_Leave);
            this.textBJR2.CharacterCasing = CharacterCasing.Upper;
            this.textBJR2.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR2.Location = new Point(0x65, 0x5c);
            this.textBJR2.MaxLength = 4;
            this.textBJR2.Name = "textBJR2";
            this.textBJR2.Size = new Size(0x34, 0x1a);
            this.textBJR2.TabIndex = 0x53;
            this.textBJR2.Text = "0";
            this.textBJR2.Leave += new EventHandler(this.textBJR2_Leave);
            this.textBJR1.CharacterCasing = CharacterCasing.Upper;
            this.textBJR1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR1.Location = new Point(0x65, 60);
            this.textBJR1.MaxLength = 4;
            this.textBJR1.Name = "textBJR1";
            this.textBJR1.Size = new Size(0x34, 0x1a);
            this.textBJR1.TabIndex = 0x52;
            this.textBJR1.Text = "0";
            this.textBJR1.Leave += new EventHandler(this.textBJR1_Leave);
            this.textBJR0.CharacterCasing = CharacterCasing.Upper;
            this.textBJR0.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textBJR0.Location = new Point(0x65, 0x1d);
            this.textBJR0.MaxLength = 4;
            this.textBJR0.Name = "textBJR0";
            this.textBJR0.Size = new Size(0x34, 0x1a);
            this.textBJR0.TabIndex = 0x4f;
            this.textBJR0.Text = "0";
            this.textBJR0.Leave += new EventHandler(this.textBox1_Leave);
            this.label20.AutoSize = true;
            this.label20.Location = new Point(0x31, 0x44);
            this.label20.Name = "label20";
            this.label20.Size = new Size(0x2e, 13);
            this.label20.TabIndex = 0x51;
            this.label20.Text = "Month 1";
            this.label16.AutoSize = true;
            this.label16.Location = new Point(0x1ee, 0x84);
            this.label16.Name = "label16";
            this.label16.Size = new Size(0x34, 13);
            this.label16.TabIndex = 0x4f;
            this.label16.Text = "Month 12";
            this.label17.AutoSize = true;
            this.label17.Location = new Point(0x1ee, 100);
            this.label17.Name = "label17";
            this.label17.Size = new Size(0x34, 13);
            this.label17.TabIndex = 0x4e;
            this.label17.Text = "Month 11";
            this.label18.AutoSize = true;
            this.label18.Location = new Point(0x1ee, 0x44);
            this.label18.Name = "label18";
            this.label18.Size = new Size(0x34, 13);
            this.label18.TabIndex = 0x4d;
            this.label18.Text = "Month 10";
            this.label19.AutoSize = true;
            this.label19.Location = new Point(0x15d, 0x84);
            this.label19.Name = "label19";
            this.label19.Size = new Size(0x2e, 13);
            this.label19.TabIndex = 0x4c;
            this.label19.Text = "Month 9";
            this.label15.AutoSize = true;
            this.label15.Location = new Point(0x15d, 100);
            this.label15.Name = "label15";
            this.label15.Size = new Size(0x2e, 13);
            this.label15.TabIndex = 0x4b;
            this.label15.Text = "Month 8";
            this.label14.AutoSize = true;
            this.label14.Location = new Point(0x15d, 0x44);
            this.label14.Name = "label14";
            this.label14.Size = new Size(0x2e, 13);
            this.label14.TabIndex = 0x4a;
            this.label14.Text = "Month 7";
            this.label13.AutoSize = true;
            this.label13.Location = new Point(0xc2, 0x84);
            this.label13.Name = "label13";
            this.label13.Size = new Size(0x2e, 13);
            this.label13.TabIndex = 0x49;
            this.label13.Text = "Month 6";
            this.label12.AutoSize = true;
            this.label12.Location = new Point(0xc2, 100);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x2e, 13);
            this.label12.TabIndex = 0x48;
            this.label12.Text = "Month 5";
            this.label11.AutoSize = true;
            this.label11.Location = new Point(0xc2, 0x44);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x2e, 13);
            this.label11.TabIndex = 0x47;
            this.label11.Text = "Month 4";
            this.label10.AutoSize = true;
            this.label10.Location = new Point(0x31, 0x84);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x2e, 13);
            this.label10.TabIndex = 70;
            this.label10.Text = "Month 3";
            this.label9.AutoSize = true;
            this.label9.Location = new Point(0x31, 100);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x2e, 13);
            this.label9.TabIndex = 0x45;
            this.label9.Text = "Month 2";
            this.label7.AutoSize = true;
            this.label7.Location = new Point(0x31, 0x24);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x2e, 13);
            this.label7.TabIndex = 0x44;
            this.label7.Text = "Month 0";
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.lineShape7, this.lineShape6, this.lineShape5, this.lineShape4, this.lineShape3, this.lineShape2, this.lineShape1 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(670, 0xdf);
            this.shapeContainer1.TabIndex = 0x4f;
            this.shapeContainer1.TabStop = false;
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 0x26;
            this.lineShape7.X2 = 0x81;
            this.lineShape7.Y1 = 0xce;
            this.lineShape7.Y2 = 0xce;
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 0x25;
            this.lineShape6.X2 = 0x80;
            this.lineShape6.Y1 = 0xa5;
            this.lineShape6.Y2 = 0xa5;
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 0x27;
            this.lineShape5.X2 = 130;
            this.lineShape5.Y1 = 0x8b;
            this.lineShape5.Y2 = 0x8b;
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 0x25;
            this.lineShape4.X2 = 0x80;
            this.lineShape4.Y1 = 0x74;
            this.lineShape4.Y2 = 0x74;
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 0x25;
            this.lineShape3.X2 = 0x80;
            this.lineShape3.Y1 = 0x5b;
            this.lineShape3.Y2 = 0x5b;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 0x25;
            this.lineShape2.X2 = 0x80;
            this.lineShape2.Y1 = 0x34;
            this.lineShape2.Y2 = 0x34;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 0x25;
            this.lineShape1.X2 = 0x80;
            this.lineShape1.Y1 = 0x19;
            this.lineShape1.Y2 = 0x19;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(670, 0xdf);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.textYP);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.textEstateName);
            base.Controls.Add(this.textEstate);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.button11);
            base.Controls.Add(this.textDiv);
            base.Controls.Add(this.textDivName);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textSAP);
            base.Controls.Add(this.textRemark);
            base.Controls.Add(this.textBlockName);
            base.Controls.Add(this.textBlockCode);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.shapeContainer1);
            base.KeyPreview = true;
            base.Name = "FormBlockEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Entry Block";
            base.Load += new EventHandler(this.FormBlockEntry_Load);
            base.TextChanged += new EventHandler(this.s);
            base.KeyPress += new KeyPressEventHandler(this.FormBlockEntry_KeyPress);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void s(object sender, EventArgs e)
        {
        }

        private void textBJR1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR1);
        }

        private void textBJR10_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR10);
        }

        private void textBJR11_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR11);
        }

        private void textBJR12_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR12);
        }

        private void textBJR2_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR2);
        }

        private void textBJR3_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR3);
        }

        private void textBJR4_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR4);
        }

        private void textBJR5_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR5);
        }

        private void textBJR6_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR6);
        }

        private void textBJR7_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR7);
        }

        private void textBJR8_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR8);
        }

        private void textBJR9_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR9);
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            Program.CheckNumeric(this.textBJR0);
        }

        private void translate()
        {
            this.label1.Text = Resource.Block_004;
            this.label2.Text = Resource.Block_005;
            this.label3.Text = Resource.Contract_030;
            this.label4.Text = Resource.Block_001;
            this.label5.Text = Resource.Block_002;
            this.label6.Text = Resource.Block_006;
            this.label8.Text = Resource.Block_008 + this.sapIDSYS;
            this.groupBox1.Text = Resource.Gbx_BJR_Per_Month;
            this.label7.Text = Resource.ABW_003 + " 0";
            this.label20.Text = Resource.ABW_003 + " 1";
            this.label9.Text = Resource.ABW_003 + " 2";
            this.label10.Text = Resource.ABW_003 + " 3";
            this.label11.Text = Resource.ABW_003 + " 4";
            this.label12.Text = Resource.ABW_003 + " 5";
            this.label13.Text = Resource.ABW_003 + " 6";
            this.label14.Text = Resource.ABW_003 + " 7";
            this.label15.Text = Resource.ABW_003 + " 8";
            this.label19.Text = Resource.ABW_003 + " 9";
            this.label18.Text = Resource.ABW_003 + " 10";
            this.label17.Text = Resource.ABW_003 + " 11";
            this.label16.Text = Resource.ABW_003 + " 12";
            this.button1.Text = Resource.Btn_Save;
            this.button2.Text = Resource.Btn_Cancel;
            this.Text = Resource.Title_Block_Entry;
        }
    }
}

