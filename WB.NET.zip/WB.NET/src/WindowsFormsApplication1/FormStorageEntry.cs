﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormStorageEntry : Form
    {
        public WBTable zTable;
        public string pMode;
        public string OldCode;
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public bool saved = false;
        public bool ReplaceAll = false;
        public DataGridView dataGridView1;
        private IContainer components = null;
        private Button button2;
        private Button button1;
        private TextBox textBox2;
        private Label label2;
        private Label label1;
        public TextBox textBox1;

        public FormStorageEntry()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WBTable table2;
            TextBox[] aText = new TextBox[] { this.textBox1, this.textBox2 };
            if (!Program.CheckEmpty(aText))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_storage", "Select Uniq From wb_storage Where " + WBData.CompanyLocation(" and (storage_Code='" + this.textBox1.Text.Trim() + "')"), WBData.conn);
                if ((table.DT.Rows.Count <= 0) || ((this.pMode != "ADD") && !((this.pMode == "EDIT") & (this.zTable.uniq.Trim() != table.DT.Rows[0]["uniq"].ToString().Trim()))))
                {
                    table.Dispose();
                    Cursor.Current = Cursors.WaitCursor;
                    if ((this.pMode != "EDIT") || (this.textBox1.Text.Trim() == this.OldCode.Trim()))
                    {
                        goto TR_0016;
                    }
                    else
                    {
                        this.nCurrRow = this.zTable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                        table2 = new WBTable();
                        table2.OpenTable("wb_transaction", "Select uniq From wb_transaction where " + WBData.CompanyLocation(" and ( Storage='" + this.zTable.DT.Rows[this.nCurrRow]["Storage_Code"].ToString() + "')"), WBData.conn);
                        Cursor.Current = Cursors.Default;
                        if (table2.DT.Rows.Count <= 0)
                        {
                            goto TR_0017;
                        }
                        else
                        {
                            string[] textArray1 = new string[13];
                            textArray1[0] = Resource.Mes_239;
                            textArray1[1] = " ";
                            textArray1[2] = this.OldCode;
                            textArray1[3] = " -> ";
                            textArray1[4] = this.textBox1.Text;
                            textArray1[5] = "\n\n";
                            textArray1[6] = Resource.Msg_Replace_Warning;
                            textArray1[7] = "  ( ";
                            textArray1[8] = table2.DT.Rows.Count.ToString();
                            textArray1[9] = " ";
                            textArray1[10] = Resource.Mes_Records_In_Transaction;
                            textArray1[11] = " )\n\n";
                            textArray1[12] = Resource.Msg_Continue;
                            if (MessageBox.Show(string.Concat(textArray1), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                this.ReplaceAll = true;
                                goto TR_0017;
                            }
                            else
                            {
                                this.ReplaceAll = false;
                                this.textBox1.Focus();
                            }
                        }
                    }
                }
                else
                {
                    table.Dispose();
                    MessageBox.Show(Resource.Mes_240);
                    this.textBox1.Focus();
                }
            }
            return;
        TR_0016:
            if (this.pMode == "EDIT")
            {
                Cursor.Current = Cursors.Default;
                FormTransCancel cancel = new FormTransCancel {
                    label1 = { Text = Resource.Storage_001 },
                    textRefNo = { Text = this.textBox1.Text },
                    Text = Resource.Title_Change_Reason,
                    label2 = { Text = Resource.Lbl_Change_Reason + " : " }
                };
                cancel.textReason.Focus();
                cancel.ShowDialog();
                if (cancel.Saved)
                {
                    this.changeReason = cancel.textReason.Text;
                    cancel.Dispose();
                }
                else
                {
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            this.zTable.ReOpen();
            if (this.pMode == "ADD")
            {
                this.zTable.DR = this.zTable.DT.NewRow();
            }
            else
            {
                this.zTable.DR = this.zTable.DT.Rows[this.nCurrRow];
                this.logKey = this.zTable.DR["uniq"].ToString();
                this.zTable.DR.BeginEdit();
            }
            this.zTable.DR["Coy"] = WBData.sCoyCode;
            this.zTable.DR["Location_Code"] = WBData.sLocCode;
            this.zTable.DR["Storage_Code"] = this.textBox1.Text;
            this.zTable.DR["Storage_Name"] = this.textBox2.Text;
            if (this.pMode == "ADD")
            {
                this.zTable.DR["Create_By"] = WBUser.UserID;
                this.zTable.DR["Create_Date"] = DateTime.Now;
                this.zTable.DT.Rows.Add(this.zTable.DR);
            }
            else
            {
                this.zTable.DR["Change_By"] = WBUser.UserID;
                this.zTable.DR["Change_Date"] = DateTime.Now;
                this.zTable.DR.EndEdit();
            }
            this.zTable.Save();
            if ((this.pMode == "ADD") || (this.pMode == "EDIT"))
            {
                if (this.pMode == "ADD")
                {
                    WBTable table3 = new WBTable();
                    table3.OpenTable("wb_storage", "SELECT uniq FROM wb_storage WHERE " + WBData.CompanyLocation(" AND storage_code = '" + this.textBox1.Text + "'"), WBData.conn);
                    this.logKey = table3.DT.Rows[0]["uniq"].ToString();
                    table3.Dispose();
                }
                string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                Program.updateLogHeader("wb_storage", this.logKey, logField, logValue);
            }
            if ((this.pMode == "EDIT") && this.ReplaceAll)
            {
                string[] aField = new string[] { "Storage" };
                string[] aNewValue = new string[] { this.textBox1.Text };
                Program.ReplaceAll("wb_transaction", aField, aNewValue, " Storage ='" + this.OldCode.Trim() + "'", this.changeReason + " (Edit storage master data)");
            }
            Cursor.Current = Cursors.Default;
            this.saved = true;
            base.Close();
            return;
        TR_0017:
            table2.Dispose();
            goto TR_0016;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormStorageEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormStorageEntry_Load(object sender, EventArgs e)
        {
            base.KeyPreview = true;
            if (this.dataGridView1.Rows.Count > 0)
            {
                if (this.pMode != "ADD")
                {
                    this.textBox1.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Storage_Code"].Value.ToString();
                    this.OldCode = this.textBox1.Text;
                    this.textBox2.Text = this.dataGridView1.Rows[this.zTable.dataGridPosRow].Cells["Storage_Name"].Value.ToString();
                }
                if (this.pMode == "VIEW")
                {
                    foreach (Control control in base.Controls)
                    {
                        control.Enabled = false;
                    }
                    this.button2.Text = Resource.Btn_Close;
                    this.button2.Enabled = true;
                }
                if (this.pMode == "EDIT")
                {
                    this.textBox1.ReadOnly = true;
                }
            }
        }

        private void InitializeComponent()
        {
            this.button2 = new Button();
            this.button1 = new Button();
            this.textBox2 = new TextBox();
            this.textBox1 = new TextBox();
            this.label2 = new Label();
            this.label1 = new Label();
            base.SuspendLayout();
            this.button2.Location = new Point(430, 0x48);
            this.button2.Name = "button2";
            this.button2.Size = new Size(0x4b, 0x17);
            this.button2.TabIndex = 0x40;
            this.button2.Text = "&Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Location = new Point(0x14b, 0x48);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x4b, 0x17);
            this.button1.TabIndex = 0x3e;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBox2.Location = new Point(0x65, 0x26);
            this.textBox2.MaxLength = 50;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x194, 20);
            this.textBox2.TabIndex = 60;
            this.textBox1.CharacterCasing = CharacterCasing.Upper;
            this.textBox1.Location = new Point(0x65, 12);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0xa5, 20);
            this.textBox1.TabIndex = 0x3b;
            this.label2.Location = new Point(12, 0x29);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x53, 13);
            this.label2.TabIndex = 0x42;
            this.label2.Text = "Storage Name";
            this.label2.TextAlign = ContentAlignment.MiddleRight;
            this.label1.Location = new Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x53, 13);
            this.label1.TabIndex = 0x41;
            this.label1.Text = "Storage Code";
            this.label1.TextAlign = ContentAlignment.MiddleRight;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x209, 110);
            base.ControlBox = false;
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Name = "FormStorageEntry";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "FormStorageEntry";
            base.Load += new EventHandler(this.FormStorageEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormStorageEntry_KeyPress);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void translate()
        {
            this.label1.Text = Resource.Storage_001;
            this.label2.Text = Resource.Storage_002;
            this.button1.Text = Resource.Save;
            this.button2.Text = Resource.Menu_Cancel;
        }
    }
}

