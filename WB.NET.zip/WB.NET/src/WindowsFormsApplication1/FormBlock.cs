﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormBlock : Form
    {
        private int idxFind = 0;
        public string pMode = "";
        public string pSQLtext = "";
        public string changeReason = "";
        public string logKey = "";
        public int nCurrRow;
        public WBTable ztable = new WBTable();
        public DataRow ReturnRow;
        public string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private DataGridView dataGridView1;
        public MenuStrip menuStrip1;
        public ToolStripMenuItem activitiesToolStripMenuItem;
        private ToolStripMenuItem addNewRecordToolStripMenuItem;
        private ToolStripMenuItem editRecordToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem printToolStripMenuItem;
        public ToolStripMenuItem closeToolStripMenuItem;
        public TextBox TextFind;
        public Button buttonFind;
        public Panel panel1;
        private ToolStripMenuItem chooseStripMenuItem1;
        private ToolStripMenuItem viewRecordToolStripMenuItem;

        public FormBlock()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void addNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormBlockEntry entry = new FormBlockEntry {
                    pMode = "ADD",
                    zTable = this.ztable,
                    Text = Resource.Title_Add_Block,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                    string[] aField = new string[] { "block_code" };
                    string[] aFind = new string[] { entry.textBlockCode.Text };
                    this.ztable.SetCursor(this.dataGridView1, this.ztable.GetCurrentRow(this.dataGridView1, aField, aFind));
                }
                this.ztable.UnLock();
                entry.Dispose();
                if (this.dataGridView1.RowCount > 0)
                {
                    this.viewRecordToolStripMenuItem.Enabled = true;
                    this.editRecordToolStripMenuItem.Enabled = true;
                    this.deleteToolStripMenuItem.Enabled = true;
                    this.printToolStripMenuItem.Enabled = true;
                    this.chooseStripMenuItem1.Enabled = true;
                }
            }
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            this.idxFind = this.ztable.NextFindSql(this.dataGridView1, this.TextFind.Text, this.idxFind);
        }

        private void chooseStripMenuItem1_Click(object sender, EventArgs e)
        {
            string[] aField = new string[] { "uniq" };
            string[] aFind = new string[] { this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString() };
            this.nCurrRow = this.ztable.GetRecNo(aField, aFind);
            this.ReturnRow = this.ztable.DT.Rows[this.nCurrRow];
            base.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.chooseStripMenuItem1.PerformClick();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Enter) && (this.pMode == "CHOOSE"))
            {
                this.chooseStripMenuItem1.PerformClick();
            }
        }

        private void dataGridView1_SortCompare(object sender, DataGridViewSortCompareEventArgs e)
        {
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "DELETE"))
            {
                this.nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString());
                WBTable table = new WBTable();
                string[] textArray1 = new string[] { " AND (Division_Code='", this.ztable.DT.Rows[this.nCurrRow]["Division_Code"].ToString(), "') and (Block_Code='", this.ztable.DT.Rows[this.nCurrRow]["Block_Code"].ToString(), "')" };
                table.OpenTable("wb_transDivision", "Select Ref,Block_Code From wb_transDivision where " + WBData.CompanyLocation(string.Concat(textArray1)), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    string[] textArray3 = new string[9];
                    textArray3[0] = this.ztable.DT.Rows[this.nCurrRow]["Division_Code"].ToString();
                    textArray3[1] = " - ";
                    textArray3[2] = this.ztable.DT.Rows[this.nCurrRow]["Division_Name"].ToString();
                    textArray3[3] = "\n";
                    textArray3[4] = this.ztable.DT.Rows[this.nCurrRow]["Block_Code"].ToString();
                    textArray3[5] = " - ";
                    textArray3[6] = this.ztable.DT.Rows[this.nCurrRow]["Block_Name"].ToString();
                    textArray3[7] = ".\n\n";
                    textArray3[8] = Resource.Mes_006;
                    if (MessageBox.Show(string.Concat(textArray3), Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        FormTransCancel cancel = new FormTransCancel {
                            label1 = { Text = Resource.Block_004 },
                            textRefNo = { Text = this.ztable.DT.Rows[this.nCurrRow]["Block_Code"].ToString() },
                            Text = Resource.Form_Delete_Reason,
                            label2 = { Text = Resource.Lbl_Delete_Reason }
                        };
                        cancel.textReason.Focus();
                        cancel.ShowDialog();
                        if (cancel.Saved)
                        {
                            this.changeReason = cancel.textReason.Text;
                            cancel.Dispose();
                            this.ztable.ReOpen();
                            this.logKey = this.ztable.DT.Rows[this.nCurrRow]["uniq"].ToString();
                            this.ztable.DT.Rows[this.nCurrRow].Delete();
                            this.ztable.Save();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "DELETE", WBUser.UserID, this.changeReason };
                            Program.updateLogHeader("wb_block", this.logKey, logField, logValue);
                            this.ztable.ReOpen();
                            this.ztable.AfterEdit("DELETE");
                        }
                        else
                        {
                            return;
                        }
                    }
                    this.ztable.UnLock();
                    table.Dispose();
                    if (this.dataGridView1.RowCount == 0)
                    {
                        this.viewRecordToolStripMenuItem.Enabled = false;
                        this.editRecordToolStripMenuItem.Enabled = false;
                        this.deleteToolStripMenuItem.Enabled = false;
                        this.printToolStripMenuItem.Enabled = false;
                        this.chooseStripMenuItem1.Enabled = false;
                    }
                }
                else
                {
                    string[] textArray2 = new string[] { Resource.Mes_013, "\n ( ", table.DT.Rows.Count.ToString(), " ", Resource.Mes_047B, ")" };
                    MessageBox.Show(string.Concat(textArray2), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    table.Dispose();
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ztable.BeforeEdit(this.dataGridView1, "EDIT"))
            {
                FormBlockEntry entry = new FormBlockEntry {
                    pMode = "EDIT",
                    zTable = this.ztable,
                    Text = Resource.Title_Edit_Block,
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                if (entry.saved)
                {
                    this.ztable.ReOpen();
                    this.dataGridView1 = this.ztable.AfterEdit(entry.pMode);
                }
                this.ztable.UnLock();
                entry.Dispose();
            }
        }

        private void FormBlock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormBlock_Load(object sender, EventArgs e)
        {
            string str = "Coy,Location_Code,Estate_Code,Division_Code,Division_Name,Block_Code,Block_Name,YearPlanting,Remark,SAP_Code,Create_By,Create_Date,Change_By,Change_Date,Delete_By,Delete_Date,Deleted,BJR0,BJR1,BJR2,BJR3,BJR4,BJR5,BJR6,BJR7,BJR8,BJR9,BJR10,BJR11,BJR12,token,uniq, completed";
            string sqltext = "SELECT " + str + " FROM wb_block ";
            if (this.pSQLtext != "")
            {
                sqltext = this.pSQLtext;
            }
            this.ztable.OpenTable("wb_block", sqltext, WBData.conn);
            this.dataGridView1.DataSource = this.ztable.DT;
            this.dataGridView1.Sort(this.dataGridView1.Columns["Division_Code"], ListSortDirection.Ascending);
            this.dataGridView1.Columns["Coy"].Visible = false;
            this.dataGridView1.Columns["Location_Code"].Visible = false;
            this.dataGridView1.Columns["Delete_By"].Visible = false;
            this.dataGridView1.Columns["Delete_Date"].Visible = false;
            this.dataGridView1.Columns["uniq"].Visible = false;
            this.dataGridView1.Columns["deleted"].Visible = false;
            this.dataGridView1.Columns["token"].Visible = true;
            this.dataGridView1.Columns["completed"].Visible = true;
            this.dataGridView1.Columns["Estate_Code"].HeaderText = Resource.Block_001;
            this.dataGridView1.Columns["Division_Code"].HeaderText = Resource.Block_002;
            this.dataGridView1.Columns["Division_Name"].HeaderText = Resource.Block_003;
            this.dataGridView1.Columns["Block_Code"].HeaderText = Resource.Block_004;
            this.dataGridView1.Columns["Block_Name"].HeaderText = Resource.Block_005;
            this.dataGridView1.Columns["YearPlanting"].HeaderText = Resource.Block_006;
            this.dataGridView1.Columns["Remark"].HeaderText = Resource.Block_007;
            this.dataGridView1.Columns["SAP_Code"].HeaderText = Resource.Block_008 + this.sapIDSYS;
            base.KeyPreview = true;
            if (!WBUser.CheckTrustee("MD_BLOCK", "A"))
            {
                this.addNewRecordToolStripMenuItem.Enabled = false;
            }
            if (WBSetting.Field("GM") == "Y")
            {
                this.editRecordToolStripMenuItem.Enabled = true;
                this.deleteToolStripMenuItem.Enabled = true;
            }
            else
            {
                if (!WBUser.CheckTrustee("MD_BLOCK", "E"))
                {
                    this.editRecordToolStripMenuItem.Enabled = false;
                }
                if (!WBUser.CheckTrustee("MD_BLOCK", "D"))
                {
                    this.deleteToolStripMenuItem.Enabled = false;
                }
            }
            if (!WBUser.CheckTrustee("MD_BLOCK", "P"))
            {
                this.printToolStripMenuItem.Enabled = false;
            }
            this.chooseStripMenuItem1.Visible = this.pMode != "";
            if (this.dataGridView1.RowCount == 0)
            {
                this.viewRecordToolStripMenuItem.Enabled = false;
                this.editRecordToolStripMenuItem.Enabled = false;
                this.deleteToolStripMenuItem.Enabled = false;
                this.printToolStripMenuItem.Enabled = false;
                this.chooseStripMenuItem1.Enabled = false;
            }
        }

        private void InitializeComponent()
        {
            this.dataGridView1 = new DataGridView();
            this.menuStrip1 = new MenuStrip();
            this.activitiesToolStripMenuItem = new ToolStripMenuItem();
            this.addNewRecordToolStripMenuItem = new ToolStripMenuItem();
            this.editRecordToolStripMenuItem = new ToolStripMenuItem();
            this.deleteToolStripMenuItem = new ToolStripMenuItem();
            this.printToolStripMenuItem = new ToolStripMenuItem();
            this.chooseStripMenuItem1 = new ToolStripMenuItem();
            this.closeToolStripMenuItem = new ToolStripMenuItem();
            this.TextFind = new TextBox();
            this.buttonFind = new Button();
            this.panel1 = new Panel();
            this.viewRecordToolStripMenuItem = new ToolStripMenuItem();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            base.SuspendLayout();
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = DockStyle.Fill;
            this.dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new Point(0, 0x18);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new Size(0x337, 0x164);
            this.dataGridView1.TabIndex = 0x10;
            this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            this.dataGridView1.SortCompare += new DataGridViewSortCompareEventHandler(this.dataGridView1_SortCompare);
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            this.menuStrip1.BackColor = Color.LightSteelBlue;
            ToolStripItem[] toolStripItems = new ToolStripItem[] { this.activitiesToolStripMenuItem, this.chooseStripMenuItem1, this.closeToolStripMenuItem };
            this.menuStrip1.Items.AddRange(toolStripItems);
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(0x337, 0x18);
            this.menuStrip1.TabIndex = 0x12;
            this.menuStrip1.Text = "menuStrip1";
            ToolStripItem[] itemArray2 = new ToolStripItem[] { this.addNewRecordToolStripMenuItem, this.viewRecordToolStripMenuItem, this.editRecordToolStripMenuItem, this.deleteToolStripMenuItem, this.printToolStripMenuItem };
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(itemArray2);
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new Size(0x43, 20);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.addNewRecordToolStripMenuItem.Name = "addNewRecordToolStripMenuItem";
            this.addNewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.addNewRecordToolStripMenuItem.Text = "Add New Record";
            this.addNewRecordToolStripMenuItem.Click += new EventHandler(this.addNewRecordToolStripMenuItem_Click);
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new EventHandler(this.editRecordToolStripMenuItem_Click);
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new EventHandler(this.deleteToolStripMenuItem_Click);
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.printToolStripMenuItem.Text = "Print";
            this.chooseStripMenuItem1.Name = "chooseStripMenuItem1";
            this.chooseStripMenuItem1.Size = new Size(0x3b, 20);
            this.chooseStripMenuItem1.Text = "Choose";
            this.chooseStripMenuItem1.Click += new EventHandler(this.chooseStripMenuItem1_Click);
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new Size(0x30, 20);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new EventHandler(this.closeToolStripMenuItem_Click);
            this.TextFind.Location = new Point(5, 4);
            this.TextFind.Name = "TextFind";
            this.TextFind.Size = new Size(0xb8, 20);
            this.TextFind.TabIndex = 3;
            this.TextFind.TextChanged += new EventHandler(this.TextFind_TextChanged);
            this.TextFind.KeyPress += new KeyPressEventHandler(this.TextFind_KeyPress);
            this.buttonFind.Location = new Point(0xc3, 3);
            this.buttonFind.Name = "buttonFind";
            this.buttonFind.Size = new Size(0x4b, 0x17);
            this.buttonFind.TabIndex = 4;
            this.buttonFind.Text = "Find";
            this.buttonFind.UseVisualStyleBackColor = true;
            this.buttonFind.Click += new EventHandler(this.buttonFind_Click);
            this.panel1.BackColor = Color.LightSteelBlue;
            this.panel1.Controls.Add(this.TextFind);
            this.panel1.Controls.Add(this.buttonFind);
            this.panel1.Dock = DockStyle.Bottom;
            this.panel1.Location = new Point(0, 380);
            this.panel1.Name = "panel1";
            this.panel1.Size = new Size(0x337, 0x21);
            this.panel1.TabIndex = 0x11;
            this.viewRecordToolStripMenuItem.Name = "viewRecordToolStripMenuItem";
            this.viewRecordToolStripMenuItem.Size = new Size(0xa3, 0x16);
            this.viewRecordToolStripMenuItem.Text = "View Record";
            this.viewRecordToolStripMenuItem.Click += new EventHandler(this.viewRecordToolStripMenuItem_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x337, 0x19d);
            base.ControlBox = false;
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.menuStrip1);
            base.Controls.Add(this.panel1);
            base.KeyPreview = true;
            base.Name = "FormBlock";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = " Form Block Entry";
            base.Load += new EventHandler(this.FormBlock_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormBlock_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void TextFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.buttonFind.PerformClick();
            }
        }

        private void TextFind_TextChanged(object sender, EventArgs e)
        {
            this.idxFind = 0;
        }

        private void translate()
        {
            this.activitiesToolStripMenuItem.Text = Resource.Menu_Activities;
            this.chooseStripMenuItem1.Text = Resource.Menu_Choose;
            this.closeToolStripMenuItem.Text = Resource.Menu_Close;
            this.viewRecordToolStripMenuItem.Text = Resource.Menu_View;
            this.addNewRecordToolStripMenuItem.Text = Resource.Menu_Add;
            this.editRecordToolStripMenuItem.Text = Resource.Menu_Edit;
            this.deleteToolStripMenuItem.Text = Resource.Menu_Delete;
            this.printToolStripMenuItem.Text = Resource.Menu_016;
            this.buttonFind.Text = Resource.Menu_Find;
            this.Text = Resource.Title_Block;
        }

        private void viewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.dataGridView1.Rows.Count > 0) && this.ztable.BeforeEdit(this.dataGridView1, "ADD"))
            {
                FormBlockEntry entry = new FormBlockEntry {
                    pMode = "VIEW",
                    zTable = this.ztable,
                    Text = Resource.Title_View_Block,
                    nCurrRow = this.ztable.GetPosRec(this.dataGridView1.CurrentRow.Cells["uniq"].Value.ToString()),
                    dataGridView1 = this.dataGridView1
                };
                entry.ShowDialog();
                this.ztable.UnLock();
                entry.Dispose();
            }
        }
    }
}

