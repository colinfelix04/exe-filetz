﻿namespace WindowsFormsApplication1
{
    using SAP.Middleware.Connector;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Africa;

    public class FormMarkAccident : Form
    {
        public string mode = "";
        public string logKey = "";
        public WBTable t_token = new WBTable();
        public WBTable t_trans = new WBTable();
        public WBTable t_transdo = new WBTable();
        public WBTable t_do = new WBTable();
        public WBTable sh_contract = new WBTable();
        public string[,] map = new string[0x3e7, 20];
        private bool can_search = false;
        private bool do_besar = false;
        private int count = 0;
        private IRfcTable ISReturn_Table;
        private string sapIDSYS = (WBSetting.integrationIDSYS ? Resource.IDSYS : Resource.SAP);
        private IContainer components = null;
        private GroupBox gb_filter;
        private GroupBox gb_method;
        private RadioButton radio_sap;
        private RadioButton radio_manual;
        public Button sh_do_no;
        public TextBox text_do;
        private Label label1;
        private Button btn_search;
        private DataGridView dgv_trans;
        private Button btn_process;
        private Button btn_cancel;
        private CachedTicketPOMAfrica cachedTicketPOMAfrica1;

        public FormMarkAccident()
        {
            this.InitializeComponent();
        }

        private void brn_process_Click(object sender, EventArgs e)
        {
            if (this.radio_manual.Checked)
            {
                int num = 0;
                int num2 = 0;
                while (true)
                {
                    if (num2 < this.dgv_trans.Rows.Count)
                    {
                        if (Convert.ToBoolean(this.dgv_trans.Rows[num2].Cells["select"].Value))
                        {
                            num++;
                        }
                        num2++;
                        continue;
                    }
                    if (num != 0)
                    {
                        int num3 = 0;
                        while (true)
                        {
                            if (num3 >= this.dgv_trans.Rows.Count)
                            {
                                break;
                            }
                            if (!(Convert.ToBoolean(this.dgv_trans.Rows[num3].Cells["select"].Value) && (this.dgv_trans.Rows[num3].Cells["accident_reason"].Value.ToString() == "")))
                            {
                                num3++;
                                continue;
                            }
                            MessageBox.Show("Please fill accident reason", "WARNING");
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select record(s) to be marked as accident", "WARNING");
                        return;
                    }
                    break;
                }
            }
            int num4 = 0;
            while (true)
            {
                if (num4 >= this.dgv_trans.Rows.Count)
                {
                    base.Close();
                    break;
                }
                if (Convert.ToBoolean(this.dgv_trans.Rows[num4].Cells["select"].Value))
                {
                    string str = this.dgv_trans.Rows[num4].Cells["REF"].Value.ToString().Trim();
                    this.t_trans.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND Ref = '" + str + "'"), WBData.conn);
                    this.t_trans.DR = this.t_trans.DT.Rows[0];
                    this.logKey = this.t_trans.DR["uniq"].ToString();
                    this.t_trans.DR.BeginEdit();
                    this.t_trans.DR["mark_accident"] = 'X';
                    this.t_trans.DR["accident_reason"] = this.dgv_trans.Rows[num4].Cells["accident_reason"].Value.ToString().Trim();
                    this.t_trans.DR["Edit_By"] = WBUser.UserID;
                    this.t_trans.DR["Edit_Date"] = DateTime.Now;
                    this.t_trans.DR["checksum"] = this.t_trans.Checksum(this.t_trans.DR);
                    this.t_trans.DR.EndEdit();
                    this.t_trans.Save();
                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                    string[] logValue = new string[] { "EDIT", WBUser.UserID, "Mark Accident" };
                    Program.updateLogHeader("wb_transaction", this.logKey, logField, logValue);
                }
                num4++;
            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            this.t_do.OpenTable("wb_contract", "SELECT * FROM wb_contract WHERE " + WBData.CompanyLocation(" AND do_no = '" + this.text_do.Text + "'"), WBData.conn);
            if (this.t_do.DT.Rows.Count != 0)
            {
                if (!this.radio_manual.Checked)
                {
                    if (this.radio_sap.Checked)
                    {
                        try
                        {
                            WBSetting.OpenSetting();
                            this.can_search = WBSAP.connect();
                        }
                        catch
                        {
                            this.can_search = false;
                        }
                    }
                }
                else if (WBSetting.Field("GM") == "Y")
                {
                    this.can_search = true;
                }
                else
                {
                    string[] strArray = new string[3];
                    strArray = Program.fillApproval("Mark Accident", "", "");
                    string str2 = strArray[1];
                    string str3 = strArray[2];
                    if (strArray[0] == "N")
                    {
                        MessageBox.Show("This Transaction is not approved.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        this.can_search = true;
                    }
                }
            }
            else
            {
                MessageBox.Show("Invalid DO No!\nPlease check DO No.", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return;
            }
            if (this.can_search)
            {
                this.gb_filter.Enabled = false;
                this.btn_process.Enabled = true;
                string sqltext = "";
                sqltext = (("SELECT a.ref, a.do_sap, a.do_sap_item, b.uniq, b.token, b.completed FROM wb_transDO a LEFT JOIN wb_transaction b ON a.ref = b.ref WHERE a.do_no = '" + this.text_do.Text + "' ") + " AND (b.mark_accident IS NULL) AND (b.Deleted IS NULL) AND (b.Report_Date IS NOT NULL) OR") + "(b.mark_accident = '') AND (b.Deleted = '')" + " ORDER BY a.ref";
                this.t_transdo.OpenTable("wb_transdo", sqltext, WBData.conn);
                if (this.radio_manual.Checked)
                {
                    this.btn_process.Enabled = false;
                    DataGridViewCheckBoxColumn dataGridViewColumn = new DataGridViewCheckBoxColumn {
                        ValueType = typeof(bool),
                        Name = "SELECT",
                        HeaderText = "Select"
                    };
                    this.dgv_trans.Columns.Add(dataGridViewColumn);
                    this.dgv_trans.ColumnCount = 9;
                    this.dgv_trans.Columns[1].Name = "REF";
                    this.dgv_trans.Columns[1].HeaderText = "Ref No";
                    this.dgv_trans.Columns[1].ReadOnly = true;
                    this.dgv_trans.Columns[2].Name = "DO_SAP";
                    this.dgv_trans.Columns[2].HeaderText = "DO " + this.sapIDSYS;
                    this.dgv_trans.Columns[2].ReadOnly = true;
                    this.dgv_trans.Columns[3].Name = "DO_SAP_ITEM";
                    this.dgv_trans.Columns[3].HeaderText = "Item";
                    this.dgv_trans.Columns[3].ReadOnly = true;
                    this.dgv_trans.Columns[4].Name = "accident_reason";
                    this.dgv_trans.Columns[4].HeaderText = "Accident Reason";
                    this.dgv_trans.Columns[5].Name = "REASON_DESC";
                    this.dgv_trans.Columns[5].HeaderText = "Reason Description";
                    this.dgv_trans.Columns[5].ReadOnly = true;
                    this.dgv_trans.Columns[6].Name = "UNIQ";
                    this.dgv_trans.Columns[6].HeaderText = "Uniq";
                    this.dgv_trans.Columns[6].Visible = false;
                    this.dgv_trans.Columns[7].Name = "token";
                    this.dgv_trans.Columns[7].HeaderText = "Token";
                    this.dgv_trans.Columns[7].Visible = false;
                    this.dgv_trans.Columns[8].Name = "completed";
                    this.dgv_trans.Columns[8].HeaderText = "Completed";
                    this.dgv_trans.Columns[8].Visible = false;
                    int num = 0;
                    foreach (DataRow row in this.t_transdo.DT.Rows)
                    {
                        this.dgv_trans.Rows.Add();
                        if (this.radio_sap.Checked)
                        {
                            this.dgv_trans.Rows[num].Cells["select"].Value = true;
                        }
                        this.dgv_trans.Rows[num].Cells["ref"].Value = row["ref"].ToString();
                        this.dgv_trans.Rows[num].Cells["do_sap"].Value = row["do_sap"].ToString();
                        this.dgv_trans.Rows[num].Cells["do_sap_item"].Value = row["do_sap_item"].ToString();
                        this.dgv_trans.Rows[num].Cells["accident_reason"].Value = "";
                        this.dgv_trans.Rows[num].Cells["reason_desc"].Value = "";
                        this.dgv_trans.Rows[num].Cells["uniq"].Value = row["uniq"].ToString();
                        this.dgv_trans.Rows[num].Cells["token"].Value = row["token"].ToString();
                        this.dgv_trans.Rows[num].Cells["completed"].Value = row["completed"].ToString();
                        num++;
                    }
                    if (WBSetting.Field("GM") == "Y")
                    {
                        sqltext = (("SELECT b.ref, b.uniq FROM wb_transDO a LEFT JOIN wb_transaction b ON a.ref = b.ref WHERE a.do_no = '" + this.text_do.Text + "' ") + " AND (b.mark_accident IS NULL) AND (b.Deleted IS NULL) AND (b.Report_Date IS NOT NULL) OR") + " (b.mark_accident = '') AND (b.Deleted = '')" + " ORDER BY a.ref";
                        this.t_transdo.OpenTable("wb_transaction", sqltext, WBData.conn);
                        if (this.t_transdo.BeforeEdit(this.dgv_trans, "MARK_ACCIDENT"))
                        {
                            this.btn_process.Enabled = true;
                        }
                    }
                }
                else if (this.radio_sap.Checked)
                {
                    foreach (DataRow row2 in this.t_transdo.DT.Rows)
                    {
                        WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_DNET_CHECK_SO_DO");
                        string str5 = this.t_do.DT.Rows[0]["so"].ToString();
                        string str6 = this.t_do.DT.Rows[0]["so_item"].ToString();
                        WBSAP.rfcFunction.SetValue("SO_NO", str5.Trim());
                        WBSAP.rfcFunction.SetValue("SO_ITEM", str6.Trim());
                        WBSAP.rfcFunction.SetValue("DO_NO", row2["do_sap"].ToString().Trim());
                        WBSAP.rfcFunction.SetValue("DO_ITEM", row2["do_sap_item"].ToString().Trim());
                        WBSAP.rfcFunction.SetValue("MARK_ACCIDENT", "X");
                        WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                        this.ISReturn_Table = WBSAP.rfcFunction.GetTable("DO_DETAILS");
                        int num2 = 0;
                        while (true)
                        {
                            if (num2 >= this.ISReturn_Table.RowCount)
                            {
                                if (this.count == 0)
                                {
                                    sqltext = "SELECT ref, do_sap, do_sap_item FROM wb_transDO WHERE 1 = 2 ORDER BY ref";
                                    this.t_transdo.OpenTable("wb_transdo", sqltext, WBData.conn);
                                    MessageBox.Show("No DO is marked as accident.\nPlease check again.\nThank you.", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                }
                                else if (this.count > 0)
                                {
                                    sqltext = "SELECT a.ref, a.do_sap, a.do_sap_item FROM wb_transDO a LEFT JOIN wb_transaction b ON a.ref = b.ref WHERE ";
                                    int num4 = 0;
                                    while (true)
                                    {
                                        if (num4 >= this.count)
                                        {
                                            sqltext = (sqltext + " AND (b.mark_accident IS NULL) AND (b.Deleted IS NULL) AND (b.Report_Date IS NOT NULL) OR") + "(b.mark_accident = '') AND (b.Deleted = '')" + " ORDER BY a.ref";
                                            this.t_transdo.OpenTable("wb_transdo", sqltext, WBData.conn);
                                            break;
                                        }
                                        if (num4 != 0)
                                        {
                                            sqltext = sqltext + " OR ";
                                        }
                                        sqltext = sqltext + " (do_sap = '" + this.map[num4, 0] + "')";
                                        num4++;
                                    }
                                }
                                break;
                            }
                            if (this.ISReturn_Table[num2].GetString(8).Trim() == "X")
                            {
                                this.count++;
                                int index = 0;
                                while (true)
                                {
                                    if (index >= 11)
                                    {
                                        break;
                                    }
                                    this.map[num2, index] = this.ISReturn_Table[num2].GetString(index).Trim();
                                    index++;
                                }
                            }
                            if (this.ISReturn_Table[num2].GetString(7).Trim() == "X")
                            {
                                this.do_besar = true;
                                this.map[num2, 0x12] = row2["do_sap"].ToString().Trim();
                                this.map[num2, 0x13] = row2["do_sap_item"].ToString().Trim();
                            }
                            num2++;
                        }
                    }
                    if (this.do_besar)
                    {
                        DataGridViewCheckBoxColumn dataGridViewColumn = new DataGridViewCheckBoxColumn {
                            ValueType = typeof(bool),
                            Name = "SELECT",
                            HeaderText = "Select"
                        };
                        this.dgv_trans.Columns.Add(dataGridViewColumn);
                        this.dgv_trans.ColumnCount = 6;
                        this.dgv_trans.Columns[1].Name = "DO_BESAR";
                        this.dgv_trans.Columns[1].HeaderText = "DO " + this.sapIDSYS + " Besar";
                        this.dgv_trans.Columns[2].Name = "DO_BESAR_ITEM";
                        this.dgv_trans.Columns[2].HeaderText = "Item DO Besar";
                        this.dgv_trans.Columns[3].Name = "DO_KECIL";
                        this.dgv_trans.Columns[3].HeaderText = "DO " + this.sapIDSYS + " Kecil";
                        this.dgv_trans.Columns[4].Name = "DO_KECIL_ITEM";
                        this.dgv_trans.Columns[4].HeaderText = "Item DO Kecil";
                        this.dgv_trans.Columns[5].Name = "DO_KECIL_ITEM";
                        this.dgv_trans.Columns[5].HeaderText = "Item DO Kecil";
                        this.dgv_trans.Columns[6].Name = "accident_reason";
                        this.dgv_trans.Columns[6].HeaderText = "Accident Reason";
                        this.dgv_trans.Columns[7].Name = "REASON_DESC";
                        this.dgv_trans.Columns[7].HeaderText = "Reason Description";
                        this.dgv_trans.Columns[8].Name = "Ref";
                        this.dgv_trans.Columns[8].HeaderText = "Ref";
                        this.dgv_trans.Columns[8].ReadOnly = false;
                    }
                    else
                    {
                        DataGridViewCheckBoxColumn dataGridViewColumn = new DataGridViewCheckBoxColumn {
                            ValueType = typeof(bool),
                            Name = "SELECT",
                            HeaderText = "Select"
                        };
                        this.dgv_trans.Columns.Add(dataGridViewColumn);
                        this.dgv_trans.ColumnCount = 6;
                        this.dgv_trans.Columns[1].Name = "REF";
                        this.dgv_trans.Columns[1].HeaderText = "Ref No";
                        this.dgv_trans.Columns[2].Name = "DO_SAP";
                        this.dgv_trans.Columns[2].HeaderText = "DO " + this.sapIDSYS;
                        this.dgv_trans.Columns[3].Name = "DO_SAP_ITEM";
                        this.dgv_trans.Columns[3].HeaderText = "Item";
                        this.dgv_trans.Columns[4].Name = "accident_reason";
                        this.dgv_trans.Columns[4].HeaderText = "Accident Reason";
                        this.dgv_trans.Columns[5].Name = "REASON_DESC";
                        this.dgv_trans.Columns[5].HeaderText = "Reason Description";
                        int num5 = 0;
                        foreach (DataRow row3 in this.t_transdo.DT.Rows)
                        {
                            this.dgv_trans.Rows.Add();
                            if (this.radio_sap.Checked)
                            {
                                this.dgv_trans.Rows[num5].Cells["select"].Value = true;
                            }
                            this.dgv_trans.Rows[num5].Cells["ref"].Value = row3["ref"].ToString();
                            this.dgv_trans.Rows[num5].Cells["do_sap"].Value = row3["do_sap"].ToString();
                            this.dgv_trans.Rows[num5].Cells["do_sap_item"].Value = row3["do_sap_item"].ToString();
                            int num6 = 0;
                            while (true)
                            {
                                if (num6 >= this.count)
                                {
                                    num5++;
                                    break;
                                }
                                if (this.map[num6, 0] == row3["do_sap"].ToString())
                                {
                                    this.dgv_trans.Rows[num5].Cells["accident_reason"].Value = this.map[num6, 9];
                                    this.dgv_trans.Rows[num5].Cells["reason_desc"].Value = this.map[num6, 10];
                                }
                                num6++;
                            }
                        }
                    }
                }
            }
        }

        private void dgv_trans_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (!this.radio_sap.Checked)
            {
                int columnIndex = this.dgv_trans.CurrentCell.ColumnIndex;
                if (this.dgv_trans.Columns[columnIndex].Name.ToUpper() == "SELECT".ToUpper())
                {
                    this.dgv_trans.CurrentCell.Value = !Convert.ToBoolean(this.dgv_trans.CurrentCell.Value);
                }
            }
        }

        private void dgv_trans_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormMarkAccident_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormMarkAccident_Load(object sender, EventArgs e)
        {
            if (WBSetting.IntegrationSAP == "Y")
            {
                this.radio_sap.Checked = true;
            }
            else
            {
                this.radio_manual.Checked = true;
            }
            this.t_token.OpenTable("wb_token", "SELECT * from wb_token where 1 = 2", WBData.conn);
            this.sh_contract.OpenTable("wb_contract", "SELECT do_no FROM wb_contract WHERE " + WBData.CompanyLocation(" and (closed is null or closed <> 'X' or closed = 'N')"), WBData.conn);
            Program.AutoComp(this.sh_contract, "do_no", this.text_do);
        }

        private void InitializeComponent()
        {
            this.gb_filter = new GroupBox();
            this.gb_method = new GroupBox();
            this.radio_sap = new RadioButton();
            this.radio_manual = new RadioButton();
            this.btn_search = new Button();
            this.label1 = new Label();
            this.sh_do_no = new Button();
            this.text_do = new TextBox();
            this.dgv_trans = new DataGridView();
            this.btn_process = new Button();
            this.btn_cancel = new Button();
            this.cachedTicketPOMAfrica1 = new CachedTicketPOMAfrica();
            this.gb_filter.SuspendLayout();
            this.gb_method.SuspendLayout();
            ((ISupportInitialize) this.dgv_trans).BeginInit();
            base.SuspendLayout();
            this.gb_filter.Controls.Add(this.gb_method);
            this.gb_filter.Controls.Add(this.btn_search);
            this.gb_filter.Controls.Add(this.label1);
            this.gb_filter.Controls.Add(this.sh_do_no);
            this.gb_filter.Controls.Add(this.text_do);
            this.gb_filter.Location = new Point(12, 12);
            this.gb_filter.Name = "gb_filter";
            this.gb_filter.Size = new Size(0x297, 0x72);
            this.gb_filter.TabIndex = 0;
            this.gb_filter.TabStop = false;
            this.gb_filter.Text = "Filter";
            this.gb_method.Controls.Add(this.radio_sap);
            this.gb_method.Controls.Add(this.radio_manual);
            this.gb_method.Location = new Point(15, 0x26);
            this.gb_method.Name = "gb_method";
            this.gb_method.Size = new Size(0xda, 0x43);
            this.gb_method.TabIndex = 1;
            this.gb_method.TabStop = false;
            this.gb_method.Text = "Method";
            this.radio_sap.AutoSize = true;
            this.radio_sap.Location = new Point(6, 0x27);
            this.radio_sap.Name = "radio_sap";
            this.radio_sap.Size = new Size(0xa6, 0x11);
            this.radio_sap.TabIndex = 1;
            this.radio_sap.TabStop = true;
            this.radio_sap.Text = "Retrieve DO Details from SAP";
            this.radio_sap.UseVisualStyleBackColor = true;
            this.radio_manual.AutoSize = true;
            this.radio_manual.Location = new Point(6, 0x10);
            this.radio_manual.Name = "radio_manual";
            this.radio_manual.Size = new Size(60, 0x11);
            this.radio_manual.TabIndex = 0;
            this.radio_manual.TabStop = true;
            this.radio_manual.Text = "Manual";
            this.radio_manual.UseVisualStyleBackColor = true;
            this.btn_search.Location = new Point(0x246, 0x52);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new Size(0x4b, 0x17);
            this.btn_search.TabIndex = 140;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new EventHandler(this.btn_search_Click);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x43, 13);
            this.label1.TabIndex = 0x89;
            this.label1.Text = "Contract  No";
            this.sh_do_no.Location = new Point(0xec, 10);
            this.sh_do_no.Margin = new Padding(0);
            this.sh_do_no.Name = "sh_do_no";
            this.sh_do_no.Size = new Size(0x17, 0x17);
            this.sh_do_no.TabIndex = 0x88;
            this.sh_do_no.Text = "...";
            this.sh_do_no.UseVisualStyleBackColor = true;
            this.sh_do_no.Click += new EventHandler(this.sh_do_no_Click);
            this.text_do.CharacterCasing = CharacterCasing.Upper;
            this.text_do.Location = new Point(0x55, 12);
            this.text_do.Name = "text_do";
            this.text_do.Size = new Size(0x94, 20);
            this.text_do.TabIndex = 0x87;
            this.dgv_trans.AllowUserToAddRows = false;
            this.dgv_trans.AllowUserToDeleteRows = false;
            this.dgv_trans.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_trans.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_trans.Location = new Point(12, 0x8d);
            this.dgv_trans.Name = "dgv_trans";
            this.dgv_trans.Size = new Size(0x297, 0x117);
            this.dgv_trans.TabIndex = 1;
            this.dgv_trans.CellClick += new DataGridViewCellEventHandler(this.dgv_trans_CellClick);
            this.dgv_trans.RowPostPaint += new DataGridViewRowPostPaintEventHandler(this.dgv_trans_RowPostPaint);
            this.btn_process.Enabled = false;
            this.btn_process.Location = new Point(0x1f8, 0x1aa);
            this.btn_process.Name = "btn_process";
            this.btn_process.Size = new Size(0x4b, 0x17);
            this.btn_process.TabIndex = 0x8d;
            this.btn_process.Text = "Process";
            this.btn_process.UseVisualStyleBackColor = true;
            this.btn_process.Click += new EventHandler(this.brn_process_Click);
            this.btn_cancel.Location = new Point(600, 0x1aa);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new Size(0x4b, 0x17);
            this.btn_cancel.TabIndex = 0x8e;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new EventHandler(this.btn_cancel_Click);
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x2af, 0x1c9);
            base.Controls.Add(this.btn_cancel);
            base.Controls.Add(this.btn_process);
            base.Controls.Add(this.dgv_trans);
            base.Controls.Add(this.gb_filter);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "FormMarkAccident";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Mark Accident";
            base.Load += new EventHandler(this.FormMarkAccident_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormMarkAccident_KeyPress);
            this.gb_filter.ResumeLayout(false);
            this.gb_filter.PerformLayout();
            this.gb_method.ResumeLayout(false);
            this.gb_method.PerformLayout();
            ((ISupportInitialize) this.dgv_trans).EndInit();
            base.ResumeLayout(false);
        }

        private void sh_do_no_Click(object sender, EventArgs e)
        {
            FormContract contract = new FormContract {
                pMode = "CHOOSE",
                pFind = this.text_do.Text.Trim()
            };
            contract.ShowDialog();
            if (contract.ReturnRow != null)
            {
                this.text_do.Text = contract.ReturnRow["DO_No"].ToString();
            }
        }
    }
}

