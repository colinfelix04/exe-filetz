﻿namespace WindowsFormsApplication1
{
    using Microsoft.VisualBasic.PowerPacks;
    using SAP.Middleware.Connector;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormTruckArrivalEntry : Form
    {
        public WBTable tblTrans = new WBTable();
        public WBTable tblTruck = new WBTable();
        public WBTable tblContainer = new WBTable();
        public WBTable tblCust = new WBTable();
        public WBTable tblDriver = new WBTable();
        public WBTable tblTransporter = new WBTable();
        public WBTable tblTransType = new WBTable();
        public WBTable tblLocation = new WBTable();
        public WBTable tblGatepassType1 = new WBTable();
        public WBTable tblGatepassType2 = new WBTable();
        public WBTable tblTAApprove = new WBTable();
        public WBTable tblGatepass = new WBTable();
        public WBTable tblTADetail = new WBTable();
        public WBTable tblGPLink = new WBTable();
        private WBTable tblTmp = new WBTable();
        public bool saved = false;
        public int nRef;
        private string gatepassType1 = "";
        private string gatepassType2 = "";
        private string gType = "";
        private string sqlTmp = "";
        private string TAApproval = "";
        public string pMode = "";
        public string sUniq = "";
        public string changeReason = "";
        public string logKey = "";
        private IRfcStructure ISReturn;
        private IRfcTable ISReturnCTR;
        private IRfcTable ISReturnVDR;
        private IRfcTable ISReturnCUST;
        private IRfcTable ISReturnINCO1;
        private IRfcTable ISReturnINCO2;
        private IRfcTable ISReturnTRP;
        private IRfcTable ISReturnCOMM;
        private IContainer components = null;
        private Label label1;
        private Label label2;
        private DateTimePicker dateTimePicker1;
        private Label label3;
        private ComboBox comboTAApproval;
        private ComboBox comboVehicleDestination;
        private Label label4;
        private ShapeContainer shapeContainer1;
        private RectangleShape rectangleShape1;
        private Label label5;
        private Label label6;
        private Button buttonTransporter;
        private TextBox textTransporter;
        private Label labelTransType;
        private ComboBox comTransType;
        private Button buttonTruck;
        private TextBox textDriverID;
        private Button buttonDriver;
        private Label label7;
        private Label labelTransporterName;
        private Button buttonOwner;
        private TextBox textOwner;
        private Label labelRelation;
        private Button buttonHaulier;
        private TextBox textHaulier;
        private Label label9;
        private TextBox textTrailerNo;
        private Label label46;
        private Label label10;
        private Button buttonContainer;
        private TextBox textContainer;
        private Label label12;
        private TextBox textGatepassType;
        private ComboBox comboGatepassType1;
        private ComboBox comboGatepassType2;
        private TextBox textRemark;
        private Label label11;
        private Button buttonSave;
        private Button buttonCancel;
        private Label labelDriverName;
        public TextBox textTruck;
        public TextBox textTA_Number;
        private Label labelHaulierName;
        private Label labelOwnerName;
        private Button buttonItemReturn;
        private Label labelTransTypeName;
        private TextBox textPO;
        private Label label8;
        private Button buttonAdopt;
        private Button buttonDelete;
        private Label labelLink;
        private DataGridView dgvDO;
        private StatusStrip statusStrip1;
        private ComboBox comboGPLink;

        public FormTruckArrivalEntry()
        {
            this.InitializeComponent();
        }

        private void adoptDataAfrica()
        {
            try
            {
                WBTable table2;
                WBSetting.OpenSetting();
                if (WBSAP.connect())
                {
                    WBSAP.rfcFunction = WBSAP.rfcRep.CreateFunction("ZRFC_WB_CONTRACT2");
                    string[] strArray = new string[3];
                    IRfcTable table = WBSAP.rfcFunction.GetTable("CONTRACT");
                    table.Append();
                    table.SetValue("TYPE", (this.gType == "I") ? "P" : "S");
                    table.SetValue("DOCUMENT", this.textPO.Text.Trim());
                    table.SetValue("ITEM", "8888");
                    WBSAP.rfcFunction.Invoke(WBSAP.rfcDest);
                    this.ISReturnCTR = WBSAP.rfcFunction.GetTable("CTRDATA");
                    this.ISReturnVDR = WBSAP.rfcFunction.GetTable("CTRVDR");
                    this.ISReturnCUST = WBSAP.rfcFunction.GetTable("CTRCUST");
                    this.ISReturnCOMM = WBSAP.rfcFunction.GetTable("CTRCOMM");
                    this.ISReturnINCO1 = WBSAP.rfcFunction.GetTable("CTRINCO1");
                    this.ISReturnINCO2 = WBSAP.rfcFunction.GetTable("CTRINCO2");
                    this.ISReturnTRP = WBSAP.rfcFunction.GetTable("CTRTRP");
                    if (this.ISReturnCTR.RowCount > 0)
                    {
                        table2 = new WBTable();
                        if (this.ISReturnVDR.RowCount <= 0)
                        {
                            goto TR_0038;
                        }
                        else
                        {
                            table2.OpenTable("wb_vendor", "select * from wb_relation where " + WBData.CompanyLocation(" and relation_code = '" + this.ISReturnVDR[0].GetString("CODE") + "'"), WBData.conn);
                            if (table2.DT.Rows.Count > 0)
                            {
                                goto TR_0039;
                            }
                            else
                            {
                                table2.DR = table2.DT.NewRow();
                                table2.DR["Coy"] = WBData.sCoyCode;
                                table2.DR["Location_Code"] = WBData.sLocCode;
                                table2.DR["Relation_Code"] = this.ISReturnVDR[0].GetString("CODE");
                                table2.DR["Relation_Name"] = this.ISReturnVDR[0].GetString("name");
                                table2.DR["Address"] = this.ISReturnVDR[0].GetString("DESC1");
                                table2.DR["City"] = "";
                                table2.DR["Phone"] = "";
                                table2.DR["Fax"] = "";
                                table2.DR["Contact_Person"] = "";
                                table2.DR["SAP_Code"] = this.ISReturnVDR[0].GetString("CODE");
                                table2.DR["Black_List"] = "N";
                                table2.DR["DailyQuantity"] = "N";
                                table2.DR["Quantity"] = "0";
                                table2.DR["Relation_Type"] = "V";
                                table2.DR["ISCC"] = "N";
                                table2.DR["Create_By"] = WBUser.UserID;
                                table2.DR["Create_Date"] = DateTime.Now;
                                table2.DT.Rows.Add(table2.DR);
                                table2.Save();
                                WBTable table3 = new WBTable();
                                table3.OpenTable("wb_relation", "SELECT uniq FROM wb_relation WHERE " + WBData.CompanyLocation(" AND relation_code = '" + this.ISReturnVDR[0].GetString("CODE") + "'"), WBData.conn);
                                if (table3.DT.Rows.Count <= 0)
                                {
                                    MessageBox.Show("Adopt Failed. Master data relation vendor code not yet maintain: " + this.ISReturnVDR[0].GetString("CODE"));
                                }
                                else
                                {
                                    this.logKey = table3.DT.Rows[0]["uniq"].ToString();
                                    table3.Dispose();
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { "ADD", WBUser.UserID, this.changeReason };
                                    Program.updateLogHeader("wb_relation", this.logKey, logField, logValue);
                                    goto TR_0039;
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_592, Resource.Title_002);
                    }
                }
                return;
            TR_0012:
                this.dgvDO.Rows.Clear();
                this.dgvDO.Rows.Add(this.ISReturnCTR.RowCount);
                if (this.ISReturnCTR.RowCount > 0)
                {
                    int num = 0;
                    while (true)
                    {
                        if (num >= this.ISReturnCTR.RowCount)
                        {
                            break;
                        }
                        this.dgvDO.Rows[num].Cells["Contract"].Value = this.ISReturnCTR[num].GetString("Document");
                        this.dgvDO.Rows[num].Cells["Item_No"].Value = this.ISReturnCTR[num].GetString("item");
                        this.dgvDO.Rows[num].Cells["Contract_Date"].Value = this.ISReturnCTR[num].GetString("DCDAT");
                        this.dgvDO.Rows[num].Cells["comm_code"].Value = this.ISReturnCTR[num].GetString("MATNR");
                        this.dgvDO.Rows[num].Cells["relation_code"].Value = this.ISReturnCTR[num].GetString("VENCUST");
                        this.dgvDO.Rows[num].Cells["Quantity"].Value = Program.StrToDouble(this.ISReturnCTR[num].GetString("QTY"), 0);
                        this.dgvDO.Rows[num].Cells["Unit"].Value = this.ISReturnCTR[num].GetString("MEINS");
                        num++;
                    }
                }
                MessageBox.Show(Resource.Mes_086, Resource.Title_007, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                return;
            TR_0014:
                table2.Close();
                goto TR_0012;
            TR_001B:
                if (this.ISReturnTRP.RowCount <= 0)
                {
                    goto TR_0012;
                }
                else
                {
                    table2.OpenTable("wb_transporter", "select * from wb_Transporter where " + WBData.CompanyLocation(" and Transporter_code = '" + this.ISReturnTRP[0].GetString("CODE") + "'"), WBData.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        goto TR_0014;
                    }
                    else
                    {
                        table2.DR = table2.DT.NewRow();
                        table2.DR["Coy"] = WBData.sCoyCode;
                        table2.DR["Location_Code"] = WBData.sLocCode;
                        table2.DR["Transporter_code"] = this.ISReturnTRP[0].GetString("CODE");
                        table2.DR["Transporter_Name"] = this.ISReturnTRP[0].GetString("NAME");
                        table2.DR["SAP_code"] = this.ISReturnTRP[0].GetString("CODE");
                        table2.DR["Address"] = this.ISReturnTRP[0].GetString("DESC1");
                        table2.DR["Create_By"] = WBUser.UserID;
                        table2.DR["Create_Date"] = DateTime.Now;
                        table2.DT.Rows.Add(table2.DR);
                        table2.Save();
                        WBTable table7 = new WBTable();
                        table7.OpenTable("wb_transporter", "SELECT uniq FROM wb_transporter WHERE " + WBData.CompanyLocation(" AND transporter_code = '" + this.ISReturnTRP[0].GetString("CODE") + "'"), WBData.conn);
                        if (table7.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show("Adopt Failed. Master data transporter code not yet maintain: " + this.ISReturnTRP[0].GetString("CODE"));
                        }
                        else
                        {
                            this.logKey = table7.DT.Rows[0]["uniq"].ToString();
                            table7.Dispose();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "ADD", WBUser.UserID, this.changeReason };
                            Program.updateLogHeader("wb_transporter", this.logKey, logField, logValue);
                            goto TR_0014;
                        }
                    }
                }
                return;
            TR_001C:
                table2.Close();
                goto TR_001B;
            TR_0028:
                if (this.ISReturnINCO1.RowCount > 0)
                {
                    table2.OpenTable("wb_incoterm", "select * from wb_incoterm where " + WBData.CompanyLocation(" and Incoterm_code = '" + this.ISReturnINCO1[0].GetString("CODE") + "'"), WBData.conn);
                    if (table2.DT.Rows.Count <= 0)
                    {
                        table2.DR = table2.DT.NewRow();
                        table2.DR["Coy"] = WBData.sCoyCode;
                        table2.DR["Location_Code"] = WBData.sLocCode;
                        table2.DR["Incoterm_code"] = this.ISReturnINCO1[0].GetString("CODE");
                        table2.DR["Incoterm_Desc"] = this.ISReturnINCO1[0].GetString("NAME");
                        table2.DR["DeductedBy"] = "F";
                        table2.DR["Create_By"] = WBUser.UserID;
                        table2.DR["Create_Date"] = DateTime.Now;
                        table2.DT.Rows.Add(table2.DR);
                        table2.Save();
                    }
                    table2.Close();
                }
                if (this.ISReturnINCO2.RowCount <= 0)
                {
                    goto TR_001B;
                }
                else
                {
                    table2.OpenTable("wb_Estate", "select * from wb_Estate where " + WBData.CompanyLocation(" and Estate_code = '" + this.ISReturnINCO2.GetString("CODE") + "'"), WBData.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        goto TR_001C;
                    }
                    else
                    {
                        table2.DR = table2.DT.NewRow();
                        table2.DR["Coy"] = WBData.sCoyCode;
                        table2.DR["Location_Code"] = WBData.sLocCode;
                        table2.DR["Estate_code"] = this.ISReturnINCO2[0].GetString("CODE");
                        table2.DR["Estate_Name"] = this.ISReturnINCO2[0].GetString("NAME");
                        table2.DR["SAP_code"] = this.ISReturnINCO2[0].GetString("CODE");
                        table2.DR["Type_Estate"] = "0";
                        table2.DR["Create_By"] = WBUser.UserID;
                        table2.DR["Create_Date"] = DateTime.Now;
                        table2.DT.Rows.Add(table2.DR);
                        table2.Save();
                        WBTable table6 = new WBTable();
                        table6.OpenTable("wb_estate", "SELECT uniq FROM wb_estate WHERE " + WBData.CompanyLocation(" AND estate_code = '" + this.ISReturnINCO2[0].GetString("CODE") + "'"), WBData.conn);
                        if (table6.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show("Adopt Failed. Master data estate code not yet maintain: " + this.ISReturnINCO2[0].GetString("CODE"));
                        }
                        else
                        {
                            this.logKey = table6.DT.Rows[0]["uniq"].ToString();
                            table6.Dispose();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "ADD", WBUser.UserID, this.changeReason };
                            Program.updateLogHeader("wb_estate", this.logKey, logField, logValue);
                            goto TR_001C;
                        }
                    }
                }
                return;
            TR_0029:
                table2.Close();
                goto TR_0028;
            TR_0030:
                if (this.ISReturnCOMM.RowCount <= 0)
                {
                    goto TR_0028;
                }
                else
                {
                    table2.OpenTable("wb_comm", "select * from wb_Commodity where " + WBData.CompanyLocation(" and Comm_code = '" + this.ISReturnCOMM[0].GetString("CODE") + "'"), WBData.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        goto TR_0029;
                    }
                    else
                    {
                        table2.DR = table2.DT.NewRow();
                        table2.DR["Coy"] = WBData.sCoyCode;
                        table2.DR["Location_Code"] = WBData.sLocCode;
                        table2.DR["Comm_Code"] = this.ISReturnCOMM[0].GetString("CODE");
                        MessageBox.Show("Code: " + table2.DR["Comm_Code"].ToString());
                        table2.DR["Comm_Name"] = this.ISReturnCOMM[0].GetString("NAME");
                        MessageBox.Show("Code: " + table2.DR["Comm_Name"].ToString());
                        table2.DR["Material"] = this.ISReturnCOMM[0].GetString("CODE");
                        MessageBox.Show("Code: " + table2.DR["Material"].ToString());
                        table2.DR["Material_Batch"] = "";
                        table2.DR["Check_Tare"] = "N";
                        table2.DR["Type"] = "S";
                        table2.DR["Trade"] = (this.ISReturnCOMM[0].GetString("CODE").ToUpper().Trim() != "TRADE") ? "N" : "T";
                        table2.DR["BulkPack"] = "B";
                        table2.DR["Check_Grading"] = "N";
                        table2.DR["Using_Gunny"] = "N";
                        table2.DR["PostSAP"] = "N";
                        table2.DR["QCapprove"] = "Y";
                        table2.DR["Create_By"] = WBUser.UserID;
                        table2.DR["Create_Date"] = DateTime.Now;
                        table2.DR["gross_min_Gunny"] = "0";
                        table2.DR["gross_max_gunny"] = "0";
                        table2.DR["netto_gunny"] = "0";
                        table2.DT.Rows.Add(table2.DR);
                        table2.Save();
                        WBTable table5 = new WBTable();
                        table5.OpenTable("wb_commodity", "SELECT uniq FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.ISReturnCOMM[0].GetString("CODE") + "'"), WBData.conn);
                        if (table5.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show("Adopt Failed. Master data commodity code not yet maintain: " + this.ISReturnCOMM[0].GetString("CODE"));
                        }
                        else
                        {
                            this.logKey = table5.DT.Rows[0]["uniq"].ToString();
                            table5.Dispose();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "ADD", WBUser.UserID, this.changeReason };
                            Program.updateLogHeader("wb_commodity", this.logKey, logField, logValue);
                            goto TR_0029;
                        }
                    }
                }
                return;
            TR_0031:
                table2.Close();
                goto TR_0030;
            TR_0038:
                if (this.ISReturnCUST.RowCount <= 0)
                {
                    goto TR_0030;
                }
                else
                {
                    table2.OpenTable("wb_vendor", "select * from wb_relation where " + WBData.CompanyLocation(" and relation_code = '" + this.ISReturnCUST[0].GetString("CODE") + "'"), WBData.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        goto TR_0031;
                    }
                    else
                    {
                        table2.DR = table2.DT.NewRow();
                        table2.DR["Coy"] = WBData.sCoyCode;
                        table2.DR["Location_Code"] = WBData.sLocCode;
                        table2.DR["Relation_Code"] = this.ISReturnCUST[0].GetString("CODE");
                        table2.DR["Relation_Name"] = this.ISReturnCUST[0].GetString("name");
                        table2.DR["Address"] = this.ISReturnCUST[0].GetString("DESC1");
                        table2.DR["City"] = "";
                        table2.DR["Phone"] = "";
                        table2.DR["Fax"] = "";
                        table2.DR["Contact_Person"] = "";
                        table2.DR["SAP_Code"] = this.ISReturnCUST[0].GetString("CODE");
                        table2.DR["Black_List"] = "N";
                        table2.DR["DailyQuantity"] = "N";
                        table2.DR["Quantity"] = "0";
                        table2.DR["Relation_Type"] = "C";
                        table2.DR["ISCC"] = "N";
                        table2.DR["Create_By"] = WBUser.UserID;
                        table2.DR["Create_Date"] = DateTime.Now;
                        table2.DT.Rows.Add(table2.DR);
                        table2.Save();
                        WBTable table4 = new WBTable();
                        table4.OpenTable("wb_relation", "SELECT uniq FROM wb_relation WHERE " + WBData.CompanyLocation(" AND relation_code = '" + this.ISReturnCUST[0].GetString("CODE") + "'"), WBData.conn);
                        if (table4.DT.Rows.Count <= 0)
                        {
                            MessageBox.Show("Adopt Failed. Master data relation customer code not yet maintain: " + this.ISReturnCUST[0].GetString("CODE"));
                        }
                        else
                        {
                            this.logKey = table4.DT.Rows[0]["uniq"].ToString();
                            table4.Dispose();
                            string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                            string[] logValue = new string[] { "ADD", WBUser.UserID, this.changeReason };
                            Program.updateLogHeader("wb_relation", this.logKey, logField, logValue);
                            goto TR_0031;
                        }
                    }
                }
                return;
            TR_0039:
                table2.Close();
                goto TR_0038;
            }
            catch (RfcInvalidParameterException exception)
            {
                MessageBox.Show($"{exception.GetType().Name} : {exception.Message}", "E R R O R <RfcInvalidParameterException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            catch (RfcCommunicationException exception2)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception2.ToString(), "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Network, "E R R O R <RfcCommunicationException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (RfcBaseException exception3)
            {
                if (WBUser.UserLevel == "1")
                {
                    MessageBox.Show(exception3.ToString(), "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Failed_To_Connect_SAP_Technical, "E R R O R <RfcBaseException>", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }
            catch (Exception exception4)
            {
                MessageBox.Show(Resource.Title_003 + " " + exception4.ToString(), Resource.Title_003, MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void buttonAdopt_Click(object sender, EventArgs e)
        {
            this.adoptDataAfrica();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonContainer_Click(object sender, EventArgs e)
        {
            FormContainer container = new FormContainer {
                pMode = "CHOOSE",
                pFind = this.textContainer.Text
            };
            container.ShowDialog();
            if (container.ReturnRow != null)
            {
                this.textContainer.Text = container.ReturnRow["Container_Number"].ToString();
            }
            container.Dispose();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if ((this.dgvDO.Rows.Count > 0) && (MessageBox.Show(Resource.Mes_203, Resource.Title_001, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes))
            {
                this.dgvDO.Rows.Remove(this.dgvDO.CurrentRow);
            }
        }

        private void buttonDriver_Click(object sender, EventArgs e)
        {
            FormDriver driver = new FormDriver {
                pMode = "CHOOSE",
                pFind = this.textDriverID.Text
            };
            driver.ShowDialog();
            if (driver.ReturnRow != null)
            {
                this.textDriverID.Text = driver.ReturnRow["License_No"].ToString();
                this.labelDriverName.Text = driver.ReturnRow["Name"].ToString();
                if (this.textTruck.Text.Trim() == "")
                {
                    this.textTruck.Text = driver.ReturnRow["Truck_Number"].ToString();
                    this.textTruck.Focus();
                }
            }
            driver.Dispose();
        }

        private void buttonHaulier_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textHaulier.Text = vendor.ReturnRow["Relation_Code"].ToString();
                this.labelHaulierName.Text = vendor.ReturnRow["Relation_Name"].ToString();
                this.textHaulier.Focus();
            }
            vendor.Dispose();
        }

        private void buttonItemReturn_Click(object sender, EventArgs e)
        {
            FormReturn return2 = new FormReturn {
                TANumber = this.textTA_Number.Text
            };
            return2.ShowDialog();
            return2.Dispose();
        }

        private void buttonOwner_Click(object sender, EventArgs e)
        {
            FormVendor vendor = new FormVendor {
                pMode = "CHOOSE"
            };
            vendor.ShowDialog();
            if (vendor.ReturnRow != null)
            {
                this.textOwner.Text = vendor.ReturnRow["Relation_Code"].ToString();
                this.labelOwnerName.Text = vendor.ReturnRow["Relation_Name"].ToString();
                this.textOwner.Focus();
            }
            vendor.Dispose();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            TextBox[] aText = new TextBox[] { this.textTruck, this.textTransporter, this.textGatepassType, this.textDriverID };
            if (!Program.CheckEmpty(aText))
            {
                if (this.comboVehicleDestination.Text.Trim() != "")
                {
                    if (this.comboGatepassType1.Text.Trim() != "")
                    {
                        if ((this.comboGatepassType2.Text.Trim() != "") || (this.comboGatepassType2.Items.Count <= 0))
                        {
                            if (this.comboTAApproval.Text.Trim() != "")
                            {
                                if (this.pMode == "EDIT")
                                {
                                    FormTransCancel cancel = new FormTransCancel {
                                        label1 = { Text = "Truck Arrival No" },
                                        textRefNo = { Text = this.textTA_Number.Text },
                                        Text = "CHANGE REASON",
                                        label2 = { Text = "Change Reason : " }
                                    };
                                    cancel.textReason.Focus();
                                    cancel.ShowDialog();
                                    if (cancel.Saved)
                                    {
                                        this.changeReason = cancel.textReason.Text;
                                        cancel.Dispose();
                                    }
                                    else
                                    {
                                        return;
                                    }
                                }
                                Cursor.Current = Cursors.WaitCursor;
                                string str = "";
                                if (this.pMode == "ADD")
                                {
                                    this.tblGatepass.DR = this.tblGatepass.DT.NewRow();
                                    this.tblGatepass.DR["TA_Number"] = this.SetTANo(true);
                                    str = this.tblGatepass.DR["TA_Number"].ToString();
                                }
                                else if ((this.pMode == "EDIT") || (this.pMode == "APPROVE"))
                                {
                                    this.tblGatepass.DR.BeginEdit();
                                    this.logKey = this.tblGatepass.DR["uniq"].ToString();
                                    this.tblGatepass.DR["TA_Number"] = this.textTA_Number.Text.Trim();
                                }
                                this.tblGatepass.DR["Coy"] = WBData.sCoyCode;
                                this.tblGatepass.DR["Location_Code"] = WBData.sLocCode;
                                this.tblGatepass.DR["License_no"] = this.textDriverID.Text;
                                this.tblGatepass.DR["Truck_number"] = this.textTruck.Text;
                                this.tblGatepass.DR["Trailer_number"] = this.textTrailerNo.Text;
                                this.tblGatepass.DR["Container_number"] = this.textContainer.Text;
                                this.tblGatepass.DR["Transporter_Code"] = this.textTransporter.Text;
                                this.tblGatepass.DR["Transaction_Code"] = this.comTransType.Text;
                                this.tblGatepass.DR["Gatepass_type"] = this.gType;
                                this.tblGatepass.DR["Gatepass_type1"] = this.gatepassType1;
                                this.tblGatepass.DR["Gatepass_type2"] = this.gatepassType2;
                                if (this.pMode == "ADD")
                                {
                                    this.tblGatepass.DR["In_Date"] = this.dateTimePicker1.Value.ToShortDateString();
                                    this.tblGatepass.DR["In_Time"] = DateTime.Now.ToString("HH:mm:ss");
                                }
                                this.tblGatepass.DR["OWner_Code"] = this.textOwner.Text;
                                this.tblGatepass.DR["Haulier_Code"] = this.textHaulier.Text;
                                this.tblGatepass.DR["GAtepass_Remark"] = this.textRemark.Text;
                                this.tblGatepass.DR["ApproveBy"] = this.TAApproval.Trim();
                                this.tblGatepass.DR["Submit_gatepass"] = "";
                                this.tblGatepass.DR["Deleted"] = "N";
                                this.tblGatepass.DR["Reject"] = "N";
                                if (this.pMode == "ADD")
                                {
                                    this.tblGatepass.DR["Approved"] = "N";
                                }
                                if (this.pMode == "APPROVE")
                                {
                                    this.tblGatepass.DR["Approved"] = "Y";
                                    this.tblGatepass.DR["Gatepass_Number"] = this.SetGateNo(true);
                                    this.tblGatepass.DR["Approve_by"] = WBUser.UserID;
                                    this.tblGatepass.DR["Approve_date"] = DateTime.Now;
                                }
                                this.tblGatepass.DR["WB"] = this.comboVehicleDestination.SelectedIndex;
                                if (this.pMode == "ADD")
                                {
                                    this.tblGatepass.DT.Rows.Add(this.tblGatepass.DR);
                                    this.tblGatepass.DR["Create_By"] = WBUser.UserID;
                                    this.tblGatepass.DR["Create_Date"] = DateTime.Now.ToString();
                                }
                                else if ((this.pMode == "EDIT") || (this.pMode == "APPROVE"))
                                {
                                    this.tblGatepass.DR.EndEdit();
                                    this.tblGatepass.DR["Change_By"] = WBUser.UserID;
                                    this.tblGatepass.DR["Change_Date"] = DateTime.Now.ToString();
                                }
                                this.tblGatepass.Save();
                                if (((this.pMode == "ADD") || (this.pMode == "EDIT")) || (this.pMode == "APPROVE"))
                                {
                                    if (this.pMode == "ADD")
                                    {
                                        WBTable table = new WBTable();
                                        table.OpenTable("wb_gatepass", "SELECT uniq FROM wb_gatepass WHERE " + WBData.CompanyLocation(" AND ta_number = '" + str + "'"), WBData.conn);
                                        this.logKey = table.DT.Rows[0]["uniq"].ToString();
                                        table.Dispose();
                                    }
                                    string[] logField = new string[] { "PMode", "UserID", "ChangeReason" };
                                    string[] logValue = new string[] { this.pMode, WBUser.UserID, this.changeReason };
                                    Program.updateLogHeader("wb_gatepass", this.logKey, logField, logValue);
                                }
                                this.tblTADetail.AddFromDGV_new(this.dgvDO, "TA_NUMBER", this.textTA_Number.Text, this.pMode, this.changeReason);
                                this.saved = true;
                                if (WBSetting.Field("Check_Email").Trim() == "Y")
                                {
                                    string[] textArray3 = new string[] { ("Dear All,<br><br>This email is to notify you that the following truck has arrived :<table border=0 rules=all cellpadding=3 cellspacing=-1><tr class='bd'><td nowrap>Company</td><td nowrap> : " + WBData.sCoyName) + "</tr><tr class='bd'><td nowrap>Location</td><td nowrap> : " + WBSetting.Field("Location_name"), "</tr><tr class='bd'><td nowrap>Date & Time</td><td nowrap> : ", DateTime.Now.ToShortDateString(), " ", DateTime.Now.ToString("HH:mm:ss") };
                                    string[] textArray4 = new string[] { string.Concat(textArray3) + "</tr><tr class='bd'><td nowrap>Truck Number</td><td nowrap> : " + this.textTruck.Text.Trim(), "</tr><tr class='bd'><td nowrap>User ID</td><td nowrap> : ", WBUser.UserGroup.Trim(), " ( ", WBUser.UserID, " - ", WBUser.UserName.Trim(), " ) " };
                                    string str2 = (string.Concat(textArray4) + "</tr><tr class='bd'><td nowrap>WB Code</td><td nowrap> : " + WBData.sWBCode) + "</tr></table>" + "<br>Thank you.";
                                    WBMail mail = new WBMail();
                                    WBTable table2 = new WBTable();
                                    table2.OpenTable("wb_email_master", "SELECT Subject, Email_To, Email_CC FROM wb_email_master WHERE " + WBData.CompanyLocation(" AND Department = '" + this.comboTAApproval.Text.Trim() + "' AND ( Email_Code ='TRUCKARRIVAL')"), WBData.conn);
                                    int num = 0;
                                    while (true)
                                    {
                                        if (num >= table2.DT.Rows.Count)
                                        {
                                            mail.SendMail();
                                            mail.Dispose();
                                            table2.Dispose();
                                            break;
                                        }
                                        DataRow row = table2.DT.Rows[num];
                                        string[] textArray5 = new string[] { row[0].ToString().Trim(), " ( ", WBData.sCoyCode, " - ", WBData.sLocCode, " )" };
                                        mail.Subject = string.Concat(textArray5);
                                        mail.To = row[1].ToString().Trim();
                                        mail.CC = row[2].ToString().Trim();
                                        num++;
                                    }
                                }
                                Cursor.Current = Cursors.Default;
                                base.Close();
                            }
                            else
                            {
                                MessageBox.Show(Resource.Mes_421, Resource.Title_002);
                                this.comboTAApproval.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_163 + " " + this.textGatepassType.Text, Resource.Title_002);
                            this.comboGatepassType2.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_162 + " " + this.textGatepassType.Text, Resource.Title_002);
                        this.comboGatepassType1.Focus();
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_164, Resource.Title_002);
                    this.comboVehicleDestination.Focus();
                }
            }
        }

        private void buttonTransporter_Click(object sender, EventArgs e)
        {
            FormTransporter transporter = new FormTransporter {
                pMode = "CHOOSE"
            };
            transporter.ShowDialog();
            if (transporter.ReturnRow != null)
            {
                this.textTransporter.Text = transporter.ReturnRow["Transporter_Code"].ToString();
                this.labelTransporterName.Text = transporter.ReturnRow["Transporter_Name"].ToString();
                this.textTransporter.Focus();
            }
            transporter.Dispose();
        }

        private void buttonTruck_Click(object sender, EventArgs e)
        {
            FormTruck truck = new FormTruck {
                pMode = "CHOOSE",
                pFind = this.textTruck.Text
            };
            truck.ShowDialog();
            if (truck.ReturnRow != null)
            {
                this.textTruck.Text = truck.ReturnRow["Truck_Number"].ToString();
                if ((this.textTransporter.Text.Trim() == "") && (truck.ReturnRow["Transporter_Code"].ToString().Trim() != ""))
                {
                    this.textTransporter.Text = truck.ReturnRow["Transporter_Code"].ToString();
                    string[] aField = new string[] { "Transporter_Code" };
                    string[] aFind = new string[] { this.textTransporter.Text };
                    DataRow data = this.tblTransporter.GetData(aField, aFind);
                    if (data != null)
                    {
                        this.labelTransporterName.Text = data["Transporter_Name"].ToString();
                    }
                }
                this.textTruck.Focus();
            }
            truck.Dispose();
        }

        private void comboGatepassType1_Leave(object sender, EventArgs e)
        {
            this.gatepass1_leave();
        }

        private void comboGatepassType2_Leave(object sender, EventArgs e)
        {
            this.gatepass2_leave();
        }

        private void comboGatepassType2_TextChanged(object sender, EventArgs e)
        {
            if ((this.comboGatepassType2.Text.Trim().ToUpper() == "") && (this.gType == "I"))
            {
                this.labelLink.Visible = true;
                this.comboGPLink.Visible = true;
            }
            else
            {
                this.labelLink.Visible = false;
                this.comboGPLink.Visible = false;
            }
        }

        private void comboTAApproval_Leave(object sender, EventArgs e)
        {
        }

        private void comboTAApproval_TextChanged(object sender, EventArgs e)
        {
            if (this.comboTAApproval.Text.Trim() != "")
            {
                string[] aField = new string[] { "ApproveName" };
                string[] aFind = new string[] { this.comboTAApproval.Text };
                DataRow data = this.tblTAApprove.GetData(aField, aFind);
                this.TAApproval = data["ApproveCode"].ToString();
                this.comboVehicleDestination.Enabled = data["Store"].ToString() == "Y";
                if ((this.pMode != "ADD") && (this.pMode != "EDIT"))
                {
                    if (this.pMode == "VIEW")
                    {
                        this.comboVehicleDestination.Enabled = false;
                    }
                }
                else
                {
                    this.comboVehicleDestination.Text = "WB";
                    if (data["Store"].ToString() == "Y")
                    {
                        this.comboVehicleDestination.Text = "STORE";
                    }
                }
            }
        }

        private void comTransType_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void comTransType_Leave(object sender, EventArgs e)
        {
        }

        private void comTransType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.comTransType.Text.Trim() != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                string[] aField = new string[] { "Transaction_code" };
                string[] aFind = new string[] { this.comTransType.Items[this.comTransType.SelectedIndex].ToString() };
                DataRow data = this.tblTransType.GetData(aField, aFind);
                if (data == null)
                {
                    MessageBox.Show(Resource.Mes_426, Resource.Title_002);
                    this.comTransType.Text = "";
                    this.labelTransTypeName.Text = "";
                    this.comboGatepassType1.Text = "";
                    this.comboGatepassType2.Text = "";
                    this.comboGatepassType2.Items.Clear();
                    this.comboGatepassType1.Items.Clear();
                    this.textGatepassType.Text = "";
                }
                else
                {
                    this.labelTransTypeName.Text = data["transaction_name"].ToString();
                    if (data["IO"].ToString() == "I")
                    {
                        this.textGatepassType.Text = "INBOUND";
                        this.gType = "I";
                    }
                    else
                    {
                        this.textGatepassType.Text = "OUTBOUND";
                        this.gType = "O";
                    }
                    DataRow[] rowArray = this.tblGatepassType1.DT.Select("Gatepass_type ='" + this.gType + "' ");
                    this.comboGatepassType1.Items.Clear();
                    foreach (DataRow row2 in rowArray)
                    {
                        this.comboGatepassType1.Items.Add(row2["gatepass_typeName"].ToString());
                    }
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void comTransType_TextChanged(object sender, EventArgs e)
        {
            this.TransType_Leave();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransactionTAEntry_Load(object sender, EventArgs e)
        {
            this.translate();
            Cursor.Current = Cursors.WaitCursor;
            this.InitTable();
            this.initCombo();
            this.initDgVDO();
            if (this.pMode == "ADD")
            {
                this.SetTANo(false);
            }
            else
            {
                DataRow data;
                this.tblGatepass.OpenTable("wb_gatepass", "Select * from wb_Gatepass where " + WBData.CompanyLocation(" and uniq = '" + this.sUniq + "'"), WBData.conn);
                string[] aField = new string[] { "uniq" };
                string[] aFind = new string[] { this.sUniq };
                this.tblGatepass.DR = this.tblGatepass.GetData(aField, aFind);
                this.textTruck.Text = this.tblGatepass.DR["Truck_number"].ToString();
                this.textTA_Number.Text = this.tblGatepass.DR["TA_Number"].ToString();
                this.textDriverID.Text = this.tblGatepass.DR["License_No"].ToString();
                string[] textArray3 = new string[] { "License_No" };
                string[] textArray4 = new string[] { this.textDriverID.Text.Trim() };
                int recNo = this.tblDriver.GetRecNo(textArray3, textArray4);
                if (recNo > -1)
                {
                    this.labelDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                }
                this.textTrailerNo.Text = this.tblGatepass.DR["Trailer_number"].ToString();
                this.textContainer.Text = this.tblGatepass.DR["Container_number"].ToString();
                this.textTransporter.Text = this.tblGatepass.DR["Transporter_Code"].ToString();
                string[] textArray5 = new string[] { "Transporter_code" };
                string[] textArray6 = new string[] { this.textTransporter.Text.Trim() };
                recNo = this.tblTransporter.GetRecNo(textArray5, textArray6);
                if (recNo > -1)
                {
                    this.labelTransporterName.Text = this.tblTransporter.DT.Rows[recNo]["Transporter_Name"].ToString();
                }
                this.comTransType.Text = this.tblGatepass.DR["Transaction_Code"].ToString();
                this.TransType();
                this.gType = this.tblGatepass.DR["gatepass_type"].ToString();
                this.textGatepassType.Text = (this.gType != "I") ? "OUTBOUND" : "INBOUND";
                this.comboGPLink.Text = this.tblGatepass.DR["Gatepass_link"].ToString();
                this.gatepassType1 = this.tblGatepass.DR["Gatepass_type1"].ToString();
                if (this.gatepassType1 != "")
                {
                    string[] textArray7 = new string[] { "gatepass_Type1" };
                    string[] textArray8 = new string[] { this.gatepassType1 };
                    data = this.tblGatepassType1.GetData(textArray7, textArray8);
                    if (data != null)
                    {
                        this.comboGatepassType1.Text = data["gatepass_TypeName"].ToString();
                    }
                    this.gatepass1_leave();
                }
                this.gatepassType2 = this.tblGatepass.DR["Gatepass_type2"].ToString();
                if (this.gatepassType2 != "")
                {
                    string[] textArray9 = new string[] { "gatepass_Type2" };
                    string[] textArray10 = new string[] { this.gatepassType2 };
                    data = this.tblGatepassType2.GetData(textArray9, textArray10);
                    if (data != null)
                    {
                        this.comboGatepassType2.Text = data["gatepass_TypeName"].ToString();
                    }
                    this.gatepass2_leave();
                }
                this.tblTADetail.OpenTable("wb_TADetail", "Select * from wb_TADetail where " + WBData.CompanyLocation(" and TA_number = '" + this.textTA_Number.Text.Trim() + "'"), WBData.conn);
                this.tblTADetail.ToDGV(this.dgvDO);
                this.TAApproval = this.tblGatepass.DR["ApproveBy"].ToString();
                string[] textArray11 = new string[] { "ApproveCode" };
                string[] textArray12 = new string[] { this.TAApproval };
                data = this.tblTAApprove.GetData(textArray11, textArray12);
                if (data != null)
                {
                    this.comboTAApproval.Text = data["ApproveName"].ToString();
                }
                this.dateTimePicker1.Text = (this.tblGatepass.DR["In_Date"].ToString().Trim() != "") ? this.tblGatepass.DR["In_Date"].ToString().Trim() : DateTime.Now.ToString();
                this.textOwner.Text = this.tblGatepass.DR["OWner_Code"].ToString();
                this.textHaulier.Text = this.tblGatepass.DR["Haulier_Code"].ToString();
                this.textRemark.Text = this.tblGatepass.DR["GAtepass_Remark"].ToString();
                this.comboVehicleDestination.SelectedIndex = (this.tblGatepass.DR["WB"].ToString().Trim() != "") ? Convert.ToInt16(this.tblGatepass.DR["WB"].ToString().Trim()) : 0;
            }
            if (this.pMode == "VIEW")
            {
                this.buttonSave.Visible = false;
            }
            if (this.pMode == "APPROVE")
            {
                this.buttonSave.Text = "APPROVE";
            }
            Cursor.Current = Cursors.Default;
        }

        private void FormTruckArrivalEntry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void gatepass1_leave()
        {
            if (this.comboGatepassType1.Text.Trim() != "")
            {
                string[] aField = new string[] { "gatepass_TypeName", "gatepass_type" };
                string[] aFind = new string[] { this.comboGatepassType1.Text, this.gType };
                DataRow data = this.tblGatepassType1.GetData(aField, aFind);
                if (data != null)
                {
                    this.gatepassType1 = data["gatepass_type1"].ToString();
                    DataRow[] rowArray = this.tblGatepassType2.DT.Select(" Gatepass_type1 = '" + data["gatepass_type1"].ToString() + "'");
                    this.comboGatepassType2.Items.Clear();
                    DataRow[] rowArray2 = rowArray;
                    int index = 0;
                    while (true)
                    {
                        if (index >= rowArray2.Length)
                        {
                            this.buttonItemReturn.Visible = data["gatepass_type1"].ToString() == "03";
                            break;
                        }
                        DataRow row2 = rowArray2[index];
                        this.comboGatepassType2.Items.Add(row2["gatepass_typeName"].ToString());
                        index++;
                    }
                }
            }
        }

        private void gatepass2_leave()
        {
            if (this.comboGatepassType2.Text != "")
            {
                string[] aField = new string[] { "gatepass_TypeName" };
                string[] aFind = new string[] { this.comboGatepassType2.Text };
                DataRow data = this.tblGatepassType2.GetData(aField, aFind);
                this.gatepassType2 = data["gatepass_type2"].ToString();
            }
        }

        private void initCombo()
        {
            DataRow[] rowArray;
            this.comTransType.Items.Clear();
            foreach (DataRow row in this.tblTransType.DT.Rows)
            {
                this.comTransType.Items.Add(row["transaction_code"].ToString());
            }
            if ((WBUser.UserLevel == "1") || (this.pMode.Trim() != "ADD"))
            {
                rowArray = this.tblTAApprove.DT.Select();
            }
            else
            {
                string[] textArray1 = new string[13];
                textArray1[0] = " user_group1 = '";
                textArray1[1] = WBUser.UserGroup;
                textArray1[2] = "' or user_group2 = '";
                textArray1[3] = WBUser.UserGroup;
                textArray1[4] = "' or  user_group3 = '";
                textArray1[5] = WBUser.UserGroup;
                textArray1[6] = "' or user_group4 = '";
                textArray1[7] = WBUser.UserGroup;
                textArray1[8] = "' or  user_group5 = '";
                textArray1[9] = WBUser.UserGroup;
                textArray1[10] = "' or user_group6 = '";
                textArray1[11] = WBUser.UserGroup;
                textArray1[12] = "'";
                rowArray = this.tblTAApprove.DT.Select(string.Concat(textArray1));
            }
            this.comboTAApproval.Items.Clear();
            foreach (DataRow row2 in rowArray)
            {
                this.comboTAApproval.Items.Add(row2["ApproveName"].ToString());
            }
            this.comboGPLink.Items.Clear();
            foreach (DataRow row3 in this.tblGPLink.DT.Rows)
            {
                this.comboGPLink.Items.Add(row3["Gatepass_Number"].ToString());
            }
        }

        private void initDgVDO()
        {
            this.dgvDO.ColumnCount = this.tblTADetail.DT.Columns.Count;
            this.dgvDO.ColumnCount++;
            int num = 0;
            while (true)
            {
                if (num >= this.tblTADetail.DT.Columns.Count)
                {
                    this.dgvDO.Columns["Contract"].Visible = true;
                    this.dgvDO.Columns["Item_NO"].Visible = true;
                    this.dgvDO.Columns["Contract_date"].Visible = true;
                    this.dgvDO.Columns["Comm_code"].Visible = true;
                    this.dgvDO.Columns["Relation_code"].Visible = true;
                    this.dgvDO.Columns["Quantity"].Visible = true;
                    this.dgvDO.Columns["unit"].Visible = true;
                    this.dgvDO.Columns["Contract"].HeaderText = Resource.TruckE_019;
                    this.dgvDO.Columns["Contract_date"].HeaderText = Resource.TruckE_020;
                    this.dgvDO.Columns["Relation_code"].HeaderText = Resource.TruckE_021;
                    this.dgvDO.Columns["Comm_code"].HeaderText = Resource.TruckE_022;
                    this.dgvDO.Columns["Quantity"].HeaderText = Resource.TruckE_023;
                    this.dgvDO.Columns["Item_NO"].HeaderText = Resource.TruckE_024;
                    this.dgvDO.Columns["Unit"].HeaderText = "Unit";
                    return;
                }
                this.dgvDO.Columns[num].Name = this.tblTADetail.DT.Columns[num].ColumnName;
                this.dgvDO.Columns[num].Visible = false;
                num++;
            }
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            DataGridViewCellStyle style2 = new DataGridViewCellStyle();
            DataGridViewCellStyle style3 = new DataGridViewCellStyle();
            this.textTA_Number = new TextBox();
            this.label1 = new Label();
            this.label2 = new Label();
            this.dateTimePicker1 = new DateTimePicker();
            this.label3 = new Label();
            this.comboTAApproval = new ComboBox();
            this.comboVehicleDestination = new ComboBox();
            this.label4 = new Label();
            this.shapeContainer1 = new ShapeContainer();
            this.rectangleShape1 = new RectangleShape();
            this.label5 = new Label();
            this.label6 = new Label();
            this.buttonTransporter = new Button();
            this.textTransporter = new TextBox();
            this.labelTransType = new Label();
            this.comTransType = new ComboBox();
            this.buttonTruck = new Button();
            this.textTruck = new TextBox();
            this.textDriverID = new TextBox();
            this.buttonDriver = new Button();
            this.label7 = new Label();
            this.labelTransporterName = new Label();
            this.buttonOwner = new Button();
            this.textOwner = new TextBox();
            this.labelRelation = new Label();
            this.buttonHaulier = new Button();
            this.textHaulier = new TextBox();
            this.label9 = new Label();
            this.textTrailerNo = new TextBox();
            this.label46 = new Label();
            this.label10 = new Label();
            this.buttonContainer = new Button();
            this.textContainer = new TextBox();
            this.label12 = new Label();
            this.textGatepassType = new TextBox();
            this.comboGatepassType1 = new ComboBox();
            this.comboGatepassType2 = new ComboBox();
            this.textRemark = new TextBox();
            this.label11 = new Label();
            this.buttonSave = new Button();
            this.buttonCancel = new Button();
            this.labelDriverName = new Label();
            this.labelHaulierName = new Label();
            this.labelOwnerName = new Label();
            this.buttonItemReturn = new Button();
            this.labelTransTypeName = new Label();
            this.textPO = new TextBox();
            this.label8 = new Label();
            this.buttonAdopt = new Button();
            this.buttonDelete = new Button();
            this.labelLink = new Label();
            this.dgvDO = new DataGridView();
            this.statusStrip1 = new StatusStrip();
            this.comboGPLink = new ComboBox();
            ((ISupportInitialize) this.dgvDO).BeginInit();
            base.SuspendLayout();
            this.textTA_Number.BackColor = SystemColors.ScrollBar;
            this.textTA_Number.Enabled = false;
            this.textTA_Number.Location = new Point(0x8f, 12);
            this.textTA_Number.Name = "textTA_Number";
            this.textTA_Number.Size = new Size(0x7b, 20);
            this.textTA_Number.TabIndex = 0;
            this.textTA_Number.Text = "ABKT00001";
            this.label1.Location = new Point(9, 15);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x7e, 14);
            this.label1.TabIndex = 0x10;
            this.label1.Text = "Tr. Arrival No.";
            this.label1.TextAlign = ContentAlignment.TopRight;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x179, 12);
            this.label2.Name = "label2";
            this.label2.Size = new Size(30, 13);
            this.label2.TabIndex = 0x1d;
            this.label2.Text = "Date";
            this.dateTimePicker1.Enabled = false;
            this.dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new Point(0x19d, 9);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new Size(0x60, 20);
            this.dateTimePicker1.TabIndex = 0x2a;
            this.label3.Location = new Point(0x1a5, 0x29);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x81, 13);
            this.label3.TabIndex = 40;
            this.label3.Text = "Vehicle Approval";
            this.label3.TextAlign = ContentAlignment.TopRight;
            this.comboTAApproval.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboTAApproval.FormattingEnabled = true;
            this.comboTAApproval.Location = new Point(0x22c, 0x26);
            this.comboTAApproval.Name = "comboTAApproval";
            this.comboTAApproval.Size = new Size(130, 0x15);
            this.comboTAApproval.TabIndex = 12;
            this.comboTAApproval.TextChanged += new EventHandler(this.comboTAApproval_TextChanged);
            this.comboTAApproval.Leave += new EventHandler(this.comboTAApproval_Leave);
            this.comboVehicleDestination.Enabled = false;
            this.comboVehicleDestination.FormattingEnabled = true;
            object[] items = new object[] { "WB", "STORE" };
            this.comboVehicleDestination.Items.AddRange(items);
            this.comboVehicleDestination.Location = new Point(0x22c, 0x3e);
            this.comboVehicleDestination.Name = "comboVehicleDestination";
            this.comboVehicleDestination.Size = new Size(0x57, 0x15);
            this.comboVehicleDestination.TabIndex = 13;
            this.comboVehicleDestination.Text = "WB";
            this.label4.Location = new Point(0x1a2, 0x41);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x84, 13);
            this.label4.TabIndex = 0x29;
            this.label4.Text = "Vehicle Destination";
            this.label4.TextAlign = ContentAlignment.TopRight;
            this.shapeContainer1.Location = new Point(0, 0);
            this.shapeContainer1.Margin = new Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            Shape[] shapes = new Shape[] { this.rectangleShape1 };
            this.shapeContainer1.Shapes.AddRange(shapes);
            this.shapeContainer1.Size = new Size(0x2e5, 0x22f);
            this.shapeContainer1.TabIndex = 0x18;
            this.shapeContainer1.TabStop = false;
            this.rectangleShape1.Location = new Point(0x19f, 0x22);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new Size(0x13a, 0x3a);
            this.label5.Location = new Point(9, 0x29);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0x7e, 13);
            this.label5.TabIndex = 0x11;
            this.label5.Text = "Vehicle No.";
            this.label5.TextAlign = ContentAlignment.TopRight;
            this.label6.Location = new Point(9, 0xdd);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0x7e, 13);
            this.label6.TabIndex = 0x19;
            this.label6.Text = "Driver ID";
            this.label6.TextAlign = ContentAlignment.TopRight;
            this.buttonTransporter.Location = new Point(270, 0xf2);
            this.buttonTransporter.Margin = new Padding(0);
            this.buttonTransporter.Name = "buttonTransporter";
            this.buttonTransporter.Size = new Size(0x17, 0x17);
            this.buttonTransporter.TabIndex = 0x26;
            this.buttonTransporter.Text = "...";
            this.buttonTransporter.UseVisualStyleBackColor = true;
            this.buttonTransporter.Click += new EventHandler(this.buttonTransporter_Click);
            this.textTransporter.CharacterCasing = CharacterCasing.Upper;
            this.textTransporter.Location = new Point(0x8f, 0xf4);
            this.textTransporter.MaxLength = 20;
            this.textTransporter.Name = "textTransporter";
            this.textTransporter.Size = new Size(0x7a, 20);
            this.textTransporter.TabIndex = 10;
            this.textTransporter.KeyPress += new KeyPressEventHandler(this.textTransporter_KeyPress);
            this.textTransporter.Leave += new EventHandler(this.textTransporter_Leave);
            this.labelTransType.Cursor = Cursors.Arrow;
            this.labelTransType.Location = new Point(11, 0xa8);
            this.labelTransType.Name = "labelTransType";
            this.labelTransType.Size = new Size(0x7e, 13);
            this.labelTransType.TabIndex = 0x17;
            this.labelTransType.Text = "Transaction Type";
            this.labelTransType.TextAlign = ContentAlignment.TopRight;
            this.comTransType.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comTransType.FormattingEnabled = true;
            this.comTransType.Location = new Point(0x8f, 0xa5);
            this.comTransType.Name = "comTransType";
            this.comTransType.Size = new Size(0x7b, 0x15);
            this.comTransType.TabIndex = 6;
            this.comTransType.SelectedIndexChanged += new EventHandler(this.comTransType_SelectedIndexChanged);
            this.comTransType.TextChanged += new EventHandler(this.comTransType_TextChanged);
            this.comTransType.KeyPress += new KeyPressEventHandler(this.comTransType_KeyPress);
            this.comTransType.Leave += new EventHandler(this.comTransType_Leave);
            this.buttonTruck.Location = new Point(270, 0x24);
            this.buttonTruck.Margin = new Padding(0);
            this.buttonTruck.Name = "buttonTruck";
            this.buttonTruck.Size = new Size(0x17, 0x17);
            this.buttonTruck.TabIndex = 30;
            this.buttonTruck.Text = "...";
            this.buttonTruck.UseVisualStyleBackColor = true;
            this.buttonTruck.Click += new EventHandler(this.buttonTruck_Click);
            this.textTruck.CharacterCasing = CharacterCasing.Upper;
            this.textTruck.Location = new Point(0x8f, 0x26);
            this.textTruck.MaxLength = 20;
            this.textTruck.Name = "textTruck";
            this.textTruck.Size = new Size(0x7b, 20);
            this.textTruck.TabIndex = 1;
            this.textTruck.KeyPress += new KeyPressEventHandler(this.textTruck_KeyPress);
            this.textTruck.Leave += new EventHandler(this.textTruck_Leave);
            this.textDriverID.CharacterCasing = CharacterCasing.Upper;
            this.textDriverID.Location = new Point(0x8f, 0xda);
            this.textDriverID.MaxLength = 50;
            this.textDriverID.Name = "textDriverID";
            this.textDriverID.Size = new Size(0x7b, 20);
            this.textDriverID.TabIndex = 9;
            this.textDriverID.KeyPress += new KeyPressEventHandler(this.textDriverID_KeyPress);
            this.textDriverID.Leave += new EventHandler(this.textDriverID_Leave);
            this.buttonDriver.Location = new Point(0x10d, 0xd8);
            this.buttonDriver.Margin = new Padding(0);
            this.buttonDriver.Name = "buttonDriver";
            this.buttonDriver.Size = new Size(0x17, 0x17);
            this.buttonDriver.TabIndex = 0x24;
            this.buttonDriver.Text = "...";
            this.buttonDriver.UseVisualStyleBackColor = true;
            this.buttonDriver.Click += new EventHandler(this.buttonDriver_Click);
            this.label7.Location = new Point(9, 0xf7);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x7e, 13);
            this.label7.TabIndex = 0x1a;
            this.label7.Text = "Transporter";
            this.label7.TextAlign = ContentAlignment.TopRight;
            this.labelTransporterName.AutoSize = true;
            this.labelTransporterName.Location = new Point(0x12d, 0xf7);
            this.labelTransporterName.Name = "labelTransporterName";
            this.labelTransporterName.Size = new Size(0x59, 13);
            this.labelTransporterName.TabIndex = 0x27;
            this.labelTransporterName.Text = "TransporterName";
            this.buttonOwner.Location = new Point(0x10d, 0x6f);
            this.buttonOwner.Margin = new Padding(0);
            this.buttonOwner.Name = "buttonOwner";
            this.buttonOwner.Size = new Size(0x17, 0x17);
            this.buttonOwner.TabIndex = 0x20;
            this.buttonOwner.Text = "...";
            this.buttonOwner.UseVisualStyleBackColor = true;
            this.buttonOwner.Click += new EventHandler(this.buttonOwner_Click);
            this.textOwner.CharacterCasing = CharacterCasing.Upper;
            this.textOwner.Location = new Point(0x8f, 0x71);
            this.textOwner.MaxLength = 50;
            this.textOwner.Name = "textOwner";
            this.textOwner.Size = new Size(0x7b, 20);
            this.textOwner.TabIndex = 4;
            this.textOwner.KeyPress += new KeyPressEventHandler(this.textOwner_KeyPress);
            this.textOwner.Leave += new EventHandler(this.textOwner_Leave);
            this.labelRelation.Location = new Point(9, 0x74);
            this.labelRelation.Name = "labelRelation";
            this.labelRelation.Size = new Size(0x7e, 13);
            this.labelRelation.TabIndex = 20;
            this.labelRelation.Text = "Owner";
            this.labelRelation.TextAlign = ContentAlignment.TopRight;
            this.buttonHaulier.Location = new Point(0x10d, 0x89);
            this.buttonHaulier.Margin = new Padding(0);
            this.buttonHaulier.Name = "buttonHaulier";
            this.buttonHaulier.Size = new Size(0x17, 0x17);
            this.buttonHaulier.TabIndex = 0x22;
            this.buttonHaulier.Text = "...";
            this.buttonHaulier.UseVisualStyleBackColor = true;
            this.buttonHaulier.Click += new EventHandler(this.buttonHaulier_Click);
            this.textHaulier.CharacterCasing = CharacterCasing.Upper;
            this.textHaulier.Location = new Point(0x8f, 0x8b);
            this.textHaulier.MaxLength = 50;
            this.textHaulier.Name = "textHaulier";
            this.textHaulier.Size = new Size(0x7b, 20);
            this.textHaulier.TabIndex = 5;
            this.textHaulier.KeyPress += new KeyPressEventHandler(this.textHaulier_KeyPress);
            this.textHaulier.Leave += new EventHandler(this.textHaulier_Leave);
            this.label9.Location = new Point(9, 0x8e);
            this.label9.Name = "label9";
            this.label9.Size = new Size(0x7e, 13);
            this.label9.TabIndex = 0x15;
            this.label9.Text = "Haulier";
            this.label9.TextAlign = ContentAlignment.TopRight;
            this.textTrailerNo.CharacterCasing = CharacterCasing.Upper;
            this.textTrailerNo.Location = new Point(0x8f, 0x3e);
            this.textTrailerNo.MaxLength = 20;
            this.textTrailerNo.Name = "textTrailerNo";
            this.textTrailerNo.Size = new Size(0x7c, 20);
            this.textTrailerNo.TabIndex = 2;
            this.textTrailerNo.KeyPress += new KeyPressEventHandler(this.textTrailerNo_KeyPress);
            this.label46.Location = new Point(9, 0x41);
            this.label46.Name = "label46";
            this.label46.Size = new Size(0x7e, 13);
            this.label46.TabIndex = 0x12;
            this.label46.Text = "Trailer No.";
            this.label46.TextAlign = ContentAlignment.TopRight;
            this.label10.Location = new Point(11, 0x5b);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0x7e, 13);
            this.label10.TabIndex = 0x13;
            this.label10.Text = "Container No.";
            this.label10.TextAlign = ContentAlignment.TopRight;
            this.buttonContainer.Location = new Point(270, 0x56);
            this.buttonContainer.Margin = new Padding(0);
            this.buttonContainer.Name = "buttonContainer";
            this.buttonContainer.Size = new Size(0x17, 0x17);
            this.buttonContainer.TabIndex = 0x1f;
            this.buttonContainer.Text = "...";
            this.buttonContainer.UseVisualStyleBackColor = true;
            this.buttonContainer.Click += new EventHandler(this.buttonContainer_Click);
            this.textContainer.CharacterCasing = CharacterCasing.Upper;
            this.textContainer.Location = new Point(0x8f, 0x58);
            this.textContainer.MaxLength = 20;
            this.textContainer.Name = "textContainer";
            this.textContainer.Size = new Size(0x7b, 20);
            this.textContainer.TabIndex = 3;
            this.textContainer.LocationChanged += new EventHandler(this.textContainer_LocationChanged);
            this.textContainer.KeyPress += new KeyPressEventHandler(this.textContainer_KeyPress);
            this.textContainer.Leave += new EventHandler(this.textContainer_Leave);
            this.label12.Location = new Point(9, 0xc3);
            this.label12.Name = "label12";
            this.label12.Size = new Size(0x7e, 13);
            this.label12.TabIndex = 0x16;
            this.label12.Text = "GatePass Type";
            this.label12.TextAlign = ContentAlignment.TopRight;
            this.textGatepassType.BackColor = SystemColors.ScrollBar;
            this.textGatepassType.CharacterCasing = CharacterCasing.Upper;
            this.textGatepassType.Location = new Point(0x8f, 0xc0);
            this.textGatepassType.MaxLength = 20;
            this.textGatepassType.Name = "textGatepassType";
            this.textGatepassType.Size = new Size(0x7b, 20);
            this.textGatepassType.TabIndex = 0x1c;
            this.comboGatepassType1.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboGatepassType1.FormattingEnabled = true;
            this.comboGatepassType1.Location = new Point(0x145, 0xc0);
            this.comboGatepassType1.Name = "comboGatepassType1";
            this.comboGatepassType1.Size = new Size(0x88, 0x15);
            this.comboGatepassType1.TabIndex = 7;
            this.comboGatepassType1.Leave += new EventHandler(this.comboGatepassType1_Leave);
            this.comboGatepassType2.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboGatepassType2.FormattingEnabled = true;
            this.comboGatepassType2.Location = new Point(490, 0xc0);
            this.comboGatepassType2.Name = "comboGatepassType2";
            this.comboGatepassType2.Size = new Size(0x88, 0x15);
            this.comboGatepassType2.TabIndex = 8;
            this.comboGatepassType2.TextChanged += new EventHandler(this.comboGatepassType2_TextChanged);
            this.comboGatepassType2.Leave += new EventHandler(this.comboGatepassType2_Leave);
            this.textRemark.Location = new Point(0x8f, 270);
            this.textRemark.MaxLength = 100;
            this.textRemark.Multiline = true;
            this.textRemark.Name = "textRemark";
            this.textRemark.Size = new Size(0x21f, 0x3f);
            this.textRemark.TabIndex = 11;
            this.textRemark.KeyPress += new KeyPressEventHandler(this.textRemark_KeyPress);
            this.label11.Location = new Point(9, 0x111);
            this.label11.Name = "label11";
            this.label11.Size = new Size(0x7e, 13);
            this.label11.TabIndex = 0x1b;
            this.label11.Text = "Remark";
            this.label11.TextAlign = ContentAlignment.TopRight;
            this.buttonSave.Location = new Point(0x20a, 0x160);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x58, 0x26);
            this.buttonSave.TabIndex = 14;
            this.buttonSave.Text = "&Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.buttonCancel.Location = new Point(0x281, 0x160);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x58, 0x26);
            this.buttonCancel.TabIndex = 15;
            this.buttonCancel.Text = "&Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.labelDriverName.AutoSize = true;
            this.labelDriverName.Location = new Point(0x12b, 0xdd);
            this.labelDriverName.Name = "labelDriverName";
            this.labelDriverName.Size = new Size(0x3f, 13);
            this.labelDriverName.TabIndex = 0x25;
            this.labelDriverName.Text = "DriverName";
            this.labelHaulierName.AutoSize = true;
            this.labelHaulierName.Location = new Point(0x12b, 0x8e);
            this.labelHaulierName.Name = "labelHaulierName";
            this.labelHaulierName.Size = new Size(0x4f, 13);
            this.labelHaulierName.TabIndex = 0x23;
            this.labelHaulierName.Text = "CustomerName";
            this.labelHaulierName.Visible = false;
            this.labelOwnerName.AutoSize = true;
            this.labelOwnerName.Location = new Point(0x12b, 0x74);
            this.labelOwnerName.Name = "labelOwnerName";
            this.labelOwnerName.Size = new Size(0x4f, 13);
            this.labelOwnerName.TabIndex = 0x21;
            this.labelOwnerName.Text = "CustomerName";
            this.labelOwnerName.Visible = false;
            this.buttonItemReturn.Location = new Point(0x114, 0x156);
            this.buttonItemReturn.Name = "buttonItemReturn";
            this.buttonItemReturn.Size = new Size(0x57, 0x26);
            this.buttonItemReturn.TabIndex = 0x2b;
            this.buttonItemReturn.Text = "Item Return";
            this.buttonItemReturn.UseVisualStyleBackColor = true;
            this.buttonItemReturn.Visible = false;
            this.buttonItemReturn.Click += new EventHandler(this.buttonItemReturn_Click);
            this.labelTransTypeName.AutoSize = true;
            this.labelTransTypeName.Cursor = Cursors.Arrow;
            this.labelTransTypeName.Location = new Point(0x110, 0xa8);
            this.labelTransTypeName.Name = "labelTransTypeName";
            this.labelTransTypeName.Size = new Size(90, 13);
            this.labelTransTypeName.TabIndex = 0x2c;
            this.labelTransTypeName.Text = "Transaction Type";
            this.textPO.CharacterCasing = CharacterCasing.Upper;
            this.textPO.Location = new Point(12, 420);
            this.textPO.MaxLength = 50;
            this.textPO.Name = "textPO";
            this.textPO.Size = new Size(0x7b, 20);
            this.textPO.TabIndex = 0x2e;
            this.label8.Location = new Point(12, 0x17f);
            this.label8.Name = "label8";
            this.label8.Size = new Size(0x7d, 0x22);
            this.label8.TabIndex = 0x2f;
            this.label8.Text = "PO/SO No.";
            this.buttonAdopt.Location = new Point(0x30, 0x1be);
            this.buttonAdopt.Name = "buttonAdopt";
            this.buttonAdopt.Size = new Size(0x57, 0x26);
            this.buttonAdopt.TabIndex = 0x30;
            this.buttonAdopt.Text = "Adopt";
            this.buttonAdopt.UseVisualStyleBackColor = true;
            this.buttonAdopt.Click += new EventHandler(this.buttonAdopt_Click);
            this.buttonDelete.Location = new Point(0x36, 0x1f8);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new Size(0x53, 30);
            this.buttonDelete.TabIndex = 50;
            this.buttonDelete.Text = "Remove Item";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new EventHandler(this.buttonDelete_Click);
            this.labelLink.Location = new Point(8, 0x156);
            this.labelLink.Name = "labelLink";
            this.labelLink.Size = new Size(0x7e, 13);
            this.labelLink.TabIndex = 0x34;
            this.labelLink.Text = "Link Returnable";
            this.labelLink.TextAlign = ContentAlignment.TopRight;
            this.dgvDO.AllowUserToAddRows = false;
            this.dgvDO.AllowUserToDeleteRows = false;
            this.dgvDO.AllowUserToResizeRows = false;
            this.dgvDO.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDO.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.BackColor = SystemColors.Control;
            style.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style.ForeColor = SystemColors.WindowText;
            style.SelectionBackColor = SystemColors.Highlight;
            style.SelectionForeColor = SystemColors.HighlightText;
            style.WrapMode = DataGridViewTriState.True;
            this.dgvDO.ColumnHeadersDefaultCellStyle = style;
            this.dgvDO.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            style2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style2.BackColor = SystemColors.Window;
            style2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style2.ForeColor = SystemColors.ControlText;
            style2.SelectionBackColor = SystemColors.Highlight;
            style2.SelectionForeColor = SystemColors.HighlightText;
            style2.WrapMode = DataGridViewTriState.False;
            this.dgvDO.DefaultCellStyle = style2;
            this.dgvDO.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dgvDO.Location = new Point(0x90, 0x199);
            this.dgvDO.MultiSelect = false;
            this.dgvDO.Name = "dgvDO";
            style3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style3.BackColor = SystemColors.Control;
            style3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            style3.ForeColor = SystemColors.WindowText;
            style3.SelectionBackColor = SystemColors.Highlight;
            style3.SelectionForeColor = SystemColors.HighlightText;
            style3.WrapMode = DataGridViewTriState.True;
            this.dgvDO.RowHeadersDefaultCellStyle = style3;
            this.dgvDO.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvDO.Size = new Size(0x24a, 0x73);
            this.dgvDO.TabIndex = 0x36;
            this.statusStrip1.Location = new Point(0, 0x219);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(0x2e5, 0x16);
            this.statusStrip1.TabIndex = 0x37;
            this.statusStrip1.Text = "statusStrip1";
            this.comboGPLink.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboGPLink.FormattingEnabled = true;
            this.comboGPLink.Location = new Point(0x8f, 0x156);
            this.comboGPLink.Name = "comboGPLink";
            this.comboGPLink.Size = new Size(0x7b, 0x15);
            this.comboGPLink.TabIndex = 0x38;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x2e5, 0x22f);
            base.ControlBox = false;
            base.Controls.Add(this.comboGPLink);
            base.Controls.Add(this.statusStrip1);
            base.Controls.Add(this.dgvDO);
            base.Controls.Add(this.labelLink);
            base.Controls.Add(this.buttonDelete);
            base.Controls.Add(this.buttonAdopt);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.textPO);
            base.Controls.Add(this.labelTransTypeName);
            base.Controls.Add(this.buttonItemReturn);
            base.Controls.Add(this.labelDriverName);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.textRemark);
            base.Controls.Add(this.label11);
            base.Controls.Add(this.comboGatepassType2);
            base.Controls.Add(this.comboGatepassType1);
            base.Controls.Add(this.textGatepassType);
            base.Controls.Add(this.label12);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.buttonContainer);
            base.Controls.Add(this.textContainer);
            base.Controls.Add(this.textTrailerNo);
            base.Controls.Add(this.label46);
            base.Controls.Add(this.labelHaulierName);
            base.Controls.Add(this.buttonHaulier);
            base.Controls.Add(this.textHaulier);
            base.Controls.Add(this.label9);
            base.Controls.Add(this.labelOwnerName);
            base.Controls.Add(this.buttonOwner);
            base.Controls.Add(this.textOwner);
            base.Controls.Add(this.labelRelation);
            base.Controls.Add(this.label5);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.buttonTransporter);
            base.Controls.Add(this.textTransporter);
            base.Controls.Add(this.labelTransType);
            base.Controls.Add(this.comTransType);
            base.Controls.Add(this.buttonTruck);
            base.Controls.Add(this.textTruck);
            base.Controls.Add(this.textDriverID);
            base.Controls.Add(this.buttonDriver);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.labelTransporterName);
            base.Controls.Add(this.comboVehicleDestination);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.comboTAApproval);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.dateTimePicker1);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.textTA_Number);
            base.Controls.Add(this.shapeContainer1);
            base.KeyPreview = true;
            base.Name = "FormTruckArrivalEntry";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Truck Arrival";
            base.Load += new EventHandler(this.FormTransactionTAEntry_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTruckArrivalEntry_KeyPress);
            ((ISupportInitialize) this.dgvDO).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void InitTable()
        {
            this.tblTruck.OpenTable("wb_truck", "Select * from wb_truck where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblContainer.OpenTable("wb_Container", "Select * from wb_Container where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblCust.OpenTable("wb_relation", "Select * from wb_relation where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblDriver.OpenTable("wb_driver", "Select * from wb_driver where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL) and (Deleted IS NULL OR Deleted <> 'Y') "), WBData.conn);
            this.tblTransporter.OpenTable("wb_transporter", "Select * from wb_transporter where " + WBData.CompanyLocation(" and (Black_List <> 'Y' OR Black_List IS NULL)"), WBData.conn);
            this.tblTransType.OpenTable("wb_transaction_type", "Select * from wb_transaction_type", WBData.conn);
            this.tblTAApprove.OpenTable("wb_TAApprove", "Select * from wb_TAApprove where " + WBData.CompanyLocation(""), WBData.conn);
            this.tblGatepass.OpenTable("wb_gatepass", "Select * from wb_Gatepass where " + WBData.CompanyLocation("and 1=0"), WBData.conn);
            this.tblTADetail.OpenTable("wb_TADetail", "Select * from wb_TADetail where " + WBData.CompanyLocation("and 1=0"), WBData.conn);
            this.tblGatepassType1.OpenTable("wb_GatepassType1", "Select * from wb_GatepassType1 where 1=1", WBData.conn);
            this.tblGatepassType2.OpenTable("wb_gatepassType2", "Select * from wb_gatepasstype2 where 1=1", WBData.conn);
            this.tblGPLink.OpenTable("gp_link", "Select * From WB_Gatepass where (GatePass_Type1 = '06') and (Submit_Gatepass <> 'V') and (Reject <> 'T') and (GatePass_Type2 = '12') ", WBData.conn);
            Program.AutoComp(this.tblTruck, "Truck_Number", this.textTruck);
            Program.AutoComp(this.tblDriver, "License_No", this.textDriverID);
            Program.AutoComp(this.tblTransporter, "Transporter_Code", this.textTransporter);
            Program.AutoComp(this.tblCust, "Relation_Code", this.textOwner);
            Program.AutoComp(this.tblCust, "Relation_Code", this.textHaulier);
            Program.AutoComp(this.tblContainer, "Container_number", this.textContainer);
            this.labelTransporterName.Text = "";
            this.labelDriverName.Text = "";
            this.labelOwnerName.Text = "";
            this.labelHaulierName.Text = "";
        }

        private object SetGateNo(bool pSave)
        {
            DataRow row;
            string str = "";
            int totalWidth = 7;
            DateTime time = DateTime.Parse(this.dateTimePicker1.Value.ToShortDateString());
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            totalWidth = 7;
            if (pSave)
            {
                bool flag2 = true;
                bool flag3 = false;
                string str3 = "";
                while (true)
                {
                    if (!flag2)
                    {
                        break;
                    }
                    table2.OpenTable("wb_location", "Select * From wb_location Where " + WBData.CompanyLocation(""), WBData.conn);
                    row = table2.DT.Rows[0];
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 < 5)
                        {
                            table2.ReOpen();
                            row = table2.DT.Rows[0];
                            if ((row["ref_lock"].ToString().Trim().ToUpper() != "N") && (row["ref_lock"].ToString().Trim() != ""))
                            {
                                str3 = row["ref_lockBy"].ToString().Trim().ToUpper();
                                flag3 = true;
                                num2++;
                                continue;
                            }
                            row.BeginEdit();
                            row["ref_lock"] = "Y";
                            row["ref_lockBy"] = WBSetting.WBCode;
                            row.EndEdit();
                            table2.Save();
                            table2.ReOpen();
                            row = table2.DT.Rows[0];
                            flag3 = false;
                            flag2 = false;
                        }
                        if (flag3 && (MessageBox.Show(" Save Data Failed, Locked by " + str3 + ".\n\n Retry Save Data? ", "R E T R Y...", MessageBoxButtons.OK, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK))
                        {
                            flag2 = true;
                        }
                        break;
                    }
                }
            }
            table2.OpenTable("wb_location", "Select * From wb_location Where " + WBData.CompanyLocation(""), WBData.conn);
            row = table2.DT.Rows[0];
            string str2 = (row["Gatepass_No"].ToString().Trim() == "") ? "0" : row["Gatepass_No"].ToString().Trim();
            while (true)
            {
                this.nRef = Convert.ToInt32(str2) + 1;
                str = this.nRef.ToString().Trim().PadLeft(totalWidth, '0');
                str = WBSetting.sGatepassCode + str;
                str2 = this.nRef.ToString().Trim();
                table.OpenTable("wb_gatepass", "Select Gatepass_Number From wb_gatepass Where " + WBData.CompanyLocation(" AND Gatepass_Number='" + str + "'"), WBData.conn);
                if (table.DT.Rows.Count == 0)
                {
                    if (pSave)
                    {
                        table2.ReOpen();
                        table2.DR = table2.DT.Rows[0];
                        table2.DR.BeginEdit();
                        table2.DR["Gatepass_No"] = this.nRef.ToString();
                        table2.DR["Ref_Lock"] = "N";
                        table2.DR.EndEdit();
                        table2.Save();
                    }
                    table2.Close();
                    table2.Dispose();
                    return str;
                }
            }
        }

        private string SetTANo(bool pSave)
        {
            DataRow row;
            string str = "";
            int length = 7;
            DateTime time = DateTime.Parse(this.dateTimePicker1.Value.ToShortDateString());
            WBTable table = new WBTable();
            WBTable table2 = new WBTable();
            if (pSave)
            {
                bool flag2 = true;
                bool flag3 = false;
                string str3 = "";
                while (true)
                {
                    if (!flag2)
                    {
                        break;
                    }
                    table2.OpenTable("wb_location", "Select * From wb_location Where " + WBData.CompanyLocation(""), WBData.conn);
                    row = table2.DT.Rows[0];
                    int num2 = 0;
                    while (true)
                    {
                        if (num2 < 5)
                        {
                            table2.ReOpen();
                            row = table2.DT.Rows[0];
                            if ((row["ref_lock"].ToString().Trim().ToUpper() != "N") && (row["ref_lock"].ToString().Trim() != ""))
                            {
                                str3 = row["ref_lockBy"].ToString().Trim().ToUpper();
                                flag3 = true;
                                num2++;
                                continue;
                            }
                            row.BeginEdit();
                            row["ref_lock"] = "Y";
                            row["ref_lockBy"] = WBSetting.WBCode;
                            row.EndEdit();
                            table2.Save();
                            table2.ReOpen();
                            row = table2.DT.Rows[0];
                            flag3 = false;
                            flag2 = false;
                        }
                        if (flag3 && (MessageBox.Show(" Save Data Failed, Locked by " + str3 + ".\n\n Retry Save Data? ", "R E T R Y...", MessageBoxButtons.OK, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK))
                        {
                            flag2 = true;
                        }
                        break;
                    }
                }
            }
            table2.OpenTable("wb_location", "Select * From wb_location Where " + WBData.CompanyLocation(""), WBData.conn);
            row = table2.DT.Rows[0];
            string str2 = (row["TA_No"].ToString().Trim() == "") ? "0" : row["TA_No"].ToString().Trim();
            length = 7;
            int num3 = 0;
            while (true)
            {
                if (num3 >= 4)
                {
                    if (pSave)
                    {
                        table2.ReOpen();
                        table2.DR = table2.DT.Rows[0];
                        table2.DR.BeginEdit();
                        table2.DR["TA_No"] = this.nRef.ToString();
                        table2.DR["Ref_Lock"] = "N";
                        table2.DR.EndEdit();
                        table2.Save();
                    }
                    table2.Close();
                    table2.Dispose();
                    this.textTA_Number.Text = str;
                    return str;
                }
                int num4 = WBSetting.sTACode.Length + length;
                string sqltext = "select TOP (1) TA_Number from wb_gatepass WHERE  " + WBData.CompanyLocation(" and ({ fn LENGTH(TA_Number) } = " + num4.ToString()) + ") order by TA_Number desc";
                table.OpenTable("wb_transaction", sqltext, WBData.conn);
                bool flag9 = table.DT.Rows.Count <= 0;
                str2 = !flag9 ? table.DT.Rows[0]["TA_Number"].ToString().Substring(WBSetting.sTACode.Length, length) : "0".PadLeft(length, '0');
                while (true)
                {
                    this.nRef = Convert.ToInt32(str2) + 1;
                    str = this.nRef.ToString().Trim().PadLeft(length, '0');
                    str = WBSetting.sTACode + str;
                    str2 = this.nRef.ToString().Trim();
                    table.OpenTable("wb_gatepass", "Select TA_Number From wb_gatepass Where " + WBData.CompanyLocation(" AND TA_Number='" + str + "'"), WBData.conn);
                    if (table.DT.Rows.Count == 0)
                    {
                        num3++;
                        break;
                    }
                }
            }
        }

        private void textContainer_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textContainer_Leave(object sender, EventArgs e)
        {
            if (this.textContainer.Text.Trim() != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tblContainer.ReOpen();
                string[] aField = new string[] { "Container_Number" };
                string[] aFind = new string[] { this.textContainer.Text.Trim() };
                if (this.tblContainer.GetRecNo(aField, aFind) < 0)
                {
                    this.buttonContainer.PerformClick();
                    this.textContainer.Focus();
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void textContainer_LocationChanged(object sender, EventArgs e)
        {
        }

        private void textDriverID_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textDriverID_Leave(object sender, EventArgs e)
        {
            if (this.textDriverID.Text.Trim() != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tblDriver.ReOpen();
                string[] aField = new string[] { "License_No" };
                string[] aFind = new string[] { this.textDriverID.Text.Trim() };
                int recNo = this.tblDriver.GetRecNo(aField, aFind);
                if (recNo <= -1)
                {
                    this.buttonDriver.PerformClick();
                    this.textDriverID.Focus();
                }
                else
                {
                    this.labelDriverName.Text = this.tblDriver.DT.Rows[recNo]["Name"].ToString();
                    if (this.textTruck.Text.Trim() == "")
                    {
                        this.textTruck.Text = this.tblDriver.DT.Rows[recNo]["Truck_Number"].ToString();
                        this.textTruck.Focus();
                    }
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void textHaulier_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textHaulier_Leave(object sender, EventArgs e)
        {
            if (this.textHaulier.Text.Trim() != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tblCust.ReOpen();
                string[] aField = new string[] { "Relation_code" };
                string[] aFind = new string[] { this.textHaulier.Text.Trim() };
                int recNo = this.tblCust.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelHaulierName.Text = this.tblCust.DT.Rows[recNo]["Relation_Name"].ToString();
                }
                else
                {
                    this.buttonHaulier.PerformClick();
                    this.textHaulier.Focus();
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void textOwner_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textOwner_Leave(object sender, EventArgs e)
        {
            if (this.textOwner.Text.Trim() != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tblCust.ReOpen();
                string[] aField = new string[] { "Relation_code" };
                string[] aFind = new string[] { this.textOwner.Text.Trim() };
                int recNo = this.tblCust.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelOwnerName.Text = this.tblCust.DT.Rows[recNo]["Relation_Name"].ToString();
                }
                else
                {
                    this.buttonOwner.PerformClick();
                    this.textOwner.Focus();
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void textRemark_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTrailerNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransporter_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTransporter_Leave(object sender, EventArgs e)
        {
            if (this.textTransporter.Text.Trim() != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tblTransporter.ReOpen();
                string[] aField = new string[] { "Transporter_code" };
                string[] aFind = new string[] { this.textTransporter.Text.Trim() };
                int recNo = this.tblTransporter.GetRecNo(aField, aFind);
                if (recNo > -1)
                {
                    this.labelTransporterName.Text = this.tblTransporter.DT.Rows[recNo]["Transporter_Name"].ToString();
                }
                else
                {
                    this.buttonTransporter.PerformClick();
                    this.textTransporter.Focus();
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void textTruck_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void textTruck_Leave(object sender, EventArgs e)
        {
            if (this.textTruck.Text.Trim() != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                string[] textArray1 = new string[] { " and ((Submit_Gatepass = 'N') OR (submit_gatepass is null) or (submit_gatepass = ''))  and ( Deleted = 'N' or Deleted is null)   and ( Reject = 'N' or Reject is null)   and (Truck_number = '", this.textTruck.Text, "')  and (TA_number <>'", this.textTA_Number.Text, "')" };
                this.sqlTmp = "select gatepass_number, ref, truck_number from wb_gatepass WHERE " + WBData.CompanyLocation(string.Concat(textArray1));
                this.tblTmp.OpenTable("wb_tmpGatepass", this.sqlTmp, WBData.conn);
                if (this.tblTmp.DT.Rows.Count > 0)
                {
                    this.tblTmp.DR = this.tblTmp.DT.Rows[0];
                    MessageBox.Show(Resource.Mes_167, Resource.Title_002);
                    this.textTruck.SelectAll();
                    this.textTruck.Focus();
                }
                else
                {
                    this.tblTruck.ReOpen();
                    string[] aField = new string[] { "Truck_Number" };
                    string[] aFind = new string[] { this.textTruck.Text.Trim() };
                    int recNo = this.tblTruck.GetRecNo(aField, aFind);
                    if (recNo <= -1)
                    {
                        this.buttonTruck.PerformClick();
                        this.textTruck.Focus();
                    }
                    else
                    {
                        this.textTruck.Text = this.tblTruck.DT.Rows[recNo]["Truck_Number"].ToString().Trim();
                        if ((this.textTransporter.Text == "") && (this.tblTruck.DT.Rows[recNo]["Transporter_Code"].ToString().Trim() != ""))
                        {
                            this.textTransporter.Text = this.tblTruck.DT.Rows[recNo]["Transporter_Code"].ToString().Trim();
                            string[] textArray4 = new string[] { "Transporter_Code" };
                            string[] textArray5 = new string[] { this.textTransporter.Text };
                            DataRow data = this.tblTransporter.GetData(textArray4, textArray5);
                            if (data != null)
                            {
                                this.labelTransporterName.Text = data["Transporter_Name"].ToString().Trim();
                            }
                        }
                    }
                    Cursor.Current = Cursors.Default;
                }
            }
        }

        private void translate()
        {
            this.label1.Text = Resource.TruckE_001;
            this.label5.Text = Resource.TruckE_002;
            this.label46.Text = Resource.TruckE_003;
            this.label10.Text = Resource.TruckE_004;
            this.labelRelation.Text = Resource.TruckE_005;
            this.label9.Text = Resource.TruckE_006;
            this.labelTransTypeName.Text = Resource.TruckE_007;
            this.label12.Text = Resource.TruckE_008;
            this.label6.Text = Resource.TruckE_009;
            this.label7.Text = Resource.TruckE_010;
            this.label11.Text = Resource.TruckE_011;
            this.labelLink.Text = Resource.TruckE_012;
            this.label3.Text = Resource.TruckE_013;
            this.label4.Text = Resource.TruckE_014;
            this.label8.Text = Resource.TruckE_015;
            this.buttonAdopt.Text = Resource.TruckE_016;
            this.buttonSave.Text = Resource.TruckE_017;
            this.buttonCancel.Text = Resource.TruckE_018;
            this.labelTransType.Text = Resource.Gatepass_023;
        }

        private void TransType()
        {
            string[] aField = new string[] { "transaction_code" };
            string[] aFind = new string[] { this.comTransType.Text.Trim() };
            this.tblTransType.DR = this.tblTransType.GetData(aField, aFind);
            this.labelTransTypeName.Text = (this.tblTransType.DR == null) ? "" : this.tblTransType.DR["transaction_name"].ToString();
        }

        private void TransType_Leave()
        {
        }
    }
}

