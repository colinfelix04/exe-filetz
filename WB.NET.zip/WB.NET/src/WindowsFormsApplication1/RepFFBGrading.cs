﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;

    public class RepFFBGrading : Form
    {
        private WBTable tblRendemen = new WBTable();
        public string tableDeduction;
        private string sqlTrans = "";
        private string relation_code1 = "";
        private string relation_code2 = "";
        private int countGrad = 0;
        private int no = 0;
        private int idxGrad = 0;
        private int jlhKolomA = 0;
        private int recNo = 0;
        private double bruto = 0.0;
        private double tarra = 0.0;
        private double netto = 0.0;
        private double received = 0.0;
        private double bunch = 0.0;
        private double reject = 0.0;
        private double sbruto = 0.0;
        private double starra = 0.0;
        private double snetto = 0.0;
        private double sreceived = 0.0;
        private double sreceivedAVG = 0.0;
        private double sbunch = 0.0;
        private double sreject = 0.0;
        private double pDeduc = 0.0;
        private double oercpo = 0.0;
        private double soercpo = 0.0;
        private double rvcpo = 0.0;
        private double srvcpo = 0.0;
        private double tnetto = 0.0;
        private double gunnyBunch = 0.0;
        private double gunnyKG = 0.0;
        private double tgunnyBunch = 0.0;
        private double tgunnyKG = 0.0;
        private double gtgunnyBunch = 0.0;
        private double gtgunnyKG = 0.0;
        private double rvpk = 0.0;
        private double oerpk = 0.0;
        private double soerpk = 0.0;
        private double srvpk = 0.0;
        private double toerpk = 0.0;
        private double trvpk = 0.0;
        private double tbruto = 0.0;
        private double ttarra = 0.0;
        private double txnetto = 0.0;
        private double treceived = 0.0;
        private double treceivedAVG = 0.0;
        private double tbunch = 0.0;
        private double treject = 0.0;
        private double tpDeduc = 0.0;
        private double toercpo = 0.0;
        private double trvcpo = 0.0;
        private double unit = 0.0;
        private double tunit = 0.0;
        private double[] vDeduc;
        private double[] tvDeduc;
        private double[] gtDeduc;
        private IContainer components = null;
        public Label labelRecNo;
        public Label labelProcess;
        public Button button2;
        public Button button1;
        public Label label5;
        public DateTimePicker monthCalendar1;
        public DateTimePicker monthCalendar2;
        private CheckBox cbGunny;
        private CheckBox checkFFBKg;
        public Label label2;
        private ComboBox comboCom;
        private GroupBox groupFType;
        private CheckBox checkR;
        private CheckBox checkK;
        private CheckBox checkS;
        private CheckBox checkB;
        private CheckBox checkM;
        public GroupBox grType;
        private RadioButton rboAll;
        public RadioButton rboGI;
        public RadioButton rboGR;
        public GroupBox groupBox1;
        public Label label3;
        public Label label4;

        public RepFFBGrading()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.monthCalendar2.Value - this.monthCalendar1.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (this.comboCom.Text.Trim() == "")
            {
                MessageBox.Show("Please choose commodity!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.comboCom.Focus();
            }
            else
            {
                int index = 0;
                string[] source = new string[5];
                foreach (Control control in this.groupFType.Controls)
                {
                    CheckBox box = control as CheckBox;
                    if ((box != null) && box.Checked)
                    {
                        source[index] = box.Text;
                        index++;
                    }
                }
                WBTable table = new WBTable();
                WBTable table2 = new WBTable();
                table2.OpenTable("wb_comm_grading", "select * from wb_commodity_grading where " + WBData.CompanyLocation(" AND comm_code = '" + this.comboCom.Text + "'"), WBData.conn);
                this.countGrad = table2.DT.Rows.Count * 2;
                this.vDeduc = new double[this.countGrad];
                this.tvDeduc = new double[this.countGrad];
                this.gtDeduc = new double[this.countGrad];
                WBTable table3 = new WBTable();
                string[] textArray1 = new string[] { " and (report_date >= '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), " 00:00:00' and  report_date <= '", this.monthCalendar2.Value.ToString("yyyy-MM-dd"), " 00:00:00')" };
                this.sqlTrans = "Select sum(NETTO) as netto from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray1));
                this.sqlTrans = this.sqlTrans + " and comm_code ='" + this.comboCom.Text + "' ";
                this.sqlTrans = this.sqlTrans + " and (deleted is null or deleted = 'N' or deleted = '') ";
                if (this.rboGI.Checked)
                {
                    this.sqlTrans = this.sqlTrans + " and IO = 'O' ";
                }
                else if (this.rboGR.Checked)
                {
                    this.sqlTrans = this.sqlTrans + " and IO = 'I' ";
                }
                if (index <= 0)
                {
                    this.sqlTrans = this.sqlTrans + " and (Fruits_type = '' or Fruits_type is null) ";
                }
                else
                {
                    int num4 = 0;
                    while (true)
                    {
                        if (num4 >= source.Count<string>())
                        {
                            this.sqlTrans = this.sqlTrans + " ) ";
                            break;
                        }
                        if (source[num4] != "")
                        {
                            this.sqlTrans = (num4 != 0) ? (this.sqlTrans + " or Fruits_type = '" + source[num4] + "' ") : (this.sqlTrans + " and ( Fruits_type = '" + source[num4] + "' ");
                        }
                        num4++;
                    }
                }
                table3.OpenTable("vw_trans", this.sqlTrans, WBData.conn);
                if (table3.DT.Rows.Count <= 0)
                {
                    MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    table3.DR = table3.DT.Rows[0];
                    this.tnetto = Program.StrToDouble(table3.DR["Netto"].ToString(), 0);
                    string[] textArray2 = new string[] { " and (report_date >= '", this.monthCalendar1.Value.ToString("yyyy-MM-dd"), " 00:00:00' and  report_date <= '", this.monthCalendar2.Value.ToString("yyyy-MM-dd"), " 00:00:00')" };
                    this.sqlTrans = "Select * from vw_trans where " + WBData.CompanyLocation(string.Concat(textArray2));
                    this.sqlTrans = this.sqlTrans + " and comm_code = '" + this.comboCom.Text + "' ";
                    this.sqlTrans = this.sqlTrans + " and (deleted is null or deleted = 'N' or deleted = '') ";
                    if (this.rboGI.Checked)
                    {
                        this.sqlTrans = this.sqlTrans + " and IO = 'O' ";
                    }
                    else if (this.rboGR.Checked)
                    {
                        this.sqlTrans = this.sqlTrans + " and IO = 'I' ";
                    }
                    if (index <= 0)
                    {
                        this.sqlTrans = this.sqlTrans + " and (Fruits_type = '' or Fruits_type is null) ";
                    }
                    else
                    {
                        int num5 = 0;
                        while (true)
                        {
                            if (num5 >= source.Count<string>())
                            {
                                this.sqlTrans = this.sqlTrans + " ) ";
                                break;
                            }
                            if (source[num5] != "")
                            {
                                this.sqlTrans = (num5 != 0) ? (this.sqlTrans + " or Fruits_type = '" + source[num5] + "' ") : (this.sqlTrans + " and ( Fruits_type = '" + source[num5] + "' ");
                            }
                            num5++;
                        }
                    }
                    this.sqlTrans = this.sqlTrans + " order by relation_Code , ref ";
                    table3.OpenTable("vw_trans", this.sqlTrans, WBData.conn);
                    if (table3.DT.Rows.Count > 0)
                    {
                        this.labelRecNo.Text = "0/" + table3.DT.Rows.Count.ToString();
                        this.labelRecNo.Refresh();
                        this.labelProcess.Refresh();
                        HTML html = new HTML();
                        string str = (this.tableDeduction == "wb_transactionPorla") ? "PORLA REPORT" : "GRADING REPORT";
                        HTML html2 = html;
                        string[] textArray3 = new string[] { html2.File, @"\", WBUser.UserID, "_", str, ".htm" };
                        html2.File = string.Concat(textArray3);
                        html.Title = str;
                        html.Open();
                        html.Write(html.Style());
                        html.Write("<br><font size=5><b>" + str + "</b></font><br>");
                        string[] textArray4 = new string[] { "<br><font size=4>", WBData.sCoyName, " (", WBData.sCoyCode, ")</font>" };
                        html.Write(string.Concat(textArray4));
                        string[] textArray5 = new string[] { "<br><font size=4>", WBSetting.tblLocation.DR["Location_Name"].ToString(), " (", WBData.sLocCode, ")</font><br>" };
                        html.Write(string.Concat(textArray5));
                        if (WBSetting.tblSetting.DR["Coy_Addr1"].ToString() != "")
                        {
                            html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr1"].ToString() + "</font><br>");
                        }
                        if (WBSetting.tblSetting.DR["Coy_Addr2"].ToString() != "")
                        {
                            html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr2"].ToString() + "</font><br>");
                        }
                        if (WBSetting.tblSetting.DR["Coy_Addr3"].ToString() != "")
                        {
                            html.Write("<font size=2>" + WBSetting.tblSetting.DR["Coy_Addr3"].ToString() + "</font><br>");
                        }
                        html.Write("<br><br>");
                        string str2 = Program.getFieldValue("wb_commodity", "Comm_Name", "comm_code", this.comboCom.Text);
                        html.Write("<table rules=all border=0 cellpadding=0 cellspacing=-1>");
                        html.Write("<tr class=bd>");
                        html.Write("<td>Commodity</td>");
                        string[] textArray6 = new string[] { "<td>: <b>", this.comboCom.Text.Trim(), " - ", str2, "</b></td>" };
                        html.Write(string.Concat(textArray6));
                        html.Write("</tr>");
                        html.Write("<tr class=bd>");
                        html.Write("<td>Selected Date</td>");
                        string[] textArray7 = new string[] { "<td>: <b>", this.monthCalendar1.Value.ToShortDateString(), "</b> to <b>", this.monthCalendar2.Value.ToShortDateString(), "</b></td>" };
                        html.Write(string.Concat(textArray7));
                        html.Write("</tr>");
                        html.Write("<tr class=bd>");
                        html.Write("<td>Report Date</td>");
                        html.Write("<td>: <b>" + DateTime.Now.ToShortDateString() + "</b></td>");
                        html.Write("</tr>");
                        html.Write("</table>");
                        html.Write("<br/><br/><br/>");
                        html.Write("<table border=1 rules=all cellpadding=3 cellspacing=-1>");
                        html.Write("<tr class='bd'>");
                        html.Write("<td nowrap rowspan='3' align=center><b>No.</b></td>");
                        this.jlhKolomA++;
                        html.Write("<td rowspan=3' align=center><b>Relation</b></td>");
                        this.jlhKolomA++;
                        html.Write("<td rowspan=3' align=center><b>Unit</b></td>");
                        this.jlhKolomA++;
                        html.Write("<td rowspan='3' align=center><b>Total Received</b></td>");
                        this.jlhKolomA++;
                        html.Write("<td rowspan='3' align=center><b>Total Bunch</b></td>");
                        this.jlhKolomA++;
                        html.Write("<td rowspan='3' align=center><b>Average</b></td>");
                        this.jlhKolomA++;
                        if (table2.DT.Rows.Count > 0)
                        {
                            int num6 = this.countGrad + (this.cbGunny.Checked ? 2 : 0);
                            html.Write("<td colspan='" + num6.ToString() + "' align=center><b>Deduction</b></td>");
                        }
                        if (this.tableDeduction != "wb_transactionPorla")
                        {
                            html.Write("<td rowspan='2' colspan = '2' align=center><b>Total Sortasi Grading</b></td>");
                            html.Write("<td rowspan='2' colspan = '2' align=center><b>Total Potongan</b></td>");
                            html.Write("<td rowspan='3' align=center><b>RV CPO</b></td>");
                            html.Write("<td rowspan='3' align=center><b>RV PK</b></td>");
                            if (this.checkFFBKg.Checked)
                            {
                                html.Write("<td rowspan='3' align=center><b>Buah REJECT (KG)</b></td>");
                            }
                            else
                            {
                                html.Write("<td rowspan='3' align=center><b>Buah REJECT (Bunch)</b></td>");
                            }
                            html.Write("<td rowspan='3' align=center><b>% TBS / SUpplier</b></td>");
                        }
                        html.Write("</tr>");
                        html.Write("<tr class='bd'>");
                        this.idxGrad = 0;
                        foreach (DataRow row in table2.DT.Rows)
                        {
                            html.Write("<td colspan='2' align=center><b>" + row["Code"] + "</b></td>");
                            this.vDeduc[this.idxGrad] = 0.0;
                            this.idxGrad++;
                        }
                        if (this.cbGunny.Checked)
                        {
                            html.Write("<td colspan='2' align=center><b>Gunny</b></td>");
                        }
                        html.Write("</tr>");
                        html.Write("<tr class='bd'>");
                        this.idxGrad = 0;
                        foreach (DataRow row2 in table2.DT.Rows)
                        {
                            if ((row2["Deduc_by"].ToString() == "2") || (row2["Deduc_by"].ToString() == "1"))
                            {
                                html.Write("<td align=center><b>%</b></td>");
                            }
                            else
                            {
                                html.Write("<td align=center><b>Bunch</b></td>");
                            }
                            html.Write("<td align=center><b>KG</b></td>");
                        }
                        if (this.cbGunny.Checked)
                        {
                            html.Write("<td align=center><b>Bunch</b></td>");
                        }
                        if (this.cbGunny.Checked)
                        {
                            html.Write("<td align=center><b>KG</b></td>");
                        }
                        if (this.tableDeduction != "wb_transactionPorla")
                        {
                            html.Write("<td  align=center><b>Bunch</b></td>");
                            html.Write("<td  align=center><b>KG</b></td>");
                            html.Write("<td  align=center><b>%</b></td>");
                            html.Write("<td  align=center><b>KG</b></td>");
                        }
                        html.Write("</tr>");
                        table3.DR = table3.DT.Rows[0];
                        this.relation_code1 = table3.DR["Relation_code"].ToString();
                        this.relation_code2 = "";
                        this.no = 0;
                        this.sreject = 0.0;
                        this.sbruto = 0.0;
                        this.starra = 0.0;
                        this.snetto = 0.0;
                        this.sreceived = 0.0;
                        this.sbunch = 0.0;
                        this.recNo = 0;
                        this.treject = 0.0;
                        this.tbruto = 0.0;
                        this.ttarra = 0.0;
                        this.txnetto = 0.0;
                        this.treceived = 0.0;
                        this.tbunch = 0.0;
                        this.soercpo = 0.0;
                        this.srvcpo = 0.0;
                        this.toercpo = 0.0;
                        this.trvcpo = 0.0;
                        this.rvpk = 0.0;
                        this.soerpk = 0.0;
                        this.srvpk = 0.0;
                        this.toerpk = 0.0;
                        this.trvpk = 0.0;
                        this.tpDeduc = 0.0;
                        this.unit = 0.0;
                        this.tunit = 0.0;
                        this.sreceivedAVG = 0.0;
                        this.treceivedAVG = 0.0;
                        this.gunnyBunch = 0.0;
                        this.gunnyKG = 0.0;
                        this.tgunnyBunch = 0.0;
                        this.tgunnyKG = 0.0;
                        this.labelProcess.Visible = true;
                        this.labelRecNo.Visible = true;
                        this.labelProcess.Refresh();
                        this.labelRecNo.Refresh();
                        double num3 = 0.0;
                        foreach (DataRow row3 in table3.DT.Rows)
                        {
                            this.recNo++;
                            string[] textArray8 = new string[] { this.relation_code1, "/", this.recNo.ToString(), "/", table3.DT.Rows.Count.ToString() };
                            this.labelRecNo.Text = string.Concat(textArray8);
                            this.labelRecNo.Refresh();
                            this.relation_code2 = row3["Relation_Code"].ToString();
                            this.bruto = Program.StrToDouble(row3["Bruto"].ToString(), 0);
                            this.tarra = Program.StrToDouble(row3["Tarra"].ToString(), 0);
                            this.netto = Program.StrToDouble(row3["Netto"].ToString(), 0);
                            bool flag29 = this.checkFFBKg.Checked;
                            this.reject = !flag29 ? Program.StrToDouble(row3["TBS_Reject"].ToString(), 0) : (Program.StrToDouble(row3["TBS_Reject"].ToString(), 2) * Program.StrToDouble(row3["Average"].ToString(), 2));
                            this.bunch = Program.StrToDouble(row3["TotalBunch"].ToString(), 0);
                            this.received = this.bruto - this.tarra;
                            this.rvcpo = Program.StrToDouble(row3["Rend_CPO"].ToString(), 2);
                            this.rvpk = this.hitRVPK(row3["average"].ToString());
                            num3 = Program.StrToDouble(row3["WeightPerUnitName"].ToString(), 2);
                            this.gunnyBunch = Program.StrToDouble(row3["TotalBunch"].ToString(), 0);
                            this.gunnyKG = num3 * this.gunnyBunch;
                            this.oercpo = (this.rvcpo * this.netto) / 100.0;
                            this.oerpk = (this.rvpk * this.netto) / 100.0;
                            if (this.relation_code1 != this.relation_code2)
                            {
                                this.no++;
                                html.Write("<tr class='bd'>");
                                html.Write("<td nowrap >" + this.no.ToString() + "</td>");
                                html.Write("<td nowrap>" + html.strq(this.relation_code1) + "</td>");
                                html.Write("<td nowrap align=right>" + html.strq($"{this.unit:N0}") + "</td>");
                                html.Write("<td nowrap align=right>" + html.strq($"{this.sreceived:N0}") + "</td>");
                                html.Write("<td nowrap align=right>" + html.strq($"{this.sbunch:N0}") + "</td>");
                                if (this.sbunch > 0.0)
                                {
                                    html.Write("<td nowrap align=right>" + html.strq($"{this.sreceivedAVG / this.sbunch:N2}") + "</td>");
                                }
                                else
                                {
                                    html.Write("<td nowrap align=right>0.00</td>");
                                }
                                this.idxGrad = 0;
                                foreach (DataRow row4 in table2.DT.Rows)
                                {
                                    if ((row4["Deduc_by"].ToString() != "2") && (row4["Deduc_by"].ToString() != "1"))
                                    {
                                        html.Write("<td nowrap align=right>" + html.strq($"{this.tvDeduc[this.idxGrad]:N0}") + "</td>");
                                    }
                                    else
                                    {
                                        this.pDeduc = (this.tvDeduc[this.idxGrad + 1] / this.sreceived) * 100.0;
                                        html.Write("<td nowrap align=right>" + html.strq($"{this.pDeduc:N2}") + "</td>");
                                    }
                                    this.idxGrad++;
                                    html.Write("<td nowrap align=right>" + html.strq($"{this.tvDeduc[this.idxGrad]:N0}") + "</td>");
                                    this.idxGrad++;
                                }
                                if (this.cbGunny.Checked)
                                {
                                    html.Write("<td nowrap align=right>" + html.strq($"{this.tgunnyBunch:N0}" + "</td>"));
                                }
                                if (this.cbGunny.Checked)
                                {
                                    html.Write("<td nowrap align=right>" + html.strq($"{this.tgunnyKG:N0}") + "</td>");
                                }
                                if (this.tableDeduction != "wb_transactionPorla")
                                {
                                    html.Write("<td nowrap align=right>" + html.strq($"{this.sbunch:N0}") + "</td>");
                                    html.Write("<td nowrap align=right>" + html.strq($"{this.snetto:N0}") + "</td>");
                                    html.Write("<td nowrap align=right>" + html.strq($"{(((this.sbruto - this.starra) - this.snetto) / this.sreceived) * 100.0:N2}") + "</td>");
                                    html.Write("<td nowrap align=right>" + html.strq($"{(this.sbruto - this.starra) - this.snetto:N0}") + "</td>");
                                    this.srvcpo = (this.soercpo * 100.0) / this.snetto;
                                    this.srvpk = (this.soerpk * 100.0) / this.snetto;
                                    html.Write("<td nowrap align=right>" + html.strq($"{this.srvcpo:N2}") + "</td>");
                                    html.Write("<td nowrap align=right>" + html.strq($"{this.srvpk:N2}") + "</td>");
                                    html.Write("<td align=right>" + html.strq($"{this.sreject:N0}") + "</td>");
                                    html.Write("<td align=right>" + html.strq($"{(this.snetto / this.tnetto) * 100.0:N2}") + "</td>");
                                }
                                this.sreject = 0.0;
                                this.sbruto = 0.0;
                                this.starra = 0.0;
                                this.snetto = 0.0;
                                this.sreceived = 0.0;
                                this.sreceivedAVG = 0.0;
                                this.sbunch = 0.0;
                                this.soercpo = 0.0;
                                this.srvcpo = 0.0;
                                this.soerpk = 0.0;
                                this.srvpk = 0.0;
                                this.unit = 0.0;
                                this.tgunnyKG = 0.0;
                                this.tgunnyBunch = 0.0;
                                int num7 = 0;
                                while (true)
                                {
                                    if (num7 >= this.countGrad)
                                    {
                                        this.relation_code1 = this.relation_code2;
                                        html.Write("</tr>");
                                        break;
                                    }
                                    this.tvDeduc[num7] = 0.0;
                                    num7++;
                                }
                            }
                            this.sreject += this.reject;
                            this.sbruto += this.bruto;
                            this.starra += this.tarra;
                            this.snetto += this.netto;
                            this.sreceived += this.received;
                            if (this.bunch > 0.0)
                            {
                                this.sreceivedAVG += this.received;
                                this.treceivedAVG += this.received;
                            }
                            this.sbunch += this.bunch;
                            this.soercpo += this.oercpo;
                            this.soerpk += this.oerpk;
                            this.toercpo += this.oercpo;
                            this.toerpk += this.oerpk;
                            this.tgunnyBunch += (num3 > 0.0) ? this.gunnyBunch : 0.0;
                            this.tgunnyKG += (num3 > 0.0) ? this.gunnyKG : 0.0;
                            this.gtgunnyBunch += (num3 > 0.0) ? this.gunnyBunch : 0.0;
                            this.gtgunnyKG += (num3 > 0.0) ? this.gunnyKG : 0.0;
                            this.ttarra += this.tarra;
                            this.tbruto += this.bruto;
                            this.txnetto += this.netto;
                            this.treceived += this.received;
                            this.tbunch += this.bunch;
                            this.treject += this.reject;
                            this.unit++;
                            this.tunit++;
                            this.idxGrad = 0;
                            foreach (DataRow row5 in table2.DT.Rows)
                            {
                                string[] textArray9 = new string[] { " and ref = '", row3["Ref"].ToString(), "' and code = '", row5["Code"].ToString(), "'" };
                                table.OpenTable(this.tableDeduction, "Select * from " + this.tableDeduction + " where " + WBData.CompanyLocation(string.Concat(textArray9)), WBData.conn);
                                if (table.DT.Rows.Count <= 0)
                                {
                                    this.vDeduc[this.idxGrad] = 0.0;
                                    this.tvDeduc[this.idxGrad] += this.vDeduc[this.idxGrad];
                                    this.gtDeduc[this.idxGrad] += this.vDeduc[this.idxGrad];
                                    this.idxGrad++;
                                    this.vDeduc[this.idxGrad] = 0.0;
                                    this.tvDeduc[this.idxGrad] += this.vDeduc[this.idxGrad];
                                    this.gtDeduc[this.idxGrad] += this.vDeduc[this.idxGrad];
                                    this.idxGrad++;
                                    continue;
                                }
                                table.DR = table.DT.Rows[0];
                                if ((row5["Deduc_by"].ToString() == "2") || (row5["Deduc_by"].ToString() == "1"))
                                {
                                    this.vDeduc[this.idxGrad] = Program.StrToDouble(table.DR["pDeduc"].ToString(), 0);
                                    this.tvDeduc[this.idxGrad] += this.vDeduc[this.idxGrad];
                                    this.gtDeduc[this.idxGrad] += this.vDeduc[this.idxGrad];
                                    this.idxGrad++;
                                }
                                else
                                {
                                    this.vDeduc[this.idxGrad] = Program.StrToDouble(table.DR["QtyBunch"].ToString(), 0);
                                    this.tvDeduc[this.idxGrad] += this.vDeduc[this.idxGrad];
                                    this.gtDeduc[this.idxGrad] += this.vDeduc[this.idxGrad];
                                    this.idxGrad++;
                                }
                                this.vDeduc[this.idxGrad] = Program.StrToDouble(table.DR["kgDeduc"].ToString(), 0);
                                this.tvDeduc[this.idxGrad] += this.vDeduc[this.idxGrad];
                                this.gtDeduc[this.idxGrad] += this.vDeduc[this.idxGrad];
                                this.idxGrad++;
                            }
                        }
                        this.no++;
                        html.Write("<tr class='bd'>");
                        html.Write("<td nowrap >" + this.no.ToString() + "</td>");
                        html.Write("<td nowrap>" + html.strq(this.relation_code1) + "</td>");
                        html.Write("<td nowrap align=right>" + html.strq($"{this.unit:N0}") + "</td>");
                        html.Write("<td nowrap align=right>" + html.strq($"{this.sreceived:N0}") + "</td>");
                        html.Write("<td nowrap align=right>" + html.strq($"{this.sbunch:N0}") + "</td>");
                        if (this.sbunch > 0.0)
                        {
                            html.Write("<td nowrap align=right>" + html.strq($"{this.sreceivedAVG / this.sbunch:N2}") + "</td>");
                        }
                        else
                        {
                            html.Write("<td nowrap align=right>0.00</td>");
                        }
                        this.idxGrad = 0;
                        foreach (DataRow row6 in table2.DT.Rows)
                        {
                            if ((row6["Deduc_by"].ToString() != "2") && (row6["Deduc_by"].ToString() != "1"))
                            {
                                html.Write("<td nowrap align=right>" + html.strq($"{this.tvDeduc[this.idxGrad]:N0}") + "</td>");
                            }
                            else
                            {
                                this.pDeduc = (this.tvDeduc[this.idxGrad + 1] / this.sreceived) * 100.0;
                                html.Write("<td nowrap align=right>" + html.strq($"{this.pDeduc:N2}") + "</td>");
                            }
                            this.idxGrad++;
                            html.Write("<td nowrap align=right>" + html.strq($"{this.tvDeduc[this.idxGrad]:N0}") + "</td>");
                            this.idxGrad++;
                        }
                        if (this.cbGunny.Checked)
                        {
                            html.Write("<td nowrap align=right>" + html.strq($"{this.tgunnyBunch:N0}" + "</td>"));
                        }
                        if (this.cbGunny.Checked)
                        {
                            html.Write("<td nowrap align=right>" + html.strq($"{this.tgunnyKG:N0}") + "</td>");
                        }
                        if (this.tableDeduction != "wb_transactionPorla")
                        {
                            html.Write("<td nowrap align=right>" + html.strq($"{this.sbunch:N0}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{this.snetto:N0}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{(((this.sbruto - this.starra) - this.snetto) / this.sreceived) * 100.0:N2}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{(this.sbruto - this.starra) - this.snetto:N0}") + "</td>");
                            this.srvcpo = (this.soercpo * 100.0) / this.snetto;
                            this.srvpk = (this.soerpk * 100.0) / this.snetto;
                            html.Write("<td nowrap align=right>" + html.strq($"{this.srvcpo:N2}") + "</td>");
                            html.Write("<td nowrap align=right>" + html.strq($"{this.srvpk:N2}") + "</td>");
                            html.Write("<td align=right>" + html.strq($"{this.sreject:N0}") + "</td>");
                            html.Write("<td align=right>" + html.strq($"{(this.snetto / this.tnetto) * 100.0:N2}") + "</td>");
                        }
                        html.Write("</tr>");
                        html.Write("<tr class='bd'>");
                        html.Write("<td colspan='2' align=center nowrap ><b>TOTAL</b></td>");
                        html.Write("<td nowrap align=right><b>" + html.strq($"{this.tunit:N0}") + "</b></td>");
                        html.Write("<td nowrap align=right><b>" + html.strq($"{this.treceived:N0}") + "</b></td>");
                        html.Write("<td nowrap align=right><b>" + html.strq($"{this.tbunch:N0}") + "</b></td>");
                        if (this.sbunch > 0.0)
                        {
                            html.Write("<td nowrap align=right><b>" + html.strq($"{this.treceivedAVG / this.tbunch:N2}") + "</b></td>");
                        }
                        else
                        {
                            html.Write("<td nowrap align=right><b>0.00</b></td>");
                        }
                        this.idxGrad = 0;
                        foreach (DataRow row7 in table2.DT.Rows)
                        {
                            if ((row7["Deduc_by"].ToString() != "2") && (row7["Deduc_by"].ToString() != "1"))
                            {
                                html.Write("<td nowrap align=right><b>" + html.strq($"{this.gtDeduc[this.idxGrad]:N0}") + "</b></td>");
                            }
                            else
                            {
                                this.pDeduc = (this.gtDeduc[this.idxGrad + 1] / this.treceived) * 100.0;
                                html.Write("<td nowrap align=right><b>" + html.strq($"{this.pDeduc:N2}") + "</b></td>");
                            }
                            this.idxGrad++;
                            html.Write("<td nowrap align=right><b>" + html.strq($"{this.gtDeduc[this.idxGrad]:N0}") + "</b></td>");
                            this.idxGrad++;
                        }
                        if (this.cbGunny.Checked)
                        {
                            html.Write("<td nowrap align=right>" + html.strq($"{this.gtgunnyBunch:N0}" + "</td>"));
                        }
                        if (this.cbGunny.Checked)
                        {
                            html.Write("<td nowrap align=right>" + html.strq($"{this.gtgunnyKG:N0}") + "</td>");
                        }
                        if (this.tableDeduction != "wb_transactionPorla")
                        {
                            html.Write("<td nowrap align=right><b>" + html.strq($"{this.tbunch:N0}") + "</b></td>");
                            html.Write("<td nowrap align=right><b>" + html.strq($"{this.tnetto:N0}") + "</b></td>");
                            html.Write("<td nowrap align=right><b>" + html.strq($"{(((this.tbruto - this.ttarra) - this.txnetto) / this.treceived) * 100.0:N2}") + "</td>");
                            html.Write("<td nowrap align=right><b>" + html.strq($"{(this.tbruto - this.ttarra) - this.tnetto:N0}") + "</b></td>");
                            this.trvcpo = (this.toercpo * 100.0) / this.txnetto;
                            html.Write("<td nowrap align=right><b>" + html.strq($"{this.trvcpo:N2}") + "</b></td>");
                            this.trvpk = (this.toerpk * 100.0) / this.txnetto;
                            html.Write("<td nowrap align=right><b>" + html.strq($"{this.trvpk:N2}") + "</b></td>");
                            html.Write("<td align=right><b>" + html.strq($"{this.treject:N0}") + "</b></td>");
                            html.Write("<td align=right><b>100</b></td>");
                        }
                        html.Write("</tr>");
                        html.Write("</table>");
                        html.Write("<br><br><br>");
                        html.writeSign();
                        html.Close();
                        ViewReport report = new ViewReport {
                            webBrowser1 = { Url = new Uri("file:///" + html.File) }
                        };
                        report.ShowDialog();
                        html.Dispose();
                        report.Dispose();
                    }
                    else
                    {
                        MessageBox.Show("No Records Found.", "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private string getRendPK(string bjr)
        {
            string str = "";
            if (this.tblRendemen.DT.Rows.Count > 0)
            {
                if (Program.StrToDouble(bjr, 2) >= Program.StrToDouble(this.tblRendemen.DT.Rows[0]["BJR"].ToString(), 2))
                {
                    if (Program.StrToDouble(bjr, 2) <= Program.StrToDouble(this.tblRendemen.DT.Rows[this.tblRendemen.DT.Rows.Count - 1]["BJR"].ToString(), 2))
                    {
                        int num = 0;
                        while (true)
                        {
                            if (num < this.tblRendemen.DT.Rows.Count)
                            {
                                if (!(Program.StrToDouble(bjr, 2) == Program.StrToDouble(this.tblRendemen.DT.Rows[num]["BJR"].ToString(), 2)))
                                {
                                    num++;
                                    continue;
                                }
                                return this.tblRendemen.DT.Rows[num]["Rend_PK"].ToString();
                            }
                            else if (str == "")
                            {
                                str = "0";
                            }
                            break;
                        }
                    }
                    else
                    {
                        return this.tblRendemen.DT.Rows[this.tblRendemen.DT.Rows.Count - 1]["Rend_PK"].ToString();
                    }
                }
                else
                {
                    return this.tblRendemen.DT.Rows[0]["Rend_PK"].ToString();
                }
            }
            return str;
        }

        private double hitRVPK(string bjr)
        {
            string pStr = WBSetting.Field("FormulaRendemen").ToString().ToUpper().Trim();
            ExpressionVariabel owner = new ExpressionVariabel {
                NET = 0.0
            };
            string str4 = (Program.StrToDouble(bjr, 0) + 1.0).ToString();
            string newValue = this.getRendPK(str4);
            if (newValue == "")
            {
                newValue = "0";
            }
            str4 = Program.StrToDouble(bjr, 0).ToString();
            string str3 = this.getRendPK(str4);
            pStr = pStr.Replace("BJR", bjr).Replace("REND1", newValue).Replace("REND2", str3);
            return ((pStr == "") ? 0.0 : Program.eval(pStr, owner));
        }

        private void InitializeComponent()
        {
            this.labelRecNo = new Label();
            this.labelProcess = new Label();
            this.button2 = new Button();
            this.button1 = new Button();
            this.label5 = new Label();
            this.monthCalendar1 = new DateTimePicker();
            this.monthCalendar2 = new DateTimePicker();
            this.cbGunny = new CheckBox();
            this.checkFFBKg = new CheckBox();
            this.label2 = new Label();
            this.comboCom = new ComboBox();
            this.groupFType = new GroupBox();
            this.checkR = new CheckBox();
            this.checkK = new CheckBox();
            this.checkS = new CheckBox();
            this.checkB = new CheckBox();
            this.checkM = new CheckBox();
            this.grType = new GroupBox();
            this.rboAll = new RadioButton();
            this.rboGI = new RadioButton();
            this.rboGR = new RadioButton();
            this.groupBox1 = new GroupBox();
            this.label3 = new Label();
            this.label4 = new Label();
            this.groupFType.SuspendLayout();
            this.grType.SuspendLayout();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.labelRecNo.AutoSize = true;
            this.labelRecNo.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelRecNo.Location = new Point(0x1d7, 0x16);
            this.labelRecNo.Name = "labelRecNo";
            this.labelRecNo.Size = new Size(0x1b, 13);
            this.labelRecNo.TabIndex = 0x60;
            this.labelRecNo.Text = "0/0";
            this.labelRecNo.Visible = false;
            this.labelRecNo.Click += new EventHandler(this.labelRecNo_Click);
            this.labelProcess.AutoSize = true;
            this.labelProcess.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProcess.Location = new Point(0x13f, 0x16);
            this.labelProcess.Name = "labelProcess";
            this.labelProcess.Size = new Size(0x72, 13);
            this.labelProcess.TabIndex = 0x5f;
            this.labelProcess.Text = "Processing Record";
            this.labelProcess.Visible = false;
            this.button2.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button2.Location = new Point(0x1a6, 0xf3);
            this.button2.Name = "button2";
            this.button2.Size = new Size(110, 0x24);
            this.button2.TabIndex = 0x5e;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.button1.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.button1.Location = new Point(0x132, 0xf3);
            this.button1.Name = "button1";
            this.button1.Size = new Size(110, 0x25);
            this.button1.TabIndex = 0x5d;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label5.Location = new Point(15, 15);
            this.label5.Name = "label5";
            this.label5.Size = new Size(0xc7, 20);
            this.label5.TabIndex = 90;
            this.label5.Text = "Grading Report for FFB";
            this.monthCalendar1.Format = DateTimePickerFormat.Short;
            this.monthCalendar1.Location = new Point(60, 0x11);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new Size(0x69, 20);
            this.monthCalendar1.TabIndex = 0x63;
            this.monthCalendar2.Format = DateTimePickerFormat.Short;
            this.monthCalendar2.Location = new Point(0xd5, 0x11);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.Size = new Size(0x69, 20);
            this.monthCalendar2.TabIndex = 100;
            this.cbGunny.AutoSize = true;
            this.cbGunny.Location = new Point(0x13, 0xce);
            this.cbGunny.Name = "cbGunny";
            this.cbGunny.Size = new Size(0x99, 0x11);
            this.cbGunny.TabIndex = 0x9e;
            this.cbGunny.Text = "Show Deduction by Gunny";
            this.cbGunny.UseVisualStyleBackColor = true;
            this.checkFFBKg.AutoSize = true;
            this.checkFFBKg.Location = new Point(0x13, 0xe4);
            this.checkFFBKg.Name = "checkFFBKg";
            this.checkFFBKg.Size = new Size(0x8a, 0x11);
            this.checkFFBKg.TabIndex = 0x9f;
            this.checkFFBKg.Text = "Show FFB Reject in KG";
            this.checkFFBKg.UseVisualStyleBackColor = true;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0x10, 0xab);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x3a, 13);
            this.label2.TabIndex = 160;
            this.label2.Text = "Commodity";
            this.comboCom.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboCom.FormattingEnabled = true;
            this.comboCom.Location = new Point(0x58, 0xa8);
            this.comboCom.Name = "comboCom";
            this.comboCom.Size = new Size(0x98, 0x15);
            this.comboCom.TabIndex = 0xa1;
            this.groupFType.Controls.Add(this.checkR);
            this.groupFType.Controls.Add(this.checkK);
            this.groupFType.Controls.Add(this.checkS);
            this.groupFType.Controls.Add(this.checkB);
            this.groupFType.Controls.Add(this.checkM);
            this.groupFType.Location = new Point(0x138, 0x3b);
            this.groupFType.Name = "groupFType";
            this.groupFType.Size = new Size(220, 0x2d);
            this.groupFType.TabIndex = 0xa2;
            this.groupFType.TabStop = false;
            this.groupFType.Text = "Fruit Type";
            this.checkR.AutoSize = true;
            this.checkR.Checked = true;
            this.checkR.CheckState = CheckState.Checked;
            this.checkR.Location = new Point(0xb0, 20);
            this.checkR.Name = "checkR";
            this.checkR.Size = new Size(0x22, 0x11);
            this.checkR.TabIndex = 4;
            this.checkR.Text = "R";
            this.checkR.UseVisualStyleBackColor = true;
            this.checkK.AutoSize = true;
            this.checkK.Checked = true;
            this.checkK.CheckState = CheckState.Checked;
            this.checkK.Location = new Point(0x89, 20);
            this.checkK.Name = "checkK";
            this.checkK.Size = new Size(0x21, 0x11);
            this.checkK.TabIndex = 3;
            this.checkK.Text = "K";
            this.checkK.UseVisualStyleBackColor = true;
            this.checkS.AutoSize = true;
            this.checkS.Checked = true;
            this.checkS.CheckState = CheckState.Checked;
            this.checkS.Location = new Point(0x62, 20);
            this.checkS.Name = "checkS";
            this.checkS.Size = new Size(0x21, 0x11);
            this.checkS.TabIndex = 2;
            this.checkS.Text = "S";
            this.checkS.UseVisualStyleBackColor = true;
            this.checkB.AutoSize = true;
            this.checkB.Checked = true;
            this.checkB.CheckState = CheckState.Checked;
            this.checkB.Location = new Point(0x3b, 20);
            this.checkB.Name = "checkB";
            this.checkB.Size = new Size(0x21, 0x11);
            this.checkB.TabIndex = 1;
            this.checkB.Text = "B";
            this.checkB.UseVisualStyleBackColor = true;
            this.checkM.AutoSize = true;
            this.checkM.Checked = true;
            this.checkM.CheckState = CheckState.Checked;
            this.checkM.Location = new Point(0x12, 20);
            this.checkM.Name = "checkM";
            this.checkM.Size = new Size(0x23, 0x11);
            this.checkM.TabIndex = 0;
            this.checkM.Text = "M";
            this.checkM.UseVisualStyleBackColor = true;
            this.grType.Controls.Add(this.rboAll);
            this.grType.Controls.Add(this.rboGI);
            this.grType.Controls.Add(this.rboGR);
            this.grType.Location = new Point(0x13, 0x3b);
            this.grType.Name = "grType";
            this.grType.Size = new Size(0x11a, 0x2d);
            this.grType.TabIndex = 0xa3;
            this.grType.TabStop = false;
            this.grType.Text = "Report Type";
            this.rboAll.AutoSize = true;
            this.rboAll.Checked = true;
            this.rboAll.Location = new Point(0x12, 0x12);
            this.rboAll.Name = "rboAll";
            this.rboAll.Size = new Size(0x24, 0x11);
            this.rboAll.TabIndex = 0x7c;
            this.rboAll.TabStop = true;
            this.rboAll.Text = "All";
            this.rboAll.UseVisualStyleBackColor = true;
            this.rboGI.AutoSize = true;
            this.rboGI.Location = new Point(0xba, 0x12);
            this.rboGI.Name = "rboGI";
            this.rboGI.Size = new Size(0x4f, 0x11);
            this.rboGI.TabIndex = 0x11;
            this.rboGI.Text = "Good Issue";
            this.rboGI.UseVisualStyleBackColor = true;
            this.rboGR.AutoSize = true;
            this.rboGR.Location = new Point(0x49, 0x12);
            this.rboGR.Name = "rboGR";
            this.rboGR.Size = new Size(0x5e, 0x11);
            this.rboGR.TabIndex = 0x10;
            this.rboGR.Text = "Good Receive";
            this.rboGR.UseVisualStyleBackColor = true;
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.monthCalendar1);
            this.groupBox1.Controls.Add(this.monthCalendar2);
            this.groupBox1.Location = new Point(0x13, 110);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x15b, 0x30);
            this.groupBox1.TabIndex = 0xa4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Date";
            this.label3.AutoSize = true;
            this.label3.Location = new Point(0x15, 0x15);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x21, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "From:";
            this.label4.AutoSize = true;
            this.label4.Location = new Point(0xb8, 0x15);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x17, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "To:";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x232, 310);
            base.ControlBox = false;
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.grType);
            base.Controls.Add(this.groupFType);
            base.Controls.Add(this.comboCom);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.checkFFBKg);
            base.Controls.Add(this.cbGunny);
            base.Controls.Add(this.labelRecNo);
            base.Controls.Add(this.labelProcess);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.label5);
            base.Name = "RepFFBGrading";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "FFB Grading Report";
            base.Load += new EventHandler(this.RepFFBGrading_Load);
            base.KeyPress += new KeyPressEventHandler(this.RepFFBGrading_KeyPress);
            this.groupFType.ResumeLayout(false);
            this.groupFType.PerformLayout();
            this.grType.ResumeLayout(false);
            this.grType.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void labelRecNo_Click(object sender, EventArgs e)
        {
        }

        private void RepFFBGrading_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void RepFFBGrading_Load(object sender, EventArgs e)
        {
            this.tblRendemen.OpenTable("wb_rendemen", "select * from wb_rendemen where " + WBData.CompanyLocation("") + " order by bjr asc", WBData.conn);
            WBTable table = new WBTable();
            table.OpenTable("wb_commodity", "select * from wb_commodity where " + WBData.CompanyLocation(" AND type='F'"), WBData.conn);
            foreach (DataRow row in table.DT.Rows)
            {
                this.comboCom.Items.Add(row["Comm_Code"].ToString());
            }
            table.Dispose();
        }
    }
}

