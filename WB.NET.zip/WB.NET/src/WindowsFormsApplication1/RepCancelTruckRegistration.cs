﻿namespace WindowsFormsApplication1
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class RepCancelTruckRegistration : Form
    {
        private IContainer components = null;
        private Label label1;
        private GroupBox groupBox1;
        private Label lblTo;
        private Label lblFrom;
        private DateTimePicker toDate;
        private Button btnProcess;
        private Button btnCancel;
        public Label labelProses1;
        public Label labelProses2;
        private DateTimePicker fromDate;

        public RepCancelTruckRegistration()
        {
            this.InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            string str = this.fromDate.Value.ToShortDateString();
            string str2 = this.toDate.Value.ToShortDateString();
            int num = 0;
            if ((this.toDate.Value - this.fromDate.Value).Days > 31.0)
            {
                MessageBox.Show(Resource.Rep01_044, "N O T I C E", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                WBTable table = new WBTable();
                string[] textArray1 = new string[9];
                textArray1[0] = "select dri.name as driver_name,gp.License_No as license_no,gp.Create_Date as register_date,gp.RegCard_No as card_no, gp.Gatepass_Number as gatepass_number,gp.Truck_Number as truck_number,trdo.DO_No as do_no,trdo.Relation_Name as relation_name, gp.reason as reason, comm.Comm_Name as comm_name,usr.user_name as deleted_by, gp.delete_date as delete_date from wb_gatepass as gp WITH (NOLOCK)left join wb_transDO trdo on gp.Gatepass_Number = trdo.gatepass_number left join wb_driver dri on gp.License_No = dri.License_No and gp.Coy = dri.Coy and gp.Location_Code = dri.Location_Code left join wb_commodity comm on trdo.Comm_Code = comm.comm_code and trdo.Coy = comm.Coy and trdo.Location_Code = comm.Location_Code LEFT JOIN wb_user as usr ON usr.user_id = gp.delete_by AND usr.coy = gp.coy AND usr.location_code = gp.location_code where gp.coy = '";
                textArray1[1] = WBData.sCoyCode;
                textArray1[2] = "' and gp.location_code = '";
                textArray1[3] = WBData.sLocCode;
                textArray1[4] = "' and gp.deleted = 'Y' and (gp.create_date between '";
                textArray1[5] = Program.DTOC(this.fromDate.Value);
                textArray1[6] = " 00:00:00' and '";
                textArray1[7] = Program.DTOC(this.toDate.Value);
                textArray1[8] = " 23:59:59')";
                table.OpenTable("wb_gatepass", string.Concat(textArray1), WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    Cursor.Current = Cursors.Default;
                    MessageBox.Show("No Data to Show", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    HTML html = new HTML();
                    html.File = html.File + @"\_ListofCancelRegistration.htm";
                    html.Title = "List of Cancel Truck Registration";
                    html.Open();
                    html.Write(html.Style());
                    html.Write("<br><font size=5><b>LIST OF CANCEL TRUCK REGISTRATION</b></font><br>");
                    html.Write("<br><font size=4>" + WBData.sCoyName + "</font>");
                    html.Write("<br><font size=3>" + WBSetting.tblLocation.DR["Location_Name"].ToString() + "</font>");
                    html.Write("<br>");
                    html.Write("<br><font size=3> Selected Date ");
                    if (this.fromDate.Value.ToShortDateString() != this.toDate.Value.ToShortDateString())
                    {
                        html.Write(this.fromDate.Value.ToShortDateString() + " to " + this.toDate.Value.ToShortDateString() + "</font>");
                    }
                    else
                    {
                        html.Write(this.fromDate.Value.ToShortDateString() + "</font>");
                    }
                    html.Write("<br><font size=3>Generate Date " + WBUtility.GetServerDatetime().ToShortDateString() + "</font>");
                    html.Write("<br><br>");
                    html.Write("<table border=4 rules=all cellpadding=3 cellspacing=-1>");
                    html.Write("<tr>");
                    html.Write("<td>No.</td>");
                    html.Write("<td>Register Date</td>");
                    html.Write("<td>Gatepass Number</td>");
                    html.Write("<td>Card No</td>");
                    html.Write("<td>Truck Number</td>");
                    html.Write("<td>License ID</td>");
                    html.Write("<td>Driver Name</td>");
                    html.Write("<td>WB DO</td>");
                    html.Write("<td>Commodity Name</td>");
                    html.Write("<td>Relation Name</td>");
                    html.Write("<td>Canceled By</td>");
                    html.Write("<td>Cancel Date</td>");
                    html.Write("<td>Cancel Reason</td>");
                    html.Write("</tr>");
                    foreach (DataRow row in table.DT.Rows)
                    {
                        num++;
                        this.labelProses1.Text = num + " / " + table.DT.Rows.Count;
                        this.labelProses2.Text = !string.IsNullOrEmpty(row["gatepass_number"].ToString()) ? row["gatepass_number"].ToString() : "";
                        this.labelProses1.Refresh();
                        this.labelProses2.Refresh();
                        html.Write("<tr>");
                        html.Write("<td>" + num + "</td>");
                        html.Write("<td>" + (!string.IsNullOrEmpty(row["register_date"].ToString()) ? row["register_date"].ToString() : "&nbsp") + "</td>");
                        html.Write("<td>" + (!string.IsNullOrEmpty(row["gatepass_number"].ToString()) ? row["gatepass_number"].ToString() : "&nbsp") + "</td>");
                        html.Write("<td>" + (!string.IsNullOrEmpty(row["card_no"].ToString()) ? row["card_no"].ToString() : "&nbsp") + "</td>");
                        html.Write("<td>" + (!string.IsNullOrEmpty(row["truck_number"].ToString()) ? row["truck_number"].ToString() : "&nbsp") + "</td>");
                        html.Write("<td>" + (!string.IsNullOrEmpty(row["license_no"].ToString()) ? row["license_no"].ToString() : "&nbsp") + "</td>");
                        html.Write("<td>" + (!string.IsNullOrEmpty(row["driver_name"].ToString()) ? row["driver_name"].ToString() : "&nbsp") + "</td>");
                        html.Write("<td>" + (!string.IsNullOrEmpty(row["do_no"].ToString()) ? row["do_no"].ToString() : "&nbsp") + "</td>");
                        html.Write("<td>" + (!string.IsNullOrEmpty(row["comm_name"].ToString()) ? row["comm_name"].ToString() : "&nbsp") + "</td>");
                        html.Write("<td>" + (!string.IsNullOrEmpty(row["relation_name"].ToString()) ? row["relation_name"].ToString() : "&nbsp") + "</td>");
                        html.Write("<td>" + (!string.IsNullOrEmpty(row["deleted_by"].ToString()) ? row["deleted_by"].ToString() : "&nbsp") + "</td>");
                        html.Write("<td>" + (!string.IsNullOrEmpty(row["delete_date"].ToString()) ? row["delete_date"].ToString() : "&nbsp") + "</td>");
                        html.Write("<td>" + (!string.IsNullOrEmpty(row["reason"].ToString()) ? row["reason"].ToString() : "&nbsp") + " </td>");
                        html.Write("</tr>");
                    }
                    html.Write("</table>");
                    html.Write("<br>");
                    html.Write("<br>");
                    html.Close();
                    ViewReport report = new ViewReport {
                        webBrowser1 = { Url = new Uri("file:///" + html.File) }
                    };
                    Cursor.Current = Cursors.Default;
                    report.ShowDialog();
                    report.Dispose();
                    this.labelProses1.Text = "";
                    this.labelProses2.Text = "";
                }
            }
        }

        private void CheckDate()
        {
            this.fromDate.MaxDate = this.toDate.Value;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void fromDate_ValueChanged(object sender, EventArgs e)
        {
            this.CheckDate();
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.groupBox1 = new GroupBox();
            this.lblTo = new Label();
            this.lblFrom = new Label();
            this.toDate = new DateTimePicker();
            this.fromDate = new DateTimePicker();
            this.btnProcess = new Button();
            this.btnCancel = new Button();
            this.labelProses1 = new Label();
            this.labelProses2 = new Label();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Microsoft Sans Serif", 15.75f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x123, 0x19);
            this.label1.TabIndex = 0;
            this.label1.Text = "List of Cancel Registration";
            this.groupBox1.Controls.Add(this.lblTo);
            this.groupBox1.Controls.Add(this.lblFrom);
            this.groupBox1.Controls.Add(this.toDate);
            this.groupBox1.Controls.Add(this.fromDate);
            this.groupBox1.Location = new Point(0x2b, 0x41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x1e3, 0x41);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.lblTo.AutoSize = true;
            this.lblTo.Location = new Point(0xff, 30);
            this.lblTo.Name = "lblTo";
            this.lblTo.Size = new Size(0x31, 13);
            this.lblTo.TabIndex = 3;
            this.lblTo.Text = "To Date:";
            this.lblFrom.AutoSize = true;
            this.lblFrom.Location = new Point(7, 30);
            this.lblFrom.Name = "lblFrom";
            this.lblFrom.Size = new Size(0x3b, 13);
            this.lblFrom.TabIndex = 2;
            this.lblFrom.Text = "From Date:";
            this.toDate.Location = new Point(310, 0x1b);
            this.toDate.Name = "toDate";
            this.toDate.Size = new Size(150, 20);
            this.toDate.TabIndex = 1;
            this.toDate.ValueChanged += new EventHandler(this.toDate_ValueChanged);
            this.fromDate.Location = new Point(0x48, 0x1b);
            this.fromDate.Name = "fromDate";
            this.fromDate.Size = new Size(0x99, 20);
            this.fromDate.TabIndex = 0;
            this.fromDate.ValueChanged += new EventHandler(this.fromDate_ValueChanged);
            this.btnProcess.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btnProcess.Location = new Point(0x15f, 0x99);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new Size(80, 0x23);
            this.btnProcess.TabIndex = 2;
            this.btnProcess.Text = "Process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new EventHandler(this.btnProcess_Click);
            this.btnCancel.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.btnCancel.Location = new Point(0x1be, 0x99);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(80, 0x23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);
            this.labelProses1.AutoSize = true;
            this.labelProses1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses1.Location = new Point(0x202, 8);
            this.labelProses1.Name = "labelProses1";
            this.labelProses1.Size = new Size(0x37, 13);
            this.labelProses1.TabIndex = 0x31;
            this.labelProses1.Text = "1/88888";
            this.labelProses2.AutoSize = true;
            this.labelProses2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.labelProses2.Location = new Point(0x1e2, 0x15);
            this.labelProses2.Name = "labelProses2";
            this.labelProses2.Size = new Size(0x38, 13);
            this.labelProses2.TabIndex = 0x30;
            this.labelProses2.Text = "Progress";
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x23f, 0xd0);
            base.ControlBox = false;
            base.Controls.Add(this.labelProses1);
            base.Controls.Add(this.labelProses2);
            base.Controls.Add(this.btnCancel);
            base.Controls.Add(this.btnProcess);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.label1);
            base.Name = "RepCancelRegistration";
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Cancel Registration Report";
            base.Load += new EventHandler(this.RepCancelRegistration_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void RepCancelRegistration_Load(object sender, EventArgs e)
        {
            this.toDate.MaxDate = DateTime.Now;
            this.fromDate.MaxDate = DateTime.Now;
            this.labelProses1.Text = "";
            this.labelProses2.Text = "";
        }

        private void toDate_ValueChanged(object sender, EventArgs e)
        {
            this.CheckDate();
        }
    }
}

