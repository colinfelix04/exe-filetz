﻿namespace WindowsFormsApplication1
{
    using Encryption.Utility;
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.Utility;

    public class FormRegistrationKeyRenew : Form
    {
        private WBTable getActivation = new WBTable();
        private DataTable decryptedTable = null;
        public bool valid = false;
        private string siteCode = "";
        private string dateToActivate = "";
        private string numberOfWB = "";
        private string dateToRenew = "";
        private string siteCodeDB = "";
        private string dateToActivateDB = "";
        private string numberOfWBDB = "";
        private string dateToRenewDB = "";
        private IContainer components = null;
        private Label label1;
        private TextBox textKey;
        private Label label4;
        private Button buttonProcess;
        private Button buttonCancel;
        private Label labelCurrentKey;
        private Label labelValidDate;
        private Label label6;
        private Label labelMaxWB;
        private Label label8;
        private Label labelMaintenance;
        private Label label10;
        private Label label2;
        private Label labelCompany;
        private Label label7;

        public FormRegistrationKeyRenew()
        {
            this.InitializeComponent();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonProcess_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.valid = this.checkRegKey();
            if (this.valid)
            {
                base.Close();
            }
        }

        private bool checkRegKey()
        {
            bool flag2;
            try
            {
                if (!this.isKeyValid())
                {
                    Cursor.Current = Cursors.Default;
                    MessageBox.Show("Activation key is not valid. Please contact WCS to get a valid one.", "KEY IS NOT VALID", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    flag2 = false;
                }
                else
                {
                    char[] separator = new char[] { '|' };
                    string[] strArray = WBEncryption.Decrypt(this.textKey.Text.Trim(), "R3gK3y4wb").Split(separator);
                    this.siteCode = strArray[0];
                    string[] textArray1 = new string[] { strArray[1].ToString().Substring(0, 2), "-", strArray[1].ToString().Substring(2, 2), "-", strArray[1].ToString().Substring(4) };
                    this.dateToActivate = Convert.ToDateTime(string.Concat(textArray1)).ToString("dd/MM/yyyy");
                    string[] textArray2 = new string[] { strArray[3].ToString().Substring(0, 2), "-", strArray[3].ToString().Substring(2, 2), "-", strArray[3].ToString().Substring(4) };
                    this.dateToRenew = Convert.ToDateTime(string.Concat(textArray2)).ToString("dd/MM/yyyy");
                    this.numberOfWB = strArray[2].ToString().Substring(2);
                    if (DateTime.Now.Date > Convert.ToDateTime(this.dateToActivateDB).Date)
                    {
                        Cursor.Current = Cursors.Default;
                        object[] objArray2 = new object[5];
                        objArray2[0] = "Activation date is expired. Key must be used before ";
                        string[] textArray3 = new string[] { this.dateToActivate.Substring(0, 2), "-", this.dateToActivate.Substring(2, 2), "-", this.dateToActivate.Substring(4) };
                        objArray2[1] = Convert.ToDateTime(string.Concat(textArray3)).Date;
                        objArray2[2] = ".";
                        objArray2[3] = Environment.NewLine;
                        objArray2[4] = "Please contact WCS if you need further support.";
                        MessageBox.Show(string.Concat(objArray2), "ACTIVATION DATE IS NOT VALID", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        flag2 = false;
                    }
                    else if (this.siteCode != this.siteCodeDB)
                    {
                        Cursor.Current = Cursors.Default;
                        MessageBox.Show("Entered activation key is not valid for this site. " + Environment.NewLine + "Please contact WCS for further support.", "ACTIVATION KEY IS NOT VALID", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        flag2 = false;
                    }
                    else
                    {
                        DataRow[] rowArray = this.decryptedTable.Select(" param LIKE 'WB|%' ");
                        if (Convert.ToInt32(this.numberOfWB) < Convert.ToInt32(rowArray.Length))
                        {
                            Cursor.Current = Cursors.Default;
                            object[] objArray1 = new object[9];
                            objArray1[0] = "Entered activation key is not valid for maximum of registered WB(s). ";
                            objArray1[1] = Environment.NewLine;
                            objArray1[2] = "New key is valid for ";
                            objArray1[3] = this.numberOfWB;
                            objArray1[4] = " WB(s) while currently ";
                            objArray1[5] = rowArray.Length;
                            objArray1[6] = " WB(s) is registred in the system.";
                            objArray1[7] = Environment.NewLine;
                            objArray1[8] = "Please maintain activation key usage first or contact WCS for further support.";
                            MessageBox.Show(string.Concat(objArray1), "ACTIVATION KEY IS NOT VALID", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            flag2 = false;
                        }
                        else
                        {
                            WBTable table = new WBTable();
                            table.OpenTable("wb_act", "SELECT * FROM wb_act WHERE param = '" + WBEncryption.Encrypt("key", "encryptDATA") + "'", WBData.conn);
                            if (table.DT.Rows.Count > 0)
                            {
                                table.DR = table.DT.Rows[0];
                                table.DR.BeginEdit();
                                table.DR["val"] = WBEncryption.Encrypt(this.textKey.Text.Trim(), "encryptDATA");
                                table.DR.EndEdit();
                                table.Save();
                            }
                            table.Dispose();
                            string str2 = "'" + rowArray[0][0].ToString() + "'";
                            int index = 1;
                            while (true)
                            {
                                if (index >= rowArray.Length)
                                {
                                    WBTable table2 = new WBTable();
                                    table2.OpenTable("wb_act", "SELECT * FROM wb_act WHERE param IN (" + str2 + ")", WBData.conn);
                                    string strToEncrypt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                                    int num2 = 0;
                                    while (true)
                                    {
                                        if (num2 >= table2.DT.Rows.Count)
                                        {
                                            table2.Dispose();
                                            WBTable table3 = new WBTable();
                                            table3.OpenTable("wb_location", "SELECT uniq, GM FROM wb_location", WBData.conn);
                                            int num3 = 0;
                                            while (true)
                                            {
                                                if (num3 >= table3.DT.Rows.Count)
                                                {
                                                    table3.Dispose();
                                                    WBTable table4 = new WBTable();
                                                    table4.OpenTable("wb_condition", "SELECT * FROM wb_condition WHERE condition_code = 'ACTIVATION_KEY_IS_EXPIRED'", WBData.conn);
                                                    int num4 = 0;
                                                    while (true)
                                                    {
                                                        if (num4 >= table4.DT.Rows.Count)
                                                        {
                                                            table4.Dispose();
                                                            this.loadDataForFirstTime();
                                                            Cursor.Current = Cursors.Default;
                                                            MessageBox.Show("Activation key is RENEWED." + Environment.NewLine + "Please close WB System and reopen it to get full version of WB System.", "KEY IS RENEWED", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                                            flag2 = true;
                                                            break;
                                                        }
                                                        table4.DT.Rows[num4].Delete();
                                                        table4.Save();
                                                        num4++;
                                                    }
                                                    break;
                                                }
                                                table3.DR = table3.DT.Rows[num3];
                                                table3.DR.BeginEdit();
                                                table3.DR["GM"] = "Y";
                                                table3.DR.EndEdit();
                                                table3.Save();
                                                num3++;
                                            }
                                            break;
                                        }
                                        table2.DR = table.DT.Rows[0];
                                        table2.DR.BeginEdit();
                                        table2.DR["val"] = WBEncryption.Encrypt(strToEncrypt, "encryptDATA");
                                        table2.DR.EndEdit();
                                        table2.Save();
                                        num2++;
                                    }
                                    break;
                                }
                                str2 = str2 + ", '" + rowArray[index][0].ToString() + "'";
                                index++;
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Fail to process key: " + exception.Message + Environment.NewLine + "Please contact WCS for further support!", "FAIL TO PROCESS KEY", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                flag2 = false;
            }
            return flag2;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormRegistrationKey_Load(object sender, EventArgs e)
        {
            this.loadDataForFirstTime();
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.textKey = new TextBox();
            this.label4 = new Label();
            this.buttonProcess = new Button();
            this.buttonCancel = new Button();
            this.labelCurrentKey = new Label();
            this.labelValidDate = new Label();
            this.label6 = new Label();
            this.labelMaxWB = new Label();
            this.label8 = new Label();
            this.labelMaintenance = new Label();
            this.label10 = new Label();
            this.label2 = new Label();
            this.labelCompany = new Label();
            this.label7 = new Label();
            base.SuspendLayout();
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Underline, GraphicsUnit.Point, 0);
            this.label1.Location = new Point(0x1c, 80);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x57, 0x11);
            this.label1.TabIndex = 0;
            this.label1.Text = "Current Key:";
            this.textKey.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textKey.Location = new Point(0x21, 0x11e);
            this.textKey.Name = "textKey";
            this.textKey.Size = new Size(0x211, 0x1a);
            this.textKey.TabIndex = 5;
            this.label4.AutoSize = true;
            this.label4.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Underline | FontStyle.Bold, GraphicsUnit.Point, 0);
            this.label4.Location = new Point(0x1d, 0x22);
            this.label4.Name = "label4";
            this.label4.Size = new Size(0x11e, 0x11);
            this.label4.TabIndex = 6;
            this.label4.Text = "Enter new activation key for all WB(s):";
            this.buttonProcess.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonProcess.Location = new Point(0x148, 0x151);
            this.buttonProcess.Name = "buttonProcess";
            this.buttonProcess.Size = new Size(0x66, 0x2c);
            this.buttonProcess.TabIndex = 7;
            this.buttonProcess.Text = "Process";
            this.buttonProcess.UseVisualStyleBackColor = true;
            this.buttonProcess.Click += new EventHandler(this.buttonProcess_Click);
            this.buttonCancel.Font = new Font("Microsoft Sans Serif", 11f, FontStyle.Bold, GraphicsUnit.Point, 0);
            this.buttonCancel.Location = new Point(460, 0x151);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x66, 0x2c);
            this.buttonCancel.TabIndex = 8;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.labelCurrentKey.AutoSize = true;
            this.labelCurrentKey.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelCurrentKey.Location = new Point(0x1d, 0x67);
            this.labelCurrentKey.Name = "labelCurrentKey";
            this.labelCurrentKey.Size = new Size(0x23, 0x11);
            this.labelCurrentKey.TabIndex = 9;
            this.labelCurrentKey.Text = "KEY";
            this.labelValidDate.AutoSize = true;
            this.labelValidDate.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelValidDate.Location = new Point(30, 0x9f);
            this.labelValidDate.Name = "labelValidDate";
            this.labelValidDate.Size = new Size(0x58, 0x11);
            this.labelValidDate.TabIndex = 11;
            this.labelValidDate.Text = "VALID DATE";
            this.label6.AutoSize = true;
            this.label6.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Underline, GraphicsUnit.Point, 0);
            this.label6.Location = new Point(0x1d, 0x88);
            this.label6.Name = "label6";
            this.label6.Size = new Size(0xc4, 0x11);
            this.label6.TabIndex = 10;
            this.label6.Text = "Maximum date to register WB:";
            this.labelMaxWB.AutoSize = true;
            this.labelMaxWB.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelMaxWB.Location = new Point(0x1f, 0xd6);
            this.labelMaxWB.Name = "labelMaxWB";
            this.labelMaxWB.Size = new Size(0x3f, 0x11);
            this.labelMaxWB.TabIndex = 13;
            this.labelMaxWB.Text = "MAX WB";
            this.label8.AutoSize = true;
            this.label8.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Underline, GraphicsUnit.Point, 0);
            this.label8.Location = new Point(30, 0xbf);
            this.label8.Name = "label8";
            this.label8.Size = new Size(180, 0x11);
            this.label8.TabIndex = 12;
            this.label8.Text = "Maximum of registered WB:";
            this.labelMaintenance.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelMaintenance.Location = new Point(0x144, 0x9f);
            this.labelMaintenance.Name = "labelMaintenance";
            this.labelMaintenance.Size = new Size(0xf1, 0x11);
            this.labelMaintenance.TabIndex = 15;
            this.labelMaintenance.Text = "MAINTENANCE DATE";
            this.labelMaintenance.TextAlign = ContentAlignment.MiddleRight;
            this.label10.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Underline, GraphicsUnit.Point, 0);
            this.label10.Location = new Point(0x143, 0x88);
            this.label10.Name = "label10";
            this.label10.Size = new Size(0xf2, 0x11);
            this.label10.TabIndex = 14;
            this.label10.Text = "Next maintenance date:";
            this.label10.TextAlign = ContentAlignment.MiddleRight;
            this.label2.AutoSize = true;
            this.label2.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Underline, GraphicsUnit.Point, 0);
            this.label2.Location = new Point(0x1f, 0x109);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x43, 0x11);
            this.label2.TabIndex = 0x10;
            this.label2.Text = "New Key:";
            this.labelCompany.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelCompany.Location = new Point(0x1b5, 0x67);
            this.labelCompany.Name = "labelCompany";
            this.labelCompany.Size = new Size(0x7d, 0x11);
            this.labelCompany.TabIndex = 0x12;
            this.labelCompany.Text = "COMPANY CODE";
            this.labelCompany.TextAlign = ContentAlignment.MiddleRight;
            this.labelCompany.Visible = false;
            this.label7.Font = new Font("Microsoft Sans Serif", 10f, FontStyle.Underline, GraphicsUnit.Point, 0);
            this.label7.Location = new Point(440, 80);
            this.label7.Name = "label7";
            this.label7.Size = new Size(0x7a, 0x11);
            this.label7.TabIndex = 0x11;
            this.label7.Text = "Company Code:";
            this.label7.TextAlign = ContentAlignment.MiddleRight;
            this.label7.Visible = false;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x24c, 0x196);
            base.ControlBox = false;
            base.Controls.Add(this.labelCompany);
            base.Controls.Add(this.label7);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.labelMaintenance);
            base.Controls.Add(this.label10);
            base.Controls.Add(this.labelMaxWB);
            base.Controls.Add(this.label8);
            base.Controls.Add(this.labelValidDate);
            base.Controls.Add(this.label6);
            base.Controls.Add(this.labelCurrentKey);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonProcess);
            base.Controls.Add(this.label4);
            base.Controls.Add(this.textKey);
            base.Controls.Add(this.label1);
            base.Name = "FormRegistrationKeyRenew";
            base.ShowIcon = false;
            base.StartPosition = FormStartPosition.CenterParent;
            base.Load += new EventHandler(this.FormRegistrationKey_Load);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private bool isKeyValid()
        {
            bool flag2;
            string str = WBEncryption.Decrypt(this.textKey.Text.Trim(), "R3gK3y4wb");
            if (!str.ToLower().Contains("wrong input"))
            {
                try
                {
                    char[] separator = new char[] { '|' };
                    string[] strArray = str.Split(separator);
                    if (strArray.Length == 4)
                    {
                        if (strArray[0].Length != 3)
                        {
                            flag2 = false;
                        }
                        else
                        {
                            try
                            {
                                int num = Convert.ToInt32(strArray[0]);
                            }
                            catch
                            {
                                return false;
                            }
                            if (strArray[1].Length != 8)
                            {
                                flag2 = false;
                            }
                            else
                            {
                                try
                                {
                                    string[] textArray1 = new string[] { strArray[1].Substring(0, 2), "-", strArray[1].Substring(2, 2), "-", strArray[1].Substring(4) };
                                    DateTime time = Convert.ToDateTime(string.Concat(textArray1));
                                }
                                catch
                                {
                                    return false;
                                }
                                if (strArray[2].Length < 3)
                                {
                                    flag2 = false;
                                }
                                else if (!strArray[2].Contains("WB"))
                                {
                                    flag2 = false;
                                }
                                else
                                {
                                    try
                                    {
                                        int num2 = Convert.ToInt32(strArray[2].Substring(2));
                                    }
                                    catch
                                    {
                                        return false;
                                    }
                                    if (strArray[3].Length != 8)
                                    {
                                        flag2 = false;
                                    }
                                    else
                                    {
                                        try
                                        {
                                            string[] textArray2 = new string[] { strArray[3].Substring(0, 2), "-", strArray[3].Substring(2, 2), "-", strArray[3].Substring(4) };
                                            DateTime time2 = Convert.ToDateTime(string.Concat(textArray2));
                                        }
                                        catch
                                        {
                                            return false;
                                        }
                                        flag2 = true;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        flag2 = false;
                    }
                }
                catch
                {
                    flag2 = false;
                }
            }
            else
            {
                flag2 = false;
            }
            return flag2;
        }

        private void loadDataForFirstTime()
        {
            this.getActivation.OpenTable("wb_act", "SELECT * FROM wb_act WHERE 1 = 1", WBData.conn);
            this.decryptedTable = WBUtility.WBTableToDataTable(this.getActivation, this.decryptedTable);
            int num = 0;
            while (true)
            {
                if (num >= this.decryptedTable.Rows.Count)
                {
                    DataRow row = this.decryptedTable.Select(" param = 'key' ")[0];
                    char[] separator = new char[] { '|' };
                    string[] strArray = WBEncryption.Decrypt(row[1].ToString(), "R3gK3y4wb").Split(separator);
                    this.labelCurrentKey.Text = row[1].ToString();
                    this.siteCodeDB = strArray[0];
                    string[] textArray1 = new string[] { strArray[1].ToString().Substring(0, 2), "-", strArray[1].ToString().Substring(2, 2), "-", strArray[1].ToString().Substring(4) };
                    this.dateToActivateDB = Convert.ToDateTime(string.Concat(textArray1)).ToString("dd/MM/yyyy");
                    string[] textArray2 = new string[] { strArray[3].ToString().Substring(0, 2), "-", strArray[3].ToString().Substring(2, 2), "-", strArray[3].ToString().Substring(4) };
                    this.dateToRenewDB = Convert.ToDateTime(string.Concat(textArray2)).ToString("dd/MM/yyyy");
                    this.numberOfWBDB = strArray[2].ToString().Substring(2);
                    this.labelCurrentKey.Text = row[1].ToString();
                    this.labelCompany.Text = this.siteCodeDB;
                    this.labelValidDate.Text = this.dateToActivateDB;
                    this.labelMaintenance.Text = this.dateToRenewDB;
                    this.labelMaxWB.Text = this.numberOfWBDB;
                    return;
                }
                int num2 = 0;
                while (true)
                {
                    if (num2 >= this.decryptedTable.Columns.Count)
                    {
                        num++;
                        break;
                    }
                    if (this.decryptedTable.Columns[num2].ColumnName.ToUpper() != "UNIQ")
                    {
                        this.decryptedTable.Rows[num][num2] = WBEncryption.Decrypt(this.decryptedTable.Rows[num][num2].ToString(), "encryptDATA");
                    }
                    num2++;
                }
            }
        }
    }
}

