﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Runtime.CompilerServices;
    using System.Windows.Forms;

    public class DataModal
    {
        public DataTable DT { get; set; }

        public DataGridView DGV { get; set; }

        public SqlDataAdapter DA { get; set; }

        public DataSet DS { get; set; }
    }
}

