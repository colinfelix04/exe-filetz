﻿namespace WindowsFormsApplication1
{
    using CrystalDecisions.CrystalReports.Engine;
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Windows.Forms;
    using WindowsFormsApplication1.E_Grading;
    using WindowsFormsApplication1.TCSUtility;
    using WindowsFormsApplication1.Utility;

    public class FormTransGatepass : Form
    {
        public WBTable tblGatepass = new WBTable();
        public WBTable tblGatepassDest = new WBTable();
        private WBTable tblDeduc = new WBTable();
        private string cField;
        public bool saved;
        public string uniq = "";
        public string no = "";
        public string noCard = "";
        public string wx = "";
        public string pMode = "";
        private string cardNo = "";
        private string uniqCardNo = "";
        private bool scanStatus = false;
        public ReportDocument ticketRpt = new ReportDocument();
        public ReportDocument ticket2Rpt = new ReportDocument();
        public ReportDocument rpt_advise = new ReportDocument();
        public FormRpt fRpt;
        private IContainer components = null;
        private Button button1;
        private Button button2;
        private Label label1;
        private Label label2;
        private ComboBox comboTruck;
        public ComboBox comboGatepass;
        private Label label3;
        private TextBox textCard;
        private DataGridView dataGridView1;
        private TextBox textBox1;
        private GroupBox groupBox1;
        private Label labelScanMessage;

        public FormTransGatepass()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.comboGatepass.Text.Trim() != "")
            {
                if (!(WBSetting.activeTCS && WBSetting.gatepassWithoutCard))
                {
                    if (this.comboGatepass.Text.Trim() != "")
                    {
                        this.saved = true;
                        base.Close();
                    }
                }
                else
                {
                    WBTable table = new WBTable();
                    table.OpenTable("wb_gatepass", " SELECT WX, uniq, gatepass_number, Deleted, Submit_Gatepass, token,completed FROM wb_gatepass  WHERE gatepass_number = '" + this.comboGatepass.Text.Trim() + "'", WBData.conn);
                    if (table.DT.Rows.Count <= 0)
                    {
                        MessageBox.Show("Gatepass is not registered! Please check gatepass number!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else if (table.CekTokenCompleted(table.DT.Rows[0]["gatepass_number"].ToString(), "", "UNLOCK_TDT", false) != "")
                    {
                        MessageBox.Show("Gatepass is in-progress edit TDT by Token", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else if ((table.DT.Rows[0]["Deleted"].ToString() == "Y") || (table.DT.Rows[0]["Submit_Gatepass"].ToString() == "Y"))
                    {
                        MessageBox.Show("Gatepass has been cancelled or submitted", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else if (table.DT.Rows[0]["completed"].ToString() == "N")
                    {
                        MessageBox.Show("Gatepass is in-progress edit by Token", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        this.can_weigh(table.DT.Rows[0]["WX"].ToString(), table.DT.Rows[0]["gatepass_number"].ToString(), table.DT.Rows[0]["uniq"].ToString());
                    }
                    table.Dispose();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.saved = false;
            base.Close();
        }

        private void can_weigh(string WX, string gatepassNo, string gatepassUniq)
        {
            WBTable table = new WBTable();
            string[] textArray1 = new string[] { " SELECT * FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND gatepass_number = '", gatepassNo, "'  AND ((Deleted = 'N' OR Deleted = '' OR Deleted IS NULL) OR (Deleted = 'Y' AND cancel_type = 'R'))  AND (split = 'Y' OR split IS NULL OR split = '')  ORDER BY uniq DESC" };
            table.OpenTable("wb_transaction", string.Concat(textArray1), WBData.conn);
            string[] aField = new string[] { "Gatepass_number" };
            string[] aFind = new string[] { gatepassNo };
            DataRow data = this.tblGatepass.GetData(aField, aFind);
            if (data != null)
            {
                if (data["completed"].ToString() != "N")
                {
                    if (this.tblGatepass.CekTokenCompleted(gatepassNo, "", "UNLOCK_TDT", false) != "")
                    {
                        MessageBox.Show("Gatepass is in-progress edit TDT by Token", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Gatepass is in-progress edit by Token", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            if (WX != "0")
            {
                if (WX != "1")
                {
                    if (WX == "2")
                    {
                        this.wx = "4X";
                        if (table.DT.Rows.Count <= 0)
                        {
                            this.timbang_TCS("1ST", "", gatepassUniq, gatepassNo, true);
                        }
                        else
                        {
                            table.DR = table.DT.Rows[0];
                            if ((table.DR["_1st"].ToString() != "0") && (table.DR["_2nd"].ToString() != "0"))
                            {
                                MessageBox.Show(Resource.RegisGatepassMess_044, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                this.textBox1.Text = "";
                                this.textCard.Text = "";
                                this.comboGatepass.Text = "";
                                this.comboTruck.Text = "";
                                this.textCard.Focus();
                            }
                            else if (table.DR["_1st"].ToString() == "0")
                            {
                                this.timbang_TCS("1ST", table.DR["ref"].ToString(), gatepassUniq, gatepassNo, false);
                            }
                            else
                            {
                                this.timbang_TCS("2ND", table.DR["ref"].ToString(), gatepassUniq, gatepassNo, false);
                            }
                        }
                    }
                    else if (WX == "3")
                    {
                        if (table.DT.Rows.Count <= 0)
                        {
                            this.wx = "1X";
                            this.timbang_TCS("1ST", "", gatepassUniq, gatepassNo, true);
                        }
                        else
                        {
                            this.wx = "4X";
                            table.DR = table.DT.Rows[0];
                            if (table.DR["linked"].ToString() == "")
                            {
                                MessageBox.Show("Please linked transaction and enter loading quantity before do 4th weighing!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                this.textBox1.Text = "";
                                this.textCard.Text = "";
                                this.comboGatepass.Text = "";
                                this.comboTruck.Text = "";
                                this.textCard.Focus();
                            }
                            else
                            {
                                WBTable table12 = new WBTable();
                                string[] textArray11 = new string[] { "SELECT * FROM wb_transaction WHERE ", WBData.CompanyLocation(""), " AND ref = '", table.DR["linked"].ToString(), "' AND ((Deleted IS NULL OR Deleted = 'N' or Deleted = '') OR (Deleted = 'Y' AND cancel_type = 'R'))" };
                                table12.OpenTable("wb_transaction", string.Concat(textArray11), WBData.conn);
                                if (table12.DT.Rows.Count <= 0)
                                {
                                    MessageBox.Show("Please linked transaction and enter loading quantity before do 4th weighing!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                    this.textBox1.Text = "";
                                    this.textCard.Text = "";
                                    this.comboGatepass.Text = "";
                                    this.comboTruck.Text = "";
                                    this.textCard.Focus();
                                }
                                else
                                {
                                    table12.DR = table12.DT.Rows[0];
                                    if ((table12.DR["report_date"].ToString() != "") && (table12.DR["_4th"].ToString() != "0"))
                                    {
                                        MessageBox.Show(Resource.RegisGatepassMess_044, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                        this.textBox1.Text = "";
                                        this.textCard.Text = "";
                                        this.comboGatepass.Text = "";
                                        this.comboTruck.Text = "";
                                        this.textCard.Focus();
                                    }
                                    else
                                    {
                                        if (table.DR["_1st"].ToString() != "0")
                                        {
                                            this.timbang_TCS("4TH", table12.DT.Rows[0]["ref"].ToString(), gatepassUniq, gatepassNo, false);
                                        }
                                        else
                                        {
                                            this.wx = "1X";
                                            this.timbang_TCS("1ST", table.DR["ref"].ToString(), gatepassUniq, gatepassNo, false);
                                        }
                                        table12.Dispose();
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    this.wx = "2X";
                    if (table.DT.Rows.Count <= 0)
                    {
                        this.timbang_TCS("1ST", "", gatepassUniq, gatepassNo, true);
                    }
                    else
                    {
                        table.DR = table.DT.Rows[0];
                        if ((table.DR["report_date"].ToString() == "") || (table.DR["_2nd"].ToString() == "0"))
                        {
                            if (table.DR["_1st"].ToString() != "0")
                            {
                                WBTable table9 = new WBTable();
                                WBTable table10 = new WBTable();
                                WBCondition condition6 = new WBCondition();
                                table9.OpenTable("wb_checkComm", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + table.DT.Rows[0]["comm_code"].ToString() + "'"), WBData.conn);
                                table10.OpenTable("wb_checkTransType", "Select * from Wb_transaction_Type where " + WBData.CompanyLocation(" and transaction_code = '" + table.DT.Rows[0]["transaction_code"].ToString() + "'"), WBData.conn);
                                if (table9.DT.Rows.Count > 0)
                                {
                                    table9.DR = table9.DT.Rows[0];
                                    table10.DR = table10.DT.Rows[0];
                                    DataRow[] dgRows = new DataRow[] { table9.DR, table10.DR };
                                    condition6.fillParameter("TRANS_LOADING_QTY", dgRows);
                                    if (condition6.getResult() && (table9.DR["Unit"].ToString().ToUpper() != "KG"))
                                    {
                                        WBTable table11 = new WBTable();
                                        string[] textArray10 = new string[9];
                                        textArray10[0] = "SELECT uniq FROM wb_transdo WHERE Ref = '";
                                        textArray10[1] = table.DT.Rows[0]["ref"].ToString();
                                        textArray10[2] = "'  AND do_no = '";
                                        textArray10[3] = table.DT.Rows[0]["do_no"].ToString();
                                        textArray10[4] = "'  AND coy = '";
                                        textArray10[5] = WBData.sCoyCode;
                                        textArray10[6] = "' and location_code = '";
                                        textArray10[7] = WBData.sLocCode;
                                        textArray10[8] = "'  AND ( loading_qty IS NULL OR loading_qty = '0' )";
                                        table11.OpenTable("wb_transDO", string.Concat(textArray10), WBData.conn);
                                        if (table11.DT.Rows.Count <= 0)
                                        {
                                            table11.Dispose();
                                        }
                                        else
                                        {
                                            MessageBox.Show("Loading quantity for " + table.DT.Rows[0]["ref"].ToString() + " is 0. Please contact Warehouse!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                            this.textBox1.Text = "";
                                            this.textCard.Text = "";
                                            this.comboGatepass.Text = "";
                                            this.comboTruck.Text = "";
                                            this.textCard.Focus();
                                            return;
                                        }
                                    }
                                }
                                condition6.Dispose();
                                table9.Dispose();
                                table10.Dispose();
                                this.timbang_TCS("2ND", table.DR["ref"].ToString(), gatepassUniq, gatepassNo, false);
                            }
                            else
                            {
                                this.timbang_TCS("1ST", table.DR["ref"].ToString(), gatepassUniq, gatepassNo, false);
                            }
                        }
                        else
                        {
                            this.timbang_TCS("COPY", table.DR["ref"].ToString(), gatepassUniq, gatepassNo, true);
                        }
                    }
                }
            }
            else
            {
                this.wx = "2X";
                if (table.DT.Rows.Count <= 0)
                {
                    if (WBSetting.wb_filling_location)
                    {
                        WBTable table8 = new WBTable();
                        table8.OpenTable("wb_transaction", " select * from wb_transaction where " + WBData.CompanyLocation(" and wx <> '' and wbcode1 = '" + WBData.sWBCode + "' and wbcode2 is null and (deleted <> 'Y' or deleted is null)"), WBData.conn);
                        if (table8.DT.Rows.Count > 0)
                        {
                            string[] textArray9 = new string[9];
                            textArray9[0] = Resource.Mainform_019;
                            textArray9[1] = " ";
                            textArray9[2] = table8.DT.Rows[0]["truck_number"].ToString();
                            textArray9[3] = " ";
                            textArray9[4] = Resource.Mainform_020;
                            textArray9[5] = " ";
                            textArray9[6] = table8.DT.Rows[0]["ref"].ToString();
                            textArray9[7] = " ";
                            textArray9[8] = Resource.Mainform_021;
                            MessageBox.Show(string.Concat(textArray9), Resource.Mainform_022, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return;
                        }
                    }
                    this.timbang_TCS("1ST", "", gatepassUniq, gatepassNo, true);
                }
                else
                {
                    table.DR = table.DT.Rows[0];
                    WBTable table2 = new WBTable();
                    WBTable table3 = new WBTable();
                    WBCondition condition = new WBCondition();
                    table2.OpenTable("wb_checkComm", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + table.DT.Rows[0]["comm_code"].ToString() + "'"), WBData.conn);
                    table3.OpenTable("wb_checkTransType", "Select * from Wb_transaction_Type where " + WBData.CompanyLocation(" and transaction_code = '" + table.DT.Rows[0]["transaction_code"].ToString() + "'"), WBData.conn);
                    table2.DR = table2.DT.Rows[0];
                    table3.DR = table3.DT.Rows[0];
                    DataRow[] dgRows = new DataRow[] { table2.DR, table3.DR };
                    condition.fillParameter("TRANS_SPAREPART_QTY", dgRows);
                    if (!(condition.getResult() && (table2.DT.Rows[0]["Unit"].ToString().ToUpper() != "KG")) || string.IsNullOrEmpty(this.tblGatepass.CekTokenCompleted(table.DR["Ref"].ToString(), "", "OVER_BC_QTY", false)))
                    {
                        if ((table.DR["report_date"].ToString() == "") || (table.DR["_2nd"].ToString() == "0"))
                        {
                            if (table.DR["_1st"].ToString() != "0")
                            {
                                table2 = new WBTable();
                                table3 = new WBTable();
                                WBCondition condition2 = new WBCondition();
                                condition = new WBCondition();
                                WBCondition condition3 = new WBCondition();
                                WBCondition condition4 = new WBCondition();
                                WBCondition condition5 = new WBCondition();
                                table2.OpenTable("wb_checkComm", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + table.DT.Rows[0]["comm_code"].ToString() + "'"), WBData.conn);
                                table3.OpenTable("wb_checkTransType", "Select * from Wb_transaction_Type where " + WBData.CompanyLocation(" and transaction_code = '" + table.DT.Rows[0]["transaction_code"].ToString() + "'"), WBData.conn);
                                if (table2.DT.Rows.Count > 0)
                                {
                                    table2.DR = table2.DT.Rows[0];
                                    table3.DR = table3.DT.Rows[0];
                                    DataRow[] rowArray2 = new DataRow[] { table2.DR, table3.DR };
                                    condition.fillParameter("TRANS_SPAREPART_QTY", rowArray2);
                                    DataRow[] rowArray3 = new DataRow[] { table2.DR };
                                    condition3.fillParameter("CALC_DENSITY_TO_SPAREPARTQTY", rowArray3);
                                    DataRow[] rowArray4 = new DataRow[] { table2.DR, table3.DR };
                                    condition2.fillParameter("TRANS_LOADING_QTY", rowArray4);
                                    DataRow[] rowArray5 = new DataRow[] { table2.DR, table3.DR };
                                    condition4.fillParameter("LOADING_NO_FLOWMETER", rowArray5);
                                    DataRow[] rowArray6 = new DataRow[] { table2.DR, table3.DR };
                                    condition5.fillParameter("LOADING_WITH_FLOWMETER", rowArray6);
                                    if (!(condition4.getResult() || condition3.getResult()))
                                    {
                                        if (!condition5.getResult())
                                        {
                                            if (!(condition2.getResult() && (table2.DR["Unit"].ToString().ToUpper() != "KG")))
                                            {
                                                if ((table2.DR["Type"].ToString().ToUpper() != "F") || (table3.DR["IO"].ToString().ToUpper() != "I"))
                                                {
                                                    if (condition.getResult() && (table2.DR["Unit"].ToString().ToUpper() != "KG"))
                                                    {
                                                        WBTable table7 = new WBTable();
                                                        string[] textArray7 = new string[9];
                                                        textArray7[0] = "SELECT uniq FROM wb_transBC WHERE Ref = '";
                                                        textArray7[1] = table.DT.Rows[0]["ref"].ToString();
                                                        textArray7[2] = "'  AND do_no = '";
                                                        textArray7[3] = table.DT.Rows[0]["do_no"].ToString();
                                                        textArray7[4] = "'  AND coy = '";
                                                        textArray7[5] = WBData.sCoyCode;
                                                        textArray7[6] = "' and location_code = '";
                                                        textArray7[7] = WBData.sLocCode;
                                                        textArray7[8] = "'  AND ( item_load_qty IS NOT NULL AND item_load_qty <> '0' AND item_load_qty <> '') and (deleted is null or deleted <> 'Y')";
                                                        table7.OpenTable("wb_transBC", string.Concat(textArray7), WBData.conn);
                                                        if (table7.DT.Rows.Count != 0)
                                                        {
                                                            table7.Dispose();
                                                        }
                                                        else
                                                        {
                                                            MessageBox.Show("Sparepart quantity for " + table.DT.Rows[0]["ref"].ToString() + " is 0. Please contact STORE!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                            this.textBox1.Text = "";
                                                            this.textCard.Text = "";
                                                            this.comboGatepass.Text = "";
                                                            this.comboTruck.Text = "";
                                                            this.textCard.Focus();
                                                            return;
                                                        }
                                                    }
                                                }
                                                else if (WBSetting.activeEGrading)
                                                {
                                                    EGrading_DBIntg intg = new EGrading_DBIntg {
                                                        sServer = WBSetting.EG_Server,
                                                        sDatabase = WBSetting.EG_Database,
                                                        sUserID = WBSetting.EG_usID,
                                                        sPassword = WBSetting.EG_password
                                                    };
                                                    if (!intg.TestConnect())
                                                    {
                                                        MessageBox.Show(Resource.Mainform_029);
                                                        return;
                                                    }
                                                    else
                                                    {
                                                        this.tblDeduc.OpenTable("vw_entry_deduction", "select * from vw_entry_deduction where " + WBData.CompanyLocation(" and RefNumber = '" + table.DR["Ref"].ToString() + "' "), EGrading_DBIntg.conn);
                                                        if (this.tblDeduc.DT.Rows.Count <= 0)
                                                        {
                                                            MessageBox.Show("Grader hasn't input data. No Grading Data. ", "E R R O R");
                                                            return;
                                                        }
                                                        else
                                                        {
                                                            this.tblDeduc.Dispose();
                                                            intg.Dispose();
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                WBTable table6 = new WBTable();
                                                string[] textArray6 = new string[9];
                                                textArray6[0] = "SELECT uniq FROM wb_transdo WHERE Ref = '";
                                                textArray6[1] = table.DT.Rows[0]["ref"].ToString();
                                                textArray6[2] = "'  AND do_no = '";
                                                textArray6[3] = table.DT.Rows[0]["do_no"].ToString();
                                                textArray6[4] = "'  AND coy = '";
                                                textArray6[5] = WBData.sCoyCode;
                                                textArray6[6] = "' and location_code = '";
                                                textArray6[7] = WBData.sLocCode;
                                                textArray6[8] = "'  AND ( loading_qty IS NULL OR loading_qty = '0' )";
                                                table6.OpenTable("wb_transDO", string.Concat(textArray6), WBData.conn);
                                                if (table6.DT.Rows.Count <= 0)
                                                {
                                                    table6.Dispose();
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Loading quantity for " + table.DT.Rows[0]["ref"].ToString() + " is 0. Please contact Warehouse!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                    this.textBox1.Text = "";
                                                    this.textCard.Text = "";
                                                    this.comboGatepass.Text = "";
                                                    this.comboTruck.Text = "";
                                                    this.textCard.Focus();
                                                    return;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            WBTable table5 = new WBTable();
                                            string[] textArray5 = new string[9];
                                            textArray5[0] = "SELECT uniq FROM wb_transdo WHERE Ref = '";
                                            textArray5[1] = table.DT.Rows[0]["ref"].ToString();
                                            textArray5[2] = "'  AND do_no = '";
                                            textArray5[3] = table.DT.Rows[0]["do_no"].ToString();
                                            textArray5[4] = "'  AND coy = '";
                                            textArray5[5] = WBData.sCoyCode;
                                            textArray5[6] = "' and location_code = '";
                                            textArray5[7] = WBData.sLocCode;
                                            textArray5[8] = "'  AND( ( Density IS NULL OR Density = '0' ) or  ( loading_qty IS NULL OR loading_qty = '0' ) )";
                                            table5.OpenTable("wb_transDO", string.Concat(textArray5), WBData.conn);
                                            if (table5.DT.Rows.Count <= 0)
                                            {
                                                table5.Dispose();
                                            }
                                            else
                                            {
                                                MessageBox.Show("Density/Loading Quantity for " + table.DT.Rows[0]["ref"].ToString() + " is 0. Please contact Pumphouse!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                                this.textBox1.Text = "";
                                                this.textCard.Text = "";
                                                this.comboGatepass.Text = "";
                                                this.comboTruck.Text = "";
                                                this.textCard.Focus();
                                                return;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        WBTable table4 = new WBTable();
                                        string[] textArray4 = new string[9];
                                        textArray4[0] = "SELECT uniq FROM wb_transdo WHERE Ref = '";
                                        textArray4[1] = table.DT.Rows[0]["ref"].ToString();
                                        textArray4[2] = "'  AND do_no = '";
                                        textArray4[3] = table.DT.Rows[0]["do_no"].ToString();
                                        textArray4[4] = "'  AND coy = '";
                                        textArray4[5] = WBData.sCoyCode;
                                        textArray4[6] = "' and location_code = '";
                                        textArray4[7] = WBData.sLocCode;
                                        textArray4[8] = "'  AND ( Density IS NULL OR Density = '0' )";
                                        table4.OpenTable("wb_transDO", string.Concat(textArray4), WBData.conn);
                                        if (table4.DT.Rows.Count <= 0)
                                        {
                                            table4.Dispose();
                                        }
                                        else
                                        {
                                            if (condition4.getResult())
                                            {
                                                MessageBox.Show("Density for " + table.DT.Rows[0]["ref"].ToString() + " is 0. Please contact Pumphouse!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                            }
                                            else
                                            {
                                                MessageBox.Show("Density for " + table.DT.Rows[0]["ref"].ToString() + " is 0. Please contact STORE!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                            }
                                            this.textBox1.Text = "";
                                            this.textCard.Text = "";
                                            this.comboGatepass.Text = "";
                                            this.comboTruck.Text = "";
                                            this.textCard.Focus();
                                            return;
                                        }
                                    }
                                }
                                condition2.Dispose();
                                table2.Dispose();
                                table3.Dispose();
                                if (!WBSetting.wb_filling_location || (table.DR["Wbcode1"].ToString().ToUpper() == WBData.sWBCode.ToUpper()))
                                {
                                    this.timbang_TCS("2ND", table.DT.Rows[0]["ref"].ToString(), gatepassUniq, gatepassNo, false);
                                }
                                else
                                {
                                    string[] textArray8 = new string[0x10];
                                    textArray8[0] = Resource.Mainform_019;
                                    textArray8[1] = " ";
                                    textArray8[2] = table.DR["truck_number"].ToString();
                                    textArray8[3] = " ";
                                    textArray8[4] = Resource.Mainform_020;
                                    textArray8[5] = " ";
                                    textArray8[6] = table.DR["ref"].ToString();
                                    textArray8[7] = " ";
                                    textArray8[8] = Resource.Mainform_023;
                                    textArray8[9] = " ";
                                    textArray8[10] = table.DR["WBCode1"].ToString();
                                    textArray8[11] = ".\n\n ";
                                    textArray8[12] = Resource.Mainform_024;
                                    textArray8[13] = " ";
                                    textArray8[14] = WBData.sWBCode;
                                    textArray8[15] = "!";
                                    MessageBox.Show(string.Concat(textArray8), Resource.Mainform_022, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    return;
                                }
                            }
                            else
                            {
                                this.timbang_TCS("1ST", table.DT.Rows[0]["ref"].ToString(), gatepassUniq, gatepassNo, false);
                            }
                            table2.Dispose();
                            table3.Dispose();
                        }
                        else
                        {
                            MessageBox.Show(Resource.RegisGatepassMess_044, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            this.textBox1.Text = "";
                            this.textCard.Text = "";
                            this.comboGatepass.Text = "";
                            this.comboTruck.Text = "";
                            this.textCard.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_617, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
        }

        private void comboGatepass_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void comboGatepass_TextChanged(object sender, EventArgs e)
        {
            if (this.comboGatepass.Text.Trim() != "")
            {
                string[] aField = new string[] { "Gatepass_number" };
                string[] aFind = new string[] { this.comboGatepass.Text };
                DataRow data = this.tblGatepass.GetData(aField, aFind);
                if (data != null)
                {
                    this.comboTruck.Text = data["truck_number"].ToString();
                    this.uniq = data["uniq"].ToString();
                    this.no = data["gatepass_number"].ToString();
                    this.noCard = data["card_no"].ToString();
                }
            }
        }

        private void comboTruck_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }

        private void comboTruck_TextChanged(object sender, EventArgs e)
        {
            if (this.comboTruck.Text.Trim() != "")
            {
                string[] aField = new string[] { "Truck_number" };
                string[] aFind = new string[] { this.comboTruck.Text };
                DataRow data = this.tblGatepass.GetData(aField, aFind);
                if (data != null)
                {
                    this.comboGatepass.Text = data["Gatepass_number"].ToString();
                    this.uniq = data["uniq"].ToString();
                    this.no = data["gatepass_number"].ToString();
                    this.noCard = data["card_no"].ToString();
                    if (data["wx"].ToString() == "0")
                    {
                        this.wx = "2X";
                    }
                    else if (data["wx"].ToString() == "1")
                    {
                        this.wx = "NX";
                    }
                    else if (data["wx"].ToString() == "2")
                    {
                        this.wx = "4X";
                    }
                    else if (data["wx"].ToString() == "3")
                    {
                        this.wx = "1X";
                    }
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormTransGatepass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x001b')
            {
                base.Close();
            }
        }

        private void FormTransGatepass_Load(object sender, EventArgs e)
        {
            this.translate();
            this.labelScanMessage.Text = "";
            this.labelScanMessage.ForeColor = Color.Black;
            string sqltext = "";
            if (WBSetting.gatepass_registration)
            {
                sqltext = "SELECT uniq, WX, card_no, Gatepass_Number, Truck_Number, tanker_no, License_No, Transporter_Code, delivery_note, seal, \r\n                GatePass_Remark, In_Date, In_Time, Create_By, Create_Date, Change_By, Change_Date, completed FROM wb_gatepass \r\n                WHERE " + WBData.CompanyLocation("") + " AND (Submit_Gatepass IS NULL OR Submit_Gatepass='' OR submit_Gatepass = 'N')  AND  \r\n                (Deleted = 'N' OR Deleted IS NULL OR Deleted = '')";
            }
            else
            {
                this.cField = " Coy, Location_code, wx, card_no, Gatepass_number, TA_number,Ref, transaction_code, transporter_code,  truck_number, trailer_number,  In_Date, In_time,  Out_Date, Submit_Date, Submit_Time, GatePass_Remark,  Deleted, uniq";
                sqltext = "select " + this.cField + " from vw_gatepass_oth WHERE " + WBData.CompanyLocation(" and (Reject = 'N')AND(Gatepass_Number is not null)  And ((Ref is null) OR (Ref = ''))  And (((Submit_Gatepass IS NULL) or (Submit_Gatepass='') or (submit_Gatepass = 'N'))  AND ((Deleted = 'N') or (Deleted is null) or (Deleted =''))) and WB = '0'  order by Gatepass_Number Asc");
            }
            this.tblGatepass.OpenTable("wb_gatepass", sqltext, WBData.conn);
            if (this.tblGatepass.DT.Rows.Count > 0)
            {
                foreach (DataRow row in this.tblGatepass.DT.Rows)
                {
                    this.comboGatepass.Items.Add(row["Gatepass_number"].ToString());
                    this.comboTruck.Items.Add(row["Truck_number"].ToString());
                }
                Program.AutoCompCombo(this.tblGatepass, "Gatepass_number", this.comboGatepass);
                Program.AutoCompCombo(this.tblGatepass, "Truck_number", this.comboTruck);
            }
            if (WBSetting.activeTCS && !WBSetting.gatepassWithoutCard)
            {
                this.textCard.Focus();
                this.Text = "Scan Card";
                this.comboGatepass.Enabled = true;
                this.comboTruck.Enabled = true;
                this.button1.Visible = false;
            }
            else
            {
                this.textCard.Enabled = false;
                this.labelScanMessage.Visible = false;
                this.comboGatepass.Enabled = true;
                this.comboTruck.Enabled = true;
                this.button1.Visible = true;
            }
        }

        private void InitializeComponent()
        {
            this.button1 = new Button();
            this.button2 = new Button();
            this.label1 = new Label();
            this.label2 = new Label();
            this.comboTruck = new ComboBox();
            this.comboGatepass = new ComboBox();
            this.label3 = new Label();
            this.textCard = new TextBox();
            this.dataGridView1 = new DataGridView();
            this.textBox1 = new TextBox();
            this.groupBox1 = new GroupBox();
            this.labelScanMessage = new Label();
            ((ISupportInitialize) this.dataGridView1).BeginInit();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.button1.Location = new Point(0x3d, 0xa3);
            this.button1.Name = "button1";
            this.button1.Size = new Size(100, 0x23);
            this.button1.TabIndex = 2;
            this.button1.Text = "&OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.button2.Location = new Point(0xc2, 0xa3);
            this.button2.Name = "button2";
            this.button2.Size = new Size(100, 0x23);
            this.button2.TabIndex = 3;
            this.button2.Text = "&CANCEL (Esc)";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new EventHandler(this.button2_Click);
            this.label1.Location = new Point(0x12, 0x17);
            this.label1.Name = "label1";
            this.label1.Size = new Size(0x51, 0x12);
            this.label1.TabIndex = 4;
            this.label1.Text = "Gatepass No.";
            this.label1.TextAlign = ContentAlignment.TopRight;
            this.label2.Location = new Point(0x21, 50);
            this.label2.Name = "label2";
            this.label2.Size = new Size(0x42, 0x12);
            this.label2.TabIndex = 5;
            this.label2.Text = "Truck No.";
            this.label2.TextAlign = ContentAlignment.TopRight;
            this.comboTruck.FormattingEnabled = true;
            this.comboTruck.Location = new Point(0x69, 0x2f);
            this.comboTruck.Name = "comboTruck";
            this.comboTruck.Size = new Size(160, 0x15);
            this.comboTruck.TabIndex = 9;
            this.comboTruck.TextChanged += new EventHandler(this.comboTruck_TextChanged);
            this.comboTruck.KeyPress += new KeyPressEventHandler(this.comboTruck_KeyPress);
            this.comboGatepass.FormattingEnabled = true;
            this.comboGatepass.Location = new Point(0x69, 20);
            this.comboGatepass.Name = "comboGatepass";
            this.comboGatepass.Size = new Size(160, 0x15);
            this.comboGatepass.TabIndex = 4;
            this.comboGatepass.TextChanged += new EventHandler(this.comboGatepass_TextChanged);
            this.comboGatepass.KeyPress += new KeyPressEventHandler(this.comboGatepass_KeyPress);
            this.label3.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.label3.Location = new Point(12, 0x15);
            this.label3.Name = "label3";
            this.label3.Size = new Size(0x53, 0x12);
            this.label3.TabIndex = 6;
            this.label3.Text = "Card No.";
            this.label3.TextAlign = ContentAlignment.TopRight;
            this.textCard.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.textCard.Location = new Point(120, 0x12);
            this.textCard.Name = "textCard";
            this.textCard.Size = new Size(0xd9, 0x1a);
            this.textCard.TabIndex = 0;
            this.textCard.TextChanged += new EventHandler(this.textCard_TextChanged);
            this.textCard.KeyDown += new KeyEventHandler(this.textCard_KeyDown);
            this.textCard.KeyPress += new KeyPressEventHandler(this.textCard_KeyPress);
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new Point(0x15f, 0xc5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new Size(12, 10);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.Visible = false;
            this.textBox1.BackColor = SystemColors.Control;
            this.textBox1.BorderStyle = BorderStyle.None;
            this.textBox1.Location = new Point(0xd7, 0xae);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(10, 13);
            this.textBox1.TabIndex = 11;
            this.textBox1.TextChanged += new EventHandler(this.textBox1_TextChanged);
            this.textBox1.KeyPress += new KeyPressEventHandler(this.textBox1_KeyPress);
            this.groupBox1.Controls.Add(this.comboGatepass);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboTruck);
            this.groupBox1.Location = new Point(0x1d, 0x3a);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(0x134, 0x54);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.labelScanMessage.AutoSize = true;
            this.labelScanMessage.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.labelScanMessage.Location = new Point(0x75, 0x2f);
            this.labelScanMessage.Name = "labelScanMessage";
            this.labelScanMessage.Size = new Size(0x56, 15);
            this.labelScanMessage.TabIndex = 0x2c;
            this.labelScanMessage.Text = "ScanMessage";
            this.labelScanMessage.TextAlign = ContentAlignment.MiddleLeft;
            this.labelScanMessage.Visible = false;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x177, 0xdb);
            base.ControlBox = false;
            base.Controls.Add(this.labelScanMessage);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.button2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.textCard);
            base.Controls.Add(this.label3);
            base.Controls.Add(this.button1);
            base.KeyPreview = true;
            base.Name = "FormTransGatepass";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Choose Gatepass No / Truck No";
            base.Load += new EventHandler(this.FormTransGatepass_Load);
            base.KeyPress += new KeyPressEventHandler(this.FormTransGatepass_KeyPress);
            ((ISupportInitialize) this.dataGridView1).EndInit();
            this.groupBox1.ResumeLayout(false);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar == '\r') || (e.KeyChar == '\n')) && (this.textBox1.Text.Length == 10))
            {
                this.textCard.Text = this.textBox1.Text.Trim();
            }
            e.Handled = !char.IsDigit(e.KeyChar) && (e.KeyChar != '\b');
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void textCard_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Tuple<bool, string, string, string, string, string, string> tuple = WBCard.scanCard(this.textCard.Text, "Timbang", this.comboGatepass.Text);
                this.scanStatus = tuple.Item1;
                this.labelScanMessage.Text = tuple.Item2;
                this.textCard.Text = tuple.Item7;
                this.textCard.SelectAll();
                this.cardNo = WBCard.getUniqCardNo(this.textCard.Text);
                string[] aField = new string[] { "Card_No" };
                string[] aFind = new string[] { this.cardNo };
                DataRow data = this.tblGatepass.GetData(aField, aFind);
                if (data != null)
                {
                    this.comboGatepass.Text = data["Gatepass_Number"].ToString();
                    this.comboTruck.Text = data["Truck_Number"].ToString();
                    if (data["wx"].ToString() == "4")
                    {
                        MessageBox.Show(Resource.RegisGatepassMess_064, "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                }
                if (tuple.Item1)
                {
                    this.labelScanMessage.ForeColor = Color.Black;
                    this.can_weigh(tuple.Item5, tuple.Item4, tuple.Item6);
                }
                else
                {
                    MessageBox.Show(tuple.Item2, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.textBox1.Text = "";
                    this.comboGatepass.Text = "";
                    this.comboTruck.Text = "";
                    this.textCard.SelectAll();
                    this.textCard.Focus();
                    this.labelScanMessage.ForeColor = Color.Red;
                }
            }
        }

        private void textCard_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void textCard_TextChanged(object sender, EventArgs e)
        {
            if ((this.textCard.Text.Trim() != this.cardNo) && this.scanStatus)
            {
                this.scanStatus = false;
                this.labelScanMessage.Text = "";
            }
        }

        private void timbang_TCS(string pMode, string ref_no, string gt_uniq, string txt_gatepass, bool tambahRecord)
        {
            if ((WBSetting.checkISCC != "Y") || (((WBSetting.validDateISCC - DateTime.Now).Days + 1) > 0))
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_calibration", "SELECT TOP 1 * FROM wb_calibration WHERE (deleted<>'Y' or deleted is null) AND WBCode = '" + WBData.sWBCode + "' ORDER BY valid_date DESC", WBData.conn);
                if ((table.DT.Rows.Count <= 0) || (table.DT.Rows[0]["lock_weighing"].ToString() != "Y"))
                {
                    table.Dispose();
                    if (WBSetting.activeTCS && (((pMode != "2ND") || (this.wx != "2X")) ? ((pMode == "4TH") && (this.wx == "4X")) : true))
                    {
                        string str = "";
                        string str2 = "";
                        DataRow data = null;
                        DataRow row2 = null;
                        WBTable table3 = new WBTable();
                        table3.OpenTable("wb_transaction", "SELECT transaction_code FROM wb_transaction WHERE " + WBData.CompanyLocation(" AND ref = '" + ref_no + "'"), WBData.conn);
                        str = table3.DT.Rows[0]["transaction_code"].ToString();
                        table3.Dispose();
                        WBTable table4 = new WBTable();
                        table4.OpenTable("wb_transaction_type", "SELECT * FROM wb_transaction_type WHERE " + WBData.CompanyLocation(""), WBData.conn);
                        string[] aField = new string[] { "Transaction_Code" };
                        string[] aFind = new string[] { str };
                        data = table4.GetData(aField, aFind);
                        WBTable table5 = new WBTable();
                        table5.OpenTable("wb_gatepass", "SELECT * FROM wb_gatepass WHERE " + WBData.CompanyLocation(" AND Gatepass_Number = '" + txt_gatepass + "'"), WBData.conn);
                        row2 = table5.DT.Rows[0];
                        if ((data != null) && (row2 != null))
                        {
                            WBCondition condition = new WBCondition();
                            DataRow[] dgRows = new DataRow[] { data, row2 };
                            condition.fillParameter("GET_QC_FROM_TCS", dgRows);
                            str2 = condition.getResult() ? "Y" : "N";
                            condition.Dispose();
                        }
                        if ((str2 != "Y") || TCS_GetQC.getQCStatus(ref_no))
                        {
                            table4.Dispose();
                            table5.Dispose();
                        }
                        else
                        {
                            string[] textArray3 = new string[] { Resource.RegisGatepassMess_042, " ", ref_no, " ", Resource.RegisGatepassMess_043 };
                            MessageBox.Show(string.Concat(textArray3), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            return;
                        }
                    }
                    WBTable table2 = new WBTable();
                    string[] textArray4 = new string[] { "SELECT ", WBTable.cFieldTrans, " FROM vw_main WHERE ref = '", ref_no, "'" };
                    table2.OpenTable("wb_transaction", string.Concat(textArray4), WBData.conn);
                    if (table2.DT.Rows.Count > 0)
                    {
                        if ((table2.DT.Rows[0]["coy"].ToString() == WBData.sCoyCode) || (table2.DT.Rows[0]["location_code"].ToString() == WBData.sLocCode))
                        {
                            this.dataGridView1.DataSource = table2.DT;
                            this.dataGridView1.CurrentCell = this.dataGridView1.Rows[0].Cells[1];
                            this.dataGridView1.Rows[0].Selected = true;
                            if (!table2.BeforeEdit(this.dataGridView1, pMode))
                            {
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please check your company and location code before weighing!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            return;
                        }
                    }
                    if (((pMode != "2ND") || (this.wx != "2X")) ? ((pMode == "4TH") && (this.wx == "4X")) : true)
                    {
                        WBTable table6 = new WBTable();
                        WBTable table7 = new WBTable();
                        WBTable table8 = new WBTable();
                        WBTable table9 = new WBTable();
                        WBCondition condition2 = new WBCondition();
                        WBCondition condition3 = new WBCondition();
                        table6.OpenTable("wb_transDO", "Select * from wb_TransDO where " + WBData.CompanyLocation(" and Ref Like '" + ref_no + "%'"), WBData.conn);
                        using (IEnumerator enumerator = table6.DT.Rows.GetEnumerator())
                        {
                            while (true)
                            {
                                if (!enumerator.MoveNext())
                                {
                                    break;
                                }
                                DataRow current = (DataRow) enumerator.Current;
                                table7.OpenTable("wb_Commodity", "Select * from Wb_commodity where " + WBData.CompanyLocation(" and comm_code = '" + current["comm_code"].ToString() + "'"), WBData.conn);
                                table7.DR = table7.DT.Rows[0];
                                DataRow[] dgRows = new DataRow[] { table7.DR };
                                condition2.fillParameter("TRANS_SPAREPART_QTY", dgRows);
                                DataRow[] rowArray3 = new DataRow[] { table7.DR };
                                condition3.fillParameter("CALC_DENSITY_TO_SPAREPARTQTY", rowArray3);
                                bool flag14 = table7.DT.Rows.Count > 0;
                                if (flag14 && ((condition2.getResult() && (table7.DR["Unit"].ToString().ToUpper() != "KG")) && !condition3.getResult()))
                                {
                                    string[] textArray5 = new string[9];
                                    textArray5[0] = "select * from wb_transBC a\r\n                            where a.Coy = '";
                                    textArray5[1] = WBData.sCoyCode;
                                    textArray5[2] = "' and a.Location_Code = '";
                                    textArray5[3] = WBData.sLocCode;
                                    textArray5[4] = "' and a.Do_No = '";
                                    textArray5[5] = current["do_no"].ToString();
                                    textArray5[6] = "' and a.Ref = '";
                                    textArray5[7] = current["Ref"].ToString();
                                    textArray5[8] = "' and (a.deleted is null or a.deleted <> 'Y')";
                                    table9.OpenTable("wb_transBC", string.Concat(textArray5), WBData.conn);
                                    if (table9.DT.Rows.Count <= 0)
                                    {
                                        MessageBox.Show(Resource.Mes_618_01 + current["Do_No"].ToString() + Resource.Mes_618_02, "W A R N I N G", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        return;
                                    }
                                }
                            }
                        }
                        if (!(condition2.getResult() && (table7.DR["Unit"].ToString().ToUpper() != "KG")) || string.IsNullOrEmpty(table8.CekTokenCompleted(ref_no, "", "OVER_BC_QTY", false)))
                        {
                            table6.Dispose();
                            table8.Dispose();
                            table9.Dispose();
                            condition2.Dispose();
                            table7.Dispose();
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_617, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            return;
                        }
                    }
                    if (WBSetting.region == "2")
                    {
                        FormTransactionMsia msia = new FormTransactionMsia {
                            gatepass_uniq = gt_uniq,
                            gatepass_no = txt_gatepass,
                            card_no = this.cardNo
                        };
                        WBTable table10 = new WBTable();
                        if (table2.DT.Rows.Count == 0)
                        {
                            table10.OpenTable("wb_transaction", "SELECT * FROM wb_transaction WHERE 1 = 2", WBData.conn);
                        }
                        else
                        {
                            string sqltext = "SELECT * FROM wb_transaction WHERE ref = '" + ref_no + "'";
                            table10.OpenTable("wb_transaction", sqltext, WBData.conn);
                            msia.sUniq = table10.DT.Rows[0]["uniq"].ToString();
                        }
                        msia.tblTrans = table10;
                        msia.pMode = pMode;
                        msia.dgvTrans = this.dataGridView1;
                        msia.WX = this.wx;
                        msia.tambahRecord = tambahRecord;
                        msia.ticketRpt = this.ticketRpt;
                        msia.rpt_advise = this.rpt_advise;
                        msia.ticket2Rpt = this.ticket2Rpt;
                        msia.fRpt = this.fRpt;
                        msia.ShowDialog();
                        if (msia.Saved)
                        {
                        }
                        table2.UnLock();
                        msia.Dispose();
                    }
                    else
                    {
                        FormTransaction transaction = new FormTransaction {
                            gatepass_uniq = gt_uniq,
                            gatepass_no = txt_gatepass,
                            card_no = this.cardNo
                        };
                        WBTable table11 = new WBTable();
                        if (table2.DT.Rows.Count == 0)
                        {
                            table11.OpenTable("wb_transaction", "select * from wb_transaction where 1 = 2", WBData.conn);
                        }
                        else
                        {
                            string sqltext = "select * from wb_transaction where ref = '" + ref_no + "'";
                            table11.OpenTable("wb_transaction", sqltext, WBData.conn);
                            transaction.sUniq = table11.DT.Rows[0]["uniq"].ToString();
                        }
                        transaction.tblTrans = table11;
                        transaction.pMode = pMode;
                        transaction.dgvTrans = this.dataGridView1;
                        transaction.tblDeduc = this.tblDeduc;
                        transaction.WX = this.wx;
                        transaction.tambahRecord = tambahRecord;
                        transaction.ticketRpt = this.ticketRpt;
                        transaction.rpt_advise = this.rpt_advise;
                        transaction.ticket2Rpt = this.ticket2Rpt;
                        transaction.fRpt = this.fRpt;
                        transaction.ShowDialog();
                        if (transaction.Saved)
                        {
                        }
                        table2.UnLock();
                        transaction.Dispose();
                    }
                    this.textBox1.Text = "";
                    this.textCard.Text = "";
                    this.comboGatepass.Text = "";
                    this.comboTruck.Text = "";
                    this.textCard.Focus();
                }
                else
                {
                    MessageBox.Show(Resource.RegisGatepassMess_046, "F A I L E D", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    table.Dispose();
                }
            }
            else
            {
                MessageBox.Show(Resource.RegisGatepassMess_045, "FAILED", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void translate()
        {
            this.label1.Text = Resource.Gatepass_001;
            this.label2.Text = Resource.TruckE_002;
            this.button2.Text = Resource.Gatepass_049;
        }
    }
}

