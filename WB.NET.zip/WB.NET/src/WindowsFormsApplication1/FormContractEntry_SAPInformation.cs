﻿namespace WindowsFormsApplication1
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public class FormContractEntry_SAPInformation : Form
    {
        public bool saved = false;
        public DataGridView dgv;
        public int nCurrRow;
        public string pMode;
        private IContainer components = null;
        private Label labelSO;
        public TextBox textSO;
        public TextBox textSOItem;
        private Label labelSOItem;
        public TextBox textComm;
        private Label labelComm;
        public TextBox textQty;
        private Label labelQty;
        private Label label1;
        private Button buttonComm;
        public Label labelComm2;
        private Button buttonSave;
        private Button buttonCancel;
        public TextBox textQtyNonKG;
        private Label label2;
        private Label labelTolerance;
        public TextBox textTolerance;

        public FormContractEntry_SAPInformation()
        {
            this.InitializeComponent();
            this.translate();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void buttonComm_Click(object sender, EventArgs e)
        {
            FormCommodity commodity = new FormCommodity {
                pMode = "CHOOSE",
                pFind = this.textComm.Text.Trim()
            };
            commodity.ShowDialog();
            if (commodity.ReturnRow != null)
            {
                this.textComm.Text = commodity.ReturnRow["Comm_Code"].ToString();
                this.labelComm2.Visible = true;
                this.labelComm2.Text = commodity.ReturnRow["comm_name"].ToString();
            }
            commodity.Dispose();
            this.textComm.Focus();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (this.textSOItem.Text.Trim() != "")
            {
                if (this.textComm.Text.Trim() != "")
                {
                    if (this.textQty.Text.Trim() != "")
                    {
                        if (this.textTolerance.Text.Trim() != "")
                        {
                            if (this.pMode == "ADD")
                            {
                                using (IEnumerator enumerator = ((IEnumerable) this.dgv.Rows).GetEnumerator())
                                {
                                    while (true)
                                    {
                                        if (!enumerator.MoveNext())
                                        {
                                            break;
                                        }
                                        DataGridViewRow current = (DataGridViewRow) enumerator.Current;
                                        if (current.Cells["so_item"].Value.ToString() == this.textSOItem.Text.Trim())
                                        {
                                            MessageBox.Show(this.textSOItem.Text.Trim() + " : " + Resource.Mes_Error_Duplicate_Item, Resource.Mes_Error_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                                            this.textSOItem.Focus();
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show(Resource.Mes_Error_Empty_Tolerance, Resource.Mes_Error_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                            this.textTolerance.Focus();
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show(Resource.Mes_Error_Empty_Qty, Resource.Mes_Error_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.textQty.Focus();
                        return;
                    }
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Error_Empty_Commodity, Resource.Mes_Error_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.textComm.Focus();
                    return;
                }
            }
            else
            {
                MessageBox.Show(Resource.Mes_Error_Empty_SO_Item, Resource.Mes_Error_With_Spaces, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                this.textSOItem.Focus();
                return;
            }
            this.saved = true;
            base.Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void FormContractEntry_SAPInformation_Load(object sender, EventArgs e)
        {
            if (this.pMode == "ADD")
            {
                this.labelComm2.Visible = false;
                this.textSOItem.Text = ((this.dgv.Rows.Count + 1) * 10).ToString();
            }
            WBTable tbl = new WBTable();
            tbl.OpenTable("wb_commodity", "SELECT * FROM wb_commodity WHERE " + WBData.CompanyLocation(""), WBData.conn);
            Program.AutoComp(tbl, "Comm_Code", this.textComm);
            tbl.Dispose();
        }

        private void InitializeComponent()
        {
            this.labelSO = new Label();
            this.textSO = new TextBox();
            this.textSOItem = new TextBox();
            this.labelSOItem = new Label();
            this.textComm = new TextBox();
            this.labelComm = new Label();
            this.textQty = new TextBox();
            this.labelQty = new Label();
            this.label1 = new Label();
            this.buttonComm = new Button();
            this.labelComm2 = new Label();
            this.buttonSave = new Button();
            this.buttonCancel = new Button();
            this.textQtyNonKG = new TextBox();
            this.label2 = new Label();
            this.labelTolerance = new Label();
            this.textTolerance = new TextBox();
            base.SuspendLayout();
            this.labelSO.Location = new Point(14, 0x10);
            this.labelSO.Name = "labelSO";
            this.labelSO.Size = new Size(90, 13);
            this.labelSO.TabIndex = 0;
            this.labelSO.Text = "SO No.";
            this.labelSO.TextAlign = ContentAlignment.MiddleRight;
            this.textSO.Enabled = false;
            this.textSO.Location = new Point(110, 13);
            this.textSO.MaxLength = 10;
            this.textSO.Name = "textSO";
            this.textSO.Size = new Size(0x86, 20);
            this.textSO.TabIndex = 1;
            this.textSOItem.Enabled = false;
            this.textSOItem.Location = new Point(110, 0x27);
            this.textSOItem.MaxLength = 3;
            this.textSOItem.Name = "textSOItem";
            this.textSOItem.Size = new Size(0x2e, 20);
            this.textSOItem.TabIndex = 3;
            this.labelSOItem.Location = new Point(14, 0x2a);
            this.labelSOItem.Name = "labelSOItem";
            this.labelSOItem.Size = new Size(90, 13);
            this.labelSOItem.TabIndex = 2;
            this.labelSOItem.Text = "SO Item";
            this.labelSOItem.TextAlign = ContentAlignment.MiddleRight;
            this.textComm.Location = new Point(110, 0x41);
            this.textComm.Name = "textComm";
            this.textComm.Size = new Size(0x86, 20);
            this.textComm.TabIndex = 5;
            this.textComm.Leave += new EventHandler(this.textComm_Leave);
            this.labelComm.Location = new Point(14, 0x44);
            this.labelComm.Name = "labelComm";
            this.labelComm.Size = new Size(90, 13);
            this.labelComm.TabIndex = 4;
            this.labelComm.Text = "Commodity Code";
            this.labelComm.TextAlign = ContentAlignment.MiddleRight;
            this.textQty.Enabled = false;
            this.textQty.Location = new Point(0x109, 0x5b);
            this.textQty.MaxLength = 10;
            this.textQty.Name = "textQty";
            this.textQty.Size = new Size(0x86, 20);
            this.textQty.TabIndex = 7;
            this.textQty.TextAlign = HorizontalAlignment.Right;
            this.labelQty.Location = new Point(14, 0x5f);
            this.labelQty.Name = "labelQty";
            this.labelQty.Size = new Size(90, 13);
            this.labelQty.TabIndex = 6;
            this.labelQty.Text = "Quantity";
            this.labelQty.TextAlign = ContentAlignment.MiddleRight;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(0x195, 0x5e);
            this.label1.Name = "label1";
            this.label1.Size = new Size(20, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Kg";
            this.buttonComm.Location = new Point(250, 0x3f);
            this.buttonComm.Name = "buttonComm";
            this.buttonComm.Size = new Size(0x19, 0x17);
            this.buttonComm.TabIndex = 9;
            this.buttonComm.Text = "...";
            this.buttonComm.UseVisualStyleBackColor = true;
            this.buttonComm.Click += new EventHandler(this.buttonComm_Click);
            this.labelComm2.AutoSize = true;
            this.labelComm2.Location = new Point(0x119, 0x44);
            this.labelComm2.Name = "labelComm2";
            this.labelComm2.Size = new Size(0x59, 13);
            this.labelComm2.TabIndex = 10;
            this.labelComm2.Text = "Commodity Name";
            this.buttonSave.Location = new Point(0x95, 0xa6);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new Size(0x4b, 0x17);
            this.buttonSave.TabIndex = 11;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new EventHandler(this.buttonSave_Click);
            this.buttonCancel.Location = new Point(230, 0xa6);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new Size(0x4b, 0x17);
            this.buttonCancel.TabIndex = 12;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new EventHandler(this.buttonCancel_Click);
            this.textQtyNonKG.Location = new Point(110, 0x5b);
            this.textQtyNonKG.MaxLength = 10;
            this.textQtyNonKG.Name = "textQtyNonKG";
            this.textQtyNonKG.Size = new Size(0x86, 20);
            this.textQtyNonKG.TabIndex = 13;
            this.textQtyNonKG.TextAlign = HorizontalAlignment.Right;
            this.textQtyNonKG.TextChanged += new EventHandler(this.textQtyNonKG_TextChanged);
            this.label2.AutoSize = true;
            this.label2.Location = new Point(0xf8, 0x5f);
            this.label2.Name = "label2";
            this.label2.Size = new Size(13, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "≈";
            this.labelTolerance.Location = new Point(14, 120);
            this.labelTolerance.Name = "labelTolerance";
            this.labelTolerance.Size = new Size(90, 13);
            this.labelTolerance.TabIndex = 15;
            this.labelTolerance.Text = "Tolerance";
            this.labelTolerance.TextAlign = ContentAlignment.MiddleRight;
            this.textTolerance.Location = new Point(110, 0x75);
            this.textTolerance.MaxLength = 10;
            this.textTolerance.Name = "textTolerance";
            this.textTolerance.Size = new Size(0x86, 20);
            this.textTolerance.TabIndex = 0x10;
            this.textTolerance.TextAlign = HorizontalAlignment.Right;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x1d0, 0xd4);
            base.Controls.Add(this.textTolerance);
            base.Controls.Add(this.labelTolerance);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.textQtyNonKG);
            base.Controls.Add(this.buttonCancel);
            base.Controls.Add(this.buttonSave);
            base.Controls.Add(this.labelComm2);
            base.Controls.Add(this.buttonComm);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.textQty);
            base.Controls.Add(this.labelQty);
            base.Controls.Add(this.textComm);
            base.Controls.Add(this.labelComm);
            base.Controls.Add(this.textSOItem);
            base.Controls.Add(this.labelSOItem);
            base.Controls.Add(this.textSO);
            base.Controls.Add(this.labelSO);
            base.Name = "FormContractEntry_SAPInformation";
            base.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "SO Item Detail";
            base.Load += new EventHandler(this.FormContractEntry_SAPInformation_Load);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void textComm_Leave(object sender, EventArgs e)
        {
            if (this.textComm.Text.Trim() == "")
            {
                this.labelComm2.Text = "";
            }
            else
            {
                WBTable table = new WBTable();
                string sqltext = "select * from wb_commodity where " + WBData.CompanyLocation(" AND comm_code = '" + this.textComm.Text.Trim() + "'");
                table.OpenTable("wb_commodity", sqltext, WBData.conn);
                if (table.DT.Rows.Count <= 0)
                {
                    MessageBox.Show(Resource.Mes_Warning_Commodity_Not_Found, Resource.Mes_Warning_Caps);
                    this.textComm.Text = "";
                    table.Close();
                }
                else if (table.DT.Rows[0]["Deleted"].ToString() != "Y")
                {
                    this.labelComm2.Visible = true;
                    this.labelComm2.Text = table.DT.Rows[0]["comm_name"].ToString();
                }
                else
                {
                    MessageBox.Show(Resource.Mes_Warning_Deleted_Commodity, Resource.Mes_Warning_Caps);
                    this.textComm.Text = "";
                    table.Close();
                }
            }
        }

        private void textQtyNonKG_TextChanged(object sender, EventArgs e)
        {
            if (this.textComm.Text.Trim() == "")
            {
                this.textQty.Text = "0";
            }
            else
            {
                WBTable table = new WBTable();
                table.OpenTable("wb_commodity", "SELECT gross_weight FROM wb_commodity WHERE " + WBData.CompanyLocation(" AND comm_code = '" + this.textComm.Text.Trim() + "'"), WBData.conn);
                if (table.DT.Rows.Count > 0)
                {
                    double num = 0.0;
                    double num2 = 0.0;
                    try
                    {
                        num = Convert.ToDouble(table.DT.Rows[0]["gross_weight"].ToString());
                        num2 = Convert.ToDouble(this.textQtyNonKG.Text.Trim());
                    }
                    catch
                    {
                    }
                    if (!(num == 0.0))
                    {
                        this.textQty.Text = (num * num2).ToString();
                    }
                    else
                    {
                        object[] objArray1 = new object[] { Resource.Mes_Error_Maintain_Gross_Weight, " '", this.textComm, "'!" };
                        MessageBox.Show(string.Concat(objArray1), Resource.Mes_Error_Caps, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        this.textQty.Text = "0";
                    }
                }
            }
        }

        private void translate()
        {
            this.labelSO.Text = Resource.Lbl_SO;
            this.labelSOItem.Text = Resource.Setting_084;
            this.labelComm.Text = Resource.CommE_001;
            this.labelQty.Text = Resource.Contract_008;
            this.labelComm2.Text = Resource.CommE_003;
            this.labelTolerance.Text = Resource.Contract_055;
            this.buttonSave.Text = Resource.Btn_Save;
            this.buttonCancel.Text = Resource.Btn_Cancel;
            this.Text = Resource.Title_SO_Item_Detail;
        }
    }
}

